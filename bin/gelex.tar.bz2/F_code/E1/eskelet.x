#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif
extern const char *names2[];
static const uint32 types2 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT64,
SK_UINT64,
SK_UINT64,
SK_UINT64,
};

static const uint16 attr_flags2 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype2_0 [] = {1182,843,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype2_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype2_2 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype2_3 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype2_4 [] = {843,0xFFFF};
static const EIF_TYPE_INDEX g_atype2_5 [] = {843,0xFFFF};
static const EIF_TYPE_INDEX g_atype2_6 [] = {843,0xFFFF};
static const EIF_TYPE_INDEX g_atype2_7 [] = {843,0xFFFF};

static const EIF_TYPE_INDEX *gtypes2 [] = {
g_atype2_0,
g_atype2_1,
g_atype2_2,
g_atype2_3,
g_atype2_4,
g_atype2_5,
g_atype2_6,
g_atype2_7,
};

static const long offsets2 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @I64OFF(1,3,0,0,0,0,0),
+ @I64OFF(1,3,0,0,0,0,1),
+ @I64OFF(1,3,0,0,0,0,2),
+ @I64OFF(1,3,0,0,0,0,3),
};

extern const char *names4[];
static const uint32 types4 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags4 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype4_0 [] = {0xFF01,786,900,0xFF01,912,0xFFFF};
static const EIF_TYPE_INDEX g_atype4_1 [] = {0xFF01,785,0xFF01,912,0xFF01,912,0xFFFF};

static const EIF_TYPE_INDEX *gtypes4 [] = {
g_atype4_0,
g_atype4_1,
};

static const long offsets4 [] =
{
0,
 + @REFACS(1),
};

extern const char *names6[];
static const uint32 types6 [] =
{
SK_UINT32,
};

static const uint16 attr_flags6 [] =
{1,};

static const EIF_TYPE_INDEX g_atype6_0 [] = {846,0xFFFF};

static const EIF_TYPE_INDEX *gtypes6 [] = {
g_atype6_0,
};

static const long offsets6 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names11[];
static const uint32 types11 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags11 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype11_0 [] = {0xFF01,912,0xFFFF};
static const EIF_TYPE_INDEX g_atype11_1 [] = {0xFF01,971,0xFFFF};

static const EIF_TYPE_INDEX *gtypes11 [] = {
g_atype11_0,
g_atype11_1,
};

static const long offsets11 [] =
{
0,
 + @REFACS(1),
};

extern const char *names27[];
static const uint32 types27 [] =
{
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags27 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype27_0 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype27_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype27_2 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype27_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes27 [] = {
g_atype27_0,
g_atype27_1,
g_atype27_2,
g_atype27_3,
};

static const long offsets27 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
+ @CHROFF(0,2),
+ @LNGOFF(0,3,0,0),
};

extern const char *names43[];
static const uint32 types43 [] =
{
SK_REF,
};

static const uint16 attr_flags43 [] =
{0,};

static const EIF_TYPE_INDEX g_atype43_0 [] = {663,0xFFFF};

static const EIF_TYPE_INDEX *gtypes43 [] = {
g_atype43_0,
};

static const long offsets43 [] =
{
0,
};

extern const char *names45[];
static const uint32 types45 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags45 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype45_0 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype45_1 [] = {0xFF01,1158,0xFF01,1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype45_2 [] = {0xFF01,1158,0xFF01,1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype45_3 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype45_4 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype45_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes45 [] = {
g_atype45_0,
g_atype45_1,
g_atype45_2,
g_atype45_3,
g_atype45_4,
g_atype45_5,
};

static const long offsets45 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @LNGOFF(3,2,0,0),
};

extern const char *names46[];
static const uint32 types46 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags46 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype46_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_2 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_3 [] = {0xFF01,1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_4 [] = {0xFF01,1158,0xFF01,162,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_5 [] = {0xFF01,1158,0xFF01,162,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_6 [] = {95,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_7 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_8 [] = {0xFF01,1158,0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_9 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_10 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_11 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_12 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_13 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_14 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_15 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_16 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_17 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_18 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_19 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_20 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_21 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_22 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_23 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_24 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_25 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_26 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_27 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_28 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_29 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_30 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_31 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_32 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes46 [] = {
g_atype46_0,
g_atype46_1,
g_atype46_2,
g_atype46_3,
g_atype46_4,
g_atype46_5,
g_atype46_6,
g_atype46_7,
g_atype46_8,
g_atype46_9,
g_atype46_10,
g_atype46_11,
g_atype46_12,
g_atype46_13,
g_atype46_14,
g_atype46_15,
g_atype46_16,
g_atype46_17,
g_atype46_18,
g_atype46_19,
g_atype46_20,
g_atype46_21,
g_atype46_22,
g_atype46_23,
g_atype46_24,
g_atype46_25,
g_atype46_26,
g_atype46_27,
g_atype46_28,
g_atype46_29,
g_atype46_30,
g_atype46_31,
g_atype46_32,
};

static const long offsets46 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
+ @CHROFF(9,1),
+ @CHROFF(9,2),
+ @CHROFF(9,3),
+ @CHROFF(9,4),
+ @CHROFF(9,5),
+ @CHROFF(9,6),
+ @CHROFF(9,7),
+ @CHROFF(9,8),
+ @CHROFF(9,9),
+ @CHROFF(9,10),
+ @CHROFF(9,11),
+ @CHROFF(9,12),
+ @CHROFF(9,13),
+ @CHROFF(9,14),
+ @CHROFF(9,15),
+ @CHROFF(9,16),
+ @CHROFF(9,17),
+ @CHROFF(9,18),
+ @CHROFF(9,19),
+ @CHROFF(9,20),
+ @CHROFF(9,21),
+ @LNGOFF(9,22,0,0),
+ @LNGOFF(9,22,0,1),
};

extern const char *names47[];
static const uint32 types47 [] =
{
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags47 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype47_0 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype47_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype47_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype47_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes47 [] = {
g_atype47_0,
g_atype47_1,
g_atype47_2,
g_atype47_3,
};

static const long offsets47 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
+ @LNGOFF(0,0,0,2),
+ @LNGOFF(0,0,0,3),
};

extern const char *names48[];
static const uint32 types48 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags48 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype48_0 [] = {0xFF01,1066,0xFF01,1069,0xFFFF};
static const EIF_TYPE_INDEX g_atype48_1 [] = {0xFF01,1069,0xFFFF};
static const EIF_TYPE_INDEX g_atype48_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes48 [] = {
g_atype48_0,
g_atype48_1,
g_atype48_2,
};

static const long offsets48 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names61[];
static const uint32 types61 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags61 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype61_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype61_1 [] = {902,0xFF01,0xFFF9,1,828,0xFF01,241,0xFFFF};
static const EIF_TYPE_INDEX g_atype61_2 [] = {902,0xFF01,0xFFF9,2,828,0xFF01,241,0xFF01,241,0xFFFF};
static const EIF_TYPE_INDEX g_atype61_3 [] = {902,0xFF01,0xFFF9,1,828,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype61_4 [] = {773,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype61_5 [] = {789,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype61_6 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype61_7 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype61_8 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype61_9 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype61_10 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype61_11 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes61 [] = {
g_atype61_0,
g_atype61_1,
g_atype61_2,
g_atype61_3,
g_atype61_4,
g_atype61_5,
g_atype61_6,
g_atype61_7,
g_atype61_8,
g_atype61_9,
g_atype61_10,
g_atype61_11,
};

static const long offsets61 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
};

extern const char *names62[];
static const uint32 types62 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags62 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype62_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_1 [] = {902,0xFF01,0xFFF9,1,828,0xFF01,241,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_2 [] = {902,0xFF01,0xFFF9,2,828,0xFF01,241,0xFF01,241,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_3 [] = {902,0xFF01,0xFFF9,1,828,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_4 [] = {773,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_5 [] = {789,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_6 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_7 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_8 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_9 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_10 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_11 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes62 [] = {
g_atype62_0,
g_atype62_1,
g_atype62_2,
g_atype62_3,
g_atype62_4,
g_atype62_5,
g_atype62_6,
g_atype62_7,
g_atype62_8,
g_atype62_9,
g_atype62_10,
g_atype62_11,
};

static const long offsets62 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
};

extern const char *names74[];
static const uint32 types74 [] =
{
SK_REF,
};

static const uint16 attr_flags74 [] =
{0,};

static const EIF_TYPE_INDEX g_atype74_0 [] = {0xFF01,127,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes74 [] = {
g_atype74_0,
};

static const long offsets74 [] =
{
0,
};

extern const char *names75[];
static const uint32 types75 [] =
{
SK_REF,
};

static const uint16 attr_flags75 [] =
{0,};

static const EIF_TYPE_INDEX g_atype75_0 [] = {0xFF01,128,834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes75 [] = {
g_atype75_0,
};

static const long offsets75 [] =
{
0,
};

extern const char *names76[];
static const uint32 types76 [] =
{
SK_REF,
};

static const uint16 attr_flags76 [] =
{0,};

static const EIF_TYPE_INDEX g_atype76_0 [] = {0xFF01,127,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes76 [] = {
g_atype76_0,
};

static const long offsets76 [] =
{
0,
};

extern const char *names77[];
static const uint32 types77 [] =
{
SK_REF,
};

static const uint16 attr_flags77 [] =
{0,};

static const EIF_TYPE_INDEX g_atype77_0 [] = {0xFF01,127,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes77 [] = {
g_atype77_0,
};

static const long offsets77 [] =
{
0,
};

extern const char *names78[];
static const uint32 types78 [] =
{
SK_REF,
};

static const uint16 attr_flags78 [] =
{0,};

static const EIF_TYPE_INDEX g_atype78_0 [] = {0xFF01,128,834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes78 [] = {
g_atype78_0,
};

static const long offsets78 [] =
{
0,
};

extern const char *names80[];
static const uint32 types80 [] =
{
SK_REF,
};

static const uint16 attr_flags80 [] =
{0,};

static const EIF_TYPE_INDEX g_atype80_0 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes80 [] = {
g_atype80_0,
};

static const long offsets80 [] =
{
0,
};

extern const char *names81[];
static const uint32 types81 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags81 [] =
{0,};

static const EIF_TYPE_INDEX g_atype81_0 [] = {864,0xFFFF};

static const EIF_TYPE_INDEX *gtypes81 [] = {
g_atype81_0,
};

static const long offsets81 [] =
{
+ @CHROFF(0,0),
};

extern const char *names82[];
static const uint32 types82 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags82 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype82_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype82_1 [] = {81,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes82 [] = {
g_atype82_0,
g_atype82_1,
};

static const long offsets82 [] =
{
0,
 + @REFACS(1),
};

extern const char *names83[];
static const uint32 types83 [] =
{
SK_REF,
SK_CHAR8,
};

static const uint16 attr_flags83 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype83_0 [] = {82,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype83_1 [] = {864,0xFFFF};

static const EIF_TYPE_INDEX *gtypes83 [] = {
g_atype83_0,
g_atype83_1,
};

static const long offsets83 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names96[];
static const uint32 types96 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags96 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype96_0 [] = {0xFF01,701,0xFF01,158,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes96 [] = {
g_atype96_0,
g_atype96_1,
g_atype96_2,
};

static const long offsets96 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names97[];
static const uint32 types97 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags97 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype97_0 [] = {0xFF01,701,0xFF01,158,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_1 [] = {0xFF01,1170,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes97 [] = {
g_atype97_0,
g_atype97_1,
g_atype97_2,
g_atype97_3,
};

static const long offsets97 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names101[];
static const uint32 types101 [] =
{
SK_REF,
};

static const uint16 attr_flags101 [] =
{0,};

static const EIF_TYPE_INDEX g_atype101_0 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes101 [] = {
g_atype101_0,
};

static const long offsets101 [] =
{
0,
};

extern const char *names102[];
static const uint32 types102 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags102 [] =
{0,};

static const EIF_TYPE_INDEX g_atype102_0 [] = {861,0xFFFF};

static const EIF_TYPE_INDEX *gtypes102 [] = {
g_atype102_0,
};

static const long offsets102 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names103[];
static const uint32 types103 [] =
{
SK_UINT64,
};

static const uint16 attr_flags103 [] =
{0,};

static const EIF_TYPE_INDEX g_atype103_0 [] = {843,0xFFFF};

static const EIF_TYPE_INDEX *gtypes103 [] = {
g_atype103_0,
};

static const long offsets103 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names104[];
static const uint32 types104 [] =
{
SK_INT32,
};

static const uint16 attr_flags104 [] =
{0,};

static const EIF_TYPE_INDEX g_atype104_0 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes104 [] = {
g_atype104_0,
};

static const long offsets104 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names105[];
static const uint32 types105 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags105 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype105_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype105_1 [] = {104,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes105 [] = {
g_atype105_0,
g_atype105_1,
};

static const long offsets105 [] =
{
0,
 + @REFACS(1),
};

extern const char *names106[];
static const uint32 types106 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags106 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype106_0 [] = {105,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype106_1 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes106 [] = {
g_atype106_0,
g_atype106_1,
};

static const long offsets106 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names109[];
static const uint32 types109 [] =
{
SK_REF,
};

static const uint16 attr_flags109 [] =
{0,};

static const EIF_TYPE_INDEX g_atype109_0 [] = {0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes109 [] = {
g_atype109_0,
};

static const long offsets109 [] =
{
0,
};

extern const char *names116[];
static const uint32 types116 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags116 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype116_0 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_2 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_3 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_4 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes116 [] = {
g_atype116_0,
g_atype116_1,
g_atype116_2,
g_atype116_3,
g_atype116_4,
g_atype116_5,
g_atype116_6,
};

static const long offsets116 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
};

extern const char *names117[];
static const uint32 types117 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags117 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype117_0 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype117_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype117_2 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype117_3 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype117_4 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype117_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype117_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype117_7 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes117 [] = {
g_atype117_0,
g_atype117_1,
g_atype117_2,
g_atype117_3,
g_atype117_4,
g_atype117_5,
g_atype117_6,
g_atype117_7,
};

static const long offsets117 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
};

extern const char *names118[];
static const uint32 types118 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags118 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype118_0 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_2 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_3 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_4 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_6 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_7 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_8 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_9 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype118_10 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes118 [] = {
g_atype118_0,
g_atype118_1,
g_atype118_2,
g_atype118_3,
g_atype118_4,
g_atype118_5,
g_atype118_6,
g_atype118_7,
g_atype118_8,
g_atype118_9,
g_atype118_10,
};

static const long offsets118 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @LNGOFF(4,6,0,0),
};

extern const char *names119[];
static const uint32 types119 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags119 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype119_0 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_2 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_3 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_4 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_6 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_7 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_8 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_9 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype119_10 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes119 [] = {
g_atype119_0,
g_atype119_1,
g_atype119_2,
g_atype119_3,
g_atype119_4,
g_atype119_5,
g_atype119_6,
g_atype119_7,
g_atype119_8,
g_atype119_9,
g_atype119_10,
};

static const long offsets119 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @CHROFF(3,3),
+ @CHROFF(3,4),
+ @CHROFF(3,5),
+ @CHROFF(3,6),
+ @LNGOFF(3,7,0,0),
};

extern const char *names120[];
static const uint32 types120 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags120 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype120_0 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_2 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_3 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_4 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_6 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_7 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_8 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype120_10 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes120 [] = {
g_atype120_0,
g_atype120_1,
g_atype120_2,
g_atype120_3,
g_atype120_4,
g_atype120_5,
g_atype120_6,
g_atype120_7,
g_atype120_8,
g_atype120_9,
g_atype120_10,
};

static const long offsets120 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @CHROFF(3,3),
+ @CHROFF(3,4),
+ @CHROFF(3,5),
+ @LNGOFF(3,6,0,0),
+ @LNGOFF(3,6,0,1),
};

extern const char *names121[];
static const uint32 types121 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags121 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype121_0 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype121_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype121_2 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype121_3 [] = {0xFF01,1141,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype121_4 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype121_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype121_6 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype121_7 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype121_8 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype121_9 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype121_10 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype121_11 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes121 [] = {
g_atype121_0,
g_atype121_1,
g_atype121_2,
g_atype121_3,
g_atype121_4,
g_atype121_5,
g_atype121_6,
g_atype121_7,
g_atype121_8,
g_atype121_9,
g_atype121_10,
g_atype121_11,
};

static const long offsets121 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @LNGOFF(4,6,0,0),
+ @LNGOFF(4,6,0,1),
};

extern const char *names122[];
static const uint32 types122 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags122 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype122_0 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_2 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_3 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_4 [] = {0xFF01,1140,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_5 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_6 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_7 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_8 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_9 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_10 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_11 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes122 [] = {
g_atype122_0,
g_atype122_1,
g_atype122_2,
g_atype122_3,
g_atype122_4,
g_atype122_5,
g_atype122_6,
g_atype122_7,
g_atype122_8,
g_atype122_9,
g_atype122_10,
g_atype122_11,
};

static const long offsets122 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @LNGOFF(5,6,0,0),
};

extern const char *names132[];
static const uint32 types132 [] =
{
SK_REF,
};

static const uint16 attr_flags132 [] =
{0,};

static const EIF_TYPE_INDEX g_atype132_0 [] = {0xFF01,127,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes132 [] = {
g_atype132_0,
};

static const long offsets132 [] =
{
0,
};

extern const char *names133[];
static const uint32 types133 [] =
{
SK_REF,
};

static const uint16 attr_flags133 [] =
{0,};

static const EIF_TYPE_INDEX g_atype133_0 [] = {0xFF01,128,834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes133 [] = {
g_atype133_0,
};

static const long offsets133 [] =
{
0,
};

extern const char *names138[];
static const uint32 types138 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags138 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype138_0 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype138_1 [] = {676,0xFF01,677,834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes138 [] = {
g_atype138_0,
g_atype138_1,
};

static const long offsets138 [] =
{
0,
 + @REFACS(1),
};

extern const char *names139[];
static const uint32 types139 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags139 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype139_0 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_1 [] = {676,0xFF01,677,834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes139 [] = {
g_atype139_0,
g_atype139_1,
};

static const long offsets139 [] =
{
0,
 + @REFACS(1),
};

extern const char *names140[];
static const uint32 types140 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags140 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype140_0 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_1 [] = {676,0xFF01,677,834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes140 [] = {
g_atype140_0,
g_atype140_1,
};

static const long offsets140 [] =
{
0,
 + @REFACS(1),
};

extern const char *names142[];
static const uint32 types142 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags142 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype142_0 [] = {0xFF01,681,843,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_1 [] = {0xFF01,681,843,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_2 [] = {0xFF01,681,843,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_3 [] = {0xFF01,681,843,0xFFFF};

static const EIF_TYPE_INDEX *gtypes142 [] = {
g_atype142_0,
g_atype142_1,
g_atype142_2,
g_atype142_3,
};

static const long offsets142 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names143[];
static const uint32 types143 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags143 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype143_0 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype143_1 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype143_2 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype143_3 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype143_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype143_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype143_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes143 [] = {
g_atype143_0,
g_atype143_1,
g_atype143_2,
g_atype143_3,
g_atype143_4,
g_atype143_5,
g_atype143_6,
};

static const long offsets143 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
+ @LNGOFF(2,2,0,1),
+ @LNGOFF(2,2,0,2),
};

extern const char *names144[];
static const uint32 types144 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
SK_UINT64,
};

static const uint16 attr_flags144 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype144_0 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_1 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_2 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_3 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_4 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_9 [] = {843,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_10 [] = {843,0xFFFF};

static const EIF_TYPE_INDEX *gtypes144 [] = {
g_atype144_0,
g_atype144_1,
g_atype144_2,
g_atype144_3,
g_atype144_4,
g_atype144_5,
g_atype144_6,
g_atype144_7,
g_atype144_8,
g_atype144_9,
g_atype144_10,
};

static const long offsets144 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
+ @LNGOFF(2,4,0,2),
+ @I64OFF(2,4,0,3,0,0,0),
+ @I64OFF(2,4,0,3,0,0,1),
};

extern const char *names145[];
static const uint32 types145 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
SK_UINT64,
};

static const uint16 attr_flags145 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype145_0 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype145_1 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype145_2 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype145_3 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype145_4 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype145_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype145_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype145_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype145_8 [] = {843,0xFFFF};
static const EIF_TYPE_INDEX g_atype145_9 [] = {843,0xFFFF};

static const EIF_TYPE_INDEX *gtypes145 [] = {
g_atype145_0,
g_atype145_1,
g_atype145_2,
g_atype145_3,
g_atype145_4,
g_atype145_5,
g_atype145_6,
g_atype145_7,
g_atype145_8,
g_atype145_9,
};

static const long offsets145 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
+ @LNGOFF(2,3,0,1),
+ @LNGOFF(2,3,0,2),
+ @I64OFF(2,3,0,3,0,0,0),
+ @I64OFF(2,3,0,3,0,0,1),
};

extern const char *names146[];
static const uint32 types146 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL64,
SK_REAL64,
SK_REAL64,
};

static const uint16 attr_flags146 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype146_0 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_1 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_2 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_3 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_4 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_6 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_7 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_10 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_11 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_12 [] = {858,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_13 [] = {858,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_14 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes146 [] = {
g_atype146_0,
g_atype146_1,
g_atype146_2,
g_atype146_3,
g_atype146_4,
g_atype146_5,
g_atype146_6,
g_atype146_7,
g_atype146_8,
g_atype146_9,
g_atype146_10,
g_atype146_11,
g_atype146_12,
g_atype146_13,
g_atype146_14,
};

static const long offsets146 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @CHROFF(2,4),
+ @CHROFF(2,5),
+ @LNGOFF(2,6,0,0),
+ @LNGOFF(2,6,0,1),
+ @LNGOFF(2,6,0,2),
+ @LNGOFF(2,6,0,3),
+ @R64OFF(2,6,0,4,0,0,0,0),
+ @R64OFF(2,6,0,4,0,0,0,1),
+ @R64OFF(2,6,0,4,0,0,0,2),
};

extern const char *names149[];
static const uint32 types149 [] =
{
SK_REF,
};

static const uint16 attr_flags149 [] =
{0,};

static const EIF_TYPE_INDEX g_atype149_0 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes149 [] = {
g_atype149_0,
};

static const long offsets149 [] =
{
0,
};

extern const char *names150[];
static const uint32 types150 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags150 [] =
{0,};

static const EIF_TYPE_INDEX g_atype150_0 [] = {864,0xFFFF};

static const EIF_TYPE_INDEX *gtypes150 [] = {
g_atype150_0,
};

static const long offsets150 [] =
{
+ @CHROFF(0,0),
};

extern const char *names151[];
static const uint32 types151 [] =
{
SK_INT32,
};

static const uint16 attr_flags151 [] =
{0,};

static const EIF_TYPE_INDEX g_atype151_0 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes151 [] = {
g_atype151_0,
};

static const long offsets151 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names152[];
static const uint32 types152 [] =
{
SK_BOOL,
};

static const uint16 attr_flags152 [] =
{0,};

static const EIF_TYPE_INDEX g_atype152_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes152 [] = {
g_atype152_0,
};

static const long offsets152 [] =
{
+ @CHROFF(0,0),
};

extern const char *names153[];
static const uint32 types153 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags153 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype153_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype153_1 [] = {0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes153 [] = {
g_atype153_0,
g_atype153_1,
};

static const long offsets153 [] =
{
0,
 + @REFACS(1),
};

extern const char *names154[];
static const uint32 types154 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags154 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype154_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_1 [] = {153,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes154 [] = {
g_atype154_0,
g_atype154_1,
};

static const long offsets154 [] =
{
0,
 + @REFACS(1),
};

extern const char *names155[];
static const uint32 types155 [] =
{
SK_REF,
SK_CHAR8,
};

static const uint16 attr_flags155 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype155_0 [] = {154,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_1 [] = {864,0xFFFF};

static const EIF_TYPE_INDEX *gtypes155 [] = {
g_atype155_0,
g_atype155_1,
};

static const long offsets155 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names156[];
static const uint32 types156 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags156 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype156_0 [] = {155,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_1 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes156 [] = {
g_atype156_0,
g_atype156_1,
};

static const long offsets156 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names157[];
static const uint32 types157 [] =
{
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags157 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype157_0 [] = {156,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_1 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes157 [] = {
g_atype157_0,
g_atype157_1,
};

static const long offsets157 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names158[];
static const uint32 types158 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags158 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype158_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_1 [] = {157,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_2 [] = {157,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes158 [] = {
g_atype158_0,
g_atype158_1,
g_atype158_2,
};

static const long offsets158 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names159[];
static const uint32 types159 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags159 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype159_0 [] = {158,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype159_1 [] = {158,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype159_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes159 [] = {
g_atype159_0,
g_atype159_1,
g_atype159_2,
};

static const long offsets159 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names163[];
static const uint32 types163 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags163 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype163_0 [] = {0xFF01,107,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_1 [] = {0xFF01,1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_2 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_3 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_9 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes163 [] = {
g_atype163_0,
g_atype163_1,
g_atype163_2,
g_atype163_3,
g_atype163_4,
g_atype163_5,
g_atype163_6,
g_atype163_7,
g_atype163_8,
g_atype163_9,
};

static const long offsets163 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
+ @LNGOFF(2,2,0,1),
+ @LNGOFF(2,2,0,2),
+ @LNGOFF(2,2,0,3),
+ @LNGOFF(2,2,0,4),
+ @LNGOFF(2,2,0,5),
};

extern const char *names166[];
static const uint32 types166 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags166 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype166_0 [] = {0xFF01,92,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_2 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_3 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_9 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes166 [] = {
g_atype166_0,
g_atype166_1,
g_atype166_2,
g_atype166_3,
g_atype166_4,
g_atype166_5,
g_atype166_6,
g_atype166_7,
g_atype166_8,
g_atype166_9,
};

static const long offsets166 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @LNGOFF(1,3,0,0),
+ @LNGOFF(1,3,0,1),
+ @LNGOFF(1,3,0,2),
+ @LNGOFF(1,3,0,3),
+ @LNGOFF(1,3,0,4),
+ @LNGOFF(1,3,0,5),
};

extern const char *names167[];
static const uint32 types167 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags167 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype167_0 [] = {0xFF01,92,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_2 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_3 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_9 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes167 [] = {
g_atype167_0,
g_atype167_1,
g_atype167_2,
g_atype167_3,
g_atype167_4,
g_atype167_5,
g_atype167_6,
g_atype167_7,
g_atype167_8,
g_atype167_9,
};

static const long offsets167 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @LNGOFF(1,3,0,0),
+ @LNGOFF(1,3,0,1),
+ @LNGOFF(1,3,0,2),
+ @LNGOFF(1,3,0,3),
+ @LNGOFF(1,3,0,4),
+ @LNGOFF(1,3,0,5),
};

extern const char *names168[];
static const uint32 types168 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags168 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype168_0 [] = {0xFF01,269,0xFFFF};
static const EIF_TYPE_INDEX g_atype168_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype168_2 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype168_3 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype168_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype168_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype168_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype168_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype168_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype168_9 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes168 [] = {
g_atype168_0,
g_atype168_1,
g_atype168_2,
g_atype168_3,
g_atype168_4,
g_atype168_5,
g_atype168_6,
g_atype168_7,
g_atype168_8,
g_atype168_9,
};

static const long offsets168 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @LNGOFF(1,3,0,0),
+ @LNGOFF(1,3,0,1),
+ @LNGOFF(1,3,0,2),
+ @LNGOFF(1,3,0,3),
+ @LNGOFF(1,3,0,4),
+ @LNGOFF(1,3,0,5),
};

extern const char *names169[];
static const uint32 types169 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags169 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype169_0 [] = {0xFF01,92,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_1 [] = {0xFF01,944,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_2 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_3 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_4 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_10 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_11 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes169 [] = {
g_atype169_0,
g_atype169_1,
g_atype169_2,
g_atype169_3,
g_atype169_4,
g_atype169_5,
g_atype169_6,
g_atype169_7,
g_atype169_8,
g_atype169_9,
g_atype169_10,
g_atype169_11,
};

static const long offsets169 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
+ @LNGOFF(2,4,0,2),
+ @LNGOFF(2,4,0,3),
+ @LNGOFF(2,4,0,4),
+ @LNGOFF(2,4,0,5),
};

extern const char *names170[];
static const uint32 types170 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags170 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype170_0 [] = {0xFF01,92,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_1 [] = {0xFF01,944,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_2 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_3 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_4 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_10 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_11 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_12 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_13 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes170 [] = {
g_atype170_0,
g_atype170_1,
g_atype170_2,
g_atype170_3,
g_atype170_4,
g_atype170_5,
g_atype170_6,
g_atype170_7,
g_atype170_8,
g_atype170_9,
g_atype170_10,
g_atype170_11,
g_atype170_12,
g_atype170_13,
};

static const long offsets170 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
+ @LNGOFF(2,4,0,2),
+ @LNGOFF(2,4,0,3),
+ @LNGOFF(2,4,0,4),
+ @LNGOFF(2,4,0,5),
+ @LNGOFF(2,4,0,6),
+ @LNGOFF(2,4,0,7),
};

extern const char *names171[];
static const uint32 types171 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags171 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype171_0 [] = {0xFF01,269,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_1 [] = {0xFF01,944,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_2 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_3 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_4 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_6 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_10 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_11 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_12 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_13 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_14 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes171 [] = {
g_atype171_0,
g_atype171_1,
g_atype171_2,
g_atype171_3,
g_atype171_4,
g_atype171_5,
g_atype171_6,
g_atype171_7,
g_atype171_8,
g_atype171_9,
g_atype171_10,
g_atype171_11,
g_atype171_12,
g_atype171_13,
g_atype171_14,
};

static const long offsets171 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @CHROFF(2,4),
+ @LNGOFF(2,5,0,0),
+ @LNGOFF(2,5,0,1),
+ @LNGOFF(2,5,0,2),
+ @LNGOFF(2,5,0,3),
+ @LNGOFF(2,5,0,4),
+ @LNGOFF(2,5,0,5),
+ @LNGOFF(2,5,0,6),
+ @LNGOFF(2,5,0,7),
};

extern const char *names173[];
static const uint32 types173 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags173 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype173_0 [] = {104,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype173_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype173_2 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes173 [] = {
g_atype173_0,
g_atype173_1,
g_atype173_2,
};

static const long offsets173 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names174[];
static const uint32 types174 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags174 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype174_0 [] = {105,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype174_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype174_2 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes174 [] = {
g_atype174_0,
g_atype174_1,
g_atype174_2,
};

static const long offsets174 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names175[];
static const uint32 types175 [] =
{
SK_INT32,
};

static const uint16 attr_flags175 [] =
{0,};

static const EIF_TYPE_INDEX g_atype175_0 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes175 [] = {
g_atype175_0,
};

static const long offsets175 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names176[];
static const uint32 types176 [] =
{
SK_INT32,
};

static const uint16 attr_flags176 [] =
{0,};

static const EIF_TYPE_INDEX g_atype176_0 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes176 [] = {
g_atype176_0,
};

static const long offsets176 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names180[];
static const uint32 types180 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags180 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype180_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes180 [] = {
g_atype180_0,
g_atype180_1,
g_atype180_2,
g_atype180_3,
g_atype180_4,
g_atype180_5,
g_atype180_6,
};

static const long offsets180 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names181[];
static const uint32 types181 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags181 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype181_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes181 [] = {
g_atype181_0,
g_atype181_1,
g_atype181_2,
g_atype181_3,
g_atype181_4,
g_atype181_5,
g_atype181_6,
};

static const long offsets181 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names182[];
static const uint32 types182 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags182 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype182_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes182 [] = {
g_atype182_0,
g_atype182_1,
g_atype182_2,
g_atype182_3,
g_atype182_4,
g_atype182_5,
g_atype182_6,
};

static const long offsets182 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names183[];
static const uint32 types183 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags183 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype183_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes183 [] = {
g_atype183_0,
g_atype183_1,
g_atype183_2,
g_atype183_3,
g_atype183_4,
g_atype183_5,
g_atype183_6,
};

static const long offsets183 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names184[];
static const uint32 types184 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags184 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype184_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes184 [] = {
g_atype184_0,
g_atype184_1,
g_atype184_2,
g_atype184_3,
g_atype184_4,
g_atype184_5,
g_atype184_6,
};

static const long offsets184 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names185[];
static const uint32 types185 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags185 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype185_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes185 [] = {
g_atype185_0,
g_atype185_1,
g_atype185_2,
g_atype185_3,
g_atype185_4,
g_atype185_5,
g_atype185_6,
};

static const long offsets185 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names186[];
static const uint32 types186 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags186 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype186_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes186 [] = {
g_atype186_0,
g_atype186_1,
g_atype186_2,
g_atype186_3,
g_atype186_4,
g_atype186_5,
g_atype186_6,
};

static const long offsets186 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names187[];
static const uint32 types187 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags187 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype187_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_7 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes187 [] = {
g_atype187_0,
g_atype187_1,
g_atype187_2,
g_atype187_3,
g_atype187_4,
g_atype187_5,
g_atype187_6,
g_atype187_7,
};

static const long offsets187 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names188[];
static const uint32 types188 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags188 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype188_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_5 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_6 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_9 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes188 [] = {
g_atype188_0,
g_atype188_1,
g_atype188_2,
g_atype188_3,
g_atype188_4,
g_atype188_5,
g_atype188_6,
g_atype188_7,
g_atype188_8,
g_atype188_9,
};

static const long offsets188 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @LNGOFF(6,1,0,0),
+ @LNGOFF(6,1,0,1),
+ @LNGOFF(6,1,0,2),
};

extern const char *names189[];
static const uint32 types189 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags189 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype189_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype189_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype189_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype189_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype189_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype189_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype189_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype189_7 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes189 [] = {
g_atype189_0,
g_atype189_1,
g_atype189_2,
g_atype189_3,
g_atype189_4,
g_atype189_5,
g_atype189_6,
g_atype189_7,
};

static const long offsets189 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names190[];
static const uint32 types190 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags190 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype190_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype190_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype190_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype190_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype190_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype190_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype190_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes190 [] = {
g_atype190_0,
g_atype190_1,
g_atype190_2,
g_atype190_3,
g_atype190_4,
g_atype190_5,
g_atype190_6,
};

static const long offsets190 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names191[];
static const uint32 types191 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags191 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype191_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype191_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype191_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype191_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype191_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype191_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype191_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes191 [] = {
g_atype191_0,
g_atype191_1,
g_atype191_2,
g_atype191_3,
g_atype191_4,
g_atype191_5,
g_atype191_6,
};

static const long offsets191 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names192[];
static const uint32 types192 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags192 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype192_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes192 [] = {
g_atype192_0,
g_atype192_1,
g_atype192_2,
g_atype192_3,
g_atype192_4,
g_atype192_5,
g_atype192_6,
};

static const long offsets192 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names193[];
static const uint32 types193 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags193 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype193_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype193_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype193_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype193_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype193_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype193_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype193_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes193 [] = {
g_atype193_0,
g_atype193_1,
g_atype193_2,
g_atype193_3,
g_atype193_4,
g_atype193_5,
g_atype193_6,
};

static const long offsets193 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names194[];
static const uint32 types194 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags194 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype194_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes194 [] = {
g_atype194_0,
g_atype194_1,
g_atype194_2,
g_atype194_3,
g_atype194_4,
g_atype194_5,
g_atype194_6,
};

static const long offsets194 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names195[];
static const uint32 types195 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags195 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype195_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype195_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype195_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype195_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype195_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype195_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype195_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype195_7 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes195 [] = {
g_atype195_0,
g_atype195_1,
g_atype195_2,
g_atype195_3,
g_atype195_4,
g_atype195_5,
g_atype195_6,
g_atype195_7,
};

static const long offsets195 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names196[];
static const uint32 types196 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags196 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype196_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype196_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype196_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype196_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype196_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype196_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype196_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes196 [] = {
g_atype196_0,
g_atype196_1,
g_atype196_2,
g_atype196_3,
g_atype196_4,
g_atype196_5,
g_atype196_6,
};

static const long offsets196 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names197[];
static const uint32 types197 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags197 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype197_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype197_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype197_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype197_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype197_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype197_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype197_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes197 [] = {
g_atype197_0,
g_atype197_1,
g_atype197_2,
g_atype197_3,
g_atype197_4,
g_atype197_5,
g_atype197_6,
};

static const long offsets197 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names198[];
static const uint32 types198 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags198 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype198_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype198_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype198_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype198_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype198_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype198_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype198_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes198 [] = {
g_atype198_0,
g_atype198_1,
g_atype198_2,
g_atype198_3,
g_atype198_4,
g_atype198_5,
g_atype198_6,
};

static const long offsets198 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names199[];
static const uint32 types199 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags199 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype199_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype199_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype199_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype199_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype199_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype199_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype199_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes199 [] = {
g_atype199_0,
g_atype199_1,
g_atype199_2,
g_atype199_3,
g_atype199_4,
g_atype199_5,
g_atype199_6,
};

static const long offsets199 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names200[];
static const uint32 types200 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags200 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype200_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_7 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes200 [] = {
g_atype200_0,
g_atype200_1,
g_atype200_2,
g_atype200_3,
g_atype200_4,
g_atype200_5,
g_atype200_6,
g_atype200_7,
};

static const long offsets200 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names201[];
static const uint32 types201 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags201 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype201_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes201 [] = {
g_atype201_0,
g_atype201_1,
g_atype201_2,
g_atype201_3,
g_atype201_4,
g_atype201_5,
g_atype201_6,
};

static const long offsets201 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names202[];
static const uint32 types202 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags202 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype202_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype202_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype202_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype202_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype202_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype202_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype202_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype202_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype202_8 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes202 [] = {
g_atype202_0,
g_atype202_1,
g_atype202_2,
g_atype202_3,
g_atype202_4,
g_atype202_5,
g_atype202_6,
g_atype202_7,
g_atype202_8,
};

static const long offsets202 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
+ @LNGOFF(5,1,0,2),
};

extern const char *names203[];
static const uint32 types203 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags203 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype203_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes203 [] = {
g_atype203_0,
g_atype203_1,
g_atype203_2,
g_atype203_3,
g_atype203_4,
g_atype203_5,
g_atype203_6,
};

static const long offsets203 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names204[];
static const uint32 types204 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags204 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype204_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes204 [] = {
g_atype204_0,
g_atype204_1,
g_atype204_2,
g_atype204_3,
g_atype204_4,
g_atype204_5,
g_atype204_6,
};

static const long offsets204 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names205[];
static const uint32 types205 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags205 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype205_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes205 [] = {
g_atype205_0,
g_atype205_1,
g_atype205_2,
g_atype205_3,
g_atype205_4,
g_atype205_5,
g_atype205_6,
};

static const long offsets205 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names206[];
static const uint32 types206 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags206 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype206_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes206 [] = {
g_atype206_0,
g_atype206_1,
g_atype206_2,
g_atype206_3,
g_atype206_4,
g_atype206_5,
g_atype206_6,
};

static const long offsets206 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names207[];
static const uint32 types207 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags207 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype207_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes207 [] = {
g_atype207_0,
g_atype207_1,
g_atype207_2,
g_atype207_3,
g_atype207_4,
g_atype207_5,
g_atype207_6,
};

static const long offsets207 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names208[];
static const uint32 types208 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags208 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype208_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_5 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_6 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_7 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_8 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes208 [] = {
g_atype208_0,
g_atype208_1,
g_atype208_2,
g_atype208_3,
g_atype208_4,
g_atype208_5,
g_atype208_6,
g_atype208_7,
g_atype208_8,
};

static const long offsets208 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @LNGOFF(7,1,0,0),
};

extern const char *names209[];
static const uint32 types209 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags209 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype209_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype209_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype209_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype209_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype209_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype209_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype209_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes209 [] = {
g_atype209_0,
g_atype209_1,
g_atype209_2,
g_atype209_3,
g_atype209_4,
g_atype209_5,
g_atype209_6,
};

static const long offsets209 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names210[];
static const uint32 types210 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags210 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype210_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype210_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype210_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype210_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype210_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype210_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype210_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes210 [] = {
g_atype210_0,
g_atype210_1,
g_atype210_2,
g_atype210_3,
g_atype210_4,
g_atype210_5,
g_atype210_6,
};

static const long offsets210 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names211[];
static const uint32 types211 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags211 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype211_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype211_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype211_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype211_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype211_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype211_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype211_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes211 [] = {
g_atype211_0,
g_atype211_1,
g_atype211_2,
g_atype211_3,
g_atype211_4,
g_atype211_5,
g_atype211_6,
};

static const long offsets211 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names212[];
static const uint32 types212 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags212 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype212_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes212 [] = {
g_atype212_0,
g_atype212_1,
g_atype212_2,
g_atype212_3,
g_atype212_4,
g_atype212_5,
g_atype212_6,
};

static const long offsets212 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names213[];
static const uint32 types213 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags213 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype213_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes213 [] = {
g_atype213_0,
g_atype213_1,
g_atype213_2,
g_atype213_3,
g_atype213_4,
g_atype213_5,
g_atype213_6,
};

static const long offsets213 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names214[];
static const uint32 types214 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags214 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype214_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype214_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype214_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype214_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype214_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype214_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype214_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes214 [] = {
g_atype214_0,
g_atype214_1,
g_atype214_2,
g_atype214_3,
g_atype214_4,
g_atype214_5,
g_atype214_6,
};

static const long offsets214 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names215[];
static const uint32 types215 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags215 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype215_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype215_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype215_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype215_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype215_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype215_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype215_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes215 [] = {
g_atype215_0,
g_atype215_1,
g_atype215_2,
g_atype215_3,
g_atype215_4,
g_atype215_5,
g_atype215_6,
};

static const long offsets215 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names216[];
static const uint32 types216 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags216 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype216_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype216_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype216_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype216_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype216_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype216_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype216_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes216 [] = {
g_atype216_0,
g_atype216_1,
g_atype216_2,
g_atype216_3,
g_atype216_4,
g_atype216_5,
g_atype216_6,
};

static const long offsets216 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names217[];
static const uint32 types217 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags217 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype217_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_6 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_7 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes217 [] = {
g_atype217_0,
g_atype217_1,
g_atype217_2,
g_atype217_3,
g_atype217_4,
g_atype217_5,
g_atype217_6,
g_atype217_7,
};

static const long offsets217 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
};

extern const char *names218[];
static const uint32 types218 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags218 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype218_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype218_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype218_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype218_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype218_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype218_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype218_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes218 [] = {
g_atype218_0,
g_atype218_1,
g_atype218_2,
g_atype218_3,
g_atype218_4,
g_atype218_5,
g_atype218_6,
};

static const long offsets218 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names219[];
static const uint32 types219 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags219 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype219_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype219_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype219_2 [] = {179,0xFFFF};
static const EIF_TYPE_INDEX g_atype219_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype219_4 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype219_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype219_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes219 [] = {
g_atype219_0,
g_atype219_1,
g_atype219_2,
g_atype219_3,
g_atype219_4,
g_atype219_5,
g_atype219_6,
};

static const long offsets219 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names221[];
static const uint32 types221 [] =
{
SK_BOOL,
SK_INT32,
SK_POINTER,
SK_UINT64,
};

static const uint16 attr_flags221 [] =
{0,0,1,1,};

static const EIF_TYPE_INDEX g_atype221_0 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_2 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_3 [] = {843,0xFFFF};

static const EIF_TYPE_INDEX *gtypes221 [] = {
g_atype221_0,
g_atype221_1,
g_atype221_2,
g_atype221_3,
};

static const long offsets221 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
+ @PTROFF(0,1,0,1,0,0),
+ @I64OFF(0,1,0,1,0,1,0),
};

extern const char *names225[];
static const uint32 types225 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags225 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype225_0 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_2 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_3 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_4 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_7 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes225 [] = {
g_atype225_0,
g_atype225_1,
g_atype225_2,
g_atype225_3,
g_atype225_4,
g_atype225_5,
g_atype225_6,
g_atype225_7,
};

static const long offsets225 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
};

extern const char *names238[];
static const uint32 types238 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags238 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype238_0 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_2 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_3 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_4 [] = {0xFF01,1140,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_5 [] = {0xFF01,1140,0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_6 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_7 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_8 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_9 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_10 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_11 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_12 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes238 [] = {
g_atype238_0,
g_atype238_1,
g_atype238_2,
g_atype238_3,
g_atype238_4,
g_atype238_5,
g_atype238_6,
g_atype238_7,
g_atype238_8,
g_atype238_9,
g_atype238_10,
g_atype238_11,
g_atype238_12,
};

static const long offsets238 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @LNGOFF(6,6,0,0),
};

extern const char *names239[];
static const uint32 types239 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags239 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype239_0 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_2 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_3 [] = {0xFF01,1143,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_4 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_6 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_7 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_8 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_9 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_10 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_11 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes239 [] = {
g_atype239_0,
g_atype239_1,
g_atype239_2,
g_atype239_3,
g_atype239_4,
g_atype239_5,
g_atype239_6,
g_atype239_7,
g_atype239_8,
g_atype239_9,
g_atype239_10,
g_atype239_11,
};

static const long offsets239 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @CHROFF(4,6),
+ @LNGOFF(4,7,0,0),
};

extern const char *names242[];
static const uint32 types242 [] =
{
SK_INT32,
};

static const uint16 attr_flags242 [] =
{0,};

static const EIF_TYPE_INDEX g_atype242_0 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes242 [] = {
g_atype242_0,
};

static const long offsets242 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names246[];
static const uint32 types246 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags246 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype246_0 [] = {0xFF01,241,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes246 [] = {
g_atype246_0,
g_atype246_1,
g_atype246_2,
g_atype246_3,
};

static const long offsets246 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names247[];
static const uint32 types247 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags247 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype247_0 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes247 [] = {
g_atype247_0,
g_atype247_1,
g_atype247_2,
};

static const long offsets247 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names248[];
static const uint32 types248 [] =
{
SK_REF,
};

static const uint16 attr_flags248 [] =
{0,};

static const EIF_TYPE_INDEX g_atype248_0 [] = {0xFF01,676,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes248 [] = {
g_atype248_0,
};

static const long offsets248 [] =
{
0,
};

extern const char *names249[];
static const uint32 types249 [] =
{
SK_REF,
};

static const uint16 attr_flags249 [] =
{0,};

static const EIF_TYPE_INDEX g_atype249_0 [] = {0xFF01,677,834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes249 [] = {
g_atype249_0,
};

static const long offsets249 [] =
{
0,
};

extern const char *names250[];
static const uint32 types250 [] =
{
SK_REF,
};

static const uint16 attr_flags250 [] =
{0,};

static const EIF_TYPE_INDEX g_atype250_0 [] = {0xFF01,678,900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes250 [] = {
g_atype250_0,
};

static const long offsets250 [] =
{
0,
};

extern const char *names251[];
static const uint32 types251 [] =
{
SK_REF,
};

static const uint16 attr_flags251 [] =
{0,};

static const EIF_TYPE_INDEX g_atype251_0 [] = {0xFF01,679,867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes251 [] = {
g_atype251_0,
};

static const long offsets251 [] =
{
0,
};

extern const char *names252[];
static const uint32 types252 [] =
{
SK_REF,
};

static const uint16 attr_flags252 [] =
{0,};

static const EIF_TYPE_INDEX g_atype252_0 [] = {0xFF01,680,861,0xFFFF};

static const EIF_TYPE_INDEX *gtypes252 [] = {
g_atype252_0,
};

static const long offsets252 [] =
{
0,
};

extern const char *names253[];
static const uint32 types253 [] =
{
SK_REF,
};

static const uint16 attr_flags253 [] =
{0,};

static const EIF_TYPE_INDEX g_atype253_0 [] = {0xFF01,681,843,0xFFFF};

static const EIF_TYPE_INDEX *gtypes253 [] = {
g_atype253_0,
};

static const long offsets253 [] =
{
0,
};

extern const char *names254[];
static const uint32 types254 [] =
{
SK_REF,
};

static const uint16 attr_flags254 [] =
{0,};

static const EIF_TYPE_INDEX g_atype254_0 [] = {0xFF01,682,864,0xFFFF};

static const EIF_TYPE_INDEX *gtypes254 [] = {
g_atype254_0,
};

static const long offsets254 [] =
{
0,
};

extern const char *names255[];
static const uint32 types255 [] =
{
SK_REF,
};

static const uint16 attr_flags255 [] =
{0,};

static const EIF_TYPE_INDEX g_atype255_0 [] = {0xFF01,683,852,0xFFFF};

static const EIF_TYPE_INDEX *gtypes255 [] = {
g_atype255_0,
};

static const long offsets255 [] =
{
0,
};

extern const char *names256[];
static const uint32 types256 [] =
{
SK_REF,
};

static const uint16 attr_flags256 [] =
{0,};

static const EIF_TYPE_INDEX g_atype256_0 [] = {0xFF01,684,849,0xFFFF};

static const EIF_TYPE_INDEX *gtypes256 [] = {
g_atype256_0,
};

static const long offsets256 [] =
{
0,
};

extern const char *names257[];
static const uint32 types257 [] =
{
SK_REF,
};

static const uint16 attr_flags257 [] =
{0,};

static const EIF_TYPE_INDEX g_atype257_0 [] = {0xFF01,685,855,0xFFFF};

static const EIF_TYPE_INDEX *gtypes257 [] = {
g_atype257_0,
};

static const long offsets257 [] =
{
0,
};

extern const char *names258[];
static const uint32 types258 [] =
{
SK_REF,
};

static const uint16 attr_flags258 [] =
{0,};

static const EIF_TYPE_INDEX g_atype258_0 [] = {0xFF01,686,858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes258 [] = {
g_atype258_0,
};

static const long offsets258 [] =
{
0,
};

extern const char *names259[];
static const uint32 types259 [] =
{
SK_REF,
};

static const uint16 attr_flags259 [] =
{0,};

static const EIF_TYPE_INDEX g_atype259_0 [] = {0xFF01,687,846,0xFFFF};

static const EIF_TYPE_INDEX *gtypes259 [] = {
g_atype259_0,
};

static const long offsets259 [] =
{
0,
};

extern const char *names261[];
static const uint32 types261 [] =
{
SK_INT32,
};

static const uint16 attr_flags261 [] =
{0,};

static const EIF_TYPE_INDEX g_atype261_0 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes261 [] = {
g_atype261_0,
};

static const long offsets261 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names262[];
static const uint32 types262 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags262 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype262_0 [] = {0xFF01,220,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_1 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes262 [] = {
g_atype262_0,
g_atype262_1,
};

static const long offsets262 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names263[];
static const uint32 types263 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags263 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype263_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_1 [] = {0xFF01,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_2 [] = {220,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_4 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_5 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes263 [] = {
g_atype263_0,
g_atype263_1,
g_atype263_2,
g_atype263_3,
g_atype263_4,
g_atype263_5,
};

static const long offsets263 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @PTROFF(3,0,0,1,0,0),
+ @PTROFF(3,0,0,1,0,1),
};

extern const char *names264[];
static const uint32 types264 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags264 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype264_0 [] = {0xFF01,683,852,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_2 [] = {220,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_3 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_4 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes264 [] = {
g_atype264_0,
g_atype264_1,
g_atype264_2,
g_atype264_3,
g_atype264_4,
};

static const long offsets264 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names265[];
static const uint32 types265 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags265 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype265_0 [] = {0xFF01,683,852,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_2 [] = {220,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_3 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_4 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes265 [] = {
g_atype265_0,
g_atype265_1,
g_atype265_2,
g_atype265_3,
g_atype265_4,
};

static const long offsets265 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names267[];
static const uint32 types267 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags267 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype267_0 [] = {0xFF01,45,0xFFFF};
static const EIF_TYPE_INDEX g_atype267_1 [] = {0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype267_2 [] = {1073,0xFFFF};

static const EIF_TYPE_INDEX *gtypes267 [] = {
g_atype267_0,
g_atype267_1,
g_atype267_2,
};

static const long offsets267 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names270[];
static const uint32 types270 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR32,
};

static const uint16 attr_flags270 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype270_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_1 [] = {0xFF01,911,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_2 [] = {0xFF01,680,861,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_3 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_4 [] = {861,0xFFFF};

static const EIF_TYPE_INDEX *gtypes270 [] = {
g_atype270_0,
g_atype270_1,
g_atype270_2,
g_atype270_3,
g_atype270_4,
};

static const long offsets270 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
};

extern const char *names271[];
static const uint32 types271 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags271 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype271_0 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_1 [] = {0xFF01,682,864,0xFFFF};

static const EIF_TYPE_INDEX *gtypes271 [] = {
g_atype271_0,
g_atype271_1,
};

static const long offsets271 [] =
{
0,
 + @REFACS(1),
};

extern const char *names272[];
static const uint32 types272 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags272 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype272_0 [] = {0xFF01,220,0xFFFF};
static const EIF_TYPE_INDEX g_atype272_1 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes272 [] = {
g_atype272_0,
g_atype272_1,
};

static const long offsets272 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names273[];
static const uint32 types273 [] =
{
SK_REF,
SK_CHAR8,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags273 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype273_0 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_1 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_2 [] = {852,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_3 [] = {840,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_4 [] = {849,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_5 [] = {837,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_6 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_9 [] = {855,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_10 [] = {843,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_11 [] = {831,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_12 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes273 [] = {
g_atype273_0,
g_atype273_1,
g_atype273_2,
g_atype273_3,
g_atype273_4,
g_atype273_5,
g_atype273_6,
g_atype273_7,
g_atype273_8,
g_atype273_9,
g_atype273_10,
g_atype273_11,
g_atype273_12,
};

static const long offsets273 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @I16OFF(1,3,0),
+ @I16OFF(1,3,1),
+ @LNGOFF(1,3,2,0),
+ @LNGOFF(1,3,2,1),
+ @LNGOFF(1,3,2,2),
+ @R32OFF(1,3,2,3,0),
+ @I64OFF(1,3,2,3,1,0,0),
+ @I64OFF(1,3,2,3,1,0,1),
+ @R64OFF(1,3,2,3,1,0,2,0),
};

extern const char *names275[];
static const uint32 types275 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags275 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype275_0 [] = {0xFF01,1185,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_2 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_3 [] = {274,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_4 [] = {0xFF01,776,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_5 [] = {773,274,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_6 [] = {773,0xFF01,276,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_7 [] = {0xFF01,0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_8 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_9 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_10 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_11 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_12 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_13 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_14 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes275 [] = {
g_atype275_0,
g_atype275_1,
g_atype275_2,
g_atype275_3,
g_atype275_4,
g_atype275_5,
g_atype275_6,
g_atype275_7,
g_atype275_8,
g_atype275_9,
g_atype275_10,
g_atype275_11,
g_atype275_12,
g_atype275_13,
g_atype275_14,
};

static const long offsets275 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @CHROFF(8,1),
+ @CHROFF(8,2),
+ @CHROFF(8,3),
+ @LNGOFF(8,4,0,0),
+ @LNGOFF(8,4,0,1),
+ @LNGOFF(8,4,0,2),
};

extern const char *names277[];
static const uint32 types277 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags277 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype277_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype277_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype277_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes277 [] = {
g_atype277_0,
g_atype277_1,
g_atype277_2,
};

static const long offsets277 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names278[];
static const uint32 types278 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags278 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype278_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_1 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes278 [] = {
g_atype278_0,
g_atype278_1,
g_atype278_2,
g_atype278_3,
g_atype278_4,
g_atype278_5,
};

static const long offsets278 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names279[];
static const uint32 types279 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags279 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype279_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_1 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_5 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes279 [] = {
g_atype279_0,
g_atype279_1,
g_atype279_2,
g_atype279_3,
g_atype279_4,
g_atype279_5,
};

static const long offsets279 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @PTROFF(1,0,0,4,0,0),
};

extern const char *names280[];
static const uint32 types280 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags280 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype280_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype280_1 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype280_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype280_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype280_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype280_5 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes280 [] = {
g_atype280_0,
g_atype280_1,
g_atype280_2,
g_atype280_3,
g_atype280_4,
g_atype280_5,
};

static const long offsets280 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @R64OFF(1,0,0,4,0,0,0,0),
};

extern const char *names281[];
static const uint32 types281 [] =
{
SK_REF,
SK_UINT8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags281 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype281_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype281_1 [] = {852,0xFFFF};
static const EIF_TYPE_INDEX g_atype281_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype281_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype281_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype281_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes281 [] = {
g_atype281_0,
g_atype281_1,
g_atype281_2,
g_atype281_3,
g_atype281_4,
g_atype281_5,
};

static const long offsets281 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names282[];
static const uint32 types282 [] =
{
SK_REF,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags282 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype282_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_1 [] = {849,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes282 [] = {
g_atype282_0,
g_atype282_1,
g_atype282_2,
g_atype282_3,
g_atype282_4,
g_atype282_5,
};

static const long offsets282 [] =
{
0,
+ @I16OFF(1,0,0),
+ @LNGOFF(1,0,1,0),
+ @LNGOFF(1,0,1,1),
+ @LNGOFF(1,0,1,2),
+ @LNGOFF(1,0,1,3),
};

extern const char *names283[];
static const uint32 types283 [] =
{
SK_REF,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags283 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype283_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype283_1 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype283_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype283_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype283_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype283_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes283 [] = {
g_atype283_0,
g_atype283_1,
g_atype283_2,
g_atype283_3,
g_atype283_4,
g_atype283_5,
};

static const long offsets283 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names284[];
static const uint32 types284 [] =
{
SK_REF,
SK_INT8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags284 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype284_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype284_1 [] = {840,0xFFFF};
static const EIF_TYPE_INDEX g_atype284_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype284_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype284_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype284_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes284 [] = {
g_atype284_0,
g_atype284_1,
g_atype284_2,
g_atype284_3,
g_atype284_4,
g_atype284_5,
};

static const long offsets284 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names285[];
static const uint32 types285 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags285 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype285_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype285_1 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype285_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype285_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype285_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype285_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes285 [] = {
g_atype285_0,
g_atype285_1,
g_atype285_2,
g_atype285_3,
g_atype285_4,
g_atype285_5,
};

static const long offsets285 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names286[];
static const uint32 types286 [] =
{
SK_REF,
SK_CHAR8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags286 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype286_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype286_1 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype286_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype286_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype286_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype286_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes286 [] = {
g_atype286_0,
g_atype286_1,
g_atype286_2,
g_atype286_3,
g_atype286_4,
g_atype286_5,
};

static const long offsets286 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names287[];
static const uint32 types287 [] =
{
SK_REF,
SK_CHAR32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags287 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype287_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_1 [] = {861,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes287 [] = {
g_atype287_0,
g_atype287_1,
g_atype287_2,
g_atype287_3,
g_atype287_4,
g_atype287_5,
};

static const long offsets287 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names288[];
static const uint32 types288 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags288 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype288_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_1 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_5 [] = {843,0xFFFF};

static const EIF_TYPE_INDEX *gtypes288 [] = {
g_atype288_0,
g_atype288_1,
g_atype288_2,
g_atype288_3,
g_atype288_4,
g_atype288_5,
};

static const long offsets288 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @I64OFF(1,0,0,4,0,0,0),
};

extern const char *names289[];
static const uint32 types289 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags289 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype289_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_1 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_5 [] = {831,0xFFFF};

static const EIF_TYPE_INDEX *gtypes289 [] = {
g_atype289_0,
g_atype289_1,
g_atype289_2,
g_atype289_3,
g_atype289_4,
g_atype289_5,
};

static const long offsets289 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @I64OFF(1,0,0,4,0,0,0),
};

extern const char *names290[];
static const uint32 types290 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags290 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype290_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_1 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_5 [] = {855,0xFFFF};

static const EIF_TYPE_INDEX *gtypes290 [] = {
g_atype290_0,
g_atype290_1,
g_atype290_2,
g_atype290_3,
g_atype290_4,
g_atype290_5,
};

static const long offsets290 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @R32OFF(1,0,0,4,0),
};

extern const char *names291[];
static const uint32 types291 [] =
{
SK_REF,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags291 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype291_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_1 [] = {837,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes291 [] = {
g_atype291_0,
g_atype291_1,
g_atype291_2,
g_atype291_3,
g_atype291_4,
g_atype291_5,
};

static const long offsets291 [] =
{
0,
+ @I16OFF(1,0,0),
+ @LNGOFF(1,0,1,0),
+ @LNGOFF(1,0,1,1),
+ @LNGOFF(1,0,1,2),
+ @LNGOFF(1,0,1,3),
};

extern const char *names292[];
static const uint32 types292 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags292 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype292_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes292 [] = {
g_atype292_0,
g_atype292_1,
g_atype292_2,
g_atype292_3,
g_atype292_4,
g_atype292_5,
};

static const long offsets292 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names293[];
static const uint32 types293 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags293 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype293_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_2 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_3 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes293 [] = {
g_atype293_0,
g_atype293_1,
g_atype293_2,
g_atype293_3,
g_atype293_4,
g_atype293_5,
};

static const long offsets293 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names294[];
static const uint32 types294 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags294 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype294_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_5 [] = {831,0xFFFF};

static const EIF_TYPE_INDEX *gtypes294 [] = {
g_atype294_0,
g_atype294_1,
g_atype294_2,
g_atype294_3,
g_atype294_4,
g_atype294_5,
};

static const long offsets294 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @I64OFF(2,0,0,3,0,0,0),
};

extern const char *names295[];
static const uint32 types295 [] =
{
SK_REF,
SK_REF,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags295 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype295_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_2 [] = {837,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_3 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes295 [] = {
g_atype295_0,
g_atype295_1,
g_atype295_2,
g_atype295_3,
g_atype295_4,
g_atype295_5,
};

static const long offsets295 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
+ @LNGOFF(2,0,1,2),
};

extern const char *names296[];
static const uint32 types296 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags296 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype296_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_5 [] = {843,0xFFFF};

static const EIF_TYPE_INDEX *gtypes296 [] = {
g_atype296_0,
g_atype296_1,
g_atype296_2,
g_atype296_3,
g_atype296_4,
g_atype296_5,
};

static const long offsets296 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @I64OFF(2,0,0,3,0,0,0),
};

extern const char *names297[];
static const uint32 types297 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags297 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype297_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_3 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes297 [] = {
g_atype297_0,
g_atype297_1,
g_atype297_2,
g_atype297_3,
g_atype297_4,
g_atype297_5,
};

static const long offsets297 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names298[];
static const uint32 types298 [] =
{
SK_REF,
SK_REF,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags298 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype298_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_2 [] = {849,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_3 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes298 [] = {
g_atype298_0,
g_atype298_1,
g_atype298_2,
g_atype298_3,
g_atype298_4,
g_atype298_5,
};

static const long offsets298 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
+ @LNGOFF(2,0,1,2),
};

extern const char *names299[];
static const uint32 types299 [] =
{
SK_REF,
SK_REF,
SK_UINT8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags299 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype299_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_2 [] = {852,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_3 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes299 [] = {
g_atype299_0,
g_atype299_1,
g_atype299_2,
g_atype299_3,
g_atype299_4,
g_atype299_5,
};

static const long offsets299 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names300[];
static const uint32 types300 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags300 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype300_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_5 [] = {855,0xFFFF};

static const EIF_TYPE_INDEX *gtypes300 [] = {
g_atype300_0,
g_atype300_1,
g_atype300_2,
g_atype300_3,
g_atype300_4,
g_atype300_5,
};

static const long offsets300 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @R32OFF(2,0,0,3,0),
};

extern const char *names301[];
static const uint32 types301 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags301 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype301_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype301_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype301_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype301_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype301_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype301_5 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes301 [] = {
g_atype301_0,
g_atype301_1,
g_atype301_2,
g_atype301_3,
g_atype301_4,
g_atype301_5,
};

static const long offsets301 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @R64OFF(2,0,0,3,0,0,0,0),
};

extern const char *names302[];
static const uint32 types302 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags302 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype302_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype302_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype302_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype302_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype302_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype302_5 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes302 [] = {
g_atype302_0,
g_atype302_1,
g_atype302_2,
g_atype302_3,
g_atype302_4,
g_atype302_5,
};

static const long offsets302 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @PTROFF(2,0,0,3,0,0),
};

extern const char *names303[];
static const uint32 types303 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags303 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype303_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype303_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype303_2 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype303_3 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype303_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype303_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes303 [] = {
g_atype303_0,
g_atype303_1,
g_atype303_2,
g_atype303_3,
g_atype303_4,
g_atype303_5,
};

static const long offsets303 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names304[];
static const uint32 types304 [] =
{
SK_REF,
SK_REF,
SK_CHAR32,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags304 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype304_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype304_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype304_2 [] = {861,0xFFFF};
static const EIF_TYPE_INDEX g_atype304_3 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype304_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype304_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes304 [] = {
g_atype304_0,
g_atype304_1,
g_atype304_2,
g_atype304_3,
g_atype304_4,
g_atype304_5,
};

static const long offsets304 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names305[];
static const uint32 types305 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags305 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype305_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype305_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype305_2 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype305_3 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype305_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype305_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes305 [] = {
g_atype305_0,
g_atype305_1,
g_atype305_2,
g_atype305_3,
g_atype305_4,
g_atype305_5,
};

static const long offsets305 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names306[];
static const uint32 types306 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags306 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype306_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes306 [] = {
g_atype306_0,
g_atype306_1,
g_atype306_2,
g_atype306_3,
g_atype306_4,
g_atype306_5,
};

static const long offsets306 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names307[];
static const uint32 types307 [] =
{
SK_REF,
SK_REF,
SK_INT8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags307 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype307_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype307_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype307_2 [] = {840,0xFFFF};
static const EIF_TYPE_INDEX g_atype307_3 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype307_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype307_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes307 [] = {
g_atype307_0,
g_atype307_1,
g_atype307_2,
g_atype307_3,
g_atype307_4,
g_atype307_5,
};

static const long offsets307 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names308[];
static const uint32 types308 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags308 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype308_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_2 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes308 [] = {
g_atype308_0,
g_atype308_1,
g_atype308_2,
g_atype308_3,
g_atype308_4,
};

static const long offsets308 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
};

extern const char *names309[];
static const uint32 types309 [] =
{
SK_REF,
SK_REF,
SK_CHAR32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags309 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype309_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_2 [] = {861,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes309 [] = {
g_atype309_0,
g_atype309_1,
g_atype309_2,
g_atype309_3,
g_atype309_4,
};

static const long offsets309 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names310[];
static const uint32 types310 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags310 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype310_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes310 [] = {
g_atype310_0,
g_atype310_1,
g_atype310_2,
g_atype310_3,
g_atype310_4,
};

static const long offsets310 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names311[];
static const uint32 types311 [] =
{
SK_REF,
SK_REF,
SK_UINT8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags311 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype311_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_2 [] = {852,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes311 [] = {
g_atype311_0,
g_atype311_1,
g_atype311_2,
g_atype311_3,
g_atype311_4,
};

static const long offsets311 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names312[];
static const uint32 types312 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags312 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype312_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_4 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes312 [] = {
g_atype312_0,
g_atype312_1,
g_atype312_2,
g_atype312_3,
g_atype312_4,
};

static const long offsets312 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @R64OFF(2,0,0,2,0,0,0,0),
};

extern const char *names313[];
static const uint32 types313 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags313 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype313_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_4 [] = {855,0xFFFF};

static const EIF_TYPE_INDEX *gtypes313 [] = {
g_atype313_0,
g_atype313_1,
g_atype313_2,
g_atype313_3,
g_atype313_4,
};

static const long offsets313 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @R32OFF(2,0,0,2,0),
};

extern const char *names314[];
static const uint32 types314 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags314 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype314_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_4 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes314 [] = {
g_atype314_0,
g_atype314_1,
g_atype314_2,
g_atype314_3,
g_atype314_4,
};

static const long offsets314 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @PTROFF(2,0,0,2,0,0),
};

extern const char *names315[];
static const uint32 types315 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags315 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype315_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype315_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype315_2 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype315_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype315_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes315 [] = {
g_atype315_0,
g_atype315_1,
g_atype315_2,
g_atype315_3,
g_atype315_4,
};

static const long offsets315 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names316[];
static const uint32 types316 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags316 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype316_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype316_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype316_2 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype316_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype316_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes316 [] = {
g_atype316_0,
g_atype316_1,
g_atype316_2,
g_atype316_3,
g_atype316_4,
};

static const long offsets316 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names317[];
static const uint32 types317 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags317 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype317_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype317_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype317_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype317_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype317_4 [] = {831,0xFFFF};

static const EIF_TYPE_INDEX *gtypes317 [] = {
g_atype317_0,
g_atype317_1,
g_atype317_2,
g_atype317_3,
g_atype317_4,
};

static const long offsets317 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @I64OFF(2,0,0,2,0,0,0),
};

extern const char *names318[];
static const uint32 types318 [] =
{
SK_REF,
SK_REF,
SK_INT8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags318 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype318_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_2 [] = {840,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes318 [] = {
g_atype318_0,
g_atype318_1,
g_atype318_2,
g_atype318_3,
g_atype318_4,
};

static const long offsets318 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names319[];
static const uint32 types319 [] =
{
SK_REF,
SK_REF,
SK_INT16,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags319 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype319_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_2 [] = {837,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes319 [] = {
g_atype319_0,
g_atype319_1,
g_atype319_2,
g_atype319_3,
g_atype319_4,
};

static const long offsets319 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
};

extern const char *names320[];
static const uint32 types320 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags320 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype320_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes320 [] = {
g_atype320_0,
g_atype320_1,
g_atype320_2,
g_atype320_3,
g_atype320_4,
};

static const long offsets320 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names321[];
static const uint32 types321 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags321 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype321_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_4 [] = {843,0xFFFF};

static const EIF_TYPE_INDEX *gtypes321 [] = {
g_atype321_0,
g_atype321_1,
g_atype321_2,
g_atype321_3,
g_atype321_4,
};

static const long offsets321 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @I64OFF(2,0,0,2,0,0,0),
};

extern const char *names322[];
static const uint32 types322 [] =
{
SK_REF,
SK_REF,
SK_UINT16,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags322 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype322_0 [] = {0xFFF9,2,828,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_2 [] = {849,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes322 [] = {
g_atype322_0,
g_atype322_1,
g_atype322_2,
g_atype322_3,
g_atype322_4,
};

static const long offsets322 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
};

extern const char *names336[];
static const uint32 types336 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags336 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype336_0 [] = {0xFF01,676,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_1 [] = {0xFFF5,1,0xFF01,676,0xFFF8,1,3078,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_2 [] = {0xFFF5,1,0xFF01,772,0xFFF8,1,3241,0xFFFF};

static const EIF_TYPE_INDEX *gtypes336 [] = {
g_atype336_0,
g_atype336_1,
g_atype336_2,
};

static const long offsets336 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names337[];
static const uint32 types337 [] =
{
SK_UINT8,
SK_POINTER,
};

static const uint16 attr_flags337 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype337_0 [] = {852,0xFFFF};
static const EIF_TYPE_INDEX g_atype337_1 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes337 [] = {
g_atype337_0,
g_atype337_1,
};

static const long offsets337 [] =
{
+ @CHROFF(0,0),
+ @PTROFF(0,1,0,0,0,0),
};

extern const char *names356[];
static const uint32 types356 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags356 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype356_0 [] = {0xFF01,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype356_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype356_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype356_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes356 [] = {
g_atype356_0,
g_atype356_1,
g_atype356_2,
g_atype356_3,
};

static const long offsets356 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names358[];
static const uint32 types358 [] =
{
SK_REF,
};

static const uint16 attr_flags358 [] =
{0,};

static const EIF_TYPE_INDEX g_atype358_0 [] = {0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes358 [] = {
g_atype358_0,
};

static const long offsets358 [] =
{
0,
};

extern const char *names388[];
static const uint32 types388 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags388 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype388_0 [] = {0xFF01,664,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype388_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype388_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype388_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype388_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype388_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype388_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes388 [] = {
g_atype388_0,
g_atype388_1,
g_atype388_2,
g_atype388_3,
g_atype388_4,
g_atype388_5,
g_atype388_6,
};

static const long offsets388 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names389[];
static const uint32 types389 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags389 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype389_0 [] = {0xFF01,665,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype389_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype389_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype389_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype389_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype389_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype389_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes389 [] = {
g_atype389_0,
g_atype389_1,
g_atype389_2,
g_atype389_3,
g_atype389_4,
g_atype389_5,
g_atype389_6,
};

static const long offsets389 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names390[];
static const uint32 types390 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags390 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype390_0 [] = {0xFF01,666,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype390_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype390_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype390_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype390_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype390_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype390_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes390 [] = {
g_atype390_0,
g_atype390_1,
g_atype390_2,
g_atype390_3,
g_atype390_4,
g_atype390_5,
g_atype390_6,
};

static const long offsets390 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names391[];
static const uint32 types391 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags391 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype391_0 [] = {0xFF01,667,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype391_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype391_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype391_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype391_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype391_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype391_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes391 [] = {
g_atype391_0,
g_atype391_1,
g_atype391_2,
g_atype391_3,
g_atype391_4,
g_atype391_5,
g_atype391_6,
};

static const long offsets391 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names392[];
static const uint32 types392 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags392 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype392_0 [] = {0xFF01,668,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype392_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype392_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype392_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype392_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype392_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype392_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes392 [] = {
g_atype392_0,
g_atype392_1,
g_atype392_2,
g_atype392_3,
g_atype392_4,
g_atype392_5,
g_atype392_6,
};

static const long offsets392 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names393[];
static const uint32 types393 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags393 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype393_0 [] = {0xFF01,669,861,0xFFFF};
static const EIF_TYPE_INDEX g_atype393_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype393_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype393_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype393_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype393_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype393_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes393 [] = {
g_atype393_0,
g_atype393_1,
g_atype393_2,
g_atype393_3,
g_atype393_4,
g_atype393_5,
g_atype393_6,
};

static const long offsets393 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names394[];
static const uint32 types394 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags394 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype394_0 [] = {0xFF01,670,843,0xFFFF};
static const EIF_TYPE_INDEX g_atype394_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype394_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype394_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype394_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype394_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype394_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes394 [] = {
g_atype394_0,
g_atype394_1,
g_atype394_2,
g_atype394_3,
g_atype394_4,
g_atype394_5,
g_atype394_6,
};

static const long offsets394 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names395[];
static const uint32 types395 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags395 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype395_0 [] = {0xFF01,671,852,0xFFFF};
static const EIF_TYPE_INDEX g_atype395_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype395_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype395_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype395_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype395_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype395_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes395 [] = {
g_atype395_0,
g_atype395_1,
g_atype395_2,
g_atype395_3,
g_atype395_4,
g_atype395_5,
g_atype395_6,
};

static const long offsets395 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names396[];
static const uint32 types396 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags396 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype396_0 [] = {0xFF01,672,849,0xFFFF};
static const EIF_TYPE_INDEX g_atype396_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype396_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype396_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype396_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype396_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype396_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes396 [] = {
g_atype396_0,
g_atype396_1,
g_atype396_2,
g_atype396_3,
g_atype396_4,
g_atype396_5,
g_atype396_6,
};

static const long offsets396 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names397[];
static const uint32 types397 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags397 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype397_0 [] = {0xFF01,673,855,0xFFFF};
static const EIF_TYPE_INDEX g_atype397_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype397_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype397_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype397_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype397_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype397_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes397 [] = {
g_atype397_0,
g_atype397_1,
g_atype397_2,
g_atype397_3,
g_atype397_4,
g_atype397_5,
g_atype397_6,
};

static const long offsets397 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names398[];
static const uint32 types398 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags398 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype398_0 [] = {0xFF01,674,858,0xFFFF};
static const EIF_TYPE_INDEX g_atype398_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype398_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype398_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype398_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype398_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype398_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes398 [] = {
g_atype398_0,
g_atype398_1,
g_atype398_2,
g_atype398_3,
g_atype398_4,
g_atype398_5,
g_atype398_6,
};

static const long offsets398 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names399[];
static const uint32 types399 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags399 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype399_0 [] = {0xFF01,675,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype399_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype399_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype399_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype399_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype399_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype399_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes399 [] = {
g_atype399_0,
g_atype399_1,
g_atype399_2,
g_atype399_3,
g_atype399_4,
g_atype399_5,
g_atype399_6,
};

static const long offsets399 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names400[];
static const uint32 types400 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags400 [] =
{0,0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype400_0 [] = {0xFF01,767,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype400_1 [] = {104,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype400_2 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype400_3 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype400_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype400_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype400_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype400_7 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes400 [] = {
g_atype400_0,
g_atype400_1,
g_atype400_2,
g_atype400_3,
g_atype400_4,
g_atype400_5,
g_atype400_6,
g_atype400_7,
};

static const long offsets400 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
+ @LNGOFF(2,1,0,4),
};

extern const char *names401[];
static const uint32 types401 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags401 [] =
{0,0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype401_0 [] = {0xFF01,768,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype401_1 [] = {105,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype401_2 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype401_3 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype401_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype401_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype401_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype401_7 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes401 [] = {
g_atype401_0,
g_atype401_1,
g_atype401_2,
g_atype401_3,
g_atype401_4,
g_atype401_5,
g_atype401_6,
g_atype401_7,
};

static const long offsets401 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
+ @LNGOFF(2,1,0,4),
};

extern const char *names402[];
static const uint32 types402 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags402 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype402_0 [] = {0xFF01,785,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype402_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype402_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype402_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype402_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype402_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype402_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes402 [] = {
g_atype402_0,
g_atype402_1,
g_atype402_2,
g_atype402_3,
g_atype402_4,
g_atype402_5,
g_atype402_6,
};

static const long offsets402 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names403[];
static const uint32 types403 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags403 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype403_0 [] = {0xFF01,786,900,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype403_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype403_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype403_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype403_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype403_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype403_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes403 [] = {
g_atype403_0,
g_atype403_1,
g_atype403_2,
g_atype403_3,
g_atype403_4,
g_atype403_5,
g_atype403_6,
};

static const long offsets403 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names404[];
static const uint32 types404 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags404 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype404_0 [] = {0xFF01,787,0xFFF8,1,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype404_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype404_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype404_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype404_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype404_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype404_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes404 [] = {
g_atype404_0,
g_atype404_1,
g_atype404_2,
g_atype404_3,
g_atype404_4,
g_atype404_5,
g_atype404_6,
};

static const long offsets404 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names405[];
static const uint32 types405 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags405 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype405_0 [] = {0xFF01,788,834,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype405_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype405_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype405_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype405_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype405_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype405_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes405 [] = {
g_atype405_0,
g_atype405_1,
g_atype405_2,
g_atype405_3,
g_atype405_4,
g_atype405_5,
g_atype405_6,
};

static const long offsets405 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names406[];
static const uint32 types406 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags406 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype406_0 [] = {0xFF01,789,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype406_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype406_2 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype406_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype406_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype406_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype406_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes406 [] = {
g_atype406_0,
g_atype406_1,
g_atype406_2,
g_atype406_3,
g_atype406_4,
g_atype406_5,
g_atype406_6,
};

static const long offsets406 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names407[];
static const uint32 types407 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags407 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype407_0 [] = {0xFF01,676,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype407_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype407_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes407 [] = {
g_atype407_0,
g_atype407_1,
g_atype407_2,
};

static const long offsets407 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names408[];
static const uint32 types408 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags408 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype408_0 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype408_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype408_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes408 [] = {
g_atype408_0,
g_atype408_1,
g_atype408_2,
};

static const long offsets408 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names409[];
static const uint32 types409 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags409 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype409_0 [] = {0xFF01,678,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype409_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype409_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes409 [] = {
g_atype409_0,
g_atype409_1,
g_atype409_2,
};

static const long offsets409 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names410[];
static const uint32 types410 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags410 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype410_0 [] = {0xFF01,679,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype410_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype410_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes410 [] = {
g_atype410_0,
g_atype410_1,
g_atype410_2,
};

static const long offsets410 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names411[];
static const uint32 types411 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags411 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype411_0 [] = {0xFF01,680,861,0xFFFF};
static const EIF_TYPE_INDEX g_atype411_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype411_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes411 [] = {
g_atype411_0,
g_atype411_1,
g_atype411_2,
};

static const long offsets411 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names412[];
static const uint32 types412 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags412 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype412_0 [] = {0xFF01,681,843,0xFFFF};
static const EIF_TYPE_INDEX g_atype412_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype412_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes412 [] = {
g_atype412_0,
g_atype412_1,
g_atype412_2,
};

static const long offsets412 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names413[];
static const uint32 types413 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags413 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype413_0 [] = {0xFF01,682,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype413_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype413_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes413 [] = {
g_atype413_0,
g_atype413_1,
g_atype413_2,
};

static const long offsets413 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names414[];
static const uint32 types414 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags414 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype414_0 [] = {0xFF01,683,852,0xFFFF};
static const EIF_TYPE_INDEX g_atype414_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype414_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes414 [] = {
g_atype414_0,
g_atype414_1,
g_atype414_2,
};

static const long offsets414 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names415[];
static const uint32 types415 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags415 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype415_0 [] = {0xFF01,684,849,0xFFFF};
static const EIF_TYPE_INDEX g_atype415_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype415_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes415 [] = {
g_atype415_0,
g_atype415_1,
g_atype415_2,
};

static const long offsets415 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names416[];
static const uint32 types416 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags416 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype416_0 [] = {0xFF01,685,855,0xFFFF};
static const EIF_TYPE_INDEX g_atype416_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype416_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes416 [] = {
g_atype416_0,
g_atype416_1,
g_atype416_2,
};

static const long offsets416 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names417[];
static const uint32 types417 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags417 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype417_0 [] = {0xFF01,686,858,0xFFFF};
static const EIF_TYPE_INDEX g_atype417_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype417_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes417 [] = {
g_atype417_0,
g_atype417_1,
g_atype417_2,
};

static const long offsets417 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names418[];
static const uint32 types418 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags418 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype418_0 [] = {0xFF01,687,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype418_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype418_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes418 [] = {
g_atype418_0,
g_atype418_1,
g_atype418_2,
};

static const long offsets418 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names419[];
static const uint32 types419 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags419 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype419_0 [] = {0xFF01,676,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype419_1 [] = {0xFF01,773,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype419_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype419_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes419 [] = {
g_atype419_0,
g_atype419_1,
g_atype419_2,
g_atype419_3,
};

static const long offsets419 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names420[];
static const uint32 types420 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags420 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype420_0 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype420_1 [] = {0xFF01,774,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype420_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype420_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes420 [] = {
g_atype420_0,
g_atype420_1,
g_atype420_2,
g_atype420_3,
};

static const long offsets420 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names421[];
static const uint32 types421 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags421 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype421_0 [] = {0xFF01,678,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype421_1 [] = {0xFF01,775,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype421_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype421_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes421 [] = {
g_atype421_0,
g_atype421_1,
g_atype421_2,
g_atype421_3,
};

static const long offsets421 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names422[];
static const uint32 types422 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags422 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype422_0 [] = {0xFF01,679,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype422_1 [] = {0xFF01,776,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype422_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype422_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes422 [] = {
g_atype422_0,
g_atype422_1,
g_atype422_2,
g_atype422_3,
};

static const long offsets422 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names423[];
static const uint32 types423 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags423 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype423_0 [] = {0xFF01,680,861,0xFFFF};
static const EIF_TYPE_INDEX g_atype423_1 [] = {0xFF01,777,861,0xFFFF};
static const EIF_TYPE_INDEX g_atype423_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype423_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes423 [] = {
g_atype423_0,
g_atype423_1,
g_atype423_2,
g_atype423_3,
};

static const long offsets423 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names424[];
static const uint32 types424 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags424 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype424_0 [] = {0xFF01,681,843,0xFFFF};
static const EIF_TYPE_INDEX g_atype424_1 [] = {0xFF01,778,843,0xFFFF};
static const EIF_TYPE_INDEX g_atype424_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype424_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes424 [] = {
g_atype424_0,
g_atype424_1,
g_atype424_2,
g_atype424_3,
};

static const long offsets424 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names425[];
static const uint32 types425 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags425 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype425_0 [] = {0xFF01,682,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype425_1 [] = {0xFF01,779,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype425_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype425_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes425 [] = {
g_atype425_0,
g_atype425_1,
g_atype425_2,
g_atype425_3,
};

static const long offsets425 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names426[];
static const uint32 types426 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags426 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype426_0 [] = {0xFF01,683,852,0xFFFF};
static const EIF_TYPE_INDEX g_atype426_1 [] = {0xFF01,780,852,0xFFFF};
static const EIF_TYPE_INDEX g_atype426_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype426_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes426 [] = {
g_atype426_0,
g_atype426_1,
g_atype426_2,
g_atype426_3,
};

static const long offsets426 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names427[];
static const uint32 types427 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags427 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype427_0 [] = {0xFF01,684,849,0xFFFF};
static const EIF_TYPE_INDEX g_atype427_1 [] = {0xFF01,781,849,0xFFFF};
static const EIF_TYPE_INDEX g_atype427_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype427_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes427 [] = {
g_atype427_0,
g_atype427_1,
g_atype427_2,
g_atype427_3,
};

static const long offsets427 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names428[];
static const uint32 types428 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags428 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype428_0 [] = {0xFF01,685,855,0xFFFF};
static const EIF_TYPE_INDEX g_atype428_1 [] = {0xFF01,782,855,0xFFFF};
static const EIF_TYPE_INDEX g_atype428_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype428_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes428 [] = {
g_atype428_0,
g_atype428_1,
g_atype428_2,
g_atype428_3,
};

static const long offsets428 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names429[];
static const uint32 types429 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags429 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype429_0 [] = {0xFF01,686,858,0xFFFF};
static const EIF_TYPE_INDEX g_atype429_1 [] = {0xFF01,783,858,0xFFFF};
static const EIF_TYPE_INDEX g_atype429_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype429_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes429 [] = {
g_atype429_0,
g_atype429_1,
g_atype429_2,
g_atype429_3,
};

static const long offsets429 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names430[];
static const uint32 types430 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags430 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype430_0 [] = {0xFF01,687,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype430_1 [] = {0xFF01,784,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype430_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype430_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes430 [] = {
g_atype430_0,
g_atype430_1,
g_atype430_2,
g_atype430_3,
};

static const long offsets430 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names431[];
static const uint32 types431 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags431 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype431_0 [] = {0xFF01,680,861,0xFFFF};
static const EIF_TYPE_INDEX g_atype431_1 [] = {0xFF01,909,0xFFFF};
static const EIF_TYPE_INDEX g_atype431_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype431_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype431_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes431 [] = {
g_atype431_0,
g_atype431_1,
g_atype431_2,
g_atype431_3,
g_atype431_4,
};

static const long offsets431 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names432[];
static const uint32 types432 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags432 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype432_0 [] = {0xFF01,682,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype432_1 [] = {0xFF01,912,0xFFFF};
static const EIF_TYPE_INDEX g_atype432_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype432_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype432_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes432 [] = {
g_atype432_0,
g_atype432_1,
g_atype432_2,
g_atype432_3,
g_atype432_4,
};

static const long offsets432 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names433[];
static const uint32 types433 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags433 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype433_0 [] = {0xFF01,676,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype433_1 [] = {0xFF01,701,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype433_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype433_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype433_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes433 [] = {
g_atype433_0,
g_atype433_1,
g_atype433_2,
g_atype433_3,
g_atype433_4,
};

static const long offsets433 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names434[];
static const uint32 types434 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags434 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype434_0 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype434_1 [] = {0xFF01,702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype434_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype434_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype434_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes434 [] = {
g_atype434_0,
g_atype434_1,
g_atype434_2,
g_atype434_3,
g_atype434_4,
};

static const long offsets434 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names435[];
static const uint32 types435 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags435 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype435_0 [] = {0xFF01,678,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype435_1 [] = {0xFF01,703,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype435_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype435_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype435_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes435 [] = {
g_atype435_0,
g_atype435_1,
g_atype435_2,
g_atype435_3,
g_atype435_4,
};

static const long offsets435 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names436[];
static const uint32 types436 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags436 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype436_0 [] = {0xFF01,679,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype436_1 [] = {0xFF01,704,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype436_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype436_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype436_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes436 [] = {
g_atype436_0,
g_atype436_1,
g_atype436_2,
g_atype436_3,
g_atype436_4,
};

static const long offsets436 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names437[];
static const uint32 types437 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags437 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype437_0 [] = {0xFF01,680,861,0xFFFF};
static const EIF_TYPE_INDEX g_atype437_1 [] = {0xFF01,705,861,0xFFFF};
static const EIF_TYPE_INDEX g_atype437_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype437_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype437_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes437 [] = {
g_atype437_0,
g_atype437_1,
g_atype437_2,
g_atype437_3,
g_atype437_4,
};

static const long offsets437 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names438[];
static const uint32 types438 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags438 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype438_0 [] = {0xFF01,681,843,0xFFFF};
static const EIF_TYPE_INDEX g_atype438_1 [] = {0xFF01,706,843,0xFFFF};
static const EIF_TYPE_INDEX g_atype438_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype438_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype438_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes438 [] = {
g_atype438_0,
g_atype438_1,
g_atype438_2,
g_atype438_3,
g_atype438_4,
};

static const long offsets438 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names439[];
static const uint32 types439 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags439 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype439_0 [] = {0xFF01,682,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype439_1 [] = {0xFF01,707,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype439_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype439_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype439_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes439 [] = {
g_atype439_0,
g_atype439_1,
g_atype439_2,
g_atype439_3,
g_atype439_4,
};

static const long offsets439 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names440[];
static const uint32 types440 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags440 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype440_0 [] = {0xFF01,683,852,0xFFFF};
static const EIF_TYPE_INDEX g_atype440_1 [] = {0xFF01,708,852,0xFFFF};
static const EIF_TYPE_INDEX g_atype440_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype440_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype440_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes440 [] = {
g_atype440_0,
g_atype440_1,
g_atype440_2,
g_atype440_3,
g_atype440_4,
};

static const long offsets440 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names441[];
static const uint32 types441 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags441 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype441_0 [] = {0xFF01,684,849,0xFFFF};
static const EIF_TYPE_INDEX g_atype441_1 [] = {0xFF01,709,849,0xFFFF};
static const EIF_TYPE_INDEX g_atype441_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype441_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype441_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes441 [] = {
g_atype441_0,
g_atype441_1,
g_atype441_2,
g_atype441_3,
g_atype441_4,
};

static const long offsets441 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names442[];
static const uint32 types442 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags442 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype442_0 [] = {0xFF01,685,855,0xFFFF};
static const EIF_TYPE_INDEX g_atype442_1 [] = {0xFF01,710,855,0xFFFF};
static const EIF_TYPE_INDEX g_atype442_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype442_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype442_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes442 [] = {
g_atype442_0,
g_atype442_1,
g_atype442_2,
g_atype442_3,
g_atype442_4,
};

static const long offsets442 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names443[];
static const uint32 types443 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags443 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype443_0 [] = {0xFF01,686,858,0xFFFF};
static const EIF_TYPE_INDEX g_atype443_1 [] = {0xFF01,711,858,0xFFFF};
static const EIF_TYPE_INDEX g_atype443_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype443_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype443_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes443 [] = {
g_atype443_0,
g_atype443_1,
g_atype443_2,
g_atype443_3,
g_atype443_4,
};

static const long offsets443 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names444[];
static const uint32 types444 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags444 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype444_0 [] = {0xFF01,687,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype444_1 [] = {0xFF01,712,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype444_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype444_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype444_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes444 [] = {
g_atype444_0,
g_atype444_1,
g_atype444_2,
g_atype444_3,
g_atype444_4,
};

static const long offsets444 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names445[];
static const uint32 types445 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags445 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype445_0 [] = {0xFF01,676,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype445_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype445_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes445 [] = {
g_atype445_0,
g_atype445_1,
g_atype445_2,
};

static const long offsets445 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names446[];
static const uint32 types446 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags446 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype446_0 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype446_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype446_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes446 [] = {
g_atype446_0,
g_atype446_1,
g_atype446_2,
};

static const long offsets446 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names447[];
static const uint32 types447 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags447 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype447_0 [] = {0xFF01,678,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype447_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype447_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes447 [] = {
g_atype447_0,
g_atype447_1,
g_atype447_2,
};

static const long offsets447 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names448[];
static const uint32 types448 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags448 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype448_0 [] = {0xFF01,679,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes448 [] = {
g_atype448_0,
g_atype448_1,
g_atype448_2,
};

static const long offsets448 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names449[];
static const uint32 types449 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags449 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype449_0 [] = {0xFF01,680,861,0xFFFF};
static const EIF_TYPE_INDEX g_atype449_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype449_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes449 [] = {
g_atype449_0,
g_atype449_1,
g_atype449_2,
};

static const long offsets449 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names450[];
static const uint32 types450 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags450 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype450_0 [] = {0xFF01,681,843,0xFFFF};
static const EIF_TYPE_INDEX g_atype450_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype450_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes450 [] = {
g_atype450_0,
g_atype450_1,
g_atype450_2,
};

static const long offsets450 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names451[];
static const uint32 types451 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags451 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype451_0 [] = {0xFF01,682,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype451_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype451_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes451 [] = {
g_atype451_0,
g_atype451_1,
g_atype451_2,
};

static const long offsets451 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names452[];
static const uint32 types452 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags452 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype452_0 [] = {0xFF01,683,852,0xFFFF};
static const EIF_TYPE_INDEX g_atype452_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype452_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes452 [] = {
g_atype452_0,
g_atype452_1,
g_atype452_2,
};

static const long offsets452 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names453[];
static const uint32 types453 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags453 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype453_0 [] = {0xFF01,684,849,0xFFFF};
static const EIF_TYPE_INDEX g_atype453_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype453_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes453 [] = {
g_atype453_0,
g_atype453_1,
g_atype453_2,
};

static const long offsets453 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names454[];
static const uint32 types454 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags454 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype454_0 [] = {0xFF01,685,855,0xFFFF};
static const EIF_TYPE_INDEX g_atype454_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype454_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes454 [] = {
g_atype454_0,
g_atype454_1,
g_atype454_2,
};

static const long offsets454 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names455[];
static const uint32 types455 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags455 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype455_0 [] = {0xFF01,686,858,0xFFFF};
static const EIF_TYPE_INDEX g_atype455_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype455_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes455 [] = {
g_atype455_0,
g_atype455_1,
g_atype455_2,
};

static const long offsets455 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names456[];
static const uint32 types456 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags456 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype456_0 [] = {0xFF01,687,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype456_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype456_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes456 [] = {
g_atype456_0,
g_atype456_1,
g_atype456_2,
};

static const long offsets456 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names457[];
static const uint32 types457 [] =
{
SK_BOOL,
};

static const uint16 attr_flags457 [] =
{0,};

static const EIF_TYPE_INDEX g_atype457_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes457 [] = {
g_atype457_0,
};

static const long offsets457 [] =
{
+ @CHROFF(0,0),
};

extern const char *names458[];
static const uint32 types458 [] =
{
SK_BOOL,
};

static const uint16 attr_flags458 [] =
{0,};

static const EIF_TYPE_INDEX g_atype458_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes458 [] = {
g_atype458_0,
};

static const long offsets458 [] =
{
+ @CHROFF(0,0),
};

extern const char *names459[];
static const uint32 types459 [] =
{
SK_BOOL,
};

static const uint16 attr_flags459 [] =
{0,};

static const EIF_TYPE_INDEX g_atype459_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes459 [] = {
g_atype459_0,
};

static const long offsets459 [] =
{
+ @CHROFF(0,0),
};

extern const char *names460[];
static const uint32 types460 [] =
{
SK_BOOL,
};

static const uint16 attr_flags460 [] =
{0,};

static const EIF_TYPE_INDEX g_atype460_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes460 [] = {
g_atype460_0,
};

static const long offsets460 [] =
{
+ @CHROFF(0,0),
};

extern const char *names461[];
static const uint32 types461 [] =
{
SK_BOOL,
};

static const uint16 attr_flags461 [] =
{0,};

static const EIF_TYPE_INDEX g_atype461_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes461 [] = {
g_atype461_0,
};

static const long offsets461 [] =
{
+ @CHROFF(0,0),
};

extern const char *names462[];
static const uint32 types462 [] =
{
SK_BOOL,
};

static const uint16 attr_flags462 [] =
{0,};

static const EIF_TYPE_INDEX g_atype462_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes462 [] = {
g_atype462_0,
};

static const long offsets462 [] =
{
+ @CHROFF(0,0),
};

extern const char *names463[];
static const uint32 types463 [] =
{
SK_BOOL,
};

static const uint16 attr_flags463 [] =
{0,};

static const EIF_TYPE_INDEX g_atype463_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes463 [] = {
g_atype463_0,
};

static const long offsets463 [] =
{
+ @CHROFF(0,0),
};

extern const char *names464[];
static const uint32 types464 [] =
{
SK_BOOL,
};

static const uint16 attr_flags464 [] =
{0,};

static const EIF_TYPE_INDEX g_atype464_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes464 [] = {
g_atype464_0,
};

static const long offsets464 [] =
{
+ @CHROFF(0,0),
};

extern const char *names465[];
static const uint32 types465 [] =
{
SK_BOOL,
};

static const uint16 attr_flags465 [] =
{0,};

static const EIF_TYPE_INDEX g_atype465_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes465 [] = {
g_atype465_0,
};

static const long offsets465 [] =
{
+ @CHROFF(0,0),
};

extern const char *names466[];
static const uint32 types466 [] =
{
SK_BOOL,
};

static const uint16 attr_flags466 [] =
{0,};

static const EIF_TYPE_INDEX g_atype466_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes466 [] = {
g_atype466_0,
};

static const long offsets466 [] =
{
+ @CHROFF(0,0),
};

extern const char *names467[];
static const uint32 types467 [] =
{
SK_BOOL,
};

static const uint16 attr_flags467 [] =
{0,};

static const EIF_TYPE_INDEX g_atype467_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes467 [] = {
g_atype467_0,
};

static const long offsets467 [] =
{
+ @CHROFF(0,0),
};

extern const char *names468[];
static const uint32 types468 [] =
{
SK_BOOL,
};

static const uint16 attr_flags468 [] =
{0,};

static const EIF_TYPE_INDEX g_atype468_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes468 [] = {
g_atype468_0,
};

static const long offsets468 [] =
{
+ @CHROFF(0,0),
};

extern const char *names469[];
static const uint32 types469 [] =
{
SK_BOOL,
};

static const uint16 attr_flags469 [] =
{0,};

static const EIF_TYPE_INDEX g_atype469_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes469 [] = {
g_atype469_0,
};

static const long offsets469 [] =
{
+ @CHROFF(0,0),
};

extern const char *names470[];
static const uint32 types470 [] =
{
SK_BOOL,
};

static const uint16 attr_flags470 [] =
{0,};

static const EIF_TYPE_INDEX g_atype470_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes470 [] = {
g_atype470_0,
};

static const long offsets470 [] =
{
+ @CHROFF(0,0),
};

extern const char *names471[];
static const uint32 types471 [] =
{
SK_BOOL,
};

static const uint16 attr_flags471 [] =
{0,};

static const EIF_TYPE_INDEX g_atype471_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes471 [] = {
g_atype471_0,
};

static const long offsets471 [] =
{
+ @CHROFF(0,0),
};

extern const char *names472[];
static const uint32 types472 [] =
{
SK_BOOL,
};

static const uint16 attr_flags472 [] =
{0,};

static const EIF_TYPE_INDEX g_atype472_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes472 [] = {
g_atype472_0,
};

static const long offsets472 [] =
{
+ @CHROFF(0,0),
};

extern const char *names473[];
static const uint32 types473 [] =
{
SK_BOOL,
};

static const uint16 attr_flags473 [] =
{0,};

static const EIF_TYPE_INDEX g_atype473_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes473 [] = {
g_atype473_0,
};

static const long offsets473 [] =
{
+ @CHROFF(0,0),
};

extern const char *names474[];
static const uint32 types474 [] =
{
SK_BOOL,
};

static const uint16 attr_flags474 [] =
{0,};

static const EIF_TYPE_INDEX g_atype474_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes474 [] = {
g_atype474_0,
};

static const long offsets474 [] =
{
+ @CHROFF(0,0),
};

extern const char *names475[];
static const uint32 types475 [] =
{
SK_BOOL,
};

static const uint16 attr_flags475 [] =
{0,};

static const EIF_TYPE_INDEX g_atype475_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes475 [] = {
g_atype475_0,
};

static const long offsets475 [] =
{
+ @CHROFF(0,0),
};

extern const char *names476[];
static const uint32 types476 [] =
{
SK_BOOL,
};

static const uint16 attr_flags476 [] =
{0,};

static const EIF_TYPE_INDEX g_atype476_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes476 [] = {
g_atype476_0,
};

static const long offsets476 [] =
{
+ @CHROFF(0,0),
};

extern const char *names477[];
static const uint32 types477 [] =
{
SK_BOOL,
};

static const uint16 attr_flags477 [] =
{0,};

static const EIF_TYPE_INDEX g_atype477_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes477 [] = {
g_atype477_0,
};

static const long offsets477 [] =
{
+ @CHROFF(0,0),
};

extern const char *names478[];
static const uint32 types478 [] =
{
SK_BOOL,
};

static const uint16 attr_flags478 [] =
{0,};

static const EIF_TYPE_INDEX g_atype478_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes478 [] = {
g_atype478_0,
};

static const long offsets478 [] =
{
+ @CHROFF(0,0),
};

extern const char *names479[];
static const uint32 types479 [] =
{
SK_BOOL,
};

static const uint16 attr_flags479 [] =
{0,};

static const EIF_TYPE_INDEX g_atype479_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes479 [] = {
g_atype479_0,
};

static const long offsets479 [] =
{
+ @CHROFF(0,0),
};

extern const char *names480[];
static const uint32 types480 [] =
{
SK_BOOL,
};

static const uint16 attr_flags480 [] =
{0,};

static const EIF_TYPE_INDEX g_atype480_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes480 [] = {
g_atype480_0,
};

static const long offsets480 [] =
{
+ @CHROFF(0,0),
};

extern const char *names481[];
static const uint32 types481 [] =
{
SK_BOOL,
};

static const uint16 attr_flags481 [] =
{0,};

static const EIF_TYPE_INDEX g_atype481_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes481 [] = {
g_atype481_0,
};

static const long offsets481 [] =
{
+ @CHROFF(0,0),
};

extern const char *names482[];
static const uint32 types482 [] =
{
SK_BOOL,
};

static const uint16 attr_flags482 [] =
{0,};

static const EIF_TYPE_INDEX g_atype482_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes482 [] = {
g_atype482_0,
};

static const long offsets482 [] =
{
+ @CHROFF(0,0),
};

extern const char *names483[];
static const uint32 types483 [] =
{
SK_BOOL,
};

static const uint16 attr_flags483 [] =
{0,};

static const EIF_TYPE_INDEX g_atype483_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes483 [] = {
g_atype483_0,
};

static const long offsets483 [] =
{
+ @CHROFF(0,0),
};

extern const char *names484[];
static const uint32 types484 [] =
{
SK_BOOL,
};

static const uint16 attr_flags484 [] =
{0,};

static const EIF_TYPE_INDEX g_atype484_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes484 [] = {
g_atype484_0,
};

static const long offsets484 [] =
{
+ @CHROFF(0,0),
};

extern const char *names485[];
static const uint32 types485 [] =
{
SK_BOOL,
};

static const uint16 attr_flags485 [] =
{0,};

static const EIF_TYPE_INDEX g_atype485_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes485 [] = {
g_atype485_0,
};

static const long offsets485 [] =
{
+ @CHROFF(0,0),
};

extern const char *names486[];
static const uint32 types486 [] =
{
SK_BOOL,
};

static const uint16 attr_flags486 [] =
{0,};

static const EIF_TYPE_INDEX g_atype486_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes486 [] = {
g_atype486_0,
};

static const long offsets486 [] =
{
+ @CHROFF(0,0),
};

extern const char *names487[];
static const uint32 types487 [] =
{
SK_BOOL,
};

static const uint16 attr_flags487 [] =
{0,};

static const EIF_TYPE_INDEX g_atype487_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes487 [] = {
g_atype487_0,
};

static const long offsets487 [] =
{
+ @CHROFF(0,0),
};

extern const char *names488[];
static const uint32 types488 [] =
{
SK_BOOL,
};

static const uint16 attr_flags488 [] =
{0,};

static const EIF_TYPE_INDEX g_atype488_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes488 [] = {
g_atype488_0,
};

static const long offsets488 [] =
{
+ @CHROFF(0,0),
};

extern const char *names489[];
static const uint32 types489 [] =
{
SK_BOOL,
};

static const uint16 attr_flags489 [] =
{0,};

static const EIF_TYPE_INDEX g_atype489_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes489 [] = {
g_atype489_0,
};

static const long offsets489 [] =
{
+ @CHROFF(0,0),
};

extern const char *names490[];
static const uint32 types490 [] =
{
SK_BOOL,
};

static const uint16 attr_flags490 [] =
{0,};

static const EIF_TYPE_INDEX g_atype490_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes490 [] = {
g_atype490_0,
};

static const long offsets490 [] =
{
+ @CHROFF(0,0),
};

extern const char *names491[];
static const uint32 types491 [] =
{
SK_BOOL,
};

static const uint16 attr_flags491 [] =
{0,};

static const EIF_TYPE_INDEX g_atype491_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes491 [] = {
g_atype491_0,
};

static const long offsets491 [] =
{
+ @CHROFF(0,0),
};

extern const char *names492[];
static const uint32 types492 [] =
{
SK_BOOL,
};

static const uint16 attr_flags492 [] =
{0,};

static const EIF_TYPE_INDEX g_atype492_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes492 [] = {
g_atype492_0,
};

static const long offsets492 [] =
{
+ @CHROFF(0,0),
};

extern const char *names493[];
static const uint32 types493 [] =
{
SK_BOOL,
};

static const uint16 attr_flags493 [] =
{0,};

static const EIF_TYPE_INDEX g_atype493_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes493 [] = {
g_atype493_0,
};

static const long offsets493 [] =
{
+ @CHROFF(0,0),
};

extern const char *names494[];
static const uint32 types494 [] =
{
SK_BOOL,
};

static const uint16 attr_flags494 [] =
{0,};

static const EIF_TYPE_INDEX g_atype494_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes494 [] = {
g_atype494_0,
};

static const long offsets494 [] =
{
+ @CHROFF(0,0),
};

extern const char *names495[];
static const uint32 types495 [] =
{
SK_BOOL,
};

static const uint16 attr_flags495 [] =
{0,};

static const EIF_TYPE_INDEX g_atype495_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes495 [] = {
g_atype495_0,
};

static const long offsets495 [] =
{
+ @CHROFF(0,0),
};

extern const char *names496[];
static const uint32 types496 [] =
{
SK_BOOL,
};

static const uint16 attr_flags496 [] =
{0,};

static const EIF_TYPE_INDEX g_atype496_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes496 [] = {
g_atype496_0,
};

static const long offsets496 [] =
{
+ @CHROFF(0,0),
};

extern const char *names497[];
static const uint32 types497 [] =
{
SK_BOOL,
};

static const uint16 attr_flags497 [] =
{0,};

static const EIF_TYPE_INDEX g_atype497_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes497 [] = {
g_atype497_0,
};

static const long offsets497 [] =
{
+ @CHROFF(0,0),
};

extern const char *names498[];
static const uint32 types498 [] =
{
SK_BOOL,
};

static const uint16 attr_flags498 [] =
{0,};

static const EIF_TYPE_INDEX g_atype498_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes498 [] = {
g_atype498_0,
};

static const long offsets498 [] =
{
+ @CHROFF(0,0),
};

extern const char *names499[];
static const uint32 types499 [] =
{
SK_BOOL,
};

static const uint16 attr_flags499 [] =
{0,};

static const EIF_TYPE_INDEX g_atype499_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes499 [] = {
g_atype499_0,
};

static const long offsets499 [] =
{
+ @CHROFF(0,0),
};

extern const char *names500[];
static const uint32 types500 [] =
{
SK_BOOL,
};

static const uint16 attr_flags500 [] =
{0,};

static const EIF_TYPE_INDEX g_atype500_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes500 [] = {
g_atype500_0,
};

static const long offsets500 [] =
{
+ @CHROFF(0,0),
};

extern const char *names501[];
static const uint32 types501 [] =
{
SK_BOOL,
};

static const uint16 attr_flags501 [] =
{0,};

static const EIF_TYPE_INDEX g_atype501_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes501 [] = {
g_atype501_0,
};

static const long offsets501 [] =
{
+ @CHROFF(0,0),
};

extern const char *names502[];
static const uint32 types502 [] =
{
SK_BOOL,
};

static const uint16 attr_flags502 [] =
{0,};

static const EIF_TYPE_INDEX g_atype502_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes502 [] = {
g_atype502_0,
};

static const long offsets502 [] =
{
+ @CHROFF(0,0),
};

extern const char *names503[];
static const uint32 types503 [] =
{
SK_BOOL,
};

static const uint16 attr_flags503 [] =
{0,};

static const EIF_TYPE_INDEX g_atype503_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes503 [] = {
g_atype503_0,
};

static const long offsets503 [] =
{
+ @CHROFF(0,0),
};

extern const char *names504[];
static const uint32 types504 [] =
{
SK_BOOL,
};

static const uint16 attr_flags504 [] =
{0,};

static const EIF_TYPE_INDEX g_atype504_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes504 [] = {
g_atype504_0,
};

static const long offsets504 [] =
{
+ @CHROFF(0,0),
};

extern const char *names505[];
static const uint32 types505 [] =
{
SK_BOOL,
};

static const uint16 attr_flags505 [] =
{0,};

static const EIF_TYPE_INDEX g_atype505_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes505 [] = {
g_atype505_0,
};

static const long offsets505 [] =
{
+ @CHROFF(0,0),
};

extern const char *names506[];
static const uint32 types506 [] =
{
SK_BOOL,
};

static const uint16 attr_flags506 [] =
{0,};

static const EIF_TYPE_INDEX g_atype506_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes506 [] = {
g_atype506_0,
};

static const long offsets506 [] =
{
+ @CHROFF(0,0),
};

extern const char *names507[];
static const uint32 types507 [] =
{
SK_BOOL,
};

static const uint16 attr_flags507 [] =
{0,};

static const EIF_TYPE_INDEX g_atype507_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes507 [] = {
g_atype507_0,
};

static const long offsets507 [] =
{
+ @CHROFF(0,0),
};

extern const char *names508[];
static const uint32 types508 [] =
{
SK_BOOL,
};

static const uint16 attr_flags508 [] =
{0,};

static const EIF_TYPE_INDEX g_atype508_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes508 [] = {
g_atype508_0,
};

static const long offsets508 [] =
{
+ @CHROFF(0,0),
};

extern const char *names509[];
static const uint32 types509 [] =
{
SK_BOOL,
};

static const uint16 attr_flags509 [] =
{0,};

static const EIF_TYPE_INDEX g_atype509_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes509 [] = {
g_atype509_0,
};

static const long offsets509 [] =
{
+ @CHROFF(0,0),
};

extern const char *names510[];
static const uint32 types510 [] =
{
SK_BOOL,
};

static const uint16 attr_flags510 [] =
{0,};

static const EIF_TYPE_INDEX g_atype510_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes510 [] = {
g_atype510_0,
};

static const long offsets510 [] =
{
+ @CHROFF(0,0),
};

extern const char *names511[];
static const uint32 types511 [] =
{
SK_BOOL,
};

static const uint16 attr_flags511 [] =
{0,};

static const EIF_TYPE_INDEX g_atype511_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes511 [] = {
g_atype511_0,
};

static const long offsets511 [] =
{
+ @CHROFF(0,0),
};

extern const char *names512[];
static const uint32 types512 [] =
{
SK_BOOL,
};

static const uint16 attr_flags512 [] =
{0,};

static const EIF_TYPE_INDEX g_atype512_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes512 [] = {
g_atype512_0,
};

static const long offsets512 [] =
{
+ @CHROFF(0,0),
};

extern const char *names513[];
static const uint32 types513 [] =
{
SK_BOOL,
};

static const uint16 attr_flags513 [] =
{0,};

static const EIF_TYPE_INDEX g_atype513_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes513 [] = {
g_atype513_0,
};

static const long offsets513 [] =
{
+ @CHROFF(0,0),
};

extern const char *names514[];
static const uint32 types514 [] =
{
SK_BOOL,
};

static const uint16 attr_flags514 [] =
{0,};

static const EIF_TYPE_INDEX g_atype514_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes514 [] = {
g_atype514_0,
};

static const long offsets514 [] =
{
+ @CHROFF(0,0),
};

extern const char *names515[];
static const uint32 types515 [] =
{
SK_BOOL,
};

static const uint16 attr_flags515 [] =
{0,};

static const EIF_TYPE_INDEX g_atype515_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes515 [] = {
g_atype515_0,
};

static const long offsets515 [] =
{
+ @CHROFF(0,0),
};

extern const char *names516[];
static const uint32 types516 [] =
{
SK_BOOL,
};

static const uint16 attr_flags516 [] =
{0,};

static const EIF_TYPE_INDEX g_atype516_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes516 [] = {
g_atype516_0,
};

static const long offsets516 [] =
{
+ @CHROFF(0,0),
};

extern const char *names517[];
static const uint32 types517 [] =
{
SK_BOOL,
};

static const uint16 attr_flags517 [] =
{0,};

static const EIF_TYPE_INDEX g_atype517_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes517 [] = {
g_atype517_0,
};

static const long offsets517 [] =
{
+ @CHROFF(0,0),
};

extern const char *names518[];
static const uint32 types518 [] =
{
SK_BOOL,
};

static const uint16 attr_flags518 [] =
{0,};

static const EIF_TYPE_INDEX g_atype518_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes518 [] = {
g_atype518_0,
};

static const long offsets518 [] =
{
+ @CHROFF(0,0),
};

extern const char *names519[];
static const uint32 types519 [] =
{
SK_BOOL,
};

static const uint16 attr_flags519 [] =
{0,};

static const EIF_TYPE_INDEX g_atype519_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes519 [] = {
g_atype519_0,
};

static const long offsets519 [] =
{
+ @CHROFF(0,0),
};

extern const char *names520[];
static const uint32 types520 [] =
{
SK_BOOL,
};

static const uint16 attr_flags520 [] =
{0,};

static const EIF_TYPE_INDEX g_atype520_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes520 [] = {
g_atype520_0,
};

static const long offsets520 [] =
{
+ @CHROFF(0,0),
};

extern const char *names521[];
static const uint32 types521 [] =
{
SK_BOOL,
};

static const uint16 attr_flags521 [] =
{0,};

static const EIF_TYPE_INDEX g_atype521_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes521 [] = {
g_atype521_0,
};

static const long offsets521 [] =
{
+ @CHROFF(0,0),
};

extern const char *names522[];
static const uint32 types522 [] =
{
SK_BOOL,
};

static const uint16 attr_flags522 [] =
{0,};

static const EIF_TYPE_INDEX g_atype522_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes522 [] = {
g_atype522_0,
};

static const long offsets522 [] =
{
+ @CHROFF(0,0),
};

extern const char *names523[];
static const uint32 types523 [] =
{
SK_BOOL,
};

static const uint16 attr_flags523 [] =
{0,};

static const EIF_TYPE_INDEX g_atype523_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes523 [] = {
g_atype523_0,
};

static const long offsets523 [] =
{
+ @CHROFF(0,0),
};

extern const char *names524[];
static const uint32 types524 [] =
{
SK_BOOL,
};

static const uint16 attr_flags524 [] =
{0,};

static const EIF_TYPE_INDEX g_atype524_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes524 [] = {
g_atype524_0,
};

static const long offsets524 [] =
{
+ @CHROFF(0,0),
};

extern const char *names525[];
static const uint32 types525 [] =
{
SK_BOOL,
};

static const uint16 attr_flags525 [] =
{0,};

static const EIF_TYPE_INDEX g_atype525_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes525 [] = {
g_atype525_0,
};

static const long offsets525 [] =
{
+ @CHROFF(0,0),
};

extern const char *names526[];
static const uint32 types526 [] =
{
SK_BOOL,
};

static const uint16 attr_flags526 [] =
{0,};

static const EIF_TYPE_INDEX g_atype526_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes526 [] = {
g_atype526_0,
};

static const long offsets526 [] =
{
+ @CHROFF(0,0),
};

extern const char *names527[];
static const uint32 types527 [] =
{
SK_BOOL,
};

static const uint16 attr_flags527 [] =
{0,};

static const EIF_TYPE_INDEX g_atype527_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes527 [] = {
g_atype527_0,
};

static const long offsets527 [] =
{
+ @CHROFF(0,0),
};

extern const char *names528[];
static const uint32 types528 [] =
{
SK_BOOL,
};

static const uint16 attr_flags528 [] =
{0,};

static const EIF_TYPE_INDEX g_atype528_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes528 [] = {
g_atype528_0,
};

static const long offsets528 [] =
{
+ @CHROFF(0,0),
};

extern const char *names529[];
static const uint32 types529 [] =
{
SK_BOOL,
};

static const uint16 attr_flags529 [] =
{0,};

static const EIF_TYPE_INDEX g_atype529_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes529 [] = {
g_atype529_0,
};

static const long offsets529 [] =
{
+ @CHROFF(0,0),
};

extern const char *names530[];
static const uint32 types530 [] =
{
SK_BOOL,
};

static const uint16 attr_flags530 [] =
{0,};

static const EIF_TYPE_INDEX g_atype530_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes530 [] = {
g_atype530_0,
};

static const long offsets530 [] =
{
+ @CHROFF(0,0),
};

extern const char *names531[];
static const uint32 types531 [] =
{
SK_BOOL,
};

static const uint16 attr_flags531 [] =
{0,};

static const EIF_TYPE_INDEX g_atype531_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes531 [] = {
g_atype531_0,
};

static const long offsets531 [] =
{
+ @CHROFF(0,0),
};

extern const char *names532[];
static const uint32 types532 [] =
{
SK_BOOL,
};

static const uint16 attr_flags532 [] =
{0,};

static const EIF_TYPE_INDEX g_atype532_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes532 [] = {
g_atype532_0,
};

static const long offsets532 [] =
{
+ @CHROFF(0,0),
};

extern const char *names533[];
static const uint32 types533 [] =
{
SK_BOOL,
};

static const uint16 attr_flags533 [] =
{0,};

static const EIF_TYPE_INDEX g_atype533_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes533 [] = {
g_atype533_0,
};

static const long offsets533 [] =
{
+ @CHROFF(0,0),
};

extern const char *names534[];
static const uint32 types534 [] =
{
SK_BOOL,
};

static const uint16 attr_flags534 [] =
{0,};

static const EIF_TYPE_INDEX g_atype534_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes534 [] = {
g_atype534_0,
};

static const long offsets534 [] =
{
+ @CHROFF(0,0),
};

extern const char *names535[];
static const uint32 types535 [] =
{
SK_BOOL,
};

static const uint16 attr_flags535 [] =
{0,};

static const EIF_TYPE_INDEX g_atype535_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes535 [] = {
g_atype535_0,
};

static const long offsets535 [] =
{
+ @CHROFF(0,0),
};

extern const char *names536[];
static const uint32 types536 [] =
{
SK_BOOL,
};

static const uint16 attr_flags536 [] =
{0,};

static const EIF_TYPE_INDEX g_atype536_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes536 [] = {
g_atype536_0,
};

static const long offsets536 [] =
{
+ @CHROFF(0,0),
};

extern const char *names537[];
static const uint32 types537 [] =
{
SK_BOOL,
};

static const uint16 attr_flags537 [] =
{0,};

static const EIF_TYPE_INDEX g_atype537_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes537 [] = {
g_atype537_0,
};

static const long offsets537 [] =
{
+ @CHROFF(0,0),
};

extern const char *names538[];
static const uint32 types538 [] =
{
SK_BOOL,
};

static const uint16 attr_flags538 [] =
{0,};

static const EIF_TYPE_INDEX g_atype538_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes538 [] = {
g_atype538_0,
};

static const long offsets538 [] =
{
+ @CHROFF(0,0),
};

extern const char *names539[];
static const uint32 types539 [] =
{
SK_BOOL,
};

static const uint16 attr_flags539 [] =
{0,};

static const EIF_TYPE_INDEX g_atype539_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes539 [] = {
g_atype539_0,
};

static const long offsets539 [] =
{
+ @CHROFF(0,0),
};

extern const char *names540[];
static const uint32 types540 [] =
{
SK_BOOL,
};

static const uint16 attr_flags540 [] =
{0,};

static const EIF_TYPE_INDEX g_atype540_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes540 [] = {
g_atype540_0,
};

static const long offsets540 [] =
{
+ @CHROFF(0,0),
};

extern const char *names541[];
static const uint32 types541 [] =
{
SK_BOOL,
};

static const uint16 attr_flags541 [] =
{0,};

static const EIF_TYPE_INDEX g_atype541_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes541 [] = {
g_atype541_0,
};

static const long offsets541 [] =
{
+ @CHROFF(0,0),
};

extern const char *names542[];
static const uint32 types542 [] =
{
SK_BOOL,
};

static const uint16 attr_flags542 [] =
{0,};

static const EIF_TYPE_INDEX g_atype542_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes542 [] = {
g_atype542_0,
};

static const long offsets542 [] =
{
+ @CHROFF(0,0),
};

extern const char *names543[];
static const uint32 types543 [] =
{
SK_BOOL,
};

static const uint16 attr_flags543 [] =
{0,};

static const EIF_TYPE_INDEX g_atype543_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes543 [] = {
g_atype543_0,
};

static const long offsets543 [] =
{
+ @CHROFF(0,0),
};

extern const char *names544[];
static const uint32 types544 [] =
{
SK_BOOL,
};

static const uint16 attr_flags544 [] =
{0,};

static const EIF_TYPE_INDEX g_atype544_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes544 [] = {
g_atype544_0,
};

static const long offsets544 [] =
{
+ @CHROFF(0,0),
};

extern const char *names545[];
static const uint32 types545 [] =
{
SK_BOOL,
};

static const uint16 attr_flags545 [] =
{0,};

static const EIF_TYPE_INDEX g_atype545_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes545 [] = {
g_atype545_0,
};

static const long offsets545 [] =
{
+ @CHROFF(0,0),
};

extern const char *names546[];
static const uint32 types546 [] =
{
SK_BOOL,
};

static const uint16 attr_flags546 [] =
{0,};

static const EIF_TYPE_INDEX g_atype546_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes546 [] = {
g_atype546_0,
};

static const long offsets546 [] =
{
+ @CHROFF(0,0),
};

extern const char *names547[];
static const uint32 types547 [] =
{
SK_BOOL,
};

static const uint16 attr_flags547 [] =
{0,};

static const EIF_TYPE_INDEX g_atype547_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes547 [] = {
g_atype547_0,
};

static const long offsets547 [] =
{
+ @CHROFF(0,0),
};

extern const char *names548[];
static const uint32 types548 [] =
{
SK_BOOL,
};

static const uint16 attr_flags548 [] =
{0,};

static const EIF_TYPE_INDEX g_atype548_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes548 [] = {
g_atype548_0,
};

static const long offsets548 [] =
{
+ @CHROFF(0,0),
};

extern const char *names549[];
static const uint32 types549 [] =
{
SK_BOOL,
};

static const uint16 attr_flags549 [] =
{0,};

static const EIF_TYPE_INDEX g_atype549_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes549 [] = {
g_atype549_0,
};

static const long offsets549 [] =
{
+ @CHROFF(0,0),
};

extern const char *names550[];
static const uint32 types550 [] =
{
SK_BOOL,
};

static const uint16 attr_flags550 [] =
{0,};

static const EIF_TYPE_INDEX g_atype550_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes550 [] = {
g_atype550_0,
};

static const long offsets550 [] =
{
+ @CHROFF(0,0),
};

extern const char *names551[];
static const uint32 types551 [] =
{
SK_BOOL,
};

static const uint16 attr_flags551 [] =
{0,};

static const EIF_TYPE_INDEX g_atype551_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes551 [] = {
g_atype551_0,
};

static const long offsets551 [] =
{
+ @CHROFF(0,0),
};

extern const char *names552[];
static const uint32 types552 [] =
{
SK_BOOL,
};

static const uint16 attr_flags552 [] =
{0,};

static const EIF_TYPE_INDEX g_atype552_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes552 [] = {
g_atype552_0,
};

static const long offsets552 [] =
{
+ @CHROFF(0,0),
};

extern const char *names553[];
static const uint32 types553 [] =
{
SK_BOOL,
};

static const uint16 attr_flags553 [] =
{0,};

static const EIF_TYPE_INDEX g_atype553_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes553 [] = {
g_atype553_0,
};

static const long offsets553 [] =
{
+ @CHROFF(0,0),
};

extern const char *names554[];
static const uint32 types554 [] =
{
SK_BOOL,
};

static const uint16 attr_flags554 [] =
{0,};

static const EIF_TYPE_INDEX g_atype554_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes554 [] = {
g_atype554_0,
};

static const long offsets554 [] =
{
+ @CHROFF(0,0),
};

extern const char *names555[];
static const uint32 types555 [] =
{
SK_BOOL,
};

static const uint16 attr_flags555 [] =
{0,};

static const EIF_TYPE_INDEX g_atype555_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes555 [] = {
g_atype555_0,
};

static const long offsets555 [] =
{
+ @CHROFF(0,0),
};

extern const char *names556[];
static const uint32 types556 [] =
{
SK_BOOL,
};

static const uint16 attr_flags556 [] =
{0,};

static const EIF_TYPE_INDEX g_atype556_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes556 [] = {
g_atype556_0,
};

static const long offsets556 [] =
{
+ @CHROFF(0,0),
};

extern const char *names557[];
static const uint32 types557 [] =
{
SK_BOOL,
};

static const uint16 attr_flags557 [] =
{0,};

static const EIF_TYPE_INDEX g_atype557_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes557 [] = {
g_atype557_0,
};

static const long offsets557 [] =
{
+ @CHROFF(0,0),
};

extern const char *names558[];
static const uint32 types558 [] =
{
SK_BOOL,
};

static const uint16 attr_flags558 [] =
{0,};

static const EIF_TYPE_INDEX g_atype558_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes558 [] = {
g_atype558_0,
};

static const long offsets558 [] =
{
+ @CHROFF(0,0),
};

extern const char *names559[];
static const uint32 types559 [] =
{
SK_BOOL,
};

static const uint16 attr_flags559 [] =
{0,};

static const EIF_TYPE_INDEX g_atype559_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes559 [] = {
g_atype559_0,
};

static const long offsets559 [] =
{
+ @CHROFF(0,0),
};

extern const char *names560[];
static const uint32 types560 [] =
{
SK_BOOL,
};

static const uint16 attr_flags560 [] =
{0,};

static const EIF_TYPE_INDEX g_atype560_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes560 [] = {
g_atype560_0,
};

static const long offsets560 [] =
{
+ @CHROFF(0,0),
};

extern const char *names561[];
static const uint32 types561 [] =
{
SK_BOOL,
};

static const uint16 attr_flags561 [] =
{0,};

static const EIF_TYPE_INDEX g_atype561_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes561 [] = {
g_atype561_0,
};

static const long offsets561 [] =
{
+ @CHROFF(0,0),
};

extern const char *names562[];
static const uint32 types562 [] =
{
SK_BOOL,
};

static const uint16 attr_flags562 [] =
{0,};

static const EIF_TYPE_INDEX g_atype562_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes562 [] = {
g_atype562_0,
};

static const long offsets562 [] =
{
+ @CHROFF(0,0),
};

extern const char *names563[];
static const uint32 types563 [] =
{
SK_BOOL,
};

static const uint16 attr_flags563 [] =
{0,};

static const EIF_TYPE_INDEX g_atype563_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes563 [] = {
g_atype563_0,
};

static const long offsets563 [] =
{
+ @CHROFF(0,0),
};

extern const char *names564[];
static const uint32 types564 [] =
{
SK_BOOL,
};

static const uint16 attr_flags564 [] =
{0,};

static const EIF_TYPE_INDEX g_atype564_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes564 [] = {
g_atype564_0,
};

static const long offsets564 [] =
{
+ @CHROFF(0,0),
};

extern const char *names565[];
static const uint32 types565 [] =
{
SK_BOOL,
};

static const uint16 attr_flags565 [] =
{0,};

static const EIF_TYPE_INDEX g_atype565_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes565 [] = {
g_atype565_0,
};

static const long offsets565 [] =
{
+ @CHROFF(0,0),
};

extern const char *names566[];
static const uint32 types566 [] =
{
SK_BOOL,
};

static const uint16 attr_flags566 [] =
{0,};

static const EIF_TYPE_INDEX g_atype566_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes566 [] = {
g_atype566_0,
};

static const long offsets566 [] =
{
+ @CHROFF(0,0),
};

extern const char *names567[];
static const uint32 types567 [] =
{
SK_BOOL,
};

static const uint16 attr_flags567 [] =
{0,};

static const EIF_TYPE_INDEX g_atype567_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes567 [] = {
g_atype567_0,
};

static const long offsets567 [] =
{
+ @CHROFF(0,0),
};

extern const char *names568[];
static const uint32 types568 [] =
{
SK_BOOL,
};

static const uint16 attr_flags568 [] =
{0,};

static const EIF_TYPE_INDEX g_atype568_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes568 [] = {
g_atype568_0,
};

static const long offsets568 [] =
{
+ @CHROFF(0,0),
};

extern const char *names569[];
static const uint32 types569 [] =
{
SK_BOOL,
};

static const uint16 attr_flags569 [] =
{0,};

static const EIF_TYPE_INDEX g_atype569_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes569 [] = {
g_atype569_0,
};

static const long offsets569 [] =
{
+ @CHROFF(0,0),
};

extern const char *names570[];
static const uint32 types570 [] =
{
SK_BOOL,
};

static const uint16 attr_flags570 [] =
{0,};

static const EIF_TYPE_INDEX g_atype570_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes570 [] = {
g_atype570_0,
};

static const long offsets570 [] =
{
+ @CHROFF(0,0),
};

extern const char *names571[];
static const uint32 types571 [] =
{
SK_BOOL,
};

static const uint16 attr_flags571 [] =
{0,};

static const EIF_TYPE_INDEX g_atype571_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes571 [] = {
g_atype571_0,
};

static const long offsets571 [] =
{
+ @CHROFF(0,0),
};

extern const char *names572[];
static const uint32 types572 [] =
{
SK_BOOL,
};

static const uint16 attr_flags572 [] =
{0,};

static const EIF_TYPE_INDEX g_atype572_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes572 [] = {
g_atype572_0,
};

static const long offsets572 [] =
{
+ @CHROFF(0,0),
};

extern const char *names573[];
static const uint32 types573 [] =
{
SK_BOOL,
};

static const uint16 attr_flags573 [] =
{0,};

static const EIF_TYPE_INDEX g_atype573_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes573 [] = {
g_atype573_0,
};

static const long offsets573 [] =
{
+ @CHROFF(0,0),
};

extern const char *names574[];
static const uint32 types574 [] =
{
SK_BOOL,
};

static const uint16 attr_flags574 [] =
{0,};

static const EIF_TYPE_INDEX g_atype574_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes574 [] = {
g_atype574_0,
};

static const long offsets574 [] =
{
+ @CHROFF(0,0),
};

extern const char *names575[];
static const uint32 types575 [] =
{
SK_BOOL,
};

static const uint16 attr_flags575 [] =
{0,};

static const EIF_TYPE_INDEX g_atype575_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes575 [] = {
g_atype575_0,
};

static const long offsets575 [] =
{
+ @CHROFF(0,0),
};

extern const char *names576[];
static const uint32 types576 [] =
{
SK_BOOL,
};

static const uint16 attr_flags576 [] =
{0,};

static const EIF_TYPE_INDEX g_atype576_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes576 [] = {
g_atype576_0,
};

static const long offsets576 [] =
{
+ @CHROFF(0,0),
};

extern const char *names577[];
static const uint32 types577 [] =
{
SK_BOOL,
};

static const uint16 attr_flags577 [] =
{0,};

static const EIF_TYPE_INDEX g_atype577_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes577 [] = {
g_atype577_0,
};

static const long offsets577 [] =
{
+ @CHROFF(0,0),
};

extern const char *names578[];
static const uint32 types578 [] =
{
SK_BOOL,
};

static const uint16 attr_flags578 [] =
{0,};

static const EIF_TYPE_INDEX g_atype578_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes578 [] = {
g_atype578_0,
};

static const long offsets578 [] =
{
+ @CHROFF(0,0),
};

extern const char *names579[];
static const uint32 types579 [] =
{
SK_BOOL,
};

static const uint16 attr_flags579 [] =
{0,};

static const EIF_TYPE_INDEX g_atype579_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes579 [] = {
g_atype579_0,
};

static const long offsets579 [] =
{
+ @CHROFF(0,0),
};

extern const char *names580[];
static const uint32 types580 [] =
{
SK_BOOL,
};

static const uint16 attr_flags580 [] =
{0,};

static const EIF_TYPE_INDEX g_atype580_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes580 [] = {
g_atype580_0,
};

static const long offsets580 [] =
{
+ @CHROFF(0,0),
};

extern const char *names581[];
static const uint32 types581 [] =
{
SK_BOOL,
};

static const uint16 attr_flags581 [] =
{0,};

static const EIF_TYPE_INDEX g_atype581_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes581 [] = {
g_atype581_0,
};

static const long offsets581 [] =
{
+ @CHROFF(0,0),
};

extern const char *names582[];
static const uint32 types582 [] =
{
SK_BOOL,
};

static const uint16 attr_flags582 [] =
{0,};

static const EIF_TYPE_INDEX g_atype582_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes582 [] = {
g_atype582_0,
};

static const long offsets582 [] =
{
+ @CHROFF(0,0),
};

extern const char *names583[];
static const uint32 types583 [] =
{
SK_BOOL,
};

static const uint16 attr_flags583 [] =
{0,};

static const EIF_TYPE_INDEX g_atype583_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes583 [] = {
g_atype583_0,
};

static const long offsets583 [] =
{
+ @CHROFF(0,0),
};

extern const char *names584[];
static const uint32 types584 [] =
{
SK_BOOL,
};

static const uint16 attr_flags584 [] =
{0,};

static const EIF_TYPE_INDEX g_atype584_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes584 [] = {
g_atype584_0,
};

static const long offsets584 [] =
{
+ @CHROFF(0,0),
};

extern const char *names585[];
static const uint32 types585 [] =
{
SK_BOOL,
};

static const uint16 attr_flags585 [] =
{0,};

static const EIF_TYPE_INDEX g_atype585_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes585 [] = {
g_atype585_0,
};

static const long offsets585 [] =
{
+ @CHROFF(0,0),
};

extern const char *names586[];
static const uint32 types586 [] =
{
SK_BOOL,
};

static const uint16 attr_flags586 [] =
{0,};

static const EIF_TYPE_INDEX g_atype586_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes586 [] = {
g_atype586_0,
};

static const long offsets586 [] =
{
+ @CHROFF(0,0),
};

extern const char *names587[];
static const uint32 types587 [] =
{
SK_BOOL,
};

static const uint16 attr_flags587 [] =
{0,};

static const EIF_TYPE_INDEX g_atype587_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes587 [] = {
g_atype587_0,
};

static const long offsets587 [] =
{
+ @CHROFF(0,0),
};

extern const char *names588[];
static const uint32 types588 [] =
{
SK_BOOL,
};

static const uint16 attr_flags588 [] =
{0,};

static const EIF_TYPE_INDEX g_atype588_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes588 [] = {
g_atype588_0,
};

static const long offsets588 [] =
{
+ @CHROFF(0,0),
};

extern const char *names589[];
static const uint32 types589 [] =
{
SK_BOOL,
};

static const uint16 attr_flags589 [] =
{0,};

static const EIF_TYPE_INDEX g_atype589_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes589 [] = {
g_atype589_0,
};

static const long offsets589 [] =
{
+ @CHROFF(0,0),
};

extern const char *names590[];
static const uint32 types590 [] =
{
SK_BOOL,
};

static const uint16 attr_flags590 [] =
{0,};

static const EIF_TYPE_INDEX g_atype590_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes590 [] = {
g_atype590_0,
};

static const long offsets590 [] =
{
+ @CHROFF(0,0),
};

extern const char *names591[];
static const uint32 types591 [] =
{
SK_BOOL,
};

static const uint16 attr_flags591 [] =
{0,};

static const EIF_TYPE_INDEX g_atype591_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes591 [] = {
g_atype591_0,
};

static const long offsets591 [] =
{
+ @CHROFF(0,0),
};

extern const char *names592[];
static const uint32 types592 [] =
{
SK_BOOL,
};

static const uint16 attr_flags592 [] =
{0,};

static const EIF_TYPE_INDEX g_atype592_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes592 [] = {
g_atype592_0,
};

static const long offsets592 [] =
{
+ @CHROFF(0,0),
};

extern const char *names593[];
static const uint32 types593 [] =
{
SK_BOOL,
};

static const uint16 attr_flags593 [] =
{0,};

static const EIF_TYPE_INDEX g_atype593_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes593 [] = {
g_atype593_0,
};

static const long offsets593 [] =
{
+ @CHROFF(0,0),
};

extern const char *names594[];
static const uint32 types594 [] =
{
SK_BOOL,
};

static const uint16 attr_flags594 [] =
{0,};

static const EIF_TYPE_INDEX g_atype594_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes594 [] = {
g_atype594_0,
};

static const long offsets594 [] =
{
+ @CHROFF(0,0),
};

extern const char *names595[];
static const uint32 types595 [] =
{
SK_BOOL,
};

static const uint16 attr_flags595 [] =
{0,};

static const EIF_TYPE_INDEX g_atype595_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes595 [] = {
g_atype595_0,
};

static const long offsets595 [] =
{
+ @CHROFF(0,0),
};

extern const char *names596[];
static const uint32 types596 [] =
{
SK_BOOL,
};

static const uint16 attr_flags596 [] =
{0,};

static const EIF_TYPE_INDEX g_atype596_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes596 [] = {
g_atype596_0,
};

static const long offsets596 [] =
{
+ @CHROFF(0,0),
};

extern const char *names597[];
static const uint32 types597 [] =
{
SK_BOOL,
};

static const uint16 attr_flags597 [] =
{0,};

static const EIF_TYPE_INDEX g_atype597_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes597 [] = {
g_atype597_0,
};

static const long offsets597 [] =
{
+ @CHROFF(0,0),
};

extern const char *names598[];
static const uint32 types598 [] =
{
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags598 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype598_0 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype598_1 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes598 [] = {
g_atype598_0,
g_atype598_1,
};

static const long offsets598 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
};

extern const char *names599[];
static const uint32 types599 [] =
{
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags599 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype599_0 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype599_1 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes599 [] = {
g_atype599_0,
g_atype599_1,
};

static const long offsets599 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
};

extern const char *names600[];
static const uint32 types600 [] =
{
SK_BOOL,
};

static const uint16 attr_flags600 [] =
{0,};

static const EIF_TYPE_INDEX g_atype600_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes600 [] = {
g_atype600_0,
};

static const long offsets600 [] =
{
+ @CHROFF(0,0),
};

extern const char *names601[];
static const uint32 types601 [] =
{
SK_BOOL,
};

static const uint16 attr_flags601 [] =
{0,};

static const EIF_TYPE_INDEX g_atype601_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes601 [] = {
g_atype601_0,
};

static const long offsets601 [] =
{
+ @CHROFF(0,0),
};

extern const char *names602[];
static const uint32 types602 [] =
{
SK_BOOL,
};

static const uint16 attr_flags602 [] =
{0,};

static const EIF_TYPE_INDEX g_atype602_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes602 [] = {
g_atype602_0,
};

static const long offsets602 [] =
{
+ @CHROFF(0,0),
};

extern const char *names603[];
static const uint32 types603 [] =
{
SK_BOOL,
};

static const uint16 attr_flags603 [] =
{0,};

static const EIF_TYPE_INDEX g_atype603_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes603 [] = {
g_atype603_0,
};

static const long offsets603 [] =
{
+ @CHROFF(0,0),
};

extern const char *names604[];
static const uint32 types604 [] =
{
SK_BOOL,
};

static const uint16 attr_flags604 [] =
{0,};

static const EIF_TYPE_INDEX g_atype604_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes604 [] = {
g_atype604_0,
};

static const long offsets604 [] =
{
+ @CHROFF(0,0),
};

extern const char *names605[];
static const uint32 types605 [] =
{
SK_BOOL,
};

static const uint16 attr_flags605 [] =
{0,};

static const EIF_TYPE_INDEX g_atype605_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes605 [] = {
g_atype605_0,
};

static const long offsets605 [] =
{
+ @CHROFF(0,0),
};

extern const char *names606[];
static const uint32 types606 [] =
{
SK_BOOL,
};

static const uint16 attr_flags606 [] =
{0,};

static const EIF_TYPE_INDEX g_atype606_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes606 [] = {
g_atype606_0,
};

static const long offsets606 [] =
{
+ @CHROFF(0,0),
};

extern const char *names607[];
static const uint32 types607 [] =
{
SK_BOOL,
};

static const uint16 attr_flags607 [] =
{0,};

static const EIF_TYPE_INDEX g_atype607_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes607 [] = {
g_atype607_0,
};

static const long offsets607 [] =
{
+ @CHROFF(0,0),
};

extern const char *names608[];
static const uint32 types608 [] =
{
SK_BOOL,
};

static const uint16 attr_flags608 [] =
{0,};

static const EIF_TYPE_INDEX g_atype608_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes608 [] = {
g_atype608_0,
};

static const long offsets608 [] =
{
+ @CHROFF(0,0),
};

extern const char *names609[];
static const uint32 types609 [] =
{
SK_BOOL,
};

static const uint16 attr_flags609 [] =
{0,};

static const EIF_TYPE_INDEX g_atype609_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes609 [] = {
g_atype609_0,
};

static const long offsets609 [] =
{
+ @CHROFF(0,0),
};

extern const char *names610[];
static const uint32 types610 [] =
{
SK_BOOL,
};

static const uint16 attr_flags610 [] =
{0,};

static const EIF_TYPE_INDEX g_atype610_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes610 [] = {
g_atype610_0,
};

static const long offsets610 [] =
{
+ @CHROFF(0,0),
};

extern const char *names611[];
static const uint32 types611 [] =
{
SK_BOOL,
};

static const uint16 attr_flags611 [] =
{0,};

static const EIF_TYPE_INDEX g_atype611_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes611 [] = {
g_atype611_0,
};

static const long offsets611 [] =
{
+ @CHROFF(0,0),
};

extern const char *names612[];
static const uint32 types612 [] =
{
SK_BOOL,
};

static const uint16 attr_flags612 [] =
{0,};

static const EIF_TYPE_INDEX g_atype612_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes612 [] = {
g_atype612_0,
};

static const long offsets612 [] =
{
+ @CHROFF(0,0),
};

extern const char *names613[];
static const uint32 types613 [] =
{
SK_BOOL,
};

static const uint16 attr_flags613 [] =
{0,};

static const EIF_TYPE_INDEX g_atype613_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes613 [] = {
g_atype613_0,
};

static const long offsets613 [] =
{
+ @CHROFF(0,0),
};

extern const char *names614[];
static const uint32 types614 [] =
{
SK_BOOL,
};

static const uint16 attr_flags614 [] =
{0,};

static const EIF_TYPE_INDEX g_atype614_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes614 [] = {
g_atype614_0,
};

static const long offsets614 [] =
{
+ @CHROFF(0,0),
};

extern const char *names615[];
static const uint32 types615 [] =
{
SK_BOOL,
};

static const uint16 attr_flags615 [] =
{0,};

static const EIF_TYPE_INDEX g_atype615_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes615 [] = {
g_atype615_0,
};

static const long offsets615 [] =
{
+ @CHROFF(0,0),
};

extern const char *names616[];
static const uint32 types616 [] =
{
SK_BOOL,
};

static const uint16 attr_flags616 [] =
{0,};

static const EIF_TYPE_INDEX g_atype616_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes616 [] = {
g_atype616_0,
};

static const long offsets616 [] =
{
+ @CHROFF(0,0),
};

extern const char *names617[];
static const uint32 types617 [] =
{
SK_BOOL,
};

static const uint16 attr_flags617 [] =
{0,};

static const EIF_TYPE_INDEX g_atype617_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes617 [] = {
g_atype617_0,
};

static const long offsets617 [] =
{
+ @CHROFF(0,0),
};

extern const char *names618[];
static const uint32 types618 [] =
{
SK_BOOL,
};

static const uint16 attr_flags618 [] =
{0,};

static const EIF_TYPE_INDEX g_atype618_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes618 [] = {
g_atype618_0,
};

static const long offsets618 [] =
{
+ @CHROFF(0,0),
};

extern const char *names619[];
static const uint32 types619 [] =
{
SK_BOOL,
};

static const uint16 attr_flags619 [] =
{0,};

static const EIF_TYPE_INDEX g_atype619_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes619 [] = {
g_atype619_0,
};

static const long offsets619 [] =
{
+ @CHROFF(0,0),
};

extern const char *names620[];
static const uint32 types620 [] =
{
SK_BOOL,
};

static const uint16 attr_flags620 [] =
{0,};

static const EIF_TYPE_INDEX g_atype620_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes620 [] = {
g_atype620_0,
};

static const long offsets620 [] =
{
+ @CHROFF(0,0),
};

extern const char *names621[];
static const uint32 types621 [] =
{
SK_BOOL,
};

static const uint16 attr_flags621 [] =
{0,};

static const EIF_TYPE_INDEX g_atype621_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes621 [] = {
g_atype621_0,
};

static const long offsets621 [] =
{
+ @CHROFF(0,0),
};

extern const char *names622[];
static const uint32 types622 [] =
{
SK_BOOL,
};

static const uint16 attr_flags622 [] =
{0,};

static const EIF_TYPE_INDEX g_atype622_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes622 [] = {
g_atype622_0,
};

static const long offsets622 [] =
{
+ @CHROFF(0,0),
};

extern const char *names623[];
static const uint32 types623 [] =
{
SK_BOOL,
};

static const uint16 attr_flags623 [] =
{0,};

static const EIF_TYPE_INDEX g_atype623_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes623 [] = {
g_atype623_0,
};

static const long offsets623 [] =
{
+ @CHROFF(0,0),
};

extern const char *names624[];
static const uint32 types624 [] =
{
SK_BOOL,
};

static const uint16 attr_flags624 [] =
{0,};

static const EIF_TYPE_INDEX g_atype624_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes624 [] = {
g_atype624_0,
};

static const long offsets624 [] =
{
+ @CHROFF(0,0),
};

extern const char *names625[];
static const uint32 types625 [] =
{
SK_BOOL,
};

static const uint16 attr_flags625 [] =
{0,};

static const EIF_TYPE_INDEX g_atype625_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes625 [] = {
g_atype625_0,
};

static const long offsets625 [] =
{
+ @CHROFF(0,0),
};

extern const char *names626[];
static const uint32 types626 [] =
{
SK_BOOL,
};

static const uint16 attr_flags626 [] =
{0,};

static const EIF_TYPE_INDEX g_atype626_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes626 [] = {
g_atype626_0,
};

static const long offsets626 [] =
{
+ @CHROFF(0,0),
};

extern const char *names627[];
static const uint32 types627 [] =
{
SK_BOOL,
};

static const uint16 attr_flags627 [] =
{0,};

static const EIF_TYPE_INDEX g_atype627_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes627 [] = {
g_atype627_0,
};

static const long offsets627 [] =
{
+ @CHROFF(0,0),
};

extern const char *names628[];
static const uint32 types628 [] =
{
SK_BOOL,
};

static const uint16 attr_flags628 [] =
{0,};

static const EIF_TYPE_INDEX g_atype628_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes628 [] = {
g_atype628_0,
};

static const long offsets628 [] =
{
+ @CHROFF(0,0),
};

extern const char *names629[];
static const uint32 types629 [] =
{
SK_BOOL,
};

static const uint16 attr_flags629 [] =
{0,};

static const EIF_TYPE_INDEX g_atype629_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes629 [] = {
g_atype629_0,
};

static const long offsets629 [] =
{
+ @CHROFF(0,0),
};

extern const char *names630[];
static const uint32 types630 [] =
{
SK_BOOL,
};

static const uint16 attr_flags630 [] =
{0,};

static const EIF_TYPE_INDEX g_atype630_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes630 [] = {
g_atype630_0,
};

static const long offsets630 [] =
{
+ @CHROFF(0,0),
};

extern const char *names631[];
static const uint32 types631 [] =
{
SK_BOOL,
};

static const uint16 attr_flags631 [] =
{0,};

static const EIF_TYPE_INDEX g_atype631_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes631 [] = {
g_atype631_0,
};

static const long offsets631 [] =
{
+ @CHROFF(0,0),
};

extern const char *names632[];
static const uint32 types632 [] =
{
SK_BOOL,
};

static const uint16 attr_flags632 [] =
{0,};

static const EIF_TYPE_INDEX g_atype632_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes632 [] = {
g_atype632_0,
};

static const long offsets632 [] =
{
+ @CHROFF(0,0),
};

extern const char *names633[];
static const uint32 types633 [] =
{
SK_BOOL,
};

static const uint16 attr_flags633 [] =
{0,};

static const EIF_TYPE_INDEX g_atype633_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes633 [] = {
g_atype633_0,
};

static const long offsets633 [] =
{
+ @CHROFF(0,0),
};

extern const char *names634[];
static const uint32 types634 [] =
{
SK_BOOL,
};

static const uint16 attr_flags634 [] =
{0,};

static const EIF_TYPE_INDEX g_atype634_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes634 [] = {
g_atype634_0,
};

static const long offsets634 [] =
{
+ @CHROFF(0,0),
};

extern const char *names635[];
static const uint32 types635 [] =
{
SK_BOOL,
};

static const uint16 attr_flags635 [] =
{0,};

static const EIF_TYPE_INDEX g_atype635_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes635 [] = {
g_atype635_0,
};

static const long offsets635 [] =
{
+ @CHROFF(0,0),
};

extern const char *names636[];
static const uint32 types636 [] =
{
SK_BOOL,
};

static const uint16 attr_flags636 [] =
{0,};

static const EIF_TYPE_INDEX g_atype636_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes636 [] = {
g_atype636_0,
};

static const long offsets636 [] =
{
+ @CHROFF(0,0),
};

extern const char *names637[];
static const uint32 types637 [] =
{
SK_BOOL,
};

static const uint16 attr_flags637 [] =
{0,};

static const EIF_TYPE_INDEX g_atype637_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes637 [] = {
g_atype637_0,
};

static const long offsets637 [] =
{
+ @CHROFF(0,0),
};

extern const char *names638[];
static const uint32 types638 [] =
{
SK_BOOL,
};

static const uint16 attr_flags638 [] =
{0,};

static const EIF_TYPE_INDEX g_atype638_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes638 [] = {
g_atype638_0,
};

static const long offsets638 [] =
{
+ @CHROFF(0,0),
};

extern const char *names639[];
static const uint32 types639 [] =
{
SK_BOOL,
};

static const uint16 attr_flags639 [] =
{0,};

static const EIF_TYPE_INDEX g_atype639_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes639 [] = {
g_atype639_0,
};

static const long offsets639 [] =
{
+ @CHROFF(0,0),
};

extern const char *names640[];
static const uint32 types640 [] =
{
SK_BOOL,
};

static const uint16 attr_flags640 [] =
{0,};

static const EIF_TYPE_INDEX g_atype640_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes640 [] = {
g_atype640_0,
};

static const long offsets640 [] =
{
+ @CHROFF(0,0),
};

extern const char *names641[];
static const uint32 types641 [] =
{
SK_BOOL,
};

static const uint16 attr_flags641 [] =
{0,};

static const EIF_TYPE_INDEX g_atype641_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes641 [] = {
g_atype641_0,
};

static const long offsets641 [] =
{
+ @CHROFF(0,0),
};

extern const char *names642[];
static const uint32 types642 [] =
{
SK_BOOL,
};

static const uint16 attr_flags642 [] =
{0,};

static const EIF_TYPE_INDEX g_atype642_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes642 [] = {
g_atype642_0,
};

static const long offsets642 [] =
{
+ @CHROFF(0,0),
};

extern const char *names643[];
static const uint32 types643 [] =
{
SK_BOOL,
};

static const uint16 attr_flags643 [] =
{0,};

static const EIF_TYPE_INDEX g_atype643_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes643 [] = {
g_atype643_0,
};

static const long offsets643 [] =
{
+ @CHROFF(0,0),
};

extern const char *names644[];
static const uint32 types644 [] =
{
SK_BOOL,
};

static const uint16 attr_flags644 [] =
{0,};

static const EIF_TYPE_INDEX g_atype644_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes644 [] = {
g_atype644_0,
};

static const long offsets644 [] =
{
+ @CHROFF(0,0),
};

extern const char *names645[];
static const uint32 types645 [] =
{
SK_BOOL,
};

static const uint16 attr_flags645 [] =
{0,};

static const EIF_TYPE_INDEX g_atype645_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes645 [] = {
g_atype645_0,
};

static const long offsets645 [] =
{
+ @CHROFF(0,0),
};

extern const char *names646[];
static const uint32 types646 [] =
{
SK_BOOL,
};

static const uint16 attr_flags646 [] =
{0,};

static const EIF_TYPE_INDEX g_atype646_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes646 [] = {
g_atype646_0,
};

static const long offsets646 [] =
{
+ @CHROFF(0,0),
};

extern const char *names647[];
static const uint32 types647 [] =
{
SK_BOOL,
};

static const uint16 attr_flags647 [] =
{0,};

static const EIF_TYPE_INDEX g_atype647_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes647 [] = {
g_atype647_0,
};

static const long offsets647 [] =
{
+ @CHROFF(0,0),
};

extern const char *names648[];
static const uint32 types648 [] =
{
SK_BOOL,
};

static const uint16 attr_flags648 [] =
{0,};

static const EIF_TYPE_INDEX g_atype648_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes648 [] = {
g_atype648_0,
};

static const long offsets648 [] =
{
+ @CHROFF(0,0),
};

extern const char *names649[];
static const uint32 types649 [] =
{
SK_BOOL,
};

static const uint16 attr_flags649 [] =
{0,};

static const EIF_TYPE_INDEX g_atype649_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes649 [] = {
g_atype649_0,
};

static const long offsets649 [] =
{
+ @CHROFF(0,0),
};

extern const char *names650[];
static const uint32 types650 [] =
{
SK_BOOL,
};

static const uint16 attr_flags650 [] =
{0,};

static const EIF_TYPE_INDEX g_atype650_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes650 [] = {
g_atype650_0,
};

static const long offsets650 [] =
{
+ @CHROFF(0,0),
};

extern const char *names651[];
static const uint32 types651 [] =
{
SK_BOOL,
};

static const uint16 attr_flags651 [] =
{0,};

static const EIF_TYPE_INDEX g_atype651_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes651 [] = {
g_atype651_0,
};

static const long offsets651 [] =
{
+ @CHROFF(0,0),
};

extern const char *names652[];
static const uint32 types652 [] =
{
SK_BOOL,
};

static const uint16 attr_flags652 [] =
{0,};

static const EIF_TYPE_INDEX g_atype652_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes652 [] = {
g_atype652_0,
};

static const long offsets652 [] =
{
+ @CHROFF(0,0),
};

extern const char *names653[];
static const uint32 types653 [] =
{
SK_BOOL,
};

static const uint16 attr_flags653 [] =
{0,};

static const EIF_TYPE_INDEX g_atype653_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes653 [] = {
g_atype653_0,
};

static const long offsets653 [] =
{
+ @CHROFF(0,0),
};

extern const char *names654[];
static const uint32 types654 [] =
{
SK_BOOL,
};

static const uint16 attr_flags654 [] =
{0,};

static const EIF_TYPE_INDEX g_atype654_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes654 [] = {
g_atype654_0,
};

static const long offsets654 [] =
{
+ @CHROFF(0,0),
};

extern const char *names655[];
static const uint32 types655 [] =
{
SK_BOOL,
};

static const uint16 attr_flags655 [] =
{0,};

static const EIF_TYPE_INDEX g_atype655_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes655 [] = {
g_atype655_0,
};

static const long offsets655 [] =
{
+ @CHROFF(0,0),
};

extern const char *names656[];
static const uint32 types656 [] =
{
SK_BOOL,
};

static const uint16 attr_flags656 [] =
{0,};

static const EIF_TYPE_INDEX g_atype656_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes656 [] = {
g_atype656_0,
};

static const long offsets656 [] =
{
+ @CHROFF(0,0),
};

extern const char *names657[];
static const uint32 types657 [] =
{
SK_BOOL,
};

static const uint16 attr_flags657 [] =
{0,};

static const EIF_TYPE_INDEX g_atype657_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes657 [] = {
g_atype657_0,
};

static const long offsets657 [] =
{
+ @CHROFF(0,0),
};

extern const char *names658[];
static const uint32 types658 [] =
{
SK_BOOL,
};

static const uint16 attr_flags658 [] =
{0,};

static const EIF_TYPE_INDEX g_atype658_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes658 [] = {
g_atype658_0,
};

static const long offsets658 [] =
{
+ @CHROFF(0,0),
};

extern const char *names659[];
static const uint32 types659 [] =
{
SK_BOOL,
};

static const uint16 attr_flags659 [] =
{0,};

static const EIF_TYPE_INDEX g_atype659_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes659 [] = {
g_atype659_0,
};

static const long offsets659 [] =
{
+ @CHROFF(0,0),
};

extern const char *names660[];
static const uint32 types660 [] =
{
SK_BOOL,
};

static const uint16 attr_flags660 [] =
{0,};

static const EIF_TYPE_INDEX g_atype660_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes660 [] = {
g_atype660_0,
};

static const long offsets660 [] =
{
+ @CHROFF(0,0),
};

extern const char *names661[];
static const uint32 types661 [] =
{
SK_BOOL,
};

static const uint16 attr_flags661 [] =
{0,};

static const EIF_TYPE_INDEX g_atype661_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes661 [] = {
g_atype661_0,
};

static const long offsets661 [] =
{
+ @CHROFF(0,0),
};

extern const char *names662[];
static const uint32 types662 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags662 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype662_0 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype662_1 [] = {0xFF01,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype662_2 [] = {220,0xFFFF};
static const EIF_TYPE_INDEX g_atype662_3 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype662_4 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype662_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype662_6 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype662_7 [] = {852,0xFFFF};
static const EIF_TYPE_INDEX g_atype662_8 [] = {840,0xFFFF};
static const EIF_TYPE_INDEX g_atype662_9 [] = {849,0xFFFF};
static const EIF_TYPE_INDEX g_atype662_10 [] = {837,0xFFFF};
static const EIF_TYPE_INDEX g_atype662_11 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype662_12 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype662_13 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype662_14 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype662_15 [] = {855,0xFFFF};
static const EIF_TYPE_INDEX g_atype662_16 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype662_17 [] = {843,0xFFFF};
static const EIF_TYPE_INDEX g_atype662_18 [] = {831,0xFFFF};
static const EIF_TYPE_INDEX g_atype662_19 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes662 [] = {
g_atype662_0,
g_atype662_1,
g_atype662_2,
g_atype662_3,
g_atype662_4,
g_atype662_5,
g_atype662_6,
g_atype662_7,
g_atype662_8,
g_atype662_9,
g_atype662_10,
g_atype662_11,
g_atype662_12,
g_atype662_13,
g_atype662_14,
g_atype662_15,
g_atype662_16,
g_atype662_17,
g_atype662_18,
g_atype662_19,
};

static const long offsets662 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @CHROFF(3,3),
+ @CHROFF(3,4),
+ @CHROFF(3,5),
+ @I16OFF(3,6,0),
+ @I16OFF(3,6,1),
+ @LNGOFF(3,6,2,0),
+ @LNGOFF(3,6,2,1),
+ @LNGOFF(3,6,2,2),
+ @LNGOFF(3,6,2,3),
+ @R32OFF(3,6,2,4,0),
+ @PTROFF(3,6,2,4,1,0),
+ @I64OFF(3,6,2,4,1,1,0),
+ @I64OFF(3,6,2,4,1,1,1),
+ @R64OFF(3,6,2,4,1,1,2,0),
};

extern const char *names663[];
static const uint32 types663 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags663 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype663_0 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype663_1 [] = {0xFF01,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype663_2 [] = {220,0xFFFF};
static const EIF_TYPE_INDEX g_atype663_3 [] = {220,0xFFFF};
static const EIF_TYPE_INDEX g_atype663_4 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype663_5 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype663_6 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype663_7 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype663_8 [] = {852,0xFFFF};
static const EIF_TYPE_INDEX g_atype663_9 [] = {840,0xFFFF};
static const EIF_TYPE_INDEX g_atype663_10 [] = {849,0xFFFF};
static const EIF_TYPE_INDEX g_atype663_11 [] = {837,0xFFFF};
static const EIF_TYPE_INDEX g_atype663_12 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype663_13 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype663_14 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype663_15 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype663_16 [] = {855,0xFFFF};
static const EIF_TYPE_INDEX g_atype663_17 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype663_18 [] = {843,0xFFFF};
static const EIF_TYPE_INDEX g_atype663_19 [] = {831,0xFFFF};
static const EIF_TYPE_INDEX g_atype663_20 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes663 [] = {
g_atype663_0,
g_atype663_1,
g_atype663_2,
g_atype663_3,
g_atype663_4,
g_atype663_5,
g_atype663_6,
g_atype663_7,
g_atype663_8,
g_atype663_9,
g_atype663_10,
g_atype663_11,
g_atype663_12,
g_atype663_13,
g_atype663_14,
g_atype663_15,
g_atype663_16,
g_atype663_17,
g_atype663_18,
g_atype663_19,
g_atype663_20,
};

static const long offsets663 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @I16OFF(4,6,0),
+ @I16OFF(4,6,1),
+ @LNGOFF(4,6,2,0),
+ @LNGOFF(4,6,2,1),
+ @LNGOFF(4,6,2,2),
+ @LNGOFF(4,6,2,3),
+ @R32OFF(4,6,2,4,0),
+ @PTROFF(4,6,2,4,1,0),
+ @I64OFF(4,6,2,4,1,1,0),
+ @I64OFF(4,6,2,4,1,1,1),
+ @R64OFF(4,6,2,4,1,1,2,0),
};

extern const char *names664[];
static const uint32 types664 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags664 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype664_0 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype664_1 [] = {0xFF01,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype664_2 [] = {220,0xFFFF};
static const EIF_TYPE_INDEX g_atype664_3 [] = {0xFF01,911,0xFFFF};
static const EIF_TYPE_INDEX g_atype664_4 [] = {10,0xFFFF};
static const EIF_TYPE_INDEX g_atype664_5 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype664_6 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype664_7 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype664_8 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype664_9 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype664_10 [] = {852,0xFFFF};
static const EIF_TYPE_INDEX g_atype664_11 [] = {840,0xFFFF};
static const EIF_TYPE_INDEX g_atype664_12 [] = {849,0xFFFF};
static const EIF_TYPE_INDEX g_atype664_13 [] = {837,0xFFFF};
static const EIF_TYPE_INDEX g_atype664_14 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype664_15 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype664_16 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype664_17 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype664_18 [] = {855,0xFFFF};
static const EIF_TYPE_INDEX g_atype664_19 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype664_20 [] = {843,0xFFFF};
static const EIF_TYPE_INDEX g_atype664_21 [] = {831,0xFFFF};
static const EIF_TYPE_INDEX g_atype664_22 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes664 [] = {
g_atype664_0,
g_atype664_1,
g_atype664_2,
g_atype664_3,
g_atype664_4,
g_atype664_5,
g_atype664_6,
g_atype664_7,
g_atype664_8,
g_atype664_9,
g_atype664_10,
g_atype664_11,
g_atype664_12,
g_atype664_13,
g_atype664_14,
g_atype664_15,
g_atype664_16,
g_atype664_17,
g_atype664_18,
g_atype664_19,
g_atype664_20,
g_atype664_21,
g_atype664_22,
};

static const long offsets664 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @I16OFF(5,7,0),
+ @I16OFF(5,7,1),
+ @LNGOFF(5,7,2,0),
+ @LNGOFF(5,7,2,1),
+ @LNGOFF(5,7,2,2),
+ @LNGOFF(5,7,2,3),
+ @R32OFF(5,7,2,4,0),
+ @PTROFF(5,7,2,4,1,0),
+ @I64OFF(5,7,2,4,1,1,0),
+ @I64OFF(5,7,2,4,1,1,1),
+ @R64OFF(5,7,2,4,1,1,2,0),
};

extern const char *names689[];
static const uint32 types689 [] =
{
SK_BOOL,
};

static const uint16 attr_flags689 [] =
{0,};

static const EIF_TYPE_INDEX g_atype689_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes689 [] = {
g_atype689_0,
};

static const long offsets689 [] =
{
+ @CHROFF(0,0),
};

extern const char *names690[];
static const uint32 types690 [] =
{
SK_BOOL,
};

static const uint16 attr_flags690 [] =
{0,};

static const EIF_TYPE_INDEX g_atype690_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes690 [] = {
g_atype690_0,
};

static const long offsets690 [] =
{
+ @CHROFF(0,0),
};

extern const char *names691[];
static const uint32 types691 [] =
{
SK_BOOL,
};

static const uint16 attr_flags691 [] =
{0,};

static const EIF_TYPE_INDEX g_atype691_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes691 [] = {
g_atype691_0,
};

static const long offsets691 [] =
{
+ @CHROFF(0,0),
};

extern const char *names692[];
static const uint32 types692 [] =
{
SK_BOOL,
};

static const uint16 attr_flags692 [] =
{0,};

static const EIF_TYPE_INDEX g_atype692_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes692 [] = {
g_atype692_0,
};

static const long offsets692 [] =
{
+ @CHROFF(0,0),
};

extern const char *names693[];
static const uint32 types693 [] =
{
SK_BOOL,
};

static const uint16 attr_flags693 [] =
{0,};

static const EIF_TYPE_INDEX g_atype693_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes693 [] = {
g_atype693_0,
};

static const long offsets693 [] =
{
+ @CHROFF(0,0),
};

extern const char *names694[];
static const uint32 types694 [] =
{
SK_BOOL,
};

static const uint16 attr_flags694 [] =
{0,};

static const EIF_TYPE_INDEX g_atype694_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes694 [] = {
g_atype694_0,
};

static const long offsets694 [] =
{
+ @CHROFF(0,0),
};

extern const char *names695[];
static const uint32 types695 [] =
{
SK_BOOL,
};

static const uint16 attr_flags695 [] =
{0,};

static const EIF_TYPE_INDEX g_atype695_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes695 [] = {
g_atype695_0,
};

static const long offsets695 [] =
{
+ @CHROFF(0,0),
};

extern const char *names696[];
static const uint32 types696 [] =
{
SK_BOOL,
};

static const uint16 attr_flags696 [] =
{0,};

static const EIF_TYPE_INDEX g_atype696_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes696 [] = {
g_atype696_0,
};

static const long offsets696 [] =
{
+ @CHROFF(0,0),
};

extern const char *names697[];
static const uint32 types697 [] =
{
SK_BOOL,
};

static const uint16 attr_flags697 [] =
{0,};

static const EIF_TYPE_INDEX g_atype697_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes697 [] = {
g_atype697_0,
};

static const long offsets697 [] =
{
+ @CHROFF(0,0),
};

extern const char *names698[];
static const uint32 types698 [] =
{
SK_BOOL,
};

static const uint16 attr_flags698 [] =
{0,};

static const EIF_TYPE_INDEX g_atype698_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes698 [] = {
g_atype698_0,
};

static const long offsets698 [] =
{
+ @CHROFF(0,0),
};

extern const char *names699[];
static const uint32 types699 [] =
{
SK_BOOL,
};

static const uint16 attr_flags699 [] =
{0,};

static const EIF_TYPE_INDEX g_atype699_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes699 [] = {
g_atype699_0,
};

static const long offsets699 [] =
{
+ @CHROFF(0,0),
};

extern const char *names700[];
static const uint32 types700 [] =
{
SK_BOOL,
};

static const uint16 attr_flags700 [] =
{0,};

static const EIF_TYPE_INDEX g_atype700_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes700 [] = {
g_atype700_0,
};

static const long offsets700 [] =
{
+ @CHROFF(0,0),
};

extern const char *names701[];
static const uint32 types701 [] =
{
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags701 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype701_0 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype701_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype701_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes701 [] = {
g_atype701_0,
g_atype701_1,
g_atype701_2,
};

static const long offsets701 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
+ @LNGOFF(0,1,0,1),
};

extern const char *names702[];
static const uint32 types702 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags702 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype702_0 [] = {0xFF01,676,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype702_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype702_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype702_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes702 [] = {
g_atype702_0,
g_atype702_1,
g_atype702_2,
g_atype702_3,
};

static const long offsets702 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names703[];
static const uint32 types703 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags703 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype703_0 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype703_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype703_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype703_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes703 [] = {
g_atype703_0,
g_atype703_1,
g_atype703_2,
g_atype703_3,
};

static const long offsets703 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names704[];
static const uint32 types704 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags704 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype704_0 [] = {0xFF01,678,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype704_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype704_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype704_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes704 [] = {
g_atype704_0,
g_atype704_1,
g_atype704_2,
g_atype704_3,
};

static const long offsets704 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names705[];
static const uint32 types705 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags705 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype705_0 [] = {0xFF01,679,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype705_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype705_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype705_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes705 [] = {
g_atype705_0,
g_atype705_1,
g_atype705_2,
g_atype705_3,
};

static const long offsets705 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names706[];
static const uint32 types706 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags706 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype706_0 [] = {0xFF01,680,861,0xFFFF};
static const EIF_TYPE_INDEX g_atype706_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype706_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype706_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes706 [] = {
g_atype706_0,
g_atype706_1,
g_atype706_2,
g_atype706_3,
};

static const long offsets706 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names707[];
static const uint32 types707 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags707 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype707_0 [] = {0xFF01,681,843,0xFFFF};
static const EIF_TYPE_INDEX g_atype707_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype707_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype707_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes707 [] = {
g_atype707_0,
g_atype707_1,
g_atype707_2,
g_atype707_3,
};

static const long offsets707 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names708[];
static const uint32 types708 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags708 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype708_0 [] = {0xFF01,682,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype708_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype708_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype708_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes708 [] = {
g_atype708_0,
g_atype708_1,
g_atype708_2,
g_atype708_3,
};

static const long offsets708 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names709[];
static const uint32 types709 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags709 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype709_0 [] = {0xFF01,683,852,0xFFFF};
static const EIF_TYPE_INDEX g_atype709_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype709_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype709_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes709 [] = {
g_atype709_0,
g_atype709_1,
g_atype709_2,
g_atype709_3,
};

static const long offsets709 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names710[];
static const uint32 types710 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags710 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype710_0 [] = {0xFF01,684,849,0xFFFF};
static const EIF_TYPE_INDEX g_atype710_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype710_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype710_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes710 [] = {
g_atype710_0,
g_atype710_1,
g_atype710_2,
g_atype710_3,
};

static const long offsets710 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names711[];
static const uint32 types711 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags711 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype711_0 [] = {0xFF01,685,855,0xFFFF};
static const EIF_TYPE_INDEX g_atype711_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype711_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype711_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes711 [] = {
g_atype711_0,
g_atype711_1,
g_atype711_2,
g_atype711_3,
};

static const long offsets711 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names712[];
static const uint32 types712 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags712 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype712_0 [] = {0xFF01,686,858,0xFFFF};
static const EIF_TYPE_INDEX g_atype712_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype712_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype712_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes712 [] = {
g_atype712_0,
g_atype712_1,
g_atype712_2,
g_atype712_3,
};

static const long offsets712 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names713[];
static const uint32 types713 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags713 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype713_0 [] = {0xFF01,687,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype713_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype713_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype713_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes713 [] = {
g_atype713_0,
g_atype713_1,
g_atype713_2,
g_atype713_3,
};

static const long offsets713 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names714[];
static const uint32 types714 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags714 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype714_0 [] = {0xFF01,676,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype714_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype714_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype714_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes714 [] = {
g_atype714_0,
g_atype714_1,
g_atype714_2,
g_atype714_3,
};

static const long offsets714 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names715[];
static const uint32 types715 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags715 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype715_0 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype715_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype715_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype715_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes715 [] = {
g_atype715_0,
g_atype715_1,
g_atype715_2,
g_atype715_3,
};

static const long offsets715 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names716[];
static const uint32 types716 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags716 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype716_0 [] = {0xFF01,682,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype716_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype716_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype716_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes716 [] = {
g_atype716_0,
g_atype716_1,
g_atype716_2,
g_atype716_3,
};

static const long offsets716 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names717[];
static const uint32 types717 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags717 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype717_0 [] = {0xFF01,679,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes717 [] = {
g_atype717_0,
g_atype717_1,
g_atype717_2,
g_atype717_3,
};

static const long offsets717 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names718[];
static const uint32 types718 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags718 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype718_0 [] = {0xFF01,687,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes718 [] = {
g_atype718_0,
g_atype718_1,
g_atype718_2,
g_atype718_3,
};

static const long offsets718 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names719[];
static const uint32 types719 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags719 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype719_0 [] = {0xFF01,681,843,0xFFFF};
static const EIF_TYPE_INDEX g_atype719_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype719_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype719_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes719 [] = {
g_atype719_0,
g_atype719_1,
g_atype719_2,
g_atype719_3,
};

static const long offsets719 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names720[];
static const uint32 types720 [] =
{
SK_BOOL,
};

static const uint16 attr_flags720 [] =
{0,};

static const EIF_TYPE_INDEX g_atype720_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes720 [] = {
g_atype720_0,
};

static const long offsets720 [] =
{
+ @CHROFF(0,0),
};

extern const char *names721[];
static const uint32 types721 [] =
{
SK_BOOL,
};

static const uint16 attr_flags721 [] =
{0,};

static const EIF_TYPE_INDEX g_atype721_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes721 [] = {
g_atype721_0,
};

static const long offsets721 [] =
{
+ @CHROFF(0,0),
};

extern const char *names722[];
static const uint32 types722 [] =
{
SK_BOOL,
};

static const uint16 attr_flags722 [] =
{0,};

static const EIF_TYPE_INDEX g_atype722_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes722 [] = {
g_atype722_0,
};

static const long offsets722 [] =
{
+ @CHROFF(0,0),
};

extern const char *names723[];
static const uint32 types723 [] =
{
SK_BOOL,
};

static const uint16 attr_flags723 [] =
{0,};

static const EIF_TYPE_INDEX g_atype723_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes723 [] = {
g_atype723_0,
};

static const long offsets723 [] =
{
+ @CHROFF(0,0),
};

extern const char *names724[];
static const uint32 types724 [] =
{
SK_BOOL,
};

static const uint16 attr_flags724 [] =
{0,};

static const EIF_TYPE_INDEX g_atype724_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes724 [] = {
g_atype724_0,
};

static const long offsets724 [] =
{
+ @CHROFF(0,0),
};

extern const char *names725[];
static const uint32 types725 [] =
{
SK_BOOL,
};

static const uint16 attr_flags725 [] =
{0,};

static const EIF_TYPE_INDEX g_atype725_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes725 [] = {
g_atype725_0,
};

static const long offsets725 [] =
{
+ @CHROFF(0,0),
};

extern const char *names726[];
static const uint32 types726 [] =
{
SK_BOOL,
};

static const uint16 attr_flags726 [] =
{0,};

static const EIF_TYPE_INDEX g_atype726_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes726 [] = {
g_atype726_0,
};

static const long offsets726 [] =
{
+ @CHROFF(0,0),
};

extern const char *names727[];
static const uint32 types727 [] =
{
SK_BOOL,
};

static const uint16 attr_flags727 [] =
{0,};

static const EIF_TYPE_INDEX g_atype727_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes727 [] = {
g_atype727_0,
};

static const long offsets727 [] =
{
+ @CHROFF(0,0),
};

extern const char *names728[];
static const uint32 types728 [] =
{
SK_BOOL,
};

static const uint16 attr_flags728 [] =
{0,};

static const EIF_TYPE_INDEX g_atype728_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes728 [] = {
g_atype728_0,
};

static const long offsets728 [] =
{
+ @CHROFF(0,0),
};

extern const char *names729[];
static const uint32 types729 [] =
{
SK_BOOL,
};

static const uint16 attr_flags729 [] =
{0,};

static const EIF_TYPE_INDEX g_atype729_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes729 [] = {
g_atype729_0,
};

static const long offsets729 [] =
{
+ @CHROFF(0,0),
};

extern const char *names730[];
static const uint32 types730 [] =
{
SK_BOOL,
};

static const uint16 attr_flags730 [] =
{0,};

static const EIF_TYPE_INDEX g_atype730_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes730 [] = {
g_atype730_0,
};

static const long offsets730 [] =
{
+ @CHROFF(0,0),
};

extern const char *names731[];
static const uint32 types731 [] =
{
SK_BOOL,
};

static const uint16 attr_flags731 [] =
{0,};

static const EIF_TYPE_INDEX g_atype731_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes731 [] = {
g_atype731_0,
};

static const long offsets731 [] =
{
+ @CHROFF(0,0),
};

extern const char *names732[];
static const uint32 types732 [] =
{
SK_BOOL,
};

static const uint16 attr_flags732 [] =
{0,};

static const EIF_TYPE_INDEX g_atype732_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes732 [] = {
g_atype732_0,
};

static const long offsets732 [] =
{
+ @CHROFF(0,0),
};

extern const char *names733[];
static const uint32 types733 [] =
{
SK_BOOL,
};

static const uint16 attr_flags733 [] =
{0,};

static const EIF_TYPE_INDEX g_atype733_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes733 [] = {
g_atype733_0,
};

static const long offsets733 [] =
{
+ @CHROFF(0,0),
};

extern const char *names734[];
static const uint32 types734 [] =
{
SK_BOOL,
};

static const uint16 attr_flags734 [] =
{0,};

static const EIF_TYPE_INDEX g_atype734_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes734 [] = {
g_atype734_0,
};

static const long offsets734 [] =
{
+ @CHROFF(0,0),
};

extern const char *names735[];
static const uint32 types735 [] =
{
SK_BOOL,
};

static const uint16 attr_flags735 [] =
{0,};

static const EIF_TYPE_INDEX g_atype735_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes735 [] = {
g_atype735_0,
};

static const long offsets735 [] =
{
+ @CHROFF(0,0),
};

extern const char *names736[];
static const uint32 types736 [] =
{
SK_BOOL,
};

static const uint16 attr_flags736 [] =
{0,};

static const EIF_TYPE_INDEX g_atype736_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes736 [] = {
g_atype736_0,
};

static const long offsets736 [] =
{
+ @CHROFF(0,0),
};

extern const char *names737[];
static const uint32 types737 [] =
{
SK_BOOL,
};

static const uint16 attr_flags737 [] =
{0,};

static const EIF_TYPE_INDEX g_atype737_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes737 [] = {
g_atype737_0,
};

static const long offsets737 [] =
{
+ @CHROFF(0,0),
};

extern const char *names738[];
static const uint32 types738 [] =
{
SK_BOOL,
};

static const uint16 attr_flags738 [] =
{0,};

static const EIF_TYPE_INDEX g_atype738_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes738 [] = {
g_atype738_0,
};

static const long offsets738 [] =
{
+ @CHROFF(0,0),
};

extern const char *names739[];
static const uint32 types739 [] =
{
SK_BOOL,
};

static const uint16 attr_flags739 [] =
{0,};

static const EIF_TYPE_INDEX g_atype739_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes739 [] = {
g_atype739_0,
};

static const long offsets739 [] =
{
+ @CHROFF(0,0),
};

extern const char *names740[];
static const uint32 types740 [] =
{
SK_BOOL,
};

static const uint16 attr_flags740 [] =
{0,};

static const EIF_TYPE_INDEX g_atype740_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes740 [] = {
g_atype740_0,
};

static const long offsets740 [] =
{
+ @CHROFF(0,0),
};

extern const char *names741[];
static const uint32 types741 [] =
{
SK_BOOL,
};

static const uint16 attr_flags741 [] =
{0,};

static const EIF_TYPE_INDEX g_atype741_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes741 [] = {
g_atype741_0,
};

static const long offsets741 [] =
{
+ @CHROFF(0,0),
};

extern const char *names742[];
static const uint32 types742 [] =
{
SK_BOOL,
};

static const uint16 attr_flags742 [] =
{0,};

static const EIF_TYPE_INDEX g_atype742_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes742 [] = {
g_atype742_0,
};

static const long offsets742 [] =
{
+ @CHROFF(0,0),
};

extern const char *names743[];
static const uint32 types743 [] =
{
SK_BOOL,
};

static const uint16 attr_flags743 [] =
{0,};

static const EIF_TYPE_INDEX g_atype743_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes743 [] = {
g_atype743_0,
};

static const long offsets743 [] =
{
+ @CHROFF(0,0),
};

extern const char *names744[];
static const uint32 types744 [] =
{
SK_BOOL,
};

static const uint16 attr_flags744 [] =
{0,};

static const EIF_TYPE_INDEX g_atype744_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes744 [] = {
g_atype744_0,
};

static const long offsets744 [] =
{
+ @CHROFF(0,0),
};

extern const char *names745[];
static const uint32 types745 [] =
{
SK_BOOL,
};

static const uint16 attr_flags745 [] =
{0,};

static const EIF_TYPE_INDEX g_atype745_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes745 [] = {
g_atype745_0,
};

static const long offsets745 [] =
{
+ @CHROFF(0,0),
};

extern const char *names746[];
static const uint32 types746 [] =
{
SK_BOOL,
};

static const uint16 attr_flags746 [] =
{0,};

static const EIF_TYPE_INDEX g_atype746_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes746 [] = {
g_atype746_0,
};

static const long offsets746 [] =
{
+ @CHROFF(0,0),
};

extern const char *names747[];
static const uint32 types747 [] =
{
SK_BOOL,
};

static const uint16 attr_flags747 [] =
{0,};

static const EIF_TYPE_INDEX g_atype747_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes747 [] = {
g_atype747_0,
};

static const long offsets747 [] =
{
+ @CHROFF(0,0),
};

extern const char *names748[];
static const uint32 types748 [] =
{
SK_BOOL,
};

static const uint16 attr_flags748 [] =
{0,};

static const EIF_TYPE_INDEX g_atype748_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes748 [] = {
g_atype748_0,
};

static const long offsets748 [] =
{
+ @CHROFF(0,0),
};

extern const char *names749[];
static const uint32 types749 [] =
{
SK_BOOL,
};

static const uint16 attr_flags749 [] =
{0,};

static const EIF_TYPE_INDEX g_atype749_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes749 [] = {
g_atype749_0,
};

static const long offsets749 [] =
{
+ @CHROFF(0,0),
};

extern const char *names750[];
static const uint32 types750 [] =
{
SK_BOOL,
};

static const uint16 attr_flags750 [] =
{0,};

static const EIF_TYPE_INDEX g_atype750_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes750 [] = {
g_atype750_0,
};

static const long offsets750 [] =
{
+ @CHROFF(0,0),
};

extern const char *names751[];
static const uint32 types751 [] =
{
SK_BOOL,
};

static const uint16 attr_flags751 [] =
{0,};

static const EIF_TYPE_INDEX g_atype751_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes751 [] = {
g_atype751_0,
};

static const long offsets751 [] =
{
+ @CHROFF(0,0),
};

extern const char *names752[];
static const uint32 types752 [] =
{
SK_BOOL,
};

static const uint16 attr_flags752 [] =
{0,};

static const EIF_TYPE_INDEX g_atype752_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes752 [] = {
g_atype752_0,
};

static const long offsets752 [] =
{
+ @CHROFF(0,0),
};

extern const char *names753[];
static const uint32 types753 [] =
{
SK_BOOL,
};

static const uint16 attr_flags753 [] =
{0,};

static const EIF_TYPE_INDEX g_atype753_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes753 [] = {
g_atype753_0,
};

static const long offsets753 [] =
{
+ @CHROFF(0,0),
};

extern const char *names754[];
static const uint32 types754 [] =
{
SK_BOOL,
};

static const uint16 attr_flags754 [] =
{0,};

static const EIF_TYPE_INDEX g_atype754_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes754 [] = {
g_atype754_0,
};

static const long offsets754 [] =
{
+ @CHROFF(0,0),
};

extern const char *names755[];
static const uint32 types755 [] =
{
SK_BOOL,
};

static const uint16 attr_flags755 [] =
{0,};

static const EIF_TYPE_INDEX g_atype755_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes755 [] = {
g_atype755_0,
};

static const long offsets755 [] =
{
+ @CHROFF(0,0),
};

extern const char *names756[];
static const uint32 types756 [] =
{
SK_BOOL,
};

static const uint16 attr_flags756 [] =
{0,};

static const EIF_TYPE_INDEX g_atype756_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes756 [] = {
g_atype756_0,
};

static const long offsets756 [] =
{
+ @CHROFF(0,0),
};

extern const char *names757[];
static const uint32 types757 [] =
{
SK_BOOL,
};

static const uint16 attr_flags757 [] =
{0,};

static const EIF_TYPE_INDEX g_atype757_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes757 [] = {
g_atype757_0,
};

static const long offsets757 [] =
{
+ @CHROFF(0,0),
};

extern const char *names758[];
static const uint32 types758 [] =
{
SK_BOOL,
};

static const uint16 attr_flags758 [] =
{0,};

static const EIF_TYPE_INDEX g_atype758_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes758 [] = {
g_atype758_0,
};

static const long offsets758 [] =
{
+ @CHROFF(0,0),
};

extern const char *names759[];
static const uint32 types759 [] =
{
SK_BOOL,
};

static const uint16 attr_flags759 [] =
{0,};

static const EIF_TYPE_INDEX g_atype759_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes759 [] = {
g_atype759_0,
};

static const long offsets759 [] =
{
+ @CHROFF(0,0),
};

extern const char *names760[];
static const uint32 types760 [] =
{
SK_BOOL,
};

static const uint16 attr_flags760 [] =
{0,};

static const EIF_TYPE_INDEX g_atype760_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes760 [] = {
g_atype760_0,
};

static const long offsets760 [] =
{
+ @CHROFF(0,0),
};

extern const char *names761[];
static const uint32 types761 [] =
{
SK_BOOL,
};

static const uint16 attr_flags761 [] =
{0,};

static const EIF_TYPE_INDEX g_atype761_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes761 [] = {
g_atype761_0,
};

static const long offsets761 [] =
{
+ @CHROFF(0,0),
};

extern const char *names762[];
static const uint32 types762 [] =
{
SK_BOOL,
};

static const uint16 attr_flags762 [] =
{0,};

static const EIF_TYPE_INDEX g_atype762_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes762 [] = {
g_atype762_0,
};

static const long offsets762 [] =
{
+ @CHROFF(0,0),
};

extern const char *names763[];
static const uint32 types763 [] =
{
SK_BOOL,
};

static const uint16 attr_flags763 [] =
{0,};

static const EIF_TYPE_INDEX g_atype763_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes763 [] = {
g_atype763_0,
};

static const long offsets763 [] =
{
+ @CHROFF(0,0),
};

extern const char *names764[];
static const uint32 types764 [] =
{
SK_BOOL,
};

static const uint16 attr_flags764 [] =
{0,};

static const EIF_TYPE_INDEX g_atype764_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes764 [] = {
g_atype764_0,
};

static const long offsets764 [] =
{
+ @CHROFF(0,0),
};

extern const char *names765[];
static const uint32 types765 [] =
{
SK_BOOL,
};

static const uint16 attr_flags765 [] =
{0,};

static const EIF_TYPE_INDEX g_atype765_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes765 [] = {
g_atype765_0,
};

static const long offsets765 [] =
{
+ @CHROFF(0,0),
};

extern const char *names766[];
static const uint32 types766 [] =
{
SK_BOOL,
};

static const uint16 attr_flags766 [] =
{0,};

static const EIF_TYPE_INDEX g_atype766_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes766 [] = {
g_atype766_0,
};

static const long offsets766 [] =
{
+ @CHROFF(0,0),
};

extern const char *names767[];
static const uint32 types767 [] =
{
SK_BOOL,
};

static const uint16 attr_flags767 [] =
{0,};

static const EIF_TYPE_INDEX g_atype767_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes767 [] = {
g_atype767_0,
};

static const long offsets767 [] =
{
+ @CHROFF(0,0),
};

extern const char *names768[];
static const uint32 types768 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags768 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype768_0 [] = {104,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_1 [] = {104,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_2 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_3 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_4 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes768 [] = {
g_atype768_0,
g_atype768_1,
g_atype768_2,
g_atype768_3,
g_atype768_4,
g_atype768_5,
};

static const long offsets768 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names769[];
static const uint32 types769 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags769 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype769_0 [] = {105,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_1 [] = {105,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_2 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_3 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_4 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes769 [] = {
g_atype769_0,
g_atype769_1,
g_atype769_2,
g_atype769_3,
g_atype769_4,
g_atype769_5,
};

static const long offsets769 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names773[];
static const uint32 types773 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags773 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype773_0 [] = {0xFF01,676,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes773 [] = {
g_atype773_0,
g_atype773_1,
g_atype773_2,
g_atype773_3,
};

static const long offsets773 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names774[];
static const uint32 types774 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags774 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype774_0 [] = {0xFF01,676,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes774 [] = {
g_atype774_0,
g_atype774_1,
g_atype774_2,
};

static const long offsets774 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names775[];
static const uint32 types775 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags775 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype775_0 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype775_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype775_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes775 [] = {
g_atype775_0,
g_atype775_1,
g_atype775_2,
};

static const long offsets775 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names776[];
static const uint32 types776 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags776 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype776_0 [] = {0xFF01,678,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype776_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype776_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes776 [] = {
g_atype776_0,
g_atype776_1,
g_atype776_2,
};

static const long offsets776 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names777[];
static const uint32 types777 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags777 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype777_0 [] = {0xFF01,679,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes777 [] = {
g_atype777_0,
g_atype777_1,
g_atype777_2,
};

static const long offsets777 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names778[];
static const uint32 types778 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags778 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype778_0 [] = {0xFF01,680,861,0xFFFF};
static const EIF_TYPE_INDEX g_atype778_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype778_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes778 [] = {
g_atype778_0,
g_atype778_1,
g_atype778_2,
};

static const long offsets778 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names779[];
static const uint32 types779 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags779 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype779_0 [] = {0xFF01,681,843,0xFFFF};
static const EIF_TYPE_INDEX g_atype779_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype779_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes779 [] = {
g_atype779_0,
g_atype779_1,
g_atype779_2,
};

static const long offsets779 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names780[];
static const uint32 types780 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags780 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype780_0 [] = {0xFF01,682,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype780_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype780_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes780 [] = {
g_atype780_0,
g_atype780_1,
g_atype780_2,
};

static const long offsets780 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names781[];
static const uint32 types781 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags781 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype781_0 [] = {0xFF01,683,852,0xFFFF};
static const EIF_TYPE_INDEX g_atype781_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype781_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes781 [] = {
g_atype781_0,
g_atype781_1,
g_atype781_2,
};

static const long offsets781 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names782[];
static const uint32 types782 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags782 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype782_0 [] = {0xFF01,684,849,0xFFFF};
static const EIF_TYPE_INDEX g_atype782_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype782_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes782 [] = {
g_atype782_0,
g_atype782_1,
g_atype782_2,
};

static const long offsets782 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names783[];
static const uint32 types783 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags783 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype783_0 [] = {0xFF01,685,855,0xFFFF};
static const EIF_TYPE_INDEX g_atype783_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype783_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes783 [] = {
g_atype783_0,
g_atype783_1,
g_atype783_2,
};

static const long offsets783 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names784[];
static const uint32 types784 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags784 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype784_0 [] = {0xFF01,686,858,0xFFFF};
static const EIF_TYPE_INDEX g_atype784_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype784_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes784 [] = {
g_atype784_0,
g_atype784_1,
g_atype784_2,
};

static const long offsets784 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names785[];
static const uint32 types785 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags785 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype785_0 [] = {0xFF01,687,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype785_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype785_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes785 [] = {
g_atype785_0,
g_atype785_1,
g_atype785_2,
};

static const long offsets785 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names786[];
static const uint32 types786 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags786 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype786_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_1 [] = {0xFF01,676,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_2 [] = {0xFF01,676,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_3 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_4 [] = {0xFF01,679,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_5 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_6 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_7 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_8 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_9 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_10 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_11 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_12 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_13 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_14 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_15 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_16 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes786 [] = {
g_atype786_0,
g_atype786_1,
g_atype786_2,
g_atype786_3,
g_atype786_4,
g_atype786_5,
g_atype786_6,
g_atype786_7,
g_atype786_8,
g_atype786_9,
g_atype786_10,
g_atype786_11,
g_atype786_12,
g_atype786_13,
g_atype786_14,
g_atype786_15,
g_atype786_16,
};

static const long offsets786 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @LNGOFF(7,3,0,0),
+ @LNGOFF(7,3,0,1),
+ @LNGOFF(7,3,0,2),
+ @LNGOFF(7,3,0,3),
+ @LNGOFF(7,3,0,4),
+ @LNGOFF(7,3,0,5),
+ @LNGOFF(7,3,0,6),
};

extern const char *names787[];
static const uint32 types787 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags787 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype787_0 [] = {0xFF01,678,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_1 [] = {0xFF01,676,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_2 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_3 [] = {0xFF01,679,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_6 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_7 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_10 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_11 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_12 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_13 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_14 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_15 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_16 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes787 [] = {
g_atype787_0,
g_atype787_1,
g_atype787_2,
g_atype787_3,
g_atype787_4,
g_atype787_5,
g_atype787_6,
g_atype787_7,
g_atype787_8,
g_atype787_9,
g_atype787_10,
g_atype787_11,
g_atype787_12,
g_atype787_13,
g_atype787_14,
g_atype787_15,
g_atype787_16,
};

static const long offsets787 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @LNGOFF(5,3,0,0),
+ @LNGOFF(5,3,0,1),
+ @LNGOFF(5,3,0,2),
+ @LNGOFF(5,3,0,3),
+ @LNGOFF(5,3,0,4),
+ @LNGOFF(5,3,0,5),
+ @LNGOFF(5,3,0,6),
+ @PTROFF(5,3,0,7,0,0),
+ @PTROFF(5,3,0,7,0,1),
};

extern const char *names788[];
static const uint32 types788 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags788 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype788_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_1 [] = {0xFF01,676,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_2 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_3 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_4 [] = {0xFF01,679,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_5 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_6 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_7 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_8 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_10 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_11 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_12 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_13 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_14 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_15 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_16 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes788 [] = {
g_atype788_0,
g_atype788_1,
g_atype788_2,
g_atype788_3,
g_atype788_4,
g_atype788_5,
g_atype788_6,
g_atype788_7,
g_atype788_8,
g_atype788_9,
g_atype788_10,
g_atype788_11,
g_atype788_12,
g_atype788_13,
g_atype788_14,
g_atype788_15,
g_atype788_16,
};

static const long offsets788 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @LNGOFF(6,3,0,0),
+ @LNGOFF(6,3,0,1),
+ @LNGOFF(6,3,0,2),
+ @LNGOFF(6,3,0,3),
+ @LNGOFF(6,3,0,4),
+ @LNGOFF(6,3,0,5),
+ @LNGOFF(6,3,0,6),
+ @LNGOFF(6,3,0,7),
};

extern const char *names789[];
static const uint32 types789 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags789 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype789_0 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_1 [] = {0xFF01,676,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_2 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_3 [] = {0xFF01,679,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_6 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_7 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_10 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_11 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_12 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_13 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_14 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_15 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_16 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes789 [] = {
g_atype789_0,
g_atype789_1,
g_atype789_2,
g_atype789_3,
g_atype789_4,
g_atype789_5,
g_atype789_6,
g_atype789_7,
g_atype789_8,
g_atype789_9,
g_atype789_10,
g_atype789_11,
g_atype789_12,
g_atype789_13,
g_atype789_14,
g_atype789_15,
g_atype789_16,
};

static const long offsets789 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @LNGOFF(5,3,0,0),
+ @LNGOFF(5,3,0,1),
+ @LNGOFF(5,3,0,2),
+ @LNGOFF(5,3,0,3),
+ @LNGOFF(5,3,0,4),
+ @LNGOFF(5,3,0,5),
+ @LNGOFF(5,3,0,6),
+ @LNGOFF(5,3,0,7),
+ @LNGOFF(5,3,0,8),
};

extern const char *names790[];
static const uint32 types790 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags790 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype790_0 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_1 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_2 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_3 [] = {0xFF01,679,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_4 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_6 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_10 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_11 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_12 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_13 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_14 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_15 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_16 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes790 [] = {
g_atype790_0,
g_atype790_1,
g_atype790_2,
g_atype790_3,
g_atype790_4,
g_atype790_5,
g_atype790_6,
g_atype790_7,
g_atype790_8,
g_atype790_9,
g_atype790_10,
g_atype790_11,
g_atype790_12,
g_atype790_13,
g_atype790_14,
g_atype790_15,
g_atype790_16,
};

static const long offsets790 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @LNGOFF(4,3,0,3),
+ @LNGOFF(4,3,0,4),
+ @LNGOFF(4,3,0,5),
+ @LNGOFF(4,3,0,6),
+ @LNGOFF(4,3,0,7),
+ @LNGOFF(4,3,0,8),
+ @LNGOFF(4,3,0,9),
};

extern const char *names791[];
static const uint32 types791 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags791 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype791_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_1 [] = {0xFF01,676,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_2 [] = {0xFF01,676,0xFF01,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_3 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_4 [] = {0xFF01,679,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_5 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_7 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_8 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_9 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_10 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_11 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_12 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_13 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_14 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_15 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_16 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_17 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes791 [] = {
g_atype791_0,
g_atype791_1,
g_atype791_2,
g_atype791_3,
g_atype791_4,
g_atype791_5,
g_atype791_6,
g_atype791_7,
g_atype791_8,
g_atype791_9,
g_atype791_10,
g_atype791_11,
g_atype791_12,
g_atype791_13,
g_atype791_14,
g_atype791_15,
g_atype791_16,
g_atype791_17,
};

static const long offsets791 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @LNGOFF(7,4,0,0),
+ @LNGOFF(7,4,0,1),
+ @LNGOFF(7,4,0,2),
+ @LNGOFF(7,4,0,3),
+ @LNGOFF(7,4,0,4),
+ @LNGOFF(7,4,0,5),
+ @LNGOFF(7,4,0,6),
};

extern const char *names792[];
static const uint32 types792 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags792 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype792_0 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_1 [] = {0xFF01,676,0xFF01,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_2 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_3 [] = {0xFF01,679,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_6 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_7 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_8 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_10 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_11 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_12 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_13 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_14 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_15 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_16 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_17 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes792 [] = {
g_atype792_0,
g_atype792_1,
g_atype792_2,
g_atype792_3,
g_atype792_4,
g_atype792_5,
g_atype792_6,
g_atype792_7,
g_atype792_8,
g_atype792_9,
g_atype792_10,
g_atype792_11,
g_atype792_12,
g_atype792_13,
g_atype792_14,
g_atype792_15,
g_atype792_16,
g_atype792_17,
};

static const long offsets792 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @LNGOFF(5,4,0,0),
+ @LNGOFF(5,4,0,1),
+ @LNGOFF(5,4,0,2),
+ @LNGOFF(5,4,0,3),
+ @LNGOFF(5,4,0,4),
+ @LNGOFF(5,4,0,5),
+ @LNGOFF(5,4,0,6),
+ @LNGOFF(5,4,0,7),
+ @LNGOFF(5,4,0,8),
};

extern const char *names793[];
static const uint32 types793 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags793 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype793_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_1 [] = {0xFF01,676,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_2 [] = {0xFF01,676,0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_3 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_4 [] = {0xFF01,679,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_5 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_6 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_7 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_8 [] = {913,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_9 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_10 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_11 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_12 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_13 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_14 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_15 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_16 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_17 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_18 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes793 [] = {
g_atype793_0,
g_atype793_1,
g_atype793_2,
g_atype793_3,
g_atype793_4,
g_atype793_5,
g_atype793_6,
g_atype793_7,
g_atype793_8,
g_atype793_9,
g_atype793_10,
g_atype793_11,
g_atype793_12,
g_atype793_13,
g_atype793_14,
g_atype793_15,
g_atype793_16,
g_atype793_17,
g_atype793_18,
};

static const long offsets793 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
+ @CHROFF(9,1),
+ @CHROFF(9,2),
+ @LNGOFF(9,3,0,0),
+ @LNGOFF(9,3,0,1),
+ @LNGOFF(9,3,0,2),
+ @LNGOFF(9,3,0,3),
+ @LNGOFF(9,3,0,4),
+ @LNGOFF(9,3,0,5),
+ @LNGOFF(9,3,0,6),
};

extern const char *names796[];
static const uint32 types796 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags796 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype796_0 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype796_1 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype796_2 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes796 [] = {
g_atype796_0,
g_atype796_1,
g_atype796_2,
};

static const long offsets796 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
};

extern const char *names797[];
static const uint32 types797 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_UINT64,
SK_UINT64,
SK_UINT64,
SK_UINT64,
};

static const uint16 attr_flags797 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype797_0 [] = {676,681,843,0xFFFF};
static const EIF_TYPE_INDEX g_atype797_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype797_2 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype797_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype797_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype797_5 [] = {843,0xFFFF};
static const EIF_TYPE_INDEX g_atype797_6 [] = {843,0xFFFF};
static const EIF_TYPE_INDEX g_atype797_7 [] = {843,0xFFFF};
static const EIF_TYPE_INDEX g_atype797_8 [] = {843,0xFFFF};

static const EIF_TYPE_INDEX *gtypes797 [] = {
g_atype797_0,
g_atype797_1,
g_atype797_2,
g_atype797_3,
g_atype797_4,
g_atype797_5,
g_atype797_6,
g_atype797_7,
g_atype797_8,
};

static const long offsets797 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @LNGOFF(1,2,0,0),
+ @LNGOFF(1,2,0,1),
+ @I64OFF(1,2,0,2,0,0,0),
+ @I64OFF(1,2,0,2,0,0,1),
+ @I64OFF(1,2,0,2,0,0,2),
+ @I64OFF(1,2,0,2,0,0,3),
};

extern const char *names798[];
static const uint32 types798 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags798 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype798_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype798_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes798 [] = {
g_atype798_0,
g_atype798_1,
};

static const long offsets798 [] =
{
0,
 + @REFACS(1),
};

extern const char *names799[];
static const uint32 types799 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags799 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype799_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype799_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes799 [] = {
g_atype799_0,
g_atype799_1,
};

static const long offsets799 [] =
{
0,
 + @REFACS(1),
};

extern const char *names800[];
static const uint32 types800 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags800 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype800_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype800_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes800 [] = {
g_atype800_0,
g_atype800_1,
};

static const long offsets800 [] =
{
0,
 + @REFACS(1),
};

extern const char *names801[];
static const uint32 types801 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags801 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype801_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype801_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes801 [] = {
g_atype801_0,
g_atype801_1,
};

static const long offsets801 [] =
{
0,
 + @REFACS(1),
};

extern const char *names802[];
static const uint32 types802 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags802 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype802_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype802_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes802 [] = {
g_atype802_0,
g_atype802_1,
};

static const long offsets802 [] =
{
0,
 + @REFACS(1),
};

extern const char *names803[];
static const uint32 types803 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags803 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype803_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype803_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes803 [] = {
g_atype803_0,
g_atype803_1,
};

static const long offsets803 [] =
{
0,
 + @REFACS(1),
};

extern const char *names804[];
static const uint32 types804 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags804 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype804_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes804 [] = {
g_atype804_0,
g_atype804_1,
};

static const long offsets804 [] =
{
0,
 + @REFACS(1),
};

extern const char *names805[];
static const uint32 types805 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags805 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype805_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype805_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes805 [] = {
g_atype805_0,
g_atype805_1,
};

static const long offsets805 [] =
{
0,
 + @REFACS(1),
};

extern const char *names806[];
static const uint32 types806 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags806 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype806_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes806 [] = {
g_atype806_0,
g_atype806_1,
};

static const long offsets806 [] =
{
0,
 + @REFACS(1),
};

extern const char *names807[];
static const uint32 types807 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags807 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype807_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype807_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes807 [] = {
g_atype807_0,
g_atype807_1,
};

static const long offsets807 [] =
{
0,
 + @REFACS(1),
};

extern const char *names808[];
static const uint32 types808 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags808 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype808_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype808_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes808 [] = {
g_atype808_0,
g_atype808_1,
};

static const long offsets808 [] =
{
0,
 + @REFACS(1),
};

extern const char *names809[];
static const uint32 types809 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags809 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype809_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype809_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes809 [] = {
g_atype809_0,
g_atype809_1,
};

static const long offsets809 [] =
{
0,
 + @REFACS(1),
};

extern const char *names810[];
static const uint32 types810 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags810 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype810_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype810_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes810 [] = {
g_atype810_0,
g_atype810_1,
};

static const long offsets810 [] =
{
0,
 + @REFACS(1),
};

extern const char *names811[];
static const uint32 types811 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags811 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype811_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype811_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes811 [] = {
g_atype811_0,
g_atype811_1,
};

static const long offsets811 [] =
{
0,
 + @REFACS(1),
};

extern const char *names812[];
static const uint32 types812 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags812 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype812_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype812_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes812 [] = {
g_atype812_0,
g_atype812_1,
};

static const long offsets812 [] =
{
0,
 + @REFACS(1),
};

extern const char *names813[];
static const uint32 types813 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags813 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype813_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype813_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes813 [] = {
g_atype813_0,
g_atype813_1,
};

static const long offsets813 [] =
{
0,
 + @REFACS(1),
};

extern const char *names814[];
static const uint32 types814 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags814 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype814_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype814_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes814 [] = {
g_atype814_0,
g_atype814_1,
};

static const long offsets814 [] =
{
0,
 + @REFACS(1),
};

extern const char *names815[];
static const uint32 types815 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags815 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype815_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype815_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes815 [] = {
g_atype815_0,
g_atype815_1,
};

static const long offsets815 [] =
{
0,
 + @REFACS(1),
};

extern const char *names816[];
static const uint32 types816 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags816 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype816_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype816_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes816 [] = {
g_atype816_0,
g_atype816_1,
};

static const long offsets816 [] =
{
0,
 + @REFACS(1),
};

extern const char *names817[];
static const uint32 types817 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags817 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype817_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype817_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes817 [] = {
g_atype817_0,
g_atype817_1,
};

static const long offsets817 [] =
{
0,
 + @REFACS(1),
};

extern const char *names818[];
static const uint32 types818 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags818 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype818_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype818_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes818 [] = {
g_atype818_0,
g_atype818_1,
};

static const long offsets818 [] =
{
0,
 + @REFACS(1),
};

extern const char *names819[];
static const uint32 types819 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags819 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype819_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype819_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes819 [] = {
g_atype819_0,
g_atype819_1,
};

static const long offsets819 [] =
{
0,
 + @REFACS(1),
};

extern const char *names820[];
static const uint32 types820 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags820 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype820_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype820_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes820 [] = {
g_atype820_0,
g_atype820_1,
};

static const long offsets820 [] =
{
0,
 + @REFACS(1),
};

extern const char *names821[];
static const uint32 types821 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags821 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype821_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype821_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes821 [] = {
g_atype821_0,
g_atype821_1,
};

static const long offsets821 [] =
{
0,
 + @REFACS(1),
};

extern const char *names822[];
static const uint32 types822 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags822 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype822_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes822 [] = {
g_atype822_0,
g_atype822_1,
};

static const long offsets822 [] =
{
0,
 + @REFACS(1),
};

extern const char *names823[];
static const uint32 types823 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags823 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype823_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes823 [] = {
g_atype823_0,
g_atype823_1,
};

static const long offsets823 [] =
{
0,
 + @REFACS(1),
};

extern const char *names824[];
static const uint32 types824 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags824 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype824_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes824 [] = {
g_atype824_0,
g_atype824_1,
};

static const long offsets824 [] =
{
0,
 + @REFACS(1),
};

extern const char *names825[];
static const uint32 types825 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags825 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype825_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype825_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes825 [] = {
g_atype825_0,
g_atype825_1,
};

static const long offsets825 [] =
{
0,
 + @REFACS(1),
};

extern const char *names826[];
static const uint32 types826 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags826 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype826_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype826_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes826 [] = {
g_atype826_0,
g_atype826_1,
};

static const long offsets826 [] =
{
0,
 + @REFACS(1),
};

extern const char *names827[];
static const uint32 types827 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags827 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype827_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype827_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes827 [] = {
g_atype827_0,
g_atype827_1,
};

static const long offsets827 [] =
{
0,
 + @REFACS(1),
};

extern const char *names828[];
static const uint32 types828 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags828 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype828_0 [] = {910,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_1 [] = {913,0xFFFF};

static const EIF_TYPE_INDEX *gtypes828 [] = {
g_atype828_0,
g_atype828_1,
};

static const long offsets828 [] =
{
0,
 + @REFACS(1),
};

extern const char *names830[];
static const uint32 types830 [] =
{
SK_INT64,
};

static const uint16 attr_flags830 [] =
{0,};

static const EIF_TYPE_INDEX g_atype830_0 [] = {831,0xFFFF};

static const EIF_TYPE_INDEX *gtypes830 [] = {
g_atype830_0,
};

static const long offsets830 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names831[];
static const uint32 types831 [] =
{
SK_INT64,
};

static const uint16 attr_flags831 [] =
{0,};

static const EIF_TYPE_INDEX g_atype831_0 [] = {831,0xFFFF};

static const EIF_TYPE_INDEX *gtypes831 [] = {
g_atype831_0,
};

static const long offsets831 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names832[];
static const uint32 types832 [] =
{
SK_INT64,
};

static const uint16 attr_flags832 [] =
{0,};

static const EIF_TYPE_INDEX g_atype832_0 [] = {831,0xFFFF};

static const EIF_TYPE_INDEX *gtypes832 [] = {
g_atype832_0,
};

static const long offsets832 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names833[];
static const uint32 types833 [] =
{
SK_INT32,
};

static const uint16 attr_flags833 [] =
{0,};

static const EIF_TYPE_INDEX g_atype833_0 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes833 [] = {
g_atype833_0,
};

static const long offsets833 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names834[];
static const uint32 types834 [] =
{
SK_INT32,
};

static const uint16 attr_flags834 [] =
{0,};

static const EIF_TYPE_INDEX g_atype834_0 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes834 [] = {
g_atype834_0,
};

static const long offsets834 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names835[];
static const uint32 types835 [] =
{
SK_INT32,
};

static const uint16 attr_flags835 [] =
{0,};

static const EIF_TYPE_INDEX g_atype835_0 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes835 [] = {
g_atype835_0,
};

static const long offsets835 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names836[];
static const uint32 types836 [] =
{
SK_INT16,
};

static const uint16 attr_flags836 [] =
{0,};

static const EIF_TYPE_INDEX g_atype836_0 [] = {837,0xFFFF};

static const EIF_TYPE_INDEX *gtypes836 [] = {
g_atype836_0,
};

static const long offsets836 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names837[];
static const uint32 types837 [] =
{
SK_INT16,
};

static const uint16 attr_flags837 [] =
{0,};

static const EIF_TYPE_INDEX g_atype837_0 [] = {837,0xFFFF};

static const EIF_TYPE_INDEX *gtypes837 [] = {
g_atype837_0,
};

static const long offsets837 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names838[];
static const uint32 types838 [] =
{
SK_INT16,
};

static const uint16 attr_flags838 [] =
{0,};

static const EIF_TYPE_INDEX g_atype838_0 [] = {837,0xFFFF};

static const EIF_TYPE_INDEX *gtypes838 [] = {
g_atype838_0,
};

static const long offsets838 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names839[];
static const uint32 types839 [] =
{
SK_INT8,
};

static const uint16 attr_flags839 [] =
{0,};

static const EIF_TYPE_INDEX g_atype839_0 [] = {840,0xFFFF};

static const EIF_TYPE_INDEX *gtypes839 [] = {
g_atype839_0,
};

static const long offsets839 [] =
{
+ @CHROFF(0,0),
};

extern const char *names840[];
static const uint32 types840 [] =
{
SK_INT8,
};

static const uint16 attr_flags840 [] =
{0,};

static const EIF_TYPE_INDEX g_atype840_0 [] = {840,0xFFFF};

static const EIF_TYPE_INDEX *gtypes840 [] = {
g_atype840_0,
};

static const long offsets840 [] =
{
+ @CHROFF(0,0),
};

extern const char *names841[];
static const uint32 types841 [] =
{
SK_INT8,
};

static const uint16 attr_flags841 [] =
{0,};

static const EIF_TYPE_INDEX g_atype841_0 [] = {840,0xFFFF};

static const EIF_TYPE_INDEX *gtypes841 [] = {
g_atype841_0,
};

static const long offsets841 [] =
{
+ @CHROFF(0,0),
};

extern const char *names842[];
static const uint32 types842 [] =
{
SK_UINT64,
};

static const uint16 attr_flags842 [] =
{0,};

static const EIF_TYPE_INDEX g_atype842_0 [] = {843,0xFFFF};

static const EIF_TYPE_INDEX *gtypes842 [] = {
g_atype842_0,
};

static const long offsets842 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names843[];
static const uint32 types843 [] =
{
SK_UINT64,
};

static const uint16 attr_flags843 [] =
{0,};

static const EIF_TYPE_INDEX g_atype843_0 [] = {843,0xFFFF};

static const EIF_TYPE_INDEX *gtypes843 [] = {
g_atype843_0,
};

static const long offsets843 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names844[];
static const uint32 types844 [] =
{
SK_UINT64,
};

static const uint16 attr_flags844 [] =
{0,};

static const EIF_TYPE_INDEX g_atype844_0 [] = {843,0xFFFF};

static const EIF_TYPE_INDEX *gtypes844 [] = {
g_atype844_0,
};

static const long offsets844 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names845[];
static const uint32 types845 [] =
{
SK_UINT32,
};

static const uint16 attr_flags845 [] =
{0,};

static const EIF_TYPE_INDEX g_atype845_0 [] = {846,0xFFFF};

static const EIF_TYPE_INDEX *gtypes845 [] = {
g_atype845_0,
};

static const long offsets845 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names846[];
static const uint32 types846 [] =
{
SK_UINT32,
};

static const uint16 attr_flags846 [] =
{0,};

static const EIF_TYPE_INDEX g_atype846_0 [] = {846,0xFFFF};

static const EIF_TYPE_INDEX *gtypes846 [] = {
g_atype846_0,
};

static const long offsets846 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names847[];
static const uint32 types847 [] =
{
SK_UINT32,
};

static const uint16 attr_flags847 [] =
{0,};

static const EIF_TYPE_INDEX g_atype847_0 [] = {846,0xFFFF};

static const EIF_TYPE_INDEX *gtypes847 [] = {
g_atype847_0,
};

static const long offsets847 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names848[];
static const uint32 types848 [] =
{
SK_UINT16,
};

static const uint16 attr_flags848 [] =
{0,};

static const EIF_TYPE_INDEX g_atype848_0 [] = {849,0xFFFF};

static const EIF_TYPE_INDEX *gtypes848 [] = {
g_atype848_0,
};

static const long offsets848 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names849[];
static const uint32 types849 [] =
{
SK_UINT16,
};

static const uint16 attr_flags849 [] =
{0,};

static const EIF_TYPE_INDEX g_atype849_0 [] = {849,0xFFFF};

static const EIF_TYPE_INDEX *gtypes849 [] = {
g_atype849_0,
};

static const long offsets849 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names850[];
static const uint32 types850 [] =
{
SK_UINT16,
};

static const uint16 attr_flags850 [] =
{0,};

static const EIF_TYPE_INDEX g_atype850_0 [] = {849,0xFFFF};

static const EIF_TYPE_INDEX *gtypes850 [] = {
g_atype850_0,
};

static const long offsets850 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names851[];
static const uint32 types851 [] =
{
SK_UINT8,
};

static const uint16 attr_flags851 [] =
{0,};

static const EIF_TYPE_INDEX g_atype851_0 [] = {852,0xFFFF};

static const EIF_TYPE_INDEX *gtypes851 [] = {
g_atype851_0,
};

static const long offsets851 [] =
{
+ @CHROFF(0,0),
};

extern const char *names852[];
static const uint32 types852 [] =
{
SK_UINT8,
};

static const uint16 attr_flags852 [] =
{0,};

static const EIF_TYPE_INDEX g_atype852_0 [] = {852,0xFFFF};

static const EIF_TYPE_INDEX *gtypes852 [] = {
g_atype852_0,
};

static const long offsets852 [] =
{
+ @CHROFF(0,0),
};

extern const char *names853[];
static const uint32 types853 [] =
{
SK_UINT8,
};

static const uint16 attr_flags853 [] =
{0,};

static const EIF_TYPE_INDEX g_atype853_0 [] = {852,0xFFFF};

static const EIF_TYPE_INDEX *gtypes853 [] = {
g_atype853_0,
};

static const long offsets853 [] =
{
+ @CHROFF(0,0),
};

extern const char *names854[];
static const uint32 types854 [] =
{
SK_REAL32,
};

static const uint16 attr_flags854 [] =
{0,};

static const EIF_TYPE_INDEX g_atype854_0 [] = {855,0xFFFF};

static const EIF_TYPE_INDEX *gtypes854 [] = {
g_atype854_0,
};

static const long offsets854 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names855[];
static const uint32 types855 [] =
{
SK_REAL32,
};

static const uint16 attr_flags855 [] =
{0,};

static const EIF_TYPE_INDEX g_atype855_0 [] = {855,0xFFFF};

static const EIF_TYPE_INDEX *gtypes855 [] = {
g_atype855_0,
};

static const long offsets855 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names856[];
static const uint32 types856 [] =
{
SK_REAL32,
};

static const uint16 attr_flags856 [] =
{0,};

static const EIF_TYPE_INDEX g_atype856_0 [] = {855,0xFFFF};

static const EIF_TYPE_INDEX *gtypes856 [] = {
g_atype856_0,
};

static const long offsets856 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names857[];
static const uint32 types857 [] =
{
SK_REAL64,
};

static const uint16 attr_flags857 [] =
{0,};

static const EIF_TYPE_INDEX g_atype857_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes857 [] = {
g_atype857_0,
};

static const long offsets857 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names858[];
static const uint32 types858 [] =
{
SK_REAL64,
};

static const uint16 attr_flags858 [] =
{0,};

static const EIF_TYPE_INDEX g_atype858_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes858 [] = {
g_atype858_0,
};

static const long offsets858 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names859[];
static const uint32 types859 [] =
{
SK_REAL64,
};

static const uint16 attr_flags859 [] =
{0,};

static const EIF_TYPE_INDEX g_atype859_0 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes859 [] = {
g_atype859_0,
};

static const long offsets859 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names860[];
static const uint32 types860 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags860 [] =
{0,};

static const EIF_TYPE_INDEX g_atype860_0 [] = {861,0xFFFF};

static const EIF_TYPE_INDEX *gtypes860 [] = {
g_atype860_0,
};

static const long offsets860 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names861[];
static const uint32 types861 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags861 [] =
{0,};

static const EIF_TYPE_INDEX g_atype861_0 [] = {861,0xFFFF};

static const EIF_TYPE_INDEX *gtypes861 [] = {
g_atype861_0,
};

static const long offsets861 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names862[];
static const uint32 types862 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags862 [] =
{0,};

static const EIF_TYPE_INDEX g_atype862_0 [] = {861,0xFFFF};

static const EIF_TYPE_INDEX *gtypes862 [] = {
g_atype862_0,
};

static const long offsets862 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names863[];
static const uint32 types863 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags863 [] =
{0,};

static const EIF_TYPE_INDEX g_atype863_0 [] = {864,0xFFFF};

static const EIF_TYPE_INDEX *gtypes863 [] = {
g_atype863_0,
};

static const long offsets863 [] =
{
+ @CHROFF(0,0),
};

extern const char *names864[];
static const uint32 types864 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags864 [] =
{0,};

static const EIF_TYPE_INDEX g_atype864_0 [] = {864,0xFFFF};

static const EIF_TYPE_INDEX *gtypes864 [] = {
g_atype864_0,
};

static const long offsets864 [] =
{
+ @CHROFF(0,0),
};

extern const char *names865[];
static const uint32 types865 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags865 [] =
{0,};

static const EIF_TYPE_INDEX g_atype865_0 [] = {864,0xFFFF};

static const EIF_TYPE_INDEX *gtypes865 [] = {
g_atype865_0,
};

static const long offsets865 [] =
{
+ @CHROFF(0,0),
};

extern const char *names866[];
static const uint32 types866 [] =
{
SK_BOOL,
};

static const uint16 attr_flags866 [] =
{0,};

static const EIF_TYPE_INDEX g_atype866_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes866 [] = {
g_atype866_0,
};

static const long offsets866 [] =
{
+ @CHROFF(0,0),
};

extern const char *names867[];
static const uint32 types867 [] =
{
SK_BOOL,
};

static const uint16 attr_flags867 [] =
{0,};

static const EIF_TYPE_INDEX g_atype867_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes867 [] = {
g_atype867_0,
};

static const long offsets867 [] =
{
+ @CHROFF(0,0),
};

extern const char *names868[];
static const uint32 types868 [] =
{
SK_BOOL,
};

static const uint16 attr_flags868 [] =
{0,};

static const EIF_TYPE_INDEX g_atype868_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes868 [] = {
g_atype868_0,
};

static const long offsets868 [] =
{
+ @CHROFF(0,0),
};

extern const char *names869[];
static const uint32 types869 [] =
{
SK_POINTER,
};

static const uint16 attr_flags869 [] =
{0,};

static const EIF_TYPE_INDEX g_atype869_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes869 [] = {
g_atype869_0,
};

static const long offsets869 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names870[];
static const uint32 types870 [] =
{
SK_POINTER,
};

static const uint16 attr_flags870 [] =
{0,};

static const EIF_TYPE_INDEX g_atype870_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes870 [] = {
g_atype870_0,
};

static const long offsets870 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names871[];
static const uint32 types871 [] =
{
SK_POINTER,
};

static const uint16 attr_flags871 [] =
{0,};

static const EIF_TYPE_INDEX g_atype871_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes871 [] = {
g_atype871_0,
};

static const long offsets871 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names872[];
static const uint32 types872 [] =
{
SK_POINTER,
};

static const uint16 attr_flags872 [] =
{0,};

static const EIF_TYPE_INDEX g_atype872_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes872 [] = {
g_atype872_0,
};

static const long offsets872 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names873[];
static const uint32 types873 [] =
{
SK_POINTER,
};

static const uint16 attr_flags873 [] =
{0,};

static const EIF_TYPE_INDEX g_atype873_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes873 [] = {
g_atype873_0,
};

static const long offsets873 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names874[];
static const uint32 types874 [] =
{
SK_POINTER,
};

static const uint16 attr_flags874 [] =
{0,};

static const EIF_TYPE_INDEX g_atype874_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes874 [] = {
g_atype874_0,
};

static const long offsets874 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names875[];
static const uint32 types875 [] =
{
SK_POINTER,
};

static const uint16 attr_flags875 [] =
{0,};

static const EIF_TYPE_INDEX g_atype875_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes875 [] = {
g_atype875_0,
};

static const long offsets875 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names876[];
static const uint32 types876 [] =
{
SK_POINTER,
};

static const uint16 attr_flags876 [] =
{0,};

static const EIF_TYPE_INDEX g_atype876_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes876 [] = {
g_atype876_0,
};

static const long offsets876 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names877[];
static const uint32 types877 [] =
{
SK_POINTER,
};

static const uint16 attr_flags877 [] =
{0,};

static const EIF_TYPE_INDEX g_atype877_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes877 [] = {
g_atype877_0,
};

static const long offsets877 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names878[];
static const uint32 types878 [] =
{
SK_POINTER,
};

static const uint16 attr_flags878 [] =
{0,};

static const EIF_TYPE_INDEX g_atype878_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes878 [] = {
g_atype878_0,
};

static const long offsets878 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names879[];
static const uint32 types879 [] =
{
SK_POINTER,
};

static const uint16 attr_flags879 [] =
{0,};

static const EIF_TYPE_INDEX g_atype879_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes879 [] = {
g_atype879_0,
};

static const long offsets879 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names880[];
static const uint32 types880 [] =
{
SK_POINTER,
};

static const uint16 attr_flags880 [] =
{0,};

static const EIF_TYPE_INDEX g_atype880_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes880 [] = {
g_atype880_0,
};

static const long offsets880 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names881[];
static const uint32 types881 [] =
{
SK_POINTER,
};

static const uint16 attr_flags881 [] =
{0,};

static const EIF_TYPE_INDEX g_atype881_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes881 [] = {
g_atype881_0,
};

static const long offsets881 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names882[];
static const uint32 types882 [] =
{
SK_POINTER,
};

static const uint16 attr_flags882 [] =
{0,};

static const EIF_TYPE_INDEX g_atype882_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes882 [] = {
g_atype882_0,
};

static const long offsets882 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names883[];
static const uint32 types883 [] =
{
SK_POINTER,
};

static const uint16 attr_flags883 [] =
{0,};

static const EIF_TYPE_INDEX g_atype883_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes883 [] = {
g_atype883_0,
};

static const long offsets883 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names884[];
static const uint32 types884 [] =
{
SK_POINTER,
};

static const uint16 attr_flags884 [] =
{0,};

static const EIF_TYPE_INDEX g_atype884_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes884 [] = {
g_atype884_0,
};

static const long offsets884 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names885[];
static const uint32 types885 [] =
{
SK_POINTER,
};

static const uint16 attr_flags885 [] =
{0,};

static const EIF_TYPE_INDEX g_atype885_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes885 [] = {
g_atype885_0,
};

static const long offsets885 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names886[];
static const uint32 types886 [] =
{
SK_POINTER,
};

static const uint16 attr_flags886 [] =
{0,};

static const EIF_TYPE_INDEX g_atype886_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes886 [] = {
g_atype886_0,
};

static const long offsets886 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names887[];
static const uint32 types887 [] =
{
SK_POINTER,
};

static const uint16 attr_flags887 [] =
{0,};

static const EIF_TYPE_INDEX g_atype887_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes887 [] = {
g_atype887_0,
};

static const long offsets887 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names888[];
static const uint32 types888 [] =
{
SK_POINTER,
};

static const uint16 attr_flags888 [] =
{0,};

static const EIF_TYPE_INDEX g_atype888_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes888 [] = {
g_atype888_0,
};

static const long offsets888 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names889[];
static const uint32 types889 [] =
{
SK_POINTER,
};

static const uint16 attr_flags889 [] =
{0,};

static const EIF_TYPE_INDEX g_atype889_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes889 [] = {
g_atype889_0,
};

static const long offsets889 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names890[];
static const uint32 types890 [] =
{
SK_POINTER,
};

static const uint16 attr_flags890 [] =
{0,};

static const EIF_TYPE_INDEX g_atype890_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes890 [] = {
g_atype890_0,
};

static const long offsets890 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names891[];
static const uint32 types891 [] =
{
SK_POINTER,
};

static const uint16 attr_flags891 [] =
{0,};

static const EIF_TYPE_INDEX g_atype891_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes891 [] = {
g_atype891_0,
};

static const long offsets891 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names892[];
static const uint32 types892 [] =
{
SK_POINTER,
};

static const uint16 attr_flags892 [] =
{0,};

static const EIF_TYPE_INDEX g_atype892_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes892 [] = {
g_atype892_0,
};

static const long offsets892 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names893[];
static const uint32 types893 [] =
{
SK_POINTER,
};

static const uint16 attr_flags893 [] =
{0,};

static const EIF_TYPE_INDEX g_atype893_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes893 [] = {
g_atype893_0,
};

static const long offsets893 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names894[];
static const uint32 types894 [] =
{
SK_POINTER,
};

static const uint16 attr_flags894 [] =
{0,};

static const EIF_TYPE_INDEX g_atype894_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes894 [] = {
g_atype894_0,
};

static const long offsets894 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names895[];
static const uint32 types895 [] =
{
SK_POINTER,
};

static const uint16 attr_flags895 [] =
{0,};

static const EIF_TYPE_INDEX g_atype895_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes895 [] = {
g_atype895_0,
};

static const long offsets895 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names896[];
static const uint32 types896 [] =
{
SK_POINTER,
};

static const uint16 attr_flags896 [] =
{0,};

static const EIF_TYPE_INDEX g_atype896_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes896 [] = {
g_atype896_0,
};

static const long offsets896 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names897[];
static const uint32 types897 [] =
{
SK_POINTER,
};

static const uint16 attr_flags897 [] =
{0,};

static const EIF_TYPE_INDEX g_atype897_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes897 [] = {
g_atype897_0,
};

static const long offsets897 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names898[];
static const uint32 types898 [] =
{
SK_POINTER,
};

static const uint16 attr_flags898 [] =
{0,};

static const EIF_TYPE_INDEX g_atype898_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes898 [] = {
g_atype898_0,
};

static const long offsets898 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names899[];
static const uint32 types899 [] =
{
SK_POINTER,
};

static const uint16 attr_flags899 [] =
{0,};

static const EIF_TYPE_INDEX g_atype899_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes899 [] = {
g_atype899_0,
};

static const long offsets899 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names900[];
static const uint32 types900 [] =
{
SK_POINTER,
};

static const uint16 attr_flags900 [] =
{0,};

static const EIF_TYPE_INDEX g_atype900_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes900 [] = {
g_atype900_0,
};

static const long offsets900 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names901[];
static const uint32 types901 [] =
{
SK_POINTER,
};

static const uint16 attr_flags901 [] =
{0,};

static const EIF_TYPE_INDEX g_atype901_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes901 [] = {
g_atype901_0,
};

static const long offsets901 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names902[];
static const uint32 types902 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags902 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype902_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype902_1 [] = {0xFFF9,0,828,0xFFFF};
static const EIF_TYPE_INDEX g_atype902_2 [] = {702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype902_3 [] = {702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype902_4 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype902_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype902_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype902_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype902_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype902_9 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype902_10 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype902_11 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes902 [] = {
g_atype902_0,
g_atype902_1,
g_atype902_2,
g_atype902_3,
g_atype902_4,
g_atype902_5,
g_atype902_6,
g_atype902_7,
g_atype902_8,
g_atype902_9,
g_atype902_10,
g_atype902_11,
};

static const long offsets902 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
+ @LNGOFF(4,2,0,1),
+ @LNGOFF(4,2,0,2),
+ @PTROFF(4,2,0,3,0,0),
+ @PTROFF(4,2,0,3,0,1),
+ @PTROFF(4,2,0,3,0,2),
};

extern const char *names903[];
static const uint32 types903 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags903 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype903_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype903_1 [] = {0xFFF9,0,828,0xFFFF};
static const EIF_TYPE_INDEX g_atype903_2 [] = {702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype903_3 [] = {702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype903_4 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype903_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype903_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype903_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype903_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype903_9 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype903_10 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype903_11 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes903 [] = {
g_atype903_0,
g_atype903_1,
g_atype903_2,
g_atype903_3,
g_atype903_4,
g_atype903_5,
g_atype903_6,
g_atype903_7,
g_atype903_8,
g_atype903_9,
g_atype903_10,
g_atype903_11,
};

static const long offsets903 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
+ @LNGOFF(4,2,0,1),
+ @LNGOFF(4,2,0,2),
+ @PTROFF(4,2,0,3,0,0),
+ @PTROFF(4,2,0,3,0,1),
+ @PTROFF(4,2,0,3,0,2),
};

extern const char *names904[];
static const uint32 types904 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags904 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype904_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype904_1 [] = {0xFFF9,0,828,0xFFFF};
static const EIF_TYPE_INDEX g_atype904_2 [] = {702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype904_3 [] = {702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype904_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype904_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype904_6 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype904_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype904_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype904_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype904_10 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype904_11 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype904_12 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes904 [] = {
g_atype904_0,
g_atype904_1,
g_atype904_2,
g_atype904_3,
g_atype904_4,
g_atype904_5,
g_atype904_6,
g_atype904_7,
g_atype904_8,
g_atype904_9,
g_atype904_10,
g_atype904_11,
g_atype904_12,
};

static const long offsets904 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
+ @LNGOFF(5,2,0,1),
+ @LNGOFF(5,2,0,2),
+ @PTROFF(5,2,0,3,0,0),
+ @PTROFF(5,2,0,3,0,1),
+ @PTROFF(5,2,0,3,0,2),
};

extern const char *names905[];
static const uint32 types905 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags905 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype905_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype905_1 [] = {0xFFF9,0,828,0xFFFF};
static const EIF_TYPE_INDEX g_atype905_2 [] = {702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype905_3 [] = {702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype905_4 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype905_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype905_6 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype905_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype905_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype905_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype905_10 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype905_11 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype905_12 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes905 [] = {
g_atype905_0,
g_atype905_1,
g_atype905_2,
g_atype905_3,
g_atype905_4,
g_atype905_5,
g_atype905_6,
g_atype905_7,
g_atype905_8,
g_atype905_9,
g_atype905_10,
g_atype905_11,
g_atype905_12,
};

static const long offsets905 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @PTROFF(4,3,0,3,0,0),
+ @PTROFF(4,3,0,3,0,1),
+ @PTROFF(4,3,0,3,0,2),
};

extern const char *names906[];
static const uint32 types906 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags906 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype906_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype906_1 [] = {0xFFF9,0,828,0xFFFF};
static const EIF_TYPE_INDEX g_atype906_2 [] = {702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype906_3 [] = {702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype906_4 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype906_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype906_6 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype906_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype906_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype906_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype906_10 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype906_11 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype906_12 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes906 [] = {
g_atype906_0,
g_atype906_1,
g_atype906_2,
g_atype906_3,
g_atype906_4,
g_atype906_5,
g_atype906_6,
g_atype906_7,
g_atype906_8,
g_atype906_9,
g_atype906_10,
g_atype906_11,
g_atype906_12,
};

static const long offsets906 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @PTROFF(4,3,0,3,0,0),
+ @PTROFF(4,3,0,3,0,1),
+ @PTROFF(4,3,0,3,0,2),
};

extern const char *names907[];
static const uint32 types907 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags907 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype907_0 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype907_1 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes907 [] = {
g_atype907_0,
g_atype907_1,
};

static const long offsets907 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names908[];
static const uint32 types908 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags908 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype908_0 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype908_1 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes908 [] = {
g_atype908_0,
g_atype908_1,
};

static const long offsets908 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names909[];
static const uint32 types909 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags909 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype909_0 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype909_1 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes909 [] = {
g_atype909_0,
g_atype909_1,
};

static const long offsets909 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names910[];
static const uint32 types910 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags910 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype910_0 [] = {0xFF01,680,861,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype910_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes910 [] = {
g_atype910_0,
g_atype910_1,
g_atype910_2,
g_atype910_3,
};

static const long offsets910 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names911[];
static const uint32 types911 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags911 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype911_0 [] = {0xFF01,680,861,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype911_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes911 [] = {
g_atype911_0,
g_atype911_1,
g_atype911_2,
g_atype911_3,
g_atype911_4,
};

static const long offsets911 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
};

extern const char *names912[];
static const uint32 types912 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags912 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype912_0 [] = {0xFF01,680,861,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes912 [] = {
g_atype912_0,
g_atype912_1,
g_atype912_2,
g_atype912_3,
g_atype912_4,
};

static const long offsets912 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names913[];
static const uint32 types913 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags913 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype913_0 [] = {0xFF01,682,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype913_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype913_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype913_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes913 [] = {
g_atype913_0,
g_atype913_1,
g_atype913_2,
g_atype913_3,
};

static const long offsets913 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names914[];
static const uint32 types914 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags914 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype914_0 [] = {0xFF01,682,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype914_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes914 [] = {
g_atype914_0,
g_atype914_1,
g_atype914_2,
g_atype914_3,
g_atype914_4,
};

static const long offsets914 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
};

extern const char *names915[];
static const uint32 types915 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags915 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype915_0 [] = {0xFF01,682,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype915_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes915 [] = {
g_atype915_0,
g_atype915_1,
g_atype915_2,
g_atype915_3,
g_atype915_4,
};

static const long offsets915 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names916[];
static const uint32 types916 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags916 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype916_0 [] = {0xFF01,682,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype916_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes916 [] = {
g_atype916_0,
g_atype916_1,
g_atype916_2,
g_atype916_3,
g_atype916_4,
};

static const long offsets916 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names920[];
static const uint32 types920 [] =
{
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags920 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype920_0 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype920_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype920_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes920 [] = {
g_atype920_0,
g_atype920_1,
g_atype920_2,
};

static const long offsets920 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
+ @LNGOFF(0,0,0,2),
};

extern const char *names922[];
static const uint32 types922 [] =
{
SK_INT32,
};

static const uint16 attr_flags922 [] =
{0,};

static const EIF_TYPE_INDEX g_atype922_0 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes922 [] = {
g_atype922_0,
};

static const long offsets922 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names923[];
static const uint32 types923 [] =
{
SK_REF,
};

static const uint16 attr_flags923 [] =
{0,};

static const EIF_TYPE_INDEX g_atype923_0 [] = {0xFF01,1191,0xFFFF};

static const EIF_TYPE_INDEX *gtypes923 [] = {
g_atype923_0,
};

static const long offsets923 [] =
{
0,
};

extern const char *names930[];
static const uint32 types930 [] =
{
SK_REF,
};

static const uint16 attr_flags930 [] =
{0,};

static const EIF_TYPE_INDEX g_atype930_0 [] = {0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes930 [] = {
g_atype930_0,
};

static const long offsets930 [] =
{
0,
};

extern const char *names947[];
static const uint32 types947 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
};

static const uint16 attr_flags947 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype947_0 [] = {82,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_1 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_2 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_3 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes947 [] = {
g_atype947_0,
g_atype947_1,
g_atype947_2,
g_atype947_3,
};

static const long offsets947 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
};

extern const char *names948[];
static const uint32 types948 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags948 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype948_0 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype948_1 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype948_2 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype948_3 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype948_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes948 [] = {
g_atype948_0,
g_atype948_1,
g_atype948_2,
g_atype948_3,
g_atype948_4,
};

static const long offsets948 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
};

extern const char *names952[];
static const uint32 types952 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags952 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype952_0 [] = {0xFF01,687,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype952_1 [] = {0xFF01,1158,0xFF01,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype952_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype952_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes952 [] = {
g_atype952_0,
g_atype952_1,
g_atype952_2,
g_atype952_3,
};

static const long offsets952 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names954[];
static const uint32 types954 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags954 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype954_0 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_1 [] = {0xFF01,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_2 [] = {220,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_3 [] = {0xFF01,911,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_4 [] = {10,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_5 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_6 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_7 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_8 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_9 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_10 [] = {852,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_11 [] = {840,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_12 [] = {849,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_13 [] = {837,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_14 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_15 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_16 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_17 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_18 [] = {855,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_19 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_20 [] = {843,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_21 [] = {831,0xFFFF};
static const EIF_TYPE_INDEX g_atype954_22 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes954 [] = {
g_atype954_0,
g_atype954_1,
g_atype954_2,
g_atype954_3,
g_atype954_4,
g_atype954_5,
g_atype954_6,
g_atype954_7,
g_atype954_8,
g_atype954_9,
g_atype954_10,
g_atype954_11,
g_atype954_12,
g_atype954_13,
g_atype954_14,
g_atype954_15,
g_atype954_16,
g_atype954_17,
g_atype954_18,
g_atype954_19,
g_atype954_20,
g_atype954_21,
g_atype954_22,
};

static const long offsets954 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @I16OFF(5,7,0),
+ @I16OFF(5,7,1),
+ @LNGOFF(5,7,2,0),
+ @LNGOFF(5,7,2,1),
+ @LNGOFF(5,7,2,2),
+ @LNGOFF(5,7,2,3),
+ @R32OFF(5,7,2,4,0),
+ @PTROFF(5,7,2,4,1,0),
+ @I64OFF(5,7,2,4,1,1,0),
+ @I64OFF(5,7,2,4,1,1,1),
+ @R64OFF(5,7,2,4,1,1,2,0),
};

extern const char *names967[];
static const uint32 types967 [] =
{
SK_REF,
SK_CHAR8,
SK_CHAR32,
SK_INT32,
};

static const uint16 attr_flags967 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype967_0 [] = {0xFF01,165,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_1 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_2 [] = {861,0xFFFF};
static const EIF_TYPE_INDEX g_atype967_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes967 [] = {
g_atype967_0,
g_atype967_1,
g_atype967_2,
g_atype967_3,
};

static const long offsets967 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names968[];
static const uint32 types968 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags968 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype968_0 [] = {0xFF01,165,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_1 [] = {0xFF01,92,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_2 [] = {682,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_3 [] = {680,861,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_4 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_5 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_6 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_7 [] = {861,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_10 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_11 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_12 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_13 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_14 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_15 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_16 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_17 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_18 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_19 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_20 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype968_21 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes968 [] = {
g_atype968_0,
g_atype968_1,
g_atype968_2,
g_atype968_3,
g_atype968_4,
g_atype968_5,
g_atype968_6,
g_atype968_7,
g_atype968_8,
g_atype968_9,
g_atype968_10,
g_atype968_11,
g_atype968_12,
g_atype968_13,
g_atype968_14,
g_atype968_15,
g_atype968_16,
g_atype968_17,
g_atype968_18,
g_atype968_19,
g_atype968_20,
g_atype968_21,
};

static const long offsets968 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
+ @LNGOFF(5,2,0,1),
+ @LNGOFF(5,2,0,2),
+ @LNGOFF(5,2,0,3),
+ @LNGOFF(5,2,0,4),
+ @LNGOFF(5,2,0,5),
+ @LNGOFF(5,2,0,6),
+ @LNGOFF(5,2,0,7),
+ @LNGOFF(5,2,0,8),
+ @LNGOFF(5,2,0,9),
+ @LNGOFF(5,2,0,10),
+ @LNGOFF(5,2,0,11),
+ @LNGOFF(5,2,0,12),
+ @LNGOFF(5,2,0,13),
+ @LNGOFF(5,2,0,14),
};

extern const char *names969[];
static const uint32 types969 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags969 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype969_0 [] = {0xFF01,165,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_1 [] = {0xFF01,92,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_2 [] = {682,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_3 [] = {680,861,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_4 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_5 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_6 [] = {677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_7 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_8 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_9 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_10 [] = {861,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_11 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_12 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_13 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_14 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_15 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_16 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_17 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_18 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_19 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_20 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_21 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_22 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_23 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype969_24 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes969 [] = {
g_atype969_0,
g_atype969_1,
g_atype969_2,
g_atype969_3,
g_atype969_4,
g_atype969_5,
g_atype969_6,
g_atype969_7,
g_atype969_8,
g_atype969_9,
g_atype969_10,
g_atype969_11,
g_atype969_12,
g_atype969_13,
g_atype969_14,
g_atype969_15,
g_atype969_16,
g_atype969_17,
g_atype969_18,
g_atype969_19,
g_atype969_20,
g_atype969_21,
g_atype969_22,
g_atype969_23,
g_atype969_24,
};

static const long offsets969 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @CHROFF(8,1),
+ @LNGOFF(8,2,0,0),
+ @LNGOFF(8,2,0,1),
+ @LNGOFF(8,2,0,2),
+ @LNGOFF(8,2,0,3),
+ @LNGOFF(8,2,0,4),
+ @LNGOFF(8,2,0,5),
+ @LNGOFF(8,2,0,6),
+ @LNGOFF(8,2,0,7),
+ @LNGOFF(8,2,0,8),
+ @LNGOFF(8,2,0,9),
+ @LNGOFF(8,2,0,10),
+ @LNGOFF(8,2,0,11),
+ @LNGOFF(8,2,0,12),
+ @LNGOFF(8,2,0,13),
+ @LNGOFF(8,2,0,14),
};

extern const char *names970[];
static const uint32 types970 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags970 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype970_0 [] = {0xFF01,165,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_1 [] = {0xFF01,92,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_2 [] = {682,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_3 [] = {680,861,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_4 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_5 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_6 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_7 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_8 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_9 [] = {677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_10 [] = {677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_11 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_12 [] = {677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_13 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_14 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_15 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_16 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_17 [] = {861,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_18 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_19 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_20 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_21 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_22 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_23 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_24 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_25 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_26 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_27 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_28 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_29 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_30 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_31 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_32 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_33 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_34 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_35 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_36 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype970_37 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes970 [] = {
g_atype970_0,
g_atype970_1,
g_atype970_2,
g_atype970_3,
g_atype970_4,
g_atype970_5,
g_atype970_6,
g_atype970_7,
g_atype970_8,
g_atype970_9,
g_atype970_10,
g_atype970_11,
g_atype970_12,
g_atype970_13,
g_atype970_14,
g_atype970_15,
g_atype970_16,
g_atype970_17,
g_atype970_18,
g_atype970_19,
g_atype970_20,
g_atype970_21,
g_atype970_22,
g_atype970_23,
g_atype970_24,
g_atype970_25,
g_atype970_26,
g_atype970_27,
g_atype970_28,
g_atype970_29,
g_atype970_30,
g_atype970_31,
g_atype970_32,
g_atype970_33,
g_atype970_34,
g_atype970_35,
g_atype970_36,
g_atype970_37,
};

static const long offsets970 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
+ @CHROFF(14,0),
+ @CHROFF(14,1),
+ @CHROFF(14,2),
+ @LNGOFF(14,3,0,0),
+ @LNGOFF(14,3,0,1),
+ @LNGOFF(14,3,0,2),
+ @LNGOFF(14,3,0,3),
+ @LNGOFF(14,3,0,4),
+ @LNGOFF(14,3,0,5),
+ @LNGOFF(14,3,0,6),
+ @LNGOFF(14,3,0,7),
+ @LNGOFF(14,3,0,8),
+ @LNGOFF(14,3,0,9),
+ @LNGOFF(14,3,0,10),
+ @LNGOFF(14,3,0,11),
+ @LNGOFF(14,3,0,12),
+ @LNGOFF(14,3,0,13),
+ @LNGOFF(14,3,0,14),
+ @LNGOFF(14,3,0,15),
+ @LNGOFF(14,3,0,16),
+ @LNGOFF(14,3,0,17),
+ @LNGOFF(14,3,0,18),
+ @LNGOFF(14,3,0,19),
+ @LNGOFF(14,3,0,20),
};

extern const char *names971[];
static const uint32 types971 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags971 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype971_0 [] = {0xFF01,165,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_1 [] = {0xFF01,92,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_2 [] = {682,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_3 [] = {680,861,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_4 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_5 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_6 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_7 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_8 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_9 [] = {677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_10 [] = {677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_11 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_12 [] = {677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_13 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_14 [] = {0xFF01,45,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_15 [] = {0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_16 [] = {0xFF01,1169,0xFF01,796,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_17 [] = {0xFF01,1179,0xFF01,796,0xFF01,911,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_18 [] = {0xFF01,1169,0xFF01,796,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_19 [] = {0xFF01,1179,0xFF01,796,0xFF01,911,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_20 [] = {0xFF01,1179,0xFF01,911,0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_21 [] = {0xFF01,1157,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_22 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_23 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_24 [] = {0xFF01,911,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_25 [] = {0xFF01,796,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_26 [] = {0xFF01,911,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_27 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_28 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_29 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_30 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_31 [] = {861,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_32 [] = {861,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_33 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_34 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_35 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_36 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_37 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_38 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_39 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_40 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_41 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_42 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_43 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_44 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_45 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_46 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_47 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_48 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_49 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_50 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_51 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_52 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_53 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_54 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_55 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_56 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype971_57 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes971 [] = {
g_atype971_0,
g_atype971_1,
g_atype971_2,
g_atype971_3,
g_atype971_4,
g_atype971_5,
g_atype971_6,
g_atype971_7,
g_atype971_8,
g_atype971_9,
g_atype971_10,
g_atype971_11,
g_atype971_12,
g_atype971_13,
g_atype971_14,
g_atype971_15,
g_atype971_16,
g_atype971_17,
g_atype971_18,
g_atype971_19,
g_atype971_20,
g_atype971_21,
g_atype971_22,
g_atype971_23,
g_atype971_24,
g_atype971_25,
g_atype971_26,
g_atype971_27,
g_atype971_28,
g_atype971_29,
g_atype971_30,
g_atype971_31,
g_atype971_32,
g_atype971_33,
g_atype971_34,
g_atype971_35,
g_atype971_36,
g_atype971_37,
g_atype971_38,
g_atype971_39,
g_atype971_40,
g_atype971_41,
g_atype971_42,
g_atype971_43,
g_atype971_44,
g_atype971_45,
g_atype971_46,
g_atype971_47,
g_atype971_48,
g_atype971_49,
g_atype971_50,
g_atype971_51,
g_atype971_52,
g_atype971_53,
g_atype971_54,
g_atype971_55,
g_atype971_56,
g_atype971_57,
};

static const long offsets971 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
+ @CHROFF(27,0),
+ @CHROFF(27,1),
+ @CHROFF(27,2),
+ @CHROFF(27,3),
+ @LNGOFF(27,4,0,0),
+ @LNGOFF(27,4,0,1),
+ @LNGOFF(27,4,0,2),
+ @LNGOFF(27,4,0,3),
+ @LNGOFF(27,4,0,4),
+ @LNGOFF(27,4,0,5),
+ @LNGOFF(27,4,0,6),
+ @LNGOFF(27,4,0,7),
+ @LNGOFF(27,4,0,8),
+ @LNGOFF(27,4,0,9),
+ @LNGOFF(27,4,0,10),
+ @LNGOFF(27,4,0,11),
+ @LNGOFF(27,4,0,12),
+ @LNGOFF(27,4,0,13),
+ @LNGOFF(27,4,0,14),
+ @LNGOFF(27,4,0,15),
+ @LNGOFF(27,4,0,16),
+ @LNGOFF(27,4,0,17),
+ @LNGOFF(27,4,0,18),
+ @LNGOFF(27,4,0,19),
+ @LNGOFF(27,4,0,20),
+ @LNGOFF(27,4,0,21),
+ @LNGOFF(27,4,0,22),
+ @LNGOFF(27,4,0,23),
+ @LNGOFF(27,4,0,24),
+ @LNGOFF(27,4,0,25),
+ @LNGOFF(27,4,0,26),
};

extern const char *names972[];
static const uint32 types972 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags972 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype972_0 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype972_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype972_2 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes972 [] = {
g_atype972_0,
g_atype972_1,
g_atype972_2,
};

static const long offsets972 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names973[];
static const uint32 types973 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags973 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype973_0 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype973_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype973_2 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes973 [] = {
g_atype973_0,
g_atype973_1,
g_atype973_2,
};

static const long offsets973 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names974[];
static const uint32 types974 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags974 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype974_0 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_2 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes974 [] = {
g_atype974_0,
g_atype974_1,
g_atype974_2,
};

static const long offsets974 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names975[];
static const uint32 types975 [] =
{
SK_REF,
};

static const uint16 attr_flags975 [] =
{0,};

static const EIF_TYPE_INDEX g_atype975_0 [] = {974,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes975 [] = {
g_atype975_0,
};

static const long offsets975 [] =
{
0,
};

extern const char *names976[];
static const uint32 types976 [] =
{
SK_REF,
};

static const uint16 attr_flags976 [] =
{0,};

static const EIF_TYPE_INDEX g_atype976_0 [] = {975,834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes976 [] = {
g_atype976_0,
};

static const long offsets976 [] =
{
0,
};

extern const char *names977[];
static const uint32 types977 [] =
{
SK_REF,
};

static const uint16 attr_flags977 [] =
{0,};

static const EIF_TYPE_INDEX g_atype977_0 [] = {976,864,0xFFFF};

static const EIF_TYPE_INDEX *gtypes977 [] = {
g_atype977_0,
};

static const long offsets977 [] =
{
0,
};

extern const char *names978[];
static const uint32 types978 [] =
{
SK_REF,
};

static const uint16 attr_flags978 [] =
{0,};

static const EIF_TYPE_INDEX g_atype978_0 [] = {977,867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes978 [] = {
g_atype978_0,
};

static const long offsets978 [] =
{
0,
};

extern const char *names979[];
static const uint32 types979 [] =
{
SK_REF,
};

static const uint16 attr_flags979 [] =
{0,};

static const EIF_TYPE_INDEX g_atype979_0 [] = {978,843,0xFFFF};

static const EIF_TYPE_INDEX *gtypes979 [] = {
g_atype979_0,
};

static const long offsets979 [] =
{
0,
};

extern const char *names980[];
static const uint32 types980 [] =
{
SK_REF,
};

static const uint16 attr_flags980 [] =
{0,};

static const EIF_TYPE_INDEX g_atype980_0 [] = {979,846,0xFFFF};

static const EIF_TYPE_INDEX *gtypes980 [] = {
g_atype980_0,
};

static const long offsets980 [] =
{
0,
};

extern const char *names981[];
static const uint32 types981 [] =
{
SK_REF,
};

static const uint16 attr_flags981 [] =
{0,};

static const EIF_TYPE_INDEX g_atype981_0 [] = {974,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes981 [] = {
g_atype981_0,
};

static const long offsets981 [] =
{
0,
};

extern const char *names982[];
static const uint32 types982 [] =
{
SK_REF,
};

static const uint16 attr_flags982 [] =
{0,};

static const EIF_TYPE_INDEX g_atype982_0 [] = {975,834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes982 [] = {
g_atype982_0,
};

static const long offsets982 [] =
{
0,
};

extern const char *names983[];
static const uint32 types983 [] =
{
SK_REF,
};

static const uint16 attr_flags983 [] =
{0,};

static const EIF_TYPE_INDEX g_atype983_0 [] = {976,864,0xFFFF};

static const EIF_TYPE_INDEX *gtypes983 [] = {
g_atype983_0,
};

static const long offsets983 [] =
{
0,
};

extern const char *names984[];
static const uint32 types984 [] =
{
SK_REF,
};

static const uint16 attr_flags984 [] =
{0,};

static const EIF_TYPE_INDEX g_atype984_0 [] = {977,867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes984 [] = {
g_atype984_0,
};

static const long offsets984 [] =
{
0,
};

extern const char *names985[];
static const uint32 types985 [] =
{
SK_REF,
};

static const uint16 attr_flags985 [] =
{0,};

static const EIF_TYPE_INDEX g_atype985_0 [] = {974,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes985 [] = {
g_atype985_0,
};

static const long offsets985 [] =
{
0,
};

extern const char *names986[];
static const uint32 types986 [] =
{
SK_REF,
};

static const uint16 attr_flags986 [] =
{0,};

static const EIF_TYPE_INDEX g_atype986_0 [] = {975,834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes986 [] = {
g_atype986_0,
};

static const long offsets986 [] =
{
0,
};

extern const char *names987[];
static const uint32 types987 [] =
{
SK_REF,
};

static const uint16 attr_flags987 [] =
{0,};

static const EIF_TYPE_INDEX g_atype987_0 [] = {976,864,0xFFFF};

static const EIF_TYPE_INDEX *gtypes987 [] = {
g_atype987_0,
};

static const long offsets987 [] =
{
0,
};

extern const char *names988[];
static const uint32 types988 [] =
{
SK_REF,
};

static const uint16 attr_flags988 [] =
{0,};

static const EIF_TYPE_INDEX g_atype988_0 [] = {977,867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes988 [] = {
g_atype988_0,
};

static const long offsets988 [] =
{
0,
};

extern const char *names989[];
static const uint32 types989 [] =
{
SK_REF,
};

static const uint16 attr_flags989 [] =
{0,};

static const EIF_TYPE_INDEX g_atype989_0 [] = {978,843,0xFFFF};

static const EIF_TYPE_INDEX *gtypes989 [] = {
g_atype989_0,
};

static const long offsets989 [] =
{
0,
};

extern const char *names990[];
static const uint32 types990 [] =
{
SK_REF,
};

static const uint16 attr_flags990 [] =
{0,};

static const EIF_TYPE_INDEX g_atype990_0 [] = {989,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes990 [] = {
g_atype990_0,
};

static const long offsets990 [] =
{
0,
};

extern const char *names991[];
static const uint32 types991 [] =
{
SK_REF,
};

static const uint16 attr_flags991 [] =
{0,};

static const EIF_TYPE_INDEX g_atype991_0 [] = {990,834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes991 [] = {
g_atype991_0,
};

static const long offsets991 [] =
{
0,
};

extern const char *names992[];
static const uint32 types992 [] =
{
SK_REF,
};

static const uint16 attr_flags992 [] =
{0,};

static const EIF_TYPE_INDEX g_atype992_0 [] = {991,864,0xFFFF};

static const EIF_TYPE_INDEX *gtypes992 [] = {
g_atype992_0,
};

static const long offsets992 [] =
{
0,
};

extern const char *names993[];
static const uint32 types993 [] =
{
SK_REF,
};

static const uint16 attr_flags993 [] =
{0,};

static const EIF_TYPE_INDEX g_atype993_0 [] = {992,867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes993 [] = {
g_atype993_0,
};

static const long offsets993 [] =
{
0,
};

extern const char *names994[];
static const uint32 types994 [] =
{
SK_REF,
};

static const uint16 attr_flags994 [] =
{0,};

static const EIF_TYPE_INDEX g_atype994_0 [] = {993,843,0xFFFF};

static const EIF_TYPE_INDEX *gtypes994 [] = {
g_atype994_0,
};

static const long offsets994 [] =
{
0,
};

extern const char *names995[];
static const uint32 types995 [] =
{
SK_REF,
};

static const uint16 attr_flags995 [] =
{0,};

static const EIF_TYPE_INDEX g_atype995_0 [] = {994,846,0xFFFF};

static const EIF_TYPE_INDEX *gtypes995 [] = {
g_atype995_0,
};

static const long offsets995 [] =
{
0,
};

extern const char *names996[];
static const uint32 types996 [] =
{
SK_REF,
};

static const uint16 attr_flags996 [] =
{0,};

static const EIF_TYPE_INDEX g_atype996_0 [] = {995,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes996 [] = {
g_atype996_0,
};

static const long offsets996 [] =
{
0,
};

extern const char *names997[];
static const uint32 types997 [] =
{
SK_REF,
};

static const uint16 attr_flags997 [] =
{0,};

static const EIF_TYPE_INDEX g_atype997_0 [] = {996,834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes997 [] = {
g_atype997_0,
};

static const long offsets997 [] =
{
0,
};

extern const char *names998[];
static const uint32 types998 [] =
{
SK_REF,
};

static const uint16 attr_flags998 [] =
{0,};

static const EIF_TYPE_INDEX g_atype998_0 [] = {997,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes998 [] = {
g_atype998_0,
};

static const long offsets998 [] =
{
0,
};

extern const char *names999[];
static const uint32 types999 [] =
{
SK_REF,
};

static const uint16 attr_flags999 [] =
{0,};

static const EIF_TYPE_INDEX g_atype999_0 [] = {998,834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes999 [] = {
g_atype999_0,
};

static const long offsets999 [] =
{
0,
};

extern const char *names1000[];
static const uint32 types1000 [] =
{
SK_REF,
};

static const uint16 attr_flags1000 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1000_0 [] = {999,864,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1000 [] = {
g_atype1000_0,
};

static const long offsets1000 [] =
{
0,
};

extern const char *names1001[];
static const uint32 types1001 [] =
{
SK_REF,
};

static const uint16 attr_flags1001 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1001_0 [] = {1000,867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1001 [] = {
g_atype1001_0,
};

static const long offsets1001 [] =
{
0,
};

extern const char *names1002[];
static const uint32 types1002 [] =
{
SK_REF,
};

static const uint16 attr_flags1002 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1002_0 [] = {1001,843,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1002 [] = {
g_atype1002_0,
};

static const long offsets1002 [] =
{
0,
};

extern const char *names1003[];
static const uint32 types1003 [] =
{
SK_REF,
};

static const uint16 attr_flags1003 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1003_0 [] = {1002,846,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1003 [] = {
g_atype1003_0,
};

static const long offsets1003 [] =
{
0,
};

extern const char *names1004[];
static const uint32 types1004 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1004 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1004_0 [] = {1003,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1004_1 [] = {0xFFF5,2,0xFF01,1118,0xFFF8,1,0xFFF8,2,5655,5603,0xFFFF};
static const EIF_TYPE_INDEX g_atype1004_2 [] = {0xFF01,1118,0xFFF8,1,0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1004 [] = {
g_atype1004_0,
g_atype1004_1,
g_atype1004_2,
};

static const long offsets1004 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1005[];
static const uint32 types1005 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1005 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1005_0 [] = {1004,0xFFF8,1,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1005_1 [] = {0xFFF5,2,0xFF01,1119,0xFFF8,1,834,5655,5603,0xFFFF};
static const EIF_TYPE_INDEX g_atype1005_2 [] = {0xFF01,1119,0xFFF8,1,834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1005 [] = {
g_atype1005_0,
g_atype1005_1,
g_atype1005_2,
};

static const long offsets1005 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1006[];
static const uint32 types1006 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1006 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1006_0 [] = {1005,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1006_1 [] = {0xFF01,1023,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1006_2 [] = {0xFF01,1120,834,834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1006 [] = {
g_atype1006_0,
g_atype1006_1,
g_atype1006_2,
};

static const long offsets1006 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1007[];
static const uint32 types1007 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1007 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1007_0 [] = {1006,843,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1007_1 [] = {0xFF01,1024,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1007_2 [] = {0xFF01,1121,843,846,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1007 [] = {
g_atype1007_0,
g_atype1007_1,
g_atype1007_2,
};

static const long offsets1007 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1008[];
static const uint32 types1008 [] =
{
SK_REF,
};

static const uint16 attr_flags1008 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1008_0 [] = {1007,0xFFF8,1,0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1008 [] = {
g_atype1008_0,
};

static const long offsets1008 [] =
{
0,
};

extern const char *names1009[];
static const uint32 types1009 [] =
{
SK_REF,
};

static const uint16 attr_flags1009 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1009_0 [] = {1008,0xFFF8,1,834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1009 [] = {
g_atype1009_0,
};

static const long offsets1009 [] =
{
0,
};

extern const char *names1010[];
static const uint32 types1010 [] =
{
SK_REF,
};

static const uint16 attr_flags1010 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1010_0 [] = {1009,834,834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1010 [] = {
g_atype1010_0,
};

static const long offsets1010 [] =
{
0,
};

extern const char *names1011[];
static const uint32 types1011 [] =
{
SK_REF,
};

static const uint16 attr_flags1011 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1011_0 [] = {1010,843,846,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1011 [] = {
g_atype1011_0,
};

static const long offsets1011 [] =
{
0,
};

extern const char *names1012[];
static const uint32 types1012 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1012 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1012_0 [] = {1011,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1012_1 [] = {0xFF01,1161,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1012_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1012 [] = {
g_atype1012_0,
g_atype1012_1,
g_atype1012_2,
};

static const long offsets1012 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1013[];
static const uint32 types1013 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1013 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1013_0 [] = {1012,0xFFF8,1,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1013_1 [] = {0xFF01,1162,0xFFF8,1,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1013_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1013 [] = {
g_atype1013_0,
g_atype1013_1,
g_atype1013_2,
};

static const long offsets1013 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1014[];
static const uint32 types1014 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1014 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1014_0 [] = {1013,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1014_1 [] = {0xFF01,1163,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1014_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1014 [] = {
g_atype1014_0,
g_atype1014_1,
g_atype1014_2,
};

static const long offsets1014 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1015[];
static const uint32 types1015 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1015 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1015_0 [] = {1014,843,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1015_1 [] = {0xFF01,1164,843,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1015_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1015 [] = {
g_atype1015_0,
g_atype1015_1,
g_atype1015_2,
};

static const long offsets1015 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1016[];
static const uint32 types1016 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1016 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1016_0 [] = {1015,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_1 [] = {0xFF01,1165,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1016 [] = {
g_atype1016_0,
g_atype1016_1,
g_atype1016_2,
};

static const long offsets1016 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1017[];
static const uint32 types1017 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1017 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1017_0 [] = {1016,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_1 [] = {0xFF01,1166,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1017 [] = {
g_atype1017_0,
g_atype1017_1,
g_atype1017_2,
};

static const long offsets1017 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1018[];
static const uint32 types1018 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1018 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1018_0 [] = {1017,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_1 [] = {0xFF01,1167,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1018 [] = {
g_atype1018_0,
g_atype1018_1,
g_atype1018_2,
};

static const long offsets1018 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1019[];
static const uint32 types1019 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1019 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1019_0 [] = {1018,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_1 [] = {0xFF01,1168,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1019 [] = {
g_atype1019_0,
g_atype1019_1,
g_atype1019_2,
};

static const long offsets1019 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1020[];
static const uint32 types1020 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1020 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1020_0 [] = {1019,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1020_1 [] = {0xFF01,1169,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1020_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1020 [] = {
g_atype1020_0,
g_atype1020_1,
g_atype1020_2,
};

static const long offsets1020 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1021[];
static const uint32 types1021 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1021 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1021_0 [] = {1020,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1021_1 [] = {0xFF01,1170,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1021_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1021 [] = {
g_atype1021_0,
g_atype1021_1,
g_atype1021_2,
};

static const long offsets1021 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1022[];
static const uint32 types1022 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1022 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1022_0 [] = {1021,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1022_1 [] = {0xFF01,1171,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1022_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1022 [] = {
g_atype1022_0,
g_atype1022_1,
g_atype1022_2,
};

static const long offsets1022 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1023[];
static const uint32 types1023 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1023 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1023_0 [] = {1022,0xFFF8,1,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1023_1 [] = {0xFF01,1172,0xFFF8,1,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1023_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1023 [] = {
g_atype1023_0,
g_atype1023_1,
g_atype1023_2,
};

static const long offsets1023 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1024[];
static const uint32 types1024 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1024 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1024_0 [] = {1023,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1024_1 [] = {0xFF01,1173,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1024_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1024 [] = {
g_atype1024_0,
g_atype1024_1,
g_atype1024_2,
};

static const long offsets1024 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1025[];
static const uint32 types1025 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1025 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1025_0 [] = {1024,843,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1025_1 [] = {0xFF01,1174,843,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1025_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1025 [] = {
g_atype1025_0,
g_atype1025_1,
g_atype1025_2,
};

static const long offsets1025 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1026[];
static const uint32 types1026 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1026 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1026_0 [] = {1025,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1026_1 [] = {0xFF01,1175,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1026_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1026 [] = {
g_atype1026_0,
g_atype1026_1,
g_atype1026_2,
};

static const long offsets1026 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1027[];
static const uint32 types1027 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1027 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1027_0 [] = {1026,0xFFF8,1,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1027_1 [] = {0xFF01,1176,0xFFF8,1,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1027_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1027 [] = {
g_atype1027_0,
g_atype1027_1,
g_atype1027_2,
};

static const long offsets1027 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1028[];
static const uint32 types1028 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1028 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1028_0 [] = {1027,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1028_1 [] = {0xFF01,1177,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1028_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1028 [] = {
g_atype1028_0,
g_atype1028_1,
g_atype1028_2,
};

static const long offsets1028 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1029[];
static const uint32 types1029 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1029 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1029_0 [] = {1028,843,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1029_1 [] = {0xFF01,1178,843,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1029_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1029 [] = {
g_atype1029_0,
g_atype1029_1,
g_atype1029_2,
};

static const long offsets1029 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1030[];
static const uint32 types1030 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1030 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1030_0 [] = {1029,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1030_1 [] = {0xFF01,1179,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1030_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1030 [] = {
g_atype1030_0,
g_atype1030_1,
g_atype1030_2,
};

static const long offsets1030 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1031[];
static const uint32 types1031 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1031 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1031_0 [] = {1030,0xFFF8,1,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1031_1 [] = {0xFF01,1180,0xFFF8,1,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1031_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1031 [] = {
g_atype1031_0,
g_atype1031_1,
g_atype1031_2,
};

static const long offsets1031 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1032[];
static const uint32 types1032 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1032 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1032_0 [] = {1031,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1032_1 [] = {0xFF01,1181,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1032_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1032 [] = {
g_atype1032_0,
g_atype1032_1,
g_atype1032_2,
};

static const long offsets1032 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1033[];
static const uint32 types1033 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1033 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1033_0 [] = {1032,843,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1033_1 [] = {0xFF01,1182,843,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1033_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1033 [] = {
g_atype1033_0,
g_atype1033_1,
g_atype1033_2,
};

static const long offsets1033 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1034[];
static const uint32 types1034 [] =
{
SK_REF,
};

static const uint16 attr_flags1034 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1034_0 [] = {1033,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1034 [] = {
g_atype1034_0,
};

static const long offsets1034 [] =
{
0,
};

extern const char *names1035[];
static const uint32 types1035 [] =
{
SK_REF,
};

static const uint16 attr_flags1035 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1035_0 [] = {1034,834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1035 [] = {
g_atype1035_0,
};

static const long offsets1035 [] =
{
0,
};

extern const char *names1036[];
static const uint32 types1036 [] =
{
SK_REF,
};

static const uint16 attr_flags1036 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1036_0 [] = {1035,864,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1036 [] = {
g_atype1036_0,
};

static const long offsets1036 [] =
{
0,
};

extern const char *names1037[];
static const uint32 types1037 [] =
{
SK_REF,
};

static const uint16 attr_flags1037 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1037_0 [] = {1036,867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1037 [] = {
g_atype1037_0,
};

static const long offsets1037 [] =
{
0,
};

extern const char *names1038[];
static const uint32 types1038 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1038 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1038_0 [] = {1037,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_1 [] = {0xFF01,1158,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1038 [] = {
g_atype1038_0,
g_atype1038_1,
g_atype1038_2,
};

static const long offsets1038 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1039[];
static const uint32 types1039 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1039 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1039_0 [] = {1038,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1039_1 [] = {0xFF01,1159,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1039_2 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1039 [] = {
g_atype1039_0,
g_atype1039_1,
g_atype1039_2,
};

static const long offsets1039 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1040[];
static const uint32 types1040 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1040 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1040_0 [] = {1039,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1040_1 [] = {153,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1040_2 [] = {0xFF01,1144,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1040_3 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1040_4 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1040 [] = {
g_atype1040_0,
g_atype1040_1,
g_atype1040_2,
g_atype1040_3,
g_atype1040_4,
};

static const long offsets1040 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names1041[];
static const uint32 types1041 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1041 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1041_0 [] = {1040,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1041_1 [] = {154,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1041_2 [] = {0xFF01,1145,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1041_3 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1041_4 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1041 [] = {
g_atype1041_0,
g_atype1041_1,
g_atype1041_2,
g_atype1041_3,
g_atype1041_4,
};

static const long offsets1041 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names1042[];
static const uint32 types1042 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1042 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1042_0 [] = {1041,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1042_1 [] = {156,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1042_2 [] = {0xFF01,1146,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1042_3 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1042_4 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1042 [] = {
g_atype1042_0,
g_atype1042_1,
g_atype1042_2,
g_atype1042_3,
g_atype1042_4,
};

static const long offsets1042 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names1043[];
static const uint32 types1043 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1043 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1043_0 [] = {1042,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1043_1 [] = {155,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1043_2 [] = {0xFF01,1147,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1043_3 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1043_4 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1043 [] = {
g_atype1043_0,
g_atype1043_1,
g_atype1043_2,
g_atype1043_3,
g_atype1043_4,
};

static const long offsets1043 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names1044[];
static const uint32 types1044 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1044 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1044_0 [] = {1043,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1044_1 [] = {157,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1044_2 [] = {0xFF01,1150,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1044_3 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1044_4 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1044 [] = {
g_atype1044_0,
g_atype1044_1,
g_atype1044_2,
g_atype1044_3,
g_atype1044_4,
};

static const long offsets1044 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names1046[];
static const uint32 types1046 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1046 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1046_0 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_1 [] = {0xFF01,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_2 [] = {220,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_3 [] = {81,0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_4 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_5 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_6 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_7 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_9 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_10 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1046 [] = {
g_atype1046_0,
g_atype1046_1,
g_atype1046_2,
g_atype1046_3,
g_atype1046_4,
g_atype1046_5,
g_atype1046_6,
g_atype1046_7,
g_atype1046_8,
g_atype1046_9,
g_atype1046_10,
};

static const long offsets1046 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @LNGOFF(6,2,0,0),
+ @PTROFF(6,2,0,1,0,0),
+ @PTROFF(6,2,0,1,0,1),
};

extern const char *names1047[];
static const uint32 types1047 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags1047 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1047_0 [] = {0xFF01,1140,0xFF01,1149,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_1 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_2 [] = {0xFF01,1192,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_3 [] = {0xFF01,1140,0xFF01,115,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_4 [] = {0xFF01,1140,0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_5 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_6 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_7 [] = {1140,0xFF01,115,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_8 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1047 [] = {
g_atype1047_0,
g_atype1047_1,
g_atype1047_2,
g_atype1047_3,
g_atype1047_4,
g_atype1047_5,
g_atype1047_6,
g_atype1047_7,
g_atype1047_8,
};

static const long offsets1047 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
};

extern const char *names1048[];
static const uint32 types1048 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags1048 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1048_0 [] = {0xFF01,1140,0xFF01,1149,0xFFFF};
static const EIF_TYPE_INDEX g_atype1048_1 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1048_2 [] = {0xFF01,1192,0xFFFF};
static const EIF_TYPE_INDEX g_atype1048_3 [] = {0xFF01,1140,0xFF01,115,0xFFFF};
static const EIF_TYPE_INDEX g_atype1048_4 [] = {0xFF01,1140,0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1048_5 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1048_6 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1048_7 [] = {1140,0xFF01,115,0xFFFF};
static const EIF_TYPE_INDEX g_atype1048_8 [] = {0xFF01,224,0xFFFF};
static const EIF_TYPE_INDEX g_atype1048_9 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1048 [] = {
g_atype1048_0,
g_atype1048_1,
g_atype1048_2,
g_atype1048_3,
g_atype1048_4,
g_atype1048_5,
g_atype1048_6,
g_atype1048_7,
g_atype1048_8,
g_atype1048_9,
};

static const long offsets1048 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
};

extern const char *names1049[];
static const uint32 types1049 [] =
{
SK_REF,
};

static const uint16 attr_flags1049 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1049_0 [] = {0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1049 [] = {
g_atype1049_0,
};

static const long offsets1049 [] =
{
0,
};

extern const char *names1050[];
static const uint32 types1050 [] =
{
SK_REF,
};

static const uint16 attr_flags1050 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1050_0 [] = {0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1050 [] = {
g_atype1050_0,
};

static const long offsets1050 [] =
{
0,
};

extern const char *names1051[];
static const uint32 types1051 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1051 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1051_0 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1051_1 [] = {0xFF01,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1051_2 [] = {220,0xFFFF};
static const EIF_TYPE_INDEX g_atype1051_3 [] = {0xFF01,911,0xFFFF};
static const EIF_TYPE_INDEX g_atype1051_4 [] = {10,0xFFFF};
static const EIF_TYPE_INDEX g_atype1051_5 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1051_6 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1051_7 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1051_8 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1051_9 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1051_10 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1051_11 [] = {852,0xFFFF};
static const EIF_TYPE_INDEX g_atype1051_12 [] = {840,0xFFFF};
static const EIF_TYPE_INDEX g_atype1051_13 [] = {849,0xFFFF};
static const EIF_TYPE_INDEX g_atype1051_14 [] = {837,0xFFFF};
static const EIF_TYPE_INDEX g_atype1051_15 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1051_16 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1051_17 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1051_18 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1051_19 [] = {855,0xFFFF};
static const EIF_TYPE_INDEX g_atype1051_20 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1051_21 [] = {843,0xFFFF};
static const EIF_TYPE_INDEX g_atype1051_22 [] = {831,0xFFFF};
static const EIF_TYPE_INDEX g_atype1051_23 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1051 [] = {
g_atype1051_0,
g_atype1051_1,
g_atype1051_2,
g_atype1051_3,
g_atype1051_4,
g_atype1051_5,
g_atype1051_6,
g_atype1051_7,
g_atype1051_8,
g_atype1051_9,
g_atype1051_10,
g_atype1051_11,
g_atype1051_12,
g_atype1051_13,
g_atype1051_14,
g_atype1051_15,
g_atype1051_16,
g_atype1051_17,
g_atype1051_18,
g_atype1051_19,
g_atype1051_20,
g_atype1051_21,
g_atype1051_22,
g_atype1051_23,
};

static const long offsets1051 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names1052[];
static const uint32 types1052 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1052 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1052_0 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1052_1 [] = {0xFF01,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1052_2 [] = {220,0xFFFF};
static const EIF_TYPE_INDEX g_atype1052_3 [] = {220,0xFFFF};
static const EIF_TYPE_INDEX g_atype1052_4 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1052_5 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1052_6 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1052_7 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1052_8 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1052_9 [] = {852,0xFFFF};
static const EIF_TYPE_INDEX g_atype1052_10 [] = {840,0xFFFF};
static const EIF_TYPE_INDEX g_atype1052_11 [] = {849,0xFFFF};
static const EIF_TYPE_INDEX g_atype1052_12 [] = {837,0xFFFF};
static const EIF_TYPE_INDEX g_atype1052_13 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1052_14 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1052_15 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1052_16 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1052_17 [] = {855,0xFFFF};
static const EIF_TYPE_INDEX g_atype1052_18 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1052_19 [] = {843,0xFFFF};
static const EIF_TYPE_INDEX g_atype1052_20 [] = {831,0xFFFF};
static const EIF_TYPE_INDEX g_atype1052_21 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1052 [] = {
g_atype1052_0,
g_atype1052_1,
g_atype1052_2,
g_atype1052_3,
g_atype1052_4,
g_atype1052_5,
g_atype1052_6,
g_atype1052_7,
g_atype1052_8,
g_atype1052_9,
g_atype1052_10,
g_atype1052_11,
g_atype1052_12,
g_atype1052_13,
g_atype1052_14,
g_atype1052_15,
g_atype1052_16,
g_atype1052_17,
g_atype1052_18,
g_atype1052_19,
g_atype1052_20,
g_atype1052_21,
};

static const long offsets1052 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @I16OFF(5,6,0),
+ @I16OFF(5,6,1),
+ @LNGOFF(5,6,2,0),
+ @LNGOFF(5,6,2,1),
+ @LNGOFF(5,6,2,2),
+ @LNGOFF(5,6,2,3),
+ @R32OFF(5,6,2,4,0),
+ @PTROFF(5,6,2,4,1,0),
+ @I64OFF(5,6,2,4,1,1,0),
+ @I64OFF(5,6,2,4,1,1,1),
+ @R64OFF(5,6,2,4,1,1,2,0),
};

extern const char *names1053[];
static const uint32 types1053 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1053 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1053_0 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1053_1 [] = {0xFF01,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1053_2 [] = {220,0xFFFF};
static const EIF_TYPE_INDEX g_atype1053_3 [] = {220,0xFFFF};
static const EIF_TYPE_INDEX g_atype1053_4 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1053_5 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1053_6 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1053_7 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1053_8 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1053_9 [] = {852,0xFFFF};
static const EIF_TYPE_INDEX g_atype1053_10 [] = {840,0xFFFF};
static const EIF_TYPE_INDEX g_atype1053_11 [] = {849,0xFFFF};
static const EIF_TYPE_INDEX g_atype1053_12 [] = {837,0xFFFF};
static const EIF_TYPE_INDEX g_atype1053_13 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1053_14 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1053_15 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1053_16 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1053_17 [] = {855,0xFFFF};
static const EIF_TYPE_INDEX g_atype1053_18 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1053_19 [] = {843,0xFFFF};
static const EIF_TYPE_INDEX g_atype1053_20 [] = {831,0xFFFF};
static const EIF_TYPE_INDEX g_atype1053_21 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1053 [] = {
g_atype1053_0,
g_atype1053_1,
g_atype1053_2,
g_atype1053_3,
g_atype1053_4,
g_atype1053_5,
g_atype1053_6,
g_atype1053_7,
g_atype1053_8,
g_atype1053_9,
g_atype1053_10,
g_atype1053_11,
g_atype1053_12,
g_atype1053_13,
g_atype1053_14,
g_atype1053_15,
g_atype1053_16,
g_atype1053_17,
g_atype1053_18,
g_atype1053_19,
g_atype1053_20,
g_atype1053_21,
};

static const long offsets1053 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @I16OFF(5,6,0),
+ @I16OFF(5,6,1),
+ @LNGOFF(5,6,2,0),
+ @LNGOFF(5,6,2,1),
+ @LNGOFF(5,6,2,2),
+ @LNGOFF(5,6,2,3),
+ @R32OFF(5,6,2,4,0),
+ @PTROFF(5,6,2,4,1,0),
+ @I64OFF(5,6,2,4,1,1,0),
+ @I64OFF(5,6,2,4,1,1,1),
+ @R64OFF(5,6,2,4,1,1,2,0),
};

extern const char *names1054[];
static const uint32 types1054 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1054 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1054_0 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_1 [] = {0xFF01,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_2 [] = {220,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_3 [] = {220,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_4 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_5 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_6 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_7 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_8 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_9 [] = {852,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_10 [] = {840,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_11 [] = {849,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_12 [] = {837,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_13 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_14 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_15 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_16 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_17 [] = {855,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_18 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_19 [] = {843,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_20 [] = {831,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_21 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1054 [] = {
g_atype1054_0,
g_atype1054_1,
g_atype1054_2,
g_atype1054_3,
g_atype1054_4,
g_atype1054_5,
g_atype1054_6,
g_atype1054_7,
g_atype1054_8,
g_atype1054_9,
g_atype1054_10,
g_atype1054_11,
g_atype1054_12,
g_atype1054_13,
g_atype1054_14,
g_atype1054_15,
g_atype1054_16,
g_atype1054_17,
g_atype1054_18,
g_atype1054_19,
g_atype1054_20,
g_atype1054_21,
};

static const long offsets1054 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @I16OFF(5,6,0),
+ @I16OFF(5,6,1),
+ @LNGOFF(5,6,2,0),
+ @LNGOFF(5,6,2,1),
+ @LNGOFF(5,6,2,2),
+ @LNGOFF(5,6,2,3),
+ @R32OFF(5,6,2,4,0),
+ @PTROFF(5,6,2,4,1,0),
+ @I64OFF(5,6,2,4,1,1,0),
+ @I64OFF(5,6,2,4,1,1,1),
+ @R64OFF(5,6,2,4,1,1,2,0),
};

extern const char *names1055[];
static const uint32 types1055 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
};

static const uint16 attr_flags1055 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1055_0 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1055_1 [] = {82,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1055_2 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1055_3 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1055_4 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1055 [] = {
g_atype1055_0,
g_atype1055_1,
g_atype1055_2,
g_atype1055_3,
g_atype1055_4,
};

static const long offsets1055 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names1056[];
static const uint32 types1056 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1056 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1056_0 [] = {0xFF01,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_1 [] = {220,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_2 [] = {0xFF01,911,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_3 [] = {10,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_4 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_5 [] = {82,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_6 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_7 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_8 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_9 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_10 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_11 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_12 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_13 [] = {852,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_14 [] = {840,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_15 [] = {849,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_16 [] = {837,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_17 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_18 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_19 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_20 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_21 [] = {855,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_22 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_23 [] = {843,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_24 [] = {831,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_25 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1056 [] = {
g_atype1056_0,
g_atype1056_1,
g_atype1056_2,
g_atype1056_3,
g_atype1056_4,
g_atype1056_5,
g_atype1056_6,
g_atype1056_7,
g_atype1056_8,
g_atype1056_9,
g_atype1056_10,
g_atype1056_11,
g_atype1056_12,
g_atype1056_13,
g_atype1056_14,
g_atype1056_15,
g_atype1056_16,
g_atype1056_17,
g_atype1056_18,
g_atype1056_19,
g_atype1056_20,
g_atype1056_21,
g_atype1056_22,
g_atype1056_23,
g_atype1056_24,
g_atype1056_25,
};

static const long offsets1056 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @CHROFF(7,4),
+ @CHROFF(7,5),
+ @CHROFF(7,6),
+ @CHROFF(7,7),
+ @I16OFF(7,8,0),
+ @I16OFF(7,8,1),
+ @LNGOFF(7,8,2,0),
+ @LNGOFF(7,8,2,1),
+ @LNGOFF(7,8,2,2),
+ @LNGOFF(7,8,2,3),
+ @R32OFF(7,8,2,4,0),
+ @PTROFF(7,8,2,4,1,0),
+ @I64OFF(7,8,2,4,1,1,0),
+ @I64OFF(7,8,2,4,1,1,1),
+ @R64OFF(7,8,2,4,1,1,2,0),
};

extern const char *names1057[];
static const uint32 types1057 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1057 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1057_0 [] = {0xFF01,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_1 [] = {220,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_2 [] = {220,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_3 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_4 [] = {82,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_5 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_6 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_7 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_8 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_9 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_10 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_11 [] = {852,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_12 [] = {840,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_13 [] = {849,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_14 [] = {837,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_15 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_16 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_17 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_18 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_19 [] = {855,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_20 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_21 [] = {843,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_22 [] = {831,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_23 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1057 [] = {
g_atype1057_0,
g_atype1057_1,
g_atype1057_2,
g_atype1057_3,
g_atype1057_4,
g_atype1057_5,
g_atype1057_6,
g_atype1057_7,
g_atype1057_8,
g_atype1057_9,
g_atype1057_10,
g_atype1057_11,
g_atype1057_12,
g_atype1057_13,
g_atype1057_14,
g_atype1057_15,
g_atype1057_16,
g_atype1057_17,
g_atype1057_18,
g_atype1057_19,
g_atype1057_20,
g_atype1057_21,
g_atype1057_22,
g_atype1057_23,
};

static const long offsets1057 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names1058[];
static const uint32 types1058 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1058 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1058_0 [] = {0xFF01,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_1 [] = {220,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_2 [] = {220,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_3 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_4 [] = {82,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_5 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_6 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_7 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_8 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_9 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_10 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_11 [] = {852,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_12 [] = {840,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_13 [] = {849,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_14 [] = {837,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_15 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_16 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_17 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_18 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_19 [] = {855,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_20 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_21 [] = {843,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_22 [] = {831,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_23 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1058 [] = {
g_atype1058_0,
g_atype1058_1,
g_atype1058_2,
g_atype1058_3,
g_atype1058_4,
g_atype1058_5,
g_atype1058_6,
g_atype1058_7,
g_atype1058_8,
g_atype1058_9,
g_atype1058_10,
g_atype1058_11,
g_atype1058_12,
g_atype1058_13,
g_atype1058_14,
g_atype1058_15,
g_atype1058_16,
g_atype1058_17,
g_atype1058_18,
g_atype1058_19,
g_atype1058_20,
g_atype1058_21,
g_atype1058_22,
g_atype1058_23,
};

static const long offsets1058 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names1059[];
static const uint32 types1059 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1059 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1059_0 [] = {0xFF01,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_1 [] = {220,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_2 [] = {220,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_3 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_4 [] = {82,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_5 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_6 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_7 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_8 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_9 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_10 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_11 [] = {852,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_12 [] = {840,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_13 [] = {849,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_14 [] = {837,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_15 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_16 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_17 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_18 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_19 [] = {855,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_20 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_21 [] = {843,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_22 [] = {831,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_23 [] = {858,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1059 [] = {
g_atype1059_0,
g_atype1059_1,
g_atype1059_2,
g_atype1059_3,
g_atype1059_4,
g_atype1059_5,
g_atype1059_6,
g_atype1059_7,
g_atype1059_8,
g_atype1059_9,
g_atype1059_10,
g_atype1059_11,
g_atype1059_12,
g_atype1059_13,
g_atype1059_14,
g_atype1059_15,
g_atype1059_16,
g_atype1059_17,
g_atype1059_18,
g_atype1059_19,
g_atype1059_20,
g_atype1059_21,
g_atype1059_22,
g_atype1059_23,
};

static const long offsets1059 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names1060[];
static const uint32 types1060 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1060 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1060_0 [] = {0xFF01,702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1060_1 [] = {702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1060_2 [] = {0xFF01,701,0xFF01,162,0xFFFF};
static const EIF_TYPE_INDEX g_atype1060_3 [] = {0xFF01,701,162,0xFFFF};
static const EIF_TYPE_INDEX g_atype1060_4 [] = {0xFF01,701,0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1060_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1060_6 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1060_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1060_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1060_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1060_10 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1060 [] = {
g_atype1060_0,
g_atype1060_1,
g_atype1060_2,
g_atype1060_3,
g_atype1060_4,
g_atype1060_5,
g_atype1060_6,
g_atype1060_7,
g_atype1060_8,
g_atype1060_9,
g_atype1060_10,
};

static const long offsets1060 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
+ @LNGOFF(5,2,0,1),
+ @LNGOFF(5,2,0,2),
+ @LNGOFF(5,2,0,3),
};

extern const char *names1061[];
static const uint32 types1061 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1061 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1061_0 [] = {0xFF01,165,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_1 [] = {0xFF01,92,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_2 [] = {682,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_3 [] = {680,861,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_4 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_5 [] = {0xFF01,702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_6 [] = {702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_7 [] = {0xFF01,701,0xFF01,162,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_8 [] = {0xFF01,701,162,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_9 [] = {0xFF01,701,0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_10 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_11 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_12 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_13 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_14 [] = {861,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_15 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_16 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_17 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_18 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_19 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_20 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_21 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_22 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_23 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_24 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_25 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_26 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_27 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_28 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_29 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_30 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_31 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1061_32 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1061 [] = {
g_atype1061_0,
g_atype1061_1,
g_atype1061_2,
g_atype1061_3,
g_atype1061_4,
g_atype1061_5,
g_atype1061_6,
g_atype1061_7,
g_atype1061_8,
g_atype1061_9,
g_atype1061_10,
g_atype1061_11,
g_atype1061_12,
g_atype1061_13,
g_atype1061_14,
g_atype1061_15,
g_atype1061_16,
g_atype1061_17,
g_atype1061_18,
g_atype1061_19,
g_atype1061_20,
g_atype1061_21,
g_atype1061_22,
g_atype1061_23,
g_atype1061_24,
g_atype1061_25,
g_atype1061_26,
g_atype1061_27,
g_atype1061_28,
g_atype1061_29,
g_atype1061_30,
g_atype1061_31,
g_atype1061_32,
};

static const long offsets1061 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @CHROFF(10,0),
+ @CHROFF(10,1),
+ @CHROFF(10,2),
+ @CHROFF(10,3),
+ @LNGOFF(10,4,0,0),
+ @LNGOFF(10,4,0,1),
+ @LNGOFF(10,4,0,2),
+ @LNGOFF(10,4,0,3),
+ @LNGOFF(10,4,0,4),
+ @LNGOFF(10,4,0,5),
+ @LNGOFF(10,4,0,6),
+ @LNGOFF(10,4,0,7),
+ @LNGOFF(10,4,0,8),
+ @LNGOFF(10,4,0,9),
+ @LNGOFF(10,4,0,10),
+ @LNGOFF(10,4,0,11),
+ @LNGOFF(10,4,0,12),
+ @LNGOFF(10,4,0,13),
+ @LNGOFF(10,4,0,14),
+ @LNGOFF(10,4,0,15),
+ @LNGOFF(10,4,0,16),
+ @LNGOFF(10,4,0,17),
+ @LNGOFF(10,4,0,18),
};

extern const char *names1062[];
static const uint32 types1062 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1062 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1062_0 [] = {0xFF01,702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_1 [] = {702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_2 [] = {0xFF01,701,0xFF01,162,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_3 [] = {0xFF01,701,162,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_4 [] = {0xFF01,701,0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_5 [] = {0xFF01,702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_6 [] = {0xFF01,702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_7 [] = {0xFF01,702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_8 [] = {0xFF01,702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_9 [] = {702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_10 [] = {702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_11 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_12 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_13 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_14 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_15 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_16 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_17 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_18 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_19 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_20 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1062_21 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1062 [] = {
g_atype1062_0,
g_atype1062_1,
g_atype1062_2,
g_atype1062_3,
g_atype1062_4,
g_atype1062_5,
g_atype1062_6,
g_atype1062_7,
g_atype1062_8,
g_atype1062_9,
g_atype1062_10,
g_atype1062_11,
g_atype1062_12,
g_atype1062_13,
g_atype1062_14,
g_atype1062_15,
g_atype1062_16,
g_atype1062_17,
g_atype1062_18,
g_atype1062_19,
g_atype1062_20,
g_atype1062_21,
};

static const long offsets1062 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @CHROFF(11,0),
+ @CHROFF(11,1),
+ @CHROFF(11,2),
+ @CHROFF(11,3),
+ @LNGOFF(11,4,0,0),
+ @LNGOFF(11,4,0,1),
+ @LNGOFF(11,4,0,2),
+ @LNGOFF(11,4,0,3),
+ @LNGOFF(11,4,0,4),
+ @LNGOFF(11,4,0,5),
+ @LNGOFF(11,4,0,6),
};

extern const char *names1063[];
static const uint32 types1063 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1063 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1063_0 [] = {0xFF01,165,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_1 [] = {0xFF01,92,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_2 [] = {682,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_3 [] = {680,861,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_4 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_5 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_6 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_7 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_8 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_9 [] = {677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_10 [] = {677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_11 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_12 [] = {677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_13 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_14 [] = {0xFF01,702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_15 [] = {702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_16 [] = {0xFF01,701,0xFF01,162,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_17 [] = {0xFF01,701,162,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_18 [] = {0xFF01,701,0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_19 [] = {0xFF01,702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_20 [] = {0xFF01,702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_21 [] = {0xFF01,702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_22 [] = {0xFF01,702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_23 [] = {702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_24 [] = {702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_25 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_26 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_27 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_28 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_29 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_30 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_31 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_32 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_33 [] = {861,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_34 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_35 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_36 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_37 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_38 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_39 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_40 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_41 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_42 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_43 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_44 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_45 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_46 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_47 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_48 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_49 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_50 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_51 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_52 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_53 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_54 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_55 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_56 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_57 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_58 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_59 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_60 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1063 [] = {
g_atype1063_0,
g_atype1063_1,
g_atype1063_2,
g_atype1063_3,
g_atype1063_4,
g_atype1063_5,
g_atype1063_6,
g_atype1063_7,
g_atype1063_8,
g_atype1063_9,
g_atype1063_10,
g_atype1063_11,
g_atype1063_12,
g_atype1063_13,
g_atype1063_14,
g_atype1063_15,
g_atype1063_16,
g_atype1063_17,
g_atype1063_18,
g_atype1063_19,
g_atype1063_20,
g_atype1063_21,
g_atype1063_22,
g_atype1063_23,
g_atype1063_24,
g_atype1063_25,
g_atype1063_26,
g_atype1063_27,
g_atype1063_28,
g_atype1063_29,
g_atype1063_30,
g_atype1063_31,
g_atype1063_32,
g_atype1063_33,
g_atype1063_34,
g_atype1063_35,
g_atype1063_36,
g_atype1063_37,
g_atype1063_38,
g_atype1063_39,
g_atype1063_40,
g_atype1063_41,
g_atype1063_42,
g_atype1063_43,
g_atype1063_44,
g_atype1063_45,
g_atype1063_46,
g_atype1063_47,
g_atype1063_48,
g_atype1063_49,
g_atype1063_50,
g_atype1063_51,
g_atype1063_52,
g_atype1063_53,
g_atype1063_54,
g_atype1063_55,
g_atype1063_56,
g_atype1063_57,
g_atype1063_58,
g_atype1063_59,
g_atype1063_60,
};

static const long offsets1063 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
+ @CHROFF(25,0),
+ @CHROFF(25,1),
+ @CHROFF(25,2),
+ @CHROFF(25,3),
+ @CHROFF(25,4),
+ @CHROFF(25,5),
+ @CHROFF(25,6),
+ @CHROFF(25,7),
+ @LNGOFF(25,8,0,0),
+ @LNGOFF(25,8,0,1),
+ @LNGOFF(25,8,0,2),
+ @LNGOFF(25,8,0,3),
+ @LNGOFF(25,8,0,4),
+ @LNGOFF(25,8,0,5),
+ @LNGOFF(25,8,0,6),
+ @LNGOFF(25,8,0,7),
+ @LNGOFF(25,8,0,8),
+ @LNGOFF(25,8,0,9),
+ @LNGOFF(25,8,0,10),
+ @LNGOFF(25,8,0,11),
+ @LNGOFF(25,8,0,12),
+ @LNGOFF(25,8,0,13),
+ @LNGOFF(25,8,0,14),
+ @LNGOFF(25,8,0,15),
+ @LNGOFF(25,8,0,16),
+ @LNGOFF(25,8,0,17),
+ @LNGOFF(25,8,0,18),
+ @LNGOFF(25,8,0,19),
+ @LNGOFF(25,8,0,20),
+ @LNGOFF(25,8,0,21),
+ @LNGOFF(25,8,0,22),
+ @LNGOFF(25,8,0,23),
+ @LNGOFF(25,8,0,24),
+ @LNGOFF(25,8,0,25),
+ @LNGOFF(25,8,0,26),
+ @LNGOFF(25,8,0,27),
};

extern const char *names1064[];
static const uint32 types1064 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1064 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1064_0 [] = {0xFF01,702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_1 [] = {702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_2 [] = {0xFF01,701,0xFF01,162,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_3 [] = {0xFF01,701,162,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_4 [] = {0xFF01,701,0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_5 [] = {0xFF01,702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_6 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_7 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_8 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_10 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_11 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_12 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_13 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1064 [] = {
g_atype1064_0,
g_atype1064_1,
g_atype1064_2,
g_atype1064_3,
g_atype1064_4,
g_atype1064_5,
g_atype1064_6,
g_atype1064_7,
g_atype1064_8,
g_atype1064_9,
g_atype1064_10,
g_atype1064_11,
g_atype1064_12,
g_atype1064_13,
};

static const long offsets1064 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @LNGOFF(6,3,0,0),
+ @LNGOFF(6,3,0,1),
+ @LNGOFF(6,3,0,2),
+ @LNGOFF(6,3,0,3),
+ @LNGOFF(6,3,0,4),
};

extern const char *names1065[];
static const uint32 types1065 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1065 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1065_0 [] = {0xFF01,165,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_1 [] = {0xFF01,92,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_2 [] = {682,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_3 [] = {680,861,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_4 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_5 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_6 [] = {677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_7 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_8 [] = {0xFF01,702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_9 [] = {702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_10 [] = {0xFF01,701,0xFF01,162,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_11 [] = {0xFF01,701,162,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_12 [] = {0xFF01,701,0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_13 [] = {0xFF01,702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_14 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_15 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_16 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_17 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_18 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_19 [] = {861,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_20 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_21 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_22 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_23 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_24 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_25 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_26 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_27 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_28 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_29 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_30 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_31 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_32 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_33 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_34 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_35 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_36 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_37 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_38 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1065 [] = {
g_atype1065_0,
g_atype1065_1,
g_atype1065_2,
g_atype1065_3,
g_atype1065_4,
g_atype1065_5,
g_atype1065_6,
g_atype1065_7,
g_atype1065_8,
g_atype1065_9,
g_atype1065_10,
g_atype1065_11,
g_atype1065_12,
g_atype1065_13,
g_atype1065_14,
g_atype1065_15,
g_atype1065_16,
g_atype1065_17,
g_atype1065_18,
g_atype1065_19,
g_atype1065_20,
g_atype1065_21,
g_atype1065_22,
g_atype1065_23,
g_atype1065_24,
g_atype1065_25,
g_atype1065_26,
g_atype1065_27,
g_atype1065_28,
g_atype1065_29,
g_atype1065_30,
g_atype1065_31,
g_atype1065_32,
g_atype1065_33,
g_atype1065_34,
g_atype1065_35,
g_atype1065_36,
g_atype1065_37,
g_atype1065_38,
};

static const long offsets1065 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
+ @CHROFF(14,0),
+ @CHROFF(14,1),
+ @CHROFF(14,2),
+ @CHROFF(14,3),
+ @CHROFF(14,4),
+ @LNGOFF(14,5,0,0),
+ @LNGOFF(14,5,0,1),
+ @LNGOFF(14,5,0,2),
+ @LNGOFF(14,5,0,3),
+ @LNGOFF(14,5,0,4),
+ @LNGOFF(14,5,0,5),
+ @LNGOFF(14,5,0,6),
+ @LNGOFF(14,5,0,7),
+ @LNGOFF(14,5,0,8),
+ @LNGOFF(14,5,0,9),
+ @LNGOFF(14,5,0,10),
+ @LNGOFF(14,5,0,11),
+ @LNGOFF(14,5,0,12),
+ @LNGOFF(14,5,0,13),
+ @LNGOFF(14,5,0,14),
+ @LNGOFF(14,5,0,15),
+ @LNGOFF(14,5,0,16),
+ @LNGOFF(14,5,0,17),
+ @LNGOFF(14,5,0,18),
+ @LNGOFF(14,5,0,19),
};

extern const char *names1067[];
static const uint32 types1067 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1067 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1067_0 [] = {0xFF01,1180,0xFFF8,1,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1067 [] = {
g_atype1067_0,
g_atype1067_1,
g_atype1067_2,
g_atype1067_3,
g_atype1067_4,
g_atype1067_5,
};

static const long offsets1067 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names1069[];
static const uint32 types1069 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1069 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1069_0 [] = {1076,0xFF01,1068,0xFFFF};
static const EIF_TYPE_INDEX g_atype1069_1 [] = {1079,0xFF01,1068,0xFFFF};
static const EIF_TYPE_INDEX g_atype1069_2 [] = {162,0xFFFF};
static const EIF_TYPE_INDEX g_atype1069_3 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1069_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1069 [] = {
g_atype1069_0,
g_atype1069_1,
g_atype1069_2,
g_atype1069_3,
g_atype1069_4,
};

static const long offsets1069 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
};

extern const char *names1070[];
static const uint32 types1070 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1070 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1070_0 [] = {0xFF01,1158,0xFF01,1068,0xFFFF};
static const EIF_TYPE_INDEX g_atype1070_1 [] = {0xFF01,1158,0xFF01,162,0xFFFF};
static const EIF_TYPE_INDEX g_atype1070_2 [] = {0xFF01,1158,0xFF01,162,0xFFFF};
static const EIF_TYPE_INDEX g_atype1070_3 [] = {0xFF01,1066,0xFF01,1069,0xFFFF};
static const EIF_TYPE_INDEX g_atype1070_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1070_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1070 [] = {
g_atype1070_0,
g_atype1070_1,
g_atype1070_2,
g_atype1070_3,
g_atype1070_4,
g_atype1070_5,
};

static const long offsets1070 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
};

extern const char *names1072[];
static const uint32 types1072 [] =
{
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags1072 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1072_0 [] = {0xFF01,1158,0xFF01,1068,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_1 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1072 [] = {
g_atype1072_0,
g_atype1072_1,
};

static const long offsets1072 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names1073[];
static const uint32 types1073 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1073 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1073_0 [] = {0xFF01,1158,0xFF01,1069,0xFFFF};
static const EIF_TYPE_INDEX g_atype1073_1 [] = {96,0xFFFF};
static const EIF_TYPE_INDEX g_atype1073_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1073_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1073_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1073_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1073 [] = {
g_atype1073_0,
g_atype1073_1,
g_atype1073_2,
g_atype1073_3,
g_atype1073_4,
g_atype1073_5,
};

static const long offsets1073 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names1074[];
static const uint32 types1074 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1074 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1074_0 [] = {0xFF01,702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_1 [] = {702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_2 [] = {0xFF01,701,0xFF01,162,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_3 [] = {0xFF01,701,162,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_4 [] = {0xFF01,701,0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_5 [] = {0xFF01,1158,0xFF01,1069,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_6 [] = {96,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_7 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_8 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_9 [] = {0xFF01,1158,0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_10 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_11 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_12 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_13 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_14 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_15 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_16 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_17 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_18 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_19 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_20 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_21 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_22 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_23 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_24 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_25 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_26 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_27 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_28 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_29 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1074 [] = {
g_atype1074_0,
g_atype1074_1,
g_atype1074_2,
g_atype1074_3,
g_atype1074_4,
g_atype1074_5,
g_atype1074_6,
g_atype1074_7,
g_atype1074_8,
g_atype1074_9,
g_atype1074_10,
g_atype1074_11,
g_atype1074_12,
g_atype1074_13,
g_atype1074_14,
g_atype1074_15,
g_atype1074_16,
g_atype1074_17,
g_atype1074_18,
g_atype1074_19,
g_atype1074_20,
g_atype1074_21,
g_atype1074_22,
g_atype1074_23,
g_atype1074_24,
g_atype1074_25,
g_atype1074_26,
g_atype1074_27,
g_atype1074_28,
g_atype1074_29,
};

static const long offsets1074 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @CHROFF(10,0),
+ @CHROFF(10,1),
+ @CHROFF(10,2),
+ @CHROFF(10,3),
+ @CHROFF(10,4),
+ @CHROFF(10,5),
+ @CHROFF(10,6),
+ @CHROFF(10,7),
+ @CHROFF(10,8),
+ @CHROFF(10,9),
+ @CHROFF(10,10),
+ @LNGOFF(10,11,0,0),
+ @LNGOFF(10,11,0,1),
+ @LNGOFF(10,11,0,2),
+ @LNGOFF(10,11,0,3),
+ @LNGOFF(10,11,0,4),
+ @LNGOFF(10,11,0,5),
+ @LNGOFF(10,11,0,6),
+ @LNGOFF(10,11,0,7),
+ @LNGOFF(10,11,0,8),
};

extern const char *names1075[];
static const uint32 types1075 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1075 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1075_0 [] = {0xFF01,702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_1 [] = {702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_2 [] = {0xFF01,701,0xFF01,162,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_3 [] = {0xFF01,701,162,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_4 [] = {0xFF01,701,0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_5 [] = {0xFF01,702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_6 [] = {0xFF01,702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_7 [] = {0xFF01,702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_8 [] = {0xFF01,702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_9 [] = {702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_10 [] = {702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_11 [] = {0xFF01,1158,0xFF01,1069,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_12 [] = {96,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_13 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_14 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_15 [] = {0xFF01,1158,0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_16 [] = {95,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_17 [] = {1151,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_18 [] = {1148,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_19 [] = {1158,0xFF01,46,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_20 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_21 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_22 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_23 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_24 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_25 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_26 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_27 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_28 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_29 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_30 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_31 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_32 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_33 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_34 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_35 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_36 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_37 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_38 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_39 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_40 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_41 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_42 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_43 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_44 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_45 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_46 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_47 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_48 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1075 [] = {
g_atype1075_0,
g_atype1075_1,
g_atype1075_2,
g_atype1075_3,
g_atype1075_4,
g_atype1075_5,
g_atype1075_6,
g_atype1075_7,
g_atype1075_8,
g_atype1075_9,
g_atype1075_10,
g_atype1075_11,
g_atype1075_12,
g_atype1075_13,
g_atype1075_14,
g_atype1075_15,
g_atype1075_16,
g_atype1075_17,
g_atype1075_18,
g_atype1075_19,
g_atype1075_20,
g_atype1075_21,
g_atype1075_22,
g_atype1075_23,
g_atype1075_24,
g_atype1075_25,
g_atype1075_26,
g_atype1075_27,
g_atype1075_28,
g_atype1075_29,
g_atype1075_30,
g_atype1075_31,
g_atype1075_32,
g_atype1075_33,
g_atype1075_34,
g_atype1075_35,
g_atype1075_36,
g_atype1075_37,
g_atype1075_38,
g_atype1075_39,
g_atype1075_40,
g_atype1075_41,
g_atype1075_42,
g_atype1075_43,
g_atype1075_44,
g_atype1075_45,
g_atype1075_46,
g_atype1075_47,
g_atype1075_48,
};

static const long offsets1075 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
+ @CHROFF(20,0),
+ @CHROFF(20,1),
+ @CHROFF(20,2),
+ @CHROFF(20,3),
+ @CHROFF(20,4),
+ @CHROFF(20,5),
+ @CHROFF(20,6),
+ @CHROFF(20,7),
+ @CHROFF(20,8),
+ @CHROFF(20,9),
+ @CHROFF(20,10),
+ @CHROFF(20,11),
+ @CHROFF(20,12),
+ @CHROFF(20,13),
+ @LNGOFF(20,14,0,0),
+ @LNGOFF(20,14,0,1),
+ @LNGOFF(20,14,0,2),
+ @LNGOFF(20,14,0,3),
+ @LNGOFF(20,14,0,4),
+ @LNGOFF(20,14,0,5),
+ @LNGOFF(20,14,0,6),
+ @LNGOFF(20,14,0,7),
+ @LNGOFF(20,14,0,8),
+ @LNGOFF(20,14,0,9),
+ @LNGOFF(20,14,0,10),
+ @LNGOFF(20,14,0,11),
+ @LNGOFF(20,14,0,12),
+ @LNGOFF(20,14,0,13),
+ @LNGOFF(20,14,0,14),
};

extern const char *names1076[];
static const uint32 types1076 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1076 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1076_0 [] = {0xFF01,702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_1 [] = {702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_2 [] = {0xFF01,701,0xFF01,162,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_3 [] = {0xFF01,701,162,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_4 [] = {0xFF01,701,0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_5 [] = {0xFF01,702,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_6 [] = {0xFF01,1158,0xFF01,1069,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_7 [] = {96,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_8 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_9 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_10 [] = {0xFF01,1158,0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_11 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_12 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_13 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_14 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_15 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_16 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_17 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_18 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_19 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_20 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_21 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_22 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_23 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_24 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_25 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_26 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_27 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_28 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_29 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_30 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_31 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_32 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1076 [] = {
g_atype1076_0,
g_atype1076_1,
g_atype1076_2,
g_atype1076_3,
g_atype1076_4,
g_atype1076_5,
g_atype1076_6,
g_atype1076_7,
g_atype1076_8,
g_atype1076_9,
g_atype1076_10,
g_atype1076_11,
g_atype1076_12,
g_atype1076_13,
g_atype1076_14,
g_atype1076_15,
g_atype1076_16,
g_atype1076_17,
g_atype1076_18,
g_atype1076_19,
g_atype1076_20,
g_atype1076_21,
g_atype1076_22,
g_atype1076_23,
g_atype1076_24,
g_atype1076_25,
g_atype1076_26,
g_atype1076_27,
g_atype1076_28,
g_atype1076_29,
g_atype1076_30,
g_atype1076_31,
g_atype1076_32,
};

static const long offsets1076 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @CHROFF(11,0),
+ @CHROFF(11,1),
+ @CHROFF(11,2),
+ @CHROFF(11,3),
+ @CHROFF(11,4),
+ @CHROFF(11,5),
+ @CHROFF(11,6),
+ @CHROFF(11,7),
+ @CHROFF(11,8),
+ @CHROFF(11,9),
+ @CHROFF(11,10),
+ @CHROFF(11,11),
+ @LNGOFF(11,12,0,0),
+ @LNGOFF(11,12,0,1),
+ @LNGOFF(11,12,0,2),
+ @LNGOFF(11,12,0,3),
+ @LNGOFF(11,12,0,4),
+ @LNGOFF(11,12,0,5),
+ @LNGOFF(11,12,0,6),
+ @LNGOFF(11,12,0,7),
+ @LNGOFF(11,12,0,8),
+ @LNGOFF(11,12,0,9),
};

extern const char *names1077[];
static const uint32 types1077 [] =
{
SK_REF,
};

static const uint16 attr_flags1077 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1077_0 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1077 [] = {
g_atype1077_0,
};

static const long offsets1077 [] =
{
0,
};

extern const char *names1078[];
static const uint32 types1078 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1078 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1078_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1078_1 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1078 [] = {
g_atype1078_0,
g_atype1078_1,
};

static const long offsets1078 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names1079[];
static const uint32 types1079 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1079 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1079_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_1 [] = {0xFF01,796,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1079 [] = {
g_atype1079_0,
g_atype1079_1,
};

static const long offsets1079 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1080[];
static const uint32 types1080 [] =
{
SK_REF,
};

static const uint16 attr_flags1080 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1080_0 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1080 [] = {
g_atype1080_0,
};

static const long offsets1080 [] =
{
0,
};

extern const char *names1101[];
static const uint32 types1101 [] =
{
SK_REF,
};

static const uint16 attr_flags1101 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1101_0 [] = {225,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1101 [] = {
g_atype1101_0,
};

static const long offsets1101 [] =
{
0,
};

extern const char *names1102[];
static const uint32 types1102 [] =
{
SK_REF,
};

static const uint16 attr_flags1102 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1102_0 [] = {226,834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1102 [] = {
g_atype1102_0,
};

static const long offsets1102 [] =
{
0,
};

extern const char *names1103[];
static const uint32 types1103 [] =
{
SK_REF,
};

static const uint16 attr_flags1103 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1103_0 [] = {227,864,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1103 [] = {
g_atype1103_0,
};

static const long offsets1103 [] =
{
0,
};

extern const char *names1104[];
static const uint32 types1104 [] =
{
SK_REF,
};

static const uint16 attr_flags1104 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1104_0 [] = {228,867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1104 [] = {
g_atype1104_0,
};

static const long offsets1104 [] =
{
0,
};

extern const char *names1105[];
static const uint32 types1105 [] =
{
SK_REF,
};

static const uint16 attr_flags1105 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1105_0 [] = {229,843,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1105 [] = {
g_atype1105_0,
};

static const long offsets1105 [] =
{
0,
};

extern const char *names1106[];
static const uint32 types1106 [] =
{
SK_REF,
};

static const uint16 attr_flags1106 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1106_0 [] = {230,846,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1106 [] = {
g_atype1106_0,
};

static const long offsets1106 [] =
{
0,
};

extern const char *names1107[];
static const uint32 types1107 [] =
{
SK_REF,
};

static const uint16 attr_flags1107 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1107_0 [] = {225,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1107 [] = {
g_atype1107_0,
};

static const long offsets1107 [] =
{
0,
};

extern const char *names1108[];
static const uint32 types1108 [] =
{
SK_REF,
};

static const uint16 attr_flags1108 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1108_0 [] = {226,834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1108 [] = {
g_atype1108_0,
};

static const long offsets1108 [] =
{
0,
};

extern const char *names1109[];
static const uint32 types1109 [] =
{
SK_REF,
};

static const uint16 attr_flags1109 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1109_0 [] = {227,864,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1109 [] = {
g_atype1109_0,
};

static const long offsets1109 [] =
{
0,
};

extern const char *names1110[];
static const uint32 types1110 [] =
{
SK_REF,
};

static const uint16 attr_flags1110 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1110_0 [] = {228,867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1110 [] = {
g_atype1110_0,
};

static const long offsets1110 [] =
{
0,
};

extern const char *names1111[];
static const uint32 types1111 [] =
{
SK_REF,
};

static const uint16 attr_flags1111 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1111_0 [] = {229,843,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1111 [] = {
g_atype1111_0,
};

static const long offsets1111 [] =
{
0,
};

extern const char *names1112[];
static const uint32 types1112 [] =
{
SK_REF,
};

static const uint16 attr_flags1112 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1112_0 [] = {230,846,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1112 [] = {
g_atype1112_0,
};

static const long offsets1112 [] =
{
0,
};

extern const char *names1113[];
static const uint32 types1113 [] =
{
SK_REF,
};

static const uint16 attr_flags1113 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1113_0 [] = {225,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1113 [] = {
g_atype1113_0,
};

static const long offsets1113 [] =
{
0,
};

extern const char *names1114[];
static const uint32 types1114 [] =
{
SK_REF,
};

static const uint16 attr_flags1114 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1114_0 [] = {226,834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1114 [] = {
g_atype1114_0,
};

static const long offsets1114 [] =
{
0,
};

extern const char *names1115[];
static const uint32 types1115 [] =
{
SK_REF,
};

static const uint16 attr_flags1115 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1115_0 [] = {227,864,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1115 [] = {
g_atype1115_0,
};

static const long offsets1115 [] =
{
0,
};

extern const char *names1116[];
static const uint32 types1116 [] =
{
SK_REF,
};

static const uint16 attr_flags1116 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1116_0 [] = {228,867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1116 [] = {
g_atype1116_0,
};

static const long offsets1116 [] =
{
0,
};

extern const char *names1117[];
static const uint32 types1117 [] =
{
SK_REF,
};

static const uint16 attr_flags1117 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1117_0 [] = {229,843,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1117 [] = {
g_atype1117_0,
};

static const long offsets1117 [] =
{
0,
};

extern const char *names1118[];
static const uint32 types1118 [] =
{
SK_REF,
};

static const uint16 attr_flags1118 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1118_0 [] = {230,846,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1118 [] = {
g_atype1118_0,
};

static const long offsets1118 [] =
{
0,
};

extern const char *names1119[];
static const uint32 types1119 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1119 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1119_0 [] = {225,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_1 [] = {0xFF01,1171,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_2 [] = {0xFF01,1003,0xFFF8,1,0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1119 [] = {
g_atype1119_0,
g_atype1119_1,
g_atype1119_2,
};

static const long offsets1119 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1120[];
static const uint32 types1120 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1120 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1120_0 [] = {226,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_1 [] = {0xFF01,1172,0xFFF8,1,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_2 [] = {0xFF01,1004,0xFFF8,1,834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1120 [] = {
g_atype1120_0,
g_atype1120_1,
g_atype1120_2,
};

static const long offsets1120 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1121[];
static const uint32 types1121 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1121 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1121_0 [] = {226,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1121_1 [] = {0xFF01,1173,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1121_2 [] = {0xFF01,1005,834,834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1121 [] = {
g_atype1121_0,
g_atype1121_1,
g_atype1121_2,
};

static const long offsets1121 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1122[];
static const uint32 types1122 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1122 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1122_0 [] = {230,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_1 [] = {0xFF01,1174,843,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_2 [] = {0xFF01,1006,843,846,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1122 [] = {
g_atype1122_0,
g_atype1122_1,
g_atype1122_2,
};

static const long offsets1122 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1123[];
static const uint32 types1123 [] =
{
SK_REF,
};

static const uint16 attr_flags1123 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1123_0 [] = {225,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1123 [] = {
g_atype1123_0,
};

static const long offsets1123 [] =
{
0,
};

extern const char *names1124[];
static const uint32 types1124 [] =
{
SK_REF,
};

static const uint16 attr_flags1124 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1124_0 [] = {225,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1124 [] = {
g_atype1124_0,
};

static const long offsets1124 [] =
{
0,
};

extern const char *names1125[];
static const uint32 types1125 [] =
{
SK_REF,
};

static const uint16 attr_flags1125 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1125_0 [] = {226,834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1125 [] = {
g_atype1125_0,
};

static const long offsets1125 [] =
{
0,
};

extern const char *names1126[];
static const uint32 types1126 [] =
{
SK_REF,
};

static const uint16 attr_flags1126 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1126_0 [] = {229,843,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1126 [] = {
g_atype1126_0,
};

static const long offsets1126 [] =
{
0,
};

extern const char *names1127[];
static const uint32 types1127 [] =
{
SK_REF,
};

static const uint16 attr_flags1127 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1127_0 [] = {225,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1127 [] = {
g_atype1127_0,
};

static const long offsets1127 [] =
{
0,
};

extern const char *names1128[];
static const uint32 types1128 [] =
{
SK_REF,
};

static const uint16 attr_flags1128 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1128_0 [] = {226,834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1128 [] = {
g_atype1128_0,
};

static const long offsets1128 [] =
{
0,
};

extern const char *names1129[];
static const uint32 types1129 [] =
{
SK_REF,
};

static const uint16 attr_flags1129 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1129_0 [] = {227,864,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1129 [] = {
g_atype1129_0,
};

static const long offsets1129 [] =
{
0,
};

extern const char *names1130[];
static const uint32 types1130 [] =
{
SK_REF,
};

static const uint16 attr_flags1130 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1130_0 [] = {228,867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1130 [] = {
g_atype1130_0,
};

static const long offsets1130 [] =
{
0,
};

extern const char *names1131[];
static const uint32 types1131 [] =
{
SK_REF,
};

static const uint16 attr_flags1131 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1131_0 [] = {225,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1131 [] = {
g_atype1131_0,
};

static const long offsets1131 [] =
{
0,
};

extern const char *names1132[];
static const uint32 types1132 [] =
{
SK_REF,
};

static const uint16 attr_flags1132 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1132_0 [] = {226,834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1132 [] = {
g_atype1132_0,
};

static const long offsets1132 [] =
{
0,
};

extern const char *names1133[];
static const uint32 types1133 [] =
{
SK_REF,
};

static const uint16 attr_flags1133 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1133_0 [] = {226,834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1133 [] = {
g_atype1133_0,
};

static const long offsets1133 [] =
{
0,
};

extern const char *names1134[];
static const uint32 types1134 [] =
{
SK_REF,
};

static const uint16 attr_flags1134 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1134_0 [] = {228,867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1134 [] = {
g_atype1134_0,
};

static const long offsets1134 [] =
{
0,
};

extern const char *names1135[];
static const uint32 types1135 [] =
{
SK_REF,
};

static const uint16 attr_flags1135 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1135_0 [] = {226,834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1135 [] = {
g_atype1135_0,
};

static const long offsets1135 [] =
{
0,
};

extern const char *names1136[];
static const uint32 types1136 [] =
{
SK_REF,
};

static const uint16 attr_flags1136 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1136_0 [] = {228,867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1136 [] = {
g_atype1136_0,
};

static const long offsets1136 [] =
{
0,
};

extern const char *names1137[];
static const uint32 types1137 [] =
{
SK_REF,
};

static const uint16 attr_flags1137 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1137_0 [] = {225,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1137 [] = {
g_atype1137_0,
};

static const long offsets1137 [] =
{
0,
};

extern const char *names1138[];
static const uint32 types1138 [] =
{
SK_REF,
};

static const uint16 attr_flags1138 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1138_0 [] = {226,834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1138 [] = {
g_atype1138_0,
};

static const long offsets1138 [] =
{
0,
};

extern const char *names1139[];
static const uint32 types1139 [] =
{
SK_REF,
};

static const uint16 attr_flags1139 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1139_0 [] = {227,864,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1139 [] = {
g_atype1139_0,
};

static const long offsets1139 [] =
{
0,
};

extern const char *names1140[];
static const uint32 types1140 [] =
{
SK_REF,
};

static const uint16 attr_flags1140 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1140_0 [] = {228,867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1140 [] = {
g_atype1140_0,
};

static const long offsets1140 [] =
{
0,
};

extern const char *names1141[];
static const uint32 types1141 [] =
{
SK_REF,
};

static const uint16 attr_flags1141 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1141_0 [] = {225,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1141 [] = {
g_atype1141_0,
};

static const long offsets1141 [] =
{
0,
};

extern const char *names1142[];
static const uint32 types1142 [] =
{
SK_REF,
};

static const uint16 attr_flags1142 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1142_0 [] = {226,834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1142 [] = {
g_atype1142_0,
};

static const long offsets1142 [] =
{
0,
};

extern const char *names1143[];
static const uint32 types1143 [] =
{
SK_REF,
};

static const uint16 attr_flags1143 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1143_0 [] = {227,864,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1143 [] = {
g_atype1143_0,
};

static const long offsets1143 [] =
{
0,
};

extern const char *names1144[];
static const uint32 types1144 [] =
{
SK_REF,
};

static const uint16 attr_flags1144 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1144_0 [] = {228,867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1144 [] = {
g_atype1144_0,
};

static const long offsets1144 [] =
{
0,
};

extern const char *names1145[];
static const uint32 types1145 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1145 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1145_0 [] = {225,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1145_1 [] = {153,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1145_2 [] = {153,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1145_3 [] = {0xFF01,1039,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1145_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1145 [] = {
g_atype1145_0,
g_atype1145_1,
g_atype1145_2,
g_atype1145_3,
g_atype1145_4,
};

static const long offsets1145 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
};

extern const char *names1146[];
static const uint32 types1146 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1146 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1146_0 [] = {227,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1146_1 [] = {154,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1146_2 [] = {154,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1146_3 [] = {0xFF01,1040,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1146_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1146 [] = {
g_atype1146_0,
g_atype1146_1,
g_atype1146_2,
g_atype1146_3,
g_atype1146_4,
};

static const long offsets1146 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
};

extern const char *names1147[];
static const uint32 types1147 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1147 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1147_0 [] = {228,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1147_1 [] = {156,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1147_2 [] = {156,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1147_3 [] = {0xFF01,1041,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1147_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1147 [] = {
g_atype1147_0,
g_atype1147_1,
g_atype1147_2,
g_atype1147_3,
g_atype1147_4,
};

static const long offsets1147 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
};

extern const char *names1148[];
static const uint32 types1148 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1148 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1148_0 [] = {226,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1148_1 [] = {155,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1148_2 [] = {155,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1148_3 [] = {0xFF01,1042,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1148_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1148 [] = {
g_atype1148_0,
g_atype1148_1,
g_atype1148_2,
g_atype1148_3,
g_atype1148_4,
};

static const long offsets1148 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
};

extern const char *names1149[];
static const uint32 types1149 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1149 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1149_0 [] = {225,0xFF01,1066,0xFF01,1069,0xFFFF};
static const EIF_TYPE_INDEX g_atype1149_1 [] = {153,0xFF01,1066,0xFF01,1069,0xFFFF};
static const EIF_TYPE_INDEX g_atype1149_2 [] = {153,0xFF01,1066,0xFF01,1069,0xFFFF};
static const EIF_TYPE_INDEX g_atype1149_3 [] = {0xFF01,1039,0xFF01,1066,0xFF01,1069,0xFFFF};
static const EIF_TYPE_INDEX g_atype1149_4 [] = {95,0xFFFF};
static const EIF_TYPE_INDEX g_atype1149_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1149 [] = {
g_atype1149_0,
g_atype1149_1,
g_atype1149_2,
g_atype1149_3,
g_atype1149_4,
g_atype1149_5,
};

static const long offsets1149 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @LNGOFF(5,0,0,0),
};

extern const char *names1150[];
static const uint32 types1150 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1150 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1150_0 [] = {225,0xFF01,115,0xFFFF};
static const EIF_TYPE_INDEX g_atype1150_1 [] = {153,0xFF01,115,0xFFFF};
static const EIF_TYPE_INDEX g_atype1150_2 [] = {153,0xFF01,115,0xFFFF};
static const EIF_TYPE_INDEX g_atype1150_3 [] = {0xFF01,1039,0xFF01,115,0xFFFF};
static const EIF_TYPE_INDEX g_atype1150_4 [] = {0xFF01,115,0xFFFF};
static const EIF_TYPE_INDEX g_atype1150_5 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1150_6 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1150 [] = {
g_atype1150_0,
g_atype1150_1,
g_atype1150_2,
g_atype1150_3,
g_atype1150_4,
g_atype1150_5,
g_atype1150_6,
};

static const long offsets1150 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @LNGOFF(6,0,0,0),
};

extern const char *names1151[];
static const uint32 types1151 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1151 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1151_0 [] = {225,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1151_1 [] = {157,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1151_2 [] = {157,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1151_3 [] = {0xFF01,1043,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1151_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1151 [] = {
g_atype1151_0,
g_atype1151_1,
g_atype1151_2,
g_atype1151_3,
g_atype1151_4,
};

static const long offsets1151 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
};

extern const char *names1152[];
static const uint32 types1152 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1152 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1152_0 [] = {225,0xFF01,47,0xFFFF};
static const EIF_TYPE_INDEX g_atype1152_1 [] = {157,0xFF01,47,0xFFFF};
static const EIF_TYPE_INDEX g_atype1152_2 [] = {157,0xFF01,47,0xFFFF};
static const EIF_TYPE_INDEX g_atype1152_3 [] = {0xFF01,1043,0xFF01,47,0xFFFF};
static const EIF_TYPE_INDEX g_atype1152_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1152 [] = {
g_atype1152_0,
g_atype1152_1,
g_atype1152_2,
g_atype1152_3,
g_atype1152_4,
};

static const long offsets1152 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
};

extern const char *names1157[];
static const uint32 types1157 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1157 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1157_0 [] = {226,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_1 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_2 [] = {0xFF01,20,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1157 [] = {
g_atype1157_0,
g_atype1157_1,
g_atype1157_2,
g_atype1157_3,
g_atype1157_4,
};

static const long offsets1157 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
};

extern const char *names1158[];
static const uint32 types1158 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1158 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1158_0 [] = {228,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_1 [] = {0xFF01,679,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_2 [] = {0xFF01,21,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1158 [] = {
g_atype1158_0,
g_atype1158_1,
g_atype1158_2,
g_atype1158_3,
g_atype1158_4,
};

static const long offsets1158 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
};

extern const char *names1159[];
static const uint32 types1159 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1159 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1159_0 [] = {225,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_1 [] = {0xFF01,676,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_2 [] = {0xFF01,19,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_3 [] = {0xFF01,1037,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1159 [] = {
g_atype1159_0,
g_atype1159_1,
g_atype1159_2,
g_atype1159_3,
g_atype1159_4,
g_atype1159_5,
};

static const long offsets1159 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
};

extern const char *names1160[];
static const uint32 types1160 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1160 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1160_0 [] = {226,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_1 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_2 [] = {0xFF01,20,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_3 [] = {0xFF01,1038,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1160 [] = {
g_atype1160_0,
g_atype1160_1,
g_atype1160_2,
g_atype1160_3,
g_atype1160_4,
g_atype1160_5,
};

static const long offsets1160 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
};

extern const char *names1161[];
static const uint32 types1161 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1161 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1161_0 [] = {225,0xFF01,44,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_1 [] = {0xFF01,676,0xFF01,44,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_2 [] = {0xFF01,19,0xFF01,44,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_3 [] = {0xFF01,1037,0xFF01,44,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1161 [] = {
g_atype1161_0,
g_atype1161_1,
g_atype1161_2,
g_atype1161_3,
g_atype1161_4,
g_atype1161_5,
};

static const long offsets1161 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
};

extern const char *names1162[];
static const uint32 types1162 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1162 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1162_0 [] = {225,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_1 [] = {0xFF01,1011,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_10 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1162 [] = {
g_atype1162_0,
g_atype1162_1,
g_atype1162_2,
g_atype1162_3,
g_atype1162_4,
g_atype1162_5,
g_atype1162_6,
g_atype1162_7,
g_atype1162_8,
g_atype1162_9,
g_atype1162_10,
};

static const long offsets1162 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
+ @LNGOFF(2,0,0,7),
+ @LNGOFF(2,0,0,8),
};

extern const char *names1163[];
static const uint32 types1163 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1163 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1163_0 [] = {225,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_1 [] = {0xFF01,1012,0xFFF8,1,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_10 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1163 [] = {
g_atype1163_0,
g_atype1163_1,
g_atype1163_2,
g_atype1163_3,
g_atype1163_4,
g_atype1163_5,
g_atype1163_6,
g_atype1163_7,
g_atype1163_8,
g_atype1163_9,
g_atype1163_10,
};

static const long offsets1163 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
+ @LNGOFF(2,0,0,7),
+ @LNGOFF(2,0,0,8),
};

extern const char *names1164[];
static const uint32 types1164 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1164 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1164_0 [] = {226,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_1 [] = {0xFF01,1013,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_10 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1164 [] = {
g_atype1164_0,
g_atype1164_1,
g_atype1164_2,
g_atype1164_3,
g_atype1164_4,
g_atype1164_5,
g_atype1164_6,
g_atype1164_7,
g_atype1164_8,
g_atype1164_9,
g_atype1164_10,
};

static const long offsets1164 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
+ @LNGOFF(2,0,0,7),
+ @LNGOFF(2,0,0,8),
};

extern const char *names1165[];
static const uint32 types1165 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1165 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1165_0 [] = {229,843,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_1 [] = {0xFF01,1014,843,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_10 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1165 [] = {
g_atype1165_0,
g_atype1165_1,
g_atype1165_2,
g_atype1165_3,
g_atype1165_4,
g_atype1165_5,
g_atype1165_6,
g_atype1165_7,
g_atype1165_8,
g_atype1165_9,
g_atype1165_10,
};

static const long offsets1165 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
+ @LNGOFF(2,0,0,7),
+ @LNGOFF(2,0,0,8),
};

extern const char *names1166[];
static const uint32 types1166 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1166 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1166_0 [] = {225,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_1 [] = {0xFF01,1015,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_10 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1166 [] = {
g_atype1166_0,
g_atype1166_1,
g_atype1166_2,
g_atype1166_3,
g_atype1166_4,
g_atype1166_5,
g_atype1166_6,
g_atype1166_7,
g_atype1166_8,
g_atype1166_9,
g_atype1166_10,
};

static const long offsets1166 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
+ @LNGOFF(2,0,0,7),
+ @LNGOFF(2,0,0,8),
};

extern const char *names1167[];
static const uint32 types1167 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1167 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1167_0 [] = {226,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_1 [] = {0xFF01,1016,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_10 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1167 [] = {
g_atype1167_0,
g_atype1167_1,
g_atype1167_2,
g_atype1167_3,
g_atype1167_4,
g_atype1167_5,
g_atype1167_6,
g_atype1167_7,
g_atype1167_8,
g_atype1167_9,
g_atype1167_10,
};

static const long offsets1167 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
+ @LNGOFF(2,0,0,7),
+ @LNGOFF(2,0,0,8),
};

extern const char *names1168[];
static const uint32 types1168 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1168 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1168_0 [] = {225,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_1 [] = {0xFF01,1017,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_2 [] = {0xFF01,676,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_3 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_4 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_5 [] = {0xFF01,19,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_10 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_11 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_12 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_13 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_14 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1168 [] = {
g_atype1168_0,
g_atype1168_1,
g_atype1168_2,
g_atype1168_3,
g_atype1168_4,
g_atype1168_5,
g_atype1168_6,
g_atype1168_7,
g_atype1168_8,
g_atype1168_9,
g_atype1168_10,
g_atype1168_11,
g_atype1168_12,
g_atype1168_13,
g_atype1168_14,
};

static const long offsets1168 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @LNGOFF(6,0,0,0),
+ @LNGOFF(6,0,0,1),
+ @LNGOFF(6,0,0,2),
+ @LNGOFF(6,0,0,3),
+ @LNGOFF(6,0,0,4),
+ @LNGOFF(6,0,0,5),
+ @LNGOFF(6,0,0,6),
+ @LNGOFF(6,0,0,7),
+ @LNGOFF(6,0,0,8),
};

extern const char *names1169[];
static const uint32 types1169 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1169 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1169_0 [] = {226,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1169_1 [] = {0xFF01,1018,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1169_2 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1169_3 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1169_4 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1169_5 [] = {0xFF01,20,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1169_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1169_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1169_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1169_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1169_10 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1169_11 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1169_12 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1169_13 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1169_14 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1169 [] = {
g_atype1169_0,
g_atype1169_1,
g_atype1169_2,
g_atype1169_3,
g_atype1169_4,
g_atype1169_5,
g_atype1169_6,
g_atype1169_7,
g_atype1169_8,
g_atype1169_9,
g_atype1169_10,
g_atype1169_11,
g_atype1169_12,
g_atype1169_13,
g_atype1169_14,
};

static const long offsets1169 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @LNGOFF(6,0,0,0),
+ @LNGOFF(6,0,0,1),
+ @LNGOFF(6,0,0,2),
+ @LNGOFF(6,0,0,3),
+ @LNGOFF(6,0,0,4),
+ @LNGOFF(6,0,0,5),
+ @LNGOFF(6,0,0,6),
+ @LNGOFF(6,0,0,7),
+ @LNGOFF(6,0,0,8),
};

extern const char *names1170[];
static const uint32 types1170 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1170 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1170_0 [] = {225,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_1 [] = {0xFF01,1019,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_2 [] = {0xFF01,676,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_3 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_4 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_5 [] = {0xFF01,19,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_6 [] = {12,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_10 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_11 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_12 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_13 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_14 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_15 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1170 [] = {
g_atype1170_0,
g_atype1170_1,
g_atype1170_2,
g_atype1170_3,
g_atype1170_4,
g_atype1170_5,
g_atype1170_6,
g_atype1170_7,
g_atype1170_8,
g_atype1170_9,
g_atype1170_10,
g_atype1170_11,
g_atype1170_12,
g_atype1170_13,
g_atype1170_14,
g_atype1170_15,
};

static const long offsets1170 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @LNGOFF(7,0,0,0),
+ @LNGOFF(7,0,0,1),
+ @LNGOFF(7,0,0,2),
+ @LNGOFF(7,0,0,3),
+ @LNGOFF(7,0,0,4),
+ @LNGOFF(7,0,0,5),
+ @LNGOFF(7,0,0,6),
+ @LNGOFF(7,0,0,7),
+ @LNGOFF(7,0,0,8),
};

extern const char *names1171[];
static const uint32 types1171 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1171 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1171_0 [] = {226,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_1 [] = {0xFF01,1020,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_2 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_3 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_4 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_5 [] = {0xFF01,20,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_6 [] = {13,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_10 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_11 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_12 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_13 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_14 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_15 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1171 [] = {
g_atype1171_0,
g_atype1171_1,
g_atype1171_2,
g_atype1171_3,
g_atype1171_4,
g_atype1171_5,
g_atype1171_6,
g_atype1171_7,
g_atype1171_8,
g_atype1171_9,
g_atype1171_10,
g_atype1171_11,
g_atype1171_12,
g_atype1171_13,
g_atype1171_14,
g_atype1171_15,
};

static const long offsets1171 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @LNGOFF(7,0,0,0),
+ @LNGOFF(7,0,0,1),
+ @LNGOFF(7,0,0,2),
+ @LNGOFF(7,0,0,3),
+ @LNGOFF(7,0,0,4),
+ @LNGOFF(7,0,0,5),
+ @LNGOFF(7,0,0,6),
+ @LNGOFF(7,0,0,7),
+ @LNGOFF(7,0,0,8),
};

extern const char *names1172[];
static const uint32 types1172 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1172 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1172_0 [] = {225,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_1 [] = {0xFF01,1021,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_2 [] = {1118,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_3 [] = {225,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_10 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_11 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_12 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1172 [] = {
g_atype1172_0,
g_atype1172_1,
g_atype1172_2,
g_atype1172_3,
g_atype1172_4,
g_atype1172_5,
g_atype1172_6,
g_atype1172_7,
g_atype1172_8,
g_atype1172_9,
g_atype1172_10,
g_atype1172_11,
g_atype1172_12,
};

static const long offsets1172 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
+ @LNGOFF(4,0,0,2),
+ @LNGOFF(4,0,0,3),
+ @LNGOFF(4,0,0,4),
+ @LNGOFF(4,0,0,5),
+ @LNGOFF(4,0,0,6),
+ @LNGOFF(4,0,0,7),
+ @LNGOFF(4,0,0,8),
};

extern const char *names1173[];
static const uint32 types1173 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1173 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1173_0 [] = {225,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_1 [] = {0xFF01,1022,0xFFF8,1,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_2 [] = {1119,0xFFF8,1,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_3 [] = {226,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_10 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_11 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_12 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1173 [] = {
g_atype1173_0,
g_atype1173_1,
g_atype1173_2,
g_atype1173_3,
g_atype1173_4,
g_atype1173_5,
g_atype1173_6,
g_atype1173_7,
g_atype1173_8,
g_atype1173_9,
g_atype1173_10,
g_atype1173_11,
g_atype1173_12,
};

static const long offsets1173 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
+ @LNGOFF(4,0,0,2),
+ @LNGOFF(4,0,0,3),
+ @LNGOFF(4,0,0,4),
+ @LNGOFF(4,0,0,5),
+ @LNGOFF(4,0,0,6),
+ @LNGOFF(4,0,0,7),
+ @LNGOFF(4,0,0,8),
};

extern const char *names1174[];
static const uint32 types1174 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1174 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1174_0 [] = {226,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_1 [] = {0xFF01,1023,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_2 [] = {1120,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_3 [] = {226,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_10 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_11 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_12 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1174 [] = {
g_atype1174_0,
g_atype1174_1,
g_atype1174_2,
g_atype1174_3,
g_atype1174_4,
g_atype1174_5,
g_atype1174_6,
g_atype1174_7,
g_atype1174_8,
g_atype1174_9,
g_atype1174_10,
g_atype1174_11,
g_atype1174_12,
};

static const long offsets1174 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
+ @LNGOFF(4,0,0,2),
+ @LNGOFF(4,0,0,3),
+ @LNGOFF(4,0,0,4),
+ @LNGOFF(4,0,0,5),
+ @LNGOFF(4,0,0,6),
+ @LNGOFF(4,0,0,7),
+ @LNGOFF(4,0,0,8),
};

extern const char *names1175[];
static const uint32 types1175 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1175 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1175_0 [] = {229,843,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_1 [] = {0xFF01,1024,843,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_2 [] = {1121,843,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_3 [] = {230,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_7 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_8 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_10 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_11 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_12 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1175 [] = {
g_atype1175_0,
g_atype1175_1,
g_atype1175_2,
g_atype1175_3,
g_atype1175_4,
g_atype1175_5,
g_atype1175_6,
g_atype1175_7,
g_atype1175_8,
g_atype1175_9,
g_atype1175_10,
g_atype1175_11,
g_atype1175_12,
};

static const long offsets1175 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
+ @LNGOFF(4,0,0,2),
+ @LNGOFF(4,0,0,3),
+ @LNGOFF(4,0,0,4),
+ @LNGOFF(4,0,0,5),
+ @LNGOFF(4,0,0,6),
+ @LNGOFF(4,0,0,7),
+ @LNGOFF(4,0,0,8),
};

extern const char *names1176[];
static const uint32 types1176 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1176 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1176_0 [] = {225,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_1 [] = {0xFF01,1025,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_2 [] = {1118,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_3 [] = {225,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_4 [] = {0xFF01,676,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_5 [] = {0xFF01,676,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_6 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_7 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_8 [] = {0xFF01,19,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_9 [] = {0xFF01,19,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_10 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_11 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_12 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_13 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_14 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_15 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_16 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_17 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_18 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1176 [] = {
g_atype1176_0,
g_atype1176_1,
g_atype1176_2,
g_atype1176_3,
g_atype1176_4,
g_atype1176_5,
g_atype1176_6,
g_atype1176_7,
g_atype1176_8,
g_atype1176_9,
g_atype1176_10,
g_atype1176_11,
g_atype1176_12,
g_atype1176_13,
g_atype1176_14,
g_atype1176_15,
g_atype1176_16,
g_atype1176_17,
g_atype1176_18,
};

static const long offsets1176 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @LNGOFF(10,0,0,0),
+ @LNGOFF(10,0,0,1),
+ @LNGOFF(10,0,0,2),
+ @LNGOFF(10,0,0,3),
+ @LNGOFF(10,0,0,4),
+ @LNGOFF(10,0,0,5),
+ @LNGOFF(10,0,0,6),
+ @LNGOFF(10,0,0,7),
+ @LNGOFF(10,0,0,8),
};

extern const char *names1177[];
static const uint32 types1177 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1177 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1177_0 [] = {225,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_1 [] = {0xFF01,1026,0xFFF8,1,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_2 [] = {1119,0xFFF8,1,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_3 [] = {226,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_4 [] = {0xFF01,676,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_5 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_6 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_7 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_8 [] = {0xFF01,19,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_9 [] = {0xFF01,20,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_10 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_11 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_12 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_13 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_14 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_15 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_16 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_17 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_18 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1177 [] = {
g_atype1177_0,
g_atype1177_1,
g_atype1177_2,
g_atype1177_3,
g_atype1177_4,
g_atype1177_5,
g_atype1177_6,
g_atype1177_7,
g_atype1177_8,
g_atype1177_9,
g_atype1177_10,
g_atype1177_11,
g_atype1177_12,
g_atype1177_13,
g_atype1177_14,
g_atype1177_15,
g_atype1177_16,
g_atype1177_17,
g_atype1177_18,
};

static const long offsets1177 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @LNGOFF(10,0,0,0),
+ @LNGOFF(10,0,0,1),
+ @LNGOFF(10,0,0,2),
+ @LNGOFF(10,0,0,3),
+ @LNGOFF(10,0,0,4),
+ @LNGOFF(10,0,0,5),
+ @LNGOFF(10,0,0,6),
+ @LNGOFF(10,0,0,7),
+ @LNGOFF(10,0,0,8),
};

extern const char *names1178[];
static const uint32 types1178 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1178 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1178_0 [] = {226,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_1 [] = {0xFF01,1027,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_2 [] = {1120,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_3 [] = {226,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_4 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_5 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_6 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_7 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_8 [] = {0xFF01,20,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_9 [] = {0xFF01,20,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_10 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_11 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_12 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_13 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_14 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_15 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_16 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_17 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_18 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1178 [] = {
g_atype1178_0,
g_atype1178_1,
g_atype1178_2,
g_atype1178_3,
g_atype1178_4,
g_atype1178_5,
g_atype1178_6,
g_atype1178_7,
g_atype1178_8,
g_atype1178_9,
g_atype1178_10,
g_atype1178_11,
g_atype1178_12,
g_atype1178_13,
g_atype1178_14,
g_atype1178_15,
g_atype1178_16,
g_atype1178_17,
g_atype1178_18,
};

static const long offsets1178 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @LNGOFF(10,0,0,0),
+ @LNGOFF(10,0,0,1),
+ @LNGOFF(10,0,0,2),
+ @LNGOFF(10,0,0,3),
+ @LNGOFF(10,0,0,4),
+ @LNGOFF(10,0,0,5),
+ @LNGOFF(10,0,0,6),
+ @LNGOFF(10,0,0,7),
+ @LNGOFF(10,0,0,8),
};

extern const char *names1179[];
static const uint32 types1179 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1179 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1179_0 [] = {229,843,0xFFFF};
static const EIF_TYPE_INDEX g_atype1179_1 [] = {0xFF01,1028,843,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1179_2 [] = {1121,843,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1179_3 [] = {230,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1179_4 [] = {0xFF01,681,843,0xFFFF};
static const EIF_TYPE_INDEX g_atype1179_5 [] = {0xFF01,687,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1179_6 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1179_7 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1179_8 [] = {0xFF01,23,843,0xFFFF};
static const EIF_TYPE_INDEX g_atype1179_9 [] = {0xFF01,22,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1179_10 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1179_11 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1179_12 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1179_13 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1179_14 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1179_15 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1179_16 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1179_17 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1179_18 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1179 [] = {
g_atype1179_0,
g_atype1179_1,
g_atype1179_2,
g_atype1179_3,
g_atype1179_4,
g_atype1179_5,
g_atype1179_6,
g_atype1179_7,
g_atype1179_8,
g_atype1179_9,
g_atype1179_10,
g_atype1179_11,
g_atype1179_12,
g_atype1179_13,
g_atype1179_14,
g_atype1179_15,
g_atype1179_16,
g_atype1179_17,
g_atype1179_18,
};

static const long offsets1179 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @LNGOFF(10,0,0,0),
+ @LNGOFF(10,0,0,1),
+ @LNGOFF(10,0,0,2),
+ @LNGOFF(10,0,0,3),
+ @LNGOFF(10,0,0,4),
+ @LNGOFF(10,0,0,5),
+ @LNGOFF(10,0,0,6),
+ @LNGOFF(10,0,0,7),
+ @LNGOFF(10,0,0,8),
};

extern const char *names1180[];
static const uint32 types1180 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1180 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1180_0 [] = {225,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_1 [] = {0xFF01,1029,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_2 [] = {1118,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_3 [] = {225,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_4 [] = {0xFF01,676,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_5 [] = {0xFF01,676,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_6 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_7 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_8 [] = {0xFF01,19,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_9 [] = {0xFF01,19,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_10 [] = {12,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_11 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_12 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_13 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_14 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_15 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_16 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_17 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_18 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_19 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1180 [] = {
g_atype1180_0,
g_atype1180_1,
g_atype1180_2,
g_atype1180_3,
g_atype1180_4,
g_atype1180_5,
g_atype1180_6,
g_atype1180_7,
g_atype1180_8,
g_atype1180_9,
g_atype1180_10,
g_atype1180_11,
g_atype1180_12,
g_atype1180_13,
g_atype1180_14,
g_atype1180_15,
g_atype1180_16,
g_atype1180_17,
g_atype1180_18,
g_atype1180_19,
};

static const long offsets1180 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @LNGOFF(11,0,0,0),
+ @LNGOFF(11,0,0,1),
+ @LNGOFF(11,0,0,2),
+ @LNGOFF(11,0,0,3),
+ @LNGOFF(11,0,0,4),
+ @LNGOFF(11,0,0,5),
+ @LNGOFF(11,0,0,6),
+ @LNGOFF(11,0,0,7),
+ @LNGOFF(11,0,0,8),
};

extern const char *names1181[];
static const uint32 types1181 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1181 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1181_0 [] = {225,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_1 [] = {0xFF01,1030,0xFFF8,1,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_2 [] = {1119,0xFFF8,1,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_3 [] = {226,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_4 [] = {0xFF01,676,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_5 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_6 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_7 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_8 [] = {0xFF01,19,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_9 [] = {0xFF01,20,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_10 [] = {13,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_11 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_12 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_13 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_14 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_15 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_16 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_17 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_18 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_19 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1181 [] = {
g_atype1181_0,
g_atype1181_1,
g_atype1181_2,
g_atype1181_3,
g_atype1181_4,
g_atype1181_5,
g_atype1181_6,
g_atype1181_7,
g_atype1181_8,
g_atype1181_9,
g_atype1181_10,
g_atype1181_11,
g_atype1181_12,
g_atype1181_13,
g_atype1181_14,
g_atype1181_15,
g_atype1181_16,
g_atype1181_17,
g_atype1181_18,
g_atype1181_19,
};

static const long offsets1181 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @LNGOFF(11,0,0,0),
+ @LNGOFF(11,0,0,1),
+ @LNGOFF(11,0,0,2),
+ @LNGOFF(11,0,0,3),
+ @LNGOFF(11,0,0,4),
+ @LNGOFF(11,0,0,5),
+ @LNGOFF(11,0,0,6),
+ @LNGOFF(11,0,0,7),
+ @LNGOFF(11,0,0,8),
};

extern const char *names1182[];
static const uint32 types1182 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1182 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1182_0 [] = {226,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_1 [] = {0xFF01,1031,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_2 [] = {1120,834,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_3 [] = {226,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_4 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_5 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_6 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_7 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_8 [] = {0xFF01,20,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_9 [] = {0xFF01,20,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_10 [] = {13,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_11 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_12 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_13 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_14 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_15 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_16 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_17 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_18 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_19 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1182 [] = {
g_atype1182_0,
g_atype1182_1,
g_atype1182_2,
g_atype1182_3,
g_atype1182_4,
g_atype1182_5,
g_atype1182_6,
g_atype1182_7,
g_atype1182_8,
g_atype1182_9,
g_atype1182_10,
g_atype1182_11,
g_atype1182_12,
g_atype1182_13,
g_atype1182_14,
g_atype1182_15,
g_atype1182_16,
g_atype1182_17,
g_atype1182_18,
g_atype1182_19,
};

static const long offsets1182 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @LNGOFF(11,0,0,0),
+ @LNGOFF(11,0,0,1),
+ @LNGOFF(11,0,0,2),
+ @LNGOFF(11,0,0,3),
+ @LNGOFF(11,0,0,4),
+ @LNGOFF(11,0,0,5),
+ @LNGOFF(11,0,0,6),
+ @LNGOFF(11,0,0,7),
+ @LNGOFF(11,0,0,8),
};

extern const char *names1183[];
static const uint32 types1183 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1183 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1183_0 [] = {229,843,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_1 [] = {0xFF01,1032,843,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_2 [] = {1121,843,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_3 [] = {230,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_4 [] = {0xFF01,681,843,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_5 [] = {0xFF01,687,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_6 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_7 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_8 [] = {0xFF01,23,843,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_9 [] = {0xFF01,22,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_10 [] = {14,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_11 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_12 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_13 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_14 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_15 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_16 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_17 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_18 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_19 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1183 [] = {
g_atype1183_0,
g_atype1183_1,
g_atype1183_2,
g_atype1183_3,
g_atype1183_4,
g_atype1183_5,
g_atype1183_6,
g_atype1183_7,
g_atype1183_8,
g_atype1183_9,
g_atype1183_10,
g_atype1183_11,
g_atype1183_12,
g_atype1183_13,
g_atype1183_14,
g_atype1183_15,
g_atype1183_16,
g_atype1183_17,
g_atype1183_18,
g_atype1183_19,
};

static const long offsets1183 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @LNGOFF(11,0,0,0),
+ @LNGOFF(11,0,0,1),
+ @LNGOFF(11,0,0,2),
+ @LNGOFF(11,0,0,3),
+ @LNGOFF(11,0,0,4),
+ @LNGOFF(11,0,0,5),
+ @LNGOFF(11,0,0,6),
+ @LNGOFF(11,0,0,7),
+ @LNGOFF(11,0,0,8),
};

extern const char *names1184[];
static const uint32 types1184 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1184 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1184_0 [] = {0xFF01,687,846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1184_1 [] = {0xFF01,687,846,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1184 [] = {
g_atype1184_0,
g_atype1184_1,
};

static const long offsets1184 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1186[];
static const uint32 types1186 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1186 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1186_0 [] = {274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1186_1 [] = {274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1186_2 [] = {274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1186_3 [] = {767,0xFF01,0xFFF9,2,828,0xFF01,274,773,0xFF01,0xFFF9,2,828,0xFF01,276,0xFF01,276,0xFFFF};
static const EIF_TYPE_INDEX g_atype1186_4 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1186_5 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1186_6 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1186_7 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1186_8 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1186_9 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1186_10 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1186 [] = {
g_atype1186_0,
g_atype1186_1,
g_atype1186_2,
g_atype1186_3,
g_atype1186_4,
g_atype1186_5,
g_atype1186_6,
g_atype1186_7,
g_atype1186_8,
g_atype1186_9,
g_atype1186_10,
};

static const long offsets1186 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @LNGOFF(4,5,0,0),
+ @LNGOFF(4,5,0,1),
};

extern const char *names1192[];
static const uint32 types1192 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1192 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1192_0 [] = {0xFF01,926,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_1 [] = {0xFF01,926,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_2 [] = {0xFF01,926,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1192 [] = {
g_atype1192_0,
g_atype1192_1,
g_atype1192_2,
};

static const long offsets1192 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1193[];
static const uint32 types1193 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags1193 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1193_0 [] = {0xFF01,926,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_1 [] = {0xFF01,926,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_2 [] = {0xFF01,926,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_3 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1193 [] = {
g_atype1193_0,
g_atype1193_1,
g_atype1193_2,
g_atype1193_3,
};

static const long offsets1193 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
};

extern const char *names1194[];
static const uint32 types1194 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1194 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1194_0 [] = {0xFF01,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1194_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1194_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1194_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1194 [] = {
g_atype1194_0,
g_atype1194_1,
g_atype1194_2,
g_atype1194_3,
};

static const long offsets1194 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names1195[];
static const uint32 types1195 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1195 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1195_0 [] = {0xFF01,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1195_1 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1195_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1195_3 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1195 [] = {
g_atype1195_0,
g_atype1195_1,
g_atype1195_2,
g_atype1195_3,
};

static const long offsets1195 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names1198[];
static const uint32 types1198 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1198 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1198_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1198_1 [] = {0xFF01,911,0xFFFF};
static const EIF_TYPE_INDEX g_atype1198_2 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1198_3 [] = {0xFF01,796,0xFFFF};
static const EIF_TYPE_INDEX g_atype1198_4 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1198 [] = {
g_atype1198_0,
g_atype1198_1,
g_atype1198_2,
g_atype1198_3,
g_atype1198_4,
};

static const long offsets1198 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
};

extern const char *names1199[];
static const uint32 types1199 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1199 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1199_0 [] = {0xFF01,165,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_1 [] = {0xFF01,92,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_2 [] = {682,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_3 [] = {680,861,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_4 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_5 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_6 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_7 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_8 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_9 [] = {677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_10 [] = {677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_11 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_12 [] = {677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_13 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_14 [] = {0xFF01,45,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_15 [] = {0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_16 [] = {0xFF01,1169,0xFF01,796,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_17 [] = {0xFF01,1179,0xFF01,796,0xFF01,911,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_18 [] = {0xFF01,1169,0xFF01,796,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_19 [] = {0xFF01,1179,0xFF01,796,0xFF01,911,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_20 [] = {0xFF01,1179,0xFF01,911,0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_21 [] = {0xFF01,1157,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_22 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_23 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_24 [] = {0xFF01,911,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_25 [] = {0xFF01,796,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_26 [] = {0xFF01,911,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_27 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_28 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_29 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_30 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_31 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_32 [] = {861,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_33 [] = {861,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_34 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_35 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_36 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_37 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_38 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_39 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_40 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_41 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_42 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_43 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_44 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_45 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_46 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_47 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_48 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_49 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_50 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_51 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_52 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_53 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_54 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_55 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_56 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_57 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_58 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1199 [] = {
g_atype1199_0,
g_atype1199_1,
g_atype1199_2,
g_atype1199_3,
g_atype1199_4,
g_atype1199_5,
g_atype1199_6,
g_atype1199_7,
g_atype1199_8,
g_atype1199_9,
g_atype1199_10,
g_atype1199_11,
g_atype1199_12,
g_atype1199_13,
g_atype1199_14,
g_atype1199_15,
g_atype1199_16,
g_atype1199_17,
g_atype1199_18,
g_atype1199_19,
g_atype1199_20,
g_atype1199_21,
g_atype1199_22,
g_atype1199_23,
g_atype1199_24,
g_atype1199_25,
g_atype1199_26,
g_atype1199_27,
g_atype1199_28,
g_atype1199_29,
g_atype1199_30,
g_atype1199_31,
g_atype1199_32,
g_atype1199_33,
g_atype1199_34,
g_atype1199_35,
g_atype1199_36,
g_atype1199_37,
g_atype1199_38,
g_atype1199_39,
g_atype1199_40,
g_atype1199_41,
g_atype1199_42,
g_atype1199_43,
g_atype1199_44,
g_atype1199_45,
g_atype1199_46,
g_atype1199_47,
g_atype1199_48,
g_atype1199_49,
g_atype1199_50,
g_atype1199_51,
g_atype1199_52,
g_atype1199_53,
g_atype1199_54,
g_atype1199_55,
g_atype1199_56,
g_atype1199_57,
g_atype1199_58,
};

static const long offsets1199 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
 + @REFACS(27),
+ @CHROFF(28,0),
+ @CHROFF(28,1),
+ @CHROFF(28,2),
+ @CHROFF(28,3),
+ @LNGOFF(28,4,0,0),
+ @LNGOFF(28,4,0,1),
+ @LNGOFF(28,4,0,2),
+ @LNGOFF(28,4,0,3),
+ @LNGOFF(28,4,0,4),
+ @LNGOFF(28,4,0,5),
+ @LNGOFF(28,4,0,6),
+ @LNGOFF(28,4,0,7),
+ @LNGOFF(28,4,0,8),
+ @LNGOFF(28,4,0,9),
+ @LNGOFF(28,4,0,10),
+ @LNGOFF(28,4,0,11),
+ @LNGOFF(28,4,0,12),
+ @LNGOFF(28,4,0,13),
+ @LNGOFF(28,4,0,14),
+ @LNGOFF(28,4,0,15),
+ @LNGOFF(28,4,0,16),
+ @LNGOFF(28,4,0,17),
+ @LNGOFF(28,4,0,18),
+ @LNGOFF(28,4,0,19),
+ @LNGOFF(28,4,0,20),
+ @LNGOFF(28,4,0,21),
+ @LNGOFF(28,4,0,22),
+ @LNGOFF(28,4,0,23),
+ @LNGOFF(28,4,0,24),
+ @LNGOFF(28,4,0,25),
+ @LNGOFF(28,4,0,26),
};

extern const char *names1200[];
static const uint32 types1200 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1200 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1200_0 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_1 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_2 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_3 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_4 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_5 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_6 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_7 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_8 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_9 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_10 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_11 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_12 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_13 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_14 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_15 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_16 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_17 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_18 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_19 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_20 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_21 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_22 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1200 [] = {
g_atype1200_0,
g_atype1200_1,
g_atype1200_2,
g_atype1200_3,
g_atype1200_4,
g_atype1200_5,
g_atype1200_6,
g_atype1200_7,
g_atype1200_8,
g_atype1200_9,
g_atype1200_10,
g_atype1200_11,
g_atype1200_12,
g_atype1200_13,
g_atype1200_14,
g_atype1200_15,
g_atype1200_16,
g_atype1200_17,
g_atype1200_18,
g_atype1200_19,
g_atype1200_20,
g_atype1200_21,
g_atype1200_22,
};

static const long offsets1200 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @CHROFF(11,0),
+ @LNGOFF(11,1,0,0),
+ @LNGOFF(11,1,0,1),
+ @LNGOFF(11,1,0,2),
+ @LNGOFF(11,1,0,3),
+ @LNGOFF(11,1,0,4),
+ @LNGOFF(11,1,0,5),
+ @LNGOFF(11,1,0,6),
+ @LNGOFF(11,1,0,7),
+ @LNGOFF(11,1,0,8),
+ @LNGOFF(11,1,0,9),
+ @LNGOFF(11,1,0,10),
};

extern const char *names1201[];
static const uint32 types1201 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1201 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1201_0 [] = {0xFF01,165,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_1 [] = {0xFF01,92,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_2 [] = {682,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_3 [] = {680,861,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_4 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_5 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_6 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_7 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_8 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_9 [] = {677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_10 [] = {677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_11 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_12 [] = {677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_13 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_14 [] = {0xFF01,45,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_15 [] = {0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_16 [] = {0xFF01,1169,0xFF01,796,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_17 [] = {0xFF01,1179,0xFF01,796,0xFF01,911,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_18 [] = {0xFF01,1169,0xFF01,796,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_19 [] = {0xFF01,1179,0xFF01,796,0xFF01,911,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_20 [] = {0xFF01,1179,0xFF01,911,0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_21 [] = {0xFF01,1157,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_22 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_23 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_24 [] = {0xFF01,911,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_25 [] = {0xFF01,796,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_26 [] = {0xFF01,911,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_27 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_28 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_29 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_30 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_31 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_32 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_33 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_34 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_35 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_36 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_37 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_38 [] = {0xFF01,1158,0xFF01,162,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_39 [] = {0xFF01,1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_40 [] = {0xFF01,6,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_41 [] = {106,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_42 [] = {162,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_43 [] = {0xFF01,1156,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_44 [] = {0xFF01,1156,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_45 [] = {0xFF01,1156,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_46 [] = {0xFF01,1156,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_47 [] = {0xFF01,1156,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_48 [] = {0xFF01,1156,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_49 [] = {0xFF01,1179,0xFF01,1158,0xFF01,1158,0xFF01,796,0xFF01,796,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_50 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_51 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_52 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_53 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_54 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_55 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_56 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_57 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_58 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_59 [] = {861,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_60 [] = {861,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_61 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_62 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_63 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_64 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_65 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_66 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_67 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_68 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_69 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_70 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_71 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_72 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_73 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_74 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_75 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_76 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_77 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_78 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_79 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_80 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_81 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_82 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_83 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_84 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_85 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_86 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_87 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_88 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_89 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_90 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_91 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_92 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_93 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_94 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_95 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_96 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_97 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_98 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_99 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_100 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_101 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_102 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_103 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_104 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_105 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_106 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_107 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_108 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_109 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_110 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_111 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1201 [] = {
g_atype1201_0,
g_atype1201_1,
g_atype1201_2,
g_atype1201_3,
g_atype1201_4,
g_atype1201_5,
g_atype1201_6,
g_atype1201_7,
g_atype1201_8,
g_atype1201_9,
g_atype1201_10,
g_atype1201_11,
g_atype1201_12,
g_atype1201_13,
g_atype1201_14,
g_atype1201_15,
g_atype1201_16,
g_atype1201_17,
g_atype1201_18,
g_atype1201_19,
g_atype1201_20,
g_atype1201_21,
g_atype1201_22,
g_atype1201_23,
g_atype1201_24,
g_atype1201_25,
g_atype1201_26,
g_atype1201_27,
g_atype1201_28,
g_atype1201_29,
g_atype1201_30,
g_atype1201_31,
g_atype1201_32,
g_atype1201_33,
g_atype1201_34,
g_atype1201_35,
g_atype1201_36,
g_atype1201_37,
g_atype1201_38,
g_atype1201_39,
g_atype1201_40,
g_atype1201_41,
g_atype1201_42,
g_atype1201_43,
g_atype1201_44,
g_atype1201_45,
g_atype1201_46,
g_atype1201_47,
g_atype1201_48,
g_atype1201_49,
g_atype1201_50,
g_atype1201_51,
g_atype1201_52,
g_atype1201_53,
g_atype1201_54,
g_atype1201_55,
g_atype1201_56,
g_atype1201_57,
g_atype1201_58,
g_atype1201_59,
g_atype1201_60,
g_atype1201_61,
g_atype1201_62,
g_atype1201_63,
g_atype1201_64,
g_atype1201_65,
g_atype1201_66,
g_atype1201_67,
g_atype1201_68,
g_atype1201_69,
g_atype1201_70,
g_atype1201_71,
g_atype1201_72,
g_atype1201_73,
g_atype1201_74,
g_atype1201_75,
g_atype1201_76,
g_atype1201_77,
g_atype1201_78,
g_atype1201_79,
g_atype1201_80,
g_atype1201_81,
g_atype1201_82,
g_atype1201_83,
g_atype1201_84,
g_atype1201_85,
g_atype1201_86,
g_atype1201_87,
g_atype1201_88,
g_atype1201_89,
g_atype1201_90,
g_atype1201_91,
g_atype1201_92,
g_atype1201_93,
g_atype1201_94,
g_atype1201_95,
g_atype1201_96,
g_atype1201_97,
g_atype1201_98,
g_atype1201_99,
g_atype1201_100,
g_atype1201_101,
g_atype1201_102,
g_atype1201_103,
g_atype1201_104,
g_atype1201_105,
g_atype1201_106,
g_atype1201_107,
g_atype1201_108,
g_atype1201_109,
g_atype1201_110,
g_atype1201_111,
};

static const long offsets1201 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
 + @REFACS(27),
 + @REFACS(28),
 + @REFACS(29),
 + @REFACS(30),
 + @REFACS(31),
 + @REFACS(32),
 + @REFACS(33),
 + @REFACS(34),
 + @REFACS(35),
 + @REFACS(36),
 + @REFACS(37),
 + @REFACS(38),
 + @REFACS(39),
 + @REFACS(40),
 + @REFACS(41),
 + @REFACS(42),
 + @REFACS(43),
 + @REFACS(44),
 + @REFACS(45),
 + @REFACS(46),
 + @REFACS(47),
 + @REFACS(48),
 + @REFACS(49),
 + @REFACS(50),
+ @CHROFF(51,0),
+ @CHROFF(51,1),
+ @CHROFF(51,2),
+ @CHROFF(51,3),
+ @CHROFF(51,4),
+ @CHROFF(51,5),
+ @CHROFF(51,6),
+ @CHROFF(51,7),
+ @LNGOFF(51,8,0,0),
+ @LNGOFF(51,8,0,1),
+ @LNGOFF(51,8,0,2),
+ @LNGOFF(51,8,0,3),
+ @LNGOFF(51,8,0,4),
+ @LNGOFF(51,8,0,5),
+ @LNGOFF(51,8,0,6),
+ @LNGOFF(51,8,0,7),
+ @LNGOFF(51,8,0,8),
+ @LNGOFF(51,8,0,9),
+ @LNGOFF(51,8,0,10),
+ @LNGOFF(51,8,0,11),
+ @LNGOFF(51,8,0,12),
+ @LNGOFF(51,8,0,13),
+ @LNGOFF(51,8,0,14),
+ @LNGOFF(51,8,0,15),
+ @LNGOFF(51,8,0,16),
+ @LNGOFF(51,8,0,17),
+ @LNGOFF(51,8,0,18),
+ @LNGOFF(51,8,0,19),
+ @LNGOFF(51,8,0,20),
+ @LNGOFF(51,8,0,21),
+ @LNGOFF(51,8,0,22),
+ @LNGOFF(51,8,0,23),
+ @LNGOFF(51,8,0,24),
+ @LNGOFF(51,8,0,25),
+ @LNGOFF(51,8,0,26),
+ @LNGOFF(51,8,0,27),
+ @LNGOFF(51,8,0,28),
+ @LNGOFF(51,8,0,29),
+ @LNGOFF(51,8,0,30),
+ @LNGOFF(51,8,0,31),
+ @LNGOFF(51,8,0,32),
+ @LNGOFF(51,8,0,33),
+ @LNGOFF(51,8,0,34),
+ @LNGOFF(51,8,0,35),
+ @LNGOFF(51,8,0,36),
+ @LNGOFF(51,8,0,37),
+ @LNGOFF(51,8,0,38),
+ @LNGOFF(51,8,0,39),
+ @LNGOFF(51,8,0,40),
+ @LNGOFF(51,8,0,41),
+ @LNGOFF(51,8,0,42),
+ @LNGOFF(51,8,0,43),
+ @LNGOFF(51,8,0,44),
+ @LNGOFF(51,8,0,45),
+ @LNGOFF(51,8,0,46),
+ @LNGOFF(51,8,0,47),
+ @LNGOFF(51,8,0,48),
+ @LNGOFF(51,8,0,49),
+ @LNGOFF(51,8,0,50),
+ @LNGOFF(51,8,0,51),
+ @LNGOFF(51,8,0,52),
};

extern const char *names1202[];
static const uint32 types1202 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1202 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1202_0 [] = {0xFF01,165,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_1 [] = {0xFF01,92,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_2 [] = {682,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_3 [] = {680,861,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_4 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_5 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_6 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_7 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_8 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_9 [] = {677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_10 [] = {677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_11 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_12 [] = {677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_13 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_14 [] = {0xFF01,45,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_15 [] = {0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_16 [] = {0xFF01,1169,0xFF01,796,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_17 [] = {0xFF01,1179,0xFF01,796,0xFF01,911,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_18 [] = {0xFF01,1169,0xFF01,796,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_19 [] = {0xFF01,1179,0xFF01,796,0xFF01,911,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_20 [] = {0xFF01,1179,0xFF01,911,0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_21 [] = {0xFF01,1157,867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_22 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_23 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_24 [] = {0xFF01,911,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_25 [] = {0xFF01,796,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_26 [] = {0xFF01,911,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_27 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_28 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_29 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_30 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_31 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_32 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_33 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_34 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_35 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_36 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_37 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_38 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_39 [] = {0xFF01,1158,0xFF01,162,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_40 [] = {0xFF01,1160,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_41 [] = {0xFF01,6,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_42 [] = {106,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_43 [] = {162,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_44 [] = {0xFF01,1156,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_45 [] = {0xFF01,1156,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_46 [] = {0xFF01,1156,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_47 [] = {0xFF01,1156,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_48 [] = {0xFF01,1156,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_49 [] = {0xFF01,1156,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_50 [] = {0xFF01,1179,0xFF01,1158,0xFF01,1158,0xFF01,796,0xFF01,796,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_51 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_52 [] = {0xFF01,676,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_53 [] = {0xFF01,19,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_54 [] = {0xFF01,676,0xFF01,911,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_55 [] = {0xFF01,19,0xFF01,911,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_56 [] = {0xFF01,676,0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_57 [] = {0xFF01,19,0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_58 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_59 [] = {0xFF01,20,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_60 [] = {0xFF01,676,0xFF01,796,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_61 [] = {0xFF01,19,0xFF01,796,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_62 [] = {0xFF01,676,0xFF01,1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_63 [] = {0xFF01,19,0xFF01,1071,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_64 [] = {864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_65 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_66 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_67 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_68 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_69 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_70 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_71 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_72 [] = {861,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_73 [] = {861,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_74 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_75 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_76 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_77 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_78 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_79 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_80 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_81 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_82 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_83 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_84 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_85 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_86 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_87 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_88 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_89 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_90 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_91 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_92 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_93 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_94 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_95 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_96 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_97 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_98 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_99 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_100 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_101 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_102 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_103 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_104 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_105 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_106 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_107 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_108 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_109 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_110 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_111 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_112 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_113 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_114 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_115 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_116 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_117 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_118 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_119 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_120 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_121 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_122 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_123 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_124 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_125 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_126 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_127 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_128 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_129 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_130 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_131 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_132 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_133 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_134 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_135 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_136 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1202 [] = {
g_atype1202_0,
g_atype1202_1,
g_atype1202_2,
g_atype1202_3,
g_atype1202_4,
g_atype1202_5,
g_atype1202_6,
g_atype1202_7,
g_atype1202_8,
g_atype1202_9,
g_atype1202_10,
g_atype1202_11,
g_atype1202_12,
g_atype1202_13,
g_atype1202_14,
g_atype1202_15,
g_atype1202_16,
g_atype1202_17,
g_atype1202_18,
g_atype1202_19,
g_atype1202_20,
g_atype1202_21,
g_atype1202_22,
g_atype1202_23,
g_atype1202_24,
g_atype1202_25,
g_atype1202_26,
g_atype1202_27,
g_atype1202_28,
g_atype1202_29,
g_atype1202_30,
g_atype1202_31,
g_atype1202_32,
g_atype1202_33,
g_atype1202_34,
g_atype1202_35,
g_atype1202_36,
g_atype1202_37,
g_atype1202_38,
g_atype1202_39,
g_atype1202_40,
g_atype1202_41,
g_atype1202_42,
g_atype1202_43,
g_atype1202_44,
g_atype1202_45,
g_atype1202_46,
g_atype1202_47,
g_atype1202_48,
g_atype1202_49,
g_atype1202_50,
g_atype1202_51,
g_atype1202_52,
g_atype1202_53,
g_atype1202_54,
g_atype1202_55,
g_atype1202_56,
g_atype1202_57,
g_atype1202_58,
g_atype1202_59,
g_atype1202_60,
g_atype1202_61,
g_atype1202_62,
g_atype1202_63,
g_atype1202_64,
g_atype1202_65,
g_atype1202_66,
g_atype1202_67,
g_atype1202_68,
g_atype1202_69,
g_atype1202_70,
g_atype1202_71,
g_atype1202_72,
g_atype1202_73,
g_atype1202_74,
g_atype1202_75,
g_atype1202_76,
g_atype1202_77,
g_atype1202_78,
g_atype1202_79,
g_atype1202_80,
g_atype1202_81,
g_atype1202_82,
g_atype1202_83,
g_atype1202_84,
g_atype1202_85,
g_atype1202_86,
g_atype1202_87,
g_atype1202_88,
g_atype1202_89,
g_atype1202_90,
g_atype1202_91,
g_atype1202_92,
g_atype1202_93,
g_atype1202_94,
g_atype1202_95,
g_atype1202_96,
g_atype1202_97,
g_atype1202_98,
g_atype1202_99,
g_atype1202_100,
g_atype1202_101,
g_atype1202_102,
g_atype1202_103,
g_atype1202_104,
g_atype1202_105,
g_atype1202_106,
g_atype1202_107,
g_atype1202_108,
g_atype1202_109,
g_atype1202_110,
g_atype1202_111,
g_atype1202_112,
g_atype1202_113,
g_atype1202_114,
g_atype1202_115,
g_atype1202_116,
g_atype1202_117,
g_atype1202_118,
g_atype1202_119,
g_atype1202_120,
g_atype1202_121,
g_atype1202_122,
g_atype1202_123,
g_atype1202_124,
g_atype1202_125,
g_atype1202_126,
g_atype1202_127,
g_atype1202_128,
g_atype1202_129,
g_atype1202_130,
g_atype1202_131,
g_atype1202_132,
g_atype1202_133,
g_atype1202_134,
g_atype1202_135,
g_atype1202_136,
};

static const long offsets1202 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
 + @REFACS(27),
 + @REFACS(28),
 + @REFACS(29),
 + @REFACS(30),
 + @REFACS(31),
 + @REFACS(32),
 + @REFACS(33),
 + @REFACS(34),
 + @REFACS(35),
 + @REFACS(36),
 + @REFACS(37),
 + @REFACS(38),
 + @REFACS(39),
 + @REFACS(40),
 + @REFACS(41),
 + @REFACS(42),
 + @REFACS(43),
 + @REFACS(44),
 + @REFACS(45),
 + @REFACS(46),
 + @REFACS(47),
 + @REFACS(48),
 + @REFACS(49),
 + @REFACS(50),
 + @REFACS(51),
 + @REFACS(52),
 + @REFACS(53),
 + @REFACS(54),
 + @REFACS(55),
 + @REFACS(56),
 + @REFACS(57),
 + @REFACS(58),
 + @REFACS(59),
 + @REFACS(60),
 + @REFACS(61),
 + @REFACS(62),
 + @REFACS(63),
+ @CHROFF(64,0),
+ @CHROFF(64,1),
+ @CHROFF(64,2),
+ @CHROFF(64,3),
+ @CHROFF(64,4),
+ @CHROFF(64,5),
+ @CHROFF(64,6),
+ @CHROFF(64,7),
+ @LNGOFF(64,8,0,0),
+ @LNGOFF(64,8,0,1),
+ @LNGOFF(64,8,0,2),
+ @LNGOFF(64,8,0,3),
+ @LNGOFF(64,8,0,4),
+ @LNGOFF(64,8,0,5),
+ @LNGOFF(64,8,0,6),
+ @LNGOFF(64,8,0,7),
+ @LNGOFF(64,8,0,8),
+ @LNGOFF(64,8,0,9),
+ @LNGOFF(64,8,0,10),
+ @LNGOFF(64,8,0,11),
+ @LNGOFF(64,8,0,12),
+ @LNGOFF(64,8,0,13),
+ @LNGOFF(64,8,0,14),
+ @LNGOFF(64,8,0,15),
+ @LNGOFF(64,8,0,16),
+ @LNGOFF(64,8,0,17),
+ @LNGOFF(64,8,0,18),
+ @LNGOFF(64,8,0,19),
+ @LNGOFF(64,8,0,20),
+ @LNGOFF(64,8,0,21),
+ @LNGOFF(64,8,0,22),
+ @LNGOFF(64,8,0,23),
+ @LNGOFF(64,8,0,24),
+ @LNGOFF(64,8,0,25),
+ @LNGOFF(64,8,0,26),
+ @LNGOFF(64,8,0,27),
+ @LNGOFF(64,8,0,28),
+ @LNGOFF(64,8,0,29),
+ @LNGOFF(64,8,0,30),
+ @LNGOFF(64,8,0,31),
+ @LNGOFF(64,8,0,32),
+ @LNGOFF(64,8,0,33),
+ @LNGOFF(64,8,0,34),
+ @LNGOFF(64,8,0,35),
+ @LNGOFF(64,8,0,36),
+ @LNGOFF(64,8,0,37),
+ @LNGOFF(64,8,0,38),
+ @LNGOFF(64,8,0,39),
+ @LNGOFF(64,8,0,40),
+ @LNGOFF(64,8,0,41),
+ @LNGOFF(64,8,0,42),
+ @LNGOFF(64,8,0,43),
+ @LNGOFF(64,8,0,44),
+ @LNGOFF(64,8,0,45),
+ @LNGOFF(64,8,0,46),
+ @LNGOFF(64,8,0,47),
+ @LNGOFF(64,8,0,48),
+ @LNGOFF(64,8,0,49),
+ @LNGOFF(64,8,0,50),
+ @LNGOFF(64,8,0,51),
+ @LNGOFF(64,8,0,52),
+ @LNGOFF(64,8,0,53),
+ @LNGOFF(64,8,0,54),
+ @LNGOFF(64,8,0,55),
+ @LNGOFF(64,8,0,56),
+ @LNGOFF(64,8,0,57),
+ @LNGOFF(64,8,0,58),
+ @LNGOFF(64,8,0,59),
+ @LNGOFF(64,8,0,60),
+ @LNGOFF(64,8,0,61),
+ @LNGOFF(64,8,0,62),
+ @LNGOFF(64,8,0,63),
+ @LNGOFF(64,8,0,64),
};

extern const char *names1204[];
static const uint32 types1204 [] =
{
SK_REF,
};

static const uint16 attr_flags1204 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1204_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1204 [] = {
g_atype1204_0,
};

static const long offsets1204 [] =
{
0,
};

extern const char *names1205[];
static const uint32 types1205 [] =
{
SK_REF,
};

static const uint16 attr_flags1205 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1205_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1205 [] = {
g_atype1205_0,
};

static const long offsets1205 [] =
{
0,
};

extern const char *names1206[];
static const uint32 types1206 [] =
{
SK_REF,
};

static const uint16 attr_flags1206 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1206_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1206 [] = {
g_atype1206_0,
};

static const long offsets1206 [] =
{
0,
};

extern const char *names1207[];
static const uint32 types1207 [] =
{
SK_REF,
};

static const uint16 attr_flags1207 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1207_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1207 [] = {
g_atype1207_0,
};

static const long offsets1207 [] =
{
0,
};

extern const char *names1208[];
static const uint32 types1208 [] =
{
SK_REF,
};

static const uint16 attr_flags1208 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1208_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1208 [] = {
g_atype1208_0,
};

static const long offsets1208 [] =
{
0,
};

extern const char *names1209[];
static const uint32 types1209 [] =
{
SK_REF,
};

static const uint16 attr_flags1209 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1209_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1209 [] = {
g_atype1209_0,
};

static const long offsets1209 [] =
{
0,
};

extern const char *names1210[];
static const uint32 types1210 [] =
{
SK_REF,
};

static const uint16 attr_flags1210 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1210_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1210 [] = {
g_atype1210_0,
};

static const long offsets1210 [] =
{
0,
};

extern const char *names1211[];
static const uint32 types1211 [] =
{
SK_REF,
};

static const uint16 attr_flags1211 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1211_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1211 [] = {
g_atype1211_0,
};

static const long offsets1211 [] =
{
0,
};

extern const char *names1212[];
static const uint32 types1212 [] =
{
SK_REF,
};

static const uint16 attr_flags1212 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1212_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1212 [] = {
g_atype1212_0,
};

static const long offsets1212 [] =
{
0,
};

extern const char *names1213[];
static const uint32 types1213 [] =
{
SK_REF,
};

static const uint16 attr_flags1213 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1213_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1213 [] = {
g_atype1213_0,
};

static const long offsets1213 [] =
{
0,
};

extern const char *names1214[];
static const uint32 types1214 [] =
{
SK_REF,
};

static const uint16 attr_flags1214 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1214_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1214 [] = {
g_atype1214_0,
};

static const long offsets1214 [] =
{
0,
};

extern const char *names1215[];
static const uint32 types1215 [] =
{
SK_REF,
};

static const uint16 attr_flags1215 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1215_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1215 [] = {
g_atype1215_0,
};

static const long offsets1215 [] =
{
0,
};

extern const char *names1216[];
static const uint32 types1216 [] =
{
SK_REF,
};

static const uint16 attr_flags1216 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1216_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1216 [] = {
g_atype1216_0,
};

static const long offsets1216 [] =
{
0,
};

extern const char *names1217[];
static const uint32 types1217 [] =
{
SK_REF,
};

static const uint16 attr_flags1217 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1217_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1217 [] = {
g_atype1217_0,
};

static const long offsets1217 [] =
{
0,
};

extern const char *names1218[];
static const uint32 types1218 [] =
{
SK_REF,
};

static const uint16 attr_flags1218 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1218_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1218 [] = {
g_atype1218_0,
};

static const long offsets1218 [] =
{
0,
};

extern const char *names1219[];
static const uint32 types1219 [] =
{
SK_REF,
};

static const uint16 attr_flags1219 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1219_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1219 [] = {
g_atype1219_0,
};

static const long offsets1219 [] =
{
0,
};

extern const char *names1220[];
static const uint32 types1220 [] =
{
SK_REF,
};

static const uint16 attr_flags1220 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1220_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1220 [] = {
g_atype1220_0,
};

static const long offsets1220 [] =
{
0,
};

extern const char *names1221[];
static const uint32 types1221 [] =
{
SK_REF,
};

static const uint16 attr_flags1221 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1221_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1221 [] = {
g_atype1221_0,
};

static const long offsets1221 [] =
{
0,
};

extern const char *names1222[];
static const uint32 types1222 [] =
{
SK_REF,
};

static const uint16 attr_flags1222 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1222_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1222 [] = {
g_atype1222_0,
};

static const long offsets1222 [] =
{
0,
};

extern const char *names1223[];
static const uint32 types1223 [] =
{
SK_REF,
};

static const uint16 attr_flags1223 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1223_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1223 [] = {
g_atype1223_0,
};

static const long offsets1223 [] =
{
0,
};

extern const char *names1224[];
static const uint32 types1224 [] =
{
SK_REF,
};

static const uint16 attr_flags1224 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1224_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1224 [] = {
g_atype1224_0,
};

static const long offsets1224 [] =
{
0,
};

extern const char *names1225[];
static const uint32 types1225 [] =
{
SK_REF,
};

static const uint16 attr_flags1225 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1225_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1225 [] = {
g_atype1225_0,
};

static const long offsets1225 [] =
{
0,
};

extern const char *names1226[];
static const uint32 types1226 [] =
{
SK_REF,
};

static const uint16 attr_flags1226 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1226_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1226 [] = {
g_atype1226_0,
};

static const long offsets1226 [] =
{
0,
};

extern const char *names1227[];
static const uint32 types1227 [] =
{
SK_REF,
};

static const uint16 attr_flags1227 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1227_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1227 [] = {
g_atype1227_0,
};

static const long offsets1227 [] =
{
0,
};

extern const char *names1228[];
static const uint32 types1228 [] =
{
SK_REF,
};

static const uint16 attr_flags1228 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1228_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1228 [] = {
g_atype1228_0,
};

static const long offsets1228 [] =
{
0,
};

extern const char *names1229[];
static const uint32 types1229 [] =
{
SK_REF,
};

static const uint16 attr_flags1229 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1229_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1229 [] = {
g_atype1229_0,
};

static const long offsets1229 [] =
{
0,
};

extern const char *names1230[];
static const uint32 types1230 [] =
{
SK_REF,
};

static const uint16 attr_flags1230 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1230_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1230 [] = {
g_atype1230_0,
};

static const long offsets1230 [] =
{
0,
};

extern const char *names1231[];
static const uint32 types1231 [] =
{
SK_REF,
};

static const uint16 attr_flags1231 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1231_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1231 [] = {
g_atype1231_0,
};

static const long offsets1231 [] =
{
0,
};

extern const char *names1232[];
static const uint32 types1232 [] =
{
SK_REF,
};

static const uint16 attr_flags1232 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1232_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1232 [] = {
g_atype1232_0,
};

static const long offsets1232 [] =
{
0,
};

extern const char *names1233[];
static const uint32 types1233 [] =
{
SK_REF,
};

static const uint16 attr_flags1233 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1233_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1233 [] = {
g_atype1233_0,
};

static const long offsets1233 [] =
{
0,
};

extern const char *names1234[];
static const uint32 types1234 [] =
{
SK_REF,
};

static const uint16 attr_flags1234 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1234_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1234 [] = {
g_atype1234_0,
};

static const long offsets1234 [] =
{
0,
};

extern const char *names1235[];
static const uint32 types1235 [] =
{
SK_REF,
};

static const uint16 attr_flags1235 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1235_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1235 [] = {
g_atype1235_0,
};

static const long offsets1235 [] =
{
0,
};

extern const char *names1236[];
static const uint32 types1236 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1236 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1236_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_1 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_2 [] = {0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1236 [] = {
g_atype1236_0,
g_atype1236_1,
g_atype1236_2,
};

static const long offsets1236 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1237[];
static const uint32 types1237 [] =
{
SK_REF,
};

static const uint16 attr_flags1237 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1237_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1237 [] = {
g_atype1237_0,
};

static const long offsets1237 [] =
{
0,
};

extern const char *names1238[];
static const uint32 types1238 [] =
{
SK_REF,
};

static const uint16 attr_flags1238 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1238_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1238 [] = {
g_atype1238_0,
};

static const long offsets1238 [] =
{
0,
};

extern const char *names1239[];
static const uint32 types1239 [] =
{
SK_REF,
};

static const uint16 attr_flags1239 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1239_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1239 [] = {
g_atype1239_0,
};

static const long offsets1239 [] =
{
0,
};

extern const char *names1240[];
static const uint32 types1240 [] =
{
SK_REF,
};

static const uint16 attr_flags1240 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1240_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1240 [] = {
g_atype1240_0,
};

static const long offsets1240 [] =
{
0,
};

extern const char *names1241[];
static const uint32 types1241 [] =
{
SK_REF,
};

static const uint16 attr_flags1241 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1241_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1241 [] = {
g_atype1241_0,
};

static const long offsets1241 [] =
{
0,
};

extern const char *names1242[];
static const uint32 types1242 [] =
{
SK_REF,
};

static const uint16 attr_flags1242 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1242_0 [] = {0xFF01,701,0xFF01,914,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1242 [] = {
g_atype1242_0,
};

static const long offsets1242 [] =
{
0,
};

extern const char *names1244[];
static const uint32 types1244 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1244 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1244_0 [] = {0xFF01,701,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1244_1 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1244_2 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1244_3 [] = {914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1244_4 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1244_5 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1244 [] = {
g_atype1244_0,
g_atype1244_1,
g_atype1244_2,
g_atype1244_3,
g_atype1244_4,
g_atype1244_5,
};

static const long offsets1244 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @LNGOFF(4,1,0,0),
};

extern const char *names1245[];
static const uint32 types1245 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT64,
SK_INT64,
};

static const uint16 attr_flags1245 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1245_0 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_1 [] = {0xFF01,951,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_2 [] = {0xFF01,1183,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_3 [] = {0xFF01,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_4 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_5 [] = {0xFF01,911,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_6 [] = {0xFF01,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_7 [] = {1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_8 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_9 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_10 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_11 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_12 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_13 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_14 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_15 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_16 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_17 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_18 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_19 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_20 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_21 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_22 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_23 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_24 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_25 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_26 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_27 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_28 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_29 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_30 [] = {831,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_31 [] = {831,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1245 [] = {
g_atype1245_0,
g_atype1245_1,
g_atype1245_2,
g_atype1245_3,
g_atype1245_4,
g_atype1245_5,
g_atype1245_6,
g_atype1245_7,
g_atype1245_8,
g_atype1245_9,
g_atype1245_10,
g_atype1245_11,
g_atype1245_12,
g_atype1245_13,
g_atype1245_14,
g_atype1245_15,
g_atype1245_16,
g_atype1245_17,
g_atype1245_18,
g_atype1245_19,
g_atype1245_20,
g_atype1245_21,
g_atype1245_22,
g_atype1245_23,
g_atype1245_24,
g_atype1245_25,
g_atype1245_26,
g_atype1245_27,
g_atype1245_28,
g_atype1245_29,
g_atype1245_30,
g_atype1245_31,
};

static const long offsets1245 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @CHROFF(8,1),
+ @CHROFF(8,2),
+ @CHROFF(8,3),
+ @CHROFF(8,4),
+ @CHROFF(8,5),
+ @CHROFF(8,6),
+ @CHROFF(8,7),
+ @CHROFF(8,8),
+ @CHROFF(8,9),
+ @CHROFF(8,10),
+ @CHROFF(8,11),
+ @CHROFF(8,12),
+ @LNGOFF(8,13,0,0),
+ @LNGOFF(8,13,0,1),
+ @LNGOFF(8,13,0,2),
+ @LNGOFF(8,13,0,3),
+ @LNGOFF(8,13,0,4),
+ @LNGOFF(8,13,0,5),
+ @LNGOFF(8,13,0,6),
+ @LNGOFF(8,13,0,7),
+ @LNGOFF(8,13,0,8),
+ @I64OFF(8,13,0,9,0,0,0),
+ @I64OFF(8,13,0,9,0,0,1),
};

extern const char *names1246[];
static const uint32 types1246 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT64,
SK_INT64,
};

static const uint16 attr_flags1246 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1246_0 [] = {0xFF01,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_2 [] = {0xFF01,951,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_3 [] = {0xFF01,1183,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_4 [] = {0xFF01,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_5 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_6 [] = {0xFF01,911,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_7 [] = {0xFF01,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_8 [] = {1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_9 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_10 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_11 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_12 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_13 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_14 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_15 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_16 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_17 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_18 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_19 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_20 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_21 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_22 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_23 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_24 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_25 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_26 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_27 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_28 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_29 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_30 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_31 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_32 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_33 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_34 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_35 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_36 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_37 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_38 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_39 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_40 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_41 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_42 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_43 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_44 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_45 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_46 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_47 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_48 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_49 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_50 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_51 [] = {831,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_52 [] = {831,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1246 [] = {
g_atype1246_0,
g_atype1246_1,
g_atype1246_2,
g_atype1246_3,
g_atype1246_4,
g_atype1246_5,
g_atype1246_6,
g_atype1246_7,
g_atype1246_8,
g_atype1246_9,
g_atype1246_10,
g_atype1246_11,
g_atype1246_12,
g_atype1246_13,
g_atype1246_14,
g_atype1246_15,
g_atype1246_16,
g_atype1246_17,
g_atype1246_18,
g_atype1246_19,
g_atype1246_20,
g_atype1246_21,
g_atype1246_22,
g_atype1246_23,
g_atype1246_24,
g_atype1246_25,
g_atype1246_26,
g_atype1246_27,
g_atype1246_28,
g_atype1246_29,
g_atype1246_30,
g_atype1246_31,
g_atype1246_32,
g_atype1246_33,
g_atype1246_34,
g_atype1246_35,
g_atype1246_36,
g_atype1246_37,
g_atype1246_38,
g_atype1246_39,
g_atype1246_40,
g_atype1246_41,
g_atype1246_42,
g_atype1246_43,
g_atype1246_44,
g_atype1246_45,
g_atype1246_46,
g_atype1246_47,
g_atype1246_48,
g_atype1246_49,
g_atype1246_50,
g_atype1246_51,
g_atype1246_52,
};

static const long offsets1246 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
+ @CHROFF(12,0),
+ @CHROFF(12,1),
+ @CHROFF(12,2),
+ @CHROFF(12,3),
+ @CHROFF(12,4),
+ @CHROFF(12,5),
+ @CHROFF(12,6),
+ @CHROFF(12,7),
+ @CHROFF(12,8),
+ @CHROFF(12,9),
+ @CHROFF(12,10),
+ @CHROFF(12,11),
+ @CHROFF(12,12),
+ @CHROFF(12,13),
+ @CHROFF(12,14),
+ @CHROFF(12,15),
+ @LNGOFF(12,16,0,0),
+ @LNGOFF(12,16,0,1),
+ @LNGOFF(12,16,0,2),
+ @LNGOFF(12,16,0,3),
+ @LNGOFF(12,16,0,4),
+ @LNGOFF(12,16,0,5),
+ @LNGOFF(12,16,0,6),
+ @LNGOFF(12,16,0,7),
+ @LNGOFF(12,16,0,8),
+ @LNGOFF(12,16,0,9),
+ @LNGOFF(12,16,0,10),
+ @LNGOFF(12,16,0,11),
+ @LNGOFF(12,16,0,12),
+ @LNGOFF(12,16,0,13),
+ @LNGOFF(12,16,0,14),
+ @LNGOFF(12,16,0,15),
+ @LNGOFF(12,16,0,16),
+ @LNGOFF(12,16,0,17),
+ @LNGOFF(12,16,0,18),
+ @LNGOFF(12,16,0,19),
+ @LNGOFF(12,16,0,20),
+ @LNGOFF(12,16,0,21),
+ @LNGOFF(12,16,0,22),
+ @I64OFF(12,16,0,23,0,0,0),
+ @I64OFF(12,16,0,23,0,0,1),
};

extern const char *names1247[];
static const uint32 types1247 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT64,
SK_INT64,
};

static const uint16 attr_flags1247 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1247_0 [] = {0xFF01,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_2 [] = {0xFF01,951,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_3 [] = {0xFF01,1183,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_4 [] = {0xFF01,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_5 [] = {0xFF01,914,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_6 [] = {0xFF01,911,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_7 [] = {0xFF01,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_8 [] = {1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_9 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_10 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_11 [] = {0xFF01,677,834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_12 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_13 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_14 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_15 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_16 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_17 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_18 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_19 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_20 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_21 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_22 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_23 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_24 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_25 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_26 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_27 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_28 [] = {846,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_29 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_30 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_31 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_32 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_33 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_34 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_35 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_36 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_37 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_38 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_39 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_40 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_41 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_42 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_43 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_44 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_45 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_46 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_47 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_48 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_49 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_50 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_51 [] = {831,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_52 [] = {831,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1247 [] = {
g_atype1247_0,
g_atype1247_1,
g_atype1247_2,
g_atype1247_3,
g_atype1247_4,
g_atype1247_5,
g_atype1247_6,
g_atype1247_7,
g_atype1247_8,
g_atype1247_9,
g_atype1247_10,
g_atype1247_11,
g_atype1247_12,
g_atype1247_13,
g_atype1247_14,
g_atype1247_15,
g_atype1247_16,
g_atype1247_17,
g_atype1247_18,
g_atype1247_19,
g_atype1247_20,
g_atype1247_21,
g_atype1247_22,
g_atype1247_23,
g_atype1247_24,
g_atype1247_25,
g_atype1247_26,
g_atype1247_27,
g_atype1247_28,
g_atype1247_29,
g_atype1247_30,
g_atype1247_31,
g_atype1247_32,
g_atype1247_33,
g_atype1247_34,
g_atype1247_35,
g_atype1247_36,
g_atype1247_37,
g_atype1247_38,
g_atype1247_39,
g_atype1247_40,
g_atype1247_41,
g_atype1247_42,
g_atype1247_43,
g_atype1247_44,
g_atype1247_45,
g_atype1247_46,
g_atype1247_47,
g_atype1247_48,
g_atype1247_49,
g_atype1247_50,
g_atype1247_51,
g_atype1247_52,
};

static const long offsets1247 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
+ @CHROFF(12,0),
+ @CHROFF(12,1),
+ @CHROFF(12,2),
+ @CHROFF(12,3),
+ @CHROFF(12,4),
+ @CHROFF(12,5),
+ @CHROFF(12,6),
+ @CHROFF(12,7),
+ @CHROFF(12,8),
+ @CHROFF(12,9),
+ @CHROFF(12,10),
+ @CHROFF(12,11),
+ @CHROFF(12,12),
+ @CHROFF(12,13),
+ @CHROFF(12,14),
+ @CHROFF(12,15),
+ @LNGOFF(12,16,0,0),
+ @LNGOFF(12,16,0,1),
+ @LNGOFF(12,16,0,2),
+ @LNGOFF(12,16,0,3),
+ @LNGOFF(12,16,0,4),
+ @LNGOFF(12,16,0,5),
+ @LNGOFF(12,16,0,6),
+ @LNGOFF(12,16,0,7),
+ @LNGOFF(12,16,0,8),
+ @LNGOFF(12,16,0,9),
+ @LNGOFF(12,16,0,10),
+ @LNGOFF(12,16,0,11),
+ @LNGOFF(12,16,0,12),
+ @LNGOFF(12,16,0,13),
+ @LNGOFF(12,16,0,14),
+ @LNGOFF(12,16,0,15),
+ @LNGOFF(12,16,0,16),
+ @LNGOFF(12,16,0,17),
+ @LNGOFF(12,16,0,18),
+ @LNGOFF(12,16,0,19),
+ @LNGOFF(12,16,0,20),
+ @LNGOFF(12,16,0,21),
+ @LNGOFF(12,16,0,22),
+ @I64OFF(12,16,0,23,0,0,0),
+ @I64OFF(12,16,0,23,0,0,1),
};

extern const char *names1248[];
static const uint32 types1248 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1248 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1248_0 [] = {0xFF01,682,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_7 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1248 [] = {
g_atype1248_0,
g_atype1248_1,
g_atype1248_2,
g_atype1248_3,
g_atype1248_4,
g_atype1248_5,
g_atype1248_6,
g_atype1248_7,
};

static const long offsets1248 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
+ @LNGOFF(1,1,0,5),
};

extern const char *names1249[];
static const uint32 types1249 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1249 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1249_0 [] = {0xFF01,682,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_2 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_3 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_4 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_5 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_6 [] = {834,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_7 [] = {834,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1249 [] = {
g_atype1249_0,
g_atype1249_1,
g_atype1249_2,
g_atype1249_3,
g_atype1249_4,
g_atype1249_5,
g_atype1249_6,
g_atype1249_7,
};

static const long offsets1249 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
+ @LNGOFF(1,1,0,5),
};

const struct cnode egc_fsystem_init[] = {
{
	(long) 0,
	(long) 0,
	"ANY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 8,
	(long) 8,
	"RX_CHARACTER_SET",
	names2,
	types2,
	attr_flags2,
	gtypes2,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets2,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_OPERATING_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DESCRIPTOR_CACHE",
	names4,
	types4,
	attr_flags4,
	gtypes4,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets4,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RX_PCRE_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 0,
	"VERSIONABLE",
	names6,
	types6,
	attr_flags6,
	gtypes6,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets6,
	NULL
},
{
	(long) 0,
	(long) 0,
	"LX_ACTION_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_ARRAY_FORMATTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_BOOLEAN_FORMATTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CODE_PAGE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"ENCODING",
	names11,
	types11,
	attr_flags11,
	gtypes11,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets11,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_HASH_FUNCTION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_HASH_FUNCTION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_HASH_FUNCTION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ANY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_STRING_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CHARACTER_PROPERTY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STANDARD_FILES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_STRING",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"RT_DBG_EXECUTION_PARAMETERS",
	names27,
	types27,
	attr_flags27,
	gtypes27,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets27,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UTF_CONVERTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0100,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UTF_CONVERTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0300,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ISE_RUNTIME",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"STD_FILES",
	names43,
	types43,
	attr_flags43,
	gtypes43,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets43,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OPERATING_ENVIRONMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LX_START_CONDITION",
	names45,
	types45,
	attr_flags45,
	gtypes45,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets45,
	NULL
},
{
	(long) 33,
	(long) 33,
	"LX_DESCRIPTION",
	names46,
	types46,
	attr_flags46,
	gtypes46,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets46,
	NULL
},
{
	(long) 4,
	(long) 4,
	"LX_SINGLETON",
	names47,
	types47,
	attr_flags47,
	gtypes47,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets47,
	NULL
},
{
	(long) 3,
	(long) 3,
	"LX_PROTO",
	names48,
	types48,
	attr_flags48,
	gtypes48,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets48,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RX_PCRE_SHARED_CHARACTER_SETS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RX_PCRE_OPTION_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RX_PCRE_ERROR_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RX_PCRE_BYTE_CODE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_SHARED_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_VALUES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_VALUES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_VALUES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_VALUES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CODE_SETS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_OPERATING_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 12,
	(long) 12,
	"OBJECT_GRAPH_TRAVERSABLE",
	names61,
	types61,
	attr_flags61,
	gtypes61,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets61,
	NULL
},
{
	(long) 12,
	(long) 12,
	"OBJECT_GRAPH_BREADTH_FIRST_TRAVERSABLE",
	names62,
	types62,
	attr_flags62,
	gtypes62,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets62,
	NULL
},
{
	(long) 0,
	(long) 0,
	"YY_PARSER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ANY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_CHARACTER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UNICODE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UTF8_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_SORTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_SORTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_SORTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_SORTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_INDEXABLE_SORTER",
	names74,
	types74,
	attr_flags74,
	gtypes74,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets74,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_INDEXABLE_SORTER",
	names75,
	types75,
	attr_flags75,
	gtypes75,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets75,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_QUICK_SORTER",
	names76,
	types76,
	attr_flags76,
	gtypes76,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets76,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BUBBLE_SORTER",
	names77,
	types77,
	attr_flags77,
	gtypes77,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets77,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BUBBLE_SORTER",
	names78,
	types78,
	attr_flags78,
	gtypes78,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets78,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS_I",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_CELL",
	names80,
	types80,
	attr_flags80,
	gtypes80,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets80,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_CELL",
	names81,
	types81,
	attr_flags81,
	gtypes81,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets81,
	NULL
},
{
	(long) 2,
	(long) 2,
	"KL_LINKABLE",
	names82,
	types82,
	attr_flags82,
	gtypes82,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets82,
	NULL
},
{
	(long) 2,
	(long) 2,
	"KL_LINKABLE",
	names83,
	types83,
	attr_flags83,
	gtypes83,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets83,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_OUTPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OBJECT_GRAPH_MARKER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MATH_CONST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DOUBLE_MATH",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_EXCEPTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_GOBO_VERSION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"GELEX_VERSION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BUFFER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BUFFER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_CHARACTER_BUFFER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFACTORING_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"LX_EQUIVALENCE_CLASSES",
	names96,
	types96,
	attr_flags96,
	gtypes96,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets96,
	NULL
},
{
	(long) 4,
	(long) 4,
	"LX_SYMBOL_PARTITIONS",
	names97,
	types97,
	attr_flags97,
	gtypes97,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets97,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTION_MANAGER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ISE_EXCEPTION_MANAGER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEP_CONST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names101,
	types101,
	attr_flags101,
	gtypes101,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets101,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names102,
	types102,
	attr_flags102,
	gtypes102,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets102,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names103,
	types103,
	attr_flags103,
	gtypes103,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets103,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names104,
	types104,
	attr_flags104,
	gtypes104,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets104,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LINKABLE",
	names105,
	types105,
	attr_flags105,
	gtypes105,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets105,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LINKABLE",
	names106,
	types106,
	attr_flags106,
	gtypes106,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets106,
	NULL
},
{
	(long) 0,
	(long) 0,
	"LX_DESCRIPTION_OVERRIDER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DP_COMMAND",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_ACTION",
	names109,
	types109,
	attr_flags109,
	gtypes109,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets109,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_CHARACTER_32_CODES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ENCODING_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS_IMP",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_FILE_SYSTEM_ENTRY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"AP_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 7,
	"AP_OPTION",
	names116,
	types116,
	attr_flags116,
	gtypes116,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets116,
	NULL
},
{
	(long) 8,
	(long) 8,
	"AP_FLAG",
	names117,
	types117,
	attr_flags117,
	gtypes117,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets117,
	NULL
},
{
	(long) 11,
	(long) 11,
	"AP_OPTION_WITH_PARAMETER",
	names118,
	types118,
	attr_flags118,
	gtypes118,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets118,
	NULL
},
{
	(long) 11,
	(long) 11,
	"AP_OPTION_WITH_PARAMETER",
	names119,
	types119,
	attr_flags119,
	gtypes119,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets119,
	NULL
},
{
	(long) 11,
	(long) 11,
	"AP_OPTION_WITH_PARAMETER",
	names120,
	types120,
	attr_flags120,
	gtypes120,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets120,
	NULL
},
{
	(long) 12,
	(long) 12,
	"AP_INTEGER_OPTION",
	names121,
	types121,
	attr_flags121,
	gtypes121,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets121,
	NULL
},
{
	(long) 12,
	(long) 12,
	"AP_STRING_OPTION",
	names122,
	types122,
	attr_flags122,
	gtypes122,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets122,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_CHARACTER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UTF32_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UTF16_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_PART_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_PART_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_PART_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_PART_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_REVERSE_PART_COMPARATOR",
	names132,
	types132,
	attr_flags132,
	gtypes132,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets132,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_REVERSE_PART_COMPARATOR",
	names133,
	types133,
	attr_flags133,
	gtypes133,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets133,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION_COMMON",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION_GENERAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_DBG_COMMON",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_SEARCHER",
	names138,
	types138,
	attr_flags138,
	gtypes138,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets138,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_32_SEARCHER",
	names139,
	types139,
	attr_flags139,
	gtypes139,
	(uint16) 0x6000,
	(void (*)()) 0,
	offsets139,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_8_SEARCHER",
	names140,
	types140,
	attr_flags140,
	gtypes140,
	(uint16) 0x6000,
	(void (*)()) 0,
	offsets140,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NUMERIC_INFORMATION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"INTEGER_OVERFLOW_CHECKER",
	names142,
	types142,
	attr_flags142,
	gtypes142,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets142,
	NULL
},
{
	(long) 7,
	(long) 7,
	"STRING_TO_NUMERIC_CONVERTOR",
	names143,
	types143,
	attr_flags143,
	gtypes143,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets143,
	NULL
},
{
	(long) 11,
	(long) 11,
	"HEXADECIMAL_STRING_TO_INTEGER_CONVERTER",
	names144,
	types144,
	attr_flags144,
	gtypes144,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets144,
	NULL
},
{
	(long) 10,
	(long) 10,
	"STRING_TO_INTEGER_CONVERTOR",
	names145,
	types145,
	attr_flags145,
	gtypes145,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets145,
	NULL
},
{
	(long) 15,
	(long) 15,
	"STRING_TO_REAL_CONVERTOR",
	names146,
	types146,
	attr_flags146,
	gtypes146,
	(uint16) 0x6000,
	(void (*)()) 0,
	offsets146,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_STREAMS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_CHARACTER_CODES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CELL",
	names149,
	types149,
	attr_flags149,
	gtypes149,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets149,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CELL",
	names150,
	types150,
	attr_flags150,
	gtypes150,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets150,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CELL",
	names151,
	types151,
	attr_flags151,
	gtypes151,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets151,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CELL",
	names152,
	types152,
	attr_flags152,
	gtypes152,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets152,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DS_PAIR",
	names153,
	types153,
	attr_flags153,
	gtypes153,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets153,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DS_LINKABLE",
	names154,
	types154,
	attr_flags154,
	gtypes154,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets154,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DS_LINKABLE",
	names155,
	types155,
	attr_flags155,
	gtypes155,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets155,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DS_LINKABLE",
	names156,
	types156,
	attr_flags156,
	gtypes156,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets156,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DS_LINKABLE",
	names157,
	types157,
	attr_flags157,
	gtypes157,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets157,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_BILINKABLE",
	names158,
	types158,
	attr_flags158,
	gtypes158,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets158,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_BILINKABLE",
	names159,
	types159,
	attr_flags159,
	gtypes159,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets159,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PART_COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 10,
	(long) 10,
	"LX_RULE",
	names163,
	types163,
	attr_flags163,
	gtypes163,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets163,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 10,
	(long) 10,
	"YY_BUFFER",
	names166,
	types166,
	attr_flags166,
	gtypes166,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets166,
	NULL
},
{
	(long) 10,
	(long) 10,
	"YY_UTF8_BUFFER",
	names167,
	types167,
	attr_flags167,
	gtypes167,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets167,
	NULL
},
{
	(long) 10,
	(long) 10,
	"YY_UNICODE_BUFFER",
	names168,
	types168,
	attr_flags168,
	gtypes168,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets168,
	NULL
},
{
	(long) 12,
	(long) 12,
	"YY_FILE_BUFFER",
	names169,
	types169,
	attr_flags169,
	gtypes169,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets169,
	NULL
},
{
	(long) 14,
	(long) 14,
	"YY_UTF8_FILE_BUFFER",
	names170,
	types170,
	attr_flags170,
	gtypes170,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets170,
	NULL
},
{
	(long) 15,
	(long) 15,
	"YY_UNICODE_FILE_BUFFER",
	names171,
	types171,
	attr_flags171,
	gtypes171,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets171,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"LINKED_LIST_CURSOR",
	names173,
	types173,
	attr_flags173,
	gtypes173,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets173,
	NULL
},
{
	(long) 3,
	(long) 3,
	"LINKED_LIST_CURSOR",
	names174,
	types174,
	attr_flags174,
	gtypes174,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets174,
	NULL
},
{
	(long) 1,
	(long) 1,
	"HASH_TABLE_CURSOR",
	names175,
	types175,
	attr_flags175,
	gtypes175,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets175,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ARRAYED_LIST_CURSOR",
	names176,
	types176,
	attr_flags176,
	gtypes176,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets176,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTION_MANAGER_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EXCEPTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXCEPTION",
	names180,
	types180,
	attr_flags180,
	gtypes180,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets180,
	NULL
},
{
	(long) 7,
	(long) 7,
	"DEVELOPER_EXCEPTION",
	names181,
	types181,
	attr_flags181,
	gtypes181,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets181,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CONVERSION_FAILURE",
	names182,
	types182,
	attr_flags182,
	gtypes182,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets182,
	NULL
},
{
	(long) 7,
	(long) 7,
	"MACHINE_EXCEPTION",
	names183,
	types183,
	attr_flags183,
	gtypes183,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets183,
	NULL
},
{
	(long) 7,
	(long) 7,
	"HARDWARE_EXCEPTION",
	names184,
	types184,
	attr_flags184,
	gtypes184,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets184,
	NULL
},
{
	(long) 7,
	(long) 7,
	"FLOATING_POINT_FAILURE",
	names185,
	types185,
	attr_flags185,
	gtypes185,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets185,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OPERATING_SYSTEM_EXCEPTION",
	names186,
	types186,
	attr_flags186,
	gtypes186,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets186,
	NULL
},
{
	(long) 8,
	(long) 8,
	"OPERATING_SYSTEM_SIGNAL_FAILURE",
	names187,
	types187,
	attr_flags187,
	gtypes187,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets187,
	NULL
},
{
	(long) 10,
	(long) 10,
	"COM_FAILURE",
	names188,
	types188,
	attr_flags188,
	gtypes188,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets188,
	NULL
},
{
	(long) 8,
	(long) 8,
	"OPERATING_SYSTEM_FAILURE",
	names189,
	types189,
	attr_flags189,
	gtypes189,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets189,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OBSOLETE_EXCEPTION",
	names190,
	types190,
	attr_flags190,
	gtypes190,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets190,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXCEPTION_IN_SIGNAL_HANDLER_FAILURE",
	names191,
	types191,
	attr_flags191,
	gtypes191,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets191,
	NULL
},
{
	(long) 7,
	(long) 7,
	"RESUMPTION_FAILURE",
	names192,
	types192,
	attr_flags192,
	gtypes192,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets192,
	NULL
},
{
	(long) 7,
	(long) 7,
	"RESCUE_FAILURE",
	names193,
	types193,
	attr_flags193,
	gtypes193,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets193,
	NULL
},
{
	(long) 7,
	(long) 7,
	"SYS_EXCEPTION",
	names194,
	types194,
	attr_flags194,
	gtypes194,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets194,
	NULL
},
{
	(long) 8,
	(long) 8,
	"EIFFEL_RUNTIME_PANIC",
	names195,
	types195,
	attr_flags195,
	gtypes195,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets195,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OLD_VIOLATION",
	names196,
	types196,
	attr_flags196,
	gtypes196,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets196,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIF_EXCEPTION",
	names197,
	types197,
	attr_flags197,
	gtypes197,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets197,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIFFEL_RUNTIME_EXCEPTION",
	names198,
	types198,
	attr_flags198,
	gtypes198,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets198,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXTERNAL_FAILURE",
	names199,
	types199,
	attr_flags199,
	gtypes199,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets199,
	NULL
},
{
	(long) 8,
	(long) 8,
	"NO_MORE_MEMORY",
	names200,
	types200,
	attr_flags200,
	gtypes200,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets200,
	NULL
},
{
	(long) 7,
	(long) 7,
	"DATA_EXCEPTION",
	names201,
	types201,
	attr_flags201,
	gtypes201,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets201,
	NULL
},
{
	(long) 9,
	(long) 9,
	"IO_FAILURE",
	names202,
	types202,
	attr_flags202,
	gtypes202,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets202,
	NULL
},
{
	(long) 7,
	(long) 7,
	"SERIALIZATION_FAILURE",
	names203,
	types203,
	attr_flags203,
	gtypes203,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets203,
	NULL
},
{
	(long) 7,
	(long) 7,
	"MISMATCH_FAILURE",
	names204,
	types204,
	attr_flags204,
	gtypes204,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets204,
	NULL
},
{
	(long) 7,
	(long) 7,
	"LANGUAGE_EXCEPTION",
	names205,
	types205,
	attr_flags205,
	gtypes205,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets205,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VOID_ASSIGNED_TO_EXPANDED",
	names206,
	types206,
	attr_flags206,
	gtypes206,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets206,
	NULL
},
{
	(long) 7,
	(long) 7,
	"BAD_INSPECT_VALUE",
	names207,
	types207,
	attr_flags207,
	gtypes207,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets207,
	NULL
},
{
	(long) 9,
	(long) 9,
	"ROUTINE_FAILURE",
	names208,
	types208,
	attr_flags208,
	gtypes208,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets208,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VOID_TARGET",
	names209,
	types209,
	attr_flags209,
	gtypes209,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets209,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIFFELSTUDIO_SPECIFIC_LANGUAGE_EXCEPTION",
	names210,
	types210,
	attr_flags210,
	gtypes210,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets210,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CREATE_ON_DEFERRED",
	names211,
	types211,
	attr_flags211,
	gtypes211,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets211,
	NULL
},
{
	(long) 7,
	(long) 7,
	"ADDRESS_APPLIED_TO_MELTED_FEATURE",
	names212,
	types212,
	attr_flags212,
	gtypes212,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets212,
	NULL
},
{
	(long) 7,
	(long) 7,
	"ASSERTION_VIOLATION",
	names213,
	types213,
	attr_flags213,
	gtypes213,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets213,
	NULL
},
{
	(long) 7,
	(long) 7,
	"LOOP_INVARIANT_VIOLATION",
	names214,
	types214,
	attr_flags214,
	gtypes214,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets214,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VARIANT_VIOLATION",
	names215,
	types215,
	attr_flags215,
	gtypes215,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets215,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CHECK_VIOLATION",
	names216,
	types216,
	attr_flags216,
	gtypes216,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets216,
	NULL
},
{
	(long) 8,
	(long) 8,
	"INVARIANT_VIOLATION",
	names217,
	types217,
	attr_flags217,
	gtypes217,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets217,
	NULL
},
{
	(long) 7,
	(long) 7,
	"POSTCONDITION_VIOLATION",
	names218,
	types218,
	attr_flags218,
	gtypes218,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets218,
	NULL
},
{
	(long) 7,
	(long) 7,
	"PRECONDITION_VIOLATION",
	names219,
	types219,
	attr_flags219,
	gtypes219,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets219,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DISPOSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 2,
	"MANAGED_POINTER",
	names221,
	types221,
	attr_flags221,
	gtypes221,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets221,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_IMPORTED_FORMATTERS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_ARGUMENTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_EXCEPTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 8,
	(long) 8,
	"AP_DISPLAY_HELP_FLAG",
	names225,
	types225,
	attr_flags225,
	gtypes225,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets225,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_COMPARABLE_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_COMPARABLE_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 13,
	(long) 13,
	"AP_ENUMERATION_OPTION",
	names238,
	types238,
	attr_flags238,
	gtypes238,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets238,
	NULL
},
{
	(long) 12,
	(long) 12,
	"AP_BOOLEAN_OPTION",
	names239,
	types239,
	attr_flags239,
	gtypes239,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets239,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UNICODE_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REFLECTED_OBJECT",
	names242,
	types242,
	attr_flags242,
	gtypes242,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets242,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INTERNAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_DBG_INTERNAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"REFLECTED_COPY_SEMANTICS_OBJECT",
	names246,
	types246,
	attr_flags246,
	gtypes246,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets246,
	NULL
},
{
	(long) 3,
	(long) 3,
	"REFLECTED_REFERENCE_OBJECT",
	names247,
	types247,
	attr_flags247,
	gtypes247,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets247,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names248,
	types248,
	attr_flags248,
	gtypes248,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets248,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names249,
	types249,
	attr_flags249,
	gtypes249,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets249,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names250,
	types250,
	attr_flags250,
	gtypes250,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets250,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names251,
	types251,
	attr_flags251,
	gtypes251,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets251,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names252,
	types252,
	attr_flags252,
	gtypes252,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets252,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names253,
	types253,
	attr_flags253,
	gtypes253,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets253,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names254,
	types254,
	attr_flags254,
	gtypes254,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets254,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names255,
	types255,
	attr_flags255,
	gtypes255,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets255,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names256,
	types256,
	attr_flags256,
	gtypes256,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets256,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names257,
	types257,
	attr_flags257,
	gtypes257,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets257,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names258,
	types258,
	attr_flags258,
	gtypes258,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets258,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names259,
	types259,
	attr_flags259,
	gtypes259,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets259,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EXECUTION_ENVIRONMENT",
	names261,
	types261,
	attr_flags261,
	gtypes261,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets261,
	NULL
},
{
	(long) 2,
	(long) 2,
	"NATIVE_STRING",
	names262,
	types262,
	attr_flags262,
	gtypes262,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets262,
	NULL
},
{
	(long) 6,
	(long) 6,
	"DIRECTORY",
	names263,
	types263,
	attr_flags263,
	gtypes263,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets263,
	NULL
},
{
	(long) 5,
	(long) 5,
	"FILE_INFO",
	names264,
	types264,
	attr_flags264,
	gtypes264,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets264,
	NULL
},
{
	(long) 5,
	(long) 5,
	"UNIX_FILE_INFO",
	names265,
	types265,
	attr_flags265,
	gtypes265,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets265,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_STANDARD_FILES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GELEX",
	names267,
	types267,
	attr_flags267,
	gtypes267,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets267,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_UNICODE_CHARACTER_BUFFER",
	names270,
	types270,
	attr_flags270,
	gtypes270,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets270,
	NULL
},
{
	(long) 2,
	(long) 2,
	"KL_CHARACTER_BUFFER",
	names271,
	types271,
	attr_flags271,
	gtypes271,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets271,
	NULL
},
{
	(long) 2,
	(long) 2,
	"C_STRING",
	names272,
	types272,
	attr_flags272,
	gtypes272,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets272,
	NULL
},
{
	(long) 13,
	(long) 13,
	"IO_MEDIUM",
	names273,
	types273,
	attr_flags273,
	gtypes273,
	(uint16) 0x5400,
	(void (*)()) 0,
	offsets273,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DEBUG_OUTPUT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 15,
	(long) 15,
	"RT_DBG_CALL_RECORD",
	names275,
	types275,
	attr_flags275,
	gtypes275,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets275,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ABSTRACT_SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"RT_DBG_VALUE_RECORD",
	names277,
	types277,
	attr_flags277,
	gtypes277,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets277,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names278,
	types278,
	attr_flags278,
	gtypes278,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets278,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names279,
	types279,
	attr_flags279,
	gtypes279,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets279,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names280,
	types280,
	attr_flags280,
	gtypes280,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets280,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names281,
	types281,
	attr_flags281,
	gtypes281,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets281,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names282,
	types282,
	attr_flags282,
	gtypes282,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets282,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names283,
	types283,
	attr_flags283,
	gtypes283,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets283,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names284,
	types284,
	attr_flags284,
	gtypes284,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets284,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names285,
	types285,
	attr_flags285,
	gtypes285,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets285,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names286,
	types286,
	attr_flags286,
	gtypes286,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets286,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names287,
	types287,
	attr_flags287,
	gtypes287,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets287,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names288,
	types288,
	attr_flags288,
	gtypes288,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets288,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names289,
	types289,
	attr_flags289,
	gtypes289,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets289,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names290,
	types290,
	attr_flags290,
	gtypes290,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets290,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names291,
	types291,
	attr_flags291,
	gtypes291,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets291,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names292,
	types292,
	attr_flags292,
	gtypes292,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets292,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names293,
	types293,
	attr_flags293,
	gtypes293,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets293,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names294,
	types294,
	attr_flags294,
	gtypes294,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets294,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names295,
	types295,
	attr_flags295,
	gtypes295,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets295,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names296,
	types296,
	attr_flags296,
	gtypes296,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets296,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names297,
	types297,
	attr_flags297,
	gtypes297,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets297,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names298,
	types298,
	attr_flags298,
	gtypes298,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets298,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names299,
	types299,
	attr_flags299,
	gtypes299,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets299,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names300,
	types300,
	attr_flags300,
	gtypes300,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets300,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names301,
	types301,
	attr_flags301,
	gtypes301,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets301,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names302,
	types302,
	attr_flags302,
	gtypes302,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets302,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names303,
	types303,
	attr_flags303,
	gtypes303,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets303,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names304,
	types304,
	attr_flags304,
	gtypes304,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets304,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names305,
	types305,
	attr_flags305,
	gtypes305,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets305,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names306,
	types306,
	attr_flags306,
	gtypes306,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets306,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names307,
	types307,
	attr_flags307,
	gtypes307,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets307,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names308,
	types308,
	attr_flags308,
	gtypes308,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets308,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names309,
	types309,
	attr_flags309,
	gtypes309,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets309,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names310,
	types310,
	attr_flags310,
	gtypes310,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets310,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names311,
	types311,
	attr_flags311,
	gtypes311,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets311,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names312,
	types312,
	attr_flags312,
	gtypes312,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets312,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names313,
	types313,
	attr_flags313,
	gtypes313,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets313,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names314,
	types314,
	attr_flags314,
	gtypes314,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets314,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names315,
	types315,
	attr_flags315,
	gtypes315,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets315,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names316,
	types316,
	attr_flags316,
	gtypes316,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets316,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names317,
	types317,
	attr_flags317,
	gtypes317,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets317,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names318,
	types318,
	attr_flags318,
	gtypes318,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets318,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names319,
	types319,
	attr_flags319,
	gtypes319,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets319,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names320,
	types320,
	attr_flags320,
	gtypes320,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets320,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names321,
	types321,
	attr_flags321,
	gtypes321,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets321,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names322,
	types322,
	attr_flags322,
	gtypes322,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets322,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NUMERIC",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_QUEUE_ITERATION_CURSOR",
	names336,
	types336,
	attr_flags336,
	gtypes336,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets336,
	NULL
},
{
	(long) 2,
	(long) 2,
	"FILE_ITERATION_CURSOR",
	names337,
	types337,
	attr_flags337,
	gtypes337,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets337,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENTS_32",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"STRING_ITERATION_CURSOR",
	names356,
	types356,
	attr_flags356,
	gtypes356,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets356,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_ARGUMENTS",
	names358,
	types358,
	attr_flags358,
	gtypes358,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets358,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names388,
	types388,
	attr_flags388,
	gtypes388,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets388,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names389,
	types389,
	attr_flags389,
	gtypes389,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets389,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names390,
	types390,
	attr_flags390,
	gtypes390,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets390,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names391,
	types391,
	attr_flags391,
	gtypes391,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets391,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names392,
	types392,
	attr_flags392,
	gtypes392,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets392,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names393,
	types393,
	attr_flags393,
	gtypes393,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets393,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names394,
	types394,
	attr_flags394,
	gtypes394,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets394,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names395,
	types395,
	attr_flags395,
	gtypes395,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets395,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names396,
	types396,
	attr_flags396,
	gtypes396,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets396,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names397,
	types397,
	attr_flags397,
	gtypes397,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets397,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names398,
	types398,
	attr_flags398,
	gtypes398,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets398,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names399,
	types399,
	attr_flags399,
	gtypes399,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets399,
	NULL
},
{
	(long) 8,
	(long) 7,
	"LINKED_LIST_ITERATION_CURSOR",
	names400,
	types400,
	attr_flags400,
	gtypes400,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets400,
	NULL
},
{
	(long) 8,
	(long) 7,
	"LINKED_LIST_ITERATION_CURSOR",
	names401,
	types401,
	attr_flags401,
	gtypes401,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets401,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names402,
	types402,
	attr_flags402,
	gtypes402,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets402,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names403,
	types403,
	attr_flags403,
	gtypes403,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets403,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names404,
	types404,
	attr_flags404,
	gtypes404,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets404,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names405,
	types405,
	attr_flags405,
	gtypes405,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets405,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names406,
	types406,
	attr_flags406,
	gtypes406,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets406,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names407,
	types407,
	attr_flags407,
	gtypes407,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets407,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names408,
	types408,
	attr_flags408,
	gtypes408,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets408,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names409,
	types409,
	attr_flags409,
	gtypes409,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets409,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names410,
	types410,
	attr_flags410,
	gtypes410,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets410,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names411,
	types411,
	attr_flags411,
	gtypes411,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets411,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names412,
	types412,
	attr_flags412,
	gtypes412,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets412,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names413,
	types413,
	attr_flags413,
	gtypes413,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets413,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names414,
	types414,
	attr_flags414,
	gtypes414,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets414,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names415,
	types415,
	attr_flags415,
	gtypes415,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets415,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names416,
	types416,
	attr_flags416,
	gtypes416,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets416,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names417,
	types417,
	attr_flags417,
	gtypes417,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets417,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names418,
	types418,
	attr_flags418,
	gtypes418,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets418,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names419,
	types419,
	attr_flags419,
	gtypes419,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets419,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names420,
	types420,
	attr_flags420,
	gtypes420,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets420,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names421,
	types421,
	attr_flags421,
	gtypes421,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets421,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names422,
	types422,
	attr_flags422,
	gtypes422,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets422,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names423,
	types423,
	attr_flags423,
	gtypes423,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets423,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names424,
	types424,
	attr_flags424,
	gtypes424,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets424,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names425,
	types425,
	attr_flags425,
	gtypes425,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets425,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names426,
	types426,
	attr_flags426,
	gtypes426,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets426,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names427,
	types427,
	attr_flags427,
	gtypes427,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets427,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names428,
	types428,
	attr_flags428,
	gtypes428,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets428,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names429,
	types429,
	attr_flags429,
	gtypes429,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets429,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names430,
	types430,
	attr_flags430,
	gtypes430,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets430,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_32_ITERATION_CURSOR",
	names431,
	types431,
	attr_flags431,
	gtypes431,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets431,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_8_ITERATION_CURSOR",
	names432,
	types432,
	attr_flags432,
	gtypes432,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets432,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names433,
	types433,
	attr_flags433,
	gtypes433,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets433,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names434,
	types434,
	attr_flags434,
	gtypes434,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets434,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names435,
	types435,
	attr_flags435,
	gtypes435,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets435,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names436,
	types436,
	attr_flags436,
	gtypes436,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets436,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names437,
	types437,
	attr_flags437,
	gtypes437,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets437,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names438,
	types438,
	attr_flags438,
	gtypes438,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets438,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names439,
	types439,
	attr_flags439,
	gtypes439,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets439,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names440,
	types440,
	attr_flags440,
	gtypes440,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets440,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names441,
	types441,
	attr_flags441,
	gtypes441,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets441,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names442,
	types442,
	attr_flags442,
	gtypes442,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets442,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names443,
	types443,
	attr_flags443,
	gtypes443,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets443,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names444,
	types444,
	attr_flags444,
	gtypes444,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets444,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names445,
	types445,
	attr_flags445,
	gtypes445,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets445,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names446,
	types446,
	attr_flags446,
	gtypes446,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets446,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names447,
	types447,
	attr_flags447,
	gtypes447,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets447,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names448,
	types448,
	attr_flags448,
	gtypes448,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets448,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names449,
	types449,
	attr_flags449,
	gtypes449,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets449,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names450,
	types450,
	attr_flags450,
	gtypes450,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets450,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names451,
	types451,
	attr_flags451,
	gtypes451,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets451,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names452,
	types452,
	attr_flags452,
	gtypes452,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets452,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names453,
	types453,
	attr_flags453,
	gtypes453,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets453,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names454,
	types454,
	attr_flags454,
	gtypes454,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets454,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names455,
	types455,
	attr_flags455,
	gtypes455,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets455,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names456,
	types456,
	attr_flags456,
	gtypes456,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets456,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names457,
	types457,
	attr_flags457,
	gtypes457,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets457,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names458,
	types458,
	attr_flags458,
	gtypes458,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets458,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names459,
	types459,
	attr_flags459,
	gtypes459,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets459,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names460,
	types460,
	attr_flags460,
	gtypes460,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets460,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names461,
	types461,
	attr_flags461,
	gtypes461,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets461,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names462,
	types462,
	attr_flags462,
	gtypes462,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets462,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names463,
	types463,
	attr_flags463,
	gtypes463,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets463,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names464,
	types464,
	attr_flags464,
	gtypes464,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets464,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names465,
	types465,
	attr_flags465,
	gtypes465,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets465,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names466,
	types466,
	attr_flags466,
	gtypes466,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets466,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names467,
	types467,
	attr_flags467,
	gtypes467,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets467,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names468,
	types468,
	attr_flags468,
	gtypes468,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets468,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names469,
	types469,
	attr_flags469,
	gtypes469,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets469,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names470,
	types470,
	attr_flags470,
	gtypes470,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets470,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names471,
	types471,
	attr_flags471,
	gtypes471,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets471,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names472,
	types472,
	attr_flags472,
	gtypes472,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets472,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names473,
	types473,
	attr_flags473,
	gtypes473,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets473,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names474,
	types474,
	attr_flags474,
	gtypes474,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets474,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names475,
	types475,
	attr_flags475,
	gtypes475,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets475,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names476,
	types476,
	attr_flags476,
	gtypes476,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets476,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names477,
	types477,
	attr_flags477,
	gtypes477,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets477,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names478,
	types478,
	attr_flags478,
	gtypes478,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets478,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names479,
	types479,
	attr_flags479,
	gtypes479,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets479,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names480,
	types480,
	attr_flags480,
	gtypes480,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets480,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names481,
	types481,
	attr_flags481,
	gtypes481,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets481,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names482,
	types482,
	attr_flags482,
	gtypes482,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets482,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names483,
	types483,
	attr_flags483,
	gtypes483,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets483,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names484,
	types484,
	attr_flags484,
	gtypes484,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets484,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names485,
	types485,
	attr_flags485,
	gtypes485,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets485,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names486,
	types486,
	attr_flags486,
	gtypes486,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets486,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names487,
	types487,
	attr_flags487,
	gtypes487,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets487,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names488,
	types488,
	attr_flags488,
	gtypes488,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets488,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names489,
	types489,
	attr_flags489,
	gtypes489,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets489,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names490,
	types490,
	attr_flags490,
	gtypes490,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets490,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names491,
	types491,
	attr_flags491,
	gtypes491,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets491,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names492,
	types492,
	attr_flags492,
	gtypes492,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets492,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names493,
	types493,
	attr_flags493,
	gtypes493,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets493,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names494,
	types494,
	attr_flags494,
	gtypes494,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets494,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names495,
	types495,
	attr_flags495,
	gtypes495,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets495,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names496,
	types496,
	attr_flags496,
	gtypes496,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets496,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names497,
	types497,
	attr_flags497,
	gtypes497,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets497,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names498,
	types498,
	attr_flags498,
	gtypes498,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets498,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names499,
	types499,
	attr_flags499,
	gtypes499,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets499,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names500,
	types500,
	attr_flags500,
	gtypes500,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets500,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names501,
	types501,
	attr_flags501,
	gtypes501,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets501,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names502,
	types502,
	attr_flags502,
	gtypes502,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets502,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names503,
	types503,
	attr_flags503,
	gtypes503,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets503,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names504,
	types504,
	attr_flags504,
	gtypes504,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets504,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names505,
	types505,
	attr_flags505,
	gtypes505,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets505,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names506,
	types506,
	attr_flags506,
	gtypes506,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets506,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names507,
	types507,
	attr_flags507,
	gtypes507,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets507,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names508,
	types508,
	attr_flags508,
	gtypes508,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets508,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names509,
	types509,
	attr_flags509,
	gtypes509,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets509,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names510,
	types510,
	attr_flags510,
	gtypes510,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets510,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names511,
	types511,
	attr_flags511,
	gtypes511,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets511,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names512,
	types512,
	attr_flags512,
	gtypes512,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets512,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names513,
	types513,
	attr_flags513,
	gtypes513,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets513,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names514,
	types514,
	attr_flags514,
	gtypes514,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets514,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names515,
	types515,
	attr_flags515,
	gtypes515,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets515,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names516,
	types516,
	attr_flags516,
	gtypes516,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets516,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SET",
	names517,
	types517,
	attr_flags517,
	gtypes517,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets517,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names518,
	types518,
	attr_flags518,
	gtypes518,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets518,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names519,
	types519,
	attr_flags519,
	gtypes519,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets519,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names520,
	types520,
	attr_flags520,
	gtypes520,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets520,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names521,
	types521,
	attr_flags521,
	gtypes521,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets521,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names522,
	types522,
	attr_flags522,
	gtypes522,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets522,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names523,
	types523,
	attr_flags523,
	gtypes523,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets523,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names524,
	types524,
	attr_flags524,
	gtypes524,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets524,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names525,
	types525,
	attr_flags525,
	gtypes525,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets525,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names526,
	types526,
	attr_flags526,
	gtypes526,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets526,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names527,
	types527,
	attr_flags527,
	gtypes527,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets527,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names528,
	types528,
	attr_flags528,
	gtypes528,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets528,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names529,
	types529,
	attr_flags529,
	gtypes529,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets529,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names530,
	types530,
	attr_flags530,
	gtypes530,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets530,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names531,
	types531,
	attr_flags531,
	gtypes531,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets531,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names532,
	types532,
	attr_flags532,
	gtypes532,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets532,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names533,
	types533,
	attr_flags533,
	gtypes533,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets533,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names534,
	types534,
	attr_flags534,
	gtypes534,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets534,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names535,
	types535,
	attr_flags535,
	gtypes535,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets535,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names536,
	types536,
	attr_flags536,
	gtypes536,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets536,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names537,
	types537,
	attr_flags537,
	gtypes537,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets537,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names538,
	types538,
	attr_flags538,
	gtypes538,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets538,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names539,
	types539,
	attr_flags539,
	gtypes539,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets539,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names540,
	types540,
	attr_flags540,
	gtypes540,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets540,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names541,
	types541,
	attr_flags541,
	gtypes541,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets541,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names542,
	types542,
	attr_flags542,
	gtypes542,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets542,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names543,
	types543,
	attr_flags543,
	gtypes543,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets543,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names544,
	types544,
	attr_flags544,
	gtypes544,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets544,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names545,
	types545,
	attr_flags545,
	gtypes545,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets545,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names546,
	types546,
	attr_flags546,
	gtypes546,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets546,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names547,
	types547,
	attr_flags547,
	gtypes547,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets547,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names548,
	types548,
	attr_flags548,
	gtypes548,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets548,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names549,
	types549,
	attr_flags549,
	gtypes549,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets549,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names550,
	types550,
	attr_flags550,
	gtypes550,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets550,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names551,
	types551,
	attr_flags551,
	gtypes551,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets551,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names552,
	types552,
	attr_flags552,
	gtypes552,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets552,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names553,
	types553,
	attr_flags553,
	gtypes553,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets553,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names554,
	types554,
	attr_flags554,
	gtypes554,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets554,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names555,
	types555,
	attr_flags555,
	gtypes555,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets555,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names556,
	types556,
	attr_flags556,
	gtypes556,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets556,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names557,
	types557,
	attr_flags557,
	gtypes557,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets557,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names558,
	types558,
	attr_flags558,
	gtypes558,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets558,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names559,
	types559,
	attr_flags559,
	gtypes559,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets559,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names560,
	types560,
	attr_flags560,
	gtypes560,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets560,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names561,
	types561,
	attr_flags561,
	gtypes561,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets561,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names562,
	types562,
	attr_flags562,
	gtypes562,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets562,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names563,
	types563,
	attr_flags563,
	gtypes563,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets563,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names564,
	types564,
	attr_flags564,
	gtypes564,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets564,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names565,
	types565,
	attr_flags565,
	gtypes565,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets565,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names566,
	types566,
	attr_flags566,
	gtypes566,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets566,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names567,
	types567,
	attr_flags567,
	gtypes567,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets567,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names568,
	types568,
	attr_flags568,
	gtypes568,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets568,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names569,
	types569,
	attr_flags569,
	gtypes569,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets569,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names570,
	types570,
	attr_flags570,
	gtypes570,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets570,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names571,
	types571,
	attr_flags571,
	gtypes571,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets571,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names572,
	types572,
	attr_flags572,
	gtypes572,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets572,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names573,
	types573,
	attr_flags573,
	gtypes573,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets573,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names574,
	types574,
	attr_flags574,
	gtypes574,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets574,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names575,
	types575,
	attr_flags575,
	gtypes575,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets575,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names576,
	types576,
	attr_flags576,
	gtypes576,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets576,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names577,
	types577,
	attr_flags577,
	gtypes577,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets577,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names578,
	types578,
	attr_flags578,
	gtypes578,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets578,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names579,
	types579,
	attr_flags579,
	gtypes579,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets579,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names580,
	types580,
	attr_flags580,
	gtypes580,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets580,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names581,
	types581,
	attr_flags581,
	gtypes581,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets581,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names582,
	types582,
	attr_flags582,
	gtypes582,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets582,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names583,
	types583,
	attr_flags583,
	gtypes583,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets583,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names584,
	types584,
	attr_flags584,
	gtypes584,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets584,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names585,
	types585,
	attr_flags585,
	gtypes585,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets585,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names586,
	types586,
	attr_flags586,
	gtypes586,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets586,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names587,
	types587,
	attr_flags587,
	gtypes587,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets587,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names588,
	types588,
	attr_flags588,
	gtypes588,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets588,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names589,
	types589,
	attr_flags589,
	gtypes589,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets589,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names590,
	types590,
	attr_flags590,
	gtypes590,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets590,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names591,
	types591,
	attr_flags591,
	gtypes591,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets591,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names592,
	types592,
	attr_flags592,
	gtypes592,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets592,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names593,
	types593,
	attr_flags593,
	gtypes593,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets593,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names594,
	types594,
	attr_flags594,
	gtypes594,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets594,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names595,
	types595,
	attr_flags595,
	gtypes595,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets595,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INFINITE",
	names596,
	types596,
	attr_flags596,
	gtypes596,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets596,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COUNTABLE",
	names597,
	types597,
	attr_flags597,
	gtypes597,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets597,
	NULL
},
{
	(long) 2,
	(long) 2,
	"COUNTABLE_SEQUENCE",
	names598,
	types598,
	attr_flags598,
	gtypes598,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets598,
	NULL
},
{
	(long) 2,
	(long) 2,
	"PRIMES",
	names599,
	types599,
	attr_flags599,
	gtypes599,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets599,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names600,
	types600,
	attr_flags600,
	gtypes600,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets600,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names601,
	types601,
	attr_flags601,
	gtypes601,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets601,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names602,
	types602,
	attr_flags602,
	gtypes602,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets602,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names603,
	types603,
	attr_flags603,
	gtypes603,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets603,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names604,
	types604,
	attr_flags604,
	gtypes604,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets604,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names605,
	types605,
	attr_flags605,
	gtypes605,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets605,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names606,
	types606,
	attr_flags606,
	gtypes606,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets606,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names607,
	types607,
	attr_flags607,
	gtypes607,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets607,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names608,
	types608,
	attr_flags608,
	gtypes608,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets608,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names609,
	types609,
	attr_flags609,
	gtypes609,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets609,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names610,
	types610,
	attr_flags610,
	gtypes610,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets610,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names611,
	types611,
	attr_flags611,
	gtypes611,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets611,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DISPENSER",
	names612,
	types612,
	attr_flags612,
	gtypes612,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets612,
	NULL
},
{
	(long) 1,
	(long) 1,
	"QUEUE",
	names613,
	types613,
	attr_flags613,
	gtypes613,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets613,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names614,
	types614,
	attr_flags614,
	gtypes614,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets614,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names615,
	types615,
	attr_flags615,
	gtypes615,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets615,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names616,
	types616,
	attr_flags616,
	gtypes616,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets616,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names617,
	types617,
	attr_flags617,
	gtypes617,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets617,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names618,
	types618,
	attr_flags618,
	gtypes618,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets618,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names619,
	types619,
	attr_flags619,
	gtypes619,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets619,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names620,
	types620,
	attr_flags620,
	gtypes620,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets620,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names621,
	types621,
	attr_flags621,
	gtypes621,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets621,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names622,
	types622,
	attr_flags622,
	gtypes622,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets622,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names623,
	types623,
	attr_flags623,
	gtypes623,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets623,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names624,
	types624,
	attr_flags624,
	gtypes624,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets624,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names625,
	types625,
	attr_flags625,
	gtypes625,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets625,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names626,
	types626,
	attr_flags626,
	gtypes626,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets626,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names627,
	types627,
	attr_flags627,
	gtypes627,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets627,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names628,
	types628,
	attr_flags628,
	gtypes628,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets628,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names629,
	types629,
	attr_flags629,
	gtypes629,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets629,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names630,
	types630,
	attr_flags630,
	gtypes630,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets630,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names631,
	types631,
	attr_flags631,
	gtypes631,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets631,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names632,
	types632,
	attr_flags632,
	gtypes632,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets632,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names633,
	types633,
	attr_flags633,
	gtypes633,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets633,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names634,
	types634,
	attr_flags634,
	gtypes634,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets634,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names635,
	types635,
	attr_flags635,
	gtypes635,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets635,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names636,
	types636,
	attr_flags636,
	gtypes636,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets636,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names637,
	types637,
	attr_flags637,
	gtypes637,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets637,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names638,
	types638,
	attr_flags638,
	gtypes638,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets638,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names639,
	types639,
	attr_flags639,
	gtypes639,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets639,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names640,
	types640,
	attr_flags640,
	gtypes640,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets640,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names641,
	types641,
	attr_flags641,
	gtypes641,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets641,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names642,
	types642,
	attr_flags642,
	gtypes642,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets642,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names643,
	types643,
	attr_flags643,
	gtypes643,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets643,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names644,
	types644,
	attr_flags644,
	gtypes644,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets644,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names645,
	types645,
	attr_flags645,
	gtypes645,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets645,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names646,
	types646,
	attr_flags646,
	gtypes646,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets646,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names647,
	types647,
	attr_flags647,
	gtypes647,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets647,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names648,
	types648,
	attr_flags648,
	gtypes648,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets648,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names649,
	types649,
	attr_flags649,
	gtypes649,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets649,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names650,
	types650,
	attr_flags650,
	gtypes650,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets650,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names651,
	types651,
	attr_flags651,
	gtypes651,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets651,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names652,
	types652,
	attr_flags652,
	gtypes652,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets652,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names653,
	types653,
	attr_flags653,
	gtypes653,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets653,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names654,
	types654,
	attr_flags654,
	gtypes654,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets654,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names655,
	types655,
	attr_flags655,
	gtypes655,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets655,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names656,
	types656,
	attr_flags656,
	gtypes656,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets656,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names657,
	types657,
	attr_flags657,
	gtypes657,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets657,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names658,
	types658,
	attr_flags658,
	gtypes658,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets658,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names659,
	types659,
	attr_flags659,
	gtypes659,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets659,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names660,
	types660,
	attr_flags660,
	gtypes660,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets660,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names661,
	types661,
	attr_flags661,
	gtypes661,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets661,
	NULL
},
{
	(long) 20,
	(long) 19,
	"FILE",
	names662,
	types662,
	attr_flags662,
	gtypes662,
	(uint16) 0x5400,
	(void (*)()) 0,
	offsets662,
	NULL
},
{
	(long) 21,
	(long) 20,
	"RAW_FILE",
	names663,
	types663,
	attr_flags663,
	gtypes663,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets663,
	NULL
},
{
	(long) 23,
	(long) 22,
	"PLAIN_TEXT_FILE",
	names664,
	types664,
	attr_flags664,
	gtypes664,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets664,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names689,
	types689,
	attr_flags689,
	gtypes689,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets689,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names690,
	types690,
	attr_flags690,
	gtypes690,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets690,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names691,
	types691,
	attr_flags691,
	gtypes691,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets691,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names692,
	types692,
	attr_flags692,
	gtypes692,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets692,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names693,
	types693,
	attr_flags693,
	gtypes693,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets693,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names694,
	types694,
	attr_flags694,
	gtypes694,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets694,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names695,
	types695,
	attr_flags695,
	gtypes695,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets695,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names696,
	types696,
	attr_flags696,
	gtypes696,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets696,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names697,
	types697,
	attr_flags697,
	gtypes697,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets697,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names698,
	types698,
	attr_flags698,
	gtypes698,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets698,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names699,
	types699,
	attr_flags699,
	gtypes699,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets699,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names700,
	types700,
	attr_flags700,
	gtypes700,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets700,
	NULL
},
{
	(long) 3,
	(long) 3,
	"INTEGER_INTERVAL",
	names701,
	types701,
	attr_flags701,
	gtypes701,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets701,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names702,
	types702,
	attr_flags702,
	gtypes702,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets702,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names703,
	types703,
	attr_flags703,
	gtypes703,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets703,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names704,
	types704,
	attr_flags704,
	gtypes704,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets704,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names705,
	types705,
	attr_flags705,
	gtypes705,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets705,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names706,
	types706,
	attr_flags706,
	gtypes706,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets706,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names707,
	types707,
	attr_flags707,
	gtypes707,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets707,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names708,
	types708,
	attr_flags708,
	gtypes708,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets708,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names709,
	types709,
	attr_flags709,
	gtypes709,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets709,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names710,
	types710,
	attr_flags710,
	gtypes710,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets710,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names711,
	types711,
	attr_flags711,
	gtypes711,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets711,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names712,
	types712,
	attr_flags712,
	gtypes712,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets712,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names713,
	types713,
	attr_flags713,
	gtypes713,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets713,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names714,
	types714,
	attr_flags714,
	gtypes714,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets714,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names715,
	types715,
	attr_flags715,
	gtypes715,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets715,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names716,
	types716,
	attr_flags716,
	gtypes716,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets716,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names717,
	types717,
	attr_flags717,
	gtypes717,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets717,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names718,
	types718,
	attr_flags718,
	gtypes718,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets718,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names719,
	types719,
	attr_flags719,
	gtypes719,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets719,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names720,
	types720,
	attr_flags720,
	gtypes720,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets720,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names721,
	types721,
	attr_flags721,
	gtypes721,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets721,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names722,
	types722,
	attr_flags722,
	gtypes722,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets722,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names723,
	types723,
	attr_flags723,
	gtypes723,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets723,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names724,
	types724,
	attr_flags724,
	gtypes724,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets724,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names725,
	types725,
	attr_flags725,
	gtypes725,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets725,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names726,
	types726,
	attr_flags726,
	gtypes726,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets726,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names727,
	types727,
	attr_flags727,
	gtypes727,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets727,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names728,
	types728,
	attr_flags728,
	gtypes728,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets728,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names729,
	types729,
	attr_flags729,
	gtypes729,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets729,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names730,
	types730,
	attr_flags730,
	gtypes730,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets730,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names731,
	types731,
	attr_flags731,
	gtypes731,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets731,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names732,
	types732,
	attr_flags732,
	gtypes732,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets732,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names733,
	types733,
	attr_flags733,
	gtypes733,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets733,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names734,
	types734,
	attr_flags734,
	gtypes734,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets734,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names735,
	types735,
	attr_flags735,
	gtypes735,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets735,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names736,
	types736,
	attr_flags736,
	gtypes736,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets736,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names737,
	types737,
	attr_flags737,
	gtypes737,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets737,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names738,
	types738,
	attr_flags738,
	gtypes738,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets738,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names739,
	types739,
	attr_flags739,
	gtypes739,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets739,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names740,
	types740,
	attr_flags740,
	gtypes740,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets740,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names741,
	types741,
	attr_flags741,
	gtypes741,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets741,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names742,
	types742,
	attr_flags742,
	gtypes742,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets742,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names743,
	types743,
	attr_flags743,
	gtypes743,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets743,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names744,
	types744,
	attr_flags744,
	gtypes744,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets744,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names745,
	types745,
	attr_flags745,
	gtypes745,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets745,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names746,
	types746,
	attr_flags746,
	gtypes746,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets746,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names747,
	types747,
	attr_flags747,
	gtypes747,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets747,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names748,
	types748,
	attr_flags748,
	gtypes748,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets748,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names749,
	types749,
	attr_flags749,
	gtypes749,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets749,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names750,
	types750,
	attr_flags750,
	gtypes750,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets750,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names751,
	types751,
	attr_flags751,
	gtypes751,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets751,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names752,
	types752,
	attr_flags752,
	gtypes752,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets752,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names753,
	types753,
	attr_flags753,
	gtypes753,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets753,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names754,
	types754,
	attr_flags754,
	gtypes754,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets754,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names755,
	types755,
	attr_flags755,
	gtypes755,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets755,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names756,
	types756,
	attr_flags756,
	gtypes756,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets756,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names757,
	types757,
	attr_flags757,
	gtypes757,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets757,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names758,
	types758,
	attr_flags758,
	gtypes758,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets758,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names759,
	types759,
	attr_flags759,
	gtypes759,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets759,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names760,
	types760,
	attr_flags760,
	gtypes760,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets760,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names761,
	types761,
	attr_flags761,
	gtypes761,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets761,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names762,
	types762,
	attr_flags762,
	gtypes762,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets762,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names763,
	types763,
	attr_flags763,
	gtypes763,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets763,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names764,
	types764,
	attr_flags764,
	gtypes764,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets764,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names765,
	types765,
	attr_flags765,
	gtypes765,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets765,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names766,
	types766,
	attr_flags766,
	gtypes766,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets766,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names767,
	types767,
	attr_flags767,
	gtypes767,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets767,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_LIST",
	names768,
	types768,
	attr_flags768,
	gtypes768,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets768,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_LIST",
	names769,
	types769,
	attr_flags769,
	gtypes769,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets769,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_DIRECTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MISMATCH_CORRECTOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_QUEUE",
	names773,
	types773,
	attr_flags773,
	gtypes773,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets773,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names774,
	types774,
	attr_flags774,
	gtypes774,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets774,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names775,
	types775,
	attr_flags775,
	gtypes775,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets775,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names776,
	types776,
	attr_flags776,
	gtypes776,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets776,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names777,
	types777,
	attr_flags777,
	gtypes777,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets777,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names778,
	types778,
	attr_flags778,
	gtypes778,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets778,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names779,
	types779,
	attr_flags779,
	gtypes779,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets779,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names780,
	types780,
	attr_flags780,
	gtypes780,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets780,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names781,
	types781,
	attr_flags781,
	gtypes781,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets781,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names782,
	types782,
	attr_flags782,
	gtypes782,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets782,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names783,
	types783,
	attr_flags783,
	gtypes783,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets783,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names784,
	types784,
	attr_flags784,
	gtypes784,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets784,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names785,
	types785,
	attr_flags785,
	gtypes785,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets785,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names786,
	types786,
	attr_flags786,
	gtypes786,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets786,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names787,
	types787,
	attr_flags787,
	gtypes787,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets787,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names788,
	types788,
	attr_flags788,
	gtypes788,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets788,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names789,
	types789,
	attr_flags789,
	gtypes789,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets789,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names790,
	types790,
	attr_flags790,
	gtypes790,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets790,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names791,
	types791,
	attr_flags791,
	gtypes791,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets791,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names792,
	types792,
	attr_flags792,
	gtypes792,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets792,
	NULL
},
{
	(long) 19,
	(long) 19,
	"MISMATCH_INFORMATION",
	names793,
	types793,
	attr_flags793,
	gtypes793,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets793,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_INTEGER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"HASHABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"PATH",
	names796,
	types796,
	attr_flags796,
	gtypes796,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets796,
	NULL
},
{
	(long) 9,
	(long) 9,
	"LX_SYMBOL_CLASS",
	names797,
	types797,
	attr_flags797,
	gtypes797,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets797,
	"20190721"
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names798,
	types798,
	attr_flags798,
	gtypes798,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets798,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names799,
	types799,
	attr_flags799,
	gtypes799,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets799,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names800,
	types800,
	attr_flags800,
	gtypes800,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets800,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names801,
	types801,
	attr_flags801,
	gtypes801,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets801,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names802,
	types802,
	attr_flags802,
	gtypes802,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets802,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names803,
	types803,
	attr_flags803,
	gtypes803,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets803,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names804,
	types804,
	attr_flags804,
	gtypes804,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets804,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names805,
	types805,
	attr_flags805,
	gtypes805,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets805,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names806,
	types806,
	attr_flags806,
	gtypes806,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets806,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names807,
	types807,
	attr_flags807,
	gtypes807,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets807,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names808,
	types808,
	attr_flags808,
	gtypes808,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets808,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names809,
	types809,
	attr_flags809,
	gtypes809,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets809,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names810,
	types810,
	attr_flags810,
	gtypes810,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets810,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names811,
	types811,
	attr_flags811,
	gtypes811,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets811,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names812,
	types812,
	attr_flags812,
	gtypes812,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets812,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names813,
	types813,
	attr_flags813,
	gtypes813,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets813,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names814,
	types814,
	attr_flags814,
	gtypes814,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets814,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names815,
	types815,
	attr_flags815,
	gtypes815,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets815,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names816,
	types816,
	attr_flags816,
	gtypes816,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets816,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names817,
	types817,
	attr_flags817,
	gtypes817,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets817,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names818,
	types818,
	attr_flags818,
	gtypes818,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets818,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names819,
	types819,
	attr_flags819,
	gtypes819,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets819,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names820,
	types820,
	attr_flags820,
	gtypes820,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets820,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names821,
	types821,
	attr_flags821,
	gtypes821,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets821,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names822,
	types822,
	attr_flags822,
	gtypes822,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets822,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names823,
	types823,
	attr_flags823,
	gtypes823,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets823,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names824,
	types824,
	attr_flags824,
	gtypes824,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets824,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names825,
	types825,
	attr_flags825,
	gtypes825,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets825,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names826,
	types826,
	attr_flags826,
	gtypes826,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets826,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names827,
	types827,
	attr_flags827,
	gtypes827,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets827,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names828,
	types828,
	attr_flags828,
	gtypes828,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets828,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TUPLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64_REF",
	names830,
	types830,
	attr_flags830,
	gtypes830,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets830,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64",
	names831,
	types831,
	attr_flags831,
	gtypes831,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets831,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64",
	names832,
	types832,
	attr_flags832,
	gtypes832,
	(uint16) 0x2309,
	(void (*)()) 0,
	offsets832,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32_REF",
	names833,
	types833,
	attr_flags833,
	gtypes833,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets833,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32",
	names834,
	types834,
	attr_flags834,
	gtypes834,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets834,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32",
	names835,
	types835,
	attr_flags835,
	gtypes835,
	(uint16) 0x2308,
	(void (*)()) 0,
	offsets835,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16_REF",
	names836,
	types836,
	attr_flags836,
	gtypes836,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets836,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16",
	names837,
	types837,
	attr_flags837,
	gtypes837,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets837,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16",
	names838,
	types838,
	attr_flags838,
	gtypes838,
	(uint16) 0x2307,
	(void (*)()) 0,
	offsets838,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8_REF",
	names839,
	types839,
	attr_flags839,
	gtypes839,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets839,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8",
	names840,
	types840,
	attr_flags840,
	gtypes840,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets840,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8",
	names841,
	types841,
	attr_flags841,
	gtypes841,
	(uint16) 0x2306,
	(void (*)()) 0,
	offsets841,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64_REF",
	names842,
	types842,
	attr_flags842,
	gtypes842,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets842,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64",
	names843,
	types843,
	attr_flags843,
	gtypes843,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets843,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64",
	names844,
	types844,
	attr_flags844,
	gtypes844,
	(uint16) 0x230D,
	(void (*)()) 0,
	offsets844,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32_REF",
	names845,
	types845,
	attr_flags845,
	gtypes845,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets845,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32",
	names846,
	types846,
	attr_flags846,
	gtypes846,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets846,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32",
	names847,
	types847,
	attr_flags847,
	gtypes847,
	(uint16) 0x230C,
	(void (*)()) 0,
	offsets847,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16_REF",
	names848,
	types848,
	attr_flags848,
	gtypes848,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets848,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16",
	names849,
	types849,
	attr_flags849,
	gtypes849,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets849,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16",
	names850,
	types850,
	attr_flags850,
	gtypes850,
	(uint16) 0x230B,
	(void (*)()) 0,
	offsets850,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8_REF",
	names851,
	types851,
	attr_flags851,
	gtypes851,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets851,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8",
	names852,
	types852,
	attr_flags852,
	gtypes852,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets852,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8",
	names853,
	types853,
	attr_flags853,
	gtypes853,
	(uint16) 0x230A,
	(void (*)()) 0,
	offsets853,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32_REF",
	names854,
	types854,
	attr_flags854,
	gtypes854,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets854,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32",
	names855,
	types855,
	attr_flags855,
	gtypes855,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets855,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32",
	names856,
	types856,
	attr_flags856,
	gtypes856,
	(uint16) 0x2304,
	(void (*)()) 0,
	offsets856,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64_REF",
	names857,
	types857,
	attr_flags857,
	gtypes857,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets857,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64",
	names858,
	types858,
	attr_flags858,
	gtypes858,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets858,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64",
	names859,
	types859,
	attr_flags859,
	gtypes859,
	(uint16) 0x2303,
	(void (*)()) 0,
	offsets859,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32_REF",
	names860,
	types860,
	attr_flags860,
	gtypes860,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets860,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32",
	names861,
	types861,
	attr_flags861,
	gtypes861,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets861,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32",
	names862,
	types862,
	attr_flags862,
	gtypes862,
	(uint16) 0x230E,
	(void (*)()) 0,
	offsets862,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8_REF",
	names863,
	types863,
	attr_flags863,
	gtypes863,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets863,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8",
	names864,
	types864,
	attr_flags864,
	gtypes864,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets864,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8",
	names865,
	types865,
	attr_flags865,
	gtypes865,
	(uint16) 0x2302,
	(void (*)()) 0,
	offsets865,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN_REF",
	names866,
	types866,
	attr_flags866,
	gtypes866,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets866,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN",
	names867,
	types867,
	attr_flags867,
	gtypes867,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets867,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN",
	names868,
	types868,
	attr_flags868,
	gtypes868,
	(uint16) 0x2301,
	(void (*)()) 0,
	offsets868,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER_REF",
	names869,
	types869,
	attr_flags869,
	gtypes869,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets869,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names870,
	types870,
	attr_flags870,
	gtypes870,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets870,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names871,
	types871,
	attr_flags871,
	gtypes871,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets871,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names872,
	types872,
	attr_flags872,
	gtypes872,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets872,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names873,
	types873,
	attr_flags873,
	gtypes873,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets873,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names874,
	types874,
	attr_flags874,
	gtypes874,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets874,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names875,
	types875,
	attr_flags875,
	gtypes875,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets875,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names876,
	types876,
	attr_flags876,
	gtypes876,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets876,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names877,
	types877,
	attr_flags877,
	gtypes877,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets877,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names878,
	types878,
	attr_flags878,
	gtypes878,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets878,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names879,
	types879,
	attr_flags879,
	gtypes879,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets879,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names880,
	types880,
	attr_flags880,
	gtypes880,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets880,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names881,
	types881,
	attr_flags881,
	gtypes881,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets881,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names882,
	types882,
	attr_flags882,
	gtypes882,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets882,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names883,
	types883,
	attr_flags883,
	gtypes883,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets883,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names884,
	types884,
	attr_flags884,
	gtypes884,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets884,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names885,
	types885,
	attr_flags885,
	gtypes885,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets885,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names886,
	types886,
	attr_flags886,
	gtypes886,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets886,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names887,
	types887,
	attr_flags887,
	gtypes887,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets887,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names888,
	types888,
	attr_flags888,
	gtypes888,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets888,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names889,
	types889,
	attr_flags889,
	gtypes889,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets889,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names890,
	types890,
	attr_flags890,
	gtypes890,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets890,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names891,
	types891,
	attr_flags891,
	gtypes891,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets891,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names892,
	types892,
	attr_flags892,
	gtypes892,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets892,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names893,
	types893,
	attr_flags893,
	gtypes893,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets893,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names894,
	types894,
	attr_flags894,
	gtypes894,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets894,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names895,
	types895,
	attr_flags895,
	gtypes895,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets895,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names896,
	types896,
	attr_flags896,
	gtypes896,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets896,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names897,
	types897,
	attr_flags897,
	gtypes897,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets897,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names898,
	types898,
	attr_flags898,
	gtypes898,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets898,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names899,
	types899,
	attr_flags899,
	gtypes899,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets899,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER",
	names900,
	types900,
	attr_flags900,
	gtypes900,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets900,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER",
	names901,
	types901,
	attr_flags901,
	gtypes901,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets901,
	NULL
},
{
	(long) 12,
	(long) 12,
	"ROUTINE",
	names902,
	types902,
	attr_flags902,
	gtypes902,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets902,
	NULL
},
{
	(long) 12,
	(long) 12,
	"PROCEDURE",
	names903,
	types903,
	attr_flags903,
	gtypes903,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets903,
	NULL
},
{
	(long) 13,
	(long) 13,
	"FUNCTION",
	names904,
	types904,
	attr_flags904,
	gtypes904,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets904,
	NULL
},
{
	(long) 13,
	(long) 13,
	"FUNCTION",
	names905,
	types905,
	attr_flags905,
	gtypes905,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets905,
	NULL
},
{
	(long) 13,
	(long) 13,
	"PREDICATE",
	names906,
	types906,
	attr_flags906,
	gtypes906,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets906,
	NULL
},
{
	(long) 2,
	(long) 2,
	"READABLE_STRING_GENERAL",
	names907,
	types907,
	attr_flags907,
	gtypes907,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets907,
	NULL
},
{
	(long) 2,
	(long) 2,
	"IMMUTABLE_STRING_GENERAL",
	names908,
	types908,
	attr_flags908,
	gtypes908,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets908,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_GENERAL",
	names909,
	types909,
	attr_flags909,
	gtypes909,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets909,
	NULL
},
{
	(long) 4,
	(long) 4,
	"READABLE_STRING_32",
	names910,
	types910,
	attr_flags910,
	gtypes910,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets910,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IMMUTABLE_STRING_32",
	names911,
	types911,
	attr_flags911,
	gtypes911,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets911,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_32",
	names912,
	types912,
	attr_flags912,
	gtypes912,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets912,
	NULL
},
{
	(long) 4,
	(long) 4,
	"READABLE_STRING_8",
	names913,
	types913,
	attr_flags913,
	gtypes913,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets913,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IMMUTABLE_STRING_8",
	names914,
	types914,
	attr_flags914,
	gtypes914,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets914,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_8",
	names915,
	types915,
	attr_flags915,
	gtypes915,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets915,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_STRING",
	names916,
	types916,
	attr_flags916,
	gtypes916,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets916,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_STRING_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_CASE_INSENSITIVE_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ST_WORD_WRAPPER",
	names920,
	types920,
	attr_flags920,
	gtypes920,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets920,
	NULL
},
{
	(long) 0,
	(long) 0,
	"AP_OPTION_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UC_CHARACTER",
	names922,
	types922,
	attr_flags922,
	gtypes922,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets922,
	NULL
},
{
	(long) 1,
	(long) 1,
	"GELEX_COMMAND_LINE",
	names923,
	types923,
	attr_flags923,
	gtypes923,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets923,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_CHARACTER_OUTPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_OUTPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BINARY_OUTPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_OUTPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STDERR_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STDOUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_NULL_TEXT_OUTPUT_STREAM",
	names930,
	types930,
	attr_flags930,
	gtypes930,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets930,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_OUTPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_ANY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_NATURAL_32_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UTF32_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UTF16_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STRING_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_INTEGER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UTF8_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_CHARACTER_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_STDIN_FILE",
	names947,
	types947,
	attr_flags947,
	gtypes947,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets947,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_STRING_INPUT_STREAM",
	names948,
	types948,
	attr_flags948,
	gtypes948,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets948,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_INPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BINARY_INPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_INPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"RX_BYTE_CODE",
	names952,
	types952,
	attr_flags952,
	gtypes952,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets952,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_INTEGER_FORMATTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 23,
	(long) 22,
	"CONSOLE",
	names954,
	types954,
	attr_flags954,
	gtypes954,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets954,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RX_PCRE_ESCAPE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE_TITLECASE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE_UPPERCASE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE_LOWERCASE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_CTYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"YY_SCANNER",
	names967,
	types967,
	attr_flags967,
	gtypes967,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets967,
	NULL
},
{
	(long) 22,
	(long) 22,
	"YY_SCANNER_SKELETON",
	names968,
	types968,
	attr_flags968,
	gtypes968,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets968,
	NULL
},
{
	(long) 25,
	(long) 25,
	"YY_FULL_SCANNER_SKELETON",
	names969,
	types969,
	attr_flags969,
	gtypes969,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets969,
	NULL
},
{
	(long) 38,
	(long) 38,
	"YY_COMPRESSED_SCANNER_SKELETON",
	names970,
	types970,
	attr_flags970,
	gtypes970,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets970,
	NULL
},
{
	(long) 58,
	(long) 58,
	"LX_LEX_SCANNER_SKELETON",
	names971,
	types971,
	attr_flags971,
	gtypes971,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets971,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ENCODING_I",
	names972,
	types972,
	attr_flags972,
	gtypes972,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets972,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ENCODING_IMP",
	names973,
	types973,
	attr_flags973,
	gtypes973,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets973,
	NULL
},
{
	(long) 3,
	(long) 3,
	"UNICODE_CONVERSION",
	names974,
	types974,
	attr_flags974,
	gtypes974,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets974,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CURSOR",
	names975,
	types975,
	attr_flags975,
	gtypes975,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets975,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CURSOR",
	names976,
	types976,
	attr_flags976,
	gtypes976,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets976,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CURSOR",
	names977,
	types977,
	attr_flags977,
	gtypes977,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets977,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CURSOR",
	names978,
	types978,
	attr_flags978,
	gtypes978,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets978,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CURSOR",
	names979,
	types979,
	attr_flags979,
	gtypes979,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets979,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CURSOR",
	names980,
	types980,
	attr_flags980,
	gtypes980,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets980,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_INDEXED_CURSOR",
	names981,
	types981,
	attr_flags981,
	gtypes981,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets981,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_INDEXED_CURSOR",
	names982,
	types982,
	attr_flags982,
	gtypes982,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets982,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_INDEXED_CURSOR",
	names983,
	types983,
	attr_flags983,
	gtypes983,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets983,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_INDEXED_CURSOR",
	names984,
	types984,
	attr_flags984,
	gtypes984,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets984,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_DYNAMIC_CURSOR",
	names985,
	types985,
	attr_flags985,
	gtypes985,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets985,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_DYNAMIC_CURSOR",
	names986,
	types986,
	attr_flags986,
	gtypes986,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets986,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_DYNAMIC_CURSOR",
	names987,
	types987,
	attr_flags987,
	gtypes987,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets987,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_DYNAMIC_CURSOR",
	names988,
	types988,
	attr_flags988,
	gtypes988,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets988,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_DYNAMIC_CURSOR",
	names989,
	types989,
	attr_flags989,
	gtypes989,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets989,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR_CURSOR",
	names990,
	types990,
	attr_flags990,
	gtypes990,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets990,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR_CURSOR",
	names991,
	types991,
	attr_flags991,
	gtypes991,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets991,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR_CURSOR",
	names992,
	types992,
	attr_flags992,
	gtypes992,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets992,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR_CURSOR",
	names993,
	types993,
	attr_flags993,
	gtypes993,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets993,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR_CURSOR",
	names994,
	types994,
	attr_flags994,
	gtypes994,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets994,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR_CURSOR",
	names995,
	types995,
	attr_flags995,
	gtypes995,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets995,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SET_CURSOR",
	names996,
	types996,
	attr_flags996,
	gtypes996,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets996,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SET_CURSOR",
	names997,
	types997,
	attr_flags997,
	gtypes997,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets997,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_CURSOR",
	names998,
	types998,
	attr_flags998,
	gtypes998,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets998,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_CURSOR",
	names999,
	types999,
	attr_flags999,
	gtypes999,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets999,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_CURSOR",
	names1000,
	types1000,
	attr_flags1000,
	gtypes1000,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1000,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_CURSOR",
	names1001,
	types1001,
	attr_flags1001,
	gtypes1001,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1001,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_CURSOR",
	names1002,
	types1002,
	attr_flags1002,
	gtypes1002,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1002,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_CURSOR",
	names1003,
	types1003,
	attr_flags1003,
	gtypes1003,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1003,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS_CURSOR",
	names1004,
	types1004,
	attr_flags1004,
	gtypes1004,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1004,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS_CURSOR",
	names1005,
	types1005,
	attr_flags1005,
	gtypes1005,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1005,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS_CURSOR",
	names1006,
	types1006,
	attr_flags1006,
	gtypes1006,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1006,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS_CURSOR",
	names1007,
	types1007,
	attr_flags1007,
	gtypes1007,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1007,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE_CURSOR",
	names1008,
	types1008,
	attr_flags1008,
	gtypes1008,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1008,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE_CURSOR",
	names1009,
	types1009,
	attr_flags1009,
	gtypes1009,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1009,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE_CURSOR",
	names1010,
	types1010,
	attr_flags1010,
	gtypes1010,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1010,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE_CURSOR",
	names1011,
	types1011,
	attr_flags1011,
	gtypes1011,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1011,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_CONTAINER_CURSOR",
	names1012,
	types1012,
	attr_flags1012,
	gtypes1012,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1012,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_CONTAINER_CURSOR",
	names1013,
	types1013,
	attr_flags1013,
	gtypes1013,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1013,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_CONTAINER_CURSOR",
	names1014,
	types1014,
	attr_flags1014,
	gtypes1014,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1014,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_CONTAINER_CURSOR",
	names1015,
	types1015,
	attr_flags1015,
	gtypes1015,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1015,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_SET_CURSOR",
	names1016,
	types1016,
	attr_flags1016,
	gtypes1016,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1016,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_SET_CURSOR",
	names1017,
	types1017,
	attr_flags1017,
	gtypes1017,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1017,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_SPARSE_SET_CURSOR",
	names1018,
	types1018,
	attr_flags1018,
	gtypes1018,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1018,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_SPARSE_SET_CURSOR",
	names1019,
	types1019,
	attr_flags1019,
	gtypes1019,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1019,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_HASH_SET_CURSOR",
	names1020,
	types1020,
	attr_flags1020,
	gtypes1020,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1020,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_HASH_SET_CURSOR",
	names1021,
	types1021,
	attr_flags1021,
	gtypes1021,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1021,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_CURSOR",
	names1022,
	types1022,
	attr_flags1022,
	gtypes1022,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1022,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_CURSOR",
	names1023,
	types1023,
	attr_flags1023,
	gtypes1023,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1023,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_CURSOR",
	names1024,
	types1024,
	attr_flags1024,
	gtypes1024,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1024,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_CURSOR",
	names1025,
	types1025,
	attr_flags1025,
	gtypes1025,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1025,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_SPARSE_TABLE_CURSOR",
	names1026,
	types1026,
	attr_flags1026,
	gtypes1026,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1026,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_SPARSE_TABLE_CURSOR",
	names1027,
	types1027,
	attr_flags1027,
	gtypes1027,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1027,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_SPARSE_TABLE_CURSOR",
	names1028,
	types1028,
	attr_flags1028,
	gtypes1028,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1028,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_SPARSE_TABLE_CURSOR",
	names1029,
	types1029,
	attr_flags1029,
	gtypes1029,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1029,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_HASH_TABLE_CURSOR",
	names1030,
	types1030,
	attr_flags1030,
	gtypes1030,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1030,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_HASH_TABLE_CURSOR",
	names1031,
	types1031,
	attr_flags1031,
	gtypes1031,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1031,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_HASH_TABLE_CURSOR",
	names1032,
	types1032,
	attr_flags1032,
	gtypes1032,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1032,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_HASH_TABLE_CURSOR",
	names1033,
	types1033,
	attr_flags1033,
	gtypes1033,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1033,
	"20130823"
},
{
	(long) 1,
	(long) 1,
	"DS_LIST_CURSOR",
	names1034,
	types1034,
	attr_flags1034,
	gtypes1034,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1034,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LIST_CURSOR",
	names1035,
	types1035,
	attr_flags1035,
	gtypes1035,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1035,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LIST_CURSOR",
	names1036,
	types1036,
	attr_flags1036,
	gtypes1036,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1036,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LIST_CURSOR",
	names1037,
	types1037,
	attr_flags1037,
	gtypes1037,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1037,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_LIST_CURSOR",
	names1038,
	types1038,
	attr_flags1038,
	gtypes1038,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1038,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_LIST_CURSOR",
	names1039,
	types1039,
	attr_flags1039,
	gtypes1039,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1039,
	"20130823"
},
{
	(long) 5,
	(long) 5,
	"DS_LINKED_LIST_CURSOR",
	names1040,
	types1040,
	attr_flags1040,
	gtypes1040,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1040,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DS_LINKED_LIST_CURSOR",
	names1041,
	types1041,
	attr_flags1041,
	gtypes1041,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1041,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DS_LINKED_LIST_CURSOR",
	names1042,
	types1042,
	attr_flags1042,
	gtypes1042,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1042,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DS_LINKED_LIST_CURSOR",
	names1043,
	types1043,
	attr_flags1043,
	gtypes1043,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1043,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DS_BILINKED_LIST_CURSOR",
	names1044,
	types1044,
	attr_flags1044,
	gtypes1044,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1044,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 11,
	(long) 11,
	"KL_DIRECTORY",
	names1046,
	types1046,
	attr_flags1046,
	gtypes1046,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1046,
	NULL
},
{
	(long) 9,
	(long) 9,
	"AP_BASIC_PARSER",
	names1047,
	types1047,
	attr_flags1047,
	gtypes1047,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1047,
	NULL
},
{
	(long) 10,
	(long) 10,
	"AP_PARSER",
	names1048,
	types1048,
	attr_flags1048,
	gtypes1048,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1048,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_FILE",
	names1049,
	types1049,
	attr_flags1049,
	gtypes1049,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1049,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_OUTPUT_FILE",
	names1050,
	types1050,
	attr_flags1050,
	gtypes1050,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1050,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_TEXT_OUTPUT_FILE",
	names1051,
	types1051,
	attr_flags1051,
	gtypes1051,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets1051,
	NULL
},
{
	(long) 22,
	(long) 21,
	"KL_BINARY_OUTPUT_FILE",
	names1052,
	types1052,
	attr_flags1052,
	gtypes1052,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1052,
	NULL
},
{
	(long) 22,
	(long) 21,
	"KL_UNIX_OUTPUT_FILE",
	names1053,
	types1053,
	attr_flags1053,
	gtypes1053,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1053,
	NULL
},
{
	(long) 22,
	(long) 21,
	"KL_WINDOWS_OUTPUT_FILE",
	names1054,
	types1054,
	attr_flags1054,
	gtypes1054,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1054,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_INPUT_FILE",
	names1055,
	types1055,
	attr_flags1055,
	gtypes1055,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1055,
	NULL
},
{
	(long) 26,
	(long) 25,
	"KL_TEXT_INPUT_FILE",
	names1056,
	types1056,
	attr_flags1056,
	gtypes1056,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets1056,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_BINARY_INPUT_FILE",
	names1057,
	types1057,
	attr_flags1057,
	gtypes1057,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1057,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_UNIX_INPUT_FILE",
	names1058,
	types1058,
	attr_flags1058,
	gtypes1058,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1058,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_WINDOWS_INPUT_FILE",
	names1059,
	types1059,
	attr_flags1059,
	gtypes1059,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1059,
	NULL
},
{
	(long) 11,
	(long) 11,
	"LX_TABLES",
	names1060,
	types1060,
	attr_flags1060,
	gtypes1060,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1060,
	NULL
},
{
	(long) 33,
	(long) 33,
	"LX_SCANNER",
	names1061,
	types1061,
	attr_flags1061,
	gtypes1061,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1061,
	NULL
},
{
	(long) 22,
	(long) 22,
	"LX_COMPRESSED_TABLES",
	names1062,
	types1062,
	attr_flags1062,
	gtypes1062,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1062,
	NULL
},
{
	(long) 61,
	(long) 61,
	"LX_COMPRESSED_SCANNER",
	names1063,
	types1063,
	attr_flags1063,
	gtypes1063,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1063,
	NULL
},
{
	(long) 14,
	(long) 14,
	"LX_FULL_TABLES",
	names1064,
	types1064,
	attr_flags1064,
	gtypes1064,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1064,
	NULL
},
{
	(long) 39,
	(long) 39,
	"LX_FULL_SCANNER",
	names1065,
	types1065,
	attr_flags1065,
	gtypes1065,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1065,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_CLONABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LX_TRANSITION_TABLE",
	names1067,
	types1067,
	attr_flags1067,
	gtypes1067,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1067,
	NULL
},
{
	(long) 0,
	(long) 0,
	"LX_STATE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"LX_NFA_STATE",
	names1069,
	types1069,
	attr_flags1069,
	gtypes1069,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1069,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LX_DFA_STATE",
	names1070,
	types1070,
	attr_flags1070,
	gtypes1070,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1070,
	NULL
},
{
	(long) 0,
	(long) 0,
	"LX_AUTOMATON",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LX_NFA",
	names1072,
	types1072,
	attr_flags1072,
	gtypes1072,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1072,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LX_DFA",
	names1073,
	types1073,
	attr_flags1073,
	gtypes1073,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1073,
	NULL
},
{
	(long) 30,
	(long) 30,
	"LX_GENERATABLE_DFA",
	names1074,
	types1074,
	attr_flags1074,
	gtypes1074,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1074,
	NULL
},
{
	(long) 49,
	(long) 49,
	"LX_COMPRESSED_DFA",
	names1075,
	types1075,
	attr_flags1075,
	gtypes1075,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1075,
	NULL
},
{
	(long) 33,
	(long) 33,
	"LX_FULL_DFA",
	names1076,
	types1076,
	attr_flags1076,
	gtypes1076,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1076,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_TRANSITION",
	names1077,
	types1077,
	attr_flags1077,
	gtypes1077,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1077,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LX_SYMBOL_TRANSITION",
	names1078,
	types1078,
	attr_flags1078,
	gtypes1078,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1078,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LX_SYMBOL_CLASS_TRANSITION",
	names1079,
	types1079,
	attr_flags1079,
	gtypes1079,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1079,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_EPSILON_TRANSITION",
	names1080,
	types1080,
	attr_flags1080,
	gtypes1080,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1080,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_CONTAINER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_CONTAINER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_CONTAINER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_CONTAINER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_CONTAINER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_CONTAINER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_SORTABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_SORTABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_SORTABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_SORTABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TRAVERSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TRAVERSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TRAVERSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TRAVERSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TRAVERSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TRAVERSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SEARCHABLE",
	names1101,
	types1101,
	attr_flags1101,
	gtypes1101,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1101,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SEARCHABLE",
	names1102,
	types1102,
	attr_flags1102,
	gtypes1102,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1102,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SEARCHABLE",
	names1103,
	types1103,
	attr_flags1103,
	gtypes1103,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1103,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SEARCHABLE",
	names1104,
	types1104,
	attr_flags1104,
	gtypes1104,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1104,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SEARCHABLE",
	names1105,
	types1105,
	attr_flags1105,
	gtypes1105,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1105,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SEARCHABLE",
	names1106,
	types1106,
	attr_flags1106,
	gtypes1106,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1106,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR",
	names1107,
	types1107,
	attr_flags1107,
	gtypes1107,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1107,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR",
	names1108,
	types1108,
	attr_flags1108,
	gtypes1108,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1108,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR",
	names1109,
	types1109,
	attr_flags1109,
	gtypes1109,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1109,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR",
	names1110,
	types1110,
	attr_flags1110,
	gtypes1110,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1110,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR",
	names1111,
	types1111,
	attr_flags1111,
	gtypes1111,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1111,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR",
	names1112,
	types1112,
	attr_flags1112,
	gtypes1112,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1112,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR",
	names1113,
	types1113,
	attr_flags1113,
	gtypes1113,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1113,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR",
	names1114,
	types1114,
	attr_flags1114,
	gtypes1114,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1114,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR",
	names1115,
	types1115,
	attr_flags1115,
	gtypes1115,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1115,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR",
	names1116,
	types1116,
	attr_flags1116,
	gtypes1116,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1116,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR",
	names1117,
	types1117,
	attr_flags1117,
	gtypes1117,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1117,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR",
	names1118,
	types1118,
	attr_flags1118,
	gtypes1118,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1118,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS",
	names1119,
	types1119,
	attr_flags1119,
	gtypes1119,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1119,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS",
	names1120,
	types1120,
	attr_flags1120,
	gtypes1120,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1120,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS",
	names1121,
	types1121,
	attr_flags1121,
	gtypes1121,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1121,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS",
	names1122,
	types1122,
	attr_flags1122,
	gtypes1122,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1122,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE",
	names1123,
	types1123,
	attr_flags1123,
	gtypes1123,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1123,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE",
	names1124,
	types1124,
	attr_flags1124,
	gtypes1124,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1124,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE",
	names1125,
	types1125,
	attr_flags1125,
	gtypes1125,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1125,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE",
	names1126,
	types1126,
	attr_flags1126,
	gtypes1126,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1126,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_EXTENDIBLE",
	names1127,
	types1127,
	attr_flags1127,
	gtypes1127,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1127,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_EXTENDIBLE",
	names1128,
	types1128,
	attr_flags1128,
	gtypes1128,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1128,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_EXTENDIBLE",
	names1129,
	types1129,
	attr_flags1129,
	gtypes1129,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1129,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_EXTENDIBLE",
	names1130,
	types1130,
	attr_flags1130,
	gtypes1130,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1130,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SET",
	names1131,
	types1131,
	attr_flags1131,
	gtypes1131,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1131,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SET",
	names1132,
	types1132,
	attr_flags1132,
	gtypes1132,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1132,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_DISPENSER",
	names1133,
	types1133,
	attr_flags1133,
	gtypes1133,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1133,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_DISPENSER",
	names1134,
	types1134,
	attr_flags1134,
	gtypes1134,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1134,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_STACK",
	names1135,
	types1135,
	attr_flags1135,
	gtypes1135,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1135,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_STACK",
	names1136,
	types1136,
	attr_flags1136,
	gtypes1136,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1136,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_INDEXABLE",
	names1137,
	types1137,
	attr_flags1137,
	gtypes1137,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1137,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_INDEXABLE",
	names1138,
	types1138,
	attr_flags1138,
	gtypes1138,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1138,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_INDEXABLE",
	names1139,
	types1139,
	attr_flags1139,
	gtypes1139,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1139,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_INDEXABLE",
	names1140,
	types1140,
	attr_flags1140,
	gtypes1140,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1140,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LIST",
	names1141,
	types1141,
	attr_flags1141,
	gtypes1141,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1141,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LIST",
	names1142,
	types1142,
	attr_flags1142,
	gtypes1142,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1142,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LIST",
	names1143,
	types1143,
	attr_flags1143,
	gtypes1143,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1143,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LIST",
	names1144,
	types1144,
	attr_flags1144,
	gtypes1144,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1144,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DS_LINKED_LIST",
	names1145,
	types1145,
	attr_flags1145,
	gtypes1145,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1145,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DS_LINKED_LIST",
	names1146,
	types1146,
	attr_flags1146,
	gtypes1146,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1146,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DS_LINKED_LIST",
	names1147,
	types1147,
	attr_flags1147,
	gtypes1147,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1147,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DS_LINKED_LIST",
	names1148,
	types1148,
	attr_flags1148,
	gtypes1148,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1148,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LX_TEMPLATE_LIST",
	names1149,
	types1149,
	attr_flags1149,
	gtypes1149,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1149,
	NULL
},
{
	(long) 7,
	(long) 7,
	"AP_ALTERNATIVE_OPTIONS_LIST",
	names1150,
	types1150,
	attr_flags1150,
	gtypes1150,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1150,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DS_BILINKED_LIST",
	names1151,
	types1151,
	attr_flags1151,
	gtypes1151,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1151,
	NULL
},
{
	(long) 5,
	(long) 5,
	"LX_PROTO_QUEUE",
	names1152,
	types1152,
	attr_flags1152,
	gtypes1152,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1152,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_RESIZABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_RESIZABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_RESIZABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_RESIZABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DS_ARRAYED_STACK",
	names1157,
	types1157,
	attr_flags1157,
	gtypes1157,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1157,
	"20130823"
},
{
	(long) 5,
	(long) 5,
	"DS_ARRAYED_STACK",
	names1158,
	types1158,
	attr_flags1158,
	gtypes1158,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1158,
	"20130823"
},
{
	(long) 6,
	(long) 6,
	"DS_ARRAYED_LIST",
	names1159,
	types1159,
	attr_flags1159,
	gtypes1159,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1159,
	"20130823"
},
{
	(long) 6,
	(long) 6,
	"DS_ARRAYED_LIST",
	names1160,
	types1160,
	attr_flags1160,
	gtypes1160,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1160,
	"20130823"
},
{
	(long) 6,
	(long) 6,
	"LX_START_CONDITIONS",
	names1161,
	types1161,
	attr_flags1161,
	gtypes1161,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1161,
	"20130823"
},
{
	(long) 11,
	(long) 11,
	"DS_SPARSE_CONTAINER",
	names1162,
	types1162,
	attr_flags1162,
	gtypes1162,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1162,
	"20130823"
},
{
	(long) 11,
	(long) 11,
	"DS_SPARSE_CONTAINER",
	names1163,
	types1163,
	attr_flags1163,
	gtypes1163,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1163,
	"20130823"
},
{
	(long) 11,
	(long) 11,
	"DS_SPARSE_CONTAINER",
	names1164,
	types1164,
	attr_flags1164,
	gtypes1164,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1164,
	"20130823"
},
{
	(long) 11,
	(long) 11,
	"DS_SPARSE_CONTAINER",
	names1165,
	types1165,
	attr_flags1165,
	gtypes1165,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1165,
	"20130823"
},
{
	(long) 11,
	(long) 11,
	"DS_SPARSE_SET",
	names1166,
	types1166,
	attr_flags1166,
	gtypes1166,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1166,
	"20130823"
},
{
	(long) 11,
	(long) 11,
	"DS_SPARSE_SET",
	names1167,
	types1167,
	attr_flags1167,
	gtypes1167,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1167,
	"20130823"
},
{
	(long) 15,
	(long) 15,
	"DS_ARRAYED_SPARSE_SET",
	names1168,
	types1168,
	attr_flags1168,
	gtypes1168,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1168,
	"20130823"
},
{
	(long) 15,
	(long) 15,
	"DS_ARRAYED_SPARSE_SET",
	names1169,
	types1169,
	attr_flags1169,
	gtypes1169,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1169,
	"20130823"
},
{
	(long) 16,
	(long) 16,
	"DS_HASH_SET",
	names1170,
	types1170,
	attr_flags1170,
	gtypes1170,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1170,
	"20130823"
},
{
	(long) 16,
	(long) 16,
	"DS_HASH_SET",
	names1171,
	types1171,
	attr_flags1171,
	gtypes1171,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1171,
	"20130823"
},
{
	(long) 13,
	(long) 13,
	"DS_SPARSE_TABLE",
	names1172,
	types1172,
	attr_flags1172,
	gtypes1172,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1172,
	"20130823"
},
{
	(long) 13,
	(long) 13,
	"DS_SPARSE_TABLE",
	names1173,
	types1173,
	attr_flags1173,
	gtypes1173,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1173,
	"20130823"
},
{
	(long) 13,
	(long) 13,
	"DS_SPARSE_TABLE",
	names1174,
	types1174,
	attr_flags1174,
	gtypes1174,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1174,
	"20130823"
},
{
	(long) 13,
	(long) 13,
	"DS_SPARSE_TABLE",
	names1175,
	types1175,
	attr_flags1175,
	gtypes1175,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1175,
	"20130823"
},
{
	(long) 19,
	(long) 19,
	"DS_ARRAYED_SPARSE_TABLE",
	names1176,
	types1176,
	attr_flags1176,
	gtypes1176,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1176,
	"20130823"
},
{
	(long) 19,
	(long) 19,
	"DS_ARRAYED_SPARSE_TABLE",
	names1177,
	types1177,
	attr_flags1177,
	gtypes1177,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1177,
	"20130823"
},
{
	(long) 19,
	(long) 19,
	"DS_ARRAYED_SPARSE_TABLE",
	names1178,
	types1178,
	attr_flags1178,
	gtypes1178,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1178,
	"20130823"
},
{
	(long) 19,
	(long) 19,
	"DS_ARRAYED_SPARSE_TABLE",
	names1179,
	types1179,
	attr_flags1179,
	gtypes1179,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1179,
	"20130823"
},
{
	(long) 20,
	(long) 20,
	"DS_HASH_TABLE",
	names1180,
	types1180,
	attr_flags1180,
	gtypes1180,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1180,
	"20130823"
},
{
	(long) 20,
	(long) 20,
	"DS_HASH_TABLE",
	names1181,
	types1181,
	attr_flags1181,
	gtypes1181,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1181,
	"20130823"
},
{
	(long) 20,
	(long) 20,
	"DS_HASH_TABLE",
	names1182,
	types1182,
	attr_flags1182,
	gtypes1182,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1182,
	"20130823"
},
{
	(long) 20,
	(long) 20,
	"DS_HASH_TABLE",
	names1183,
	types1183,
	attr_flags1183,
	gtypes1183,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1183,
	"20130823"
},
{
	(long) 2,
	(long) 2,
	"RX_CASE_MAPPING",
	names1184,
	types1184,
	attr_flags1184,
	gtypes1184,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1184,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_CHARACTER_FORMATTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 11,
	(long) 11,
	"RT_DBG_EXECUTION_RECORDER",
	names1186,
	types1186,
	attr_flags1186,
	gtypes1186,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1186,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_UNIX_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_WINDOWS_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_WINDOWS_FILE_SYSTEM_BACKSLASH_ONLY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"UT_ERROR_HANDLER",
	names1192,
	types1192,
	attr_flags1192,
	gtypes1192,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1192,
	NULL
},
{
	(long) 4,
	(long) 4,
	"AP_ERROR_HANDLER",
	names1193,
	types1193,
	attr_flags1193,
	gtypes1193,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1193,
	NULL
},
{
	(long) 4,
	(long) 4,
	"RX_PATTERN_MATCHER",
	names1194,
	types1194,
	attr_flags1194,
	gtypes1194,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1194,
	NULL
},
{
	(long) 4,
	(long) 4,
	"RX_REGULAR_EXPRESSION",
	names1195,
	types1195,
	attr_flags1195,
	gtypes1195,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1195,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UNICODE_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"YY_PARSER_TOKENS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"LX_LEX_TOKENS",
	names1198,
	types1198,
	attr_flags1198,
	gtypes1198,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1198,
	NULL
},
{
	(long) 59,
	(long) 59,
	"LX_LEX_SCANNER",
	names1199,
	types1199,
	attr_flags1199,
	gtypes1199,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1199,
	NULL
},
{
	(long) 23,
	(long) 23,
	"YY_PARSER_SKELETON",
	names1200,
	types1200,
	attr_flags1200,
	gtypes1200,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1200,
	NULL
},
{
	(long) 112,
	(long) 112,
	"LX_LEX_PARSER_SKELETON",
	names1201,
	types1201,
	attr_flags1201,
	gtypes1201,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1201,
	NULL
},
{
	(long) 137,
	(long) 137,
	"LX_LEX_PARSER",
	names1202,
	types1202,
	attr_flags1202,
	gtypes1202,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1202,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_STRING_FORMATTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UT_ERROR",
	names1204,
	types1204,
	attr_flags1204,
	gtypes1204,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1204,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_MISSING_BRACKET_ERROR",
	names1205,
	types1205,
	attr_flags1205,
	gtypes1205,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1205,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_UNRECOGNIZED_OPTION_ERROR",
	names1206,
	types1206,
	attr_flags1206,
	gtypes1206,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1206,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_UNRECOGNIZED_DIRECTIVE_ERROR",
	names1207,
	types1207,
	attr_flags1207,
	gtypes1207,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1207,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_UNDEFINED_DEFINITION_ERROR",
	names1208,
	types1208,
	attr_flags1208,
	gtypes1208,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1208,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_START_CONDITION_EXPECTED_ERROR",
	names1209,
	types1209,
	attr_flags1209,
	gtypes1209,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1209,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_START_CONDITION_DECLARED_TWICE_ERROR",
	names1210,
	types1210,
	attr_flags1210,
	gtypes1210,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1210,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_NAME_DEFINED_TWICE_ERROR",
	names1211,
	types1211,
	attr_flags1211,
	gtypes1211,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1211,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_MISSING_QUOTE_ERROR",
	names1212,
	types1212,
	attr_flags1212,
	gtypes1212,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1212,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_INCOMPLETE_NAME_DEFINITION_ERROR",
	names1213,
	types1213,
	attr_flags1213,
	gtypes1213,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1213,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_DIRECTIVE_EXPECTED_ERROR",
	names1214,
	types1214,
	attr_flags1214,
	gtypes1214,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1214,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_INTEGER_TOO_LARGE_ERROR",
	names1215,
	types1215,
	attr_flags1215,
	gtypes1215,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1215,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_INVALID_UNICODE_CHARACTER_ERROR",
	names1216,
	types1216,
	attr_flags1216,
	gtypes1216,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1216,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_CHARACTER_OUT_OF_RANGE_ERROR",
	names1217,
	types1217,
	attr_flags1217,
	gtypes1217,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1217,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_BAD_START_CONDITION_ERROR",
	names1218,
	types1218,
	attr_flags1218,
	gtypes1218,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1218,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_BAD_CHARACTER_IN_BRACKETS_ERROR",
	names1219,
	types1219,
	attr_flags1219,
	gtypes1219,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1219,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_BAD_CHARACTER_CLASS_ERROR",
	names1220,
	types1220,
	attr_flags1220,
	gtypes1220,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1220,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_BAD_CHARACTER_ERROR",
	names1221,
	types1221,
	attr_flags1221,
	gtypes1221,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1221,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UT_SYNTAX_ERROR",
	names1222,
	types1222,
	attr_flags1222,
	gtypes1222,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1222,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_FULL_AND_REJECT_ERROR",
	names1223,
	types1223,
	attr_flags1223,
	gtypes1223,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1223,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_FULL_AND_META_ERROR",
	names1224,
	types1224,
	attr_flags1224,
	gtypes1224,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1224,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_UNDECLARED_START_CONDITION_ERROR",
	names1225,
	types1225,
	attr_flags1225,
	gtypes1225,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1225,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_TRAILING_CONTEXT_USED_TWICE_ERROR",
	names1226,
	types1226,
	attr_flags1226,
	gtypes1226,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1226,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_START_CONDITION_SPECIFIED_TWICE_ERROR",
	names1227,
	types1227,
	attr_flags1227,
	gtypes1227,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1227,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_NEGATIVE_RANGE_IN_CHARACTER_CLASS_ERROR",
	names1228,
	types1228,
	attr_flags1228,
	gtypes1228,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1228,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_MULTIPLE_EOF_RULES_ERROR",
	names1229,
	types1229,
	attr_flags1229,
	gtypes1229,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1229,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_ITERATION_NOT_POSITIVE_ERROR",
	names1230,
	types1230,
	attr_flags1230,
	gtypes1230,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1230,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_BAD_ITERATION_VALUES_ERROR",
	names1231,
	types1231,
	attr_flags1231,
	gtypes1231,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1231,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_BAD_START_CONDITION_LIST_ERROR",
	names1232,
	types1232,
	attr_flags1232,
	gtypes1232,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1232,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_ALL_START_CONDITIONS_EOF_ERROR",
	names1233,
	types1233,
	attr_flags1233,
	gtypes1233,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1233,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_FULL_AND_VARIABLE_TRAILING_CONTEXT_ERROR",
	names1234,
	types1234,
	attr_flags1234,
	gtypes1234,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1234,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_UNRECOGNIZED_RULE_ERROR",
	names1235,
	types1235,
	attr_flags1235,
	gtypes1235,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1235,
	NULL
},
{
	(long) 3,
	(long) 3,
	"AP_ERROR",
	names1236,
	types1236,
	attr_flags1236,
	gtypes1236,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1236,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UT_VERSION_NUMBER",
	names1237,
	types1237,
	attr_flags1237,
	gtypes1237,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1237,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_DEFAULT_RULE_CAN_BE_MATCHED_ERROR",
	names1238,
	types1238,
	attr_flags1238,
	gtypes1238,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1238,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_RULE_CANNOT_BE_MATCHED_ERROR",
	names1239,
	types1239,
	attr_flags1239,
	gtypes1239,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1239,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_DANGEROUS_TRAILING_CONTEXT_ERROR",
	names1240,
	types1240,
	attr_flags1240,
	gtypes1240,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1240,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UT_CANNOT_WRITE_TO_FILE_ERROR",
	names1241,
	types1241,
	attr_flags1241,
	gtypes1241,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1241,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UT_CANNOT_READ_FILE_ERROR",
	names1242,
	types1242,
	attr_flags1242,
	gtypes1242,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1242,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_PATHNAME",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"KL_PATHNAME",
	names1244,
	types1244,
	attr_flags1244,
	gtypes1244,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1244,
	NULL
},
{
	(long) 32,
	(long) 32,
	"RX_PCRE_COMPILER",
	names1245,
	types1245,
	attr_flags1245,
	gtypes1245,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1245,
	NULL
},
{
	(long) 53,
	(long) 53,
	"RX_PCRE_MATCHER",
	names1246,
	types1246,
	attr_flags1246,
	gtypes1246,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1246,
	NULL
},
{
	(long) 53,
	(long) 53,
	"RX_PCRE_REGULAR_EXPRESSION",
	names1247,
	types1247,
	attr_flags1247,
	gtypes1247,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1247,
	NULL
},
{
	(long) 8,
	(long) 8,
	"UC_STRING",
	names1248,
	types1248,
	attr_flags1248,
	gtypes1248,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1248,
	NULL
},
{
	(long) 8,
	(long) 8,
	"UC_UTF8_STRING",
	names1249,
	types1249,
	attr_flags1249,
	gtypes1249,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1249,
	NULL
},};


#ifdef __cplusplus
}
#endif
