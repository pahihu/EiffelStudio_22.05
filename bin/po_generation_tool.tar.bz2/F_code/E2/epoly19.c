#include "epoly19.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4797[482])();
void R4797_init () {
	R4797[0] = (char *(*)()) F832_6276;
	R4797[481] = (char *(*)()) F1313_14035;
}

char *(*R4896[12])();
void R4896_init () {
	R4896[0] = (char *(*)()) F840_6408;
	R4896[1] = (char *(*)()) F841_6408;
	R4896[2] = (char *(*)()) F842_6408;
	R4896[3] = (char *(*)()) F843_6408;
	R4896[4] = (char *(*)()) F844_6408;
	R4896[5] = (char *(*)()) F845_6408;
	R4896[6] = (char *(*)()) F846_6408;
	R4896[7] = (char *(*)()) F847_6408;
	R4896[8] = (char *(*)()) F848_6408;
	R4896[9] = (char *(*)()) F849_6408;
	R4896[10] = (char *(*)()) F850_6408;
	R4896[11] = (char *(*)()) F851_6408;
}

char *(*R4897[12])();
void R4897_init () {
	R4897[0] = (char *(*)()) F840_6409;
	R4897[1] = (char *(*)()) F841_6409;
	R4897[2] = (char *(*)()) F842_6409;
	R4897[3] = (char *(*)()) F843_6409;
	R4897[4] = (char *(*)()) F844_6409;
	R4897[5] = (char *(*)()) F845_6409;
	R4897[6] = (char *(*)()) F846_6409;
	R4897[7] = (char *(*)()) F847_6409;
	R4897[8] = (char *(*)()) F848_6409;
	R4897[9] = (char *(*)()) F849_6409;
	R4897[10] = (char *(*)()) F850_6409;
	R4897[11] = (char *(*)()) F851_6409;
}

char *(*R4899[12])();
void R4899_init () {
	R4899[0] = (char *(*)()) F840_6395;
	R4899[1] = (char *(*)()) F841_6395;
	R4899[2] = (char *(*)()) F842_6395;
	R4899[3] = (char *(*)()) F843_6395;
	R4899[4] = (char *(*)()) F844_6395;
	R4899[5] = (char *(*)()) F845_6395;
	R4899[6] = (char *(*)()) F846_6395;
	R4899[7] = (char *(*)()) F847_6395;
	R4899[8] = (char *(*)()) F848_6395;
	R4899[9] = (char *(*)()) F849_6395;
	R4899[10] = (char *(*)()) F850_6395;
	R4899[11] = (char *(*)()) F851_6395;
}

char *(*R4900[12])();
void R4900_init () {
	R4900[0] = (char *(*)()) F840_6396;
	R4900[1] = (char *(*)()) F841_6396_4900_136;
	R4900[2] = (char *(*)()) F842_6396_4900_136;
	R4900[3] = (char *(*)()) F843_6396_4900_136;
	R4900[4] = (char *(*)()) F844_6396_4900_136;
	R4900[5] = (char *(*)()) F845_6396_4900_136;
	R4900[6] = (char *(*)()) F846_6396_4900_136;
	R4900[7] = (char *(*)()) F847_6396_4900_136;
	R4900[8] = (char *(*)()) F848_6396_4900_136;
	R4900[9] = (char *(*)()) F849_6396_4900_136;
	R4900[10] = (char *(*)()) F850_6396_4900_136;
	R4900[11] = (char *(*)()) F851_6396_4900_136;
}
static void F841_6396_4900_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F841_6396(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F842_6396_4900_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F842_6396(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F843_6396_4900_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F843_6396(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F844_6396_4900_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F844_6396(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F845_6396_4900_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F845_6396(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F846_6396_4900_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F846_6396(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F847_6396_4900_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F847_6396(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F848_6396_4900_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F848_6396(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F849_6396_4900_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F849_6396(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F850_6396_4900_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F850_6396(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F851_6396_4900_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F851_6396(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R4909[12])();
void R4909_init () {
	R4909[0] = (char *(*)()) F840_6411;
	R4909[1] = (char *(*)()) F841_6411;
	R4909[2] = (char *(*)()) F842_6411;
	R4909[3] = (char *(*)()) F843_6411;
	R4909[4] = (char *(*)()) F844_6411;
	R4909[5] = (char *(*)()) F845_6411;
	R4909[6] = (char *(*)()) F846_6411;
	R4909[7] = (char *(*)()) F847_6411;
	R4909[8] = (char *(*)()) F848_6411;
	R4909[9] = (char *(*)()) F849_6411;
	R4909[10] = (char *(*)()) F850_6411;
	R4909[11] = (char *(*)()) F851_6411;
}

char *(*R4910[12])();
void R4910_init () {
	R4910[0] = (char *(*)()) F840_6413;
	R4910[1] = (char *(*)()) F841_6413_4910_136;
	R4910[2] = (char *(*)()) F842_6413_4910_136;
	R4910[3] = (char *(*)()) F843_6413_4910_136;
	R4910[4] = (char *(*)()) F844_6413_4910_136;
	R4910[5] = (char *(*)()) F845_6413_4910_136;
	R4910[6] = (char *(*)()) F846_6413_4910_136;
	R4910[7] = (char *(*)()) F847_6413_4910_136;
	R4910[8] = (char *(*)()) F848_6413_4910_136;
	R4910[9] = (char *(*)()) F849_6413_4910_136;
	R4910[10] = (char *(*)()) F850_6413_4910_136;
	R4910[11] = (char *(*)()) F851_6413_4910_136;
}
static void F841_6413_4910_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F841_6413(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F842_6413_4910_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F842_6413(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F843_6413_4910_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F843_6413(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F844_6413_4910_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F844_6413(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F845_6413_4910_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F845_6413(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F846_6413_4910_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F846_6413(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F847_6413_4910_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F847_6413(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F848_6413_4910_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F848_6413(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F849_6413_4910_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F849_6413(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F850_6413_4910_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F850_6413(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F851_6413_4910_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F851_6413(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R4911[12])();
void R4911_init () {
	R4911[0] = (char *(*)()) F840_6414;
	R4911[1] = (char *(*)()) F841_6414_4911_136;
	R4911[2] = (char *(*)()) F842_6414_4911_136;
	R4911[3] = (char *(*)()) F843_6414_4911_136;
	R4911[4] = (char *(*)()) F844_6414_4911_136;
	R4911[5] = (char *(*)()) F845_6414_4911_136;
	R4911[6] = (char *(*)()) F846_6414_4911_136;
	R4911[7] = (char *(*)()) F847_6414_4911_136;
	R4911[8] = (char *(*)()) F848_6414_4911_136;
	R4911[9] = (char *(*)()) F849_6414_4911_136;
	R4911[10] = (char *(*)()) F850_6414_4911_136;
	R4911[11] = (char *(*)()) F851_6414_4911_136;
}
static void F841_6414_4911_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F841_6414(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F842_6414_4911_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F842_6414(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F843_6414_4911_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F843_6414(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F844_6414_4911_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F844_6414(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F845_6414_4911_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F845_6414(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F846_6414_4911_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F846_6414(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F847_6414_4911_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F847_6414(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F848_6414_4911_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F848_6414(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F849_6414_4911_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F849_6414(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F850_6414_4911_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F850_6414(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F851_6414_4911_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F851_6414(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R4912[12])();
void R4912_init () {
	R4912[0] = (char *(*)()) F840_6415;
	R4912[1] = (char *(*)()) F841_6415_4912_4;
	R4912[2] = (char *(*)()) F842_6415_4912_4;
	R4912[3] = (char *(*)()) F843_6415_4912_4;
	R4912[4] = (char *(*)()) F844_6415_4912_4;
	R4912[5] = (char *(*)()) F845_6415_4912_4;
	R4912[6] = (char *(*)()) F846_6415_4912_4;
	R4912[7] = (char *(*)()) F847_6415_4912_4;
	R4912[8] = (char *(*)()) F848_6415_4912_4;
	R4912[9] = (char *(*)()) F849_6415_4912_4;
	R4912[10] = (char *(*)()) F850_6415_4912_4;
	R4912[11] = (char *(*)()) F851_6415_4912_4;
}
static void F841_6415_4912_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F841_6415(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F842_6415_4912_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F842_6415(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F843_6415_4912_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F843_6415(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F844_6415_4912_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F844_6415(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F845_6415_4912_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F845_6415(Current, *(EIF_POINTER *)arg1);
}
static void F846_6415_4912_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F846_6415(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F847_6415_4912_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F847_6415(Current, *(EIF_BOOLEAN *)arg1);
}
static void F848_6415_4912_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F848_6415(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F849_6415_4912_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F849_6415(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F850_6415_4912_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F850_6415(Current, *(EIF_REAL_32 *)arg1);
}
static void F851_6415_4912_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F851_6415(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R4913[12])();
void R4913_init () {
	R4913[0] = (char *(*)()) F840_6416;
	R4913[1] = (char *(*)()) F841_6416_4913_4;
	R4913[2] = (char *(*)()) F842_6416_4913_4;
	R4913[3] = (char *(*)()) F843_6416_4913_4;
	R4913[4] = (char *(*)()) F844_6416_4913_4;
	R4913[5] = (char *(*)()) F845_6416_4913_4;
	R4913[6] = (char *(*)()) F846_6416_4913_4;
	R4913[7] = (char *(*)()) F847_6416_4913_4;
	R4913[8] = (char *(*)()) F848_6416_4913_4;
	R4913[9] = (char *(*)()) F849_6416_4913_4;
	R4913[10] = (char *(*)()) F850_6416_4913_4;
	R4913[11] = (char *(*)()) F851_6416_4913_4;
}
static void F841_6416_4913_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F841_6416(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F842_6416_4913_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F842_6416(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F843_6416_4913_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F843_6416(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F844_6416_4913_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F844_6416(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F845_6416_4913_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F845_6416(Current, *(EIF_POINTER *)arg1);
}
static void F846_6416_4913_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F846_6416(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F847_6416_4913_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F847_6416(Current, *(EIF_BOOLEAN *)arg1);
}
static void F848_6416_4913_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F848_6416(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F849_6416_4913_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F849_6416(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F850_6416_4913_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F850_6416(Current, *(EIF_REAL_32 *)arg1);
}
static void F851_6416_4913_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F851_6416(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R4914[12])();
void R4914_init () {
	R4914[0] = (char *(*)()) F840_6417;
	R4914[1] = (char *(*)()) F841_6417_4914_51;
	R4914[2] = (char *(*)()) F842_6417_4914_51;
	R4914[3] = (char *(*)()) F843_6417_4914_51;
	R4914[4] = (char *(*)()) F844_6417_4914_51;
	R4914[5] = (char *(*)()) F845_6417_4914_51;
	R4914[6] = (char *(*)()) F846_6417_4914_51;
	R4914[7] = (char *(*)()) F847_6417_4914_51;
	R4914[8] = (char *(*)()) F848_6417_4914_51;
	R4914[9] = (char *(*)()) F849_6417_4914_51;
	R4914[10] = (char *(*)()) F850_6417_4914_51;
	R4914[11] = (char *(*)()) F851_6417_4914_51;
}
static void F841_6417_4914_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F841_6417(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F842_6417_4914_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F842_6417(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F843_6417_4914_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F843_6417(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F844_6417_4914_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F844_6417(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F845_6417_4914_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F845_6417(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F846_6417_4914_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F846_6417(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F847_6417_4914_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F847_6417(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F848_6417_4914_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F848_6417(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F849_6417_4914_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F849_6417(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F850_6417_4914_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F850_6417(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F851_6417_4914_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F851_6417(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R4917[12])();
void R4917_init () {
	R4917[0] = (char *(*)()) F840_6420;
	R4917[1] = (char *(*)()) F841_6420;
	R4917[2] = (char *(*)()) F842_6420;
	R4917[3] = (char *(*)()) F843_6420;
	R4917[4] = (char *(*)()) F844_6420;
	R4917[5] = (char *(*)()) F845_6420;
	R4917[6] = (char *(*)()) F846_6420;
	R4917[7] = (char *(*)()) F847_6420;
	R4917[8] = (char *(*)()) F848_6420;
	R4917[9] = (char *(*)()) F849_6420;
	R4917[10] = (char *(*)()) F850_6420;
	R4917[11] = (char *(*)()) F851_6420;
}

char *(*R4918[12])();
void R4918_init () {
	R4918[0] = (char *(*)()) F840_6421;
	R4918[1] = (char *(*)()) F841_6421;
	R4918[2] = (char *(*)()) F842_6421;
	R4918[3] = (char *(*)()) F843_6421;
	R4918[4] = (char *(*)()) F844_6421;
	R4918[5] = (char *(*)()) F845_6421;
	R4918[6] = (char *(*)()) F846_6421;
	R4918[7] = (char *(*)()) F847_6421;
	R4918[8] = (char *(*)()) F848_6421;
	R4918[9] = (char *(*)()) F849_6421;
	R4918[10] = (char *(*)()) F850_6421;
	R4918[11] = (char *(*)()) F851_6421;
}

char *(*R4919[12])();
void R4919_init () {
	R4919[0] = (char *(*)()) F840_6422;
	R4919[1] = (char *(*)()) F841_6422;
	R4919[2] = (char *(*)()) F842_6422;
	R4919[3] = (char *(*)()) F843_6422;
	R4919[4] = (char *(*)()) F844_6422;
	R4919[5] = (char *(*)()) F845_6422;
	R4919[6] = (char *(*)()) F846_6422;
	R4919[7] = (char *(*)()) F847_6422;
	R4919[8] = (char *(*)()) F848_6422;
	R4919[9] = (char *(*)()) F849_6422;
	R4919[10] = (char *(*)()) F850_6422;
	R4919[11] = (char *(*)()) F851_6422;
}

char *(*R4920[12])();
void R4920_init () {
	R4920[0] = (char *(*)()) F840_6423;
	R4920[1] = (char *(*)()) F841_6423;
	R4920[2] = (char *(*)()) F842_6423;
	R4920[3] = (char *(*)()) F843_6423;
	R4920[4] = (char *(*)()) F844_6423;
	R4920[5] = (char *(*)()) F845_6423;
	R4920[6] = (char *(*)()) F846_6423;
	R4920[7] = (char *(*)()) F847_6423;
	R4920[8] = (char *(*)()) F848_6423;
	R4920[9] = (char *(*)()) F849_6423;
	R4920[10] = (char *(*)()) F850_6423;
	R4920[11] = (char *(*)()) F851_6423;
}

char *(*R4921[12])();
void R4921_init () {
	R4921[0] = (char *(*)()) F840_6424;
	R4921[1] = (char *(*)()) F841_6424;
	R4921[2] = (char *(*)()) F842_6424;
	R4921[3] = (char *(*)()) F843_6424;
	R4921[4] = (char *(*)()) F844_6424;
	R4921[5] = (char *(*)()) F845_6424;
	R4921[6] = (char *(*)()) F846_6424;
	R4921[7] = (char *(*)()) F847_6424;
	R4921[8] = (char *(*)()) F848_6424;
	R4921[9] = (char *(*)()) F849_6424;
	R4921[10] = (char *(*)()) F850_6424;
	R4921[11] = (char *(*)()) F851_6424;
}

char *(*R4924[12])();
void R4924_init () {
	R4924[0] = (char *(*)()) F840_6427;
	R4924[1] = (char *(*)()) F841_6427;
	R4924[2] = (char *(*)()) F842_6427;
	R4924[3] = (char *(*)()) F843_6427;
	R4924[4] = (char *(*)()) F844_6427;
	R4924[5] = (char *(*)()) F845_6427;
	R4924[6] = (char *(*)()) F846_6427;
	R4924[7] = (char *(*)()) F847_6427;
	R4924[8] = (char *(*)()) F848_6427;
	R4924[9] = (char *(*)()) F849_6427;
	R4924[10] = (char *(*)()) F850_6427;
	R4924[11] = (char *(*)()) F851_6427;
}

char *(*R4927[12])();
void R4927_init () {
	R4927[0] = (char *(*)()) F840_6430;
	R4927[1] = (char *(*)()) F841_6430;
	R4927[2] = (char *(*)()) F842_6430;
	R4927[3] = (char *(*)()) F843_6430;
	R4927[4] = (char *(*)()) F844_6430;
	R4927[5] = (char *(*)()) F845_6430;
	R4927[6] = (char *(*)()) F846_6430;
	R4927[7] = (char *(*)()) F847_6430;
	R4927[8] = (char *(*)()) F848_6430;
	R4927[9] = (char *(*)()) F849_6430;
	R4927[10] = (char *(*)()) F850_6430;
	R4927[11] = (char *(*)()) F851_6430;
}

char *(*R4930[12])();
void R4930_init () {
	R4930[0] = (char *(*)()) F840_6433;
	R4930[1] = (char *(*)()) F841_6433;
	R4930[2] = (char *(*)()) F842_6433;
	R4930[3] = (char *(*)()) F843_6433;
	R4930[4] = (char *(*)()) F844_6433;
	R4930[5] = (char *(*)()) F845_6433;
	R4930[6] = (char *(*)()) F846_6433;
	R4930[7] = (char *(*)()) F847_6433;
	R4930[8] = (char *(*)()) F848_6433;
	R4930[9] = (char *(*)()) F849_6433;
	R4930[10] = (char *(*)()) F850_6433;
	R4930[11] = (char *(*)()) F851_6433;
}

char *(*R4932[12])();
void R4932_init () {
	R4932[0] = (char *(*)()) F840_6435;
	R4932[1] = (char *(*)()) F841_6435;
	R4932[2] = (char *(*)()) F842_6435;
	R4932[3] = (char *(*)()) F843_6435;
	R4932[4] = (char *(*)()) F844_6435;
	R4932[5] = (char *(*)()) F845_6435;
	R4932[6] = (char *(*)()) F846_6435;
	R4932[7] = (char *(*)()) F847_6435;
	R4932[8] = (char *(*)()) F848_6435;
	R4932[9] = (char *(*)()) F849_6435;
	R4932[10] = (char *(*)()) F850_6435;
	R4932[11] = (char *(*)()) F851_6435;
}

char *(*R4934[12])();
void R4934_init () {
	R4934[0] = (char *(*)()) F840_6437;
	R4934[1] = (char *(*)()) F841_6437;
	R4934[2] = (char *(*)()) F842_6437;
	R4934[3] = (char *(*)()) F843_6437;
	R4934[4] = (char *(*)()) F844_6437;
	R4934[5] = (char *(*)()) F845_6437;
	R4934[6] = (char *(*)()) F846_6437;
	R4934[7] = (char *(*)()) F847_6437;
	R4934[8] = (char *(*)()) F848_6437;
	R4934[9] = (char *(*)()) F849_6437;
	R4934[10] = (char *(*)()) F850_6437;
	R4934[11] = (char *(*)()) F851_6437;
}

char *(*R4939[12])();
void R4939_init () {
	R4939[0] = (char *(*)()) F840_6443;
	R4939[1] = (char *(*)()) F841_6443;
	R4939[2] = (char *(*)()) F842_6443;
	R4939[3] = (char *(*)()) F843_6443;
	R4939[4] = (char *(*)()) F844_6443;
	R4939[5] = (char *(*)()) F845_6443;
	R4939[6] = (char *(*)()) F846_6443;
	R4939[7] = (char *(*)()) F847_6443;
	R4939[8] = (char *(*)()) F848_6443;
	R4939[9] = (char *(*)()) F849_6443;
	R4939[10] = (char *(*)()) F850_6443;
	R4939[11] = (char *(*)()) F851_6443;
}

char *(*R4986[11])();
void R4986_init () {
	R4986[0] = (char *(*)()) F956_7065_4986_1;
	R4986[1] = (char *(*)()) F957_7065_4986_1;
	R4986[3] = (char *(*)()) F959_7164_4986_1;
	R4986[4] = (char *(*)()) F960_7164_4986_1;
	R4986[6] = (char *(*)()) F962_7263_4986_1;
	R4986[7] = (char *(*)()) F963_7263_4986_1;
	R4986[9] = (char *(*)()) F965_7362_4986_1;
	R4986[10] = (char *(*)()) F966_7362_4986_1;
}
static EIF_REFERENCE F956_7065_4986_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F956_7065(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(956, 0x00).id, 956, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F957_7065_4986_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F957_7065(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(956, 0x00).id, 956, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F959_7164_4986_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F959_7164(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F960_7164_4986_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F960_7164(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F962_7263_4986_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F962_7263(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(962, 0x00).id, 962, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F963_7263_4986_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F963_7263(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(962, 0x00).id, 962, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F965_7362_4986_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F965_7362(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(965, 0x00).id, 965, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F966_7362_4986_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F966_7362(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(965, 0x00).id, 965, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}

char *(*R5179[394])();
void R5179_init () {
	R5179[0] = (char *(*)()) F920_6789;
	R5179[1] = (char *(*)()) F921_6831;
	R5179[2] = (char *(*)()) F922_6831;
	R5179[3] = (char *(*)()) F923_6831;
	R5179[4] = (char *(*)()) F924_6831;
	R5179[5] = (char *(*)()) F925_6831;
	R5179[6] = (char *(*)()) F926_6831;
	R5179[7] = (char *(*)()) F927_6831;
	R5179[8] = (char *(*)()) F928_6831;
	R5179[9] = (char *(*)()) F929_6831;
	R5179[10] = (char *(*)()) F930_6831;
	R5179[11] = (char *(*)()) F931_6831;
	R5179[12] = (char *(*)()) F932_6831;
	R5179[13] = (char *(*)()) F933_6831;
	R5179[14] = (char *(*)()) F934_6831;
	R5179[15] = (char *(*)()) F935_6831;
	R5179[16] = (char *(*)()) F936_6831;
	R5179[17] = (char *(*)()) F937_6831;
	R5179[18] = (char *(*)()) F938_6831;
	R5179[19] = (char *(*)()) F939_6831;
	R5179[20] = (char *(*)()) F940_6831;
	R5179[21] = (char *(*)()) F941_6831;
	R5179[22] = (char *(*)()) F942_6831;
	R5179[23] = (char *(*)()) F943_6831;
	R5179[24] = (char *(*)()) F944_6831;
	R5179[25] = (char *(*)()) F945_6831;
	R5179[26] = (char *(*)()) F946_6831;
	R5179[27] = (char *(*)()) F947_6831;
	R5179[28] = (char *(*)()) F948_6831;
	R5179[29] = (char *(*)()) F949_6831;
	R5179[30] = (char *(*)()) F950_6831;
	R5179[31] = (char *(*)()) F951_6831;
	R5179[32] = (char *(*)()) F952_6831;
	R5179[33] = (char *(*)()) F953_6831;
	R5179[34] = (char *(*)()) F954_6883;
	{long i; for (i = 36; i < 38; i++) R5179[i] = (char *(*)()) F955_6990;}
	{long i; for (i = 39; i < 41; i++) R5179[i] = (char *(*)()) F958_7088;}
	{long i; for (i = 42; i < 44; i++) R5179[i] = (char *(*)()) F961_7187;}
	{long i; for (i = 45; i < 47; i++) R5179[i] = (char *(*)()) F964_7286;}
	{long i; for (i = 48; i < 50; i++) R5179[i] = (char *(*)()) F967_7385;}
	{long i; for (i = 51; i < 53; i++) R5179[i] = (char *(*)()) F970_7479;}
	{long i; for (i = 54; i < 56; i++) R5179[i] = (char *(*)()) F973_7573;}
	{long i; for (i = 57; i < 59; i++) R5179[i] = (char *(*)()) F976_7668;}
	{long i; for (i = 60; i < 62; i++) R5179[i] = (char *(*)()) F979_7763;}
	{long i; for (i = 63; i < 65; i++) R5179[i] = (char *(*)()) F982_7829;}
	{long i; for (i = 66; i < 68; i++) R5179[i] = (char *(*)()) F985_7896;}
	{long i; for (i = 69; i < 71; i++) R5179[i] = (char *(*)()) F988_7937;}
	{long i; for (i = 72; i < 74; i++) R5179[i] = (char *(*)()) F991_7985;}
	{long i; for (i = 75; i < 105; i++) R5179[i] = (char *(*)()) F994_8006;}
	R5179[105] = (char *(*)()) F1025_8032;
	R5179[106] = (char *(*)()) F1026_8032;
	{long i; for (i = 108; i < 113; i++) R5179[i] = (char *(*)()) F1027_8040;}
	{long i; for (i = 117; i < 119; i++) R5179[i] = (char *(*)()) F1033_8099;}
	{long i; for (i = 121; i < 123; i++) R5179[i] = (char *(*)()) F1033_8099;}
	R5179[123] = (char *(*)()) F1043_8556;
	R5179[124] = (char *(*)()) F1044_8565;
	{long i; for (i = 355; i < 357; i++) R5179[i] = (char *(*)()) F1275_13562;}
	R5179[393] = (char *(*)()) F1313_13962;
}

char *(*R5263[33])();
void R5263_init () {
	R5263[0] = (char *(*)()) F921_6827;
	R5263[1] = (char *(*)()) F922_6827;
	R5263[2] = (char *(*)()) F923_6827;
	R5263[3] = (char *(*)()) F924_6827;
	R5263[4] = (char *(*)()) F925_6827;
	R5263[5] = (char *(*)()) F926_6827;
	R5263[6] = (char *(*)()) F927_6827;
	R5263[7] = (char *(*)()) F928_6827;
	R5263[8] = (char *(*)()) F929_6827;
	R5263[9] = (char *(*)()) F930_6827;
	R5263[10] = (char *(*)()) F931_6827;
	R5263[11] = (char *(*)()) F932_6827;
	R5263[12] = (char *(*)()) F933_6827;
	R5263[13] = (char *(*)()) F934_6827;
	R5263[14] = (char *(*)()) F935_6827;
	R5263[15] = (char *(*)()) F936_6827;
	R5263[16] = (char *(*)()) F937_6827;
	R5263[17] = (char *(*)()) F938_6827;
	R5263[18] = (char *(*)()) F939_6827;
	R5263[19] = (char *(*)()) F940_6827;
	R5263[20] = (char *(*)()) F941_6827;
	R5263[21] = (char *(*)()) F942_6827;
	R5263[22] = (char *(*)()) F943_6827;
	R5263[23] = (char *(*)()) F944_6827;
	R5263[24] = (char *(*)()) F945_6827;
	R5263[25] = (char *(*)()) F946_6827;
	R5263[26] = (char *(*)()) F947_6827;
	R5263[27] = (char *(*)()) F948_6827;
	R5263[28] = (char *(*)()) F949_6827;
	R5263[29] = (char *(*)()) F950_6827;
	R5263[30] = (char *(*)()) F951_6827;
	R5263[31] = (char *(*)()) F952_6827;
	R5263[32] = (char *(*)()) F953_6827;
}

char *(*R5264[33])();
void R5264_init () {
	R5264[0] = (char *(*)()) F921_6828;
	R5264[1] = (char *(*)()) F922_6828;
	R5264[2] = (char *(*)()) F923_6828;
	R5264[3] = (char *(*)()) F924_6828;
	R5264[4] = (char *(*)()) F925_6828;
	R5264[5] = (char *(*)()) F926_6828;
	R5264[6] = (char *(*)()) F927_6828;
	R5264[7] = (char *(*)()) F928_6828;
	R5264[8] = (char *(*)()) F929_6828;
	R5264[9] = (char *(*)()) F930_6828;
	R5264[10] = (char *(*)()) F931_6828;
	R5264[11] = (char *(*)()) F932_6828;
	R5264[12] = (char *(*)()) F933_6828;
	R5264[13] = (char *(*)()) F934_6828;
	R5264[14] = (char *(*)()) F935_6828;
	R5264[15] = (char *(*)()) F936_6828;
	R5264[16] = (char *(*)()) F937_6828;
	R5264[17] = (char *(*)()) F938_6828;
	R5264[18] = (char *(*)()) F939_6828;
	R5264[19] = (char *(*)()) F940_6828;
	R5264[20] = (char *(*)()) F941_6828;
	R5264[21] = (char *(*)()) F942_6828;
	R5264[22] = (char *(*)()) F943_6828;
	R5264[23] = (char *(*)()) F944_6828;
	R5264[24] = (char *(*)()) F945_6828;
	R5264[25] = (char *(*)()) F946_6828;
	R5264[26] = (char *(*)()) F947_6828;
	R5264[27] = (char *(*)()) F948_6828;
	R5264[28] = (char *(*)()) F949_6828;
	R5264[29] = (char *(*)()) F950_6828;
	R5264[30] = (char *(*)()) F951_6828;
	R5264[31] = (char *(*)()) F952_6828;
	R5264[32] = (char *(*)()) F953_6828;
}

char *(*R5266[33])();
void R5266_init () {
	R5266[0] = (char *(*)()) F921_6830;
	R5266[1] = (char *(*)()) F922_6830;
	R5266[2] = (char *(*)()) F923_6830;
	R5266[3] = (char *(*)()) F924_6830;
	R5266[4] = (char *(*)()) F925_6830;
	R5266[5] = (char *(*)()) F926_6830;
	R5266[6] = (char *(*)()) F927_6830;
	R5266[7] = (char *(*)()) F928_6830;
	R5266[8] = (char *(*)()) F929_6830;
	R5266[9] = (char *(*)()) F930_6830;
	R5266[10] = (char *(*)()) F931_6830;
	R5266[11] = (char *(*)()) F932_6830;
	R5266[12] = (char *(*)()) F933_6830;
	R5266[13] = (char *(*)()) F934_6830;
	R5266[14] = (char *(*)()) F935_6830;
	R5266[15] = (char *(*)()) F936_6830;
	R5266[16] = (char *(*)()) F937_6830;
	R5266[17] = (char *(*)()) F938_6830;
	R5266[18] = (char *(*)()) F939_6830;
	R5266[19] = (char *(*)()) F940_6830;
	R5266[20] = (char *(*)()) F941_6830;
	R5266[21] = (char *(*)()) F942_6830;
	R5266[22] = (char *(*)()) F943_6830;
	R5266[23] = (char *(*)()) F944_6830;
	R5266[24] = (char *(*)()) F945_6830;
	R5266[25] = (char *(*)()) F946_6830;
	R5266[26] = (char *(*)()) F947_6830;
	R5266[27] = (char *(*)()) F948_6830;
	R5266[28] = (char *(*)()) F949_6830;
	R5266[29] = (char *(*)()) F950_6830;
	R5266[30] = (char *(*)()) F951_6830;
	R5266[31] = (char *(*)()) F952_6830;
	R5266[32] = (char *(*)()) F953_6830;
}

char *(*R5271[33])();
void R5271_init () {
	R5271[0] = (char *(*)()) F921_6836;
	R5271[1] = (char *(*)()) F922_6836;
	R5271[2] = (char *(*)()) F923_6836;
	R5271[3] = (char *(*)()) F924_6836;
	R5271[4] = (char *(*)()) F925_6836;
	R5271[5] = (char *(*)()) F926_6836;
	R5271[6] = (char *(*)()) F927_6836;
	R5271[7] = (char *(*)()) F928_6836;
	R5271[8] = (char *(*)()) F929_6836;
	R5271[9] = (char *(*)()) F930_6836;
	R5271[10] = (char *(*)()) F931_6836;
	R5271[11] = (char *(*)()) F932_6836;
	R5271[12] = (char *(*)()) F933_6836;
	R5271[13] = (char *(*)()) F934_6836;
	R5271[14] = (char *(*)()) F935_6836;
	R5271[15] = (char *(*)()) F936_6836;
	R5271[16] = (char *(*)()) F937_6836;
	R5271[17] = (char *(*)()) F938_6836;
	R5271[18] = (char *(*)()) F939_6836;
	R5271[19] = (char *(*)()) F940_6836;
	R5271[20] = (char *(*)()) F941_6836;
	R5271[21] = (char *(*)()) F942_6836;
	R5271[22] = (char *(*)()) F943_6836;
	R5271[23] = (char *(*)()) F944_6836;
	R5271[24] = (char *(*)()) F945_6836;
	R5271[25] = (char *(*)()) F946_6836;
	R5271[26] = (char *(*)()) F947_6836;
	R5271[27] = (char *(*)()) F948_6836;
	R5271[28] = (char *(*)()) F949_6836;
	R5271[29] = (char *(*)()) F950_6836;
	R5271[30] = (char *(*)()) F951_6836;
	R5271[31] = (char *(*)()) F952_6836;
	R5271[32] = (char *(*)()) F953_6836;
}

char *(*R5276[33])();
void R5276_init () {
	R5276[0] = (char *(*)()) F921_6844;
	R5276[1] = (char *(*)()) F922_6844_5276_1;
	R5276[2] = (char *(*)()) F923_6844_5276_1;
	R5276[3] = (char *(*)()) F924_6844_5276_1;
	R5276[4] = (char *(*)()) F925_6844_5276_1;
	R5276[5] = (char *(*)()) F926_6844_5276_1;
	R5276[6] = (char *(*)()) F927_6844_5276_1;
	R5276[7] = (char *(*)()) F928_6844_5276_1;
	R5276[8] = (char *(*)()) F929_6844_5276_1;
	R5276[9] = (char *(*)()) F930_6844_5276_1;
	R5276[10] = (char *(*)()) F931_6844_5276_1;
	R5276[11] = (char *(*)()) F932_6844_5276_1;
	R5276[12] = (char *(*)()) F933_6844_5276_1;
	R5276[13] = (char *(*)()) F934_6844_5276_1;
	R5276[14] = (char *(*)()) F935_6844_5276_1;
	R5276[15] = (char *(*)()) F936_6844;
	R5276[16] = (char *(*)()) F937_6844_5276_1;
	R5276[17] = (char *(*)()) F938_6844;
	R5276[18] = (char *(*)()) F939_6844_5276_1;
	R5276[19] = (char *(*)()) F940_6844_5276_1;
	R5276[20] = (char *(*)()) F941_6844_5276_1;
	R5276[21] = (char *(*)()) F942_6844;
	R5276[22] = (char *(*)()) F943_6844_5276_1;
	R5276[23] = (char *(*)()) F944_6844_5276_1;
	R5276[24] = (char *(*)()) F945_6844_5276_1;
	R5276[25] = (char *(*)()) F946_6844_5276_1;
	R5276[26] = (char *(*)()) F947_6844_5276_1;
	R5276[27] = (char *(*)()) F948_6844_5276_1;
	R5276[28] = (char *(*)()) F949_6844_5276_1;
	R5276[29] = (char *(*)()) F950_6844_5276_1;
	R5276[30] = (char *(*)()) F951_6844_5276_1;
	R5276[31] = (char *(*)()) F952_6844_5276_1;
	R5276[32] = (char *(*)()) F953_6844_5276_1;
}
static EIF_REFERENCE F922_6844_5276_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REFERENCE* r = F922_6844(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {995,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 995, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REFERENCE* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F923_6844_5276_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F923_6844(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1025, 0x00).id, 1025, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F924_6844_5276_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F924_6844(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(983, 0x00).id, 983, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F925_6844_5276_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F925_6844(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(980, 0x00).id, 980, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F926_6844_5276_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F926_6844(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(977, 0x00).id, 977, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F927_6844_5276_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F927_6844(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(974, 0x00).id, 974, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F928_6844_5276_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F928_6844(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(971, 0x00).id, 971, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F929_6844_5276_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F929_6844(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(968, 0x00).id, 968, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F930_6844_5276_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F930_6844(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(965, 0x00).id, 965, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F931_6844_5276_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F931_6844(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(962, 0x00).id, 962, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F932_6844_5276_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F932_6844(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F933_6844_5276_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F933_6844(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(956, 0x00).id, 956, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F934_6844_5276_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F934_6844(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(989, 0x00).id, 989, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F935_6844_5276_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F935_6844(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F937_6844_5276_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F937_6844(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(986, 0x00).id, 986, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F939_6844_5276_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32* r = F939_6844(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {997,986,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 997, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F940_6844_5276_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64* r = F940_6844(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {999,956,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 999, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F941_6844_5276_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16* r = F941_6844(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1001,962,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1001, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F943_6844_5276_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8* r = F943_6844(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1003,965,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1003, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F944_6844_5276_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32* r = F944_6844(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1005,959,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1005, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F945_6844_5276_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64* r = F945_6844(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1007,983,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1007, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F946_6844_5276_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER* r = F946_6844(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1009,1025,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1009, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_POINTER* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F947_6844_5276_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16* r = F947_6844(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1011,974,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1011, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F948_6844_5276_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32* r = F948_6844(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1013,980,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1013, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F949_6844_5276_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8* r = F949_6844(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1015,977,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1015, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F950_6844_5276_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN* r = F950_6844(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1017,992,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1017, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_BOOLEAN* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F951_6844_5276_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64* r = F951_6844(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1019,968,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1019, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F952_6844_5276_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32* r = F952_6844(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1021,971,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1021, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F953_6844_5276_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8* r = F953_6844(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1023,989,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1023, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_8* *)Result = r;
		return Result;
	}
}

char *(*R5286[33])();
void R5286_init () {
	R5286[0] = (char *(*)()) F921_6856;
	R5286[1] = (char *(*)()) F922_6856;
	R5286[2] = (char *(*)()) F923_6856;
	R5286[3] = (char *(*)()) F924_6856;
	R5286[4] = (char *(*)()) F925_6856;
	R5286[5] = (char *(*)()) F926_6856;
	R5286[6] = (char *(*)()) F927_6856;
	R5286[7] = (char *(*)()) F928_6856;
	R5286[8] = (char *(*)()) F929_6856;
	R5286[9] = (char *(*)()) F930_6856;
	R5286[10] = (char *(*)()) F931_6856;
	R5286[11] = (char *(*)()) F932_6856;
	R5286[12] = (char *(*)()) F933_6856;
	R5286[13] = (char *(*)()) F934_6856;
	R5286[14] = (char *(*)()) F935_6856;
	R5286[15] = (char *(*)()) F936_6856;
	R5286[16] = (char *(*)()) F937_6856;
	R5286[17] = (char *(*)()) F938_6856;
	R5286[18] = (char *(*)()) F939_6856;
	R5286[19] = (char *(*)()) F940_6856;
	R5286[20] = (char *(*)()) F941_6856;
	R5286[21] = (char *(*)()) F942_6856;
	R5286[22] = (char *(*)()) F943_6856;
	R5286[23] = (char *(*)()) F944_6856;
	R5286[24] = (char *(*)()) F945_6856;
	R5286[25] = (char *(*)()) F946_6856;
	R5286[26] = (char *(*)()) F947_6856;
	R5286[27] = (char *(*)()) F948_6856;
	R5286[28] = (char *(*)()) F949_6856;
	R5286[29] = (char *(*)()) F950_6856;
	R5286[30] = (char *(*)()) F951_6856;
	R5286[31] = (char *(*)()) F952_6856;
	R5286[32] = (char *(*)()) F953_6856;
}

char *(*R5432[2])();
void R5432_init () {
	R5432[0] = (char *(*)()) F956_7072;
	R5432[1] = (char *(*)()) F957_7072;
}

char *(*R5435[2])();
void R5435_init () {
	R5435[0] = (char *(*)()) F956_7075;
	R5435[1] = (char *(*)()) F957_7075;
}

char *(*R5486[2])();
void R5486_init () {
	R5486[0] = (char *(*)()) F959_7169;
	R5486[1] = (char *(*)()) F960_7169;
}

char *(*R5487[2])();
void R5487_init () {
	R5487[0] = (char *(*)()) F959_7170;
	R5487[1] = (char *(*)()) F960_7170;
}

char *(*R5488[2])();
void R5488_init () {
	R5488[0] = (char *(*)()) F959_7171;
	R5488[1] = (char *(*)()) F960_7171;
}

char *(*R5492[2])();
void R5492_init () {
	R5492[0] = (char *(*)()) F959_7175;
	R5492[1] = (char *(*)()) F960_7175;
}

char *(*R5544[2])();
void R5544_init () {
	R5544[0] = (char *(*)()) F962_7270;
	R5544[1] = (char *(*)()) F963_7270;
}

char *(*R5547[2])();
void R5547_init () {
	R5547[0] = (char *(*)()) F962_7273;
	R5547[1] = (char *(*)()) F963_7273;
}

char *(*R5597[2])();
void R5597_init () {
	R5597[0] = (char *(*)()) F965_7366;
	R5597[1] = (char *(*)()) F966_7366;
}

char *(*R5600[2])();
void R5600_init () {
	R5600[0] = (char *(*)()) F965_7369;
	R5600[1] = (char *(*)()) F966_7369;
}

char *(*R5603[2])();
void R5603_init () {
	R5603[0] = (char *(*)()) F965_7372;
	R5603[1] = (char *(*)()) F966_7372;
}

char *(*R5657[2])();
void R5657_init () {
	R5657[0] = (char *(*)()) F968_7466;
	R5657[1] = (char *(*)()) F969_7466;
}

char *(*R5703[2])();
void R5703_init () {
	R5703[0] = (char *(*)()) F971_7554;
	R5703[1] = (char *(*)()) F972_7554;
}

char *(*R5704[2])();
void R5704_init () {
	R5704[0] = (char *(*)()) F971_7555;
	R5704[1] = (char *(*)()) F972_7555;
}

char *(*R5706[2])();
void R5706_init () {
	R5706[0] = (char *(*)()) F971_7557;
	R5706[1] = (char *(*)()) F972_7557;
}

char *(*R5709[2])();
void R5709_init () {
	R5709[0] = (char *(*)()) F971_7560;
	R5709[1] = (char *(*)()) F972_7560;
}

char *(*R5710[2])();
void R5710_init () {
	R5710[0] = (char *(*)()) F971_7561;
	R5710[1] = (char *(*)()) F972_7561;
}

char *(*R5758[2])();
void R5758_init () {
	R5758[0] = (char *(*)()) F974_7651;
	R5758[1] = (char *(*)()) F975_7651;
}

char *(*R5759[2])();
void R5759_init () {
	R5759[0] = (char *(*)()) F974_7652;
	R5759[1] = (char *(*)()) F975_7652;
}

char *(*R5762[2])();
void R5762_init () {
	R5762[0] = (char *(*)()) F974_7655;
	R5762[1] = (char *(*)()) F975_7655;
}

char *(*R5810[2])();
void R5810_init () {
	R5810[0] = (char *(*)()) F977_7745;
	R5810[1] = (char *(*)()) F978_7745;
}

char *(*R5811[2])();
void R5811_init () {
	R5811[0] = (char *(*)()) F977_7746;
	R5811[1] = (char *(*)()) F978_7746;
}

char *(*R5812[2])();
void R5812_init () {
	R5812[0] = (char *(*)()) F977_7747;
	R5812[1] = (char *(*)()) F978_7747;
}

char *(*R5813[2])();
void R5813_init () {
	R5813[0] = (char *(*)()) F977_7748;
	R5813[1] = (char *(*)()) F978_7748;
}

char *(*R5815[2])();
void R5815_init () {
	R5815[0] = (char *(*)()) F977_7750;
	R5815[1] = (char *(*)()) F978_7750;
}

char *(*R5861[2])();
void R5861_init () {
	R5861[0] = (char *(*)()) F980_7808;
	R5861[1] = (char *(*)()) F981_7808;
}

char *(*R5895[2])();
void R5895_init () {
	R5895[0] = (char *(*)()) F983_7874;
	R5895[1] = (char *(*)()) F984_7874;
}

char *(*R5916[2])();
void R5916_init () {
	R5916[0] = (char *(*)()) F986_7932;
	R5916[1] = (char *(*)()) F987_7932;
}

char *(*R6064[4])();
void R6064_init () {
	R6064[0] = (char *(*)()) F1029_8079;
	R6064[1] = (char *(*)()) F1030_8079_6064_1;
	R6064[2] = (char *(*)()) F1031_8079_6064_1;
	R6064[3] = (char *(*)()) F1030_8079_6064_1;
}
static EIF_REFERENCE F1030_8079_6064_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1030_8079(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1031_8079_6064_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1031_8079(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R6069[4])();
void R6069_init () {
	R6069[0] = (char *(*)()) F1029_8088;
	R6069[1] = (char *(*)()) F1030_8088_6069_535;
	R6069[2] = (char *(*)()) F1031_8088_6069_535;
	R6069[3] = (char *(*)()) F1030_8088_6069_535;
}
static EIF_REFERENCE F1030_8088_6069_535 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1030_8088(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1031_8088_6069_535 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1031_8088(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y6070_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6070_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6070_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6070_pgtype3[] = {992,0xFFFF};
EIF_TYPE_INDEX *Y6070_gen_type [4];
EIF_TYPE_INDEX Y6070 [4];
void Y6070_init (void)
{
	egc_routines_types [6070] = Y6070;
	egc_routines_gen_types [6070] = Y6070_gen_type;
	egc_routines_offset [6070] = 1028;
	Y6070_gen_type [0] = Y6070_pgtype0;
	Y6070_gen_type [1] = Y6070_pgtype1;
	Y6070_gen_type [2] = Y6070_pgtype2;
	Y6070_gen_type [3] = Y6070_pgtype3;
	Y6070[3] = 992;
}

char *(*R6071[277])();
void R6071_init () {
	{long i; for (i = 0; i < 2; i++) R6071[i] = (char *(*)()) F1036_8220;}
	{long i; for (i = 4; i < 6; i++) R6071[i] = (char *(*)()) F1040_8386;}
	R6071[276] = (char *(*)()) F1313_13936;
}

char *(*R6073[277])();
void R6073_init () {
	R6073[0] = (char *(*)()) F1037_8280;
	R6073[1] = (char *(*)()) F1038_8302;
	R6073[4] = (char *(*)()) F1041_8447;
	R6073[5] = (char *(*)()) F1042_8470;
	R6073[276] = (char *(*)()) F1313_14064;
}

char *(*R6074[277])();
void R6074_init () {
	R6074[0] = (char *(*)()) F1037_8279;
	R6074[1] = (char *(*)()) F1038_8301;
	R6074[4] = (char *(*)()) F1041_8445;
	R6074[5] = (char *(*)()) F1042_8468;
	R6074[276] = (char *(*)()) F1038_8301;
}

char *(*R6075[277])();
void R6075_init () {
	{long i; for (i = 0; i < 2; i++) R6075[i] = (char *(*)()) F1033_8093;}
	{long i; for (i = 4; i < 6; i++) R6075[i] = (char *(*)()) F1040_8398;}
	R6075[276] = (char *(*)()) F1033_8093;
}

char *(*R6085[277])();
void R6085_init () {
	{long i; for (i = 0; i < 2; i++) R6085[i] = (char *(*)()) F1036_8251;}
	{long i; for (i = 4; i < 6; i++) R6085[i] = (char *(*)()) F1040_8416;}
	R6085[276] = (char *(*)()) F1036_8251;
}

char *(*R6087[277])();
void R6087_init () {
	{long i; for (i = 0; i < 2; i++) R6087[i] = (char *(*)()) F1036_8253;}
	{long i; for (i = 4; i < 6; i++) R6087[i] = (char *(*)()) F1040_8418;}
	R6087[276] = (char *(*)()) F1036_8253;
}

char *(*R6088[277])();
void R6088_init () {
	R6088[0] = (char *(*)()) F1037_8289;
	R6088[1] = (char *(*)()) F619_5084;
	R6088[4] = (char *(*)()) F1041_8457;
	R6088[5] = (char *(*)()) F620_5084;
	R6088[276] = (char *(*)()) F619_5084;
}

char *(*R6091[277])();
void R6091_init () {
	{long i; for (i = 0; i < 2; i++) R6091[i] = (char *(*)()) F1033_8110;}
	{long i; for (i = 4; i < 6; i++) R6091[i] = (char *(*)()) F1040_8420;}
	R6091[276] = (char *(*)()) F1033_8110;
}

char *(*R6110[277])();
void R6110_init () {
	{long i; for (i = 0; i < 2; i++) R6110[i] = (char *(*)()) F1036_8242;}
	{long i; for (i = 4; i < 6; i++) R6110[i] = (char *(*)()) F1040_8407;}
	R6110[276] = (char *(*)()) F1313_13967;
}

char *(*R6111[277])();
void R6111_init () {
	{long i; for (i = 0; i < 2; i++) R6111[i] = (char *(*)()) F1036_8241;}
	{long i; for (i = 4; i < 6; i++) R6111[i] = (char *(*)()) F1040_8406;}
	R6111[276] = (char *(*)()) F1313_13969;
}

char *(*R6115[277])();
void R6115_init () {
	{long i; for (i = 0; i < 2; i++) R6115[i] = (char *(*)()) F1033_8134;}
	{long i; for (i = 4; i < 6; i++) R6115[i] = (char *(*)()) F1033_8134;}
	R6115[276] = (char *(*)()) F1313_13974;
}

char *(*R6116[277])();
void R6116_init () {
	{long i; for (i = 0; i < 2; i++) R6116[i] = (char *(*)()) F1033_8135;}
	{long i; for (i = 4; i < 6; i++) R6116[i] = (char *(*)()) F1033_8135;}
	R6116[276] = (char *(*)()) F1313_13980;
}

char *(*R6121[277])();
void R6121_init () {
	{long i; for (i = 0; i < 2; i++) R6121[i] = (char *(*)()) F1036_8238;}
	{long i; for (i = 4; i < 6; i++) R6121[i] = (char *(*)()) F1040_8403;}
	R6121[276] = (char *(*)()) F1313_13955;
}

char *(*R6132[277])();
void R6132_init () {
	R6132[0] = (char *(*)()) F1037_8285;
	R6132[1] = (char *(*)()) F1038_8368;
	R6132[4] = (char *(*)()) F1041_8452;
	R6132[5] = (char *(*)()) F1042_8536;
	R6132[276] = (char *(*)()) F1313_14024;
}

char *(*R6151[277])();
void R6151_init () {
	R6151[0] = (char *(*)()) F1037_8287;
	R6151[1] = (char *(*)()) F1038_8380;
	R6151[4] = (char *(*)()) F1041_8454;
	R6151[5] = (char *(*)()) F1042_8548;
	R6151[276] = (char *(*)()) F1313_13953;
}

char *(*R6155[277])();
void R6155_init () {
	R6155[0] = (char *(*)()) F1037_8291;
	R6155[1] = (char *(*)()) F1038_8384;
	R6155[4] = (char *(*)()) F1041_8458;
	R6155[5] = (char *(*)()) F1042_8551;
	R6155[276] = (char *(*)()) F1038_8384;
}

char *(*R6166[276])();
void R6166_init () {
	R6166[0] = (char *(*)()) F1038_8382;
	R6166[4] = (char *(*)()) F1042_8550;
	R6166[275] = (char *(*)()) F1038_8382;
}

char *(*R6169[276])();
void R6169_init () {
	R6169[0] = (char *(*)()) F1038_8321;
	R6169[4] = (char *(*)()) F1042_8489;
	R6169[275] = (char *(*)()) F1313_14066;
}

char *(*R6170[276])();
void R6170_init () {
	R6170[0] = (char *(*)()) F1035_8190;
	R6170[4] = (char *(*)()) F1035_8190;
	R6170[275] = (char *(*)()) F1313_14067;
}

char *(*R6181[276])();
void R6181_init () {
	R6181[0] = (char *(*)()) F1038_8332;
	R6181[4] = (char *(*)()) F1042_8500;
	R6181[275] = (char *(*)()) F1313_13989;
}

char *(*R6189[276])();
void R6189_init () {
	R6189[0] = (char *(*)()) F1038_8315;
	R6189[4] = (char *(*)()) F1042_8483;
	R6189[275] = (char *(*)()) F1313_14013;
}

char *(*R6190[276])();
void R6190_init () {
	R6190[0] = (char *(*)()) F1038_8316;
	R6190[4] = (char *(*)()) F1042_8484;
	R6190[275] = (char *(*)()) F1313_14014;
}

char *(*R6194[276])();
void R6194_init () {
	R6194[0] = (char *(*)()) F1038_8354;
	R6194[275] = (char *(*)()) F1313_14017;
}

char *(*R6195[276])();
void R6195_init () {
	R6195[0] = (char *(*)()) F1038_8355;
	R6195[4] = (char *(*)()) F1042_8523;
	R6195[275] = (char *(*)()) F1313_14015;
}

char *(*R6197[276])();
void R6197_init () {
	R6197[0] = (char *(*)()) F1038_8357;
	R6197[4] = (char *(*)()) F1042_8525;
	R6197[275] = (char *(*)()) F1313_14016;
}

char *(*R6198[276])();
void R6198_init () {
	R6198[0] = (char *(*)()) F1038_8362;
	R6198[4] = (char *(*)()) F1042_8530;
	R6198[275] = (char *(*)()) F1313_14060;
}

char *(*R6199[276])();
void R6199_init () {
	R6199[0] = (char *(*)()) F1038_8365;
	R6199[4] = (char *(*)()) F1042_8533;
	R6199[275] = (char *(*)()) F1038_8365;
}

char *(*R6211[277])();
void R6211_init () {
	{long i; for (i = 0; i < 2; i++) R6211[i] = (char *(*)()) F1036_8233;}
	R6211[276] = (char *(*)()) F1313_13961;
}

char *(*R6213[277])();
void R6213_init () {
	{long i; for (i = 0; i < 2; i++) R6213[i] = (char *(*)()) F1036_8236;}
	R6213[276] = (char *(*)()) F1313_13956;
}

char *(*R6223[277])();
void R6223_init () {
	R6223[0] = (char *(*)()) F1037_8282;
	R6223[1] = (char *(*)()) F1038_8352;
	R6223[276] = (char *(*)()) F1313_13957;
}

char *(*R6231[277])();
void R6231_init () {
	R6231[0] = (char *(*)()) F1037_8293;
	R6231[1] = (char *(*)()) F1036_8272;
	R6231[276] = (char *(*)()) F1036_8272;
}

char *(*R6246[276])();
void R6246_init () {
	R6246[0] = (char *(*)()) F1038_8310;
	R6246[275] = (char *(*)()) F1313_14012;
}


#ifdef __cplusplus
}
#endif
