#include "epoly17.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4067[437])();
void R4067_init () {
	R4067[0] = (char *(*)()) F774_5298;
	R4067[1] = (char *(*)()) F775_5298;
	R4067[2] = (char *(*)()) F776_5298;
	R4067[6] = (char *(*)()) F779_5365;
	R4067[20] = (char *(*)()) F794_5603;
	R4067[21] = (char *(*)()) F795_5603;
	R4067[22] = (char *(*)()) F796_5603;
	R4067[23] = (char *(*)()) F797_5603;
	R4067[24] = (char *(*)()) F798_5603;
	R4067[25] = (char *(*)()) F799_5603;
	R4067[26] = (char *(*)()) F800_5603;
	R4067[27] = (char *(*)()) F801_5603;
	R4067[28] = (char *(*)()) F802_5603;
	R4067[29] = (char *(*)()) F803_5603;
	R4067[30] = (char *(*)()) F804_5603;
	R4067[31] = (char *(*)()) F805_5603;
	R4067[33] = (char *(*)()) F794_5603;
	R4067[34] = (char *(*)()) F797_5603;
	R4067[35] = (char *(*)()) F801_5603;
	R4067[36] = (char *(*)()) F794_5603;
	{long i; for (i = 38; i < 40; i++) R4067[i] = (char *(*)()) F794_5603;}
	{long i; for (i = 40; i < 42; i++) R4067[i] = (char *(*)()) F797_5603;}
	{long i; for (i = 427; i < 437; i++) R4067[i] = (char *(*)()) F794_5603;}
}

char *(*R4068[597])();
void R4068_init () {
	R4068[0] = (char *(*)()) F613_5062;
	R4068[160] = (char *(*)()) F774_5299;
	R4068[161] = (char *(*)()) F775_5299;
	R4068[162] = (char *(*)()) F776_5299;
	R4068[166] = (char *(*)()) F779_5363;
	R4068[180] = (char *(*)()) F794_5604;
	R4068[181] = (char *(*)()) F795_5604;
	R4068[182] = (char *(*)()) F796_5604;
	R4068[183] = (char *(*)()) F797_5604;
	R4068[184] = (char *(*)()) F798_5604;
	R4068[185] = (char *(*)()) F799_5604;
	R4068[186] = (char *(*)()) F800_5604;
	R4068[187] = (char *(*)()) F801_5604;
	R4068[188] = (char *(*)()) F802_5604;
	R4068[189] = (char *(*)()) F803_5604;
	R4068[190] = (char *(*)()) F804_5604;
	R4068[191] = (char *(*)()) F805_5604;
	R4068[193] = (char *(*)()) F794_5604;
	R4068[194] = (char *(*)()) F797_5604;
	R4068[195] = (char *(*)()) F801_5604;
	R4068[196] = (char *(*)()) F794_5604;
	{long i; for (i = 198; i < 200; i++) R4068[i] = (char *(*)()) F794_5604;}
	{long i; for (i = 200; i < 202; i++) R4068[i] = (char *(*)()) F797_5604;}
	{long i; for (i = 209; i < 211; i++) R4068[i] = (char *(*)()) F822_5994;}
	R4068[440] = (char *(*)()) F822_5994;
	{long i; for (i = 587; i < 597; i++) R4068[i] = (char *(*)()) F794_5604;}
}

char *(*R4069[437])();
void R4069_init () {
	R4069[0] = (char *(*)()) F774_5290;
	R4069[1] = (char *(*)()) F775_5290;
	R4069[2] = (char *(*)()) F776_5290;
	R4069[6] = (char *(*)()) F774_5290;
	R4069[20] = (char *(*)()) F748_5259;
	R4069[21] = (char *(*)()) F749_5259;
	R4069[22] = (char *(*)()) F750_5259;
	R4069[23] = (char *(*)()) F751_5259;
	R4069[24] = (char *(*)()) F752_5259;
	R4069[25] = (char *(*)()) F753_5259;
	R4069[26] = (char *(*)()) F754_5259;
	R4069[27] = (char *(*)()) F755_5259;
	R4069[28] = (char *(*)()) F756_5259;
	R4069[29] = (char *(*)()) F757_5259;
	R4069[30] = (char *(*)()) F758_5259;
	R4069[31] = (char *(*)()) F759_5259;
	R4069[33] = (char *(*)()) F748_5259;
	R4069[34] = (char *(*)()) F751_5259;
	R4069[35] = (char *(*)()) F755_5259;
	R4069[36] = (char *(*)()) F748_5259;
	{long i; for (i = 38; i < 40; i++) R4069[i] = (char *(*)()) F748_5259;}
	{long i; for (i = 40; i < 42; i++) R4069[i] = (char *(*)()) F751_5259;}
	{long i; for (i = 49; i < 51; i++) R4069[i] = (char *(*)()) F822_5936;}
	R4069[280] = (char *(*)()) F822_5936;
	{long i; for (i = 427; i < 437; i++) R4069[i] = (char *(*)()) F748_5259;}
}

char *(*R4070[431])();
void R4070_init () {
	R4070[0] = (char *(*)()) F779_5364;
	R4070[14] = (char *(*)()) F794_5605;
	R4070[15] = (char *(*)()) F795_5605;
	R4070[16] = (char *(*)()) F796_5605;
	R4070[17] = (char *(*)()) F797_5605;
	R4070[18] = (char *(*)()) F798_5605;
	R4070[19] = (char *(*)()) F799_5605;
	R4070[20] = (char *(*)()) F800_5605;
	R4070[21] = (char *(*)()) F801_5605;
	R4070[22] = (char *(*)()) F802_5605;
	R4070[23] = (char *(*)()) F803_5605;
	R4070[24] = (char *(*)()) F804_5605;
	R4070[25] = (char *(*)()) F805_5605;
	R4070[27] = (char *(*)()) F794_5605;
	R4070[28] = (char *(*)()) F797_5605;
	R4070[29] = (char *(*)()) F801_5605;
	R4070[30] = (char *(*)()) F794_5605;
	{long i; for (i = 32; i < 34; i++) R4070[i] = (char *(*)()) F794_5605;}
	{long i; for (i = 34; i < 36; i++) R4070[i] = (char *(*)()) F797_5605;}
	{long i; for (i = 43; i < 45; i++) R4070[i] = (char *(*)()) F822_5995;}
	R4070[274] = (char *(*)()) F1054_8646;
	{long i; for (i = 421; i < 431; i++) R4070[i] = (char *(*)()) F794_5605;}
}

char *(*R4075[540])();
void R4075_init () {
	R4075[0] = (char *(*)()) F774_5305;
	R4075[1] = (char *(*)()) F775_5305_4075_4;
	R4075[2] = (char *(*)()) F776_5305_4075_4;
	R4075[6] = (char *(*)()) F780_5383;
	R4075[20] = (char *(*)()) F794_5612;
	R4075[21] = (char *(*)()) F795_5612_4075_4;
	R4075[22] = (char *(*)()) F796_5612_4075_4;
	R4075[23] = (char *(*)()) F797_5612_4075_4;
	R4075[24] = (char *(*)()) F798_5612_4075_4;
	R4075[25] = (char *(*)()) F799_5612_4075_4;
	R4075[26] = (char *(*)()) F800_5612_4075_4;
	R4075[27] = (char *(*)()) F801_5612_4075_4;
	R4075[28] = (char *(*)()) F802_5612_4075_4;
	R4075[29] = (char *(*)()) F803_5612_4075_4;
	R4075[30] = (char *(*)()) F804_5612_4075_4;
	R4075[31] = (char *(*)()) F805_5612_4075_4;
	R4075[33] = (char *(*)()) F807_5640;
	R4075[34] = (char *(*)()) F808_5640_4075_4;
	R4075[35] = (char *(*)()) F809_5640_4075_4;
	R4075[36] = (char *(*)()) F794_5612;
	R4075[38] = (char *(*)()) F811_5661;
	R4075[39] = (char *(*)()) F794_5612;
	{long i; for (i = 40; i < 42; i++) R4075[i] = (char *(*)()) F797_5612_4075_4;}
	R4075[264] = (char *(*)()) F1038_8347_4075_4;
	R4075[268] = (char *(*)()) F1042_8515_4075_4;
	{long i; for (i = 427; i < 437; i++) R4075[i] = (char *(*)()) F794_5612;}
	R4075[539] = (char *(*)()) F1038_8347_4075_4;
}
static void F775_5305_4075_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F775_5305(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F776_5305_4075_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F776_5305(Current, *(EIF_BOOLEAN *)arg1);
}
static void F795_5612_4075_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F795_5612(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F796_5612_4075_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F796_5612(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F797_5612_4075_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F797_5612(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F798_5612_4075_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F798_5612(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F799_5612_4075_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F799_5612(Current, *(EIF_POINTER *)arg1);
}
static void F800_5612_4075_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F800_5612(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F801_5612_4075_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F801_5612(Current, *(EIF_BOOLEAN *)arg1);
}
static void F802_5612_4075_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F802_5612(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F803_5612_4075_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F803_5612(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F804_5612_4075_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F804_5612(Current, *(EIF_REAL_32 *)arg1);
}
static void F805_5612_4075_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F805_5612(Current, *(EIF_REAL_64 *)arg1);
}
static void F808_5640_4075_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F808_5640(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F809_5640_4075_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F809_5640(Current, *(EIF_BOOLEAN *)arg1);
}
static void F1038_8347_4075_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1038_8347(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1042_8515_4075_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1042_8515(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R4079[540])();
void R4079_init () {
	R4079[0] = (char *(*)()) F774_5314;
	R4079[1] = (char *(*)()) F775_5314;
	R4079[2] = (char *(*)()) F776_5314;
	R4079[6] = (char *(*)()) F779_5376;
	R4079[10] = (char *(*)()) F784_5494;
	R4079[11] = (char *(*)()) F785_5494;
	R4079[12] = (char *(*)()) F786_5494;
	R4079[13] = (char *(*)()) F787_5494;
	R4079[14] = (char *(*)()) F788_5494;
	R4079[15] = (char *(*)()) F789_5494;
	R4079[16] = (char *(*)()) F784_5494;
	R4079[17] = (char *(*)()) F789_5494;
	R4079[18] = (char *(*)()) F785_5494;
	R4079[19] = (char *(*)()) F784_5494;
	R4079[20] = (char *(*)()) F794_5630;
	R4079[21] = (char *(*)()) F795_5630;
	R4079[22] = (char *(*)()) F796_5630;
	R4079[23] = (char *(*)()) F797_5630;
	R4079[24] = (char *(*)()) F798_5630;
	R4079[25] = (char *(*)()) F799_5630;
	R4079[26] = (char *(*)()) F800_5630;
	R4079[27] = (char *(*)()) F801_5630;
	R4079[28] = (char *(*)()) F802_5630;
	R4079[29] = (char *(*)()) F803_5630;
	R4079[30] = (char *(*)()) F804_5630;
	R4079[31] = (char *(*)()) F805_5630;
	R4079[33] = (char *(*)()) F794_5630;
	R4079[34] = (char *(*)()) F797_5630;
	R4079[35] = (char *(*)()) F801_5630;
	R4079[36] = (char *(*)()) F794_5630;
	R4079[38] = (char *(*)()) F811_5673;
	R4079[39] = (char *(*)()) F794_5630;
	{long i; for (i = 40; i < 42; i++) R4079[i] = (char *(*)()) F797_5630;}
	R4079[264] = (char *(*)()) F1038_8362;
	R4079[268] = (char *(*)()) F1042_8530;
	{long i; for (i = 427; i < 437; i++) R4079[i] = (char *(*)()) F794_5630;}
	R4079[539] = (char *(*)()) F1313_14060;
}

char *(*R4082[607])();
void R4082_init () {
	R4082[0] = (char *(*)()) F707_5165_4082_5;
	R4082[1] = (char *(*)()) F708_5165_4082_5;
	R4082[2] = (char *(*)()) F709_5165_4082_5;
	R4082[3] = (char *(*)()) F710_5165_4082_5;
	R4082[4] = (char *(*)()) F711_5165_4082_5;
	R4082[5] = (char *(*)()) F712_5165_4082_5;
	R4082[6] = (char *(*)()) F713_5165_4082_5;
	R4082[7] = (char *(*)()) F714_5165_4082_5;
	R4082[8] = (char *(*)()) F715_5165_4082_5;
	R4082[9] = (char *(*)()) F716_5165_4082_5;
	R4082[10] = (char *(*)()) F717_5165_4082_5;
	R4082[11] = (char *(*)()) F718_5165_4082_5;
	R4082[67] = (char *(*)()) F724_5223_4082_5;
	R4082[68] = (char *(*)()) F727_5223_4082_5;
	R4082[69] = (char *(*)()) F731_5223_4082_5;
	R4082[73] = (char *(*)()) F724_5223_4082_5;
	R4082[87] = (char *(*)()) F794_5577_4082_5;
	R4082[88] = (char *(*)()) F795_5577_4082_5;
	R4082[89] = (char *(*)()) F796_5577_4082_5;
	R4082[90] = (char *(*)()) F797_5577_4082_5;
	R4082[91] = (char *(*)()) F798_5577_4082_5;
	R4082[92] = (char *(*)()) F799_5577_4082_5;
	R4082[93] = (char *(*)()) F800_5577_4082_5;
	R4082[94] = (char *(*)()) F801_5577_4082_5;
	R4082[95] = (char *(*)()) F802_5577_4082_5;
	R4082[96] = (char *(*)()) F803_5577_4082_5;
	R4082[97] = (char *(*)()) F804_5577_4082_5;
	R4082[98] = (char *(*)()) F805_5577_4082_5;
	R4082[100] = (char *(*)()) F794_5577_4082_5;
	R4082[101] = (char *(*)()) F797_5577_4082_5;
	R4082[102] = (char *(*)()) F801_5577_4082_5;
	R4082[103] = (char *(*)()) F794_5577_4082_5;
	{long i; for (i = 105; i < 107; i++) R4082[i] = (char *(*)()) F794_5577_4082_5;}
	{long i; for (i = 107; i < 109; i++) R4082[i] = (char *(*)()) F797_5577_4082_5;}
	R4082[331] = (char *(*)()) F1038_8299_4082_5;
	R4082[335] = (char *(*)()) F1042_8468_4082_5;
	{long i; for (i = 494; i < 504; i++) R4082[i] = (char *(*)()) F794_5577_4082_5;}
	R4082[606] = (char *(*)()) F1313_13951_4082_5;
}
static EIF_REFERENCE F707_5165_4082_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F707_5165(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F708_5165_4082_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F708_5165(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(977, 0x00).id, 977, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F709_5165_4082_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F709_5165(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(968, 0x00).id, 968, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F710_5165_4082_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F710_5165(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F711_5165_4082_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F711_5165(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(974, 0x00).id, 974, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F712_5165_4082_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F712_5165(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1025, 0x00).id, 1025, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F713_5165_4082_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F713_5165(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(989, 0x00).id, 989, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F714_5165_4082_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F714_5165(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F715_5165_4082_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F715_5165(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(971, 0x00).id, 971, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F716_5165_4082_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F716_5165(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(986, 0x00).id, 986, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F717_5165_4082_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F717_5165(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(980, 0x00).id, 980, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F718_5165_4082_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F718_5165(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(983, 0x00).id, 983, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F724_5223_4082_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F724_5223(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F727_5223_4082_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F727_5223(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F731_5223_4082_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F731_5223(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F794_5577_4082_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F794_5577(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F795_5577_4082_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F795_5577(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(977, 0x00).id, 977, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F796_5577_4082_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F796_5577(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(968, 0x00).id, 968, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F797_5577_4082_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F797_5577(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F798_5577_4082_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F798_5577(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(974, 0x00).id, 974, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F799_5577_4082_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F799_5577(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1025, 0x00).id, 1025, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F800_5577_4082_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F800_5577(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(989, 0x00).id, 989, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F801_5577_4082_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F801_5577(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F802_5577_4082_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F802_5577(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(971, 0x00).id, 971, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F803_5577_4082_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F803_5577(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(986, 0x00).id, 986, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F804_5577_4082_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F804_5577(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(980, 0x00).id, 980, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F805_5577_4082_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F805_5577(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(983, 0x00).id, 983, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1038_8299_4082_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1038_8299(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(989, 0x00).id, 989, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1042_8468_4082_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1042_8468(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(986, 0x00).id, 986, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1313_13951_4082_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1313_13951(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(989, 0x00).id, 989, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R4085[607])();
void R4085_init () {
	R4085[0] = (char *(*)()) F707_5184_4085_9;
	R4085[1] = (char *(*)()) F708_5184_4085_9;
	R4085[2] = (char *(*)()) F709_5184_4085_9;
	R4085[3] = (char *(*)()) F710_5184_4085_9;
	R4085[4] = (char *(*)()) F711_5184_4085_9;
	R4085[5] = (char *(*)()) F712_5184_4085_9;
	R4085[6] = (char *(*)()) F713_5184_4085_9;
	R4085[7] = (char *(*)()) F714_5184_4085_9;
	R4085[8] = (char *(*)()) F715_5184_4085_9;
	R4085[9] = (char *(*)()) F716_5184_4085_9;
	R4085[10] = (char *(*)()) F717_5184_4085_9;
	R4085[11] = (char *(*)()) F718_5184_4085_9;
	R4085[77] = (char *(*)()) F784_5486;
	R4085[78] = (char *(*)()) F785_5486_4085_9;
	R4085[79] = (char *(*)()) F786_5486_4085_9;
	R4085[80] = (char *(*)()) F787_5486_4085_9;
	R4085[81] = (char *(*)()) F788_5486_4085_9;
	R4085[82] = (char *(*)()) F789_5486_4085_9;
	R4085[83] = (char *(*)()) F784_5486;
	R4085[84] = (char *(*)()) F789_5486_4085_9;
	R4085[85] = (char *(*)()) F785_5486_4085_9;
	R4085[86] = (char *(*)()) F784_5486;
	R4085[87] = (char *(*)()) F794_5610_4085_9;
	R4085[88] = (char *(*)()) F795_5610_4085_9;
	R4085[89] = (char *(*)()) F796_5610_4085_9;
	R4085[90] = (char *(*)()) F797_5610_4085_9;
	R4085[91] = (char *(*)()) F798_5610_4085_9;
	R4085[92] = (char *(*)()) F799_5610_4085_9;
	R4085[93] = (char *(*)()) F800_5610_4085_9;
	R4085[94] = (char *(*)()) F801_5610_4085_9;
	R4085[95] = (char *(*)()) F802_5610_4085_9;
	R4085[96] = (char *(*)()) F803_5610_4085_9;
	R4085[97] = (char *(*)()) F804_5610_4085_9;
	R4085[98] = (char *(*)()) F805_5610_4085_9;
	R4085[100] = (char *(*)()) F794_5610_4085_9;
	R4085[101] = (char *(*)()) F797_5610_4085_9;
	R4085[102] = (char *(*)()) F801_5610_4085_9;
	R4085[103] = (char *(*)()) F794_5610_4085_9;
	R4085[105] = (char *(*)()) F811_5665_4085_9;
	R4085[106] = (char *(*)()) F794_5610_4085_9;
	{long i; for (i = 107; i < 109; i++) R4085[i] = (char *(*)()) F797_5610_4085_9;}
	R4085[331] = (char *(*)()) F1038_8320_4085_9;
	R4085[335] = (char *(*)()) F1042_8488_4085_9;
	{long i; for (i = 494; i < 504; i++) R4085[i] = (char *(*)()) F794_5610_4085_9;}
	R4085[606] = (char *(*)()) F1313_13986_4085_9;
}
static void F707_5184_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F707_5184(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F708_5184_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F708_5184(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F709_5184_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F709_5184(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F710_5184_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F710_5184(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F711_5184_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F711_5184(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F712_5184_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F712_5184(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F713_5184_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F713_5184(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F714_5184_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F714_5184(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F715_5184_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F715_5184(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F716_5184_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F716_5184(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F717_5184_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F717_5184(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F718_5184_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F718_5184(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F785_5486_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F785_5486(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F786_5486_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F786_5486(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F787_5486_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F787_5486(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F788_5486_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F788_5486(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F789_5486_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F789_5486(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F794_5610_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F794_5610(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F795_5610_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F795_5610(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F796_5610_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F796_5610(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F797_5610_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F797_5610(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F798_5610_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F798_5610(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F799_5610_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F799_5610(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F800_5610_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F800_5610(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F801_5610_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F801_5610(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F802_5610_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F802_5610(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F803_5610_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F803_5610(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F804_5610_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F804_5610(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F805_5610_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F805_5610(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F811_5665_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F811_5665(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1038_8320_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1038_8320(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1042_8488_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1042_8488(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1313_13986_4085_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1313_13986(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

static EIF_TYPE_INDEX Y4087_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype30[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype31[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype32[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype33[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype34[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype35[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype36[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype37[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype38[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype39[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype40[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype41[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype42[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype43[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype44[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype45[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype46[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype47[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype48[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype49[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype50[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype51[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype52[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype53[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype54[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype55[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype56[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype57[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype58[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype59[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype60[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype61[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype62[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype63[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype64[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype65[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype66[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype67[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype68[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype69[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype70[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype71[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype72[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype73[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype74[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype75[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype76[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype77[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype78[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype79[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype80[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype81[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype82[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype83[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype84[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype85[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype86[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype87[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype88[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype89[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype90[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype91[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype92[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype93[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype94[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype95[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype96[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype97[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype98[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype99[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype100[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype101[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype102[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype103[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype104[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype105[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype106[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype107[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype108[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype109[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype110[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype111[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype112[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype113[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype114[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype115[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype116[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype117[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype118[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype119[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype120[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype121[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype122[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype123[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype124[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype125[] = {0xFF01,1032,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype126[] = {0xFF01,1032,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype127[] = {0xFF01,1032,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype128[] = {0xFF01,1037,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype129[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype130[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype131[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype132[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype133[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype134[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype135[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype136[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype137[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype138[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype139[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype140[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype141[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype142[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype143[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype144[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype145[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype146[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype147[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype148[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype149[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype150[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype151[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype152[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype153[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype154[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype155[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype156[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype157[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype158[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype159[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype160[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype161[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype162[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype163[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype164[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y4087_pgtype165[] = {959,0xFFFF};
EIF_TYPE_INDEX *Y4087_gen_type [772];
EIF_TYPE_INDEX Y4087 [772];
void Y4087_init (void)
{
	egc_routines_types [4087] = Y4087;
	egc_routines_gen_types [4087] = Y4087_gen_type;
	egc_routines_offset [4087] = 542;
	Y4087_gen_type [0] = Y4087_pgtype0;
	Y4087_gen_type [1] = Y4087_pgtype1;
	Y4087_gen_type [2] = Y4087_pgtype2;
	Y4087_gen_type [3] = Y4087_pgtype3;
	Y4087_gen_type [4] = Y4087_pgtype4;
	Y4087_gen_type [5] = Y4087_pgtype5;
	Y4087_gen_type [6] = Y4087_pgtype6;
	Y4087_gen_type [7] = Y4087_pgtype7;
	Y4087_gen_type [8] = Y4087_pgtype8;
	Y4087_gen_type [9] = Y4087_pgtype9;
	Y4087_gen_type [10] = Y4087_pgtype10;
	Y4087_gen_type [11] = Y4087_pgtype11;
	Y4087_gen_type [12] = Y4087_pgtype12;
	Y4087_gen_type [13] = Y4087_pgtype13;
	Y4087_gen_type [14] = Y4087_pgtype14;
	Y4087_gen_type [15] = Y4087_pgtype15;
	Y4087_gen_type [16] = Y4087_pgtype16;
	Y4087_gen_type [17] = Y4087_pgtype17;
	Y4087_gen_type [18] = Y4087_pgtype18;
	Y4087_gen_type [19] = Y4087_pgtype19;
	Y4087_gen_type [20] = Y4087_pgtype20;
	Y4087_gen_type [21] = Y4087_pgtype21;
	Y4087_gen_type [22] = Y4087_pgtype22;
	Y4087_gen_type [23] = Y4087_pgtype23;
	Y4087_gen_type [24] = Y4087_pgtype24;
	Y4087_gen_type [25] = Y4087_pgtype25;
	Y4087_gen_type [26] = Y4087_pgtype26;
	Y4087_gen_type [27] = Y4087_pgtype27;
	Y4087_gen_type [28] = Y4087_pgtype28;
	Y4087_gen_type [29] = Y4087_pgtype29;
	Y4087_gen_type [30] = Y4087_pgtype30;
	Y4087_gen_type [31] = Y4087_pgtype31;
	Y4087_gen_type [151] = Y4087_pgtype32;
	Y4087_gen_type [152] = Y4087_pgtype33;
	Y4087_gen_type [153] = Y4087_pgtype34;
	Y4087_gen_type [154] = Y4087_pgtype35;
	Y4087_gen_type [155] = Y4087_pgtype36;
	Y4087_gen_type [156] = Y4087_pgtype37;
	Y4087_gen_type [157] = Y4087_pgtype38;
	Y4087_gen_type [158] = Y4087_pgtype39;
	Y4087_gen_type [159] = Y4087_pgtype40;
	Y4087_gen_type [160] = Y4087_pgtype41;
	Y4087_gen_type [161] = Y4087_pgtype42;
	Y4087_gen_type [162] = Y4087_pgtype43;
	Y4087_gen_type [163] = Y4087_pgtype44;
	Y4087_gen_type [164] = Y4087_pgtype45;
	Y4087_gen_type [165] = Y4087_pgtype46;
	Y4087_gen_type [166] = Y4087_pgtype47;
	Y4087_gen_type [167] = Y4087_pgtype48;
	Y4087_gen_type [168] = Y4087_pgtype49;
	Y4087_gen_type [169] = Y4087_pgtype50;
	Y4087_gen_type [170] = Y4087_pgtype51;
	Y4087_gen_type [171] = Y4087_pgtype52;
	Y4087_gen_type [172] = Y4087_pgtype53;
	Y4087_gen_type [173] = Y4087_pgtype54;
	Y4087_gen_type [174] = Y4087_pgtype55;
	Y4087_gen_type [175] = Y4087_pgtype56;
	Y4087_gen_type [176] = Y4087_pgtype57;
	Y4087_gen_type [177] = Y4087_pgtype58;
	Y4087_gen_type [178] = Y4087_pgtype59;
	Y4087_gen_type [179] = Y4087_pgtype60;
	Y4087_gen_type [180] = Y4087_pgtype61;
	Y4087_gen_type [181] = Y4087_pgtype62;
	Y4087_gen_type [182] = Y4087_pgtype63;
	Y4087_gen_type [183] = Y4087_pgtype64;
	Y4087_gen_type [184] = Y4087_pgtype65;
	Y4087_gen_type [185] = Y4087_pgtype66;
	Y4087_gen_type [186] = Y4087_pgtype67;
	Y4087_gen_type [187] = Y4087_pgtype68;
	Y4087_gen_type [188] = Y4087_pgtype69;
	Y4087_gen_type [189] = Y4087_pgtype70;
	Y4087_gen_type [190] = Y4087_pgtype71;
	Y4087_gen_type [191] = Y4087_pgtype72;
	Y4087_gen_type [192] = Y4087_pgtype73;
	Y4087_gen_type [193] = Y4087_pgtype74;
	Y4087_gen_type [194] = Y4087_pgtype75;
	Y4087_gen_type [195] = Y4087_pgtype76;
	Y4087_gen_type [196] = Y4087_pgtype77;
	Y4087_gen_type [197] = Y4087_pgtype78;
	Y4087_gen_type [198] = Y4087_pgtype79;
	Y4087_gen_type [199] = Y4087_pgtype80;
	Y4087_gen_type [200] = Y4087_pgtype81;
	Y4087_gen_type [201] = Y4087_pgtype82;
	Y4087_gen_type [202] = Y4087_pgtype83;
	Y4087_gen_type [203] = Y4087_pgtype84;
	Y4087_gen_type [204] = Y4087_pgtype85;
	Y4087_gen_type [205] = Y4087_pgtype86;
	Y4087_gen_type [206] = Y4087_pgtype87;
	Y4087_gen_type [207] = Y4087_pgtype88;
	Y4087_gen_type [208] = Y4087_pgtype89;
	Y4087_gen_type [209] = Y4087_pgtype90;
	Y4087_gen_type [210] = Y4087_pgtype91;
	Y4087_gen_type [211] = Y4087_pgtype92;
	Y4087_gen_type [212] = Y4087_pgtype93;
	Y4087_gen_type [213] = Y4087_pgtype94;
	Y4087_gen_type [214] = Y4087_pgtype95;
	Y4087_gen_type [215] = Y4087_pgtype96;
	Y4087_gen_type [216] = Y4087_pgtype97;
	Y4087_gen_type [217] = Y4087_pgtype98;
	Y4087_gen_type [218] = Y4087_pgtype99;
	Y4087_gen_type [219] = Y4087_pgtype100;
	Y4087_gen_type [220] = Y4087_pgtype101;
	Y4087_gen_type [221] = Y4087_pgtype102;
	Y4087_gen_type [222] = Y4087_pgtype103;
	Y4087_gen_type [223] = Y4087_pgtype104;
	Y4087_gen_type [224] = Y4087_pgtype105;
	Y4087_gen_type [225] = Y4087_pgtype106;
	Y4087_gen_type [226] = Y4087_pgtype107;
	Y4087_gen_type [227] = Y4087_pgtype108;
	Y4087_gen_type [228] = Y4087_pgtype109;
	Y4087_gen_type [229] = Y4087_pgtype110;
	Y4087_gen_type [230] = Y4087_pgtype111;
	Y4087_gen_type [231] = Y4087_pgtype112;
	Y4087_gen_type [232] = Y4087_pgtype113;
	Y4087_gen_type [233] = Y4087_pgtype114;
	Y4087_gen_type [234] = Y4087_pgtype115;
	Y4087_gen_type [235] = Y4087_pgtype116;
	Y4087_gen_type [236] = Y4087_pgtype117;
	Y4087_gen_type [237] = Y4087_pgtype118;
	Y4087_gen_type [241] = Y4087_pgtype119;
	Y4087_gen_type [242] = Y4087_pgtype120;
	Y4087_gen_type [243] = Y4087_pgtype121;
	Y4087_gen_type [244] = Y4087_pgtype122;
	Y4087_gen_type [245] = Y4087_pgtype123;
	Y4087_gen_type [246] = Y4087_pgtype124;
	Y4087_gen_type [247] = Y4087_pgtype125;
	Y4087_gen_type [248] = Y4087_pgtype126;
	Y4087_gen_type [249] = Y4087_pgtype127;
	Y4087_gen_type [250] = Y4087_pgtype128;
	Y4087_gen_type [251] = Y4087_pgtype129;
	Y4087_gen_type [252] = Y4087_pgtype130;
	Y4087_gen_type [253] = Y4087_pgtype131;
	Y4087_gen_type [254] = Y4087_pgtype132;
	Y4087_gen_type [255] = Y4087_pgtype133;
	Y4087_gen_type [256] = Y4087_pgtype134;
	Y4087_gen_type [257] = Y4087_pgtype135;
	Y4087_gen_type [258] = Y4087_pgtype136;
	Y4087_gen_type [259] = Y4087_pgtype137;
	Y4087_gen_type [260] = Y4087_pgtype138;
	Y4087_gen_type [261] = Y4087_pgtype139;
	Y4087_gen_type [262] = Y4087_pgtype140;
	Y4087_gen_type [263] = Y4087_pgtype141;
	Y4087_gen_type [264] = Y4087_pgtype142;
	Y4087_gen_type [265] = Y4087_pgtype143;
	Y4087_gen_type [266] = Y4087_pgtype144;
	Y4087_gen_type [267] = Y4087_pgtype145;
	Y4087_gen_type [268] = Y4087_pgtype146;
	Y4087_gen_type [269] = Y4087_pgtype147;
	Y4087_gen_type [270] = Y4087_pgtype148;
	Y4087_gen_type [271] = Y4087_pgtype149;
	Y4087_gen_type [272] = Y4087_pgtype150;
	Y4087_gen_type [495] = Y4087_pgtype151;
	Y4087_gen_type [496] = Y4087_pgtype152;
	Y4087_gen_type [499] = Y4087_pgtype153;
	Y4087_gen_type [658] = Y4087_pgtype154;
	Y4087_gen_type [659] = Y4087_pgtype155;
	Y4087_gen_type [660] = Y4087_pgtype156;
	Y4087_gen_type [661] = Y4087_pgtype157;
	Y4087_gen_type [662] = Y4087_pgtype158;
	Y4087_gen_type [663] = Y4087_pgtype159;
	Y4087_gen_type [664] = Y4087_pgtype160;
	Y4087_gen_type [665] = Y4087_pgtype161;
	Y4087_gen_type [666] = Y4087_pgtype162;
	Y4087_gen_type [667] = Y4087_pgtype163;
	Y4087_gen_type [770] = Y4087_pgtype164;
	Y4087_gen_type [771] = Y4087_pgtype165;
	{long i; for (i = 151; i < 238; i++) Y4087[i] = 959;};
	{long i; for (i = 247; i < 250; i++) Y4087[i] = 1032;};
	Y4087[250] = 1037;
	{long i; for (i = 251; i < 273; i++) Y4087[i] = 959;};
	{long i; for (i = 495; i < 497; i++) Y4087[i] = 959;};
	Y4087[499] = 959;
	{long i; for (i = 658; i < 668; i++) Y4087[i] = 959;};
	{long i; for (i = 770; i < 772; i++) Y4087[i] = 959;};
}

char *(*R4089[597])();
void R4089_init () {
	R4089[0] = (char *(*)()) F613_5055_4089_1;
	R4089[160] = (char *(*)()) F774_5280;
	R4089[161] = (char *(*)()) F775_5280_4089_1;
	R4089[162] = (char *(*)()) F776_5280_4089_1;
	R4089[166] = (char *(*)()) F774_5280;
	R4089[180] = (char *(*)()) F794_5576;
	R4089[181] = (char *(*)()) F795_5576_4089_1;
	R4089[182] = (char *(*)()) F796_5576_4089_1;
	R4089[183] = (char *(*)()) F797_5576_4089_1;
	R4089[184] = (char *(*)()) F798_5576_4089_1;
	R4089[185] = (char *(*)()) F799_5576_4089_1;
	R4089[186] = (char *(*)()) F800_5576_4089_1;
	R4089[187] = (char *(*)()) F801_5576_4089_1;
	R4089[188] = (char *(*)()) F802_5576_4089_1;
	R4089[189] = (char *(*)()) F803_5576_4089_1;
	R4089[190] = (char *(*)()) F804_5576_4089_1;
	R4089[191] = (char *(*)()) F805_5576_4089_1;
	R4089[193] = (char *(*)()) F794_5576;
	R4089[194] = (char *(*)()) F797_5576_4089_1;
	R4089[195] = (char *(*)()) F801_5576_4089_1;
	R4089[196] = (char *(*)()) F794_5576;
	{long i; for (i = 198; i < 200; i++) R4089[i] = (char *(*)()) F794_5576;}
	{long i; for (i = 200; i < 202; i++) R4089[i] = (char *(*)()) F797_5576_4089_1;}
	{long i; for (i = 209; i < 211; i++) R4089[i] = (char *(*)()) F822_5916_4089_1;}
	R4089[440] = (char *(*)()) F822_5916_4089_1;
	{long i; for (i = 587; i < 597; i++) R4089[i] = (char *(*)()) F794_5576;}
}
static EIF_REFERENCE F613_5055_4089_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F613_5055(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F775_5280_4089_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F775_5280(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F776_5280_4089_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F776_5280(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F795_5576_4089_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F795_5576(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(977, 0x00).id, 977, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F796_5576_4089_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F796_5576(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(968, 0x00).id, 968, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F797_5576_4089_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F797_5576(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F798_5576_4089_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F798_5576(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(974, 0x00).id, 974, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F799_5576_4089_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F799_5576(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1025, 0x00).id, 1025, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F800_5576_4089_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F800_5576(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(989, 0x00).id, 989, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F801_5576_4089_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F801_5576(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F802_5576_4089_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F802_5576(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(971, 0x00).id, 971, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F803_5576_4089_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F803_5576(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(986, 0x00).id, 986, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F804_5576_4089_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F804_5576(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(980, 0x00).id, 980, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F805_5576_4089_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F805_5576(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(983, 0x00).id, 983, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F822_5916_4089_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F822_5916(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(989, 0x00).id, 989, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y4089_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype114[] = {0xFF01,23,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype118[] = {0xFF01,326,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype120[] = {0xFF01,1027,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype123[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype124[] = {0xFF01,1274,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype125[] = {0xFF01,1133,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype126[] = {0xFF01,1147,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype127[] = {0xFF01,1148,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype128[] = {0xFF01,1137,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype129[] = {0xFF01,1141,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype130[] = {0xFF01,1142,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype131[] = {0xFF01,1135,0xFFFF};
static EIF_TYPE_INDEX Y4089_pgtype132[] = {0xFF01,1191,0xFFFF};
EIF_TYPE_INDEX *Y4089_gen_type [636];
EIF_TYPE_INDEX Y4089 [636];
void Y4089_init (void)
{
	egc_routines_types [4089] = Y4089;
	egc_routines_gen_types [4089] = Y4089_gen_type;
	egc_routines_offset [4089] = 574;
	Y4089_gen_type [0] = Y4089_pgtype0;
	Y4089_gen_type [1] = Y4089_pgtype1;
	Y4089_gen_type [2] = Y4089_pgtype2;
	Y4089_gen_type [3] = Y4089_pgtype3;
	Y4089_gen_type [4] = Y4089_pgtype4;
	Y4089_gen_type [5] = Y4089_pgtype5;
	Y4089_gen_type [6] = Y4089_pgtype6;
	Y4089_gen_type [7] = Y4089_pgtype7;
	Y4089_gen_type [8] = Y4089_pgtype8;
	Y4089_gen_type [9] = Y4089_pgtype9;
	Y4089_gen_type [10] = Y4089_pgtype10;
	Y4089_gen_type [11] = Y4089_pgtype11;
	Y4089_gen_type [12] = Y4089_pgtype12;
	Y4089_gen_type [13] = Y4089_pgtype13;
	Y4089_gen_type [14] = Y4089_pgtype14;
	Y4089_gen_type [15] = Y4089_pgtype15;
	Y4089_gen_type [16] = Y4089_pgtype16;
	Y4089_gen_type [17] = Y4089_pgtype17;
	Y4089_gen_type [18] = Y4089_pgtype18;
	Y4089_gen_type [19] = Y4089_pgtype19;
	Y4089_gen_type [20] = Y4089_pgtype20;
	Y4089_gen_type [21] = Y4089_pgtype21;
	Y4089_gen_type [22] = Y4089_pgtype22;
	Y4089_gen_type [23] = Y4089_pgtype23;
	Y4089_gen_type [38] = Y4089_pgtype24;
	Y4089_gen_type [76] = Y4089_pgtype25;
	Y4089_gen_type [77] = Y4089_pgtype26;
	Y4089_gen_type [78] = Y4089_pgtype27;
	Y4089_gen_type [79] = Y4089_pgtype28;
	Y4089_gen_type [80] = Y4089_pgtype29;
	Y4089_gen_type [81] = Y4089_pgtype30;
	Y4089_gen_type [82] = Y4089_pgtype31;
	Y4089_gen_type [83] = Y4089_pgtype32;
	Y4089_gen_type [84] = Y4089_pgtype33;
	Y4089_gen_type [85] = Y4089_pgtype34;
	Y4089_gen_type [86] = Y4089_pgtype35;
	Y4089_gen_type [87] = Y4089_pgtype36;
	Y4089_gen_type [88] = Y4089_pgtype37;
	Y4089_gen_type [89] = Y4089_pgtype38;
	Y4089_gen_type [90] = Y4089_pgtype39;
	Y4089_gen_type [91] = Y4089_pgtype40;
	Y4089_gen_type [92] = Y4089_pgtype41;
	Y4089_gen_type [93] = Y4089_pgtype42;
	Y4089_gen_type [94] = Y4089_pgtype43;
	Y4089_gen_type [149] = Y4089_pgtype44;
	Y4089_gen_type [150] = Y4089_pgtype45;
	Y4089_gen_type [151] = Y4089_pgtype46;
	Y4089_gen_type [152] = Y4089_pgtype47;
	Y4089_gen_type [153] = Y4089_pgtype48;
	Y4089_gen_type [154] = Y4089_pgtype49;
	Y4089_gen_type [155] = Y4089_pgtype50;
	Y4089_gen_type [156] = Y4089_pgtype51;
	Y4089_gen_type [157] = Y4089_pgtype52;
	Y4089_gen_type [158] = Y4089_pgtype53;
	Y4089_gen_type [159] = Y4089_pgtype54;
	Y4089_gen_type [160] = Y4089_pgtype55;
	Y4089_gen_type [161] = Y4089_pgtype56;
	Y4089_gen_type [162] = Y4089_pgtype57;
	Y4089_gen_type [163] = Y4089_pgtype58;
	Y4089_gen_type [164] = Y4089_pgtype59;
	Y4089_gen_type [165] = Y4089_pgtype60;
	Y4089_gen_type [166] = Y4089_pgtype61;
	Y4089_gen_type [167] = Y4089_pgtype62;
	Y4089_gen_type [168] = Y4089_pgtype63;
	Y4089_gen_type [169] = Y4089_pgtype64;
	Y4089_gen_type [170] = Y4089_pgtype65;
	Y4089_gen_type [171] = Y4089_pgtype66;
	Y4089_gen_type [172] = Y4089_pgtype67;
	Y4089_gen_type [173] = Y4089_pgtype68;
	Y4089_gen_type [174] = Y4089_pgtype69;
	Y4089_gen_type [175] = Y4089_pgtype70;
	Y4089_gen_type [176] = Y4089_pgtype71;
	Y4089_gen_type [177] = Y4089_pgtype72;
	Y4089_gen_type [178] = Y4089_pgtype73;
	Y4089_gen_type [179] = Y4089_pgtype74;
	Y4089_gen_type [180] = Y4089_pgtype75;
	Y4089_gen_type [181] = Y4089_pgtype76;
	Y4089_gen_type [182] = Y4089_pgtype77;
	Y4089_gen_type [183] = Y4089_pgtype78;
	Y4089_gen_type [184] = Y4089_pgtype79;
	Y4089_gen_type [185] = Y4089_pgtype80;
	Y4089_gen_type [186] = Y4089_pgtype81;
	Y4089_gen_type [187] = Y4089_pgtype82;
	Y4089_gen_type [188] = Y4089_pgtype83;
	Y4089_gen_type [189] = Y4089_pgtype84;
	Y4089_gen_type [190] = Y4089_pgtype85;
	Y4089_gen_type [191] = Y4089_pgtype86;
	Y4089_gen_type [192] = Y4089_pgtype87;
	Y4089_gen_type [193] = Y4089_pgtype88;
	Y4089_gen_type [194] = Y4089_pgtype89;
	Y4089_gen_type [195] = Y4089_pgtype90;
	Y4089_gen_type [196] = Y4089_pgtype91;
	Y4089_gen_type [197] = Y4089_pgtype92;
	Y4089_gen_type [198] = Y4089_pgtype93;
	Y4089_gen_type [199] = Y4089_pgtype94;
	Y4089_gen_type [200] = Y4089_pgtype95;
	Y4089_gen_type [201] = Y4089_pgtype96;
	Y4089_gen_type [202] = Y4089_pgtype97;
	Y4089_gen_type [203] = Y4089_pgtype98;
	Y4089_gen_type [204] = Y4089_pgtype99;
	Y4089_gen_type [205] = Y4089_pgtype100;
	Y4089_gen_type [207] = Y4089_pgtype101;
	Y4089_gen_type [219] = Y4089_pgtype102;
	Y4089_gen_type [220] = Y4089_pgtype103;
	Y4089_gen_type [221] = Y4089_pgtype104;
	Y4089_gen_type [222] = Y4089_pgtype105;
	Y4089_gen_type [223] = Y4089_pgtype106;
	Y4089_gen_type [224] = Y4089_pgtype107;
	Y4089_gen_type [225] = Y4089_pgtype108;
	Y4089_gen_type [226] = Y4089_pgtype109;
	Y4089_gen_type [227] = Y4089_pgtype110;
	Y4089_gen_type [228] = Y4089_pgtype111;
	Y4089_gen_type [229] = Y4089_pgtype112;
	Y4089_gen_type [230] = Y4089_pgtype113;
	Y4089_gen_type [231] = Y4089_pgtype114;
	Y4089_gen_type [232] = Y4089_pgtype115;
	Y4089_gen_type [233] = Y4089_pgtype116;
	Y4089_gen_type [234] = Y4089_pgtype117;
	Y4089_gen_type [235] = Y4089_pgtype118;
	Y4089_gen_type [236] = Y4089_pgtype119;
	Y4089_gen_type [237] = Y4089_pgtype120;
	Y4089_gen_type [238] = Y4089_pgtype121;
	Y4089_gen_type [239] = Y4089_pgtype122;
	Y4089_gen_type [626] = Y4089_pgtype123;
	Y4089_gen_type [627] = Y4089_pgtype124;
	Y4089_gen_type [628] = Y4089_pgtype125;
	Y4089_gen_type [629] = Y4089_pgtype126;
	Y4089_gen_type [630] = Y4089_pgtype127;
	Y4089_gen_type [631] = Y4089_pgtype128;
	Y4089_gen_type [632] = Y4089_pgtype129;
	Y4089_gen_type [633] = Y4089_pgtype130;
	Y4089_gen_type [634] = Y4089_pgtype131;
	Y4089_gen_type [635] = Y4089_pgtype132;
	Y4089[39] = 959;
	Y4089[231] = 23;
	Y4089[235] = 326;
	Y4089[237] = 1027;
	Y4089[240] = 959;
	{long i; for (i = 247; i < 250; i++) Y4089[i] = 989;};
	Y4089[479] = 989;
	{long i; for (i = 503; i < 506; i++) Y4089[i] = 989;};
	{long i; for (i = 507; i < 511; i++) Y4089[i] = 989;};
	Y4089[627] = 1274;
	Y4089[628] = 1133;
	Y4089[629] = 1147;
	Y4089[630] = 1148;
	Y4089[631] = 1137;
	Y4089[632] = 1141;
	Y4089[633] = 1142;
	Y4089[634] = 1135;
	Y4089[635] = 1191;
}

char *(*R4095[437])();
void R4095_init () {
	R4095[0] = (char *(*)()) F774_5284;
	R4095[1] = (char *(*)()) F775_5284;
	R4095[2] = (char *(*)()) F776_5284;
	R4095[6] = (char *(*)()) F779_5360;
	R4095[20] = (char *(*)()) F794_5582;
	R4095[21] = (char *(*)()) F795_5582;
	R4095[22] = (char *(*)()) F796_5582;
	R4095[23] = (char *(*)()) F797_5582;
	R4095[24] = (char *(*)()) F798_5582;
	R4095[25] = (char *(*)()) F799_5582;
	R4095[26] = (char *(*)()) F800_5582;
	R4095[27] = (char *(*)()) F801_5582;
	R4095[28] = (char *(*)()) F802_5582;
	R4095[29] = (char *(*)()) F803_5582;
	R4095[30] = (char *(*)()) F804_5582;
	R4095[31] = (char *(*)()) F805_5582;
	R4095[33] = (char *(*)()) F794_5582;
	R4095[34] = (char *(*)()) F797_5582;
	R4095[35] = (char *(*)()) F801_5582;
	R4095[36] = (char *(*)()) F794_5582;
	{long i; for (i = 38; i < 40; i++) R4095[i] = (char *(*)()) F794_5582;}
	{long i; for (i = 40; i < 42; i++) R4095[i] = (char *(*)()) F797_5582;}
	{long i; for (i = 427; i < 437; i++) R4095[i] = (char *(*)()) F794_5582;}
}

static EIF_TYPE_INDEX Y4095_pgtype0[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype1[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype2[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype3[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype4[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype5[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype6[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype7[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype8[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype9[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype10[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype11[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype12[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype13[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype14[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype15[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype16[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype17[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype18[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype19[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype20[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype21[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype22[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype23[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype24[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype25[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype26[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype27[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype28[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype29[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype30[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype31[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype32[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype33[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype34[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype35[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype36[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype37[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype38[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype39[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype40[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype41[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype42[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype43[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype44[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype45[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype46[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype47[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype48[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype49[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype50[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype51[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype52[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype53[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype54[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype55[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype56[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype57[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype58[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype59[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype60[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype61[] = {0xFF01,214,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype62[] = {0xFF01,217,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype63[] = {0xFF01,218,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype64[] = {0xFF01,219,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype65[] = {0xFF01,217,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype66[] = {0xFF01,219,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype67[] = {0xFF01,220,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype68[] = {0xFF01,220,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype69[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype70[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype71[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype72[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype73[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype74[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype75[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype76[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype77[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype78[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype79[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype80[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype81[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype82[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype83[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype84[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype85[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype86[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype87[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype88[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype89[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype90[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype91[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype92[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype93[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype94[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype95[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype96[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype97[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype98[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype99[] = {0xFF01,216,0xFFFF};
static EIF_TYPE_INDEX Y4095_pgtype100[] = {0xFF01,216,0xFFFF};
EIF_TYPE_INDEX *Y4095_gen_type [624];
EIF_TYPE_INDEX Y4095 [624];
void Y4095_init (void)
{
	egc_routines_types [4095] = Y4095;
	egc_routines_gen_types [4095] = Y4095_gen_type;
	egc_routines_offset [4095] = 586;
	Y4095_gen_type [0] = Y4095_pgtype0;
	Y4095_gen_type [1] = Y4095_pgtype1;
	Y4095_gen_type [2] = Y4095_pgtype2;
	Y4095_gen_type [3] = Y4095_pgtype3;
	Y4095_gen_type [4] = Y4095_pgtype4;
	Y4095_gen_type [5] = Y4095_pgtype5;
	Y4095_gen_type [6] = Y4095_pgtype6;
	Y4095_gen_type [7] = Y4095_pgtype7;
	Y4095_gen_type [8] = Y4095_pgtype8;
	Y4095_gen_type [9] = Y4095_pgtype9;
	Y4095_gen_type [10] = Y4095_pgtype10;
	Y4095_gen_type [11] = Y4095_pgtype11;
	Y4095_gen_type [137] = Y4095_pgtype12;
	Y4095_gen_type [138] = Y4095_pgtype13;
	Y4095_gen_type [139] = Y4095_pgtype14;
	Y4095_gen_type [140] = Y4095_pgtype15;
	Y4095_gen_type [141] = Y4095_pgtype16;
	Y4095_gen_type [142] = Y4095_pgtype17;
	Y4095_gen_type [143] = Y4095_pgtype18;
	Y4095_gen_type [144] = Y4095_pgtype19;
	Y4095_gen_type [145] = Y4095_pgtype20;
	Y4095_gen_type [146] = Y4095_pgtype21;
	Y4095_gen_type [147] = Y4095_pgtype22;
	Y4095_gen_type [148] = Y4095_pgtype23;
	Y4095_gen_type [149] = Y4095_pgtype24;
	Y4095_gen_type [150] = Y4095_pgtype25;
	Y4095_gen_type [151] = Y4095_pgtype26;
	Y4095_gen_type [152] = Y4095_pgtype27;
	Y4095_gen_type [153] = Y4095_pgtype28;
	Y4095_gen_type [154] = Y4095_pgtype29;
	Y4095_gen_type [155] = Y4095_pgtype30;
	Y4095_gen_type [156] = Y4095_pgtype31;
	Y4095_gen_type [157] = Y4095_pgtype32;
	Y4095_gen_type [158] = Y4095_pgtype33;
	Y4095_gen_type [159] = Y4095_pgtype34;
	Y4095_gen_type [160] = Y4095_pgtype35;
	Y4095_gen_type [161] = Y4095_pgtype36;
	Y4095_gen_type [162] = Y4095_pgtype37;
	Y4095_gen_type [163] = Y4095_pgtype38;
	Y4095_gen_type [164] = Y4095_pgtype39;
	Y4095_gen_type [165] = Y4095_pgtype40;
	Y4095_gen_type [166] = Y4095_pgtype41;
	Y4095_gen_type [167] = Y4095_pgtype42;
	Y4095_gen_type [168] = Y4095_pgtype43;
	Y4095_gen_type [169] = Y4095_pgtype44;
	Y4095_gen_type [170] = Y4095_pgtype45;
	Y4095_gen_type [171] = Y4095_pgtype46;
	Y4095_gen_type [172] = Y4095_pgtype47;
	Y4095_gen_type [173] = Y4095_pgtype48;
	Y4095_gen_type [174] = Y4095_pgtype49;
	Y4095_gen_type [175] = Y4095_pgtype50;
	Y4095_gen_type [176] = Y4095_pgtype51;
	Y4095_gen_type [177] = Y4095_pgtype52;
	Y4095_gen_type [178] = Y4095_pgtype53;
	Y4095_gen_type [179] = Y4095_pgtype54;
	Y4095_gen_type [180] = Y4095_pgtype55;
	Y4095_gen_type [181] = Y4095_pgtype56;
	Y4095_gen_type [182] = Y4095_pgtype57;
	Y4095_gen_type [183] = Y4095_pgtype58;
	Y4095_gen_type [184] = Y4095_pgtype59;
	Y4095_gen_type [185] = Y4095_pgtype60;
	Y4095_gen_type [186] = Y4095_pgtype61;
	Y4095_gen_type [187] = Y4095_pgtype62;
	Y4095_gen_type [188] = Y4095_pgtype63;
	Y4095_gen_type [189] = Y4095_pgtype64;
	Y4095_gen_type [190] = Y4095_pgtype65;
	Y4095_gen_type [191] = Y4095_pgtype66;
	Y4095_gen_type [192] = Y4095_pgtype67;
	Y4095_gen_type [193] = Y4095_pgtype68;
	Y4095_gen_type [207] = Y4095_pgtype69;
	Y4095_gen_type [208] = Y4095_pgtype70;
	Y4095_gen_type [209] = Y4095_pgtype71;
	Y4095_gen_type [210] = Y4095_pgtype72;
	Y4095_gen_type [211] = Y4095_pgtype73;
	Y4095_gen_type [212] = Y4095_pgtype74;
	Y4095_gen_type [213] = Y4095_pgtype75;
	Y4095_gen_type [214] = Y4095_pgtype76;
	Y4095_gen_type [215] = Y4095_pgtype77;
	Y4095_gen_type [216] = Y4095_pgtype78;
	Y4095_gen_type [217] = Y4095_pgtype79;
	Y4095_gen_type [218] = Y4095_pgtype80;
	Y4095_gen_type [219] = Y4095_pgtype81;
	Y4095_gen_type [220] = Y4095_pgtype82;
	Y4095_gen_type [221] = Y4095_pgtype83;
	Y4095_gen_type [222] = Y4095_pgtype84;
	Y4095_gen_type [223] = Y4095_pgtype85;
	Y4095_gen_type [224] = Y4095_pgtype86;
	Y4095_gen_type [225] = Y4095_pgtype87;
	Y4095_gen_type [226] = Y4095_pgtype88;
	Y4095_gen_type [227] = Y4095_pgtype89;
	Y4095_gen_type [228] = Y4095_pgtype90;
	Y4095_gen_type [614] = Y4095_pgtype91;
	Y4095_gen_type [615] = Y4095_pgtype92;
	Y4095_gen_type [616] = Y4095_pgtype93;
	Y4095_gen_type [617] = Y4095_pgtype94;
	Y4095_gen_type [618] = Y4095_pgtype95;
	Y4095_gen_type [619] = Y4095_pgtype96;
	Y4095_gen_type [620] = Y4095_pgtype97;
	Y4095_gen_type [621] = Y4095_pgtype98;
	Y4095_gen_type [622] = Y4095_pgtype99;
	Y4095_gen_type [623] = Y4095_pgtype100;
	{long i; for (i = 0; i < 12; i++) Y4095[i] = 214;};
	{long i; for (i = 137; i < 187; i++) Y4095[i] = 214;};
	Y4095[187] = 217;
	Y4095[188] = 218;
	Y4095[189] = 219;
	Y4095[190] = 217;
	Y4095[191] = 219;
	{long i; for (i = 192; i < 194; i++) Y4095[i] = 220;};
	{long i; for (i = 207; i < 229; i++) Y4095[i] = 216;};
	{long i; for (i = 614; i < 624; i++) Y4095[i] = 216;};
}

char *(*R4097[437])();
void R4097_init () {
	R4097[0] = (char *(*)()) F774_5303;
	R4097[1] = (char *(*)()) F775_5303;
	R4097[2] = (char *(*)()) F776_5303;
	R4097[6] = (char *(*)()) F774_5303;
	R4097[20] = (char *(*)()) F794_5607;
	R4097[21] = (char *(*)()) F795_5607;
	R4097[22] = (char *(*)()) F796_5607;
	R4097[23] = (char *(*)()) F797_5607;
	R4097[24] = (char *(*)()) F798_5607;
	R4097[25] = (char *(*)()) F799_5607;
	R4097[26] = (char *(*)()) F800_5607;
	R4097[27] = (char *(*)()) F801_5607;
	R4097[28] = (char *(*)()) F802_5607;
	R4097[29] = (char *(*)()) F803_5607;
	R4097[30] = (char *(*)()) F804_5607;
	R4097[31] = (char *(*)()) F805_5607;
	R4097[33] = (char *(*)()) F794_5607;
	R4097[34] = (char *(*)()) F797_5607;
	R4097[35] = (char *(*)()) F801_5607;
	R4097[36] = (char *(*)()) F794_5607;
	{long i; for (i = 38; i < 40; i++) R4097[i] = (char *(*)()) F794_5607;}
	{long i; for (i = 40; i < 42; i++) R4097[i] = (char *(*)()) F797_5607;}
	{long i; for (i = 427; i < 437; i++) R4097[i] = (char *(*)()) F794_5607;}
}

char *(*R4109[607])();
void R4109_init () {
	R4109[0] = (char *(*)()) F707_5172;
	R4109[1] = (char *(*)()) F708_5172;
	R4109[2] = (char *(*)()) F709_5172;
	R4109[3] = (char *(*)()) F710_5172;
	R4109[4] = (char *(*)()) F711_5172;
	R4109[5] = (char *(*)()) F712_5172;
	R4109[6] = (char *(*)()) F713_5172;
	R4109[7] = (char *(*)()) F714_5172;
	R4109[8] = (char *(*)()) F715_5172;
	R4109[9] = (char *(*)()) F716_5172;
	R4109[10] = (char *(*)()) F717_5172;
	R4109[11] = (char *(*)()) F718_5172;
	R4109[67] = (char *(*)()) F774_5287;
	R4109[68] = (char *(*)()) F775_5287;
	R4109[69] = (char *(*)()) F776_5287;
	R4109[73] = (char *(*)()) F774_5287;
	R4109[77] = (char *(*)()) F784_5458;
	R4109[78] = (char *(*)()) F785_5458;
	R4109[79] = (char *(*)()) F786_5458;
	R4109[80] = (char *(*)()) F787_5458;
	R4109[81] = (char *(*)()) F788_5458;
	R4109[82] = (char *(*)()) F789_5458;
	R4109[83] = (char *(*)()) F784_5458;
	R4109[84] = (char *(*)()) F789_5458;
	R4109[85] = (char *(*)()) F785_5458;
	R4109[86] = (char *(*)()) F784_5458;
	R4109[87] = (char *(*)()) F794_5592;
	R4109[88] = (char *(*)()) F795_5592;
	R4109[89] = (char *(*)()) F796_5592;
	R4109[90] = (char *(*)()) F797_5592;
	R4109[91] = (char *(*)()) F798_5592;
	R4109[92] = (char *(*)()) F799_5592;
	R4109[93] = (char *(*)()) F800_5592;
	R4109[94] = (char *(*)()) F801_5592;
	R4109[95] = (char *(*)()) F802_5592;
	R4109[96] = (char *(*)()) F803_5592;
	R4109[97] = (char *(*)()) F804_5592;
	R4109[98] = (char *(*)()) F805_5592;
	R4109[100] = (char *(*)()) F794_5592;
	R4109[101] = (char *(*)()) F797_5592;
	R4109[102] = (char *(*)()) F801_5592;
	R4109[103] = (char *(*)()) F794_5592;
	{long i; for (i = 105; i < 107; i++) R4109[i] = (char *(*)()) F794_5592;}
	{long i; for (i = 107; i < 109; i++) R4109[i] = (char *(*)()) F797_5592;}
	{long i; for (i = 116; i < 118; i++) R4109[i] = (char *(*)()) F822_5934;}
	R4109[331] = (char *(*)()) F1036_8242;
	R4109[335] = (char *(*)()) F1040_8407;
	R4109[347] = (char *(*)()) F1054_8644;
	{long i; for (i = 494; i < 504; i++) R4109[i] = (char *(*)()) F794_5592;}
	R4109[606] = (char *(*)()) F1313_13967;
}

EIF_TYPE_INDEX *Y4109_gen_type [700];
EIF_TYPE_INDEX Y4109 [700];
void Y4109_init (void)
{
	egc_routines_types [4109] = Y4109;
	egc_routines_gen_types [4109] = Y4109_gen_type;
	egc_routines_offset [4109] = 614;
	{long i; for (i = 0; i < 67; i++) Y4109[i] = 959;};
	{long i; for (i = 91; i < 166; i++) Y4109[i] = 959;};
	Y4109[167] = 959;
	{long i; for (i = 169; i < 201; i++) Y4109[i] = 959;};
	{long i; for (i = 207; i < 210; i++) Y4109[i] = 959;};
	{long i; for (i = 423; i < 425; i++) Y4109[i] = 959;};
	Y4109[427] = 959;
	Y4109[439] = 959;
	{long i; for (i = 463; i < 466; i++) Y4109[i] = 959;};
	{long i; for (i = 467; i < 471; i++) Y4109[i] = 959;};
	{long i; for (i = 586; i < 596; i++) Y4109[i] = 959;};
	{long i; for (i = 698; i < 700; i++) Y4109[i] = 959;};
}

char *(*R4110[607])();
void R4110_init () {
	R4110[0] = (char *(*)()) F707_5173;
	R4110[1] = (char *(*)()) F708_5173;
	R4110[2] = (char *(*)()) F709_5173;
	R4110[3] = (char *(*)()) F710_5173;
	R4110[4] = (char *(*)()) F711_5173;
	R4110[5] = (char *(*)()) F712_5173;
	R4110[6] = (char *(*)()) F713_5173;
	R4110[7] = (char *(*)()) F714_5173;
	R4110[8] = (char *(*)()) F715_5173;
	R4110[9] = (char *(*)()) F716_5173;
	R4110[10] = (char *(*)()) F717_5173;
	R4110[11] = (char *(*)()) F718_5173;
	R4110[87] = (char *(*)()) F794_5593;
	R4110[88] = (char *(*)()) F795_5593;
	R4110[89] = (char *(*)()) F796_5593;
	R4110[90] = (char *(*)()) F797_5593;
	R4110[91] = (char *(*)()) F798_5593;
	R4110[92] = (char *(*)()) F799_5593;
	R4110[93] = (char *(*)()) F800_5593;
	R4110[94] = (char *(*)()) F801_5593;
	R4110[95] = (char *(*)()) F802_5593;
	R4110[96] = (char *(*)()) F803_5593;
	R4110[97] = (char *(*)()) F804_5593;
	R4110[98] = (char *(*)()) F805_5593;
	R4110[100] = (char *(*)()) F794_5593;
	R4110[101] = (char *(*)()) F797_5593;
	R4110[102] = (char *(*)()) F801_5593;
	R4110[103] = (char *(*)()) F794_5593;
	{long i; for (i = 105; i < 107; i++) R4110[i] = (char *(*)()) F794_5593;}
	{long i; for (i = 107; i < 109; i++) R4110[i] = (char *(*)()) F797_5593;}
	R4110[331] = (char *(*)()) F1036_8241;
	R4110[335] = (char *(*)()) F1040_8406;
	{long i; for (i = 494; i < 504; i++) R4110[i] = (char *(*)()) F794_5593;}
	R4110[606] = (char *(*)()) F1313_13969;
}

char *(*R4114[607])();
void R4114_init () {
	R4114[0] = (char *(*)()) F639_5090;
	R4114[1] = (char *(*)()) F640_5090;
	R4114[2] = (char *(*)()) F641_5090;
	R4114[3] = (char *(*)()) F642_5090;
	R4114[4] = (char *(*)()) F643_5090;
	R4114[5] = (char *(*)()) F644_5090;
	R4114[6] = (char *(*)()) F645_5090;
	R4114[7] = (char *(*)()) F646_5090;
	R4114[8] = (char *(*)()) F647_5090;
	R4114[9] = (char *(*)()) F648_5090;
	R4114[10] = (char *(*)()) F649_5090;
	R4114[11] = (char *(*)()) F650_5090;
	R4114[87] = (char *(*)()) F639_5090;
	R4114[88] = (char *(*)()) F640_5090;
	R4114[89] = (char *(*)()) F641_5090;
	R4114[90] = (char *(*)()) F642_5090;
	R4114[91] = (char *(*)()) F643_5090;
	R4114[92] = (char *(*)()) F644_5090;
	R4114[93] = (char *(*)()) F645_5090;
	R4114[94] = (char *(*)()) F646_5090;
	R4114[95] = (char *(*)()) F647_5090;
	R4114[96] = (char *(*)()) F648_5090;
	R4114[97] = (char *(*)()) F649_5090;
	R4114[98] = (char *(*)()) F650_5090;
	R4114[100] = (char *(*)()) F639_5090;
	R4114[101] = (char *(*)()) F642_5090;
	R4114[102] = (char *(*)()) F646_5090;
	R4114[103] = (char *(*)()) F639_5090;
	{long i; for (i = 105; i < 107; i++) R4114[i] = (char *(*)()) F639_5090;}
	{long i; for (i = 107; i < 109; i++) R4114[i] = (char *(*)()) F642_5090;}
	R4114[331] = (char *(*)()) F645_5090;
	R4114[335] = (char *(*)()) F648_5090;
	{long i; for (i = 494; i < 504; i++) R4114[i] = (char *(*)()) F639_5090;}
	R4114[606] = (char *(*)()) F645_5090;
}


#ifdef __cplusplus
}
#endif
