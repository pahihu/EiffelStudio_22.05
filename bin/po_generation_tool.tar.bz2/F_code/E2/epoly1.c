#include "epoly1.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R11[1312])();
void R11_init () {
	{long i; for (i = 0; i < 2; i++) R11[i] = (char *(*)()) F1_8;}
	R11[3] = (char *(*)()) F1_8;
	R11[6] = (char *(*)()) F1_8;
	R11[8] = (char *(*)()) F1_8;
	{long i; for (i = 10; i < 15; i++) R11[i] = (char *(*)()) F1_8;}
	R11[19] = (char *(*)()) F1_8;
	R11[23] = (char *(*)()) F1_8;
	R11[25] = (char *(*)()) F1_8;
	R11[28] = (char *(*)()) F1_8;
	{long i; for (i = 30; i < 39; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 40; i < 45; i++) R11[i] = (char *(*)()) F1_8;}
	R11[47] = (char *(*)()) F1_8;
	{long i; for (i = 60; i < 67; i++) R11[i] = (char *(*)()) F1_8;}
	R11[79] = (char *(*)()) F1_8;
	R11[81] = (char *(*)()) F1_8;
	R11[90] = (char *(*)()) F1_8;
	R11[96] = (char *(*)()) F1_8;
	R11[98] = (char *(*)()) F1_8;
	R11[107] = (char *(*)()) F1_8;
	{long i; for (i = 111; i < 114; i++) R11[i] = (char *(*)()) F1_8;}
	R11[127] = (char *(*)()) F1_8;
	{long i; for (i = 129; i < 131; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 133; i < 145; i++) R11[i] = (char *(*)()) F1_8;}
	R11[153] = (char *(*)()) F1_8;
	R11[160] = (char *(*)()) F1_8;
	{long i; for (i = 162; i < 164; i++) R11[i] = (char *(*)()) F1_8;}
	R11[172] = (char *(*)()) F1_8;
	{long i; for (i = 181; i < 183; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 184; i < 189; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 191; i < 195; i++) R11[i] = (char *(*)()) F1_8;}
	R11[201] = (char *(*)()) F1_8;
	R11[203] = (char *(*)()) F1_8;
	R11[210] = (char *(*)()) F1_8;
	{long i; for (i = 215; i < 220; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 221; i < 225; i++) R11[i] = (char *(*)()) F1_8;}
	R11[227] = (char *(*)()) F1_8;
	{long i; for (i = 229; i < 232; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 233; i < 236; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 237; i < 239; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 241; i < 243; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 244; i < 247; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 248; i < 252; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 253; i < 255; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 256; i < 262; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 263; i < 267; i++) R11[i] = (char *(*)()) F1_8;}
	R11[268] = (char *(*)()) F1_8;
	R11[270] = (char *(*)()) F272_3590;
	R11[278] = (char *(*)()) F279_3810;
	R11[286] = (char *(*)()) F1_8;
	R11[306] = (char *(*)()) F308_4119;
	R11[307] = (char *(*)()) F309_4168;
	{long i; for (i = 310; i < 312; i++) R11[i] = (char *(*)()) F1_8;}
	R11[313] = (char *(*)()) F1_8;
	{long i; for (i = 318; i < 320; i++) R11[i] = (char *(*)()) F1_8;}
	R11[322] = (char *(*)()) F1_8;
	R11[324] = (char *(*)()) F1_8;
	R11[325] = (char *(*)()) F327_4761;
	R11[326] = (char *(*)()) F1_8;
	{long i; for (i = 341; i < 345; i++) R11[i] = (char *(*)()) F1_8;}
	R11[364] = (char *(*)()) F1_8;
	{long i; for (i = 395; i < 417; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 429; i < 467; i++) R11[i] = (char *(*)()) F1_8;}
	R11[612] = (char *(*)()) F1_8;
	R11[705] = (char *(*)()) F707_5175;
	R11[706] = (char *(*)()) F708_5175;
	R11[707] = (char *(*)()) F709_5175;
	R11[708] = (char *(*)()) F710_5175;
	R11[709] = (char *(*)()) F711_5175;
	R11[710] = (char *(*)()) F712_5175;
	R11[711] = (char *(*)()) F713_5175;
	R11[712] = (char *(*)()) F714_5175;
	R11[713] = (char *(*)()) F715_5175;
	R11[714] = (char *(*)()) F716_5175;
	R11[715] = (char *(*)()) F717_5175;
	R11[716] = (char *(*)()) F718_5175;
	R11[772] = (char *(*)()) F748_5257;
	R11[773] = (char *(*)()) F751_5257;
	R11[774] = (char *(*)()) F755_5257;
	R11[778] = (char *(*)()) F748_5257;
	R11[782] = (char *(*)()) F784_5463;
	R11[783] = (char *(*)()) F785_5463;
	R11[784] = (char *(*)()) F786_5463;
	R11[785] = (char *(*)()) F787_5463;
	R11[786] = (char *(*)()) F788_5463;
	R11[787] = (char *(*)()) F789_5463;
	R11[788] = (char *(*)()) F790_5557;
	R11[789] = (char *(*)()) F791_5557;
	R11[790] = (char *(*)()) F792_5557;
	R11[791] = (char *(*)()) F784_5463;
	R11[792] = (char *(*)()) F794_5595;
	R11[793] = (char *(*)()) F795_5595;
	R11[794] = (char *(*)()) F796_5595;
	R11[795] = (char *(*)()) F797_5595;
	R11[796] = (char *(*)()) F798_5595;
	R11[797] = (char *(*)()) F799_5595;
	R11[798] = (char *(*)()) F800_5595;
	R11[799] = (char *(*)()) F801_5595;
	R11[800] = (char *(*)()) F802_5595;
	R11[801] = (char *(*)()) F803_5595;
	R11[802] = (char *(*)()) F804_5595;
	R11[803] = (char *(*)()) F805_5595;
	R11[805] = (char *(*)()) F794_5595;
	R11[806] = (char *(*)()) F797_5595;
	R11[807] = (char *(*)()) F801_5595;
	R11[808] = (char *(*)()) F810_5653;
	{long i; for (i = 810; i < 812; i++) R11[i] = (char *(*)()) F794_5595;}
	{long i; for (i = 812; i < 814; i++) R11[i] = (char *(*)()) F797_5595;}
	{long i; for (i = 816; i < 819; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 821; i < 823; i++) R11[i] = (char *(*)()) F1_8;}
	R11[830] = (char *(*)()) F1_8;
	{long i; for (i = 838; i < 850; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 900; i < 908; i++) R11[i] = (char *(*)()) F1_8;}
	R11[918] = (char *(*)()) F920_6800;
	R11[919] = (char *(*)()) F921_6837;
	R11[920] = (char *(*)()) F922_6837;
	R11[921] = (char *(*)()) F923_6837;
	R11[922] = (char *(*)()) F924_6837;
	R11[923] = (char *(*)()) F925_6837;
	R11[924] = (char *(*)()) F926_6837;
	R11[925] = (char *(*)()) F927_6837;
	R11[926] = (char *(*)()) F928_6837;
	R11[927] = (char *(*)()) F929_6837;
	R11[928] = (char *(*)()) F930_6837;
	R11[929] = (char *(*)()) F931_6837;
	R11[930] = (char *(*)()) F932_6837;
	R11[931] = (char *(*)()) F933_6837;
	R11[932] = (char *(*)()) F934_6837;
	R11[933] = (char *(*)()) F935_6837;
	R11[934] = (char *(*)()) F936_6837;
	R11[935] = (char *(*)()) F937_6837;
	R11[936] = (char *(*)()) F938_6837;
	R11[937] = (char *(*)()) F939_6837;
	R11[938] = (char *(*)()) F940_6837;
	R11[939] = (char *(*)()) F941_6837;
	R11[940] = (char *(*)()) F942_6837;
	R11[941] = (char *(*)()) F943_6837;
	R11[942] = (char *(*)()) F944_6837;
	R11[943] = (char *(*)()) F945_6837;
	R11[944] = (char *(*)()) F946_6837;
	R11[945] = (char *(*)()) F947_6837;
	R11[946] = (char *(*)()) F948_6837;
	R11[947] = (char *(*)()) F949_6837;
	R11[948] = (char *(*)()) F950_6837;
	R11[949] = (char *(*)()) F951_6837;
	R11[950] = (char *(*)()) F952_6837;
	R11[951] = (char *(*)()) F953_6837;
	R11[952] = (char *(*)()) F954_6880;
	{long i; for (i = 954; i < 956; i++) R11[i] = (char *(*)()) F955_6998;}
	{long i; for (i = 957; i < 959; i++) R11[i] = (char *(*)()) F958_7096;}
	{long i; for (i = 960; i < 962; i++) R11[i] = (char *(*)()) F961_7195;}
	{long i; for (i = 963; i < 965; i++) R11[i] = (char *(*)()) F964_7294;}
	{long i; for (i = 966; i < 968; i++) R11[i] = (char *(*)()) F967_7393;}
	{long i; for (i = 969; i < 971; i++) R11[i] = (char *(*)()) F970_7487;}
	{long i; for (i = 972; i < 974; i++) R11[i] = (char *(*)()) F973_7581;}
	{long i; for (i = 975; i < 977; i++) R11[i] = (char *(*)()) F976_7676;}
	{long i; for (i = 978; i < 980; i++) R11[i] = (char *(*)()) F979_7775;}
	{long i; for (i = 981; i < 983; i++) R11[i] = (char *(*)()) F982_7841;}
	{long i; for (i = 984; i < 986; i++) R11[i] = (char *(*)()) F985_7902;}
	{long i; for (i = 987; i < 989; i++) R11[i] = (char *(*)()) F988_7942;}
	{long i; for (i = 990; i < 992; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 993; i < 1025; i++) R11[i] = (char *(*)()) F994_8008;}
	R11[1026] = (char *(*)()) F1027_8045;
	R11[1027] = (char *(*)()) F1029_8083;
	R11[1028] = (char *(*)()) F1030_8083;
	R11[1029] = (char *(*)()) F1031_8083;
	R11[1030] = (char *(*)()) F1030_8083;
	{long i; for (i = 1035; i < 1037; i++) R11[i] = (char *(*)()) F1036_8245;}
	{long i; for (i = 1039; i < 1041; i++) R11[i] = (char *(*)()) F1040_8410;}
	R11[1041] = (char *(*)()) F1043_8555;
	R11[1042] = (char *(*)()) F1044_8566;
	R11[1043] = (char *(*)()) F1_8;
	R11[1044] = (char *(*)()) F1046_8592;
	R11[1045] = (char *(*)()) F1047_8592;
	R11[1046] = (char *(*)()) F1048_8592;
	{long i; for (i = 1047; i < 1053; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1061] = (char *(*)()) F1_8;
	{long i; for (i = 1069; i < 1072; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1085; i < 1087; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1088] = (char *(*)()) F1_8;
	R11[1105] = (char *(*)()) F1_8;
	{long i; for (i = 1108; i < 1115; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1116] = (char *(*)()) F1_8;
	R11[1118] = (char *(*)()) F1_8;
	R11[1125] = (char *(*)()) F1_8;
	{long i; for (i = 1127; i < 1148; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1149; i < 1153; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1154; i < 1156; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1157; i < 1159; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1161] = (char *(*)()) F1_8;
	{long i; for (i = 1163; i < 1167; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1168; i < 1170; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1171; i < 1173; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1174; i < 1177; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1178; i < 1182; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1183; i < 1188; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1189] = (char *(*)()) F1_8;
	{long i; for (i = 1191; i < 1199; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1199; i < 1209; i++) R11[i] = (char *(*)()) F794_5595;}
	{long i; for (i = 1210; i < 1217; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1218; i < 1231; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1232; i < 1239; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1240; i < 1257; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1258; i < 1260; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1261; i < 1266; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1267; i < 1273; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1273; i < 1275; i++) R11[i] = (char *(*)()) F1275_13569;}
	{long i; for (i = 1275; i < 1279; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1280; i < 1291; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1292; i < 1296; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1297; i < 1306; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1306; i < 1308; i++) R11[i] = (char *(*)()) F1308_13847;}
	R11[1308] = (char *(*)()) F1_8;
	R11[1311] = (char *(*)()) F1313_13977;
}

char *(*R28[1312])();
void R28_init () {
	{long i; for (i = 0; i < 2; i++) R28[i] = (char *(*)()) F1_25;}
	R28[3] = (char *(*)()) F1_25;
	R28[6] = (char *(*)()) F1_25;
	R28[8] = (char *(*)()) F1_25;
	{long i; for (i = 10; i < 15; i++) R28[i] = (char *(*)()) F1_25;}
	R28[19] = (char *(*)()) F1_25;
	R28[23] = (char *(*)()) F1_25;
	R28[25] = (char *(*)()) F1_25;
	R28[28] = (char *(*)()) F1_25;
	{long i; for (i = 30; i < 39; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 40; i < 45; i++) R28[i] = (char *(*)()) F1_25;}
	R28[47] = (char *(*)()) F1_25;
	{long i; for (i = 60; i < 67; i++) R28[i] = (char *(*)()) F1_25;}
	R28[79] = (char *(*)()) F1_25;
	R28[81] = (char *(*)()) F1_25;
	R28[90] = (char *(*)()) F1_25;
	R28[96] = (char *(*)()) F1_25;
	R28[98] = (char *(*)()) F1_25;
	R28[107] = (char *(*)()) F1_25;
	{long i; for (i = 111; i < 114; i++) R28[i] = (char *(*)()) F1_25;}
	R28[127] = (char *(*)()) F1_25;
	{long i; for (i = 129; i < 131; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 133; i < 145; i++) R28[i] = (char *(*)()) F1_25;}
	R28[153] = (char *(*)()) F1_25;
	R28[160] = (char *(*)()) F1_25;
	{long i; for (i = 162; i < 164; i++) R28[i] = (char *(*)()) F1_25;}
	R28[172] = (char *(*)()) F1_25;
	{long i; for (i = 181; i < 183; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 184; i < 189; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 191; i < 195; i++) R28[i] = (char *(*)()) F1_25;}
	R28[201] = (char *(*)()) F1_25;
	R28[203] = (char *(*)()) F1_25;
	R28[210] = (char *(*)()) F1_25;
	{long i; for (i = 215; i < 220; i++) R28[i] = (char *(*)()) F1_25;}
	R28[221] = (char *(*)()) F1_25;
	{long i; for (i = 222; i < 225; i++) R28[i] = (char *(*)()) F224_3442;}
	R28[227] = (char *(*)()) F224_3442;
	{long i; for (i = 229; i < 232; i++) R28[i] = (char *(*)()) F224_3442;}
	{long i; for (i = 233; i < 236; i++) R28[i] = (char *(*)()) F224_3442;}
	{long i; for (i = 237; i < 239; i++) R28[i] = (char *(*)()) F224_3442;}
	{long i; for (i = 241; i < 243; i++) R28[i] = (char *(*)()) F224_3442;}
	{long i; for (i = 244; i < 247; i++) R28[i] = (char *(*)()) F224_3442;}
	{long i; for (i = 248; i < 252; i++) R28[i] = (char *(*)()) F224_3442;}
	{long i; for (i = 253; i < 255; i++) R28[i] = (char *(*)()) F224_3442;}
	{long i; for (i = 256; i < 262; i++) R28[i] = (char *(*)()) F224_3442;}
	{long i; for (i = 263; i < 267; i++) R28[i] = (char *(*)()) F1_25;}
	R28[268] = (char *(*)()) F1_25;
	R28[270] = (char *(*)()) F1_25;
	R28[278] = (char *(*)()) F1_25;
	R28[286] = (char *(*)()) F1_25;
	{long i; for (i = 306; i < 308; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 310; i < 312; i++) R28[i] = (char *(*)()) F1_25;}
	R28[313] = (char *(*)()) F1_25;
	R28[318] = (char *(*)()) F320_4385;
	R28[319] = (char *(*)()) F1_25;
	R28[322] = (char *(*)()) F1_25;
	{long i; for (i = 324; i < 327; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 341; i < 345; i++) R28[i] = (char *(*)()) F1_25;}
	R28[364] = (char *(*)()) F1_25;
	{long i; for (i = 395; i < 417; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 429; i < 467; i++) R28[i] = (char *(*)()) F1_25;}
	R28[612] = (char *(*)()) F1_25;
	{long i; for (i = 705; i < 717; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 772; i < 775; i++) R28[i] = (char *(*)()) F1_25;}
	R28[778] = (char *(*)()) F1_25;
	{long i; for (i = 782; i < 791; i++) R28[i] = (char *(*)()) F1_25;}
	R28[791] = (char *(*)()) F793_5566;
	{long i; for (i = 792; i < 804; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 805; i < 809; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 810; i < 814; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 816; i < 819; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 821; i < 823; i++) R28[i] = (char *(*)()) F1_25;}
	R28[830] = (char *(*)()) F1_25;
	{long i; for (i = 838; i < 850; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 900; i < 908; i++) R28[i] = (char *(*)()) F1_25;}
	R28[918] = (char *(*)()) F920_6804;
	R28[919] = (char *(*)()) F921_6845;
	R28[920] = (char *(*)()) F922_6845;
	R28[921] = (char *(*)()) F923_6845;
	R28[922] = (char *(*)()) F924_6845;
	R28[923] = (char *(*)()) F925_6845;
	R28[924] = (char *(*)()) F926_6845;
	R28[925] = (char *(*)()) F927_6845;
	R28[926] = (char *(*)()) F928_6845;
	R28[927] = (char *(*)()) F929_6845;
	R28[928] = (char *(*)()) F930_6845;
	R28[929] = (char *(*)()) F931_6845;
	R28[930] = (char *(*)()) F932_6845;
	R28[931] = (char *(*)()) F933_6845;
	R28[932] = (char *(*)()) F934_6845;
	R28[933] = (char *(*)()) F935_6845;
	R28[934] = (char *(*)()) F936_6845;
	R28[935] = (char *(*)()) F937_6845;
	R28[936] = (char *(*)()) F938_6845;
	R28[937] = (char *(*)()) F939_6845;
	R28[938] = (char *(*)()) F940_6845;
	R28[939] = (char *(*)()) F941_6845;
	R28[940] = (char *(*)()) F942_6845;
	R28[941] = (char *(*)()) F943_6845;
	R28[942] = (char *(*)()) F944_6845;
	R28[943] = (char *(*)()) F945_6845;
	R28[944] = (char *(*)()) F946_6845;
	R28[945] = (char *(*)()) F947_6845;
	R28[946] = (char *(*)()) F948_6845;
	R28[947] = (char *(*)()) F949_6845;
	R28[948] = (char *(*)()) F950_6845;
	R28[949] = (char *(*)()) F951_6845;
	R28[950] = (char *(*)()) F952_6845;
	R28[951] = (char *(*)()) F953_6845;
	R28[952] = (char *(*)()) F1_25;
	{long i; for (i = 954; i < 956; i++) R28[i] = (char *(*)()) F955_7057;}
	{long i; for (i = 957; i < 959; i++) R28[i] = (char *(*)()) F958_7156;}
	{long i; for (i = 960; i < 962; i++) R28[i] = (char *(*)()) F961_7255;}
	{long i; for (i = 963; i < 965; i++) R28[i] = (char *(*)()) F964_7354;}
	{long i; for (i = 966; i < 968; i++) R28[i] = (char *(*)()) F967_7450;}
	{long i; for (i = 969; i < 971; i++) R28[i] = (char *(*)()) F970_7544;}
	{long i; for (i = 972; i < 974; i++) R28[i] = (char *(*)()) F973_7639;}
	{long i; for (i = 975; i < 977; i++) R28[i] = (char *(*)()) F976_7734;}
	R28[978] = (char *(*)()) F980_7827;
	R28[979] = (char *(*)()) F981_7827;
	R28[981] = (char *(*)()) F983_7893;
	R28[982] = (char *(*)()) F984_7893;
	{long i; for (i = 984; i < 986; i++) R28[i] = (char *(*)()) F985_7909;}
	{long i; for (i = 987; i < 989; i++) R28[i] = (char *(*)()) F988_7949;}
	{long i; for (i = 990; i < 992; i++) R28[i] = (char *(*)()) F991_7997;}
	{long i; for (i = 993; i < 1023; i++) R28[i] = (char *(*)()) F994_8023;}
	R28[1023] = (char *(*)()) F1025_8036;
	R28[1024] = (char *(*)()) F1026_8036;
	{long i; for (i = 1026; i < 1031; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1035; i < 1037; i++) R28[i] = (char *(*)()) F1036_8265;}
	{long i; for (i = 1039; i < 1041; i++) R28[i] = (char *(*)()) F1040_8430;}
	{long i; for (i = 1041; i < 1053; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1061] = (char *(*)()) F1_25;
	{long i; for (i = 1069; i < 1072; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1085; i < 1087; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1088] = (char *(*)()) F1_25;
	R28[1105] = (char *(*)()) F1_25;
	{long i; for (i = 1108; i < 1115; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1116] = (char *(*)()) F1_25;
	R28[1118] = (char *(*)()) F1_25;
	R28[1125] = (char *(*)()) F1_25;
	{long i; for (i = 1127; i < 1148; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1149; i < 1153; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1154; i < 1156; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1157; i < 1159; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1161] = (char *(*)()) F1_25;
	{long i; for (i = 1163; i < 1167; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1168; i < 1170; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1171; i < 1173; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1174; i < 1177; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1178; i < 1182; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1183; i < 1188; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1189] = (char *(*)()) F1_25;
	{long i; for (i = 1191; i < 1209; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1210; i < 1217; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1218; i < 1231; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1232; i < 1239; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1240; i < 1257; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1258; i < 1260; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1261; i < 1266; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1267; i < 1279; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1280; i < 1291; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1292; i < 1296; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1297; i < 1309; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1311] = (char *(*)()) F1313_14022;
}

char *(*R499[5])();
void R499_init () {
	R499[0] = (char *(*)()) F36_496;
	R499[1] = (char *(*)()) F37_496;
	R499[2] = (char *(*)()) F38_496;
	R499[3] = (char *(*)()) F39_496;
	R499[4] = (char *(*)()) F40_496;
}

char *(*R504[5])();
void R504_init () {
	R504[0] = (char *(*)()) F36_501;
	R504[1] = (char *(*)()) F37_501_504_47;
	R504[2] = (char *(*)()) F38_501_504_47;
	R504[3] = (char *(*)()) F39_501_504_47;
	R504[4] = (char *(*)()) F40_501_504_47;
}
static void F37_501_504_47 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F37_501(Current, arg1, *(EIF_CHARACTER_8 *)arg2, arg3);
}
static void F38_501_504_47 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F38_501(Current, arg1, *(EIF_BOOLEAN *)arg2, arg3);
}
static void F39_501_504_47 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F39_501(Current, arg1, *(EIF_NATURAL_32 *)arg2, arg3);
}
static void F40_501_504_47 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F40_501(Current, arg1, *(EIF_INTEGER_32 *)arg2, arg3);
}

char *(*R507[5])();
void R507_init () {
	R507[0] = (char *(*)()) F36_504;
	R507[1] = (char *(*)()) F37_504;
	R507[2] = (char *(*)()) F38_504;
	R507[3] = (char *(*)()) F39_504;
	R507[4] = (char *(*)()) F40_504;
}

char *(*R1017[482])();
void R1017_init () {
	R1017[0] = (char *(*)()) F832_6278;
	R1017[481] = (char *(*)()) F1313_13992;
}

char *(*R1500[2])();
void R1500_init () {
	R1500[0] = (char *(*)()) F818_5728_1500_21;
	R1500[1] = (char *(*)()) F819_5747_1500_21;
}
static EIF_REFERENCE F818_5728_1500_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F818_5728(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(989, 0x00).id, 989, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F819_5747_1500_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F819_5747(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(989, 0x00).id, 989, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R1501[2])();
void R1501_init () {
	R1501[0] = (char *(*)()) F818_5732;
	R1501[1] = (char *(*)()) F819_5755;
}

char *(*R1502[2])();
void R1502_init () {
	R1502[0] = (char *(*)()) F818_5734_1502_136;
	R1502[1] = (char *(*)()) F819_5759_1502_136;
}
static void F818_5734_1502_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F818_5734(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F819_5759_1502_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F819_5759(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}

char *(*R1510[2])();
void R1510_init () {
	R1510[0] = (char *(*)()) F120_1524;
	R1510[1] = (char *(*)()) F819_5748;
}

char *(*R1511[2])();
void R1511_init () {
	R1511[0] = (char *(*)()) F120_1525;
	R1511[1] = (char *(*)()) F819_5749;
}

char *(*R1512[2])();
void R1512_init () {
	R1512[0] = (char *(*)()) F818_5729;
	R1512[1] = (char *(*)()) F819_5750;
}

char *(*R1513[2])();
void R1513_init () {
	R1513[0] = (char *(*)()) F818_5730;
	R1513[1] = (char *(*)()) F819_5751;
}

char *(*R1514[2])();
void R1514_init () {
	R1514[0] = (char *(*)()) F818_5731;
	R1514[1] = (char *(*)()) F819_5752;
}

char *(*R1517[2])();
void R1517_init () {
	R1517[0] = (char *(*)()) F818_5733;
	R1517[1] = (char *(*)()) F120_1531;
}

char *(*R1518[2])();
void R1518_init () {
	R1518[0] = (char *(*)()) F120_1532;
	R1518[1] = (char *(*)()) F819_5756;
}

char *(*R1521[2])();
void R1521_init () {
	R1521[0] = (char *(*)()) F818_5737;
	R1521[1] = (char *(*)()) F819_5763;
}

char *(*R1523[2])();
void R1523_init () {
	R1523[0] = (char *(*)()) F818_5738;
	R1523[1] = (char *(*)()) F819_5766;
}

char *(*R1966[9])();
void R1966_init () {
	R1966[0] = (char *(*)()) F137_1993;
	R1966[1] = (char *(*)()) F138_1993_1966_1;
	R1966[2] = (char *(*)()) F139_1993_1966_1;
	R1966[3] = (char *(*)()) F140_1993_1966_1;
	R1966[4] = (char *(*)()) F141_1993_1966_1;
	R1966[5] = (char *(*)()) F137_1993;
	R1966[6] = (char *(*)()) F138_1993_1966_1;
	R1966[7] = (char *(*)()) F141_1993_1966_1;
	R1966[8] = (char *(*)()) F137_1993;
}
static EIF_REFERENCE F138_1993_1966_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F138_1993(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F139_1993_1966_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F139_1993(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(968, 0x00).id, 968, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F140_1993_1966_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F140_1993(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(986, 0x00).id, 986, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F141_1993_1966_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F141_1993(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}

char *(*R1967[9])();
void R1967_init () {
	R1967[0] = (char *(*)()) F137_1994;
	R1967[1] = (char *(*)()) F138_1994_1967_4;
	R1967[2] = (char *(*)()) F139_1994_1967_4;
	R1967[3] = (char *(*)()) F140_1994_1967_4;
	R1967[4] = (char *(*)()) F141_1994_1967_4;
	R1967[5] = (char *(*)()) F137_1994;
	R1967[6] = (char *(*)()) F138_1994_1967_4;
	R1967[7] = (char *(*)()) F141_1994_1967_4;
	R1967[8] = (char *(*)()) F137_1994;
}
static void F138_1994_1967_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F138_1994(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F139_1994_1967_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F139_1994(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F140_1994_1967_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F140_1994(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F141_1994_1967_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F141_1994(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R1971[4])();
void R1971_init () {
	R1971[0] = (char *(*)()) F142_1997;
	R1971[1] = (char *(*)()) F143_1997;
	R1971[2] = (char *(*)()) F144_1997;
	R1971[3] = (char *(*)()) F145_2000;
}

char *(*R2147[2])();
void R2147_init () {
	R2147[0] = (char *(*)()) F164_2212;
	R2147[1] = (char *(*)()) F165_2223;
}

char *(*R2154[2])();
void R2154_init () {
	R2154[0] = (char *(*)()) F164_2216;
	R2154[1] = (char *(*)()) F165_2225;
}

char *(*R2155[2])();
void R2155_init () {
	R2155[0] = (char *(*)()) F164_2217;
	R2155[1] = (char *(*)()) F165_2226;
}

char *(*R2182[10])();
void R2182_init () {
	{long i; for (i = 0; i < 4; i++) R2182[i] = (char *(*)()) F170_2241;}
	{long i; for (i = 5; i < 10; i++) R2182[i] = (char *(*)()) F170_2241;}
}

char *(*R2262[2])();
void R2262_init () {
	R2262[0] = (char *(*)()) F183_2333;
	R2262[1] = (char *(*)()) F184_2337;
}

char *(*R2264[2])();
void R2264_init () {
	R2264[0] = (char *(*)()) F183_2334;
	R2264[1] = (char *(*)()) F184_2338;
}

char *(*R2283[3])();
void R2283_init () {
	R2283[0] = (char *(*)()) F186_2369;
	R2283[1] = (char *(*)()) F187_2375;
	R2283[2] = (char *(*)()) F188_2383;
}

char *(*R2347[2])();
void R2347_init () {
	R2347[0] = (char *(*)()) F193_2461;
	R2347[1] = (char *(*)()) F194_2485;
}

char *(*R2349[2])();
void R2349_init () {
	R2349[0] = (char *(*)()) F193_2457;
	R2349[1] = (char *(*)()) F194_2486;
}

char *(*R2355[2])();
void R2355_init () {
	R2355[0] = (char *(*)()) F193_2466;
	R2355[1] = (char *(*)()) F194_2488;
}

char *(*R2506[3])();
void R2506_init () {
	R2506[0] = (char *(*)()) F203_2640;
	R2506[2] = (char *(*)()) F205_2652;
}

char *(*R2539[876])();
void R2539_init () {
	R2539[0] = (char *(*)()) F211_3016;
	R2539[875] = (char *(*)()) F213_3226;
}

char *(*R2540[876])();
void R2540_init () {
	R2540[0] = (char *(*)()) F211_3017;
	R2540[875] = (char *(*)()) F213_3227;
}

char *(*R2541[876])();
void R2541_init () {
	R2541[0] = (char *(*)()) F211_3018;
	R2541[875] = (char *(*)()) F1087_9262;
}

char *(*R2542[876])();
void R2542_init () {
	R2542[0] = (char *(*)()) F211_3019;
	R2542[875] = (char *(*)()) F213_3229;
}

char *(*R2543[876])();
void R2543_init () {
	R2543[0] = (char *(*)()) F211_3020;
	R2543[875] = (char *(*)()) F213_3207;
}

char *(*R2544[876])();
void R2544_init () {
	R2544[0] = (char *(*)()) F211_3021;
	R2544[875] = (char *(*)()) F213_3208;
}

char *(*R2545[876])();
void R2545_init () {
	R2545[0] = (char *(*)()) F211_3022;
	R2545[875] = (char *(*)()) F213_3209;
}

char *(*R2546[876])();
void R2546_init () {
	R2546[0] = (char *(*)()) F211_3023;
	R2546[875] = (char *(*)()) F213_3210;
}


#ifdef __cplusplus
}
#endif
