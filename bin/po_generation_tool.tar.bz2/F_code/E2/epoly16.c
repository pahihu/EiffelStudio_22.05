#include "epoly16.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

static EIF_TYPE_INDEX Y3664_pgtype0[] = {0xFF01,0xFFF9,5,953,1212,1274,959,959,0xFFF5,1,0xFF01,1103,7193,0xFFFF};
static EIF_TYPE_INDEX Y3664_pgtype1[] = {0xFF01,0xFFF9,5,953,1212,1274,959,959,0xFFF5,1,0xFF01,1103,7193,0xFFFF};
static EIF_TYPE_INDEX Y3664_pgtype2[] = {0xFF01,0xFFF9,5,953,1212,1274,959,959,0xFFF5,1,0xFF01,1103,7193,0xFFFF};
EIF_TYPE_INDEX *Y3664_gen_type [3];
EIF_TYPE_INDEX Y3664 [3];
void Y3664_init (void)
{
	egc_routines_types [3664] = Y3664;
	egc_routines_gen_types [3664] = Y3664_gen_type;
	egc_routines_offset [3664] = 321;
	Y3664_gen_type [0] = Y3664_pgtype0;
	Y3664_gen_type [1] = Y3664_pgtype1;
	Y3664_gen_type [2] = Y3664_pgtype2;
	{long i; for (i = 0; i < 3; i++) Y3664[i] = 953;};
}

char *(*R3930[272])();
void R3930_init () {
	R3930[0] = (char *(*)()) F343_4798;
	R3930[1] = (char *(*)()) F344_4798_3930_1;
	R3930[2] = (char *(*)()) F345_4798_3930_1;
	R3930[3] = (char *(*)()) F346_4806_3930_1;
	R3930[54] = (char *(*)()) F385_4863;
	R3930[55] = (char *(*)()) F386_4863_3930_1;
	R3930[56] = (char *(*)()) F387_4863_3930_1;
	R3930[57] = (char *(*)()) F388_4863_3930_1;
	R3930[58] = (char *(*)()) F389_4863_3930_1;
	R3930[59] = (char *(*)()) F390_4863_3930_1;
	R3930[60] = (char *(*)()) F391_4863_3930_1;
	R3930[61] = (char *(*)()) F392_4863_3930_1;
	R3930[62] = (char *(*)()) F393_4863_3930_1;
	R3930[63] = (char *(*)()) F394_4863_3930_1;
	R3930[64] = (char *(*)()) F395_4863_3930_1;
	R3930[65] = (char *(*)()) F396_4863_3930_1;
	R3930[66] = (char *(*)()) F409_4891;
	R3930[67] = (char *(*)()) F410_4891_3930_1;
	R3930[68] = (char *(*)()) F411_4891_3930_1;
	R3930[69] = (char *(*)()) F412_4891;
	R3930[70] = (char *(*)()) F413_4891_3930_1;
	R3930[71] = (char *(*)()) F414_4891_3930_1;
	R3930[72] = (char *(*)()) F415_4897;
	R3930[73] = (char *(*)()) F416_4897_3930_1;
	R3930[74] = (char *(*)()) F417_4897_3930_1;
	R3930[75] = (char *(*)()) F418_4903;
	R3930[88] = (char *(*)()) F425_4909_3930_1;
	R3930[89] = (char *(*)()) F419_4909;
	R3930[90] = (char *(*)()) F420_4909_3930_1;
	R3930[91] = (char *(*)()) F421_4909_3930_1;
	R3930[92] = (char *(*)()) F422_4909_3930_1;
	R3930[93] = (char *(*)()) F423_4909_3930_1;
	R3930[94] = (char *(*)()) F424_4909_3930_1;
	R3930[95] = (char *(*)()) F425_4909_3930_1;
	R3930[96] = (char *(*)()) F426_4909_3930_1;
	R3930[97] = (char *(*)()) F427_4909_3930_1;
	R3930[98] = (char *(*)()) F428_4909_3930_1;
	R3930[99] = (char *(*)()) F429_4909_3930_1;
	R3930[100] = (char *(*)()) F430_4909_3930_1;
	R3930[101] = (char *(*)()) F428_4909_3930_1;
	R3930[102] = (char *(*)()) F419_4909;
	R3930[103] = (char *(*)()) F420_4909_3930_1;
	R3930[104] = (char *(*)()) F421_4909_3930_1;
	R3930[105] = (char *(*)()) F422_4909_3930_1;
	R3930[106] = (char *(*)()) F423_4909_3930_1;
	R3930[107] = (char *(*)()) F424_4909_3930_1;
	R3930[108] = (char *(*)()) F425_4909_3930_1;
	R3930[109] = (char *(*)()) F426_4909_3930_1;
	R3930[110] = (char *(*)()) F427_4909_3930_1;
	R3930[111] = (char *(*)()) F428_4909_3930_1;
	R3930[112] = (char *(*)()) F429_4909_3930_1;
	R3930[113] = (char *(*)()) F430_4909_3930_1;
	R3930[114] = (char *(*)()) F419_4909;
	R3930[115] = (char *(*)()) F420_4909_3930_1;
	R3930[116] = (char *(*)()) F421_4909_3930_1;
	R3930[117] = (char *(*)()) F422_4909_3930_1;
	R3930[118] = (char *(*)()) F423_4909_3930_1;
	R3930[119] = (char *(*)()) F424_4909_3930_1;
	R3930[120] = (char *(*)()) F425_4909_3930_1;
	R3930[121] = (char *(*)()) F426_4909_3930_1;
	R3930[122] = (char *(*)()) F427_4909_3930_1;
	R3930[123] = (char *(*)()) F428_4909_3930_1;
	R3930[124] = (char *(*)()) F429_4909_3930_1;
	R3930[125] = (char *(*)()) F430_4909_3930_1;
	R3930[271] = (char *(*)()) F613_5055_3930_1;
}
static EIF_REFERENCE F344_4798_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F344_4798(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(986, 0x00).id, 986, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F345_4798_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F345_4798(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F346_4806_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F346_4806(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(989, 0x00).id, 989, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F386_4863_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F386_4863(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(977, 0x00).id, 977, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F387_4863_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F387_4863(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(968, 0x00).id, 968, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F388_4863_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F388_4863(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F389_4863_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F389_4863(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(989, 0x00).id, 989, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F390_4863_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F390_4863(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(986, 0x00).id, 986, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F391_4863_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F391_4863(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(974, 0x00).id, 974, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F392_4863_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F392_4863(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1025, 0x00).id, 1025, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F393_4863_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F393_4863(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F394_4863_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F394_4863(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(971, 0x00).id, 971, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F395_4863_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F395_4863(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(980, 0x00).id, 980, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F396_4863_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F396_4863(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(983, 0x00).id, 983, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F410_4891_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F410_4891(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F411_4891_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F411_4891(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1025, 0x00).id, 1025, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F413_4891_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F413_4891(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F414_4891_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F414_4891(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F416_4897_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F416_4897(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F417_4897_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F417_4897(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F425_4909_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F425_4909(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(989, 0x00).id, 989, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F420_4909_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F420_4909(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(977, 0x00).id, 977, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F421_4909_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F421_4909(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(968, 0x00).id, 968, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F422_4909_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F422_4909(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F423_4909_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F423_4909(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(974, 0x00).id, 974, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F424_4909_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F424_4909(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1025, 0x00).id, 1025, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F426_4909_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F426_4909(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F427_4909_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F427_4909(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(971, 0x00).id, 971, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F428_4909_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F428_4909(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(986, 0x00).id, 986, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F429_4909_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F429_4909(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(980, 0x00).id, 980, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F430_4909_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F430_4909(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(983, 0x00).id, 983, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F613_5055_3930_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F613_5055(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R3931[272])();
void R3931_init () {
	R3931[0] = (char *(*)()) F343_4799;
	R3931[1] = (char *(*)()) F344_4799;
	R3931[2] = (char *(*)()) F345_4799;
	R3931[3] = (char *(*)()) F346_4808;
	R3931[54] = (char *(*)()) F397_4881;
	R3931[55] = (char *(*)()) F398_4881;
	R3931[56] = (char *(*)()) F399_4881;
	R3931[57] = (char *(*)()) F400_4881;
	R3931[58] = (char *(*)()) F401_4881;
	R3931[59] = (char *(*)()) F402_4881;
	R3931[60] = (char *(*)()) F403_4881;
	R3931[61] = (char *(*)()) F404_4881;
	R3931[62] = (char *(*)()) F405_4881;
	R3931[63] = (char *(*)()) F406_4881;
	R3931[64] = (char *(*)()) F407_4881;
	R3931[65] = (char *(*)()) F408_4881;
	R3931[66] = (char *(*)()) F409_4894;
	R3931[67] = (char *(*)()) F410_4894;
	R3931[68] = (char *(*)()) F411_4894;
	R3931[69] = (char *(*)()) F412_4894;
	R3931[70] = (char *(*)()) F413_4894;
	R3931[71] = (char *(*)()) F414_4894;
	R3931[72] = (char *(*)()) F415_4898;
	R3931[73] = (char *(*)()) F416_4898;
	R3931[74] = (char *(*)()) F417_4898;
	R3931[75] = (char *(*)()) F418_4904;
	R3931[88] = (char *(*)()) F425_4918;
	R3931[89] = (char *(*)()) F419_4918;
	R3931[90] = (char *(*)()) F420_4918;
	R3931[91] = (char *(*)()) F421_4918;
	R3931[92] = (char *(*)()) F422_4918;
	R3931[93] = (char *(*)()) F423_4918;
	R3931[94] = (char *(*)()) F424_4918;
	R3931[95] = (char *(*)()) F425_4918;
	R3931[96] = (char *(*)()) F426_4918;
	R3931[97] = (char *(*)()) F427_4918;
	R3931[98] = (char *(*)()) F428_4918;
	R3931[99] = (char *(*)()) F429_4918;
	R3931[100] = (char *(*)()) F430_4918;
	R3931[101] = (char *(*)()) F428_4918;
	R3931[102] = (char *(*)()) F419_4918;
	R3931[103] = (char *(*)()) F420_4918;
	R3931[104] = (char *(*)()) F421_4918;
	R3931[105] = (char *(*)()) F422_4918;
	R3931[106] = (char *(*)()) F423_4918;
	R3931[107] = (char *(*)()) F424_4918;
	R3931[108] = (char *(*)()) F425_4918;
	R3931[109] = (char *(*)()) F426_4918;
	R3931[110] = (char *(*)()) F427_4918;
	R3931[111] = (char *(*)()) F428_4918;
	R3931[112] = (char *(*)()) F429_4918;
	R3931[113] = (char *(*)()) F430_4918;
	R3931[114] = (char *(*)()) F419_4918;
	R3931[115] = (char *(*)()) F420_4918;
	R3931[116] = (char *(*)()) F421_4918;
	R3931[117] = (char *(*)()) F422_4918;
	R3931[118] = (char *(*)()) F423_4918;
	R3931[119] = (char *(*)()) F424_4918;
	R3931[120] = (char *(*)()) F425_4918;
	R3931[121] = (char *(*)()) F426_4918;
	R3931[122] = (char *(*)()) F427_4918;
	R3931[123] = (char *(*)()) F428_4918;
	R3931[124] = (char *(*)()) F429_4918;
	R3931[125] = (char *(*)()) F430_4918;
	R3931[271] = (char *(*)()) F613_5056;
}

char *(*R3932[272])();
void R3932_init () {
	R3932[0] = (char *(*)()) F343_4800;
	R3932[1] = (char *(*)()) F344_4800;
	R3932[2] = (char *(*)()) F345_4800;
	R3932[3] = (char *(*)()) F346_4809;
	R3932[54] = (char *(*)()) F397_4889;
	R3932[55] = (char *(*)()) F398_4889;
	R3932[56] = (char *(*)()) F399_4889;
	R3932[57] = (char *(*)()) F400_4889;
	R3932[58] = (char *(*)()) F401_4889;
	R3932[59] = (char *(*)()) F402_4889;
	R3932[60] = (char *(*)()) F403_4889;
	R3932[61] = (char *(*)()) F404_4889;
	R3932[62] = (char *(*)()) F405_4889;
	R3932[63] = (char *(*)()) F406_4889;
	R3932[64] = (char *(*)()) F407_4889;
	R3932[65] = (char *(*)()) F408_4889;
	R3932[66] = (char *(*)()) F409_4895;
	R3932[67] = (char *(*)()) F410_4895;
	R3932[68] = (char *(*)()) F411_4895;
	R3932[69] = (char *(*)()) F412_4895;
	R3932[70] = (char *(*)()) F413_4895;
	R3932[71] = (char *(*)()) F414_4895;
	R3932[72] = (char *(*)()) F415_4900;
	R3932[73] = (char *(*)()) F416_4900;
	R3932[74] = (char *(*)()) F417_4900;
	R3932[75] = (char *(*)()) F418_4906;
	R3932[88] = (char *(*)()) F425_4924;
	R3932[89] = (char *(*)()) F419_4924;
	R3932[90] = (char *(*)()) F420_4924;
	R3932[91] = (char *(*)()) F421_4924;
	R3932[92] = (char *(*)()) F422_4924;
	R3932[93] = (char *(*)()) F423_4924;
	R3932[94] = (char *(*)()) F424_4924;
	R3932[95] = (char *(*)()) F425_4924;
	R3932[96] = (char *(*)()) F426_4924;
	R3932[97] = (char *(*)()) F427_4924;
	R3932[98] = (char *(*)()) F428_4924;
	R3932[99] = (char *(*)()) F429_4924;
	R3932[100] = (char *(*)()) F430_4924;
	R3932[101] = (char *(*)()) F428_4924;
	R3932[102] = (char *(*)()) F419_4924;
	R3932[103] = (char *(*)()) F420_4924;
	R3932[104] = (char *(*)()) F421_4924;
	R3932[105] = (char *(*)()) F422_4924;
	R3932[106] = (char *(*)()) F423_4924;
	R3932[107] = (char *(*)()) F424_4924;
	R3932[108] = (char *(*)()) F425_4924;
	R3932[109] = (char *(*)()) F426_4924;
	R3932[110] = (char *(*)()) F427_4924;
	R3932[111] = (char *(*)()) F428_4924;
	R3932[112] = (char *(*)()) F429_4924;
	R3932[113] = (char *(*)()) F430_4924;
	R3932[114] = (char *(*)()) F419_4924;
	R3932[115] = (char *(*)()) F420_4924;
	R3932[116] = (char *(*)()) F421_4924;
	R3932[117] = (char *(*)()) F422_4924;
	R3932[118] = (char *(*)()) F423_4924;
	R3932[119] = (char *(*)()) F424_4924;
	R3932[120] = (char *(*)()) F425_4924;
	R3932[121] = (char *(*)()) F426_4924;
	R3932[122] = (char *(*)()) F427_4924;
	R3932[123] = (char *(*)()) F428_4924;
	R3932[124] = (char *(*)()) F429_4924;
	R3932[125] = (char *(*)()) F430_4924;
	R3932[271] = (char *(*)()) F613_5062;
}

static EIF_TYPE_INDEX Y3933_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype16[] = {989,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype23[] = {986,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype82[] = {989,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype95[] = {986,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3933_pgtype120[] = {959,0xFFFF};
EIF_TYPE_INDEX *Y3933_gen_type [285];
EIF_TYPE_INDEX Y3933 [285];
void Y3933_init (void)
{
	egc_routines_types [3933] = Y3933;
	egc_routines_gen_types [3933] = Y3933_gen_type;
	egc_routines_offset [3933] = 329;
	Y3933_gen_type [0] = Y3933_pgtype0;
	Y3933_gen_type [1] = Y3933_pgtype1;
	Y3933_gen_type [2] = Y3933_pgtype2;
	Y3933_gen_type [3] = Y3933_pgtype3;
	Y3933_gen_type [4] = Y3933_pgtype4;
	Y3933_gen_type [5] = Y3933_pgtype5;
	Y3933_gen_type [6] = Y3933_pgtype6;
	Y3933_gen_type [7] = Y3933_pgtype7;
	Y3933_gen_type [8] = Y3933_pgtype8;
	Y3933_gen_type [9] = Y3933_pgtype9;
	Y3933_gen_type [10] = Y3933_pgtype10;
	Y3933_gen_type [11] = Y3933_pgtype11;
	Y3933_gen_type [12] = Y3933_pgtype12;
	Y3933_gen_type [13] = Y3933_pgtype13;
	Y3933_gen_type [14] = Y3933_pgtype14;
	Y3933_gen_type [15] = Y3933_pgtype15;
	Y3933_gen_type [16] = Y3933_pgtype16;
	Y3933_gen_type [17] = Y3933_pgtype17;
	Y3933_gen_type [18] = Y3933_pgtype18;
	Y3933_gen_type [19] = Y3933_pgtype19;
	Y3933_gen_type [20] = Y3933_pgtype20;
	Y3933_gen_type [21] = Y3933_pgtype21;
	Y3933_gen_type [22] = Y3933_pgtype22;
	Y3933_gen_type [35] = Y3933_pgtype23;
	Y3933_gen_type [43] = Y3933_pgtype24;
	Y3933_gen_type [44] = Y3933_pgtype25;
	Y3933_gen_type [45] = Y3933_pgtype26;
	Y3933_gen_type [46] = Y3933_pgtype27;
	Y3933_gen_type [47] = Y3933_pgtype28;
	Y3933_gen_type [48] = Y3933_pgtype29;
	Y3933_gen_type [49] = Y3933_pgtype30;
	Y3933_gen_type [50] = Y3933_pgtype31;
	Y3933_gen_type [51] = Y3933_pgtype32;
	Y3933_gen_type [52] = Y3933_pgtype33;
	Y3933_gen_type [53] = Y3933_pgtype34;
	Y3933_gen_type [54] = Y3933_pgtype35;
	Y3933_gen_type [55] = Y3933_pgtype36;
	Y3933_gen_type [56] = Y3933_pgtype37;
	Y3933_gen_type [57] = Y3933_pgtype38;
	Y3933_gen_type [58] = Y3933_pgtype39;
	Y3933_gen_type [59] = Y3933_pgtype40;
	Y3933_gen_type [60] = Y3933_pgtype41;
	Y3933_gen_type [61] = Y3933_pgtype42;
	Y3933_gen_type [62] = Y3933_pgtype43;
	Y3933_gen_type [63] = Y3933_pgtype44;
	Y3933_gen_type [64] = Y3933_pgtype45;
	Y3933_gen_type [65] = Y3933_pgtype46;
	Y3933_gen_type [66] = Y3933_pgtype47;
	Y3933_gen_type [67] = Y3933_pgtype48;
	Y3933_gen_type [68] = Y3933_pgtype49;
	Y3933_gen_type [69] = Y3933_pgtype50;
	Y3933_gen_type [70] = Y3933_pgtype51;
	Y3933_gen_type [71] = Y3933_pgtype52;
	Y3933_gen_type [72] = Y3933_pgtype53;
	Y3933_gen_type [73] = Y3933_pgtype54;
	Y3933_gen_type [74] = Y3933_pgtype55;
	Y3933_gen_type [75] = Y3933_pgtype56;
	Y3933_gen_type [76] = Y3933_pgtype57;
	Y3933_gen_type [77] = Y3933_pgtype58;
	Y3933_gen_type [78] = Y3933_pgtype59;
	Y3933_gen_type [79] = Y3933_pgtype60;
	Y3933_gen_type [80] = Y3933_pgtype61;
	Y3933_gen_type [81] = Y3933_pgtype62;
	Y3933_gen_type [82] = Y3933_pgtype63;
	Y3933_gen_type [83] = Y3933_pgtype64;
	Y3933_gen_type [84] = Y3933_pgtype65;
	Y3933_gen_type [85] = Y3933_pgtype66;
	Y3933_gen_type [86] = Y3933_pgtype67;
	Y3933_gen_type [87] = Y3933_pgtype68;
	Y3933_gen_type [88] = Y3933_pgtype69;
	Y3933_gen_type [89] = Y3933_pgtype70;
	Y3933_gen_type [90] = Y3933_pgtype71;
	Y3933_gen_type [91] = Y3933_pgtype72;
	Y3933_gen_type [92] = Y3933_pgtype73;
	Y3933_gen_type [93] = Y3933_pgtype74;
	Y3933_gen_type [94] = Y3933_pgtype75;
	Y3933_gen_type [95] = Y3933_pgtype76;
	Y3933_gen_type [96] = Y3933_pgtype77;
	Y3933_gen_type [97] = Y3933_pgtype78;
	Y3933_gen_type [98] = Y3933_pgtype79;
	Y3933_gen_type [99] = Y3933_pgtype80;
	Y3933_gen_type [100] = Y3933_pgtype81;
	Y3933_gen_type [101] = Y3933_pgtype82;
	Y3933_gen_type [102] = Y3933_pgtype83;
	Y3933_gen_type [103] = Y3933_pgtype84;
	Y3933_gen_type [104] = Y3933_pgtype85;
	Y3933_gen_type [105] = Y3933_pgtype86;
	Y3933_gen_type [106] = Y3933_pgtype87;
	Y3933_gen_type [107] = Y3933_pgtype88;
	Y3933_gen_type [108] = Y3933_pgtype89;
	Y3933_gen_type [109] = Y3933_pgtype90;
	Y3933_gen_type [110] = Y3933_pgtype91;
	Y3933_gen_type [111] = Y3933_pgtype92;
	Y3933_gen_type [112] = Y3933_pgtype93;
	Y3933_gen_type [113] = Y3933_pgtype94;
	Y3933_gen_type [114] = Y3933_pgtype95;
	Y3933_gen_type [115] = Y3933_pgtype96;
	Y3933_gen_type [116] = Y3933_pgtype97;
	Y3933_gen_type [117] = Y3933_pgtype98;
	Y3933_gen_type [118] = Y3933_pgtype99;
	Y3933_gen_type [119] = Y3933_pgtype100;
	Y3933_gen_type [120] = Y3933_pgtype101;
	Y3933_gen_type [121] = Y3933_pgtype102;
	Y3933_gen_type [122] = Y3933_pgtype103;
	Y3933_gen_type [123] = Y3933_pgtype104;
	Y3933_gen_type [124] = Y3933_pgtype105;
	Y3933_gen_type [125] = Y3933_pgtype106;
	Y3933_gen_type [126] = Y3933_pgtype107;
	Y3933_gen_type [127] = Y3933_pgtype108;
	Y3933_gen_type [128] = Y3933_pgtype109;
	Y3933_gen_type [129] = Y3933_pgtype110;
	Y3933_gen_type [130] = Y3933_pgtype111;
	Y3933_gen_type [131] = Y3933_pgtype112;
	Y3933_gen_type [132] = Y3933_pgtype113;
	Y3933_gen_type [133] = Y3933_pgtype114;
	Y3933_gen_type [134] = Y3933_pgtype115;
	Y3933_gen_type [135] = Y3933_pgtype116;
	Y3933_gen_type [136] = Y3933_pgtype117;
	Y3933_gen_type [137] = Y3933_pgtype118;
	Y3933_gen_type [138] = Y3933_pgtype119;
	Y3933_gen_type [284] = Y3933_pgtype120;
	Y3933[16] = 989;
	Y3933[35] = 986;
	Y3933[101] = 989;
	Y3933[114] = 986;
	Y3933[284] = 959;
}

char *(*R3938[3])();
void R3938_init () {
	R3938[0] = (char *(*)()) F343_4797;
	R3938[1] = (char *(*)()) F344_4797;
	R3938[2] = (char *(*)()) F345_4797;
}

char *(*R3946[6])();
void R3946_init () {
	R3946[0] = (char *(*)()) F409_4892;
	R3946[1] = (char *(*)()) F410_4892;
	R3946[2] = (char *(*)()) F411_4892;
	R3946[3] = (char *(*)()) F412_4892_3946_1;
	R3946[4] = (char *(*)()) F413_4892_3946_1;
	R3946[5] = (char *(*)()) F414_4892;
}
static EIF_REFERENCE F412_4892_3946_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F412_4892(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F413_4892_3946_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F413_4892(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R3948[948])();
void R3948_init () {
	R3948[0] = (char *(*)()) F366_4829;
	R3948[31] = (char *(*)()) F397_4875;
	R3948[32] = (char *(*)()) F398_4875;
	R3948[33] = (char *(*)()) F399_4875;
	R3948[34] = (char *(*)()) F400_4875;
	R3948[35] = (char *(*)()) F401_4875;
	R3948[36] = (char *(*)()) F402_4875;
	R3948[37] = (char *(*)()) F403_4875;
	R3948[38] = (char *(*)()) F404_4875;
	R3948[39] = (char *(*)()) F405_4875;
	R3948[40] = (char *(*)()) F406_4875;
	R3948[41] = (char *(*)()) F407_4875;
	R3948[42] = (char *(*)()) F408_4875;
	R3948[43] = (char *(*)()) F397_4875;
	R3948[44] = (char *(*)()) F400_4875;
	R3948[45] = (char *(*)()) F404_4875;
	R3948[46] = (char *(*)()) F397_4875;
	R3948[47] = (char *(*)()) F400_4875;
	R3948[48] = (char *(*)()) F405_4875;
	R3948[49] = (char *(*)()) F397_4875;
	R3948[50] = (char *(*)()) F400_4875;
	R3948[51] = (char *(*)()) F405_4875;
	R3948[52] = (char *(*)()) F397_4875;
	R3948[65] = (char *(*)()) F431_4931;
	R3948[66] = (char *(*)()) F432_4937;
	R3948[67] = (char *(*)()) F433_4937;
	R3948[68] = (char *(*)()) F434_4937;
	R3948[69] = (char *(*)()) F435_4937;
	R3948[70] = (char *(*)()) F436_4937;
	R3948[71] = (char *(*)()) F437_4937;
	R3948[72] = (char *(*)()) F438_4937;
	R3948[73] = (char *(*)()) F439_4937;
	R3948[74] = (char *(*)()) F440_4937;
	R3948[75] = (char *(*)()) F441_4937;
	R3948[76] = (char *(*)()) F442_4937;
	R3948[77] = (char *(*)()) F443_4937;
	R3948[78] = (char *(*)()) F444_4943;
	R3948[79] = (char *(*)()) F445_4949;
	R3948[80] = (char *(*)()) F446_4949;
	R3948[81] = (char *(*)()) F447_4949;
	R3948[82] = (char *(*)()) F448_4949;
	R3948[83] = (char *(*)()) F449_4949;
	R3948[84] = (char *(*)()) F450_4949;
	R3948[85] = (char *(*)()) F451_4949;
	R3948[86] = (char *(*)()) F452_4949;
	R3948[87] = (char *(*)()) F453_4949;
	R3948[88] = (char *(*)()) F454_4949;
	R3948[89] = (char *(*)()) F455_4949;
	R3948[90] = (char *(*)()) F456_4949;
	R3948[91] = (char *(*)()) F457_4955;
	R3948[92] = (char *(*)()) F458_4955;
	R3948[93] = (char *(*)()) F459_4955;
	R3948[94] = (char *(*)()) F460_4955;
	R3948[95] = (char *(*)()) F461_4955;
	R3948[96] = (char *(*)()) F462_4955;
	R3948[97] = (char *(*)()) F463_4955;
	R3948[98] = (char *(*)()) F464_4955;
	R3948[99] = (char *(*)()) F465_4955;
	R3948[100] = (char *(*)()) F466_4955;
	R3948[101] = (char *(*)()) F467_4955;
	R3948[102] = (char *(*)()) F468_4955;
	R3948[248] = (char *(*)()) F614_5079;
	R3948[341] = (char *(*)()) F707_5169;
	R3948[342] = (char *(*)()) F708_5169;
	R3948[343] = (char *(*)()) F709_5169;
	R3948[344] = (char *(*)()) F710_5169;
	R3948[345] = (char *(*)()) F711_5169;
	R3948[346] = (char *(*)()) F712_5169;
	R3948[347] = (char *(*)()) F713_5169;
	R3948[348] = (char *(*)()) F714_5169;
	R3948[349] = (char *(*)()) F715_5169;
	R3948[350] = (char *(*)()) F716_5169;
	R3948[351] = (char *(*)()) F717_5169;
	R3948[352] = (char *(*)()) F718_5169;
	R3948[408] = (char *(*)()) F774_5285;
	R3948[409] = (char *(*)()) F775_5285;
	R3948[410] = (char *(*)()) F776_5285;
	R3948[414] = (char *(*)()) F779_5361;
	R3948[418] = (char *(*)()) F784_5455;
	R3948[419] = (char *(*)()) F785_5455;
	R3948[420] = (char *(*)()) F786_5455;
	R3948[421] = (char *(*)()) F787_5455;
	R3948[422] = (char *(*)()) F788_5455;
	R3948[423] = (char *(*)()) F789_5455;
	R3948[424] = (char *(*)()) F784_5455;
	R3948[425] = (char *(*)()) F789_5455;
	R3948[426] = (char *(*)()) F785_5455;
	R3948[427] = (char *(*)()) F784_5455;
	R3948[428] = (char *(*)()) F794_5585;
	R3948[429] = (char *(*)()) F795_5585;
	R3948[430] = (char *(*)()) F796_5585;
	R3948[431] = (char *(*)()) F797_5585;
	R3948[432] = (char *(*)()) F798_5585;
	R3948[433] = (char *(*)()) F799_5585;
	R3948[434] = (char *(*)()) F800_5585;
	R3948[435] = (char *(*)()) F801_5585;
	R3948[436] = (char *(*)()) F802_5585;
	R3948[437] = (char *(*)()) F803_5585;
	R3948[438] = (char *(*)()) F804_5585;
	R3948[439] = (char *(*)()) F805_5585;
	R3948[441] = (char *(*)()) F794_5585;
	R3948[442] = (char *(*)()) F797_5585;
	R3948[443] = (char *(*)()) F801_5585;
	R3948[444] = (char *(*)()) F794_5585;
	{long i; for (i = 446; i < 448; i++) R3948[i] = (char *(*)()) F794_5585;}
	{long i; for (i = 448; i < 450; i++) R3948[i] = (char *(*)()) F797_5585;}
	{long i; for (i = 457; i < 459; i++) R3948[i] = (char *(*)()) F822_6000;}
	R3948[474] = (char *(*)()) F840_6405;
	R3948[475] = (char *(*)()) F841_6405;
	R3948[476] = (char *(*)()) F842_6405;
	R3948[477] = (char *(*)()) F843_6405;
	R3948[478] = (char *(*)()) F844_6405;
	R3948[479] = (char *(*)()) F845_6405;
	R3948[480] = (char *(*)()) F846_6405;
	R3948[481] = (char *(*)()) F847_6405;
	R3948[482] = (char *(*)()) F848_6405;
	R3948[483] = (char *(*)()) F849_6405;
	R3948[484] = (char *(*)()) F850_6405;
	R3948[485] = (char *(*)()) F851_6405;
	R3948[588] = (char *(*)()) F682_5115;
	{long i; for (i = 671; i < 673; i++) R3948[i] = (char *(*)()) F1036_8240;}
	{long i; for (i = 675; i < 677; i++) R3948[i] = (char *(*)()) F1040_8405;}
	R3948[680] = (char *(*)()) F1046_8591;
	R3948[681] = (char *(*)()) F1047_8591;
	R3948[682] = (char *(*)()) F1048_8591;
	R3948[688] = (char *(*)()) F1054_8647;
	R3948[722] = (char *(*)()) F469_4961;
	{long i; for (i = 835; i < 845; i++) R3948[i] = (char *(*)()) F794_5585;}
	R3948[947] = (char *(*)()) F1036_8240;
}

static EIF_TYPE_INDEX Y3949_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype12[] = {986,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype13[] = {0xFF01,1040,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype78[] = {989,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype91[] = {986,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype116[] = {0xFF01,1037,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype123[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype124[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype125[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype126[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype127[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype128[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype129[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype130[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype131[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype132[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype133[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype134[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype135[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype136[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype137[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype138[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype139[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype140[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype141[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype142[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype143[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype144[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype145[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype146[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype147[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype148[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype149[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype150[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype151[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype152[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype153[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype154[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype155[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype156[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype157[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype158[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype159[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype160[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype161[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype162[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype163[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype164[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype165[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype166[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype167[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype168[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype169[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype170[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype171[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype172[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype173[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype174[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype175[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype176[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype177[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype178[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype179[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype180[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype181[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype182[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype183[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype184[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype185[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype186[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype187[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype188[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype189[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype190[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype191[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype192[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype193[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype194[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype195[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype196[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype197[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype198[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype199[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype200[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype201[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype202[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype203[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype204[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype205[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype206[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype207[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype208[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype209[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype210[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype211[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype212[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype213[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype214[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype215[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype216[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype217[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype218[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype219[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype220[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype221[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype222[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype223[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype224[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype225[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype226[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype227[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype228[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype229[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype230[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype231[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype232[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype233[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype234[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype235[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype236[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype237[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype238[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype239[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype240[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype241[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype242[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype243[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype244[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype245[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype246[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype247[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype248[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype249[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype250[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype251[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype252[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype253[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype254[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype255[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype256[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype257[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype258[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype259[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype260[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype261[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype262[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype263[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype264[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype265[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype266[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype267[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype268[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype269[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype270[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype271[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype272[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype273[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype274[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype275[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype276[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype277[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype278[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype279[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype280[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype281[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype282[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype283[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype284[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype285[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype286[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype287[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype288[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype289[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype290[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype291[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype292[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype293[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype294[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype295[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype296[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype297[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype298[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype299[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype300[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype301[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype302[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype303[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype304[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype305[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype306[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype307[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype308[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype309[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype310[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype311[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype312[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype313[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype314[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype315[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype316[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype317[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype318[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype319[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype320[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype321[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype322[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype323[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype324[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype325[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype326[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype327[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype328[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype329[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype330[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype331[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype332[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype333[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype334[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype335[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype336[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype337[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype338[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype339[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype340[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype341[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype342[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype343[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype344[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype345[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype346[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype347[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype348[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype349[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype350[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype351[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype352[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype353[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype354[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype355[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype356[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype357[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype358[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype359[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype360[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype361[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype362[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype363[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype364[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype365[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype366[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype367[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype368[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype369[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype370[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype371[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype372[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype373[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype374[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype375[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype376[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype377[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype378[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype379[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype380[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype381[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype382[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype383[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype384[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype385[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype386[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype387[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype388[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype389[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype390[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype391[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype392[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype393[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype394[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype395[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype396[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype397[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype398[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype399[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype400[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype401[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype402[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype403[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype404[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype405[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype406[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype407[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype408[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype409[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype410[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype411[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype412[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype413[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype414[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype415[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype416[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype417[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype418[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype419[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype420[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype421[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype422[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype423[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype424[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype425[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype426[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype427[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype428[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype429[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype430[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype431[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype432[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype433[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype434[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype435[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype436[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype437[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype438[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype439[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype440[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype441[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype442[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype443[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype444[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype445[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype446[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype447[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype448[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype449[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype450[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype451[] = {0xFF01,23,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype452[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype453[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype454[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype455[] = {0xFF01,326,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype456[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype457[] = {0xFF01,1027,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype458[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype459[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype460[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype461[] = {989,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype462[] = {989,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype463[] = {989,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype464[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype465[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype466[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype467[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype468[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype469[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype470[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype471[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype472[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype473[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype474[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype475[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype476[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype477[] = {989,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype478[] = {989,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype479[] = {989,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype480[] = {989,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype481[] = {986,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype482[] = {986,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype483[] = {986,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype484[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype485[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype486[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype487[] = {989,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype488[] = {989,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype489[] = {989,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype490[] = {989,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype491[] = {989,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype492[] = {989,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype493[] = {989,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype494[] = {989,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype495[] = {0xFF01,1037,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype496[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype497[] = {0xFF01,1274,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype498[] = {0xFF01,1133,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype499[] = {0xFF01,1147,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype500[] = {0xFF01,1148,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype501[] = {0xFF01,1137,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype502[] = {0xFF01,1141,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype503[] = {0xFF01,1142,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype504[] = {0xFF01,1135,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype505[] = {0xFF01,1191,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype506[] = {989,0xFFFF};
static EIF_TYPE_INDEX Y3949_pgtype507[] = {989,0xFFFF};
EIF_TYPE_INDEX *Y3949_gen_type [962];
EIF_TYPE_INDEX Y3949 [962];
void Y3949_init (void)
{
	egc_routines_types [3949] = Y3949;
	egc_routines_gen_types [3949] = Y3949_gen_type;
	egc_routines_offset [3949] = 352;
	Y3949_gen_type [0] = Y3949_pgtype0;
	Y3949_gen_type [1] = Y3949_pgtype1;
	Y3949_gen_type [2] = Y3949_pgtype2;
	Y3949_gen_type [3] = Y3949_pgtype3;
	Y3949_gen_type [4] = Y3949_pgtype4;
	Y3949_gen_type [5] = Y3949_pgtype5;
	Y3949_gen_type [6] = Y3949_pgtype6;
	Y3949_gen_type [7] = Y3949_pgtype7;
	Y3949_gen_type [8] = Y3949_pgtype8;
	Y3949_gen_type [9] = Y3949_pgtype9;
	Y3949_gen_type [10] = Y3949_pgtype10;
	Y3949_gen_type [11] = Y3949_pgtype11;
	Y3949_gen_type [12] = Y3949_pgtype12;
	Y3949_gen_type [13] = Y3949_pgtype13;
	Y3949_gen_type [14] = Y3949_pgtype14;
	Y3949_gen_type [15] = Y3949_pgtype15;
	Y3949_gen_type [16] = Y3949_pgtype16;
	Y3949_gen_type [17] = Y3949_pgtype17;
	Y3949_gen_type [18] = Y3949_pgtype18;
	Y3949_gen_type [19] = Y3949_pgtype19;
	Y3949_gen_type [20] = Y3949_pgtype20;
	Y3949_gen_type [21] = Y3949_pgtype21;
	Y3949_gen_type [22] = Y3949_pgtype22;
	Y3949_gen_type [23] = Y3949_pgtype23;
	Y3949_gen_type [24] = Y3949_pgtype24;
	Y3949_gen_type [25] = Y3949_pgtype25;
	Y3949_gen_type [26] = Y3949_pgtype26;
	Y3949_gen_type [27] = Y3949_pgtype27;
	Y3949_gen_type [28] = Y3949_pgtype28;
	Y3949_gen_type [29] = Y3949_pgtype29;
	Y3949_gen_type [30] = Y3949_pgtype30;
	Y3949_gen_type [31] = Y3949_pgtype31;
	Y3949_gen_type [32] = Y3949_pgtype32;
	Y3949_gen_type [33] = Y3949_pgtype33;
	Y3949_gen_type [34] = Y3949_pgtype34;
	Y3949_gen_type [35] = Y3949_pgtype35;
	Y3949_gen_type [36] = Y3949_pgtype36;
	Y3949_gen_type [37] = Y3949_pgtype37;
	Y3949_gen_type [38] = Y3949_pgtype38;
	Y3949_gen_type [39] = Y3949_pgtype39;
	Y3949_gen_type [40] = Y3949_pgtype40;
	Y3949_gen_type [41] = Y3949_pgtype41;
	Y3949_gen_type [42] = Y3949_pgtype42;
	Y3949_gen_type [43] = Y3949_pgtype43;
	Y3949_gen_type [44] = Y3949_pgtype44;
	Y3949_gen_type [45] = Y3949_pgtype45;
	Y3949_gen_type [46] = Y3949_pgtype46;
	Y3949_gen_type [47] = Y3949_pgtype47;
	Y3949_gen_type [48] = Y3949_pgtype48;
	Y3949_gen_type [49] = Y3949_pgtype49;
	Y3949_gen_type [50] = Y3949_pgtype50;
	Y3949_gen_type [51] = Y3949_pgtype51;
	Y3949_gen_type [52] = Y3949_pgtype52;
	Y3949_gen_type [53] = Y3949_pgtype53;
	Y3949_gen_type [54] = Y3949_pgtype54;
	Y3949_gen_type [55] = Y3949_pgtype55;
	Y3949_gen_type [56] = Y3949_pgtype56;
	Y3949_gen_type [57] = Y3949_pgtype57;
	Y3949_gen_type [58] = Y3949_pgtype58;
	Y3949_gen_type [59] = Y3949_pgtype59;
	Y3949_gen_type [60] = Y3949_pgtype60;
	Y3949_gen_type [61] = Y3949_pgtype61;
	Y3949_gen_type [62] = Y3949_pgtype62;
	Y3949_gen_type [63] = Y3949_pgtype63;
	Y3949_gen_type [64] = Y3949_pgtype64;
	Y3949_gen_type [65] = Y3949_pgtype65;
	Y3949_gen_type [66] = Y3949_pgtype66;
	Y3949_gen_type [67] = Y3949_pgtype67;
	Y3949_gen_type [68] = Y3949_pgtype68;
	Y3949_gen_type [69] = Y3949_pgtype69;
	Y3949_gen_type [70] = Y3949_pgtype70;
	Y3949_gen_type [71] = Y3949_pgtype71;
	Y3949_gen_type [72] = Y3949_pgtype72;
	Y3949_gen_type [73] = Y3949_pgtype73;
	Y3949_gen_type [74] = Y3949_pgtype74;
	Y3949_gen_type [75] = Y3949_pgtype75;
	Y3949_gen_type [76] = Y3949_pgtype76;
	Y3949_gen_type [77] = Y3949_pgtype77;
	Y3949_gen_type [78] = Y3949_pgtype78;
	Y3949_gen_type [79] = Y3949_pgtype79;
	Y3949_gen_type [80] = Y3949_pgtype80;
	Y3949_gen_type [81] = Y3949_pgtype81;
	Y3949_gen_type [82] = Y3949_pgtype82;
	Y3949_gen_type [83] = Y3949_pgtype83;
	Y3949_gen_type [84] = Y3949_pgtype84;
	Y3949_gen_type [85] = Y3949_pgtype85;
	Y3949_gen_type [86] = Y3949_pgtype86;
	Y3949_gen_type [87] = Y3949_pgtype87;
	Y3949_gen_type [88] = Y3949_pgtype88;
	Y3949_gen_type [89] = Y3949_pgtype89;
	Y3949_gen_type [90] = Y3949_pgtype90;
	Y3949_gen_type [91] = Y3949_pgtype91;
	Y3949_gen_type [92] = Y3949_pgtype92;
	Y3949_gen_type [93] = Y3949_pgtype93;
	Y3949_gen_type [94] = Y3949_pgtype94;
	Y3949_gen_type [95] = Y3949_pgtype95;
	Y3949_gen_type [96] = Y3949_pgtype96;
	Y3949_gen_type [97] = Y3949_pgtype97;
	Y3949_gen_type [98] = Y3949_pgtype98;
	Y3949_gen_type [99] = Y3949_pgtype99;
	Y3949_gen_type [100] = Y3949_pgtype100;
	Y3949_gen_type [101] = Y3949_pgtype101;
	Y3949_gen_type [102] = Y3949_pgtype102;
	Y3949_gen_type [103] = Y3949_pgtype103;
	Y3949_gen_type [104] = Y3949_pgtype104;
	Y3949_gen_type [105] = Y3949_pgtype105;
	Y3949_gen_type [106] = Y3949_pgtype106;
	Y3949_gen_type [107] = Y3949_pgtype107;
	Y3949_gen_type [108] = Y3949_pgtype108;
	Y3949_gen_type [109] = Y3949_pgtype109;
	Y3949_gen_type [110] = Y3949_pgtype110;
	Y3949_gen_type [111] = Y3949_pgtype111;
	Y3949_gen_type [112] = Y3949_pgtype112;
	Y3949_gen_type [113] = Y3949_pgtype113;
	Y3949_gen_type [114] = Y3949_pgtype114;
	Y3949_gen_type [115] = Y3949_pgtype115;
	Y3949_gen_type [116] = Y3949_pgtype116;
	Y3949_gen_type [117] = Y3949_pgtype117;
	Y3949_gen_type [118] = Y3949_pgtype118;
	Y3949_gen_type [119] = Y3949_pgtype119;
	Y3949_gen_type [120] = Y3949_pgtype120;
	Y3949_gen_type [121] = Y3949_pgtype121;
	Y3949_gen_type [122] = Y3949_pgtype122;
	Y3949_gen_type [123] = Y3949_pgtype123;
	Y3949_gen_type [124] = Y3949_pgtype124;
	Y3949_gen_type [125] = Y3949_pgtype125;
	Y3949_gen_type [126] = Y3949_pgtype126;
	Y3949_gen_type [127] = Y3949_pgtype127;
	Y3949_gen_type [128] = Y3949_pgtype128;
	Y3949_gen_type [129] = Y3949_pgtype129;
	Y3949_gen_type [130] = Y3949_pgtype130;
	Y3949_gen_type [131] = Y3949_pgtype131;
	Y3949_gen_type [132] = Y3949_pgtype132;
	Y3949_gen_type [133] = Y3949_pgtype133;
	Y3949_gen_type [134] = Y3949_pgtype134;
	Y3949_gen_type [135] = Y3949_pgtype135;
	Y3949_gen_type [136] = Y3949_pgtype136;
	Y3949_gen_type [137] = Y3949_pgtype137;
	Y3949_gen_type [138] = Y3949_pgtype138;
	Y3949_gen_type [139] = Y3949_pgtype139;
	Y3949_gen_type [140] = Y3949_pgtype140;
	Y3949_gen_type [141] = Y3949_pgtype141;
	Y3949_gen_type [142] = Y3949_pgtype142;
	Y3949_gen_type [143] = Y3949_pgtype143;
	Y3949_gen_type [144] = Y3949_pgtype144;
	Y3949_gen_type [145] = Y3949_pgtype145;
	Y3949_gen_type [146] = Y3949_pgtype146;
	Y3949_gen_type [147] = Y3949_pgtype147;
	Y3949_gen_type [148] = Y3949_pgtype148;
	Y3949_gen_type [149] = Y3949_pgtype149;
	Y3949_gen_type [150] = Y3949_pgtype150;
	Y3949_gen_type [151] = Y3949_pgtype151;
	Y3949_gen_type [152] = Y3949_pgtype152;
	Y3949_gen_type [153] = Y3949_pgtype153;
	Y3949_gen_type [154] = Y3949_pgtype154;
	Y3949_gen_type [155] = Y3949_pgtype155;
	Y3949_gen_type [156] = Y3949_pgtype156;
	Y3949_gen_type [157] = Y3949_pgtype157;
	Y3949_gen_type [158] = Y3949_pgtype158;
	Y3949_gen_type [159] = Y3949_pgtype159;
	Y3949_gen_type [160] = Y3949_pgtype160;
	Y3949_gen_type [161] = Y3949_pgtype161;
	Y3949_gen_type [162] = Y3949_pgtype162;
	Y3949_gen_type [163] = Y3949_pgtype163;
	Y3949_gen_type [164] = Y3949_pgtype164;
	Y3949_gen_type [165] = Y3949_pgtype165;
	Y3949_gen_type [166] = Y3949_pgtype166;
	Y3949_gen_type [167] = Y3949_pgtype167;
	Y3949_gen_type [168] = Y3949_pgtype168;
	Y3949_gen_type [169] = Y3949_pgtype169;
	Y3949_gen_type [170] = Y3949_pgtype170;
	Y3949_gen_type [171] = Y3949_pgtype171;
	Y3949_gen_type [172] = Y3949_pgtype172;
	Y3949_gen_type [173] = Y3949_pgtype173;
	Y3949_gen_type [174] = Y3949_pgtype174;
	Y3949_gen_type [175] = Y3949_pgtype175;
	Y3949_gen_type [176] = Y3949_pgtype176;
	Y3949_gen_type [177] = Y3949_pgtype177;
	Y3949_gen_type [178] = Y3949_pgtype178;
	Y3949_gen_type [179] = Y3949_pgtype179;
	Y3949_gen_type [180] = Y3949_pgtype180;
	Y3949_gen_type [181] = Y3949_pgtype181;
	Y3949_gen_type [182] = Y3949_pgtype182;
	Y3949_gen_type [183] = Y3949_pgtype183;
	Y3949_gen_type [184] = Y3949_pgtype184;
	Y3949_gen_type [185] = Y3949_pgtype185;
	Y3949_gen_type [186] = Y3949_pgtype186;
	Y3949_gen_type [187] = Y3949_pgtype187;
	Y3949_gen_type [188] = Y3949_pgtype188;
	Y3949_gen_type [189] = Y3949_pgtype189;
	Y3949_gen_type [190] = Y3949_pgtype190;
	Y3949_gen_type [191] = Y3949_pgtype191;
	Y3949_gen_type [192] = Y3949_pgtype192;
	Y3949_gen_type [193] = Y3949_pgtype193;
	Y3949_gen_type [194] = Y3949_pgtype194;
	Y3949_gen_type [195] = Y3949_pgtype195;
	Y3949_gen_type [196] = Y3949_pgtype196;
	Y3949_gen_type [197] = Y3949_pgtype197;
	Y3949_gen_type [198] = Y3949_pgtype198;
	Y3949_gen_type [199] = Y3949_pgtype199;
	Y3949_gen_type [200] = Y3949_pgtype200;
	Y3949_gen_type [201] = Y3949_pgtype201;
	Y3949_gen_type [202] = Y3949_pgtype202;
	Y3949_gen_type [203] = Y3949_pgtype203;
	Y3949_gen_type [204] = Y3949_pgtype204;
	Y3949_gen_type [205] = Y3949_pgtype205;
	Y3949_gen_type [206] = Y3949_pgtype206;
	Y3949_gen_type [207] = Y3949_pgtype207;
	Y3949_gen_type [208] = Y3949_pgtype208;
	Y3949_gen_type [209] = Y3949_pgtype209;
	Y3949_gen_type [210] = Y3949_pgtype210;
	Y3949_gen_type [211] = Y3949_pgtype211;
	Y3949_gen_type [212] = Y3949_pgtype212;
	Y3949_gen_type [213] = Y3949_pgtype213;
	Y3949_gen_type [214] = Y3949_pgtype214;
	Y3949_gen_type [215] = Y3949_pgtype215;
	Y3949_gen_type [216] = Y3949_pgtype216;
	Y3949_gen_type [217] = Y3949_pgtype217;
	Y3949_gen_type [218] = Y3949_pgtype218;
	Y3949_gen_type [219] = Y3949_pgtype219;
	Y3949_gen_type [220] = Y3949_pgtype220;
	Y3949_gen_type [221] = Y3949_pgtype221;
	Y3949_gen_type [222] = Y3949_pgtype222;
	Y3949_gen_type [223] = Y3949_pgtype223;
	Y3949_gen_type [224] = Y3949_pgtype224;
	Y3949_gen_type [225] = Y3949_pgtype225;
	Y3949_gen_type [226] = Y3949_pgtype226;
	Y3949_gen_type [227] = Y3949_pgtype227;
	Y3949_gen_type [228] = Y3949_pgtype228;
	Y3949_gen_type [229] = Y3949_pgtype229;
	Y3949_gen_type [230] = Y3949_pgtype230;
	Y3949_gen_type [231] = Y3949_pgtype231;
	Y3949_gen_type [232] = Y3949_pgtype232;
	Y3949_gen_type [233] = Y3949_pgtype233;
	Y3949_gen_type [234] = Y3949_pgtype234;
	Y3949_gen_type [235] = Y3949_pgtype235;
	Y3949_gen_type [236] = Y3949_pgtype236;
	Y3949_gen_type [237] = Y3949_pgtype237;
	Y3949_gen_type [238] = Y3949_pgtype238;
	Y3949_gen_type [239] = Y3949_pgtype239;
	Y3949_gen_type [240] = Y3949_pgtype240;
	Y3949_gen_type [241] = Y3949_pgtype241;
	Y3949_gen_type [242] = Y3949_pgtype242;
	Y3949_gen_type [243] = Y3949_pgtype243;
	Y3949_gen_type [244] = Y3949_pgtype244;
	Y3949_gen_type [245] = Y3949_pgtype245;
	Y3949_gen_type [246] = Y3949_pgtype246;
	Y3949_gen_type [247] = Y3949_pgtype247;
	Y3949_gen_type [248] = Y3949_pgtype248;
	Y3949_gen_type [249] = Y3949_pgtype249;
	Y3949_gen_type [250] = Y3949_pgtype250;
	Y3949_gen_type [251] = Y3949_pgtype251;
	Y3949_gen_type [252] = Y3949_pgtype252;
	Y3949_gen_type [253] = Y3949_pgtype253;
	Y3949_gen_type [254] = Y3949_pgtype254;
	Y3949_gen_type [255] = Y3949_pgtype255;
	Y3949_gen_type [256] = Y3949_pgtype256;
	Y3949_gen_type [257] = Y3949_pgtype257;
	Y3949_gen_type [258] = Y3949_pgtype258;
	Y3949_gen_type [259] = Y3949_pgtype259;
	Y3949_gen_type [260] = Y3949_pgtype260;
	Y3949_gen_type [261] = Y3949_pgtype261;
	Y3949_gen_type [262] = Y3949_pgtype262;
	Y3949_gen_type [263] = Y3949_pgtype263;
	Y3949_gen_type [264] = Y3949_pgtype264;
	Y3949_gen_type [265] = Y3949_pgtype265;
	Y3949_gen_type [266] = Y3949_pgtype266;
	Y3949_gen_type [267] = Y3949_pgtype267;
	Y3949_gen_type [268] = Y3949_pgtype268;
	Y3949_gen_type [269] = Y3949_pgtype269;
	Y3949_gen_type [270] = Y3949_pgtype270;
	Y3949_gen_type [271] = Y3949_pgtype271;
	Y3949_gen_type [272] = Y3949_pgtype272;
	Y3949_gen_type [273] = Y3949_pgtype273;
	Y3949_gen_type [274] = Y3949_pgtype274;
	Y3949_gen_type [275] = Y3949_pgtype275;
	Y3949_gen_type [276] = Y3949_pgtype276;
	Y3949_gen_type [277] = Y3949_pgtype277;
	Y3949_gen_type [278] = Y3949_pgtype278;
	Y3949_gen_type [279] = Y3949_pgtype279;
	Y3949_gen_type [280] = Y3949_pgtype280;
	Y3949_gen_type [281] = Y3949_pgtype281;
	Y3949_gen_type [282] = Y3949_pgtype282;
	Y3949_gen_type [283] = Y3949_pgtype283;
	Y3949_gen_type [284] = Y3949_pgtype284;
	Y3949_gen_type [285] = Y3949_pgtype285;
	Y3949_gen_type [286] = Y3949_pgtype286;
	Y3949_gen_type [287] = Y3949_pgtype287;
	Y3949_gen_type [288] = Y3949_pgtype288;
	Y3949_gen_type [289] = Y3949_pgtype289;
	Y3949_gen_type [290] = Y3949_pgtype290;
	Y3949_gen_type [291] = Y3949_pgtype291;
	Y3949_gen_type [292] = Y3949_pgtype292;
	Y3949_gen_type [293] = Y3949_pgtype293;
	Y3949_gen_type [294] = Y3949_pgtype294;
	Y3949_gen_type [295] = Y3949_pgtype295;
	Y3949_gen_type [296] = Y3949_pgtype296;
	Y3949_gen_type [297] = Y3949_pgtype297;
	Y3949_gen_type [298] = Y3949_pgtype298;
	Y3949_gen_type [299] = Y3949_pgtype299;
	Y3949_gen_type [300] = Y3949_pgtype300;
	Y3949_gen_type [301] = Y3949_pgtype301;
	Y3949_gen_type [302] = Y3949_pgtype302;
	Y3949_gen_type [303] = Y3949_pgtype303;
	Y3949_gen_type [304] = Y3949_pgtype304;
	Y3949_gen_type [305] = Y3949_pgtype305;
	Y3949_gen_type [306] = Y3949_pgtype306;
	Y3949_gen_type [307] = Y3949_pgtype307;
	Y3949_gen_type [308] = Y3949_pgtype308;
	Y3949_gen_type [309] = Y3949_pgtype309;
	Y3949_gen_type [310] = Y3949_pgtype310;
	Y3949_gen_type [311] = Y3949_pgtype311;
	Y3949_gen_type [312] = Y3949_pgtype312;
	Y3949_gen_type [313] = Y3949_pgtype313;
	Y3949_gen_type [314] = Y3949_pgtype314;
	Y3949_gen_type [315] = Y3949_pgtype315;
	Y3949_gen_type [316] = Y3949_pgtype316;
	Y3949_gen_type [317] = Y3949_pgtype317;
	Y3949_gen_type [318] = Y3949_pgtype318;
	Y3949_gen_type [319] = Y3949_pgtype319;
	Y3949_gen_type [320] = Y3949_pgtype320;
	Y3949_gen_type [321] = Y3949_pgtype321;
	Y3949_gen_type [322] = Y3949_pgtype322;
	Y3949_gen_type [323] = Y3949_pgtype323;
	Y3949_gen_type [324] = Y3949_pgtype324;
	Y3949_gen_type [325] = Y3949_pgtype325;
	Y3949_gen_type [326] = Y3949_pgtype326;
	Y3949_gen_type [327] = Y3949_pgtype327;
	Y3949_gen_type [328] = Y3949_pgtype328;
	Y3949_gen_type [329] = Y3949_pgtype329;
	Y3949_gen_type [330] = Y3949_pgtype330;
	Y3949_gen_type [331] = Y3949_pgtype331;
	Y3949_gen_type [332] = Y3949_pgtype332;
	Y3949_gen_type [333] = Y3949_pgtype333;
	Y3949_gen_type [334] = Y3949_pgtype334;
	Y3949_gen_type [335] = Y3949_pgtype335;
	Y3949_gen_type [336] = Y3949_pgtype336;
	Y3949_gen_type [337] = Y3949_pgtype337;
	Y3949_gen_type [338] = Y3949_pgtype338;
	Y3949_gen_type [339] = Y3949_pgtype339;
	Y3949_gen_type [340] = Y3949_pgtype340;
	Y3949_gen_type [341] = Y3949_pgtype341;
	Y3949_gen_type [342] = Y3949_pgtype342;
	Y3949_gen_type [343] = Y3949_pgtype343;
	Y3949_gen_type [344] = Y3949_pgtype344;
	Y3949_gen_type [345] = Y3949_pgtype345;
	Y3949_gen_type [346] = Y3949_pgtype346;
	Y3949_gen_type [347] = Y3949_pgtype347;
	Y3949_gen_type [348] = Y3949_pgtype348;
	Y3949_gen_type [349] = Y3949_pgtype349;
	Y3949_gen_type [350] = Y3949_pgtype350;
	Y3949_gen_type [351] = Y3949_pgtype351;
	Y3949_gen_type [352] = Y3949_pgtype352;
	Y3949_gen_type [353] = Y3949_pgtype353;
	Y3949_gen_type [354] = Y3949_pgtype354;
	Y3949_gen_type [355] = Y3949_pgtype355;
	Y3949_gen_type [356] = Y3949_pgtype356;
	Y3949_gen_type [357] = Y3949_pgtype357;
	Y3949_gen_type [358] = Y3949_pgtype358;
	Y3949_gen_type [359] = Y3949_pgtype359;
	Y3949_gen_type [360] = Y3949_pgtype360;
	Y3949_gen_type [361] = Y3949_pgtype361;
	Y3949_gen_type [362] = Y3949_pgtype362;
	Y3949_gen_type [363] = Y3949_pgtype363;
	Y3949_gen_type [364] = Y3949_pgtype364;
	Y3949_gen_type [365] = Y3949_pgtype365;
	Y3949_gen_type [366] = Y3949_pgtype366;
	Y3949_gen_type [367] = Y3949_pgtype367;
	Y3949_gen_type [368] = Y3949_pgtype368;
	Y3949_gen_type [369] = Y3949_pgtype369;
	Y3949_gen_type [370] = Y3949_pgtype370;
	Y3949_gen_type [371] = Y3949_pgtype371;
	Y3949_gen_type [372] = Y3949_pgtype372;
	Y3949_gen_type [373] = Y3949_pgtype373;
	Y3949_gen_type [374] = Y3949_pgtype374;
	Y3949_gen_type [375] = Y3949_pgtype375;
	Y3949_gen_type [376] = Y3949_pgtype376;
	Y3949_gen_type [377] = Y3949_pgtype377;
	Y3949_gen_type [378] = Y3949_pgtype378;
	Y3949_gen_type [379] = Y3949_pgtype379;
	Y3949_gen_type [380] = Y3949_pgtype380;
	Y3949_gen_type [381] = Y3949_pgtype381;
	Y3949_gen_type [382] = Y3949_pgtype382;
	Y3949_gen_type [383] = Y3949_pgtype383;
	Y3949_gen_type [384] = Y3949_pgtype384;
	Y3949_gen_type [385] = Y3949_pgtype385;
	Y3949_gen_type [386] = Y3949_pgtype386;
	Y3949_gen_type [387] = Y3949_pgtype387;
	Y3949_gen_type [388] = Y3949_pgtype388;
	Y3949_gen_type [389] = Y3949_pgtype389;
	Y3949_gen_type [390] = Y3949_pgtype390;
	Y3949_gen_type [391] = Y3949_pgtype391;
	Y3949_gen_type [392] = Y3949_pgtype392;
	Y3949_gen_type [393] = Y3949_pgtype393;
	Y3949_gen_type [394] = Y3949_pgtype394;
	Y3949_gen_type [395] = Y3949_pgtype395;
	Y3949_gen_type [396] = Y3949_pgtype396;
	Y3949_gen_type [397] = Y3949_pgtype397;
	Y3949_gen_type [398] = Y3949_pgtype398;
	Y3949_gen_type [399] = Y3949_pgtype399;
	Y3949_gen_type [400] = Y3949_pgtype400;
	Y3949_gen_type [401] = Y3949_pgtype401;
	Y3949_gen_type [402] = Y3949_pgtype402;
	Y3949_gen_type [403] = Y3949_pgtype403;
	Y3949_gen_type [404] = Y3949_pgtype404;
	Y3949_gen_type [405] = Y3949_pgtype405;
	Y3949_gen_type [406] = Y3949_pgtype406;
	Y3949_gen_type [407] = Y3949_pgtype407;
	Y3949_gen_type [408] = Y3949_pgtype408;
	Y3949_gen_type [409] = Y3949_pgtype409;
	Y3949_gen_type [410] = Y3949_pgtype410;
	Y3949_gen_type [411] = Y3949_pgtype411;
	Y3949_gen_type [412] = Y3949_pgtype412;
	Y3949_gen_type [413] = Y3949_pgtype413;
	Y3949_gen_type [414] = Y3949_pgtype414;
	Y3949_gen_type [415] = Y3949_pgtype415;
	Y3949_gen_type [416] = Y3949_pgtype416;
	Y3949_gen_type [417] = Y3949_pgtype417;
	Y3949_gen_type [418] = Y3949_pgtype418;
	Y3949_gen_type [419] = Y3949_pgtype419;
	Y3949_gen_type [420] = Y3949_pgtype420;
	Y3949_gen_type [421] = Y3949_pgtype421;
	Y3949_gen_type [422] = Y3949_pgtype422;
	Y3949_gen_type [423] = Y3949_pgtype423;
	Y3949_gen_type [424] = Y3949_pgtype424;
	Y3949_gen_type [425] = Y3949_pgtype425;
	Y3949_gen_type [426] = Y3949_pgtype426;
	Y3949_gen_type [427] = Y3949_pgtype427;
	Y3949_gen_type [429] = Y3949_pgtype428;
	Y3949_gen_type [431] = Y3949_pgtype429;
	Y3949_gen_type [432] = Y3949_pgtype430;
	Y3949_gen_type [433] = Y3949_pgtype431;
	Y3949_gen_type [434] = Y3949_pgtype432;
	Y3949_gen_type [435] = Y3949_pgtype433;
	Y3949_gen_type [436] = Y3949_pgtype434;
	Y3949_gen_type [437] = Y3949_pgtype435;
	Y3949_gen_type [438] = Y3949_pgtype436;
	Y3949_gen_type [439] = Y3949_pgtype437;
	Y3949_gen_type [440] = Y3949_pgtype438;
	Y3949_gen_type [441] = Y3949_pgtype439;
	Y3949_gen_type [442] = Y3949_pgtype440;
	Y3949_gen_type [443] = Y3949_pgtype441;
	Y3949_gen_type [444] = Y3949_pgtype442;
	Y3949_gen_type [445] = Y3949_pgtype443;
	Y3949_gen_type [446] = Y3949_pgtype444;
	Y3949_gen_type [447] = Y3949_pgtype445;
	Y3949_gen_type [448] = Y3949_pgtype446;
	Y3949_gen_type [449] = Y3949_pgtype447;
	Y3949_gen_type [450] = Y3949_pgtype448;
	Y3949_gen_type [451] = Y3949_pgtype449;
	Y3949_gen_type [452] = Y3949_pgtype450;
	Y3949_gen_type [453] = Y3949_pgtype451;
	Y3949_gen_type [454] = Y3949_pgtype452;
	Y3949_gen_type [455] = Y3949_pgtype453;
	Y3949_gen_type [456] = Y3949_pgtype454;
	Y3949_gen_type [457] = Y3949_pgtype455;
	Y3949_gen_type [458] = Y3949_pgtype456;
	Y3949_gen_type [459] = Y3949_pgtype457;
	Y3949_gen_type [460] = Y3949_pgtype458;
	Y3949_gen_type [461] = Y3949_pgtype459;
	Y3949_gen_type [462] = Y3949_pgtype460;
	Y3949_gen_type [469] = Y3949_pgtype461;
	Y3949_gen_type [470] = Y3949_pgtype462;
	Y3949_gen_type [471] = Y3949_pgtype463;
	Y3949_gen_type [487] = Y3949_pgtype464;
	Y3949_gen_type [488] = Y3949_pgtype465;
	Y3949_gen_type [489] = Y3949_pgtype466;
	Y3949_gen_type [490] = Y3949_pgtype467;
	Y3949_gen_type [491] = Y3949_pgtype468;
	Y3949_gen_type [492] = Y3949_pgtype469;
	Y3949_gen_type [493] = Y3949_pgtype470;
	Y3949_gen_type [494] = Y3949_pgtype471;
	Y3949_gen_type [495] = Y3949_pgtype472;
	Y3949_gen_type [496] = Y3949_pgtype473;
	Y3949_gen_type [497] = Y3949_pgtype474;
	Y3949_gen_type [498] = Y3949_pgtype475;
	Y3949_gen_type [601] = Y3949_pgtype476;
	Y3949_gen_type [683] = Y3949_pgtype477;
	Y3949_gen_type [684] = Y3949_pgtype478;
	Y3949_gen_type [685] = Y3949_pgtype479;
	Y3949_gen_type [686] = Y3949_pgtype480;
	Y3949_gen_type [687] = Y3949_pgtype481;
	Y3949_gen_type [688] = Y3949_pgtype482;
	Y3949_gen_type [689] = Y3949_pgtype483;
	Y3949_gen_type [693] = Y3949_pgtype484;
	Y3949_gen_type [694] = Y3949_pgtype485;
	Y3949_gen_type [695] = Y3949_pgtype486;
	Y3949_gen_type [701] = Y3949_pgtype487;
	Y3949_gen_type [725] = Y3949_pgtype488;
	Y3949_gen_type [726] = Y3949_pgtype489;
	Y3949_gen_type [727] = Y3949_pgtype490;
	Y3949_gen_type [729] = Y3949_pgtype491;
	Y3949_gen_type [730] = Y3949_pgtype492;
	Y3949_gen_type [731] = Y3949_pgtype493;
	Y3949_gen_type [732] = Y3949_pgtype494;
	Y3949_gen_type [735] = Y3949_pgtype495;
	Y3949_gen_type [848] = Y3949_pgtype496;
	Y3949_gen_type [849] = Y3949_pgtype497;
	Y3949_gen_type [850] = Y3949_pgtype498;
	Y3949_gen_type [851] = Y3949_pgtype499;
	Y3949_gen_type [852] = Y3949_pgtype500;
	Y3949_gen_type [853] = Y3949_pgtype501;
	Y3949_gen_type [854] = Y3949_pgtype502;
	Y3949_gen_type [855] = Y3949_pgtype503;
	Y3949_gen_type [856] = Y3949_pgtype504;
	Y3949_gen_type [857] = Y3949_pgtype505;
	Y3949_gen_type [960] = Y3949_pgtype506;
	Y3949_gen_type [961] = Y3949_pgtype507;
	Y3949[12] = 986;
	Y3949[13] = 1040;
	Y3949[78] = 989;
	Y3949[91] = 986;
	Y3949[116] = 1037;
	Y3949[261] = 959;
	Y3949[353] = 959;
	Y3949[440] = 0;
	Y3949[453] = 23;
	Y3949[457] = 326;
	Y3949[459] = 1027;
	Y3949[462] = 959;
	{long i; for (i = 469; i < 472; i++) Y3949[i] = 989;};
	Y3949[601] = 0;
	{long i; for (i = 683; i < 687; i++) Y3949[i] = 989;};
	{long i; for (i = 687; i < 690; i++) Y3949[i] = 986;};
	Y3949[701] = 989;
	{long i; for (i = 725; i < 728; i++) Y3949[i] = 989;};
	{long i; for (i = 729; i < 733; i++) Y3949[i] = 989;};
	Y3949[735] = 1037;
	Y3949[849] = 1274;
	Y3949[850] = 1133;
	Y3949[851] = 1147;
	Y3949[852] = 1148;
	Y3949[853] = 1137;
	Y3949[854] = 1141;
	Y3949[855] = 1142;
	Y3949[856] = 1135;
	Y3949[857] = 1191;
	{long i; for (i = 960; i < 962; i++) Y3949[i] = 989;};
}

char *(*R3979[72])();
void R3979_init () {
	R3979[0] = (char *(*)()) F397_4871;
	R3979[1] = (char *(*)()) F398_4871;
	R3979[2] = (char *(*)()) F399_4871;
	R3979[3] = (char *(*)()) F400_4871;
	R3979[4] = (char *(*)()) F401_4871;
	R3979[5] = (char *(*)()) F402_4871;
	R3979[6] = (char *(*)()) F403_4871;
	R3979[7] = (char *(*)()) F404_4871;
	R3979[8] = (char *(*)()) F405_4871;
	R3979[9] = (char *(*)()) F406_4871;
	R3979[10] = (char *(*)()) F407_4871;
	R3979[11] = (char *(*)()) F408_4871;
	R3979[12] = (char *(*)()) F397_4871;
	R3979[13] = (char *(*)()) F400_4871;
	R3979[14] = (char *(*)()) F404_4871;
	R3979[15] = (char *(*)()) F397_4871;
	R3979[16] = (char *(*)()) F400_4871;
	R3979[17] = (char *(*)()) F405_4871;
	R3979[18] = (char *(*)()) F397_4871;
	R3979[19] = (char *(*)()) F400_4871;
	R3979[20] = (char *(*)()) F405_4871;
	R3979[21] = (char *(*)()) F397_4871;
	R3979[34] = (char *(*)()) F425_4911;
	R3979[35] = (char *(*)()) F419_4911;
	R3979[36] = (char *(*)()) F420_4911;
	R3979[37] = (char *(*)()) F421_4911;
	R3979[38] = (char *(*)()) F422_4911;
	R3979[39] = (char *(*)()) F423_4911;
	R3979[40] = (char *(*)()) F424_4911;
	R3979[41] = (char *(*)()) F425_4911;
	R3979[42] = (char *(*)()) F426_4911;
	R3979[43] = (char *(*)()) F427_4911;
	R3979[44] = (char *(*)()) F428_4911;
	R3979[45] = (char *(*)()) F429_4911;
	R3979[46] = (char *(*)()) F430_4911;
	R3979[47] = (char *(*)()) F428_4911;
	R3979[48] = (char *(*)()) F419_4911;
	R3979[49] = (char *(*)()) F420_4911;
	R3979[50] = (char *(*)()) F421_4911;
	R3979[51] = (char *(*)()) F422_4911;
	R3979[52] = (char *(*)()) F423_4911;
	R3979[53] = (char *(*)()) F424_4911;
	R3979[54] = (char *(*)()) F425_4911;
	R3979[55] = (char *(*)()) F426_4911;
	R3979[56] = (char *(*)()) F427_4911;
	R3979[57] = (char *(*)()) F428_4911;
	R3979[58] = (char *(*)()) F429_4911;
	R3979[59] = (char *(*)()) F430_4911;
	R3979[60] = (char *(*)()) F419_4911;
	R3979[61] = (char *(*)()) F420_4911;
	R3979[62] = (char *(*)()) F421_4911;
	R3979[63] = (char *(*)()) F422_4911;
	R3979[64] = (char *(*)()) F423_4911;
	R3979[65] = (char *(*)()) F424_4911;
	R3979[66] = (char *(*)()) F425_4911;
	R3979[67] = (char *(*)()) F426_4911;
	R3979[68] = (char *(*)()) F427_4911;
	R3979[69] = (char *(*)()) F428_4911;
	R3979[70] = (char *(*)()) F429_4911;
	R3979[71] = (char *(*)()) F430_4911;
}

char *(*R3980[72])();
void R3980_init () {
	R3980[0] = (char *(*)()) F397_4872;
	R3980[1] = (char *(*)()) F398_4872;
	R3980[2] = (char *(*)()) F399_4872;
	R3980[3] = (char *(*)()) F400_4872;
	R3980[4] = (char *(*)()) F401_4872;
	R3980[5] = (char *(*)()) F402_4872;
	R3980[6] = (char *(*)()) F403_4872;
	R3980[7] = (char *(*)()) F404_4872;
	R3980[8] = (char *(*)()) F405_4872;
	R3980[9] = (char *(*)()) F406_4872;
	R3980[10] = (char *(*)()) F407_4872;
	R3980[11] = (char *(*)()) F408_4872;
	R3980[12] = (char *(*)()) F397_4872;
	R3980[13] = (char *(*)()) F400_4872;
	R3980[14] = (char *(*)()) F404_4872;
	R3980[15] = (char *(*)()) F397_4872;
	R3980[16] = (char *(*)()) F400_4872;
	R3980[17] = (char *(*)()) F405_4872;
	R3980[18] = (char *(*)()) F397_4872;
	R3980[19] = (char *(*)()) F400_4872;
	R3980[20] = (char *(*)()) F405_4872;
	R3980[21] = (char *(*)()) F397_4872;
	R3980[34] = (char *(*)()) F431_4930;
	R3980[35] = (char *(*)()) F432_4936;
	R3980[36] = (char *(*)()) F433_4936;
	R3980[37] = (char *(*)()) F434_4936;
	R3980[38] = (char *(*)()) F435_4936;
	R3980[39] = (char *(*)()) F436_4936;
	R3980[40] = (char *(*)()) F437_4936;
	R3980[41] = (char *(*)()) F438_4936;
	R3980[42] = (char *(*)()) F439_4936;
	R3980[43] = (char *(*)()) F440_4936;
	R3980[44] = (char *(*)()) F441_4936;
	R3980[45] = (char *(*)()) F442_4936;
	R3980[46] = (char *(*)()) F443_4936;
	R3980[47] = (char *(*)()) F444_4942;
	R3980[48] = (char *(*)()) F445_4948;
	R3980[49] = (char *(*)()) F446_4948;
	R3980[50] = (char *(*)()) F447_4948;
	R3980[51] = (char *(*)()) F448_4948;
	R3980[52] = (char *(*)()) F449_4948;
	R3980[53] = (char *(*)()) F450_4948;
	R3980[54] = (char *(*)()) F451_4948;
	R3980[55] = (char *(*)()) F452_4948;
	R3980[56] = (char *(*)()) F453_4948;
	R3980[57] = (char *(*)()) F454_4948;
	R3980[58] = (char *(*)()) F455_4948;
	R3980[59] = (char *(*)()) F456_4948;
	R3980[60] = (char *(*)()) F457_4954;
	R3980[61] = (char *(*)()) F458_4954;
	R3980[62] = (char *(*)()) F459_4954;
	R3980[63] = (char *(*)()) F460_4954;
	R3980[64] = (char *(*)()) F461_4954;
	R3980[65] = (char *(*)()) F462_4954;
	R3980[66] = (char *(*)()) F463_4954;
	R3980[67] = (char *(*)()) F464_4954;
	R3980[68] = (char *(*)()) F465_4954;
	R3980[69] = (char *(*)()) F466_4954;
	R3980[70] = (char *(*)()) F467_4954;
	R3980[71] = (char *(*)()) F468_4954;
}

char *(*R3988[22])();
void R3988_init () {
	R3988[0] = (char *(*)()) F397_4883;
	R3988[1] = (char *(*)()) F398_4883;
	R3988[2] = (char *(*)()) F399_4883;
	R3988[3] = (char *(*)()) F400_4883;
	R3988[4] = (char *(*)()) F401_4883;
	R3988[5] = (char *(*)()) F402_4883;
	R3988[6] = (char *(*)()) F403_4883;
	R3988[7] = (char *(*)()) F404_4883;
	R3988[8] = (char *(*)()) F405_4883;
	R3988[9] = (char *(*)()) F406_4883;
	R3988[10] = (char *(*)()) F407_4883;
	R3988[11] = (char *(*)()) F408_4883;
	R3988[12] = (char *(*)()) F397_4883;
	R3988[13] = (char *(*)()) F400_4883;
	R3988[14] = (char *(*)()) F404_4883;
	R3988[15] = (char *(*)()) F397_4883;
	R3988[16] = (char *(*)()) F400_4883;
	R3988[17] = (char *(*)()) F405_4883;
	R3988[18] = (char *(*)()) F397_4883;
	R3988[19] = (char *(*)()) F400_4883;
	R3988[20] = (char *(*)()) F405_4883;
	R3988[21] = (char *(*)()) F397_4883;
}

char *(*R3991[72])();
void R3991_init () {
	R3991[0] = (char *(*)()) F397_4888;
	R3991[1] = (char *(*)()) F398_4888;
	R3991[2] = (char *(*)()) F399_4888;
	R3991[3] = (char *(*)()) F400_4888;
	R3991[4] = (char *(*)()) F401_4888;
	R3991[5] = (char *(*)()) F402_4888;
	R3991[6] = (char *(*)()) F403_4888;
	R3991[7] = (char *(*)()) F404_4888;
	R3991[8] = (char *(*)()) F405_4888;
	R3991[9] = (char *(*)()) F406_4888;
	R3991[10] = (char *(*)()) F407_4888;
	R3991[11] = (char *(*)()) F408_4888;
	R3991[12] = (char *(*)()) F397_4888;
	R3991[13] = (char *(*)()) F400_4888;
	R3991[14] = (char *(*)()) F404_4888;
	R3991[15] = (char *(*)()) F397_4888;
	R3991[16] = (char *(*)()) F400_4888;
	R3991[17] = (char *(*)()) F405_4888;
	R3991[18] = (char *(*)()) F415_4899;
	R3991[19] = (char *(*)()) F416_4899;
	R3991[20] = (char *(*)()) F417_4899;
	R3991[21] = (char *(*)()) F418_4905;
	R3991[34] = (char *(*)()) F425_4923;
	R3991[35] = (char *(*)()) F419_4923;
	R3991[36] = (char *(*)()) F420_4923;
	R3991[37] = (char *(*)()) F421_4923;
	R3991[38] = (char *(*)()) F422_4923;
	R3991[39] = (char *(*)()) F423_4923;
	R3991[40] = (char *(*)()) F424_4923;
	R3991[41] = (char *(*)()) F425_4923;
	R3991[42] = (char *(*)()) F426_4923;
	R3991[43] = (char *(*)()) F427_4923;
	R3991[44] = (char *(*)()) F428_4923;
	R3991[45] = (char *(*)()) F429_4923;
	R3991[46] = (char *(*)()) F430_4923;
	R3991[47] = (char *(*)()) F428_4923;
	R3991[48] = (char *(*)()) F419_4923;
	R3991[49] = (char *(*)()) F420_4923;
	R3991[50] = (char *(*)()) F421_4923;
	R3991[51] = (char *(*)()) F422_4923;
	R3991[52] = (char *(*)()) F423_4923;
	R3991[53] = (char *(*)()) F424_4923;
	R3991[54] = (char *(*)()) F425_4923;
	R3991[55] = (char *(*)()) F426_4923;
	R3991[56] = (char *(*)()) F427_4923;
	R3991[57] = (char *(*)()) F428_4923;
	R3991[58] = (char *(*)()) F429_4923;
	R3991[59] = (char *(*)()) F430_4923;
	R3991[60] = (char *(*)()) F419_4923;
	R3991[61] = (char *(*)()) F420_4923;
	R3991[62] = (char *(*)()) F421_4923;
	R3991[63] = (char *(*)()) F422_4923;
	R3991[64] = (char *(*)()) F423_4923;
	R3991[65] = (char *(*)()) F424_4923;
	R3991[66] = (char *(*)()) F425_4923;
	R3991[67] = (char *(*)()) F426_4923;
	R3991[68] = (char *(*)()) F427_4923;
	R3991[69] = (char *(*)()) F428_4923;
	R3991[70] = (char *(*)()) F429_4923;
	R3991[71] = (char *(*)()) F430_4923;
}

char *(*R3992[72])();
void R3992_init () {
	R3992[0] = (char *(*)()) F397_4890;
	R3992[1] = (char *(*)()) F398_4890;
	R3992[2] = (char *(*)()) F399_4890;
	R3992[3] = (char *(*)()) F400_4890;
	R3992[4] = (char *(*)()) F401_4890;
	R3992[5] = (char *(*)()) F402_4890;
	R3992[6] = (char *(*)()) F403_4890;
	R3992[7] = (char *(*)()) F404_4890;
	R3992[8] = (char *(*)()) F405_4890;
	R3992[9] = (char *(*)()) F406_4890;
	R3992[10] = (char *(*)()) F407_4890;
	R3992[11] = (char *(*)()) F408_4890;
	R3992[12] = (char *(*)()) F409_4896;
	R3992[13] = (char *(*)()) F410_4896;
	R3992[14] = (char *(*)()) F411_4896;
	R3992[15] = (char *(*)()) F412_4896;
	R3992[16] = (char *(*)()) F413_4896;
	R3992[17] = (char *(*)()) F414_4896;
	R3992[18] = (char *(*)()) F415_4901;
	R3992[19] = (char *(*)()) F416_4901;
	R3992[20] = (char *(*)()) F417_4901;
	R3992[21] = (char *(*)()) F418_4907;
	R3992[34] = (char *(*)()) F431_4933;
	R3992[35] = (char *(*)()) F432_4939;
	R3992[36] = (char *(*)()) F433_4939;
	R3992[37] = (char *(*)()) F434_4939;
	R3992[38] = (char *(*)()) F435_4939;
	R3992[39] = (char *(*)()) F436_4939;
	R3992[40] = (char *(*)()) F437_4939;
	R3992[41] = (char *(*)()) F438_4939;
	R3992[42] = (char *(*)()) F439_4939;
	R3992[43] = (char *(*)()) F440_4939;
	R3992[44] = (char *(*)()) F441_4939;
	R3992[45] = (char *(*)()) F442_4939;
	R3992[46] = (char *(*)()) F443_4939;
	R3992[47] = (char *(*)()) F444_4945;
	R3992[48] = (char *(*)()) F445_4951;
	R3992[49] = (char *(*)()) F446_4951;
	R3992[50] = (char *(*)()) F447_4951;
	R3992[51] = (char *(*)()) F448_4951;
	R3992[52] = (char *(*)()) F449_4951;
	R3992[53] = (char *(*)()) F450_4951;
	R3992[54] = (char *(*)()) F451_4951;
	R3992[55] = (char *(*)()) F452_4951;
	R3992[56] = (char *(*)()) F453_4951;
	R3992[57] = (char *(*)()) F454_4951;
	R3992[58] = (char *(*)()) F455_4951;
	R3992[59] = (char *(*)()) F456_4951;
	R3992[60] = (char *(*)()) F419_4925;
	R3992[61] = (char *(*)()) F420_4925;
	R3992[62] = (char *(*)()) F421_4925;
	R3992[63] = (char *(*)()) F422_4925;
	R3992[64] = (char *(*)()) F423_4925;
	R3992[65] = (char *(*)()) F424_4925;
	R3992[66] = (char *(*)()) F425_4925;
	R3992[67] = (char *(*)()) F426_4925;
	R3992[68] = (char *(*)()) F427_4925;
	R3992[69] = (char *(*)()) F428_4925;
	R3992[70] = (char *(*)()) F429_4925;
	R3992[71] = (char *(*)()) F430_4925;
}

char *(*R3994[22])();
void R3994_init () {
	R3994[0] = (char *(*)()) F397_4869;
	R3994[1] = (char *(*)()) F398_4869;
	R3994[2] = (char *(*)()) F399_4869;
	R3994[3] = (char *(*)()) F400_4869;
	R3994[4] = (char *(*)()) F401_4869;
	R3994[5] = (char *(*)()) F402_4869;
	R3994[6] = (char *(*)()) F403_4869;
	R3994[7] = (char *(*)()) F404_4869;
	R3994[8] = (char *(*)()) F405_4869;
	R3994[9] = (char *(*)()) F406_4869;
	R3994[10] = (char *(*)()) F407_4869;
	R3994[11] = (char *(*)()) F408_4869;
	R3994[12] = (char *(*)()) F397_4869;
	R3994[13] = (char *(*)()) F400_4869;
	R3994[14] = (char *(*)()) F404_4869;
	R3994[15] = (char *(*)()) F397_4869;
	R3994[16] = (char *(*)()) F400_4869;
	R3994[17] = (char *(*)()) F405_4869;
	R3994[18] = (char *(*)()) F397_4869;
	R3994[19] = (char *(*)()) F400_4869;
	R3994[20] = (char *(*)()) F405_4869;
	R3994[21] = (char *(*)()) F397_4869;
}

char *(*R4007[38])();
void R4007_init () {
	R4007[0] = (char *(*)()) F431_4934;
	R4007[1] = (char *(*)()) F432_4940;
	R4007[2] = (char *(*)()) F433_4940;
	R4007[3] = (char *(*)()) F434_4940;
	R4007[4] = (char *(*)()) F435_4940;
	R4007[5] = (char *(*)()) F436_4940;
	R4007[6] = (char *(*)()) F437_4940;
	R4007[7] = (char *(*)()) F438_4940;
	R4007[8] = (char *(*)()) F439_4940;
	R4007[9] = (char *(*)()) F440_4940;
	R4007[10] = (char *(*)()) F441_4940;
	R4007[11] = (char *(*)()) F442_4940;
	R4007[12] = (char *(*)()) F443_4940;
	R4007[13] = (char *(*)()) F444_4946;
	R4007[14] = (char *(*)()) F445_4952;
	R4007[15] = (char *(*)()) F446_4952;
	R4007[16] = (char *(*)()) F447_4952;
	R4007[17] = (char *(*)()) F448_4952;
	R4007[18] = (char *(*)()) F449_4952;
	R4007[19] = (char *(*)()) F450_4952;
	R4007[20] = (char *(*)()) F451_4952;
	R4007[21] = (char *(*)()) F452_4952;
	R4007[22] = (char *(*)()) F453_4952;
	R4007[23] = (char *(*)()) F454_4952;
	R4007[24] = (char *(*)()) F455_4952;
	R4007[25] = (char *(*)()) F456_4952;
	R4007[26] = (char *(*)()) F457_4956;
	R4007[27] = (char *(*)()) F458_4956;
	R4007[28] = (char *(*)()) F459_4956;
	R4007[29] = (char *(*)()) F460_4956;
	R4007[30] = (char *(*)()) F461_4956;
	R4007[31] = (char *(*)()) F462_4956;
	R4007[32] = (char *(*)()) F463_4956;
	R4007[33] = (char *(*)()) F464_4956;
	R4007[34] = (char *(*)()) F465_4956;
	R4007[35] = (char *(*)()) F466_4956;
	R4007[36] = (char *(*)()) F467_4956;
	R4007[37] = (char *(*)()) F468_4956;
}

char *(*R4012[12])();
void R4012_init () {
	R4012[0] = (char *(*)()) F432_4935;
	R4012[1] = (char *(*)()) F433_4935;
	R4012[2] = (char *(*)()) F434_4935;
	R4012[3] = (char *(*)()) F435_4935;
	R4012[4] = (char *(*)()) F436_4935;
	R4012[5] = (char *(*)()) F437_4935;
	R4012[6] = (char *(*)()) F438_4935;
	R4012[7] = (char *(*)()) F439_4935;
	R4012[8] = (char *(*)()) F440_4935;
	R4012[9] = (char *(*)()) F441_4935;
	R4012[10] = (char *(*)()) F442_4935;
	R4012[11] = (char *(*)()) F443_4935;
}

char *(*R4017[12])();
void R4017_init () {
	R4017[0] = (char *(*)()) F445_4947;
	R4017[1] = (char *(*)()) F446_4947;
	R4017[2] = (char *(*)()) F447_4947;
	R4017[3] = (char *(*)()) F448_4947;
	R4017[4] = (char *(*)()) F449_4947;
	R4017[5] = (char *(*)()) F450_4947;
	R4017[6] = (char *(*)()) F451_4947;
	R4017[7] = (char *(*)()) F452_4947;
	R4017[8] = (char *(*)()) F453_4947;
	R4017[9] = (char *(*)()) F454_4947;
	R4017[10] = (char *(*)()) F455_4947;
	R4017[11] = (char *(*)()) F456_4947;
}

char *(*R4020[12])();
void R4020_init () {
	R4020[0] = (char *(*)()) F457_4953;
	R4020[1] = (char *(*)()) F458_4953;
	R4020[2] = (char *(*)()) F459_4953;
	R4020[3] = (char *(*)()) F460_4953;
	R4020[4] = (char *(*)()) F461_4953;
	R4020[5] = (char *(*)()) F462_4953;
	R4020[6] = (char *(*)()) F463_4953;
	R4020[7] = (char *(*)()) F464_4953;
	R4020[8] = (char *(*)()) F465_4953;
	R4020[9] = (char *(*)()) F466_4953;
	R4020[10] = (char *(*)()) F467_4953;
	R4020[11] = (char *(*)()) F468_4953;
}

char *(*R4044[700])();
void R4044_init () {
	R4044[0] = (char *(*)()) F614_5077_4044_2;
	R4044[160] = (char *(*)()) F724_5221;
	R4044[161] = (char *(*)()) F727_5221_4044_2;
	R4044[162] = (char *(*)()) F731_5221_4044_2;
	R4044[166] = (char *(*)()) F760_5261;
	R4044[180] = (char *(*)()) F794_5583;
	R4044[181] = (char *(*)()) F795_5583_4044_2;
	R4044[182] = (char *(*)()) F796_5583_4044_2;
	R4044[183] = (char *(*)()) F797_5583_4044_2;
	R4044[184] = (char *(*)()) F798_5583_4044_2;
	R4044[185] = (char *(*)()) F799_5583_4044_2;
	R4044[186] = (char *(*)()) F800_5583_4044_2;
	R4044[187] = (char *(*)()) F801_5583_4044_2;
	R4044[188] = (char *(*)()) F802_5583_4044_2;
	R4044[189] = (char *(*)()) F803_5583_4044_2;
	R4044[190] = (char *(*)()) F804_5583_4044_2;
	R4044[191] = (char *(*)()) F805_5583_4044_2;
	R4044[193] = (char *(*)()) F794_5583;
	R4044[194] = (char *(*)()) F797_5583_4044_2;
	R4044[195] = (char *(*)()) F801_5583_4044_2;
	R4044[196] = (char *(*)()) F794_5583;
	{long i; for (i = 198; i < 200; i++) R4044[i] = (char *(*)()) F794_5583;}
	{long i; for (i = 200; i < 202; i++) R4044[i] = (char *(*)()) F797_5583_4044_2;}
	{long i; for (i = 209; i < 211; i++) R4044[i] = (char *(*)()) F498_4997_4044_2;}
	R4044[424] = (char *(*)()) F1036_8255_4044_2;
	R4044[428] = (char *(*)()) F1040_8420_4044_2;
	R4044[440] = (char *(*)()) F498_4997_4044_2;
	{long i; for (i = 587; i < 597; i++) R4044[i] = (char *(*)()) F794_5583;}
	R4044[699] = (char *(*)()) F1313_13972_4044_2;
}
static EIF_BOOLEAN F614_5077_4044_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F614_5077(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F727_5221_4044_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F727_5221(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F731_5221_4044_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F731_5221(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F795_5583_4044_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F795_5583(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F796_5583_4044_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F796_5583(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F797_5583_4044_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F797_5583(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F798_5583_4044_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F798_5583(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F799_5583_4044_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F799_5583(Current, *(EIF_POINTER *)arg1);
}
static EIF_BOOLEAN F800_5583_4044_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F800_5583(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F801_5583_4044_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F801_5583(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F802_5583_4044_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F802_5583(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F803_5583_4044_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F803_5583(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F804_5583_4044_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F804_5583(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F805_5583_4044_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F805_5583(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F498_4997_4044_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F498_4997(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F1036_8255_4044_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1036_8255(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F1040_8420_4044_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1040_8420(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F1313_13972_4044_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1313_13972(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4045[700])();
void R4045_init () {
	R4045[0] = (char *(*)()) F611_5051;
	R4045[93] = (char *(*)()) F615_5084;
	R4045[94] = (char *(*)()) F616_5084;
	R4045[95] = (char *(*)()) F617_5084;
	R4045[96] = (char *(*)()) F618_5084;
	R4045[97] = (char *(*)()) F621_5084;
	R4045[98] = (char *(*)()) F622_5084;
	R4045[99] = (char *(*)()) F619_5084;
	R4045[100] = (char *(*)()) F623_5084;
	R4045[101] = (char *(*)()) F624_5084;
	R4045[102] = (char *(*)()) F620_5084;
	R4045[103] = (char *(*)()) F625_5084;
	R4045[104] = (char *(*)()) F626_5084;
	R4045[160] = (char *(*)()) F615_5084;
	R4045[161] = (char *(*)()) F618_5084;
	R4045[162] = (char *(*)()) F623_5084;
	R4045[166] = (char *(*)()) F615_5084;
	R4045[170] = (char *(*)()) F615_5084;
	R4045[171] = (char *(*)()) F618_5084;
	R4045[172] = (char *(*)()) F622_5084;
	R4045[173] = (char *(*)()) F615_5084;
	R4045[174] = (char *(*)()) F618_5084;
	R4045[175] = (char *(*)()) F623_5084;
	R4045[176] = (char *(*)()) F615_5084;
	R4045[177] = (char *(*)()) F623_5084;
	R4045[178] = (char *(*)()) F618_5084;
	{long i; for (i = 179; i < 181; i++) R4045[i] = (char *(*)()) F615_5084;}
	R4045[181] = (char *(*)()) F616_5084;
	R4045[182] = (char *(*)()) F617_5084;
	R4045[183] = (char *(*)()) F618_5084;
	R4045[184] = (char *(*)()) F621_5084;
	R4045[185] = (char *(*)()) F622_5084;
	R4045[186] = (char *(*)()) F619_5084;
	R4045[187] = (char *(*)()) F623_5084;
	R4045[188] = (char *(*)()) F624_5084;
	R4045[189] = (char *(*)()) F620_5084;
	R4045[190] = (char *(*)()) F625_5084;
	R4045[191] = (char *(*)()) F626_5084;
	R4045[193] = (char *(*)()) F615_5084;
	R4045[194] = (char *(*)()) F618_5084;
	R4045[195] = (char *(*)()) F623_5084;
	R4045[196] = (char *(*)()) F615_5084;
	{long i; for (i = 198; i < 200; i++) R4045[i] = (char *(*)()) F615_5084;}
	{long i; for (i = 200; i < 202; i++) R4045[i] = (char *(*)()) F618_5084;}
	{long i; for (i = 209; i < 211; i++) R4045[i] = (char *(*)()) F619_5084;}
	R4045[424] = (char *(*)()) F619_5084;
	R4045[428] = (char *(*)()) F620_5084;
	R4045[440] = (char *(*)()) F1054_8676;
	{long i; for (i = 587; i < 597; i++) R4045[i] = (char *(*)()) F615_5084;}
	R4045[699] = (char *(*)()) F619_5084;
}

char *(*R4049[700])();
void R4049_init () {
	R4049[0] = (char *(*)()) F473_4986;
	R4049[93] = (char *(*)()) F470_4986;
	R4049[94] = (char *(*)()) F471_4986;
	R4049[95] = (char *(*)()) F472_4986;
	R4049[96] = (char *(*)()) F473_4986;
	R4049[97] = (char *(*)()) F476_4986;
	R4049[98] = (char *(*)()) F477_4986;
	R4049[99] = (char *(*)()) F474_4986;
	R4049[100] = (char *(*)()) F478_4986;
	R4049[101] = (char *(*)()) F479_4986;
	R4049[102] = (char *(*)()) F475_4986;
	R4049[103] = (char *(*)()) F480_4986;
	R4049[104] = (char *(*)()) F481_4986;
	R4049[160] = (char *(*)()) F470_4986;
	R4049[161] = (char *(*)()) F473_4986;
	R4049[162] = (char *(*)()) F478_4986;
	R4049[166] = (char *(*)()) F470_4986;
	R4049[170] = (char *(*)()) F470_4986;
	R4049[171] = (char *(*)()) F473_4986;
	R4049[172] = (char *(*)()) F477_4986;
	R4049[173] = (char *(*)()) F470_4986;
	R4049[174] = (char *(*)()) F473_4986;
	R4049[175] = (char *(*)()) F478_4986;
	R4049[176] = (char *(*)()) F470_4986;
	R4049[177] = (char *(*)()) F478_4986;
	R4049[178] = (char *(*)()) F473_4986;
	{long i; for (i = 179; i < 181; i++) R4049[i] = (char *(*)()) F470_4986;}
	R4049[181] = (char *(*)()) F471_4986;
	R4049[182] = (char *(*)()) F472_4986;
	R4049[183] = (char *(*)()) F473_4986;
	R4049[184] = (char *(*)()) F476_4986;
	R4049[185] = (char *(*)()) F477_4986;
	R4049[186] = (char *(*)()) F474_4986;
	R4049[187] = (char *(*)()) F478_4986;
	R4049[188] = (char *(*)()) F479_4986;
	R4049[189] = (char *(*)()) F475_4986;
	R4049[190] = (char *(*)()) F480_4986;
	R4049[191] = (char *(*)()) F481_4986;
	R4049[193] = (char *(*)()) F470_4986;
	R4049[194] = (char *(*)()) F473_4986;
	R4049[195] = (char *(*)()) F478_4986;
	R4049[196] = (char *(*)()) F470_4986;
	{long i; for (i = 198; i < 200; i++) R4049[i] = (char *(*)()) F470_4986;}
	{long i; for (i = 200; i < 202; i++) R4049[i] = (char *(*)()) F473_4986;}
	{long i; for (i = 209; i < 211; i++) R4049[i] = (char *(*)()) F474_4986;}
	R4049[424] = (char *(*)()) F474_4986;
	R4049[428] = (char *(*)()) F475_4986;
	R4049[440] = (char *(*)()) F474_4986;
	{long i; for (i = 587; i < 597; i++) R4049[i] = (char *(*)()) F470_4986;}
	R4049[699] = (char *(*)()) F474_4986;
}

char *(*R4052[700])();
void R4052_init () {
	R4052[0] = (char *(*)()) F473_4989;
	R4052[93] = (char *(*)()) F470_4989;
	R4052[94] = (char *(*)()) F471_4989;
	R4052[95] = (char *(*)()) F472_4989;
	R4052[96] = (char *(*)()) F473_4989;
	R4052[97] = (char *(*)()) F476_4989;
	R4052[98] = (char *(*)()) F477_4989;
	R4052[99] = (char *(*)()) F474_4989;
	R4052[100] = (char *(*)()) F478_4989;
	R4052[101] = (char *(*)()) F479_4989;
	R4052[102] = (char *(*)()) F475_4989;
	R4052[103] = (char *(*)()) F480_4989;
	R4052[104] = (char *(*)()) F481_4989;
	R4052[160] = (char *(*)()) F470_4989;
	R4052[161] = (char *(*)()) F473_4989;
	R4052[162] = (char *(*)()) F478_4989;
	R4052[166] = (char *(*)()) F470_4989;
	R4052[170] = (char *(*)()) F470_4989;
	R4052[171] = (char *(*)()) F473_4989;
	R4052[172] = (char *(*)()) F477_4989;
	R4052[173] = (char *(*)()) F470_4989;
	R4052[174] = (char *(*)()) F473_4989;
	R4052[175] = (char *(*)()) F478_4989;
	R4052[176] = (char *(*)()) F470_4989;
	R4052[177] = (char *(*)()) F478_4989;
	R4052[178] = (char *(*)()) F473_4989;
	{long i; for (i = 179; i < 181; i++) R4052[i] = (char *(*)()) F470_4989;}
	R4052[181] = (char *(*)()) F471_4989;
	R4052[182] = (char *(*)()) F472_4989;
	R4052[183] = (char *(*)()) F473_4989;
	R4052[184] = (char *(*)()) F476_4989;
	R4052[185] = (char *(*)()) F477_4989;
	R4052[186] = (char *(*)()) F474_4989;
	R4052[187] = (char *(*)()) F478_4989;
	R4052[188] = (char *(*)()) F479_4989;
	R4052[189] = (char *(*)()) F475_4989;
	R4052[190] = (char *(*)()) F480_4989;
	R4052[191] = (char *(*)()) F481_4989;
	R4052[193] = (char *(*)()) F470_4989;
	R4052[194] = (char *(*)()) F473_4989;
	R4052[195] = (char *(*)()) F478_4989;
	R4052[196] = (char *(*)()) F470_4989;
	{long i; for (i = 198; i < 200; i++) R4052[i] = (char *(*)()) F470_4989;}
	{long i; for (i = 200; i < 202; i++) R4052[i] = (char *(*)()) F473_4989;}
	{long i; for (i = 209; i < 211; i++) R4052[i] = (char *(*)()) F474_4989;}
	R4052[424] = (char *(*)()) F474_4989;
	R4052[428] = (char *(*)()) F475_4989;
	R4052[440] = (char *(*)()) F474_4989;
	{long i; for (i = 587; i < 597; i++) R4052[i] = (char *(*)()) F470_4989;}
	R4052[699] = (char *(*)()) F474_4989;
}

char *(*R4053[597])();
void R4053_init () {
	R4053[0] = (char *(*)()) F613_5055_4053_1;
	R4053[160] = (char *(*)()) F774_5280;
	R4053[161] = (char *(*)()) F775_5280_4053_1;
	R4053[162] = (char *(*)()) F776_5280_4053_1;
	R4053[166] = (char *(*)()) F774_5280;
	R4053[180] = (char *(*)()) F794_5576;
	R4053[181] = (char *(*)()) F795_5576_4053_1;
	R4053[182] = (char *(*)()) F796_5576_4053_1;
	R4053[183] = (char *(*)()) F797_5576_4053_1;
	R4053[184] = (char *(*)()) F798_5576_4053_1;
	R4053[185] = (char *(*)()) F799_5576_4053_1;
	R4053[186] = (char *(*)()) F800_5576_4053_1;
	R4053[187] = (char *(*)()) F801_5576_4053_1;
	R4053[188] = (char *(*)()) F802_5576_4053_1;
	R4053[189] = (char *(*)()) F803_5576_4053_1;
	R4053[190] = (char *(*)()) F804_5576_4053_1;
	R4053[191] = (char *(*)()) F805_5576_4053_1;
	R4053[193] = (char *(*)()) F794_5576;
	R4053[194] = (char *(*)()) F797_5576_4053_1;
	R4053[195] = (char *(*)()) F801_5576_4053_1;
	R4053[196] = (char *(*)()) F794_5576;
	{long i; for (i = 198; i < 200; i++) R4053[i] = (char *(*)()) F794_5576;}
	{long i; for (i = 200; i < 202; i++) R4053[i] = (char *(*)()) F797_5576_4053_1;}
	{long i; for (i = 209; i < 211; i++) R4053[i] = (char *(*)()) F822_5916_4053_1;}
	R4053[440] = (char *(*)()) F822_5916_4053_1;
	{long i; for (i = 587; i < 597; i++) R4053[i] = (char *(*)()) F794_5576;}
}
static EIF_REFERENCE F613_5055_4053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F613_5055(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F775_5280_4053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F775_5280(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F776_5280_4053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F776_5280(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F795_5576_4053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F795_5576(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(977, 0x00).id, 977, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F796_5576_4053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F796_5576(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(968, 0x00).id, 968, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F797_5576_4053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F797_5576(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F798_5576_4053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F798_5576(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(974, 0x00).id, 974, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F799_5576_4053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F799_5576(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1025, 0x00).id, 1025, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F800_5576_4053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F800_5576(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(989, 0x00).id, 989, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F801_5576_4053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F801_5576(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F802_5576_4053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F802_5576(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(971, 0x00).id, 971, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F803_5576_4053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F803_5576(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(986, 0x00).id, 986, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F804_5576_4053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F804_5576(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(980, 0x00).id, 980, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F805_5576_4053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F805_5576(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(983, 0x00).id, 983, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F822_5916_4053_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F822_5916(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(989, 0x00).id, 989, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R4054[597])();
void R4054_init () {
	R4054[0] = (char *(*)()) F497_5005;
	R4054[160] = (char *(*)()) F774_5291;
	R4054[161] = (char *(*)()) F775_5291;
	R4054[162] = (char *(*)()) F776_5291;
	R4054[166] = (char *(*)()) F774_5291;
	R4054[180] = (char *(*)()) F724_5234;
	R4054[181] = (char *(*)()) F725_5234;
	R4054[182] = (char *(*)()) F726_5234;
	R4054[183] = (char *(*)()) F727_5234;
	R4054[184] = (char *(*)()) F728_5234;
	R4054[185] = (char *(*)()) F729_5234;
	R4054[186] = (char *(*)()) F730_5234;
	R4054[187] = (char *(*)()) F731_5234;
	R4054[188] = (char *(*)()) F732_5234;
	R4054[189] = (char *(*)()) F733_5234;
	R4054[190] = (char *(*)()) F734_5234;
	R4054[191] = (char *(*)()) F735_5234;
	R4054[193] = (char *(*)()) F724_5234;
	R4054[194] = (char *(*)()) F727_5234;
	R4054[195] = (char *(*)()) F731_5234;
	R4054[196] = (char *(*)()) F724_5234;
	{long i; for (i = 198; i < 200; i++) R4054[i] = (char *(*)()) F724_5234;}
	{long i; for (i = 200; i < 202; i++) R4054[i] = (char *(*)()) F727_5234;}
	{long i; for (i = 209; i < 211; i++) R4054[i] = (char *(*)()) F822_5937;}
	R4054[440] = (char *(*)()) F822_5937;
	{long i; for (i = 587; i < 597; i++) R4054[i] = (char *(*)()) F724_5234;}
}

char *(*R4055[597])();
void R4055_init () {
	R4055[0] = (char *(*)()) F613_5063;
	R4055[160] = (char *(*)()) F774_5297;
	R4055[161] = (char *(*)()) F775_5297;
	R4055[162] = (char *(*)()) F776_5297;
	R4055[166] = (char *(*)()) F774_5297;
	R4055[180] = (char *(*)()) F794_5602;
	R4055[181] = (char *(*)()) F795_5602;
	R4055[182] = (char *(*)()) F796_5602;
	R4055[183] = (char *(*)()) F797_5602;
	R4055[184] = (char *(*)()) F798_5602;
	R4055[185] = (char *(*)()) F799_5602;
	R4055[186] = (char *(*)()) F800_5602;
	R4055[187] = (char *(*)()) F801_5602;
	R4055[188] = (char *(*)()) F802_5602;
	R4055[189] = (char *(*)()) F803_5602;
	R4055[190] = (char *(*)()) F804_5602;
	R4055[191] = (char *(*)()) F805_5602;
	R4055[193] = (char *(*)()) F794_5602;
	R4055[194] = (char *(*)()) F797_5602;
	R4055[195] = (char *(*)()) F801_5602;
	R4055[196] = (char *(*)()) F794_5602;
	{long i; for (i = 198; i < 200; i++) R4055[i] = (char *(*)()) F794_5602;}
	{long i; for (i = 200; i < 202; i++) R4055[i] = (char *(*)()) F797_5602;}
	{long i; for (i = 209; i < 211; i++) R4055[i] = (char *(*)()) F822_5992;}
	R4055[440] = (char *(*)()) F822_5992;
	{long i; for (i = 587; i < 597; i++) R4055[i] = (char *(*)()) F794_5602;}
}

char *(*R4061[597])();
void R4061_init () {
	R4061[0] = (char *(*)()) F497_4999_4061_4;
	R4061[160] = (char *(*)()) F506_5016;
	R4061[161] = (char *(*)()) F509_5016_4061_4;
	R4061[162] = (char *(*)()) F513_5016_4061_4;
	R4061[166] = (char *(*)()) F506_5016;
	R4061[180] = (char *(*)()) F794_5608;
	R4061[181] = (char *(*)()) F795_5608_4061_4;
	R4061[182] = (char *(*)()) F796_5608_4061_4;
	R4061[183] = (char *(*)()) F797_5608_4061_4;
	R4061[184] = (char *(*)()) F798_5608_4061_4;
	R4061[185] = (char *(*)()) F799_5608_4061_4;
	R4061[186] = (char *(*)()) F800_5608_4061_4;
	R4061[187] = (char *(*)()) F801_5608_4061_4;
	R4061[188] = (char *(*)()) F802_5608_4061_4;
	R4061[189] = (char *(*)()) F803_5608_4061_4;
	R4061[190] = (char *(*)()) F804_5608_4061_4;
	R4061[191] = (char *(*)()) F805_5608_4061_4;
	R4061[193] = (char *(*)()) F794_5608;
	R4061[194] = (char *(*)()) F797_5608_4061_4;
	R4061[195] = (char *(*)()) F801_5608_4061_4;
	R4061[196] = (char *(*)()) F794_5608;
	{long i; for (i = 198; i < 200; i++) R4061[i] = (char *(*)()) F794_5608;}
	{long i; for (i = 200; i < 202; i++) R4061[i] = (char *(*)()) F797_5608_4061_4;}
	{long i; for (i = 209; i < 211; i++) R4061[i] = (char *(*)()) F512_5016_4061_4;}
	R4061[440] = (char *(*)()) F512_5016_4061_4;
	{long i; for (i = 587; i < 597; i++) R4061[i] = (char *(*)()) F794_5608;}
}
static void F497_4999_4061_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F497_4999(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F509_5016_4061_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F509_5016(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F513_5016_4061_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F513_5016(Current, *(EIF_BOOLEAN *)arg1);
}
static void F795_5608_4061_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F795_5608(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F796_5608_4061_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F796_5608(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F797_5608_4061_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F797_5608(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F798_5608_4061_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F798_5608(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F799_5608_4061_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F799_5608(Current, *(EIF_POINTER *)arg1);
}
static void F800_5608_4061_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F800_5608(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F801_5608_4061_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F801_5608(Current, *(EIF_BOOLEAN *)arg1);
}
static void F802_5608_4061_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F802_5608(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F803_5608_4061_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F803_5608(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F804_5608_4061_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F804_5608(Current, *(EIF_REAL_32 *)arg1);
}
static void F805_5608_4061_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F805_5608(Current, *(EIF_REAL_64 *)arg1);
}
static void F512_5016_4061_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F512_5016(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4062[597])();
void R4062_init () {
	R4062[0] = (char *(*)()) F613_5054;
	R4062[160] = (char *(*)()) F774_5283;
	R4062[161] = (char *(*)()) F775_5283;
	R4062[162] = (char *(*)()) F776_5283;
	R4062[166] = (char *(*)()) F774_5283;
	R4062[180] = (char *(*)()) F794_5581;
	R4062[181] = (char *(*)()) F795_5581;
	R4062[182] = (char *(*)()) F796_5581;
	R4062[183] = (char *(*)()) F797_5581;
	R4062[184] = (char *(*)()) F798_5581;
	R4062[185] = (char *(*)()) F799_5581;
	R4062[186] = (char *(*)()) F800_5581;
	R4062[187] = (char *(*)()) F801_5581;
	R4062[188] = (char *(*)()) F802_5581;
	R4062[189] = (char *(*)()) F803_5581;
	R4062[190] = (char *(*)()) F804_5581;
	R4062[191] = (char *(*)()) F805_5581;
	R4062[193] = (char *(*)()) F794_5581;
	R4062[194] = (char *(*)()) F797_5581;
	R4062[195] = (char *(*)()) F801_5581;
	R4062[196] = (char *(*)()) F794_5581;
	{long i; for (i = 198; i < 200; i++) R4062[i] = (char *(*)()) F794_5581;}
	{long i; for (i = 200; i < 202; i++) R4062[i] = (char *(*)()) F797_5581;}
	{long i; for (i = 587; i < 597; i++) R4062[i] = (char *(*)()) F794_5581;}
}

char *(*R4065[597])();
void R4065_init () {
	R4065[0] = (char *(*)()) F497_5003;
	R4065[160] = (char *(*)()) F494_5003;
	R4065[161] = (char *(*)()) F497_5003;
	R4065[162] = (char *(*)()) F502_5003;
	R4065[166] = (char *(*)()) F494_5003;
	R4065[180] = (char *(*)()) F494_5003;
	R4065[181] = (char *(*)()) F495_5003;
	R4065[182] = (char *(*)()) F496_5003;
	R4065[183] = (char *(*)()) F497_5003;
	R4065[184] = (char *(*)()) F500_5003;
	R4065[185] = (char *(*)()) F501_5003;
	R4065[186] = (char *(*)()) F498_5003;
	R4065[187] = (char *(*)()) F502_5003;
	R4065[188] = (char *(*)()) F503_5003;
	R4065[189] = (char *(*)()) F499_5003;
	R4065[190] = (char *(*)()) F504_5003;
	R4065[191] = (char *(*)()) F505_5003;
	R4065[193] = (char *(*)()) F494_5003;
	R4065[194] = (char *(*)()) F497_5003;
	R4065[195] = (char *(*)()) F502_5003;
	R4065[196] = (char *(*)()) F494_5003;
	{long i; for (i = 198; i < 200; i++) R4065[i] = (char *(*)()) F494_5003;}
	{long i; for (i = 200; i < 202; i++) R4065[i] = (char *(*)()) F497_5003;}
	{long i; for (i = 209; i < 211; i++) R4065[i] = (char *(*)()) F498_5003;}
	R4065[440] = (char *(*)()) F498_5003;
	{long i; for (i = 587; i < 597; i++) R4065[i] = (char *(*)()) F494_5003;}
}

char *(*R4066[597])();
void R4066_init () {
	R4066[0] = (char *(*)()) F613_5056;
	R4066[160] = (char *(*)()) F774_5289;
	R4066[161] = (char *(*)()) F775_5289;
	R4066[162] = (char *(*)()) F776_5289;
	R4066[166] = (char *(*)()) F774_5289;
	R4066[180] = (char *(*)()) F748_5258;
	R4066[181] = (char *(*)()) F749_5258;
	R4066[182] = (char *(*)()) F750_5258;
	R4066[183] = (char *(*)()) F751_5258;
	R4066[184] = (char *(*)()) F752_5258;
	R4066[185] = (char *(*)()) F753_5258;
	R4066[186] = (char *(*)()) F754_5258;
	R4066[187] = (char *(*)()) F755_5258;
	R4066[188] = (char *(*)()) F756_5258;
	R4066[189] = (char *(*)()) F757_5258;
	R4066[190] = (char *(*)()) F758_5258;
	R4066[191] = (char *(*)()) F759_5258;
	R4066[193] = (char *(*)()) F748_5258;
	R4066[194] = (char *(*)()) F751_5258;
	R4066[195] = (char *(*)()) F755_5258;
	R4066[196] = (char *(*)()) F748_5258;
	{long i; for (i = 198; i < 200; i++) R4066[i] = (char *(*)()) F748_5258;}
	{long i; for (i = 200; i < 202; i++) R4066[i] = (char *(*)()) F751_5258;}
	{long i; for (i = 209; i < 211; i++) R4066[i] = (char *(*)()) F822_5935;}
	R4066[440] = (char *(*)()) F822_5935;
	{long i; for (i = 587; i < 597; i++) R4066[i] = (char *(*)()) F748_5258;}
}


#ifdef __cplusplus
}
#endif
