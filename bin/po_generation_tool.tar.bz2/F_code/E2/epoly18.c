#include "epoly18.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4116[520])();
void R4116_init () {
	R4116[0] = (char *(*)()) F794_5619;
	R4116[1] = (char *(*)()) F795_5619;
	R4116[2] = (char *(*)()) F796_5619;
	R4116[3] = (char *(*)()) F797_5619;
	R4116[4] = (char *(*)()) F798_5619;
	R4116[5] = (char *(*)()) F799_5619;
	R4116[6] = (char *(*)()) F800_5619;
	R4116[7] = (char *(*)()) F801_5619;
	R4116[8] = (char *(*)()) F802_5619;
	R4116[9] = (char *(*)()) F803_5619;
	R4116[10] = (char *(*)()) F804_5619;
	R4116[11] = (char *(*)()) F805_5619;
	R4116[13] = (char *(*)()) F794_5619;
	R4116[14] = (char *(*)()) F797_5619;
	R4116[15] = (char *(*)()) F801_5619;
	R4116[16] = (char *(*)()) F794_5619;
	{long i; for (i = 18; i < 20; i++) R4116[i] = (char *(*)()) F794_5619;}
	{long i; for (i = 20; i < 22; i++) R4116[i] = (char *(*)()) F797_5619;}
	R4116[244] = (char *(*)()) F1038_8366;
	R4116[248] = (char *(*)()) F1042_8534;
	{long i; for (i = 407; i < 417; i++) R4116[i] = (char *(*)()) F794_5619;}
	R4116[519] = (char *(*)()) F1038_8366;
}

char *(*R4122[607])();
void R4122_init () {
	R4122[0] = (char *(*)()) F707_5165;
	R4122[1] = (char *(*)()) F708_5165_4122_21;
	R4122[2] = (char *(*)()) F709_5165_4122_21;
	R4122[3] = (char *(*)()) F710_5165_4122_21;
	R4122[4] = (char *(*)()) F711_5165_4122_21;
	R4122[5] = (char *(*)()) F712_5165_4122_21;
	R4122[6] = (char *(*)()) F713_5165_4122_21;
	R4122[7] = (char *(*)()) F714_5165_4122_21;
	R4122[8] = (char *(*)()) F715_5165_4122_21;
	R4122[9] = (char *(*)()) F716_5165_4122_21;
	R4122[10] = (char *(*)()) F717_5165_4122_21;
	R4122[11] = (char *(*)()) F718_5165_4122_21;
	R4122[67] = (char *(*)()) F724_5223;
	R4122[68] = (char *(*)()) F727_5223_4122_21;
	R4122[69] = (char *(*)()) F731_5223_4122_21;
	R4122[73] = (char *(*)()) F724_5223;
	R4122[77] = (char *(*)()) F784_5456;
	R4122[78] = (char *(*)()) F785_5456_4122_21;
	R4122[79] = (char *(*)()) F786_5456_4122_21;
	R4122[80] = (char *(*)()) F787_5456;
	R4122[81] = (char *(*)()) F788_5456_4122_21;
	R4122[82] = (char *(*)()) F789_5456_4122_21;
	R4122[83] = (char *(*)()) F784_5456;
	R4122[84] = (char *(*)()) F789_5456_4122_21;
	R4122[85] = (char *(*)()) F785_5456_4122_21;
	R4122[86] = (char *(*)()) F784_5456;
	R4122[87] = (char *(*)()) F794_5577;
	R4122[88] = (char *(*)()) F795_5577_4122_21;
	R4122[89] = (char *(*)()) F796_5577_4122_21;
	R4122[90] = (char *(*)()) F797_5577_4122_21;
	R4122[91] = (char *(*)()) F798_5577_4122_21;
	R4122[92] = (char *(*)()) F799_5577_4122_21;
	R4122[93] = (char *(*)()) F800_5577_4122_21;
	R4122[94] = (char *(*)()) F801_5577_4122_21;
	R4122[95] = (char *(*)()) F802_5577_4122_21;
	R4122[96] = (char *(*)()) F803_5577_4122_21;
	R4122[97] = (char *(*)()) F804_5577_4122_21;
	R4122[98] = (char *(*)()) F805_5577_4122_21;
	R4122[100] = (char *(*)()) F794_5577;
	R4122[101] = (char *(*)()) F797_5577_4122_21;
	R4122[102] = (char *(*)()) F801_5577_4122_21;
	R4122[103] = (char *(*)()) F794_5577;
	{long i; for (i = 105; i < 107; i++) R4122[i] = (char *(*)()) F794_5577;}
	{long i; for (i = 107; i < 109; i++) R4122[i] = (char *(*)()) F797_5577_4122_21;}
	R4122[133] = (char *(*)()) F840_6398;
	R4122[134] = (char *(*)()) F841_6398_4122_21;
	R4122[135] = (char *(*)()) F842_6398_4122_21;
	R4122[136] = (char *(*)()) F843_6398_4122_21;
	R4122[137] = (char *(*)()) F844_6398_4122_21;
	R4122[138] = (char *(*)()) F845_6398_4122_21;
	R4122[139] = (char *(*)()) F846_6398_4122_21;
	R4122[140] = (char *(*)()) F847_6398_4122_21;
	R4122[141] = (char *(*)()) F848_6398_4122_21;
	R4122[142] = (char *(*)()) F849_6398_4122_21;
	R4122[143] = (char *(*)()) F850_6398_4122_21;
	R4122[144] = (char *(*)()) F851_6398_4122_21;
	R4122[247] = (char *(*)()) F954_6857;
	R4122[330] = (char *(*)()) F1037_8277_4122_21;
	R4122[331] = (char *(*)()) F1038_8299_4122_21;
	R4122[334] = (char *(*)()) F1041_8445_4122_21;
	R4122[335] = (char *(*)()) F1042_8468_4122_21;
	{long i; for (i = 494; i < 504; i++) R4122[i] = (char *(*)()) F794_5577;}
	R4122[606] = (char *(*)()) F1313_13951_4122_21;
}
static EIF_REFERENCE F708_5165_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F708_5165(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(977, 0x00).id, 977, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F709_5165_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F709_5165(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(968, 0x00).id, 968, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F710_5165_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F710_5165(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F711_5165_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F711_5165(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(974, 0x00).id, 974, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F712_5165_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F712_5165(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1025, 0x00).id, 1025, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F713_5165_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F713_5165(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(989, 0x00).id, 989, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F714_5165_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F714_5165(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F715_5165_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F715_5165(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(971, 0x00).id, 971, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F716_5165_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F716_5165(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(986, 0x00).id, 986, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F717_5165_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F717_5165(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(980, 0x00).id, 980, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F718_5165_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F718_5165(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(983, 0x00).id, 983, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F727_5223_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F727_5223(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F731_5223_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F731_5223(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F785_5456_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F785_5456(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F786_5456_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F786_5456(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1025, 0x00).id, 1025, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F788_5456_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F788_5456(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F789_5456_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F789_5456(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F795_5577_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F795_5577(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(977, 0x00).id, 977, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F796_5577_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F796_5577(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(968, 0x00).id, 968, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F797_5577_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F797_5577(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F798_5577_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F798_5577(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(974, 0x00).id, 974, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F799_5577_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F799_5577(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1025, 0x00).id, 1025, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F800_5577_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F800_5577(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(989, 0x00).id, 989, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F801_5577_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F801_5577(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F802_5577_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F802_5577(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(971, 0x00).id, 971, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F803_5577_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F803_5577(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(986, 0x00).id, 986, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F804_5577_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F804_5577(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(980, 0x00).id, 980, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F805_5577_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F805_5577(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(983, 0x00).id, 983, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F841_6398_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F841_6398(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(977, 0x00).id, 977, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F842_6398_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F842_6398(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(968, 0x00).id, 968, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F843_6398_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F843_6398(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F844_6398_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F844_6398(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(974, 0x00).id, 974, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F845_6398_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F845_6398(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1025, 0x00).id, 1025, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F846_6398_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F846_6398(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(989, 0x00).id, 989, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F847_6398_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F847_6398(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F848_6398_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F848_6398(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(971, 0x00).id, 971, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F849_6398_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F849_6398(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(986, 0x00).id, 986, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F850_6398_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F850_6398(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(980, 0x00).id, 980, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F851_6398_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F851_6398(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(983, 0x00).id, 983, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1037_8277_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1037_8277(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(989, 0x00).id, 989, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1038_8299_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1038_8299(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(989, 0x00).id, 989, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1041_8445_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1041_8445(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(986, 0x00).id, 986, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1042_8468_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1042_8468(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(986, 0x00).id, 986, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1313_13951_4122_21 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1313_13951(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(989, 0x00).id, 989, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R4123[607])();
void R4123_init () {
	R4123[0] = (char *(*)()) F707_5170;
	R4123[1] = (char *(*)()) F708_5170;
	R4123[2] = (char *(*)()) F709_5170;
	R4123[3] = (char *(*)()) F710_5170;
	R4123[4] = (char *(*)()) F711_5170;
	R4123[5] = (char *(*)()) F712_5170;
	R4123[6] = (char *(*)()) F713_5170;
	R4123[7] = (char *(*)()) F714_5170;
	R4123[8] = (char *(*)()) F715_5170;
	R4123[9] = (char *(*)()) F716_5170;
	R4123[10] = (char *(*)()) F717_5170;
	R4123[11] = (char *(*)()) F718_5170;
	R4123[67] = (char *(*)()) F724_5226;
	R4123[68] = (char *(*)()) F727_5226;
	R4123[69] = (char *(*)()) F731_5226;
	R4123[73] = (char *(*)()) F724_5226;
	R4123[77] = (char *(*)()) F784_5461;
	R4123[78] = (char *(*)()) F785_5461;
	R4123[79] = (char *(*)()) F786_5461;
	R4123[80] = (char *(*)()) F787_5461;
	R4123[81] = (char *(*)()) F788_5461;
	R4123[82] = (char *(*)()) F789_5461;
	R4123[83] = (char *(*)()) F784_5461;
	R4123[84] = (char *(*)()) F789_5461;
	R4123[85] = (char *(*)()) F785_5461;
	R4123[86] = (char *(*)()) F784_5461;
	R4123[87] = (char *(*)()) F724_5226;
	R4123[88] = (char *(*)()) F725_5226;
	R4123[89] = (char *(*)()) F726_5226;
	R4123[90] = (char *(*)()) F727_5226;
	R4123[91] = (char *(*)()) F728_5226;
	R4123[92] = (char *(*)()) F729_5226;
	R4123[93] = (char *(*)()) F730_5226;
	R4123[94] = (char *(*)()) F731_5226;
	R4123[95] = (char *(*)()) F732_5226;
	R4123[96] = (char *(*)()) F733_5226;
	R4123[97] = (char *(*)()) F734_5226;
	R4123[98] = (char *(*)()) F735_5226;
	R4123[100] = (char *(*)()) F724_5226;
	R4123[101] = (char *(*)()) F727_5226;
	R4123[102] = (char *(*)()) F731_5226;
	R4123[103] = (char *(*)()) F724_5226;
	{long i; for (i = 105; i < 107; i++) R4123[i] = (char *(*)()) F724_5226;}
	{long i; for (i = 107; i < 109; i++) R4123[i] = (char *(*)()) F727_5226;}
	R4123[133] = (char *(*)()) F840_6406;
	R4123[134] = (char *(*)()) F841_6406;
	R4123[135] = (char *(*)()) F842_6406;
	R4123[136] = (char *(*)()) F843_6406;
	R4123[137] = (char *(*)()) F844_6406;
	R4123[138] = (char *(*)()) F845_6406;
	R4123[139] = (char *(*)()) F846_6406;
	R4123[140] = (char *(*)()) F847_6406;
	R4123[141] = (char *(*)()) F848_6406;
	R4123[142] = (char *(*)()) F849_6406;
	R4123[143] = (char *(*)()) F850_6406;
	R4123[144] = (char *(*)()) F851_6406;
	R4123[247] = (char *(*)()) F954_6887;
	{long i; for (i = 330; i < 332; i++) R4123[i] = (char *(*)()) F1036_8244;}
	{long i; for (i = 334; i < 336; i++) R4123[i] = (char *(*)()) F1040_8409;}
	{long i; for (i = 494; i < 504; i++) R4123[i] = (char *(*)()) F724_5226;}
	R4123[606] = (char *(*)()) F1036_8244;
}

EIF_TYPE_INDEX *Y4123_gen_type [633];
EIF_TYPE_INDEX Y4123 [633];
void Y4123_init (void)
{
	egc_routines_types [4123] = Y4123;
	egc_routines_gen_types [4123] = Y4123_gen_type;
	egc_routines_offset [4123] = 681;
	{long i; for (i = 0; i < 99; i++) Y4123[i] = 959;};
	{long i; for (i = 102; i < 134; i++) Y4123[i] = 959;};
	{long i; for (i = 158; i < 170; i++) Y4123[i] = 959;};
	Y4123[272] = 959;
	{long i; for (i = 354; i < 361; i++) Y4123[i] = 959;};
	{long i; for (i = 519; i < 529; i++) Y4123[i] = 959;};
	{long i; for (i = 631; i < 633; i++) Y4123[i] = 959;};
}

char *(*R4124[607])();
void R4124_init () {
	R4124[0] = (char *(*)()) F707_5171;
	R4124[1] = (char *(*)()) F708_5171;
	R4124[2] = (char *(*)()) F709_5171;
	R4124[3] = (char *(*)()) F710_5171;
	R4124[4] = (char *(*)()) F711_5171;
	R4124[5] = (char *(*)()) F712_5171;
	R4124[6] = (char *(*)()) F713_5171;
	R4124[7] = (char *(*)()) F714_5171;
	R4124[8] = (char *(*)()) F715_5171;
	R4124[9] = (char *(*)()) F716_5171;
	R4124[10] = (char *(*)()) F717_5171;
	R4124[11] = (char *(*)()) F718_5171;
	R4124[67] = (char *(*)()) F774_5287;
	R4124[68] = (char *(*)()) F775_5287;
	R4124[69] = (char *(*)()) F776_5287;
	R4124[73] = (char *(*)()) F774_5287;
	R4124[77] = (char *(*)()) F784_5462;
	R4124[78] = (char *(*)()) F785_5462;
	R4124[79] = (char *(*)()) F786_5462;
	R4124[80] = (char *(*)()) F787_5462;
	R4124[81] = (char *(*)()) F788_5462;
	R4124[82] = (char *(*)()) F789_5462;
	R4124[83] = (char *(*)()) F784_5462;
	R4124[84] = (char *(*)()) F789_5462;
	R4124[85] = (char *(*)()) F785_5462;
	R4124[86] = (char *(*)()) F784_5462;
	R4124[87] = (char *(*)()) F794_5592;
	R4124[88] = (char *(*)()) F795_5592;
	R4124[89] = (char *(*)()) F796_5592;
	R4124[90] = (char *(*)()) F797_5592;
	R4124[91] = (char *(*)()) F798_5592;
	R4124[92] = (char *(*)()) F799_5592;
	R4124[93] = (char *(*)()) F800_5592;
	R4124[94] = (char *(*)()) F801_5592;
	R4124[95] = (char *(*)()) F802_5592;
	R4124[96] = (char *(*)()) F803_5592;
	R4124[97] = (char *(*)()) F804_5592;
	R4124[98] = (char *(*)()) F805_5592;
	R4124[100] = (char *(*)()) F794_5592;
	R4124[101] = (char *(*)()) F797_5592;
	R4124[102] = (char *(*)()) F801_5592;
	R4124[103] = (char *(*)()) F794_5592;
	{long i; for (i = 105; i < 107; i++) R4124[i] = (char *(*)()) F794_5592;}
	{long i; for (i = 107; i < 109; i++) R4124[i] = (char *(*)()) F797_5592;}
	R4124[133] = (char *(*)()) F840_6407;
	R4124[134] = (char *(*)()) F841_6407;
	R4124[135] = (char *(*)()) F842_6407;
	R4124[136] = (char *(*)()) F843_6407;
	R4124[137] = (char *(*)()) F844_6407;
	R4124[138] = (char *(*)()) F845_6407;
	R4124[139] = (char *(*)()) F846_6407;
	R4124[140] = (char *(*)()) F847_6407;
	R4124[141] = (char *(*)()) F848_6407;
	R4124[142] = (char *(*)()) F849_6407;
	R4124[143] = (char *(*)()) F850_6407;
	R4124[144] = (char *(*)()) F851_6407;
	R4124[247] = (char *(*)()) F954_6886;
	{long i; for (i = 330; i < 332; i++) R4124[i] = (char *(*)()) F1036_8242;}
	{long i; for (i = 334; i < 336; i++) R4124[i] = (char *(*)()) F1040_8407;}
	{long i; for (i = 494; i < 504; i++) R4124[i] = (char *(*)()) F794_5592;}
	R4124[606] = (char *(*)()) F1313_13967;
}

char *(*R4126[607])();
void R4126_init () {
	R4126[0] = (char *(*)()) F707_5180;
	R4126[1] = (char *(*)()) F708_5180;
	R4126[2] = (char *(*)()) F709_5180;
	R4126[3] = (char *(*)()) F710_5180;
	R4126[4] = (char *(*)()) F711_5180;
	R4126[5] = (char *(*)()) F712_5180;
	R4126[6] = (char *(*)()) F713_5180;
	R4126[7] = (char *(*)()) F714_5180;
	R4126[8] = (char *(*)()) F715_5180;
	R4126[9] = (char *(*)()) F716_5180;
	R4126[10] = (char *(*)()) F717_5180;
	R4126[11] = (char *(*)()) F718_5180;
	R4126[67] = (char *(*)()) F724_5231;
	R4126[68] = (char *(*)()) F727_5231;
	R4126[69] = (char *(*)()) F731_5231;
	R4126[73] = (char *(*)()) F724_5231;
	R4126[77] = (char *(*)()) F784_5478;
	R4126[78] = (char *(*)()) F785_5478;
	R4126[79] = (char *(*)()) F786_5478;
	R4126[80] = (char *(*)()) F787_5478;
	R4126[81] = (char *(*)()) F788_5478;
	R4126[82] = (char *(*)()) F789_5478;
	R4126[83] = (char *(*)()) F784_5478;
	R4126[84] = (char *(*)()) F789_5478;
	R4126[85] = (char *(*)()) F785_5478;
	R4126[86] = (char *(*)()) F784_5478;
	R4126[87] = (char *(*)()) F794_5598;
	R4126[88] = (char *(*)()) F795_5598;
	R4126[89] = (char *(*)()) F796_5598;
	R4126[90] = (char *(*)()) F797_5598;
	R4126[91] = (char *(*)()) F798_5598;
	R4126[92] = (char *(*)()) F799_5598;
	R4126[93] = (char *(*)()) F800_5598;
	R4126[94] = (char *(*)()) F801_5598;
	R4126[95] = (char *(*)()) F802_5598;
	R4126[96] = (char *(*)()) F803_5598;
	R4126[97] = (char *(*)()) F804_5598;
	R4126[98] = (char *(*)()) F805_5598;
	R4126[100] = (char *(*)()) F794_5598;
	R4126[101] = (char *(*)()) F797_5598;
	R4126[102] = (char *(*)()) F801_5598;
	R4126[103] = (char *(*)()) F794_5598;
	{long i; for (i = 105; i < 107; i++) R4126[i] = (char *(*)()) F794_5598;}
	{long i; for (i = 107; i < 109; i++) R4126[i] = (char *(*)()) F797_5598;}
	R4126[133] = (char *(*)()) F840_6412;
	R4126[134] = (char *(*)()) F841_6412;
	R4126[135] = (char *(*)()) F842_6412;
	R4126[136] = (char *(*)()) F843_6412;
	R4126[137] = (char *(*)()) F844_6412;
	R4126[138] = (char *(*)()) F845_6412;
	R4126[139] = (char *(*)()) F846_6412;
	R4126[140] = (char *(*)()) F847_6412;
	R4126[141] = (char *(*)()) F848_6412;
	R4126[142] = (char *(*)()) F849_6412;
	R4126[143] = (char *(*)()) F850_6412;
	R4126[144] = (char *(*)()) F851_6412;
	R4126[247] = (char *(*)()) F954_6884;
	{long i; for (i = 330; i < 332; i++) R4126[i] = (char *(*)()) F1033_8102;}
	{long i; for (i = 334; i < 336; i++) R4126[i] = (char *(*)()) F1033_8102;}
	{long i; for (i = 494; i < 504; i++) R4126[i] = (char *(*)()) F794_5598;}
	R4126[606] = (char *(*)()) F1033_8102;
}

char *(*R4150[12])();
void R4150_init () {
	R4150[0] = (char *(*)()) F707_5163;
	R4150[1] = (char *(*)()) F708_5163;
	R4150[2] = (char *(*)()) F709_5163;
	R4150[3] = (char *(*)()) F710_5163;
	R4150[4] = (char *(*)()) F711_5163;
	R4150[5] = (char *(*)()) F712_5163;
	R4150[6] = (char *(*)()) F713_5163;
	R4150[7] = (char *(*)()) F714_5163;
	R4150[8] = (char *(*)()) F715_5163;
	R4150[9] = (char *(*)()) F716_5163;
	R4150[10] = (char *(*)()) F717_5163;
	R4150[11] = (char *(*)()) F718_5163;
}

char *(*R4160[12])();
void R4160_init () {
	R4160[0] = (char *(*)()) F707_5189;
	R4160[1] = (char *(*)()) F708_5189;
	R4160[2] = (char *(*)()) F709_5189;
	R4160[3] = (char *(*)()) F710_5189;
	R4160[4] = (char *(*)()) F711_5189;
	R4160[5] = (char *(*)()) F712_5189;
	R4160[6] = (char *(*)()) F713_5189;
	R4160[7] = (char *(*)()) F714_5189;
	R4160[8] = (char *(*)()) F715_5189;
	R4160[9] = (char *(*)()) F716_5189;
	R4160[10] = (char *(*)()) F717_5189;
	R4160[11] = (char *(*)()) F718_5189;
}

char *(*R4181[12])();
void R4181_init () {
	R4181[0] = (char *(*)()) F707_5217;
	R4181[1] = (char *(*)()) F708_5217;
	R4181[2] = (char *(*)()) F709_5217;
	R4181[3] = (char *(*)()) F710_5217;
	R4181[4] = (char *(*)()) F711_5217;
	R4181[5] = (char *(*)()) F712_5217;
	R4181[6] = (char *(*)()) F713_5217;
	R4181[7] = (char *(*)()) F714_5217;
	R4181[8] = (char *(*)()) F715_5217;
	R4181[9] = (char *(*)()) F716_5217;
	R4181[10] = (char *(*)()) F717_5217;
	R4181[11] = (char *(*)()) F718_5217;
}

char *(*R4187[7])();
void R4187_init () {
	R4187[0] = (char *(*)()) F774_5301;
	R4187[1] = (char *(*)()) F775_5301;
	R4187[2] = (char *(*)()) F776_5301;
	R4187[6] = (char *(*)()) F779_5366;
}

char *(*R4188[437])();
void R4188_init () {
	R4188[0] = (char *(*)()) F774_5302;
	R4188[1] = (char *(*)()) F775_5302;
	R4188[2] = (char *(*)()) F776_5302;
	R4188[6] = (char *(*)()) F774_5302;
	R4188[20] = (char *(*)()) F794_5606;
	R4188[21] = (char *(*)()) F795_5606;
	R4188[22] = (char *(*)()) F796_5606;
	R4188[23] = (char *(*)()) F797_5606;
	R4188[24] = (char *(*)()) F798_5606;
	R4188[25] = (char *(*)()) F799_5606;
	R4188[26] = (char *(*)()) F800_5606;
	R4188[27] = (char *(*)()) F801_5606;
	R4188[28] = (char *(*)()) F802_5606;
	R4188[29] = (char *(*)()) F803_5606;
	R4188[30] = (char *(*)()) F804_5606;
	R4188[31] = (char *(*)()) F805_5606;
	R4188[33] = (char *(*)()) F794_5606;
	R4188[34] = (char *(*)()) F797_5606;
	R4188[35] = (char *(*)()) F801_5606;
	R4188[36] = (char *(*)()) F794_5606;
	{long i; for (i = 38; i < 40; i++) R4188[i] = (char *(*)()) F794_5606;}
	{long i; for (i = 40; i < 42; i++) R4188[i] = (char *(*)()) F797_5606;}
	{long i; for (i = 427; i < 437; i++) R4188[i] = (char *(*)()) F794_5606;}
}

char *(*R4213[7])();
void R4213_init () {
	R4213[0] = (char *(*)()) F774_5317;
	R4213[1] = (char *(*)()) F775_5317_4213_5;
	R4213[2] = (char *(*)()) F776_5317_4213_5;
	R4213[6] = (char *(*)()) F779_5381;
}
static EIF_REFERENCE F775_5317_4213_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F775_5317(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F776_5317_4213_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F776_5317(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R4217[7])();
void R4217_init () {
	R4217[0] = (char *(*)()) F774_5321;
	R4217[1] = (char *(*)()) F775_5321;
	R4217[2] = (char *(*)()) F776_5321;
	R4217[6] = (char *(*)()) F779_5358;
}

char *(*R4219[7])();
void R4219_init () {
	R4219[0] = (char *(*)()) F774_5323;
	R4219[1] = (char *(*)()) F775_5323;
	R4219[2] = (char *(*)()) F776_5323;
	R4219[6] = (char *(*)()) F774_5323;
}

char *(*R4237[530])();
void R4237_init () {
	R4237[0] = (char *(*)()) F784_5499;
	R4237[1] = (char *(*)()) F785_5499;
	R4237[2] = (char *(*)()) F786_5499;
	R4237[3] = (char *(*)()) F787_5499;
	R4237[4] = (char *(*)()) F788_5499;
	R4237[5] = (char *(*)()) F789_5499;
	R4237[6] = (char *(*)()) F784_5499;
	R4237[7] = (char *(*)()) F789_5499;
	R4237[8] = (char *(*)()) F785_5499;
	R4237[9] = (char *(*)()) F784_5499;
	R4237[10] = (char *(*)()) F794_5632;
	R4237[11] = (char *(*)()) F795_5632;
	R4237[12] = (char *(*)()) F796_5632;
	R4237[13] = (char *(*)()) F797_5632;
	R4237[14] = (char *(*)()) F798_5632;
	R4237[15] = (char *(*)()) F799_5632;
	R4237[16] = (char *(*)()) F800_5632;
	R4237[17] = (char *(*)()) F801_5632;
	R4237[18] = (char *(*)()) F802_5632;
	R4237[19] = (char *(*)()) F803_5632;
	R4237[20] = (char *(*)()) F804_5632;
	R4237[21] = (char *(*)()) F805_5632;
	R4237[23] = (char *(*)()) F794_5632;
	R4237[24] = (char *(*)()) F797_5632;
	R4237[25] = (char *(*)()) F801_5632;
	R4237[26] = (char *(*)()) F794_5632;
	{long i; for (i = 28; i < 30; i++) R4237[i] = (char *(*)()) F794_5632;}
	{long i; for (i = 30; i < 32; i++) R4237[i] = (char *(*)()) F797_5632;}
	R4237[170] = (char *(*)()) F954_6965;
	{long i; for (i = 244; i < 249; i++) R4237[i] = (char *(*)()) F1027_8056;}
	R4237[254] = (char *(*)()) F1038_8383;
	R4237[257] = (char *(*)()) F1041_8461;
	R4237[258] = (char *(*)()) F1042_8552;
	{long i; for (i = 417; i < 427; i++) R4237[i] = (char *(*)()) F794_5632;}
	R4237[529] = (char *(*)()) F1038_8383;
}

char *(*R4259[10])();
void R4259_init () {
	R4259[0] = (char *(*)()) F784_5440;
	R4259[1] = (char *(*)()) F785_5440;
	R4259[2] = (char *(*)()) F786_5440;
	R4259[3] = (char *(*)()) F787_5440;
	R4259[4] = (char *(*)()) F788_5440;
	R4259[5] = (char *(*)()) F789_5440;
	R4259[6] = (char *(*)()) F784_5440;
	R4259[7] = (char *(*)()) F789_5440;
	R4259[8] = (char *(*)()) F785_5440;
	R4259[9] = (char *(*)()) F784_5440;
}

char *(*R4262[10])();
void R4262_init () {
	R4262[0] = (char *(*)()) F784_5443;
	R4262[1] = (char *(*)()) F785_5443;
	R4262[2] = (char *(*)()) F786_5443;
	R4262[3] = (char *(*)()) F787_5443;
	R4262[4] = (char *(*)()) F788_5443;
	R4262[5] = (char *(*)()) F789_5443;
	R4262[6] = (char *(*)()) F784_5443;
	R4262[7] = (char *(*)()) F789_5443;
	R4262[8] = (char *(*)()) F785_5443;
	R4262[9] = (char *(*)()) F784_5443;
}

char *(*R4263[10])();
void R4263_init () {
	R4263[0] = (char *(*)()) F784_5444;
	R4263[1] = (char *(*)()) F785_5444_4263_1;
	R4263[2] = (char *(*)()) F786_5444_4263_1;
	R4263[3] = (char *(*)()) F787_5444;
	R4263[4] = (char *(*)()) F788_5444_4263_1;
	R4263[5] = (char *(*)()) F789_5444_4263_1;
	R4263[6] = (char *(*)()) F784_5444;
	R4263[7] = (char *(*)()) F789_5444_4263_1;
	R4263[8] = (char *(*)()) F785_5444_4263_1;
	R4263[9] = (char *(*)()) F784_5444;
}
static EIF_REFERENCE F785_5444_4263_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F785_5444(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F786_5444_4263_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F786_5444(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1025, 0x00).id, 1025, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F788_5444_4263_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F788_5444(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F789_5444_4263_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F789_5444(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}

char *(*R4271[10])();
void R4271_init () {
	R4271[0] = (char *(*)()) F784_5457;
	R4271[1] = (char *(*)()) F785_5457;
	R4271[2] = (char *(*)()) F786_5457;
	R4271[3] = (char *(*)()) F787_5457_4271_27;
	R4271[4] = (char *(*)()) F788_5457_4271_27;
	R4271[5] = (char *(*)()) F789_5457;
	R4271[6] = (char *(*)()) F790_5554;
	R4271[7] = (char *(*)()) F791_5554;
	R4271[8] = (char *(*)()) F792_5554;
	R4271[9] = (char *(*)()) F784_5457;
}
static EIF_INTEGER_32 F787_5457_4271_27 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F787_5457(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F788_5457_4271_27 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F788_5457(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4273[10])();
void R4273_init () {
	R4273[0] = (char *(*)()) F784_5464;
	R4273[1] = (char *(*)()) F785_5464;
	R4273[2] = (char *(*)()) F786_5464;
	R4273[3] = (char *(*)()) F787_5464_4273_3;
	R4273[4] = (char *(*)()) F788_5464_4273_3;
	R4273[5] = (char *(*)()) F789_5464;
	R4273[6] = (char *(*)()) F790_5556;
	R4273[7] = (char *(*)()) F791_5556;
	R4273[8] = (char *(*)()) F792_5556;
	R4273[9] = (char *(*)()) F784_5464;
}
static EIF_BOOLEAN F787_5464_4273_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F787_5464(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F788_5464_4273_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F788_5464(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R4279[10])();
void R4279_init () {
	R4279[0] = (char *(*)()) F784_5472;
	R4279[1] = (char *(*)()) F785_5472;
	R4279[2] = (char *(*)()) F786_5472;
	R4279[3] = (char *(*)()) F787_5472;
	R4279[4] = (char *(*)()) F788_5472;
	R4279[5] = (char *(*)()) F789_5472;
	R4279[6] = (char *(*)()) F784_5472;
	R4279[7] = (char *(*)()) F789_5472;
	R4279[8] = (char *(*)()) F785_5472;
	R4279[9] = (char *(*)()) F784_5472;
}

char *(*R4280[10])();
void R4280_init () {
	R4280[0] = (char *(*)()) F784_5473;
	R4280[1] = (char *(*)()) F785_5473;
	R4280[2] = (char *(*)()) F786_5473;
	R4280[3] = (char *(*)()) F787_5473;
	R4280[4] = (char *(*)()) F788_5473;
	R4280[5] = (char *(*)()) F789_5473;
	R4280[6] = (char *(*)()) F784_5473;
	R4280[7] = (char *(*)()) F789_5473;
	R4280[8] = (char *(*)()) F785_5473;
	R4280[9] = (char *(*)()) F784_5473;
}

char *(*R4288[10])();
void R4288_init () {
	R4288[0] = (char *(*)()) F784_5482;
	R4288[1] = (char *(*)()) F785_5482;
	R4288[2] = (char *(*)()) F786_5482;
	R4288[3] = (char *(*)()) F787_5482_4288_4;
	R4288[4] = (char *(*)()) F788_5482_4288_4;
	R4288[5] = (char *(*)()) F789_5482;
	R4288[6] = (char *(*)()) F784_5482;
	R4288[7] = (char *(*)()) F789_5482;
	R4288[8] = (char *(*)()) F785_5482;
	R4288[9] = (char *(*)()) F784_5482;
}
static void F787_5482_4288_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F787_5482(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F788_5482_4288_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F788_5482(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4290[10])();
void R4290_init () {
	R4290[0] = (char *(*)()) F784_5484;
	R4290[1] = (char *(*)()) F785_5484;
	R4290[2] = (char *(*)()) F786_5484;
	R4290[3] = (char *(*)()) F787_5484;
	R4290[4] = (char *(*)()) F788_5484;
	R4290[5] = (char *(*)()) F789_5484;
	R4290[6] = (char *(*)()) F784_5484;
	R4290[7] = (char *(*)()) F789_5484;
	R4290[8] = (char *(*)()) F785_5484;
	R4290[9] = (char *(*)()) F784_5484;
}

char *(*R4291[10])();
void R4291_init () {
	R4291[0] = (char *(*)()) F784_5485;
	R4291[1] = (char *(*)()) F785_5485;
	R4291[2] = (char *(*)()) F786_5485;
	R4291[3] = (char *(*)()) F787_5485;
	R4291[4] = (char *(*)()) F788_5485;
	R4291[5] = (char *(*)()) F789_5485;
	R4291[6] = (char *(*)()) F784_5485;
	R4291[7] = (char *(*)()) F789_5485;
	R4291[8] = (char *(*)()) F785_5485;
	R4291[9] = (char *(*)()) F784_5485;
}

char *(*R4297[10])();
void R4297_init () {
	R4297[0] = (char *(*)()) F784_5498;
	R4297[1] = (char *(*)()) F785_5498;
	R4297[2] = (char *(*)()) F786_5498;
	R4297[3] = (char *(*)()) F787_5498;
	R4297[4] = (char *(*)()) F788_5498;
	R4297[5] = (char *(*)()) F789_5498;
	R4297[6] = (char *(*)()) F790_5558;
	R4297[7] = (char *(*)()) F791_5558;
	R4297[8] = (char *(*)()) F792_5558;
	R4297[9] = (char *(*)()) F784_5498;
}

char *(*R4306[10])();
void R4306_init () {
	R4306[0] = (char *(*)()) F784_5508;
	R4306[1] = (char *(*)()) F785_5508;
	R4306[2] = (char *(*)()) F786_5508;
	R4306[3] = (char *(*)()) F787_5508;
	R4306[4] = (char *(*)()) F788_5508;
	R4306[5] = (char *(*)()) F789_5508;
	R4306[6] = (char *(*)()) F784_5508;
	R4306[7] = (char *(*)()) F789_5508;
	R4306[8] = (char *(*)()) F785_5508;
	R4306[9] = (char *(*)()) F784_5508;
}

char *(*R4307[10])();
void R4307_init () {
	R4307[0] = (char *(*)()) F784_5509;
	R4307[1] = (char *(*)()) F785_5509;
	R4307[2] = (char *(*)()) F786_5509;
	R4307[3] = (char *(*)()) F787_5509;
	R4307[4] = (char *(*)()) F788_5509;
	R4307[5] = (char *(*)()) F789_5509;
	R4307[6] = (char *(*)()) F784_5509;
	R4307[7] = (char *(*)()) F789_5509;
	R4307[8] = (char *(*)()) F785_5509;
	R4307[9] = (char *(*)()) F784_5509;
}

char *(*R4314[10])();
void R4314_init () {
	R4314[0] = (char *(*)()) F784_5516;
	R4314[1] = (char *(*)()) F785_5516_4314_1;
	R4314[2] = (char *(*)()) F786_5516_4314_1;
	R4314[3] = (char *(*)()) F787_5516;
	R4314[4] = (char *(*)()) F788_5516_4314_1;
	R4314[5] = (char *(*)()) F789_5516_4314_1;
	R4314[6] = (char *(*)()) F784_5516;
	R4314[7] = (char *(*)()) F789_5516_4314_1;
	R4314[8] = (char *(*)()) F785_5516_4314_1;
	R4314[9] = (char *(*)()) F784_5516;
}
static EIF_REFERENCE F785_5516_4314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F785_5516(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F786_5516_4314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F786_5516(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1025, 0x00).id, 1025, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F788_5516_4314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F788_5516(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F789_5516_4314_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F789_5516(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}

char *(*R4315[10])();
void R4315_init () {
	R4315[0] = (char *(*)()) F784_5517;
	R4315[1] = (char *(*)()) F785_5517;
	R4315[2] = (char *(*)()) F786_5517;
	R4315[3] = (char *(*)()) F787_5517_4315_1;
	R4315[4] = (char *(*)()) F788_5517_4315_1;
	R4315[5] = (char *(*)()) F789_5517;
	R4315[6] = (char *(*)()) F784_5517;
	R4315[7] = (char *(*)()) F789_5517;
	R4315[8] = (char *(*)()) F785_5517;
	R4315[9] = (char *(*)()) F784_5517;
}
static EIF_REFERENCE F787_5517_4315_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F787_5517(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F788_5517_4315_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F788_5517(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R4316[10])();
void R4316_init () {
	R4316[0] = (char *(*)()) F784_5518;
	R4316[1] = (char *(*)()) F785_5518;
	R4316[2] = (char *(*)()) F786_5518;
	R4316[3] = (char *(*)()) F787_5518;
	R4316[4] = (char *(*)()) F788_5518;
	R4316[5] = (char *(*)()) F789_5518;
	R4316[6] = (char *(*)()) F784_5518;
	R4316[7] = (char *(*)()) F789_5518;
	R4316[8] = (char *(*)()) F785_5518;
	R4316[9] = (char *(*)()) F784_5518;
}

char *(*R4317[10])();
void R4317_init () {
	R4317[0] = (char *(*)()) F784_5519;
	R4317[1] = (char *(*)()) F785_5519;
	R4317[2] = (char *(*)()) F786_5519;
	R4317[3] = (char *(*)()) F787_5519;
	R4317[4] = (char *(*)()) F788_5519;
	R4317[5] = (char *(*)()) F789_5519;
	R4317[6] = (char *(*)()) F784_5519;
	R4317[7] = (char *(*)()) F789_5519;
	R4317[8] = (char *(*)()) F785_5519;
	R4317[9] = (char *(*)()) F784_5519;
}

char *(*R4318[10])();
void R4318_init () {
	R4318[0] = (char *(*)()) F784_5520;
	R4318[1] = (char *(*)()) F785_5520;
	R4318[2] = (char *(*)()) F786_5520;
	R4318[3] = (char *(*)()) F787_5520;
	R4318[4] = (char *(*)()) F788_5520;
	R4318[5] = (char *(*)()) F789_5520;
	R4318[6] = (char *(*)()) F784_5520;
	R4318[7] = (char *(*)()) F789_5520;
	R4318[8] = (char *(*)()) F785_5520;
	R4318[9] = (char *(*)()) F784_5520;
}

char *(*R4319[10])();
void R4319_init () {
	R4319[0] = (char *(*)()) F784_5521;
	R4319[1] = (char *(*)()) F785_5521;
	R4319[2] = (char *(*)()) F786_5521;
	R4319[3] = (char *(*)()) F787_5521;
	R4319[4] = (char *(*)()) F788_5521;
	R4319[5] = (char *(*)()) F789_5521;
	R4319[6] = (char *(*)()) F784_5521;
	R4319[7] = (char *(*)()) F789_5521;
	R4319[8] = (char *(*)()) F785_5521;
	R4319[9] = (char *(*)()) F784_5521;
}

char *(*R4320[10])();
void R4320_init () {
	R4320[0] = (char *(*)()) F784_5522;
	R4320[1] = (char *(*)()) F785_5522;
	R4320[2] = (char *(*)()) F786_5522;
	R4320[3] = (char *(*)()) F787_5522;
	R4320[4] = (char *(*)()) F788_5522;
	R4320[5] = (char *(*)()) F789_5522;
	R4320[6] = (char *(*)()) F784_5522;
	R4320[7] = (char *(*)()) F789_5522;
	R4320[8] = (char *(*)()) F785_5522;
	R4320[9] = (char *(*)()) F784_5522;
}

char *(*R4322[10])();
void R4322_init () {
	R4322[0] = (char *(*)()) F784_5524;
	R4322[1] = (char *(*)()) F785_5524;
	R4322[2] = (char *(*)()) F786_5524;
	R4322[3] = (char *(*)()) F787_5524;
	R4322[4] = (char *(*)()) F788_5524;
	R4322[5] = (char *(*)()) F789_5524;
	R4322[6] = (char *(*)()) F784_5524;
	R4322[7] = (char *(*)()) F789_5524;
	R4322[8] = (char *(*)()) F785_5524;
	R4322[9] = (char *(*)()) F784_5524;
}

char *(*R4323[10])();
void R4323_init () {
	R4323[0] = (char *(*)()) F784_5525;
	R4323[1] = (char *(*)()) F785_5525;
	R4323[2] = (char *(*)()) F786_5525;
	R4323[3] = (char *(*)()) F787_5525;
	R4323[4] = (char *(*)()) F788_5525;
	R4323[5] = (char *(*)()) F789_5525;
	R4323[6] = (char *(*)()) F784_5525;
	R4323[7] = (char *(*)()) F789_5525;
	R4323[8] = (char *(*)()) F785_5525;
	R4323[9] = (char *(*)()) F784_5525;
}

char *(*R4324[10])();
void R4324_init () {
	R4324[0] = (char *(*)()) F784_5526;
	R4324[1] = (char *(*)()) F785_5526;
	R4324[2] = (char *(*)()) F786_5526;
	R4324[3] = (char *(*)()) F787_5526;
	R4324[4] = (char *(*)()) F788_5526;
	R4324[5] = (char *(*)()) F789_5526;
	R4324[6] = (char *(*)()) F784_5526;
	R4324[7] = (char *(*)()) F789_5526;
	R4324[8] = (char *(*)()) F785_5526;
	R4324[9] = (char *(*)()) F784_5526;
}

char *(*R4328[10])();
void R4328_init () {
	R4328[0] = (char *(*)()) F784_5530;
	R4328[1] = (char *(*)()) F785_5530;
	R4328[2] = (char *(*)()) F786_5530;
	R4328[3] = (char *(*)()) F787_5530_4328_4;
	R4328[4] = (char *(*)()) F788_5530_4328_4;
	R4328[5] = (char *(*)()) F789_5530;
	R4328[6] = (char *(*)()) F784_5530;
	R4328[7] = (char *(*)()) F789_5530;
	R4328[8] = (char *(*)()) F785_5530;
	R4328[9] = (char *(*)()) F784_5530;
}
static void F787_5530_4328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F787_5530(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F788_5530_4328_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F788_5530(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4334[10])();
void R4334_init () {
	R4334[0] = (char *(*)()) F784_5536;
	R4334[1] = (char *(*)()) F785_5536;
	R4334[2] = (char *(*)()) F786_5536;
	R4334[3] = (char *(*)()) F787_5536;
	R4334[4] = (char *(*)()) F788_5536;
	R4334[5] = (char *(*)()) F789_5536;
	R4334[6] = (char *(*)()) F784_5536;
	R4334[7] = (char *(*)()) F789_5536;
	R4334[8] = (char *(*)()) F785_5536;
	R4334[9] = (char *(*)()) F784_5536;
}

char *(*R4347[10])();
void R4347_init () {
	R4347[0] = (char *(*)()) F784_5549;
	R4347[1] = (char *(*)()) F785_5549;
	R4347[2] = (char *(*)()) F786_5549;
	R4347[3] = (char *(*)()) F787_5549;
	R4347[4] = (char *(*)()) F788_5549;
	R4347[5] = (char *(*)()) F789_5549;
	R4347[6] = (char *(*)()) F784_5549;
	R4347[7] = (char *(*)()) F789_5549;
	R4347[8] = (char *(*)()) F785_5549;
	R4347[9] = (char *(*)()) F784_5549;
}

char *(*R4350[3])();
void R4350_init () {
	R4350[0] = (char *(*)()) F790_5552;
	R4350[1] = (char *(*)()) F791_5552;
	R4350[2] = (char *(*)()) F792_5552;
}

char *(*R4363[417])();
void R4363_init () {
	R4363[0] = (char *(*)()) F794_5571;
	R4363[1] = (char *(*)()) F795_5571;
	R4363[2] = (char *(*)()) F796_5571;
	R4363[3] = (char *(*)()) F797_5571;
	R4363[4] = (char *(*)()) F798_5571;
	R4363[5] = (char *(*)()) F799_5571;
	R4363[6] = (char *(*)()) F800_5571;
	R4363[7] = (char *(*)()) F801_5571;
	R4363[8] = (char *(*)()) F802_5571;
	R4363[9] = (char *(*)()) F803_5571;
	R4363[10] = (char *(*)()) F804_5571;
	R4363[11] = (char *(*)()) F805_5571;
	R4363[13] = (char *(*)()) F794_5571;
	R4363[14] = (char *(*)()) F797_5571;
	R4363[15] = (char *(*)()) F801_5571;
	R4363[16] = (char *(*)()) F794_5571;
	R4363[18] = (char *(*)()) F794_5571;
	R4363[19] = (char *(*)()) F813_5715;
	{long i; for (i = 20; i < 22; i++) R4363[i] = (char *(*)()) F814_5715;}
	{long i; for (i = 407; i < 417; i++) R4363[i] = (char *(*)()) F1201_12700;}
}

char *(*R4367[417])();
void R4367_init () {
	R4367[0] = (char *(*)()) F794_5575;
	R4367[1] = (char *(*)()) F795_5575;
	R4367[2] = (char *(*)()) F796_5575;
	R4367[3] = (char *(*)()) F797_5575;
	R4367[4] = (char *(*)()) F798_5575;
	R4367[5] = (char *(*)()) F799_5575;
	R4367[6] = (char *(*)()) F800_5575;
	R4367[7] = (char *(*)()) F801_5575;
	R4367[8] = (char *(*)()) F802_5575;
	R4367[9] = (char *(*)()) F803_5575;
	R4367[10] = (char *(*)()) F804_5575;
	R4367[11] = (char *(*)()) F805_5575;
	R4367[13] = (char *(*)()) F794_5575;
	R4367[14] = (char *(*)()) F797_5575;
	R4367[15] = (char *(*)()) F801_5575;
	R4367[16] = (char *(*)()) F794_5575;
	{long i; for (i = 18; i < 20; i++) R4367[i] = (char *(*)()) F794_5575;}
	{long i; for (i = 20; i < 22; i++) R4367[i] = (char *(*)()) F797_5575;}
	{long i; for (i = 407; i < 417; i++) R4367[i] = (char *(*)()) F794_5575;}
}

char *(*R4371[417])();
void R4371_init () {
	R4371[0] = (char *(*)()) F794_5594;
	R4371[1] = (char *(*)()) F795_5594;
	R4371[2] = (char *(*)()) F796_5594;
	R4371[3] = (char *(*)()) F797_5594;
	R4371[4] = (char *(*)()) F798_5594;
	R4371[5] = (char *(*)()) F799_5594;
	R4371[6] = (char *(*)()) F800_5594;
	R4371[7] = (char *(*)()) F801_5594;
	R4371[8] = (char *(*)()) F802_5594;
	R4371[9] = (char *(*)()) F803_5594;
	R4371[10] = (char *(*)()) F804_5594;
	R4371[11] = (char *(*)()) F805_5594;
	R4371[13] = (char *(*)()) F794_5594;
	R4371[14] = (char *(*)()) F797_5594;
	R4371[15] = (char *(*)()) F801_5594;
	R4371[16] = (char *(*)()) F794_5594;
	{long i; for (i = 18; i < 20; i++) R4371[i] = (char *(*)()) F794_5594;}
	{long i; for (i = 20; i < 22; i++) R4371[i] = (char *(*)()) F797_5594;}
	{long i; for (i = 407; i < 417; i++) R4371[i] = (char *(*)()) F794_5594;}
}

char *(*R4375[417])();
void R4375_init () {
	R4375[0] = (char *(*)()) F794_5635;
	R4375[1] = (char *(*)()) F795_5635_4375_136;
	R4375[2] = (char *(*)()) F796_5635_4375_136;
	R4375[3] = (char *(*)()) F797_5635_4375_136;
	R4375[4] = (char *(*)()) F798_5635_4375_136;
	R4375[5] = (char *(*)()) F799_5635_4375_136;
	R4375[6] = (char *(*)()) F800_5635_4375_136;
	R4375[7] = (char *(*)()) F801_5635_4375_136;
	R4375[8] = (char *(*)()) F802_5635_4375_136;
	R4375[9] = (char *(*)()) F803_5635_4375_136;
	R4375[10] = (char *(*)()) F804_5635_4375_136;
	R4375[11] = (char *(*)()) F805_5635_4375_136;
	R4375[13] = (char *(*)()) F794_5635;
	R4375[14] = (char *(*)()) F797_5635_4375_136;
	R4375[15] = (char *(*)()) F801_5635_4375_136;
	R4375[16] = (char *(*)()) F794_5635;
	{long i; for (i = 18; i < 20; i++) R4375[i] = (char *(*)()) F794_5635;}
	{long i; for (i = 20; i < 22; i++) R4375[i] = (char *(*)()) F797_5635_4375_136;}
	{long i; for (i = 407; i < 417; i++) R4375[i] = (char *(*)()) F794_5635;}
}
static void F795_5635_4375_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F795_5635(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F796_5635_4375_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F796_5635(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F797_5635_4375_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F797_5635(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F798_5635_4375_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F798_5635(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F799_5635_4375_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F799_5635(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F800_5635_4375_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F800_5635(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F801_5635_4375_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F801_5635(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F802_5635_4375_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F802_5635(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F803_5635_4375_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F803_5635(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F804_5635_4375_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F804_5635(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F805_5635_4375_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F805_5635(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R4381[3])();
void R4381_init () {
	R4381[0] = (char *(*)()) F794_5612;
	R4381[1] = (char *(*)()) F797_5612_4381_4;
	R4381[2] = (char *(*)()) F801_5612_4381_4;
}
static void F797_5612_4381_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F797_5612(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F801_5612_4381_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F801_5612(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R4382[3])();
void R4382_init () {
	R4382[0] = (char *(*)()) F794_5625;
	R4382[1] = (char *(*)()) F797_5625;
	R4382[2] = (char *(*)()) F801_5625;
}

char *(*R4511[232])();
void R4511_init () {
	{long i; for (i = 0; i < 2; i++) R4511[i] = (char *(*)()) F822_5939;}
	R4511[231] = (char *(*)()) F1054_8643;
}

char *(*R4524[232])();
void R4524_init () {
	{long i; for (i = 0; i < 2; i++) R4524[i] = (char *(*)()) F822_6013;}
	R4524[231] = (char *(*)()) F1054_8666;
}

char *(*R4526[232])();
void R4526_init () {
	{long i; for (i = 0; i < 2; i++) R4526[i] = (char *(*)()) F822_6016;}
	R4526[231] = (char *(*)()) F1054_8664;
}

char *(*R4554[232])();
void R4554_init () {
	{long i; for (i = 0; i < 2; i++) R4554[i] = (char *(*)()) F822_6046;}
	R4554[231] = (char *(*)()) F1054_8661;
}

char *(*R4556[232])();
void R4556_init () {
	R4556[0] = (char *(*)()) F823_6153;
	R4556[1] = (char *(*)()) F824_6211;
	R4556[231] = (char *(*)()) F824_6211;
}

char *(*R4562[232])();
void R4562_init () {
	R4562[0] = (char *(*)()) F823_6159;
	R4562[1] = (char *(*)()) F824_6220;
	R4562[231] = (char *(*)()) F824_6220;
}

char *(*R4567[232])();
void R4567_init () {
	{long i; for (i = 0; i < 2; i++) R4567[i] = (char *(*)()) F822_6053;}
	R4567[231] = (char *(*)()) F1054_8655;
}

char *(*R4580[232])();
void R4580_init () {
	R4580[0] = (char *(*)()) F822_5904;
	R4580[1] = (char *(*)()) F824_6185;
	R4580[231] = (char *(*)()) F824_6185;
}

char *(*R4605[232])();
void R4605_init () {
	{long i; for (i = 0; i < 2; i++) R4605[i] = (char *(*)()) F822_5938;}
	R4605[231] = (char *(*)()) F1054_8642;
}

char *(*R4674[232])();
void R4674_init () {
	R4674[0] = (char *(*)()) F823_6179;
	R4674[1] = (char *(*)()) F822_6062;
	R4674[231] = (char *(*)()) F822_6062;
}

char *(*R4675[232])();
void R4675_init () {
	{long i; for (i = 0; i < 2; i++) R4675[i] = (char *(*)()) F822_6063;}
	R4675[231] = (char *(*)()) F1054_8698;
}

char *(*R4758[231])();
void R4758_init () {
	R4758[0] = (char *(*)()) F824_6231;
	R4758[230] = (char *(*)()) F1054_8640;
}

char *(*R4764[231])();
void R4764_init () {
	R4764[0] = (char *(*)()) F824_6237;
	R4764[230] = (char *(*)()) F1054_8678;
}

char *(*R4768[231])();
void R4768_init () {
	R4768[0] = (char *(*)()) F824_6241;
	R4768[230] = (char *(*)()) F1054_8679;
}

char *(*R4777[482])();
void R4777_init () {
	R4777[0] = (char *(*)()) F832_6279;
	R4777[481] = (char *(*)()) F1313_13994;
}


#ifdef __cplusplus
}
#endif
