#include "epoly15.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R2694[876])();
void R2694_init () {
	R2694[0] = (char *(*)()) F211_3100;
	R2694[875] = (char *(*)()) F213_3295;
}

char *(*R2695[876])();
void R2695_init () {
	R2695[0] = (char *(*)()) F212_3183;
	R2695[875] = (char *(*)()) F213_3328;
}

char *(*R2696[876])();
void R2696_init () {
	R2696[0] = (char *(*)()) F211_3157;
	R2696[875] = (char *(*)()) F213_3352;
}

char *(*R2697[876])();
void R2697_init () {
	R2697[0] = (char *(*)()) F211_3158;
	R2697[875] = (char *(*)()) F213_3353;
}

char *(*R2698[876])();
void R2698_init () {
	R2698[0] = (char *(*)()) F211_3159;
	R2698[875] = (char *(*)()) F213_3354;
}

char *(*R2749[4])();
void R2749_init () {
	R2749[0] = (char *(*)()) F218_3390;
	R2749[1] = (char *(*)()) F219_3390;
	R2749[2] = (char *(*)()) F220_3390;
	R2749[3] = (char *(*)()) F218_3390;
}

char *(*R2788[40])();
void R2788_init () {
	R2788[0] = (char *(*)()) F224_3429;
	{long i; for (i = 1; i < 3; i++) R2788[i] = (char *(*)()) F225_3453;}
	R2788[5] = (char *(*)()) F229_3456;
	R2788[7] = (char *(*)()) F231_3460;
	R2788[8] = (char *(*)()) F232_3477;
	R2788[9] = (char *(*)()) F233_3481;
	R2788[11] = (char *(*)()) F235_3485;
	R2788[12] = (char *(*)()) F236_3487;
	R2788[13] = (char *(*)()) F237_3489;
	R2788[15] = (char *(*)()) F239_3491;
	R2788[16] = (char *(*)()) F240_3493;
	R2788[19] = (char *(*)()) F243_3497;
	R2788[20] = (char *(*)()) F244_3499;
	R2788[22] = (char *(*)()) F246_3503;
	R2788[23] = (char *(*)()) F247_3505;
	R2788[24] = (char *(*)()) F248_3511;
	R2788[26] = (char *(*)()) F250_3513;
	R2788[27] = (char *(*)()) F251_3515;
	R2788[28] = (char *(*)()) F252_3519;
	R2788[29] = (char *(*)()) F253_3523;
	R2788[31] = (char *(*)()) F255_3525;
	R2788[32] = (char *(*)()) F256_3527;
	R2788[34] = (char *(*)()) F258_3529;
	R2788[35] = (char *(*)()) F259_3531;
	R2788[36] = (char *(*)()) F260_3533;
	R2788[37] = (char *(*)()) F261_3535;
	R2788[38] = (char *(*)()) F262_3539;
	R2788[39] = (char *(*)()) F263_3541;
}

char *(*R2973[1034])();
void R2973_init () {
	R2973[0] = (char *(*)()) F280_3824;
	R2973[47] = (char *(*)()) F327_4762;
	R2973[530] = (char *(*)()) F810_5652;
	R2973[640] = (char *(*)()) F920_6799;
	R2973[676] = (char *(*)()) F956_7059_2973_2;
	R2973[677] = (char *(*)()) F957_7059_2973_2;
	R2973[679] = (char *(*)()) F959_7158_2973_2;
	R2973[680] = (char *(*)()) F960_7158_2973_2;
	R2973[682] = (char *(*)()) F962_7257_2973_2;
	R2973[683] = (char *(*)()) F963_7257_2973_2;
	R2973[685] = (char *(*)()) F965_7356_2973_2;
	R2973[686] = (char *(*)()) F966_7356_2973_2;
	R2973[688] = (char *(*)()) F968_7451_2973_2;
	R2973[689] = (char *(*)()) F969_7451_2973_2;
	R2973[691] = (char *(*)()) F971_7545_2973_2;
	R2973[692] = (char *(*)()) F972_7545_2973_2;
	R2973[694] = (char *(*)()) F974_7640_2973_2;
	R2973[695] = (char *(*)()) F975_7640_2973_2;
	R2973[697] = (char *(*)()) F977_7735_2973_2;
	R2973[698] = (char *(*)()) F978_7735_2973_2;
	R2973[700] = (char *(*)()) F980_7804_2973_2;
	R2973[701] = (char *(*)()) F981_7804_2973_2;
	R2973[703] = (char *(*)()) F983_7870_2973_2;
	R2973[704] = (char *(*)()) F984_7870_2973_2;
	{long i; for (i = 706; i < 708; i++) R2973[i] = (char *(*)()) F985_7901;}
	{long i; for (i = 709; i < 711; i++) R2973[i] = (char *(*)()) F988_7941;}
	{long i; for (i = 757; i < 759; i++) R2973[i] = (char *(*)()) F1036_8250;}
	{long i; for (i = 761; i < 763; i++) R2973[i] = (char *(*)()) F1040_8415;}
	R2973[1027] = (char *(*)()) F1307_13832;
	{long i; for (i = 1028; i < 1030; i++) R2973[i] = (char *(*)()) F1308_13848;}
	R2973[1033] = (char *(*)()) F1313_13978;
}
static EIF_BOOLEAN F956_7059_2973_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F956_7059(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F957_7059_2973_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F957_7059(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F959_7158_2973_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F959_7158(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F960_7158_2973_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F960_7158(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F962_7257_2973_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F962_7257(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F963_7257_2973_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F963_7257(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F965_7356_2973_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F965_7356(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F966_7356_2973_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F966_7356(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F968_7451_2973_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F968_7451(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F969_7451_2973_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F969_7451(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F971_7545_2973_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F971_7545(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F972_7545_2973_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F972_7545(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F974_7640_2973_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F974_7640(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F975_7640_2973_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F975_7640(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F977_7735_2973_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F977_7735(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F978_7735_2973_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F978_7735(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F980_7804_2973_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F980_7804(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F981_7804_2973_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F981_7804(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F983_7870_2973_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F983_7870(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F984_7870_2973_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F984_7870(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R2974[1034])();
void R2974_init () {
	R2974[0] = (char *(*)()) F279_3807;
	R2974[47] = (char *(*)()) F279_3807;
	R2974[530] = (char *(*)()) F279_3807;
	R2974[640] = (char *(*)()) F279_3807;
	R2974[641] = (char *(*)()) F921_6839;
	R2974[642] = (char *(*)()) F922_6839;
	R2974[643] = (char *(*)()) F923_6839;
	R2974[644] = (char *(*)()) F924_6839;
	R2974[645] = (char *(*)()) F925_6839;
	R2974[646] = (char *(*)()) F926_6839;
	R2974[647] = (char *(*)()) F927_6839;
	R2974[648] = (char *(*)()) F928_6839;
	R2974[649] = (char *(*)()) F929_6839;
	R2974[650] = (char *(*)()) F930_6839;
	R2974[651] = (char *(*)()) F931_6839;
	R2974[652] = (char *(*)()) F932_6839;
	R2974[653] = (char *(*)()) F933_6839;
	R2974[654] = (char *(*)()) F934_6839;
	R2974[655] = (char *(*)()) F935_6839;
	R2974[656] = (char *(*)()) F936_6839;
	R2974[657] = (char *(*)()) F937_6839;
	R2974[658] = (char *(*)()) F938_6839;
	R2974[659] = (char *(*)()) F939_6839;
	R2974[660] = (char *(*)()) F940_6839;
	R2974[661] = (char *(*)()) F941_6839;
	R2974[662] = (char *(*)()) F942_6839;
	R2974[663] = (char *(*)()) F943_6839;
	R2974[664] = (char *(*)()) F944_6839;
	R2974[665] = (char *(*)()) F945_6839;
	R2974[666] = (char *(*)()) F946_6839;
	R2974[667] = (char *(*)()) F947_6839;
	R2974[668] = (char *(*)()) F948_6839;
	R2974[669] = (char *(*)()) F949_6839;
	R2974[670] = (char *(*)()) F950_6839;
	R2974[671] = (char *(*)()) F951_6839;
	R2974[672] = (char *(*)()) F952_6839;
	R2974[673] = (char *(*)()) F953_6839;
	{long i; for (i = 676; i < 678; i++) R2974[i] = (char *(*)()) F279_3807;}
	{long i; for (i = 679; i < 681; i++) R2974[i] = (char *(*)()) F279_3807;}
	{long i; for (i = 682; i < 684; i++) R2974[i] = (char *(*)()) F279_3807;}
	{long i; for (i = 685; i < 687; i++) R2974[i] = (char *(*)()) F279_3807;}
	{long i; for (i = 688; i < 690; i++) R2974[i] = (char *(*)()) F279_3807;}
	{long i; for (i = 691; i < 693; i++) R2974[i] = (char *(*)()) F279_3807;}
	{long i; for (i = 694; i < 696; i++) R2974[i] = (char *(*)()) F279_3807;}
	{long i; for (i = 697; i < 699; i++) R2974[i] = (char *(*)()) F279_3807;}
	{long i; for (i = 700; i < 702; i++) R2974[i] = (char *(*)()) F279_3807;}
	{long i; for (i = 703; i < 705; i++) R2974[i] = (char *(*)()) F279_3807;}
	{long i; for (i = 706; i < 708; i++) R2974[i] = (char *(*)()) F279_3807;}
	{long i; for (i = 709; i < 711; i++) R2974[i] = (char *(*)()) F279_3807;}
	{long i; for (i = 757; i < 759; i++) R2974[i] = (char *(*)()) F279_3807;}
	{long i; for (i = 761; i < 763; i++) R2974[i] = (char *(*)()) F279_3807;}
	{long i; for (i = 1027; i < 1030; i++) R2974[i] = (char *(*)()) F279_3807;}
	R2974[1033] = (char *(*)()) F279_3807;
}

char *(*R3322[1005])();
void R3322_init () {
	R3322[0] = (char *(*)()) F294_4091;
	R3322[398] = (char *(*)()) F293_4091;
	R3322[399] = (char *(*)()) F294_4091;
	R3322[400] = (char *(*)()) F295_4091;
	R3322[401] = (char *(*)()) F296_4091;
	R3322[402] = (char *(*)()) F297_4091;
	R3322[403] = (char *(*)()) F298_4091;
	R3322[404] = (char *(*)()) F299_4091;
	R3322[405] = (char *(*)()) F300_4091;
	R3322[406] = (char *(*)()) F301_4091;
	R3322[407] = (char *(*)()) F302_4091;
	R3322[408] = (char *(*)()) F303_4091;
	R3322[409] = (char *(*)()) F304_4091;
	R3322[485] = (char *(*)()) F293_4091;
	R3322[486] = (char *(*)()) F294_4091;
	R3322[487] = (char *(*)()) F295_4091;
	R3322[488] = (char *(*)()) F296_4091;
	R3322[489] = (char *(*)()) F297_4091;
	R3322[490] = (char *(*)()) F298_4091;
	R3322[491] = (char *(*)()) F299_4091;
	R3322[492] = (char *(*)()) F300_4091;
	R3322[493] = (char *(*)()) F301_4091;
	R3322[494] = (char *(*)()) F302_4091;
	R3322[495] = (char *(*)()) F303_4091;
	R3322[496] = (char *(*)()) F304_4091;
	R3322[498] = (char *(*)()) F293_4091;
	R3322[499] = (char *(*)()) F296_4091;
	R3322[500] = (char *(*)()) F300_4091;
	R3322[501] = (char *(*)()) F293_4091;
	{long i; for (i = 503; i < 505; i++) R3322[i] = (char *(*)()) F293_4091;}
	{long i; for (i = 505; i < 507; i++) R3322[i] = (char *(*)()) F296_4091;}
	R3322[729] = (char *(*)()) F299_4091;
	R3322[733] = (char *(*)()) F302_4091;
	{long i; for (i = 892; i < 902; i++) R3322[i] = (char *(*)()) F293_4091;}
	R3322[1004] = (char *(*)()) F299_4091;
}

char *(*R3323[1005])();
void R3323_init () {
	R3323[0] = (char *(*)()) F294_4092_3323_136;
	R3323[398] = (char *(*)()) F293_4092;
	R3323[399] = (char *(*)()) F294_4092_3323_136;
	R3323[400] = (char *(*)()) F295_4092_3323_136;
	R3323[401] = (char *(*)()) F296_4092_3323_136;
	R3323[402] = (char *(*)()) F297_4092_3323_136;
	R3323[403] = (char *(*)()) F298_4092_3323_136;
	R3323[404] = (char *(*)()) F299_4092_3323_136;
	R3323[405] = (char *(*)()) F300_4092_3323_136;
	R3323[406] = (char *(*)()) F301_4092_3323_136;
	R3323[407] = (char *(*)()) F302_4092_3323_136;
	R3323[408] = (char *(*)()) F303_4092_3323_136;
	R3323[409] = (char *(*)()) F304_4092_3323_136;
	R3323[485] = (char *(*)()) F293_4092;
	R3323[486] = (char *(*)()) F294_4092_3323_136;
	R3323[487] = (char *(*)()) F295_4092_3323_136;
	R3323[488] = (char *(*)()) F296_4092_3323_136;
	R3323[489] = (char *(*)()) F297_4092_3323_136;
	R3323[490] = (char *(*)()) F298_4092_3323_136;
	R3323[491] = (char *(*)()) F299_4092_3323_136;
	R3323[492] = (char *(*)()) F300_4092_3323_136;
	R3323[493] = (char *(*)()) F301_4092_3323_136;
	R3323[494] = (char *(*)()) F302_4092_3323_136;
	R3323[495] = (char *(*)()) F303_4092_3323_136;
	R3323[496] = (char *(*)()) F304_4092_3323_136;
	R3323[498] = (char *(*)()) F293_4092;
	R3323[499] = (char *(*)()) F296_4092_3323_136;
	R3323[500] = (char *(*)()) F300_4092_3323_136;
	R3323[501] = (char *(*)()) F293_4092;
	{long i; for (i = 503; i < 505; i++) R3323[i] = (char *(*)()) F293_4092;}
	{long i; for (i = 505; i < 507; i++) R3323[i] = (char *(*)()) F296_4092_3323_136;}
	R3323[729] = (char *(*)()) F299_4092_3323_136;
	R3323[733] = (char *(*)()) F302_4092_3323_136;
	{long i; for (i = 892; i < 902; i++) R3323[i] = (char *(*)()) F293_4092;}
	R3323[1004] = (char *(*)()) F299_4092_3323_136;
}
static void F294_4092_3323_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F294_4092(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F295_4092_3323_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F295_4092(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F296_4092_3323_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F296_4092(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F297_4092_3323_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F297_4092(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F298_4092_3323_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F298_4092(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F299_4092_3323_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F299_4092(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F300_4092_3323_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F300_4092(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F301_4092_3323_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F301_4092(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F302_4092_3323_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F302_4092(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F303_4092_3323_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F303_4092(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F304_4092_3323_136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F304_4092(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R3329[1005])();
void R3329_init () {
	R3329[0] = (char *(*)()) F294_4098;
	R3329[398] = (char *(*)()) F293_4098;
	R3329[399] = (char *(*)()) F294_4098;
	R3329[400] = (char *(*)()) F295_4098;
	R3329[401] = (char *(*)()) F296_4098;
	R3329[402] = (char *(*)()) F297_4098;
	R3329[403] = (char *(*)()) F298_4098;
	R3329[404] = (char *(*)()) F299_4098;
	R3329[405] = (char *(*)()) F300_4098;
	R3329[406] = (char *(*)()) F301_4098;
	R3329[407] = (char *(*)()) F302_4098;
	R3329[408] = (char *(*)()) F303_4098;
	R3329[409] = (char *(*)()) F304_4098;
	R3329[485] = (char *(*)()) F293_4098;
	R3329[486] = (char *(*)()) F294_4098;
	R3329[487] = (char *(*)()) F295_4098;
	R3329[488] = (char *(*)()) F296_4098;
	R3329[489] = (char *(*)()) F297_4098;
	R3329[490] = (char *(*)()) F298_4098;
	R3329[491] = (char *(*)()) F299_4098;
	R3329[492] = (char *(*)()) F300_4098;
	R3329[493] = (char *(*)()) F301_4098;
	R3329[494] = (char *(*)()) F302_4098;
	R3329[495] = (char *(*)()) F303_4098;
	R3329[496] = (char *(*)()) F304_4098;
	R3329[498] = (char *(*)()) F293_4098;
	R3329[499] = (char *(*)()) F296_4098;
	R3329[500] = (char *(*)()) F300_4098;
	R3329[501] = (char *(*)()) F293_4098;
	{long i; for (i = 503; i < 505; i++) R3329[i] = (char *(*)()) F293_4098;}
	{long i; for (i = 505; i < 507; i++) R3329[i] = (char *(*)()) F296_4098;}
	R3329[729] = (char *(*)()) F299_4098;
	R3329[733] = (char *(*)()) F302_4098;
	{long i; for (i = 892; i < 902; i++) R3329[i] = (char *(*)()) F293_4098;}
	R3329[1004] = (char *(*)()) F299_4098;
}

static EIF_TYPE_INDEX Y3330_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype12[] = {977,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype13[] = {977,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype43[] = {0xFF01,23,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype47[] = {0xFF01,326,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype49[] = {0xFF01,1027,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype52[] = {959,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype53[] = {989,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype54[] = {989,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype55[] = {986,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype57[] = {0xFF01,1274,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype58[] = {0xFF01,1133,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype59[] = {0xFF01,1147,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype60[] = {0xFF01,1148,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype61[] = {0xFF01,1137,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype62[] = {0xFF01,1141,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype63[] = {0xFF01,1142,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype64[] = {0xFF01,1135,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype65[] = {0xFF01,1191,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype66[] = {989,0xFFFF};
static EIF_TYPE_INDEX Y3330_pgtype67[] = {989,0xFFFF};
EIF_TYPE_INDEX *Y3330_gen_type [1022];
EIF_TYPE_INDEX Y3330 [1022];
void Y3330_init (void)
{
	egc_routines_types [3330] = Y3330;
	egc_routines_gen_types [3330] = Y3330_gen_type;
	egc_routines_offset [3330] = 292;
	Y3330_gen_type [0] = Y3330_pgtype0;
	Y3330_gen_type [1] = Y3330_pgtype1;
	Y3330_gen_type [2] = Y3330_pgtype2;
	Y3330_gen_type [3] = Y3330_pgtype3;
	Y3330_gen_type [4] = Y3330_pgtype4;
	Y3330_gen_type [5] = Y3330_pgtype5;
	Y3330_gen_type [6] = Y3330_pgtype6;
	Y3330_gen_type [7] = Y3330_pgtype7;
	Y3330_gen_type [8] = Y3330_pgtype8;
	Y3330_gen_type [9] = Y3330_pgtype9;
	Y3330_gen_type [10] = Y3330_pgtype10;
	Y3330_gen_type [11] = Y3330_pgtype11;
	Y3330_gen_type [16] = Y3330_pgtype12;
	Y3330_gen_type [17] = Y3330_pgtype13;
	Y3330_gen_type [414] = Y3330_pgtype14;
	Y3330_gen_type [415] = Y3330_pgtype15;
	Y3330_gen_type [416] = Y3330_pgtype16;
	Y3330_gen_type [417] = Y3330_pgtype17;
	Y3330_gen_type [418] = Y3330_pgtype18;
	Y3330_gen_type [419] = Y3330_pgtype19;
	Y3330_gen_type [420] = Y3330_pgtype20;
	Y3330_gen_type [421] = Y3330_pgtype21;
	Y3330_gen_type [422] = Y3330_pgtype22;
	Y3330_gen_type [423] = Y3330_pgtype23;
	Y3330_gen_type [424] = Y3330_pgtype24;
	Y3330_gen_type [425] = Y3330_pgtype25;
	Y3330_gen_type [426] = Y3330_pgtype26;
	Y3330_gen_type [427] = Y3330_pgtype27;
	Y3330_gen_type [428] = Y3330_pgtype28;
	Y3330_gen_type [429] = Y3330_pgtype29;
	Y3330_gen_type [430] = Y3330_pgtype30;
	Y3330_gen_type [501] = Y3330_pgtype31;
	Y3330_gen_type [502] = Y3330_pgtype32;
	Y3330_gen_type [503] = Y3330_pgtype33;
	Y3330_gen_type [504] = Y3330_pgtype34;
	Y3330_gen_type [505] = Y3330_pgtype35;
	Y3330_gen_type [506] = Y3330_pgtype36;
	Y3330_gen_type [507] = Y3330_pgtype37;
	Y3330_gen_type [508] = Y3330_pgtype38;
	Y3330_gen_type [509] = Y3330_pgtype39;
	Y3330_gen_type [510] = Y3330_pgtype40;
	Y3330_gen_type [511] = Y3330_pgtype41;
	Y3330_gen_type [512] = Y3330_pgtype42;
	Y3330_gen_type [513] = Y3330_pgtype43;
	Y3330_gen_type [514] = Y3330_pgtype44;
	Y3330_gen_type [515] = Y3330_pgtype45;
	Y3330_gen_type [516] = Y3330_pgtype46;
	Y3330_gen_type [517] = Y3330_pgtype47;
	Y3330_gen_type [518] = Y3330_pgtype48;
	Y3330_gen_type [519] = Y3330_pgtype49;
	Y3330_gen_type [520] = Y3330_pgtype50;
	Y3330_gen_type [521] = Y3330_pgtype51;
	Y3330_gen_type [522] = Y3330_pgtype52;
	Y3330_gen_type [745] = Y3330_pgtype53;
	Y3330_gen_type [746] = Y3330_pgtype54;
	Y3330_gen_type [749] = Y3330_pgtype55;
	Y3330_gen_type [908] = Y3330_pgtype56;
	Y3330_gen_type [909] = Y3330_pgtype57;
	Y3330_gen_type [910] = Y3330_pgtype58;
	Y3330_gen_type [911] = Y3330_pgtype59;
	Y3330_gen_type [912] = Y3330_pgtype60;
	Y3330_gen_type [913] = Y3330_pgtype61;
	Y3330_gen_type [914] = Y3330_pgtype62;
	Y3330_gen_type [915] = Y3330_pgtype63;
	Y3330_gen_type [916] = Y3330_pgtype64;
	Y3330_gen_type [917] = Y3330_pgtype65;
	Y3330_gen_type [1020] = Y3330_pgtype66;
	Y3330_gen_type [1021] = Y3330_pgtype67;
	{long i; for (i = 16; i < 18; i++) Y3330[i] = 977;};
	Y3330[513] = 23;
	Y3330[517] = 326;
	Y3330[519] = 1027;
	Y3330[522] = 959;
	{long i; for (i = 745; i < 747; i++) Y3330[i] = 989;};
	Y3330[749] = 986;
	Y3330[909] = 1274;
	Y3330[910] = 1133;
	Y3330[911] = 1147;
	Y3330[912] = 1148;
	Y3330[913] = 1137;
	Y3330[914] = 1141;
	Y3330[915] = 1142;
	Y3330[916] = 1135;
	Y3330[917] = 1191;
	{long i; for (i = 1020; i < 1022; i++) Y3330[i] = 989;};
}


#ifdef __cplusplus
}
#endif
