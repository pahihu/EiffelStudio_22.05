#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

EIF_TYPE_INDEX *Y1032_gen_type [2];
EIF_TYPE_INDEX Y1032 [2];
void Y1032_init (void)
{
	egc_routines_types [1032] = Y1032;
	egc_routines_gen_types [1032] = Y1032_gen_type;
	egc_routines_offset [1032] = 79;
	Y1032[0] = 160;
	Y1032[1] = 161;
}

long O1278[3];
void O1278_init () {
	O1278[0] = 0;
	O1278[2] =  + _REFACS_16_;
}

long O1279[3];
void O1279_init () {
	O1279[0] = + _LNGOFF_12_0_0_0_;
	O1279[2] = + _LNGOFF_35_0_0_0_;
}

long O1283[3];
void O1283_init () {
	O1283[0] =  + _REFACS_1_;
	O1283[2] =  + _REFACS_17_;
}

long O1284[3];
void O1284_init () {
	O1284[0] = + _LNGOFF_12_0_0_1_;
	O1284[2] = + _LNGOFF_35_0_0_1_;
}

long O1285[3];
void O1285_init () {
	O1285[0] =  + _REFACS_2_;
	O1285[2] =  + _REFACS_18_;
}

long O1286[3];
void O1286_init () {
	O1286[0] =  + _REFACS_3_;
	O1286[2] =  + _REFACS_19_;
}

long O1287[3];
void O1287_init () {
	O1287[0] =  + _REFACS_4_;
	O1287[2] =  + _REFACS_20_;
}

long O1288[3];
void O1288_init () {
	O1288[0] =  + _REFACS_5_;
	O1288[2] =  + _REFACS_21_;
}

long O1289[3];
void O1289_init () {
	O1289[0] =  + _REFACS_6_;
	O1289[2] =  + _REFACS_22_;
}

long O1290[3];
void O1290_init () {
	O1290[0] =  + _REFACS_7_;
	O1290[2] =  + _REFACS_23_;
}

long O1291[3];
void O1291_init () {
	O1291[0] = + _LNGOFF_12_0_0_2_;
	O1291[2] = + _LNGOFF_35_0_0_2_;
}

long O1295[3];
void O1295_init () {
	O1295[0] =  + _REFACS_8_;
	O1295[2] =  + _REFACS_24_;
}

long O1296[3];
void O1296_init () {
	O1296[0] = + _LNGOFF_12_0_0_3_;
	O1296[2] = + _LNGOFF_35_0_0_3_;
}

long O1297[3];
void O1297_init () {
	O1297[0] =  + _REFACS_9_;
	O1297[2] =  + _REFACS_25_;
}

long O1298[3];
void O1298_init () {
	O1298[0] =  + _REFACS_10_;
	O1298[2] =  + _REFACS_26_;
}

long O1299[3];
void O1299_init () {
	O1299[0] =  + _REFACS_11_;
	O1299[2] =  + _REFACS_27_;
}

long O1351[1205];
void O1351_init () {
	{long i; for (i = 0; i < 3; i++) O1351[i] = + _LNGOFF_1_0_0_0_;}
	O1351[1046] = + _LNGOFF_2_0_0_0_;
	{long i; for (i = 1064; i < 1068; i++) O1351[i] = + _LNGOFF_3_1_0_0_;}
	O1351[1082] = + _LNGOFF_2_0_0_0_;
	O1351[1090] = + _LNGOFF_4_0_0_0_;
	O1351[1134] = + _LNGOFF_2_0_0_0_;
	O1351[1135] = + _LNGOFF_2_3_0_0_;
	O1351[1150] = + _LNGOFF_5_0_0_0_;
	{long i; for (i = 1158; i < 1160; i++) O1351[i] = + _LNGOFF_4_1_0_0_;}
	O1351[1160] = + _LNGOFF_5_1_0_0_;
	{long i; for (i = 1161; i < 1165; i++) O1351[i] = + _LNGOFF_2_0_0_0_;}
	O1351[1165] = + _LNGOFF_3_0_0_0_;
	O1351[1166] = + _LNGOFF_2_0_0_0_;
	O1351[1169] = + _LNGOFF_4_1_0_0_;
	{long i; for (i = 1180; i < 1186; i++) O1351[i] = + _LNGOFF_3_0_0_0_;}
	O1351[1186] = + _LNGOFF_4_0_0_0_;
	{long i; for (i = 1187; i < 1205; i++) O1351[i] = + _LNGOFF_3_0_0_0_;}
}

long O1869[1149];
void O1869_init () {
	O1869[0] = + _LNGOFF_0_0_3_1_;
	O1869[1079] = + _LNGOFF_0_0_3_1_;
	O1869[1080] = + _LNGOFF_1_0_3_1_;
	O1869[1081] = + _LNGOFF_0_0_3_1_;
	{long i; for (i = 1082; i < 1084; i++) O1869[i] = + _LNGOFF_1_0_3_1_;}
	{long i; for (i = 1084; i < 1086; i++) O1869[i] = + _LNGOFF_0_0_3_1_;}
	O1869[1086] = + _LNGOFF_1_0_3_1_;
	O1869[1098] = + _LNGOFF_1_0_3_1_;
	{long i; for (i = 1122; i < 1125; i++) O1869[i] = + _LNGOFF_0_0_3_1_;}
	O1869[1139] = + _LNGOFF_0_1_3_1_;
	O1869[1140] = + _LNGOFF_0_0_3_1_;
	O1869[1141] = + _LNGOFF_2_0_3_1_;
	O1869[1142] = + _LNGOFF_1_2_3_1_;
	{long i; for (i = 1143; i < 1145; i++) O1869[i] = + _LNGOFF_0_0_3_1_;}
	O1869[1145] = + _LNGOFF_0_1_3_2_;
	O1869[1146] = + _LNGOFF_1_1_3_2_;
	O1869[1147] = + _LNGOFF_2_2_3_1_;
	O1869[1148] = + _LNGOFF_3_3_3_1_;
}

long O1874[1149];
void O1874_init () {
	O1874[0] = + _LNGOFF_0_0_3_2_;
	O1874[1079] = + _LNGOFF_0_0_3_2_;
	O1874[1080] = + _LNGOFF_1_0_3_2_;
	O1874[1081] = + _LNGOFF_0_0_3_2_;
	{long i; for (i = 1082; i < 1084; i++) O1874[i] = + _LNGOFF_1_0_3_2_;}
	{long i; for (i = 1084; i < 1086; i++) O1874[i] = + _LNGOFF_0_0_3_2_;}
	O1874[1086] = + _LNGOFF_1_0_3_2_;
	O1874[1098] = + _LNGOFF_1_0_3_2_;
	{long i; for (i = 1122; i < 1125; i++) O1874[i] = + _LNGOFF_0_0_3_2_;}
	O1874[1139] = + _LNGOFF_0_1_3_2_;
	O1874[1140] = + _LNGOFF_0_0_3_2_;
	O1874[1141] = + _LNGOFF_2_0_3_2_;
	O1874[1142] = + _LNGOFF_1_2_3_2_;
	{long i; for (i = 1143; i < 1145; i++) O1874[i] = + _LNGOFF_0_0_3_2_;}
	O1874[1145] = + _LNGOFF_0_1_3_3_;
	O1874[1146] = + _LNGOFF_1_1_3_3_;
	O1874[1147] = + _LNGOFF_2_2_3_2_;
	O1874[1148] = + _LNGOFF_3_3_3_2_;
}

long O1889[1149];
void O1889_init () {
	O1889[0] = + _LNGOFF_0_0_3_0_;
	O1889[1079] = + _LNGOFF_0_0_3_0_;
	O1889[1080] = + _LNGOFF_1_0_3_0_;
	O1889[1081] = + _LNGOFF_0_0_3_0_;
	{long i; for (i = 1082; i < 1084; i++) O1889[i] = + _LNGOFF_1_0_3_0_;}
	{long i; for (i = 1084; i < 1086; i++) O1889[i] = + _LNGOFF_0_0_3_0_;}
	O1889[1086] = + _LNGOFF_1_0_3_0_;
	O1889[1098] = + _LNGOFF_1_0_3_0_;
	{long i; for (i = 1122; i < 1125; i++) O1889[i] = + _LNGOFF_0_0_3_0_;}
	O1889[1139] = + _LNGOFF_0_1_3_0_;
	O1889[1140] = + _LNGOFF_0_0_3_0_;
	O1889[1141] = + _LNGOFF_2_0_3_0_;
	O1889[1142] = + _LNGOFF_1_2_3_0_;
	{long i; for (i = 1143; i < 1145; i++) O1889[i] = + _LNGOFF_0_0_3_0_;}
	O1889[1145] = + _LNGOFF_0_1_3_1_;
	O1889[1146] = + _LNGOFF_1_1_3_1_;
	O1889[1147] = + _LNGOFF_2_2_3_0_;
	O1889[1148] = + _LNGOFF_3_3_3_0_;
}

long O1890[1149];
void O1890_init () {
	O1890[0] = + _I16OFF_0_0_0_;
	O1890[1079] = + _I16OFF_0_0_0_;
	O1890[1080] = + _I16OFF_1_0_0_;
	O1890[1081] = + _I16OFF_0_0_0_;
	{long i; for (i = 1082; i < 1084; i++) O1890[i] = + _I16OFF_1_0_0_;}
	{long i; for (i = 1084; i < 1086; i++) O1890[i] = + _I16OFF_0_0_0_;}
	O1890[1086] = + _I16OFF_1_0_0_;
	O1890[1098] = + _I16OFF_1_0_0_;
	{long i; for (i = 1122; i < 1125; i++) O1890[i] = + _I16OFF_0_0_0_;}
	O1890[1139] = + _I16OFF_0_1_0_;
	O1890[1140] = + _I16OFF_0_0_0_;
	O1890[1141] = + _I16OFF_2_0_0_;
	O1890[1142] = + _I16OFF_1_2_0_;
	{long i; for (i = 1143; i < 1145; i++) O1890[i] = + _I16OFF_0_0_0_;}
	O1890[1145] = + _I16OFF_0_1_0_;
	O1890[1146] = + _I16OFF_1_1_0_;
	O1890[1147] = + _I16OFF_2_2_0_;
	O1890[1148] = + _I16OFF_3_3_0_;
}

long O1891[1149];
void O1891_init () {
	O1891[0] = + _I16OFF_0_0_1_;
	O1891[1079] = + _I16OFF_0_0_1_;
	O1891[1080] = + _I16OFF_1_0_1_;
	O1891[1081] = + _I16OFF_0_0_1_;
	{long i; for (i = 1082; i < 1084; i++) O1891[i] = + _I16OFF_1_0_1_;}
	{long i; for (i = 1084; i < 1086; i++) O1891[i] = + _I16OFF_0_0_1_;}
	O1891[1086] = + _I16OFF_1_0_1_;
	O1891[1098] = + _I16OFF_1_0_1_;
	{long i; for (i = 1122; i < 1125; i++) O1891[i] = + _I16OFF_0_0_1_;}
	O1891[1139] = + _I16OFF_0_1_1_;
	O1891[1140] = + _I16OFF_0_0_1_;
	O1891[1141] = + _I16OFF_2_0_1_;
	O1891[1142] = + _I16OFF_1_2_1_;
	{long i; for (i = 1143; i < 1145; i++) O1891[i] = + _I16OFF_0_0_1_;}
	O1891[1145] = + _I16OFF_0_1_1_;
	O1891[1146] = + _I16OFF_1_1_1_;
	O1891[1147] = + _I16OFF_2_2_1_;
	O1891[1148] = + _I16OFF_3_3_1_;
}

long O1892[1149];
void O1892_init () {
	O1892[0] = + _I16OFF_0_0_2_;
	O1892[1079] = + _I16OFF_0_0_2_;
	O1892[1080] = + _I16OFF_1_0_2_;
	O1892[1081] = + _I16OFF_0_0_2_;
	{long i; for (i = 1082; i < 1084; i++) O1892[i] = + _I16OFF_1_0_2_;}
	{long i; for (i = 1084; i < 1086; i++) O1892[i] = + _I16OFF_0_0_2_;}
	O1892[1086] = + _I16OFF_1_0_2_;
	O1892[1098] = + _I16OFF_1_0_2_;
	{long i; for (i = 1122; i < 1125; i++) O1892[i] = + _I16OFF_0_0_2_;}
	O1892[1139] = + _I16OFF_0_1_2_;
	O1892[1140] = + _I16OFF_0_0_2_;
	O1892[1141] = + _I16OFF_2_0_2_;
	O1892[1142] = + _I16OFF_1_2_2_;
	{long i; for (i = 1143; i < 1145; i++) O1892[i] = + _I16OFF_0_0_2_;}
	O1892[1145] = + _I16OFF_0_1_2_;
	O1892[1146] = + _I16OFF_1_1_2_;
	O1892[1147] = + _I16OFF_2_2_2_;
	O1892[1148] = + _I16OFF_3_3_2_;
}

long O1966[9];
void O1966_init () {
	O1966[0] = 0;
	O1966[1] = + _LNGOFF_0_0_0_0_;
	O1966[2] = + _I64OFF_0_0_0_0_0_0_0_;
	O1966[3] = + _LNGOFF_0_0_0_0_;
	O1966[4] = + _CHROFF_0_0_;
	O1966[5] = 0;
	O1966[6] = + _LNGOFF_1_0_0_0_;
	O1966[7] = + _CHROFF_1_0_;
	O1966[8] = 0;
}

long O1970[4];
void O1970_init () {
	O1970[0] =  + _REFACS_1_;
	{long i; for (i = 1; i < 3; i++) O1970[i] = 0;}
	O1970[3] =  + _REFACS_1_;
}

long O2156[3];
void O2156_init () {
	O2156[0] = + _LNGOFF_1_0_0_0_;
	O2156[1] = + _LNGOFF_2_0_0_0_;
	O2156[2] = + _LNGOFF_1_0_0_0_;
}

long O2160[3];
void O2160_init () {
	O2160[0] = + _LNGOFF_1_0_0_1_;
	O2160[1] = + _LNGOFF_2_0_0_1_;
	O2160[2] = + _LNGOFF_1_0_0_1_;
}

long O2182[1020];
void O2182_init () {
	O2182[0] = 0;
	{long i; for (i = 1009; i < 1013; i++) O2182[i] = 0;}
	O2182[1013] =  + _REFACS_1_;
	{long i; for (i = 1014; i < 1020; i++) O2182[i] = 0;}
}

long O2281[4];
void O2281_init () {
	O2281[0] = + _CHROFF_6_0_;
	O2281[1] = + _CHROFF_8_0_;
	O2281[2] = + _CHROFF_7_0_;
	O2281[3] = + _CHROFF_8_0_;
}

long O2339[4];
void O2339_init () {
	{long i; for (i = 0; i < 3; i++) O2339[i] = + _CHROFF_2_0_;}
	O2339[3] = + _CHROFF_2_1_;
}

long O2340[4];
void O2340_init () {
	{long i; for (i = 0; i < 3; i++) O2340[i] = + _CHROFF_2_1_;}
	O2340[3] = + _CHROFF_2_2_;
}

static EIF_TYPE_INDEX Y2486_pgtype0[] = {0xFF01,119,0xFFFF};
static EIF_TYPE_INDEX Y2486_pgtype1[] = {0xFF01,119,0xFFFF};
static EIF_TYPE_INDEX Y2486_pgtype2[] = {0xFF01,818,0xFFFF};
static EIF_TYPE_INDEX Y2486_pgtype3[] = {0xFF01,119,0xFFFF};
static EIF_TYPE_INDEX Y2486_pgtype4[] = {0xFF01,119,0xFFFF};
static EIF_TYPE_INDEX Y2486_pgtype5[] = {0xFF01,818,0xFFFF};
static EIF_TYPE_INDEX Y2486_pgtype6[] = {0xFF01,818,0xFFFF};
static EIF_TYPE_INDEX Y2486_pgtype7[] = {0xFF01,818,0xFFFF};
EIF_TYPE_INDEX *Y2486_gen_type [862];
EIF_TYPE_INDEX Y2486 [862];
void Y2486_init (void)
{
	egc_routines_types [2486] = Y2486;
	egc_routines_gen_types [2486] = Y2486_gen_type;
	egc_routines_offset [2486] = 202;
	Y2486_gen_type [0] = Y2486_pgtype0;
	Y2486_gen_type [1] = Y2486_pgtype1;
	Y2486_gen_type [2] = Y2486_pgtype2;
	Y2486_gen_type [3] = Y2486_pgtype3;
	Y2486_gen_type [4] = Y2486_pgtype4;
	Y2486_gen_type [5] = Y2486_pgtype5;
	Y2486_gen_type [126] = Y2486_pgtype6;
	Y2486_gen_type [861] = Y2486_pgtype7;
	{long i; for (i = 0; i < 2; i++) Y2486[i] = 119;};
	Y2486[2] = 818;
	{long i; for (i = 3; i < 5; i++) Y2486[i] = 119;};
	Y2486[5] = 818;
	Y2486[126] = 818;
	Y2486[861] = 818;
}


#ifdef __cplusplus
}
#endif
