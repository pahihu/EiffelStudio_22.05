/*
 * Code for class PARENT_LIST_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pa534.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PARENT_LIST_AS}.process */
void F1208_12803 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2609[Dtype(RTCW(arg1))-211])(arg1, Current);
}

/* {PARENT_LIST_AS}.first_token */
EIF_REFERENCE F1208_12804 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		RTLE;
		return (EIF_REFERENCE) F1201_12709(Current, arg1);
	} else {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_) != ((EIF_INTEGER_32) 0L))) {
			RTLE;
			return (EIF_REFERENCE) F1208_12810(Current, arg1);
		}
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {PARENT_LIST_AS}.last_token */
EIF_REFERENCE F1208_12805 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		RTLE;
		return (EIF_REFERENCE) F1201_12710(Current, arg1);
	} else {
		Result = F1201_12710(Current, arg1);
		tb1 = '\0';
		tb2 = '\01';
		if (!(EIF_BOOLEAN)(Result == NULL)) {
			tb3 = F132_1904(RTCW(Result));
			tb2 = tb3;
		}
		if (tb2) {
			tb1 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_) != ((EIF_INTEGER_32) 0L));
		}
		if (tb1) {
			Result = F1208_12810(Current, arg1);
			RTLE;
			return (EIF_REFERENCE) Result;
		}
	}
	RTLE;
	return Result;
}

/* {PARENT_LIST_AS}.inherit_keyword */
EIF_REFERENCE F1208_12810 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11914(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_));
}

/* {PARENT_LIST_AS}.lcurly_symbol */
EIF_REFERENCE F1208_12811 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11915(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_));
}

/* {PARENT_LIST_AS}.rcurly_symbol */
EIF_REFERENCE F1208_12812 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11915(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_4_));
}

/* {PARENT_LIST_AS}.none_id_as */
EIF_REFERENCE F1208_12813 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_INTEGER_32 ti4_5;
	EIF_INTEGER_32 ti4_6;
	EIF_INTEGER_32 ti4_7;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_5_);
	tb1 = F320_4356(RTCW(arg1), loc1);
	if (tb1) {
		tb1 = '\0';
		tr1 = F320_4351(RTCW(arg1), loc1);
		loc2 = tr1;
		loc2 = RTRV(eif_new_type(1213, 0x01),loc2);
		if (EIF_TEST(loc2)) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9959[Dtype(loc2)-1211])(loc2, arg1);
			loc3 = tr1;
			tb1 = EIF_TEST(loc3);
		}
		if (tb1) {
			Result = RTLNS(eif_new_type(1274, 0x01).id, 1274, _OBJSIZ_0_0_3_5_0_0_0_0_);
			F1275_13556(RTCW(Result), loc3);
			ti4_1 = F132_1883(loc2);
			ti4_2 = F132_1884(loc2);
			ti4_3 = *(EIF_INTEGER_32 *)(loc2+ _LNGOFF_1_0_3_1_);
			ti4_4 = F132_1888(loc2);
			ti4_5 = F132_1889(loc2);
			ti4_6 = *(EIF_INTEGER_32 *)(loc2+ _LNGOFF_1_0_3_2_);
			ti4_7 = F132_1892(loc2);
			F132_1893(RTCW(Result), ti4_1, ti4_2, ti4_3, ti4_4, ti4_5, ti4_6, ti4_7);
			ti4_1 = *(EIF_INTEGER_32 *)(loc2+ _LNGOFF_1_0_3_3_);
			F1211_12839(RTCW(Result), ti4_1);
		}
	}
	RTLE;
	return Result;
}

/* {PARENT_LIST_AS}.set_inheritance_tokens */
void F1208_12814 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,arg4);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9961[Dtype(arg1)-1210]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_) = (EIF_INTEGER_32) ti4_1;
	}
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2) + O9961[Dtype(arg2)-1210]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_) = (EIF_INTEGER_32) ti4_1;
	}
	if ((EIF_BOOLEAN)(arg3 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg3)+ _LNGOFF_0_0_3_3_);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_5_) = (EIF_INTEGER_32) ti4_1;
	}
	if ((EIF_BOOLEAN)(arg4 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg4) + O9961[Dtype(arg4)-1210]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_4_) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

void EIF_Minit534 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
