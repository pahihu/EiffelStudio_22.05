/*
 * Code for class FORMAL_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "fo525.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {FORMAL_AS}.initialize */
void F1198_12662 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN arg3, EIF_BOOLEAN arg4, EIF_REFERENCE arg5)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg5);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_6_) = (EIF_BOOLEAN) arg2;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_7_) = (EIF_BOOLEAN) arg3;
	if (arg4) {
		F1192_12596(Current, arg5, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
	}
	if ((EIF_BOOLEAN)(arg5 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg5) + O9961[Dtype(arg5)-1210]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_8_0_5_) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

/* {FORMAL_AS}.process */
void F1198_12663 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2695[Dtype(RTCW(arg1))-211])(arg1, Current);
}

/* {FORMAL_AS}.formal_keyword */
EIF_REFERENCE F1198_12665 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11914(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_8_0_5_));
}

/* {FORMAL_AS}.first_token */
EIF_REFERENCE F1198_12671 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	Result = F1192_12584(Current, arg1);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_8_0_5_) != ((EIF_INTEGER_32) 0L)))) {
			Result = F1198_12665(Current, arg1);
			RTLE;
			return (EIF_REFERENCE) Result;
		} else {
			tr1 = *(EIF_REFERENCE *)(Current);
			Result = F1211_12834(RTCW(tr1), arg1);
		}
	}
	RTLE;
	return Result;
}

/* {FORMAL_AS}.last_token */
EIF_REFERENCE F1198_12672 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	Result = F1192_12585(Current, arg1);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		Result = F1211_12835(RTCW(tr1), arg1);
	}
	RTLE;
	return Result;
}

/* {FORMAL_AS}.dump */
EIF_REFERENCE F1198_12674 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1037, 0x01).id, 1037, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1036_8220(RTCW(Result), ((EIF_INTEGER_32) 3L));
	F1192_12599(Current, Result);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_7_)) {
		tr1 = RTMS_EX_H("expanded ",9,1955322656);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6257[Dtype(RTCW(Result))-1037])(Result, tr1);
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_6_)) {
		tr1 = RTMS_EX_H("reference ",10,2121684768);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6257[Dtype(RTCW(Result))-1037])(Result, tr1);
	}
	tr1 = RTMS_EX_H("G#",2,18211);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6257[Dtype(RTCW(Result))-1037])(Result, tr1);
	F1038_8336(RTCW(Result), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_8_0_6_));
	RTLE;
	return Result;
}

/* {FORMAL_AS}.set_position */
void F1198_12675 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_8_0_6_) = (EIF_INTEGER_32) arg1;
}

void EIF_Minit525 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
