/*
 * Code for class BREAK_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "br538.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BREAK_AS}.make */
void F1212_12840 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6213[Dtype(RTCW(arg1))-1036])(arg1);
	F1212_12848(Current, tr1);
	F132_1880(Current, arg2, arg3, arg4, arg5, arg6, arg7, arg8);
	RTLE;
}

/* {BREAK_AS}.process */
void F1212_12842 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2545[Dtype(RTCW(arg1))-211])(arg1, Current);
}

/* {BREAK_AS}.literal_text */
EIF_REFERENCE F1212_12844 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current);
}

/* {BREAK_AS}.extract_comment */
EIF_REFERENCE F1212_12846 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_8 loc6 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc7 = (EIF_CHARACTER_8) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_8 loc9 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc13 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLR(3,loc12);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	loc6 = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '-';
	loc7 = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\012';
	ti4_1 = F132_1884(Current);
	loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L));
	loc1 = F132_1883(Current);
	loc2 = F132_1884(Current);
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc4 = F132_1888(Current);
	loc10 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	Result = RTLNS(eif_new_type(809, 0x01).id, 809, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F810_5651(RTCW(Result));
	loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	for (;;) {
		if ((EIF_BOOLEAN) (loc10 > loc4)) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		loc9 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4122[Dtype(RTCW(tr1))-706])(tr1, loc10));
		if (loc8) {
			if ((EIF_BOOLEAN)(loc9 == loc7)) {
				loc13 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc11 + ((EIF_INTEGER_32) 2L)) <= (EIF_INTEGER_32) (loc10 - ((EIF_INTEGER_32) 1L)))) {
					tr1 = *(EIF_REFERENCE *)(Current);
					loc12 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6151[Dtype(RTCW(tr1))-1036])(tr1, (EIF_INTEGER_32) (loc11 + ((EIF_INTEGER_32) 2L)), (EIF_INTEGER_32) (loc10 - ((EIF_INTEGER_32) 1L)));
					tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4122[Dtype(RTCW(loc12))-706])(loc12, ((EIF_INTEGER_32) 1L)));
					if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '|')) {
						loc13 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
					tr1 = RTMS_EX_H("\015",1,13);
					tr2 = RTMS_EX_H("",0,0);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R6246[Dtype(RTCW(loc12))-1037])(loc12, tr1, tr2);
				} else {
					loc12 = RTMS_EX_H("",0,0);
				}
				tr1 = RTLNS(eif_new_type(326, 0x01).id, 326, _OBJSIZ_1_2_0_5_0_0_0_0_);
				F327_4757(RTCW(tr1), loc12, loc1, loc2, (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_3_1_) + loc11) - ((EIF_INTEGER_32) 1L)), loc5, loc13, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_3_3_), loc11);
				F794_5612(RTCW(Result), tr1);
				loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				loc1++;
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		} else {
			if ((EIF_BOOLEAN)(loc9 == loc6)) {
				loc11 = (EIF_INTEGER_32) loc10;
				loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc10++;
			} else {
				if ((EIF_BOOLEAN)(loc9 == loc7)) {
					loc1++;
					loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					loc2++;
				}
			}
		}
		loc10++;
	}
	RTLE;
	return Result;
}

/* {BREAK_AS}.set_internal_text */
void F1212_12848 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

void EIF_Minit538 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
