/*
 * Code for class KEYWORD_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ke542.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KEYWORD_AS}.make */
void F1216_12904 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current + O10080[Dtype(Current)-1215]) = (EIF_INTEGER_32) arg1;
	F132_1880(Current, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
	RTLE;
}

/* {KEYWORD_AS}.process */
void F1216_12970 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2543[Dtype(RTCW(arg1))-211])(arg1, Current);
}

void EIF_Minit542 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
