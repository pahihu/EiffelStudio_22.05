
#ifndef _C11_ke509_
#define _C11_ke509_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1181_12533(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit509(void);
extern char *(*R2612[])();

#ifdef __cplusplus
}
#endif

#endif
