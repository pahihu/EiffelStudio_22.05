
#ifndef _C11_un514_
#define _C11_un514_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1187_12546(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit514(void);
extern char *(*R2618[])();

#ifdef __cplusplus
}
#endif

#endif
