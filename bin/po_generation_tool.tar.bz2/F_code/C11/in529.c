/*
 * Code for class INDEXING_CLAUSE_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "in529.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {INDEXING_CLAUSE_AS}.process */
void F1203_12722 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2577[Dtype(RTCW(arg1))-211])(arg1, Current);
}

/* {INDEXING_CLAUSE_AS}.first_token */
EIF_REFERENCE F1203_12723 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		RTLE;
		return (EIF_REFERENCE) F1201_12709(Current, arg1);
	} else {
		RTLE;
		return (EIF_REFERENCE) F1203_12778(Current, arg1);
	}/* NOTREACHED */
	
}

/* {INDEXING_CLAUSE_AS}.last_token */
EIF_REFERENCE F1203_12724 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		RTLE;
		return (EIF_REFERENCE) F1201_12710(Current, arg1);
	} else {
		Result = F1203_12779(Current, arg1);
		if ((EIF_BOOLEAN)(Result == NULL)) {
			if ((EIF_BOOLEAN) !F615_5084(Current)) {
				Result = F1201_12710(Current, arg1);
				RTLE;
				return (EIF_REFERENCE) Result;
			} else {
				Result = F1203_12778(Current, arg1);
				RTLE;
				return (EIF_REFERENCE) Result;
			}
		}
	}
	RTLE;
	return Result;
}

/* {INDEXING_CLAUSE_AS}.has_global_once */
EIF_BOOLEAN F1203_12730 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(12757,F1203_12757, (Current));
	tr2 = RTOSCF(12764,F1203_12764, (Current));
	Result = F1203_12774(Current, tr1, tr2);
	RTLE;
	return Result;
}

/* {INDEXING_CLAUSE_AS}.index_as_of_tag_name */
EIF_REFERENCE F1203_12742 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc2 = F794_5594(Current);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = F794_5577(Current, loc1);
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(RTCW(loc3));
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			tr1 = F1275_13565(loc4);
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6110[Dtype(RTCW(arg1))-1036])(arg1);
			tb2 = F1033_8133(RTCW(tr1), arg1, ((EIF_INTEGER_32) 1L), ti4_1, ((EIF_INTEGER_32) 1L));
			tb1 = tb2;
		}
		if (tb1) {
			Result = (EIF_REFERENCE) loc3;
			loc1 = (EIF_INTEGER_32) loc2;
		}
		loc1++;
	}
	RTLE;
	return Result;
}

/* {INDEXING_CLAUSE_AS}.once_status_index_as */
EIF_REFERENCE F1203_12743 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(12757,F1203_12757, (Current));
	Result = F1203_12742(Current, tr1);
	RTLE;
	return Result;
}

/* {INDEXING_CLAUSE_AS}.once_status_header */

EIF_REFERENCE F1203_12757 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (12757,RTMS_EX_H("once_status",11,1414855283));
}

/* {INDEXING_CLAUSE_AS}.global_value */

EIF_REFERENCE F1203_12764 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (12764,RTMS_EX_H("global",6,2072054124));
}

/* {INDEXING_CLAUSE_AS}.has_tag_value */
EIF_BOOLEAN F1203_12774 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLR(6,arg2);
	RTLR(7,loc4);
	RTLIU(8);
	
	RTGC;
	tr1 = F1203_12742(Current, arg1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_1_);
		loc2 = F794_5585(RTCW(tr1));
		for (;;) {
			tb1 = F419_4918(loc2);
			if (tb1) break;
			if (Result) break;
			Result = '\01';
			tb2 = '\0';
			tr1 = F419_4909(loc2);
			loc3 = tr1;
			loc3 = RTRV(eif_new_type(1278, 0x01),loc3);
			if (EIF_TEST(loc3)) {
				tr1 = *(EIF_REFERENCE *)(loc3);
				tb3 = F1036_8246(RTCW(tr1), arg2);
				tb2 = tb3;
			}
			if (!tb2) {
				tb2 = '\0';
				tr1 = F419_4909(loc2);
				loc4 = tr1;
				loc4 = RTRV(eif_new_type(1274, 0x01),loc4);
				if (EIF_TEST(loc4)) {
					tr1 = F1275_13565(loc4);
					tb3 = F1036_8246(RTCW(tr1), arg2);
					tb2 = tb3;
				}
				Result = tb2;
			}
			F419_4924(loc2);
		}
	}
	RTLE;
	return Result;
}

/* {INDEXING_CLAUSE_AS}.indexing_keyword */
EIF_REFERENCE F1203_12778 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11914(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_));
}

/* {INDEXING_CLAUSE_AS}.end_keyword */
EIF_REFERENCE F1203_12779 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11914(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_));
}

/* {INDEXING_CLAUSE_AS}.set_indexing_keyword */
void F1203_12780 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9961[Dtype(arg1)-1210]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

/* {INDEXING_CLAUSE_AS}.set_end_keyword */
void F1203_12781 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9961[Dtype(arg1)-1210]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

void EIF_Minit529 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
