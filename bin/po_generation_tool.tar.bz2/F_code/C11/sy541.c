/*
 * Code for class SYMBOL_STUB_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sy541.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SYMBOL_STUB_AS}.process */
void F1215_12895 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2547[Dtype(RTCW(arg1))-211])(arg1, Current);
}

/* {SYMBOL_STUB_AS}.literal_text */
RTEOMS(12895,34);
EIF_REFERENCE F1215_12896 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	switch (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_3_4_)) {
		case 306L:
			Result = (EIF_REFERENCE) RTOMS(12895,0);
			break;
		case 307L:
			Result = (EIF_REFERENCE) RTOMS(12895,1);
			break;
		case 258L:
			Result = (EIF_REFERENCE) RTOMS(12895,2);
			break;
		case 290L:
			Result = (EIF_REFERENCE) RTOMS(12895,3);
			break;
		case 316L:
			Result = RTOSCF(12903,F1215_12903, (Current));
			break;
		case 319L:
			Result = RTOSCF(12898,F1215_12898, (Current));
			break;
		case 298L:
			Result = RTOSCF(12897,F1215_12897, (Current));
			break;
		case 314L:
			Result = (EIF_REFERENCE) RTOMS(12895,4);
			break;
		case 315L:
			Result = (EIF_REFERENCE) RTOMS(12895,5);
			break;
		case 317L:
			Result = (EIF_REFERENCE) RTOMS(12895,6);
			break;
		case 287L:
			Result = (EIF_REFERENCE) RTOMS(12895,7);
			break;
		case 295L:
			Result = (EIF_REFERENCE) RTOMS(12895,8);
			break;
		case 263L:
			Result = (EIF_REFERENCE) RTOMS(12895,9);
			break;
		case 277L:
			Result = (EIF_REFERENCE) RTOMS(12895,10);
			break;
		case 262L:
			Result = RTOSCF(12900,F1215_12900, (Current));
			break;
		case 261L:
			Result = RTOSCF(12899,F1215_12899, (Current));
			break;
		case 281L:
			Result = (EIF_REFERENCE) RTOMS(12895,11);
			break;
		case 279L:
			Result = (EIF_REFERENCE) RTOMS(12895,12);
			break;
		case 308L:
			Result = (EIF_REFERENCE) RTOMS(12895,13);
			break;
		case 311L:
			Result = (EIF_REFERENCE) RTOMS(12895,14);
			break;
		case 280L:
			Result = (EIF_REFERENCE) RTOMS(12895,15);
			break;
		case 297L:
			Result = (EIF_REFERENCE) RTOMS(12895,16);
			break;
		case 304L:
			Result = (EIF_REFERENCE) RTOMS(12895,17);
			break;
		case 278L:
			Result = (EIF_REFERENCE) RTOMS(12895,18);
			break;
		case 283L:
			Result = (EIF_REFERENCE) RTOMS(12895,19);
			break;
		case 286L:
			Result = (EIF_REFERENCE) RTOMS(12895,20);
			break;
		case 276L:
			Result = (EIF_REFERENCE) RTOMS(12895,21);
			break;
		case 275L:
			Result = (EIF_REFERENCE) RTOMS(12895,22);
			break;
		case 282L:
			Result = (EIF_REFERENCE) RTOMS(12895,23);
			break;
		case 288L:
			Result = (EIF_REFERENCE) RTOMS(12895,24);
			break;
		case 318L:
			Result = (EIF_REFERENCE) RTOMS(12895,25);
			break;
		case 309L:
			Result = (EIF_REFERENCE) RTOMS(12895,26);
			break;
		case 312L:
			Result = (EIF_REFERENCE) RTOMS(12895,27);
			break;
		case 260L:
			Result = RTOSCF(12902,F1215_12902, (Current));
			break;
		case 259L:
			Result = RTOSCF(12901,F1215_12901, (Current));
			break;
		case 310L:
			Result = (EIF_REFERENCE) RTOMS(12895,28);
			break;
		case 305L:
			Result = (EIF_REFERENCE) RTOMS(12895,29);
			break;
		case 313L:
			Result = (EIF_REFERENCE) RTOMS(12895,30);
			break;
		case 285L:
			Result = (EIF_REFERENCE) RTOMS(12895,31);
			break;
		case 284L:
			Result = (EIF_REFERENCE) RTOMS(12895,32);
			break;
		case 274L:
			Result = (EIF_REFERENCE) RTOMS(12895,33);
			break;
		default:
			RTEC(EN_WHEN);
	}
	RTLE;
	return Result;
}

/* {SYMBOL_STUB_AS}.mathematical_left_white_square_bracket */
static EIF_REFERENCE F1215_12897_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (12897);
#define Result RTOSR(12897)
	RTOC_NEW(Result);
	tr2 = RTMS32_EX_H("\346\'\000\000",1,10214);
	tr1 = RTLNS(eif_new_type(67, 0x00).id, 67, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = F68_916(RTCW(tr1), tr2);
	RTOSE (12897);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1215_12897 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(12897,F1215_12897_body,(Current));
}

/* {SYMBOL_STUB_AS}.mathematical_right_white_square_bracket */
static EIF_REFERENCE F1215_12898_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (12898);
#define Result RTOSR(12898)
	RTOC_NEW(Result);
	tr2 = RTMS32_EX_H("\347\'\000\000",1,10215);
	tr1 = RTLNS(eif_new_type(67, 0x00).id, 67, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = F68_916(RTCW(tr1), tr2);
	RTOSE (12898);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1215_12898 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(12898,F1215_12898_body,(Current));
}

/* {SYMBOL_STUB_AS}.for_all */
static EIF_REFERENCE F1215_12899_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (12899);
#define Result RTOSR(12899)
	RTOC_NEW(Result);
	tr2 = RTMS32_EX_H("\000\"\000\000",1,8704);
	tr1 = RTLNS(eif_new_type(67, 0x00).id, 67, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = F68_916(RTCW(tr1), tr2);
	RTOSE (12899);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1215_12899 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(12899,F1215_12899_body,(Current));
}

/* {SYMBOL_STUB_AS}.there_exists */
static EIF_REFERENCE F1215_12900_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (12900);
#define Result RTOSR(12900)
	RTOC_NEW(Result);
	tr2 = RTMS32_EX_H("\003\"\000\000",1,8707);
	tr1 = RTLNS(eif_new_type(67, 0x00).id, 67, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = F68_916(RTCW(tr1), tr2);
	RTOSE (12900);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1215_12900 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(12900,F1215_12900_body,(Current));
}

/* {SYMBOL_STUB_AS}.clockwise_gapped_circle_arrow */
static EIF_REFERENCE F1215_12901_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (12901);
#define Result RTOSR(12901)
	RTOC_NEW(Result);
	tr2 = RTMS32_EX_H("\363\'\000\000",1,10227);
	tr1 = RTLNS(eif_new_type(67, 0x00).id, 67, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = F68_916(RTCW(tr1), tr2);
	RTOSE (12901);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1215_12901 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(12901,F1215_12901_body,(Current));
}

/* {SYMBOL_STUB_AS}.anticlockwise_gapped_circle_arrow */
static EIF_REFERENCE F1215_12902_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (12902);
#define Result RTOSR(12902)
	RTOC_NEW(Result);
	tr2 = RTMS32_EX_H("\362\'\000\000",1,10226);
	tr1 = RTLNS(eif_new_type(67, 0x00).id, 67, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = F68_916(RTCW(tr1), tr2);
	RTOSE (12902);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1215_12902 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(12902,F1215_12902_body,(Current));
}

/* {SYMBOL_STUB_AS}.broken_bar */
static EIF_REFERENCE F1215_12903_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (12903);
#define Result RTOSR(12903)
	RTOC_NEW(Result);
	tr2 = RTMS32_EX_H("\246\000\000\000",1,166);
	tr1 = RTLNS(eif_new_type(67, 0x00).id, 67, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = F68_916(RTCW(tr1), tr2);
	RTOSE (12903);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1215_12903 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(12903,F1215_12903_body,(Current));
}

void EIF_Minit541 (void)
{
	GTCX
	RTPOMS(12895,33,"~",1,126);
	RTPOMS(12895,32,"*",1,42);
	RTPOMS(12895,31,"/",1,47);
	RTPOMS(12895,30,";",1,59);
	RTPOMS(12895,29,"]",1,93);
	RTPOMS(12895,28,")",1,41);
	RTPOMS(12895,27,"}",1,125);
	RTPOMS(12895,26,">>",2,15934);
	RTPOMS(12895,25,"\?",1,63);
	RTPOMS(12895,24,"^",1,94);
	RTPOMS(12895,23,"+",1,43);
	RTPOMS(12895,22,"/~",2,12158);
	RTPOMS(12895,21,"/=",2,12093);
	RTPOMS(12895,20,"\\\\",2,23644);
	RTPOMS(12895,19,"-",1,45);
	RTPOMS(12895,18,"<",1,60);
	RTPOMS(12895,17,"[",1,91);
	RTPOMS(12895,16,"(",1,40);
	RTPOMS(12895,15,"<=",2,15421);
	RTPOMS(12895,14,"{",1,123);
	RTPOMS(12895,13,"<<",2,15420);
	RTPOMS(12895,12,">",1,62);
	RTPOMS(12895,11,">=",2,15933);
	RTPOMS(12895,10,"=",1,61);
	RTPOMS(12895,9,"..",2,11822);
	RTPOMS(12895,8,".",1,46);
	RTPOMS(12895,7,"//",2,12079);
	RTPOMS(12895,6,"->",2,11582);
	RTPOMS(12895,5,",",1,44);
	RTPOMS(12895,4,":",1,58);
	RTPOMS(12895,3,"@",1,64);
	RTPOMS(12895,2,":=",2,14909);
	RTPOMS(12895,1,"$",1,36);
	RTPOMS(12895,0,"\?=",2,16189);
}


#ifdef __cplusplus
}
#endif
