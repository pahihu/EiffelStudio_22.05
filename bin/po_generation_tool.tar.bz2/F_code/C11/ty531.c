/*
 * Code for class TYPE_DEC_LIST_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ty531.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TYPE_DEC_LIST_AS}.first_token */
EIF_REFERENCE F1205_12789 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_) != ((EIF_INTEGER_32) 0L)))) {
		RTLE;
		return (EIF_REFERENCE) F1205_12794(Current, arg1);
	} else {
		RTLE;
		return (EIF_REFERENCE) F1201_12709(Current, arg1);
	}/* NOTREACHED */
	
}

/* {TYPE_DEC_LIST_AS}.last_token */
EIF_REFERENCE F1205_12790 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_) != ((EIF_INTEGER_32) 0L)))) {
		RTLE;
		return (EIF_REFERENCE) F1205_12795(Current, arg1);
	} else {
		RTLE;
		return (EIF_REFERENCE) F1201_12710(Current, arg1);
	}/* NOTREACHED */
	
}

/* {TYPE_DEC_LIST_AS}.process */
void F1205_12791 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2698[Dtype(RTCW(arg1))-211])(arg1, Current);
}

/* {TYPE_DEC_LIST_AS}.opening_bracket_as */
EIF_REFERENCE F1205_12794 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11915(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_));
}

/* {TYPE_DEC_LIST_AS}.closing_bracket_as */
EIF_REFERENCE F1205_12795 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11915(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_));
}

void EIF_Minit531 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
