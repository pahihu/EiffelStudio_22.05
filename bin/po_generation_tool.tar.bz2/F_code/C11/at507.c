/*
 * Code for class ATTRIBUTE_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "at507.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ATTRIBUTE_AS}.make */
void F1178_12515 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	F1175_12476(Current, arg1);
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2) + O9961[Dtype(arg2)-1210]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_1_) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

/* {ATTRIBUTE_AS}.process */
void F1178_12517 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2582[Dtype(RTCW(arg1))-211])(arg1, Current);
}

/* {ATTRIBUTE_AS}.attribute_keyword */
EIF_REFERENCE F1178_12519 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11914(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_1_));
}

/* {ATTRIBUTE_AS}.first_token */
EIF_REFERENCE F1178_12521 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			tr1 = F1201_12709(loc1, arg1);
			RTLE;
			return (EIF_REFERENCE) tr1;
		}
	} else {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_1_) != ((EIF_INTEGER_32) 0L))) {
			RTLE;
			return (EIF_REFERENCE) F1178_12519(Current, arg1);
		}
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {ATTRIBUTE_AS}.last_token */
EIF_REFERENCE F1178_12522 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1201_12710(loc1, arg1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		if ((EIF_BOOLEAN)(arg1 == NULL)) {
			Result = (EIF_REFERENCE) NULL;
		} else {
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_1_) != ((EIF_INTEGER_32) 0L))) {
				Result = F1178_12519(Current, arg1);
				RTLE;
				return (EIF_REFERENCE) Result;
			}
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit507 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
