/*
 * Code for class ONCE_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "on505.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ONCE_AS}.make */
void F1176_12485 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg3);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	F1175_12476(Current, arg3);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9961[Dtype(arg1)-1210]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_1_) = (EIF_INTEGER_32) ti4_1;
	}
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg2;
	RTLE;
}

/* {ONCE_AS}.process */
void F1176_12486 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2585[Dtype(RTCW(arg1))-211])(arg1, Current);
}

/* {ONCE_AS}.once_keyword */
EIF_REFERENCE F1176_12488 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11914(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_1_));
}

/* {ONCE_AS}.as_once */
EIF_REFERENCE F1176_12492 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) Current;
}

/* {ONCE_AS}.keys */
EIF_REFERENCE F1176_12493 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(loc1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {ONCE_AS}.has_invalid_key */
EIF_BOOLEAN F1176_12494 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	tr1 = F1176_12493(Current);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		F794_5602(loc2);
		for (;;) {
			tb1 = '\01';
			tb2 = F748_5258(loc2);
			if (!tb2) {
				tb1 = Result;
			}
			if (tb1) break;
			tr1 = F794_5576(loc2);
			loc1 = *(EIF_REFERENCE *)(RTCW(tr1));
			tb2 = '\01';
			tb3 = '\01';
			tr1 = RTOSCF(12505,F1176_12505, (Current));
			tb4 = F1036_8246(RTCW(loc1), tr1);
			if (!tb4) {
				tr1 = RTOSCF(12506,F1176_12506, (Current));
				tb4 = F1036_8246(RTCW(loc1), tr1);
				tb3 = tb4;
			}
			if (!tb3) {
				tr1 = RTOSCF(12507,F1176_12507, (Current));
				tb3 = F1036_8246(RTCW(loc1), tr1);
				tb2 = tb3;
			}
			if (tb2) {
				F794_5604(loc2);
			} else {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		}
	}
	RTLE;
	return Result;
}

/* {ONCE_AS}.invalid_key */
EIF_REFERENCE F1176_12495 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tr1 = F1176_12493(Current);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		F794_5602(loc2);
		for (;;) {
			tb1 = '\01';
			tb2 = F748_5258(loc2);
			if (!tb2) {
				tb1 = (EIF_BOOLEAN)(Result != NULL);
			}
			if (tb1) break;
			tr1 = F794_5576(loc2);
			loc1 = *(EIF_REFERENCE *)(RTCW(tr1));
			tb2 = '\01';
			tb3 = '\01';
			tr1 = RTOSCF(12505,F1176_12505, (Current));
			tb4 = F1036_8246(RTCW(loc1), tr1);
			if (!tb4) {
				tr1 = RTOSCF(12506,F1176_12506, (Current));
				tb4 = F1036_8246(RTCW(loc1), tr1);
				tb3 = tb4;
			}
			if (!tb3) {
				tr1 = RTOSCF(12507,F1176_12507, (Current));
				tb3 = F1036_8246(RTCW(loc1), tr1);
				tb2 = tb3;
			}
			if (tb2) {
				F794_5604(loc2);
			} else {
				Result = F794_5576(loc2);
			}
		}
	}
	RTLE;
	return Result;
}

/* {ONCE_AS}.has_key_conflict */
EIF_BOOLEAN F1176_12496 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc5);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	loc4 = F1176_12493(Current);
	loc1 = '\01';
	tr1 = RTOSCF(12505,F1176_12505, (Current));
	if (!F1176_12497(Current, tr1, loc4)) {
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			tb2 = F1203_12730(loc5);
			tb1 = tb2;
		}
		loc1 = tb1;
	}
	tr1 = RTOSCF(12506,F1176_12506, (Current));
	loc2 = F1176_12497(Current, tr1, loc4);
	tr1 = RTOSCF(12507,F1176_12507, (Current));
	loc3 = F1176_12497(Current, tr1, loc4);
	RTLE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 && loc2) || (EIF_BOOLEAN) (loc1 && loc3)) || (EIF_BOOLEAN) (loc3 && loc2));
}

/* {ONCE_AS}.has_key_inside */
EIF_BOOLEAN F1176_12497 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg2);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		F794_5602(RTCW(arg2));
		for (;;) {
			tb1 = '\01';
			tb2 = F748_5258(RTCW(arg2));
			if (!tb2) {
				tb1 = Result;
			}
			if (tb1) break;
			tr1 = F794_5576(RTCW(arg2));
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			Result = F1036_8246(RTCW(tr1), arg1);
			F794_5604(RTCW(arg2));
		}
	}
	RTLE;
	return Result;
}

/* {ONCE_AS}.first_token */
EIF_REFERENCE F1176_12502 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,Result);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTLE;
		return (EIF_REFERENCE) F1176_12488(Current, arg1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			Result = F1179_12530(loc1, NULL);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current);
			loc2 = tr1;
			if (EIF_TEST(loc2)) {
				Result = F1201_12709(loc2, NULL);
				RTLE;
				return (EIF_REFERENCE) Result;
			}
		}
	}
	RTLE;
	return Result;
}

/* {ONCE_AS}.last_token */
EIF_REFERENCE F1176_12503 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,loc2);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1201_12710(loc1, arg1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			Result = F1179_12531(loc2, arg1);
		} else {
			if ((EIF_BOOLEAN)(arg1 != NULL)) {
				Result = F1176_12488(Current, arg1);
				RTLE;
				return (EIF_REFERENCE) Result;
			}
		}
	}
	RTLE;
	return Result;
}

/* {ONCE_AS}.once_key_process */

EIF_REFERENCE F1176_12505 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (12505,RTMS_EX_H("PROCESS",7,753644115));
}

/* {ONCE_AS}.once_key_thread */

EIF_REFERENCE F1176_12506 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (12506,RTMS_EX_H("THREAD",6,1545974084));
}

/* {ONCE_AS}.once_key_object */

EIF_REFERENCE F1176_12507 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (12507,RTMS_EX_H("OBJECT",6,1401880404));
}

void EIF_Minit505 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
