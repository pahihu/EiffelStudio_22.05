
#ifndef _C11_in547_
#define _C11_in547_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1221_12993(EIF_REFERENCE, EIF_REFERENCE);
extern void F1221_12994(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1221_12997(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1221_12998(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit547(void);
extern char *(*R9356[])();
extern char *(*R9357[])();
extern char *(*R2682[])();

#ifdef __cplusplus
}
#endif

#endif
