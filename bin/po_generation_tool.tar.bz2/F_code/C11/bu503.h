
#ifndef _C11_bu503_
#define _C11_bu503_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1174_12471(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit503(void);
extern char *(*R2564[])();

#ifdef __cplusplus
}
#endif

#endif
