/*
 * Code for class GUARD_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gu549.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GUARD_AS}.initialize */
void F1223_13014 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLR(4,arg3);
	RTLR(5,arg4);
	RTLR(6,arg5);
	RTLIU(7);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9961[Dtype(arg1)-1210]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_0_0_0_) = (EIF_INTEGER_32) ti4_1;
	}
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg2;
	tr1 = F305_4099(Current, arg2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	if ((EIF_BOOLEAN)(arg3 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg3) + O9961[Dtype(arg3)-1210]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_0_0_1_) = (EIF_INTEGER_32) ti4_1;
	}
	RTAR(Current, arg4);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg4;
	RTAR(Current, arg5);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg5;
	RTLE;
}

/* {GUARD_AS}.process */
void F1223_13015 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2679[Dtype(RTCW(arg1))-211])(arg1, Current);
}

/* {GUARD_AS}.check_keyword */
EIF_REFERENCE F1223_13018 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11914(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_0_0_0_));
}

/* {GUARD_AS}.then_keyword */
EIF_REFERENCE F1223_13019 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11914(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_0_0_1_));
}

/* {GUARD_AS}.first_token */
EIF_REFERENCE F1223_13025 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLR(4,tr1);
	RTLR(5,loc2);
	RTLR(6,loc3);
	RTLIU(7);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		Result = F1223_13018(Current, arg1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc1 = tr1;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == NULL) && EIF_TEST(loc1))) {
		Result = F1201_12709(loc1, arg1);
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == NULL) && (EIF_BOOLEAN)(arg1 != NULL))) {
		Result = F1223_13019(Current, arg1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc2 = tr1;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == NULL) && EIF_TEST(loc2))) {
		Result = F1201_12709(loc2, NULL);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc3 = tr1;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == NULL) && EIF_TEST(loc3))) {
		Result = F1211_12834(loc3, arg1);
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {GUARD_AS}.last_token */
EIF_REFERENCE F1223_13026 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1211_12835(loc1, arg1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

void EIF_Minit549 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
