
#ifndef _C11_fo510_
#define _C11_fo510_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1182_12534(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit510(void);
extern char *(*R2611[])();

#ifdef __cplusplus
}
#endif

#endif
