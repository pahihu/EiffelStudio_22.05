
#ifndef _C11_in504_
#define _C11_in504_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1175_12476(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit504(void);

#ifdef __cplusplus
}
#endif

#endif
