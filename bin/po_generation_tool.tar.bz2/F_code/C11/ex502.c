/*
 * Code for class EXTERNAL_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ex502.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EXTERNAL_AS}.initialize */
void F1173_12457 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,arg3);
	RTLR(6,arg4);
	RTLIU(7);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		tr1 = F306_4100(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(arg2));
		F326_4749(RTCW(tr1), tr2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCV(F306_4100(Current))+ _LNGOFF_2_1_0_0_);
		*(EIF_INTEGER_32 *)(Current + O9732[dtype-1172]) = (EIF_INTEGER_32) ti4_1;
	}
	if ((EIF_BOOLEAN)(arg3 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg3) + O9961[Dtype(arg3)-1210]);
		*(EIF_INTEGER_32 *)(Current + O9727[dtype-1172]) = (EIF_INTEGER_32) ti4_1;
	}
	if ((EIF_BOOLEAN)(arg4 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg4) + O9961[Dtype(arg4)-1210]);
		*(EIF_INTEGER_32 *)(Current + O9726[dtype-1172]) = (EIF_INTEGER_32) ti4_1;
	}
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg2;
	RTLE;
}

/* {EXTERNAL_AS}.process */
void F1173_12458 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2688[Dtype(RTCW(arg1))-211])(arg1, Current);
}

/* {EXTERNAL_AS}.alias_keyword */
EIF_REFERENCE F1173_12461 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11914(Current, arg1, *(EIF_INTEGER_32 *)(Current + O9726[Dtype(Current)-1172]));
}

/* {EXTERNAL_AS}.external_keyword */
EIF_REFERENCE F1173_12462 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11914(Current, arg1, *(EIF_INTEGER_32 *)(Current + O9727[Dtype(Current)-1172]));
}

/* {EXTERNAL_AS}.first_token */
EIF_REFERENCE F1173_12467 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O9727[Dtype(Current)-1172]) != ((EIF_INTEGER_32) 0L)))) {
		RTLE;
		return (EIF_REFERENCE) F1173_12462(Current, arg1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = F1132_11967(RTCW(tr1), arg1);
	}
	RTLE;
	return Result;
}

/* {EXTERNAL_AS}.last_token */
EIF_REFERENCE F1173_12468 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = F1132_11968(RTCW(tr1), arg1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			Result = F1211_12835(loc1, arg1);
			RTLE;
			return (EIF_REFERENCE) Result;
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			Result = F1132_11968(RTCW(tr1), arg1);
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit502 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
