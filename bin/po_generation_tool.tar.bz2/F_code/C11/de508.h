
#ifndef _C11_de508_
#define _C11_de508_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1180_12532(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit508(void);
extern char *(*R2613[])();

#ifdef __cplusplus
}
#endif

#endif
