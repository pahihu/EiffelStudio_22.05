
#ifndef _C11_re516_
#define _C11_re516_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1189_12548(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit516(void);
extern char *(*R2616[])();

#ifdef __cplusplus
}
#endif

#endif
