/*
 * Code for class FORMAL_GENERIC_LIST_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "fo535.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {FORMAL_GENERIC_LIST_AS}.process */
void F1209_12815 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2621[Dtype(RTCW(arg1))-211])(arg1, Current);
}

/* {FORMAL_GENERIC_LIST_AS}.transform_class_types_to_formals_and_record_suppliers */
void F1209_12816 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,Current);
	RTLR(5,loc1);
	RTLR(6,tr1);
	RTLR(7,loc3);
	RTLIU(8);
	
	RTGC;
	loc2 = RTLNS(eif_new_type(211, 0x01).id, 211, _OBJSIZ_5_0_0_0_0_0_0_0_);
	F212_3175(RTCW(loc2), arg1, arg2, arg3);
	F794_5602(Current);
	for (;;) {
		if (F748_5258(Current)) break;
		loc1 = *(EIF_REFERENCE *)(RTCV(F794_5576(Current)) + _REFACS_1_);
		F794_5602(RTCW(loc1));
		for (;;) {
			tb1 = F748_5258(RTCW(loc1));
			if (tb1) break;
			tr1 = F794_5576(RTCW(loc1));
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9341[Dtype(RTCW(tr1))-1128])(tr1, loc2);
			tb2 = F212_3176(RTCW(loc2));
			if (tb2) {
				F212_3177(RTCW(loc2));
				tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
				loc3 = tr1;
				if (EIF_TEST(loc3)) {
					tr1 = F794_5576(RTCW(loc1));
					F1142_12107(RTCW(tr1), loc3);
				}
			}
			F794_5604(RTCW(loc1));
		}
		F794_5604(Current);
	}
	RTLE;
}

/* {FORMAL_GENERIC_LIST_AS}.first_token */
EIF_REFERENCE F1209_12817 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		RTLE;
		return (EIF_REFERENCE) F1201_12709(Current, arg1);
	} else {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_) != ((EIF_INTEGER_32) 0L))) {
			RTLE;
			return (EIF_REFERENCE) F1209_12821(Current, arg1);
		}
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {FORMAL_GENERIC_LIST_AS}.last_token */
EIF_REFERENCE F1209_12818 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		RTLE;
		return (EIF_REFERENCE) F1201_12710(Current, arg1);
	} else {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_) != ((EIF_INTEGER_32) 0L))) {
			RTLE;
			return (EIF_REFERENCE) F1209_12822(Current, arg1);
		}
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {FORMAL_GENERIC_LIST_AS}.lsqure_symbol */
EIF_REFERENCE F1209_12821 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11915(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_));
}

/* {FORMAL_GENERIC_LIST_AS}.rsqure_symbol */
EIF_REFERENCE F1209_12822 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11915(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_));
}

/* {FORMAL_GENERIC_LIST_AS}.set_lsqure_symbol */
void F1209_12823 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9961[Dtype(arg1)-1210]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

/* {FORMAL_GENERIC_LIST_AS}.set_rsqure_symbol */
void F1209_12824 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9961[Dtype(arg1)-1210]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

/* {FORMAL_GENERIC_LIST_AS}.set_squre_symbols */
void F1209_12825 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	F1209_12823(Current, arg1);
	F1209_12824(Current, arg2);
	RTLE;
}

void EIF_Minit535 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
