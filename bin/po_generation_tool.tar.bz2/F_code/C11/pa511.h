
#ifndef _C11_pa511_
#define _C11_pa511_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1183_12535(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1183_12536(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit511(void);
extern void F1179_12523(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F101_1357(EIF_REFERENCE);
extern char *(*R2614[])();

#ifdef __cplusplus
}
#endif

#endif
