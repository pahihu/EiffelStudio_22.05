
#ifndef _C11_de543_
#define _C11_de543_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1217_12973(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit543(void);
extern char *(*R2583[])();

#ifdef __cplusplus
}
#endif

#endif
