
#ifndef _C11_se512_
#define _C11_se512_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1185_12544(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit512(void);
extern char *(*R2620[])();

#ifdef __cplusplus
}
#endif

#endif
