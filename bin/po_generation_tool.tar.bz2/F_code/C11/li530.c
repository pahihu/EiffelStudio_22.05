/*
 * Code for class LIST_DEC_LIST_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li530.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LIST_DEC_LIST_AS}.first_token */
EIF_REFERENCE F1204_12782 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_) != ((EIF_INTEGER_32) 0L)))) {
		RTLE;
		return (EIF_REFERENCE) F1204_12787(Current, arg1);
	} else {
		RTLE;
		return (EIF_REFERENCE) F1201_12709(Current, arg1);
	}/* NOTREACHED */
	
}

/* {LIST_DEC_LIST_AS}.last_token */
EIF_REFERENCE F1204_12783 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_) != ((EIF_INTEGER_32) 0L)))) {
		RTLE;
		return (EIF_REFERENCE) F1204_12788(Current, arg1);
	} else {
		RTLE;
		return (EIF_REFERENCE) F1201_12710(Current, arg1);
	}/* NOTREACHED */
	
}

/* {LIST_DEC_LIST_AS}.process */
void F1204_12784 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2697[Dtype(RTCW(arg1))-211])(arg1, Current);
}

/* {LIST_DEC_LIST_AS}.opening_bracket_as */
EIF_REFERENCE F1204_12787 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_);
	tb1 = '\0';
	tb2 = F320_4356(RTCW(arg1), loc1);
	if (tb2) {
		tr1 = F320_4351(RTCW(arg1), loc1);
		loc2 = tr1;
		loc2 = RTRV(eif_new_type(1212, 0x01),loc2);
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) loc2;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {LIST_DEC_LIST_AS}.closing_bracket_as */
EIF_REFERENCE F1204_12788 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_);
	tb1 = '\0';
	tb2 = F320_4356(RTCW(arg1), loc1);
	if (tb2) {
		tr1 = F320_4351(RTCW(arg1), loc1);
		loc2 = tr1;
		loc2 = RTRV(eif_new_type(1212, 0x01),loc2);
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) loc2;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

void EIF_Minit530 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
