/*
 * Code for class LEAF_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "le537.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LEAF_AS}.first_token */
EIF_REFERENCE F1211_12834 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) Current;
}

/* {LEAF_AS}.last_token */
EIF_REFERENCE F1211_12835 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) Current;
}

/* {LEAF_AS}.literal_text */
EIF_REFERENCE F1211_12837 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = F320_4351(RTCW(arg1), *(EIF_INTEGER_32 *)(Current + O9961[Dtype(Current)-1210]));
		Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9959[Dtype(RTCW(tr1))-1211])(tr1, NULL);
	}
	RTLE;
	return Result;
}

/* {LEAF_AS}.index */
EIF_INTEGER_32 F1211_12838 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O9961[Dtype(Current)-1210]);
}


/* {LEAF_AS}.set_index */
void F1211_12839 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O9961[Dtype(Current)-1210]) = (EIF_INTEGER_32) arg1;
}

void EIF_Minit537 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
