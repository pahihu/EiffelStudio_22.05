
#ifndef _C11_ex515_
#define _C11_ex515_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1188_12547(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit515(void);
extern char *(*R2617[])();

#ifdef __cplusplus
}
#endif

#endif
