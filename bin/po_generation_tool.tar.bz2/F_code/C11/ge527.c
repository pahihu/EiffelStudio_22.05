/*
 * Code for class GENERIC_CLASS_TYPE_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge527.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GENERIC_CLASS_TYPE_AS}.initialize */
void F1200_12692 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	F1199_12676(Current, arg1);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg2;
	RTLE;
}

/* {GENERIC_CLASS_TYPE_AS}.has_anchor */
EIF_BOOLEAN F1200_12693 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLIU(6);
	
	RTGC;
	tr1 = F1200_12696(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,0,953,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 1, 1);
		}
		
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1031,0xFF01,0xFFF9,1,953,0xFF01,1191,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr4= RTLNRF(typres0.id, (EIF_POINTER) __A519_97_1, (EIF_POINTER) _A519_97_1, 0, tr1, 0, 1);
		}
		Result = F794_5588(loc1, tr4);
	}
	RTLE;
	return Result;
}

/* {GENERIC_CLASS_TYPE_AS}.process */
void F1200_12695 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2692[Dtype(RTCW(arg1))-211])(arg1, Current);
}

/* {GENERIC_CLASS_TYPE_AS}.generics */
EIF_REFERENCE F1200_12696 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tb1 = F615_5084(RTCW(Result));
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) NULL;
	}
	RTLE;
	return Result;
}

/* {GENERIC_CLASS_TYPE_AS}.last_token */
EIF_REFERENCE F1200_12698 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_7_0_1_) != ((EIF_INTEGER_32) 0L))) {
			Result = F1192_12576(Current, arg1);
		}
		if ((EIF_BOOLEAN)(Result == NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			Result = F1210_12827(RTCW(tr1), arg1);
		}
	}
	if ((EIF_BOOLEAN)(Result == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		Result = F1211_12835(RTCW(tr1), arg1);
	}
	RTLE;
	return Result;
}

/* {GENERIC_CLASS_TYPE_AS}.dump */
EIF_REFERENCE F1200_12699 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	Result = F1199_12689(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = F794_5585(RTCW(tr1));
	tr1 = RTMS_EX_H(" [",2,8283);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6257[Dtype(RTCW(Result))-1037])(Result, tr1);
	for (;;) {
		tb1 = F419_4918(loc1);
		if (tb1) break;
		tr1 = F419_4909(loc1);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9809[Dtype(RTCW(tr1))-1192])(tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6257[Dtype(RTCW(Result))-1037])(Result, tr1);
		tb2 = F419_4922(loc1);
		if ((EIF_BOOLEAN) !tb2) {
			tr1 = RTMS_EX_H(", ",2,11296);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6257[Dtype(RTCW(Result))-1037])(Result, tr1);
		}
		F419_4924(loc1);
	}
	tr1 = RTMS_EX_H("]",1,93);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6257[Dtype(RTCW(Result))-1037])(Result, tr1);
	RTLE;
	return Result;
}

void EIF_Minit527 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
