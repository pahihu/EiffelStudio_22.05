/*
 * Code for class KEYWORD_STUB_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ke544.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KEYWORD_STUB_AS}.make */
void F1218_12978 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_3_4_) = (EIF_INTEGER_32) arg1;
	F1214_12889(Current, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
	RTLE;
}

/* {KEYWORD_STUB_AS}.process */
void F1218_12979 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2548[Dtype(RTCW(arg1))-211])(arg1, Current);
}

void EIF_Minit544 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
