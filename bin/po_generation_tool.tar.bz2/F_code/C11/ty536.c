/*
 * Code for class TYPE_LIST_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ty536.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TYPE_LIST_AS}.first_token */
EIF_REFERENCE F1210_12826 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_) != ((EIF_INTEGER_32) 0L)))) {
		RTLE;
		return (EIF_REFERENCE) F1210_12832(Current, arg1);
	} else {
		RTLE;
		return (EIF_REFERENCE) F1201_12709(Current, arg1);
	}/* NOTREACHED */
	
}

/* {TYPE_LIST_AS}.last_token */
EIF_REFERENCE F1210_12827 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_) != ((EIF_INTEGER_32) 0L)))) {
		RTLE;
		return (EIF_REFERENCE) F1210_12833(Current, arg1);
	} else {
		RTLE;
		return (EIF_REFERENCE) F1201_12710(Current, arg1);
	}/* NOTREACHED */
	
}

/* {TYPE_LIST_AS}.process */
void F1210_12828 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2696[Dtype(RTCW(arg1))-211])(arg1, Current);
}

/* {TYPE_LIST_AS}.set_positions */
void F1210_12829 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9961[Dtype(arg1)-1210]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_) = (EIF_INTEGER_32) ti4_1;
	}
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2) + O9961[Dtype(arg2)-1210]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

/* {TYPE_LIST_AS}.opening_bracket_as */
EIF_REFERENCE F1210_12832 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11915(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_));
}

/* {TYPE_LIST_AS}.closing_bracket_as */
EIF_REFERENCE F1210_12833 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11915(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_));
}

void EIF_Minit536 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
