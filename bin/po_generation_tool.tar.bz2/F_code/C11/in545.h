
#ifndef _C11_in545_
#define _C11_in545_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1219_12981(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit545(void);
extern long O10081[];

#ifdef __cplusplus
}
#endif

#endif
