/*
 * Code for class CONVERT_FEAT_LIST_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co532.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONVERT_FEAT_LIST_AS}.process */
void F1206_12796 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2607[Dtype(RTCW(arg1))-211])(arg1, Current);
}

/* {CONVERT_FEAT_LIST_AS}.first_token */
EIF_REFERENCE F1206_12797 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		RTLE;
		return (EIF_REFERENCE) F1201_12709(Current, arg1);
	} else {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_) != ((EIF_INTEGER_32) 0L))) {
			RTLE;
			return (EIF_REFERENCE) F1206_12799(Current, arg1);
		}
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {CONVERT_FEAT_LIST_AS}.convert_keyword */
EIF_REFERENCE F1206_12799 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11914(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_));
}

/* {CONVERT_FEAT_LIST_AS}.set_convert_keyword */
void F1206_12800 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9961[Dtype(arg1)-1210]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

void EIF_Minit532 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
