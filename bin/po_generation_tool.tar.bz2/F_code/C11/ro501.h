
#ifndef _C11_ro501_
#define _C11_ro501_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1172_12453(EIF_REFERENCE);
extern void EIF_Minit501(void);

#ifdef __cplusplus
}
#endif

#endif
