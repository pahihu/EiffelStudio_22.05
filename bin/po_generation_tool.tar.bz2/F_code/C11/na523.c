/*
 * Code for class NAMED_TUPLE_TYPE_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "na523.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {NAMED_TUPLE_TYPE_AS}.initialize */
void F1196_12632 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg2;
	RTLE;
}

/* {NAMED_TUPLE_TYPE_AS}.process */
void F1196_12633 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2693[Dtype(RTCW(arg1))-211])(arg1, Current);
}

/* {NAMED_TUPLE_TYPE_AS}.has_anchor */
EIF_BOOLEAN F1196_12634 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,tr5);
	RTLIU(6);
	
	RTGC;
	tr1 = F1196_12637(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,953,0xFF01,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1031,0xFF01,0xFFF9,1,953,0xFF01,1148,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A523_119_2, (EIF_POINTER) _A523_119_2, (EIF_POINTER)(0),tr2, 1, 1);
	}
	Result = F794_5588(RTCW(tr1), tr5);
	RTLE;
	return Result;
}

/* {NAMED_TUPLE_TYPE_AS}.class_name */
EIF_REFERENCE F1196_12636 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


/* {NAMED_TUPLE_TYPE_AS}.generics */
EIF_REFERENCE F1196_12637 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = *(EIF_REFERENCE *)(RTCW(tr1));
	RTLE;
	return Result;
}

/* {NAMED_TUPLE_TYPE_AS}.first_token */
EIF_REFERENCE F1196_12643 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	Result = F1192_12584(Current, arg1);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = F1211_12834(RTCW(tr1), arg1);
	}
	RTLE;
	return Result;
}

/* {NAMED_TUPLE_TYPE_AS}.last_token */
EIF_REFERENCE F1196_12644 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	Result = F1192_12585(Current, arg1);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		Result = F1179_12531(RTCW(tr1), arg1);
	}
	RTLE;
	return Result;
}

/* {NAMED_TUPLE_TYPE_AS}.dump */
EIF_REFERENCE F1196_12647 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc3);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(1037, 0x01).id, 1037, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = F1275_13565(RTCW(tr1));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	F1036_8220(RTCW(Result), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 4L)));
	F1192_12599(Current, Result);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = F1275_13565(RTCW(tr1));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6257[Dtype(RTCW(Result))-1037])(Result, tr1);
	loc3 = F1196_12637(Current);
	F794_5602(RTCW(loc3));
	tr1 = RTMS_EX_H(" [",2,8283);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6257[Dtype(RTCW(Result))-1037])(Result, tr1);
	for (;;) {
		tb1 = F748_5258(RTCW(loc3));
		if (tb1) break;
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		tr1 = F794_5576(RTCW(loc3));
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		loc2 = F797_5592(RTCW(tr1));
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			tr1 = F794_5576(RTCW(loc3));
			tr1 = F1148_12224(RTCW(tr1), loc1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6259[Dtype(RTCW(Result))-1037])(Result, tr1);
			if ((EIF_BOOLEAN) (loc1 < loc2)) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R6261[Dtype(RTCW(Result))-1037])(Result, (EIF_CHARACTER_8) ',');
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R6261[Dtype(RTCW(Result))-1037])(Result, (EIF_CHARACTER_8) ' ');
			}
			loc1++;
		}
		tr1 = RTMS_EX_H(": ",2,14880);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6257[Dtype(RTCW(Result))-1037])(Result, tr1);
		tr1 = F794_5576(RTCW(loc3));
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9809[Dtype(RTCW(tr1))-1192])(tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6257[Dtype(RTCW(Result))-1037])(Result, tr1);
		tb2 = F724_5233(RTCW(loc3));
		if ((EIF_BOOLEAN) !tb2) {
			tr1 = RTMS_EX_H("; ",2,15136);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6257[Dtype(RTCW(Result))-1037])(Result, tr1);
		}
		F794_5604(RTCW(loc3));
	}
	tr1 = RTMS_EX_H("]",1,93);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6257[Dtype(RTCW(Result))-1037])(Result, tr1);
	RTLE;
	return Result;
}

/* {NAMED_TUPLE_TYPE_AS}.inline-agent#1 of has_anchor */
EIF_BOOLEAN F1196_14238 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R9803[Dtype(RTCW(tr1))-1192])(tr1);
	RTLE;
	return Result;
}

void EIF_Minit523 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
