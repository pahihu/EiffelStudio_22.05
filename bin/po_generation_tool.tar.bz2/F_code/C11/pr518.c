/*
 * Code for class PRECURSOR_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pr518.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PRECURSOR_AS}.initialize */
void F1191_12557 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	F101_1357(Current);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg3;
	RTLE;
}

/* {PRECURSOR_AS}.process */
void F1191_12558 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2571[Dtype(RTCW(arg1))-211])(arg1, Current);
}

/* {PRECURSOR_AS}.parameters */
EIF_REFERENCE F1191_12561 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		Result = *(EIF_REFERENCE *)(loc1 + _REFACS_1_);
		F794_5602(RTCW(Result));
	}
	RTLE;
	return Result;
}

/* {PRECURSOR_AS}.access_name */
EIF_REFERENCE F1191_12564 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

/* {PRECURSOR_AS}.first_token */
EIF_REFERENCE F1191_12567 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1211_12834(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {PRECURSOR_AS}.last_token */
EIF_REFERENCE F1191_12568 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,Result);
	RTLR(6,loc3);
	RTLR(7,loc4);
	RTLIU(8);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		tr1 = F1191_12561(Current);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9357[Dtype(loc1)-1128])(loc1, arg1);
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			loc2 = tr1;
			if (EIF_TEST(loc2)) {
				tr1 = F1199_12686(loc2, arg1);
				RTLE;
				return (EIF_REFERENCE) tr1;
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				Result = F1211_12835(RTCW(tr1), arg1);
			}
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			Result = F1179_12531(loc3, arg1);
			RTLE;
			return (EIF_REFERENCE) Result;
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			loc4 = tr1;
			if (EIF_TEST(loc4)) {
				Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9357[Dtype(loc4)-1128])(loc4, arg1);
				RTLE;
				return (EIF_REFERENCE) Result;
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				Result = F1211_12835(RTCW(tr1), arg1);
			}
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit518 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
