/*
 * Code for class TYPE_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ty519.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TYPE_AS}.lcurly_symbol */
EIF_REFERENCE F1192_12575 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11915(Current, arg1, *(EIF_INTEGER_32 *)(Current + O9783[Dtype(Current)-1191]));
}

/* {TYPE_AS}.rcurly_symbol */
EIF_REFERENCE F1192_12576 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11915(Current, arg1, *(EIF_INTEGER_32 *)(Current + O9784[Dtype(Current)-1191]));
}

/* {TYPE_AS}.attachment_mark */
EIF_REFERENCE F1192_12577 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current + O9785[Dtype(Current)-1191]);
	tb1 = F320_4356(RTCW(arg1), loc1);
	if (tb1) {
		tr1 = RTLNTY2(eif_new_type(1215, 0x01), 0x01);
		tr2 = F320_4351(RTCW(arg1), loc1);
		Result = F921_6841(tr1, tr2);
	}
	RTLE;
	return Result;
}

/* {TYPE_AS}.variance_mark */
EIF_REFERENCE F1192_12578 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current + O9786[Dtype(Current)-1191]);
	tb1 = '\0';
	tb2 = F320_4356(RTCW(arg1), loc1);
	if (tb2) {
		tr1 = F320_4351(RTCW(arg1), loc1);
		loc2 = tr1;
		tb1 = (EIF_TRUE);
	}
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) loc2;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {TYPE_AS}.separate_keyword */
EIF_REFERENCE F1192_12581 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current + O9787[Dtype(Current)-1191]);
	tb1 = '\0';
	tb2 = F320_4356(RTCW(arg1), loc1);
	if (tb2) {
		tr1 = F320_4351(RTCW(arg1), loc1);
		loc2 = tr1;
		loc2 = RTRV(eif_new_type(1215, 0x01),loc2);
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) loc2;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {TYPE_AS}.set_lcurly_symbol */
void F1192_12582 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9961[Dtype(arg1)-1210]);
		*(EIF_INTEGER_32 *)(Current + O9783[Dtype(Current)-1191]) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

/* {TYPE_AS}.set_rcurly_symbol */
void F1192_12583 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9961[Dtype(arg1)-1210]);
		*(EIF_INTEGER_32 *)(Current + O9784[Dtype(Current)-1191]) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

/* {TYPE_AS}.first_token */
EIF_REFERENCE F1192_12584 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O9783[dtype-1191]) != ((EIF_INTEGER_32) 0L))) {
			RTLE;
			return (EIF_REFERENCE) F1192_12575(Current, arg1);
		} else {
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O9785[dtype-1191]) != ((EIF_INTEGER_32) 0L))) {
				Result = F1192_12577(Current, arg1);
			} else {
				if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O9786[dtype-1191]) != ((EIF_INTEGER_32) 0L))) {
					Result = F1192_12578(Current, arg1);
				} else {
					if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O9787[dtype-1191]) != ((EIF_INTEGER_32) 0L))) {
						Result = F1192_12581(Current, arg1);
						RTLE;
						return (EIF_REFERENCE) Result;
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {TYPE_AS}.last_token */
EIF_REFERENCE F1192_12585 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O9784[Dtype(Current)-1191]) != ((EIF_INTEGER_32) 0L)))) {
		RTLE;
		return (EIF_REFERENCE) F1192_12576(Current, arg1);
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {TYPE_AS}.has_anchor */
EIF_BOOLEAN F1192_12592 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_BOOLEAN) 0;
}

/* {TYPE_AS}.set_attachment_mark */
void F1192_12595 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		*(EIF_INTEGER_32 *)(Current + O9785[dtype-1191]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9961[Dtype(arg1)-1210]);
		*(EIF_INTEGER_32 *)(Current + O9785[dtype-1191]) = (EIF_INTEGER_32) ti4_1;
	}
	*(EIF_BOOLEAN *)(Current + O9797[dtype-1191]) = (EIF_BOOLEAN) arg2;
	*(EIF_BOOLEAN *)(Current + O9798[dtype-1191]) = (EIF_BOOLEAN) arg3;
	RTLE;
}

/* {TYPE_AS}.set_variance_mark */
void F1192_12596 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		*(EIF_INTEGER_32 *)(Current + O9786[dtype-1191]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9961[Dtype(arg1)-1210]);
		*(EIF_INTEGER_32 *)(Current + O9786[dtype-1191]) = (EIF_INTEGER_32) ti4_1;
	}
	*(EIF_BOOLEAN *)(Current + O9801[dtype-1191]) = (EIF_BOOLEAN) arg2;
	*(EIF_BOOLEAN *)(Current + O9802[dtype-1191]) = (EIF_BOOLEAN) arg3;
	RTLE;
}

/* {TYPE_AS}.set_separate_mark */
void F1192_12597 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		*(EIF_INTEGER_32 *)(Current + O9787[dtype-1191]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9961[Dtype(arg1)-1210]);
		*(EIF_INTEGER_32 *)(Current + O9787[dtype-1191]) = (EIF_INTEGER_32) ti4_1;
	}
	*(EIF_BOOLEAN *)(Current + O9800[dtype-1191]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {TYPE_AS}.dump_marks */
void F1192_12599 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current + O9801[dtype-1191])) {
		tr1 = RTMS_EX_H("frozen ",7,2077218848);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6259[Dtype(RTCW(arg1))-1037])(arg1, tr1);
	} else {
		if (*(EIF_BOOLEAN *)(Current + O9802[dtype-1191])) {
			tr1 = RTMS_EX_H("variant ",8,1316418336);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6259[Dtype(RTCW(arg1))-1037])(arg1, tr1);
		}
	}
	if (*(EIF_BOOLEAN *)(Current + O9797[dtype-1191])) {
		tr1 = RTMS_EX_H("attached ",9,1651281952);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6259[Dtype(RTCW(arg1))-1037])(arg1, tr1);
	} else {
		if (*(EIF_BOOLEAN *)(Current + O9798[dtype-1191])) {
			tr1 = RTMS_EX_H("detachable ",11,1596642848);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6259[Dtype(RTCW(arg1))-1037])(arg1, tr1);
		}
	}
	if (*(EIF_BOOLEAN *)(Current + O9800[dtype-1191])) {
		tr1 = RTMS_EX_H("separate ",9,579901216);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6259[Dtype(RTCW(arg1))-1037])(arg1, tr1);
	}
	RTLE;
}

void EIF_Minit519 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
