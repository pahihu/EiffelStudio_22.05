
#ifndef _C11_le537_
#define _C11_le537_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1211_12834(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1211_12835(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1211_12837(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F1211_12838(EIF_REFERENCE);
extern void F1211_12839(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit537(void);
extern EIF_REFERENCE F320_4351(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R9959[])();
extern long O9961[];

#ifdef __cplusplus
}
#endif

#endif
