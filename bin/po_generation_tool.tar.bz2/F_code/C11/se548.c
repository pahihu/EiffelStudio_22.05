/*
 * Code for class SEPARATE_INSTRUCTION_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "se548.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SEPARATE_INSTRUCTION_AS}.make */
void F1222_13001 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,arg4);
	RTLR(5,arg5);
	RTLIU(6);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9961[Dtype(arg1)-1210]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_) = (EIF_INTEGER_32) ti4_1;
	}
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg2;
	if ((EIF_BOOLEAN)(arg3 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg3) + O9961[Dtype(arg3)-1210]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) = (EIF_INTEGER_32) ti4_1;
	}
	RTAR(Current, arg4);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg4;
	RTAR(Current, arg5);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg5;
	RTLE;
}

/* {SEPARATE_INSTRUCTION_AS}.process */
void F1222_13002 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2687[Dtype(RTCW(arg1))-211])(arg1, Current);
}

/* {SEPARATE_INSTRUCTION_AS}.separate_keyword */
EIF_REFERENCE F1222_13009 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11914(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_));
}

/* {SEPARATE_INSTRUCTION_AS}.do_keyword */
EIF_REFERENCE F1222_13011 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11914(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_));
}

/* {SEPARATE_INSTRUCTION_AS}.first_token */
EIF_REFERENCE F1222_13012 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		Result = F1222_13009(Current, arg1);
	}
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = F1201_12709(RTCW(tr1), arg1);
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL) && (EIF_BOOLEAN)(arg1 != NULL))) {
		Result = F1222_13011(Current, arg1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL) && EIF_TEST(loc1))) {
		Result = F1201_12709(loc1, arg1);
	}
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL)) {
		Result = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {SEPARATE_INSTRUCTION_AS}.last_token */
EIF_REFERENCE F1222_13013 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_3_);
}

void EIF_Minit548 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
