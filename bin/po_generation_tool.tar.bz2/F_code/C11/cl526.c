/*
 * Code for class CLASS_TYPE_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "cl526.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CLASS_TYPE_AS}.initialize */
void F1199_12676 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {CLASS_TYPE_AS}.process */
void F1199_12678 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2691[Dtype(RTCW(arg1))-211])(arg1, Current);
}

/* {CLASS_TYPE_AS}.class_name */
EIF_REFERENCE F1199_12679 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current);
}


/* {CLASS_TYPE_AS}.generics */
EIF_REFERENCE F1199_12680 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

/* {CLASS_TYPE_AS}.expanded_keyword */
EIF_REFERENCE F1199_12684 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11914(Current, arg1, *(EIF_INTEGER_32 *)(Current + O9847[Dtype(Current)-1198]));
}

/* {CLASS_TYPE_AS}.first_token */
EIF_REFERENCE F1199_12686 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	Result = F1192_12584(Current, arg1);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		if ((EIF_BOOLEAN)(arg1 != NULL)) {
			Result = F1199_12684(Current, arg1);
		}
		if ((EIF_BOOLEAN)(Result == NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current);
			Result = F1211_12834(RTCW(tr1), arg1);
		}
	}
	RTLE;
	return Result;
}

/* {CLASS_TYPE_AS}.last_token */
EIF_REFERENCE F1199_12687 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	Result = F1192_12585(Current, arg1);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		Result = F1211_12835(RTCW(tr1), arg1);
	}
	RTLE;
	return Result;
}

/* {CLASS_TYPE_AS}.dump */
EIF_REFERENCE F1199_12689 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1037, 0x01).id, 1037, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = F1275_13565(RTCW(tr1));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	F1036_8220(RTCW(Result), ti4_1);
	F1192_12599(Current, Result);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = F1275_13565(RTCW(tr1));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6257[Dtype(RTCW(Result))-1037])(Result, tr1);
	RTLE;
	return Result;
}

/* {CLASS_TYPE_AS}.set_is_expanded */
void F1199_12690 (EIF_REFERENCE Current, EIF_BOOLEAN arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLIU(2);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O9846[dtype-1198]) = (EIF_BOOLEAN) arg1;
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2) + O9961[Dtype(arg2)-1210]);
		*(EIF_INTEGER_32 *)(Current + O9847[dtype-1198]) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

void EIF_Minit526 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
