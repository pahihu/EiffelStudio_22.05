
#ifndef _C11_re513_
#define _C11_re513_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1186_12545(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit513(void);
extern char *(*R2619[])();

#ifdef __cplusplus
}
#endif

#endif
