/*
 * Code for class NONE_TYPE_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "no522.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {NONE_TYPE_AS}.initialize */
void F1195_12623 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {NONE_TYPE_AS}.process */
void F1195_12625 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2595[Dtype(RTCW(arg1))-211])(arg1, Current);
}

/* {NONE_TYPE_AS}.first_token */
EIF_REFERENCE F1195_12628 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	Result = F1192_12584(Current, arg1);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		Result = F1211_12834(RTCW(tr1), arg1);
	}
	RTLE;
	return Result;
}

/* {NONE_TYPE_AS}.last_token */
EIF_REFERENCE F1195_12629 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	Result = F1192_12585(Current, arg1);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		Result = F1211_12835(RTCW(tr1), arg1);
	}
	RTLE;
	return Result;
}

/* {NONE_TYPE_AS}.dump */
EIF_REFERENCE F1195_12631 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1037, 0x01).id, 1037, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1036_8220(RTCW(Result), ((EIF_INTEGER_32) 4L));
	F1192_12599(Current, Result);
	tr1 = RTMS_EX_H("NONE",4,1313820229);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6257[Dtype(RTCW(Result))-1037])(Result, tr1);
	RTLE;
	return Result;
}

void EIF_Minit522 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
