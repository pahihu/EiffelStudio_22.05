
#ifndef _C11_as546_
#define _C11_as546_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1220_12983(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1220_12984(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1220_12989(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1220_12990(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit546(void);
extern char *(*R9356[])();
extern char *(*R9357[])();
extern char *(*R2674[])();

#ifdef __cplusplus
}
#endif

#endif
