
#ifndef _C15_pa705_
#define _C15_pa705_

#ifdef __cplusplus
extern "C" {
#endif

extern void F33_483(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F33_484(EIF_REFERENCE);
extern EIF_REFERENCE F33_485(EIF_REFERENCE);
extern void EIF_Minit705(void);

#ifdef __cplusplus
}
#endif

#endif
