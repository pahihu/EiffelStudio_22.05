
#ifndef _C15_bi737_
#define _C15_bi737_

#ifdef __cplusplus
extern "C" {
#endif

extern void F507_5016(EIF_REFERENCE, EIF_NATURAL_8);
extern void EIF_Minit737(void);
extern EIF_BOOLEAN F616_5084(EIF_REFERENCE);
extern void F795_5604(EIF_REFERENCE);
extern void F495_4999(EIF_REFERENCE, EIF_NATURAL_8);
extern EIF_BOOLEAN F749_5259(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
