
#ifndef _C15_to724_
#define _C15_to724_

#ifdef __cplusplus
extern "C" {
#endif

extern void F294_4091(EIF_REFERENCE, EIF_INTEGER_32);
extern void F294_4092(EIF_REFERENCE, EIF_NATURAL_8, EIF_INTEGER_32);
extern void F294_4098(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit724(void);
extern void F841_6396(EIF_REFERENCE, EIF_NATURAL_8, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y3324[];
extern EIF_TYPE_INDEX *Y3324_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
