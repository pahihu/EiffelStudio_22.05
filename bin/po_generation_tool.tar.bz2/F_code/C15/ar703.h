
#ifndef _C15_ar703_
#define _C15_ar703_

#ifdef __cplusplus
extern "C" {
#endif

extern void F445_4947(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F445_4948(EIF_REFERENCE);
extern EIF_REFERENCE F445_4949(EIF_REFERENCE);
extern EIF_REFERENCE F445_4951(EIF_REFERENCE);
extern EIF_INTEGER_32 F445_4952(EIF_REFERENCE);
extern void EIF_Minit703(void);
extern char *(*R4017[])();
extern EIF_TYPE_INDEX Y3933[];
extern EIF_TYPE_INDEX *Y3933_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
