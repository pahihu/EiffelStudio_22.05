
#ifndef _C15_sp726_
#define _C15_sp726_

#ifdef __cplusplus
extern "C" {
#endif

extern void F458_4953(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F458_4954(EIF_REFERENCE);
extern EIF_REFERENCE F458_4955(EIF_REFERENCE);
extern EIF_INTEGER_32 F458_4956(EIF_REFERENCE);
extern void EIF_Minit726(void);
extern EIF_INTEGER_32 F841_6407(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y3933[];
extern EIF_TYPE_INDEX *Y3933_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
