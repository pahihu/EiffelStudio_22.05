
#ifndef _C15_ar702_
#define _C15_ar702_

#ifdef __cplusplus
extern "C" {
#endif

extern void F432_4935(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F432_4936(EIF_REFERENCE);
extern EIF_REFERENCE F432_4937(EIF_REFERENCE);
extern EIF_REFERENCE F432_4939(EIF_REFERENCE);
extern EIF_INTEGER_32 F432_4940(EIF_REFERENCE);
extern void EIF_Minit702(void);
extern char *(*R4367[])();
extern char *(*R4012[])();
extern char *(*R4371[])();
extern EIF_TYPE_INDEX Y3933[];
extern EIF_TYPE_INDEX *Y3933_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
