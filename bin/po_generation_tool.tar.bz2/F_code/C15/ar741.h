
#ifndef _C15_ar741_
#define _C15_ar741_

#ifdef __cplusplus
extern "C" {
#endif

extern void F446_4947(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F446_4948(EIF_REFERENCE);
extern EIF_REFERENCE F446_4949(EIF_REFERENCE);
extern EIF_REFERENCE F446_4951(EIF_REFERENCE);
extern EIF_INTEGER_32 F446_4952(EIF_REFERENCE);
extern void EIF_Minit741(void);
extern EIF_TYPE_INDEX Y3933[];
extern EIF_TYPE_INDEX *Y3933_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
