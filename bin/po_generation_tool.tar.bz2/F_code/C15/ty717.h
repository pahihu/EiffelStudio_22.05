
#ifndef _C15_ty717_
#define _C15_ty717_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_8 F386_4863(EIF_REFERENCE);
extern void EIF_Minit717(void);
extern char *(*R4122[])();
extern char *(*R3979[])();
extern char *(*R3992[])();

#ifdef __cplusplus
}
#endif

#endif
