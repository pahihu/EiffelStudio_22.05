
#ifndef _C15_re714_
#define _C15_re714_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F683_5115(EIF_REFERENCE);
extern void EIF_Minit714(void);
extern void F398_4869(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R3991[])();
extern EIF_TYPE_INDEX Y3949[];
extern EIF_TYPE_INDEX *Y3949_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
