
#ifndef _C15_ar701_
#define _C15_ar701_

#ifdef __cplusplus
extern "C" {
#endif

extern void F707_5159(EIF_REFERENCE);
extern void F707_5160(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F707_5161(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F707_5163(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F707_5165(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F707_5169(EIF_REFERENCE);
extern EIF_INTEGER_32 F707_5170(EIF_REFERENCE);
extern EIF_INTEGER_32 F707_5171(EIF_REFERENCE);
extern EIF_INTEGER_32 F707_5172(EIF_REFERENCE);
extern EIF_INTEGER_32 F707_5173(EIF_REFERENCE);
extern EIF_BOOLEAN F707_5175(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F707_5180(EIF_REFERENCE, EIF_INTEGER_32);
extern void F707_5184(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F707_5186(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F707_5189(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F707_5213(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F707_5217(EIF_REFERENCE);
extern void EIF_Minit701(void);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern char *(*R4122[])();
extern char *(*R4909[])();
extern char *(*R4017[])();
extern char *(*R4910[])();
extern char *(*R3322[])();
extern char *(*R3323[])();
extern char *(*R4914[])();
extern char *(*R4917[])();
extern char *(*R4918[])();
extern char *(*R3329[])();
extern char *(*R4181[])();
extern char *(*R4109[])();
extern char *(*R4927[])();
extern char *(*R5276[])();
extern char *(*R4896[])();
extern char *(*R4897[])();
extern char *(*R4110[])();
extern char *(*R4114[])();
extern char *(*R4082[])();
extern char *(*R4912[])();
extern EIF_TYPE_INDEX Y3949[];
extern EIF_TYPE_INDEX *Y3949_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
