
#ifndef _C15_ge727_
#define _C15_ge727_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_8 F420_4909(EIF_REFERENCE);
extern EIF_INTEGER_32 F420_4911(EIF_REFERENCE);
extern EIF_BOOLEAN F420_4918(EIF_REFERENCE);
extern EIF_BOOLEAN F420_4922(EIF_REFERENCE);
extern void F420_4923(EIF_REFERENCE);
extern void F420_4924(EIF_REFERENCE);
extern EIF_REFERENCE F420_4925(EIF_REFERENCE);
extern void EIF_Minit727(void);
extern char *(*R4007[])();
extern char *(*R3980[])();
extern long O4006[];
extern long O4008[];

#ifdef __cplusplus
}
#endif

#endif
