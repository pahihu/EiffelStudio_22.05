
#ifndef _C15_re707_
#define _C15_re707_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F640_5090(EIF_REFERENCE);
extern void EIF_Minit707(void);
extern char *(*R4110[])();

#ifdef __cplusplus
}
#endif

#endif
