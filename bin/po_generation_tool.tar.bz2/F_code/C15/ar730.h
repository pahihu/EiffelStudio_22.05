
#ifndef _C15_ar730_
#define _C15_ar730_

#ifdef __cplusplus
extern "C" {
#endif

extern void F433_4935(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F433_4936(EIF_REFERENCE);
extern EIF_REFERENCE F433_4937(EIF_REFERENCE);
extern EIF_REFERENCE F433_4939(EIF_REFERENCE);
extern EIF_INTEGER_32 F433_4940(EIF_REFERENCE);
extern void EIF_Minit730(void);
extern EIF_INTEGER_32 F795_5594(EIF_REFERENCE);
extern EIF_REFERENCE F795_5575(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y3933[];
extern EIF_TYPE_INDEX *Y3933_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
