/*
 * Code for class LINEAR [NATURAL_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li718.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LINEAR}.has */
EIF_BOOLEAN F495_4997 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F795_5602(Current);
	if ((EIF_BOOLEAN) !F725_5234(Current)) {
		F795_5608(Current, arg1);
	}
	Result = F495_5003(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTLE;
	return Result;
}

/* {LINEAR}.search */
void F495_4999 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current + O4047[Dtype(Current)-469])) {
		for (;;) {
			tb1 = '\01';
			if (!F495_5003(Current)) {
				tb1 = (arg1 == F795_5576(Current));
			}
			if (tb1) break;
			F795_5604(Current);
		}
	} else {
		for (;;) {
			tb2 = '\01';
			if (!F495_5003(Current)) {
				tb2 = (EIF_BOOLEAN)(arg1 == F795_5576(Current));
			}
			if (tb2) break;
			F795_5604(Current);
		}
	}
	RTLE;
}

/* {LINEAR}.exhausted */
EIF_BOOLEAN F495_5003 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F725_5234(Current);
}

/* {LINEAR}.off */
EIF_BOOLEAN F495_5005 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	if (!F616_5084(Current)) {
		Result = F749_5258(Current);
	}
	RTLE;
	return Result;
}

void EIF_Minit718 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
