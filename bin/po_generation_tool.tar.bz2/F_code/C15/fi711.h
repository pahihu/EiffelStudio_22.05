
#ifndef _C15_fi711_
#define _C15_fi711_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F616_5084(EIF_REFERENCE);
extern void EIF_Minit711(void);
extern char *(*R4109[])();

#ifdef __cplusplus
}
#endif

#endif
