
#ifndef _C15_co713_
#define _C15_co713_

#ifdef __cplusplus
extern "C" {
#endif

extern void F471_4986(EIF_REFERENCE);
extern EIF_INTEGER_32 F471_4989(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit713(void);
extern char *(*R4123[])();
extern char *(*R4124[])();
extern char *(*R4109[])();
extern long O4047[];
extern EIF_TYPE_INDEX Y3949[];
extern EIF_TYPE_INDEX *Y3949_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
