/*
 * Code for class SHARED_I18N_PLURAL_TOOLS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sh123.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SHARED_I18N_PLURAL_TOOLS}.plural_tools */
static EIF_REFERENCE F160_2147_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (2147);
#define Result RTOSR(2147)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(7, 0x01).id, 7, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2147);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F160_2147 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2147,F160_2147_body,(Current));
}

void EIF_Minit123 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
