/*
 * Code for class SYSTEM_ENCODINGS_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sy134.h"
#include "eif_langinfo.h"
#include "eif_built_in.h"
#include "string.h"
#include <locale.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F174_2271
static EIF_POINTER inline_F174_2271 (void)
{
	return nl_langinfo (CODESET);
	;
}
#define INLINE_F174_2271
#endif
#ifndef INLINE_F174_2270
static int inline_F174_2270 (void)
{
	setlocale (LC_ALL, "");
return (EIF_BOOLEAN)(strcmp (nl_langinfo (CODESET), "UTF-8") == 0);
	;
}
#define INLINE_F174_2270
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SYSTEM_ENCODINGS_IMP}.system_code_page */
EIF_REFERENCE F174_2267 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	loc1 = inline_F174_2271();
	ti4_1 = (EIF_INTEGER_32) strlen((void *) loc1);
	Result = F173_2257(Current, loc1, ti4_1);
	RTLE;
	return Result;
}

/* {SYSTEM_ENCODINGS_IMP}.console_code_page */
EIF_REFERENCE F174_2268 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if (EIF_TEST (inline_F174_2270())) {
		Result = RTMS_EX_H("UTF-8",5,1414538040);
	} else {
		if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
			Result = RTMS_EX_H("UTF-8",5,1414538040);
		} else {
			Result = F174_2267(Current);
			RTLE;
			return (EIF_REFERENCE) Result;
		}
	}
	RTLE;
	return Result;
}

/* {SYSTEM_ENCODINGS_IMP}.iso_8859_1_code_page */
EIF_REFERENCE F174_2269 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	RTGC;
	Result = RTMS_EX_H("ISO-8859-1",10,1255164721);
	RTLE;
	return Result;
}

/* {SYSTEM_ENCODINGS_IMP}.is_utf8_activated */
EIF_BOOLEAN F174_2270 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = EIF_TEST(inline_F174_2270 ());
	return Result;
}

/* {SYSTEM_ENCODINGS_IMP}.c_current_codeset */
EIF_POINTER F174_2271 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F174_2271 ();
	return Result;
}

/* {SYSTEM_ENCODINGS_IMP}.c_strlen */
EIF_INTEGER_32 F174_2272 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) strlen((void *) arg1);
	
	return Result;
}

void EIF_Minit134 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
