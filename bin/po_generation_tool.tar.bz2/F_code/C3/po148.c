/*
 * Code for class PO_FILE_HEADERS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "po148.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PO_FILE_HEADERS}.make */
void F188_2377 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = F1033_8149(RTMS_EX_H("",0,0));
	tr2 = RTMS_EX_H("",0,0);
	F187_2372(Current, tr1, tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,783,0xFF01,1041,0xFF01,1041,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F784_5440(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {PO_FILE_HEADERS}.add_header */
void F188_2381 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,tr2);
	RTLR(4,arg1);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = F1033_8150(RTCW(arg2));
	tr3 = F1033_8150(RTCW(arg1));
	F784_5486(RTCW(tr1), tr2, tr3);
	RTLE;
}

/* {PO_FILE_HEADERS}.to_string */
EIF_REFERENCE F188_2383 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4079[Dtype(RTCW(tr1))-773])(tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F784_5479(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F774_5297(RTCW(tr1));
	loc1 = RTLNS(eif_new_type(1041, 0x01).id, 1041, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1033_8090(RTCW(loc1));
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tb1 = F784_5474(RTCW(tr1));
		if (tb1) break;
		F1042_8530(RTCW(loc1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr1 = F784_5453(RTCW(tr1));
		F1042_8503(RTCW(loc1), tr1);
		tr1 = F1033_8149(RTMS_EX_H(": ",2,14880));
		F1042_8501(RTCW(loc1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr1 = F784_5452(RTCW(tr1));
		F1042_8503(RTCW(loc1), tr1);
		tr1 = F1033_8149(RTMS_EX_H("\\n",2,23662));
		F1042_8501(RTCW(loc1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tr2 = F1_14(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4075[Dtype(RTCW(tr1))-773])(tr1, tr2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		F784_5480(RTCW(tr1));
	}
	RTLE;
	return (EIF_REFERENCE) F187_2375(Current);
}

void EIF_Minit148 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
