/*
 * Code for class I18N_DICTIONARY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1126.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_DICTIONARY}.make */
void F163_2195 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current + O2156[dtype-162]) = (EIF_INTEGER_32) arg1;
	tr1 = RTOSCF(2147,F160_2147, (Current));
	tr1 = F8_158(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(2147,F160_2147, (Current));
	ti4_1 = F8_159(RTCW(tr1), arg1);
	*(EIF_INTEGER_32 *)(Current + O2160[dtype-162]) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

/* {I18N_DICTIONARY}.reduce */
EIF_INTEGER_32 F163_2207 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = eif_abs_int32 (arg1);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_POINTER, EIF_REFERENCE, EIF_INTEGER_32)) *(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_4_2_0_4_0_0_))(
		*(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_4_2_0_4_0_1_),
		*(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_), ti4_1);
	Result = ti4_1;
	RTLE;
	return Result;
}

void EIF_Minit126 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
