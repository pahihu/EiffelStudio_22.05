/*
 * Code for class BOM_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "bo136.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BOM_CONSTANTS}.bom_utf8 */
static EIF_REFERENCE F176_2279_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (2279);
#define Result RTOSR(2279)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1037, 0x01).id, 1037, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1036_8220(RTCW(tr1), ((EIF_INTEGER_32) 3L));
	Result = (EIF_REFERENCE) tr1;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R6170[Dtype(RTCW(Result))-1037])(Result, (EIF_NATURAL_32) ((EIF_INTEGER_32) 239L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R6170[Dtype(RTCW(Result))-1037])(Result, (EIF_NATURAL_32) ((EIF_INTEGER_32) 187L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R6170[Dtype(RTCW(Result))-1037])(Result, (EIF_NATURAL_32) ((EIF_INTEGER_32) 191L));
	RTOSE (2279);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F176_2279 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2279,F176_2279_body,(Current));
}

void EIF_Minit136 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
