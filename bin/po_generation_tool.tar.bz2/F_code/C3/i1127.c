/*
 * Code for class I18N_BINARY_SEARCH_ARRAY_DICTIONARY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1127.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_BINARY_SEARCH_ARRAY_DICTIONARY}.make */
void F164_2211 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F163_2195(Current, arg1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,706,0xFF01,279,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F707_5159(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTLE;
}

/* {I18N_BINARY_SEARCH_ARRAY_DICTIONARY}.extend */
void F164_2212 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F707_5186(RTCW(tr1), arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_2_));
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_2_))++;
	F164_2213(Current);
	RTLE;
}

/* {I18N_BINARY_SEARCH_ARRAY_DICTIONARY}.search_index_and_insert */
void F164_2213 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc4);
	RTLR(2,tr1);
	RTLR(3,loc5);
	RTLR(4,loc6);
	RTLR(5,loc7);
	RTLIU(6);
	
	RTGC;
	loc9 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_2_);
	loc9 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc9 - ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN) (loc9 > ((EIF_INTEGER_32) 1L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc4 = F707_5165(RTCW(tr1), loc9);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc5 = F707_5165(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc6 = F707_5165(RTCW(tr1), (EIF_INTEGER_32) (loc9 - ((EIF_INTEGER_32) 1L)));
		tb1 = F280_3824(RTCW(loc4), loc5);
		if (tb1) {
			loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			tb1 = F279_3808(RTCW(loc4), loc6);
			if (tb1) {
				loc8 = (EIF_INTEGER_32) loc9;
			} else {
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
				loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc9 - ((EIF_INTEGER_32) 2L));
				for (;;) {
					if ((EIF_BOOLEAN) (loc1 > loc2)) break;
					tu4_1 = (EIF_NATURAL_32) (EIF_INTEGER_32) (loc1 + loc2);
					tu4_1 = eif_bit_shift_right(tu4_1,((EIF_INTEGER_32) 1L));
					loc3 = (EIF_INTEGER_32) tu4_1;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					loc7 = F707_5165(RTCW(tr1), loc3);
					tb1 = F280_3824(RTCW(loc4), loc7);
					if (tb1) {
						loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L));
					} else {
						loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
					}
				}
				loc8 = (EIF_INTEGER_32) loc1;
			}
		}
		if ((EIF_BOOLEAN)(loc8 != loc9)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			F707_5189(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_), loc8, (EIF_INTEGER_32) (loc9 - ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L)));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			F707_5184(RTCW(tr1), loc4, loc8);
		}
	}
	RTLE;
}

/* {I18N_BINARY_SEARCH_ARRAY_DICTIONARY}.has_index */
EIF_INTEGER_32 F164_2214 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc6);
	RTLR(2,arg1);
	RTLR(3,loc12);
	RTLR(4,tr1);
	RTLR(5,loc4);
	RTLIU(6);
	
	RTGC;
	loc7 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_2_);
	loc7 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc7 - ((EIF_INTEGER_32) 1L));
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc2 = (EIF_INTEGER_32) loc7;
	loc6 = F1033_8149(RTCW(arg1));
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > loc2) || loc5)) break;
		tu4_1 = (EIF_NATURAL_32) (EIF_INTEGER_32) (loc1 + loc2);
		tu4_1 = eif_bit_shift_right(tu4_1,((EIF_INTEGER_32) 1L));
		loc3 = (EIF_INTEGER_32) tu4_1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = F707_5165(RTCW(tr1), loc3);
		loc12 = tr1;
		if ((EIF_TRUE)) {
			loc4 = F280_3818(loc12);
		} else {
			loc4 = RTLNS(eif_new_type(1041, 0x01).id, 1041, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F1033_8090(RTCW(loc4));
		}
		tb1 = F1040_8415(RTCW(loc6), loc4);
		if (tb1) {
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L));
		} else {
			tb1 = F279_3808(RTCW(loc6), loc4);
			if (tb1) {
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
			} else {
				loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				Result = (EIF_INTEGER_32) loc3;
				loc1++;
			}
		}
	}
	if ((EIF_BOOLEAN)(loc5 == (EIF_BOOLEAN) 0)) {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	}
	RTLE;
	return Result;
}

/* {I18N_BINARY_SEARCH_ARRAY_DICTIONARY}.singular_in_context */
EIF_REFERENCE F164_2216 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	tr1 = F159_2146(Current, arg1, arg2);
	loc1 = F164_2214(Current, tr1);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) -1L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = F707_5165(RTCW(tr1), loc1);
		loc2 = tr1;
		tb1 = (EIF_TRUE);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(loc2 + _REFACS_2_);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {I18N_BINARY_SEARCH_ARRAY_DICTIONARY}.plural_in_context */
EIF_REFERENCE F164_2217 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,arg4);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F159_2146(Current, arg1, arg4);
	loc1 = F164_2214(Current, tr1);
	tb1 = '\0';
	tb2 = '\0';
	if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) -1L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = F707_5165(RTCW(tr1), loc1);
		loc2 = tr1;
		tb2 = (EIF_TRUE);
	}
	if (tb2) {
		tb2 = F280_3817(loc2);
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(loc2 + _REFACS_3_);
		ti4_1 = F163_2207(Current, arg3);
		Result = F707_5165(RTCW(tr1), ti4_1);
	}
	RTLE;
	return Result;
}

void EIF_Minit127 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
