/*
 * Code for class PO_FILE_ENTRY_PLURAL
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "po146.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PO_FILE_ENTRY_PLURAL}.make */
void F186_2363 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	F185_2340(Current, arg1, arg2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,706,0xFF01,773,0xFF01,1041,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	tr2 = F1033_8149(RTMS_EX_H("",0,0));
	tr2 = F185_2353(Current, tr2);
	F707_5160(RTCW(tr1), tr2, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,773,0xFF01,1041,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F774_5278(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {PO_FILE_ENTRY_PLURAL}.set_msgid_plural */
void F186_2364 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4079[Dtype(RTCW(tr1))-773])(tr1);
	tr1 = F1033_8149(RTCW(arg1));
	tr1 = F185_2353(Current, tr1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {PO_FILE_ENTRY_PLURAL}.to_string */
EIF_REFERENCE F186_2369 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	Result = F185_2352(Current);
	tr1 = F1033_8149(RTMS_EX_H("msgid_plural",12,1254930796));
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F185_2356(Current, tr1, tr2);
	F1042_8503(RTCW(Result), tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_1_);
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_0_);
		if ((EIF_BOOLEAN) (loc1 > ti4_1)) break;
		tb1 = '\0';
		tb2 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tb3 = F707_5180(RTCW(tr1), loc1);
		if (tb3) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			tr1 = F707_5165(RTCW(tr1), loc1);
			tb2 = (EIF_BOOLEAN)(tr1 != NULL);
		}
		if (tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			tr1 = F707_5165(RTCW(tr1), loc1);
			tb2 = F615_5084(RTCW(tr1));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			tr1 = RTMS_EX_H("msgstr[",7,1190922843);
			tr2 = eif_out__i4_s1(loc1);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R6223[Dtype(tr1)-1036])(tr1, tr2);
			tr2 = RTMS_EX_H("]",1,93);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R6223[Dtype(RTCW(tr1))-1036])(tr1, tr2);
			tr1 = F1033_8149(RTCW(tr1));
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			tr2 = F707_5165(RTCW(tr2), loc1);
			tr1 = F185_2356(Current, tr1, tr2);
			F1042_8503(RTCW(Result), tr1);
		}
		loc1++;
	}
	RTLE;
	return Result;
}

void EIF_Minit146 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
