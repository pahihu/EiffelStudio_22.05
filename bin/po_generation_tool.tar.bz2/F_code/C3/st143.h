
#ifndef _C3_st143_
#define _C3_st143_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F183_2333(EIF_REFERENCE);
extern EIF_INTEGER_32 F183_2334(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit143(void);
extern char *(*R6073[])();
extern char *(*R6110[])();
extern char *(*R6231[])();

#ifdef __cplusplus
}
#endif

#endif
