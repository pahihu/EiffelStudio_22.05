
#ifndef _C3_bo136_
#define _C3_bo136_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,2279)
static EIF_REFERENCE F176_2279_body(EIF_REFERENCE);
extern EIF_REFERENCE F176_2279(EIF_REFERENCE);
extern void EIF_Minit136(void);
extern void F1036_8220(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R6170[])();

#ifdef __cplusplus
}
#endif

#endif
