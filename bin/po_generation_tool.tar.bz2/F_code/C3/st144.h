
#ifndef _C3_st144_
#define _C3_st144_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F184_2337(EIF_REFERENCE);
extern EIF_INTEGER_32 F184_2338(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit144(void);
extern char *(*R6073[])();
extern char *(*R6306[])();
extern char *(*R6110[])();

#ifdef __cplusplus
}
#endif

#endif
