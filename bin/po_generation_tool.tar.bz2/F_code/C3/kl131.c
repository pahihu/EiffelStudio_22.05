/*
 * Code for class KL_SHARED_STANDARD_FILES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl131.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_SHARED_STANDARD_FILES}.std */
static EIF_REFERENCE F171_2242_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (2242);
#define Result RTOSR(2242)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(12, 0x01).id, 12, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2242);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F171_2242 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2242,F171_2242_body,(Current));
}

void EIF_Minit131 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
