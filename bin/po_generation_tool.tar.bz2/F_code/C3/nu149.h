
#ifndef _C3_nu149_
#define _C3_nu149_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_64 F189_2386(EIF_REFERENCE);
extern void EIF_Minit149(void);

#ifdef __cplusplus
}
#endif

#endif
