
#ifndef _C3_kl135_
#define _C3_kl135_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,2276)
static EIF_REFERENCE F175_2276_body(EIF_REFERENCE);
extern EIF_REFERENCE F175_2276(EIF_REFERENCE);
extern void EIF_Minit135(void);

#ifdef __cplusplus
}
#endif

#endif
