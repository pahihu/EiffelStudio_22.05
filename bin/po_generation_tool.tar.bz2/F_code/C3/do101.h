
#ifndef _C3_do101_
#define _C3_do101_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REAL_64 F129_1608(EIF_REFERENCE, EIF_REAL_64);
extern void EIF_Minit101(void);

#ifdef __cplusplus
}
#endif

#endif
