
#ifndef _C3_sh123_
#define _C3_sh123_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,2147)
static EIF_REFERENCE F160_2147_body(EIF_REFERENCE);
extern EIF_REFERENCE F160_2147(EIF_REFERENCE);
extern void EIF_Minit123(void);

#ifdef __cplusplus
}
#endif

#endif
