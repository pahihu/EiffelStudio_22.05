
#ifndef _C3_i1128_
#define _C3_i1128_

#ifdef __cplusplus
extern "C" {
#endif

extern void F165_2223(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F165_2225(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F165_2226(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE);
extern void EIF_Minit128(void);

#ifdef __cplusplus
}
#endif

#endif
