/*
 * Code for class LOCATION_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "lo104.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LOCATION_AS}.make */
void F132_1880 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7)
{
	GTCX
	
	
	F132_1893(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7);
}

/* {LOCATION_AS}.make_null */
void F132_1882 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {LOCATION_AS}.line */
EIF_INTEGER_32 F132_1883 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current + O1889[Dtype(Current)-131]);
	tu4_1 = eif_bit_and(tu4_1,((EIF_NATURAL_32) 8388607U));
	Result = (EIF_INTEGER_32) tu4_1;
	RTLE;
	return Result;
}

/* {LOCATION_AS}.column */
EIF_INTEGER_32 F132_1884 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current + O1889[Dtype(Current)-131]);
	tu4_1 = eif_bit_shift_right(tu4_1,((EIF_INTEGER_32) 23L));
	Result = (EIF_INTEGER_32) tu4_1;
	RTLE;
	return Result;
}

/* {LOCATION_AS}.final_position */
EIF_INTEGER_32 F132_1886 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_16 tu2_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = *(EIF_INTEGER_32 *)(Current + O1869[dtype-131]);
	tu2_1 = *(EIF_NATURAL_16 *)(Current + O1890[dtype-131]);
	ti4_1 = (EIF_INTEGER_32) tu2_1;
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (Result + ti4_1) - ((EIF_INTEGER_32) 1L));
	RTLE;
	return Result;
}

/* {LOCATION_AS}.location_count */
EIF_INTEGER_32 F132_1888 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_16 tu2_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu2_1 = *(EIF_NATURAL_16 *)(Current + O1890[Dtype(Current)-131]);
	Result = (EIF_INTEGER_32) tu2_1;
	RTLE;
	return Result;
}

/* {LOCATION_AS}.character_column */
EIF_INTEGER_32 F132_1889 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_16 tu2_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu2_1 = *(EIF_NATURAL_16 *)(Current + O1891[Dtype(Current)-131]);
	Result = (EIF_INTEGER_32) tu2_1;
	RTLE;
	return Result;
}

/* {LOCATION_AS}.character_count */
EIF_INTEGER_32 F132_1892 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_16 tu2_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu2_1 = *(EIF_NATURAL_16 *)(Current + O1892[Dtype(Current)-131]);
	Result = (EIF_INTEGER_32) tu2_1;
	RTLE;
	return Result;
}

/* {LOCATION_AS}.set_position */
void F132_1893 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_NATURAL_16 tu2_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 > ((EIF_INTEGER_32) 8388607L))) {
		*(EIF_NATURAL_32 *)(Current + O1889[dtype-131]) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	} else {
		if ((EIF_BOOLEAN) (arg2 > ((EIF_INTEGER_32) 511L))) {
			tu4_1 = (EIF_NATURAL_32) arg1;
			*(EIF_NATURAL_32 *)(Current + O1889[dtype-131]) = (EIF_NATURAL_32) tu4_1;
		} else {
			tu4_1 = (EIF_NATURAL_32) arg2;
			tu4_1 = eif_bit_shift_left(tu4_1,((EIF_INTEGER_32) 23L));
			tu4_2 = (EIF_NATURAL_32) arg1;
			*(EIF_NATURAL_32 *)(Current + O1889[dtype-131]) = (EIF_NATURAL_32) (EIF_NATURAL_32) (tu4_1 + tu4_2);
		}
	}
	if ((EIF_BOOLEAN) (arg4 > ((EIF_INTEGER_32) 65535L))) {
		*(EIF_NATURAL_16 *)(Current + O1890[dtype-131]) = (EIF_NATURAL_16) (EIF_NATURAL_16) ((EIF_INTEGER_32) 0L);
	} else {
		tu2_1 = (EIF_NATURAL_16) arg4;
		*(EIF_NATURAL_16 *)(Current + O1890[dtype-131]) = (EIF_NATURAL_16) tu2_1;
	}
	*(EIF_INTEGER_32 *)(Current + O1869[dtype-131]) = (EIF_INTEGER_32) arg3;
	if ((EIF_BOOLEAN) (arg5 > ((EIF_INTEGER_32) 65535L))) {
		*(EIF_NATURAL_16 *)(Current + O1891[dtype-131]) = (EIF_NATURAL_16) (EIF_NATURAL_16) ((EIF_INTEGER_32) 0L);
	} else {
		tu2_1 = (EIF_NATURAL_16) arg5;
		*(EIF_NATURAL_16 *)(Current + O1891[dtype-131]) = (EIF_NATURAL_16) tu2_1;
	}
	if ((EIF_BOOLEAN) (arg7 > ((EIF_INTEGER_32) 65535L))) {
		*(EIF_NATURAL_16 *)(Current + O1892[dtype-131]) = (EIF_NATURAL_16) (EIF_NATURAL_16) ((EIF_INTEGER_32) 0L);
	} else {
		tu2_1 = (EIF_NATURAL_16) arg7;
		*(EIF_NATURAL_16 *)(Current + O1892[dtype-131]) = (EIF_NATURAL_16) tu2_1;
	}
	*(EIF_INTEGER_32 *)(Current + O1874[dtype-131]) = (EIF_INTEGER_32) arg6;
	RTLE;
}

/* {LOCATION_AS}.is_null */
EIF_BOOLEAN F132_1904 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	tu4_1 = *(EIF_NATURAL_32 *)(Current + O1889[Dtype(Current)-131]);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu4_1 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L));
	return Result;
}

void EIF_Minit104 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
