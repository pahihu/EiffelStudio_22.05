
#ifndef _C3_i1126_
#define _C3_i1126_

#ifdef __cplusplus
extern "C" {
#endif

extern void F163_2195(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F163_2207(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit126(void);
extern EIF_REFERENCE F160_2147(EIF_REFERENCE);
extern EIF_REFERENCE F8_158(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F8_159(EIF_REFERENCE, EIF_INTEGER_32);
RTOSHF(EIF_REFERENCE,2147)
extern long O2156[];
extern long O2160[];

#ifdef __cplusplus
}
#endif

#endif
