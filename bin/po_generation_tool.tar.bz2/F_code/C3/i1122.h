
#ifndef _C3_i1122_
#define _C3_i1122_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F159_2146(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit122(void);
extern EIF_REFERENCE F1042_8520(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1033_8149(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
