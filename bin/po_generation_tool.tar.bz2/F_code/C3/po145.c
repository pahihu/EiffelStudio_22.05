/*
 * Code for class PO_FILE_ENTRY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "po145.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PO_FILE_ENTRY}.make */
void F185_2340 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	tr1 = F1033_8149(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	F185_2362(Current);
	F185_2342(Current, arg2);
	RTLE;
}

/* {PO_FILE_ENTRY}.set_msgctxt */
void F185_2341 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {773,0xFF01,1041,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNSMART(typres0.id);
		}
		F774_5278(RTCW(loc1));
		tr1 = F1033_8149(RTCW(arg1));
		tr1 = F185_2353(Current, tr1);
		F724_5238(RTCW(loc1), tr1);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) loc1;
	}
	RTLE;
}

/* {PO_FILE_ENTRY}.set_msgid */
void F185_2342 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,773,0xFF01,1041,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F774_5278(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr2 = F1033_8149(RTCW(arg1));
	tr2 = F185_2353(Current, tr2);
	F724_5238(RTCW(tr1), tr2);
	RTLE;
}

/* {PO_FILE_ENTRY}.add_reference_comment */
void F185_2344 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	loc1 = F1033_8149(RTMS_EX_H("#: ",3,2308640));
	tr1 = F1033_8150(RTCW(arg1));
	F1042_8503(RTCW(loc1), tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4075[Dtype(RTCW(tr1))-773])(tr1, loc1);
	RTLE;
}

/* {PO_FILE_ENTRY}.add_automatic_comment */
void F185_2345 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	loc1 = F1033_8150(RTCW(arg1));
	tr1 = F1033_8149(RTMS_EX_H("#. ",3,2305568));
	F1042_8493(RTCW(loc1), tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4075[Dtype(RTCW(tr1))-773])(tr1, loc1);
	RTLE;
}

/* {PO_FILE_ENTRY}.entry_id */
EIF_REFERENCE F185_2347 (EIF_REFERENCE Current)
{
	GTCX
	struct eif_ex_33 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(43, 0x00).id);
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tr1 = F185_2348(Current);
	tr2 = F185_2349(Current);
	Result = F44_646(RTCW(loc1), tr1, tr2);
	RTLE;
	return Result;
}

/* {PO_FILE_ENTRY}.msgid */
EIF_REFERENCE F185_2348 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) F185_2354(Current, *(EIF_REFERENCE *)(Current + _REFACS_4_));
}

/* {PO_FILE_ENTRY}.msgctxt */
EIF_REFERENCE F185_2349 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) F185_2354(Current, loc1);
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {PO_FILE_ENTRY}.to_string */
EIF_REFERENCE F185_2352 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Result);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	Result = RTLNS(eif_new_type(1041, 0x01).id, 1041, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1033_8090(RTCW(Result));
	tr1 = F1033_8149(RTMS_EX_H("\012\012",2,2570));
	F1042_8493(RTCW(Result), tr1);
	tr1 = F185_2355(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_));
	F1042_8503(RTCW(Result), tr1);
	tr1 = F185_2355(Current, *(EIF_REFERENCE *)(Current + _REFACS_2_));
	F1042_8503(RTCW(Result), tr1);
	tr1 = F185_2355(Current, *(EIF_REFERENCE *)(Current + _REFACS_3_));
	F1042_8503(RTCW(Result), tr1);
	if (*(EIF_BOOLEAN *)(Current + O2281[Dtype(Current)-184])) {
		tr1 = F1033_8149(RTMS_EX_H("#, fuzzy\012",9,1109616138));
		F1042_8501(RTCW(Result), tr1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1033_8149(RTMS_EX_H("msgctxt",7,922488948));
		tr1 = F185_2356(Current, tr1, loc1);
		F1042_8503(RTCW(Result), tr1);
	}
	tr1 = F1033_8149(RTMS_EX_H("msgid",5,1936994148));
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr1 = F185_2356(Current, tr1, tr2);
	F1042_8503(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {PO_FILE_ENTRY}.break_line */
EIF_REFERENCE F185_2353 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,arg1);
	RTLR(4,tr1);
	RTLR(5,loc1);
	RTLIU(6);
	
	RTGC;
	loc3 = F1033_8149(RTMS_EX_H("",0,0));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,773,0xFF01,1041,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 773, _OBJSIZ_2_3_0_1_0_0_0_0_);
	}
	F774_5278(RTCW(Result));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN) (ti4_1 <= ((EIF_INTEGER_32) 78L))) {
		tr1 = F1033_8149(RTCW(arg1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4075[Dtype(RTCW(Result))-773])(Result, tr1);
	} else {
		loc1 = F1042_8544(RTCW(arg1));
		F803_5602(RTCW(loc1));
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			tb1 = F757_5258(RTCW(loc1));
			if (tb1) break;
			tw1 = F803_5576(RTCW(loc1));
			F1042_8515(RTCW(loc3), tw1);
			if ((EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 78L))) {
				for (;;) {
					tb2 = '\01';
					tw1 = F803_5576(RTCW(loc1));
					ti4_1 = (EIF_INTEGER_32) (tw1);
					ti4_2 = (EIF_INTEGER_32) ((EIF_CHARACTER_8) '\\');
					if (!(EIF_BOOLEAN)(ti4_1 != ti4_2)) {
						tb3 = F757_5258(RTCW(loc1));
						tb2 = tb3;
					}
					if (tb2) break;
					F803_5604(RTCW(loc1));
					tb3 = F757_5258(RTCW(loc1));
					if ((EIF_BOOLEAN) !tb3) {
						tw1 = F803_5576(RTCW(loc1));
						F1042_8515(RTCW(loc3), tw1);
					}
				}
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4075[Dtype(RTCW(Result))-773])(Result, loc3);
				loc3 = F1033_8149(RTMS_EX_H("",0,0));
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			}
			F803_5604(RTCW(loc1));
			loc2++;
		}
		tb3 = F620_5084(RTCW(loc3));
		if ((EIF_BOOLEAN) !tb3) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4075[Dtype(RTCW(Result))-773])(Result, loc3);
		}
	}
	RTLE;
	return Result;
}

/* {PO_FILE_ENTRY}.unbreak_line */
EIF_REFERENCE F185_2354 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4055[Dtype(RTCW(arg1))-613])(arg1);
	Result = F1033_8149(RTMS_EX_H("",0,0));
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4066[Dtype(RTCW(arg1))-613])(arg1);
		if (tb1) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4053[Dtype(RTCW(arg1))-613])(arg1);
		tr1 = F1033_8149(RTCW(tr1));
		F1042_8501(RTCW(Result), tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R4068[Dtype(RTCW(arg1))-613])(arg1);
	}
	RTLE;
	return Result;
}

/* {PO_FILE_ENTRY}.prepare_headers */
EIF_REFERENCE F185_2355 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1041, 0x01).id, 1041, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1033_8090(RTCW(Result));
	F774_5297(RTCW(arg1));
	for (;;) {
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1) + O4221[Dtype(arg1)-773]);
		if (tb1) break;
		tr1 = F774_5280(RTCW(arg1));
		F1042_8503(RTCW(Result), tr1);
		tr1 = F1033_8149(RTMS_EX_H("\012",1,10));
		F1042_8501(RTCW(Result), tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R4068[Dtype(RTCW(arg1))-613])(arg1);
	}
	RTLE;
	return Result;
}

/* {PO_FILE_ENTRY}.prepare_string */
EIF_REFERENCE F185_2356 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Result);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(1041, 0x01).id, 1041, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1033_8090(RTCW(Result));
	tb1 = '\0';
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2) + O4222[Dtype(arg2)-773]);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
		tr1 = F774_5281(RTCW(arg2));
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		tb1 = (EIF_BOOLEAN) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + ti4_2) + ((EIF_INTEGER_32) 3L)) <= ((EIF_INTEGER_32) 80L));
	}
	if (tb1) {
		F1042_8501(RTCW(Result), arg1);
		tr1 = F1033_8149(RTMS_EX_H(" \"",2,8226));
		F1042_8501(RTCW(Result), tr1);
		tr1 = F774_5281(RTCW(arg2));
		F1042_8503(RTCW(Result), tr1);
		tr1 = F1033_8149(RTMS_EX_H("\"\012",2,8714));
		F1042_8501(RTCW(Result), tr1);
	} else {
		F1042_8501(RTCW(Result), arg1);
		tr1 = F1033_8149(RTMS_EX_H(" \"\"\012",4,539107850));
		F1042_8501(RTCW(Result), tr1);
		F774_5297(RTCW(arg2));
		for (;;) {
			tb1 = *(EIF_BOOLEAN *)(RTCW(arg2) + O4221[Dtype(arg2)-773]);
			if (tb1) break;
			tr1 = F1033_8149(RTMS_EX_H("\"",1,34));
			F1042_8501(RTCW(Result), tr1);
			tr1 = F774_5280(RTCW(arg2));
			F1042_8503(RTCW(Result), tr1);
			tr1 = F1033_8149(RTMS_EX_H("\"\012",2,8714));
			F1042_8501(RTCW(Result), tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R4068[Dtype(RTCW(arg2))-613])(arg2);
		}
	}
	RTLE;
	return Result;
}

/* {PO_FILE_ENTRY}.initialize_datastructures */
void F185_2362 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,773,0xFF01,1041,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F774_5278(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,773,0xFF01,1041,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F774_5278(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,773,0xFF01,1041,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F774_5278(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,773,0xFF01,1041,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F774_5278(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit145 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
