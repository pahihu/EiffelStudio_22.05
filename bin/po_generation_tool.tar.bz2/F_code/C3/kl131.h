
#ifndef _C3_kl131_
#define _C3_kl131_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,2242)
static EIF_REFERENCE F171_2242_body(EIF_REFERENCE);
extern EIF_REFERENCE F171_2242(EIF_REFERENCE);
extern void EIF_Minit131(void);

#ifdef __cplusplus
}
#endif

#endif
