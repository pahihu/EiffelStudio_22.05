
#ifndef _C3_st142_
#define _C3_st142_

#ifdef __cplusplus
extern "C" {
#endif

extern void F182_2320(EIF_REFERENCE);
extern void F182_2321(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F182_2324(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_REFERENCE F182_2326(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F182_2330(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE);
extern void EIF_Minit142(void);
extern void F843_6417(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F797_5571(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R6073[])();
extern char *(*R6110[])();
extern char *(*R4075[])();
extern char *(*R2262[])();
extern char *(*R2264[])();

#ifdef __cplusplus
}
#endif

#endif
