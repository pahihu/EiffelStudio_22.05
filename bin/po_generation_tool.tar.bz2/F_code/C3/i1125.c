/*
 * Code for class I18N_MO_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i1125.h"
#include "eif_helpers.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_MO_FILE}.make */
void F162_2163 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(822, 0x01).id, 822, _OBJSIZ_4_6_2_4_1_1_2_1_);
	F822_5904(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,793,0xFF01,1041,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc1 = RTLNS(typres0.id, 793, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F794_5571(RTCW(loc1), ((EIF_INTEGER_32) 0L));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,953,959,0xFF01,793,0xFF01,1041,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_i4 = ((EIF_INTEGER_32) 0L);
	((EIF_TYPED_VALUE *)tr1+2)->it_r = loc1;
	RTAR(tr1,loc1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,793,0xFF01,1041,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc1 = RTLNS(typres0.id, 793, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F794_5571(RTCW(loc1), ((EIF_INTEGER_32) 0L));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,953,959,0xFF01,793,0xFF01,1041,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_i4 = ((EIF_INTEGER_32) 0L);
	((EIF_TYPED_VALUE *)tr1+2)->it_r = loc1;
	RTAR(tr1,loc1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {I18N_MO_FILE}.open */
void F162_2164 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current);
	tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4511[Dtype(RTCW(tr1))-822])(tr1);
	if (tb2) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tb2 = F822_5946(RTCW(tr1));
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current);
		F822_5974(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current);
		tb1 = F822_5964(RTCW(tr1));
		if (tb1) {
			F162_2179(Current);
			if (F162_2178(Current)) {
				ti4_1 = F162_2182(Current);
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_5_0_2_) = (EIF_INTEGER_32) ti4_1;
				ti4_1 = F162_2182(Current);
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_5_0_1_) = (EIF_INTEGER_32) ti4_1;
				ti4_1 = F162_2182(Current);
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_5_0_3_) = (EIF_INTEGER_32) ti4_1;
				ti4_1 = F162_2182(Current);
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_5_0_4_) = (EIF_INTEGER_32) ti4_1;
				ti4_1 = F162_2182(Current);
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_5_0_5_) = (EIF_INTEGER_32) ti4_1;
				ti4_1 = F162_2182(Current);
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_5_0_6_) = (EIF_INTEGER_32) ti4_1;
				ti4_1 = ((EIF_INTEGER_32) 0L);
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_5_0_0_) = (EIF_INTEGER_32) ti4_1;
				F162_2180(Current);
				*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		}
	}
	RTLE;
}

/* {I18N_MO_FILE}.close */
void F162_2165 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	F822_5991(RTCW(tr1));
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {I18N_MO_FILE}.entry_has_plurals */
EIF_BOOLEAN F162_2167 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F162_2176(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = eif_boxed_item(tr1,2);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4109[Dtype(RTCW(tr1))-706])(tr1);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L));
	RTLE;
	return Result;
}

/* {I18N_MO_FILE}.original_singular_string */
EIF_REFERENCE F162_2168 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_CHARACTER_32 tw1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	F162_2176(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = eif_boxed_item(tr1,2);
	ti4_1 = ((EIF_INTEGER_32) 1L);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4082[Dtype(RTCW(loc1))-706])(loc1, (EIF_REFERENCE) &ti4_1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\004';
	ti4_1 = F1040_8398(RTCW(Result), tw1, ((EIF_INTEGER_32) 1L));
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
	ti4_1 = eif_min_int32 ((EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)),ti4_2);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
	tr1 = F1042_8548(RTCW(Result), ti4_1, ti4_2);
	Result = (EIF_REFERENCE) tr1;
	RTLE;
	return Result;
}

/* {I18N_MO_FILE}.original_plural_string */
EIF_REFERENCE F162_2169 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	F162_2176(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = eif_boxed_item(tr1,2);
	ti4_1 = ((EIF_INTEGER_32) 2L);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4082[Dtype(RTCW(loc1))-706])(loc1, (EIF_REFERENCE) &ti4_1);
	RTLE;
	return Result;
}

/* {I18N_MO_FILE}.context_string */
EIF_REFERENCE F162_2170 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	F162_2176(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = eif_boxed_item(tr1,2);
	ti4_1 = ((EIF_INTEGER_32) 1L);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4082[Dtype(RTCW(loc1))-706])(loc1, (EIF_REFERENCE) &ti4_1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\004';
	loc2 = F1040_8398(RTCW(Result), tw1, ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
		ti4_1 = eif_max_int32 ((EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)),((EIF_INTEGER_32) 1L));
		tr1 = F1042_8548(RTCW(Result), ((EIF_INTEGER_32) 1L), ti4_1);
		Result = (EIF_REFERENCE) tr1;
	} else {
		RTLE;
		return (EIF_REFERENCE) NULL;
	}
	RTLE;
	return Result;
}

/* {I18N_MO_FILE}.translated_singular_string */
EIF_REFERENCE F162_2171 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	F162_2177(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc2 = eif_boxed_item(tr1,2);
	tr1 = RTOSCF(2147,F160_2147, (Current));
	tr1 = F8_158(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_5_0_0_));
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_POINTER, EIF_REFERENCE, EIF_INTEGER_32)) *(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_4_2_0_4_0_0_))(
		*(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_4_2_0_4_0_1_),
		*(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_), ((EIF_INTEGER_32) 1L));
	loc1 = ti4_1;
	ti4_1 = (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4082[Dtype(RTCW(loc2))-706])(loc2, (EIF_REFERENCE) &ti4_1);
	RTLE;
	return Result;
}

/* {I18N_MO_FILE}.translated_plural_strings */
EIF_REFERENCE F162_2172 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	F162_2177(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc2 = eif_boxed_item(tr1,2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,706,0xFF01,1041,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 706, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	tr1 = RTMS32_EX_H("",0,0);
	F707_5160(RTCW(Result), tr1, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 3L));
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4055[Dtype(RTCW(loc2))-613])(loc2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		tb1 = '\01';
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4066[Dtype(RTCW(loc2))-613])(loc2);
		if (!tb2) {
			tb1 = (EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 3L));
		}
		if (tb1) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4089[Dtype(RTCW(loc2))-613])(loc2);
		F707_5184(RTCW(Result), tr1, loc1);
		loc1++;
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R4068[Dtype(RTCW(loc2))-613])(loc2);
	}
	RTLE;
	return Result;
}

/* {I18N_MO_FILE}.locale */
EIF_REFERENCE F162_2173 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = F822_5914(RTCW(tr1));
	tr1 = F920_6783(RTCW(tr1));
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tr1 = RTMS_EX_H("mo",2,28015);
		tb2 = F920_6780(loc2, tr1);
		tb1 = tb2;
	}
	if (tb1) {
		loc1 = F920_6806(loc2);
		tb1 = '\01';
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6110[Dtype(RTCW(loc1))-1036])(loc1);
		if (!(EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 5L))) {
			tb2 = '\0';
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6110[Dtype(RTCW(loc1))-1036])(loc1);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 8L))) {
				tb3 = '\01';
				tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6074[Dtype(RTCW(loc1))-1036])(loc1, ((EIF_INTEGER_32) 3L));
				tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
				if (!(EIF_BOOLEAN)(tw1 == tw2)) {
					tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6074[Dtype(RTCW(loc1))-1036])(loc1, ((EIF_INTEGER_32) 3L));
					tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
					tb3 = (EIF_BOOLEAN)(tw1 == tw2);
				}
				tb2 = tb3;
			}
			tb1 = tb2;
		}
		if (tb1) {
			Result = RTLNS(eif_new_type(1041, 0x01).id, 1041, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F1042_8462(RTCW(Result), loc1);
			F1042_8525(RTCW(Result), ((EIF_INTEGER_32) 3L));
		}
	}
	RTLE;
	return Result;
}

/* {I18N_MO_FILE}.get_original_entries */
void F162_2176 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = eif_integer_32_item(RTCW(tr1),1);
	if ((EIF_BOOLEAN)(ti4_1 != arg1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		
		eif_put_integer_32_item(RTCW(tr1),1,arg1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = F162_2181(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_5_0_3_), arg1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		tr2 = F1033_8168(RTCW(tr2), tw1);
		
		eif_put_reference_item(RTCW(tr1),2,tr2);
	}
	RTLE;
}

/* {I18N_MO_FILE}.get_translated_entries */
void F162_2177 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	ti4_1 = eif_integer_32_item(RTCW(tr1),1);
	if ((EIF_BOOLEAN)(ti4_1 != arg1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		
		eif_put_integer_32_item(RTCW(tr1),1,arg1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = F162_2181(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_5_0_4_), arg1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		tr2 = F1033_8168(RTCW(tr2), tw1);
		
		eif_put_reference_item(RTCW(tr1),2,tr2);
	}
	RTLE;
}

/* {I18N_MO_FILE}.valid */
EIF_BOOLEAN F162_2178 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) ((*(EIF_BOOLEAN *)(Current+ _CHROFF_3_2_)) != (*(EIF_BOOLEAN *)(Current+ _CHROFF_3_1_)));
}

/* {I18N_MO_FILE}.read_magic_number */
void F162_2179 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = *(EIF_REFERENCE *)(Current);
	F822_5997(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4556[Dtype(RTCW(tr1))-822])(tr1);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O4496[Dtype(tr1)-820]);
	tr1 = *(EIF_REFERENCE *)(Current);
	F822_5997(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	loc2 = F162_2185(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {840,977,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 4L),sizeof(EIF_NATURAL_8), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 4L;
	}
	*((EIF_NATURAL_8 *)tr2+0) = (EIF_NATURAL_8) (EIF_NATURAL_8) ((EIF_INTEGER_32) 222L);
	*((EIF_NATURAL_8 *)tr2+1) = (EIF_NATURAL_8) (EIF_NATURAL_8) ((EIF_INTEGER_32) 18L);
	*((EIF_NATURAL_8 *)tr2+2) = (EIF_NATURAL_8) (EIF_NATURAL_8) ((EIF_INTEGER_32) 4L);
	*((EIF_NATURAL_8 *)tr2+3) = (EIF_NATURAL_8) (EIF_NATURAL_8) ((EIF_INTEGER_32) 149L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F841_6404)(tr2);
	tb1 = F708_5175(RTCW(loc2), tr1);
	if (tb1) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_3_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		if ((EIF_BOOLEAN)(loc1 == (EIF_INTEGER_32) ((EIF_INTEGER_64) RTI64C(3725722773)))) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_3_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			if ((EIF_BOOLEAN)(loc1 == (EIF_INTEGER_32) ((EIF_INTEGER_64) RTI64C(2500072158)))) {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_3_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		}
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {840,977,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 4L),sizeof(EIF_NATURAL_8), EIF_TRUE);
			RT_SPECIAL_COUNT(tr2) = 4L;
		}
		*((EIF_NATURAL_8 *)tr2+0) = (EIF_NATURAL_8) (EIF_NATURAL_8) ((EIF_INTEGER_32) 149L);
		*((EIF_NATURAL_8 *)tr2+1) = (EIF_NATURAL_8) (EIF_NATURAL_8) ((EIF_INTEGER_32) 4L);
		*((EIF_NATURAL_8 *)tr2+2) = (EIF_NATURAL_8) (EIF_NATURAL_8) ((EIF_INTEGER_32) 18L);
		*((EIF_NATURAL_8 *)tr2+3) = (EIF_NATURAL_8) (EIF_NATURAL_8) ((EIF_INTEGER_32) 222L);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F841_6404)(tr2);
		tb1 = F708_5175(RTCW(loc2), tr1);
		if (tb1) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_3_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			if ((EIF_BOOLEAN)(loc1 == (EIF_INTEGER_32) ((EIF_INTEGER_64) RTI64C(3725722773)))) {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_3_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				if ((EIF_BOOLEAN)(loc1 == (EIF_INTEGER_32) ((EIF_INTEGER_64) RTI64C(2500072158)))) {
					*(EIF_BOOLEAN *)(Current+ _CHROFF_3_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			}
		}
	}
	RTLE;
}

/* {I18N_MO_FILE}.read_plural_form */
void F162_2180 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc4 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,loc5);
	RTLIU(6);
	
	RTGC;
	loc4 = (EIF_NATURAL_32) (EIF_CHARACTER_8) '0';
	F162_2177(Current, ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = eif_boxed_item(tr1,2);
	ti4_1 = ((EIF_INTEGER_32) 1L);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4082[Dtype(RTCW(tr1))-706])(tr1, (EIF_REFERENCE) &ti4_1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
	loc1 = F1033_8168(RTCW(tr1), tw1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4055[Dtype(RTCW(loc1))-613])(loc1);
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(loc2 != NULL)) {
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4066[Dtype(RTCW(loc1))-613])(loc1);
			tb1 = tb2;
		}
		if (tb1) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4089[Dtype(RTCW(loc1))-613])(loc1);
		tr2 = RTMS_EX_H("Plural-Forms",12,621940595);
		tb2 = F1033_8134(RTCW(tr1), tr2);
		if (tb2) {
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4089[Dtype(RTCW(loc1))-613])(loc1);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R4068[Dtype(RTCW(loc1))-613])(loc1);
	}
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ';';
		loc3 = F1040_8398(RTCW(loc2), tw1, ((EIF_INTEGER_32) 1L));
		tb2 = '\0';
		if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 1L))) {
			tr1 = RTMS_EX_H("nplurals=",9,460538429);
			tb3 = F1033_8134(RTCW(loc2), tr1);
			tb2 = tb3;
		}
		if (tb2) {
			tu4_1 = F1042_8470(RTCW(loc2), (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L)));
			loc6 = (EIF_INTEGER_32) (EIF_NATURAL_32) (tu4_1 - loc4);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '=';
			ti4_1 = F1040_8398(RTCW(loc2), tw1, loc3);
			loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
			loc5 = F1042_8548(RTCW(loc2), loc3, ti4_1);
			tr1 = RTOSCF(2147,F160_2147, (Current));
			ti4_1 = F8_143(RTCW(tr1), loc6, loc5);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_5_0_0_) = (EIF_INTEGER_32) ti4_1;
		}
	}
	tb2 = '\01';
	if (!(EIF_BOOLEAN)(loc2 == NULL)) {
		ti4_1 = ((EIF_INTEGER_32) 0L);
		tb2 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_5_0_0_) == ti4_1);
	}
	if (tb2) {
		ti4_1 = ((EIF_INTEGER_32) 2L);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_5_0_0_) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

/* {I18N_MO_FILE}.extract_string */
EIF_REFERENCE F162_2181 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	F822_5997(RTCW(tr1), (EIF_INTEGER_32) (arg1 + (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)) * ((EIF_INTEGER_32) 8L))));
	loc1 = F162_2182(Current);
	loc2 = F162_2182(Current);
	tr1 = *(EIF_REFERENCE *)(Current);
	F822_5997(RTCW(tr1), loc2);
	tr1 = RTOSCF(995,F72_995, (Current));
	Result = F2_35(RTCW(tr1), *(EIF_REFERENCE *)(Current), loc1);
	RTLE;
	return Result;
}

/* {I18N_MO_FILE}.read_integer */
EIF_INTEGER_32 F162_2182 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current+ _CHROFF_3_2_) == *(EIF_BOOLEAN *)(Current+ _CHROFF_3_4_))) {
		RTLE;
		return (EIF_INTEGER_32) F162_2183(Current);
	} else {
		RTLE;
		return (EIF_INTEGER_32) F162_2184(Current);
	}/* NOTREACHED */
	
}

/* {I18N_MO_FILE}.read_integer_same_endianness */
EIF_INTEGER_32 F162_2183 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4556[Dtype(RTCW(tr1))-822])(tr1);
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1) + O4496[Dtype(tr1)-820]);
	RTLE;
	return Result;
}

/* {I18N_MO_FILE}.read_integer_opposite_endianness */
EIF_INTEGER_32 F162_2184 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc2 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc3 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc4 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_NATURAL_8 tu1_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc5 = F162_2185(Current);
	tu1_1 = F708_5165(RTCW(loc5), ((EIF_INTEGER_32) 1L));
	loc1 = (EIF_NATURAL_32) tu1_1;
	tu1_1 = F708_5165(RTCW(loc5), ((EIF_INTEGER_32) 2L));
	loc2 = (EIF_NATURAL_32) tu1_1;
	tu1_1 = F708_5165(RTCW(loc5), ((EIF_INTEGER_32) 3L));
	loc3 = (EIF_NATURAL_32) tu1_1;
	tu1_1 = F708_5165(RTCW(loc5), ((EIF_INTEGER_32) 4L));
	loc4 = (EIF_NATURAL_32) tu1_1;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_3_2_)) {
		tu4_1 = eif_bit_shift_left(loc2,((EIF_INTEGER_32) 8L));
		tu4_1 = eif_bit_or(loc1,tu4_1);
		tu4_2 = eif_bit_shift_left(loc3,((EIF_INTEGER_32) 16L));
		tu4_1 = eif_bit_or(tu4_1,tu4_2);
		tu4_2 = eif_bit_shift_left(loc4,((EIF_INTEGER_32) 24L));
		tu4_1 = eif_bit_or(tu4_1,tu4_2);
		Result = (EIF_INTEGER_32) tu4_1;
	} else {
		tu4_1 = eif_bit_shift_left(loc3,((EIF_INTEGER_32) 8L));
		tu4_1 = eif_bit_or(loc4,tu4_1);
		tu4_2 = eif_bit_shift_left(loc2,((EIF_INTEGER_32) 16L));
		tu4_1 = eif_bit_or(tu4_1,tu4_2);
		tu4_2 = eif_bit_shift_left(loc1,((EIF_INTEGER_32) 24L));
		tu4_1 = eif_bit_or(tu4_1,tu4_2);
		Result = (EIF_INTEGER_32) tu4_1;
	}
	RTLE;
	return Result;
}

/* {I18N_MO_FILE}.get_integer */
EIF_REFERENCE F162_2185 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_8 loc1 = (EIF_NATURAL_8) 0;
	EIF_NATURAL_8 loc2 = (EIF_NATURAL_8) 0;
	EIF_NATURAL_8 loc3 = (EIF_NATURAL_8) 0;
	EIF_NATURAL_8 loc4 = (EIF_NATURAL_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4562[Dtype(RTCW(tr1))-822])(tr1);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = *(EIF_NATURAL_8 *)(RTCW(tr1) + O4505[Dtype(tr1)-820]);
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4562[Dtype(RTCW(tr1))-822])(tr1);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = *(EIF_NATURAL_8 *)(RTCW(tr1) + O4505[Dtype(tr1)-820]);
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4562[Dtype(RTCW(tr1))-822])(tr1);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc3 = *(EIF_NATURAL_8 *)(RTCW(tr1) + O4505[Dtype(tr1)-820]);
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4562[Dtype(RTCW(tr1))-822])(tr1);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc4 = *(EIF_NATURAL_8 *)(RTCW(tr1) + O4505[Dtype(tr1)-820]);
	{
		static EIF_TYPE_INDEX typarr0[] = {840,977,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 4L),sizeof(EIF_NATURAL_8), EIF_TRUE);
		RT_SPECIAL_COUNT(tr2) = 4L;
	}
	*((EIF_NATURAL_8 *)tr2+0) = (EIF_NATURAL_8) loc1;
	*((EIF_NATURAL_8 *)tr2+1) = (EIF_NATURAL_8) loc2;
	*((EIF_NATURAL_8 *)tr2+2) = (EIF_NATURAL_8) loc3;
	*((EIF_NATURAL_8 *)tr2+3) = (EIF_NATURAL_8) loc4;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F841_6404)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTLE;
	return Result;
}

void EIF_Minit125 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
