
#ifndef _C3_op109_
#define _C3_op109_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_CHARACTER_8,2008)
static EIF_CHARACTER_8 F146_2008_body(EIF_REFERENCE);
extern EIF_CHARACTER_8 F146_2008(EIF_REFERENCE);
extern EIF_BOOLEAN F146_2012(EIF_REFERENCE);
extern EIF_CHARACTER_8 F146_2013(EIF_REFERENCE);
extern void EIF_Minit109(void);

#ifdef __cplusplus
}
#endif

#endif
