
#ifndef _C1_i116_
#define _C1_i116_

#ifdef __cplusplus
extern "C" {
#endif

extern void F16_198(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit16(void);
extern void F115_1496(EIF_REFERENCE, EIF_REFERENCE);
extern long O1278[];
extern long O1279[];

#ifdef __cplusplus
}
#endif

#endif
