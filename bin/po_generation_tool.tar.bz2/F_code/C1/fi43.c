/*
 * Code for class reference FILE_UTILITIES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "fi43.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {FILE_UTILITIES}.directory_path_exists */
EIF_BOOLEAN F63_876 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = '\0';
	tb1 = F920_6775(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTLNS(eif_new_type(312, 0x01).id, 312, _OBJSIZ_3_0_0_1_0_2_0_0_);
		F313_4227(RTCW(tr1), arg1);
		tb1 = F313_4250(RTCW(tr1));
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {FILE_UTILITIES}.directory_exists */
EIF_BOOLEAN F63_877 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = '\0';
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6088[Dtype(RTCW(arg1))-1036])(arg1);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTLNS(eif_new_type(312, 0x01).id, 312, _OBJSIZ_3_0_0_1_0_2_0_0_);
		F313_4225(RTCW(tr1), arg1);
		tb1 = F313_4250(RTCW(tr1));
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {FILE_UTILITIES}.file_names */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
EIF_REFERENCE F63_878 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_REFERENCE  EIF_VOLATILE tr2 = NULL;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_BOOLEAN  EIF_VOLATILE tb2;
	EIF_BOOLEAN  EIF_VOLATILE tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	RTXD;
	
	RTLI(9);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Current);
	RTLR(4,Result);
	RTLR(5,loc4);
	RTLR(6,loc3);
	RTLR(7,tr2);
	RTLR(8,saved_except);
	RTLIU(9);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN) !loc2) {
		tr1 = RTLNS(eif_new_type(312, 0x01).id, 312, _OBJSIZ_3_0_0_1_0_2_0_0_);
		F313_4225(RTCW(tr1), arg1);
		loc1 = (EIF_REFERENCE) tr1;
		tb1 = '\0';
		tb2 = F313_4250(RTCW(loc1));
		if (tb2) {
			tb2 = F313_4251(RTCW(loc1));
			tb1 = tb2;
		}
		if (tb1) {
			F313_4235(RTCW(loc1));
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,793,0xFF01,1041,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
				tr1 = RTLNS(typres0.id, 793, _OBJSIZ_1_1_0_1_0_0_0_0_);
			}
			F794_5571(RTCW(tr1), ((EIF_INTEGER_32) 0L));
			Result = (EIF_REFERENCE) tr1;
			F313_4232(RTCW(loc1));
			for (;;) {
				tr1 = F313_4245(RTCW(loc1));
				loc4 = tr1;
				if ((EIF_BOOLEAN) !EIF_TEST(loc4)) break;
				tr1 = RTLNS(eif_new_type(822, 0x01).id, 822, _OBJSIZ_4_6_2_4_1_1_2_1_);
				tr2 = RTLNS(eif_new_type(919, 0x01).id, 919, _OBJSIZ_2_1_0_0_0_0_0_0_);
				F920_6767(RTCW(tr2), arg1);
				tr2 = F920_6794(RTCW(tr2), loc4);
				F822_5905(RTCW(tr1), tr2);
				loc3 = (EIF_REFERENCE) tr1;
				tb1 = '\0';
				tb2 = '\0';
				tb3 = F822_5939(RTCW(loc3));
				if (tb3) {
					tb3 = F822_5942(RTCW(loc3));
					tb2 = tb3;
				}
				if (tb2) {
					tb2 = F822_5946(RTCW(loc3));
					tb1 = tb2;
				}
				if (tb1) {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4075[Dtype(RTCW(Result))-773])(Result, loc4);
				}
				F313_4232(RTCW(loc1));
			}
			F313_4236(RTCW(loc1));
		}
	} else {
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tb2 = F313_4248(RTCW(loc1));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			F313_4236(RTCW(loc1));
		}
	}
	RTE_E
	RTXSC;
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
	return Result;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {FILE_UTILITIES}.directory_names */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
EIF_REFERENCE F63_879 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_REFERENCE  EIF_VOLATILE tr2 = NULL;
	EIF_INTEGER_32  EIF_VOLATILE ti4_1;
	EIF_CHARACTER_32  EIF_VOLATILE tw1;
	EIF_CHARACTER_32  EIF_VOLATILE tw2;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_BOOLEAN  EIF_VOLATILE tb2;
	EIF_BOOLEAN  EIF_VOLATILE tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	RTXD;
	
	RTLI(9);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Current);
	RTLR(4,Result);
	RTLR(5,loc4);
	RTLR(6,loc3);
	RTLR(7,tr2);
	RTLR(8,saved_except);
	RTLIU(9);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN) !loc2) {
		tr1 = RTLNS(eif_new_type(312, 0x01).id, 312, _OBJSIZ_3_0_0_1_0_2_0_0_);
		F313_4225(RTCW(tr1), arg1);
		loc1 = (EIF_REFERENCE) tr1;
		tb1 = '\0';
		tb2 = F313_4250(RTCW(loc1));
		if (tb2) {
			tb2 = F313_4251(RTCW(loc1));
			tb1 = tb2;
		}
		if (tb1) {
			F313_4235(RTCW(loc1));
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,793,0xFF01,1041,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
				tr1 = RTLNS(typres0.id, 793, _OBJSIZ_1_1_0_1_0_0_0_0_);
			}
			F794_5571(RTCW(tr1), ((EIF_INTEGER_32) 0L));
			Result = (EIF_REFERENCE) tr1;
			F313_4232(RTCW(loc1));
			for (;;) {
				tr1 = F313_4245(RTCW(loc1));
				loc4 = tr1;
				if ((EIF_BOOLEAN) !EIF_TEST(loc4)) break;
				tb1 = '\01';
				tb2 = '\0';
				ti4_1 = *(EIF_INTEGER_32 *)(loc4+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
					tw1 = F1042_8468(loc4, ((EIF_INTEGER_32) 1L));
					tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
					tb2 = (EIF_BOOLEAN)(tw1 == tw2);
				}
				if (!tb2) {
					tb2 = '\0';
					tb3 = '\0';
					ti4_1 = *(EIF_INTEGER_32 *)(loc4+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
						tw1 = F1042_8468(loc4, ((EIF_INTEGER_32) 1L));
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
						tb3 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb3) {
						tw1 = F1042_8468(loc4, ((EIF_INTEGER_32) 2L));
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
						tb2 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					tb1 = tb2;
				}
				if (tb1) {
				} else {
					tr1 = RTLNS(eif_new_type(312, 0x01).id, 312, _OBJSIZ_3_0_0_1_0_2_0_0_);
					tr2 = RTLNS(eif_new_type(919, 0x01).id, 919, _OBJSIZ_2_1_0_0_0_0_0_0_);
					F920_6767(RTCW(tr2), arg1);
					tr2 = F920_6794(RTCW(tr2), loc4);
					F313_4227(RTCW(tr1), tr2);
					loc3 = (EIF_REFERENCE) tr1;
					tb1 = '\0';
					tb2 = F313_4250(RTCW(loc3));
					if (tb2) {
						tb2 = F313_4251(RTCW(loc3));
						tb1 = tb2;
					}
					if (tb1) {
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4075[Dtype(RTCW(Result))-773])(Result, loc4);
					}
				}
				F313_4232(RTCW(loc1));
			}
			F313_4236(RTCW(loc1));
		}
	} else {
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tb2 = F313_4248(RTCW(loc1));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			F313_4236(RTCW(loc1));
		}
	}
	RTE_E
	RTXSC;
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
	return Result;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {FILE_UTILITIES}.file_exists */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
EIF_BOOLEAN F63_886 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_BOOLEAN  EIF_VOLATILE tb2;
	EIF_VOLATILE EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	RTXD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,saved_except);
	RTLIU(4);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	tb1 = '\0';
	tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6088[Dtype(RTCW(arg1))-1036])(arg1);
	if ((EIF_BOOLEAN) !tb2) {
		tb1 = (EIF_BOOLEAN) !loc2;
	}
	if (tb1) {
		tr1 = RTLNS(eif_new_type(822, 0x01).id, 822, _OBJSIZ_4_6_2_4_1_1_2_1_);
		F822_5904(RTCW(tr1), arg1);
		loc1 = (EIF_REFERENCE) tr1;
		Result = '\0';
		tb1 = F822_5939(RTCW(loc1));
		if (tb1) {
			tb1 = F822_5946(RTCW(loc1));
			Result = tb1;
		}
	}
	RTE_E
	RTXSC;
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
	return Result;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

void EIF_Minit43 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
