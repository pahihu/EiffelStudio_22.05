
#ifndef _C1_su24_
#define _C1_su24_

#ifdef __cplusplus
extern "C" {
#endif

extern void F27_276(EIF_REFERENCE, EIF_REFERENCE);
extern void F27_277(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit24(void);
extern void F1046_8579(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1046_8595(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
