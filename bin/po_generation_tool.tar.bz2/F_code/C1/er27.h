
#ifndef _C1_er27_
#define _C1_er27_

#ifdef __cplusplus
extern "C" {
#endif

extern void F30_465(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit27(void);

#ifdef __cplusplus
}
#endif

#endif
