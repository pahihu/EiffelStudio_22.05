/*
 * Code for class PO_FILE_ENTRY_ID_GEN
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "po34.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PO_FILE_ENTRY_ID_GEN}.generate_id_from_msgid_and_msgctxt */
EIF_REFERENCE F44_646 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		tr1 = F1033_8149(RTCW(arg1));
		tr2 = F1033_8149(RTCW(arg2));
		Result = F1042_8520(RTCW(tr1), tr2);
	} else {
		Result = F1033_8149(RTCW(arg1));
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

void EIF_Minit34 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
