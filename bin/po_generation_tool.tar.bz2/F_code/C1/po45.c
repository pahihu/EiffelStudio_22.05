/*
 * Code for class PO_GENERATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "po45.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PO_GENERATOR}.make */
void F66_895 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg3;
	RTLE;
}

/* {PO_GENERATOR}.generate */
void F66_900 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_REFERENCE tr6 = NULL;
	EIF_REFERENCE tr7 = NULL;
	EIF_REFERENCE tr8 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(14);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,loc4);
	RTLR(5,loc5);
	RTLR(6,loc1);
	RTLR(7,tr2);
	RTLR(8,tr3);
	RTLR(9,tr4);
	RTLR(10,tr5);
	RTLR(11,tr6);
	RTLR(12,tr7);
	RTLR(13,tr8);
	RTLIU(14);
	
	RTGC;
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6132[Dtype(RTCW(loc2))-1036])(loc2);
	tb1 = '\01';
	tb2 = '\01';
	tr1 = RTOSCF(902,F66_902, (Current));
	tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R6115[Dtype(RTCW(loc3))-1036])(loc3, tr1);
	if (!tb3) {
		tr1 = RTOSCF(903,F66_903, (Current));
		tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R6115[Dtype(RTCW(loc3))-1036])(loc3, tr1);
		tb2 = tb3;
	}
	if (!tb2) {
		tr1 = F1042_8536(RTCV(RTOSCF(906,F66_906, (Current))));
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R6115[Dtype(RTCW(loc3))-1036])(loc3, tr1);
		tb1 = tb2;
	}
	if (tb1) {
		F1126_10396(RTCV(RTOSCF(901,F66_901, (Current))));
		tr1 = RTOSCF(901,F66_901, (Current));
		tu1_1 = ((EIF_NATURAL_8) 0U);
		F1124_10205(RTCW(tr1), tu1_1);
		tr1 = RTOSCF(901,F66_901, (Current));
		F1126_10412(RTCW(tr1), loc2, NULL, NULL);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(901,F66_901, (Current)))+ _LNGOFF_351_27_0_31_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			F1126_10396(RTCV(RTOSCF(901,F66_901, (Current))));
			tr1 = RTOSCF(901,F66_901, (Current));
			tu1_1 = ((EIF_NATURAL_8) 3U);
			F1124_10205(RTCW(tr1), tu1_1);
			tr1 = RTOSCF(901,F66_901, (Current));
			F1126_10412(RTCW(tr1), loc2, NULL, NULL);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(901,F66_901, (Current)))+ _LNGOFF_351_27_0_31_);
			if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
				F1126_10396(RTCV(RTOSCF(901,F66_901, (Current))));
				tr1 = RTOSCF(901,F66_901, (Current));
				tu1_1 = ((EIF_NATURAL_8) 2U);
				F1124_10205(RTCW(tr1), tu1_1);
				tr1 = RTOSCF(901,F66_901, (Current));
				F1126_10412(RTCW(tr1), loc2, NULL, NULL);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(901,F66_901, (Current)))+ _LNGOFF_351_27_0_31_);
				if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
					F1126_10396(RTCV(RTOSCF(901,F66_901, (Current))));
					tr1 = RTOSCF(901,F66_901, (Current));
					tu1_1 = ((EIF_NATURAL_8) 1U);
					F1124_10205(RTCW(tr1), tu1_1);
					tr1 = RTOSCF(901,F66_901, (Current));
					F1126_10412(RTCW(tr1), loc2, NULL, NULL);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(901,F66_901, (Current)))+ _LNGOFF_351_27_0_31_);
					if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
						*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
				}
			}
		}
		tb1 = '\0';
		tb2 = '\0';
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_)) {
			tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(901,F66_901, (Current))) + _REFACS_52_);
			loc4 = tr1;
			tb2 = EIF_TEST(loc4);
		}
		if (tb2) {
			tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(901,F66_901, (Current))) + _REFACS_40_);
			loc5 = tr1;
			tb1 = EIF_TEST(loc5);
		}
		if (tb1) {
			loc1 = RTLNS(eif_new_type(1086, 0x01).id, 1086, _OBJSIZ_11_7_0_3_0_0_0_0_);
			tr1 = *(EIF_REFERENCE *)(Current);
			tr2 = RTOSCF(902,F66_902, (Current));
			tr3 = RTOSCF(903,F66_903, (Current));
			tr4 = RTOSCF(904,F66_904, (Current));
			tr5 = RTOSCF(905,F66_905, (Current));
			tr6 = RTOSCF(906,F66_906, (Current));
			tr7 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tr8 = F1033_8149(RTCW(loc2));
			F1087_9247(RTCW(loc1), tr1, tr2, tr3, tr4, tr5, tr6, tr7, tr8);
			F213_3203(RTCW(loc1), loc4);
			F213_3204(RTCW(loc1), loc5);
			F213_3322(RTCW(loc1), loc4);
		}
	}
	RTLE;
}

/* {PO_GENERATOR}.eiffel_parser */
static EIF_REFERENCE F66_901_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (901);
#define Result RTOSR(901)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1126, 0x01).id, 1126, _OBJSIZ_351_27_0_327_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(323, 0x01).id, 323, _OBJSIZ_2_2_0_2_0_0_0_0_);
	F1126_10387(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	F1126_10388(RTCW(Result));
	RTOSE (901);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F66_901 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(901,F66_901_body,(Current));
}

/* {PO_GENERATOR}.name_of_translation */

EIF_REFERENCE F66_902 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (902,RTMS32_EX_H("t\000\000\000r\000\000\000a\000\000\000n\000\000\000s\000\000\000l\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",11,1235133806));
}

/* {PO_GENERATOR}.name_of_plural_translation */

EIF_REFERENCE F66_903 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (903,RTMS32_EX_H("p\000\000\000l\000\000\000u\000\000\000r\000\000\000a\000\000\000l\000\000\000_\000\000\000t\000\000\000r\000\000\000a\000\000\000n\000\000\000s\000\000\000l\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",18,213884014));
}

/* {PO_GENERATOR}.name_of_translation_in_context */

EIF_REFERENCE F66_904 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (904,RTMS32_EX_H("t\000\000\000r\000\000\000a\000\000\000n\000\000\000s\000\000\000l\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000_\000\000\000i\000\000\000n\000\000\000_\000\000\000c\000\000\000o\000\000\000n\000\000\000t\000\000\000e\000\000\000x\000\000\000t\000\000\000",22,2116278388));
}

/* {PO_GENERATOR}.name_of_plural_translation_in_context */

EIF_REFERENCE F66_905 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (905,RTMS32_EX_H("p\000\000\000l\000\000\000u\000\000\000r\000\000\000a\000\000\000l\000\000\000_\000\000\000t\000\000\000r\000\000\000a\000\000\000n\000\000\000s\000\000\000l\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000_\000\000\000i\000\000\000n\000\000\000_\000\000\000c\000\000\000o\000\000\000n\000\000\000t\000\000\000e\000\000\000x\000\000\000t\000\000\000",29,1835697012));
}

/* {PO_GENERATOR}.name_of_feature_clause */

EIF_REFERENCE F66_906 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (906,RTMS32_EX_H("I\000\000\000n\000\000\000t\000\000\000e\000\000\000r\000\000\000n\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000a\000\000\000l\000\000\000i\000\000\000z\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",20,2005568366));
}

void EIF_Minit45 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
