
#ifndef _C1_po34_
#define _C1_po34_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F44_646(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit34(void);
extern EIF_REFERENCE F1042_8520(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1033_8149(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
