
#ifndef _C1_kl13_
#define _C1_kl13_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,182)
static EIF_REFERENCE F13_182_body(EIF_REFERENCE);
extern EIF_REFERENCE F13_182(EIF_REFERENCE);
extern void EIF_Minit13(void);

#ifdef __cplusplus
}
#endif

#endif
