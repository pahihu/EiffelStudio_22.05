
#ifndef _C1_i114_
#define _C1_i114_

#ifdef __cplusplus
extern "C" {
#endif

extern void F14_183(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit14(void);
extern void F268_3553(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
