
#ifndef _C1_cr30_
#define _C1_cr30_

#ifdef __cplusplus
extern "C" {
#endif

extern void F34_488(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit30(void);

#ifdef __cplusplus
}
#endif

#endif
