/*
 * Code for class PO_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "po44.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PO_FILE}.make_empty */
void F65_888 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(187, 1).id);
	F188_2377(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,783,0xFF01,184,0xFF01,1041,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F784_5440(RTCW(tr1), ((EIF_INTEGER_32) 20L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTMS_EX_H("Content-Type",12,1604261989);
	tr3 = RTMS_EX_H("text/plain; charset=UTF-8",25,731690808);
	F188_2381(RTCW(tr1), tr2, tr3);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTMS_EX_H("Content-Transfer-Encoding",25,1505032295);
	tr3 = RTMS_EX_H("8bit",4,945973620);
	F188_2381(RTCW(tr1), tr2, tr3);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTMS_EX_H("Last-Translator",15,63583602);
	tr3 = RTMS_EX_H("YOUR NAME HERE",14,1744894533);
	F188_2381(RTCW(tr1), tr2, tr3);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTMS_EX_H("Language-Team",13,1921993837);
	tr3 = RTMS_EX_H("YOUR TEAM HERE",14,370601029);
	F188_2381(RTCW(tr1), tr2, tr3);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTMS_EX_H("Plural-Forms",12,621940595);
	tr3 = RTMS_EX_H("nplurals=2; plural=(n != 1);",28,1564105019);
	F188_2381(RTCW(tr1), tr2, tr3);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTMS_EX_H("MIME-Version",12,298779502);
	tr3 = RTMS_EX_H("1.0",3,3223088);
	F188_2381(RTCW(tr1), tr2, tr3);
	RTLE;
}

/* {PO_FILE}.entry */
EIF_REFERENCE F65_890 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	struct eif_ex_33 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(43, 0x00).id);
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,tr2);
	RTLR(6,Result);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr2 = F44_646(RTCW(loc1), arg1, arg2);
	Result = F784_5446(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {PO_FILE}.add_entry */
void F65_891 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr2 = F185_2347(RTCW(arg1));
	F784_5486(RTCW(tr1), arg1, tr2);
	RTLE;
}

/* {PO_FILE}.has_entry */
EIF_BOOLEAN F65_892 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	struct eif_ex_33 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(43, 0x00).id);
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr2 = F44_646(RTCW(loc1), arg1, arg2);
	Result = F784_5448(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {PO_FILE}.to_string */
EIF_REFERENCE F65_893 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1041, 0x01).id, 1041, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1033_8090(RTCW(Result));
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = F188_2383(RTCW(tr1));
	F1042_8503(RTCW(Result), tr1);
	tr1 = F1033_8149(RTMS_EX_H("\012",1,10));
	F1042_8501(RTCW(Result), tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F784_5479(RTCW(tr1));
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tb1 = F784_5474(RTCW(tr1));
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = F784_5452(RTCW(tr1));
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2283[Dtype(RTCW(tr1))-185])(tr1);
		F1042_8503(RTCW(Result), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F784_5480(RTCW(tr1));
	}
	RTLE;
	return Result;
}

void EIF_Minit44 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
