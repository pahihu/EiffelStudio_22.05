/*
 * Code for class CODE_PAGE_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co36.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CODE_PAGE_CONSTANTS}.utf7 */

EIF_REFERENCE F45_647 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (647,RTMS_EX_H("UTF-7",5,1414538039));
}

/* {CODE_PAGE_CONSTANTS}.utf8 */

EIF_REFERENCE F45_648 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (648,RTMS_EX_H("UTF-8",5,1414538040));
}

/* {CODE_PAGE_CONSTANTS}.utf16 */

EIF_REFERENCE F45_649 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (649,RTMS_EX_H("UTF-16",6,1345128758));
}

/* {CODE_PAGE_CONSTANTS}.utf32 */

EIF_REFERENCE F45_650 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (650,RTMS_EX_H("UTF-32",6,1345129266));
}

/* {CODE_PAGE_CONSTANTS}.utf16_le */

EIF_REFERENCE F45_651 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (651,RTMS_EX_H("UTF-16LE",8,312185413));
}

/* {CODE_PAGE_CONSTANTS}.utf32_le */

EIF_REFERENCE F45_652 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (652,RTMS_EX_H("UTF-32LE",8,345477701));
}

/* {CODE_PAGE_CONSTANTS}.utf16_be */

EIF_REFERENCE F45_653 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (653,RTMS_EX_H("UTF-16BE",8,312182853));
}

/* {CODE_PAGE_CONSTANTS}.utf32_be */

EIF_REFERENCE F45_654 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (654,RTMS_EX_H("UTF-32BE",8,345475141));
}

void EIF_Minit36 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
