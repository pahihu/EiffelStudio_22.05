
#ifndef _C1_po35_
#define _C1_po35_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F43_646(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit35(void);
extern EIF_REFERENCE F1042_8520(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1033_8149(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
