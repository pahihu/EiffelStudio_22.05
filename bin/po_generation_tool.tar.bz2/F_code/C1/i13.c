/*
 * Code for class I18N_FORMATTING_UTILITY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i13.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_FORMATTING_UTILITY}.pad_with_0_left */
EIF_REFERENCE F3_37 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	return (EIF_REFERENCE) F3_41(Current, arg1, arg2, (EIF_CHARACTER_8) '0');
}

/* {I18N_FORMATTING_UTILITY}.pad_left */
EIF_REFERENCE F3_41 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_CHARACTER_8 arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Result);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1041, 0x01).id, 1041, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = eif_out__i4_s1(arg1);
	F1042_8462(RTCW(Result), tr1);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN) (ti4_1 < arg2)) {
		loc1 = RTLNS(eif_new_type(1041, 0x01).id, 1041, _OBJSIZ_1_1_0_3_0_0_0_0_);
		tw1 = (EIF_CHARACTER_32) arg3;
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
		F1040_8387(RTCW(loc1), tw1, (EIF_INTEGER_32) (arg2 - ti4_1));
		F1042_8493(RTCW(Result), loc1);
	}
	RTLE;
	return Result;
}

void EIF_Minit3 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
