
#ifndef _C1_i110_
#define _C1_i110_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F10_170(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit10(void);
extern void F113_1470(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
