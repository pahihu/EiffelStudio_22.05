
#ifndef _C1_kl12_
#define _C1_kl12_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F12_176(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit12(void);

#ifdef __cplusplus
}
#endif

#endif
