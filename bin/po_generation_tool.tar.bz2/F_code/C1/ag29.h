
#ifndef _C1_ag29_
#define _C1_ag29_

#ifdef __cplusplus
extern "C" {
#endif

extern void F32_479(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit29(void);

#ifdef __cplusplus
}
#endif

#endif
