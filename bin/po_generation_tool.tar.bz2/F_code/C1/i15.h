
#ifndef _C1_i15_
#define _C1_i15_

#ifdef __cplusplus
extern "C" {
#endif

extern void F5_49(EIF_REFERENCE, EIF_REFERENCE);
extern void F5_50(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit5(void);

#ifdef __cplusplus
}
#endif

#endif
