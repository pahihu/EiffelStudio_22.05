/*
 * Code for class KL_STANDARD_FILES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl13.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_STANDARD_FILES}.error */
static EIF_REFERENCE F13_182_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (182);
#define Result RTOSR(182)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(831, 0x01).id, 831, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (182);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F13_182 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(182,F13_182_body,(Current));
}

void EIF_Minit13 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
