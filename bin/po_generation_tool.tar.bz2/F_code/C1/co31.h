
#ifndef _C1_co31_
#define _C1_co31_

#ifdef __cplusplus
extern "C" {
#endif

extern void F35_492(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit31(void);

#ifdef __cplusplus
}
#endif

#endif
