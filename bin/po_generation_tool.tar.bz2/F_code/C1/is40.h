
#ifndef _C1_is40_
#define _C1_is40_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F49_682(EIF_REFERENCE, EIF_BOOLEAN);
extern EIF_BOOLEAN F49_687(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F49_689(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F49_697(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit40(void);

#ifdef __cplusplus
}
#endif

#endif
