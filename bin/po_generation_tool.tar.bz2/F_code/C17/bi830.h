
#ifndef _C17_bi830_
#define _C17_bi830_

#ifdef __cplusplus
extern "C" {
#endif

extern void F509_5016(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit830(void);
extern void F497_4999(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F618_5084(EIF_REFERENCE);
extern char *(*R4068[])();
extern char *(*R4069[])();

#ifdef __cplusplus
}
#endif

#endif
