
#ifndef _C17_co835_
#define _C17_co835_

#ifdef __cplusplus
extern "C" {
#endif

extern void F474_4986(EIF_REFERENCE);
extern EIF_INTEGER_32 F474_4989(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit835(void);
extern char *(*R4123[])();
extern char *(*R4124[])();
extern char *(*R4109[])();
extern long O4047[];
extern EIF_TYPE_INDEX Y3949[];
extern EIF_TYPE_INDEX *Y3949_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
