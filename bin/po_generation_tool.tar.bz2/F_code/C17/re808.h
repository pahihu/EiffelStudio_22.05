
#ifndef _C17_re808_
#define _C17_re808_

#ifdef __cplusplus
extern "C" {
#endif

extern void F400_4869(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F400_4871(EIF_REFERENCE);
extern EIF_INTEGER_32 F400_4872(EIF_REFERENCE);
extern EIF_INTEGER_32 F400_4873(EIF_REFERENCE);
extern EIF_INTEGER_32 F400_4874(EIF_REFERENCE);
extern EIF_REFERENCE F400_4875(EIF_REFERENCE);
extern EIF_BOOLEAN F400_4881(EIF_REFERENCE);
extern EIF_BOOLEAN F400_4882(EIF_REFERENCE);
extern EIF_BOOLEAN F400_4883(EIF_REFERENCE);
extern void F400_4888(EIF_REFERENCE);
extern void F400_4889(EIF_REFERENCE);
extern EIF_REFERENCE F400_4890(EIF_REFERENCE);
extern void EIF_Minit808(void);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern char *(*R4123[])();
extern char *(*R4124[])();
extern char *(*R4126[])();
extern char *(*R3991[])();
extern long O4000[];
extern long O4001[];
extern long O4002[];
extern long O4003[];
extern long O3995[];
extern long O3999[];

#ifdef __cplusplus
}
#endif

#endif
