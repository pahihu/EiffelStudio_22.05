
#ifndef _C17_ch828_
#define _C17_ch828_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F727_5221(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F727_5223(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F727_5226(EIF_REFERENCE);
extern EIF_BOOLEAN F727_5231(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F727_5233(EIF_REFERENCE);
extern EIF_BOOLEAN F727_5234(EIF_REFERENCE);
extern void F727_5238(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit828(void);
extern EIF_BOOLEAN F497_4997(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F497_5003(EIF_REFERENCE);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern EIF_BOOLEAN F618_5084(EIF_REFERENCE);
extern char *(*R4095[])();
extern char *(*R4097[])();
extern char *(*R4055[])();
extern char *(*R4062[])();
extern char *(*R4067[])();
extern char *(*R4068[])();
extern char *(*R4188[])();
extern char *(*R4109[])();
extern char *(*R4075[])();
extern char *(*R4089[])();

#ifdef __cplusplus
}
#endif

#endif
