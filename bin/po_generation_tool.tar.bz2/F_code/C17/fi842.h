
#ifndef _C17_fi842_
#define _C17_fi842_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F619_5084(EIF_REFERENCE);
extern void EIF_Minit842(void);
extern char *(*R4109[])();

#ifdef __cplusplus
}
#endif

#endif
