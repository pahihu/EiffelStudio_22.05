
#ifndef _C17_ar825_
#define _C17_ar825_

#ifdef __cplusplus
extern "C" {
#endif

extern void F435_4935(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F435_4936(EIF_REFERENCE);
extern EIF_REFERENCE F435_4937(EIF_REFERENCE);
extern EIF_REFERENCE F435_4939(EIF_REFERENCE);
extern EIF_INTEGER_32 F435_4940(EIF_REFERENCE);
extern void EIF_Minit825(void);
extern EIF_INTEGER_32 F797_5594(EIF_REFERENCE);
extern EIF_REFERENCE F797_5575(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y3933[];
extern EIF_TYPE_INDEX *Y3933_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
