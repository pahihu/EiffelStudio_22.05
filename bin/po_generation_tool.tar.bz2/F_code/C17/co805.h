
#ifndef _C17_co805_
#define _C17_co805_

#ifdef __cplusplus
extern "C" {
#endif

extern void F473_4986(EIF_REFERENCE);
extern EIF_INTEGER_32 F473_4989(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit805(void);
extern char *(*R4123[])();
extern char *(*R4124[])();
extern char *(*R4109[])();
extern long O4047[];
extern EIF_TYPE_INDEX Y3949[];
extern EIF_TYPE_INDEX *Y3949_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
