
#ifndef _C17_ar824_
#define _C17_ar824_

#ifdef __cplusplus
extern "C" {
#endif

extern void F448_4947(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F448_4948(EIF_REFERENCE);
extern EIF_REFERENCE F448_4949(EIF_REFERENCE);
extern EIF_REFERENCE F448_4951(EIF_REFERENCE);
extern EIF_INTEGER_32 F448_4952(EIF_REFERENCE);
extern void EIF_Minit824(void);
extern EIF_TYPE_INDEX Y3933[];
extern EIF_TYPE_INDEX *Y3933_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
