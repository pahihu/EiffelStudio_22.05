
#ifndef _C17_ge819_
#define _C17_ge819_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F422_4909(EIF_REFERENCE);
extern EIF_INTEGER_32 F422_4911(EIF_REFERENCE);
extern EIF_BOOLEAN F422_4918(EIF_REFERENCE);
extern EIF_BOOLEAN F422_4922(EIF_REFERENCE);
extern void F422_4923(EIF_REFERENCE);
extern void F422_4924(EIF_REFERENCE);
extern EIF_REFERENCE F422_4925(EIF_REFERENCE);
extern void EIF_Minit819(void);
extern char *(*R4007[])();
extern char *(*R3980[])();
extern long O4006[];
extern long O4008[];

#ifdef __cplusplus
}
#endif

#endif
