
#ifndef _C17_ty841_
#define _C17_ty841_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_8 F389_4863(EIF_REFERENCE);
extern void EIF_Minit841(void);
extern char *(*R4122[])();
extern char *(*R3979[])();
extern char *(*R3992[])();

#ifdef __cplusplus
}
#endif

#endif
