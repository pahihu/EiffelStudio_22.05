
#ifndef _C17_re836_
#define _C17_re836_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F686_5115(EIF_REFERENCE);
extern void EIF_Minit836(void);
extern void F401_4869(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R3991[])();
extern EIF_TYPE_INDEX Y3949[];
extern EIF_TYPE_INDEX *Y3949_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
