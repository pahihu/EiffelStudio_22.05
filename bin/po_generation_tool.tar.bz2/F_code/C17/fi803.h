
#ifndef _C17_fi803_
#define _C17_fi803_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F618_5084(EIF_REFERENCE);
extern void EIF_Minit803(void);
extern char *(*R4109[])();

#ifdef __cplusplus
}
#endif

#endif
