
#ifndef _C17_sp818_
#define _C17_sp818_

#ifdef __cplusplus
extern "C" {
#endif

extern void F460_4953(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F460_4954(EIF_REFERENCE);
extern EIF_REFERENCE F460_4955(EIF_REFERENCE);
extern EIF_INTEGER_32 F460_4956(EIF_REFERENCE);
extern void EIF_Minit818(void);
extern EIF_INTEGER_32 F843_6407(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y3933[];
extern EIF_TYPE_INDEX *Y3933_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
