
#ifndef _C17_to816_
#define _C17_to816_

#ifdef __cplusplus
extern "C" {
#endif

extern void F296_4091(EIF_REFERENCE, EIF_INTEGER_32);
extern void F296_4092(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F296_4098(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit816(void);
extern void F843_6396(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y3324[];
extern EIF_TYPE_INDEX *Y3324_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
