
#ifndef _C17_li810_
#define _C17_li810_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F497_4997(EIF_REFERENCE, EIF_INTEGER_32);
extern void F497_4999(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F497_5003(EIF_REFERENCE);
extern EIF_BOOLEAN F497_5005(EIF_REFERENCE);
extern void EIF_Minit810(void);
extern char *(*R4053[])();
extern char *(*R4054[])();
extern char *(*R4055[])();
extern char *(*R4061[])();
extern char *(*R4066[])();
extern char *(*R4068[])();
extern char *(*R4045[])();
extern long O4047[];

#ifdef __cplusplus
}
#endif

#endif
