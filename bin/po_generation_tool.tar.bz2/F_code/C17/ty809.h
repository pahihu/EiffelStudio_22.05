
#ifndef _C17_ty809_
#define _C17_ty809_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F388_4863(EIF_REFERENCE);
extern void EIF_Minit809(void);
extern char *(*R4122[])();
extern char *(*R3979[])();
extern char *(*R3992[])();

#ifdef __cplusplus
}
#endif

#endif
