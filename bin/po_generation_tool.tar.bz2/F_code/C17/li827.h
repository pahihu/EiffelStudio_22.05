
#ifndef _C17_li827_
#define _C17_li827_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F751_5257(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F751_5258(EIF_REFERENCE);
extern EIF_BOOLEAN F751_5259(EIF_REFERENCE);
extern void EIF_Minit827(void);
extern EIF_BOOLEAN F618_5084(EIF_REFERENCE);
extern char *(*R4095[])();
extern char *(*R4097[])();
extern char *(*R4055[])();
extern char *(*R4062[])();
extern char *(*R4066[])();
extern char *(*R4068[])();
extern char *(*R4109[])();
extern char *(*R4089[])();
extern long O4047[];

#ifdef __cplusplus
}
#endif

#endif
