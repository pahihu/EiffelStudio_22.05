/*
 * Code for class ITERATION_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "it476.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ITERATION_AS}.make_keyword */
void F1145_12171 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_BOOLEAN arg5)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,arg3);
	RTLR(3,arg2);
	RTLR(4,arg4);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9961[Dtype(arg1)-1210]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_1_0_0_) = (EIF_INTEGER_32) ti4_1;
	}
	if ((EIF_BOOLEAN)(arg3 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg3) + O9961[Dtype(arg3)-1210]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_1_0_1_) = (EIF_INTEGER_32) ti4_1;
	}
	F1145_12173(Current, arg2, arg4, arg5);
	RTLE;
}

/* {ITERATION_AS}.make_symbolic */
void F1145_12172 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,arg4);
	RTLR(3,arg3);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2) + O9961[Dtype(arg2)-1210]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_1_0_1_) = (EIF_INTEGER_32) ti4_1;
	}
	if ((EIF_BOOLEAN)(arg4 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg4) + O9961[Dtype(arg4)-1210]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_1_0_0_) = (EIF_INTEGER_32) ti4_1;
	}
	F1145_12173(Current, arg3, arg1, (EIF_BOOLEAN) 1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {ITERATION_AS}.make */
void F1145_12173 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLIU(7);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg2;
	tr1 = RTLNS(eif_new_type(1220, 0x01).id, 1220, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(1162, 0x01).id, 1162, _OBJSIZ_2_0_0_1_0_0_0_0_);
	tr3 = RTLNS(eif_new_type(1238, 0x01).id, 1238, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr4 = RTLNS(eif_new_type(1167, 0x01).id, 1167, _OBJSIZ_3_1_0_3_0_0_0_0_);
	F1168_12431(RTCW(tr4), arg2);
	F1239_13189(RTCW(tr3), tr4);
	tr4 = RTMS_EX_H("start",5,1953426548);
	tr4 = F1145_12174(Current, tr4, arg2);
	F1163_12380(RTCW(tr2), tr3, tr4, NULL);
	F1221_12993(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNS(eif_new_type(1238, 0x01).id, 1238, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(1162, 0x01).id, 1162, _OBJSIZ_2_0_0_1_0_0_0_0_);
	tr3 = RTLNS(eif_new_type(1238, 0x01).id, 1238, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr4 = RTLNS(eif_new_type(1167, 0x01).id, 1167, _OBJSIZ_3_1_0_3_0_0_0_0_);
	F1168_12431(RTCW(tr4), arg2);
	F1239_13189(RTCW(tr3), tr4);
	tr4 = RTMS_EX_H("after",5,1719649138);
	tr4 = F1145_12174(Current, tr4, arg2);
	F1163_12380(RTCW(tr2), tr3, tr4, NULL);
	F1239_13189(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNS(eif_new_type(1220, 0x01).id, 1220, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr2 = RTLNS(eif_new_type(1162, 0x01).id, 1162, _OBJSIZ_2_0_0_1_0_0_0_0_);
	tr3 = RTLNS(eif_new_type(1238, 0x01).id, 1238, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr4 = RTLNS(eif_new_type(1167, 0x01).id, 1167, _OBJSIZ_3_1_0_3_0_0_0_0_);
	F1168_12431(RTCW(tr4), arg2);
	F1239_13189(RTCW(tr3), tr4);
	tr4 = RTMS_EX_H("forth",5,1870555240);
	tr4 = F1145_12174(Current, tr4, arg2);
	F1163_12380(RTCW(tr2), tr3, tr4, NULL);
	F1221_12993(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	if (arg3) {
		tr1 = RTLNS(eif_new_type(1238, 0x01).id, 1238, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTLNS(eif_new_type(1162, 0x01).id, 1162, _OBJSIZ_2_0_0_1_0_0_0_0_);
		tr3 = RTLNS(eif_new_type(1238, 0x01).id, 1238, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr4 = RTLNS(eif_new_type(1167, 0x01).id, 1167, _OBJSIZ_3_1_0_3_0_0_0_0_);
		F1168_12431(RTCW(tr4), arg2);
		F1239_13189(RTCW(tr3), tr4);
		tr4 = RTMS_EX_H("item",4,1769235821);
		tr4 = F1145_12174(Current, tr4, arg2);
		F1163_12380(RTCW(tr2), tr3, tr4, NULL);
		F1239_13189(RTCW(tr1), tr2);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {ITERATION_AS}.create_access_feat_as */
EIF_REFERENCE F1145_12174 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = F1_14(arg2);
	F1275_13558(RTCW(loc1), arg1);
	tr1 = RTLNS(eif_new_type(1164, 0x01).id, 1164, _OBJSIZ_3_1_0_2_0_0_0_0_);
	F1165_12394(RTCW(tr1), loc1, NULL);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {ITERATION_AS}.process */
void F1145_12175 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2622[Dtype(RTCW(arg1))-211])(arg1, Current);
}

/* {ITERATION_AS}.across_keyword */
EIF_REFERENCE F1145_12179 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_1_0_0_);
	tb1 = F320_4356(RTCW(arg1), loc1);
	if (tb1) {
		tr1 = RTLNTY2(eif_new_type(1215, 0x01), 0x01);
		tr2 = F320_4351(RTCW(arg1), loc1);
		Result = F921_6841(tr1, tr2);
	}
	RTLE;
	return Result;
}

/* {ITERATION_AS}.bar_symbol */
EIF_REFERENCE F1145_12180 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_1_0_0_);
	tb1 = F320_4356(RTCW(arg1), loc1);
	if (tb1) {
		tr1 = RTLNTY2(eif_new_type(1212, 0x01), 0x01);
		tr2 = F320_4351(RTCW(arg1), loc1);
		Result = F921_6841(tr1, tr2);
	}
	RTLE;
	return Result;
}

/* {ITERATION_AS}.as_keyword */
EIF_REFERENCE F1145_12181 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_1_0_1_);
	tb1 = F320_4356(RTCW(arg1), loc1);
	if (tb1) {
		tr1 = RTLNTY2(eif_new_type(1215, 0x01), 0x01);
		tr2 = F320_4351(RTCW(arg1), loc1);
		Result = F921_6841(tr1, tr2);
	}
	RTLE;
	return Result;
}

/* {ITERATION_AS}.in_symbol */
EIF_REFERENCE F1145_12182 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_1_0_1_);
	tb1 = F320_4356(RTCW(arg1), loc1);
	if (tb1) {
		tr1 = RTLNTY2(eif_new_type(1212, 0x01), 0x01);
		tr2 = F320_4351(RTCW(arg1), loc1);
		Result = F921_6841(tr1, tr2);
	}
	RTLE;
	return Result;
}

/* {ITERATION_AS}.first_token */
EIF_REFERENCE F1145_12191 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_0_)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = F1211_12834(RTCW(tr1), arg1);
	} else {
		if ((EIF_BOOLEAN)(arg1 != NULL)) {
			Result = F1145_12179(Current, arg1);
		}
		if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current);
			Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9356[Dtype(RTCW(tr1))-1128])(tr1, arg1);
		}
	}
	RTLE;
	return Result;
}

/* {ITERATION_AS}.last_token */
EIF_REFERENCE F1145_12192 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_0_)) {
		if ((EIF_BOOLEAN)(arg1 != NULL)) {
			Result = F1145_12180(Current, arg1);
		}
		if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current);
			Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9357[Dtype(RTCW(tr1))-1128])(tr1, arg1);
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = F1211_12835(RTCW(tr1), arg1);
	}
	RTLE;
	return Result;
}

void EIF_Minit476 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
