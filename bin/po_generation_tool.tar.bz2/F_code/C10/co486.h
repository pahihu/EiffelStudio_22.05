
#ifndef _C10_co486_
#define _C10_co486_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1155_12276(EIF_REFERENCE);
extern void EIF_Minit486(void);

#ifdef __cplusplus
}
#endif

#endif
