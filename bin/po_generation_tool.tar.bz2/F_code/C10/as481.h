
#ifndef _C10_as481_
#define _C10_as481_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1150_12240(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit481(void);
extern EIF_REFERENCE F305_4099(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
