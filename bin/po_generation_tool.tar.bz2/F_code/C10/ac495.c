/*
 * Code for class ACCESS_INV_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ac495.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ACCESS_INV_AS}.make */
void F1166_12425 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	F1165_12394(Current, arg1, arg2);
	if ((EIF_BOOLEAN)(arg3 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg3) + O9961[Dtype(arg3)-1210]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_2_) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

/* {ACCESS_INV_AS}.process */
void F1166_12427 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2568[Dtype(RTCW(arg1))-211])(arg1, Current);
}

/* {ACCESS_INV_AS}.dot_symbol */
EIF_REFERENCE F1166_12429 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11915(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_2_));
}

void EIF_Minit495 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
