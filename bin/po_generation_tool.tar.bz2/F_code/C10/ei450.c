/*
 * Code for class EIFFEL_ENV
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ei450.h"
#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F1119_9758
static int inline_F1119_9758 (void)
{
	return (int) (EIF_IS_WORKBENCH)
	;
}
#define INLINE_F1119_9758
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EIFFEL_ENV}.unix_product_version_name */
static EIF_REFERENCE F1119_9741_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOSP (9741);
#define Result RTOSR(9741)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1037, 0x01).id, 1037, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr2 = RTMS_EX_H("eiffelstudio",12,1924259951);
	tr3 = RTOSCF(9750,F1119_9750, (Current));
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R6223[Dtype(tr2)-1036])(tr2, tr3);
	F1036_8222(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (9741);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1119_9741 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9741,F1119_9741_body,(Current));
}

/* {EIFFEL_ENV}.version_name */
static EIF_REFERENCE F1119_9744_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (9744);
#define Result RTOSR(9744)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1037, 0x01).id, 1037, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1036_8220(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(1159,F92_1159, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6259[Dtype(RTCW(Result))-1037])(Result, tr1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R6261[Dtype(RTCW(Result))-1037])(Result, (EIF_CHARACTER_8) '.');
	tr1 = RTOSCF(1160,F92_1160, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6259[Dtype(RTCW(Result))-1037])(Result, tr1);
	RTOSE (9744);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1119_9744 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9744,F1119_9744_body,(Current));
}

/* {EIFFEL_ENV}.release_suffix */
static EIF_REFERENCE F1119_9750_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (9750);
#define Result RTOSR(9750)
	RTOC_NEW(Result);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_0_2_)) {
		tr1 = RTMS_EX_H("-",1,45);
		tr2 = RTOSCF(9744,F1119_9744, (Current));
		Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R6223[Dtype(tr1)-1036])(tr1, tr2);
	} else {
		Result = RTMS_EX_H("",0,0);
	}
	RTOSE (9750);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1119_9750 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9750,F1119_9750_body,(Current));
}

/* {EIFFEL_ENV}.is_workbench */
EIF_BOOLEAN F1119_9758 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = EIF_TEST(inline_F1119_9758 ());
	return Result;
}

/* {EIFFEL_ENV}.environment */
static EIF_REFERENCE F1119_9762_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (9762);
#define Result RTOSR(9762)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(311, 0x01).id, 311, _OBJSIZ_0_0_0_1_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (9762);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1119_9762 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9762,F1119_9762_body,(Current));
}

/* {EIFFEL_ENV}.language_path */
static EIF_REFERENCE F1119_9785_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (9785);
#define Result RTOSR(9785)
	RTOC_NEW(Result);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_0_2_)) {
		tr1 = RTOSCF(9849,F1119_9849, (Current));
		tr2 = RTOSCF(9741,F1119_9741, (Current));
		Result = F920_6794(RTCW(tr1), tr2);
	} else {
		tr1 = RTOSCF(9824,F1119_9824, (Current));
		tr2 = RTOSCF(9887,F1119_9887, (Current));
		tr1 = F920_6794(RTCW(tr1), tr2);
		tr2 = RTOSCF(9890,F1119_9890, (Current));
		Result = F920_6794(RTCW(tr1), tr2);
	}
	RTOSE (9785);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1119_9785 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9785,F1119_9785_body,(Current));
}

/* {EIFFEL_ENV}.shared_path */
static EIF_REFERENCE F1119_9823_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	struct eif_ex_41 sloc2;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) sloc2.data;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	

	memset (&sloc2.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc2.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc2.overhead, eif_new_type(63, 0x00).id);
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTEV;
	RTGC;
	RTOSP (9823);
#define Result RTOSR(9823)
	RTOC_NEW(Result);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_0_2_)) {
		tr1 = RTOSCF(9847,F1119_9847, (Current));
		tr2 = RTOSCF(9741,F1119_9741, (Current));
		Result = F920_6794(RTCW(tr1), tr2);
	} else {
		Result = F1119_9857(Current);
	}
	if (EIF_TEST (inline_F1119_9758())) {
		tr1 = RTMS_EX_H("_",1,95);
		tr1 = F920_6796(RTCW(Result), tr1);
		tr2 = RTOSCF(9870,F1119_9870, (Current));
		loc1 = F920_6796(RTCW(tr1), tr2);
		tb1 = F64_876(RTCW(loc2), loc1);
		if (tb1) {
			Result = (EIF_REFERENCE) loc1;
		}
	}
	RTOSE (9823);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1119_9823 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9823,F1119_9823_body,(Current));
}

/* {EIFFEL_ENV}.shared_application_path */
static EIF_REFERENCE F1119_9824_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (9824);
#define Result RTOSR(9824)
	RTOC_NEW(Result);
	tr1 = RTOSCF(9823,F1119_9823, (Current));
	tr2 = RTOSCF(9871,F1119_9871, (Current));
	Result = F920_6794(RTCW(tr1), tr2);
	RTOSE (9824);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1119_9824 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9824,F1119_9824_body,(Current));
}

/* {EIFFEL_ENV}.unix_layout_base_path */
static EIF_REFERENCE F1119_9846_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (9846);
#define Result RTOSR(9846)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(919, 0x01).id, 919, _OBJSIZ_2_1_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("/usr",4,796226418);
	F920_6767(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (9846);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1119_9846 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9846,F1119_9846_body,(Current));
}

/* {EIFFEL_ENV}.unix_layout_share_path */
static EIF_REFERENCE F1119_9847_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (9847);
#define Result RTOSR(9847)
	RTOC_NEW(Result);
	tr1 = RTOSCF(9846,F1119_9846, (Current));
	tr2 = RTMS_EX_H("share",5,1752099941);
	Result = F920_6794(RTCW(tr1), tr2);
	RTOSE (9847);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1119_9847 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9847,F1119_9847_body,(Current));
}

/* {EIFFEL_ENV}.unix_layout_locale_path */
static EIF_REFERENCE F1119_9849_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (9849);
#define Result RTOSR(9849)
	RTOC_NEW(Result);
	tr1 = RTOSCF(9847,F1119_9847, (Current));
	tr2 = RTMS_EX_H("locale",6,1880518245);
	Result = F920_6794(RTCW(tr1), tr2);
	RTOSE (9849);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1119_9849 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9849,F1119_9849_body,(Current));
}

/* {EIFFEL_ENV}.get_environment_32 */
EIF_REFERENCE F1119_9852 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = RTOSCF(9762,F1119_9762, (Current));
	tr2 = RTOSCF(9916,F1120_9916, (Current));
	tr3 = RTOSCF(9744,F1119_9744, (Current));
	Result = F312_4223(RTCW(tr1), arg1, tr2, tr3);
	RTLE;
	return Result;
}

/* {EIFFEL_ENV}.eiffel_install */
EIF_REFERENCE F1119_9857 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(1141,F92_1141, (Current));
	tr1 = F1119_9852(Current, tr1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1119_9904(Current, loc1);
		tr1 = RTLNS(eif_new_type(919, 0x01).id, 919, _OBJSIZ_2_1_0_0_0_0_0_0_);
		F920_6767(RTCW(tr1), loc1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		Result = RTLNS(eif_new_type(919, 0x01).id, 919, _OBJSIZ_2_1_0_0_0_0_0_0_);
		tr1 = RTMS_EX_H(".",1,46);
		F920_6767(RTCW(Result), tr1);
	}
	RTLE;
	return Result;
}

/* {EIFFEL_ENV}.wkbench_suffix */

EIF_REFERENCE F1119_9870 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (9870,RTMS_EX_H("workbench",9,1911020904));
}

/* {EIFFEL_ENV}.distribution_name */
static EIF_REFERENCE F1119_9871_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (9871);
#define Result RTOSR(9871)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("studio",6,49025135);
	RTOSE (9871);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1119_9871 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9871,F1119_9871_body,(Current));
}

/* {EIFFEL_ENV}.lang_name */

EIF_REFERENCE F1119_9887 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (9887,RTMS_EX_H("lang",4,1818324583));
}

/* {EIFFEL_ENV}.mo_files_name */

EIF_REFERENCE F1119_9890 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (9890,RTMS_EX_H("mo_files",8,2015040371));
}

/* {EIFFEL_ENV}.remove_trailing_dir_separator */
void F1119_9904 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc2 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6088[Dtype(RTCW(arg1))-1036])(arg1);
	if ((EIF_BOOLEAN) !tb1) {
		loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6110[Dtype(RTCW(arg1))-1036])(arg1);
		tc1 = RTOSCF(2008,F146_2008, (RTCV(RTOSCF(28,F1_28, (Current)))));
		loc2 = (EIF_NATURAL_32) tc1;
		tb1 = '\0';
		tb2 = '\0';
		tb3 = '\0';
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 1L))) {
			tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6073[Dtype(RTCW(arg1))-1036])(arg1, loc1);
			tb3 = (EIF_BOOLEAN)(tu4_1 == loc2);
		}
		if (tb3) {
			tb2 = (EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 2L));
		}
		if (tb2) {
			tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6073[Dtype(RTCW(arg1))-1036])(arg1, (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
			tb1 = (EIF_BOOLEAN)(tu4_1 != loc2);
		}
		if (tb1) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6189[Dtype(RTCW(arg1))-1037])(arg1, (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
		}
	}
	RTLE;
}

void EIF_Minit450 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
