
#ifndef _C10_ca490_
#define _C10_ca490_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1160_12366(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit490(void);
extern char *(*R2675[])();

#ifdef __cplusplus
}
#endif

#endif
