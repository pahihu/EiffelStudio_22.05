/*
 * Code for class EIFFEL_PARSER_SKELETON
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ei457.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EIFFEL_PARSER_SKELETON}.make_with_factory */
void F1126_10387 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,807,959,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F797_5571(RTCW(tr1), ((EIF_INTEGER_32) 20L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_75_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,807,959,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F797_5571(RTCW(tr1), ((EIF_INTEGER_32) 20L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_73_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,807,959,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F797_5571(RTCW(tr1), ((EIF_INTEGER_32) 20L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_74_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,806,1212,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F794_5571(RTCW(tr1), ((EIF_INTEGER_32) 20L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_71_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,806,0xFF01,0xFFF9,6,953,959,959,992,992,992,992,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F794_5571(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_63_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(26, 1).id);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_59_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,793,0xFF01,1197,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F794_5571(RTCW(tr1), ((EIF_INTEGER_32) 8L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_60_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,807,959,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F797_5571(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_62_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,806,0xFF01,0xFFF9,2,953,959,977,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F794_5571(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_61_) = (EIF_REFERENCE) tr1;
	F1122_9919(Current);
	F1124_10160(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_60_);
	F470_4986(RTCW(tr1));
	*(EIF_BOOLEAN *)(Current+ _CHROFF_351_25_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	F1126_10479(Current);
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.set_il_parser */
void F1126_10388 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_351_7_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EIFFEL_PARSER_SKELETON}.reset */
void F1126_10396 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1124_10161(Current);
	tr1 = RTLNSMART(eif_new_type(26, 1).id);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_59_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_63_);
	F794_5630(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_62_);
	F797_5630(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_61_);
	F794_5630(RTCW(tr1));
	*(EIF_BOOLEAN *)(Current+ _CHROFF_351_25_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_351_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_REFERENCE *)(Current + _REFACS_72_) = (EIF_REFERENCE) NULL;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_73_);
	F797_5630(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_74_);
	F797_5630(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_75_);
	F797_5630(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_71_);
	F794_5630(RTCW(tr1));
	*(EIF_REFERENCE *)(Current + _REFACS_43_) = (EIF_REFERENCE) NULL;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_351_14_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_351_15_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_351_19_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_351_20_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_351_21_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_351_16_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_351_17_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_351_18_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_REFERENCE *)(Current + _REFACS_68_) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + _REFACS_67_) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + _REFACS_69_) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + _REFACS_70_) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + _REFACS_66_) = (EIF_REFERENCE) NULL;
	F1126_10479(Current);
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.is_ignoring_variance_mark */
EIF_BOOLEAN F1126_10406 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_NATURAL_8 *)(Current+ _CHROFF_351_26_) != ((EIF_NATURAL_8) 3U));
}

/* {EIFFEL_PARSER_SKELETON}.is_type_inference_supported */
EIF_BOOLEAN F1126_10408 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EIFFEL_PARSER_SKELETON}.parse_class_from_string */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F1126_10412 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_INTEGER_32  EIF_VOLATILE ti4_1;
	RTLD;
	RTXD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,arg3);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,arg1);
	RTLR(5,arg2);
	RTLR(6,loc1);
	RTLR(7,saved_except);
	RTLIU(8);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	F1126_10444(Current);
	if ((EIF_BOOLEAN)(arg3 != NULL)) {
		tr1 = F325_4735(Current);
		loc2 = F1310_13879(RTCW(tr1), arg1, arg3);
		RTAR(Current, arg3);
		*(EIF_REFERENCE *)(Current + _REFACS_50_) = (EIF_REFERENCE) arg3;
		*(EIF_REFERENCE *)(Current + _REFACS_51_) = (EIF_REFERENCE) NULL;
	} else {
		tr1 = F325_4735(Current);
		loc2 = F1310_13880(RTCW(tr1), arg1, arg2);
		tr1 = *(EIF_REFERENCE *)(RTCV(F325_4735(Current)) + _REFACS_2_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_50_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(RTCV(F325_4735(Current)) + _REFACS_1_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_51_) = (EIF_REFERENCE) tr1;
	}
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		(RTNA((RTCW(arg2), *(EIF_REFERENCE *)(Current + _REFACS_50_), *(EIF_REFERENCE *)(Current + _REFACS_51_))));
	}
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTAR(Current, loc2);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc2;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
		F1067_8979(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_3_0_5_);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_3_) = (EIF_INTEGER_32) ti4_1;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_4_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_3_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_3_0_3_);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_5_) = (EIF_INTEGER_32) ti4_1;
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_3_0_4_);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_6_) = (EIF_INTEGER_32) ti4_1;
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_3_0_2_);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_7_) = (EIF_INTEGER_32) ti4_1;
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_42_);
		F324_4709(RTCW(loc1), ((EIF_INTEGER_32) 1000L));
		RTAR(Current, arg2);
		*(EIF_REFERENCE *)(Current + _REFACS_43_) = (EIF_REFERENCE) arg2;
		F1122_9920(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_40_) = (EIF_REFERENCE) tr1;
	} else {
		F1122_9925(Current);
	}
	F1126_10396(Current);
	RTE_E
	RTXSC;
	F1126_10396(Current);
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {EIFFEL_PARSER_SKELETON}.set_formal_generics_end_positions */
void F1126_10438 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (arg1) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_45_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_51_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_45_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_12_);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_51_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_40_);
	}
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.set_conforming_inheritance_end_positions */
void F1126_10439 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_46_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_12_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_52_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_40_);
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.set_non_conforming_inheritance_end_positions */
void F1126_10440 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_47_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_12_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_53_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_40_);
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.set_features_end_positions */
void F1126_10441 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_48_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_12_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_54_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_40_);
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.set_feature_clause_end_positions */
void F1126_10443 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_50_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_12_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_56_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_40_);
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.reset_nodes */
void F1126_10444 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_REFERENCE *)(Current + _REFACS_52_) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + _REFACS_53_) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + _REFACS_54_) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + _REFACS_56_) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + _REFACS_58_) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + _REFACS_72_) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + _REFACS_40_) = (EIF_REFERENCE) NULL;
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.clear_all */
void F1126_10446 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {EIFFEL_PARSER_SKELETON}.insert_supplier */
void F1126_10449 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_INTEGER_32 ti4_5;
	EIF_INTEGER_32 ti4_6;
	EIF_INTEGER_32 ti4_7;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		loc1 = RTLNS(eif_new_type(1274, 0x01).id, 1274, _OBJSIZ_0_0_3_5_0_0_0_0_);
		F1275_13556(RTCW(loc1), arg1);
		ti4_1 = F132_1883(RTCW(arg2));
		ti4_2 = F132_1884(RTCW(arg2));
		ti4_3 = *(EIF_INTEGER_32 *)(RTCW(arg2) + O1869[Dtype(arg2)-131]);
		ti4_4 = F132_1888(RTCW(arg2));
		ti4_5 = F132_1889(RTCW(arg2));
		ti4_6 = *(EIF_INTEGER_32 *)(RTCW(arg2) + O1874[Dtype(arg2)-131]);
		ti4_7 = F132_1892(RTCW(arg2));
		F132_1893(RTCW(loc1), ti4_1, ti4_2, ti4_3, ti4_4, ti4_5, ti4_6, ti4_7);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_59_);
		F27_276(RTCW(tr1), loc1);
	}
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.enter_scope */
void F1126_10458 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_62_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_61_);
	ti4_1 = F794_5592(RTCW(tr2));
	F808_5641(RTCW(tr1), ti4_1);
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.leave_scope */
void F1126_10459 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_62_);
	F808_5643(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_61_);
	loc1 = F794_5592(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_62_);
	tb1 = F618_5084(RTCW(tr1));
	if (tb1) {
		ti4_1 = ((EIF_INTEGER_32) 0L);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_62_);
		ti4_2 = F797_5576(RTCW(tr1));
		ti4_1 = ti4_2;
	}
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ti4_1);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 <= ((EIF_INTEGER_32) 0L))) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_61_);
		F807_5643(RTCW(tr1));
		loc1--;
	}
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.add_scope_arguments */
void F1126_10460 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	loc1 = F797_5585(RTCW(arg1));
	for (;;) {
		tb1 = F422_4918(loc1);
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_61_);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,953,959,977,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr2 = RTLNTS(typres0.id, 3, 1);
		}
		ti4_1 = F422_4909(loc1);
		((EIF_TYPED_VALUE *)tr2+1)->it_i4 = ti4_1;
		((EIF_TYPED_VALUE *)tr2+2)->it_n1 = ((EIF_NATURAL_8) 1U);
		F807_5641(RTCW(tr1), tr2);
		F422_4924(loc1);
	}
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.add_scope_locals */
void F1126_10461 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	loc1 = F797_5585(RTCW(arg1));
	for (;;) {
		tb1 = F422_4918(loc1);
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_61_);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,953,959,977,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr2 = RTLNTS(typres0.id, 3, 1);
		}
		ti4_1 = F422_4909(loc1);
		((EIF_TYPED_VALUE *)tr2+1)->it_i4 = ti4_1;
		((EIF_TYPED_VALUE *)tr2+2)->it_n1 = ((EIF_NATURAL_8) 2U);
		F807_5641(RTCW(tr1), tr2);
		F422_4924(loc1);
	}
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.add_scope_iteration */
void F1126_10462 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_61_);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,953,959,977,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr2 = RTLNTS(typres0.id, 3, 1);
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_3_4_);
		((EIF_TYPED_VALUE *)tr2+1)->it_i4 = ti4_1;
		((EIF_TYPED_VALUE *)tr2+2)->it_n1 = ((EIF_NATURAL_8) 4U);
		F807_5641(RTCW(tr1), tr2);
	}
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.add_scope_separate */
void F1126_10463 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_61_);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,953,959,977,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr2 = RTLNTS(typres0.id, 3, 1);
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_3_4_);
		((EIF_TYPED_VALUE *)tr2+1)->it_i4 = ti4_1;
		((EIF_TYPED_VALUE *)tr2+2)->it_n1 = ((EIF_NATURAL_8) 5U);
		F807_5641(RTCW(tr1), tr2);
	}
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.add_scope_test */
void F1126_10464 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_61_);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,953,959,977,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr2 = RTLNTS(typres0.id, 3, 1);
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_3_4_);
		((EIF_TYPED_VALUE *)tr2+1)->it_i4 = ti4_1;
		((EIF_TYPED_VALUE *)tr2+2)->it_n1 = ((EIF_NATURAL_8) 3U);
		F807_5641(RTCW(tr1), tr2);
	}
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.is_class_feature */
EIF_BOOLEAN F1126_10466 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_63_);
	tr1 = F794_5576(RTCW(tr1));
	Result = eif_boolean_item(RTCW(tr1),3);
	RTLE;
	return Result;
}

/* {EIFFEL_PARSER_SKELETON}.has_non_object_call */
EIF_BOOLEAN F1126_10467 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_63_);
	tr1 = F794_5576(RTCW(tr1));
	Result = eif_boolean_item(RTCW(tr1),4);
	RTLE;
	return Result;
}

/* {EIFFEL_PARSER_SKELETON}.has_non_object_call_in_assertion */
EIF_BOOLEAN F1126_10468 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_63_);
	tr1 = F794_5576(RTCW(tr1));
	Result = eif_boolean_item(RTCW(tr1),5);
	RTLE;
	return Result;
}

/* {EIFFEL_PARSER_SKELETON}.has_unqualified_call_in_assertion */
EIF_BOOLEAN F1126_10469 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_63_);
	tr1 = F794_5576(RTCW(tr1));
	Result = eif_boolean_item(RTCW(tr1),6);
	RTLE;
	return Result;
}

/* {EIFFEL_PARSER_SKELETON}.set_is_class_feature */
void F1126_10470 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_63_);
	tr1 = F794_5576(RTCW(tr1));
	
	eif_put_boolean_item(RTCW(tr1),3,arg1);
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.set_has_non_object_call */
void F1126_10471 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_63_);
	tr1 = F794_5576(RTCW(tr1));
	
	eif_put_boolean_item(RTCW(tr1),4,arg1);
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.set_has_non_object_call_in_assertion */
void F1126_10472 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_63_);
	tr1 = F794_5576(RTCW(tr1));
	
	eif_put_boolean_item(RTCW(tr1),5,arg1);
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.set_has_unqualified_call_in_assertion */
void F1126_10473 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_63_);
	tr1 = F794_5576(RTCW(tr1));
	
	eif_put_boolean_item(RTCW(tr1),6,arg1);
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.id_level */
EIF_INTEGER_32 F1126_10474 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_63_);
	tr1 = F794_5576(RTCW(tr1));
	Result = eif_integer_32_item(RTCW(tr1),1);
	RTLE;
	return Result;
}

/* {EIFFEL_PARSER_SKELETON}.set_id_level */
void F1126_10475 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_63_);
	tr1 = F794_5576(RTCW(tr1));
	
	eif_put_integer_32_item(RTCW(tr1),1,arg1);
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.fbody_pos */
EIF_INTEGER_32 F1126_10476 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_63_);
	tr1 = F794_5576(RTCW(tr1));
	Result = eif_integer_32_item(RTCW(tr1),2);
	RTLE;
	return Result;
}

/* {EIFFEL_PARSER_SKELETON}.set_fbody_pos */
void F1126_10477 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_63_);
	tr1 = F794_5576(RTCW(tr1));
	
	eif_put_integer_32_item(RTCW(tr1),2,arg1);
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.add_feature_frame */
void F1126_10479 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_63_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,6,953,959,959,992,992,992,992,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNTS(typres0.id, 7, 1);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_i4 = ((EIF_INTEGER_32) 0L);
	((EIF_TYPED_VALUE *)tr2+2)->it_i4 = ((EIF_INTEGER_32) 0L);
	((EIF_TYPED_VALUE *)tr2+3)->it_b = (EIF_BOOLEAN) 0;
	((EIF_TYPED_VALUE *)tr2+4)->it_b = (EIF_BOOLEAN) 0;
	((EIF_TYPED_VALUE *)tr2+5)->it_b = (EIF_BOOLEAN) 0;
	((EIF_TYPED_VALUE *)tr2+6)->it_b = (EIF_BOOLEAN) 0;
	F807_5642(RTCW(tr1), tr2);
	F1126_10506(Current);
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.remove_feature_frame */
void F1126_10480 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_63_);
	F807_5643(RTCW(tr1));
	F1126_10509(Current);
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.reset_feature_frame */
void F1126_10481 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_75_);
	F797_5615(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	F1126_10470(Current, (EIF_BOOLEAN) 0);
	F1126_10471(Current, (EIF_BOOLEAN) 0);
	F1126_10472(Current, (EIF_BOOLEAN) 0);
	F1126_10473(Current, (EIF_BOOLEAN) 0);
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.insert_object_test_locals */
void F1126_10500 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_72_);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {793,0xFF01,0xFFF9,2,953,0xFF01,1274,0xFF01,1191,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNSMART(typres0.id);
		}
		F794_5571(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_72_) = (EIF_REFERENCE) loc1;
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4075[Dtype(RTCW(loc1))-773])(loc1, arg1);
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.counter_value */
EIF_INTEGER_32 F1126_10501 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_73_);
	Result = F797_5576(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EIFFEL_PARSER_SKELETON}.counter2_value */
EIF_INTEGER_32 F1126_10502 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_74_);
	Result = F797_5576(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EIFFEL_PARSER_SKELETON}.once_manifest_string_counter_value */
EIF_INTEGER_32 F1126_10503 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_75_);
	Result = F797_5576(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EIFFEL_PARSER_SKELETON}.add_counter */
void F1126_10504 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_73_);
	F808_5642(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.add_counter2 */
void F1126_10505 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_74_);
	F808_5642(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.add_once_manifest_string_counter */
void F1126_10506 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_75_);
	F808_5642(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.remove_counter */
void F1126_10507 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_73_);
	F808_5643(RTCW(tr1));
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.remove_counter2 */
void F1126_10508 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_74_);
	F808_5643(RTCW(tr1));
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.remove_once_manifest_string_counter */
void F1126_10509 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_75_);
	F808_5643(RTCW(tr1));
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.increment_counter */
void F1126_10510 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_73_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_73_);
	ti4_1 = F797_5576(RTCW(tr2));
	F797_5615(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.increment_counter2 */
void F1126_10511 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_74_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_74_);
	ti4_1 = F797_5576(RTCW(tr2));
	F797_5615(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.increment_once_manifest_string_counter */
void F1126_10512 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_75_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_75_);
	ti4_1 = F797_5576(RTCW(tr2));
	F797_5615(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.new_class_description */
EIF_REFERENCE F1126_10516 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3, EIF_BOOLEAN arg4, EIF_BOOLEAN arg5, EIF_BOOLEAN arg6, EIF_BOOLEAN arg7, EIF_BOOLEAN arg8, EIF_REFERENCE arg9, EIF_REFERENCE arg10, EIF_REFERENCE arg11, EIF_REFERENCE arg12, EIF_REFERENCE arg13, EIF_REFERENCE arg14, EIF_REFERENCE arg15, EIF_REFERENCE arg16, EIF_REFERENCE arg17, EIF_REFERENCE arg18, EIF_REFERENCE arg19, EIF_REFERENCE arg20)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(20);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,arg13);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLR(6,arg12);
	RTLR(7,tr1);
	RTLR(8,arg1);
	RTLR(9,arg9);
	RTLR(10,arg10);
	RTLR(11,arg11);
	RTLR(12,arg14);
	RTLR(13,arg15);
	RTLR(14,arg16);
	RTLR(15,arg17);
	RTLR(16,arg18);
	RTLR(17,arg19);
	RTLR(18,arg20);
	RTLR(19,Result);
	RTLIU(20);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_351_7_)) {
			F1122_9929(Current);
		} else {
			loc1 = (EIF_REFERENCE) arg2;
		}
	}
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_351_24_) && (EIF_BOOLEAN)(arg13 == NULL))) {
		loc2 = (EIF_REFERENCE) NULL;
		loc3 = (EIF_REFERENCE) arg12;
	} else {
		loc2 = (EIF_REFERENCE) arg12;
		loc3 = (EIF_REFERENCE) arg13;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_42_);
	Result = F322_4537(RTCW(tr1), arg1, loc1, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, loc2, loc3, arg14, arg15, arg16, arg17, arg18, arg19, arg20);
	RTLE;
	return Result;
}

/* {EIFFEL_PARSER_SKELETON}.extract_keyword */
EIF_REFERENCE F1126_10517 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = eif_boxed_item(arg1,1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {EIFFEL_PARSER_SKELETON}.extract_id */
RTEOMS(10517,2);
EIF_REFERENCE F1126_10518 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLIU(7);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		Result = eif_boxed_item(arg1,2);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_NATURAL_8 *)(Current+ _CHROFF_351_26_) == ((EIF_NATURAL_8) 0U)) || (EIF_BOOLEAN)(*(EIF_NATURAL_8 *)(Current+ _CHROFF_351_26_) == ((EIF_NATURAL_8) 3U)))) {
			tr1 = RTLNS(eif_new_type(1110, 0x01).id, 1110, _OBJSIZ_6_0_0_2_0_0_0_0_);
			ti4_1 = eif_integer_32_item(RTCW(arg1),3);
			ti4_2 = eif_integer_32_item(RTCW(arg1),4);
			tr2 = eif_boxed_item(arg1,5);
			tr3 = F1089_9299(Current);
			tr4 = RTMS_EX_H("Using keyword as identifier.",28,699740462);
			tr3 = F21_215(RTCW(tr3), tr4, RTOMS(10517,0));
			F1111_9709(RTCW(tr1), ti4_1, ti4_2, tr2, tr3);
			F1126_10526(Current, tr1);
		} else {
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_351_4_)) {
				tr1 = RTLNS(eif_new_type(1106, 0x01).id, 1106, _OBJSIZ_6_0_0_2_0_0_0_0_);
				ti4_1 = eif_integer_32_item(RTCW(arg1),3);
				ti4_2 = eif_integer_32_item(RTCW(arg1),4);
				tr2 = eif_boxed_item(arg1,5);
				tr3 = F1089_9299(Current);
				tr4 = RTMS_EX_H("Using keyword as identifier.",28,699740462);
				tr3 = F21_215(RTCW(tr3), tr4, RTOMS(10517,1));
				F1107_9694(RTCW(tr1), ti4_1, ti4_2, tr2, tr3);
				F1124_10208(Current, tr1);
			}
		}
	}
	RTLE;
	return Result;
}

/* {EIFFEL_PARSER_SKELETON}.extract_symbol */
EIF_REFERENCE F1126_10519 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = eif_boxed_item(arg1,1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {EIFFEL_PARSER_SKELETON}.extract_id_from_symbol */
EIF_REFERENCE F1126_10520 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = eif_boxed_item(arg1,2);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {EIFFEL_PARSER_SKELETON}.check_object_test_expression */
RTEOMS(10520,1);
void F1126_10521 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLIU(6);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R10168[Dtype(RTCW(arg1))-1233])(arg1);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tr1 = RTLNS(eif_new_type(1110, 0x01).id, 1110, _OBJSIZ_6_0_0_2_0_0_0_0_);
		ti4_1 = F1124_10199(Current, arg1);
		ti4_2 = F1124_10200(Current, arg1);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
		tr3 = F1089_9299(Current);
		tr4 = RTMS_EX_H("Expression used in object test should be \"Detachable_expression\".",65,837799726);
		tr3 = F21_215(RTCW(tr3), tr4, RTOMS(10520,0));
		F1111_9709(RTCW(tr1), ti4_1, ti4_2, tr2, tr3);
		F1126_10526(Current, tr1);
	}
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.new_none_id */
EIF_REFERENCE F1126_10522 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_42_);
	Result = F322_4459(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_14_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_13_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_12_), ((EIF_INTEGER_32) 4L), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_39_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_40_), ((EIF_INTEGER_32) 4L));
	RTLE;
	return Result;
}

/* {EIFFEL_PARSER_SKELETON}.new_class_type */
EIF_REFERENCE F1126_10524 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,Result);
	RTLR(6,loc2);
	RTLR(7,loc3);
	RTLIU(8);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		loc1 = (EIF_REFERENCE) arg1;
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_0_0_3_4_);
		if ((EIF_BOOLEAN)(((EIF_INTEGER_32) 170L) == ti4_1)) {
			if ((EIF_BOOLEAN)(arg2 != NULL)) {
				F1126_10525(Current);
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_42_);
			Result = F322_4618(RTCW(tr1), arg1);
		} else {
			if ((EIF_BOOLEAN)(arg2 == NULL)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_60_);
				F794_5602(RTCW(tr1));
				for (;;) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_60_);
					tb1 = F748_5258(RTCW(tr1));
					if (tb1) break;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_60_);
					loc2 = F794_5576(RTCW(tr1));
					tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
					tb2 = F1275_13569(RTCW(loc1), tr1);
					if (tb2) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_42_);
						tb2 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_1_6_);
						tb3 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_1_7_);
						tb4 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_1_4_);
						loc3 = F322_4591(RTCW(tr1), arg1, tb2, tb3, tb4, NULL);
						if ((EIF_BOOLEAN)(loc3 != NULL)) {
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_8_0_6_);
							F1198_12675(RTCW(loc3), ti4_1);
						}
						Result = (EIF_REFERENCE) loc3;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_60_);
						F794_5603(RTCW(tr1));
					}
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_60_);
					F794_5604(RTCW(tr1));
				}
			}
			if ((EIF_BOOLEAN)(Result == NULL)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_42_);
				Result = F322_4538(RTCW(tr1), loc1, arg2);
				if (*(EIF_BOOLEAN *)(Current+ _CHROFF_351_25_)) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_59_);
					F27_276(RTCW(tr1), loc1);
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {EIFFEL_PARSER_SKELETON}.report_basic_generic_type_error */
void F1126_10525 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1111, 0x01).id, 1111, _OBJSIZ_6_0_0_2_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_14_);
	ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_13_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
	tr3 = F1033_8149(RTMS_EX_H("",0,0));
	F1111_9709(RTCW(tr1), ti4_1, ti4_2, tr2, tr3);
	F1126_10526(Current, tr1);
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.report_one_error */
void F1126_10526 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1124_10207(Current, arg1);
	F1122_9925(Current);
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.report_error */
void F1126_10527 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1110, 0x01).id, 1110, _OBJSIZ_6_0_0_2_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_14_);
	ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_13_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
	tr3 = F1033_8149(RTMS_EX_H("",0,0));
	F1111_9709(RTCW(tr1), ti4_1, ti4_2, tr2, tr3);
	F1126_10526(Current, tr1);
	RTLE;
}

/* {EIFFEL_PARSER_SKELETON}.report_deprecated_use_of_keyword_is */
RTEOMS(10527,2);
void F1126_10528 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_351_4_) && (EIF_BOOLEAN)(*(EIF_NATURAL_8 *)(Current+ _CHROFF_351_26_) != ((EIF_NATURAL_8) 1U)))) {
		if ((EIF_BOOLEAN)(arg1 != NULL)) {
			loc1 = F1124_10199(Current, arg1);
			loc2 = F1124_10200(Current, arg1);
		} else {
			loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_14_);
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_13_);
		}
		tr1 = RTLNS(eif_new_type(1106, 0x01).id, 1106, _OBJSIZ_6_0_0_2_0_0_0_0_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
		tr3 = F1089_9299(Current);
		tr3 = F21_215(RTCW(tr3), RTOMS(10527,0), RTOMS(10527,1));
		F1107_9694(RTCW(tr1), loc1, loc2, tr2, tr3);
		F1124_10208(Current, tr1);
	}
	RTLE;
}

void EIF_Minit457 (void)
{
	GTCX
	RTPOMS(10517,1,"parser.eiffel.warning",21,1798114407);
	RTPOMS(10517,0,"parser.eiffel.error",19,1396656242);
	RTPOMS(10520,0,"parser.eiffel.error",19,1396656242);
	RTPOMS(10527,1,"parser.eiffel.warning",21,1798114407);
	RTPOMS(10527,0,"Deprecated use of keyword `is`.",31,249071150);
}


#ifdef __cplusplus
}
#endif
