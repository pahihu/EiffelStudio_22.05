
#ifndef _C10_ac493_
#define _C10_ac493_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1164_12390(EIF_REFERENCE);
extern void EIF_Minit493(void);
extern EIF_REFERENCE F325_4735(EIF_REFERENCE);
extern EIF_REFERENCE F1072_9073(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R9681[])();

#ifdef __cplusplus
}
#endif

#endif
