/*
 * Code for class REQUIRE_ELSE_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "re485.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {REQUIRE_ELSE_AS}.make */
void F1154_12269 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	F1153_12261(Current, arg1, arg2);
	if ((EIF_BOOLEAN)(arg3 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg3) + O9961[Dtype(arg3)-1210]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_1_) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

/* {REQUIRE_ELSE_AS}.process */
void F1154_12270 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2605[Dtype(RTCW(arg1))-211])(arg1, Current);
}

/* {REQUIRE_ELSE_AS}.else_keyword */
EIF_REFERENCE F1154_12272 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11914(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_1_));
}

/* {REQUIRE_ELSE_AS}.last_token */
EIF_REFERENCE F1154_12274 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			tr1 = F1201_12710(loc1, arg1);
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			RTLE;
			return (EIF_REFERENCE) NULL;
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tr1 = F1201_12710(loc2, arg1);
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_1_) != ((EIF_INTEGER_32) 0L))) {
				RTLE;
				return (EIF_REFERENCE) F1154_12272(Current, arg1);
			}
		}
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

void EIF_Minit485 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
