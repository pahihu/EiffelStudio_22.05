/*
 * Code for class CASE_EXPRESSION_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ca489.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CASE_EXPRESSION_AS}.process */
void F1159_12365 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2667[Dtype(RTCW(arg1))-211])(arg1, Current);
}

void EIF_Minit489 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
