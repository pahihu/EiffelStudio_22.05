/*
 * Code for class EIFFEL_SCANNER_SKELETON
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ei455.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EIFFEL_SCANNER_SKELETON}.make_with_factory */
void F1124_10160 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_42_) = (EIF_REFERENCE) arg1;
	tr1 = RTOSCF(8873,F1065_8873, (Current));
	F1066_8888(Current, tr1);
	tr1 = RTLNSMART(eif_new_type(1037, 1).id);
	F1036_8220(RTCW(tr1), ((EIF_INTEGER_32) 5120L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_48_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1037, 1).id);
	F1036_8220(RTCW(tr1), ((EIF_INTEGER_32) 5120L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_41_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(131, 1).id);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_47_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1037, 1).id);
	F1036_8220(RTCW(tr1), ((EIF_INTEGER_32) 3L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_49_) = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("",0,0);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_44_) = (EIF_REFERENCE) tr1;
	*(EIF_NATURAL_8 *)(Current+ _CHROFF_351_26_) = (EIF_NATURAL_8) ((EIF_NATURAL_8) 1U);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_42_);
	F322_4451(RTCW(tr1), Current);
	RTLE;
}

/* {EIFFEL_SCANNER_SKELETON}.reset */
void F1124_10161 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1067_8968(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_47_);
	F132_1893(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_48_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6198[Dtype(RTCW(tr1))-1037])(tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_41_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6198[Dtype(RTCW(tr1))-1037])(tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_49_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6198[Dtype(RTCW(tr1))-1037])(tr1);
	*(EIF_NATURAL_8 *)(Current+ _CHROFF_351_26_) = (EIF_NATURAL_8) ((EIF_NATURAL_8) 1U);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_40_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_12_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_39_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_13_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_43_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_12_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_42_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_13_);
	RTLE;
}

/* {EIFFEL_SCANNER_SKELETON}.yy_initialize */
void F1124_10162 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1067_8967(Current);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_40_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_12_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_39_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_13_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_43_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_12_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_42_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_13_);
	RTLE;
}

/* {EIFFEL_SCANNER_SKELETON}.yy_load_input_buffer */
void F1124_10163 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1066_8923(Current);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_40_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_39_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_42_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_43_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_41_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTLE;
}

/* {EIFFEL_SCANNER_SKELETON}.token_line */
EIF_INTEGER_32 F1124_10199 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = F1128_11897(RTCW(arg1));
		tb2 = F132_1904(RTCW(tr1));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tr1 = F1128_11897(RTCW(arg1));
		Result = F132_1883(RTCW(tr1));
	} else {
		Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_14_);
		RTLE;
		return (EIF_INTEGER_32) Result;
	}
	RTLE;
	return Result;
}

/* {EIFFEL_SCANNER_SKELETON}.token_column */
EIF_INTEGER_32 F1124_10200 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = F1128_11897(RTCW(arg1));
		tb2 = F132_1904(RTCW(tr1));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tr1 = F1128_11897(RTCW(arg1));
		Result = F132_1884(RTCW(tr1));
	} else {
		Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_13_);
		RTLE;
		return (EIF_INTEGER_32) Result;
	}
	RTLE;
	return Result;
}

/* {EIFFEL_SCANNER_SKELETON}.set_syntax_version */
void F1124_10205 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	
	
	*(EIF_NATURAL_8 *)(Current+ _CHROFF_351_26_) = (EIF_NATURAL_8) arg1;
}

/* {EIFFEL_SCANNER_SKELETON}.report_one_error */
void F1124_10207 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1104_9680(RTCW(arg1), *(EIF_REFERENCE *)(Current + _REFACS_43_));
	tr1 = RTOSCF(1577,F125_1577, (Current));
	F315_4294(RTCW(tr1), arg1);
	F1065_8855(Current);
	RTLE;
}

/* {EIFFEL_SCANNER_SKELETON}.report_one_warning */
void F1124_10208 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1104_9680(RTCW(arg1), *(EIF_REFERENCE *)(Current + _REFACS_43_));
	tr1 = RTOSCF(1577,F125_1577, (Current));
	F315_4295(RTCW(tr1), arg1, *(EIF_BOOLEAN *)(Current+ _CHROFF_351_5_));
	RTLE;
}

/* {EIFFEL_SCANNER_SKELETON}.fatal_error */
void F1124_10209 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(5);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1110, 0x01).id, 1110, _OBJSIZ_6_0_0_2_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_14_);
	ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_13_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
	tr3 = F1033_8149(RTCW(arg1));
	F1111_9709(RTCW(tr1), ti4_1, ti4_2, tr2, tr3);
	F1126_10526(Current, tr1);
	RTLE;
}

/* {EIFFEL_SCANNER_SKELETON}.report_character_missing_quote_error */
void F1124_10210 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1114, 0x01).id, 1114, _OBJSIZ_6_0_0_2_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_14_);
	ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_13_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
	tr3 = F1033_8149(RTMS_EX_H("",0,0));
	F1111_9709(RTCW(tr1), ti4_1, ti4_2, tr2, tr3);
	F1126_10526(Current, tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_48_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R6261[Dtype(RTCW(tr1))-1037])(tr1, (EIF_CHARACTER_8) 'a');
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 303L);
	RTLE;
}

/* {EIFFEL_SCANNER_SKELETON}.report_string_bad_special_character_error */
void F1124_10211 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_6_0_0_2_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_14_);
	ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_13_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
	tr3 = F1033_8149(RTMS_EX_H("",0,0));
	F1111_9709(RTCW(tr1), ti4_1, ti4_2, tr2, tr3);
	F1126_10526(Current, tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_48_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R6261[Dtype(RTCW(tr1))-1037])(tr1, (EIF_CHARACTER_8) 'a');
	RTLE;
}

/* {EIFFEL_SCANNER_SKELETON}.report_string_invalid_code_error */
void F1124_10212 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_6_0_0_2_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_14_);
	ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_13_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
	tr3 = F1033_8149(RTMS_EX_H("",0,0));
	F1111_9709(RTCW(tr1), ti4_1, ti4_2, tr2, tr3);
	F1126_10526(Current, tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_48_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R6261[Dtype(RTCW(tr1))-1037])(tr1, (EIF_CHARACTER_8) 'a');
	RTLE;
}

/* {EIFFEL_SCANNER_SKELETON}.report_string_missing_quote_error */
void F1124_10213 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1115, 0x01).id, 1115, _OBJSIZ_6_0_0_2_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_14_);
	ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_13_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
	tr3 = F1033_8149(RTMS_EX_H("",0,0));
	F1111_9709(RTCW(tr1), ti4_1, ti4_2, tr2, tr3);
	F1126_10526(Current, tr1);
	tb1 = F619_5084(RTCW(arg1));
	if (tb1) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 383L);
	} else {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 382L);
	}
	RTLE;
}

/* {EIFFEL_SCANNER_SKELETON}.report_missing_end_of_verbatim_string_error */
void F1124_10214 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1113, 0x01).id, 1113, _OBJSIZ_6_0_0_2_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_14_);
	ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_13_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
	tr3 = F1033_8149(RTMS_EX_H("",0,0));
	F1111_9709(RTCW(tr1), ti4_1, ti4_2, tr2, tr3);
	F1126_10526(Current, tr1);
	tb1 = F619_5084(RTCW(arg1));
	if (tb1) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 385L);
	} else {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 384L);
	}
	RTLE;
}

/* {EIFFEL_SCANNER_SKELETON}.report_too_long_string */
void F1124_10215 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_REFERENCE tr6 = NULL;
	EIF_REFERENCE tr7 = NULL;
	EIF_REFERENCE tr8 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	RTCFDT;
	RTLD;
	
	RTLI(10);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,tr5);
	RTLR(6,tr6);
	RTLR(7,tr7);
	RTLR(8,arg1);
	RTLR(9,tr8);
	RTLIU(10);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1110, 0x01).id, 1110, _OBJSIZ_6_0_0_2_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_14_);
	ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_13_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
	tr3 = F1089_9299(Current);
	tr4 = F1089_9299(Current);
	tr5 = RTMS_EX_H("Identifier, manifest string or free operator is $1 character long.",66,952619566);
	tr6 = RTMS_EX_H("Identifier, manifest string or free operator is $1 characters long.",67,2046347566);
	tr7 = RTMS_EX_H("compiler.parser",15,1546037106);
	ti4_3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	tr4 = F21_216(RTCW(tr4), tr5, tr6, tr7, ti4_3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,953,959,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5 = RTLNTS(typres0.id, 2, 1);
	}
	ti4_3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	((EIF_TYPED_VALUE *)tr5+1)->it_i4 = ti4_3;
	tr3 = F21_217(RTCW(tr3), tr4, tr5);
	tr4 = F1089_9299(Current);
	tr5 = F1089_9299(Current);
	tr6 = RTMS_EX_H(" It exceeds limit of $1 character.",34,1238769710);
	tr7 = RTMS_EX_H(" It exceeds limit of $1 characters.",35,1445531694);
	tr8 = RTMS_EX_H("compiler.parser",15,1546037106);
	tr5 = F21_216(RTCW(tr5), tr6, tr7, tr8, ((EIF_INTEGER_32) 32767L));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,953,959,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr6 = RTLNTS(typres0.id, 2, 1);
	}
	((EIF_TYPED_VALUE *)tr6+1)->it_i4 = ((EIF_INTEGER_32) 32767L);
	tr4 = F21_217(RTCW(tr4), tr5, tr6);
	tr3 = F1042_8520(RTCW(tr3), tr4);
	F1111_9709(RTCW(tr1), ti4_1, ti4_2, tr2, tr3);
	F1126_10526(Current, tr1);
	RTLE;
}

/* {EIFFEL_SCANNER_SKELETON}.report_unknown_token_error */
void F1124_10216 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1110, 0x01).id, 1110, _OBJSIZ_6_0_0_2_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_14_);
	ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_13_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
	tr3 = F1033_8149(RTMS_EX_H("",0,0));
	F1111_9709(RTCW(tr1), ti4_1, ti4_2, tr2, tr3);
	F1126_10526(Current, tr1);
	RTLE;
}

/* {EIFFEL_SCANNER_SKELETON}.report_invalid_integer_error */
void F1124_10217 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1109, 0x01).id, 1109, _OBJSIZ_5_0_0_2_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_14_);
	ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_13_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
	tr3 = RTMS_EX_H("",0,0);
	F1108_9700(RTCW(tr1), ti4_1, ti4_2, tr2, tr3);
	F1126_10526(Current, tr1);
	RTLE;
}

/* {EIFFEL_SCANNER_SKELETON}.report_character_code_too_large_error */
void F1124_10222 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_REFERENCE tr6 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(8);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,tr5);
	RTLR(6,tr6);
	RTLR(7,arg1);
	RTLIU(8);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1114, 0x01).id, 1114, _OBJSIZ_6_0_0_2_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_14_);
	ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_13_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
	tr3 = F1089_9299(Current);
	tr4 = F1089_9299(Current);
	tr5 = RTMS_EX_H("Character code $1 is too large for CHARACTER_32.",48,1010885678);
	tr6 = RTMS_EX_H("compiler.parser",15,1546037106);
	tr4 = F21_215(RTCW(tr4), tr5, tr6);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,953,0xFF01,1035,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr5 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr5+1)->it_r = arg1;
	RTAR(tr5,arg1);
	tr3 = F21_217(RTCW(tr3), tr4, tr5);
	F1111_9709(RTCW(tr1), ti4_1, ti4_2, tr2, tr3);
	F1126_10526(Current, tr1);
	RTLE;
}

/* {EIFFEL_SCANNER_SKELETON}.process_id_as */
void F1124_10223 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc1 = F1066_8901(Current);
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 32767L))) {
		tr1 = F1066_8894(Current);
		F1124_10215(Current, tr1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_42_);
		tr1 = F324_4720(RTCW(tr1), Current);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_29_) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {EIFFEL_SCANNER_SKELETON}.process_string_character_as_value */
void F1124_10225 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_42_);
	tr1 = F322_4476(RTCW(tr1), Current, (EIF_CHARACTER_8) '+', arg1);
	loc1 = tr1;
	if ((EIF_BOOLEAN) !EIF_TEST(loc1)) {
		F1124_10211(Current);
	} else {
		tu8_1 = F1274_13535(loc1);
		tu8_2 = (EIF_NATURAL_64) ((EIF_NATURAL_32) 4294967295U);
		if ((EIF_BOOLEAN) (tu8_1 > tu8_2)) {
			F1124_10222(Current, arg1);
		} else {
			tu4_1 = F1274_13534(loc1);
			F1124_10226(Current, tu4_1);
		}
	}
	RTLE;
}

/* {EIFFEL_SCANNER_SKELETON}.process_string_character_code */
void F1124_10226 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 > ((EIF_NATURAL_32) 1114111U))) {
		F1066_8906(Current, ((EIF_INTEGER_32) 0L));
		F1124_10212(Current, arg1);
	} else {
		tr1 = F325_4735(Current);
		F1072_9077(RTCW(tr1), arg1, *(EIF_REFERENCE *)(Current + _REFACS_48_));
	}
	RTLE;
}

/* {EIFFEL_SCANNER_SKELETON}.process_simple_string_as */
void F1124_10227 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc2 = F1066_8901(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_42_);
	loc1 = F322_4434(RTCW(tr1), (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 2L)));
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		F1066_8914(Current, ((EIF_INTEGER_32) 2L), (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)), loc1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_42_);
	F324_4705(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_41_), Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_42_);
	tr1 = F324_4713(RTCW(tr1), loc1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_14_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_13_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_12_), loc2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_39_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_40_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_41_), *(EIF_REFERENCE *)(Current + _REFACS_41_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_39_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_1_) = (EIF_INTEGER_32) arg1;
	if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 2L)) > ((EIF_INTEGER_32) 32767L))) {
		if ((EIF_BOOLEAN)(loc1 == NULL)) {
			loc1 = RTLNS(eif_new_type(1037, 0x01).id, 1037, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F1036_8220(RTCW(loc1), (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 2L)));
			F1066_8914(Current, ((EIF_INTEGER_32) 2L), (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)), loc1);
		}
		F1124_10215(Current, loc1);
	}
	RTLE;
}

/* {EIFFEL_SCANNER_SKELETON}.is_verbatim_string_closer */
EIF_BOOLEAN F1124_10228 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if (loc4) break;
		loc2++;
		switch (F1066_8895(Current, loc2)) {
			case (EIF_CHARACTER_8) ']':
			case (EIF_CHARACTER_8) '}':
				loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				break;
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_49_);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN)(loc3 == (EIF_INTEGER_32) (F1066_8901(Current) - loc2))) {
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc3)) break;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_49_);
			tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4122[Dtype(RTCW(tr1))-706])(tr1, loc1));
			if ((EIF_BOOLEAN)(tc1 == F1066_8895(Current, loc2))) {
				loc1++;
				loc2++;
			} else {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
			}
		}
	}
	RTLE;
	return Result;
}

/* {EIFFEL_SCANNER_SKELETON}.align_left */
void F1124_10229 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_8 loc2 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_32_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	loc1 = F619_5084(RTCW(arg1));
	for (;;) {
		if (loc1) break;
		loc2 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4122[Dtype(RTCW(arg1))-706])(arg1, ((EIF_INTEGER_32) 1L)));
		switch (loc2) {
			case (EIF_CHARACTER_8) '\011':
			case (EIF_CHARACTER_8) ' ':
			case (EIF_CHARACTER_8) '|':
				loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R6211[Dtype(RTCW(arg1))-1036])(arg1, (EIF_CHARACTER_8) '\012', ((EIF_INTEGER_32) 1L));
				for (;;) {
					tb1 = '\01';
					tb2 = '\01';
					if (!(EIF_BOOLEAN) (loc3 <= ((EIF_INTEGER_32) 0L))) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
						tb2 = (EIF_BOOLEAN) (loc3 >= ti4_1);
					}
					if (!tb2) {
						tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4122[Dtype(RTCW(arg1))-706])(arg1, (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L))));
						tb1 = (EIF_BOOLEAN)(tc1 != loc2);
					}
					if (tb1) break;
					ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R6211[Dtype(RTCW(arg1))-1036])(arg1, (EIF_CHARACTER_8) '\012', (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)));
					loc3 = (EIF_INTEGER_32) ti4_1;
				}
				if ((EIF_BOOLEAN) (loc3 <= ((EIF_INTEGER_32) 0L))) {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6194[Dtype(RTCW(arg1))-1037])(arg1, ((EIF_INTEGER_32) 1L));
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_32_))++;
					loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R6211[Dtype(RTCW(arg1))-1036])(arg1, (EIF_CHARACTER_8) '\012', ((EIF_INTEGER_32) 1L));
					for (;;) {
						if ((EIF_BOOLEAN) (loc3 <= ((EIF_INTEGER_32) 0L))) break;
						loc3++;
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6194[Dtype(RTCW(arg1))-1037])(arg1, loc3);
						ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R6211[Dtype(RTCW(arg1))-1036])(arg1, (EIF_CHARACTER_8) '\012', loc3);
						loc3 = (EIF_INTEGER_32) ti4_1;
					}
					loc1 = F619_5084(RTCW(arg1));
				} else {
					loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
				break;
			default:
				loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				break;
		}
	}
	RTLE;
}

/* {EIFFEL_SCANNER_SKELETON}.cloned_string */
EIF_REFERENCE F1124_10230 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(1037, 0x01).id, 1037, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	F1036_8220(RTCW(Result), ti4_1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6259[Dtype(RTCW(Result))-1037])(Result, arg1);
	RTLE;
	return Result;
}

/* {EIFFEL_SCANNER_SKELETON}.char_32_from_source */
EIF_CHARACTER_32 F1124_10231 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tb1 = F619_5084(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = F325_4735(Current);
		Result = F1072_9078(RTCW(tr1), ((EIF_INTEGER_32) 1L), NULL, arg1);
	}
	RTLE;
	return Result;
}

/* {EIFFEL_SCANNER_SKELETON}.create_break_as_with_saved_data */
void F1124_10232 (EIF_REFERENCE Current)
{
	GTCX
	struct eif_ex_45 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_INTEGER_32 ti4_5;
	EIF_INTEGER_32 ti4_6;
	EIF_INTEGER_32 ti4_7;
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(67, 0x00).id);
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_41_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_42_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_34_);
	ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_35_);
	ti4_3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_36_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_41_);
	ti4_4 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_1_1_0_2_);
	ti4_5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_37_);
	ti4_6 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_38_);
	tr2 = *(EIF_REFERENCE *)(RTCW(loc2));
	ti4_7 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
	ti4_7 = F68_915(RTCW(loc1), tr2, ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (ti4_7 - ((EIF_INTEGER_32) 1L)));
	F324_4734(RTCW(tr1), loc2, ti4_1, ti4_2, ti4_3, ti4_4, ti4_5, ti4_6, ti4_7);
	RTLE;
}

/* {EIFFEL_SCANNER_SKELETON}.save_break_as_data */
void F1124_10233 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_36_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_12_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_34_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_14_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_35_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_13_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_37_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_39_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_38_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_40_);
	RTLE;
}

/* {EIFFEL_SCANNER_SKELETON}.update_character_locations */
void F1124_10234 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1124_10235(Current, loc1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_4_), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_3_) - ((EIF_INTEGER_32) 1L)));
	}
	RTLE;
}

/* {EIFFEL_SCANNER_SKELETON}.update_character_position_from_buffer */
void F1124_10235 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) arg2;
	loc2 = (EIF_INTEGER_32) arg3;
	loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_42_);
	loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_43_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_39_) = (EIF_INTEGER_32) loc4;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_40_) = (EIF_INTEGER_32) loc5;
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		/* INLINED CODE (SPECIAL.item) */
		tw2 = *((EIF_CHARACTER_32 *)RTCW(arg1) + (loc1));
		/* END INLINED CODE */
		tw1 = tw2;
		loc3 = (EIF_INTEGER_32) (tw1);
		loc1++;
		loc5++;
		if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 10L))) {
			ti4_1 = ((EIF_INTEGER_32) 1L);
		} else {
			ti4_1 = (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L));
		}
		loc4 = (EIF_INTEGER_32) ti4_1;
	}
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_42_) = (EIF_INTEGER_32) loc4;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_43_) = (EIF_INTEGER_32) loc5;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_41_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_43_) - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_40_));
	RTLE;
}

void EIF_Minit455 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
