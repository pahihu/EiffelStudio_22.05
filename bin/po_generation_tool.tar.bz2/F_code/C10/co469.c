/*
 * Code for class CONVERT_FEAT_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co469.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONVERT_FEAT_AS}.initialize */
void F1138_12054 (EIF_REFERENCE Current, EIF_BOOLEAN arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6, EIF_REFERENCE arg7, EIF_REFERENCE arg8)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,arg3);
	RTLR(3,arg4);
	RTLR(4,arg5);
	RTLR(5,arg6);
	RTLR(6,arg7);
	RTLR(7,arg8);
	RTLIU(8);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) = (EIF_BOOLEAN) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg3;
	if ((EIF_BOOLEAN)(arg4 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg4) + O9961[Dtype(arg4)-1210]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_) = (EIF_INTEGER_32) ti4_1;
	}
	if ((EIF_BOOLEAN)(arg5 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg5) + O9961[Dtype(arg5)-1210]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_4_) = (EIF_INTEGER_32) ti4_1;
	}
	if ((EIF_BOOLEAN)(arg6 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg6) + O9961[Dtype(arg6)-1210]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_0_) = (EIF_INTEGER_32) ti4_1;
	}
	if ((EIF_BOOLEAN)(arg7 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg7) + O9961[Dtype(arg7)-1210]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_1_) = (EIF_INTEGER_32) ti4_1;
	}
	if ((EIF_BOOLEAN)(arg8 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg8) + O9961[Dtype(arg8)-1210]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

/* {CONVERT_FEAT_AS}.process */
void F1138_12055 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2606[Dtype(RTCW(arg1))-211])(arg1, Current);
}

/* {CONVERT_FEAT_AS}.colon_symbol */
EIF_REFERENCE F1138_12061 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11915(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_0_));
}

/* {CONVERT_FEAT_AS}.lcurly_symbol */
EIF_REFERENCE F1138_12062 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11915(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_1_));
}

/* {CONVERT_FEAT_AS}.rcurly_symbol */
EIF_REFERENCE F1138_12063 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11915(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_));
}

/* {CONVERT_FEAT_AS}.lparan_symbol */
EIF_REFERENCE F1138_12064 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11915(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_));
}

/* {CONVERT_FEAT_AS}.rparan_symbol */
EIF_REFERENCE F1138_12065 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1128_11915(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_4_));
}

/* {CONVERT_FEAT_AS}.first_token */
EIF_REFERENCE F1138_12070 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9356[Dtype(RTCW(tr1))-1128])(tr1, arg1);
	RTLE;
	return Result;
}

/* {CONVERT_FEAT_AS}.last_token */
EIF_REFERENCE F1138_12071 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_4_) != ((EIF_INTEGER_32) 0L)))) {
		RTLE;
		return (EIF_REFERENCE) F1138_12065(Current, arg1);
	} else {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_) != ((EIF_INTEGER_32) 0L)))) {
			RTLE;
			return (EIF_REFERENCE) F1138_12063(Current, arg1);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			Result = F1210_12827(RTCW(tr1), arg1);
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit469 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
