/*
 * Code for class YY_PARSER_SKELETON
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "yy453.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {YY_PARSER_SKELETON}.make */
void F1122_9919 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(2276,F175_2276, (Current));
	tr1 = F40_496(RTCW(tr1), ((EIF_INTEGER_32) 200L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_24_) = (EIF_REFERENCE) tr1;
	F1127_10542(Current);
	F1127_10541(Current);
	RTLE;
}

/* {YY_PARSER_SKELETON}.parse */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F1122_9920 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_INTEGER_32 EIF_VOLATILE loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc7 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_INTEGER_32  EIF_VOLATILE ti4_1;
	EIF_INTEGER_32  EIF_VOLATILE ti4_2;
	EIF_INTEGER_32  EIF_VOLATILE ti4_3;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	RTLD;
	RTXD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,saved_except);
	RTLIU(3);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_30_) == ((EIF_INTEGER_32) 105L))) {
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_21_);
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_22_);
		loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_23_);
		loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_24_);
		loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_25_);
		loc6 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_26_);
		loc7 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_27_);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_30_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 104L);
		if ((EIF_BOOLEAN)(loc7 == ((EIF_INTEGER_32) 3L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
			/* INLINED CODE (SPECIAL.item) */
			ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc3));
			/* END INLINED CODE */
			ti4_1 = ti4_2;
			loc3 = (EIF_INTEGER_32) ti4_1;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
			/* INLINED CODE (SPECIAL.item) */
			ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_28_)));
			/* END INLINED CODE */
			loc6 = ti4_3;
			loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 152L));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
			/* INLINED CODE (SPECIAL.item) */
			ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc5));
			/* END INLINED CODE */
			loc2 = ti4_2;
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + loc6);
			tb1 = '\0';
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (loc2 <= ((EIF_INTEGER_32) 5455L)))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
				/* INLINED CODE (SPECIAL.item) */
				ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc2));
				/* END INLINED CODE */
				ti4_1 = ti4_2;
				tb1 = (EIF_BOOLEAN)(ti4_1 == loc6);
			}
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
				/* INLINED CODE (SPECIAL.item) */
				ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc2));
				/* END INLINED CODE */
				ti4_1 = ti4_2;
				loc2 = (EIF_INTEGER_32) ti4_1;
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
				/* INLINED CODE (SPECIAL.item) */
				ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc5));
				/* END INLINED CODE */
				loc2 = ti4_2;
			}
			loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		}
	} else {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_31_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_351_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_29_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		F1127_10543(Current);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_28_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
		loc1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_30_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 104L);
		loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	for (;;) {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_30_) != ((EIF_INTEGER_32) 104L))) break;
		switch (loc7) {
			case 1L:
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_28_))++;
				if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_28_) >= loc1)) {
					loc1 += ((EIF_INTEGER_32) 200L);
					tr1 = RTOSCF(2276,F175_2276, (Current));
					tr1 = F40_504(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_24_), loc1);
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_24_) = (EIF_REFERENCE) tr1;
				}
				tr1 = RTOSCF(2276,F175_2276, (Current));
				F40_501(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_24_), loc2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_28_));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
				/* INLINED CODE (SPECIAL.item) */
				ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc2));
				/* END INLINED CODE */
				loc3 = ti4_2;
				if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) -32768L))) {
					loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
				} else {
					if (*(EIF_BOOLEAN *)(Current+ _CHROFF_351_3_)) {
						F1067_8969(Current);
						*(EIF_BOOLEAN *)(Current+ _CHROFF_351_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					}
					if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_1_) > ((EIF_INTEGER_32) 0L))) {
						if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_1_) <= ((EIF_INTEGER_32) 406L))) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
							/* INLINED CODE (SPECIAL.item) */
							ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_1_)));
							/* END INLINED CODE */
							loc4 = ti4_3;
						} else {
							loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 406L);
						}
						loc3 += loc4;
					} else {
						if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_1_) == ((EIF_INTEGER_32) 0L))) {
							loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
						} else {
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_31_))++;
							F1127_11242(Current, loc2);
							F1122_9925(Current);
							loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						}
					}
					tb1 = '\01';
					if (!(EIF_BOOLEAN) ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 0L)) || (EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 5455L)))) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
						/* INLINED CODE (SPECIAL.item) */
						ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc3));
						/* END INLINED CODE */
						ti4_1 = ti4_2;
						tb1 = (EIF_BOOLEAN)(ti4_1 != loc4);
					}
					if (tb1) {
						loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
						/* INLINED CODE (SPECIAL.item) */
						ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc3));
						/* END INLINED CODE */
						ti4_1 = ti4_2;
						loc3 = (EIF_INTEGER_32) ti4_1;
						if ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 0L))) {
							if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) -32768L))) {
								loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
							} else {
								loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) -loc3;
								loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
							}
						} else {
							if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
								loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
							} else {
								if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 1264L))) {
									F1122_9924(Current);
								} else {
									if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_1_) > ((EIF_INTEGER_32) 0L))) {
										*(EIF_BOOLEAN *)(Current+ _CHROFF_351_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
									}
									F1127_10545(Current, loc4);
									if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_29_) != ((EIF_INTEGER_32) 0L))) {
										(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_29_))--;
									}
									loc2 = (EIF_INTEGER_32) loc3;
								}
							}
						}
					}
				}
				break;
			case 2L:
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
				/* INLINED CODE (SPECIAL.item) */
				ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc2));
				/* END INLINED CODE */
				loc3 = ti4_2;
				if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
					loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
				} else {
					loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
				}
				break;
			case 3L:
				F1127_10549(Current, loc3);
				switch (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_30_)) {
					case 104L:
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
						/* INLINED CODE (SPECIAL.item) */
						ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc3));
						/* END INLINED CODE */
						ti4_1 = ti4_2;
						loc3 = (EIF_INTEGER_32) ti4_1;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
						/* INLINED CODE (SPECIAL.item) */
						ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_28_)));
						/* END INLINED CODE */
						loc6 = ti4_3;
						loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 152L));
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
						/* INLINED CODE (SPECIAL.item) */
						ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc5));
						/* END INLINED CODE */
						loc2 = ti4_2;
						loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + loc6);
						tb1 = '\0';
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (loc2 <= ((EIF_INTEGER_32) 5455L)))) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
							/* INLINED CODE (SPECIAL.item) */
							ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc2));
							/* END INLINED CODE */
							ti4_1 = ti4_2;
							tb1 = (EIF_BOOLEAN)(ti4_1 == loc6);
						}
						if (tb1) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
							/* INLINED CODE (SPECIAL.item) */
							ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc2));
							/* END INLINED CODE */
							ti4_1 = ti4_2;
							loc2 = (EIF_INTEGER_32) ti4_1;
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
							/* INLINED CODE (SPECIAL.item) */
							ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc5));
							/* END INLINED CODE */
							loc2 = ti4_2;
						}
						loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						break;
					case 105L:
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_21_) = (EIF_INTEGER_32) loc1;
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_22_) = (EIF_INTEGER_32) loc2;
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_23_) = (EIF_INTEGER_32) loc3;
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_24_) = (EIF_INTEGER_32) loc4;
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_25_) = (EIF_INTEGER_32) loc5;
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_26_) = (EIF_INTEGER_32) loc6;
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_27_) = (EIF_INTEGER_32) loc7;
						break;
					case 103L:
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_30_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 104L);
						loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
						break;
				}
				break;
			case 4L:
				if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_29_) == ((EIF_INTEGER_32) 3L))) {
					if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_1_) <= ((EIF_INTEGER_32) 0L))) {
						F1122_9925(Current);
					} else {
						*(EIF_BOOLEAN *)(Current+ _CHROFF_351_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
					}
				} else {
					if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_29_) == ((EIF_INTEGER_32) 0L))) {
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_31_))++;
						F1127_11242(Current, loc2);
					}
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_29_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
					loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
				}
				break;
			case 5L:
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
				/* INLINED CODE (SPECIAL.item) */
				ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc2));
				/* END INLINED CODE */
				loc3 = ti4_2;
				if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) -32768L))) {
					loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
				} else {
					loc3 += ((EIF_INTEGER_32) 1L);
					tb1 = '\01';
					if (!(EIF_BOOLEAN) ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 0L)) || (EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 5455L)))) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
						/* INLINED CODE (SPECIAL.item) */
						ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc3));
						/* END INLINED CODE */
						ti4_1 = ti4_2;
						tb1 = (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 1L));
					}
					if (tb1) {
						loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
						/* INLINED CODE (SPECIAL.item) */
						ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc3));
						/* END INLINED CODE */
						ti4_1 = ti4_2;
						loc3 = (EIF_INTEGER_32) ti4_1;
						if ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 0L))) {
							if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) -32768L))) {
								loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
							} else {
								loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) -loc3;
								loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
							}
						} else {
							if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
								loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
							} else {
								if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 1264L))) {
									F1122_9924(Current);
								} else {
									F1127_10546(Current);
									loc2 = (EIF_INTEGER_32) loc3;
									loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
								}
							}
						}
					}
				}
				break;
			case 6L:
				if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_28_) == ((EIF_INTEGER_32) 0L))) {
					F1122_9925(Current);
				} else {
					F1127_10547(Current, loc2);
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_28_))--;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					/* INLINED CODE (SPECIAL.item) */
					ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_28_)));
					/* END INLINED CODE */
					loc2 = ti4_3;
					loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
				}
				break;
			default:
				RTEC(EN_WHEN);
		}
	}
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_30_) != ((EIF_INTEGER_32) 105L))) {
		F1122_9970(Current);
	}
	RTE_E
	RTXSC;
	F1122_9925(Current);
	F1122_9970(Current);
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {YY_PARSER_SKELETON}.error_count */
EIF_INTEGER_32 F1122_9923 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_31_);
}


/* {YY_PARSER_SKELETON}.accept */
void F1122_9924 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_30_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 101L);
}

/* {YY_PARSER_SKELETON}.abort */
void F1122_9925 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_30_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 102L);
}

/* {YY_PARSER_SKELETON}.raise_error */
void F1122_9929 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_351_27_0_30_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 103L);
}

/* {YY_PARSER_SKELETON}.report_eof_expected_error */
void F1122_9932 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTMS_EX_H("parse error",11,283683698);
	F1126_10527(Current, tr1);
	RTLE;
}

/* {YY_PARSER_SKELETON}.yyfixed_array */
EIF_REFERENCE F1122_9963 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(2276,F175_2276, (Current));
	Result = F40_499(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {YY_PARSER_SKELETON}.yyarray_subcopy */
void F1122_9964 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(4328,F317_4328, (Current));
	F909_6683(RTCW(tr1), arg1, arg2, arg3, arg4, arg5);
	RTLE;
}

/* {YY_PARSER_SKELETON}.yy_clear_all */
void F1122_9970 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	{
		/* INLINED CODE (YY_PARSER_SKELETON.clear_all) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

void EIF_Minit453 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
