
#ifndef _C21_ty1041_
#define _C21_ty1041_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F393_4863(EIF_REFERENCE);
extern void EIF_Minit1041(void);
extern char *(*R4122[])();
extern char *(*R3979[])();
extern char *(*R3992[])();

#ifdef __cplusplus
}
#endif

#endif
