
#ifndef _C21_to1048_
#define _C21_to1048_

#ifdef __cplusplus
extern "C" {
#endif

extern void F300_4091(EIF_REFERENCE, EIF_INTEGER_32);
extern void F300_4092(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern void F300_4098(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1048(void);
extern void F847_6396(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y3324[];
extern EIF_TYPE_INDEX *Y3324_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
