
#ifndef _C21_ge1013_
#define _C21_ge1013_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_8 F425_4909(EIF_REFERENCE);
extern EIF_INTEGER_32 F425_4911(EIF_REFERENCE);
extern EIF_BOOLEAN F425_4918(EIF_REFERENCE);
extern EIF_BOOLEAN F425_4922(EIF_REFERENCE);
extern void F425_4923(EIF_REFERENCE);
extern void F425_4924(EIF_REFERENCE);
extern EIF_REFERENCE F425_4925(EIF_REFERENCE);
extern void EIF_Minit1013(void);
extern char *(*R4007[])();
extern char *(*R3980[])();
extern long O4006[];
extern long O4008[];

#ifdef __cplusplus
}
#endif

#endif
