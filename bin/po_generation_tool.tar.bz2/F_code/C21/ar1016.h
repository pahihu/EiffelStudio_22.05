
#ifndef _C21_ar1016_
#define _C21_ar1016_

#ifdef __cplusplus
extern "C" {
#endif

extern void F438_4935(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F438_4936(EIF_REFERENCE);
extern EIF_REFERENCE F438_4937(EIF_REFERENCE);
extern EIF_REFERENCE F438_4939(EIF_REFERENCE);
extern EIF_INTEGER_32 F438_4940(EIF_REFERENCE);
extern void EIF_Minit1016(void);
extern EIF_INTEGER_32 F800_5594(EIF_REFERENCE);
extern EIF_REFERENCE F800_5575(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y3933[];
extern EIF_TYPE_INDEX *Y3933_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
