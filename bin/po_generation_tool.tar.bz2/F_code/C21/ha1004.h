
#ifndef _C21_ha1004_
#define _C21_ha1004_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F411_4891(EIF_REFERENCE);
extern EIF_REFERENCE F411_4892(EIF_REFERENCE);
extern EIF_BOOLEAN F411_4894(EIF_REFERENCE);
extern void F411_4895(EIF_REFERENCE);
extern EIF_REFERENCE F411_4896(EIF_REFERENCE);
extern void EIF_Minit1004(void);
extern EIF_INTEGER_32 F786_5485(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F786_5484(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F404_4883(EIF_REFERENCE);
extern char *(*R4122[])();
extern char *(*R4896[])();

#ifdef __cplusplus
}
#endif

#endif
