
#ifndef _C21_re1008_
#define _C21_re1008_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F645_5090(EIF_REFERENCE);
extern void EIF_Minit1008(void);
extern char *(*R4110[])();

#ifdef __cplusplus
}
#endif

#endif
