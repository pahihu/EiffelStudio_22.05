
#ifndef _C21_to1010_
#define _C21_to1010_

#ifdef __cplusplus
extern "C" {
#endif

extern void F299_4091(EIF_REFERENCE, EIF_INTEGER_32);
extern void F299_4092(EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32);
extern void F299_4098(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1010(void);
extern void F846_6396(EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y3324[];
extern EIF_TYPE_INDEX *Y3324_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
