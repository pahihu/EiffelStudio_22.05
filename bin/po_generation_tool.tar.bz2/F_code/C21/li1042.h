
#ifndef _C21_li1042_
#define _C21_li1042_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F502_4997(EIF_REFERENCE, EIF_BOOLEAN);
extern void F502_4999(EIF_REFERENCE, EIF_BOOLEAN);
extern EIF_BOOLEAN F502_5003(EIF_REFERENCE);
extern EIF_BOOLEAN F502_5005(EIF_REFERENCE);
extern void EIF_Minit1042(void);
extern EIF_BOOLEAN F623_5084(EIF_REFERENCE);
extern char *(*R4053[])();
extern char *(*R4054[])();
extern char *(*R4055[])();
extern char *(*R4061[])();
extern char *(*R4066[])();
extern char *(*R4068[])();
extern long O4047[];

#ifdef __cplusplus
}
#endif

#endif
