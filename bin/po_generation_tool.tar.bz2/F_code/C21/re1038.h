
#ifndef _C21_re1038_
#define _C21_re1038_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F690_5115(EIF_REFERENCE);
extern void EIF_Minit1038(void);
extern void F405_4869(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R3991[])();
extern EIF_TYPE_INDEX Y3949[];
extern EIF_TYPE_INDEX *Y3949_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
