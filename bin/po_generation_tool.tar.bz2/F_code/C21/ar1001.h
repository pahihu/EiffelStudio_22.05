
#ifndef _C21_ar1001_
#define _C21_ar1001_

#ifdef __cplusplus
extern "C" {
#endif

extern void F450_4947(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F450_4948(EIF_REFERENCE);
extern EIF_REFERENCE F450_4949(EIF_REFERENCE);
extern EIF_REFERENCE F450_4951(EIF_REFERENCE);
extern EIF_INTEGER_32 F450_4952(EIF_REFERENCE);
extern void EIF_Minit1001(void);
extern EIF_TYPE_INDEX Y3933[];
extern EIF_TYPE_INDEX *Y3933_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
