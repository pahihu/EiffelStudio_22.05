
#ifndef _C21_ar1025_
#define _C21_ar1025_

#ifdef __cplusplus
extern "C" {
#endif

extern void F451_4947(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F451_4948(EIF_REFERENCE);
extern EIF_REFERENCE F451_4949(EIF_REFERENCE);
extern EIF_REFERENCE F451_4951(EIF_REFERENCE);
extern EIF_INTEGER_32 F451_4952(EIF_REFERENCE);
extern void EIF_Minit1025(void);
extern EIF_TYPE_INDEX Y3933[];
extern EIF_TYPE_INDEX *Y3933_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
