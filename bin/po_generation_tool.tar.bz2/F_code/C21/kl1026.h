
#ifndef _C21_kl1026_
#define _C21_kl1026_

#ifdef __cplusplus
extern "C" {
#endif

extern void F906_6683(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit1026(void);
extern void F713_5189(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
