
#ifndef _C21_re1040_
#define _C21_re1040_

#ifdef __cplusplus
extern "C" {
#endif

extern void F405_4869(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F405_4871(EIF_REFERENCE);
extern EIF_INTEGER_32 F405_4872(EIF_REFERENCE);
extern EIF_INTEGER_32 F405_4873(EIF_REFERENCE);
extern EIF_INTEGER_32 F405_4874(EIF_REFERENCE);
extern EIF_REFERENCE F405_4875(EIF_REFERENCE);
extern EIF_BOOLEAN F405_4881(EIF_REFERENCE);
extern EIF_BOOLEAN F405_4882(EIF_REFERENCE);
extern EIF_BOOLEAN F405_4883(EIF_REFERENCE);
extern void F405_4888(EIF_REFERENCE);
extern void F405_4889(EIF_REFERENCE);
extern EIF_REFERENCE F405_4890(EIF_REFERENCE);
extern void EIF_Minit1040(void);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern char *(*R4123[])();
extern char *(*R4124[])();
extern char *(*R4126[])();
extern char *(*R3991[])();
extern long O4000[];
extern long O4001[];
extern long O4002[];
extern long O4003[];
extern long O3995[];
extern long O3999[];

#ifdef __cplusplus
}
#endif

#endif
