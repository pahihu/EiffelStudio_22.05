
#ifndef _C21_bi1022_
#define _C21_bi1022_

#ifdef __cplusplus
extern "C" {
#endif

extern void F512_5016(EIF_REFERENCE, EIF_CHARACTER_8);
extern void EIF_Minit1022(void);
extern void F498_4999(EIF_REFERENCE, EIF_CHARACTER_8);
extern char *(*R4068[])();
extern char *(*R4069[])();
extern char *(*R4045[])();

#ifdef __cplusplus
}
#endif

#endif
