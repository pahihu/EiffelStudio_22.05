
#ifndef _C21_sp1012_
#define _C21_sp1012_

#ifdef __cplusplus
extern "C" {
#endif

extern void F463_4953(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F463_4954(EIF_REFERENCE);
extern EIF_REFERENCE F463_4955(EIF_REFERENCE);
extern EIF_INTEGER_32 F463_4956(EIF_REFERENCE);
extern void EIF_Minit1012(void);
extern EIF_INTEGER_32 F846_6407(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y3933[];
extern EIF_TYPE_INDEX *Y3933_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
