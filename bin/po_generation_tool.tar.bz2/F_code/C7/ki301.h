
#ifndef _C7_ki301_
#define _C7_ki301_

#ifdef __cplusplus
extern "C" {
#endif

extern void F831_6271(EIF_REFERENCE, EIF_REFERENCE);
extern void F831_6272(EIF_REFERENCE);
extern void EIF_Minit301(void);
extern char *(*R4797[])();
extern char *(*R4777[])();

#ifdef __cplusplus
}
#endif

#endif
