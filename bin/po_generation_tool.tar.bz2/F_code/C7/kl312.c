/*
 * Code for class KL_IMPORTED_ANY_ROUTINES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl312.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_IMPORTED_ANY_ROUTINES}.any_ */
static EIF_REFERENCE F899_6515_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (6515);
#define Result RTOSR(6515)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(11, 0x01).id, 11, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (6515);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F899_6515 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6515,F899_6515_body,(Current));
}

void EIF_Minit312 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
