
#ifndef _C7_kl312_
#define _C7_kl312_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,6515)
static EIF_REFERENCE F899_6515_body(EIF_REFERENCE);
extern EIF_REFERENCE F899_6515(EIF_REFERENCE);
extern void EIF_Minit312(void);

#ifdef __cplusplus
}
#endif

#endif
