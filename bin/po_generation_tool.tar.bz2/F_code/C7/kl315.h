
#ifndef _C7_kl315_
#define _C7_kl315_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_8 F902_6556(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F902_6560(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit315(void);

#ifdef __cplusplus
}
#endif

#endif
