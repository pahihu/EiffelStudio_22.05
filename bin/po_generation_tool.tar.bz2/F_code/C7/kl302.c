/*
 * Code for class KL_STDERR_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl302.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_STDERR_FILE}.make */
void F832_6274 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {KL_STDERR_FILE}.eol */

EIF_REFERENCE F832_6276 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6276,RTMS_EX_H("\012",1,10));
}

/* {KL_STDERR_FILE}.put_character */
void F832_6278 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(6281,F832_6281, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4526[Dtype(RTCW(tr1))-822])(tr1, arg1);
	RTLE;
}

/* {KL_STDERR_FILE}.put_string */
void F832_6279 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(6249,F825_6249, (Current));
	loc1 = F903_6605(RTCW(tr1), arg1);
	tr1 = RTOSCF(6281,F832_6281, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4524[Dtype(RTCW(tr1))-822])(tr1, loc1);
	RTLE;
}

/* {KL_STDERR_FILE}.console */
static EIF_REFERENCE F832_6281_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (6281);
#define Result RTOSR(6281)
	RTOC_NEW(Result);
	Result = RTOSCF(793,F62_793, (RTCV(RTOSCF(24,F1_24, (Current)))));
	RTOSE (6281);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F832_6281 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6281,F832_6281_body,(Current));
}

void EIF_Minit302 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
