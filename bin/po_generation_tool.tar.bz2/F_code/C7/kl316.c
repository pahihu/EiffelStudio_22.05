/*
 * Code for class KL_STRING_ROUTINES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl316.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_STRING_ROUTINES}.as_string */
EIF_REFERENCE F903_6605 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	tb1 = '\0';
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(1037, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		tr1 = RTOSCF(6515,F899_6515, (Current));
		tr2 = RTOSCF(6613,F903_6613, (Current));
		tb2 = F12_176(RTCW(tr1), arg1, tr2);
		tb1 = tb2;
	}
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		loc2 = arg1;
		loc2 = RTRV(eif_new_type(1312, 0x01),loc2);
		if (EIF_TEST(loc2)) {
			tr1 = F1313_14033(loc2);
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6213[Dtype(RTCW(arg1))-1036])(arg1);
			RTLE;
			return (EIF_REFERENCE) tr1;
		}
	}/* NOTREACHED */
	
}

/* {KL_STRING_ROUTINES}.dummy_string */

EIF_REFERENCE F903_6613 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6613,RTMS_EX_H("",0,0));
}

void EIF_Minit316 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
