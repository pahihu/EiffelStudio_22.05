#include "eif_eiffel.h"
#include "eif_rout_obj.h"

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1196_14238(EIF_REFERENCE, EIF_REFERENCE);
extern void F793_5567(EIF_REFERENCE, EIF_REFERENCE, EIF_POINTER);
extern void F784_5494(EIF_REFERENCE);
extern EIF_BOOLEAN F619_5084(EIF_REFERENCE);
extern void F1197_14240(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F793_5568(EIF_REFERENCE, EIF_POINTER, EIF_POINTER);
extern char *(*R9803[])();

#ifdef __cplusplus
}
#endif
