#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif
extern const char *names5[];
static const uint32 types5 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags5 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype5_0 [] = {1043,0xFFFF};
static const EIF_TYPE_INDEX g_atype5_1 [] = {1042,0xFFFF};

static const EIF_TYPE_INDEX *gtypes5 [] = {
g_atype5_0,
g_atype5_1,
};

static const long offsets5 [] =
{
0,
 + @REFACS(1),
};

extern const char *names6[];
static const uint32 types6 [] =
{
SK_UINT32,
};

static const uint16 attr_flags6 [] =
{0,};

static const EIF_TYPE_INDEX g_atype6_0 [] = {971,0xFFFF};

static const EIF_TYPE_INDEX *gtypes6 [] = {
g_atype6_0,
};

static const long offsets6 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names7[];
static const uint32 types7 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags7 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype7_0 [] = {0xFF01,271,0xFFFF};
static const EIF_TYPE_INDEX g_atype7_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype7_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes7 [] = {
g_atype7_0,
g_atype7_1,
g_atype7_2,
};

static const long offsets7 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names11[];
static const uint32 types11 [] =
{
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags11 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype11_0 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype11_1 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes11 [] = {
g_atype11_0,
g_atype11_1,
};

static const long offsets11 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
};

extern const char *names14[];
static const uint32 types14 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags14 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype14_0 [] = {0xFF01,267,0xFFFF};
static const EIF_TYPE_INDEX g_atype14_1 [] = {0xFF01,267,0xFFFF};
static const EIF_TYPE_INDEX g_atype14_2 [] = {0xFF01,267,0xFFFF};

static const EIF_TYPE_INDEX *gtypes14 [] = {
g_atype14_0,
g_atype14_1,
g_atype14_2,
};

static const long offsets14 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names15[];
static const uint32 types15 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags15 [] =
{0,};

static const EIF_TYPE_INDEX g_atype15_0 [] = {989,0xFFFF};

static const EIF_TYPE_INDEX *gtypes15 [] = {
g_atype15_0,
};

static const long offsets15 [] =
{
+ @CHROFF(0,0),
};

extern const char *names16[];
static const uint32 types16 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags16 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype16_0 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype16_1 [] = {0xFF01,114,0xFFFF};
static const EIF_TYPE_INDEX g_atype16_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes16 [] = {
g_atype16_0,
g_atype16_1,
g_atype16_2,
};

static const long offsets16 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names21[];
static const uint32 types21 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags21 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype21_0 [] = {0xFF01,99,0xFFFF};
static const EIF_TYPE_INDEX g_atype21_1 [] = {0xFF01,13,0xFFFF};
static const EIF_TYPE_INDEX g_atype21_2 [] = {0xFF01,113,0xFFFF};
static const EIF_TYPE_INDEX g_atype21_3 [] = {0xFF01,15,0xFFFF};
static const EIF_TYPE_INDEX g_atype21_4 [] = {0xFF01,14,0xFFFF};
static const EIF_TYPE_INDEX g_atype21_5 [] = {0xFF01,162,0xFFFF};

static const EIF_TYPE_INDEX *gtypes21 [] = {
g_atype21_0,
g_atype21_1,
g_atype21_2,
g_atype21_3,
g_atype21_4,
g_atype21_5,
};

static const long offsets21 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
};

extern const char *names22[];
static const uint32 types22 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags22 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype22_0 [] = {0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype22_1 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype22_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype22_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype22_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype22_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype22_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes22 [] = {
g_atype22_0,
g_atype22_1,
g_atype22_2,
g_atype22_3,
g_atype22_4,
g_atype22_5,
g_atype22_6,
};

static const long offsets22 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
+ @LNGOFF(3,1,0,1),
+ @LNGOFF(3,1,0,2),
};

extern const char *names24[];
static const uint32 types24 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags24 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype24_0 [] = {0xFF01,1189,0xFFFF};
static const EIF_TYPE_INDEX g_atype24_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype24_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype24_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype24_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes24 [] = {
g_atype24_0,
g_atype24_1,
g_atype24_2,
g_atype24_3,
g_atype24_4,
};

static const long offsets24 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
};

extern const char *names25[];
static const uint32 types25 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags25 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype25_0 [] = {0xFF01,785,1025,0xFF01,1035,0xFFFF};
static const EIF_TYPE_INDEX g_atype25_1 [] = {0xFF01,783,0xFF01,1035,0xFF01,1035,0xFFFF};

static const EIF_TYPE_INDEX *gtypes25 [] = {
g_atype25_0,
g_atype25_1,
};

static const long offsets25 [] =
{
0,
 + @REFACS(1),
};

extern const char *names27[];
static const uint32 types27 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags27 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype27_0 [] = {1045,0xFF01,1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype27_1 [] = {1045,0xFF01,1274,0xFFFF};

static const EIF_TYPE_INDEX *gtypes27 [] = {
g_atype27_0,
g_atype27_1,
};

static const long offsets27 [] =
{
0,
 + @REFACS(1),
};

extern const char *names30[];
static const uint32 types30 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags30 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype30_0 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype30_1 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes30 [] = {
g_atype30_0,
g_atype30_1,
};

static const long offsets30 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names31[];
static const uint32 types31 [] =
{
SK_UINT32,
};

static const uint16 attr_flags31 [] =
{1,};

static const EIF_TYPE_INDEX g_atype31_0 [] = {971,0xFFFF};

static const EIF_TYPE_INDEX *gtypes31 [] = {
g_atype31_0,
};

static const long offsets31 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names32[];
static const uint32 types32 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags32 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype32_0 [] = {1212,0xFFFF};
static const EIF_TYPE_INDEX g_atype32_1 [] = {1212,0xFFFF};
static const EIF_TYPE_INDEX g_atype32_2 [] = {1249,0xFFFF};

static const EIF_TYPE_INDEX *gtypes32 [] = {
g_atype32_0,
g_atype32_1,
g_atype32_2,
};

static const long offsets32 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names33[];
static const uint32 types33 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags33 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype33_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype33_1 [] = {0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes33 [] = {
g_atype33_0,
g_atype33_1,
};

static const long offsets33 [] =
{
0,
 + @REFACS(1),
};

extern const char *names34[];
static const uint32 types34 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags34 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype34_0 [] = {1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_1 [] = {1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_2 [] = {1200,0xFF01,1307,0xFFFF};

static const EIF_TYPE_INDEX *gtypes34 [] = {
g_atype34_0,
g_atype34_1,
g_atype34_2,
};

static const long offsets34 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names35[];
static const uint32 types35 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags35 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype35_0 [] = {1212,0xFFFF};
static const EIF_TYPE_INDEX g_atype35_1 [] = {1206,0xFFFF};
static const EIF_TYPE_INDEX g_atype35_2 [] = {33,0xFFFF};

static const EIF_TYPE_INDEX *gtypes35 [] = {
g_atype35_0,
g_atype35_1,
g_atype35_2,
};

static const long offsets35 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names46[];
static const uint32 types46 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags46 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype46_0 [] = {0xFF01,1035,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_1 [] = {0xFF01,1069,0xFFFF};

static const EIF_TYPE_INDEX *gtypes46 [] = {
g_atype46_0,
g_atype46_1,
};

static const long offsets46 [] =
{
0,
 + @REFACS(1),
};

extern const char *names48[];
static const uint32 types48 [] =
{
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags48 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype48_0 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype48_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype48_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype48_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes48 [] = {
g_atype48_0,
g_atype48_1,
g_atype48_2,
g_atype48_3,
};

static const long offsets48 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
+ @CHROFF(0,2),
+ @LNGOFF(0,3,0,0),
};

extern const char *names62[];
static const uint32 types62 [] =
{
SK_REF,
};

static const uint16 attr_flags62 [] =
{0,};

static const EIF_TYPE_INDEX g_atype62_0 [] = {823,0xFFFF};

static const EIF_TYPE_INDEX *gtypes62 [] = {
g_atype62_0,
};

static const long offsets62 [] =
{
0,
};

extern const char *names65[];
static const uint32 types65 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags65 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype65_0 [] = {0xFF01,187,0xFFFF};
static const EIF_TYPE_INDEX g_atype65_1 [] = {0xFF01,783,0xFF01,184,0xFF01,1041,0xFFFF};

static const EIF_TYPE_INDEX *gtypes65 [] = {
g_atype65_0,
g_atype65_1,
};

static const long offsets65 [] =
{
0,
 + @REFACS(1),
};

extern const char *names66[];
static const uint32 types66 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags66 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype66_0 [] = {0xFF01,64,0xFFFF};
static const EIF_TYPE_INDEX g_atype66_1 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype66_2 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype66_3 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes66 [] = {
g_atype66_0,
g_atype66_1,
g_atype66_2,
g_atype66_3,
};

static const long offsets66 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
};

extern const char *names70[];
static const uint32 types70 [] =
{
SK_REF,
};

static const uint16 attr_flags70 [] =
{0,};

static const EIF_TYPE_INDEX g_atype70_0 [] = {793,0xFF01,1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes70 [] = {
g_atype70_0,
};

static const long offsets70 [] =
{
0,
};

extern const char *names71[];
static const uint32 types71 [] =
{
SK_REF,
};

static const uint16 attr_flags71 [] =
{0,};

static const EIF_TYPE_INDEX g_atype71_0 [] = {793,0xFF01,1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes71 [] = {
g_atype71_0,
};

static const long offsets71 [] =
{
0,
};

extern const char *names80[];
static const uint32 types80 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags80 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype80_0 [] = {79,0xFFFF};
static const EIF_TYPE_INDEX g_atype80_1 [] = {160,0xFFFF};
static const EIF_TYPE_INDEX g_atype80_2 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes80 [] = {
g_atype80_0,
g_atype80_1,
g_atype80_2,
};

static const long offsets80 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
};

extern const char *names81[];
static const uint32 types81 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags81 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype81_0 [] = {79,0xFFFF};
static const EIF_TYPE_INDEX g_atype81_1 [] = {161,0xFFFF};
static const EIF_TYPE_INDEX g_atype81_2 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes81 [] = {
g_atype81_0,
g_atype81_1,
g_atype81_2,
};

static const long offsets81 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
};

extern const char *names84[];
static const uint32 types84 [] =
{
SK_REF,
};

static const uint16 attr_flags84 [] =
{0,};

static const EIF_TYPE_INDEX g_atype84_0 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes84 [] = {
g_atype84_0,
};

static const long offsets84 [] =
{
0,
};

extern const char *names85[];
static const uint32 types85 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags85 [] =
{0,};

static const EIF_TYPE_INDEX g_atype85_0 [] = {989,0xFFFF};

static const EIF_TYPE_INDEX *gtypes85 [] = {
g_atype85_0,
};

static const long offsets85 [] =
{
+ @CHROFF(0,0),
};

extern const char *names86[];
static const uint32 types86 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags86 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype86_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype86_1 [] = {85,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes86 [] = {
g_atype86_0,
g_atype86_1,
};

static const long offsets86 [] =
{
0,
 + @REFACS(1),
};

extern const char *names87[];
static const uint32 types87 [] =
{
SK_REF,
SK_CHAR8,
};

static const uint16 attr_flags87 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype87_0 [] = {86,989,0xFFFF};
static const EIF_TYPE_INDEX g_atype87_1 [] = {989,0xFFFF};

static const EIF_TYPE_INDEX *gtypes87 [] = {
g_atype87_0,
g_atype87_1,
};

static const long offsets87 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names96[];
static const uint32 types96 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags96 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype96_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_2 [] = {1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes96 [] = {
g_atype96_0,
g_atype96_1,
g_atype96_2,
};

static const long offsets96 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names97[];
static const uint32 types97 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags97 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype97_0 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_1 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_2 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_3 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_4 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_5 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_6 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_7 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_8 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_9 [] = {0xFF01,706,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_10 [] = {0xFF01,706,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_11 [] = {0xFF01,706,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_12 [] = {0xFF01,706,0xFF01,1041,0xFFFF};

static const EIF_TYPE_INDEX *gtypes97 [] = {
g_atype97_0,
g_atype97_1,
g_atype97_2,
g_atype97_3,
g_atype97_4,
g_atype97_5,
g_atype97_6,
g_atype97_7,
g_atype97_8,
g_atype97_9,
g_atype97_10,
g_atype97_11,
g_atype97_12,
};

static const long offsets97 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
};

extern const char *names98[];
static const uint32 types98 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags98 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype98_0 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_1 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_2 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_3 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_4 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_5 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_6 [] = {0xFF01,709,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_7 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_8 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_9 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_10 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_11 [] = {0xFF01,709,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_12 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_13 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_14 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_15 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes98 [] = {
g_atype98_0,
g_atype98_1,
g_atype98_2,
g_atype98_3,
g_atype98_4,
g_atype98_5,
g_atype98_6,
g_atype98_7,
g_atype98_8,
g_atype98_9,
g_atype98_10,
g_atype98_11,
g_atype98_12,
g_atype98_13,
g_atype98_14,
g_atype98_15,
};

static const long offsets98 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
+ @LNGOFF(12,0,0,0),
+ @LNGOFF(12,0,0,1),
+ @LNGOFF(12,0,0,2),
+ @LNGOFF(12,0,0,3),
};

extern const char *names99[];
static const uint32 types99 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags99 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype99_0 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype99_1 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype99_2 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype99_3 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype99_4 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype99_5 [] = {0xFF01,709,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype99_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes99 [] = {
g_atype99_0,
g_atype99_1,
g_atype99_2,
g_atype99_3,
g_atype99_4,
g_atype99_5,
g_atype99_6,
};

static const long offsets99 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @LNGOFF(6,0,0,0),
};

extern const char *names100[];
static const uint32 types100 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags100 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype100_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_3 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_4 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_5 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_6 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_7 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_8 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_9 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_10 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_11 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_12 [] = {0xFF01,706,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_13 [] = {0xFF01,706,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_14 [] = {0xFF01,706,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_15 [] = {0xFF01,706,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_16 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_17 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_18 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_19 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_20 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_21 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_22 [] = {0xFF01,709,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_23 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_24 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_25 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_26 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_27 [] = {0xFF01,709,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_28 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_29 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_30 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_31 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_32 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_33 [] = {0xFF01,709,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_34 [] = {0xFF01,1043,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_35 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_36 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_37 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_38 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_39 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes100 [] = {
g_atype100_0,
g_atype100_1,
g_atype100_2,
g_atype100_3,
g_atype100_4,
g_atype100_5,
g_atype100_6,
g_atype100_7,
g_atype100_8,
g_atype100_9,
g_atype100_10,
g_atype100_11,
g_atype100_12,
g_atype100_13,
g_atype100_14,
g_atype100_15,
g_atype100_16,
g_atype100_17,
g_atype100_18,
g_atype100_19,
g_atype100_20,
g_atype100_21,
g_atype100_22,
g_atype100_23,
g_atype100_24,
g_atype100_25,
g_atype100_26,
g_atype100_27,
g_atype100_28,
g_atype100_29,
g_atype100_30,
g_atype100_31,
g_atype100_32,
g_atype100_33,
g_atype100_34,
g_atype100_35,
g_atype100_36,
g_atype100_37,
g_atype100_38,
g_atype100_39,
};

static const long offsets100 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
 + @REFACS(27),
 + @REFACS(28),
 + @REFACS(29),
 + @REFACS(30),
 + @REFACS(31),
 + @REFACS(32),
 + @REFACS(33),
 + @REFACS(34),
+ @LNGOFF(35,0,0,0),
+ @LNGOFF(35,0,0,1),
+ @LNGOFF(35,0,0,2),
+ @LNGOFF(35,0,0,3),
+ @LNGOFF(35,0,0,4),
};

extern const char *names101[];
static const uint32 types101 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags101 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype101_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype101_1 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes101 [] = {
g_atype101_0,
g_atype101_1,
};

static const long offsets101 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names102[];
static const uint32 types102 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags102 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype102_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype102_1 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes102 [] = {
g_atype102_0,
g_atype102_1,
};

static const long offsets102 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names103[];
static const uint32 types103 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags103 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype103_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype103_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype103_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes103 [] = {
g_atype103_0,
g_atype103_1,
g_atype103_2,
};

static const long offsets103 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names112[];
static const uint32 types112 [] =
{
SK_REF,
};

static const uint16 attr_flags112 [] =
{0,};

static const EIF_TYPE_INDEX g_atype112_0 [] = {0xFF01,1041,0xFFFF};

static const EIF_TYPE_INDEX *gtypes112 [] = {
g_atype112_0,
};

static const long offsets112 [] =
{
0,
};

extern const char *names113[];
static const uint32 types113 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags113 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype113_0 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype113_1 [] = {0xFF01,783,0xFF01,1032,0xFF01,1043,0xFFFF};
static const EIF_TYPE_INDEX g_atype113_2 [] = {0xFF01,793,0xFF01,1043,0xFFFF};
static const EIF_TYPE_INDEX g_atype113_3 [] = {0xFF01,783,0xFF01,1032,0xFF01,1042,0xFFFF};
static const EIF_TYPE_INDEX g_atype113_4 [] = {0xFF01,793,0xFF01,1042,0xFFFF};
static const EIF_TYPE_INDEX g_atype113_5 [] = {0xFF01,312,0xFFFF};
static const EIF_TYPE_INDEX g_atype113_6 [] = {0xFF01,79,0xFFFF};

static const EIF_TYPE_INDEX *gtypes113 [] = {
g_atype113_0,
g_atype113_1,
g_atype113_2,
g_atype113_3,
g_atype113_4,
g_atype113_5,
g_atype113_6,
};

static const long offsets113 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
};

extern const char *names114[];
static const uint32 types114 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags114 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype114_0 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype114_1 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype114_2 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype114_3 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype114_4 [] = {0xFF01,709,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype114_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes114 [] = {
g_atype114_0,
g_atype114_1,
g_atype114_2,
g_atype114_3,
g_atype114_4,
g_atype114_5,
};

static const long offsets114 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @LNGOFF(5,0,0,0),
};

extern const char *names115[];
static const uint32 types115 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags115 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype115_0 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype115_1 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype115_2 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype115_3 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype115_4 [] = {0xFF01,709,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype115_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes115 [] = {
g_atype115_0,
g_atype115_1,
g_atype115_2,
g_atype115_3,
g_atype115_4,
g_atype115_5,
};

static const long offsets115 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @LNGOFF(5,0,0,0),
};

extern const char *names122[];
static const uint32 types122 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags122 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype122_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_1 [] = {1027,0xFF01,0xFFF9,1,953,0xFF01,286,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_2 [] = {1027,0xFF01,0xFFF9,2,953,0xFF01,286,0xFF01,286,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_3 [] = {1027,0xFF01,0xFFF9,1,953,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_4 [] = {793,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_5 [] = {787,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_7 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_8 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_9 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_10 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_11 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes122 [] = {
g_atype122_0,
g_atype122_1,
g_atype122_2,
g_atype122_3,
g_atype122_4,
g_atype122_5,
g_atype122_6,
g_atype122_7,
g_atype122_8,
g_atype122_9,
g_atype122_10,
g_atype122_11,
};

static const long offsets122 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
};

extern const char *names123[];
static const uint32 types123 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags123 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype123_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype123_1 [] = {1027,0xFF01,0xFFF9,1,953,0xFF01,286,0xFFFF};
static const EIF_TYPE_INDEX g_atype123_2 [] = {1027,0xFF01,0xFFF9,2,953,0xFF01,286,0xFF01,286,0xFFFF};
static const EIF_TYPE_INDEX g_atype123_3 [] = {1027,0xFF01,0xFFF9,1,953,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype123_4 [] = {793,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype123_5 [] = {787,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype123_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype123_7 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype123_8 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype123_9 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype123_10 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype123_11 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes123 [] = {
g_atype123_0,
g_atype123_1,
g_atype123_2,
g_atype123_3,
g_atype123_4,
g_atype123_5,
g_atype123_6,
g_atype123_7,
g_atype123_8,
g_atype123_9,
g_atype123_10,
g_atype123_11,
};

static const long offsets123 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
};

extern const char *names132[];
static const uint32 types132 [] =
{
SK_UINT16,
SK_UINT16,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags132 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype132_0 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype132_1 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype132_2 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype132_3 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype132_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype132_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes132 [] = {
g_atype132_0,
g_atype132_1,
g_atype132_2,
g_atype132_3,
g_atype132_4,
g_atype132_5,
};

static const long offsets132 [] =
{
+ @I16OFF(0,0,0),
+ @I16OFF(0,0,1),
+ @I16OFF(0,0,2),
+ @LNGOFF(0,0,3,0),
+ @LNGOFF(0,0,3,1),
+ @LNGOFF(0,0,3,2),
};

extern const char *names137[];
static const uint32 types137 [] =
{
SK_REF,
};

static const uint16 attr_flags137 [] =
{0,};

static const EIF_TYPE_INDEX g_atype137_0 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes137 [] = {
g_atype137_0,
};

static const long offsets137 [] =
{
0,
};

extern const char *names138[];
static const uint32 types138 [] =
{
SK_INT32,
};

static const uint16 attr_flags138 [] =
{0,};

static const EIF_TYPE_INDEX g_atype138_0 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes138 [] = {
g_atype138_0,
};

static const long offsets138 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names139[];
static const uint32 types139 [] =
{
SK_UINT64,
};

static const uint16 attr_flags139 [] =
{0,};

static const EIF_TYPE_INDEX g_atype139_0 [] = {968,0xFFFF};

static const EIF_TYPE_INDEX *gtypes139 [] = {
g_atype139_0,
};

static const long offsets139 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names140[];
static const uint32 types140 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags140 [] =
{0,};

static const EIF_TYPE_INDEX g_atype140_0 [] = {986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes140 [] = {
g_atype140_0,
};

static const long offsets140 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names141[];
static const uint32 types141 [] =
{
SK_BOOL,
};

static const uint16 attr_flags141 [] =
{0,};

static const EIF_TYPE_INDEX g_atype141_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes141 [] = {
g_atype141_0,
};

static const long offsets141 [] =
{
+ @CHROFF(0,0),
};

extern const char *names142[];
static const uint32 types142 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags142 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype142_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_1 [] = {141,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes142 [] = {
g_atype142_0,
g_atype142_1,
};

static const long offsets142 [] =
{
0,
 + @REFACS(1),
};

extern const char *names143[];
static const uint32 types143 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags143 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype143_0 [] = {142,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype143_1 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes143 [] = {
g_atype143_0,
g_atype143_1,
};

static const long offsets143 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names144[];
static const uint32 types144 [] =
{
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags144 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype144_0 [] = {143,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_1 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes144 [] = {
g_atype144_0,
g_atype144_1,
};

static const long offsets144 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names145[];
static const uint32 types145 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags145 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype145_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype145_1 [] = {144,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype145_2 [] = {144,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes145 [] = {
g_atype145_0,
g_atype145_1,
g_atype145_2,
};

static const long offsets145 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names147[];
static const uint32 types147 [] =
{
SK_REF,
};

static const uint16 attr_flags147 [] =
{0,};

static const EIF_TYPE_INDEX g_atype147_0 [] = {0xFF01,1040,0xFFFF};

static const EIF_TYPE_INDEX *gtypes147 [] = {
g_atype147_0,
};

static const long offsets147 [] =
{
0,
};

extern const char *names154[];
static const uint32 types154 [] =
{
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags154 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype154_0 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_1 [] = {983,0xFFFF};

static const EIF_TYPE_INDEX *gtypes154 [] = {
g_atype154_0,
g_atype154_1,
};

static const long offsets154 [] =
{
+ @LNGOFF(0,0,0,0),
+ @R64OFF(0,0,0,1,0,0,0,0),
};

extern const char *names158[];
static const uint32 types158 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags158 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype158_0 [] = {0xFF01,153,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_1 [] = {0xFF01,782,0xFFFF};

static const EIF_TYPE_INDEX *gtypes158 [] = {
g_atype158_0,
g_atype158_1,
};

static const long offsets158 [] =
{
0,
 + @REFACS(1),
};

extern const char *names161[];
static const uint32 types161 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags161 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype161_0 [] = {0xFF01,821,0xFFFF};
static const EIF_TYPE_INDEX g_atype161_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype161_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype161_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes161 [] = {
g_atype161_0,
g_atype161_1,
g_atype161_2,
g_atype161_3,
};

static const long offsets161 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names162[];
static const uint32 types162 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags162 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype162_0 [] = {0xFF01,821,0xFFFF};
static const EIF_TYPE_INDEX g_atype162_1 [] = {0xFF01,0xFFF9,2,953,959,0xFF01,747,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype162_2 [] = {0xFF01,0xFFF9,2,953,959,0xFF01,747,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype162_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype162_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype162_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype162_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype162_7 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype162_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype162_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype162_10 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype162_11 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype162_12 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype162_13 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype162_14 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes162 [] = {
g_atype162_0,
g_atype162_1,
g_atype162_2,
g_atype162_3,
g_atype162_4,
g_atype162_5,
g_atype162_6,
g_atype162_7,
g_atype162_8,
g_atype162_9,
g_atype162_10,
g_atype162_11,
g_atype162_12,
g_atype162_13,
g_atype162_14,
};

static const long offsets162 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @CHROFF(3,3),
+ @CHROFF(3,4),
+ @LNGOFF(3,5,0,0),
+ @LNGOFF(3,5,0,1),
+ @LNGOFF(3,5,0,2),
+ @LNGOFF(3,5,0,3),
+ @LNGOFF(3,5,0,4),
+ @LNGOFF(3,5,0,5),
+ @LNGOFF(3,5,0,6),
};

extern const char *names163[];
static const uint32 types163 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags163 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype163_0 [] = {0xFF01,1030,0xFF01,0xFFF9,1,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes163 [] = {
g_atype163_0,
g_atype163_1,
g_atype163_2,
};

static const long offsets163 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names164[];
static const uint32 types164 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags164 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype164_0 [] = {0xFF01,1030,0xFF01,0xFFF9,1,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_1 [] = {0xFF01,706,0xFF01,279,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes164 [] = {
g_atype164_0,
g_atype164_1,
g_atype164_2,
g_atype164_3,
g_atype164_4,
};

static const long offsets164 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names165[];
static const uint32 types165 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags165 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype165_0 [] = {0xFF01,1030,0xFF01,0xFFF9,1,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes165 [] = {
g_atype165_0,
g_atype165_1,
g_atype165_2,
};

static const long offsets165 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names170[];
static const uint32 types170 [] =
{
SK_REF,
};

static const uint16 attr_flags170 [] =
{0,};

static const EIF_TYPE_INDEX g_atype170_0 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes170 [] = {
g_atype170_0,
};

static const long offsets170 [] =
{
0,
};

extern const char *names182[];
static const uint32 types182 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags182 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype182_0 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_1 [] = {839,0xFF01,842,959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes182 [] = {
g_atype182_0,
g_atype182_1,
};

static const long offsets182 [] =
{
0,
 + @REFACS(1),
};

extern const char *names183[];
static const uint32 types183 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags183 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype183_0 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_1 [] = {839,0xFF01,842,959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes183 [] = {
g_atype183_0,
g_atype183_1,
};

static const long offsets183 [] =
{
0,
 + @REFACS(1),
};

extern const char *names184[];
static const uint32 types184 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags184 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype184_0 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_1 [] = {839,0xFF01,842,959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes184 [] = {
g_atype184_0,
g_atype184_1,
};

static const long offsets184 [] =
{
0,
 + @REFACS(1),
};

extern const char *names185[];
static const uint32 types185 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags185 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype185_0 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_1 [] = {0xFF01,773,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_2 [] = {0xFF01,773,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_3 [] = {0xFF01,773,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_4 [] = {0xFF01,773,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_5 [] = {773,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_6 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes185 [] = {
g_atype185_0,
g_atype185_1,
g_atype185_2,
g_atype185_3,
g_atype185_4,
g_atype185_5,
g_atype185_6,
};

static const long offsets185 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
};

extern const char *names186[];
static const uint32 types186 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags186 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype186_0 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_1 [] = {0xFF01,773,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_2 [] = {0xFF01,773,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_3 [] = {0xFF01,773,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_4 [] = {0xFF01,773,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_5 [] = {773,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_6 [] = {0xFF01,706,0xFF01,773,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_7 [] = {0xFF01,773,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_8 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes186 [] = {
g_atype186_0,
g_atype186_1,
g_atype186_2,
g_atype186_3,
g_atype186_4,
g_atype186_5,
g_atype186_6,
g_atype186_7,
g_atype186_8,
};

static const long offsets186 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
};

extern const char *names187[];
static const uint32 types187 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags187 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype187_0 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_1 [] = {0xFF01,773,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_2 [] = {0xFF01,773,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_3 [] = {0xFF01,773,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_4 [] = {0xFF01,773,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_5 [] = {773,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_6 [] = {0xFF01,773,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_7 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes187 [] = {
g_atype187_0,
g_atype187_1,
g_atype187_2,
g_atype187_3,
g_atype187_4,
g_atype187_5,
g_atype187_6,
g_atype187_7,
};

static const long offsets187 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
};

extern const char *names188[];
static const uint32 types188 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags188 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype188_0 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_1 [] = {0xFF01,773,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_2 [] = {0xFF01,773,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_3 [] = {0xFF01,773,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_4 [] = {0xFF01,773,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_5 [] = {773,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_6 [] = {0xFF01,773,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_7 [] = {0xFF01,783,0xFF01,1041,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_8 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes188 [] = {
g_atype188_0,
g_atype188_1,
g_atype188_2,
g_atype188_3,
g_atype188_4,
g_atype188_5,
g_atype188_6,
g_atype188_7,
g_atype188_8,
};

static const long offsets188 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
};

extern const char *names190[];
static const uint32 types190 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags190 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype190_0 [] = {0xFF01,841,968,0xFFFF};
static const EIF_TYPE_INDEX g_atype190_1 [] = {0xFF01,841,968,0xFFFF};
static const EIF_TYPE_INDEX g_atype190_2 [] = {0xFF01,841,968,0xFFFF};
static const EIF_TYPE_INDEX g_atype190_3 [] = {0xFF01,841,968,0xFFFF};

static const EIF_TYPE_INDEX *gtypes190 [] = {
g_atype190_0,
g_atype190_1,
g_atype190_2,
g_atype190_3,
};

static const long offsets190 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names191[];
static const uint32 types191 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags191 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype191_0 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype191_1 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype191_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype191_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype191_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype191_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype191_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes191 [] = {
g_atype191_0,
g_atype191_1,
g_atype191_2,
g_atype191_3,
g_atype191_4,
g_atype191_5,
g_atype191_6,
};

static const long offsets191 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
+ @LNGOFF(2,2,0,1),
+ @LNGOFF(2,2,0,2),
};

extern const char *names192[];
static const uint32 types192 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL64,
SK_REAL64,
SK_REAL64,
};

static const uint16 attr_flags192 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype192_0 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_1 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_7 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_10 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_11 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_12 [] = {983,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_13 [] = {983,0xFFFF};
static const EIF_TYPE_INDEX g_atype192_14 [] = {983,0xFFFF};

static const EIF_TYPE_INDEX *gtypes192 [] = {
g_atype192_0,
g_atype192_1,
g_atype192_2,
g_atype192_3,
g_atype192_4,
g_atype192_5,
g_atype192_6,
g_atype192_7,
g_atype192_8,
g_atype192_9,
g_atype192_10,
g_atype192_11,
g_atype192_12,
g_atype192_13,
g_atype192_14,
};

static const long offsets192 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @CHROFF(2,4),
+ @CHROFF(2,5),
+ @LNGOFF(2,6,0,0),
+ @LNGOFF(2,6,0,1),
+ @LNGOFF(2,6,0,2),
+ @LNGOFF(2,6,0,3),
+ @R64OFF(2,6,0,4,0,0,0,0),
+ @R64OFF(2,6,0,4,0,0,0,1),
+ @R64OFF(2,6,0,4,0,0,0,2),
};

extern const char *names193[];
static const uint32 types193 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
SK_UINT64,
};

static const uint16 attr_flags193 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype193_0 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype193_1 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype193_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype193_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype193_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype193_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype193_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype193_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype193_8 [] = {968,0xFFFF};
static const EIF_TYPE_INDEX g_atype193_9 [] = {968,0xFFFF};

static const EIF_TYPE_INDEX *gtypes193 [] = {
g_atype193_0,
g_atype193_1,
g_atype193_2,
g_atype193_3,
g_atype193_4,
g_atype193_5,
g_atype193_6,
g_atype193_7,
g_atype193_8,
g_atype193_9,
};

static const long offsets193 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
+ @LNGOFF(2,3,0,1),
+ @LNGOFF(2,3,0,2),
+ @I64OFF(2,3,0,3,0,0,0),
+ @I64OFF(2,3,0,3,0,0,1),
};

extern const char *names194[];
static const uint32 types194 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
SK_UINT64,
};

static const uint16 attr_flags194 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype194_0 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_1 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_2 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_9 [] = {968,0xFFFF};
static const EIF_TYPE_INDEX g_atype194_10 [] = {968,0xFFFF};

static const EIF_TYPE_INDEX *gtypes194 [] = {
g_atype194_0,
g_atype194_1,
g_atype194_2,
g_atype194_3,
g_atype194_4,
g_atype194_5,
g_atype194_6,
g_atype194_7,
g_atype194_8,
g_atype194_9,
g_atype194_10,
};

static const long offsets194 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
+ @LNGOFF(2,4,0,2),
+ @I64OFF(2,4,0,3,0,0,0),
+ @I64OFF(2,4,0,3,0,0,1),
};

extern const char *names199[];
static const uint32 types199 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags199 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype199_0 [] = {0xFF01,29,0xFFFF};
static const EIF_TYPE_INDEX g_atype199_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype199_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes199 [] = {
g_atype199_0,
g_atype199_1,
g_atype199_2,
};

static const long offsets199 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names200[];
static const uint32 types200 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags200 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype200_0 [] = {0xFF01,29,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes200 [] = {
g_atype200_0,
g_atype200_1,
g_atype200_2,
};

static const long offsets200 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names201[];
static const uint32 types201 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags201 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype201_0 [] = {0xFF01,29,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_1 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes201 [] = {
g_atype201_0,
g_atype201_1,
g_atype201_2,
g_atype201_3,
};

static const long offsets201 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
};

extern const char *names202[];
static const uint32 types202 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags202 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype202_0 [] = {0xFF01,29,0xFFFF};
static const EIF_TYPE_INDEX g_atype202_1 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype202_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype202_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes202 [] = {
g_atype202_0,
g_atype202_1,
g_atype202_2,
g_atype202_3,
};

static const long offsets202 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
};

extern const char *names203[];
static const uint32 types203 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags203 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype203_0 [] = {0xFF01,119,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_9 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes203 [] = {
g_atype203_0,
g_atype203_1,
g_atype203_2,
g_atype203_3,
g_atype203_4,
g_atype203_5,
g_atype203_6,
g_atype203_7,
g_atype203_8,
g_atype203_9,
};

static const long offsets203 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @LNGOFF(1,3,0,0),
+ @LNGOFF(1,3,0,1),
+ @LNGOFF(1,3,0,2),
+ @LNGOFF(1,3,0,3),
+ @LNGOFF(1,3,0,4),
+ @LNGOFF(1,3,0,5),
};

extern const char *names204[];
static const uint32 types204 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags204 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype204_0 [] = {0xFF01,119,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_9 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes204 [] = {
g_atype204_0,
g_atype204_1,
g_atype204_2,
g_atype204_3,
g_atype204_4,
g_atype204_5,
g_atype204_6,
g_atype204_7,
g_atype204_8,
g_atype204_9,
};

static const long offsets204 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @LNGOFF(1,3,0,0),
+ @LNGOFF(1,3,0,1),
+ @LNGOFF(1,3,0,2),
+ @LNGOFF(1,3,0,3),
+ @LNGOFF(1,3,0,4),
+ @LNGOFF(1,3,0,5),
};

extern const char *names205[];
static const uint32 types205 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags205 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype205_0 [] = {0xFF01,818,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_9 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes205 [] = {
g_atype205_0,
g_atype205_1,
g_atype205_2,
g_atype205_3,
g_atype205_4,
g_atype205_5,
g_atype205_6,
g_atype205_7,
g_atype205_8,
g_atype205_9,
};

static const long offsets205 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @LNGOFF(1,3,0,0),
+ @LNGOFF(1,3,0,1),
+ @LNGOFF(1,3,0,2),
+ @LNGOFF(1,3,0,3),
+ @LNGOFF(1,3,0,4),
+ @LNGOFF(1,3,0,5),
};

extern const char *names206[];
static const uint32 types206 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags206 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype206_0 [] = {0xFF01,119,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_1 [] = {0xFF01,909,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_10 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_11 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes206 [] = {
g_atype206_0,
g_atype206_1,
g_atype206_2,
g_atype206_3,
g_atype206_4,
g_atype206_5,
g_atype206_6,
g_atype206_7,
g_atype206_8,
g_atype206_9,
g_atype206_10,
g_atype206_11,
};

static const long offsets206 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
+ @LNGOFF(2,4,0,2),
+ @LNGOFF(2,4,0,3),
+ @LNGOFF(2,4,0,4),
+ @LNGOFF(2,4,0,5),
};

extern const char *names207[];
static const uint32 types207 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags207 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype207_0 [] = {0xFF01,119,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_1 [] = {0xFF01,909,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_10 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_11 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_12 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype207_13 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes207 [] = {
g_atype207_0,
g_atype207_1,
g_atype207_2,
g_atype207_3,
g_atype207_4,
g_atype207_5,
g_atype207_6,
g_atype207_7,
g_atype207_8,
g_atype207_9,
g_atype207_10,
g_atype207_11,
g_atype207_12,
g_atype207_13,
};

static const long offsets207 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
+ @LNGOFF(2,4,0,2),
+ @LNGOFF(2,4,0,3),
+ @LNGOFF(2,4,0,4),
+ @LNGOFF(2,4,0,5),
+ @LNGOFF(2,4,0,6),
+ @LNGOFF(2,4,0,7),
};

extern const char *names208[];
static const uint32 types208 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags208 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype208_0 [] = {0xFF01,818,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_1 [] = {0xFF01,909,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_10 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_11 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_12 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_13 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype208_14 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes208 [] = {
g_atype208_0,
g_atype208_1,
g_atype208_2,
g_atype208_3,
g_atype208_4,
g_atype208_5,
g_atype208_6,
g_atype208_7,
g_atype208_8,
g_atype208_9,
g_atype208_10,
g_atype208_11,
g_atype208_12,
g_atype208_13,
g_atype208_14,
};

static const long offsets208 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @CHROFF(2,4),
+ @LNGOFF(2,5,0,0),
+ @LNGOFF(2,5,0,1),
+ @LNGOFF(2,5,0,2),
+ @LNGOFF(2,5,0,3),
+ @LNGOFF(2,5,0,4),
+ @LNGOFF(2,5,0,5),
+ @LNGOFF(2,5,0,6),
+ @LNGOFF(2,5,0,7),
};

extern const char *names212[];
static const uint32 types212 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags212 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype212_0 [] = {1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_1 [] = {1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_2 [] = {0xFF01,321,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_3 [] = {0xFF01,26,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_4 [] = {0xFF01,793,0xFF01,1197,0xFFFF};

static const EIF_TYPE_INDEX *gtypes212 [] = {
g_atype212_0,
g_atype212_1,
g_atype212_2,
g_atype212_3,
g_atype212_4,
};

static const long offsets212 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
};

extern const char *names213[];
static const uint32 types213 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags213 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype213_0 [] = {1305,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_1 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes213 [] = {
g_atype213_0,
g_atype213_1,
g_atype213_2,
g_atype213_3,
g_atype213_4,
g_atype213_5,
g_atype213_6,
};

static const long offsets213 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
+ @LNGOFF(2,2,0,1),
+ @LNGOFF(2,2,0,2),
};

extern const char *names214[];
static const uint32 types214 [] =
{
SK_BOOL,
};

static const uint16 attr_flags214 [] =
{0,};

static const EIF_TYPE_INDEX g_atype214_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes214 [] = {
g_atype214_0,
};

static const long offsets214 [] =
{
+ @CHROFF(0,0),
};

extern const char *names216[];
static const uint32 types216 [] =
{
SK_INT32,
};

static const uint16 attr_flags216 [] =
{0,};

static const EIF_TYPE_INDEX g_atype216_0 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes216 [] = {
g_atype216_0,
};

static const long offsets216 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names217[];
static const uint32 types217 [] =
{
SK_INT32,
};

static const uint16 attr_flags217 [] =
{0,};

static const EIF_TYPE_INDEX g_atype217_0 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes217 [] = {
g_atype217_0,
};

static const long offsets217 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names218[];
static const uint32 types218 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags218 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype218_0 [] = {141,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype218_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype218_2 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes218 [] = {
g_atype218_0,
g_atype218_1,
g_atype218_2,
};

static const long offsets218 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names219[];
static const uint32 types219 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags219 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype219_0 [] = {142,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype219_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype219_2 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes219 [] = {
g_atype219_0,
g_atype219_1,
g_atype219_2,
};

static const long offsets219 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names220[];
static const uint32 types220 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags220 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype220_0 [] = {143,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_2 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes220 [] = {
g_atype220_0,
g_atype220_1,
g_atype220_2,
};

static const long offsets220 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names221[];
static const uint32 types221 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags221 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype221_0 [] = {144,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_2 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes221 [] = {
g_atype221_0,
g_atype221_1,
g_atype221_2,
};

static const long offsets221 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names224[];
static const uint32 types224 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags224 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype224_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype224_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype224_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype224_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype224_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype224_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype224_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes224 [] = {
g_atype224_0,
g_atype224_1,
g_atype224_2,
g_atype224_3,
g_atype224_4,
g_atype224_5,
g_atype224_6,
};

static const long offsets224 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names225[];
static const uint32 types225 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags225 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype225_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes225 [] = {
g_atype225_0,
g_atype225_1,
g_atype225_2,
g_atype225_3,
g_atype225_4,
g_atype225_5,
g_atype225_6,
};

static const long offsets225 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names226[];
static const uint32 types226 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags226 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype226_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype226_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype226_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype226_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype226_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype226_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype226_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes226 [] = {
g_atype226_0,
g_atype226_1,
g_atype226_2,
g_atype226_3,
g_atype226_4,
g_atype226_5,
g_atype226_6,
};

static const long offsets226 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names227[];
static const uint32 types227 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags227 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype227_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype227_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype227_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype227_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype227_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype227_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype227_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes227 [] = {
g_atype227_0,
g_atype227_1,
g_atype227_2,
g_atype227_3,
g_atype227_4,
g_atype227_5,
g_atype227_6,
};

static const long offsets227 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names228[];
static const uint32 types228 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags228 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype228_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype228_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype228_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype228_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype228_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype228_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype228_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes228 [] = {
g_atype228_0,
g_atype228_1,
g_atype228_2,
g_atype228_3,
g_atype228_4,
g_atype228_5,
g_atype228_6,
};

static const long offsets228 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names229[];
static const uint32 types229 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags229 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype229_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype229_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype229_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype229_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype229_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype229_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype229_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes229 [] = {
g_atype229_0,
g_atype229_1,
g_atype229_2,
g_atype229_3,
g_atype229_4,
g_atype229_5,
g_atype229_6,
};

static const long offsets229 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names230[];
static const uint32 types230 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags230 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype230_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype230_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype230_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype230_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype230_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype230_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype230_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes230 [] = {
g_atype230_0,
g_atype230_1,
g_atype230_2,
g_atype230_3,
g_atype230_4,
g_atype230_5,
g_atype230_6,
};

static const long offsets230 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names231[];
static const uint32 types231 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags231 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype231_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype231_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype231_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype231_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype231_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype231_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype231_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype231_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype231_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype231_9 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes231 [] = {
g_atype231_0,
g_atype231_1,
g_atype231_2,
g_atype231_3,
g_atype231_4,
g_atype231_5,
g_atype231_6,
g_atype231_7,
g_atype231_8,
g_atype231_9,
};

static const long offsets231 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @LNGOFF(6,1,0,0),
+ @LNGOFF(6,1,0,1),
+ @LNGOFF(6,1,0,2),
};

extern const char *names232[];
static const uint32 types232 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags232 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype232_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype232_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype232_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype232_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype232_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype232_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype232_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype232_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes232 [] = {
g_atype232_0,
g_atype232_1,
g_atype232_2,
g_atype232_3,
g_atype232_4,
g_atype232_5,
g_atype232_6,
g_atype232_7,
};

static const long offsets232 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names233[];
static const uint32 types233 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags233 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype233_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype233_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype233_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype233_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype233_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype233_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype233_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype233_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes233 [] = {
g_atype233_0,
g_atype233_1,
g_atype233_2,
g_atype233_3,
g_atype233_4,
g_atype233_5,
g_atype233_6,
g_atype233_7,
};

static const long offsets233 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names234[];
static const uint32 types234 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags234 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype234_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes234 [] = {
g_atype234_0,
g_atype234_1,
g_atype234_2,
g_atype234_3,
g_atype234_4,
g_atype234_5,
g_atype234_6,
};

static const long offsets234 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names235[];
static const uint32 types235 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags235 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype235_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes235 [] = {
g_atype235_0,
g_atype235_1,
g_atype235_2,
g_atype235_3,
g_atype235_4,
g_atype235_5,
g_atype235_6,
};

static const long offsets235 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names236[];
static const uint32 types236 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags236 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype236_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype236_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype236_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype236_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype236_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype236_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype236_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes236 [] = {
g_atype236_0,
g_atype236_1,
g_atype236_2,
g_atype236_3,
g_atype236_4,
g_atype236_5,
g_atype236_6,
};

static const long offsets236 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names237[];
static const uint32 types237 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags237 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype237_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype237_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype237_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype237_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype237_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype237_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype237_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes237 [] = {
g_atype237_0,
g_atype237_1,
g_atype237_2,
g_atype237_3,
g_atype237_4,
g_atype237_5,
g_atype237_6,
};

static const long offsets237 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names238[];
static const uint32 types238 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags238 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype238_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes238 [] = {
g_atype238_0,
g_atype238_1,
g_atype238_2,
g_atype238_3,
g_atype238_4,
g_atype238_5,
g_atype238_6,
};

static const long offsets238 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names239[];
static const uint32 types239 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags239 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype239_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes239 [] = {
g_atype239_0,
g_atype239_1,
g_atype239_2,
g_atype239_3,
g_atype239_4,
g_atype239_5,
g_atype239_6,
};

static const long offsets239 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names240[];
static const uint32 types240 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags240 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype240_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype240_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype240_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype240_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype240_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype240_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype240_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype240_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes240 [] = {
g_atype240_0,
g_atype240_1,
g_atype240_2,
g_atype240_3,
g_atype240_4,
g_atype240_5,
g_atype240_6,
g_atype240_7,
};

static const long offsets240 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names241[];
static const uint32 types241 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags241 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype241_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype241_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype241_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype241_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype241_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype241_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype241_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes241 [] = {
g_atype241_0,
g_atype241_1,
g_atype241_2,
g_atype241_3,
g_atype241_4,
g_atype241_5,
g_atype241_6,
};

static const long offsets241 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names242[];
static const uint32 types242 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags242 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype242_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype242_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype242_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype242_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype242_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype242_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype242_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes242 [] = {
g_atype242_0,
g_atype242_1,
g_atype242_2,
g_atype242_3,
g_atype242_4,
g_atype242_5,
g_atype242_6,
};

static const long offsets242 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names243[];
static const uint32 types243 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags243 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype243_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype243_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype243_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype243_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype243_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype243_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype243_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes243 [] = {
g_atype243_0,
g_atype243_1,
g_atype243_2,
g_atype243_3,
g_atype243_4,
g_atype243_5,
g_atype243_6,
};

static const long offsets243 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names244[];
static const uint32 types244 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags244 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype244_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes244 [] = {
g_atype244_0,
g_atype244_1,
g_atype244_2,
g_atype244_3,
g_atype244_4,
g_atype244_5,
g_atype244_6,
g_atype244_7,
};

static const long offsets244 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names245[];
static const uint32 types245 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags245 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype245_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes245 [] = {
g_atype245_0,
g_atype245_1,
g_atype245_2,
g_atype245_3,
g_atype245_4,
g_atype245_5,
g_atype245_6,
};

static const long offsets245 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names246[];
static const uint32 types246 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags246 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype246_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes246 [] = {
g_atype246_0,
g_atype246_1,
g_atype246_2,
g_atype246_3,
g_atype246_4,
g_atype246_5,
g_atype246_6,
};

static const long offsets246 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names247[];
static const uint32 types247 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags247 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype247_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_8 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes247 [] = {
g_atype247_0,
g_atype247_1,
g_atype247_2,
g_atype247_3,
g_atype247_4,
g_atype247_5,
g_atype247_6,
g_atype247_7,
g_atype247_8,
};

static const long offsets247 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
+ @LNGOFF(5,1,0,2),
};

extern const char *names248[];
static const uint32 types248 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags248 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype248_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype248_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype248_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype248_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype248_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype248_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype248_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes248 [] = {
g_atype248_0,
g_atype248_1,
g_atype248_2,
g_atype248_3,
g_atype248_4,
g_atype248_5,
g_atype248_6,
};

static const long offsets248 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names249[];
static const uint32 types249 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags249 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype249_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype249_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype249_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype249_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype249_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype249_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype249_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes249 [] = {
g_atype249_0,
g_atype249_1,
g_atype249_2,
g_atype249_3,
g_atype249_4,
g_atype249_5,
g_atype249_6,
};

static const long offsets249 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names250[];
static const uint32 types250 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags250 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype250_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes250 [] = {
g_atype250_0,
g_atype250_1,
g_atype250_2,
g_atype250_3,
g_atype250_4,
g_atype250_5,
g_atype250_6,
};

static const long offsets250 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names251[];
static const uint32 types251 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags251 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype251_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype251_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype251_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype251_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype251_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype251_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype251_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes251 [] = {
g_atype251_0,
g_atype251_1,
g_atype251_2,
g_atype251_3,
g_atype251_4,
g_atype251_5,
g_atype251_6,
};

static const long offsets251 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names252[];
static const uint32 types252 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags252 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype252_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype252_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype252_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype252_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype252_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype252_5 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype252_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype252_7 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype252_8 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes252 [] = {
g_atype252_0,
g_atype252_1,
g_atype252_2,
g_atype252_3,
g_atype252_4,
g_atype252_5,
g_atype252_6,
g_atype252_7,
g_atype252_8,
};

static const long offsets252 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @LNGOFF(7,1,0,0),
};

extern const char *names253[];
static const uint32 types253 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags253 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype253_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype253_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype253_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype253_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype253_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype253_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype253_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes253 [] = {
g_atype253_0,
g_atype253_1,
g_atype253_2,
g_atype253_3,
g_atype253_4,
g_atype253_5,
g_atype253_6,
};

static const long offsets253 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names254[];
static const uint32 types254 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags254 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype254_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype254_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype254_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype254_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype254_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype254_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype254_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes254 [] = {
g_atype254_0,
g_atype254_1,
g_atype254_2,
g_atype254_3,
g_atype254_4,
g_atype254_5,
g_atype254_6,
};

static const long offsets254 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names255[];
static const uint32 types255 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags255 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype255_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype255_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype255_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype255_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype255_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype255_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype255_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes255 [] = {
g_atype255_0,
g_atype255_1,
g_atype255_2,
g_atype255_3,
g_atype255_4,
g_atype255_5,
g_atype255_6,
};

static const long offsets255 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names256[];
static const uint32 types256 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags256 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype256_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype256_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype256_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype256_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype256_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype256_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype256_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes256 [] = {
g_atype256_0,
g_atype256_1,
g_atype256_2,
g_atype256_3,
g_atype256_4,
g_atype256_5,
g_atype256_6,
};

static const long offsets256 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names257[];
static const uint32 types257 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags257 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype257_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype257_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype257_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype257_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype257_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype257_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype257_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes257 [] = {
g_atype257_0,
g_atype257_1,
g_atype257_2,
g_atype257_3,
g_atype257_4,
g_atype257_5,
g_atype257_6,
};

static const long offsets257 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names258[];
static const uint32 types258 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags258 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype258_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype258_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype258_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype258_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype258_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype258_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype258_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes258 [] = {
g_atype258_0,
g_atype258_1,
g_atype258_2,
g_atype258_3,
g_atype258_4,
g_atype258_5,
g_atype258_6,
};

static const long offsets258 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names259[];
static const uint32 types259 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags259 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype259_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype259_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype259_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype259_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype259_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype259_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype259_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes259 [] = {
g_atype259_0,
g_atype259_1,
g_atype259_2,
g_atype259_3,
g_atype259_4,
g_atype259_5,
g_atype259_6,
};

static const long offsets259 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names260[];
static const uint32 types260 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags260 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype260_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype260_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype260_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype260_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype260_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype260_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype260_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes260 [] = {
g_atype260_0,
g_atype260_1,
g_atype260_2,
g_atype260_3,
g_atype260_4,
g_atype260_5,
g_atype260_6,
};

static const long offsets260 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names261[];
static const uint32 types261 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags261 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype261_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes261 [] = {
g_atype261_0,
g_atype261_1,
g_atype261_2,
g_atype261_3,
g_atype261_4,
g_atype261_5,
g_atype261_6,
g_atype261_7,
};

static const long offsets261 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
};

extern const char *names262[];
static const uint32 types262 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags262 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype262_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes262 [] = {
g_atype262_0,
g_atype262_1,
g_atype262_2,
g_atype262_3,
g_atype262_4,
g_atype262_5,
g_atype262_6,
};

static const long offsets262 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names263[];
static const uint32 types263 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags263 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype263_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_2 [] = {223,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_3 [] = {819,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_4 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes263 [] = {
g_atype263_0,
g_atype263_1,
g_atype263_2,
g_atype263_3,
g_atype263_4,
g_atype263_5,
g_atype263_6,
};

static const long offsets263 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names265[];
static const uint32 types265 [] =
{
SK_REF,
};

static const uint16 attr_flags265 [] =
{0,};

static const EIF_TYPE_INDEX g_atype265_0 [] = {0xFF01,1028,0xFF01,0xFFF9,1,953,0xFF01,1097,0xFF01,1041,0xFFFF};

static const EIF_TYPE_INDEX *gtypes265 [] = {
g_atype265_0,
};

static const long offsets265 [] =
{
0,
};

extern const char *names266[];
static const uint32 types266 [] =
{
SK_REF,
};

static const uint16 attr_flags266 [] =
{0,};

static const EIF_TYPE_INDEX g_atype266_0 [] = {0xFF01,1041,0xFFFF};

static const EIF_TYPE_INDEX *gtypes266 [] = {
g_atype266_0,
};

static const long offsets266 [] =
{
0,
};

extern const char *names267[];
static const uint32 types267 [] =
{
SK_REF,
};

static const uint16 attr_flags267 [] =
{0,};

static const EIF_TYPE_INDEX g_atype267_0 [] = {0xFF01,1028,0xFF01,0xFFF9,1,953,0xFF01,1099,0xFF01,1041,0xFFFF};

static const EIF_TYPE_INDEX *gtypes267 [] = {
g_atype267_0,
};

static const long offsets267 [] =
{
0,
};

extern const char *names268[];
static const uint32 types268 [] =
{
SK_REF,
};

static const uint16 attr_flags268 [] =
{0,};

static const EIF_TYPE_INDEX g_atype268_0 [] = {0xFF01,773,0xFF01,263,0xFFFF};

static const EIF_TYPE_INDEX *gtypes268 [] = {
g_atype268_0,
};

static const long offsets268 [] =
{
0,
};

extern const char *names269[];
static const uint32 types269 [] =
{
SK_INT32,
};

static const uint16 attr_flags269 [] =
{0,};

static const EIF_TYPE_INDEX g_atype269_0 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes269 [] = {
g_atype269_0,
};

static const long offsets269 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names272[];
static const uint32 types272 [] =
{
SK_BOOL,
SK_INT32,
SK_POINTER,
SK_UINT64,
};

static const uint16 attr_flags272 [] =
{0,0,1,1,};

static const EIF_TYPE_INDEX g_atype272_0 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype272_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype272_2 [] = {1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype272_3 [] = {968,0xFFFF};

static const EIF_TYPE_INDEX *gtypes272 [] = {
g_atype272_0,
g_atype272_1,
g_atype272_2,
g_atype272_3,
};

static const long offsets272 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
+ @PTROFF(0,1,0,1,0,0),
+ @I64OFF(0,1,0,1,0,1,0),
};

extern const char *names274[];
static const uint32 types274 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags274 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype274_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype274_1 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes274 [] = {
g_atype274_0,
g_atype274_1,
};

static const long offsets274 [] =
{
0,
 + @REFACS(1),
};

extern const char *names276[];
static const uint32 types276 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags276 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype276_0 [] = {1097,0xFFFF};
static const EIF_TYPE_INDEX g_atype276_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype276_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype276_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes276 [] = {
g_atype276_0,
g_atype276_1,
g_atype276_2,
g_atype276_3,
};

static const long offsets276 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names277[];
static const uint32 types277 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags277 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype277_0 [] = {1102,0xFFFF};
static const EIF_TYPE_INDEX g_atype277_1 [] = {0xFF01,277,0xFFFF};
static const EIF_TYPE_INDEX g_atype277_2 [] = {0xFF01,275,0xFFFF};

static const EIF_TYPE_INDEX *gtypes277 [] = {
g_atype277_0,
g_atype277_1,
g_atype277_2,
};

static const long offsets277 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names278[];
static const uint32 types278 [] =
{
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags278 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype278_0 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_2 [] = {983,0xFFFF};

static const EIF_TYPE_INDEX *gtypes278 [] = {
g_atype278_0,
g_atype278_1,
g_atype278_2,
};

static const long offsets278 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
+ @R64OFF(0,0,0,2,0,0,0,0),
};

extern const char *names280[];
static const uint32 types280 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags280 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype280_0 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype280_1 [] = {1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype280_2 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype280_3 [] = {0xFF01,706,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype280_4 [] = {1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype280_5 [] = {1041,0xFFFF};

static const EIF_TYPE_INDEX *gtypes280 [] = {
g_atype280_0,
g_atype280_1,
g_atype280_2,
g_atype280_3,
g_atype280_4,
g_atype280_5,
};

static const long offsets280 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
};

extern const char *names281[];
static const uint32 types281 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags281 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype281_0 [] = {0xFF01,29,0xFFFF};
static const EIF_TYPE_INDEX g_atype281_1 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype281_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype281_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes281 [] = {
g_atype281_0,
g_atype281_1,
g_atype281_2,
g_atype281_3,
};

static const long offsets281 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
};

extern const char *names282[];
static const uint32 types282 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags282 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype282_0 [] = {0xFF01,29,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_1 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes282 [] = {
g_atype282_0,
g_atype282_1,
g_atype282_2,
g_atype282_3,
};

static const long offsets282 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
};

extern const char *names287[];
static const uint32 types287 [] =
{
SK_INT32,
};

static const uint16 attr_flags287 [] =
{0,};

static const EIF_TYPE_INDEX g_atype287_0 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes287 [] = {
g_atype287_0,
};

static const long offsets287 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names291[];
static const uint32 types291 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags291 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype291_0 [] = {0xFF01,286,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes291 [] = {
g_atype291_0,
g_atype291_1,
g_atype291_2,
g_atype291_3,
};

static const long offsets291 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names292[];
static const uint32 types292 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags292 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype292_0 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes292 [] = {
g_atype292_0,
g_atype292_1,
g_atype292_2,
};

static const long offsets292 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names293[];
static const uint32 types293 [] =
{
SK_REF,
};

static const uint16 attr_flags293 [] =
{0,};

static const EIF_TYPE_INDEX g_atype293_0 [] = {0xFF01,839,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes293 [] = {
g_atype293_0,
};

static const long offsets293 [] =
{
0,
};

extern const char *names294[];
static const uint32 types294 [] =
{
SK_REF,
};

static const uint16 attr_flags294 [] =
{0,};

static const EIF_TYPE_INDEX g_atype294_0 [] = {0xFF01,840,977,0xFFFF};

static const EIF_TYPE_INDEX *gtypes294 [] = {
g_atype294_0,
};

static const long offsets294 [] =
{
0,
};

extern const char *names295[];
static const uint32 types295 [] =
{
SK_REF,
};

static const uint16 attr_flags295 [] =
{0,};

static const EIF_TYPE_INDEX g_atype295_0 [] = {0xFF01,841,968,0xFFFF};

static const EIF_TYPE_INDEX *gtypes295 [] = {
g_atype295_0,
};

static const long offsets295 [] =
{
0,
};

extern const char *names296[];
static const uint32 types296 [] =
{
SK_REF,
};

static const uint16 attr_flags296 [] =
{0,};

static const EIF_TYPE_INDEX g_atype296_0 [] = {0xFF01,842,959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes296 [] = {
g_atype296_0,
};

static const long offsets296 [] =
{
0,
};

extern const char *names297[];
static const uint32 types297 [] =
{
SK_REF,
};

static const uint16 attr_flags297 [] =
{0,};

static const EIF_TYPE_INDEX g_atype297_0 [] = {0xFF01,843,974,0xFFFF};

static const EIF_TYPE_INDEX *gtypes297 [] = {
g_atype297_0,
};

static const long offsets297 [] =
{
0,
};

extern const char *names298[];
static const uint32 types298 [] =
{
SK_REF,
};

static const uint16 attr_flags298 [] =
{0,};

static const EIF_TYPE_INDEX g_atype298_0 [] = {0xFF01,844,1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes298 [] = {
g_atype298_0,
};

static const long offsets298 [] =
{
0,
};

extern const char *names299[];
static const uint32 types299 [] =
{
SK_REF,
};

static const uint16 attr_flags299 [] =
{0,};

static const EIF_TYPE_INDEX g_atype299_0 [] = {0xFF01,845,989,0xFFFF};

static const EIF_TYPE_INDEX *gtypes299 [] = {
g_atype299_0,
};

static const long offsets299 [] =
{
0,
};

extern const char *names300[];
static const uint32 types300 [] =
{
SK_REF,
};

static const uint16 attr_flags300 [] =
{0,};

static const EIF_TYPE_INDEX g_atype300_0 [] = {0xFF01,846,992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes300 [] = {
g_atype300_0,
};

static const long offsets300 [] =
{
0,
};

extern const char *names301[];
static const uint32 types301 [] =
{
SK_REF,
};

static const uint16 attr_flags301 [] =
{0,};

static const EIF_TYPE_INDEX g_atype301_0 [] = {0xFF01,847,971,0xFFFF};

static const EIF_TYPE_INDEX *gtypes301 [] = {
g_atype301_0,
};

static const long offsets301 [] =
{
0,
};

extern const char *names302[];
static const uint32 types302 [] =
{
SK_REF,
};

static const uint16 attr_flags302 [] =
{0,};

static const EIF_TYPE_INDEX g_atype302_0 [] = {0xFF01,848,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes302 [] = {
g_atype302_0,
};

static const long offsets302 [] =
{
0,
};

extern const char *names303[];
static const uint32 types303 [] =
{
SK_REF,
};

static const uint16 attr_flags303 [] =
{0,};

static const EIF_TYPE_INDEX g_atype303_0 [] = {0xFF01,849,980,0xFFFF};

static const EIF_TYPE_INDEX *gtypes303 [] = {
g_atype303_0,
};

static const long offsets303 [] =
{
0,
};

extern const char *names304[];
static const uint32 types304 [] =
{
SK_REF,
};

static const uint16 attr_flags304 [] =
{0,};

static const EIF_TYPE_INDEX g_atype304_0 [] = {0xFF01,850,983,0xFFFF};

static const EIF_TYPE_INDEX *gtypes304 [] = {
g_atype304_0,
};

static const long offsets304 [] =
{
0,
};

extern const char *names308[];
static const uint32 types308 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags308 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype308_0 [] = {0xFF01,271,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_1 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes308 [] = {
g_atype308_0,
g_atype308_1,
};

static const long offsets308 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names309[];
static const uint32 types309 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags309 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype309_0 [] = {0xFF01,840,977,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_1 [] = {1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_2 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_4 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes309 [] = {
g_atype309_0,
g_atype309_1,
g_atype309_2,
g_atype309_3,
g_atype309_4,
};

static const long offsets309 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names310[];
static const uint32 types310 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags310 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype310_0 [] = {0xFF01,840,977,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_1 [] = {1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_2 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_4 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes310 [] = {
g_atype310_0,
g_atype310_1,
g_atype310_2,
g_atype310_3,
g_atype310_4,
};

static const long offsets310 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names311[];
static const uint32 types311 [] =
{
SK_INT32,
};

static const uint16 attr_flags311 [] =
{0,};

static const EIF_TYPE_INDEX g_atype311_0 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes311 [] = {
g_atype311_0,
};

static const long offsets311 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names312[];
static const uint32 types312 [] =
{
SK_INT32,
};

static const uint16 attr_flags312 [] =
{0,};

static const EIF_TYPE_INDEX g_atype312_0 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes312 [] = {
g_atype312_0,
};

static const long offsets312 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names313[];
static const uint32 types313 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags313 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype313_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_1 [] = {0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_2 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_4 [] = {1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_5 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes313 [] = {
g_atype313_0,
g_atype313_1,
g_atype313_2,
g_atype313_3,
g_atype313_4,
g_atype313_5,
};

static const long offsets313 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @PTROFF(3,0,0,1,0,0),
+ @PTROFF(3,0,0,1,0,1),
};

extern const char *names315[];
static const uint32 types315 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
};

static const uint16 attr_flags315 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype315_0 [] = {16,0xFFFF};
static const EIF_TYPE_INDEX g_atype315_1 [] = {0xFF01,793,0xFF01,1103,0xFFFF};
static const EIF_TYPE_INDEX g_atype315_2 [] = {0xFF01,793,0xFF01,1103,0xFFFF};
static const EIF_TYPE_INDEX g_atype315_3 [] = {0xFF01,811,0xFF01,0xFFF9,1,953,971,0xFFFF};
static const EIF_TYPE_INDEX g_atype315_4 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype315_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes315 [] = {
g_atype315_0,
g_atype315_1,
g_atype315_2,
g_atype315_3,
g_atype315_4,
g_atype315_5,
};

static const long offsets315 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
};

extern const char *names316[];
static const uint32 types316 [] =
{
SK_REF,
};

static const uint16 attr_flags316 [] =
{0,};

static const EIF_TYPE_INDEX g_atype316_0 [] = {0xFF01,805,0xFFFF};

static const EIF_TYPE_INDEX *gtypes316 [] = {
g_atype316_0,
};

static const long offsets316 [] =
{
0,
};

extern const char *names320[];
static const uint32 types320 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags320 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype320_0 [] = {0xFF01,839,0xFF01,1210,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_1 [] = {0xFF01,793,0xFF01,839,0xFF01,1210,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_2 [] = {773,0xFF01,198,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_3 [] = {773,0xFF01,198,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_4 [] = {786,0xFF01,1037,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_5 [] = {779,0xFF01,281,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_6 [] = {779,0xFF01,280,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_7 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_10 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes320 [] = {
g_atype320_0,
g_atype320_1,
g_atype320_2,
g_atype320_3,
g_atype320_4,
g_atype320_5,
g_atype320_6,
g_atype320_7,
g_atype320_8,
g_atype320_9,
g_atype320_10,
};

static const long offsets320 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @LNGOFF(7,1,0,0),
+ @LNGOFF(7,1,0,1),
+ @LNGOFF(7,1,0,2),
};

extern const char *names321[];
static const uint32 types321 [] =
{
SK_REF,
SK_UINT8,
SK_INT32,
};

static const uint16 attr_flags321 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype321_0 [] = {0xFF01,1278,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_1 [] = {977,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes321 [] = {
g_atype321_0,
g_atype321_1,
g_atype321_2,
};

static const long offsets321 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names322[];
static const uint32 types322 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags322 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype322_0 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_1 [] = {1123,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes322 [] = {
g_atype322_0,
g_atype322_1,
g_atype322_2,
g_atype322_3,
g_atype322_4,
g_atype322_5,
};

static const long offsets322 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
+ @LNGOFF(2,2,0,1),
};

extern const char *names323[];
static const uint32 types323 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags323 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype323_0 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_1 [] = {1123,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes323 [] = {
g_atype323_0,
g_atype323_1,
g_atype323_2,
g_atype323_3,
g_atype323_4,
g_atype323_5,
};

static const long offsets323 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
+ @LNGOFF(2,2,0,1),
};

extern const char *names324[];
static const uint32 types324 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags324 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype324_0 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_1 [] = {1123,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes324 [] = {
g_atype324_0,
g_atype324_1,
g_atype324_2,
g_atype324_3,
g_atype324_4,
g_atype324_5,
};

static const long offsets324 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
+ @LNGOFF(2,2,0,1),
};

extern const char *names326[];
static const uint32 types326 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags326 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype326_0 [] = {0xFF01,839,0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_1 [] = {0xFF01,784,959,0xFF01,1035,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes326 [] = {
g_atype326_0,
g_atype326_1,
g_atype326_2,
g_atype326_3,
};

static const long offsets326 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
};

extern const char *names327[];
static const uint32 types327 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags327 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype327_0 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes327 [] = {
g_atype327_0,
g_atype327_1,
g_atype327_2,
g_atype327_3,
g_atype327_4,
g_atype327_5,
g_atype327_6,
g_atype327_7,
};

static const long offsets327 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @LNGOFF(1,2,0,0),
+ @LNGOFF(1,2,0,1),
+ @LNGOFF(1,2,0,2),
+ @LNGOFF(1,2,0,3),
+ @LNGOFF(1,2,0,4),
};

extern const char *names329[];
static const uint32 types329 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags329 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype329_0 [] = {0xFF01,818,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_1 [] = {0xFF01,909,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_2 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_7 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_10 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_11 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_12 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_13 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_14 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_15 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_16 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes329 [] = {
g_atype329_0,
g_atype329_1,
g_atype329_2,
g_atype329_3,
g_atype329_4,
g_atype329_5,
g_atype329_6,
g_atype329_7,
g_atype329_8,
g_atype329_9,
g_atype329_10,
g_atype329_11,
g_atype329_12,
g_atype329_13,
g_atype329_14,
g_atype329_15,
g_atype329_16,
};

static const long offsets329 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @CHROFF(3,3),
+ @CHROFF(3,4),
+ @LNGOFF(3,5,0,0),
+ @LNGOFF(3,5,0,1),
+ @LNGOFF(3,5,0,2),
+ @LNGOFF(3,5,0,3),
+ @LNGOFF(3,5,0,4),
+ @LNGOFF(3,5,0,5),
+ @LNGOFF(3,5,0,6),
+ @LNGOFF(3,5,0,7),
+ @LNGOFF(3,5,0,8),
};

extern const char *names342[];
static const uint32 types342 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags342 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype342_0 [] = {0xFF01,839,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype342_1 [] = {0xFFF5,1,0xFF01,839,0xFFF8,1,4123,0xFFFF};
static const EIF_TYPE_INDEX g_atype342_2 [] = {0xFFF5,1,0xFF01,781,0xFFF8,1,4248,0xFFFF};

static const EIF_TYPE_INDEX *gtypes342 [] = {
g_atype342_0,
g_atype342_1,
g_atype342_2,
};

static const long offsets342 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names343[];
static const uint32 types343 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags343 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype343_0 [] = {0xFF01,1045,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype343_1 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes343 [] = {
g_atype343_0,
g_atype343_1,
};

static const long offsets343 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names344[];
static const uint32 types344 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags344 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype344_0 [] = {0xFF01,1046,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype344_1 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes344 [] = {
g_atype344_0,
g_atype344_1,
};

static const long offsets344 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names345[];
static const uint32 types345 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags345 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype345_0 [] = {0xFF01,1047,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype345_1 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes345 [] = {
g_atype345_0,
g_atype345_1,
};

static const long offsets345 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names346[];
static const uint32 types346 [] =
{
SK_UINT8,
SK_POINTER,
};

static const uint16 attr_flags346 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype346_0 [] = {977,0xFFFF};
static const EIF_TYPE_INDEX g_atype346_1 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes346 [] = {
g_atype346_0,
g_atype346_1,
};

static const long offsets346 [] =
{
+ @CHROFF(0,0),
+ @PTROFF(0,1,0,0,0,0),
};

extern const char *names365[];
static const uint32 types365 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags365 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype365_0 [] = {0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype365_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype365_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype365_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes365 [] = {
g_atype365_0,
g_atype365_1,
g_atype365_2,
g_atype365_3,
};

static const long offsets365 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names397[];
static const uint32 types397 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags397 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype397_0 [] = {0xFF01,681,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype397_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype397_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype397_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype397_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype397_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype397_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes397 [] = {
g_atype397_0,
g_atype397_1,
g_atype397_2,
g_atype397_3,
g_atype397_4,
g_atype397_5,
g_atype397_6,
};

static const long offsets397 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names398[];
static const uint32 types398 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags398 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype398_0 [] = {0xFF01,682,977,0xFFFF};
static const EIF_TYPE_INDEX g_atype398_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype398_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype398_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype398_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype398_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype398_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes398 [] = {
g_atype398_0,
g_atype398_1,
g_atype398_2,
g_atype398_3,
g_atype398_4,
g_atype398_5,
g_atype398_6,
};

static const long offsets398 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names399[];
static const uint32 types399 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags399 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype399_0 [] = {0xFF01,683,968,0xFFFF};
static const EIF_TYPE_INDEX g_atype399_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype399_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype399_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype399_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype399_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype399_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes399 [] = {
g_atype399_0,
g_atype399_1,
g_atype399_2,
g_atype399_3,
g_atype399_4,
g_atype399_5,
g_atype399_6,
};

static const long offsets399 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names400[];
static const uint32 types400 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags400 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype400_0 [] = {0xFF01,684,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype400_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype400_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype400_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype400_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype400_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype400_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes400 [] = {
g_atype400_0,
g_atype400_1,
g_atype400_2,
g_atype400_3,
g_atype400_4,
g_atype400_5,
g_atype400_6,
};

static const long offsets400 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names401[];
static const uint32 types401 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags401 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype401_0 [] = {0xFF01,685,989,0xFFFF};
static const EIF_TYPE_INDEX g_atype401_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype401_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype401_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype401_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype401_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype401_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes401 [] = {
g_atype401_0,
g_atype401_1,
g_atype401_2,
g_atype401_3,
g_atype401_4,
g_atype401_5,
g_atype401_6,
};

static const long offsets401 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names402[];
static const uint32 types402 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags402 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype402_0 [] = {0xFF01,686,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype402_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype402_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype402_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype402_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype402_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype402_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes402 [] = {
g_atype402_0,
g_atype402_1,
g_atype402_2,
g_atype402_3,
g_atype402_4,
g_atype402_5,
g_atype402_6,
};

static const long offsets402 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names403[];
static const uint32 types403 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags403 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype403_0 [] = {0xFF01,687,974,0xFFFF};
static const EIF_TYPE_INDEX g_atype403_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype403_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype403_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype403_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype403_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype403_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes403 [] = {
g_atype403_0,
g_atype403_1,
g_atype403_2,
g_atype403_3,
g_atype403_4,
g_atype403_5,
g_atype403_6,
};

static const long offsets403 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names404[];
static const uint32 types404 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags404 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype404_0 [] = {0xFF01,688,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype404_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype404_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype404_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype404_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype404_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype404_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes404 [] = {
g_atype404_0,
g_atype404_1,
g_atype404_2,
g_atype404_3,
g_atype404_4,
g_atype404_5,
g_atype404_6,
};

static const long offsets404 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names405[];
static const uint32 types405 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags405 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype405_0 [] = {0xFF01,689,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype405_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype405_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype405_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype405_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype405_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype405_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes405 [] = {
g_atype405_0,
g_atype405_1,
g_atype405_2,
g_atype405_3,
g_atype405_4,
g_atype405_5,
g_atype405_6,
};

static const long offsets405 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names406[];
static const uint32 types406 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags406 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype406_0 [] = {0xFF01,690,971,0xFFFF};
static const EIF_TYPE_INDEX g_atype406_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype406_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype406_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype406_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype406_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype406_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes406 [] = {
g_atype406_0,
g_atype406_1,
g_atype406_2,
g_atype406_3,
g_atype406_4,
g_atype406_5,
g_atype406_6,
};

static const long offsets406 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names407[];
static const uint32 types407 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags407 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype407_0 [] = {0xFF01,691,980,0xFFFF};
static const EIF_TYPE_INDEX g_atype407_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype407_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype407_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype407_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype407_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype407_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes407 [] = {
g_atype407_0,
g_atype407_1,
g_atype407_2,
g_atype407_3,
g_atype407_4,
g_atype407_5,
g_atype407_6,
};

static const long offsets407 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names408[];
static const uint32 types408 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags408 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype408_0 [] = {0xFF01,692,983,0xFFFF};
static const EIF_TYPE_INDEX g_atype408_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype408_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype408_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype408_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype408_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype408_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes408 [] = {
g_atype408_0,
g_atype408_1,
g_atype408_2,
g_atype408_3,
g_atype408_4,
g_atype408_5,
g_atype408_6,
};

static const long offsets408 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names409[];
static const uint32 types409 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags409 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype409_0 [] = {0xFF01,783,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype409_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype409_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype409_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype409_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype409_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype409_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes409 [] = {
g_atype409_0,
g_atype409_1,
g_atype409_2,
g_atype409_3,
g_atype409_4,
g_atype409_5,
g_atype409_6,
};

static const long offsets409 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names410[];
static const uint32 types410 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags410 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype410_0 [] = {0xFF01,784,959,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype410_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype410_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype410_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype410_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype410_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype410_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes410 [] = {
g_atype410_0,
g_atype410_1,
g_atype410_2,
g_atype410_3,
g_atype410_4,
g_atype410_5,
g_atype410_6,
};

static const long offsets410 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names411[];
static const uint32 types411 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags411 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype411_0 [] = {0xFF01,785,1025,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype411_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype411_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype411_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype411_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype411_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype411_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes411 [] = {
g_atype411_0,
g_atype411_1,
g_atype411_2,
g_atype411_3,
g_atype411_4,
g_atype411_5,
g_atype411_6,
};

static const long offsets411 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names412[];
static const uint32 types412 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags412 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype412_0 [] = {0xFF01,786,0xFFF8,1,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype412_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype412_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype412_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype412_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype412_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype412_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes412 [] = {
g_atype412_0,
g_atype412_1,
g_atype412_2,
g_atype412_3,
g_atype412_4,
g_atype412_5,
g_atype412_6,
};

static const long offsets412 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names413[];
static const uint32 types413 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags413 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype413_0 [] = {0xFF01,787,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype413_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype413_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype413_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype413_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype413_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype413_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes413 [] = {
g_atype413_0,
g_atype413_1,
g_atype413_2,
g_atype413_3,
g_atype413_4,
g_atype413_5,
g_atype413_6,
};

static const long offsets413 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names414[];
static const uint32 types414 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags414 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype414_0 [] = {0xFF01,788,992,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype414_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype414_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype414_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype414_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype414_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype414_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes414 [] = {
g_atype414_0,
g_atype414_1,
g_atype414_2,
g_atype414_3,
g_atype414_4,
g_atype414_5,
g_atype414_6,
};

static const long offsets414 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names415[];
static const uint32 types415 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags415 [] =
{0,0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype415_0 [] = {0xFF01,773,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype415_1 [] = {141,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype415_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype415_3 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype415_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype415_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype415_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype415_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes415 [] = {
g_atype415_0,
g_atype415_1,
g_atype415_2,
g_atype415_3,
g_atype415_4,
g_atype415_5,
g_atype415_6,
g_atype415_7,
};

static const long offsets415 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
+ @LNGOFF(2,1,0,4),
};

extern const char *names416[];
static const uint32 types416 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags416 [] =
{0,0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype416_0 [] = {0xFF01,774,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype416_1 [] = {142,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype416_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype416_3 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype416_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype416_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype416_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype416_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes416 [] = {
g_atype416_0,
g_atype416_1,
g_atype416_2,
g_atype416_3,
g_atype416_4,
g_atype416_5,
g_atype416_6,
g_atype416_7,
};

static const long offsets416 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
+ @LNGOFF(2,1,0,4),
};

extern const char *names417[];
static const uint32 types417 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags417 [] =
{0,0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype417_0 [] = {0xFF01,775,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype417_1 [] = {143,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype417_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype417_3 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype417_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype417_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype417_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype417_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes417 [] = {
g_atype417_0,
g_atype417_1,
g_atype417_2,
g_atype417_3,
g_atype417_4,
g_atype417_5,
g_atype417_6,
g_atype417_7,
};

static const long offsets417 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
+ @LNGOFF(2,1,0,4),
};

extern const char *names418[];
static const uint32 types418 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags418 [] =
{0,0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype418_0 [] = {0xFF01,778,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype418_1 [] = {144,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype418_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype418_3 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype418_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype418_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype418_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype418_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes418 [] = {
g_atype418_0,
g_atype418_1,
g_atype418_2,
g_atype418_3,
g_atype418_4,
g_atype418_5,
g_atype418_6,
g_atype418_7,
};

static const long offsets418 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
+ @LNGOFF(2,1,0,4),
};

extern const char *names419[];
static const uint32 types419 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags419 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype419_0 [] = {0xFF01,839,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype419_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype419_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes419 [] = {
g_atype419_0,
g_atype419_1,
g_atype419_2,
};

static const long offsets419 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names420[];
static const uint32 types420 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags420 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype420_0 [] = {0xFF01,840,977,0xFFFF};
static const EIF_TYPE_INDEX g_atype420_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype420_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes420 [] = {
g_atype420_0,
g_atype420_1,
g_atype420_2,
};

static const long offsets420 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names421[];
static const uint32 types421 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags421 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype421_0 [] = {0xFF01,841,968,0xFFFF};
static const EIF_TYPE_INDEX g_atype421_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype421_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes421 [] = {
g_atype421_0,
g_atype421_1,
g_atype421_2,
};

static const long offsets421 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names422[];
static const uint32 types422 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags422 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype422_0 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype422_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype422_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes422 [] = {
g_atype422_0,
g_atype422_1,
g_atype422_2,
};

static const long offsets422 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names423[];
static const uint32 types423 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags423 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype423_0 [] = {0xFF01,843,974,0xFFFF};
static const EIF_TYPE_INDEX g_atype423_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype423_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes423 [] = {
g_atype423_0,
g_atype423_1,
g_atype423_2,
};

static const long offsets423 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names424[];
static const uint32 types424 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags424 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype424_0 [] = {0xFF01,844,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype424_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype424_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes424 [] = {
g_atype424_0,
g_atype424_1,
g_atype424_2,
};

static const long offsets424 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names425[];
static const uint32 types425 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags425 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype425_0 [] = {0xFF01,845,989,0xFFFF};
static const EIF_TYPE_INDEX g_atype425_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype425_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes425 [] = {
g_atype425_0,
g_atype425_1,
g_atype425_2,
};

static const long offsets425 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names426[];
static const uint32 types426 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags426 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype426_0 [] = {0xFF01,846,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype426_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype426_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes426 [] = {
g_atype426_0,
g_atype426_1,
g_atype426_2,
};

static const long offsets426 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names427[];
static const uint32 types427 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags427 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype427_0 [] = {0xFF01,847,971,0xFFFF};
static const EIF_TYPE_INDEX g_atype427_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype427_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes427 [] = {
g_atype427_0,
g_atype427_1,
g_atype427_2,
};

static const long offsets427 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names428[];
static const uint32 types428 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags428 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype428_0 [] = {0xFF01,848,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype428_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype428_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes428 [] = {
g_atype428_0,
g_atype428_1,
g_atype428_2,
};

static const long offsets428 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names429[];
static const uint32 types429 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags429 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype429_0 [] = {0xFF01,849,980,0xFFFF};
static const EIF_TYPE_INDEX g_atype429_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype429_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes429 [] = {
g_atype429_0,
g_atype429_1,
g_atype429_2,
};

static const long offsets429 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names430[];
static const uint32 types430 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags430 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype430_0 [] = {0xFF01,850,983,0xFFFF};
static const EIF_TYPE_INDEX g_atype430_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype430_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes430 [] = {
g_atype430_0,
g_atype430_1,
g_atype430_2,
};

static const long offsets430 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names431[];
static const uint32 types431 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags431 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype431_0 [] = {0xFF01,845,989,0xFFFF};
static const EIF_TYPE_INDEX g_atype431_1 [] = {0xFF01,1035,0xFFFF};
static const EIF_TYPE_INDEX g_atype431_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype431_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype431_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes431 [] = {
g_atype431_0,
g_atype431_1,
g_atype431_2,
g_atype431_3,
g_atype431_4,
};

static const long offsets431 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names432[];
static const uint32 types432 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags432 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype432_0 [] = {0xFF01,839,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype432_1 [] = {0xFF01,793,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype432_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype432_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes432 [] = {
g_atype432_0,
g_atype432_1,
g_atype432_2,
g_atype432_3,
};

static const long offsets432 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names433[];
static const uint32 types433 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags433 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype433_0 [] = {0xFF01,840,977,0xFFFF};
static const EIF_TYPE_INDEX g_atype433_1 [] = {0xFF01,794,977,0xFFFF};
static const EIF_TYPE_INDEX g_atype433_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype433_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes433 [] = {
g_atype433_0,
g_atype433_1,
g_atype433_2,
g_atype433_3,
};

static const long offsets433 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names434[];
static const uint32 types434 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags434 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype434_0 [] = {0xFF01,841,968,0xFFFF};
static const EIF_TYPE_INDEX g_atype434_1 [] = {0xFF01,795,968,0xFFFF};
static const EIF_TYPE_INDEX g_atype434_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype434_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes434 [] = {
g_atype434_0,
g_atype434_1,
g_atype434_2,
g_atype434_3,
};

static const long offsets434 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names435[];
static const uint32 types435 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags435 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype435_0 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype435_1 [] = {0xFF01,796,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype435_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype435_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes435 [] = {
g_atype435_0,
g_atype435_1,
g_atype435_2,
g_atype435_3,
};

static const long offsets435 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names436[];
static const uint32 types436 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags436 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype436_0 [] = {0xFF01,843,974,0xFFFF};
static const EIF_TYPE_INDEX g_atype436_1 [] = {0xFF01,797,974,0xFFFF};
static const EIF_TYPE_INDEX g_atype436_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype436_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes436 [] = {
g_atype436_0,
g_atype436_1,
g_atype436_2,
g_atype436_3,
};

static const long offsets436 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names437[];
static const uint32 types437 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags437 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype437_0 [] = {0xFF01,844,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype437_1 [] = {0xFF01,798,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype437_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype437_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes437 [] = {
g_atype437_0,
g_atype437_1,
g_atype437_2,
g_atype437_3,
};

static const long offsets437 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names438[];
static const uint32 types438 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags438 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype438_0 [] = {0xFF01,845,989,0xFFFF};
static const EIF_TYPE_INDEX g_atype438_1 [] = {0xFF01,799,989,0xFFFF};
static const EIF_TYPE_INDEX g_atype438_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype438_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes438 [] = {
g_atype438_0,
g_atype438_1,
g_atype438_2,
g_atype438_3,
};

static const long offsets438 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names439[];
static const uint32 types439 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags439 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype439_0 [] = {0xFF01,846,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype439_1 [] = {0xFF01,800,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype439_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype439_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes439 [] = {
g_atype439_0,
g_atype439_1,
g_atype439_2,
g_atype439_3,
};

static const long offsets439 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names440[];
static const uint32 types440 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags440 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype440_0 [] = {0xFF01,847,971,0xFFFF};
static const EIF_TYPE_INDEX g_atype440_1 [] = {0xFF01,801,971,0xFFFF};
static const EIF_TYPE_INDEX g_atype440_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype440_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes440 [] = {
g_atype440_0,
g_atype440_1,
g_atype440_2,
g_atype440_3,
};

static const long offsets440 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names441[];
static const uint32 types441 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags441 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype441_0 [] = {0xFF01,848,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype441_1 [] = {0xFF01,802,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype441_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype441_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes441 [] = {
g_atype441_0,
g_atype441_1,
g_atype441_2,
g_atype441_3,
};

static const long offsets441 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names442[];
static const uint32 types442 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags442 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype442_0 [] = {0xFF01,849,980,0xFFFF};
static const EIF_TYPE_INDEX g_atype442_1 [] = {0xFF01,803,980,0xFFFF};
static const EIF_TYPE_INDEX g_atype442_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype442_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes442 [] = {
g_atype442_0,
g_atype442_1,
g_atype442_2,
g_atype442_3,
};

static const long offsets442 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names443[];
static const uint32 types443 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags443 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype443_0 [] = {0xFF01,850,983,0xFFFF};
static const EIF_TYPE_INDEX g_atype443_1 [] = {0xFF01,804,983,0xFFFF};
static const EIF_TYPE_INDEX g_atype443_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype443_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes443 [] = {
g_atype443_0,
g_atype443_1,
g_atype443_2,
g_atype443_3,
};

static const long offsets443 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names444[];
static const uint32 types444 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags444 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype444_0 [] = {0xFF01,848,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype444_1 [] = {0xFF01,1039,0xFFFF};
static const EIF_TYPE_INDEX g_atype444_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype444_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype444_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes444 [] = {
g_atype444_0,
g_atype444_1,
g_atype444_2,
g_atype444_3,
g_atype444_4,
};

static const long offsets444 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names445[];
static const uint32 types445 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags445 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype445_0 [] = {0xFF01,839,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype445_1 [] = {0xFF01,706,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype445_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype445_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype445_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes445 [] = {
g_atype445_0,
g_atype445_1,
g_atype445_2,
g_atype445_3,
g_atype445_4,
};

static const long offsets445 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names446[];
static const uint32 types446 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags446 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype446_0 [] = {0xFF01,840,977,0xFFFF};
static const EIF_TYPE_INDEX g_atype446_1 [] = {0xFF01,707,977,0xFFFF};
static const EIF_TYPE_INDEX g_atype446_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype446_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype446_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes446 [] = {
g_atype446_0,
g_atype446_1,
g_atype446_2,
g_atype446_3,
g_atype446_4,
};

static const long offsets446 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names447[];
static const uint32 types447 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags447 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype447_0 [] = {0xFF01,841,968,0xFFFF};
static const EIF_TYPE_INDEX g_atype447_1 [] = {0xFF01,708,968,0xFFFF};
static const EIF_TYPE_INDEX g_atype447_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype447_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype447_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes447 [] = {
g_atype447_0,
g_atype447_1,
g_atype447_2,
g_atype447_3,
g_atype447_4,
};

static const long offsets447 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names448[];
static const uint32 types448 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags448 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype448_0 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_1 [] = {0xFF01,709,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes448 [] = {
g_atype448_0,
g_atype448_1,
g_atype448_2,
g_atype448_3,
g_atype448_4,
};

static const long offsets448 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names449[];
static const uint32 types449 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags449 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype449_0 [] = {0xFF01,843,974,0xFFFF};
static const EIF_TYPE_INDEX g_atype449_1 [] = {0xFF01,710,974,0xFFFF};
static const EIF_TYPE_INDEX g_atype449_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype449_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype449_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes449 [] = {
g_atype449_0,
g_atype449_1,
g_atype449_2,
g_atype449_3,
g_atype449_4,
};

static const long offsets449 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names450[];
static const uint32 types450 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags450 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype450_0 [] = {0xFF01,844,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype450_1 [] = {0xFF01,711,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype450_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype450_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype450_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes450 [] = {
g_atype450_0,
g_atype450_1,
g_atype450_2,
g_atype450_3,
g_atype450_4,
};

static const long offsets450 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names451[];
static const uint32 types451 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags451 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype451_0 [] = {0xFF01,845,989,0xFFFF};
static const EIF_TYPE_INDEX g_atype451_1 [] = {0xFF01,712,989,0xFFFF};
static const EIF_TYPE_INDEX g_atype451_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype451_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype451_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes451 [] = {
g_atype451_0,
g_atype451_1,
g_atype451_2,
g_atype451_3,
g_atype451_4,
};

static const long offsets451 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names452[];
static const uint32 types452 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags452 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype452_0 [] = {0xFF01,846,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype452_1 [] = {0xFF01,713,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype452_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype452_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype452_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes452 [] = {
g_atype452_0,
g_atype452_1,
g_atype452_2,
g_atype452_3,
g_atype452_4,
};

static const long offsets452 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names453[];
static const uint32 types453 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags453 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype453_0 [] = {0xFF01,847,971,0xFFFF};
static const EIF_TYPE_INDEX g_atype453_1 [] = {0xFF01,714,971,0xFFFF};
static const EIF_TYPE_INDEX g_atype453_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype453_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype453_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes453 [] = {
g_atype453_0,
g_atype453_1,
g_atype453_2,
g_atype453_3,
g_atype453_4,
};

static const long offsets453 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names454[];
static const uint32 types454 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags454 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype454_0 [] = {0xFF01,848,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype454_1 [] = {0xFF01,715,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype454_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype454_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype454_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes454 [] = {
g_atype454_0,
g_atype454_1,
g_atype454_2,
g_atype454_3,
g_atype454_4,
};

static const long offsets454 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names455[];
static const uint32 types455 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags455 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype455_0 [] = {0xFF01,849,980,0xFFFF};
static const EIF_TYPE_INDEX g_atype455_1 [] = {0xFF01,716,980,0xFFFF};
static const EIF_TYPE_INDEX g_atype455_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype455_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype455_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes455 [] = {
g_atype455_0,
g_atype455_1,
g_atype455_2,
g_atype455_3,
g_atype455_4,
};

static const long offsets455 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names456[];
static const uint32 types456 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags456 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype456_0 [] = {0xFF01,850,983,0xFFFF};
static const EIF_TYPE_INDEX g_atype456_1 [] = {0xFF01,717,983,0xFFFF};
static const EIF_TYPE_INDEX g_atype456_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype456_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype456_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes456 [] = {
g_atype456_0,
g_atype456_1,
g_atype456_2,
g_atype456_3,
g_atype456_4,
};

static const long offsets456 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names457[];
static const uint32 types457 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags457 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype457_0 [] = {0xFF01,839,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype457_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype457_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes457 [] = {
g_atype457_0,
g_atype457_1,
g_atype457_2,
};

static const long offsets457 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names458[];
static const uint32 types458 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags458 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype458_0 [] = {0xFF01,840,977,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes458 [] = {
g_atype458_0,
g_atype458_1,
g_atype458_2,
};

static const long offsets458 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names459[];
static const uint32 types459 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags459 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype459_0 [] = {0xFF01,841,968,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes459 [] = {
g_atype459_0,
g_atype459_1,
g_atype459_2,
};

static const long offsets459 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names460[];
static const uint32 types460 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags460 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype460_0 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes460 [] = {
g_atype460_0,
g_atype460_1,
g_atype460_2,
};

static const long offsets460 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names461[];
static const uint32 types461 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags461 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype461_0 [] = {0xFF01,843,974,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes461 [] = {
g_atype461_0,
g_atype461_1,
g_atype461_2,
};

static const long offsets461 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names462[];
static const uint32 types462 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags462 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype462_0 [] = {0xFF01,844,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype462_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype462_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes462 [] = {
g_atype462_0,
g_atype462_1,
g_atype462_2,
};

static const long offsets462 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names463[];
static const uint32 types463 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags463 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype463_0 [] = {0xFF01,845,989,0xFFFF};
static const EIF_TYPE_INDEX g_atype463_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype463_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes463 [] = {
g_atype463_0,
g_atype463_1,
g_atype463_2,
};

static const long offsets463 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names464[];
static const uint32 types464 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags464 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype464_0 [] = {0xFF01,846,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype464_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype464_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes464 [] = {
g_atype464_0,
g_atype464_1,
g_atype464_2,
};

static const long offsets464 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names465[];
static const uint32 types465 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags465 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype465_0 [] = {0xFF01,847,971,0xFFFF};
static const EIF_TYPE_INDEX g_atype465_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype465_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes465 [] = {
g_atype465_0,
g_atype465_1,
g_atype465_2,
};

static const long offsets465 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names466[];
static const uint32 types466 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags466 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype466_0 [] = {0xFF01,848,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype466_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype466_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes466 [] = {
g_atype466_0,
g_atype466_1,
g_atype466_2,
};

static const long offsets466 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names467[];
static const uint32 types467 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags467 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype467_0 [] = {0xFF01,849,980,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes467 [] = {
g_atype467_0,
g_atype467_1,
g_atype467_2,
};

static const long offsets467 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names468[];
static const uint32 types468 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags468 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype468_0 [] = {0xFF01,850,983,0xFFFF};
static const EIF_TYPE_INDEX g_atype468_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype468_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes468 [] = {
g_atype468_0,
g_atype468_1,
g_atype468_2,
};

static const long offsets468 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names470[];
static const uint32 types470 [] =
{
SK_BOOL,
};

static const uint16 attr_flags470 [] =
{0,};

static const EIF_TYPE_INDEX g_atype470_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes470 [] = {
g_atype470_0,
};

static const long offsets470 [] =
{
+ @CHROFF(0,0),
};

extern const char *names471[];
static const uint32 types471 [] =
{
SK_BOOL,
};

static const uint16 attr_flags471 [] =
{0,};

static const EIF_TYPE_INDEX g_atype471_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes471 [] = {
g_atype471_0,
};

static const long offsets471 [] =
{
+ @CHROFF(0,0),
};

extern const char *names472[];
static const uint32 types472 [] =
{
SK_BOOL,
};

static const uint16 attr_flags472 [] =
{0,};

static const EIF_TYPE_INDEX g_atype472_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes472 [] = {
g_atype472_0,
};

static const long offsets472 [] =
{
+ @CHROFF(0,0),
};

extern const char *names473[];
static const uint32 types473 [] =
{
SK_BOOL,
};

static const uint16 attr_flags473 [] =
{0,};

static const EIF_TYPE_INDEX g_atype473_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes473 [] = {
g_atype473_0,
};

static const long offsets473 [] =
{
+ @CHROFF(0,0),
};

extern const char *names474[];
static const uint32 types474 [] =
{
SK_BOOL,
};

static const uint16 attr_flags474 [] =
{0,};

static const EIF_TYPE_INDEX g_atype474_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes474 [] = {
g_atype474_0,
};

static const long offsets474 [] =
{
+ @CHROFF(0,0),
};

extern const char *names475[];
static const uint32 types475 [] =
{
SK_BOOL,
};

static const uint16 attr_flags475 [] =
{0,};

static const EIF_TYPE_INDEX g_atype475_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes475 [] = {
g_atype475_0,
};

static const long offsets475 [] =
{
+ @CHROFF(0,0),
};

extern const char *names476[];
static const uint32 types476 [] =
{
SK_BOOL,
};

static const uint16 attr_flags476 [] =
{0,};

static const EIF_TYPE_INDEX g_atype476_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes476 [] = {
g_atype476_0,
};

static const long offsets476 [] =
{
+ @CHROFF(0,0),
};

extern const char *names477[];
static const uint32 types477 [] =
{
SK_BOOL,
};

static const uint16 attr_flags477 [] =
{0,};

static const EIF_TYPE_INDEX g_atype477_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes477 [] = {
g_atype477_0,
};

static const long offsets477 [] =
{
+ @CHROFF(0,0),
};

extern const char *names478[];
static const uint32 types478 [] =
{
SK_BOOL,
};

static const uint16 attr_flags478 [] =
{0,};

static const EIF_TYPE_INDEX g_atype478_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes478 [] = {
g_atype478_0,
};

static const long offsets478 [] =
{
+ @CHROFF(0,0),
};

extern const char *names479[];
static const uint32 types479 [] =
{
SK_BOOL,
};

static const uint16 attr_flags479 [] =
{0,};

static const EIF_TYPE_INDEX g_atype479_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes479 [] = {
g_atype479_0,
};

static const long offsets479 [] =
{
+ @CHROFF(0,0),
};

extern const char *names480[];
static const uint32 types480 [] =
{
SK_BOOL,
};

static const uint16 attr_flags480 [] =
{0,};

static const EIF_TYPE_INDEX g_atype480_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes480 [] = {
g_atype480_0,
};

static const long offsets480 [] =
{
+ @CHROFF(0,0),
};

extern const char *names481[];
static const uint32 types481 [] =
{
SK_BOOL,
};

static const uint16 attr_flags481 [] =
{0,};

static const EIF_TYPE_INDEX g_atype481_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes481 [] = {
g_atype481_0,
};

static const long offsets481 [] =
{
+ @CHROFF(0,0),
};

extern const char *names482[];
static const uint32 types482 [] =
{
SK_BOOL,
};

static const uint16 attr_flags482 [] =
{0,};

static const EIF_TYPE_INDEX g_atype482_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes482 [] = {
g_atype482_0,
};

static const long offsets482 [] =
{
+ @CHROFF(0,0),
};

extern const char *names483[];
static const uint32 types483 [] =
{
SK_BOOL,
};

static const uint16 attr_flags483 [] =
{0,};

static const EIF_TYPE_INDEX g_atype483_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes483 [] = {
g_atype483_0,
};

static const long offsets483 [] =
{
+ @CHROFF(0,0),
};

extern const char *names484[];
static const uint32 types484 [] =
{
SK_BOOL,
};

static const uint16 attr_flags484 [] =
{0,};

static const EIF_TYPE_INDEX g_atype484_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes484 [] = {
g_atype484_0,
};

static const long offsets484 [] =
{
+ @CHROFF(0,0),
};

extern const char *names485[];
static const uint32 types485 [] =
{
SK_BOOL,
};

static const uint16 attr_flags485 [] =
{0,};

static const EIF_TYPE_INDEX g_atype485_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes485 [] = {
g_atype485_0,
};

static const long offsets485 [] =
{
+ @CHROFF(0,0),
};

extern const char *names486[];
static const uint32 types486 [] =
{
SK_BOOL,
};

static const uint16 attr_flags486 [] =
{0,};

static const EIF_TYPE_INDEX g_atype486_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes486 [] = {
g_atype486_0,
};

static const long offsets486 [] =
{
+ @CHROFF(0,0),
};

extern const char *names487[];
static const uint32 types487 [] =
{
SK_BOOL,
};

static const uint16 attr_flags487 [] =
{0,};

static const EIF_TYPE_INDEX g_atype487_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes487 [] = {
g_atype487_0,
};

static const long offsets487 [] =
{
+ @CHROFF(0,0),
};

extern const char *names488[];
static const uint32 types488 [] =
{
SK_BOOL,
};

static const uint16 attr_flags488 [] =
{0,};

static const EIF_TYPE_INDEX g_atype488_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes488 [] = {
g_atype488_0,
};

static const long offsets488 [] =
{
+ @CHROFF(0,0),
};

extern const char *names489[];
static const uint32 types489 [] =
{
SK_BOOL,
};

static const uint16 attr_flags489 [] =
{0,};

static const EIF_TYPE_INDEX g_atype489_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes489 [] = {
g_atype489_0,
};

static const long offsets489 [] =
{
+ @CHROFF(0,0),
};

extern const char *names490[];
static const uint32 types490 [] =
{
SK_BOOL,
};

static const uint16 attr_flags490 [] =
{0,};

static const EIF_TYPE_INDEX g_atype490_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes490 [] = {
g_atype490_0,
};

static const long offsets490 [] =
{
+ @CHROFF(0,0),
};

extern const char *names491[];
static const uint32 types491 [] =
{
SK_BOOL,
};

static const uint16 attr_flags491 [] =
{0,};

static const EIF_TYPE_INDEX g_atype491_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes491 [] = {
g_atype491_0,
};

static const long offsets491 [] =
{
+ @CHROFF(0,0),
};

extern const char *names492[];
static const uint32 types492 [] =
{
SK_BOOL,
};

static const uint16 attr_flags492 [] =
{0,};

static const EIF_TYPE_INDEX g_atype492_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes492 [] = {
g_atype492_0,
};

static const long offsets492 [] =
{
+ @CHROFF(0,0),
};

extern const char *names493[];
static const uint32 types493 [] =
{
SK_BOOL,
};

static const uint16 attr_flags493 [] =
{0,};

static const EIF_TYPE_INDEX g_atype493_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes493 [] = {
g_atype493_0,
};

static const long offsets493 [] =
{
+ @CHROFF(0,0),
};

extern const char *names494[];
static const uint32 types494 [] =
{
SK_BOOL,
};

static const uint16 attr_flags494 [] =
{0,};

static const EIF_TYPE_INDEX g_atype494_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes494 [] = {
g_atype494_0,
};

static const long offsets494 [] =
{
+ @CHROFF(0,0),
};

extern const char *names495[];
static const uint32 types495 [] =
{
SK_BOOL,
};

static const uint16 attr_flags495 [] =
{0,};

static const EIF_TYPE_INDEX g_atype495_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes495 [] = {
g_atype495_0,
};

static const long offsets495 [] =
{
+ @CHROFF(0,0),
};

extern const char *names496[];
static const uint32 types496 [] =
{
SK_BOOL,
};

static const uint16 attr_flags496 [] =
{0,};

static const EIF_TYPE_INDEX g_atype496_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes496 [] = {
g_atype496_0,
};

static const long offsets496 [] =
{
+ @CHROFF(0,0),
};

extern const char *names497[];
static const uint32 types497 [] =
{
SK_BOOL,
};

static const uint16 attr_flags497 [] =
{0,};

static const EIF_TYPE_INDEX g_atype497_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes497 [] = {
g_atype497_0,
};

static const long offsets497 [] =
{
+ @CHROFF(0,0),
};

extern const char *names498[];
static const uint32 types498 [] =
{
SK_BOOL,
};

static const uint16 attr_flags498 [] =
{0,};

static const EIF_TYPE_INDEX g_atype498_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes498 [] = {
g_atype498_0,
};

static const long offsets498 [] =
{
+ @CHROFF(0,0),
};

extern const char *names499[];
static const uint32 types499 [] =
{
SK_BOOL,
};

static const uint16 attr_flags499 [] =
{0,};

static const EIF_TYPE_INDEX g_atype499_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes499 [] = {
g_atype499_0,
};

static const long offsets499 [] =
{
+ @CHROFF(0,0),
};

extern const char *names500[];
static const uint32 types500 [] =
{
SK_BOOL,
};

static const uint16 attr_flags500 [] =
{0,};

static const EIF_TYPE_INDEX g_atype500_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes500 [] = {
g_atype500_0,
};

static const long offsets500 [] =
{
+ @CHROFF(0,0),
};

extern const char *names501[];
static const uint32 types501 [] =
{
SK_BOOL,
};

static const uint16 attr_flags501 [] =
{0,};

static const EIF_TYPE_INDEX g_atype501_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes501 [] = {
g_atype501_0,
};

static const long offsets501 [] =
{
+ @CHROFF(0,0),
};

extern const char *names502[];
static const uint32 types502 [] =
{
SK_BOOL,
};

static const uint16 attr_flags502 [] =
{0,};

static const EIF_TYPE_INDEX g_atype502_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes502 [] = {
g_atype502_0,
};

static const long offsets502 [] =
{
+ @CHROFF(0,0),
};

extern const char *names503[];
static const uint32 types503 [] =
{
SK_BOOL,
};

static const uint16 attr_flags503 [] =
{0,};

static const EIF_TYPE_INDEX g_atype503_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes503 [] = {
g_atype503_0,
};

static const long offsets503 [] =
{
+ @CHROFF(0,0),
};

extern const char *names504[];
static const uint32 types504 [] =
{
SK_BOOL,
};

static const uint16 attr_flags504 [] =
{0,};

static const EIF_TYPE_INDEX g_atype504_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes504 [] = {
g_atype504_0,
};

static const long offsets504 [] =
{
+ @CHROFF(0,0),
};

extern const char *names505[];
static const uint32 types505 [] =
{
SK_BOOL,
};

static const uint16 attr_flags505 [] =
{0,};

static const EIF_TYPE_INDEX g_atype505_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes505 [] = {
g_atype505_0,
};

static const long offsets505 [] =
{
+ @CHROFF(0,0),
};

extern const char *names506[];
static const uint32 types506 [] =
{
SK_BOOL,
};

static const uint16 attr_flags506 [] =
{0,};

static const EIF_TYPE_INDEX g_atype506_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes506 [] = {
g_atype506_0,
};

static const long offsets506 [] =
{
+ @CHROFF(0,0),
};

extern const char *names507[];
static const uint32 types507 [] =
{
SK_BOOL,
};

static const uint16 attr_flags507 [] =
{0,};

static const EIF_TYPE_INDEX g_atype507_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes507 [] = {
g_atype507_0,
};

static const long offsets507 [] =
{
+ @CHROFF(0,0),
};

extern const char *names508[];
static const uint32 types508 [] =
{
SK_BOOL,
};

static const uint16 attr_flags508 [] =
{0,};

static const EIF_TYPE_INDEX g_atype508_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes508 [] = {
g_atype508_0,
};

static const long offsets508 [] =
{
+ @CHROFF(0,0),
};

extern const char *names509[];
static const uint32 types509 [] =
{
SK_BOOL,
};

static const uint16 attr_flags509 [] =
{0,};

static const EIF_TYPE_INDEX g_atype509_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes509 [] = {
g_atype509_0,
};

static const long offsets509 [] =
{
+ @CHROFF(0,0),
};

extern const char *names510[];
static const uint32 types510 [] =
{
SK_BOOL,
};

static const uint16 attr_flags510 [] =
{0,};

static const EIF_TYPE_INDEX g_atype510_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes510 [] = {
g_atype510_0,
};

static const long offsets510 [] =
{
+ @CHROFF(0,0),
};

extern const char *names511[];
static const uint32 types511 [] =
{
SK_BOOL,
};

static const uint16 attr_flags511 [] =
{0,};

static const EIF_TYPE_INDEX g_atype511_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes511 [] = {
g_atype511_0,
};

static const long offsets511 [] =
{
+ @CHROFF(0,0),
};

extern const char *names512[];
static const uint32 types512 [] =
{
SK_BOOL,
};

static const uint16 attr_flags512 [] =
{0,};

static const EIF_TYPE_INDEX g_atype512_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes512 [] = {
g_atype512_0,
};

static const long offsets512 [] =
{
+ @CHROFF(0,0),
};

extern const char *names513[];
static const uint32 types513 [] =
{
SK_BOOL,
};

static const uint16 attr_flags513 [] =
{0,};

static const EIF_TYPE_INDEX g_atype513_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes513 [] = {
g_atype513_0,
};

static const long offsets513 [] =
{
+ @CHROFF(0,0),
};

extern const char *names514[];
static const uint32 types514 [] =
{
SK_BOOL,
};

static const uint16 attr_flags514 [] =
{0,};

static const EIF_TYPE_INDEX g_atype514_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes514 [] = {
g_atype514_0,
};

static const long offsets514 [] =
{
+ @CHROFF(0,0),
};

extern const char *names515[];
static const uint32 types515 [] =
{
SK_BOOL,
};

static const uint16 attr_flags515 [] =
{0,};

static const EIF_TYPE_INDEX g_atype515_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes515 [] = {
g_atype515_0,
};

static const long offsets515 [] =
{
+ @CHROFF(0,0),
};

extern const char *names516[];
static const uint32 types516 [] =
{
SK_BOOL,
};

static const uint16 attr_flags516 [] =
{0,};

static const EIF_TYPE_INDEX g_atype516_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes516 [] = {
g_atype516_0,
};

static const long offsets516 [] =
{
+ @CHROFF(0,0),
};

extern const char *names517[];
static const uint32 types517 [] =
{
SK_BOOL,
};

static const uint16 attr_flags517 [] =
{0,};

static const EIF_TYPE_INDEX g_atype517_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes517 [] = {
g_atype517_0,
};

static const long offsets517 [] =
{
+ @CHROFF(0,0),
};

extern const char *names518[];
static const uint32 types518 [] =
{
SK_BOOL,
};

static const uint16 attr_flags518 [] =
{0,};

static const EIF_TYPE_INDEX g_atype518_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes518 [] = {
g_atype518_0,
};

static const long offsets518 [] =
{
+ @CHROFF(0,0),
};

extern const char *names519[];
static const uint32 types519 [] =
{
SK_BOOL,
};

static const uint16 attr_flags519 [] =
{0,};

static const EIF_TYPE_INDEX g_atype519_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes519 [] = {
g_atype519_0,
};

static const long offsets519 [] =
{
+ @CHROFF(0,0),
};

extern const char *names520[];
static const uint32 types520 [] =
{
SK_BOOL,
};

static const uint16 attr_flags520 [] =
{0,};

static const EIF_TYPE_INDEX g_atype520_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes520 [] = {
g_atype520_0,
};

static const long offsets520 [] =
{
+ @CHROFF(0,0),
};

extern const char *names521[];
static const uint32 types521 [] =
{
SK_BOOL,
};

static const uint16 attr_flags521 [] =
{0,};

static const EIF_TYPE_INDEX g_atype521_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes521 [] = {
g_atype521_0,
};

static const long offsets521 [] =
{
+ @CHROFF(0,0),
};

extern const char *names522[];
static const uint32 types522 [] =
{
SK_BOOL,
};

static const uint16 attr_flags522 [] =
{0,};

static const EIF_TYPE_INDEX g_atype522_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes522 [] = {
g_atype522_0,
};

static const long offsets522 [] =
{
+ @CHROFF(0,0),
};

extern const char *names523[];
static const uint32 types523 [] =
{
SK_BOOL,
};

static const uint16 attr_flags523 [] =
{0,};

static const EIF_TYPE_INDEX g_atype523_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes523 [] = {
g_atype523_0,
};

static const long offsets523 [] =
{
+ @CHROFF(0,0),
};

extern const char *names524[];
static const uint32 types524 [] =
{
SK_BOOL,
};

static const uint16 attr_flags524 [] =
{0,};

static const EIF_TYPE_INDEX g_atype524_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes524 [] = {
g_atype524_0,
};

static const long offsets524 [] =
{
+ @CHROFF(0,0),
};

extern const char *names525[];
static const uint32 types525 [] =
{
SK_BOOL,
};

static const uint16 attr_flags525 [] =
{0,};

static const EIF_TYPE_INDEX g_atype525_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes525 [] = {
g_atype525_0,
};

static const long offsets525 [] =
{
+ @CHROFF(0,0),
};

extern const char *names526[];
static const uint32 types526 [] =
{
SK_BOOL,
};

static const uint16 attr_flags526 [] =
{0,};

static const EIF_TYPE_INDEX g_atype526_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes526 [] = {
g_atype526_0,
};

static const long offsets526 [] =
{
+ @CHROFF(0,0),
};

extern const char *names527[];
static const uint32 types527 [] =
{
SK_BOOL,
};

static const uint16 attr_flags527 [] =
{0,};

static const EIF_TYPE_INDEX g_atype527_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes527 [] = {
g_atype527_0,
};

static const long offsets527 [] =
{
+ @CHROFF(0,0),
};

extern const char *names528[];
static const uint32 types528 [] =
{
SK_BOOL,
};

static const uint16 attr_flags528 [] =
{0,};

static const EIF_TYPE_INDEX g_atype528_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes528 [] = {
g_atype528_0,
};

static const long offsets528 [] =
{
+ @CHROFF(0,0),
};

extern const char *names529[];
static const uint32 types529 [] =
{
SK_BOOL,
};

static const uint16 attr_flags529 [] =
{0,};

static const EIF_TYPE_INDEX g_atype529_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes529 [] = {
g_atype529_0,
};

static const long offsets529 [] =
{
+ @CHROFF(0,0),
};

extern const char *names530[];
static const uint32 types530 [] =
{
SK_BOOL,
};

static const uint16 attr_flags530 [] =
{0,};

static const EIF_TYPE_INDEX g_atype530_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes530 [] = {
g_atype530_0,
};

static const long offsets530 [] =
{
+ @CHROFF(0,0),
};

extern const char *names531[];
static const uint32 types531 [] =
{
SK_BOOL,
};

static const uint16 attr_flags531 [] =
{0,};

static const EIF_TYPE_INDEX g_atype531_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes531 [] = {
g_atype531_0,
};

static const long offsets531 [] =
{
+ @CHROFF(0,0),
};

extern const char *names532[];
static const uint32 types532 [] =
{
SK_BOOL,
};

static const uint16 attr_flags532 [] =
{0,};

static const EIF_TYPE_INDEX g_atype532_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes532 [] = {
g_atype532_0,
};

static const long offsets532 [] =
{
+ @CHROFF(0,0),
};

extern const char *names533[];
static const uint32 types533 [] =
{
SK_BOOL,
};

static const uint16 attr_flags533 [] =
{0,};

static const EIF_TYPE_INDEX g_atype533_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes533 [] = {
g_atype533_0,
};

static const long offsets533 [] =
{
+ @CHROFF(0,0),
};

extern const char *names534[];
static const uint32 types534 [] =
{
SK_BOOL,
};

static const uint16 attr_flags534 [] =
{0,};

static const EIF_TYPE_INDEX g_atype534_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes534 [] = {
g_atype534_0,
};

static const long offsets534 [] =
{
+ @CHROFF(0,0),
};

extern const char *names535[];
static const uint32 types535 [] =
{
SK_BOOL,
};

static const uint16 attr_flags535 [] =
{0,};

static const EIF_TYPE_INDEX g_atype535_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes535 [] = {
g_atype535_0,
};

static const long offsets535 [] =
{
+ @CHROFF(0,0),
};

extern const char *names536[];
static const uint32 types536 [] =
{
SK_BOOL,
};

static const uint16 attr_flags536 [] =
{0,};

static const EIF_TYPE_INDEX g_atype536_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes536 [] = {
g_atype536_0,
};

static const long offsets536 [] =
{
+ @CHROFF(0,0),
};

extern const char *names537[];
static const uint32 types537 [] =
{
SK_BOOL,
};

static const uint16 attr_flags537 [] =
{0,};

static const EIF_TYPE_INDEX g_atype537_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes537 [] = {
g_atype537_0,
};

static const long offsets537 [] =
{
+ @CHROFF(0,0),
};

extern const char *names538[];
static const uint32 types538 [] =
{
SK_BOOL,
};

static const uint16 attr_flags538 [] =
{0,};

static const EIF_TYPE_INDEX g_atype538_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes538 [] = {
g_atype538_0,
};

static const long offsets538 [] =
{
+ @CHROFF(0,0),
};

extern const char *names539[];
static const uint32 types539 [] =
{
SK_BOOL,
};

static const uint16 attr_flags539 [] =
{0,};

static const EIF_TYPE_INDEX g_atype539_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes539 [] = {
g_atype539_0,
};

static const long offsets539 [] =
{
+ @CHROFF(0,0),
};

extern const char *names540[];
static const uint32 types540 [] =
{
SK_BOOL,
};

static const uint16 attr_flags540 [] =
{0,};

static const EIF_TYPE_INDEX g_atype540_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes540 [] = {
g_atype540_0,
};

static const long offsets540 [] =
{
+ @CHROFF(0,0),
};

extern const char *names541[];
static const uint32 types541 [] =
{
SK_BOOL,
};

static const uint16 attr_flags541 [] =
{0,};

static const EIF_TYPE_INDEX g_atype541_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes541 [] = {
g_atype541_0,
};

static const long offsets541 [] =
{
+ @CHROFF(0,0),
};

extern const char *names542[];
static const uint32 types542 [] =
{
SK_BOOL,
};

static const uint16 attr_flags542 [] =
{0,};

static const EIF_TYPE_INDEX g_atype542_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes542 [] = {
g_atype542_0,
};

static const long offsets542 [] =
{
+ @CHROFF(0,0),
};

extern const char *names543[];
static const uint32 types543 [] =
{
SK_BOOL,
};

static const uint16 attr_flags543 [] =
{0,};

static const EIF_TYPE_INDEX g_atype543_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes543 [] = {
g_atype543_0,
};

static const long offsets543 [] =
{
+ @CHROFF(0,0),
};

extern const char *names544[];
static const uint32 types544 [] =
{
SK_BOOL,
};

static const uint16 attr_flags544 [] =
{0,};

static const EIF_TYPE_INDEX g_atype544_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes544 [] = {
g_atype544_0,
};

static const long offsets544 [] =
{
+ @CHROFF(0,0),
};

extern const char *names545[];
static const uint32 types545 [] =
{
SK_BOOL,
};

static const uint16 attr_flags545 [] =
{0,};

static const EIF_TYPE_INDEX g_atype545_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes545 [] = {
g_atype545_0,
};

static const long offsets545 [] =
{
+ @CHROFF(0,0),
};

extern const char *names546[];
static const uint32 types546 [] =
{
SK_BOOL,
};

static const uint16 attr_flags546 [] =
{0,};

static const EIF_TYPE_INDEX g_atype546_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes546 [] = {
g_atype546_0,
};

static const long offsets546 [] =
{
+ @CHROFF(0,0),
};

extern const char *names547[];
static const uint32 types547 [] =
{
SK_BOOL,
};

static const uint16 attr_flags547 [] =
{0,};

static const EIF_TYPE_INDEX g_atype547_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes547 [] = {
g_atype547_0,
};

static const long offsets547 [] =
{
+ @CHROFF(0,0),
};

extern const char *names548[];
static const uint32 types548 [] =
{
SK_BOOL,
};

static const uint16 attr_flags548 [] =
{0,};

static const EIF_TYPE_INDEX g_atype548_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes548 [] = {
g_atype548_0,
};

static const long offsets548 [] =
{
+ @CHROFF(0,0),
};

extern const char *names549[];
static const uint32 types549 [] =
{
SK_BOOL,
};

static const uint16 attr_flags549 [] =
{0,};

static const EIF_TYPE_INDEX g_atype549_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes549 [] = {
g_atype549_0,
};

static const long offsets549 [] =
{
+ @CHROFF(0,0),
};

extern const char *names550[];
static const uint32 types550 [] =
{
SK_BOOL,
};

static const uint16 attr_flags550 [] =
{0,};

static const EIF_TYPE_INDEX g_atype550_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes550 [] = {
g_atype550_0,
};

static const long offsets550 [] =
{
+ @CHROFF(0,0),
};

extern const char *names551[];
static const uint32 types551 [] =
{
SK_BOOL,
};

static const uint16 attr_flags551 [] =
{0,};

static const EIF_TYPE_INDEX g_atype551_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes551 [] = {
g_atype551_0,
};

static const long offsets551 [] =
{
+ @CHROFF(0,0),
};

extern const char *names552[];
static const uint32 types552 [] =
{
SK_BOOL,
};

static const uint16 attr_flags552 [] =
{0,};

static const EIF_TYPE_INDEX g_atype552_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes552 [] = {
g_atype552_0,
};

static const long offsets552 [] =
{
+ @CHROFF(0,0),
};

extern const char *names553[];
static const uint32 types553 [] =
{
SK_BOOL,
};

static const uint16 attr_flags553 [] =
{0,};

static const EIF_TYPE_INDEX g_atype553_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes553 [] = {
g_atype553_0,
};

static const long offsets553 [] =
{
+ @CHROFF(0,0),
};

extern const char *names554[];
static const uint32 types554 [] =
{
SK_BOOL,
};

static const uint16 attr_flags554 [] =
{0,};

static const EIF_TYPE_INDEX g_atype554_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes554 [] = {
g_atype554_0,
};

static const long offsets554 [] =
{
+ @CHROFF(0,0),
};

extern const char *names555[];
static const uint32 types555 [] =
{
SK_BOOL,
};

static const uint16 attr_flags555 [] =
{0,};

static const EIF_TYPE_INDEX g_atype555_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes555 [] = {
g_atype555_0,
};

static const long offsets555 [] =
{
+ @CHROFF(0,0),
};

extern const char *names556[];
static const uint32 types556 [] =
{
SK_BOOL,
};

static const uint16 attr_flags556 [] =
{0,};

static const EIF_TYPE_INDEX g_atype556_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes556 [] = {
g_atype556_0,
};

static const long offsets556 [] =
{
+ @CHROFF(0,0),
};

extern const char *names557[];
static const uint32 types557 [] =
{
SK_BOOL,
};

static const uint16 attr_flags557 [] =
{0,};

static const EIF_TYPE_INDEX g_atype557_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes557 [] = {
g_atype557_0,
};

static const long offsets557 [] =
{
+ @CHROFF(0,0),
};

extern const char *names558[];
static const uint32 types558 [] =
{
SK_BOOL,
};

static const uint16 attr_flags558 [] =
{0,};

static const EIF_TYPE_INDEX g_atype558_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes558 [] = {
g_atype558_0,
};

static const long offsets558 [] =
{
+ @CHROFF(0,0),
};

extern const char *names559[];
static const uint32 types559 [] =
{
SK_BOOL,
};

static const uint16 attr_flags559 [] =
{0,};

static const EIF_TYPE_INDEX g_atype559_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes559 [] = {
g_atype559_0,
};

static const long offsets559 [] =
{
+ @CHROFF(0,0),
};

extern const char *names560[];
static const uint32 types560 [] =
{
SK_BOOL,
};

static const uint16 attr_flags560 [] =
{0,};

static const EIF_TYPE_INDEX g_atype560_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes560 [] = {
g_atype560_0,
};

static const long offsets560 [] =
{
+ @CHROFF(0,0),
};

extern const char *names561[];
static const uint32 types561 [] =
{
SK_BOOL,
};

static const uint16 attr_flags561 [] =
{0,};

static const EIF_TYPE_INDEX g_atype561_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes561 [] = {
g_atype561_0,
};

static const long offsets561 [] =
{
+ @CHROFF(0,0),
};

extern const char *names562[];
static const uint32 types562 [] =
{
SK_BOOL,
};

static const uint16 attr_flags562 [] =
{0,};

static const EIF_TYPE_INDEX g_atype562_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes562 [] = {
g_atype562_0,
};

static const long offsets562 [] =
{
+ @CHROFF(0,0),
};

extern const char *names563[];
static const uint32 types563 [] =
{
SK_BOOL,
};

static const uint16 attr_flags563 [] =
{0,};

static const EIF_TYPE_INDEX g_atype563_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes563 [] = {
g_atype563_0,
};

static const long offsets563 [] =
{
+ @CHROFF(0,0),
};

extern const char *names564[];
static const uint32 types564 [] =
{
SK_BOOL,
};

static const uint16 attr_flags564 [] =
{0,};

static const EIF_TYPE_INDEX g_atype564_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes564 [] = {
g_atype564_0,
};

static const long offsets564 [] =
{
+ @CHROFF(0,0),
};

extern const char *names565[];
static const uint32 types565 [] =
{
SK_BOOL,
};

static const uint16 attr_flags565 [] =
{0,};

static const EIF_TYPE_INDEX g_atype565_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes565 [] = {
g_atype565_0,
};

static const long offsets565 [] =
{
+ @CHROFF(0,0),
};

extern const char *names566[];
static const uint32 types566 [] =
{
SK_BOOL,
};

static const uint16 attr_flags566 [] =
{0,};

static const EIF_TYPE_INDEX g_atype566_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes566 [] = {
g_atype566_0,
};

static const long offsets566 [] =
{
+ @CHROFF(0,0),
};

extern const char *names567[];
static const uint32 types567 [] =
{
SK_BOOL,
};

static const uint16 attr_flags567 [] =
{0,};

static const EIF_TYPE_INDEX g_atype567_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes567 [] = {
g_atype567_0,
};

static const long offsets567 [] =
{
+ @CHROFF(0,0),
};

extern const char *names568[];
static const uint32 types568 [] =
{
SK_BOOL,
};

static const uint16 attr_flags568 [] =
{0,};

static const EIF_TYPE_INDEX g_atype568_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes568 [] = {
g_atype568_0,
};

static const long offsets568 [] =
{
+ @CHROFF(0,0),
};

extern const char *names569[];
static const uint32 types569 [] =
{
SK_BOOL,
};

static const uint16 attr_flags569 [] =
{0,};

static const EIF_TYPE_INDEX g_atype569_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes569 [] = {
g_atype569_0,
};

static const long offsets569 [] =
{
+ @CHROFF(0,0),
};

extern const char *names570[];
static const uint32 types570 [] =
{
SK_BOOL,
};

static const uint16 attr_flags570 [] =
{0,};

static const EIF_TYPE_INDEX g_atype570_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes570 [] = {
g_atype570_0,
};

static const long offsets570 [] =
{
+ @CHROFF(0,0),
};

extern const char *names571[];
static const uint32 types571 [] =
{
SK_BOOL,
};

static const uint16 attr_flags571 [] =
{0,};

static const EIF_TYPE_INDEX g_atype571_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes571 [] = {
g_atype571_0,
};

static const long offsets571 [] =
{
+ @CHROFF(0,0),
};

extern const char *names572[];
static const uint32 types572 [] =
{
SK_BOOL,
};

static const uint16 attr_flags572 [] =
{0,};

static const EIF_TYPE_INDEX g_atype572_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes572 [] = {
g_atype572_0,
};

static const long offsets572 [] =
{
+ @CHROFF(0,0),
};

extern const char *names573[];
static const uint32 types573 [] =
{
SK_BOOL,
};

static const uint16 attr_flags573 [] =
{0,};

static const EIF_TYPE_INDEX g_atype573_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes573 [] = {
g_atype573_0,
};

static const long offsets573 [] =
{
+ @CHROFF(0,0),
};

extern const char *names574[];
static const uint32 types574 [] =
{
SK_BOOL,
};

static const uint16 attr_flags574 [] =
{0,};

static const EIF_TYPE_INDEX g_atype574_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes574 [] = {
g_atype574_0,
};

static const long offsets574 [] =
{
+ @CHROFF(0,0),
};

extern const char *names575[];
static const uint32 types575 [] =
{
SK_BOOL,
};

static const uint16 attr_flags575 [] =
{0,};

static const EIF_TYPE_INDEX g_atype575_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes575 [] = {
g_atype575_0,
};

static const long offsets575 [] =
{
+ @CHROFF(0,0),
};

extern const char *names576[];
static const uint32 types576 [] =
{
SK_BOOL,
};

static const uint16 attr_flags576 [] =
{0,};

static const EIF_TYPE_INDEX g_atype576_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes576 [] = {
g_atype576_0,
};

static const long offsets576 [] =
{
+ @CHROFF(0,0),
};

extern const char *names577[];
static const uint32 types577 [] =
{
SK_BOOL,
};

static const uint16 attr_flags577 [] =
{0,};

static const EIF_TYPE_INDEX g_atype577_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes577 [] = {
g_atype577_0,
};

static const long offsets577 [] =
{
+ @CHROFF(0,0),
};

extern const char *names578[];
static const uint32 types578 [] =
{
SK_BOOL,
};

static const uint16 attr_flags578 [] =
{0,};

static const EIF_TYPE_INDEX g_atype578_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes578 [] = {
g_atype578_0,
};

static const long offsets578 [] =
{
+ @CHROFF(0,0),
};

extern const char *names579[];
static const uint32 types579 [] =
{
SK_BOOL,
};

static const uint16 attr_flags579 [] =
{0,};

static const EIF_TYPE_INDEX g_atype579_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes579 [] = {
g_atype579_0,
};

static const long offsets579 [] =
{
+ @CHROFF(0,0),
};

extern const char *names580[];
static const uint32 types580 [] =
{
SK_BOOL,
};

static const uint16 attr_flags580 [] =
{0,};

static const EIF_TYPE_INDEX g_atype580_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes580 [] = {
g_atype580_0,
};

static const long offsets580 [] =
{
+ @CHROFF(0,0),
};

extern const char *names581[];
static const uint32 types581 [] =
{
SK_BOOL,
};

static const uint16 attr_flags581 [] =
{0,};

static const EIF_TYPE_INDEX g_atype581_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes581 [] = {
g_atype581_0,
};

static const long offsets581 [] =
{
+ @CHROFF(0,0),
};

extern const char *names582[];
static const uint32 types582 [] =
{
SK_BOOL,
};

static const uint16 attr_flags582 [] =
{0,};

static const EIF_TYPE_INDEX g_atype582_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes582 [] = {
g_atype582_0,
};

static const long offsets582 [] =
{
+ @CHROFF(0,0),
};

extern const char *names583[];
static const uint32 types583 [] =
{
SK_BOOL,
};

static const uint16 attr_flags583 [] =
{0,};

static const EIF_TYPE_INDEX g_atype583_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes583 [] = {
g_atype583_0,
};

static const long offsets583 [] =
{
+ @CHROFF(0,0),
};

extern const char *names584[];
static const uint32 types584 [] =
{
SK_BOOL,
};

static const uint16 attr_flags584 [] =
{0,};

static const EIF_TYPE_INDEX g_atype584_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes584 [] = {
g_atype584_0,
};

static const long offsets584 [] =
{
+ @CHROFF(0,0),
};

extern const char *names585[];
static const uint32 types585 [] =
{
SK_BOOL,
};

static const uint16 attr_flags585 [] =
{0,};

static const EIF_TYPE_INDEX g_atype585_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes585 [] = {
g_atype585_0,
};

static const long offsets585 [] =
{
+ @CHROFF(0,0),
};

extern const char *names586[];
static const uint32 types586 [] =
{
SK_BOOL,
};

static const uint16 attr_flags586 [] =
{0,};

static const EIF_TYPE_INDEX g_atype586_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes586 [] = {
g_atype586_0,
};

static const long offsets586 [] =
{
+ @CHROFF(0,0),
};

extern const char *names587[];
static const uint32 types587 [] =
{
SK_BOOL,
};

static const uint16 attr_flags587 [] =
{0,};

static const EIF_TYPE_INDEX g_atype587_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes587 [] = {
g_atype587_0,
};

static const long offsets587 [] =
{
+ @CHROFF(0,0),
};

extern const char *names588[];
static const uint32 types588 [] =
{
SK_BOOL,
};

static const uint16 attr_flags588 [] =
{0,};

static const EIF_TYPE_INDEX g_atype588_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes588 [] = {
g_atype588_0,
};

static const long offsets588 [] =
{
+ @CHROFF(0,0),
};

extern const char *names589[];
static const uint32 types589 [] =
{
SK_BOOL,
};

static const uint16 attr_flags589 [] =
{0,};

static const EIF_TYPE_INDEX g_atype589_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes589 [] = {
g_atype589_0,
};

static const long offsets589 [] =
{
+ @CHROFF(0,0),
};

extern const char *names590[];
static const uint32 types590 [] =
{
SK_BOOL,
};

static const uint16 attr_flags590 [] =
{0,};

static const EIF_TYPE_INDEX g_atype590_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes590 [] = {
g_atype590_0,
};

static const long offsets590 [] =
{
+ @CHROFF(0,0),
};

extern const char *names591[];
static const uint32 types591 [] =
{
SK_BOOL,
};

static const uint16 attr_flags591 [] =
{0,};

static const EIF_TYPE_INDEX g_atype591_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes591 [] = {
g_atype591_0,
};

static const long offsets591 [] =
{
+ @CHROFF(0,0),
};

extern const char *names592[];
static const uint32 types592 [] =
{
SK_BOOL,
};

static const uint16 attr_flags592 [] =
{0,};

static const EIF_TYPE_INDEX g_atype592_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes592 [] = {
g_atype592_0,
};

static const long offsets592 [] =
{
+ @CHROFF(0,0),
};

extern const char *names593[];
static const uint32 types593 [] =
{
SK_BOOL,
};

static const uint16 attr_flags593 [] =
{0,};

static const EIF_TYPE_INDEX g_atype593_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes593 [] = {
g_atype593_0,
};

static const long offsets593 [] =
{
+ @CHROFF(0,0),
};

extern const char *names594[];
static const uint32 types594 [] =
{
SK_BOOL,
};

static const uint16 attr_flags594 [] =
{0,};

static const EIF_TYPE_INDEX g_atype594_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes594 [] = {
g_atype594_0,
};

static const long offsets594 [] =
{
+ @CHROFF(0,0),
};

extern const char *names595[];
static const uint32 types595 [] =
{
SK_BOOL,
};

static const uint16 attr_flags595 [] =
{0,};

static const EIF_TYPE_INDEX g_atype595_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes595 [] = {
g_atype595_0,
};

static const long offsets595 [] =
{
+ @CHROFF(0,0),
};

extern const char *names596[];
static const uint32 types596 [] =
{
SK_BOOL,
};

static const uint16 attr_flags596 [] =
{0,};

static const EIF_TYPE_INDEX g_atype596_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes596 [] = {
g_atype596_0,
};

static const long offsets596 [] =
{
+ @CHROFF(0,0),
};

extern const char *names597[];
static const uint32 types597 [] =
{
SK_BOOL,
};

static const uint16 attr_flags597 [] =
{0,};

static const EIF_TYPE_INDEX g_atype597_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes597 [] = {
g_atype597_0,
};

static const long offsets597 [] =
{
+ @CHROFF(0,0),
};

extern const char *names598[];
static const uint32 types598 [] =
{
SK_BOOL,
};

static const uint16 attr_flags598 [] =
{0,};

static const EIF_TYPE_INDEX g_atype598_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes598 [] = {
g_atype598_0,
};

static const long offsets598 [] =
{
+ @CHROFF(0,0),
};

extern const char *names599[];
static const uint32 types599 [] =
{
SK_BOOL,
};

static const uint16 attr_flags599 [] =
{0,};

static const EIF_TYPE_INDEX g_atype599_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes599 [] = {
g_atype599_0,
};

static const long offsets599 [] =
{
+ @CHROFF(0,0),
};

extern const char *names600[];
static const uint32 types600 [] =
{
SK_BOOL,
};

static const uint16 attr_flags600 [] =
{0,};

static const EIF_TYPE_INDEX g_atype600_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes600 [] = {
g_atype600_0,
};

static const long offsets600 [] =
{
+ @CHROFF(0,0),
};

extern const char *names601[];
static const uint32 types601 [] =
{
SK_BOOL,
};

static const uint16 attr_flags601 [] =
{0,};

static const EIF_TYPE_INDEX g_atype601_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes601 [] = {
g_atype601_0,
};

static const long offsets601 [] =
{
+ @CHROFF(0,0),
};

extern const char *names602[];
static const uint32 types602 [] =
{
SK_BOOL,
};

static const uint16 attr_flags602 [] =
{0,};

static const EIF_TYPE_INDEX g_atype602_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes602 [] = {
g_atype602_0,
};

static const long offsets602 [] =
{
+ @CHROFF(0,0),
};

extern const char *names603[];
static const uint32 types603 [] =
{
SK_BOOL,
};

static const uint16 attr_flags603 [] =
{0,};

static const EIF_TYPE_INDEX g_atype603_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes603 [] = {
g_atype603_0,
};

static const long offsets603 [] =
{
+ @CHROFF(0,0),
};

extern const char *names604[];
static const uint32 types604 [] =
{
SK_BOOL,
};

static const uint16 attr_flags604 [] =
{0,};

static const EIF_TYPE_INDEX g_atype604_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes604 [] = {
g_atype604_0,
};

static const long offsets604 [] =
{
+ @CHROFF(0,0),
};

extern const char *names605[];
static const uint32 types605 [] =
{
SK_BOOL,
};

static const uint16 attr_flags605 [] =
{0,};

static const EIF_TYPE_INDEX g_atype605_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes605 [] = {
g_atype605_0,
};

static const long offsets605 [] =
{
+ @CHROFF(0,0),
};

extern const char *names606[];
static const uint32 types606 [] =
{
SK_BOOL,
};

static const uint16 attr_flags606 [] =
{0,};

static const EIF_TYPE_INDEX g_atype606_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes606 [] = {
g_atype606_0,
};

static const long offsets606 [] =
{
+ @CHROFF(0,0),
};

extern const char *names607[];
static const uint32 types607 [] =
{
SK_BOOL,
};

static const uint16 attr_flags607 [] =
{0,};

static const EIF_TYPE_INDEX g_atype607_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes607 [] = {
g_atype607_0,
};

static const long offsets607 [] =
{
+ @CHROFF(0,0),
};

extern const char *names608[];
static const uint32 types608 [] =
{
SK_BOOL,
};

static const uint16 attr_flags608 [] =
{0,};

static const EIF_TYPE_INDEX g_atype608_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes608 [] = {
g_atype608_0,
};

static const long offsets608 [] =
{
+ @CHROFF(0,0),
};

extern const char *names609[];
static const uint32 types609 [] =
{
SK_BOOL,
};

static const uint16 attr_flags609 [] =
{0,};

static const EIF_TYPE_INDEX g_atype609_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes609 [] = {
g_atype609_0,
};

static const long offsets609 [] =
{
+ @CHROFF(0,0),
};

extern const char *names610[];
static const uint32 types610 [] =
{
SK_BOOL,
};

static const uint16 attr_flags610 [] =
{0,};

static const EIF_TYPE_INDEX g_atype610_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes610 [] = {
g_atype610_0,
};

static const long offsets610 [] =
{
+ @CHROFF(0,0),
};

extern const char *names611[];
static const uint32 types611 [] =
{
SK_BOOL,
};

static const uint16 attr_flags611 [] =
{0,};

static const EIF_TYPE_INDEX g_atype611_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes611 [] = {
g_atype611_0,
};

static const long offsets611 [] =
{
+ @CHROFF(0,0),
};

extern const char *names612[];
static const uint32 types612 [] =
{
SK_BOOL,
};

static const uint16 attr_flags612 [] =
{0,};

static const EIF_TYPE_INDEX g_atype612_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes612 [] = {
g_atype612_0,
};

static const long offsets612 [] =
{
+ @CHROFF(0,0),
};

extern const char *names613[];
static const uint32 types613 [] =
{
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags613 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype613_0 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype613_1 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes613 [] = {
g_atype613_0,
g_atype613_1,
};

static const long offsets613 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
};

extern const char *names614[];
static const uint32 types614 [] =
{
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags614 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype614_0 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype614_1 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes614 [] = {
g_atype614_0,
g_atype614_1,
};

static const long offsets614 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
};

extern const char *names615[];
static const uint32 types615 [] =
{
SK_BOOL,
};

static const uint16 attr_flags615 [] =
{0,};

static const EIF_TYPE_INDEX g_atype615_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes615 [] = {
g_atype615_0,
};

static const long offsets615 [] =
{
+ @CHROFF(0,0),
};

extern const char *names616[];
static const uint32 types616 [] =
{
SK_BOOL,
};

static const uint16 attr_flags616 [] =
{0,};

static const EIF_TYPE_INDEX g_atype616_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes616 [] = {
g_atype616_0,
};

static const long offsets616 [] =
{
+ @CHROFF(0,0),
};

extern const char *names617[];
static const uint32 types617 [] =
{
SK_BOOL,
};

static const uint16 attr_flags617 [] =
{0,};

static const EIF_TYPE_INDEX g_atype617_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes617 [] = {
g_atype617_0,
};

static const long offsets617 [] =
{
+ @CHROFF(0,0),
};

extern const char *names618[];
static const uint32 types618 [] =
{
SK_BOOL,
};

static const uint16 attr_flags618 [] =
{0,};

static const EIF_TYPE_INDEX g_atype618_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes618 [] = {
g_atype618_0,
};

static const long offsets618 [] =
{
+ @CHROFF(0,0),
};

extern const char *names619[];
static const uint32 types619 [] =
{
SK_BOOL,
};

static const uint16 attr_flags619 [] =
{0,};

static const EIF_TYPE_INDEX g_atype619_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes619 [] = {
g_atype619_0,
};

static const long offsets619 [] =
{
+ @CHROFF(0,0),
};

extern const char *names620[];
static const uint32 types620 [] =
{
SK_BOOL,
};

static const uint16 attr_flags620 [] =
{0,};

static const EIF_TYPE_INDEX g_atype620_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes620 [] = {
g_atype620_0,
};

static const long offsets620 [] =
{
+ @CHROFF(0,0),
};

extern const char *names621[];
static const uint32 types621 [] =
{
SK_BOOL,
};

static const uint16 attr_flags621 [] =
{0,};

static const EIF_TYPE_INDEX g_atype621_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes621 [] = {
g_atype621_0,
};

static const long offsets621 [] =
{
+ @CHROFF(0,0),
};

extern const char *names622[];
static const uint32 types622 [] =
{
SK_BOOL,
};

static const uint16 attr_flags622 [] =
{0,};

static const EIF_TYPE_INDEX g_atype622_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes622 [] = {
g_atype622_0,
};

static const long offsets622 [] =
{
+ @CHROFF(0,0),
};

extern const char *names623[];
static const uint32 types623 [] =
{
SK_BOOL,
};

static const uint16 attr_flags623 [] =
{0,};

static const EIF_TYPE_INDEX g_atype623_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes623 [] = {
g_atype623_0,
};

static const long offsets623 [] =
{
+ @CHROFF(0,0),
};

extern const char *names624[];
static const uint32 types624 [] =
{
SK_BOOL,
};

static const uint16 attr_flags624 [] =
{0,};

static const EIF_TYPE_INDEX g_atype624_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes624 [] = {
g_atype624_0,
};

static const long offsets624 [] =
{
+ @CHROFF(0,0),
};

extern const char *names625[];
static const uint32 types625 [] =
{
SK_BOOL,
};

static const uint16 attr_flags625 [] =
{0,};

static const EIF_TYPE_INDEX g_atype625_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes625 [] = {
g_atype625_0,
};

static const long offsets625 [] =
{
+ @CHROFF(0,0),
};

extern const char *names626[];
static const uint32 types626 [] =
{
SK_BOOL,
};

static const uint16 attr_flags626 [] =
{0,};

static const EIF_TYPE_INDEX g_atype626_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes626 [] = {
g_atype626_0,
};

static const long offsets626 [] =
{
+ @CHROFF(0,0),
};

extern const char *names627[];
static const uint32 types627 [] =
{
SK_BOOL,
};

static const uint16 attr_flags627 [] =
{0,};

static const EIF_TYPE_INDEX g_atype627_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes627 [] = {
g_atype627_0,
};

static const long offsets627 [] =
{
+ @CHROFF(0,0),
};

extern const char *names628[];
static const uint32 types628 [] =
{
SK_BOOL,
};

static const uint16 attr_flags628 [] =
{0,};

static const EIF_TYPE_INDEX g_atype628_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes628 [] = {
g_atype628_0,
};

static const long offsets628 [] =
{
+ @CHROFF(0,0),
};

extern const char *names629[];
static const uint32 types629 [] =
{
SK_BOOL,
};

static const uint16 attr_flags629 [] =
{0,};

static const EIF_TYPE_INDEX g_atype629_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes629 [] = {
g_atype629_0,
};

static const long offsets629 [] =
{
+ @CHROFF(0,0),
};

extern const char *names630[];
static const uint32 types630 [] =
{
SK_BOOL,
};

static const uint16 attr_flags630 [] =
{0,};

static const EIF_TYPE_INDEX g_atype630_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes630 [] = {
g_atype630_0,
};

static const long offsets630 [] =
{
+ @CHROFF(0,0),
};

extern const char *names631[];
static const uint32 types631 [] =
{
SK_BOOL,
};

static const uint16 attr_flags631 [] =
{0,};

static const EIF_TYPE_INDEX g_atype631_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes631 [] = {
g_atype631_0,
};

static const long offsets631 [] =
{
+ @CHROFF(0,0),
};

extern const char *names632[];
static const uint32 types632 [] =
{
SK_BOOL,
};

static const uint16 attr_flags632 [] =
{0,};

static const EIF_TYPE_INDEX g_atype632_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes632 [] = {
g_atype632_0,
};

static const long offsets632 [] =
{
+ @CHROFF(0,0),
};

extern const char *names633[];
static const uint32 types633 [] =
{
SK_BOOL,
};

static const uint16 attr_flags633 [] =
{0,};

static const EIF_TYPE_INDEX g_atype633_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes633 [] = {
g_atype633_0,
};

static const long offsets633 [] =
{
+ @CHROFF(0,0),
};

extern const char *names634[];
static const uint32 types634 [] =
{
SK_BOOL,
};

static const uint16 attr_flags634 [] =
{0,};

static const EIF_TYPE_INDEX g_atype634_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes634 [] = {
g_atype634_0,
};

static const long offsets634 [] =
{
+ @CHROFF(0,0),
};

extern const char *names635[];
static const uint32 types635 [] =
{
SK_BOOL,
};

static const uint16 attr_flags635 [] =
{0,};

static const EIF_TYPE_INDEX g_atype635_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes635 [] = {
g_atype635_0,
};

static const long offsets635 [] =
{
+ @CHROFF(0,0),
};

extern const char *names636[];
static const uint32 types636 [] =
{
SK_BOOL,
};

static const uint16 attr_flags636 [] =
{0,};

static const EIF_TYPE_INDEX g_atype636_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes636 [] = {
g_atype636_0,
};

static const long offsets636 [] =
{
+ @CHROFF(0,0),
};

extern const char *names637[];
static const uint32 types637 [] =
{
SK_BOOL,
};

static const uint16 attr_flags637 [] =
{0,};

static const EIF_TYPE_INDEX g_atype637_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes637 [] = {
g_atype637_0,
};

static const long offsets637 [] =
{
+ @CHROFF(0,0),
};

extern const char *names638[];
static const uint32 types638 [] =
{
SK_BOOL,
};

static const uint16 attr_flags638 [] =
{0,};

static const EIF_TYPE_INDEX g_atype638_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes638 [] = {
g_atype638_0,
};

static const long offsets638 [] =
{
+ @CHROFF(0,0),
};

extern const char *names639[];
static const uint32 types639 [] =
{
SK_BOOL,
};

static const uint16 attr_flags639 [] =
{0,};

static const EIF_TYPE_INDEX g_atype639_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes639 [] = {
g_atype639_0,
};

static const long offsets639 [] =
{
+ @CHROFF(0,0),
};

extern const char *names640[];
static const uint32 types640 [] =
{
SK_BOOL,
};

static const uint16 attr_flags640 [] =
{0,};

static const EIF_TYPE_INDEX g_atype640_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes640 [] = {
g_atype640_0,
};

static const long offsets640 [] =
{
+ @CHROFF(0,0),
};

extern const char *names641[];
static const uint32 types641 [] =
{
SK_BOOL,
};

static const uint16 attr_flags641 [] =
{0,};

static const EIF_TYPE_INDEX g_atype641_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes641 [] = {
g_atype641_0,
};

static const long offsets641 [] =
{
+ @CHROFF(0,0),
};

extern const char *names642[];
static const uint32 types642 [] =
{
SK_BOOL,
};

static const uint16 attr_flags642 [] =
{0,};

static const EIF_TYPE_INDEX g_atype642_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes642 [] = {
g_atype642_0,
};

static const long offsets642 [] =
{
+ @CHROFF(0,0),
};

extern const char *names643[];
static const uint32 types643 [] =
{
SK_BOOL,
};

static const uint16 attr_flags643 [] =
{0,};

static const EIF_TYPE_INDEX g_atype643_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes643 [] = {
g_atype643_0,
};

static const long offsets643 [] =
{
+ @CHROFF(0,0),
};

extern const char *names644[];
static const uint32 types644 [] =
{
SK_BOOL,
};

static const uint16 attr_flags644 [] =
{0,};

static const EIF_TYPE_INDEX g_atype644_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes644 [] = {
g_atype644_0,
};

static const long offsets644 [] =
{
+ @CHROFF(0,0),
};

extern const char *names645[];
static const uint32 types645 [] =
{
SK_BOOL,
};

static const uint16 attr_flags645 [] =
{0,};

static const EIF_TYPE_INDEX g_atype645_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes645 [] = {
g_atype645_0,
};

static const long offsets645 [] =
{
+ @CHROFF(0,0),
};

extern const char *names646[];
static const uint32 types646 [] =
{
SK_BOOL,
};

static const uint16 attr_flags646 [] =
{0,};

static const EIF_TYPE_INDEX g_atype646_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes646 [] = {
g_atype646_0,
};

static const long offsets646 [] =
{
+ @CHROFF(0,0),
};

extern const char *names647[];
static const uint32 types647 [] =
{
SK_BOOL,
};

static const uint16 attr_flags647 [] =
{0,};

static const EIF_TYPE_INDEX g_atype647_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes647 [] = {
g_atype647_0,
};

static const long offsets647 [] =
{
+ @CHROFF(0,0),
};

extern const char *names648[];
static const uint32 types648 [] =
{
SK_BOOL,
};

static const uint16 attr_flags648 [] =
{0,};

static const EIF_TYPE_INDEX g_atype648_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes648 [] = {
g_atype648_0,
};

static const long offsets648 [] =
{
+ @CHROFF(0,0),
};

extern const char *names649[];
static const uint32 types649 [] =
{
SK_BOOL,
};

static const uint16 attr_flags649 [] =
{0,};

static const EIF_TYPE_INDEX g_atype649_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes649 [] = {
g_atype649_0,
};

static const long offsets649 [] =
{
+ @CHROFF(0,0),
};

extern const char *names650[];
static const uint32 types650 [] =
{
SK_BOOL,
};

static const uint16 attr_flags650 [] =
{0,};

static const EIF_TYPE_INDEX g_atype650_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes650 [] = {
g_atype650_0,
};

static const long offsets650 [] =
{
+ @CHROFF(0,0),
};

extern const char *names651[];
static const uint32 types651 [] =
{
SK_BOOL,
};

static const uint16 attr_flags651 [] =
{0,};

static const EIF_TYPE_INDEX g_atype651_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes651 [] = {
g_atype651_0,
};

static const long offsets651 [] =
{
+ @CHROFF(0,0),
};

extern const char *names652[];
static const uint32 types652 [] =
{
SK_BOOL,
};

static const uint16 attr_flags652 [] =
{0,};

static const EIF_TYPE_INDEX g_atype652_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes652 [] = {
g_atype652_0,
};

static const long offsets652 [] =
{
+ @CHROFF(0,0),
};

extern const char *names653[];
static const uint32 types653 [] =
{
SK_BOOL,
};

static const uint16 attr_flags653 [] =
{0,};

static const EIF_TYPE_INDEX g_atype653_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes653 [] = {
g_atype653_0,
};

static const long offsets653 [] =
{
+ @CHROFF(0,0),
};

extern const char *names654[];
static const uint32 types654 [] =
{
SK_BOOL,
};

static const uint16 attr_flags654 [] =
{0,};

static const EIF_TYPE_INDEX g_atype654_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes654 [] = {
g_atype654_0,
};

static const long offsets654 [] =
{
+ @CHROFF(0,0),
};

extern const char *names655[];
static const uint32 types655 [] =
{
SK_BOOL,
};

static const uint16 attr_flags655 [] =
{0,};

static const EIF_TYPE_INDEX g_atype655_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes655 [] = {
g_atype655_0,
};

static const long offsets655 [] =
{
+ @CHROFF(0,0),
};

extern const char *names656[];
static const uint32 types656 [] =
{
SK_BOOL,
};

static const uint16 attr_flags656 [] =
{0,};

static const EIF_TYPE_INDEX g_atype656_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes656 [] = {
g_atype656_0,
};

static const long offsets656 [] =
{
+ @CHROFF(0,0),
};

extern const char *names657[];
static const uint32 types657 [] =
{
SK_BOOL,
};

static const uint16 attr_flags657 [] =
{0,};

static const EIF_TYPE_INDEX g_atype657_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes657 [] = {
g_atype657_0,
};

static const long offsets657 [] =
{
+ @CHROFF(0,0),
};

extern const char *names658[];
static const uint32 types658 [] =
{
SK_BOOL,
};

static const uint16 attr_flags658 [] =
{0,};

static const EIF_TYPE_INDEX g_atype658_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes658 [] = {
g_atype658_0,
};

static const long offsets658 [] =
{
+ @CHROFF(0,0),
};

extern const char *names659[];
static const uint32 types659 [] =
{
SK_BOOL,
};

static const uint16 attr_flags659 [] =
{0,};

static const EIF_TYPE_INDEX g_atype659_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes659 [] = {
g_atype659_0,
};

static const long offsets659 [] =
{
+ @CHROFF(0,0),
};

extern const char *names660[];
static const uint32 types660 [] =
{
SK_BOOL,
};

static const uint16 attr_flags660 [] =
{0,};

static const EIF_TYPE_INDEX g_atype660_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes660 [] = {
g_atype660_0,
};

static const long offsets660 [] =
{
+ @CHROFF(0,0),
};

extern const char *names661[];
static const uint32 types661 [] =
{
SK_BOOL,
};

static const uint16 attr_flags661 [] =
{0,};

static const EIF_TYPE_INDEX g_atype661_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes661 [] = {
g_atype661_0,
};

static const long offsets661 [] =
{
+ @CHROFF(0,0),
};

extern const char *names662[];
static const uint32 types662 [] =
{
SK_BOOL,
};

static const uint16 attr_flags662 [] =
{0,};

static const EIF_TYPE_INDEX g_atype662_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes662 [] = {
g_atype662_0,
};

static const long offsets662 [] =
{
+ @CHROFF(0,0),
};

extern const char *names663[];
static const uint32 types663 [] =
{
SK_BOOL,
};

static const uint16 attr_flags663 [] =
{0,};

static const EIF_TYPE_INDEX g_atype663_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes663 [] = {
g_atype663_0,
};

static const long offsets663 [] =
{
+ @CHROFF(0,0),
};

extern const char *names664[];
static const uint32 types664 [] =
{
SK_BOOL,
};

static const uint16 attr_flags664 [] =
{0,};

static const EIF_TYPE_INDEX g_atype664_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes664 [] = {
g_atype664_0,
};

static const long offsets664 [] =
{
+ @CHROFF(0,0),
};

extern const char *names665[];
static const uint32 types665 [] =
{
SK_BOOL,
};

static const uint16 attr_flags665 [] =
{0,};

static const EIF_TYPE_INDEX g_atype665_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes665 [] = {
g_atype665_0,
};

static const long offsets665 [] =
{
+ @CHROFF(0,0),
};

extern const char *names666[];
static const uint32 types666 [] =
{
SK_BOOL,
};

static const uint16 attr_flags666 [] =
{0,};

static const EIF_TYPE_INDEX g_atype666_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes666 [] = {
g_atype666_0,
};

static const long offsets666 [] =
{
+ @CHROFF(0,0),
};

extern const char *names667[];
static const uint32 types667 [] =
{
SK_BOOL,
};

static const uint16 attr_flags667 [] =
{0,};

static const EIF_TYPE_INDEX g_atype667_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes667 [] = {
g_atype667_0,
};

static const long offsets667 [] =
{
+ @CHROFF(0,0),
};

extern const char *names668[];
static const uint32 types668 [] =
{
SK_BOOL,
};

static const uint16 attr_flags668 [] =
{0,};

static const EIF_TYPE_INDEX g_atype668_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes668 [] = {
g_atype668_0,
};

static const long offsets668 [] =
{
+ @CHROFF(0,0),
};

extern const char *names669[];
static const uint32 types669 [] =
{
SK_BOOL,
};

static const uint16 attr_flags669 [] =
{0,};

static const EIF_TYPE_INDEX g_atype669_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes669 [] = {
g_atype669_0,
};

static const long offsets669 [] =
{
+ @CHROFF(0,0),
};

extern const char *names670[];
static const uint32 types670 [] =
{
SK_BOOL,
};

static const uint16 attr_flags670 [] =
{0,};

static const EIF_TYPE_INDEX g_atype670_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes670 [] = {
g_atype670_0,
};

static const long offsets670 [] =
{
+ @CHROFF(0,0),
};

extern const char *names671[];
static const uint32 types671 [] =
{
SK_BOOL,
};

static const uint16 attr_flags671 [] =
{0,};

static const EIF_TYPE_INDEX g_atype671_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes671 [] = {
g_atype671_0,
};

static const long offsets671 [] =
{
+ @CHROFF(0,0),
};

extern const char *names672[];
static const uint32 types672 [] =
{
SK_BOOL,
};

static const uint16 attr_flags672 [] =
{0,};

static const EIF_TYPE_INDEX g_atype672_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes672 [] = {
g_atype672_0,
};

static const long offsets672 [] =
{
+ @CHROFF(0,0),
};

extern const char *names673[];
static const uint32 types673 [] =
{
SK_BOOL,
};

static const uint16 attr_flags673 [] =
{0,};

static const EIF_TYPE_INDEX g_atype673_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes673 [] = {
g_atype673_0,
};

static const long offsets673 [] =
{
+ @CHROFF(0,0),
};

extern const char *names674[];
static const uint32 types674 [] =
{
SK_BOOL,
};

static const uint16 attr_flags674 [] =
{0,};

static const EIF_TYPE_INDEX g_atype674_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes674 [] = {
g_atype674_0,
};

static const long offsets674 [] =
{
+ @CHROFF(0,0),
};

extern const char *names675[];
static const uint32 types675 [] =
{
SK_BOOL,
};

static const uint16 attr_flags675 [] =
{0,};

static const EIF_TYPE_INDEX g_atype675_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes675 [] = {
g_atype675_0,
};

static const long offsets675 [] =
{
+ @CHROFF(0,0),
};

extern const char *names676[];
static const uint32 types676 [] =
{
SK_BOOL,
};

static const uint16 attr_flags676 [] =
{0,};

static const EIF_TYPE_INDEX g_atype676_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes676 [] = {
g_atype676_0,
};

static const long offsets676 [] =
{
+ @CHROFF(0,0),
};

extern const char *names677[];
static const uint32 types677 [] =
{
SK_BOOL,
};

static const uint16 attr_flags677 [] =
{0,};

static const EIF_TYPE_INDEX g_atype677_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes677 [] = {
g_atype677_0,
};

static const long offsets677 [] =
{
+ @CHROFF(0,0),
};

extern const char *names678[];
static const uint32 types678 [] =
{
SK_BOOL,
};

static const uint16 attr_flags678 [] =
{0,};

static const EIF_TYPE_INDEX g_atype678_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes678 [] = {
g_atype678_0,
};

static const long offsets678 [] =
{
+ @CHROFF(0,0),
};

extern const char *names679[];
static const uint32 types679 [] =
{
SK_BOOL,
};

static const uint16 attr_flags679 [] =
{0,};

static const EIF_TYPE_INDEX g_atype679_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes679 [] = {
g_atype679_0,
};

static const long offsets679 [] =
{
+ @CHROFF(0,0),
};

extern const char *names680[];
static const uint32 types680 [] =
{
SK_BOOL,
};

static const uint16 attr_flags680 [] =
{0,};

static const EIF_TYPE_INDEX g_atype680_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes680 [] = {
g_atype680_0,
};

static const long offsets680 [] =
{
+ @CHROFF(0,0),
};

extern const char *names681[];
static const uint32 types681 [] =
{
SK_BOOL,
};

static const uint16 attr_flags681 [] =
{0,};

static const EIF_TYPE_INDEX g_atype681_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes681 [] = {
g_atype681_0,
};

static const long offsets681 [] =
{
+ @CHROFF(0,0),
};

extern const char *names694[];
static const uint32 types694 [] =
{
SK_BOOL,
};

static const uint16 attr_flags694 [] =
{0,};

static const EIF_TYPE_INDEX g_atype694_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes694 [] = {
g_atype694_0,
};

static const long offsets694 [] =
{
+ @CHROFF(0,0),
};

extern const char *names695[];
static const uint32 types695 [] =
{
SK_BOOL,
};

static const uint16 attr_flags695 [] =
{0,};

static const EIF_TYPE_INDEX g_atype695_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes695 [] = {
g_atype695_0,
};

static const long offsets695 [] =
{
+ @CHROFF(0,0),
};

extern const char *names696[];
static const uint32 types696 [] =
{
SK_BOOL,
};

static const uint16 attr_flags696 [] =
{0,};

static const EIF_TYPE_INDEX g_atype696_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes696 [] = {
g_atype696_0,
};

static const long offsets696 [] =
{
+ @CHROFF(0,0),
};

extern const char *names697[];
static const uint32 types697 [] =
{
SK_BOOL,
};

static const uint16 attr_flags697 [] =
{0,};

static const EIF_TYPE_INDEX g_atype697_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes697 [] = {
g_atype697_0,
};

static const long offsets697 [] =
{
+ @CHROFF(0,0),
};

extern const char *names698[];
static const uint32 types698 [] =
{
SK_BOOL,
};

static const uint16 attr_flags698 [] =
{0,};

static const EIF_TYPE_INDEX g_atype698_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes698 [] = {
g_atype698_0,
};

static const long offsets698 [] =
{
+ @CHROFF(0,0),
};

extern const char *names699[];
static const uint32 types699 [] =
{
SK_BOOL,
};

static const uint16 attr_flags699 [] =
{0,};

static const EIF_TYPE_INDEX g_atype699_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes699 [] = {
g_atype699_0,
};

static const long offsets699 [] =
{
+ @CHROFF(0,0),
};

extern const char *names700[];
static const uint32 types700 [] =
{
SK_BOOL,
};

static const uint16 attr_flags700 [] =
{0,};

static const EIF_TYPE_INDEX g_atype700_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes700 [] = {
g_atype700_0,
};

static const long offsets700 [] =
{
+ @CHROFF(0,0),
};

extern const char *names701[];
static const uint32 types701 [] =
{
SK_BOOL,
};

static const uint16 attr_flags701 [] =
{0,};

static const EIF_TYPE_INDEX g_atype701_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes701 [] = {
g_atype701_0,
};

static const long offsets701 [] =
{
+ @CHROFF(0,0),
};

extern const char *names702[];
static const uint32 types702 [] =
{
SK_BOOL,
};

static const uint16 attr_flags702 [] =
{0,};

static const EIF_TYPE_INDEX g_atype702_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes702 [] = {
g_atype702_0,
};

static const long offsets702 [] =
{
+ @CHROFF(0,0),
};

extern const char *names703[];
static const uint32 types703 [] =
{
SK_BOOL,
};

static const uint16 attr_flags703 [] =
{0,};

static const EIF_TYPE_INDEX g_atype703_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes703 [] = {
g_atype703_0,
};

static const long offsets703 [] =
{
+ @CHROFF(0,0),
};

extern const char *names704[];
static const uint32 types704 [] =
{
SK_BOOL,
};

static const uint16 attr_flags704 [] =
{0,};

static const EIF_TYPE_INDEX g_atype704_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes704 [] = {
g_atype704_0,
};

static const long offsets704 [] =
{
+ @CHROFF(0,0),
};

extern const char *names705[];
static const uint32 types705 [] =
{
SK_BOOL,
};

static const uint16 attr_flags705 [] =
{0,};

static const EIF_TYPE_INDEX g_atype705_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes705 [] = {
g_atype705_0,
};

static const long offsets705 [] =
{
+ @CHROFF(0,0),
};

extern const char *names706[];
static const uint32 types706 [] =
{
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags706 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype706_0 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype706_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype706_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes706 [] = {
g_atype706_0,
g_atype706_1,
g_atype706_2,
};

static const long offsets706 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
+ @LNGOFF(0,1,0,1),
};

extern const char *names707[];
static const uint32 types707 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags707 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype707_0 [] = {0xFF01,839,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype707_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype707_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype707_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes707 [] = {
g_atype707_0,
g_atype707_1,
g_atype707_2,
g_atype707_3,
};

static const long offsets707 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names708[];
static const uint32 types708 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags708 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype708_0 [] = {0xFF01,840,977,0xFFFF};
static const EIF_TYPE_INDEX g_atype708_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype708_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype708_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes708 [] = {
g_atype708_0,
g_atype708_1,
g_atype708_2,
g_atype708_3,
};

static const long offsets708 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names709[];
static const uint32 types709 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags709 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype709_0 [] = {0xFF01,841,968,0xFFFF};
static const EIF_TYPE_INDEX g_atype709_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype709_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype709_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes709 [] = {
g_atype709_0,
g_atype709_1,
g_atype709_2,
g_atype709_3,
};

static const long offsets709 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names710[];
static const uint32 types710 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags710 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype710_0 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype710_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype710_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype710_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes710 [] = {
g_atype710_0,
g_atype710_1,
g_atype710_2,
g_atype710_3,
};

static const long offsets710 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names711[];
static const uint32 types711 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags711 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype711_0 [] = {0xFF01,843,974,0xFFFF};
static const EIF_TYPE_INDEX g_atype711_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype711_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype711_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes711 [] = {
g_atype711_0,
g_atype711_1,
g_atype711_2,
g_atype711_3,
};

static const long offsets711 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names712[];
static const uint32 types712 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags712 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype712_0 [] = {0xFF01,844,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype712_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype712_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype712_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes712 [] = {
g_atype712_0,
g_atype712_1,
g_atype712_2,
g_atype712_3,
};

static const long offsets712 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names713[];
static const uint32 types713 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags713 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype713_0 [] = {0xFF01,845,989,0xFFFF};
static const EIF_TYPE_INDEX g_atype713_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype713_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype713_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes713 [] = {
g_atype713_0,
g_atype713_1,
g_atype713_2,
g_atype713_3,
};

static const long offsets713 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names714[];
static const uint32 types714 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags714 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype714_0 [] = {0xFF01,846,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype714_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype714_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype714_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes714 [] = {
g_atype714_0,
g_atype714_1,
g_atype714_2,
g_atype714_3,
};

static const long offsets714 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names715[];
static const uint32 types715 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags715 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype715_0 [] = {0xFF01,847,971,0xFFFF};
static const EIF_TYPE_INDEX g_atype715_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype715_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype715_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes715 [] = {
g_atype715_0,
g_atype715_1,
g_atype715_2,
g_atype715_3,
};

static const long offsets715 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names716[];
static const uint32 types716 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags716 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype716_0 [] = {0xFF01,848,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype716_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype716_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype716_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes716 [] = {
g_atype716_0,
g_atype716_1,
g_atype716_2,
g_atype716_3,
};

static const long offsets716 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names717[];
static const uint32 types717 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags717 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype717_0 [] = {0xFF01,849,980,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype717_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes717 [] = {
g_atype717_0,
g_atype717_1,
g_atype717_2,
g_atype717_3,
};

static const long offsets717 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names718[];
static const uint32 types718 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags718 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype718_0 [] = {0xFF01,850,983,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype718_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes718 [] = {
g_atype718_0,
g_atype718_1,
g_atype718_2,
g_atype718_3,
};

static const long offsets718 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names719[];
static const uint32 types719 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags719 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype719_0 [] = {0xFF01,839,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype719_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype719_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype719_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes719 [] = {
g_atype719_0,
g_atype719_1,
g_atype719_2,
g_atype719_3,
};

static const long offsets719 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names720[];
static const uint32 types720 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags720 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype720_0 [] = {0xFF01,845,989,0xFFFF};
static const EIF_TYPE_INDEX g_atype720_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype720_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype720_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes720 [] = {
g_atype720_0,
g_atype720_1,
g_atype720_2,
g_atype720_3,
};

static const long offsets720 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names721[];
static const uint32 types721 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags721 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype721_0 [] = {0xFF01,846,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype721_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype721_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype721_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes721 [] = {
g_atype721_0,
g_atype721_1,
g_atype721_2,
g_atype721_3,
};

static const long offsets721 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names722[];
static const uint32 types722 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags722 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype722_0 [] = {0xFF01,847,971,0xFFFF};
static const EIF_TYPE_INDEX g_atype722_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype722_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype722_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes722 [] = {
g_atype722_0,
g_atype722_1,
g_atype722_2,
g_atype722_3,
};

static const long offsets722 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names723[];
static const uint32 types723 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags723 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype723_0 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype723_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype723_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype723_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes723 [] = {
g_atype723_0,
g_atype723_1,
g_atype723_2,
g_atype723_3,
};

static const long offsets723 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names724[];
static const uint32 types724 [] =
{
SK_BOOL,
};

static const uint16 attr_flags724 [] =
{0,};

static const EIF_TYPE_INDEX g_atype724_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes724 [] = {
g_atype724_0,
};

static const long offsets724 [] =
{
+ @CHROFF(0,0),
};

extern const char *names725[];
static const uint32 types725 [] =
{
SK_BOOL,
};

static const uint16 attr_flags725 [] =
{0,};

static const EIF_TYPE_INDEX g_atype725_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes725 [] = {
g_atype725_0,
};

static const long offsets725 [] =
{
+ @CHROFF(0,0),
};

extern const char *names726[];
static const uint32 types726 [] =
{
SK_BOOL,
};

static const uint16 attr_flags726 [] =
{0,};

static const EIF_TYPE_INDEX g_atype726_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes726 [] = {
g_atype726_0,
};

static const long offsets726 [] =
{
+ @CHROFF(0,0),
};

extern const char *names727[];
static const uint32 types727 [] =
{
SK_BOOL,
};

static const uint16 attr_flags727 [] =
{0,};

static const EIF_TYPE_INDEX g_atype727_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes727 [] = {
g_atype727_0,
};

static const long offsets727 [] =
{
+ @CHROFF(0,0),
};

extern const char *names728[];
static const uint32 types728 [] =
{
SK_BOOL,
};

static const uint16 attr_flags728 [] =
{0,};

static const EIF_TYPE_INDEX g_atype728_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes728 [] = {
g_atype728_0,
};

static const long offsets728 [] =
{
+ @CHROFF(0,0),
};

extern const char *names729[];
static const uint32 types729 [] =
{
SK_BOOL,
};

static const uint16 attr_flags729 [] =
{0,};

static const EIF_TYPE_INDEX g_atype729_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes729 [] = {
g_atype729_0,
};

static const long offsets729 [] =
{
+ @CHROFF(0,0),
};

extern const char *names730[];
static const uint32 types730 [] =
{
SK_BOOL,
};

static const uint16 attr_flags730 [] =
{0,};

static const EIF_TYPE_INDEX g_atype730_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes730 [] = {
g_atype730_0,
};

static const long offsets730 [] =
{
+ @CHROFF(0,0),
};

extern const char *names731[];
static const uint32 types731 [] =
{
SK_BOOL,
};

static const uint16 attr_flags731 [] =
{0,};

static const EIF_TYPE_INDEX g_atype731_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes731 [] = {
g_atype731_0,
};

static const long offsets731 [] =
{
+ @CHROFF(0,0),
};

extern const char *names732[];
static const uint32 types732 [] =
{
SK_BOOL,
};

static const uint16 attr_flags732 [] =
{0,};

static const EIF_TYPE_INDEX g_atype732_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes732 [] = {
g_atype732_0,
};

static const long offsets732 [] =
{
+ @CHROFF(0,0),
};

extern const char *names733[];
static const uint32 types733 [] =
{
SK_BOOL,
};

static const uint16 attr_flags733 [] =
{0,};

static const EIF_TYPE_INDEX g_atype733_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes733 [] = {
g_atype733_0,
};

static const long offsets733 [] =
{
+ @CHROFF(0,0),
};

extern const char *names734[];
static const uint32 types734 [] =
{
SK_BOOL,
};

static const uint16 attr_flags734 [] =
{0,};

static const EIF_TYPE_INDEX g_atype734_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes734 [] = {
g_atype734_0,
};

static const long offsets734 [] =
{
+ @CHROFF(0,0),
};

extern const char *names735[];
static const uint32 types735 [] =
{
SK_BOOL,
};

static const uint16 attr_flags735 [] =
{0,};

static const EIF_TYPE_INDEX g_atype735_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes735 [] = {
g_atype735_0,
};

static const long offsets735 [] =
{
+ @CHROFF(0,0),
};

extern const char *names736[];
static const uint32 types736 [] =
{
SK_BOOL,
};

static const uint16 attr_flags736 [] =
{0,};

static const EIF_TYPE_INDEX g_atype736_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes736 [] = {
g_atype736_0,
};

static const long offsets736 [] =
{
+ @CHROFF(0,0),
};

extern const char *names737[];
static const uint32 types737 [] =
{
SK_BOOL,
};

static const uint16 attr_flags737 [] =
{0,};

static const EIF_TYPE_INDEX g_atype737_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes737 [] = {
g_atype737_0,
};

static const long offsets737 [] =
{
+ @CHROFF(0,0),
};

extern const char *names738[];
static const uint32 types738 [] =
{
SK_BOOL,
};

static const uint16 attr_flags738 [] =
{0,};

static const EIF_TYPE_INDEX g_atype738_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes738 [] = {
g_atype738_0,
};

static const long offsets738 [] =
{
+ @CHROFF(0,0),
};

extern const char *names739[];
static const uint32 types739 [] =
{
SK_BOOL,
};

static const uint16 attr_flags739 [] =
{0,};

static const EIF_TYPE_INDEX g_atype739_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes739 [] = {
g_atype739_0,
};

static const long offsets739 [] =
{
+ @CHROFF(0,0),
};

extern const char *names740[];
static const uint32 types740 [] =
{
SK_BOOL,
};

static const uint16 attr_flags740 [] =
{0,};

static const EIF_TYPE_INDEX g_atype740_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes740 [] = {
g_atype740_0,
};

static const long offsets740 [] =
{
+ @CHROFF(0,0),
};

extern const char *names741[];
static const uint32 types741 [] =
{
SK_BOOL,
};

static const uint16 attr_flags741 [] =
{0,};

static const EIF_TYPE_INDEX g_atype741_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes741 [] = {
g_atype741_0,
};

static const long offsets741 [] =
{
+ @CHROFF(0,0),
};

extern const char *names742[];
static const uint32 types742 [] =
{
SK_BOOL,
};

static const uint16 attr_flags742 [] =
{0,};

static const EIF_TYPE_INDEX g_atype742_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes742 [] = {
g_atype742_0,
};

static const long offsets742 [] =
{
+ @CHROFF(0,0),
};

extern const char *names743[];
static const uint32 types743 [] =
{
SK_BOOL,
};

static const uint16 attr_flags743 [] =
{0,};

static const EIF_TYPE_INDEX g_atype743_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes743 [] = {
g_atype743_0,
};

static const long offsets743 [] =
{
+ @CHROFF(0,0),
};

extern const char *names744[];
static const uint32 types744 [] =
{
SK_BOOL,
};

static const uint16 attr_flags744 [] =
{0,};

static const EIF_TYPE_INDEX g_atype744_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes744 [] = {
g_atype744_0,
};

static const long offsets744 [] =
{
+ @CHROFF(0,0),
};

extern const char *names745[];
static const uint32 types745 [] =
{
SK_BOOL,
};

static const uint16 attr_flags745 [] =
{0,};

static const EIF_TYPE_INDEX g_atype745_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes745 [] = {
g_atype745_0,
};

static const long offsets745 [] =
{
+ @CHROFF(0,0),
};

extern const char *names746[];
static const uint32 types746 [] =
{
SK_BOOL,
};

static const uint16 attr_flags746 [] =
{0,};

static const EIF_TYPE_INDEX g_atype746_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes746 [] = {
g_atype746_0,
};

static const long offsets746 [] =
{
+ @CHROFF(0,0),
};

extern const char *names747[];
static const uint32 types747 [] =
{
SK_BOOL,
};

static const uint16 attr_flags747 [] =
{0,};

static const EIF_TYPE_INDEX g_atype747_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes747 [] = {
g_atype747_0,
};

static const long offsets747 [] =
{
+ @CHROFF(0,0),
};

extern const char *names748[];
static const uint32 types748 [] =
{
SK_BOOL,
};

static const uint16 attr_flags748 [] =
{0,};

static const EIF_TYPE_INDEX g_atype748_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes748 [] = {
g_atype748_0,
};

static const long offsets748 [] =
{
+ @CHROFF(0,0),
};

extern const char *names749[];
static const uint32 types749 [] =
{
SK_BOOL,
};

static const uint16 attr_flags749 [] =
{0,};

static const EIF_TYPE_INDEX g_atype749_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes749 [] = {
g_atype749_0,
};

static const long offsets749 [] =
{
+ @CHROFF(0,0),
};

extern const char *names750[];
static const uint32 types750 [] =
{
SK_BOOL,
};

static const uint16 attr_flags750 [] =
{0,};

static const EIF_TYPE_INDEX g_atype750_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes750 [] = {
g_atype750_0,
};

static const long offsets750 [] =
{
+ @CHROFF(0,0),
};

extern const char *names751[];
static const uint32 types751 [] =
{
SK_BOOL,
};

static const uint16 attr_flags751 [] =
{0,};

static const EIF_TYPE_INDEX g_atype751_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes751 [] = {
g_atype751_0,
};

static const long offsets751 [] =
{
+ @CHROFF(0,0),
};

extern const char *names752[];
static const uint32 types752 [] =
{
SK_BOOL,
};

static const uint16 attr_flags752 [] =
{0,};

static const EIF_TYPE_INDEX g_atype752_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes752 [] = {
g_atype752_0,
};

static const long offsets752 [] =
{
+ @CHROFF(0,0),
};

extern const char *names753[];
static const uint32 types753 [] =
{
SK_BOOL,
};

static const uint16 attr_flags753 [] =
{0,};

static const EIF_TYPE_INDEX g_atype753_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes753 [] = {
g_atype753_0,
};

static const long offsets753 [] =
{
+ @CHROFF(0,0),
};

extern const char *names754[];
static const uint32 types754 [] =
{
SK_BOOL,
};

static const uint16 attr_flags754 [] =
{0,};

static const EIF_TYPE_INDEX g_atype754_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes754 [] = {
g_atype754_0,
};

static const long offsets754 [] =
{
+ @CHROFF(0,0),
};

extern const char *names755[];
static const uint32 types755 [] =
{
SK_BOOL,
};

static const uint16 attr_flags755 [] =
{0,};

static const EIF_TYPE_INDEX g_atype755_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes755 [] = {
g_atype755_0,
};

static const long offsets755 [] =
{
+ @CHROFF(0,0),
};

extern const char *names756[];
static const uint32 types756 [] =
{
SK_BOOL,
};

static const uint16 attr_flags756 [] =
{0,};

static const EIF_TYPE_INDEX g_atype756_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes756 [] = {
g_atype756_0,
};

static const long offsets756 [] =
{
+ @CHROFF(0,0),
};

extern const char *names757[];
static const uint32 types757 [] =
{
SK_BOOL,
};

static const uint16 attr_flags757 [] =
{0,};

static const EIF_TYPE_INDEX g_atype757_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes757 [] = {
g_atype757_0,
};

static const long offsets757 [] =
{
+ @CHROFF(0,0),
};

extern const char *names758[];
static const uint32 types758 [] =
{
SK_BOOL,
};

static const uint16 attr_flags758 [] =
{0,};

static const EIF_TYPE_INDEX g_atype758_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes758 [] = {
g_atype758_0,
};

static const long offsets758 [] =
{
+ @CHROFF(0,0),
};

extern const char *names759[];
static const uint32 types759 [] =
{
SK_BOOL,
};

static const uint16 attr_flags759 [] =
{0,};

static const EIF_TYPE_INDEX g_atype759_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes759 [] = {
g_atype759_0,
};

static const long offsets759 [] =
{
+ @CHROFF(0,0),
};

extern const char *names760[];
static const uint32 types760 [] =
{
SK_BOOL,
};

static const uint16 attr_flags760 [] =
{0,};

static const EIF_TYPE_INDEX g_atype760_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes760 [] = {
g_atype760_0,
};

static const long offsets760 [] =
{
+ @CHROFF(0,0),
};

extern const char *names761[];
static const uint32 types761 [] =
{
SK_BOOL,
};

static const uint16 attr_flags761 [] =
{0,};

static const EIF_TYPE_INDEX g_atype761_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes761 [] = {
g_atype761_0,
};

static const long offsets761 [] =
{
+ @CHROFF(0,0),
};

extern const char *names762[];
static const uint32 types762 [] =
{
SK_BOOL,
};

static const uint16 attr_flags762 [] =
{0,};

static const EIF_TYPE_INDEX g_atype762_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes762 [] = {
g_atype762_0,
};

static const long offsets762 [] =
{
+ @CHROFF(0,0),
};

extern const char *names763[];
static const uint32 types763 [] =
{
SK_BOOL,
};

static const uint16 attr_flags763 [] =
{0,};

static const EIF_TYPE_INDEX g_atype763_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes763 [] = {
g_atype763_0,
};

static const long offsets763 [] =
{
+ @CHROFF(0,0),
};

extern const char *names764[];
static const uint32 types764 [] =
{
SK_BOOL,
};

static const uint16 attr_flags764 [] =
{0,};

static const EIF_TYPE_INDEX g_atype764_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes764 [] = {
g_atype764_0,
};

static const long offsets764 [] =
{
+ @CHROFF(0,0),
};

extern const char *names765[];
static const uint32 types765 [] =
{
SK_BOOL,
};

static const uint16 attr_flags765 [] =
{0,};

static const EIF_TYPE_INDEX g_atype765_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes765 [] = {
g_atype765_0,
};

static const long offsets765 [] =
{
+ @CHROFF(0,0),
};

extern const char *names766[];
static const uint32 types766 [] =
{
SK_BOOL,
};

static const uint16 attr_flags766 [] =
{0,};

static const EIF_TYPE_INDEX g_atype766_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes766 [] = {
g_atype766_0,
};

static const long offsets766 [] =
{
+ @CHROFF(0,0),
};

extern const char *names767[];
static const uint32 types767 [] =
{
SK_BOOL,
};

static const uint16 attr_flags767 [] =
{0,};

static const EIF_TYPE_INDEX g_atype767_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes767 [] = {
g_atype767_0,
};

static const long offsets767 [] =
{
+ @CHROFF(0,0),
};

extern const char *names768[];
static const uint32 types768 [] =
{
SK_BOOL,
};

static const uint16 attr_flags768 [] =
{0,};

static const EIF_TYPE_INDEX g_atype768_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes768 [] = {
g_atype768_0,
};

static const long offsets768 [] =
{
+ @CHROFF(0,0),
};

extern const char *names769[];
static const uint32 types769 [] =
{
SK_BOOL,
};

static const uint16 attr_flags769 [] =
{0,};

static const EIF_TYPE_INDEX g_atype769_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes769 [] = {
g_atype769_0,
};

static const long offsets769 [] =
{
+ @CHROFF(0,0),
};

extern const char *names770[];
static const uint32 types770 [] =
{
SK_BOOL,
};

static const uint16 attr_flags770 [] =
{0,};

static const EIF_TYPE_INDEX g_atype770_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes770 [] = {
g_atype770_0,
};

static const long offsets770 [] =
{
+ @CHROFF(0,0),
};

extern const char *names771[];
static const uint32 types771 [] =
{
SK_BOOL,
};

static const uint16 attr_flags771 [] =
{0,};

static const EIF_TYPE_INDEX g_atype771_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes771 [] = {
g_atype771_0,
};

static const long offsets771 [] =
{
+ @CHROFF(0,0),
};

extern const char *names772[];
static const uint32 types772 [] =
{
SK_BOOL,
};

static const uint16 attr_flags772 [] =
{0,};

static const EIF_TYPE_INDEX g_atype772_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes772 [] = {
g_atype772_0,
};

static const long offsets772 [] =
{
+ @CHROFF(0,0),
};

extern const char *names773[];
static const uint32 types773 [] =
{
SK_BOOL,
};

static const uint16 attr_flags773 [] =
{0,};

static const EIF_TYPE_INDEX g_atype773_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes773 [] = {
g_atype773_0,
};

static const long offsets773 [] =
{
+ @CHROFF(0,0),
};

extern const char *names774[];
static const uint32 types774 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags774 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype774_0 [] = {141,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_1 [] = {141,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes774 [] = {
g_atype774_0,
g_atype774_1,
g_atype774_2,
g_atype774_3,
g_atype774_4,
g_atype774_5,
};

static const long offsets774 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names775[];
static const uint32 types775 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags775 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype775_0 [] = {142,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype775_1 [] = {142,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype775_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype775_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype775_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype775_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes775 [] = {
g_atype775_0,
g_atype775_1,
g_atype775_2,
g_atype775_3,
g_atype775_4,
g_atype775_5,
};

static const long offsets775 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names776[];
static const uint32 types776 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags776 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype776_0 [] = {143,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype776_1 [] = {143,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype776_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype776_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype776_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype776_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes776 [] = {
g_atype776_0,
g_atype776_1,
g_atype776_2,
g_atype776_3,
g_atype776_4,
g_atype776_5,
};

static const long offsets776 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names777[];
static const uint32 types777 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags777 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype777_0 [] = {141,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_1 [] = {141,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes777 [] = {
g_atype777_0,
g_atype777_1,
g_atype777_2,
g_atype777_3,
g_atype777_4,
g_atype777_5,
};

static const long offsets777 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names778[];
static const uint32 types778 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags778 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype778_0 [] = {143,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype778_1 [] = {143,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype778_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype778_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype778_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype778_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes778 [] = {
g_atype778_0,
g_atype778_1,
g_atype778_2,
g_atype778_3,
g_atype778_4,
g_atype778_5,
};

static const long offsets778 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names779[];
static const uint32 types779 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags779 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype779_0 [] = {144,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype779_1 [] = {144,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype779_2 [] = {778,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype779_3 [] = {144,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype779_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype779_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype779_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype779_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes779 [] = {
g_atype779_0,
g_atype779_1,
g_atype779_2,
g_atype779_3,
g_atype779_4,
g_atype779_5,
g_atype779_6,
g_atype779_7,
};

static const long offsets779 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
};

extern const char *names780[];
static const uint32 types780 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags780 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype780_0 [] = {144,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype780_1 [] = {144,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype780_2 [] = {779,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype780_3 [] = {144,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype780_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype780_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype780_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype780_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes780 [] = {
g_atype780_0,
g_atype780_1,
g_atype780_2,
g_atype780_3,
g_atype780_4,
g_atype780_5,
g_atype780_6,
g_atype780_7,
};

static const long offsets780 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
};

extern const char *names782[];
static const uint32 types782 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags782 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype782_0 [] = {0xFF01,839,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype782_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype782_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype782_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes782 [] = {
g_atype782_0,
g_atype782_1,
g_atype782_2,
g_atype782_3,
};

static const long offsets782 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names783[];
static const uint32 types783 [] =
{
SK_INT32,
};

static const uint16 attr_flags783 [] =
{0,};

static const EIF_TYPE_INDEX g_atype783_0 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes783 [] = {
g_atype783_0,
};

static const long offsets783 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names784[];
static const uint32 types784 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags784 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype784_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype784_1 [] = {0xFF01,839,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype784_2 [] = {0xFF01,839,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype784_3 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype784_4 [] = {0xFF01,846,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype784_5 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype784_6 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype784_7 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype784_8 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype784_9 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype784_10 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype784_11 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype784_12 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype784_13 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype784_14 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype784_15 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype784_16 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes784 [] = {
g_atype784_0,
g_atype784_1,
g_atype784_2,
g_atype784_3,
g_atype784_4,
g_atype784_5,
g_atype784_6,
g_atype784_7,
g_atype784_8,
g_atype784_9,
g_atype784_10,
g_atype784_11,
g_atype784_12,
g_atype784_13,
g_atype784_14,
g_atype784_15,
g_atype784_16,
};

static const long offsets784 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @LNGOFF(7,3,0,0),
+ @LNGOFF(7,3,0,1),
+ @LNGOFF(7,3,0,2),
+ @LNGOFF(7,3,0,3),
+ @LNGOFF(7,3,0,4),
+ @LNGOFF(7,3,0,5),
+ @LNGOFF(7,3,0,6),
};

extern const char *names785[];
static const uint32 types785 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags785 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype785_0 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype785_1 [] = {0xFF01,839,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype785_2 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype785_3 [] = {0xFF01,846,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype785_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype785_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype785_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype785_7 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype785_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype785_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype785_10 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype785_11 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype785_12 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype785_13 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype785_14 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype785_15 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype785_16 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes785 [] = {
g_atype785_0,
g_atype785_1,
g_atype785_2,
g_atype785_3,
g_atype785_4,
g_atype785_5,
g_atype785_6,
g_atype785_7,
g_atype785_8,
g_atype785_9,
g_atype785_10,
g_atype785_11,
g_atype785_12,
g_atype785_13,
g_atype785_14,
g_atype785_15,
g_atype785_16,
};

static const long offsets785 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @LNGOFF(5,3,0,0),
+ @LNGOFF(5,3,0,1),
+ @LNGOFF(5,3,0,2),
+ @LNGOFF(5,3,0,3),
+ @LNGOFF(5,3,0,4),
+ @LNGOFF(5,3,0,5),
+ @LNGOFF(5,3,0,6),
+ @LNGOFF(5,3,0,7),
+ @LNGOFF(5,3,0,8),
};

extern const char *names786[];
static const uint32 types786 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags786 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype786_0 [] = {0xFF01,844,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_1 [] = {0xFF01,839,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_2 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_3 [] = {0xFF01,846,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_7 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_10 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_11 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_12 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_13 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_14 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_15 [] = {1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_16 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes786 [] = {
g_atype786_0,
g_atype786_1,
g_atype786_2,
g_atype786_3,
g_atype786_4,
g_atype786_5,
g_atype786_6,
g_atype786_7,
g_atype786_8,
g_atype786_9,
g_atype786_10,
g_atype786_11,
g_atype786_12,
g_atype786_13,
g_atype786_14,
g_atype786_15,
g_atype786_16,
};

static const long offsets786 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @LNGOFF(5,3,0,0),
+ @LNGOFF(5,3,0,1),
+ @LNGOFF(5,3,0,2),
+ @LNGOFF(5,3,0,3),
+ @LNGOFF(5,3,0,4),
+ @LNGOFF(5,3,0,5),
+ @LNGOFF(5,3,0,6),
+ @PTROFF(5,3,0,7,0,0),
+ @PTROFF(5,3,0,7,0,1),
};

extern const char *names787[];
static const uint32 types787 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags787 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype787_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_1 [] = {0xFF01,839,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_2 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_3 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_4 [] = {0xFF01,846,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_5 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_7 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_8 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_10 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_11 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_12 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_13 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_14 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_15 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_16 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes787 [] = {
g_atype787_0,
g_atype787_1,
g_atype787_2,
g_atype787_3,
g_atype787_4,
g_atype787_5,
g_atype787_6,
g_atype787_7,
g_atype787_8,
g_atype787_9,
g_atype787_10,
g_atype787_11,
g_atype787_12,
g_atype787_13,
g_atype787_14,
g_atype787_15,
g_atype787_16,
};

static const long offsets787 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @LNGOFF(6,3,0,0),
+ @LNGOFF(6,3,0,1),
+ @LNGOFF(6,3,0,2),
+ @LNGOFF(6,3,0,3),
+ @LNGOFF(6,3,0,4),
+ @LNGOFF(6,3,0,5),
+ @LNGOFF(6,3,0,6),
+ @LNGOFF(6,3,0,7),
};

extern const char *names788[];
static const uint32 types788 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags788 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype788_0 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_1 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_2 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_3 [] = {0xFF01,846,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_10 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_11 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_12 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_13 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_14 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_15 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_16 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes788 [] = {
g_atype788_0,
g_atype788_1,
g_atype788_2,
g_atype788_3,
g_atype788_4,
g_atype788_5,
g_atype788_6,
g_atype788_7,
g_atype788_8,
g_atype788_9,
g_atype788_10,
g_atype788_11,
g_atype788_12,
g_atype788_13,
g_atype788_14,
g_atype788_15,
g_atype788_16,
};

static const long offsets788 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @LNGOFF(4,3,0,3),
+ @LNGOFF(4,3,0,4),
+ @LNGOFF(4,3,0,5),
+ @LNGOFF(4,3,0,6),
+ @LNGOFF(4,3,0,7),
+ @LNGOFF(4,3,0,8),
+ @LNGOFF(4,3,0,9),
};

extern const char *names789[];
static const uint32 types789 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags789 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype789_0 [] = {0xFF01,846,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_1 [] = {0xFF01,839,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_2 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_3 [] = {0xFF01,846,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_7 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_8 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_9 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_10 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_11 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_12 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_13 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_14 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_15 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_16 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes789 [] = {
g_atype789_0,
g_atype789_1,
g_atype789_2,
g_atype789_3,
g_atype789_4,
g_atype789_5,
g_atype789_6,
g_atype789_7,
g_atype789_8,
g_atype789_9,
g_atype789_10,
g_atype789_11,
g_atype789_12,
g_atype789_13,
g_atype789_14,
g_atype789_15,
g_atype789_16,
};

static const long offsets789 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @LNGOFF(5,5,0,0),
+ @LNGOFF(5,5,0,1),
+ @LNGOFF(5,5,0,2),
+ @LNGOFF(5,5,0,3),
+ @LNGOFF(5,5,0,4),
+ @LNGOFF(5,5,0,5),
+ @LNGOFF(5,5,0,6),
};

extern const char *names790[];
static const uint32 types790 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags790 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype790_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_1 [] = {0xFF01,839,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_2 [] = {0xFF01,839,0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_3 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_4 [] = {0xFF01,846,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_5 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_6 [] = {1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_7 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_8 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_9 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_10 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_11 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_12 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_13 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_14 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_15 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_16 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype790_17 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes790 [] = {
g_atype790_0,
g_atype790_1,
g_atype790_2,
g_atype790_3,
g_atype790_4,
g_atype790_5,
g_atype790_6,
g_atype790_7,
g_atype790_8,
g_atype790_9,
g_atype790_10,
g_atype790_11,
g_atype790_12,
g_atype790_13,
g_atype790_14,
g_atype790_15,
g_atype790_16,
g_atype790_17,
};

static const long offsets790 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @LNGOFF(7,4,0,0),
+ @LNGOFF(7,4,0,1),
+ @LNGOFF(7,4,0,2),
+ @LNGOFF(7,4,0,3),
+ @LNGOFF(7,4,0,4),
+ @LNGOFF(7,4,0,5),
+ @LNGOFF(7,4,0,6),
};

extern const char *names791[];
static const uint32 types791 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags791 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype791_0 [] = {0xFF01,846,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_1 [] = {0xFF01,839,0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_2 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_3 [] = {0xFF01,846,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_4 [] = {1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_7 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_8 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_9 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_10 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_11 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_12 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_13 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_14 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_15 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_16 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype791_17 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes791 [] = {
g_atype791_0,
g_atype791_1,
g_atype791_2,
g_atype791_3,
g_atype791_4,
g_atype791_5,
g_atype791_6,
g_atype791_7,
g_atype791_8,
g_atype791_9,
g_atype791_10,
g_atype791_11,
g_atype791_12,
g_atype791_13,
g_atype791_14,
g_atype791_15,
g_atype791_16,
g_atype791_17,
};

static const long offsets791 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @LNGOFF(5,6,0,0),
+ @LNGOFF(5,6,0,1),
+ @LNGOFF(5,6,0,2),
+ @LNGOFF(5,6,0,3),
+ @LNGOFF(5,6,0,4),
+ @LNGOFF(5,6,0,5),
+ @LNGOFF(5,6,0,6),
};

extern const char *names792[];
static const uint32 types792 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags792 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype792_0 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_1 [] = {0xFF01,839,0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_2 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_3 [] = {0xFF01,846,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_4 [] = {1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_7 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_8 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_10 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_11 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_12 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_13 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_14 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_15 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_16 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype792_17 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes792 [] = {
g_atype792_0,
g_atype792_1,
g_atype792_2,
g_atype792_3,
g_atype792_4,
g_atype792_5,
g_atype792_6,
g_atype792_7,
g_atype792_8,
g_atype792_9,
g_atype792_10,
g_atype792_11,
g_atype792_12,
g_atype792_13,
g_atype792_14,
g_atype792_15,
g_atype792_16,
g_atype792_17,
};

static const long offsets792 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @LNGOFF(5,4,0,0),
+ @LNGOFF(5,4,0,1),
+ @LNGOFF(5,4,0,2),
+ @LNGOFF(5,4,0,3),
+ @LNGOFF(5,4,0,4),
+ @LNGOFF(5,4,0,5),
+ @LNGOFF(5,4,0,6),
+ @LNGOFF(5,4,0,7),
+ @LNGOFF(5,4,0,8),
};

extern const char *names793[];
static const uint32 types793 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags793 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype793_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_1 [] = {0xFF01,839,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_2 [] = {0xFF01,839,0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_3 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_4 [] = {0xFF01,846,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_5 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_6 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_7 [] = {1036,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_8 [] = {1036,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_9 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_10 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_11 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_12 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_13 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_14 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_15 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_16 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_17 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype793_18 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes793 [] = {
g_atype793_0,
g_atype793_1,
g_atype793_2,
g_atype793_3,
g_atype793_4,
g_atype793_5,
g_atype793_6,
g_atype793_7,
g_atype793_8,
g_atype793_9,
g_atype793_10,
g_atype793_11,
g_atype793_12,
g_atype793_13,
g_atype793_14,
g_atype793_15,
g_atype793_16,
g_atype793_17,
g_atype793_18,
};

static const long offsets793 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
+ @CHROFF(9,1),
+ @CHROFF(9,2),
+ @LNGOFF(9,3,0,0),
+ @LNGOFF(9,3,0,1),
+ @LNGOFF(9,3,0,2),
+ @LNGOFF(9,3,0,3),
+ @LNGOFF(9,3,0,4),
+ @LNGOFF(9,3,0,5),
+ @LNGOFF(9,3,0,6),
};

extern const char *names794[];
static const uint32 types794 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags794 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype794_0 [] = {0xFF01,839,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype794_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype794_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes794 [] = {
g_atype794_0,
g_atype794_1,
g_atype794_2,
};

static const long offsets794 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names795[];
static const uint32 types795 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags795 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype795_0 [] = {0xFF01,840,977,0xFFFF};
static const EIF_TYPE_INDEX g_atype795_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype795_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes795 [] = {
g_atype795_0,
g_atype795_1,
g_atype795_2,
};

static const long offsets795 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names796[];
static const uint32 types796 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags796 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype796_0 [] = {0xFF01,841,968,0xFFFF};
static const EIF_TYPE_INDEX g_atype796_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype796_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes796 [] = {
g_atype796_0,
g_atype796_1,
g_atype796_2,
};

static const long offsets796 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names797[];
static const uint32 types797 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags797 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype797_0 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype797_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype797_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes797 [] = {
g_atype797_0,
g_atype797_1,
g_atype797_2,
};

static const long offsets797 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names798[];
static const uint32 types798 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags798 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype798_0 [] = {0xFF01,843,974,0xFFFF};
static const EIF_TYPE_INDEX g_atype798_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype798_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes798 [] = {
g_atype798_0,
g_atype798_1,
g_atype798_2,
};

static const long offsets798 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names799[];
static const uint32 types799 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags799 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype799_0 [] = {0xFF01,844,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype799_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype799_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes799 [] = {
g_atype799_0,
g_atype799_1,
g_atype799_2,
};

static const long offsets799 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names800[];
static const uint32 types800 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags800 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype800_0 [] = {0xFF01,845,989,0xFFFF};
static const EIF_TYPE_INDEX g_atype800_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype800_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes800 [] = {
g_atype800_0,
g_atype800_1,
g_atype800_2,
};

static const long offsets800 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names801[];
static const uint32 types801 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags801 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype801_0 [] = {0xFF01,846,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype801_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype801_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes801 [] = {
g_atype801_0,
g_atype801_1,
g_atype801_2,
};

static const long offsets801 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names802[];
static const uint32 types802 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags802 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype802_0 [] = {0xFF01,847,971,0xFFFF};
static const EIF_TYPE_INDEX g_atype802_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype802_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes802 [] = {
g_atype802_0,
g_atype802_1,
g_atype802_2,
};

static const long offsets802 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names803[];
static const uint32 types803 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags803 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype803_0 [] = {0xFF01,848,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype803_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype803_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes803 [] = {
g_atype803_0,
g_atype803_1,
g_atype803_2,
};

static const long offsets803 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names804[];
static const uint32 types804 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags804 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype804_0 [] = {0xFF01,849,980,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes804 [] = {
g_atype804_0,
g_atype804_1,
g_atype804_2,
};

static const long offsets804 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names805[];
static const uint32 types805 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags805 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype805_0 [] = {0xFF01,850,983,0xFFFF};
static const EIF_TYPE_INDEX g_atype805_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype805_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes805 [] = {
g_atype805_0,
g_atype805_1,
g_atype805_2,
};

static const long offsets805 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names806[];
static const uint32 types806 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags806 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype806_0 [] = {0xFF01,839,0xFF01,23,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype806_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes806 [] = {
g_atype806_0,
g_atype806_1,
g_atype806_2,
};

static const long offsets806 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names807[];
static const uint32 types807 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags807 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype807_0 [] = {0xFF01,839,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype807_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype807_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes807 [] = {
g_atype807_0,
g_atype807_1,
g_atype807_2,
};

static const long offsets807 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names808[];
static const uint32 types808 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags808 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype808_0 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype808_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype808_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes808 [] = {
g_atype808_0,
g_atype808_1,
g_atype808_2,
};

static const long offsets808 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names809[];
static const uint32 types809 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags809 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype809_0 [] = {0xFF01,846,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype809_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype809_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes809 [] = {
g_atype809_0,
g_atype809_1,
g_atype809_2,
};

static const long offsets809 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names810[];
static const uint32 types810 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags810 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype810_0 [] = {0xFF01,839,0xFF01,326,0xFFFF};
static const EIF_TYPE_INDEX g_atype810_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype810_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes810 [] = {
g_atype810_0,
g_atype810_1,
g_atype810_2,
};

static const long offsets810 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names811[];
static const uint32 types811 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags811 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype811_0 [] = {0xFF01,839,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype811_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype811_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype811_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes811 [] = {
g_atype811_0,
g_atype811_1,
g_atype811_2,
g_atype811_3,
};

static const long offsets811 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @LNGOFF(1,2,0,0),
};

extern const char *names812[];
static const uint32 types812 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags812 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype812_0 [] = {0xFF01,839,0xFF01,1027,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype812_1 [] = {777,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype812_2 [] = {776,0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype812_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype812_4 [] = {706,0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype812_5 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype812_6 [] = {793,0xFF01,1027,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype812_7 [] = {793,0xFF01,1027,0xFF01,0xFFF9,0,953,0xFFFF};
static const EIF_TYPE_INDEX g_atype812_8 [] = {793,0xFF01,1027,0xFF01,0xFFF9,0,953,0xFFFF};
static const EIF_TYPE_INDEX g_atype812_9 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype812_10 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype812_11 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype812_12 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes812 [] = {
g_atype812_0,
g_atype812_1,
g_atype812_2,
g_atype812_3,
g_atype812_4,
g_atype812_5,
g_atype812_6,
g_atype812_7,
g_atype812_8,
g_atype812_9,
g_atype812_10,
g_atype812_11,
g_atype812_12,
};

static const long offsets812 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
+ @CHROFF(9,1),
+ @LNGOFF(9,2,0,0),
+ @LNGOFF(9,2,0,1),
};

extern const char *names813[];
static const uint32 types813 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags813 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype813_0 [] = {0xFF01,839,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype813_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype813_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype813_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes813 [] = {
g_atype813_0,
g_atype813_1,
g_atype813_2,
g_atype813_3,
};

static const long offsets813 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names814[];
static const uint32 types814 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags814 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype814_0 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype814_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype814_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype814_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes814 [] = {
g_atype814_0,
g_atype814_1,
g_atype814_2,
g_atype814_3,
};

static const long offsets814 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names815[];
static const uint32 types815 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags815 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype815_0 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype815_1 [] = {813,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype815_2 [] = {813,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype815_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype815_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype815_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes815 [] = {
g_atype815_0,
g_atype815_1,
g_atype815_2,
g_atype815_3,
g_atype815_4,
g_atype815_5,
};

static const long offsets815 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
+ @LNGOFF(3,1,0,1),
};

extern const char *names818[];
static const uint32 types818 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags818 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype818_0 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype818_1 [] = {0xFF01,845,989,0xFFFF};

static const EIF_TYPE_INDEX *gtypes818 [] = {
g_atype818_0,
g_atype818_1,
};

static const long offsets818 [] =
{
0,
 + @REFACS(1),
};

extern const char *names819[];
static const uint32 types819 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR32,
};

static const uint16 attr_flags819 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype819_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype819_1 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype819_2 [] = {0xFF01,848,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype819_3 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype819_4 [] = {986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes819 [] = {
g_atype819_0,
g_atype819_1,
g_atype819_2,
g_atype819_3,
g_atype819_4,
};

static const long offsets819 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
};

extern const char *names820[];
static const uint32 types820 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags820 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype820_0 [] = {0xFF01,271,0xFFFF};
static const EIF_TYPE_INDEX g_atype820_1 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes820 [] = {
g_atype820_0,
g_atype820_1,
};

static const long offsets820 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names821[];
static const uint32 types821 [] =
{
SK_REF,
SK_CHAR8,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags821 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype821_0 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype821_1 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype821_2 [] = {977,0xFFFF};
static const EIF_TYPE_INDEX g_atype821_3 [] = {965,0xFFFF};
static const EIF_TYPE_INDEX g_atype821_4 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype821_5 [] = {962,0xFFFF};
static const EIF_TYPE_INDEX g_atype821_6 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype821_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype821_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype821_9 [] = {980,0xFFFF};
static const EIF_TYPE_INDEX g_atype821_10 [] = {968,0xFFFF};
static const EIF_TYPE_INDEX g_atype821_11 [] = {956,0xFFFF};
static const EIF_TYPE_INDEX g_atype821_12 [] = {983,0xFFFF};

static const EIF_TYPE_INDEX *gtypes821 [] = {
g_atype821_0,
g_atype821_1,
g_atype821_2,
g_atype821_3,
g_atype821_4,
g_atype821_5,
g_atype821_6,
g_atype821_7,
g_atype821_8,
g_atype821_9,
g_atype821_10,
g_atype821_11,
g_atype821_12,
};

static const long offsets821 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @I16OFF(1,3,0),
+ @I16OFF(1,3,1),
+ @LNGOFF(1,3,2,0),
+ @LNGOFF(1,3,2,1),
+ @LNGOFF(1,3,2,2),
+ @R32OFF(1,3,2,3,0),
+ @I64OFF(1,3,2,3,1,0,0),
+ @I64OFF(1,3,2,3,1,0,1),
+ @R64OFF(1,3,2,3,1,0,2,0),
};

extern const char *names822[];
static const uint32 types822 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags822 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype822_0 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_1 [] = {0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_2 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_3 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_4 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_7 [] = {977,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_8 [] = {965,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_9 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_10 [] = {962,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_11 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_12 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_13 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_14 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_15 [] = {980,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_16 [] = {1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_17 [] = {968,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_18 [] = {956,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_19 [] = {983,0xFFFF};

static const EIF_TYPE_INDEX *gtypes822 [] = {
g_atype822_0,
g_atype822_1,
g_atype822_2,
g_atype822_3,
g_atype822_4,
g_atype822_5,
g_atype822_6,
g_atype822_7,
g_atype822_8,
g_atype822_9,
g_atype822_10,
g_atype822_11,
g_atype822_12,
g_atype822_13,
g_atype822_14,
g_atype822_15,
g_atype822_16,
g_atype822_17,
g_atype822_18,
g_atype822_19,
};

static const long offsets822 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @CHROFF(3,3),
+ @CHROFF(3,4),
+ @CHROFF(3,5),
+ @I16OFF(3,6,0),
+ @I16OFF(3,6,1),
+ @LNGOFF(3,6,2,0),
+ @LNGOFF(3,6,2,1),
+ @LNGOFF(3,6,2,2),
+ @LNGOFF(3,6,2,3),
+ @R32OFF(3,6,2,4,0),
+ @PTROFF(3,6,2,4,1,0),
+ @I64OFF(3,6,2,4,1,1,0),
+ @I64OFF(3,6,2,4,1,1,1),
+ @R64OFF(3,6,2,4,1,1,2,0),
};

extern const char *names823[];
static const uint32 types823 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags823 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype823_0 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_1 [] = {0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_2 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_4 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_5 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_7 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_8 [] = {977,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_9 [] = {965,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_10 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_11 [] = {962,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_12 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_13 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_14 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_15 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_16 [] = {980,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_17 [] = {1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_18 [] = {968,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_19 [] = {956,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_20 [] = {983,0xFFFF};

static const EIF_TYPE_INDEX *gtypes823 [] = {
g_atype823_0,
g_atype823_1,
g_atype823_2,
g_atype823_3,
g_atype823_4,
g_atype823_5,
g_atype823_6,
g_atype823_7,
g_atype823_8,
g_atype823_9,
g_atype823_10,
g_atype823_11,
g_atype823_12,
g_atype823_13,
g_atype823_14,
g_atype823_15,
g_atype823_16,
g_atype823_17,
g_atype823_18,
g_atype823_19,
g_atype823_20,
};

static const long offsets823 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @I16OFF(4,6,0),
+ @I16OFF(4,6,1),
+ @LNGOFF(4,6,2,0),
+ @LNGOFF(4,6,2,1),
+ @LNGOFF(4,6,2,2),
+ @LNGOFF(4,6,2,3),
+ @R32OFF(4,6,2,4,0),
+ @PTROFF(4,6,2,4,1,0),
+ @I64OFF(4,6,2,4,1,1,0),
+ @I64OFF(4,6,2,4,1,1,1),
+ @R64OFF(4,6,2,4,1,1,2,0),
};

extern const char *names824[];
static const uint32 types824 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags824 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype824_0 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_1 [] = {0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_2 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_3 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_4 [] = {45,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_5 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_6 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_7 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_8 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_9 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_10 [] = {977,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_11 [] = {965,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_12 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_13 [] = {962,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_14 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_15 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_16 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_17 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_18 [] = {980,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_19 [] = {1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_20 [] = {968,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_21 [] = {956,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_22 [] = {983,0xFFFF};

static const EIF_TYPE_INDEX *gtypes824 [] = {
g_atype824_0,
g_atype824_1,
g_atype824_2,
g_atype824_3,
g_atype824_4,
g_atype824_5,
g_atype824_6,
g_atype824_7,
g_atype824_8,
g_atype824_9,
g_atype824_10,
g_atype824_11,
g_atype824_12,
g_atype824_13,
g_atype824_14,
g_atype824_15,
g_atype824_16,
g_atype824_17,
g_atype824_18,
g_atype824_19,
g_atype824_20,
g_atype824_21,
g_atype824_22,
};

static const long offsets824 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @I16OFF(5,7,0),
+ @I16OFF(5,7,1),
+ @LNGOFF(5,7,2,0),
+ @LNGOFF(5,7,2,1),
+ @LNGOFF(5,7,2,2),
+ @LNGOFF(5,7,2,3),
+ @R32OFF(5,7,2,4,0),
+ @PTROFF(5,7,2,4,1,0),
+ @I64OFF(5,7,2,4,1,1,0),
+ @I64OFF(5,7,2,4,1,1,1),
+ @R64OFF(5,7,2,4,1,1,2,0),
};

extern const char *names834[];
static const uint32 types834 [] =
{
SK_REF,
};

static const uint16 attr_flags834 [] =
{0,};

static const EIF_TYPE_INDEX g_atype834_0 [] = {0xFF01,1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes834 [] = {
g_atype834_0,
};

static const long offsets834 [] =
{
0,
};

extern const char *names837[];
static const uint32 types837 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags837 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype837_0 [] = {0xFF01,1035,0xFFFF};
static const EIF_TYPE_INDEX g_atype837_1 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype837_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype837_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype837_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype837_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype837_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype837_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype837_8 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes837 [] = {
g_atype837_0,
g_atype837_1,
g_atype837_2,
g_atype837_3,
g_atype837_4,
g_atype837_5,
g_atype837_6,
g_atype837_7,
g_atype837_8,
};

static const long offsets837 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
+ @LNGOFF(2,2,0,1),
+ @LNGOFF(2,2,0,2),
+ @LNGOFF(2,2,0,3),
+ @LNGOFF(2,2,0,4),
};

extern const char *names838[];
static const uint32 types838 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags838 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype838_0 [] = {0xFF01,1090,0xFFFF};
static const EIF_TYPE_INDEX g_atype838_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype838_2 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype838_3 [] = {837,0xFFFF};
static const EIF_TYPE_INDEX g_atype838_4 [] = {0xFF01,800,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype838_5 [] = {793,837,0xFFFF};
static const EIF_TYPE_INDEX g_atype838_6 [] = {793,0xFF01,851,0xFFFF};
static const EIF_TYPE_INDEX g_atype838_7 [] = {0xFF01,0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype838_8 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype838_9 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype838_10 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype838_11 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype838_12 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype838_13 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype838_14 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes838 [] = {
g_atype838_0,
g_atype838_1,
g_atype838_2,
g_atype838_3,
g_atype838_4,
g_atype838_5,
g_atype838_6,
g_atype838_7,
g_atype838_8,
g_atype838_9,
g_atype838_10,
g_atype838_11,
g_atype838_12,
g_atype838_13,
g_atype838_14,
};

static const long offsets838 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @CHROFF(8,1),
+ @CHROFF(8,2),
+ @CHROFF(8,3),
+ @LNGOFF(8,4,0,0),
+ @LNGOFF(8,4,0,1),
+ @LNGOFF(8,4,0,2),
};

extern const char *names852[];
static const uint32 types852 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags852 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype852_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype852_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype852_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes852 [] = {
g_atype852_0,
g_atype852_1,
g_atype852_2,
};

static const long offsets852 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names853[];
static const uint32 types853 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags853 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype853_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype853_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype853_2 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype853_3 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype853_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype853_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes853 [] = {
g_atype853_0,
g_atype853_1,
g_atype853_2,
g_atype853_3,
g_atype853_4,
g_atype853_5,
};

static const long offsets853 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names854[];
static const uint32 types854 [] =
{
SK_REF,
SK_REF,
SK_INT8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags854 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype854_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype854_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype854_2 [] = {965,0xFFFF};
static const EIF_TYPE_INDEX g_atype854_3 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype854_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype854_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes854 [] = {
g_atype854_0,
g_atype854_1,
g_atype854_2,
g_atype854_3,
g_atype854_4,
g_atype854_5,
};

static const long offsets854 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names855[];
static const uint32 types855 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags855 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype855_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes855 [] = {
g_atype855_0,
g_atype855_1,
g_atype855_2,
g_atype855_3,
g_atype855_4,
g_atype855_5,
};

static const long offsets855 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names856[];
static const uint32 types856 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags856 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype856_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_5 [] = {983,0xFFFF};

static const EIF_TYPE_INDEX *gtypes856 [] = {
g_atype856_0,
g_atype856_1,
g_atype856_2,
g_atype856_3,
g_atype856_4,
g_atype856_5,
};

static const long offsets856 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @R64OFF(2,0,0,3,0,0,0,0),
};

extern const char *names857[];
static const uint32 types857 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags857 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype857_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_5 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes857 [] = {
g_atype857_0,
g_atype857_1,
g_atype857_2,
g_atype857_3,
g_atype857_4,
g_atype857_5,
};

static const long offsets857 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @PTROFF(2,0,0,3,0,0),
};

extern const char *names858[];
static const uint32 types858 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags858 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype858_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_5 [] = {968,0xFFFF};

static const EIF_TYPE_INDEX *gtypes858 [] = {
g_atype858_0,
g_atype858_1,
g_atype858_2,
g_atype858_3,
g_atype858_4,
g_atype858_5,
};

static const long offsets858 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @I64OFF(2,0,0,3,0,0,0),
};

extern const char *names859[];
static const uint32 types859 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags859 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype859_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_3 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes859 [] = {
g_atype859_0,
g_atype859_1,
g_atype859_2,
g_atype859_3,
g_atype859_4,
g_atype859_5,
};

static const long offsets859 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names860[];
static const uint32 types860 [] =
{
SK_REF,
SK_REF,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags860 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype860_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_2 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_3 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes860 [] = {
g_atype860_0,
g_atype860_1,
g_atype860_2,
g_atype860_3,
g_atype860_4,
g_atype860_5,
};

static const long offsets860 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
+ @LNGOFF(2,0,1,2),
};

extern const char *names861[];
static const uint32 types861 [] =
{
SK_REF,
SK_REF,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags861 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype861_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_2 [] = {962,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_3 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes861 [] = {
g_atype861_0,
g_atype861_1,
g_atype861_2,
g_atype861_3,
g_atype861_4,
g_atype861_5,
};

static const long offsets861 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
+ @LNGOFF(2,0,1,2),
};

extern const char *names862[];
static const uint32 types862 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags862 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype862_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_2 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_3 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes862 [] = {
g_atype862_0,
g_atype862_1,
g_atype862_2,
g_atype862_3,
g_atype862_4,
g_atype862_5,
};

static const long offsets862 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names863[];
static const uint32 types863 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags863 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype863_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_5 [] = {956,0xFFFF};

static const EIF_TYPE_INDEX *gtypes863 [] = {
g_atype863_0,
g_atype863_1,
g_atype863_2,
g_atype863_3,
g_atype863_4,
g_atype863_5,
};

static const long offsets863 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @I64OFF(2,0,0,3,0,0,0),
};

extern const char *names864[];
static const uint32 types864 [] =
{
SK_REF,
SK_REF,
SK_UINT8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags864 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype864_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_2 [] = {977,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_3 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes864 [] = {
g_atype864_0,
g_atype864_1,
g_atype864_2,
g_atype864_3,
g_atype864_4,
g_atype864_5,
};

static const long offsets864 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names865[];
static const uint32 types865 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags865 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype865_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype865_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype865_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype865_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype865_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype865_5 [] = {980,0xFFFF};

static const EIF_TYPE_INDEX *gtypes865 [] = {
g_atype865_0,
g_atype865_1,
g_atype865_2,
g_atype865_3,
g_atype865_4,
g_atype865_5,
};

static const long offsets865 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @R32OFF(2,0,0,3,0),
};

extern const char *names866[];
static const uint32 types866 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags866 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype866_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype866_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype866_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype866_3 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype866_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype866_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes866 [] = {
g_atype866_0,
g_atype866_1,
g_atype866_2,
g_atype866_3,
g_atype866_4,
g_atype866_5,
};

static const long offsets866 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names867[];
static const uint32 types867 [] =
{
SK_REF,
SK_REF,
SK_CHAR32,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags867 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype867_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype867_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype867_2 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype867_3 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype867_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype867_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes867 [] = {
g_atype867_0,
g_atype867_1,
g_atype867_2,
g_atype867_3,
g_atype867_4,
g_atype867_5,
};

static const long offsets867 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names868[];
static const uint32 types868 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags868 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype868_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype868_1 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype868_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype868_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype868_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype868_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes868 [] = {
g_atype868_0,
g_atype868_1,
g_atype868_2,
g_atype868_3,
g_atype868_4,
g_atype868_5,
};

static const long offsets868 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names869[];
static const uint32 types869 [] =
{
SK_REF,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags869 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype869_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype869_1 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype869_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype869_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype869_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype869_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes869 [] = {
g_atype869_0,
g_atype869_1,
g_atype869_2,
g_atype869_3,
g_atype869_4,
g_atype869_5,
};

static const long offsets869 [] =
{
0,
+ @I16OFF(1,0,0),
+ @LNGOFF(1,0,1,0),
+ @LNGOFF(1,0,1,1),
+ @LNGOFF(1,0,1,2),
+ @LNGOFF(1,0,1,3),
};

extern const char *names870[];
static const uint32 types870 [] =
{
SK_REF,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags870 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype870_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype870_1 [] = {962,0xFFFF};
static const EIF_TYPE_INDEX g_atype870_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype870_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype870_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype870_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes870 [] = {
g_atype870_0,
g_atype870_1,
g_atype870_2,
g_atype870_3,
g_atype870_4,
g_atype870_5,
};

static const long offsets870 [] =
{
0,
+ @I16OFF(1,0,0),
+ @LNGOFF(1,0,1,0),
+ @LNGOFF(1,0,1,1),
+ @LNGOFF(1,0,1,2),
+ @LNGOFF(1,0,1,3),
};

extern const char *names871[];
static const uint32 types871 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags871 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype871_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype871_1 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype871_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype871_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype871_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype871_5 [] = {956,0xFFFF};

static const EIF_TYPE_INDEX *gtypes871 [] = {
g_atype871_0,
g_atype871_1,
g_atype871_2,
g_atype871_3,
g_atype871_4,
g_atype871_5,
};

static const long offsets871 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @I64OFF(1,0,0,4,0,0,0),
};

extern const char *names872[];
static const uint32 types872 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags872 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype872_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype872_1 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype872_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype872_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype872_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype872_5 [] = {980,0xFFFF};

static const EIF_TYPE_INDEX *gtypes872 [] = {
g_atype872_0,
g_atype872_1,
g_atype872_2,
g_atype872_3,
g_atype872_4,
g_atype872_5,
};

static const long offsets872 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @R32OFF(1,0,0,4,0),
};

extern const char *names873[];
static const uint32 types873 [] =
{
SK_REF,
SK_CHAR32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags873 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype873_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype873_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype873_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype873_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype873_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype873_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes873 [] = {
g_atype873_0,
g_atype873_1,
g_atype873_2,
g_atype873_3,
g_atype873_4,
g_atype873_5,
};

static const long offsets873 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names874[];
static const uint32 types874 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags874 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype874_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype874_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype874_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype874_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype874_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype874_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes874 [] = {
g_atype874_0,
g_atype874_1,
g_atype874_2,
g_atype874_3,
g_atype874_4,
g_atype874_5,
};

static const long offsets874 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names875[];
static const uint32 types875 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags875 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype875_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype875_1 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype875_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype875_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype875_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype875_5 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes875 [] = {
g_atype875_0,
g_atype875_1,
g_atype875_2,
g_atype875_3,
g_atype875_4,
g_atype875_5,
};

static const long offsets875 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @PTROFF(1,0,0,4,0,0),
};

extern const char *names876[];
static const uint32 types876 [] =
{
SK_REF,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags876 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype876_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype876_1 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype876_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype876_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype876_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype876_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes876 [] = {
g_atype876_0,
g_atype876_1,
g_atype876_2,
g_atype876_3,
g_atype876_4,
g_atype876_5,
};

static const long offsets876 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names877[];
static const uint32 types877 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags877 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype877_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype877_1 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype877_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype877_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype877_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype877_5 [] = {968,0xFFFF};

static const EIF_TYPE_INDEX *gtypes877 [] = {
g_atype877_0,
g_atype877_1,
g_atype877_2,
g_atype877_3,
g_atype877_4,
g_atype877_5,
};

static const long offsets877 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @I64OFF(1,0,0,4,0,0,0),
};

extern const char *names878[];
static const uint32 types878 [] =
{
SK_REF,
SK_INT8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags878 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype878_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype878_1 [] = {965,0xFFFF};
static const EIF_TYPE_INDEX g_atype878_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype878_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype878_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype878_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes878 [] = {
g_atype878_0,
g_atype878_1,
g_atype878_2,
g_atype878_3,
g_atype878_4,
g_atype878_5,
};

static const long offsets878 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names879[];
static const uint32 types879 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags879 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype879_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype879_1 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype879_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype879_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype879_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype879_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes879 [] = {
g_atype879_0,
g_atype879_1,
g_atype879_2,
g_atype879_3,
g_atype879_4,
g_atype879_5,
};

static const long offsets879 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names880[];
static const uint32 types880 [] =
{
SK_REF,
SK_CHAR8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags880 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype880_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_1 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes880 [] = {
g_atype880_0,
g_atype880_1,
g_atype880_2,
g_atype880_3,
g_atype880_4,
g_atype880_5,
};

static const long offsets880 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names881[];
static const uint32 types881 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags881 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype881_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype881_1 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype881_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype881_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype881_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype881_5 [] = {983,0xFFFF};

static const EIF_TYPE_INDEX *gtypes881 [] = {
g_atype881_0,
g_atype881_1,
g_atype881_2,
g_atype881_3,
g_atype881_4,
g_atype881_5,
};

static const long offsets881 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @R64OFF(1,0,0,4,0,0,0,0),
};

extern const char *names882[];
static const uint32 types882 [] =
{
SK_REF,
SK_UINT8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags882 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype882_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype882_1 [] = {977,0xFFFF};
static const EIF_TYPE_INDEX g_atype882_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype882_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype882_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype882_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes882 [] = {
g_atype882_0,
g_atype882_1,
g_atype882_2,
g_atype882_3,
g_atype882_4,
g_atype882_5,
};

static const long offsets882 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names883[];
static const uint32 types883 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags883 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype883_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype883_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype883_2 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype883_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype883_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes883 [] = {
g_atype883_0,
g_atype883_1,
g_atype883_2,
g_atype883_3,
g_atype883_4,
};

static const long offsets883 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
};

extern const char *names884[];
static const uint32 types884 [] =
{
SK_REF,
SK_REF,
SK_CHAR32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags884 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype884_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype884_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype884_2 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype884_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype884_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes884 [] = {
g_atype884_0,
g_atype884_1,
g_atype884_2,
g_atype884_3,
g_atype884_4,
};

static const long offsets884 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names885[];
static const uint32 types885 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags885 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype885_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_4 [] = {956,0xFFFF};

static const EIF_TYPE_INDEX *gtypes885 [] = {
g_atype885_0,
g_atype885_1,
g_atype885_2,
g_atype885_3,
g_atype885_4,
};

static const long offsets885 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @I64OFF(2,0,0,2,0,0,0),
};

extern const char *names886[];
static const uint32 types886 [] =
{
SK_REF,
SK_REF,
SK_INT16,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags886 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype886_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_2 [] = {962,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes886 [] = {
g_atype886_0,
g_atype886_1,
g_atype886_2,
g_atype886_3,
g_atype886_4,
};

static const long offsets886 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
};

extern const char *names887[];
static const uint32 types887 [] =
{
SK_REF,
SK_REF,
SK_UINT16,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags887 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype887_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_2 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes887 [] = {
g_atype887_0,
g_atype887_1,
g_atype887_2,
g_atype887_3,
g_atype887_4,
};

static const long offsets887 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
};

extern const char *names888[];
static const uint32 types888 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags888 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype888_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_4 [] = {980,0xFFFF};

static const EIF_TYPE_INDEX *gtypes888 [] = {
g_atype888_0,
g_atype888_1,
g_atype888_2,
g_atype888_3,
g_atype888_4,
};

static const long offsets888 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @R32OFF(2,0,0,2,0),
};

extern const char *names889[];
static const uint32 types889 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags889 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype889_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype889_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype889_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype889_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype889_4 [] = {983,0xFFFF};

static const EIF_TYPE_INDEX *gtypes889 [] = {
g_atype889_0,
g_atype889_1,
g_atype889_2,
g_atype889_3,
g_atype889_4,
};

static const long offsets889 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @R64OFF(2,0,0,2,0,0,0,0),
};

extern const char *names890[];
static const uint32 types890 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags890 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype890_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype890_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype890_2 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype890_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype890_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes890 [] = {
g_atype890_0,
g_atype890_1,
g_atype890_2,
g_atype890_3,
g_atype890_4,
};

static const long offsets890 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names891[];
static const uint32 types891 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags891 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype891_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype891_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype891_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype891_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype891_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes891 [] = {
g_atype891_0,
g_atype891_1,
g_atype891_2,
g_atype891_3,
g_atype891_4,
};

static const long offsets891 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names892[];
static const uint32 types892 [] =
{
SK_REF,
SK_REF,
SK_INT8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags892 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype892_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype892_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype892_2 [] = {965,0xFFFF};
static const EIF_TYPE_INDEX g_atype892_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype892_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes892 [] = {
g_atype892_0,
g_atype892_1,
g_atype892_2,
g_atype892_3,
g_atype892_4,
};

static const long offsets892 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names893[];
static const uint32 types893 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags893 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype893_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype893_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype893_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype893_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype893_4 [] = {968,0xFFFF};

static const EIF_TYPE_INDEX *gtypes893 [] = {
g_atype893_0,
g_atype893_1,
g_atype893_2,
g_atype893_3,
g_atype893_4,
};

static const long offsets893 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @I64OFF(2,0,0,2,0,0,0),
};

extern const char *names894[];
static const uint32 types894 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags894 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype894_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype894_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype894_2 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype894_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype894_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes894 [] = {
g_atype894_0,
g_atype894_1,
g_atype894_2,
g_atype894_3,
g_atype894_4,
};

static const long offsets894 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names895[];
static const uint32 types895 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags895 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype895_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype895_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype895_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype895_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype895_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes895 [] = {
g_atype895_0,
g_atype895_1,
g_atype895_2,
g_atype895_3,
g_atype895_4,
};

static const long offsets895 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names896[];
static const uint32 types896 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags896 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype896_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype896_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype896_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype896_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype896_4 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes896 [] = {
g_atype896_0,
g_atype896_1,
g_atype896_2,
g_atype896_3,
g_atype896_4,
};

static const long offsets896 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @PTROFF(2,0,0,2,0,0),
};

extern const char *names897[];
static const uint32 types897 [] =
{
SK_REF,
SK_REF,
SK_UINT8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags897 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype897_0 [] = {0xFFF9,2,953,959,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype897_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype897_2 [] = {977,0xFFFF};
static const EIF_TYPE_INDEX g_atype897_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype897_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes897 [] = {
g_atype897_0,
g_atype897_1,
g_atype897_2,
g_atype897_3,
g_atype897_4,
};

static const long offsets897 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names912[];
static const uint32 types912 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
};

static const uint16 attr_flags912 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype912_0 [] = {86,989,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_1 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_2 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype912_3 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes912 [] = {
g_atype912_0,
g_atype912_1,
g_atype912_2,
g_atype912_3,
};

static const long offsets912 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
};

extern const char *names913[];
static const uint32 types913 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags913 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype913_0 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype913_1 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype913_2 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype913_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype913_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes913 [] = {
g_atype913_0,
g_atype913_1,
g_atype913_2,
g_atype913_3,
g_atype913_4,
};

static const long offsets913 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
};

extern const char *names918[];
static const uint32 types918 [] =
{
SK_INT32,
};

static const uint16 attr_flags918 [] =
{0,};

static const EIF_TYPE_INDEX g_atype918_0 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes918 [] = {
g_atype918_0,
};

static const long offsets918 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names919[];
static const uint32 types919 [] =
{
SK_UINT16,
SK_UINT16,
SK_UINT16,
SK_UINT32,
SK_UINT64,
};

static const uint16 attr_flags919 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype919_0 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype919_1 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype919_2 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype919_3 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype919_4 [] = {968,0xFFFF};

static const EIF_TYPE_INDEX *gtypes919 [] = {
g_atype919_0,
g_atype919_1,
g_atype919_2,
g_atype919_3,
g_atype919_4,
};

static const long offsets919 [] =
{
+ @I16OFF(0,0,0),
+ @I16OFF(0,0,1),
+ @I16OFF(0,0,2),
+ @LNGOFF(0,0,3,0),
+ @I64OFF(0,0,3,1,0,0,0),
};

extern const char *names920[];
static const uint32 types920 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags920 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype920_0 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype920_1 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype920_2 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes920 [] = {
g_atype920_0,
g_atype920_1,
g_atype920_2,
};

static const long offsets920 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
};

extern const char *names921[];
static const uint32 types921 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags921 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype921_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype921_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes921 [] = {
g_atype921_0,
g_atype921_1,
};

static const long offsets921 [] =
{
0,
 + @REFACS(1),
};

extern const char *names922[];
static const uint32 types922 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags922 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype922_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype922_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes922 [] = {
g_atype922_0,
g_atype922_1,
};

static const long offsets922 [] =
{
0,
 + @REFACS(1),
};

extern const char *names923[];
static const uint32 types923 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags923 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype923_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype923_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes923 [] = {
g_atype923_0,
g_atype923_1,
};

static const long offsets923 [] =
{
0,
 + @REFACS(1),
};

extern const char *names924[];
static const uint32 types924 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags924 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype924_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype924_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes924 [] = {
g_atype924_0,
g_atype924_1,
};

static const long offsets924 [] =
{
0,
 + @REFACS(1),
};

extern const char *names925[];
static const uint32 types925 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags925 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype925_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype925_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes925 [] = {
g_atype925_0,
g_atype925_1,
};

static const long offsets925 [] =
{
0,
 + @REFACS(1),
};

extern const char *names926[];
static const uint32 types926 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags926 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype926_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype926_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes926 [] = {
g_atype926_0,
g_atype926_1,
};

static const long offsets926 [] =
{
0,
 + @REFACS(1),
};

extern const char *names927[];
static const uint32 types927 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags927 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype927_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype927_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes927 [] = {
g_atype927_0,
g_atype927_1,
};

static const long offsets927 [] =
{
0,
 + @REFACS(1),
};

extern const char *names928[];
static const uint32 types928 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags928 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype928_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype928_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes928 [] = {
g_atype928_0,
g_atype928_1,
};

static const long offsets928 [] =
{
0,
 + @REFACS(1),
};

extern const char *names929[];
static const uint32 types929 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags929 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype929_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype929_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes929 [] = {
g_atype929_0,
g_atype929_1,
};

static const long offsets929 [] =
{
0,
 + @REFACS(1),
};

extern const char *names930[];
static const uint32 types930 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags930 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype930_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype930_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes930 [] = {
g_atype930_0,
g_atype930_1,
};

static const long offsets930 [] =
{
0,
 + @REFACS(1),
};

extern const char *names931[];
static const uint32 types931 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags931 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype931_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype931_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes931 [] = {
g_atype931_0,
g_atype931_1,
};

static const long offsets931 [] =
{
0,
 + @REFACS(1),
};

extern const char *names932[];
static const uint32 types932 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags932 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype932_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype932_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes932 [] = {
g_atype932_0,
g_atype932_1,
};

static const long offsets932 [] =
{
0,
 + @REFACS(1),
};

extern const char *names933[];
static const uint32 types933 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags933 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype933_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype933_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes933 [] = {
g_atype933_0,
g_atype933_1,
};

static const long offsets933 [] =
{
0,
 + @REFACS(1),
};

extern const char *names934[];
static const uint32 types934 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags934 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype934_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype934_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes934 [] = {
g_atype934_0,
g_atype934_1,
};

static const long offsets934 [] =
{
0,
 + @REFACS(1),
};

extern const char *names935[];
static const uint32 types935 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags935 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype935_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype935_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes935 [] = {
g_atype935_0,
g_atype935_1,
};

static const long offsets935 [] =
{
0,
 + @REFACS(1),
};

extern const char *names936[];
static const uint32 types936 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags936 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype936_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype936_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes936 [] = {
g_atype936_0,
g_atype936_1,
};

static const long offsets936 [] =
{
0,
 + @REFACS(1),
};

extern const char *names937[];
static const uint32 types937 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags937 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype937_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype937_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes937 [] = {
g_atype937_0,
g_atype937_1,
};

static const long offsets937 [] =
{
0,
 + @REFACS(1),
};

extern const char *names938[];
static const uint32 types938 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags938 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype938_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes938 [] = {
g_atype938_0,
g_atype938_1,
};

static const long offsets938 [] =
{
0,
 + @REFACS(1),
};

extern const char *names939[];
static const uint32 types939 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags939 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype939_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype939_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes939 [] = {
g_atype939_0,
g_atype939_1,
};

static const long offsets939 [] =
{
0,
 + @REFACS(1),
};

extern const char *names940[];
static const uint32 types940 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags940 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype940_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype940_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes940 [] = {
g_atype940_0,
g_atype940_1,
};

static const long offsets940 [] =
{
0,
 + @REFACS(1),
};

extern const char *names941[];
static const uint32 types941 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags941 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype941_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype941_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes941 [] = {
g_atype941_0,
g_atype941_1,
};

static const long offsets941 [] =
{
0,
 + @REFACS(1),
};

extern const char *names942[];
static const uint32 types942 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags942 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype942_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes942 [] = {
g_atype942_0,
g_atype942_1,
};

static const long offsets942 [] =
{
0,
 + @REFACS(1),
};

extern const char *names943[];
static const uint32 types943 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags943 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype943_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype943_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes943 [] = {
g_atype943_0,
g_atype943_1,
};

static const long offsets943 [] =
{
0,
 + @REFACS(1),
};

extern const char *names944[];
static const uint32 types944 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags944 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype944_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype944_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes944 [] = {
g_atype944_0,
g_atype944_1,
};

static const long offsets944 [] =
{
0,
 + @REFACS(1),
};

extern const char *names945[];
static const uint32 types945 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags945 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype945_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype945_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes945 [] = {
g_atype945_0,
g_atype945_1,
};

static const long offsets945 [] =
{
0,
 + @REFACS(1),
};

extern const char *names946[];
static const uint32 types946 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags946 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype946_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype946_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes946 [] = {
g_atype946_0,
g_atype946_1,
};

static const long offsets946 [] =
{
0,
 + @REFACS(1),
};

extern const char *names947[];
static const uint32 types947 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags947 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype947_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes947 [] = {
g_atype947_0,
g_atype947_1,
};

static const long offsets947 [] =
{
0,
 + @REFACS(1),
};

extern const char *names948[];
static const uint32 types948 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags948 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype948_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype948_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes948 [] = {
g_atype948_0,
g_atype948_1,
};

static const long offsets948 [] =
{
0,
 + @REFACS(1),
};

extern const char *names949[];
static const uint32 types949 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags949 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype949_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype949_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes949 [] = {
g_atype949_0,
g_atype949_1,
};

static const long offsets949 [] =
{
0,
 + @REFACS(1),
};

extern const char *names950[];
static const uint32 types950 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags950 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype950_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype950_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes950 [] = {
g_atype950_0,
g_atype950_1,
};

static const long offsets950 [] =
{
0,
 + @REFACS(1),
};

extern const char *names951[];
static const uint32 types951 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags951 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype951_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype951_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes951 [] = {
g_atype951_0,
g_atype951_1,
};

static const long offsets951 [] =
{
0,
 + @REFACS(1),
};

extern const char *names952[];
static const uint32 types952 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags952 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype952_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype952_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes952 [] = {
g_atype952_0,
g_atype952_1,
};

static const long offsets952 [] =
{
0,
 + @REFACS(1),
};

extern const char *names953[];
static const uint32 types953 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags953 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype953_0 [] = {1040,0xFFFF};
static const EIF_TYPE_INDEX g_atype953_1 [] = {1036,0xFFFF};

static const EIF_TYPE_INDEX *gtypes953 [] = {
g_atype953_0,
g_atype953_1,
};

static const long offsets953 [] =
{
0,
 + @REFACS(1),
};

extern const char *names955[];
static const uint32 types955 [] =
{
SK_INT64,
};

static const uint16 attr_flags955 [] =
{0,};

static const EIF_TYPE_INDEX g_atype955_0 [] = {956,0xFFFF};

static const EIF_TYPE_INDEX *gtypes955 [] = {
g_atype955_0,
};

static const long offsets955 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names956[];
static const uint32 types956 [] =
{
SK_INT64,
};

static const uint16 attr_flags956 [] =
{0,};

static const EIF_TYPE_INDEX g_atype956_0 [] = {956,0xFFFF};

static const EIF_TYPE_INDEX *gtypes956 [] = {
g_atype956_0,
};

static const long offsets956 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names957[];
static const uint32 types957 [] =
{
SK_INT64,
};

static const uint16 attr_flags957 [] =
{0,};

static const EIF_TYPE_INDEX g_atype957_0 [] = {956,0xFFFF};

static const EIF_TYPE_INDEX *gtypes957 [] = {
g_atype957_0,
};

static const long offsets957 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names958[];
static const uint32 types958 [] =
{
SK_INT32,
};

static const uint16 attr_flags958 [] =
{0,};

static const EIF_TYPE_INDEX g_atype958_0 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes958 [] = {
g_atype958_0,
};

static const long offsets958 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names959[];
static const uint32 types959 [] =
{
SK_INT32,
};

static const uint16 attr_flags959 [] =
{0,};

static const EIF_TYPE_INDEX g_atype959_0 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes959 [] = {
g_atype959_0,
};

static const long offsets959 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names960[];
static const uint32 types960 [] =
{
SK_INT32,
};

static const uint16 attr_flags960 [] =
{0,};

static const EIF_TYPE_INDEX g_atype960_0 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes960 [] = {
g_atype960_0,
};

static const long offsets960 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names961[];
static const uint32 types961 [] =
{
SK_INT16,
};

static const uint16 attr_flags961 [] =
{0,};

static const EIF_TYPE_INDEX g_atype961_0 [] = {962,0xFFFF};

static const EIF_TYPE_INDEX *gtypes961 [] = {
g_atype961_0,
};

static const long offsets961 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names962[];
static const uint32 types962 [] =
{
SK_INT16,
};

static const uint16 attr_flags962 [] =
{0,};

static const EIF_TYPE_INDEX g_atype962_0 [] = {962,0xFFFF};

static const EIF_TYPE_INDEX *gtypes962 [] = {
g_atype962_0,
};

static const long offsets962 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names963[];
static const uint32 types963 [] =
{
SK_INT16,
};

static const uint16 attr_flags963 [] =
{0,};

static const EIF_TYPE_INDEX g_atype963_0 [] = {962,0xFFFF};

static const EIF_TYPE_INDEX *gtypes963 [] = {
g_atype963_0,
};

static const long offsets963 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names964[];
static const uint32 types964 [] =
{
SK_INT8,
};

static const uint16 attr_flags964 [] =
{0,};

static const EIF_TYPE_INDEX g_atype964_0 [] = {965,0xFFFF};

static const EIF_TYPE_INDEX *gtypes964 [] = {
g_atype964_0,
};

static const long offsets964 [] =
{
+ @CHROFF(0,0),
};

extern const char *names965[];
static const uint32 types965 [] =
{
SK_INT8,
};

static const uint16 attr_flags965 [] =
{0,};

static const EIF_TYPE_INDEX g_atype965_0 [] = {965,0xFFFF};

static const EIF_TYPE_INDEX *gtypes965 [] = {
g_atype965_0,
};

static const long offsets965 [] =
{
+ @CHROFF(0,0),
};

extern const char *names966[];
static const uint32 types966 [] =
{
SK_INT8,
};

static const uint16 attr_flags966 [] =
{0,};

static const EIF_TYPE_INDEX g_atype966_0 [] = {965,0xFFFF};

static const EIF_TYPE_INDEX *gtypes966 [] = {
g_atype966_0,
};

static const long offsets966 [] =
{
+ @CHROFF(0,0),
};

extern const char *names967[];
static const uint32 types967 [] =
{
SK_UINT64,
};

static const uint16 attr_flags967 [] =
{0,};

static const EIF_TYPE_INDEX g_atype967_0 [] = {968,0xFFFF};

static const EIF_TYPE_INDEX *gtypes967 [] = {
g_atype967_0,
};

static const long offsets967 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names968[];
static const uint32 types968 [] =
{
SK_UINT64,
};

static const uint16 attr_flags968 [] =
{0,};

static const EIF_TYPE_INDEX g_atype968_0 [] = {968,0xFFFF};

static const EIF_TYPE_INDEX *gtypes968 [] = {
g_atype968_0,
};

static const long offsets968 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names969[];
static const uint32 types969 [] =
{
SK_UINT64,
};

static const uint16 attr_flags969 [] =
{0,};

static const EIF_TYPE_INDEX g_atype969_0 [] = {968,0xFFFF};

static const EIF_TYPE_INDEX *gtypes969 [] = {
g_atype969_0,
};

static const long offsets969 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names970[];
static const uint32 types970 [] =
{
SK_UINT32,
};

static const uint16 attr_flags970 [] =
{0,};

static const EIF_TYPE_INDEX g_atype970_0 [] = {971,0xFFFF};

static const EIF_TYPE_INDEX *gtypes970 [] = {
g_atype970_0,
};

static const long offsets970 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names971[];
static const uint32 types971 [] =
{
SK_UINT32,
};

static const uint16 attr_flags971 [] =
{0,};

static const EIF_TYPE_INDEX g_atype971_0 [] = {971,0xFFFF};

static const EIF_TYPE_INDEX *gtypes971 [] = {
g_atype971_0,
};

static const long offsets971 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names972[];
static const uint32 types972 [] =
{
SK_UINT32,
};

static const uint16 attr_flags972 [] =
{0,};

static const EIF_TYPE_INDEX g_atype972_0 [] = {971,0xFFFF};

static const EIF_TYPE_INDEX *gtypes972 [] = {
g_atype972_0,
};

static const long offsets972 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names973[];
static const uint32 types973 [] =
{
SK_UINT16,
};

static const uint16 attr_flags973 [] =
{0,};

static const EIF_TYPE_INDEX g_atype973_0 [] = {974,0xFFFF};

static const EIF_TYPE_INDEX *gtypes973 [] = {
g_atype973_0,
};

static const long offsets973 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names974[];
static const uint32 types974 [] =
{
SK_UINT16,
};

static const uint16 attr_flags974 [] =
{0,};

static const EIF_TYPE_INDEX g_atype974_0 [] = {974,0xFFFF};

static const EIF_TYPE_INDEX *gtypes974 [] = {
g_atype974_0,
};

static const long offsets974 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names975[];
static const uint32 types975 [] =
{
SK_UINT16,
};

static const uint16 attr_flags975 [] =
{0,};

static const EIF_TYPE_INDEX g_atype975_0 [] = {974,0xFFFF};

static const EIF_TYPE_INDEX *gtypes975 [] = {
g_atype975_0,
};

static const long offsets975 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names976[];
static const uint32 types976 [] =
{
SK_UINT8,
};

static const uint16 attr_flags976 [] =
{0,};

static const EIF_TYPE_INDEX g_atype976_0 [] = {977,0xFFFF};

static const EIF_TYPE_INDEX *gtypes976 [] = {
g_atype976_0,
};

static const long offsets976 [] =
{
+ @CHROFF(0,0),
};

extern const char *names977[];
static const uint32 types977 [] =
{
SK_UINT8,
};

static const uint16 attr_flags977 [] =
{0,};

static const EIF_TYPE_INDEX g_atype977_0 [] = {977,0xFFFF};

static const EIF_TYPE_INDEX *gtypes977 [] = {
g_atype977_0,
};

static const long offsets977 [] =
{
+ @CHROFF(0,0),
};

extern const char *names978[];
static const uint32 types978 [] =
{
SK_UINT8,
};

static const uint16 attr_flags978 [] =
{0,};

static const EIF_TYPE_INDEX g_atype978_0 [] = {977,0xFFFF};

static const EIF_TYPE_INDEX *gtypes978 [] = {
g_atype978_0,
};

static const long offsets978 [] =
{
+ @CHROFF(0,0),
};

extern const char *names979[];
static const uint32 types979 [] =
{
SK_REAL32,
};

static const uint16 attr_flags979 [] =
{0,};

static const EIF_TYPE_INDEX g_atype979_0 [] = {980,0xFFFF};

static const EIF_TYPE_INDEX *gtypes979 [] = {
g_atype979_0,
};

static const long offsets979 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names980[];
static const uint32 types980 [] =
{
SK_REAL32,
};

static const uint16 attr_flags980 [] =
{0,};

static const EIF_TYPE_INDEX g_atype980_0 [] = {980,0xFFFF};

static const EIF_TYPE_INDEX *gtypes980 [] = {
g_atype980_0,
};

static const long offsets980 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names981[];
static const uint32 types981 [] =
{
SK_REAL32,
};

static const uint16 attr_flags981 [] =
{0,};

static const EIF_TYPE_INDEX g_atype981_0 [] = {980,0xFFFF};

static const EIF_TYPE_INDEX *gtypes981 [] = {
g_atype981_0,
};

static const long offsets981 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names982[];
static const uint32 types982 [] =
{
SK_REAL64,
};

static const uint16 attr_flags982 [] =
{0,};

static const EIF_TYPE_INDEX g_atype982_0 [] = {983,0xFFFF};

static const EIF_TYPE_INDEX *gtypes982 [] = {
g_atype982_0,
};

static const long offsets982 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names983[];
static const uint32 types983 [] =
{
SK_REAL64,
};

static const uint16 attr_flags983 [] =
{0,};

static const EIF_TYPE_INDEX g_atype983_0 [] = {983,0xFFFF};

static const EIF_TYPE_INDEX *gtypes983 [] = {
g_atype983_0,
};

static const long offsets983 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names984[];
static const uint32 types984 [] =
{
SK_REAL64,
};

static const uint16 attr_flags984 [] =
{0,};

static const EIF_TYPE_INDEX g_atype984_0 [] = {983,0xFFFF};

static const EIF_TYPE_INDEX *gtypes984 [] = {
g_atype984_0,
};

static const long offsets984 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names985[];
static const uint32 types985 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags985 [] =
{0,};

static const EIF_TYPE_INDEX g_atype985_0 [] = {986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes985 [] = {
g_atype985_0,
};

static const long offsets985 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names986[];
static const uint32 types986 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags986 [] =
{0,};

static const EIF_TYPE_INDEX g_atype986_0 [] = {986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes986 [] = {
g_atype986_0,
};

static const long offsets986 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names987[];
static const uint32 types987 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags987 [] =
{0,};

static const EIF_TYPE_INDEX g_atype987_0 [] = {986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes987 [] = {
g_atype987_0,
};

static const long offsets987 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names988[];
static const uint32 types988 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags988 [] =
{0,};

static const EIF_TYPE_INDEX g_atype988_0 [] = {989,0xFFFF};

static const EIF_TYPE_INDEX *gtypes988 [] = {
g_atype988_0,
};

static const long offsets988 [] =
{
+ @CHROFF(0,0),
};

extern const char *names989[];
static const uint32 types989 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags989 [] =
{0,};

static const EIF_TYPE_INDEX g_atype989_0 [] = {989,0xFFFF};

static const EIF_TYPE_INDEX *gtypes989 [] = {
g_atype989_0,
};

static const long offsets989 [] =
{
+ @CHROFF(0,0),
};

extern const char *names990[];
static const uint32 types990 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags990 [] =
{0,};

static const EIF_TYPE_INDEX g_atype990_0 [] = {989,0xFFFF};

static const EIF_TYPE_INDEX *gtypes990 [] = {
g_atype990_0,
};

static const long offsets990 [] =
{
+ @CHROFF(0,0),
};

extern const char *names991[];
static const uint32 types991 [] =
{
SK_BOOL,
};

static const uint16 attr_flags991 [] =
{0,};

static const EIF_TYPE_INDEX g_atype991_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes991 [] = {
g_atype991_0,
};

static const long offsets991 [] =
{
+ @CHROFF(0,0),
};

extern const char *names992[];
static const uint32 types992 [] =
{
SK_BOOL,
};

static const uint16 attr_flags992 [] =
{0,};

static const EIF_TYPE_INDEX g_atype992_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes992 [] = {
g_atype992_0,
};

static const long offsets992 [] =
{
+ @CHROFF(0,0),
};

extern const char *names993[];
static const uint32 types993 [] =
{
SK_BOOL,
};

static const uint16 attr_flags993 [] =
{0,};

static const EIF_TYPE_INDEX g_atype993_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes993 [] = {
g_atype993_0,
};

static const long offsets993 [] =
{
+ @CHROFF(0,0),
};

extern const char *names994[];
static const uint32 types994 [] =
{
SK_POINTER,
};

static const uint16 attr_flags994 [] =
{0,};

static const EIF_TYPE_INDEX g_atype994_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes994 [] = {
g_atype994_0,
};

static const long offsets994 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names995[];
static const uint32 types995 [] =
{
SK_POINTER,
};

static const uint16 attr_flags995 [] =
{0,};

static const EIF_TYPE_INDEX g_atype995_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes995 [] = {
g_atype995_0,
};

static const long offsets995 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names996[];
static const uint32 types996 [] =
{
SK_POINTER,
};

static const uint16 attr_flags996 [] =
{0,};

static const EIF_TYPE_INDEX g_atype996_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes996 [] = {
g_atype996_0,
};

static const long offsets996 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names997[];
static const uint32 types997 [] =
{
SK_POINTER,
};

static const uint16 attr_flags997 [] =
{0,};

static const EIF_TYPE_INDEX g_atype997_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes997 [] = {
g_atype997_0,
};

static const long offsets997 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names998[];
static const uint32 types998 [] =
{
SK_POINTER,
};

static const uint16 attr_flags998 [] =
{0,};

static const EIF_TYPE_INDEX g_atype998_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes998 [] = {
g_atype998_0,
};

static const long offsets998 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names999[];
static const uint32 types999 [] =
{
SK_POINTER,
};

static const uint16 attr_flags999 [] =
{0,};

static const EIF_TYPE_INDEX g_atype999_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes999 [] = {
g_atype999_0,
};

static const long offsets999 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1000[];
static const uint32 types1000 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1000 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1000_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1000 [] = {
g_atype1000_0,
};

static const long offsets1000 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1001[];
static const uint32 types1001 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1001 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1001_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1001 [] = {
g_atype1001_0,
};

static const long offsets1001 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1002[];
static const uint32 types1002 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1002 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1002_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1002 [] = {
g_atype1002_0,
};

static const long offsets1002 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1003[];
static const uint32 types1003 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1003 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1003_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1003 [] = {
g_atype1003_0,
};

static const long offsets1003 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1004[];
static const uint32 types1004 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1004 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1004_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1004 [] = {
g_atype1004_0,
};

static const long offsets1004 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1005[];
static const uint32 types1005 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1005 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1005_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1005 [] = {
g_atype1005_0,
};

static const long offsets1005 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1006[];
static const uint32 types1006 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1006 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1006_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1006 [] = {
g_atype1006_0,
};

static const long offsets1006 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1007[];
static const uint32 types1007 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1007 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1007_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1007 [] = {
g_atype1007_0,
};

static const long offsets1007 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1008[];
static const uint32 types1008 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1008 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1008_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1008 [] = {
g_atype1008_0,
};

static const long offsets1008 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1009[];
static const uint32 types1009 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1009 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1009_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1009 [] = {
g_atype1009_0,
};

static const long offsets1009 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1010[];
static const uint32 types1010 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1010 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1010_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1010 [] = {
g_atype1010_0,
};

static const long offsets1010 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1011[];
static const uint32 types1011 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1011 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1011_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1011 [] = {
g_atype1011_0,
};

static const long offsets1011 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1012[];
static const uint32 types1012 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1012 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1012_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1012 [] = {
g_atype1012_0,
};

static const long offsets1012 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1013[];
static const uint32 types1013 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1013 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1013_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1013 [] = {
g_atype1013_0,
};

static const long offsets1013 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1014[];
static const uint32 types1014 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1014 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1014_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1014 [] = {
g_atype1014_0,
};

static const long offsets1014 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1015[];
static const uint32 types1015 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1015 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1015_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1015 [] = {
g_atype1015_0,
};

static const long offsets1015 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1016[];
static const uint32 types1016 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1016 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1016_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1016 [] = {
g_atype1016_0,
};

static const long offsets1016 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1017[];
static const uint32 types1017 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1017 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1017_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1017 [] = {
g_atype1017_0,
};

static const long offsets1017 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1018[];
static const uint32 types1018 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1018 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1018_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1018 [] = {
g_atype1018_0,
};

static const long offsets1018 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1019[];
static const uint32 types1019 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1019 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1019_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1019 [] = {
g_atype1019_0,
};

static const long offsets1019 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1020[];
static const uint32 types1020 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1020 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1020_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1020 [] = {
g_atype1020_0,
};

static const long offsets1020 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1021[];
static const uint32 types1021 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1021 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1021_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1021 [] = {
g_atype1021_0,
};

static const long offsets1021 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1022[];
static const uint32 types1022 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1022 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1022_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1022 [] = {
g_atype1022_0,
};

static const long offsets1022 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1023[];
static const uint32 types1023 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1023 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1023_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1023 [] = {
g_atype1023_0,
};

static const long offsets1023 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1024[];
static const uint32 types1024 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1024 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1024_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1024 [] = {
g_atype1024_0,
};

static const long offsets1024 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1025[];
static const uint32 types1025 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1025 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1025_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1025 [] = {
g_atype1025_0,
};

static const long offsets1025 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1026[];
static const uint32 types1026 [] =
{
SK_POINTER,
};

static const uint16 attr_flags1026 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1026_0 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1026 [] = {
g_atype1026_0,
};

static const long offsets1026 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names1027[];
static const uint32 types1027 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1027 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1027_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1027_1 [] = {0xFFF9,0,953,0xFFFF};
static const EIF_TYPE_INDEX g_atype1027_2 [] = {709,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1027_3 [] = {709,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1027_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1027_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1027_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1027_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1027_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1027_9 [] = {1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype1027_10 [] = {1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype1027_11 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1027 [] = {
g_atype1027_0,
g_atype1027_1,
g_atype1027_2,
g_atype1027_3,
g_atype1027_4,
g_atype1027_5,
g_atype1027_6,
g_atype1027_7,
g_atype1027_8,
g_atype1027_9,
g_atype1027_10,
g_atype1027_11,
};

static const long offsets1027 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
+ @LNGOFF(4,2,0,1),
+ @LNGOFF(4,2,0,2),
+ @PTROFF(4,2,0,3,0,0),
+ @PTROFF(4,2,0,3,0,1),
+ @PTROFF(4,2,0,3,0,2),
};

extern const char *names1028[];
static const uint32 types1028 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1028 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1028_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1028_1 [] = {0xFFF9,0,953,0xFFFF};
static const EIF_TYPE_INDEX g_atype1028_2 [] = {709,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1028_3 [] = {709,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1028_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1028_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1028_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1028_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1028_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1028_9 [] = {1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype1028_10 [] = {1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype1028_11 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1028 [] = {
g_atype1028_0,
g_atype1028_1,
g_atype1028_2,
g_atype1028_3,
g_atype1028_4,
g_atype1028_5,
g_atype1028_6,
g_atype1028_7,
g_atype1028_8,
g_atype1028_9,
g_atype1028_10,
g_atype1028_11,
};

static const long offsets1028 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
+ @LNGOFF(4,2,0,1),
+ @LNGOFF(4,2,0,2),
+ @PTROFF(4,2,0,3,0,0),
+ @PTROFF(4,2,0,3,0,1),
+ @PTROFF(4,2,0,3,0,2),
};

extern const char *names1029[];
static const uint32 types1029 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1029 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1029_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1029_1 [] = {0xFFF9,0,953,0xFFFF};
static const EIF_TYPE_INDEX g_atype1029_2 [] = {709,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1029_3 [] = {709,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1029_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1029_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1029_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1029_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1029_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1029_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1029_10 [] = {1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype1029_11 [] = {1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype1029_12 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1029 [] = {
g_atype1029_0,
g_atype1029_1,
g_atype1029_2,
g_atype1029_3,
g_atype1029_4,
g_atype1029_5,
g_atype1029_6,
g_atype1029_7,
g_atype1029_8,
g_atype1029_9,
g_atype1029_10,
g_atype1029_11,
g_atype1029_12,
};

static const long offsets1029 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
+ @LNGOFF(5,2,0,1),
+ @LNGOFF(5,2,0,2),
+ @PTROFF(5,2,0,3,0,0),
+ @PTROFF(5,2,0,3,0,1),
+ @PTROFF(5,2,0,3,0,2),
};

extern const char *names1030[];
static const uint32 types1030 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1030 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1030_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1030_1 [] = {0xFFF9,0,953,0xFFFF};
static const EIF_TYPE_INDEX g_atype1030_2 [] = {709,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1030_3 [] = {709,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1030_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1030_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1030_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1030_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1030_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1030_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1030_10 [] = {1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype1030_11 [] = {1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype1030_12 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1030 [] = {
g_atype1030_0,
g_atype1030_1,
g_atype1030_2,
g_atype1030_3,
g_atype1030_4,
g_atype1030_5,
g_atype1030_6,
g_atype1030_7,
g_atype1030_8,
g_atype1030_9,
g_atype1030_10,
g_atype1030_11,
g_atype1030_12,
};

static const long offsets1030 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @PTROFF(4,3,0,3,0,0),
+ @PTROFF(4,3,0,3,0,1),
+ @PTROFF(4,3,0,3,0,2),
};

extern const char *names1031[];
static const uint32 types1031 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1031 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1031_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1031_1 [] = {0xFFF9,0,953,0xFFFF};
static const EIF_TYPE_INDEX g_atype1031_2 [] = {709,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1031_3 [] = {709,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1031_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1031_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1031_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1031_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1031_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1031_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1031_10 [] = {1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype1031_11 [] = {1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype1031_12 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1031 [] = {
g_atype1031_0,
g_atype1031_1,
g_atype1031_2,
g_atype1031_3,
g_atype1031_4,
g_atype1031_5,
g_atype1031_6,
g_atype1031_7,
g_atype1031_8,
g_atype1031_9,
g_atype1031_10,
g_atype1031_11,
g_atype1031_12,
};

static const long offsets1031 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
+ @LNGOFF(4,2,0,1),
+ @LNGOFF(4,2,0,2),
+ @LNGOFF(4,2,0,3),
+ @PTROFF(4,2,0,4,0,0),
+ @PTROFF(4,2,0,4,0,1),
+ @PTROFF(4,2,0,4,0,2),
};

extern const char *names1032[];
static const uint32 types1032 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1032 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1032_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1032_1 [] = {0xFFF9,0,953,0xFFFF};
static const EIF_TYPE_INDEX g_atype1032_2 [] = {709,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1032_3 [] = {709,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1032_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1032_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1032_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1032_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1032_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1032_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1032_10 [] = {1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype1032_11 [] = {1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype1032_12 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1032 [] = {
g_atype1032_0,
g_atype1032_1,
g_atype1032_2,
g_atype1032_3,
g_atype1032_4,
g_atype1032_5,
g_atype1032_6,
g_atype1032_7,
g_atype1032_8,
g_atype1032_9,
g_atype1032_10,
g_atype1032_11,
g_atype1032_12,
};

static const long offsets1032 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @PTROFF(4,3,0,3,0,0),
+ @PTROFF(4,3,0,3,0,1),
+ @PTROFF(4,3,0,3,0,2),
};

extern const char *names1033[];
static const uint32 types1033 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1033 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1033_0 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1033_1 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1033 [] = {
g_atype1033_0,
g_atype1033_1,
};

static const long offsets1033 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names1034[];
static const uint32 types1034 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1034 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1034_0 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1034_1 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1034 [] = {
g_atype1034_0,
g_atype1034_1,
};

static const long offsets1034 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names1035[];
static const uint32 types1035 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1035 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1035_0 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1035_1 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1035 [] = {
g_atype1035_0,
g_atype1035_1,
};

static const long offsets1035 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names1036[];
static const uint32 types1036 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1036 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1036_0 [] = {0xFF01,845,989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1036 [] = {
g_atype1036_0,
g_atype1036_1,
g_atype1036_2,
g_atype1036_3,
};

static const long offsets1036 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names1037[];
static const uint32 types1037 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1037 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1037_0 [] = {0xFF01,845,989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1037_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1037_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1037_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1037_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1037 [] = {
g_atype1037_0,
g_atype1037_1,
g_atype1037_2,
g_atype1037_3,
g_atype1037_4,
};

static const long offsets1037 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
};

extern const char *names1038[];
static const uint32 types1038 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1038 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1038_0 [] = {0xFF01,845,989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1038 [] = {
g_atype1038_0,
g_atype1038_1,
g_atype1038_2,
g_atype1038_3,
g_atype1038_4,
};

static const long offsets1038 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names1039[];
static const uint32 types1039 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1039 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1039_0 [] = {0xFF01,845,989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1039_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1039_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1039_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1039_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1039 [] = {
g_atype1039_0,
g_atype1039_1,
g_atype1039_2,
g_atype1039_3,
g_atype1039_4,
};

static const long offsets1039 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names1040[];
static const uint32 types1040 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1040 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1040_0 [] = {0xFF01,848,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1040_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1040_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1040_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1040 [] = {
g_atype1040_0,
g_atype1040_1,
g_atype1040_2,
g_atype1040_3,
};

static const long offsets1040 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names1041[];
static const uint32 types1041 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1041 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1041_0 [] = {0xFF01,848,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1041_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1041_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1041_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1041_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1041 [] = {
g_atype1041_0,
g_atype1041_1,
g_atype1041_2,
g_atype1041_3,
g_atype1041_4,
};

static const long offsets1041 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
};

extern const char *names1042[];
static const uint32 types1042 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1042 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1042_0 [] = {0xFF01,848,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1042_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1042_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1042_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1042_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1042 [] = {
g_atype1042_0,
g_atype1042_1,
g_atype1042_2,
g_atype1042_3,
g_atype1042_4,
};

static const long offsets1042 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names1043[];
static const uint32 types1043 [] =
{
SK_REF,
};

static const uint16 attr_flags1043 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1043_0 [] = {0xFF01,1041,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1043 [] = {
g_atype1043_0,
};

static const long offsets1043 [] =
{
0,
};

extern const char *names1044[];
static const uint32 types1044 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1044 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1044_0 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype1044_1 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype1044_2 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype1044_3 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype1044_4 [] = {1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype1044_5 [] = {1041,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1044 [] = {
g_atype1044_0,
g_atype1044_1,
g_atype1044_2,
g_atype1044_3,
g_atype1044_4,
g_atype1044_5,
};

static const long offsets1044 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
};

extern const char *names1045[];
static const uint32 types1045 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1045 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1045_0 [] = {0xFF01,111,0xFFFF};
static const EIF_TYPE_INDEX g_atype1045_1 [] = {0xFF01,110,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1045 [] = {
g_atype1045_0,
g_atype1045_1,
};

static const long offsets1045 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1046[];
static const uint32 types1046 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1046 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1046_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_1 [] = {17,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_2 [] = {0xFF01,846,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_3 [] = {0xFF01,839,0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_9 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1046 [] = {
g_atype1046_0,
g_atype1046_1,
g_atype1046_2,
g_atype1046_3,
g_atype1046_4,
g_atype1046_5,
g_atype1046_6,
g_atype1046_7,
g_atype1046_8,
g_atype1046_9,
};

static const long offsets1046 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @LNGOFF(4,1,0,0),
+ @LNGOFF(4,1,0,1),
+ @LNGOFF(4,1,0,2),
+ @LNGOFF(4,1,0,3),
+ @LNGOFF(4,1,0,4),
};

extern const char *names1047[];
static const uint32 types1047 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1047 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1047_0 [] = {18,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_1 [] = {0xFF01,846,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_2 [] = {0xFF01,848,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_9 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1047 [] = {
g_atype1047_0,
g_atype1047_1,
g_atype1047_2,
g_atype1047_3,
g_atype1047_4,
g_atype1047_5,
g_atype1047_6,
g_atype1047_7,
g_atype1047_8,
g_atype1047_9,
};

static const long offsets1047 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
+ @LNGOFF(3,1,0,1),
+ @LNGOFF(3,1,0,2),
+ @LNGOFF(3,1,0,3),
+ @LNGOFF(3,1,0,4),
+ @LNGOFF(3,1,0,5),
};

extern const char *names1048[];
static const uint32 types1048 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1048 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1048_0 [] = {19,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1048_1 [] = {0xFF01,846,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1048_2 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1048_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1048_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1048_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1048_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1048_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1048_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1048_9 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1048 [] = {
g_atype1048_0,
g_atype1048_1,
g_atype1048_2,
g_atype1048_3,
g_atype1048_4,
g_atype1048_5,
g_atype1048_6,
g_atype1048_7,
g_atype1048_8,
g_atype1048_9,
};

static const long offsets1048 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
+ @LNGOFF(3,1,0,1),
+ @LNGOFF(3,1,0,2),
+ @LNGOFF(3,1,0,3),
+ @LNGOFF(3,1,0,4),
+ @LNGOFF(3,1,0,5),
};

extern const char *names1054[];
static const uint32 types1054 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1054 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1054_0 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_1 [] = {0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_2 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_3 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_4 [] = {45,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_5 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_6 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_7 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_8 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_9 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_10 [] = {977,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_11 [] = {965,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_12 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_13 [] = {962,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_14 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_15 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_16 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_17 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_18 [] = {980,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_19 [] = {1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_20 [] = {968,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_21 [] = {956,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_22 [] = {983,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1054 [] = {
g_atype1054_0,
g_atype1054_1,
g_atype1054_2,
g_atype1054_3,
g_atype1054_4,
g_atype1054_5,
g_atype1054_6,
g_atype1054_7,
g_atype1054_8,
g_atype1054_9,
g_atype1054_10,
g_atype1054_11,
g_atype1054_12,
g_atype1054_13,
g_atype1054_14,
g_atype1054_15,
g_atype1054_16,
g_atype1054_17,
g_atype1054_18,
g_atype1054_19,
g_atype1054_20,
g_atype1054_21,
g_atype1054_22,
};

static const long offsets1054 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @I16OFF(5,7,0),
+ @I16OFF(5,7,1),
+ @LNGOFF(5,7,2,0),
+ @LNGOFF(5,7,2,1),
+ @LNGOFF(5,7,2,2),
+ @LNGOFF(5,7,2,3),
+ @R32OFF(5,7,2,4,0),
+ @PTROFF(5,7,2,4,1,0),
+ @I64OFF(5,7,2,4,1,1,0),
+ @I64OFF(5,7,2,4,1,1,1),
+ @R64OFF(5,7,2,4,1,1,2,0),
};

extern const char *names1062[];
static const uint32 types1062 [] =
{
SK_BOOL,
};

static const uint16 attr_flags1062 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1062_0 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1062 [] = {
g_atype1062_0,
};

static const long offsets1062 [] =
{
+ @CHROFF(0,0),
};

extern const char *names1063[];
static const uint32 types1063 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1063 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1063_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_1 [] = {45,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1063_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1063 [] = {
g_atype1063_0,
g_atype1063_1,
g_atype1063_2,
g_atype1063_3,
};

static const long offsets1063 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
};

extern const char *names1064[];
static const uint32 types1064 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1064 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1064_0 [] = {0xFF01,818,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_1 [] = {0xFF01,909,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_3 [] = {45,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_7 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_8 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_9 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_10 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_11 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_12 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_13 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_14 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_15 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_16 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_17 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_18 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1064 [] = {
g_atype1064_0,
g_atype1064_1,
g_atype1064_2,
g_atype1064_3,
g_atype1064_4,
g_atype1064_5,
g_atype1064_6,
g_atype1064_7,
g_atype1064_8,
g_atype1064_9,
g_atype1064_10,
g_atype1064_11,
g_atype1064_12,
g_atype1064_13,
g_atype1064_14,
g_atype1064_15,
g_atype1064_16,
g_atype1064_17,
g_atype1064_18,
};

static const long offsets1064 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @LNGOFF(4,6,0,0),
+ @LNGOFF(4,6,0,1),
+ @LNGOFF(4,6,0,2),
+ @LNGOFF(4,6,0,3),
+ @LNGOFF(4,6,0,4),
+ @LNGOFF(4,6,0,5),
+ @LNGOFF(4,6,0,6),
+ @LNGOFF(4,6,0,7),
+ @LNGOFF(4,6,0,8),
};

extern const char *names1065[];
static const uint32 types1065 [] =
{
SK_REF,
SK_CHAR8,
SK_CHAR32,
SK_INT32,
};

static const uint16 attr_flags1065 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1065_0 [] = {0xFF01,202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_1 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_2 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1065_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1065 [] = {
g_atype1065_0,
g_atype1065_1,
g_atype1065_2,
g_atype1065_3,
};

static const long offsets1065 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names1066[];
static const uint32 types1066 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1066 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1066_0 [] = {0xFF01,202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1066_1 [] = {0xFF01,119,0xFFFF};
static const EIF_TYPE_INDEX g_atype1066_2 [] = {845,989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1066_3 [] = {848,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1066_4 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1066_5 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1066_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1066_7 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1066_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1066_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1066_10 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1066_11 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1066_12 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1066_13 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1066_14 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1066_15 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1066_16 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1066_17 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1066_18 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1066_19 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1066_20 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1066_21 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1066 [] = {
g_atype1066_0,
g_atype1066_1,
g_atype1066_2,
g_atype1066_3,
g_atype1066_4,
g_atype1066_5,
g_atype1066_6,
g_atype1066_7,
g_atype1066_8,
g_atype1066_9,
g_atype1066_10,
g_atype1066_11,
g_atype1066_12,
g_atype1066_13,
g_atype1066_14,
g_atype1066_15,
g_atype1066_16,
g_atype1066_17,
g_atype1066_18,
g_atype1066_19,
g_atype1066_20,
g_atype1066_21,
};

static const long offsets1066 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
+ @LNGOFF(5,2,0,1),
+ @LNGOFF(5,2,0,2),
+ @LNGOFF(5,2,0,3),
+ @LNGOFF(5,2,0,4),
+ @LNGOFF(5,2,0,5),
+ @LNGOFF(5,2,0,6),
+ @LNGOFF(5,2,0,7),
+ @LNGOFF(5,2,0,8),
+ @LNGOFF(5,2,0,9),
+ @LNGOFF(5,2,0,10),
+ @LNGOFF(5,2,0,11),
+ @LNGOFF(5,2,0,12),
+ @LNGOFF(5,2,0,13),
+ @LNGOFF(5,2,0,14),
};

extern const char *names1067[];
static const uint32 types1067 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1067 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1067_0 [] = {0xFF01,202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_1 [] = {0xFF01,119,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_2 [] = {845,989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_3 [] = {848,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_4 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_5 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_6 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_7 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_8 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_9 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_10 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_11 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_12 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_13 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_14 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_15 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_16 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_17 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_18 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_19 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_20 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_21 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_22 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_23 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_24 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_25 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_26 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_27 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_28 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_29 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_30 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_31 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_32 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_33 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_34 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_35 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_36 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_37 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1067 [] = {
g_atype1067_0,
g_atype1067_1,
g_atype1067_2,
g_atype1067_3,
g_atype1067_4,
g_atype1067_5,
g_atype1067_6,
g_atype1067_7,
g_atype1067_8,
g_atype1067_9,
g_atype1067_10,
g_atype1067_11,
g_atype1067_12,
g_atype1067_13,
g_atype1067_14,
g_atype1067_15,
g_atype1067_16,
g_atype1067_17,
g_atype1067_18,
g_atype1067_19,
g_atype1067_20,
g_atype1067_21,
g_atype1067_22,
g_atype1067_23,
g_atype1067_24,
g_atype1067_25,
g_atype1067_26,
g_atype1067_27,
g_atype1067_28,
g_atype1067_29,
g_atype1067_30,
g_atype1067_31,
g_atype1067_32,
g_atype1067_33,
g_atype1067_34,
g_atype1067_35,
g_atype1067_36,
g_atype1067_37,
};

static const long offsets1067 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
+ @CHROFF(14,0),
+ @CHROFF(14,1),
+ @CHROFF(14,2),
+ @LNGOFF(14,3,0,0),
+ @LNGOFF(14,3,0,1),
+ @LNGOFF(14,3,0,2),
+ @LNGOFF(14,3,0,3),
+ @LNGOFF(14,3,0,4),
+ @LNGOFF(14,3,0,5),
+ @LNGOFF(14,3,0,6),
+ @LNGOFF(14,3,0,7),
+ @LNGOFF(14,3,0,8),
+ @LNGOFF(14,3,0,9),
+ @LNGOFF(14,3,0,10),
+ @LNGOFF(14,3,0,11),
+ @LNGOFF(14,3,0,12),
+ @LNGOFF(14,3,0,13),
+ @LNGOFF(14,3,0,14),
+ @LNGOFF(14,3,0,15),
+ @LNGOFF(14,3,0,16),
+ @LNGOFF(14,3,0,17),
+ @LNGOFF(14,3,0,18),
+ @LNGOFF(14,3,0,19),
+ @LNGOFF(14,3,0,20),
};

extern const char *names1069[];
static const uint32 types1069 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1069 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1069_0 [] = {0xFF01,786,0xFF01,836,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1069_1 [] = {0xFF01,706,0xFF01,1035,0xFFFF};
static const EIF_TYPE_INDEX g_atype1069_2 [] = {0xFF01,706,0xFF01,1035,0xFFFF};
static const EIF_TYPE_INDEX g_atype1069_3 [] = {1101,0xFFFF};
static const EIF_TYPE_INDEX g_atype1069_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1069_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1069_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1069 [] = {
g_atype1069_0,
g_atype1069_1,
g_atype1069_2,
g_atype1069_3,
g_atype1069_4,
g_atype1069_5,
g_atype1069_6,
};

static const long offsets1069 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
};

extern const char *names1070[];
static const uint32 types1070 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1070 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1070_0 [] = {1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1070_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1070_2 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1070 [] = {
g_atype1070_0,
g_atype1070_1,
g_atype1070_2,
};

static const long offsets1070 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names1071[];
static const uint32 types1071 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1071 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1071_0 [] = {1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1071_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1071_2 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1071 [] = {
g_atype1071_0,
g_atype1071_1,
g_atype1071_2,
};

static const long offsets1071 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names1072[];
static const uint32 types1072 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1072 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1072_0 [] = {1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1072_2 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1072 [] = {
g_atype1072_0,
g_atype1072_1,
g_atype1072_2,
};

static const long offsets1072 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names1073[];
static const uint32 types1073 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1073 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1073_0 [] = {1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1073_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1073_2 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1073 [] = {
g_atype1073_0,
g_atype1073_1,
g_atype1073_2,
};

static const long offsets1073 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names1075[];
static const uint32 types1075 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1075 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1075_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_1 [] = {0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_2 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_3 [] = {85,0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_4 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_5 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_7 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_9 [] = {1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_10 [] = {1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1075 [] = {
g_atype1075_0,
g_atype1075_1,
g_atype1075_2,
g_atype1075_3,
g_atype1075_4,
g_atype1075_5,
g_atype1075_6,
g_atype1075_7,
g_atype1075_8,
g_atype1075_9,
g_atype1075_10,
};

static const long offsets1075 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @LNGOFF(6,2,0,0),
+ @PTROFF(6,2,0,1,0,0),
+ @PTROFF(6,2,0,1,0,1),
};

extern const char *names1076[];
static const uint32 types1076 [] =
{
SK_REF,
};

static const uint16 attr_flags1076 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1076_0 [] = {0xFF01,1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1076 [] = {
g_atype1076_0,
};

static const long offsets1076 [] =
{
0,
};

extern const char *names1077[];
static const uint32 types1077 [] =
{
SK_REF,
};

static const uint16 attr_flags1077 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1077_0 [] = {0xFF01,1037,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1077 [] = {
g_atype1077_0,
};

static const long offsets1077 [] =
{
0,
};

extern const char *names1078[];
static const uint32 types1078 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1078 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1078_0 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1078_1 [] = {0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1078_2 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype1078_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype1078_4 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1078_5 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1078_6 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1078_7 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1078_8 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1078_9 [] = {977,0xFFFF};
static const EIF_TYPE_INDEX g_atype1078_10 [] = {965,0xFFFF};
static const EIF_TYPE_INDEX g_atype1078_11 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1078_12 [] = {962,0xFFFF};
static const EIF_TYPE_INDEX g_atype1078_13 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1078_14 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1078_15 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1078_16 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1078_17 [] = {980,0xFFFF};
static const EIF_TYPE_INDEX g_atype1078_18 [] = {1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype1078_19 [] = {968,0xFFFF};
static const EIF_TYPE_INDEX g_atype1078_20 [] = {956,0xFFFF};
static const EIF_TYPE_INDEX g_atype1078_21 [] = {983,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1078 [] = {
g_atype1078_0,
g_atype1078_1,
g_atype1078_2,
g_atype1078_3,
g_atype1078_4,
g_atype1078_5,
g_atype1078_6,
g_atype1078_7,
g_atype1078_8,
g_atype1078_9,
g_atype1078_10,
g_atype1078_11,
g_atype1078_12,
g_atype1078_13,
g_atype1078_14,
g_atype1078_15,
g_atype1078_16,
g_atype1078_17,
g_atype1078_18,
g_atype1078_19,
g_atype1078_20,
g_atype1078_21,
};

static const long offsets1078 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @I16OFF(5,6,0),
+ @I16OFF(5,6,1),
+ @LNGOFF(5,6,2,0),
+ @LNGOFF(5,6,2,1),
+ @LNGOFF(5,6,2,2),
+ @LNGOFF(5,6,2,3),
+ @R32OFF(5,6,2,4,0),
+ @PTROFF(5,6,2,4,1,0),
+ @I64OFF(5,6,2,4,1,1,0),
+ @I64OFF(5,6,2,4,1,1,1),
+ @R64OFF(5,6,2,4,1,1,2,0),
};

extern const char *names1079[];
static const uint32 types1079 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1079 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1079_0 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_1 [] = {0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_2 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_4 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_5 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_6 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_7 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_8 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_9 [] = {977,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_10 [] = {965,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_11 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_12 [] = {962,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_13 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_14 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_15 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_16 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_17 [] = {980,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_18 [] = {1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_19 [] = {968,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_20 [] = {956,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_21 [] = {983,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1079 [] = {
g_atype1079_0,
g_atype1079_1,
g_atype1079_2,
g_atype1079_3,
g_atype1079_4,
g_atype1079_5,
g_atype1079_6,
g_atype1079_7,
g_atype1079_8,
g_atype1079_9,
g_atype1079_10,
g_atype1079_11,
g_atype1079_12,
g_atype1079_13,
g_atype1079_14,
g_atype1079_15,
g_atype1079_16,
g_atype1079_17,
g_atype1079_18,
g_atype1079_19,
g_atype1079_20,
g_atype1079_21,
};

static const long offsets1079 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @I16OFF(5,6,0),
+ @I16OFF(5,6,1),
+ @LNGOFF(5,6,2,0),
+ @LNGOFF(5,6,2,1),
+ @LNGOFF(5,6,2,2),
+ @LNGOFF(5,6,2,3),
+ @R32OFF(5,6,2,4,0),
+ @PTROFF(5,6,2,4,1,0),
+ @I64OFF(5,6,2,4,1,1,0),
+ @I64OFF(5,6,2,4,1,1,1),
+ @R64OFF(5,6,2,4,1,1,2,0),
};

extern const char *names1080[];
static const uint32 types1080 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1080 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1080_0 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_1 [] = {0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_2 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_3 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_4 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_5 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_6 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_7 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_8 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_9 [] = {977,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_10 [] = {965,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_11 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_12 [] = {962,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_13 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_14 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_15 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_16 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_17 [] = {980,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_18 [] = {1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_19 [] = {968,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_20 [] = {956,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_21 [] = {983,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1080 [] = {
g_atype1080_0,
g_atype1080_1,
g_atype1080_2,
g_atype1080_3,
g_atype1080_4,
g_atype1080_5,
g_atype1080_6,
g_atype1080_7,
g_atype1080_8,
g_atype1080_9,
g_atype1080_10,
g_atype1080_11,
g_atype1080_12,
g_atype1080_13,
g_atype1080_14,
g_atype1080_15,
g_atype1080_16,
g_atype1080_17,
g_atype1080_18,
g_atype1080_19,
g_atype1080_20,
g_atype1080_21,
};

static const long offsets1080 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @I16OFF(5,6,0),
+ @I16OFF(5,6,1),
+ @LNGOFF(5,6,2,0),
+ @LNGOFF(5,6,2,1),
+ @LNGOFF(5,6,2,2),
+ @LNGOFF(5,6,2,3),
+ @R32OFF(5,6,2,4,0),
+ @PTROFF(5,6,2,4,1,0),
+ @I64OFF(5,6,2,4,1,1,0),
+ @I64OFF(5,6,2,4,1,1,1),
+ @R64OFF(5,6,2,4,1,1,2,0),
};

extern const char *names1081[];
static const uint32 types1081 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
};

static const uint16 attr_flags1081 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1081_0 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1081_1 [] = {86,989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1081_2 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1081_3 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1081_4 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1081 [] = {
g_atype1081_0,
g_atype1081_1,
g_atype1081_2,
g_atype1081_3,
g_atype1081_4,
};

static const long offsets1081 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names1082[];
static const uint32 types1082 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1082 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1082_0 [] = {0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_1 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_2 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_3 [] = {45,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_4 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_5 [] = {86,989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_6 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_7 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_8 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_9 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_10 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_11 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_12 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_13 [] = {977,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_14 [] = {965,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_15 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_16 [] = {962,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_17 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_18 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_19 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_20 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_21 [] = {980,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_22 [] = {1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_23 [] = {968,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_24 [] = {956,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_25 [] = {983,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1082 [] = {
g_atype1082_0,
g_atype1082_1,
g_atype1082_2,
g_atype1082_3,
g_atype1082_4,
g_atype1082_5,
g_atype1082_6,
g_atype1082_7,
g_atype1082_8,
g_atype1082_9,
g_atype1082_10,
g_atype1082_11,
g_atype1082_12,
g_atype1082_13,
g_atype1082_14,
g_atype1082_15,
g_atype1082_16,
g_atype1082_17,
g_atype1082_18,
g_atype1082_19,
g_atype1082_20,
g_atype1082_21,
g_atype1082_22,
g_atype1082_23,
g_atype1082_24,
g_atype1082_25,
};

static const long offsets1082 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @CHROFF(7,4),
+ @CHROFF(7,5),
+ @CHROFF(7,6),
+ @CHROFF(7,7),
+ @I16OFF(7,8,0),
+ @I16OFF(7,8,1),
+ @LNGOFF(7,8,2,0),
+ @LNGOFF(7,8,2,1),
+ @LNGOFF(7,8,2,2),
+ @LNGOFF(7,8,2,3),
+ @R32OFF(7,8,2,4,0),
+ @PTROFF(7,8,2,4,1,0),
+ @I64OFF(7,8,2,4,1,1,0),
+ @I64OFF(7,8,2,4,1,1,1),
+ @R64OFF(7,8,2,4,1,1,2,0),
};

extern const char *names1083[];
static const uint32 types1083 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1083 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1083_0 [] = {0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_1 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_2 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_3 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_4 [] = {86,989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_5 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_6 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_7 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_8 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_9 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_10 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_11 [] = {977,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_12 [] = {965,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_13 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_14 [] = {962,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_15 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_16 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_17 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_18 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_19 [] = {980,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_20 [] = {1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_21 [] = {968,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_22 [] = {956,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_23 [] = {983,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1083 [] = {
g_atype1083_0,
g_atype1083_1,
g_atype1083_2,
g_atype1083_3,
g_atype1083_4,
g_atype1083_5,
g_atype1083_6,
g_atype1083_7,
g_atype1083_8,
g_atype1083_9,
g_atype1083_10,
g_atype1083_11,
g_atype1083_12,
g_atype1083_13,
g_atype1083_14,
g_atype1083_15,
g_atype1083_16,
g_atype1083_17,
g_atype1083_18,
g_atype1083_19,
g_atype1083_20,
g_atype1083_21,
g_atype1083_22,
g_atype1083_23,
};

static const long offsets1083 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names1084[];
static const uint32 types1084 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1084 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1084_0 [] = {0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_1 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_2 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_3 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_4 [] = {86,989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_5 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_6 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_7 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_8 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_9 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_10 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_11 [] = {977,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_12 [] = {965,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_13 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_14 [] = {962,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_15 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_16 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_17 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_18 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_19 [] = {980,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_20 [] = {1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_21 [] = {968,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_22 [] = {956,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_23 [] = {983,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1084 [] = {
g_atype1084_0,
g_atype1084_1,
g_atype1084_2,
g_atype1084_3,
g_atype1084_4,
g_atype1084_5,
g_atype1084_6,
g_atype1084_7,
g_atype1084_8,
g_atype1084_9,
g_atype1084_10,
g_atype1084_11,
g_atype1084_12,
g_atype1084_13,
g_atype1084_14,
g_atype1084_15,
g_atype1084_16,
g_atype1084_17,
g_atype1084_18,
g_atype1084_19,
g_atype1084_20,
g_atype1084_21,
g_atype1084_22,
g_atype1084_23,
};

static const long offsets1084 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names1085[];
static const uint32 types1085 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1085 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1085_0 [] = {0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_1 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_2 [] = {271,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_3 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_4 [] = {86,989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_5 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_6 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_7 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_8 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_9 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_10 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_11 [] = {977,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_12 [] = {965,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_13 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_14 [] = {962,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_15 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_16 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_17 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_18 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_19 [] = {980,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_20 [] = {1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_21 [] = {968,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_22 [] = {956,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_23 [] = {983,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1085 [] = {
g_atype1085_0,
g_atype1085_1,
g_atype1085_2,
g_atype1085_3,
g_atype1085_4,
g_atype1085_5,
g_atype1085_6,
g_atype1085_7,
g_atype1085_8,
g_atype1085_9,
g_atype1085_10,
g_atype1085_11,
g_atype1085_12,
g_atype1085_13,
g_atype1085_14,
g_atype1085_15,
g_atype1085_16,
g_atype1085_17,
g_atype1085_18,
g_atype1085_19,
g_atype1085_20,
g_atype1085_21,
g_atype1085_22,
g_atype1085_23,
};

static const long offsets1085 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names1087[];
static const uint32 types1087 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1087 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1087_0 [] = {1305,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_1 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_2 [] = {1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_3 [] = {0xFF01,64,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_4 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_5 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_6 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_7 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_8 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_9 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_10 [] = {0xFF01,1039,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_11 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_12 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_13 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_14 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_15 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_16 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_17 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_18 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_19 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_20 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1087 [] = {
g_atype1087_0,
g_atype1087_1,
g_atype1087_2,
g_atype1087_3,
g_atype1087_4,
g_atype1087_5,
g_atype1087_6,
g_atype1087_7,
g_atype1087_8,
g_atype1087_9,
g_atype1087_10,
g_atype1087_11,
g_atype1087_12,
g_atype1087_13,
g_atype1087_14,
g_atype1087_15,
g_atype1087_16,
g_atype1087_17,
g_atype1087_18,
g_atype1087_19,
g_atype1087_20,
};

static const long offsets1087 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @CHROFF(11,0),
+ @CHROFF(11,1),
+ @CHROFF(11,2),
+ @CHROFF(11,3),
+ @CHROFF(11,4),
+ @CHROFF(11,5),
+ @CHROFF(11,6),
+ @LNGOFF(11,7,0,0),
+ @LNGOFF(11,7,0,1),
+ @LNGOFF(11,7,0,2),
};

extern const char *names1088[];
static const uint32 types1088 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1088 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1088_0 [] = {0xFF01,793,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype1088_1 [] = {0xFF01,793,0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype1088_2 [] = {1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype1088_3 [] = {0xFF01,64,0xFFFF};
static const EIF_TYPE_INDEX g_atype1088_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1088_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1088_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1088_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1088 [] = {
g_atype1088_0,
g_atype1088_1,
g_atype1088_2,
g_atype1088_3,
g_atype1088_4,
g_atype1088_5,
g_atype1088_6,
g_atype1088_7,
};

static const long offsets1088 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
};

extern const char *names1090[];
static const uint32 types1090 [] =
{
SK_REF,
};

static const uint16 attr_flags1090 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1090_0 [] = {0xFF01,99,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1090 [] = {
g_atype1090_0,
};

static const long offsets1090 [] =
{
0,
};

extern const char *names1091[];
static const uint32 types1091 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1091 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1091_0 [] = {837,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_1 [] = {837,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_2 [] = {837,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_3 [] = {773,0xFF01,0xFFF9,2,953,0xFF01,837,793,0xFF01,0xFFF9,2,953,0xFF01,851,0xFF01,851,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_7 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_8 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_10 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1091 [] = {
g_atype1091_0,
g_atype1091_1,
g_atype1091_2,
g_atype1091_3,
g_atype1091_4,
g_atype1091_5,
g_atype1091_6,
g_atype1091_7,
g_atype1091_8,
g_atype1091_9,
g_atype1091_10,
};

static const long offsets1091 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @LNGOFF(4,5,0,0),
+ @LNGOFF(4,5,0,1),
};

extern const char *names1097[];
static const uint32 types1097 [] =
{
SK_INT32,
};

static const uint16 attr_flags1097 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1097_0 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1097 [] = {
g_atype1097_0,
};

static const long offsets1097 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1098[];
static const uint32 types1098 [] =
{
SK_INT32,
};

static const uint16 attr_flags1098 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1098_0 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1098 [] = {
g_atype1098_0,
};

static const long offsets1098 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1099[];
static const uint32 types1099 [] =
{
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags1099 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1099_0 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1099_1 [] = {983,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1099 [] = {
g_atype1099_0,
g_atype1099_1,
};

static const long offsets1099 [] =
{
+ @LNGOFF(0,0,0,0),
+ @R64OFF(0,0,0,1,0,0,0,0),
};

extern const char *names1100[];
static const uint32 types1100 [] =
{
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags1100 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1100_0 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1100_1 [] = {983,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1100 [] = {
g_atype1100_0,
g_atype1100_1,
};

static const long offsets1100 [] =
{
+ @LNGOFF(0,0,0,0),
+ @R64OFF(0,0,0,1,0,0,0,0),
};

extern const char *names1101[];
static const uint32 types1101 [] =
{
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags1101 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1101_0 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_2 [] = {983,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1101 [] = {
g_atype1101_0,
g_atype1101_1,
g_atype1101_2,
};

static const long offsets1101 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
+ @R64OFF(0,0,0,2,0,0,0,0),
};

extern const char *names1102[];
static const uint32 types1102 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL64,
SK_REAL64,
};

static const uint16 attr_flags1102 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1102_0 [] = {1035,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_1 [] = {1035,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_2 [] = {0xFF01,786,0xFF01,836,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_3 [] = {706,0xFF01,1035,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_4 [] = {706,0xFF01,1035,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_10 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_11 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_12 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_13 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_14 [] = {983,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_15 [] = {983,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1102 [] = {
g_atype1102_0,
g_atype1102_1,
g_atype1102_2,
g_atype1102_3,
g_atype1102_4,
g_atype1102_5,
g_atype1102_6,
g_atype1102_7,
g_atype1102_8,
g_atype1102_9,
g_atype1102_10,
g_atype1102_11,
g_atype1102_12,
g_atype1102_13,
g_atype1102_14,
g_atype1102_15,
};

static const long offsets1102 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
+ @LNGOFF(5,1,0,2),
+ @LNGOFF(5,1,0,3),
+ @LNGOFF(5,1,0,4),
+ @LNGOFF(5,1,0,5),
+ @LNGOFF(5,1,0,6),
+ @LNGOFF(5,1,0,7),
+ @R64OFF(5,1,0,8,0,0,0,0),
+ @R64OFF(5,1,0,8,0,0,0,1),
};

extern const char *names1103[];
static const uint32 types1103 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags1103 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1103_0 [] = {0xFF01,1099,0xFFFF};
static const EIF_TYPE_INDEX g_atype1103_1 [] = {0xFF01,1097,0xFFFF};
static const EIF_TYPE_INDEX g_atype1103_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1103_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1103_4 [] = {983,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1103 [] = {
g_atype1103_0,
g_atype1103_1,
g_atype1103_2,
g_atype1103_3,
g_atype1103_4,
};

static const long offsets1103 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @R64OFF(2,0,0,2,0,0,0,0),
};

extern const char *names1104[];
static const uint32 types1104 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1104 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1104_0 [] = {27,0xFFFF};
static const EIF_TYPE_INDEX g_atype1104_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1104_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1104_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1104_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1104_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1104 [] = {
g_atype1104_0,
g_atype1104_1,
g_atype1104_2,
g_atype1104_3,
g_atype1104_4,
g_atype1104_5,
};

static const long offsets1104 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
};

extern const char *names1105[];
static const uint32 types1105 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1105 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1105_0 [] = {27,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1105_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1105 [] = {
g_atype1105_0,
g_atype1105_1,
g_atype1105_2,
g_atype1105_3,
g_atype1105_4,
g_atype1105_5,
};

static const long offsets1105 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
};

extern const char *names1106[];
static const uint32 types1106 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1106 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1106_0 [] = {27,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1106 [] = {
g_atype1106_0,
g_atype1106_1,
g_atype1106_2,
g_atype1106_3,
g_atype1106_4,
g_atype1106_5,
};

static const long offsets1106 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
};

extern const char *names1107[];
static const uint32 types1107 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1107 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1107_0 [] = {27,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_4 [] = {0xFF01,1039,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_5 [] = {0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1107 [] = {
g_atype1107_0,
g_atype1107_1,
g_atype1107_2,
g_atype1107_3,
g_atype1107_4,
g_atype1107_5,
g_atype1107_6,
g_atype1107_7,
};

static const long offsets1107 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @LNGOFF(6,0,0,0),
+ @LNGOFF(6,0,0,1),
};

extern const char *names1108[];
static const uint32 types1108 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1108 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1108_0 [] = {27,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_4 [] = {0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1108 [] = {
g_atype1108_0,
g_atype1108_1,
g_atype1108_2,
g_atype1108_3,
g_atype1108_4,
g_atype1108_5,
g_atype1108_6,
};

static const long offsets1108 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @LNGOFF(5,0,0,0),
+ @LNGOFF(5,0,0,1),
};

extern const char *names1109[];
static const uint32 types1109 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1109 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1109_0 [] = {27,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_4 [] = {0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1109 [] = {
g_atype1109_0,
g_atype1109_1,
g_atype1109_2,
g_atype1109_3,
g_atype1109_4,
g_atype1109_5,
g_atype1109_6,
};

static const long offsets1109 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @LNGOFF(5,0,0,0),
+ @LNGOFF(5,0,0,1),
};

extern const char *names1110[];
static const uint32 types1110 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1110 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1110_0 [] = {27,0xFFFF};
static const EIF_TYPE_INDEX g_atype1110_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1110_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1110_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1110_4 [] = {0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1110_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1110_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1110 [] = {
g_atype1110_0,
g_atype1110_1,
g_atype1110_2,
g_atype1110_3,
g_atype1110_4,
g_atype1110_5,
g_atype1110_6,
};

static const long offsets1110 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @LNGOFF(5,0,0,0),
+ @LNGOFF(5,0,0,1),
};

extern const char *names1111[];
static const uint32 types1111 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1111 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1111_0 [] = {27,0xFFFF};
static const EIF_TYPE_INDEX g_atype1111_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1111_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1111_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1111_4 [] = {0xFF01,1039,0xFFFF};
static const EIF_TYPE_INDEX g_atype1111_5 [] = {0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1111_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1111_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1111 [] = {
g_atype1111_0,
g_atype1111_1,
g_atype1111_2,
g_atype1111_3,
g_atype1111_4,
g_atype1111_5,
g_atype1111_6,
g_atype1111_7,
};

static const long offsets1111 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @LNGOFF(6,0,0,0),
+ @LNGOFF(6,0,0,1),
};

extern const char *names1112[];
static const uint32 types1112 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1112 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1112_0 [] = {27,0xFFFF};
static const EIF_TYPE_INDEX g_atype1112_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1112_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1112_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1112_4 [] = {0xFF01,1039,0xFFFF};
static const EIF_TYPE_INDEX g_atype1112_5 [] = {0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1112_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1112_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1112 [] = {
g_atype1112_0,
g_atype1112_1,
g_atype1112_2,
g_atype1112_3,
g_atype1112_4,
g_atype1112_5,
g_atype1112_6,
g_atype1112_7,
};

static const long offsets1112 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @LNGOFF(6,0,0,0),
+ @LNGOFF(6,0,0,1),
};

extern const char *names1113[];
static const uint32 types1113 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1113 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1113_0 [] = {27,0xFFFF};
static const EIF_TYPE_INDEX g_atype1113_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1113_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1113_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1113_4 [] = {0xFF01,1039,0xFFFF};
static const EIF_TYPE_INDEX g_atype1113_5 [] = {0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1113_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1113_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1113 [] = {
g_atype1113_0,
g_atype1113_1,
g_atype1113_2,
g_atype1113_3,
g_atype1113_4,
g_atype1113_5,
g_atype1113_6,
g_atype1113_7,
};

static const long offsets1113 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @LNGOFF(6,0,0,0),
+ @LNGOFF(6,0,0,1),
};

extern const char *names1114[];
static const uint32 types1114 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1114 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1114_0 [] = {27,0xFFFF};
static const EIF_TYPE_INDEX g_atype1114_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1114_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1114_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1114_4 [] = {0xFF01,1039,0xFFFF};
static const EIF_TYPE_INDEX g_atype1114_5 [] = {0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1114_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1114_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1114 [] = {
g_atype1114_0,
g_atype1114_1,
g_atype1114_2,
g_atype1114_3,
g_atype1114_4,
g_atype1114_5,
g_atype1114_6,
g_atype1114_7,
};

static const long offsets1114 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @LNGOFF(6,0,0,0),
+ @LNGOFF(6,0,0,1),
};

extern const char *names1115[];
static const uint32 types1115 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1115 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1115_0 [] = {27,0xFFFF};
static const EIF_TYPE_INDEX g_atype1115_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1115_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1115_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1115_4 [] = {0xFF01,1039,0xFFFF};
static const EIF_TYPE_INDEX g_atype1115_5 [] = {0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1115_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1115_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1115 [] = {
g_atype1115_0,
g_atype1115_1,
g_atype1115_2,
g_atype1115_3,
g_atype1115_4,
g_atype1115_5,
g_atype1115_6,
g_atype1115_7,
};

static const long offsets1115 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @LNGOFF(6,0,0,0),
+ @LNGOFF(6,0,0,1),
};

extern const char *names1116[];
static const uint32 types1116 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1116 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1116_0 [] = {27,0xFFFF};
static const EIF_TYPE_INDEX g_atype1116_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1116_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1116_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1116_4 [] = {0xFF01,1039,0xFFFF};
static const EIF_TYPE_INDEX g_atype1116_5 [] = {0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1116_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1116_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1116 [] = {
g_atype1116_0,
g_atype1116_1,
g_atype1116_2,
g_atype1116_3,
g_atype1116_4,
g_atype1116_5,
g_atype1116_6,
g_atype1116_7,
};

static const long offsets1116 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @LNGOFF(6,0,0,0),
+ @LNGOFF(6,0,0,1),
};

extern const char *names1119[];
static const uint32 types1119 [] =
{
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1119 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1119_0 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_2 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1119 [] = {
g_atype1119_0,
g_atype1119_1,
g_atype1119_2,
};

static const long offsets1119 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
+ @CHROFF(0,2),
};

extern const char *names1120[];
static const uint32 types1120 [] =
{
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1120 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1120_0 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_2 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1120 [] = {
g_atype1120_0,
g_atype1120_1,
g_atype1120_2,
};

static const long offsets1120 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
+ @CHROFF(0,2),
};

extern const char *names1122[];
static const uint32 types1122 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1122 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1122_0 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_1 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_2 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_3 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_4 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_5 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_6 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_7 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_8 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_9 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_10 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_11 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_12 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_13 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_14 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_15 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_16 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_17 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_18 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_19 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_20 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_21 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1122_22 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1122 [] = {
g_atype1122_0,
g_atype1122_1,
g_atype1122_2,
g_atype1122_3,
g_atype1122_4,
g_atype1122_5,
g_atype1122_6,
g_atype1122_7,
g_atype1122_8,
g_atype1122_9,
g_atype1122_10,
g_atype1122_11,
g_atype1122_12,
g_atype1122_13,
g_atype1122_14,
g_atype1122_15,
g_atype1122_16,
g_atype1122_17,
g_atype1122_18,
g_atype1122_19,
g_atype1122_20,
g_atype1122_21,
g_atype1122_22,
};

static const long offsets1122 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @CHROFF(11,0),
+ @LNGOFF(11,1,0,0),
+ @LNGOFF(11,1,0,1),
+ @LNGOFF(11,1,0,2),
+ @LNGOFF(11,1,0,3),
+ @LNGOFF(11,1,0,4),
+ @LNGOFF(11,1,0,5),
+ @LNGOFF(11,1,0,6),
+ @LNGOFF(11,1,0,7),
+ @LNGOFF(11,1,0,8),
+ @LNGOFF(11,1,0,9),
+ @LNGOFF(11,1,0,10),
};

extern const char *names1123[];
static const uint32 types1123 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1123 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1123_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_1 [] = {1212,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_2 [] = {0xFFF9,5,953,1212,1274,959,959,0xFFF5,1,0xFF01,1103,7193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_3 [] = {1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_4 [] = {1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_5 [] = {1276,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_6 [] = {1270,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_7 [] = {1254,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_8 [] = {1229,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_9 [] = {1271,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_10 [] = {1253,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_11 [] = {1216,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_12 [] = {1255,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_13 [] = {0xFFF9,5,953,1215,1274,959,959,0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_14 [] = {1278,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1123 [] = {
g_atype1123_0,
g_atype1123_1,
g_atype1123_2,
g_atype1123_3,
g_atype1123_4,
g_atype1123_5,
g_atype1123_6,
g_atype1123_7,
g_atype1123_8,
g_atype1123_9,
g_atype1123_10,
g_atype1123_11,
g_atype1123_12,
g_atype1123_13,
g_atype1123_14,
};

static const long offsets1123 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
};

extern const char *names1124[];
static const uint32 types1124 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1124 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1124_0 [] = {0xFF01,202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_1 [] = {0xFF01,119,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_2 [] = {845,989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_3 [] = {848,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_4 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_5 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_6 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_7 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_8 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_9 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_10 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_11 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_12 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_13 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_14 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_15 [] = {1212,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_16 [] = {0xFFF9,5,953,1212,1274,959,959,0xFFF5,1,0xFF01,1103,7193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_17 [] = {1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_18 [] = {1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_19 [] = {1276,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_20 [] = {1270,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_21 [] = {1254,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_22 [] = {1229,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_23 [] = {1271,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_24 [] = {1253,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_25 [] = {1216,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_26 [] = {1255,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_27 [] = {0xFFF9,5,953,1215,1274,959,959,0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_28 [] = {1278,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_29 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_30 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_31 [] = {0xFF01,321,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_32 [] = {27,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_33 [] = {0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_34 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_35 [] = {1211,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_36 [] = {0xFF01,131,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_37 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_38 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_39 [] = {45,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_40 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_41 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_42 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_43 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_44 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_45 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_46 [] = {977,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_47 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_48 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_49 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_50 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_51 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_52 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_53 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_54 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_55 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_56 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_57 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_58 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_59 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_60 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_61 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_62 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_63 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_64 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_65 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_66 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_67 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_68 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_69 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_70 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_71 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_72 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_73 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_74 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_75 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_76 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_77 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_78 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_79 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_80 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1124 [] = {
g_atype1124_0,
g_atype1124_1,
g_atype1124_2,
g_atype1124_3,
g_atype1124_4,
g_atype1124_5,
g_atype1124_6,
g_atype1124_7,
g_atype1124_8,
g_atype1124_9,
g_atype1124_10,
g_atype1124_11,
g_atype1124_12,
g_atype1124_13,
g_atype1124_14,
g_atype1124_15,
g_atype1124_16,
g_atype1124_17,
g_atype1124_18,
g_atype1124_19,
g_atype1124_20,
g_atype1124_21,
g_atype1124_22,
g_atype1124_23,
g_atype1124_24,
g_atype1124_25,
g_atype1124_26,
g_atype1124_27,
g_atype1124_28,
g_atype1124_29,
g_atype1124_30,
g_atype1124_31,
g_atype1124_32,
g_atype1124_33,
g_atype1124_34,
g_atype1124_35,
g_atype1124_36,
g_atype1124_37,
g_atype1124_38,
g_atype1124_39,
g_atype1124_40,
g_atype1124_41,
g_atype1124_42,
g_atype1124_43,
g_atype1124_44,
g_atype1124_45,
g_atype1124_46,
g_atype1124_47,
g_atype1124_48,
g_atype1124_49,
g_atype1124_50,
g_atype1124_51,
g_atype1124_52,
g_atype1124_53,
g_atype1124_54,
g_atype1124_55,
g_atype1124_56,
g_atype1124_57,
g_atype1124_58,
g_atype1124_59,
g_atype1124_60,
g_atype1124_61,
g_atype1124_62,
g_atype1124_63,
g_atype1124_64,
g_atype1124_65,
g_atype1124_66,
g_atype1124_67,
g_atype1124_68,
g_atype1124_69,
g_atype1124_70,
g_atype1124_71,
g_atype1124_72,
g_atype1124_73,
g_atype1124_74,
g_atype1124_75,
g_atype1124_76,
g_atype1124_77,
g_atype1124_78,
g_atype1124_79,
g_atype1124_80,
};

static const long offsets1124 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
 + @REFACS(27),
 + @REFACS(28),
 + @REFACS(29),
 + @REFACS(30),
 + @REFACS(31),
 + @REFACS(32),
 + @REFACS(33),
 + @REFACS(34),
 + @REFACS(35),
 + @REFACS(36),
 + @REFACS(37),
 + @REFACS(38),
 + @REFACS(39),
 + @REFACS(40),
+ @CHROFF(41,0),
+ @CHROFF(41,1),
+ @CHROFF(41,2),
+ @CHROFF(41,3),
+ @CHROFF(41,4),
+ @CHROFF(41,5),
+ @LNGOFF(41,6,0,0),
+ @LNGOFF(41,6,0,1),
+ @LNGOFF(41,6,0,2),
+ @LNGOFF(41,6,0,3),
+ @LNGOFF(41,6,0,4),
+ @LNGOFF(41,6,0,5),
+ @LNGOFF(41,6,0,6),
+ @LNGOFF(41,6,0,7),
+ @LNGOFF(41,6,0,8),
+ @LNGOFF(41,6,0,9),
+ @LNGOFF(41,6,0,10),
+ @LNGOFF(41,6,0,11),
+ @LNGOFF(41,6,0,12),
+ @LNGOFF(41,6,0,13),
+ @LNGOFF(41,6,0,14),
+ @LNGOFF(41,6,0,15),
+ @LNGOFF(41,6,0,16),
+ @LNGOFF(41,6,0,17),
+ @LNGOFF(41,6,0,18),
+ @LNGOFF(41,6,0,19),
+ @LNGOFF(41,6,0,20),
+ @LNGOFF(41,6,0,21),
+ @LNGOFF(41,6,0,22),
+ @LNGOFF(41,6,0,23),
+ @LNGOFF(41,6,0,24),
+ @LNGOFF(41,6,0,25),
+ @LNGOFF(41,6,0,26),
+ @LNGOFF(41,6,0,27),
+ @LNGOFF(41,6,0,28),
+ @LNGOFF(41,6,0,29),
+ @LNGOFF(41,6,0,30),
+ @LNGOFF(41,6,0,31),
+ @LNGOFF(41,6,0,32),
+ @LNGOFF(41,6,0,33),
};

extern const char *names1125[];
static const uint32 types1125 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1125 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1125_0 [] = {0xFF01,202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_1 [] = {0xFF01,119,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_2 [] = {845,989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_3 [] = {848,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_4 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_5 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_6 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_7 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_8 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_9 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_10 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_11 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_12 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_13 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_14 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_15 [] = {1212,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_16 [] = {0xFFF9,5,953,1212,1274,959,959,0xFFF5,1,0xFF01,1103,7193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_17 [] = {1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_18 [] = {1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_19 [] = {1276,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_20 [] = {1270,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_21 [] = {1254,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_22 [] = {1229,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_23 [] = {1271,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_24 [] = {1253,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_25 [] = {1216,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_26 [] = {1255,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_27 [] = {0xFFF9,5,953,1215,1274,959,959,0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_28 [] = {1278,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_29 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_30 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_31 [] = {0xFF01,321,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_32 [] = {27,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_33 [] = {0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_34 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_35 [] = {1211,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_36 [] = {0xFF01,131,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_37 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_38 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_39 [] = {45,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_40 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_41 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_42 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_43 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_44 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_45 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_46 [] = {977,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_47 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_48 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_49 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_50 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_51 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_52 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_53 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_54 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_55 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_56 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_57 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_58 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_59 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_60 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_61 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_62 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_63 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_64 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_65 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_66 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_67 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_68 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_69 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_70 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_71 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_72 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_73 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_74 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_75 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_76 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_77 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_78 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_79 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1125_80 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1125 [] = {
g_atype1125_0,
g_atype1125_1,
g_atype1125_2,
g_atype1125_3,
g_atype1125_4,
g_atype1125_5,
g_atype1125_6,
g_atype1125_7,
g_atype1125_8,
g_atype1125_9,
g_atype1125_10,
g_atype1125_11,
g_atype1125_12,
g_atype1125_13,
g_atype1125_14,
g_atype1125_15,
g_atype1125_16,
g_atype1125_17,
g_atype1125_18,
g_atype1125_19,
g_atype1125_20,
g_atype1125_21,
g_atype1125_22,
g_atype1125_23,
g_atype1125_24,
g_atype1125_25,
g_atype1125_26,
g_atype1125_27,
g_atype1125_28,
g_atype1125_29,
g_atype1125_30,
g_atype1125_31,
g_atype1125_32,
g_atype1125_33,
g_atype1125_34,
g_atype1125_35,
g_atype1125_36,
g_atype1125_37,
g_atype1125_38,
g_atype1125_39,
g_atype1125_40,
g_atype1125_41,
g_atype1125_42,
g_atype1125_43,
g_atype1125_44,
g_atype1125_45,
g_atype1125_46,
g_atype1125_47,
g_atype1125_48,
g_atype1125_49,
g_atype1125_50,
g_atype1125_51,
g_atype1125_52,
g_atype1125_53,
g_atype1125_54,
g_atype1125_55,
g_atype1125_56,
g_atype1125_57,
g_atype1125_58,
g_atype1125_59,
g_atype1125_60,
g_atype1125_61,
g_atype1125_62,
g_atype1125_63,
g_atype1125_64,
g_atype1125_65,
g_atype1125_66,
g_atype1125_67,
g_atype1125_68,
g_atype1125_69,
g_atype1125_70,
g_atype1125_71,
g_atype1125_72,
g_atype1125_73,
g_atype1125_74,
g_atype1125_75,
g_atype1125_76,
g_atype1125_77,
g_atype1125_78,
g_atype1125_79,
g_atype1125_80,
};

static const long offsets1125 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
 + @REFACS(27),
 + @REFACS(28),
 + @REFACS(29),
 + @REFACS(30),
 + @REFACS(31),
 + @REFACS(32),
 + @REFACS(33),
 + @REFACS(34),
 + @REFACS(35),
 + @REFACS(36),
 + @REFACS(37),
 + @REFACS(38),
 + @REFACS(39),
 + @REFACS(40),
+ @CHROFF(41,0),
+ @CHROFF(41,1),
+ @CHROFF(41,2),
+ @CHROFF(41,3),
+ @CHROFF(41,4),
+ @CHROFF(41,5),
+ @LNGOFF(41,6,0,0),
+ @LNGOFF(41,6,0,1),
+ @LNGOFF(41,6,0,2),
+ @LNGOFF(41,6,0,3),
+ @LNGOFF(41,6,0,4),
+ @LNGOFF(41,6,0,5),
+ @LNGOFF(41,6,0,6),
+ @LNGOFF(41,6,0,7),
+ @LNGOFF(41,6,0,8),
+ @LNGOFF(41,6,0,9),
+ @LNGOFF(41,6,0,10),
+ @LNGOFF(41,6,0,11),
+ @LNGOFF(41,6,0,12),
+ @LNGOFF(41,6,0,13),
+ @LNGOFF(41,6,0,14),
+ @LNGOFF(41,6,0,15),
+ @LNGOFF(41,6,0,16),
+ @LNGOFF(41,6,0,17),
+ @LNGOFF(41,6,0,18),
+ @LNGOFF(41,6,0,19),
+ @LNGOFF(41,6,0,20),
+ @LNGOFF(41,6,0,21),
+ @LNGOFF(41,6,0,22),
+ @LNGOFF(41,6,0,23),
+ @LNGOFF(41,6,0,24),
+ @LNGOFF(41,6,0,25),
+ @LNGOFF(41,6,0,26),
+ @LNGOFF(41,6,0,27),
+ @LNGOFF(41,6,0,28),
+ @LNGOFF(41,6,0,29),
+ @LNGOFF(41,6,0,30),
+ @LNGOFF(41,6,0,31),
+ @LNGOFF(41,6,0,32),
+ @LNGOFF(41,6,0,33),
};

extern const char *names1126[];
static const uint32 types1126 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1126 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1126_0 [] = {0xFF01,202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_1 [] = {0xFF01,119,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_2 [] = {845,989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_3 [] = {848,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_4 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_5 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_6 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_7 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_8 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_9 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_10 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_11 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_12 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_13 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_14 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_15 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_16 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_17 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_18 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_19 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_20 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_21 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_22 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_23 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_24 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_25 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_26 [] = {1212,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_27 [] = {0xFFF9,5,953,1212,1274,959,959,0xFFF5,1,0xFF01,1103,7193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_28 [] = {1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_29 [] = {1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_30 [] = {1276,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_31 [] = {1270,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_32 [] = {1254,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_33 [] = {1229,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_34 [] = {1271,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_35 [] = {1253,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_36 [] = {1216,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_37 [] = {1255,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_38 [] = {0xFFF9,5,953,1215,1274,959,959,0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_39 [] = {1278,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_40 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_41 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_42 [] = {0xFF01,321,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_43 [] = {27,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_44 [] = {0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_45 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_46 [] = {1211,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_47 [] = {0xFF01,131,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_48 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_49 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_50 [] = {45,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_51 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_52 [] = {1305,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_53 [] = {1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_54 [] = {1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_55 [] = {1306,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_56 [] = {1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_57 [] = {1134,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_58 [] = {1200,0xFF01,1147,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_59 [] = {0xFF01,26,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_60 [] = {0xFF01,793,0xFF01,1197,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_61 [] = {0xFF01,806,0xFF01,0xFFF9,2,953,0xFFF5,1,0xFF01,1274,10429,977,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_62 [] = {0xFF01,807,0xFFF5,1,0xFF01,806,0xFF01,0xFFF9,0,953,4109,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_63 [] = {0xFF01,806,0xFF01,0xFFF9,6,953,959,959,992,992,992,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_64 [] = {1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_65 [] = {1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_66 [] = {1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_67 [] = {1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_68 [] = {1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_69 [] = {1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_70 [] = {1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_71 [] = {0xFF01,806,1212,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_72 [] = {793,0xFF01,0xFFF9,2,953,0xFF01,1274,0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_73 [] = {0xFF01,807,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_74 [] = {0xFF01,807,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_75 [] = {0xFF01,807,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_76 [] = {1278,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_77 [] = {1278,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_78 [] = {1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_79 [] = {1236,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_80 [] = {1243,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_81 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_82 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_83 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_84 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_85 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_86 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_87 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_88 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_89 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_90 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_91 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_92 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_93 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_94 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_95 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_96 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_97 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_98 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_99 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_100 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_101 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_102 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_103 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_104 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_105 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_106 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_107 [] = {977,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_108 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_109 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_110 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_111 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_112 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_113 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_114 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_115 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_116 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_117 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_118 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_119 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_120 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_121 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_122 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_123 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_124 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_125 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_126 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_127 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_128 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_129 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_130 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_131 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_132 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_133 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_134 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_135 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_136 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_137 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_138 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_139 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_140 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_141 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_142 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_143 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_144 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_145 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_146 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_147 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_148 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_149 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_150 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_151 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_152 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_153 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_154 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_155 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_156 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_157 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_158 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_159 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_160 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_161 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_162 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_163 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1126_164 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1126 [] = {
g_atype1126_0,
g_atype1126_1,
g_atype1126_2,
g_atype1126_3,
g_atype1126_4,
g_atype1126_5,
g_atype1126_6,
g_atype1126_7,
g_atype1126_8,
g_atype1126_9,
g_atype1126_10,
g_atype1126_11,
g_atype1126_12,
g_atype1126_13,
g_atype1126_14,
g_atype1126_15,
g_atype1126_16,
g_atype1126_17,
g_atype1126_18,
g_atype1126_19,
g_atype1126_20,
g_atype1126_21,
g_atype1126_22,
g_atype1126_23,
g_atype1126_24,
g_atype1126_25,
g_atype1126_26,
g_atype1126_27,
g_atype1126_28,
g_atype1126_29,
g_atype1126_30,
g_atype1126_31,
g_atype1126_32,
g_atype1126_33,
g_atype1126_34,
g_atype1126_35,
g_atype1126_36,
g_atype1126_37,
g_atype1126_38,
g_atype1126_39,
g_atype1126_40,
g_atype1126_41,
g_atype1126_42,
g_atype1126_43,
g_atype1126_44,
g_atype1126_45,
g_atype1126_46,
g_atype1126_47,
g_atype1126_48,
g_atype1126_49,
g_atype1126_50,
g_atype1126_51,
g_atype1126_52,
g_atype1126_53,
g_atype1126_54,
g_atype1126_55,
g_atype1126_56,
g_atype1126_57,
g_atype1126_58,
g_atype1126_59,
g_atype1126_60,
g_atype1126_61,
g_atype1126_62,
g_atype1126_63,
g_atype1126_64,
g_atype1126_65,
g_atype1126_66,
g_atype1126_67,
g_atype1126_68,
g_atype1126_69,
g_atype1126_70,
g_atype1126_71,
g_atype1126_72,
g_atype1126_73,
g_atype1126_74,
g_atype1126_75,
g_atype1126_76,
g_atype1126_77,
g_atype1126_78,
g_atype1126_79,
g_atype1126_80,
g_atype1126_81,
g_atype1126_82,
g_atype1126_83,
g_atype1126_84,
g_atype1126_85,
g_atype1126_86,
g_atype1126_87,
g_atype1126_88,
g_atype1126_89,
g_atype1126_90,
g_atype1126_91,
g_atype1126_92,
g_atype1126_93,
g_atype1126_94,
g_atype1126_95,
g_atype1126_96,
g_atype1126_97,
g_atype1126_98,
g_atype1126_99,
g_atype1126_100,
g_atype1126_101,
g_atype1126_102,
g_atype1126_103,
g_atype1126_104,
g_atype1126_105,
g_atype1126_106,
g_atype1126_107,
g_atype1126_108,
g_atype1126_109,
g_atype1126_110,
g_atype1126_111,
g_atype1126_112,
g_atype1126_113,
g_atype1126_114,
g_atype1126_115,
g_atype1126_116,
g_atype1126_117,
g_atype1126_118,
g_atype1126_119,
g_atype1126_120,
g_atype1126_121,
g_atype1126_122,
g_atype1126_123,
g_atype1126_124,
g_atype1126_125,
g_atype1126_126,
g_atype1126_127,
g_atype1126_128,
g_atype1126_129,
g_atype1126_130,
g_atype1126_131,
g_atype1126_132,
g_atype1126_133,
g_atype1126_134,
g_atype1126_135,
g_atype1126_136,
g_atype1126_137,
g_atype1126_138,
g_atype1126_139,
g_atype1126_140,
g_atype1126_141,
g_atype1126_142,
g_atype1126_143,
g_atype1126_144,
g_atype1126_145,
g_atype1126_146,
g_atype1126_147,
g_atype1126_148,
g_atype1126_149,
g_atype1126_150,
g_atype1126_151,
g_atype1126_152,
g_atype1126_153,
g_atype1126_154,
g_atype1126_155,
g_atype1126_156,
g_atype1126_157,
g_atype1126_158,
g_atype1126_159,
g_atype1126_160,
g_atype1126_161,
g_atype1126_162,
g_atype1126_163,
g_atype1126_164,
};

static const long offsets1126 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
 + @REFACS(27),
 + @REFACS(28),
 + @REFACS(29),
 + @REFACS(30),
 + @REFACS(31),
 + @REFACS(32),
 + @REFACS(33),
 + @REFACS(34),
 + @REFACS(35),
 + @REFACS(36),
 + @REFACS(37),
 + @REFACS(38),
 + @REFACS(39),
 + @REFACS(40),
 + @REFACS(41),
 + @REFACS(42),
 + @REFACS(43),
 + @REFACS(44),
 + @REFACS(45),
 + @REFACS(46),
 + @REFACS(47),
 + @REFACS(48),
 + @REFACS(49),
 + @REFACS(50),
 + @REFACS(51),
 + @REFACS(52),
 + @REFACS(53),
 + @REFACS(54),
 + @REFACS(55),
 + @REFACS(56),
 + @REFACS(57),
 + @REFACS(58),
 + @REFACS(59),
 + @REFACS(60),
 + @REFACS(61),
 + @REFACS(62),
 + @REFACS(63),
 + @REFACS(64),
 + @REFACS(65),
 + @REFACS(66),
 + @REFACS(67),
 + @REFACS(68),
 + @REFACS(69),
 + @REFACS(70),
 + @REFACS(71),
 + @REFACS(72),
 + @REFACS(73),
 + @REFACS(74),
 + @REFACS(75),
 + @REFACS(76),
 + @REFACS(77),
 + @REFACS(78),
 + @REFACS(79),
 + @REFACS(80),
+ @CHROFF(81,0),
+ @CHROFF(81,1),
+ @CHROFF(81,2),
+ @CHROFF(81,3),
+ @CHROFF(81,4),
+ @CHROFF(81,5),
+ @CHROFF(81,6),
+ @CHROFF(81,7),
+ @CHROFF(81,8),
+ @CHROFF(81,9),
+ @CHROFF(81,10),
+ @CHROFF(81,11),
+ @CHROFF(81,12),
+ @CHROFF(81,13),
+ @CHROFF(81,14),
+ @CHROFF(81,15),
+ @CHROFF(81,16),
+ @CHROFF(81,17),
+ @CHROFF(81,18),
+ @CHROFF(81,19),
+ @CHROFF(81,20),
+ @CHROFF(81,21),
+ @CHROFF(81,22),
+ @CHROFF(81,23),
+ @CHROFF(81,24),
+ @CHROFF(81,25),
+ @CHROFF(81,26),
+ @LNGOFF(81,27,0,0),
+ @LNGOFF(81,27,0,1),
+ @LNGOFF(81,27,0,2),
+ @LNGOFF(81,27,0,3),
+ @LNGOFF(81,27,0,4),
+ @LNGOFF(81,27,0,5),
+ @LNGOFF(81,27,0,6),
+ @LNGOFF(81,27,0,7),
+ @LNGOFF(81,27,0,8),
+ @LNGOFF(81,27,0,9),
+ @LNGOFF(81,27,0,10),
+ @LNGOFF(81,27,0,11),
+ @LNGOFF(81,27,0,12),
+ @LNGOFF(81,27,0,13),
+ @LNGOFF(81,27,0,14),
+ @LNGOFF(81,27,0,15),
+ @LNGOFF(81,27,0,16),
+ @LNGOFF(81,27,0,17),
+ @LNGOFF(81,27,0,18),
+ @LNGOFF(81,27,0,19),
+ @LNGOFF(81,27,0,20),
+ @LNGOFF(81,27,0,21),
+ @LNGOFF(81,27,0,22),
+ @LNGOFF(81,27,0,23),
+ @LNGOFF(81,27,0,24),
+ @LNGOFF(81,27,0,25),
+ @LNGOFF(81,27,0,26),
+ @LNGOFF(81,27,0,27),
+ @LNGOFF(81,27,0,28),
+ @LNGOFF(81,27,0,29),
+ @LNGOFF(81,27,0,30),
+ @LNGOFF(81,27,0,31),
+ @LNGOFF(81,27,0,32),
+ @LNGOFF(81,27,0,33),
+ @LNGOFF(81,27,0,34),
+ @LNGOFF(81,27,0,35),
+ @LNGOFF(81,27,0,36),
+ @LNGOFF(81,27,0,37),
+ @LNGOFF(81,27,0,38),
+ @LNGOFF(81,27,0,39),
+ @LNGOFF(81,27,0,40),
+ @LNGOFF(81,27,0,41),
+ @LNGOFF(81,27,0,42),
+ @LNGOFF(81,27,0,43),
+ @LNGOFF(81,27,0,44),
+ @LNGOFF(81,27,0,45),
+ @LNGOFF(81,27,0,46),
+ @LNGOFF(81,27,0,47),
+ @LNGOFF(81,27,0,48),
+ @LNGOFF(81,27,0,49),
+ @LNGOFF(81,27,0,50),
+ @LNGOFF(81,27,0,51),
+ @LNGOFF(81,27,0,52),
+ @LNGOFF(81,27,0,53),
+ @LNGOFF(81,27,0,54),
+ @LNGOFF(81,27,0,55),
+ @LNGOFF(81,27,0,56),
};

extern const char *names1127[];
static const uint32 types1127 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1127 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1127_0 [] = {0xFF01,202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_1 [] = {0xFF01,119,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_2 [] = {845,989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_3 [] = {848,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_4 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_5 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_6 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_7 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_8 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_9 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_10 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_11 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_12 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_13 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_14 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_15 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_16 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_17 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_18 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_19 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_20 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_21 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_22 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_23 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_24 [] = {0xFF01,842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_25 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_26 [] = {1212,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_27 [] = {0xFFF9,5,953,1212,1274,959,959,0xFFF5,1,0xFF01,1103,7193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_28 [] = {1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_29 [] = {1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_30 [] = {1276,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_31 [] = {1270,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_32 [] = {1254,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_33 [] = {1229,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_34 [] = {1271,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_35 [] = {1253,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_36 [] = {1216,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_37 [] = {1255,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_38 [] = {0xFFF9,5,953,1215,1274,959,959,0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_39 [] = {1278,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_40 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_41 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_42 [] = {0xFF01,321,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_43 [] = {27,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_44 [] = {0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_45 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_46 [] = {1211,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_47 [] = {0xFF01,131,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_48 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_49 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_50 [] = {45,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_51 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_52 [] = {1305,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_53 [] = {1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_54 [] = {1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_55 [] = {1306,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_56 [] = {1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_57 [] = {1134,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_58 [] = {1200,0xFF01,1147,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_59 [] = {0xFF01,26,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_60 [] = {0xFF01,793,0xFF01,1197,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_61 [] = {0xFF01,806,0xFF01,0xFFF9,2,953,0xFFF5,1,0xFF01,1274,10429,977,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_62 [] = {0xFF01,807,0xFFF5,1,0xFF01,806,0xFF01,0xFFF9,0,953,4109,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_63 [] = {0xFF01,806,0xFF01,0xFFF9,6,953,959,959,992,992,992,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_64 [] = {1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_65 [] = {1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_66 [] = {1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_67 [] = {1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_68 [] = {1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_69 [] = {1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_70 [] = {1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_71 [] = {0xFF01,806,1212,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_72 [] = {793,0xFF01,0xFFF9,2,953,0xFF01,1274,0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_73 [] = {0xFF01,807,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_74 [] = {0xFF01,807,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_75 [] = {0xFF01,807,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_76 [] = {1278,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_77 [] = {1278,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_78 [] = {1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_79 [] = {1236,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_80 [] = {1243,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_81 [] = {0xFF01,839,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_82 [] = {0xFF01,35,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_83 [] = {0xFF01,839,1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_84 [] = {0xFF01,35,1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_85 [] = {0xFF01,839,1276,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_86 [] = {0xFF01,35,1276,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_87 [] = {0xFF01,839,1212,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_88 [] = {0xFF01,35,1212,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_89 [] = {0xFF01,839,0xFF01,321,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_90 [] = {0xFF01,35,0xFF01,321,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_91 [] = {0xFF01,839,0xFF02,0xFFF5,1,0xFF01,321,3664,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_92 [] = {0xFF01,35,0xFF02,0xFFF5,1,0xFF01,321,3664,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_93 [] = {0xFF01,839,1270,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_94 [] = {0xFF01,35,1270,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_95 [] = {0xFF01,839,1254,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_96 [] = {0xFF01,35,1254,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_97 [] = {0xFF01,839,1229,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_98 [] = {0xFF01,35,1229,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_99 [] = {0xFF01,839,1271,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_100 [] = {0xFF01,35,1271,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_101 [] = {0xFF01,839,1253,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_102 [] = {0xFF01,35,1253,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_103 [] = {0xFF01,839,1216,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_104 [] = {0xFF01,35,1216,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_105 [] = {0xFF01,839,1255,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_106 [] = {0xFF01,35,1255,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_107 [] = {0xFF01,839,1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_108 [] = {0xFF01,35,1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_109 [] = {0xFF01,839,0xFFF9,5,953,1215,1274,959,959,0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_110 [] = {0xFF01,35,0xFFF9,5,953,1215,1274,959,959,0xFF01,1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_111 [] = {0xFF01,839,1278,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_112 [] = {0xFF01,35,1278,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_113 [] = {0xFF01,839,320,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_114 [] = {0xFF01,35,320,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_115 [] = {0xFF01,839,812,0xFF01,320,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_116 [] = {0xFF01,35,812,0xFF01,320,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_117 [] = {0xFF01,839,32,0xFF01,1215,0xFF01,1200,0xFF01,1218,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_118 [] = {0xFF01,35,32,0xFF01,1215,0xFF01,1200,0xFF01,1218,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_119 [] = {0xFF01,839,32,0xFF01,1215,0xFF01,1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_120 [] = {0xFF01,35,32,0xFF01,1215,0xFF01,1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_121 [] = {0xFF01,839,32,0xFF01,1215,0xFF01,1278,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_122 [] = {0xFF01,35,32,0xFF01,1215,0xFF01,1278,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_123 [] = {0xFF01,839,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_124 [] = {0xFF01,35,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_125 [] = {0xFF01,839,32,0xFF01,1215,1200,0xFF01,1256,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_126 [] = {0xFF01,35,32,0xFF01,1215,1200,0xFF01,1256,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_127 [] = {0xFF01,839,32,0xFF01,1215,0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_128 [] = {0xFF01,35,32,0xFF01,1215,0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_129 [] = {0xFF01,839,31,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_130 [] = {0xFF01,35,31,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_131 [] = {0xFF01,839,1163,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_132 [] = {0xFF01,35,1163,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_133 [] = {0xFF01,839,1164,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_134 [] = {0xFF01,35,1164,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_135 [] = {0xFF01,839,1165,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_136 [] = {0xFF01,35,1165,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_137 [] = {0xFF01,839,1248,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_138 [] = {0xFF01,35,1248,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_139 [] = {0xFF01,839,1230,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_140 [] = {0xFF01,35,1230,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_141 [] = {0xFF01,839,1267,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_142 [] = {0xFF01,35,1267,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_143 [] = {0xFF01,839,1280,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_144 [] = {0xFF01,35,1280,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_145 [] = {0xFF01,839,1143,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_146 [] = {0xFF01,35,1143,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_147 [] = {0xFF01,846,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_148 [] = {0xFF01,37,992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_149 [] = {0xFF01,839,1161,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_150 [] = {0xFF01,35,1161,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_151 [] = {0xFF01,839,1159,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_152 [] = {0xFF01,35,1159,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_153 [] = {0xFF01,839,1158,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_154 [] = {0xFF01,35,1158,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_155 [] = {0xFF01,839,1223,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_156 [] = {0xFF01,35,1223,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_157 [] = {0xFF01,839,1129,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_158 [] = {0xFF01,35,1129,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_159 [] = {0xFF01,839,1156,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_160 [] = {0xFF01,35,1156,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_161 [] = {0xFF01,839,1137,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_162 [] = {0xFF01,35,1137,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_163 [] = {0xFF01,839,1132,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_164 [] = {0xFF01,35,1132,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_165 [] = {0xFF01,839,1224,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_166 [] = {0xFF01,35,1224,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_167 [] = {0xFF01,839,1247,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_168 [] = {0xFF01,35,1247,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_169 [] = {0xFF01,839,1225,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_170 [] = {0xFF01,35,1225,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_171 [] = {0xFF01,839,1138,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_172 [] = {0xFF01,35,1138,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_173 [] = {0xFF01,839,1245,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_174 [] = {0xFF01,35,1245,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_175 [] = {0xFF01,839,1150,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_176 [] = {0xFF01,35,1150,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_177 [] = {0xFF01,839,1139,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_178 [] = {0xFF01,35,1139,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_179 [] = {0xFF01,839,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_180 [] = {0xFF01,35,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_181 [] = {0xFF01,839,1250,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_182 [] = {0xFF01,35,1250,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_183 [] = {0xFF01,839,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_184 [] = {0xFF01,35,1172,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_185 [] = {0xFF01,839,1131,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_186 [] = {0xFF01,35,1131,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_187 [] = {0xFF01,839,1306,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_188 [] = {0xFF01,35,1306,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_189 [] = {0xFF01,839,1145,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_190 [] = {0xFF01,35,1145,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_191 [] = {0xFF01,839,1168,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_192 [] = {0xFF01,35,1168,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_193 [] = {0xFF01,839,1197,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_194 [] = {0xFF01,35,1197,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_195 [] = {0xFF01,839,1135,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_196 [] = {0xFF01,35,1135,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_197 [] = {0xFF01,839,1222,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_198 [] = {0xFF01,35,1222,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_199 [] = {0xFF01,839,1228,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_200 [] = {0xFF01,35,1228,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_201 [] = {0xFF01,839,1246,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_202 [] = {0xFF01,35,1246,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_203 [] = {0xFF01,839,1133,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_204 [] = {0xFF01,35,1133,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_205 [] = {0xFF01,839,1227,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_206 [] = {0xFF01,35,1227,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_207 [] = {0xFF01,839,1244,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_208 [] = {0xFF01,35,1244,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_209 [] = {0xFF01,839,1218,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_210 [] = {0xFF01,35,1218,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_211 [] = {0xFF01,839,1273,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_212 [] = {0xFF01,35,1273,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_213 [] = {0xFF01,839,1174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_214 [] = {0xFF01,35,1174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_215 [] = {0xFF01,839,1136,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_216 [] = {0xFF01,35,1136,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_217 [] = {0xFF01,839,1134,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_218 [] = {0xFF01,35,1134,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_219 [] = {0xFF01,839,1252,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_220 [] = {0xFF01,35,1252,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_221 [] = {0xFF01,839,1226,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_222 [] = {0xFF01,35,1226,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_223 [] = {0xFF01,839,1128,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_224 [] = {0xFF01,35,1128,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_225 [] = {0xFF01,839,1162,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_226 [] = {0xFF01,35,1162,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_227 [] = {0xFF01,839,1249,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_228 [] = {0xFF01,35,1249,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_229 [] = {0xFF01,839,1142,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_230 [] = {0xFF01,35,1142,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_231 [] = {0xFF01,839,1190,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_232 [] = {0xFF01,35,1190,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_233 [] = {0xFF01,839,1269,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_234 [] = {0xFF01,35,1269,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_235 [] = {0xFF01,839,1272,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_236 [] = {0xFF01,35,1272,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_237 [] = {0xFF01,839,1140,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_238 [] = {0xFF01,35,1140,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_239 [] = {0xFF01,839,1152,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_240 [] = {0xFF01,35,1152,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_241 [] = {0xFF01,839,1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_242 [] = {0xFF01,35,1231,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_243 [] = {0xFF01,839,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_244 [] = {0xFF01,35,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_245 [] = {0xFF01,839,1155,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_246 [] = {0xFF01,35,1155,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_247 [] = {0xFF01,839,1258,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_248 [] = {0xFF01,35,1258,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_249 [] = {0xFF01,839,1221,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_250 [] = {0xFF01,35,1221,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_251 [] = {0xFF01,839,1256,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_252 [] = {0xFF01,35,1256,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_253 [] = {0xFF01,839,1251,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_254 [] = {0xFF01,35,1251,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_255 [] = {0xFF01,839,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_256 [] = {0xFF01,35,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_257 [] = {0xFF01,839,1196,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_258 [] = {0xFF01,35,1196,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_259 [] = {0xFF01,839,1198,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_260 [] = {0xFF01,35,1198,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_261 [] = {0xFF01,839,1148,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_262 [] = {0xFF01,35,1148,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_263 [] = {0xFF01,839,1147,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_264 [] = {0xFF01,35,1147,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_265 [] = {0xFF01,839,1257,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_266 [] = {0xFF01,35,1257,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_267 [] = {0xFF01,839,1307,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_268 [] = {0xFF01,35,1307,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_269 [] = {0xFF01,839,1200,0xFF01,1267,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_270 [] = {0xFF01,35,1200,0xFF01,1267,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_271 [] = {0xFF01,839,1200,0xFF01,1159,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_272 [] = {0xFF01,35,1200,0xFF01,1159,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_273 [] = {0xFF01,839,1200,0xFF01,1158,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_274 [] = {0xFF01,35,1200,0xFF01,1158,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_275 [] = {0xFF01,839,1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_276 [] = {0xFF01,35,1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_277 [] = {0xFF01,839,1200,0xFF01,1132,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_278 [] = {0xFF01,35,1200,0xFF01,1132,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_279 [] = {0xFF01,839,1200,0xFF01,1138,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_280 [] = {0xFF01,35,1200,0xFF01,1138,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_281 [] = {0xFF01,839,1200,0xFF01,1245,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_282 [] = {0xFF01,35,1200,0xFF01,1245,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_283 [] = {0xFF01,839,1200,0xFF01,1139,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_284 [] = {0xFF01,35,1200,0xFF01,1139,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_285 [] = {0xFF01,839,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_286 [] = {0xFF01,35,1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_287 [] = {0xFF01,839,1200,0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_288 [] = {0xFF01,35,1200,0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_289 [] = {0xFF01,839,1182,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_290 [] = {0xFF01,35,1182,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_291 [] = {0xFF01,839,1200,0xFF01,1306,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_292 [] = {0xFF01,35,1200,0xFF01,1306,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_293 [] = {0xFF01,839,1200,0xFF01,1145,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_294 [] = {0xFF01,35,1200,0xFF01,1145,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_295 [] = {0xFF01,839,1200,0xFF01,1307,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_296 [] = {0xFF01,35,1200,0xFF01,1307,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_297 [] = {0xFF01,839,1200,0xFF01,1128,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_298 [] = {0xFF01,35,1200,0xFF01,1128,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_299 [] = {0xFF01,839,33,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_300 [] = {0xFF01,35,33,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_301 [] = {0xFF01,839,1186,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_302 [] = {0xFF01,35,1186,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_303 [] = {0xFF01,839,1185,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_304 [] = {0xFF01,35,1185,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_305 [] = {0xFF01,839,1184,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_306 [] = {0xFF01,35,1184,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_307 [] = {0xFF01,839,1208,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_308 [] = {0xFF01,35,1208,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_309 [] = {0xFF01,839,1201,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_310 [] = {0xFF01,35,1201,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_311 [] = {0xFF01,839,1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_312 [] = {0xFF01,35,1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_313 [] = {0xFF01,839,1144,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_314 [] = {0xFF01,35,1144,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_315 [] = {0xFF01,839,1200,0xFF01,1218,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_316 [] = {0xFF01,35,1200,0xFF01,1218,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_317 [] = {0xFF01,839,1200,0xFF01,1136,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_318 [] = {0xFF01,35,1200,0xFF01,1136,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_319 [] = {0xFF01,839,1200,0xFF01,1249,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_320 [] = {0xFF01,35,1200,0xFF01,1249,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_321 [] = {0xFF01,839,1179,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_322 [] = {0xFF01,35,1179,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_323 [] = {0xFF01,839,1207,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_324 [] = {0xFF01,35,1207,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_325 [] = {0xFF01,839,1200,0xFF01,1140,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_326 [] = {0xFF01,35,1200,0xFF01,1140,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_327 [] = {0xFF01,839,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_328 [] = {0xFF01,35,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_329 [] = {0xFF01,839,1200,0xFF01,1278,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_330 [] = {0xFF01,35,1200,0xFF01,1278,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_331 [] = {0xFF01,839,1180,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_332 [] = {0xFF01,35,1180,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_333 [] = {0xFF01,839,1200,0xFF01,1256,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_334 [] = {0xFF01,35,1200,0xFF01,1256,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_335 [] = {0xFF01,839,1209,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_336 [] = {0xFF01,35,1209,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_337 [] = {0xFF01,839,1204,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_338 [] = {0xFF01,35,1204,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_339 [] = {0xFF01,839,1203,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_340 [] = {0xFF01,35,1203,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_341 [] = {0xFF01,839,1130,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_342 [] = {0xFF01,35,1130,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_343 [] = {0xFF01,839,1181,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_344 [] = {0xFF01,35,1181,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_345 [] = {0xFF01,839,34,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_346 [] = {0xFF01,35,34,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_347 [] = {0xFF01,839,1206,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_348 [] = {0xFF01,35,1206,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_349 [] = {0xFF01,839,1141,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_350 [] = {0xFF01,35,1141,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_351 [] = {989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_352 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_353 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_354 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_355 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_356 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_357 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_358 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_359 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_360 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_361 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_362 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_363 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_364 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_365 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_366 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_367 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_368 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_369 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_370 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_371 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_372 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_373 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_374 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_375 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_376 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_377 [] = {977,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_378 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_379 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_380 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_381 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_382 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_383 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_384 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_385 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_386 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_387 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_388 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_389 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_390 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_391 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_392 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_393 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_394 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_395 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_396 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_397 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_398 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_399 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_400 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_401 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_402 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_403 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_404 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_405 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_406 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_407 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_408 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_409 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_410 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_411 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_412 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_413 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_414 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_415 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_416 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_417 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_418 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_419 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_420 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_421 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_422 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_423 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_424 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_425 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_426 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_427 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_428 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_429 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_430 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_431 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_432 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_433 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_434 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_435 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_436 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_437 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_438 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_439 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_440 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_441 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_442 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_443 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_444 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_445 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_446 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_447 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_448 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_449 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_450 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_451 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_452 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_453 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_454 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_455 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_456 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_457 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_458 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_459 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_460 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_461 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_462 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_463 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_464 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_465 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_466 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_467 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_468 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_469 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_470 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_471 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_472 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_473 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_474 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_475 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_476 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_477 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_478 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_479 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_480 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_481 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_482 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_483 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_484 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_485 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_486 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_487 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_488 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_489 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_490 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_491 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_492 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_493 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_494 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_495 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_496 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_497 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_498 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_499 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_500 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_501 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_502 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_503 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_504 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_505 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_506 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_507 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_508 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_509 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_510 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_511 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_512 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_513 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_514 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_515 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_516 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_517 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_518 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_519 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_520 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_521 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_522 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_523 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_524 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_525 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_526 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_527 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_528 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_529 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_530 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_531 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_532 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_533 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_534 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_535 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_536 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_537 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_538 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_539 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_540 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_541 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_542 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_543 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_544 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_545 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_546 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_547 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_548 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_549 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_550 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_551 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_552 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_553 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_554 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_555 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_556 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_557 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_558 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_559 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_560 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_561 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_562 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_563 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_564 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_565 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_566 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_567 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_568 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_569 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_570 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_571 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_572 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_573 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_574 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_575 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_576 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_577 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_578 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_579 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_580 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_581 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_582 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_583 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_584 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_585 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_586 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_587 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_588 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_589 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_590 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_591 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_592 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_593 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_594 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_595 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_596 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_597 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_598 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_599 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_600 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_601 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_602 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_603 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_604 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_605 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_606 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_607 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_608 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_609 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_610 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_611 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_612 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_613 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_614 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_615 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_616 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_617 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_618 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_619 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_620 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_621 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_622 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_623 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_624 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_625 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_626 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_627 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_628 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_629 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_630 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_631 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_632 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_633 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_634 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_635 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_636 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_637 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_638 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_639 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_640 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_641 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_642 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_643 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_644 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_645 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_646 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_647 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_648 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_649 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_650 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_651 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_652 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_653 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_654 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_655 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_656 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_657 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_658 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_659 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_660 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_661 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_662 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_663 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_664 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_665 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_666 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_667 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_668 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_669 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_670 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_671 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_672 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_673 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_674 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_675 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_676 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_677 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_678 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_679 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_680 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_681 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_682 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_683 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_684 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_685 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_686 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_687 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_688 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_689 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_690 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_691 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_692 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_693 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_694 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_695 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_696 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_697 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_698 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_699 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_700 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_701 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_702 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_703 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1127_704 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1127 [] = {
g_atype1127_0,
g_atype1127_1,
g_atype1127_2,
g_atype1127_3,
g_atype1127_4,
g_atype1127_5,
g_atype1127_6,
g_atype1127_7,
g_atype1127_8,
g_atype1127_9,
g_atype1127_10,
g_atype1127_11,
g_atype1127_12,
g_atype1127_13,
g_atype1127_14,
g_atype1127_15,
g_atype1127_16,
g_atype1127_17,
g_atype1127_18,
g_atype1127_19,
g_atype1127_20,
g_atype1127_21,
g_atype1127_22,
g_atype1127_23,
g_atype1127_24,
g_atype1127_25,
g_atype1127_26,
g_atype1127_27,
g_atype1127_28,
g_atype1127_29,
g_atype1127_30,
g_atype1127_31,
g_atype1127_32,
g_atype1127_33,
g_atype1127_34,
g_atype1127_35,
g_atype1127_36,
g_atype1127_37,
g_atype1127_38,
g_atype1127_39,
g_atype1127_40,
g_atype1127_41,
g_atype1127_42,
g_atype1127_43,
g_atype1127_44,
g_atype1127_45,
g_atype1127_46,
g_atype1127_47,
g_atype1127_48,
g_atype1127_49,
g_atype1127_50,
g_atype1127_51,
g_atype1127_52,
g_atype1127_53,
g_atype1127_54,
g_atype1127_55,
g_atype1127_56,
g_atype1127_57,
g_atype1127_58,
g_atype1127_59,
g_atype1127_60,
g_atype1127_61,
g_atype1127_62,
g_atype1127_63,
g_atype1127_64,
g_atype1127_65,
g_atype1127_66,
g_atype1127_67,
g_atype1127_68,
g_atype1127_69,
g_atype1127_70,
g_atype1127_71,
g_atype1127_72,
g_atype1127_73,
g_atype1127_74,
g_atype1127_75,
g_atype1127_76,
g_atype1127_77,
g_atype1127_78,
g_atype1127_79,
g_atype1127_80,
g_atype1127_81,
g_atype1127_82,
g_atype1127_83,
g_atype1127_84,
g_atype1127_85,
g_atype1127_86,
g_atype1127_87,
g_atype1127_88,
g_atype1127_89,
g_atype1127_90,
g_atype1127_91,
g_atype1127_92,
g_atype1127_93,
g_atype1127_94,
g_atype1127_95,
g_atype1127_96,
g_atype1127_97,
g_atype1127_98,
g_atype1127_99,
g_atype1127_100,
g_atype1127_101,
g_atype1127_102,
g_atype1127_103,
g_atype1127_104,
g_atype1127_105,
g_atype1127_106,
g_atype1127_107,
g_atype1127_108,
g_atype1127_109,
g_atype1127_110,
g_atype1127_111,
g_atype1127_112,
g_atype1127_113,
g_atype1127_114,
g_atype1127_115,
g_atype1127_116,
g_atype1127_117,
g_atype1127_118,
g_atype1127_119,
g_atype1127_120,
g_atype1127_121,
g_atype1127_122,
g_atype1127_123,
g_atype1127_124,
g_atype1127_125,
g_atype1127_126,
g_atype1127_127,
g_atype1127_128,
g_atype1127_129,
g_atype1127_130,
g_atype1127_131,
g_atype1127_132,
g_atype1127_133,
g_atype1127_134,
g_atype1127_135,
g_atype1127_136,
g_atype1127_137,
g_atype1127_138,
g_atype1127_139,
g_atype1127_140,
g_atype1127_141,
g_atype1127_142,
g_atype1127_143,
g_atype1127_144,
g_atype1127_145,
g_atype1127_146,
g_atype1127_147,
g_atype1127_148,
g_atype1127_149,
g_atype1127_150,
g_atype1127_151,
g_atype1127_152,
g_atype1127_153,
g_atype1127_154,
g_atype1127_155,
g_atype1127_156,
g_atype1127_157,
g_atype1127_158,
g_atype1127_159,
g_atype1127_160,
g_atype1127_161,
g_atype1127_162,
g_atype1127_163,
g_atype1127_164,
g_atype1127_165,
g_atype1127_166,
g_atype1127_167,
g_atype1127_168,
g_atype1127_169,
g_atype1127_170,
g_atype1127_171,
g_atype1127_172,
g_atype1127_173,
g_atype1127_174,
g_atype1127_175,
g_atype1127_176,
g_atype1127_177,
g_atype1127_178,
g_atype1127_179,
g_atype1127_180,
g_atype1127_181,
g_atype1127_182,
g_atype1127_183,
g_atype1127_184,
g_atype1127_185,
g_atype1127_186,
g_atype1127_187,
g_atype1127_188,
g_atype1127_189,
g_atype1127_190,
g_atype1127_191,
g_atype1127_192,
g_atype1127_193,
g_atype1127_194,
g_atype1127_195,
g_atype1127_196,
g_atype1127_197,
g_atype1127_198,
g_atype1127_199,
g_atype1127_200,
g_atype1127_201,
g_atype1127_202,
g_atype1127_203,
g_atype1127_204,
g_atype1127_205,
g_atype1127_206,
g_atype1127_207,
g_atype1127_208,
g_atype1127_209,
g_atype1127_210,
g_atype1127_211,
g_atype1127_212,
g_atype1127_213,
g_atype1127_214,
g_atype1127_215,
g_atype1127_216,
g_atype1127_217,
g_atype1127_218,
g_atype1127_219,
g_atype1127_220,
g_atype1127_221,
g_atype1127_222,
g_atype1127_223,
g_atype1127_224,
g_atype1127_225,
g_atype1127_226,
g_atype1127_227,
g_atype1127_228,
g_atype1127_229,
g_atype1127_230,
g_atype1127_231,
g_atype1127_232,
g_atype1127_233,
g_atype1127_234,
g_atype1127_235,
g_atype1127_236,
g_atype1127_237,
g_atype1127_238,
g_atype1127_239,
g_atype1127_240,
g_atype1127_241,
g_atype1127_242,
g_atype1127_243,
g_atype1127_244,
g_atype1127_245,
g_atype1127_246,
g_atype1127_247,
g_atype1127_248,
g_atype1127_249,
g_atype1127_250,
g_atype1127_251,
g_atype1127_252,
g_atype1127_253,
g_atype1127_254,
g_atype1127_255,
g_atype1127_256,
g_atype1127_257,
g_atype1127_258,
g_atype1127_259,
g_atype1127_260,
g_atype1127_261,
g_atype1127_262,
g_atype1127_263,
g_atype1127_264,
g_atype1127_265,
g_atype1127_266,
g_atype1127_267,
g_atype1127_268,
g_atype1127_269,
g_atype1127_270,
g_atype1127_271,
g_atype1127_272,
g_atype1127_273,
g_atype1127_274,
g_atype1127_275,
g_atype1127_276,
g_atype1127_277,
g_atype1127_278,
g_atype1127_279,
g_atype1127_280,
g_atype1127_281,
g_atype1127_282,
g_atype1127_283,
g_atype1127_284,
g_atype1127_285,
g_atype1127_286,
g_atype1127_287,
g_atype1127_288,
g_atype1127_289,
g_atype1127_290,
g_atype1127_291,
g_atype1127_292,
g_atype1127_293,
g_atype1127_294,
g_atype1127_295,
g_atype1127_296,
g_atype1127_297,
g_atype1127_298,
g_atype1127_299,
g_atype1127_300,
g_atype1127_301,
g_atype1127_302,
g_atype1127_303,
g_atype1127_304,
g_atype1127_305,
g_atype1127_306,
g_atype1127_307,
g_atype1127_308,
g_atype1127_309,
g_atype1127_310,
g_atype1127_311,
g_atype1127_312,
g_atype1127_313,
g_atype1127_314,
g_atype1127_315,
g_atype1127_316,
g_atype1127_317,
g_atype1127_318,
g_atype1127_319,
g_atype1127_320,
g_atype1127_321,
g_atype1127_322,
g_atype1127_323,
g_atype1127_324,
g_atype1127_325,
g_atype1127_326,
g_atype1127_327,
g_atype1127_328,
g_atype1127_329,
g_atype1127_330,
g_atype1127_331,
g_atype1127_332,
g_atype1127_333,
g_atype1127_334,
g_atype1127_335,
g_atype1127_336,
g_atype1127_337,
g_atype1127_338,
g_atype1127_339,
g_atype1127_340,
g_atype1127_341,
g_atype1127_342,
g_atype1127_343,
g_atype1127_344,
g_atype1127_345,
g_atype1127_346,
g_atype1127_347,
g_atype1127_348,
g_atype1127_349,
g_atype1127_350,
g_atype1127_351,
g_atype1127_352,
g_atype1127_353,
g_atype1127_354,
g_atype1127_355,
g_atype1127_356,
g_atype1127_357,
g_atype1127_358,
g_atype1127_359,
g_atype1127_360,
g_atype1127_361,
g_atype1127_362,
g_atype1127_363,
g_atype1127_364,
g_atype1127_365,
g_atype1127_366,
g_atype1127_367,
g_atype1127_368,
g_atype1127_369,
g_atype1127_370,
g_atype1127_371,
g_atype1127_372,
g_atype1127_373,
g_atype1127_374,
g_atype1127_375,
g_atype1127_376,
g_atype1127_377,
g_atype1127_378,
g_atype1127_379,
g_atype1127_380,
g_atype1127_381,
g_atype1127_382,
g_atype1127_383,
g_atype1127_384,
g_atype1127_385,
g_atype1127_386,
g_atype1127_387,
g_atype1127_388,
g_atype1127_389,
g_atype1127_390,
g_atype1127_391,
g_atype1127_392,
g_atype1127_393,
g_atype1127_394,
g_atype1127_395,
g_atype1127_396,
g_atype1127_397,
g_atype1127_398,
g_atype1127_399,
g_atype1127_400,
g_atype1127_401,
g_atype1127_402,
g_atype1127_403,
g_atype1127_404,
g_atype1127_405,
g_atype1127_406,
g_atype1127_407,
g_atype1127_408,
g_atype1127_409,
g_atype1127_410,
g_atype1127_411,
g_atype1127_412,
g_atype1127_413,
g_atype1127_414,
g_atype1127_415,
g_atype1127_416,
g_atype1127_417,
g_atype1127_418,
g_atype1127_419,
g_atype1127_420,
g_atype1127_421,
g_atype1127_422,
g_atype1127_423,
g_atype1127_424,
g_atype1127_425,
g_atype1127_426,
g_atype1127_427,
g_atype1127_428,
g_atype1127_429,
g_atype1127_430,
g_atype1127_431,
g_atype1127_432,
g_atype1127_433,
g_atype1127_434,
g_atype1127_435,
g_atype1127_436,
g_atype1127_437,
g_atype1127_438,
g_atype1127_439,
g_atype1127_440,
g_atype1127_441,
g_atype1127_442,
g_atype1127_443,
g_atype1127_444,
g_atype1127_445,
g_atype1127_446,
g_atype1127_447,
g_atype1127_448,
g_atype1127_449,
g_atype1127_450,
g_atype1127_451,
g_atype1127_452,
g_atype1127_453,
g_atype1127_454,
g_atype1127_455,
g_atype1127_456,
g_atype1127_457,
g_atype1127_458,
g_atype1127_459,
g_atype1127_460,
g_atype1127_461,
g_atype1127_462,
g_atype1127_463,
g_atype1127_464,
g_atype1127_465,
g_atype1127_466,
g_atype1127_467,
g_atype1127_468,
g_atype1127_469,
g_atype1127_470,
g_atype1127_471,
g_atype1127_472,
g_atype1127_473,
g_atype1127_474,
g_atype1127_475,
g_atype1127_476,
g_atype1127_477,
g_atype1127_478,
g_atype1127_479,
g_atype1127_480,
g_atype1127_481,
g_atype1127_482,
g_atype1127_483,
g_atype1127_484,
g_atype1127_485,
g_atype1127_486,
g_atype1127_487,
g_atype1127_488,
g_atype1127_489,
g_atype1127_490,
g_atype1127_491,
g_atype1127_492,
g_atype1127_493,
g_atype1127_494,
g_atype1127_495,
g_atype1127_496,
g_atype1127_497,
g_atype1127_498,
g_atype1127_499,
g_atype1127_500,
g_atype1127_501,
g_atype1127_502,
g_atype1127_503,
g_atype1127_504,
g_atype1127_505,
g_atype1127_506,
g_atype1127_507,
g_atype1127_508,
g_atype1127_509,
g_atype1127_510,
g_atype1127_511,
g_atype1127_512,
g_atype1127_513,
g_atype1127_514,
g_atype1127_515,
g_atype1127_516,
g_atype1127_517,
g_atype1127_518,
g_atype1127_519,
g_atype1127_520,
g_atype1127_521,
g_atype1127_522,
g_atype1127_523,
g_atype1127_524,
g_atype1127_525,
g_atype1127_526,
g_atype1127_527,
g_atype1127_528,
g_atype1127_529,
g_atype1127_530,
g_atype1127_531,
g_atype1127_532,
g_atype1127_533,
g_atype1127_534,
g_atype1127_535,
g_atype1127_536,
g_atype1127_537,
g_atype1127_538,
g_atype1127_539,
g_atype1127_540,
g_atype1127_541,
g_atype1127_542,
g_atype1127_543,
g_atype1127_544,
g_atype1127_545,
g_atype1127_546,
g_atype1127_547,
g_atype1127_548,
g_atype1127_549,
g_atype1127_550,
g_atype1127_551,
g_atype1127_552,
g_atype1127_553,
g_atype1127_554,
g_atype1127_555,
g_atype1127_556,
g_atype1127_557,
g_atype1127_558,
g_atype1127_559,
g_atype1127_560,
g_atype1127_561,
g_atype1127_562,
g_atype1127_563,
g_atype1127_564,
g_atype1127_565,
g_atype1127_566,
g_atype1127_567,
g_atype1127_568,
g_atype1127_569,
g_atype1127_570,
g_atype1127_571,
g_atype1127_572,
g_atype1127_573,
g_atype1127_574,
g_atype1127_575,
g_atype1127_576,
g_atype1127_577,
g_atype1127_578,
g_atype1127_579,
g_atype1127_580,
g_atype1127_581,
g_atype1127_582,
g_atype1127_583,
g_atype1127_584,
g_atype1127_585,
g_atype1127_586,
g_atype1127_587,
g_atype1127_588,
g_atype1127_589,
g_atype1127_590,
g_atype1127_591,
g_atype1127_592,
g_atype1127_593,
g_atype1127_594,
g_atype1127_595,
g_atype1127_596,
g_atype1127_597,
g_atype1127_598,
g_atype1127_599,
g_atype1127_600,
g_atype1127_601,
g_atype1127_602,
g_atype1127_603,
g_atype1127_604,
g_atype1127_605,
g_atype1127_606,
g_atype1127_607,
g_atype1127_608,
g_atype1127_609,
g_atype1127_610,
g_atype1127_611,
g_atype1127_612,
g_atype1127_613,
g_atype1127_614,
g_atype1127_615,
g_atype1127_616,
g_atype1127_617,
g_atype1127_618,
g_atype1127_619,
g_atype1127_620,
g_atype1127_621,
g_atype1127_622,
g_atype1127_623,
g_atype1127_624,
g_atype1127_625,
g_atype1127_626,
g_atype1127_627,
g_atype1127_628,
g_atype1127_629,
g_atype1127_630,
g_atype1127_631,
g_atype1127_632,
g_atype1127_633,
g_atype1127_634,
g_atype1127_635,
g_atype1127_636,
g_atype1127_637,
g_atype1127_638,
g_atype1127_639,
g_atype1127_640,
g_atype1127_641,
g_atype1127_642,
g_atype1127_643,
g_atype1127_644,
g_atype1127_645,
g_atype1127_646,
g_atype1127_647,
g_atype1127_648,
g_atype1127_649,
g_atype1127_650,
g_atype1127_651,
g_atype1127_652,
g_atype1127_653,
g_atype1127_654,
g_atype1127_655,
g_atype1127_656,
g_atype1127_657,
g_atype1127_658,
g_atype1127_659,
g_atype1127_660,
g_atype1127_661,
g_atype1127_662,
g_atype1127_663,
g_atype1127_664,
g_atype1127_665,
g_atype1127_666,
g_atype1127_667,
g_atype1127_668,
g_atype1127_669,
g_atype1127_670,
g_atype1127_671,
g_atype1127_672,
g_atype1127_673,
g_atype1127_674,
g_atype1127_675,
g_atype1127_676,
g_atype1127_677,
g_atype1127_678,
g_atype1127_679,
g_atype1127_680,
g_atype1127_681,
g_atype1127_682,
g_atype1127_683,
g_atype1127_684,
g_atype1127_685,
g_atype1127_686,
g_atype1127_687,
g_atype1127_688,
g_atype1127_689,
g_atype1127_690,
g_atype1127_691,
g_atype1127_692,
g_atype1127_693,
g_atype1127_694,
g_atype1127_695,
g_atype1127_696,
g_atype1127_697,
g_atype1127_698,
g_atype1127_699,
g_atype1127_700,
g_atype1127_701,
g_atype1127_702,
g_atype1127_703,
g_atype1127_704,
};

static const long offsets1127 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
 + @REFACS(27),
 + @REFACS(28),
 + @REFACS(29),
 + @REFACS(30),
 + @REFACS(31),
 + @REFACS(32),
 + @REFACS(33),
 + @REFACS(34),
 + @REFACS(35),
 + @REFACS(36),
 + @REFACS(37),
 + @REFACS(38),
 + @REFACS(39),
 + @REFACS(40),
 + @REFACS(41),
 + @REFACS(42),
 + @REFACS(43),
 + @REFACS(44),
 + @REFACS(45),
 + @REFACS(46),
 + @REFACS(47),
 + @REFACS(48),
 + @REFACS(49),
 + @REFACS(50),
 + @REFACS(51),
 + @REFACS(52),
 + @REFACS(53),
 + @REFACS(54),
 + @REFACS(55),
 + @REFACS(56),
 + @REFACS(57),
 + @REFACS(58),
 + @REFACS(59),
 + @REFACS(60),
 + @REFACS(61),
 + @REFACS(62),
 + @REFACS(63),
 + @REFACS(64),
 + @REFACS(65),
 + @REFACS(66),
 + @REFACS(67),
 + @REFACS(68),
 + @REFACS(69),
 + @REFACS(70),
 + @REFACS(71),
 + @REFACS(72),
 + @REFACS(73),
 + @REFACS(74),
 + @REFACS(75),
 + @REFACS(76),
 + @REFACS(77),
 + @REFACS(78),
 + @REFACS(79),
 + @REFACS(80),
 + @REFACS(81),
 + @REFACS(82),
 + @REFACS(83),
 + @REFACS(84),
 + @REFACS(85),
 + @REFACS(86),
 + @REFACS(87),
 + @REFACS(88),
 + @REFACS(89),
 + @REFACS(90),
 + @REFACS(91),
 + @REFACS(92),
 + @REFACS(93),
 + @REFACS(94),
 + @REFACS(95),
 + @REFACS(96),
 + @REFACS(97),
 + @REFACS(98),
 + @REFACS(99),
 + @REFACS(100),
 + @REFACS(101),
 + @REFACS(102),
 + @REFACS(103),
 + @REFACS(104),
 + @REFACS(105),
 + @REFACS(106),
 + @REFACS(107),
 + @REFACS(108),
 + @REFACS(109),
 + @REFACS(110),
 + @REFACS(111),
 + @REFACS(112),
 + @REFACS(113),
 + @REFACS(114),
 + @REFACS(115),
 + @REFACS(116),
 + @REFACS(117),
 + @REFACS(118),
 + @REFACS(119),
 + @REFACS(120),
 + @REFACS(121),
 + @REFACS(122),
 + @REFACS(123),
 + @REFACS(124),
 + @REFACS(125),
 + @REFACS(126),
 + @REFACS(127),
 + @REFACS(128),
 + @REFACS(129),
 + @REFACS(130),
 + @REFACS(131),
 + @REFACS(132),
 + @REFACS(133),
 + @REFACS(134),
 + @REFACS(135),
 + @REFACS(136),
 + @REFACS(137),
 + @REFACS(138),
 + @REFACS(139),
 + @REFACS(140),
 + @REFACS(141),
 + @REFACS(142),
 + @REFACS(143),
 + @REFACS(144),
 + @REFACS(145),
 + @REFACS(146),
 + @REFACS(147),
 + @REFACS(148),
 + @REFACS(149),
 + @REFACS(150),
 + @REFACS(151),
 + @REFACS(152),
 + @REFACS(153),
 + @REFACS(154),
 + @REFACS(155),
 + @REFACS(156),
 + @REFACS(157),
 + @REFACS(158),
 + @REFACS(159),
 + @REFACS(160),
 + @REFACS(161),
 + @REFACS(162),
 + @REFACS(163),
 + @REFACS(164),
 + @REFACS(165),
 + @REFACS(166),
 + @REFACS(167),
 + @REFACS(168),
 + @REFACS(169),
 + @REFACS(170),
 + @REFACS(171),
 + @REFACS(172),
 + @REFACS(173),
 + @REFACS(174),
 + @REFACS(175),
 + @REFACS(176),
 + @REFACS(177),
 + @REFACS(178),
 + @REFACS(179),
 + @REFACS(180),
 + @REFACS(181),
 + @REFACS(182),
 + @REFACS(183),
 + @REFACS(184),
 + @REFACS(185),
 + @REFACS(186),
 + @REFACS(187),
 + @REFACS(188),
 + @REFACS(189),
 + @REFACS(190),
 + @REFACS(191),
 + @REFACS(192),
 + @REFACS(193),
 + @REFACS(194),
 + @REFACS(195),
 + @REFACS(196),
 + @REFACS(197),
 + @REFACS(198),
 + @REFACS(199),
 + @REFACS(200),
 + @REFACS(201),
 + @REFACS(202),
 + @REFACS(203),
 + @REFACS(204),
 + @REFACS(205),
 + @REFACS(206),
 + @REFACS(207),
 + @REFACS(208),
 + @REFACS(209),
 + @REFACS(210),
 + @REFACS(211),
 + @REFACS(212),
 + @REFACS(213),
 + @REFACS(214),
 + @REFACS(215),
 + @REFACS(216),
 + @REFACS(217),
 + @REFACS(218),
 + @REFACS(219),
 + @REFACS(220),
 + @REFACS(221),
 + @REFACS(222),
 + @REFACS(223),
 + @REFACS(224),
 + @REFACS(225),
 + @REFACS(226),
 + @REFACS(227),
 + @REFACS(228),
 + @REFACS(229),
 + @REFACS(230),
 + @REFACS(231),
 + @REFACS(232),
 + @REFACS(233),
 + @REFACS(234),
 + @REFACS(235),
 + @REFACS(236),
 + @REFACS(237),
 + @REFACS(238),
 + @REFACS(239),
 + @REFACS(240),
 + @REFACS(241),
 + @REFACS(242),
 + @REFACS(243),
 + @REFACS(244),
 + @REFACS(245),
 + @REFACS(246),
 + @REFACS(247),
 + @REFACS(248),
 + @REFACS(249),
 + @REFACS(250),
 + @REFACS(251),
 + @REFACS(252),
 + @REFACS(253),
 + @REFACS(254),
 + @REFACS(255),
 + @REFACS(256),
 + @REFACS(257),
 + @REFACS(258),
 + @REFACS(259),
 + @REFACS(260),
 + @REFACS(261),
 + @REFACS(262),
 + @REFACS(263),
 + @REFACS(264),
 + @REFACS(265),
 + @REFACS(266),
 + @REFACS(267),
 + @REFACS(268),
 + @REFACS(269),
 + @REFACS(270),
 + @REFACS(271),
 + @REFACS(272),
 + @REFACS(273),
 + @REFACS(274),
 + @REFACS(275),
 + @REFACS(276),
 + @REFACS(277),
 + @REFACS(278),
 + @REFACS(279),
 + @REFACS(280),
 + @REFACS(281),
 + @REFACS(282),
 + @REFACS(283),
 + @REFACS(284),
 + @REFACS(285),
 + @REFACS(286),
 + @REFACS(287),
 + @REFACS(288),
 + @REFACS(289),
 + @REFACS(290),
 + @REFACS(291),
 + @REFACS(292),
 + @REFACS(293),
 + @REFACS(294),
 + @REFACS(295),
 + @REFACS(296),
 + @REFACS(297),
 + @REFACS(298),
 + @REFACS(299),
 + @REFACS(300),
 + @REFACS(301),
 + @REFACS(302),
 + @REFACS(303),
 + @REFACS(304),
 + @REFACS(305),
 + @REFACS(306),
 + @REFACS(307),
 + @REFACS(308),
 + @REFACS(309),
 + @REFACS(310),
 + @REFACS(311),
 + @REFACS(312),
 + @REFACS(313),
 + @REFACS(314),
 + @REFACS(315),
 + @REFACS(316),
 + @REFACS(317),
 + @REFACS(318),
 + @REFACS(319),
 + @REFACS(320),
 + @REFACS(321),
 + @REFACS(322),
 + @REFACS(323),
 + @REFACS(324),
 + @REFACS(325),
 + @REFACS(326),
 + @REFACS(327),
 + @REFACS(328),
 + @REFACS(329),
 + @REFACS(330),
 + @REFACS(331),
 + @REFACS(332),
 + @REFACS(333),
 + @REFACS(334),
 + @REFACS(335),
 + @REFACS(336),
 + @REFACS(337),
 + @REFACS(338),
 + @REFACS(339),
 + @REFACS(340),
 + @REFACS(341),
 + @REFACS(342),
 + @REFACS(343),
 + @REFACS(344),
 + @REFACS(345),
 + @REFACS(346),
 + @REFACS(347),
 + @REFACS(348),
 + @REFACS(349),
 + @REFACS(350),
+ @CHROFF(351,0),
+ @CHROFF(351,1),
+ @CHROFF(351,2),
+ @CHROFF(351,3),
+ @CHROFF(351,4),
+ @CHROFF(351,5),
+ @CHROFF(351,6),
+ @CHROFF(351,7),
+ @CHROFF(351,8),
+ @CHROFF(351,9),
+ @CHROFF(351,10),
+ @CHROFF(351,11),
+ @CHROFF(351,12),
+ @CHROFF(351,13),
+ @CHROFF(351,14),
+ @CHROFF(351,15),
+ @CHROFF(351,16),
+ @CHROFF(351,17),
+ @CHROFF(351,18),
+ @CHROFF(351,19),
+ @CHROFF(351,20),
+ @CHROFF(351,21),
+ @CHROFF(351,22),
+ @CHROFF(351,23),
+ @CHROFF(351,24),
+ @CHROFF(351,25),
+ @CHROFF(351,26),
+ @LNGOFF(351,27,0,0),
+ @LNGOFF(351,27,0,1),
+ @LNGOFF(351,27,0,2),
+ @LNGOFF(351,27,0,3),
+ @LNGOFF(351,27,0,4),
+ @LNGOFF(351,27,0,5),
+ @LNGOFF(351,27,0,6),
+ @LNGOFF(351,27,0,7),
+ @LNGOFF(351,27,0,8),
+ @LNGOFF(351,27,0,9),
+ @LNGOFF(351,27,0,10),
+ @LNGOFF(351,27,0,11),
+ @LNGOFF(351,27,0,12),
+ @LNGOFF(351,27,0,13),
+ @LNGOFF(351,27,0,14),
+ @LNGOFF(351,27,0,15),
+ @LNGOFF(351,27,0,16),
+ @LNGOFF(351,27,0,17),
+ @LNGOFF(351,27,0,18),
+ @LNGOFF(351,27,0,19),
+ @LNGOFF(351,27,0,20),
+ @LNGOFF(351,27,0,21),
+ @LNGOFF(351,27,0,22),
+ @LNGOFF(351,27,0,23),
+ @LNGOFF(351,27,0,24),
+ @LNGOFF(351,27,0,25),
+ @LNGOFF(351,27,0,26),
+ @LNGOFF(351,27,0,27),
+ @LNGOFF(351,27,0,28),
+ @LNGOFF(351,27,0,29),
+ @LNGOFF(351,27,0,30),
+ @LNGOFF(351,27,0,31),
+ @LNGOFF(351,27,0,32),
+ @LNGOFF(351,27,0,33),
+ @LNGOFF(351,27,0,34),
+ @LNGOFF(351,27,0,35),
+ @LNGOFF(351,27,0,36),
+ @LNGOFF(351,27,0,37),
+ @LNGOFF(351,27,0,38),
+ @LNGOFF(351,27,0,39),
+ @LNGOFF(351,27,0,40),
+ @LNGOFF(351,27,0,41),
+ @LNGOFF(351,27,0,42),
+ @LNGOFF(351,27,0,43),
+ @LNGOFF(351,27,0,44),
+ @LNGOFF(351,27,0,45),
+ @LNGOFF(351,27,0,46),
+ @LNGOFF(351,27,0,47),
+ @LNGOFF(351,27,0,48),
+ @LNGOFF(351,27,0,49),
+ @LNGOFF(351,27,0,50),
+ @LNGOFF(351,27,0,51),
+ @LNGOFF(351,27,0,52),
+ @LNGOFF(351,27,0,53),
+ @LNGOFF(351,27,0,54),
+ @LNGOFF(351,27,0,55),
+ @LNGOFF(351,27,0,56),
+ @LNGOFF(351,27,0,57),
+ @LNGOFF(351,27,0,58),
+ @LNGOFF(351,27,0,59),
+ @LNGOFF(351,27,0,60),
+ @LNGOFF(351,27,0,61),
+ @LNGOFF(351,27,0,62),
+ @LNGOFF(351,27,0,63),
+ @LNGOFF(351,27,0,64),
+ @LNGOFF(351,27,0,65),
+ @LNGOFF(351,27,0,66),
+ @LNGOFF(351,27,0,67),
+ @LNGOFF(351,27,0,68),
+ @LNGOFF(351,27,0,69),
+ @LNGOFF(351,27,0,70),
+ @LNGOFF(351,27,0,71),
+ @LNGOFF(351,27,0,72),
+ @LNGOFF(351,27,0,73),
+ @LNGOFF(351,27,0,74),
+ @LNGOFF(351,27,0,75),
+ @LNGOFF(351,27,0,76),
+ @LNGOFF(351,27,0,77),
+ @LNGOFF(351,27,0,78),
+ @LNGOFF(351,27,0,79),
+ @LNGOFF(351,27,0,80),
+ @LNGOFF(351,27,0,81),
+ @LNGOFF(351,27,0,82),
+ @LNGOFF(351,27,0,83),
+ @LNGOFF(351,27,0,84),
+ @LNGOFF(351,27,0,85),
+ @LNGOFF(351,27,0,86),
+ @LNGOFF(351,27,0,87),
+ @LNGOFF(351,27,0,88),
+ @LNGOFF(351,27,0,89),
+ @LNGOFF(351,27,0,90),
+ @LNGOFF(351,27,0,91),
+ @LNGOFF(351,27,0,92),
+ @LNGOFF(351,27,0,93),
+ @LNGOFF(351,27,0,94),
+ @LNGOFF(351,27,0,95),
+ @LNGOFF(351,27,0,96),
+ @LNGOFF(351,27,0,97),
+ @LNGOFF(351,27,0,98),
+ @LNGOFF(351,27,0,99),
+ @LNGOFF(351,27,0,100),
+ @LNGOFF(351,27,0,101),
+ @LNGOFF(351,27,0,102),
+ @LNGOFF(351,27,0,103),
+ @LNGOFF(351,27,0,104),
+ @LNGOFF(351,27,0,105),
+ @LNGOFF(351,27,0,106),
+ @LNGOFF(351,27,0,107),
+ @LNGOFF(351,27,0,108),
+ @LNGOFF(351,27,0,109),
+ @LNGOFF(351,27,0,110),
+ @LNGOFF(351,27,0,111),
+ @LNGOFF(351,27,0,112),
+ @LNGOFF(351,27,0,113),
+ @LNGOFF(351,27,0,114),
+ @LNGOFF(351,27,0,115),
+ @LNGOFF(351,27,0,116),
+ @LNGOFF(351,27,0,117),
+ @LNGOFF(351,27,0,118),
+ @LNGOFF(351,27,0,119),
+ @LNGOFF(351,27,0,120),
+ @LNGOFF(351,27,0,121),
+ @LNGOFF(351,27,0,122),
+ @LNGOFF(351,27,0,123),
+ @LNGOFF(351,27,0,124),
+ @LNGOFF(351,27,0,125),
+ @LNGOFF(351,27,0,126),
+ @LNGOFF(351,27,0,127),
+ @LNGOFF(351,27,0,128),
+ @LNGOFF(351,27,0,129),
+ @LNGOFF(351,27,0,130),
+ @LNGOFF(351,27,0,131),
+ @LNGOFF(351,27,0,132),
+ @LNGOFF(351,27,0,133),
+ @LNGOFF(351,27,0,134),
+ @LNGOFF(351,27,0,135),
+ @LNGOFF(351,27,0,136),
+ @LNGOFF(351,27,0,137),
+ @LNGOFF(351,27,0,138),
+ @LNGOFF(351,27,0,139),
+ @LNGOFF(351,27,0,140),
+ @LNGOFF(351,27,0,141),
+ @LNGOFF(351,27,0,142),
+ @LNGOFF(351,27,0,143),
+ @LNGOFF(351,27,0,144),
+ @LNGOFF(351,27,0,145),
+ @LNGOFF(351,27,0,146),
+ @LNGOFF(351,27,0,147),
+ @LNGOFF(351,27,0,148),
+ @LNGOFF(351,27,0,149),
+ @LNGOFF(351,27,0,150),
+ @LNGOFF(351,27,0,151),
+ @LNGOFF(351,27,0,152),
+ @LNGOFF(351,27,0,153),
+ @LNGOFF(351,27,0,154),
+ @LNGOFF(351,27,0,155),
+ @LNGOFF(351,27,0,156),
+ @LNGOFF(351,27,0,157),
+ @LNGOFF(351,27,0,158),
+ @LNGOFF(351,27,0,159),
+ @LNGOFF(351,27,0,160),
+ @LNGOFF(351,27,0,161),
+ @LNGOFF(351,27,0,162),
+ @LNGOFF(351,27,0,163),
+ @LNGOFF(351,27,0,164),
+ @LNGOFF(351,27,0,165),
+ @LNGOFF(351,27,0,166),
+ @LNGOFF(351,27,0,167),
+ @LNGOFF(351,27,0,168),
+ @LNGOFF(351,27,0,169),
+ @LNGOFF(351,27,0,170),
+ @LNGOFF(351,27,0,171),
+ @LNGOFF(351,27,0,172),
+ @LNGOFF(351,27,0,173),
+ @LNGOFF(351,27,0,174),
+ @LNGOFF(351,27,0,175),
+ @LNGOFF(351,27,0,176),
+ @LNGOFF(351,27,0,177),
+ @LNGOFF(351,27,0,178),
+ @LNGOFF(351,27,0,179),
+ @LNGOFF(351,27,0,180),
+ @LNGOFF(351,27,0,181),
+ @LNGOFF(351,27,0,182),
+ @LNGOFF(351,27,0,183),
+ @LNGOFF(351,27,0,184),
+ @LNGOFF(351,27,0,185),
+ @LNGOFF(351,27,0,186),
+ @LNGOFF(351,27,0,187),
+ @LNGOFF(351,27,0,188),
+ @LNGOFF(351,27,0,189),
+ @LNGOFF(351,27,0,190),
+ @LNGOFF(351,27,0,191),
+ @LNGOFF(351,27,0,192),
+ @LNGOFF(351,27,0,193),
+ @LNGOFF(351,27,0,194),
+ @LNGOFF(351,27,0,195),
+ @LNGOFF(351,27,0,196),
+ @LNGOFF(351,27,0,197),
+ @LNGOFF(351,27,0,198),
+ @LNGOFF(351,27,0,199),
+ @LNGOFF(351,27,0,200),
+ @LNGOFF(351,27,0,201),
+ @LNGOFF(351,27,0,202),
+ @LNGOFF(351,27,0,203),
+ @LNGOFF(351,27,0,204),
+ @LNGOFF(351,27,0,205),
+ @LNGOFF(351,27,0,206),
+ @LNGOFF(351,27,0,207),
+ @LNGOFF(351,27,0,208),
+ @LNGOFF(351,27,0,209),
+ @LNGOFF(351,27,0,210),
+ @LNGOFF(351,27,0,211),
+ @LNGOFF(351,27,0,212),
+ @LNGOFF(351,27,0,213),
+ @LNGOFF(351,27,0,214),
+ @LNGOFF(351,27,0,215),
+ @LNGOFF(351,27,0,216),
+ @LNGOFF(351,27,0,217),
+ @LNGOFF(351,27,0,218),
+ @LNGOFF(351,27,0,219),
+ @LNGOFF(351,27,0,220),
+ @LNGOFF(351,27,0,221),
+ @LNGOFF(351,27,0,222),
+ @LNGOFF(351,27,0,223),
+ @LNGOFF(351,27,0,224),
+ @LNGOFF(351,27,0,225),
+ @LNGOFF(351,27,0,226),
+ @LNGOFF(351,27,0,227),
+ @LNGOFF(351,27,0,228),
+ @LNGOFF(351,27,0,229),
+ @LNGOFF(351,27,0,230),
+ @LNGOFF(351,27,0,231),
+ @LNGOFF(351,27,0,232),
+ @LNGOFF(351,27,0,233),
+ @LNGOFF(351,27,0,234),
+ @LNGOFF(351,27,0,235),
+ @LNGOFF(351,27,0,236),
+ @LNGOFF(351,27,0,237),
+ @LNGOFF(351,27,0,238),
+ @LNGOFF(351,27,0,239),
+ @LNGOFF(351,27,0,240),
+ @LNGOFF(351,27,0,241),
+ @LNGOFF(351,27,0,242),
+ @LNGOFF(351,27,0,243),
+ @LNGOFF(351,27,0,244),
+ @LNGOFF(351,27,0,245),
+ @LNGOFF(351,27,0,246),
+ @LNGOFF(351,27,0,247),
+ @LNGOFF(351,27,0,248),
+ @LNGOFF(351,27,0,249),
+ @LNGOFF(351,27,0,250),
+ @LNGOFF(351,27,0,251),
+ @LNGOFF(351,27,0,252),
+ @LNGOFF(351,27,0,253),
+ @LNGOFF(351,27,0,254),
+ @LNGOFF(351,27,0,255),
+ @LNGOFF(351,27,0,256),
+ @LNGOFF(351,27,0,257),
+ @LNGOFF(351,27,0,258),
+ @LNGOFF(351,27,0,259),
+ @LNGOFF(351,27,0,260),
+ @LNGOFF(351,27,0,261),
+ @LNGOFF(351,27,0,262),
+ @LNGOFF(351,27,0,263),
+ @LNGOFF(351,27,0,264),
+ @LNGOFF(351,27,0,265),
+ @LNGOFF(351,27,0,266),
+ @LNGOFF(351,27,0,267),
+ @LNGOFF(351,27,0,268),
+ @LNGOFF(351,27,0,269),
+ @LNGOFF(351,27,0,270),
+ @LNGOFF(351,27,0,271),
+ @LNGOFF(351,27,0,272),
+ @LNGOFF(351,27,0,273),
+ @LNGOFF(351,27,0,274),
+ @LNGOFF(351,27,0,275),
+ @LNGOFF(351,27,0,276),
+ @LNGOFF(351,27,0,277),
+ @LNGOFF(351,27,0,278),
+ @LNGOFF(351,27,0,279),
+ @LNGOFF(351,27,0,280),
+ @LNGOFF(351,27,0,281),
+ @LNGOFF(351,27,0,282),
+ @LNGOFF(351,27,0,283),
+ @LNGOFF(351,27,0,284),
+ @LNGOFF(351,27,0,285),
+ @LNGOFF(351,27,0,286),
+ @LNGOFF(351,27,0,287),
+ @LNGOFF(351,27,0,288),
+ @LNGOFF(351,27,0,289),
+ @LNGOFF(351,27,0,290),
+ @LNGOFF(351,27,0,291),
+ @LNGOFF(351,27,0,292),
+ @LNGOFF(351,27,0,293),
+ @LNGOFF(351,27,0,294),
+ @LNGOFF(351,27,0,295),
+ @LNGOFF(351,27,0,296),
+ @LNGOFF(351,27,0,297),
+ @LNGOFF(351,27,0,298),
+ @LNGOFF(351,27,0,299),
+ @LNGOFF(351,27,0,300),
+ @LNGOFF(351,27,0,301),
+ @LNGOFF(351,27,0,302),
+ @LNGOFF(351,27,0,303),
+ @LNGOFF(351,27,0,304),
+ @LNGOFF(351,27,0,305),
+ @LNGOFF(351,27,0,306),
+ @LNGOFF(351,27,0,307),
+ @LNGOFF(351,27,0,308),
+ @LNGOFF(351,27,0,309),
+ @LNGOFF(351,27,0,310),
+ @LNGOFF(351,27,0,311),
+ @LNGOFF(351,27,0,312),
+ @LNGOFF(351,27,0,313),
+ @LNGOFF(351,27,0,314),
+ @LNGOFF(351,27,0,315),
+ @LNGOFF(351,27,0,316),
+ @LNGOFF(351,27,0,317),
+ @LNGOFF(351,27,0,318),
+ @LNGOFF(351,27,0,319),
+ @LNGOFF(351,27,0,320),
+ @LNGOFF(351,27,0,321),
+ @LNGOFF(351,27,0,322),
+ @LNGOFF(351,27,0,323),
+ @LNGOFF(351,27,0,324),
+ @LNGOFF(351,27,0,325),
+ @LNGOFF(351,27,0,326),
};

extern const char *names1129[];
static const uint32 types1129 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1129 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1129_0 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_1 [] = {0xFF01,1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1129_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1129 [] = {
g_atype1129_0,
g_atype1129_1,
g_atype1129_2,
};

static const long offsets1129 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1130[];
static const uint32 types1130 [] =
{
SK_REF,
};

static const uint16 attr_flags1130 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1130_0 [] = {0xFF01,1201,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1130 [] = {
g_atype1130_0,
};

static const long offsets1130 [] =
{
0,
};

extern const char *names1131[];
static const uint32 types1131 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1131 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1131_0 [] = {0xFF01,1200,0xFF01,1147,0xFFFF};
static const EIF_TYPE_INDEX g_atype1131_1 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1131 [] = {
g_atype1131_0,
g_atype1131_1,
};

static const long offsets1131 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names1132[];
static const uint32 types1132 [] =
{
SK_REF,
};

static const uint16 attr_flags1132 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1132_0 [] = {0xFF01,1278,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1132 [] = {
g_atype1132_0,
};

static const long offsets1132 [] =
{
0,
};

extern const char *names1133[];
static const uint32 types1133 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1133 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1133_0 [] = {1129,0xFFFF};
static const EIF_TYPE_INDEX g_atype1133_1 [] = {1200,0xFF01,1307,0xFFFF};
static const EIF_TYPE_INDEX g_atype1133_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1133 [] = {
g_atype1133_0,
g_atype1133_1,
g_atype1133_2,
};

static const long offsets1133 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1134[];
static const uint32 types1134 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1134 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1134_0 [] = {1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1134_1 [] = {0xFF01,1200,0xFF01,1267,0xFFFF};
static const EIF_TYPE_INDEX g_atype1134_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1134 [] = {
g_atype1134_0,
g_atype1134_1,
g_atype1134_2,
};

static const long offsets1134 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1135[];
static const uint32 types1135 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1135 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1135_0 [] = {1200,0xFF01,1256,0xFFFF};
static const EIF_TYPE_INDEX g_atype1135_1 [] = {1200,0xFF01,1256,0xFFFF};
static const EIF_TYPE_INDEX g_atype1135_2 [] = {793,0xFF01,0xFFF9,2,953,0xFF01,1274,0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1135_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1135_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1135_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1135 [] = {
g_atype1135_0,
g_atype1135_1,
g_atype1135_2,
g_atype1135_3,
g_atype1135_4,
g_atype1135_5,
};

static const long offsets1135 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names1136[];
static const uint32 types1136 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1136 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1136_0 [] = {0xFF01,1197,0xFFFF};
static const EIF_TYPE_INDEX g_atype1136_1 [] = {0xFF01,1206,0xFFFF};
static const EIF_TYPE_INDEX g_atype1136_2 [] = {1200,0xFF01,1307,0xFFFF};
static const EIF_TYPE_INDEX g_atype1136_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1136_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1136_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1136_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1136 [] = {
g_atype1136_0,
g_atype1136_1,
g_atype1136_2,
g_atype1136_3,
g_atype1136_4,
g_atype1136_5,
g_atype1136_6,
};

static const long offsets1136 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
+ @LNGOFF(3,1,0,1),
+ @LNGOFF(3,1,0,2),
};

extern const char *names1137[];
static const uint32 types1137 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1137 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1137_0 [] = {1212,0xFFFF};
static const EIF_TYPE_INDEX g_atype1137_1 [] = {0xFF01,1267,0xFFFF};
static const EIF_TYPE_INDEX g_atype1137_2 [] = {1267,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1137 [] = {
g_atype1137_0,
g_atype1137_1,
g_atype1137_2,
};

static const long offsets1137 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1138[];
static const uint32 types1138 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1138 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1138_0 [] = {0xFF01,1307,0xFFFF};
static const EIF_TYPE_INDEX g_atype1138_1 [] = {0xFF01,1209,0xFFFF};
static const EIF_TYPE_INDEX g_atype1138_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1138_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1138_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1138_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1138_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1138_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1138 [] = {
g_atype1138_0,
g_atype1138_1,
g_atype1138_2,
g_atype1138_3,
g_atype1138_4,
g_atype1138_5,
g_atype1138_6,
g_atype1138_7,
};

static const long offsets1138 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
+ @LNGOFF(2,1,0,4),
};

extern const char *names1139[];
static const uint32 types1139 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1139 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1139_0 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1139_1 [] = {1200,0xFF01,1218,0xFFFF};
static const EIF_TYPE_INDEX g_atype1139_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1139_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1139 [] = {
g_atype1139_0,
g_atype1139_1,
g_atype1139_2,
g_atype1139_3,
};

static const long offsets1139 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names1140[];
static const uint32 types1140 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1140 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1140_0 [] = {0xFF01,1129,0xFFFF};
static const EIF_TYPE_INDEX g_atype1140_1 [] = {1168,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1140 [] = {
g_atype1140_0,
g_atype1140_1,
};

static const long offsets1140 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1141[];
static const uint32 types1141 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1141 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1141_0 [] = {0xFF01,1307,0xFFFF};
static const EIF_TYPE_INDEX g_atype1141_1 [] = {0xFF01,1307,0xFFFF};
static const EIF_TYPE_INDEX g_atype1141_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1141 [] = {
g_atype1141_0,
g_atype1141_1,
g_atype1141_2,
};

static const long offsets1141 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1142[];
static const uint32 types1142 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1142 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1142_0 [] = {0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1142_1 [] = {1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1142_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1142 [] = {
g_atype1142_0,
g_atype1142_1,
g_atype1142_2,
};

static const long offsets1142 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1143[];
static const uint32 types1143 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1143 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1143_0 [] = {0xFF01,1198,0xFFFF};
static const EIF_TYPE_INDEX g_atype1143_1 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1143_2 [] = {1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1143_3 [] = {1185,0xFFFF};
static const EIF_TYPE_INDEX g_atype1143_4 [] = {1186,0xFFFF};
static const EIF_TYPE_INDEX g_atype1143_5 [] = {1184,0xFFFF};
static const EIF_TYPE_INDEX g_atype1143_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1143 [] = {
g_atype1143_0,
g_atype1143_1,
g_atype1143_2,
g_atype1143_3,
g_atype1143_4,
g_atype1143_5,
g_atype1143_6,
};

static const long offsets1143 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @LNGOFF(6,0,0,0),
};

extern const char *names1144[];
static const uint32 types1144 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1144 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1144_0 [] = {1181,0xFFFF};
static const EIF_TYPE_INDEX g_atype1144_1 [] = {1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1144_2 [] = {1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1144_3 [] = {1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1144_4 [] = {1154,0xFFFF};
static const EIF_TYPE_INDEX g_atype1144_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1144_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1144_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1144 [] = {
g_atype1144_0,
g_atype1144_1,
g_atype1144_2,
g_atype1144_3,
g_atype1144_4,
g_atype1144_5,
g_atype1144_6,
g_atype1144_7,
};

static const long offsets1144 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @LNGOFF(5,0,0,0),
+ @LNGOFF(5,0,0,1),
+ @LNGOFF(5,0,0,2),
};

extern const char *names1145[];
static const uint32 types1145 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1145 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1145_0 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1145_1 [] = {0xFF01,1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1145_2 [] = {0xFF01,1218,0xFFFF};
static const EIF_TYPE_INDEX g_atype1145_3 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1145_4 [] = {0xFF01,1218,0xFFFF};
static const EIF_TYPE_INDEX g_atype1145_5 [] = {1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1145_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1145_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1145_8 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1145 [] = {
g_atype1145_0,
g_atype1145_1,
g_atype1145_2,
g_atype1145_3,
g_atype1145_4,
g_atype1145_5,
g_atype1145_6,
g_atype1145_7,
g_atype1145_8,
};

static const long offsets1145 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @LNGOFF(6,1,0,0),
+ @LNGOFF(6,1,0,1),
};

extern const char *names1146[];
static const uint32 types1146 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1146 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1146_0 [] = {0xFF01,1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1146_1 [] = {1129,0xFFFF};
static const EIF_TYPE_INDEX g_atype1146_2 [] = {0xFF01,1200,0xFF01,1306,0xFFFF};
static const EIF_TYPE_INDEX g_atype1146_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1146 [] = {
g_atype1146_0,
g_atype1146_1,
g_atype1146_2,
g_atype1146_3,
};

static const long offsets1146 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
};

extern const char *names1147[];
static const uint32 types1147 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1147 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1147_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1147_1 [] = {0xFF01,1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1147_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1147_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1147 [] = {
g_atype1147_0,
g_atype1147_1,
g_atype1147_2,
g_atype1147_3,
};

static const long offsets1147 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names1148[];
static const uint32 types1148 [] =
{
SK_REF,
};

static const uint16 attr_flags1148 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1148_0 [] = {0xFF01,814,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1148 [] = {
g_atype1148_0,
};

static const long offsets1148 [] =
{
0,
};

extern const char *names1149[];
static const uint32 types1149 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1149 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1149_0 [] = {0xFF01,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1149_1 [] = {0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1149_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1149 [] = {
g_atype1149_0,
g_atype1149_1,
g_atype1149_2,
};

static const long offsets1149 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1150[];
static const uint32 types1150 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1150 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1150_0 [] = {1200,0xFF01,1256,0xFFFF};
static const EIF_TYPE_INDEX g_atype1150_1 [] = {1200,0xFF01,1256,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1150 [] = {
g_atype1150_0,
g_atype1150_1,
};

static const long offsets1150 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1151[];
static const uint32 types1151 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1151 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1151_0 [] = {1200,0xFF01,1256,0xFFFF};
static const EIF_TYPE_INDEX g_atype1151_1 [] = {1200,0xFF01,1256,0xFFFF};
static const EIF_TYPE_INDEX g_atype1151_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1151_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1151 [] = {
g_atype1151_0,
g_atype1151_1,
g_atype1151_2,
g_atype1151_3,
};

static const long offsets1151 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
};

extern const char *names1152[];
static const uint32 types1152 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1152 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1152_0 [] = {1200,0xFF01,1256,0xFFFF};
static const EIF_TYPE_INDEX g_atype1152_1 [] = {1200,0xFF01,1256,0xFFFF};
static const EIF_TYPE_INDEX g_atype1152_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1152_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1152_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1152 [] = {
g_atype1152_0,
g_atype1152_1,
g_atype1152_2,
g_atype1152_3,
g_atype1152_4,
};

static const long offsets1152 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names1153[];
static const uint32 types1153 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1153 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1153_0 [] = {1200,0xFF01,1256,0xFFFF};
static const EIF_TYPE_INDEX g_atype1153_1 [] = {1200,0xFF01,1256,0xFFFF};
static const EIF_TYPE_INDEX g_atype1153_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1153 [] = {
g_atype1153_0,
g_atype1153_1,
g_atype1153_2,
};

static const long offsets1153 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1154[];
static const uint32 types1154 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1154 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1154_0 [] = {1200,0xFF01,1256,0xFFFF};
static const EIF_TYPE_INDEX g_atype1154_1 [] = {1200,0xFF01,1256,0xFFFF};
static const EIF_TYPE_INDEX g_atype1154_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1154_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1154 [] = {
g_atype1154_0,
g_atype1154_1,
g_atype1154_2,
g_atype1154_3,
};

static const long offsets1154 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names1156[];
static const uint32 types1156 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1156 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1156_0 [] = {1130,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_1 [] = {1278,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_2 [] = {1152,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_3 [] = {0xFF01,1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_4 [] = {1150,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_5 [] = {1200,0xFF01,1218,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_6 [] = {1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_7 [] = {793,0xFF01,0xFFF9,2,953,0xFF01,1274,0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_8 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_9 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_10 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_11 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_12 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_13 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_14 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_15 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1156 [] = {
g_atype1156_0,
g_atype1156_1,
g_atype1156_2,
g_atype1156_3,
g_atype1156_4,
g_atype1156_5,
g_atype1156_6,
g_atype1156_7,
g_atype1156_8,
g_atype1156_9,
g_atype1156_10,
g_atype1156_11,
g_atype1156_12,
g_atype1156_13,
g_atype1156_14,
g_atype1156_15,
};

static const long offsets1156 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @CHROFF(8,1),
+ @CHROFF(8,2),
+ @LNGOFF(8,3,0,0),
+ @LNGOFF(8,3,0,1),
+ @LNGOFF(8,3,0,2),
+ @LNGOFF(8,3,0,3),
+ @LNGOFF(8,3,0,4),
};

extern const char *names1157[];
static const uint32 types1157 [] =
{
SK_REF,
};

static const uint16 attr_flags1157 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1157_0 [] = {0xFF01,1267,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1157 [] = {
g_atype1157_0,
};

static const long offsets1157 [] =
{
0,
};

extern const char *names1158[];
static const uint32 types1158 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1158 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1158_0 [] = {0xFF01,1200,0xFF01,1136,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_1 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1158 [] = {
g_atype1158_0,
g_atype1158_1,
g_atype1158_2,
g_atype1158_3,
};

static const long offsets1158 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names1159[];
static const uint32 types1159 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1159 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1159_0 [] = {0xFF01,1200,0xFF01,1136,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1159 [] = {
g_atype1159_0,
g_atype1159_1,
g_atype1159_2,
g_atype1159_3,
};

static const long offsets1159 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names1160[];
static const uint32 types1160 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1160 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1160_0 [] = {0xFF01,1200,0xFF01,1136,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_1 [] = {1200,0xFF01,1218,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1160 [] = {
g_atype1160_0,
g_atype1160_1,
g_atype1160_2,
g_atype1160_3,
};

static const long offsets1160 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names1161[];
static const uint32 types1161 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1161 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1161_0 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_1 [] = {1200,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_2 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_3 [] = {0xFF01,1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1161 [] = {
g_atype1161_0,
g_atype1161_1,
g_atype1161_2,
g_atype1161_3,
g_atype1161_4,
g_atype1161_5,
};

static const long offsets1161 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
};

extern const char *names1163[];
static const uint32 types1163 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1163 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1163_0 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_1 [] = {0xFF01,1164,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1163 [] = {
g_atype1163_0,
g_atype1163_1,
g_atype1163_2,
};

static const long offsets1163 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1165[];
static const uint32 types1165 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_UINT8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1165 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1165_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_1 [] = {0xFF01,1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_2 [] = {1182,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_3 [] = {977,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1165 [] = {
g_atype1165_0,
g_atype1165_1,
g_atype1165_2,
g_atype1165_3,
g_atype1165_4,
g_atype1165_5,
};

static const long offsets1165 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
+ @LNGOFF(3,1,0,1),
};

extern const char *names1166[];
static const uint32 types1166 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_UINT8,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1166 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1166_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_1 [] = {0xFF01,1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_2 [] = {1182,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_3 [] = {977,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1166 [] = {
g_atype1166_0,
g_atype1166_1,
g_atype1166_2,
g_atype1166_3,
g_atype1166_4,
g_atype1166_5,
g_atype1166_6,
};

static const long offsets1166 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
+ @LNGOFF(3,1,0,1),
+ @LNGOFF(3,1,0,2),
};

extern const char *names1167[];
static const uint32 types1167 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_UINT8,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1167 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1167_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_1 [] = {0xFF01,1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_2 [] = {1182,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_3 [] = {977,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1167 [] = {
g_atype1167_0,
g_atype1167_1,
g_atype1167_2,
g_atype1167_3,
g_atype1167_4,
g_atype1167_5,
g_atype1167_6,
};

static const long offsets1167 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
+ @LNGOFF(3,1,0,1),
+ @LNGOFF(3,1,0,2),
};

extern const char *names1168[];
static const uint32 types1168 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_UINT8,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1168 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1168_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_1 [] = {0xFF01,1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_2 [] = {1182,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_3 [] = {977,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1168 [] = {
g_atype1168_0,
g_atype1168_1,
g_atype1168_2,
g_atype1168_3,
g_atype1168_4,
g_atype1168_5,
g_atype1168_6,
};

static const long offsets1168 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
+ @LNGOFF(3,1,0,1),
+ @LNGOFF(3,1,0,2),
};

extern const char *names1170[];
static const uint32 types1170 [] =
{
SK_INT32,
};

static const uint16 attr_flags1170 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1170_0 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1170 [] = {
g_atype1170_0,
};

static const long offsets1170 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1171[];
static const uint32 types1171 [] =
{
SK_REF,
};

static const uint16 attr_flags1171 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1171_0 [] = {0xFF01,1200,0xFF01,1307,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1171 [] = {
g_atype1171_0,
};

static const long offsets1171 [] =
{
0,
};

extern const char *names1173[];
static const uint32 types1173 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1173 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1173_0 [] = {1278,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_1 [] = {0xFF01,1131,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1173 [] = {
g_atype1173_0,
g_atype1173_1,
g_atype1173_2,
g_atype1173_3,
g_atype1173_4,
};

static const long offsets1173 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names1174[];
static const uint32 types1174 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1174 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1174_0 [] = {1278,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_1 [] = {0xFF01,1131,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_2 [] = {1306,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1174 [] = {
g_atype1174_0,
g_atype1174_1,
g_atype1174_2,
g_atype1174_3,
g_atype1174_4,
g_atype1174_5,
};

static const long offsets1174 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names1175[];
static const uint32 types1175 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1175 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1175_0 [] = {1200,0xFF01,1218,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_1 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1175 [] = {
g_atype1175_0,
g_atype1175_1,
};

static const long offsets1175 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names1176[];
static const uint32 types1176 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1176 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1176_0 [] = {1200,0xFF01,1218,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_1 [] = {1180,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1176 [] = {
g_atype1176_0,
g_atype1176_1,
g_atype1176_2,
g_atype1176_3,
};

static const long offsets1176 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names1177[];
static const uint32 types1177 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1177 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1177_0 [] = {1200,0xFF01,1218,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1177 [] = {
g_atype1177_0,
g_atype1177_1,
g_atype1177_2,
};

static const long offsets1177 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names1178[];
static const uint32 types1178 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1178 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1178_0 [] = {1200,0xFF01,1218,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1178 [] = {
g_atype1178_0,
g_atype1178_1,
g_atype1178_2,
};

static const long offsets1178 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names1179[];
static const uint32 types1179 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1179 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1179_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1179_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1179_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1179 [] = {
g_atype1179_0,
g_atype1179_1,
g_atype1179_2,
};

static const long offsets1179 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names1180[];
static const uint32 types1180 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1180 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1180_0 [] = {0xFF01,1200,0xFF01,1249,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1180 [] = {
g_atype1180_0,
g_atype1180_1,
g_atype1180_2,
};

static const long offsets1180 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names1181[];
static const uint32 types1181 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1181 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1181_0 [] = {0xFF01,1200,0xFF01,1278,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1181 [] = {
g_atype1181_0,
g_atype1181_1,
g_atype1181_2,
};

static const long offsets1181 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names1182[];
static const uint32 types1182 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1182 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1182_0 [] = {0xFF01,1200,0xFF01,1148,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1182 [] = {
g_atype1182_0,
g_atype1182_1,
g_atype1182_2,
};

static const long offsets1182 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names1183[];
static const uint32 types1183 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1183 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1183_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_1 [] = {0xFF01,1200,0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1183 [] = {
g_atype1183_0,
g_atype1183_1,
g_atype1183_2,
g_atype1183_3,
g_atype1183_4,
g_atype1183_5,
};

static const long offsets1183 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names1184[];
static const uint32 types1184 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1184 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1184_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1184_1 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1184 [] = {
g_atype1184_0,
g_atype1184_1,
};

static const long offsets1184 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names1185[];
static const uint32 types1185 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1185 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1185_0 [] = {0xFF01,1200,0xFF01,1307,0xFFFF};
static const EIF_TYPE_INDEX g_atype1185_1 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1185 [] = {
g_atype1185_0,
g_atype1185_1,
};

static const long offsets1185 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names1186[];
static const uint32 types1186 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1186 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1186_0 [] = {0xFF01,1200,0xFF01,1307,0xFFFF};
static const EIF_TYPE_INDEX g_atype1186_1 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1186 [] = {
g_atype1186_0,
g_atype1186_1,
};

static const long offsets1186 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names1187[];
static const uint32 types1187 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1187 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1187_0 [] = {0xFF01,1200,0xFF01,1307,0xFFFF};
static const EIF_TYPE_INDEX g_atype1187_1 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1187 [] = {
g_atype1187_0,
g_atype1187_1,
};

static const long offsets1187 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names1188[];
static const uint32 types1188 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1188 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1188_0 [] = {0xFF01,1200,0xFF01,1139,0xFFFF};
static const EIF_TYPE_INDEX g_atype1188_1 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1188 [] = {
g_atype1188_0,
g_atype1188_1,
};

static const long offsets1188 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names1189[];
static const uint32 types1189 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1189 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1189_0 [] = {0xFF01,1200,0xFF01,1140,0xFFFF};
static const EIF_TYPE_INDEX g_atype1189_1 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1189 [] = {
g_atype1189_0,
g_atype1189_1,
};

static const long offsets1189 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names1191[];
static const uint32 types1191 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1191 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1191_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1191_1 [] = {0xFF01,1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1191_2 [] = {1198,0xFFFF};
static const EIF_TYPE_INDEX g_atype1191_3 [] = {1182,0xFFFF};
static const EIF_TYPE_INDEX g_atype1191_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1191_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1191 [] = {
g_atype1191_0,
g_atype1191_1,
g_atype1191_2,
g_atype1191_3,
g_atype1191_4,
g_atype1191_5,
};

static const long offsets1191 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
};

extern const char *names1192[];
static const uint32 types1192 [] =
{
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1192 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1192_0 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1192_10 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1192 [] = {
g_atype1192_0,
g_atype1192_1,
g_atype1192_2,
g_atype1192_3,
g_atype1192_4,
g_atype1192_5,
g_atype1192_6,
g_atype1192_7,
g_atype1192_8,
g_atype1192_9,
g_atype1192_10,
};

static const long offsets1192 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
+ @CHROFF(0,2),
+ @CHROFF(0,3),
+ @CHROFF(0,4),
+ @CHROFF(0,5),
+ @LNGOFF(0,6,0,0),
+ @LNGOFF(0,6,0,1),
+ @LNGOFF(0,6,0,2),
+ @LNGOFF(0,6,0,3),
+ @LNGOFF(0,6,0,4),
};

extern const char *names1193[];
static const uint32 types1193 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1193 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1193_0 [] = {0xFF01,1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_10 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_11 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1193_12 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1193 [] = {
g_atype1193_0,
g_atype1193_1,
g_atype1193_2,
g_atype1193_3,
g_atype1193_4,
g_atype1193_5,
g_atype1193_6,
g_atype1193_7,
g_atype1193_8,
g_atype1193_9,
g_atype1193_10,
g_atype1193_11,
g_atype1193_12,
};

static const long offsets1193 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @CHROFF(1,3),
+ @CHROFF(1,4),
+ @CHROFF(1,5),
+ @LNGOFF(1,6,0,0),
+ @LNGOFF(1,6,0,1),
+ @LNGOFF(1,6,0,2),
+ @LNGOFF(1,6,0,3),
+ @LNGOFF(1,6,0,4),
+ @LNGOFF(1,6,0,5),
};

extern const char *names1194[];
static const uint32 types1194 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1194 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1194_0 [] = {0xFF01,1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1194_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1194_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1194_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1194_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1194_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1194_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1194_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1194_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1194_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1194_10 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1194_11 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1194_12 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1194 [] = {
g_atype1194_0,
g_atype1194_1,
g_atype1194_2,
g_atype1194_3,
g_atype1194_4,
g_atype1194_5,
g_atype1194_6,
g_atype1194_7,
g_atype1194_8,
g_atype1194_9,
g_atype1194_10,
g_atype1194_11,
g_atype1194_12,
};

static const long offsets1194 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @CHROFF(1,3),
+ @CHROFF(1,4),
+ @CHROFF(1,5),
+ @LNGOFF(1,6,0,0),
+ @LNGOFF(1,6,0,1),
+ @LNGOFF(1,6,0,2),
+ @LNGOFF(1,6,0,3),
+ @LNGOFF(1,6,0,4),
+ @LNGOFF(1,6,0,5),
};

extern const char *names1195[];
static const uint32 types1195 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1195 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1195_0 [] = {0xFF01,1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1195_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1195_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1195_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1195_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1195_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1195_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1195_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1195_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1195_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1195_10 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1195_11 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1195 [] = {
g_atype1195_0,
g_atype1195_1,
g_atype1195_2,
g_atype1195_3,
g_atype1195_4,
g_atype1195_5,
g_atype1195_6,
g_atype1195_7,
g_atype1195_8,
g_atype1195_9,
g_atype1195_10,
g_atype1195_11,
};

static const long offsets1195 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @CHROFF(1,3),
+ @CHROFF(1,4),
+ @CHROFF(1,5),
+ @LNGOFF(1,6,0,0),
+ @LNGOFF(1,6,0,1),
+ @LNGOFF(1,6,0,2),
+ @LNGOFF(1,6,0,3),
+ @LNGOFF(1,6,0,4),
};

extern const char *names1196[];
static const uint32 types1196 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1196 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1196_0 [] = {0xFF01,1181,0xFFFF};
static const EIF_TYPE_INDEX g_atype1196_1 [] = {0xFF01,1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1196_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1196_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1196_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1196_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1196_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1196_7 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1196_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1196_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1196_10 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1196_11 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1196_12 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1196 [] = {
g_atype1196_0,
g_atype1196_1,
g_atype1196_2,
g_atype1196_3,
g_atype1196_4,
g_atype1196_5,
g_atype1196_6,
g_atype1196_7,
g_atype1196_8,
g_atype1196_9,
g_atype1196_10,
g_atype1196_11,
g_atype1196_12,
};

static const long offsets1196 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @CHROFF(2,4),
+ @CHROFF(2,5),
+ @LNGOFF(2,6,0,0),
+ @LNGOFF(2,6,0,1),
+ @LNGOFF(2,6,0,2),
+ @LNGOFF(2,6,0,3),
+ @LNGOFF(2,6,0,4),
};

extern const char *names1197[];
static const uint32 types1197 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1197 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1197_0 [] = {0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1197_1 [] = {0xFF01,1200,0xFF01,1146,0xFFFF};
static const EIF_TYPE_INDEX g_atype1197_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1197_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1197_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1197_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1197_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1197_7 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1197_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1197_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1197_10 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1197_11 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1197_12 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1197_13 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1197 [] = {
g_atype1197_0,
g_atype1197_1,
g_atype1197_2,
g_atype1197_3,
g_atype1197_4,
g_atype1197_5,
g_atype1197_6,
g_atype1197_7,
g_atype1197_8,
g_atype1197_9,
g_atype1197_10,
g_atype1197_11,
g_atype1197_12,
g_atype1197_13,
};

static const long offsets1197 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @CHROFF(2,4),
+ @CHROFF(2,5),
+ @LNGOFF(2,6,0,0),
+ @LNGOFF(2,6,0,1),
+ @LNGOFF(2,6,0,2),
+ @LNGOFF(2,6,0,3),
+ @LNGOFF(2,6,0,4),
+ @LNGOFF(2,6,0,5),
};

extern const char *names1198[];
static const uint32 types1198 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1198 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1198_0 [] = {0xFF01,1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1198_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1198_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1198_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1198_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1198_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1198_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1198_7 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1198_8 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1198_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1198_10 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1198_11 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1198_12 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1198_13 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1198_14 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1198_15 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1198 [] = {
g_atype1198_0,
g_atype1198_1,
g_atype1198_2,
g_atype1198_3,
g_atype1198_4,
g_atype1198_5,
g_atype1198_6,
g_atype1198_7,
g_atype1198_8,
g_atype1198_9,
g_atype1198_10,
g_atype1198_11,
g_atype1198_12,
g_atype1198_13,
g_atype1198_14,
g_atype1198_15,
};

static const long offsets1198 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @CHROFF(1,3),
+ @CHROFF(1,4),
+ @CHROFF(1,5),
+ @CHROFF(1,6),
+ @CHROFF(1,7),
+ @LNGOFF(1,8,0,0),
+ @LNGOFF(1,8,0,1),
+ @LNGOFF(1,8,0,2),
+ @LNGOFF(1,8,0,3),
+ @LNGOFF(1,8,0,4),
+ @LNGOFF(1,8,0,5),
+ @LNGOFF(1,8,0,6),
};

extern const char *names1199[];
static const uint32 types1199 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1199 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1199_0 [] = {0xFF01,1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_7 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_10 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_11 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_12 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1199_13 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1199 [] = {
g_atype1199_0,
g_atype1199_1,
g_atype1199_2,
g_atype1199_3,
g_atype1199_4,
g_atype1199_5,
g_atype1199_6,
g_atype1199_7,
g_atype1199_8,
g_atype1199_9,
g_atype1199_10,
g_atype1199_11,
g_atype1199_12,
g_atype1199_13,
};

static const long offsets1199 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @CHROFF(1,3),
+ @CHROFF(1,4),
+ @CHROFF(1,5),
+ @CHROFF(1,6),
+ @LNGOFF(1,7,0,0),
+ @LNGOFF(1,7,0,1),
+ @LNGOFF(1,7,0,2),
+ @LNGOFF(1,7,0,3),
+ @LNGOFF(1,7,0,4),
+ @LNGOFF(1,7,0,5),
};

extern const char *names1200[];
static const uint32 types1200 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1200 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1200_0 [] = {0xFF01,1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_1 [] = {0xFF01,1209,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_6 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_7 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_8 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_10 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_11 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_12 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_13 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1200_14 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1200 [] = {
g_atype1200_0,
g_atype1200_1,
g_atype1200_2,
g_atype1200_3,
g_atype1200_4,
g_atype1200_5,
g_atype1200_6,
g_atype1200_7,
g_atype1200_8,
g_atype1200_9,
g_atype1200_10,
g_atype1200_11,
g_atype1200_12,
g_atype1200_13,
g_atype1200_14,
};

static const long offsets1200 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @CHROFF(2,4),
+ @CHROFF(2,5),
+ @CHROFF(2,6),
+ @LNGOFF(2,7,0,0),
+ @LNGOFF(2,7,0,1),
+ @LNGOFF(2,7,0,2),
+ @LNGOFF(2,7,0,3),
+ @LNGOFF(2,7,0,4),
+ @LNGOFF(2,7,0,5),
};

extern const char *names1201[];
static const uint32 types1201 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1201 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1201_0 [] = {0xFF01,839,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_1 [] = {813,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1201 [] = {
g_atype1201_0,
g_atype1201_1,
g_atype1201_2,
g_atype1201_3,
g_atype1201_4,
};

static const long offsets1201 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names1202[];
static const uint32 types1202 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1202 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1202_0 [] = {0xFF01,839,0xFF01,1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_1 [] = {813,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1202_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1202 [] = {
g_atype1202_0,
g_atype1202_1,
g_atype1202_2,
g_atype1202_3,
g_atype1202_4,
g_atype1202_5,
g_atype1202_6,
};

static const long offsets1202 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
};

extern const char *names1203[];
static const uint32 types1203 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1203 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1203_0 [] = {0xFF01,839,0xFF01,1133,0xFFFF};
static const EIF_TYPE_INDEX g_atype1203_1 [] = {813,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1203_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1203_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1203_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1203_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1203_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1203 [] = {
g_atype1203_0,
g_atype1203_1,
g_atype1203_2,
g_atype1203_3,
g_atype1203_4,
g_atype1203_5,
g_atype1203_6,
};

static const long offsets1203 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
};

extern const char *names1204[];
static const uint32 types1204 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1204 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1204_0 [] = {0xFF01,839,0xFF01,1147,0xFFFF};
static const EIF_TYPE_INDEX g_atype1204_1 [] = {813,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1204_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1204_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1204_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1204_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1204_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1204 [] = {
g_atype1204_0,
g_atype1204_1,
g_atype1204_2,
g_atype1204_3,
g_atype1204_4,
g_atype1204_5,
g_atype1204_6,
};

static const long offsets1204 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
};

extern const char *names1205[];
static const uint32 types1205 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1205 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1205_0 [] = {0xFF01,839,0xFF01,1148,0xFFFF};
static const EIF_TYPE_INDEX g_atype1205_1 [] = {813,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1205_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1205_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1205_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1205_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1205_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1205 [] = {
g_atype1205_0,
g_atype1205_1,
g_atype1205_2,
g_atype1205_3,
g_atype1205_4,
g_atype1205_5,
g_atype1205_6,
};

static const long offsets1205 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
};

extern const char *names1206[];
static const uint32 types1206 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1206 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1206_0 [] = {0xFF01,839,0xFF01,1137,0xFFFF};
static const EIF_TYPE_INDEX g_atype1206_1 [] = {813,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1206_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1206_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1206_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1206_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1206 [] = {
g_atype1206_0,
g_atype1206_1,
g_atype1206_2,
g_atype1206_3,
g_atype1206_4,
g_atype1206_5,
};

static const long offsets1206 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names1207[];
static const uint32 types1207 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1207 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1207_0 [] = {0xFF01,839,0xFF01,1141,0xFFFF};
static const EIF_TYPE_INDEX g_atype1207_1 [] = {813,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1207_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1207_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1207_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1207 [] = {
g_atype1207_0,
g_atype1207_1,
g_atype1207_2,
g_atype1207_3,
g_atype1207_4,
};

static const long offsets1207 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names1208[];
static const uint32 types1208 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1208 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1208_0 [] = {0xFF01,839,0xFF01,1142,0xFFFF};
static const EIF_TYPE_INDEX g_atype1208_1 [] = {813,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1208_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1208_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1208_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1208_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1208_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1208_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1208_8 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1208 [] = {
g_atype1208_0,
g_atype1208_1,
g_atype1208_2,
g_atype1208_3,
g_atype1208_4,
g_atype1208_5,
g_atype1208_6,
g_atype1208_7,
g_atype1208_8,
};

static const long offsets1208 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
+ @LNGOFF(2,1,0,4),
+ @LNGOFF(2,1,0,5),
};

extern const char *names1209[];
static const uint32 types1209 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1209 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1209_0 [] = {0xFF01,839,0xFF01,1135,0xFFFF};
static const EIF_TYPE_INDEX g_atype1209_1 [] = {813,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1209_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1209_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1209_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1209_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1209_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1209 [] = {
g_atype1209_0,
g_atype1209_1,
g_atype1209_2,
g_atype1209_3,
g_atype1209_4,
g_atype1209_5,
g_atype1209_6,
};

static const long offsets1209 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
};

extern const char *names1210[];
static const uint32 types1210 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1210 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1210_0 [] = {0xFF01,839,0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1210_1 [] = {813,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1210_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1210_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1210_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1210_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1210_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1210 [] = {
g_atype1210_0,
g_atype1210_1,
g_atype1210_2,
g_atype1210_3,
g_atype1210_4,
g_atype1210_5,
g_atype1210_6,
};

static const long offsets1210 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
};

extern const char *names1211[];
static const uint32 types1211 [] =
{
SK_UINT16,
SK_UINT16,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1211 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1211_0 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1211_1 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1211_2 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1211_3 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1211_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1211_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1211_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1211 [] = {
g_atype1211_0,
g_atype1211_1,
g_atype1211_2,
g_atype1211_3,
g_atype1211_4,
g_atype1211_5,
g_atype1211_6,
};

static const long offsets1211 [] =
{
+ @I16OFF(0,0,0),
+ @I16OFF(0,0,1),
+ @I16OFF(0,0,2),
+ @LNGOFF(0,0,3,0),
+ @LNGOFF(0,0,3,1),
+ @LNGOFF(0,0,3,2),
+ @LNGOFF(0,0,3,3),
};

extern const char *names1212[];
static const uint32 types1212 [] =
{
SK_REF,
SK_UINT16,
SK_UINT16,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1212 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1212_0 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1212_1 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1212_2 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1212_3 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1212_4 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1212_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1212_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1212_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1212 [] = {
g_atype1212_0,
g_atype1212_1,
g_atype1212_2,
g_atype1212_3,
g_atype1212_4,
g_atype1212_5,
g_atype1212_6,
g_atype1212_7,
};

static const long offsets1212 [] =
{
0,
+ @I16OFF(1,0,0),
+ @I16OFF(1,0,1),
+ @I16OFF(1,0,2),
+ @LNGOFF(1,0,3,0),
+ @LNGOFF(1,0,3,1),
+ @LNGOFF(1,0,3,2),
+ @LNGOFF(1,0,3,3),
};

extern const char *names1213[];
static const uint32 types1213 [] =
{
SK_UINT16,
SK_UINT16,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1213 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1213_0 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1213_1 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1213_2 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1213_3 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1213_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1213_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1213_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1213_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1213 [] = {
g_atype1213_0,
g_atype1213_1,
g_atype1213_2,
g_atype1213_3,
g_atype1213_4,
g_atype1213_5,
g_atype1213_6,
g_atype1213_7,
};

static const long offsets1213 [] =
{
+ @I16OFF(0,0,0),
+ @I16OFF(0,0,1),
+ @I16OFF(0,0,2),
+ @LNGOFF(0,0,3,0),
+ @LNGOFF(0,0,3,1),
+ @LNGOFF(0,0,3,2),
+ @LNGOFF(0,0,3,3),
+ @LNGOFF(0,0,3,4),
};

extern const char *names1214[];
static const uint32 types1214 [] =
{
SK_REF,
SK_UINT16,
SK_UINT16,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1214 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1214_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1214_1 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1214_2 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1214_3 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1214_4 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1214_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1214_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1214_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1214 [] = {
g_atype1214_0,
g_atype1214_1,
g_atype1214_2,
g_atype1214_3,
g_atype1214_4,
g_atype1214_5,
g_atype1214_6,
g_atype1214_7,
};

static const long offsets1214 [] =
{
0,
+ @I16OFF(1,0,0),
+ @I16OFF(1,0,1),
+ @I16OFF(1,0,2),
+ @LNGOFF(1,0,3,0),
+ @LNGOFF(1,0,3,1),
+ @LNGOFF(1,0,3,2),
+ @LNGOFF(1,0,3,3),
};

extern const char *names1215[];
static const uint32 types1215 [] =
{
SK_REF,
SK_UINT16,
SK_UINT16,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1215 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1215_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1215_1 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1215_2 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1215_3 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1215_4 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1215_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1215_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1215_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1215_8 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1215 [] = {
g_atype1215_0,
g_atype1215_1,
g_atype1215_2,
g_atype1215_3,
g_atype1215_4,
g_atype1215_5,
g_atype1215_6,
g_atype1215_7,
g_atype1215_8,
};

static const long offsets1215 [] =
{
0,
+ @I16OFF(1,0,0),
+ @I16OFF(1,0,1),
+ @I16OFF(1,0,2),
+ @LNGOFF(1,0,3,0),
+ @LNGOFF(1,0,3,1),
+ @LNGOFF(1,0,3,2),
+ @LNGOFF(1,0,3,3),
+ @LNGOFF(1,0,3,4),
};

extern const char *names1216[];
static const uint32 types1216 [] =
{
SK_UINT16,
SK_UINT16,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1216 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1216_0 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1216_1 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1216_2 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1216_3 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1216_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1216_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1216_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1216_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1216 [] = {
g_atype1216_0,
g_atype1216_1,
g_atype1216_2,
g_atype1216_3,
g_atype1216_4,
g_atype1216_5,
g_atype1216_6,
g_atype1216_7,
};

static const long offsets1216 [] =
{
+ @I16OFF(0,0,0),
+ @I16OFF(0,0,1),
+ @I16OFF(0,0,2),
+ @LNGOFF(0,0,3,0),
+ @LNGOFF(0,0,3,1),
+ @LNGOFF(0,0,3,2),
+ @LNGOFF(0,0,3,3),
+ @LNGOFF(0,0,3,4),
};

extern const char *names1217[];
static const uint32 types1217 [] =
{
SK_UINT16,
SK_UINT16,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1217 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1217_0 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1217_1 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1217_2 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1217_3 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1217_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1217_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1217_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1217_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1217 [] = {
g_atype1217_0,
g_atype1217_1,
g_atype1217_2,
g_atype1217_3,
g_atype1217_4,
g_atype1217_5,
g_atype1217_6,
g_atype1217_7,
};

static const long offsets1217 [] =
{
+ @I16OFF(0,0,0),
+ @I16OFF(0,0,1),
+ @I16OFF(0,0,2),
+ @LNGOFF(0,0,3,0),
+ @LNGOFF(0,0,3,1),
+ @LNGOFF(0,0,3,2),
+ @LNGOFF(0,0,3,3),
+ @LNGOFF(0,0,3,4),
};

extern const char *names1218[];
static const uint32 types1218 [] =
{
SK_REF,
SK_UINT16,
SK_UINT16,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1218 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1218_0 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1218_1 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1218_2 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1218_3 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1218_4 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1218_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1218_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1218_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1218_8 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1218 [] = {
g_atype1218_0,
g_atype1218_1,
g_atype1218_2,
g_atype1218_3,
g_atype1218_4,
g_atype1218_5,
g_atype1218_6,
g_atype1218_7,
g_atype1218_8,
};

static const long offsets1218 [] =
{
0,
+ @I16OFF(1,0,0),
+ @I16OFF(1,0,1),
+ @I16OFF(1,0,2),
+ @LNGOFF(1,0,3,0),
+ @LNGOFF(1,0,3,1),
+ @LNGOFF(1,0,3,2),
+ @LNGOFF(1,0,3,3),
+ @LNGOFF(1,0,3,4),
};

extern const char *names1219[];
static const uint32 types1219 [] =
{
SK_REF,
};

static const uint16 attr_flags1219 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1219_0 [] = {1211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1219 [] = {
g_atype1219_0,
};

static const long offsets1219 [] =
{
0,
};

extern const char *names1220[];
static const uint32 types1220 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1220 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1220_0 [] = {1211,0xFFFF};
static const EIF_TYPE_INDEX g_atype1220_1 [] = {1212,0xFFFF};
static const EIF_TYPE_INDEX g_atype1220_2 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1220_3 [] = {0xFF01,1232,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1220 [] = {
g_atype1220_0,
g_atype1220_1,
g_atype1220_2,
g_atype1220_3,
};

static const long offsets1220 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1221[];
static const uint32 types1221 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1221 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1221_0 [] = {1211,0xFFFF};
static const EIF_TYPE_INDEX g_atype1221_1 [] = {0xFF01,1161,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1221 [] = {
g_atype1221_0,
g_atype1221_1,
};

static const long offsets1221 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1222[];
static const uint32 types1222 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1222 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1222_0 [] = {1211,0xFFFF};
static const EIF_TYPE_INDEX g_atype1222_1 [] = {0xFF01,1200,0xFF01,1128,0xFFFF};
static const EIF_TYPE_INDEX g_atype1222_2 [] = {1200,0xFF01,1218,0xFFFF};
static const EIF_TYPE_INDEX g_atype1222_3 [] = {0xFF01,1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1222_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1222_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1222 [] = {
g_atype1222_0,
g_atype1222_1,
g_atype1222_2,
g_atype1222_3,
g_atype1222_4,
g_atype1222_5,
};

static const long offsets1222 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
};

extern const char *names1223[];
static const uint32 types1223 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1223 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1223_0 [] = {1211,0xFFFF};
static const EIF_TYPE_INDEX g_atype1223_1 [] = {1200,0xFF01,1256,0xFFFF};
static const EIF_TYPE_INDEX g_atype1223_2 [] = {1200,0xFF01,1218,0xFFFF};
static const EIF_TYPE_INDEX g_atype1223_3 [] = {1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1223_4 [] = {1200,0xFF01,1256,0xFFFF};
static const EIF_TYPE_INDEX g_atype1223_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1223_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1223 [] = {
g_atype1223_0,
g_atype1223_1,
g_atype1223_2,
g_atype1223_3,
g_atype1223_4,
g_atype1223_5,
g_atype1223_6,
};

static const long offsets1223 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @LNGOFF(5,0,0,0),
+ @LNGOFF(5,0,0,1),
};

extern const char *names1224[];
static const uint32 types1224 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1224 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1224_0 [] = {1211,0xFFFF};
static const EIF_TYPE_INDEX g_atype1224_1 [] = {1200,0xFF01,1256,0xFFFF};
static const EIF_TYPE_INDEX g_atype1224_2 [] = {0xFF01,1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1224_3 [] = {1200,0xFF01,1256,0xFFFF};
static const EIF_TYPE_INDEX g_atype1224_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1224 [] = {
g_atype1224_0,
g_atype1224_1,
g_atype1224_2,
g_atype1224_3,
g_atype1224_4,
};

static const long offsets1224 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
};

extern const char *names1225[];
static const uint32 types1225 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1225 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1225_0 [] = {1211,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_1 [] = {1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_2 [] = {0xFF01,1163,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_3 [] = {1165,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1225 [] = {
g_atype1225_0,
g_atype1225_1,
g_atype1225_2,
g_atype1225_3,
g_atype1225_4,
g_atype1225_5,
};

static const long offsets1225 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @LNGOFF(4,1,0,0),
};

extern const char *names1226[];
static const uint32 types1226 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1226 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1226_0 [] = {1211,0xFFFF};
static const EIF_TYPE_INDEX g_atype1226_1 [] = {1200,0xFF01,1218,0xFFFF};
static const EIF_TYPE_INDEX g_atype1226_2 [] = {0xFF01,1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1226_3 [] = {1180,0xFFFF};
static const EIF_TYPE_INDEX g_atype1226_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1226 [] = {
g_atype1226_0,
g_atype1226_1,
g_atype1226_2,
g_atype1226_3,
g_atype1226_4,
};

static const long offsets1226 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
};

extern const char *names1227[];
static const uint32 types1227 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1227 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1227_0 [] = {1211,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_1 [] = {1200,0xFF01,1256,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_2 [] = {1144,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_3 [] = {1200,0xFF01,1218,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_4 [] = {1200,0xFF01,1256,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_5 [] = {1257,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_6 [] = {1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_7 [] = {1200,0xFF01,1218,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_8 [] = {1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_9 [] = {1212,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_10 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_11 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_12 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_13 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1227 [] = {
g_atype1227_0,
g_atype1227_1,
g_atype1227_2,
g_atype1227_3,
g_atype1227_4,
g_atype1227_5,
g_atype1227_6,
g_atype1227_7,
g_atype1227_8,
g_atype1227_9,
g_atype1227_10,
g_atype1227_11,
g_atype1227_12,
g_atype1227_13,
};

static const long offsets1227 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @LNGOFF(10,0,0,0),
+ @LNGOFF(10,0,0,1),
+ @LNGOFF(10,0,0,2),
+ @LNGOFF(10,0,0,3),
};

extern const char *names1228[];
static const uint32 types1228 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1228 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1228_0 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_1 [] = {1200,0xFF01,1159,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_2 [] = {1200,0xFF01,1218,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_3 [] = {0xFF01,1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_4 [] = {1211,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1228 [] = {
g_atype1228_0,
g_atype1228_1,
g_atype1228_2,
g_atype1228_3,
g_atype1228_4,
g_atype1228_5,
g_atype1228_6,
};

static const long offsets1228 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @LNGOFF(5,0,0,0),
+ @LNGOFF(5,0,0,1),
};

extern const char *names1229[];
static const uint32 types1229 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1229 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1229_0 [] = {1211,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_2 [] = {1200,0xFF01,1218,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_3 [] = {1200,0xFF01,1138,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_4 [] = {1200,0xFF01,1218,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_5 [] = {0xFF01,1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_8 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1229 [] = {
g_atype1229_0,
g_atype1229_1,
g_atype1229_2,
g_atype1229_3,
g_atype1229_4,
g_atype1229_5,
g_atype1229_6,
g_atype1229_7,
g_atype1229_8,
};

static const long offsets1229 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @LNGOFF(6,0,0,0),
+ @LNGOFF(6,0,0,1),
+ @LNGOFF(6,0,0,2),
};

extern const char *names1230[];
static const uint32 types1230 [] =
{
SK_REF,
SK_UINT16,
SK_UINT16,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1230 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1230_0 [] = {1211,0xFFFF};
static const EIF_TYPE_INDEX g_atype1230_1 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1230_2 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1230_3 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1230_4 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1230_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1230_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1230_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1230_8 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1230 [] = {
g_atype1230_0,
g_atype1230_1,
g_atype1230_2,
g_atype1230_3,
g_atype1230_4,
g_atype1230_5,
g_atype1230_6,
g_atype1230_7,
g_atype1230_8,
};

static const long offsets1230 [] =
{
0,
+ @I16OFF(1,0,0),
+ @I16OFF(1,0,1),
+ @I16OFF(1,0,2),
+ @LNGOFF(1,0,3,0),
+ @LNGOFF(1,0,3,1),
+ @LNGOFF(1,0,3,2),
+ @LNGOFF(1,0,3,3),
+ @LNGOFF(1,0,3,4),
};

extern const char *names1231[];
static const uint32 types1231 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1231 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1231_0 [] = {1211,0xFFFF};
static const EIF_TYPE_INDEX g_atype1231_1 [] = {0xFF01,1163,0xFFFF};
static const EIF_TYPE_INDEX g_atype1231_2 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1231_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1231 [] = {
g_atype1231_0,
g_atype1231_1,
g_atype1231_2,
g_atype1231_3,
};

static const long offsets1231 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
};

extern const char *names1232[];
static const uint32 types1232 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1232 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1232_0 [] = {1211,0xFFFF};
static const EIF_TYPE_INDEX g_atype1232_1 [] = {0xFF01,1163,0xFFFF};
static const EIF_TYPE_INDEX g_atype1232_2 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1232_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1232 [] = {
g_atype1232_0,
g_atype1232_1,
g_atype1232_2,
g_atype1232_3,
};

static const long offsets1232 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
};

extern const char *names1234[];
static const uint32 types1234 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1234 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1234_0 [] = {1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1234_1 [] = {1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1234_2 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1234_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1234_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1234_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1234_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1234 [] = {
g_atype1234_0,
g_atype1234_1,
g_atype1234_2,
g_atype1234_3,
g_atype1234_4,
g_atype1234_5,
g_atype1234_6,
};

static const long offsets1234 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
+ @LNGOFF(3,1,0,1),
+ @LNGOFF(3,1,0,2),
};

extern const char *names1235[];
static const uint32 types1235 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1235 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1235_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1235_1 [] = {0xFF01,1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1235_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1235_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1235_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1235 [] = {
g_atype1235_0,
g_atype1235_1,
g_atype1235_2,
g_atype1235_3,
g_atype1235_4,
};

static const long offsets1235 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names1236[];
static const uint32 types1236 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1236 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1236_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_1 [] = {0xFF01,1307,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_8 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1236 [] = {
g_atype1236_0,
g_atype1236_1,
g_atype1236_2,
g_atype1236_3,
g_atype1236_4,
g_atype1236_5,
g_atype1236_6,
g_atype1236_7,
g_atype1236_8,
};

static const long offsets1236 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
+ @LNGOFF(2,3,0,1),
+ @LNGOFF(2,3,0,2),
+ @LNGOFF(2,3,0,3),
};

extern const char *names1237[];
static const uint32 types1237 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1237 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1237_0 [] = {0xFF01,1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_1 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1237 [] = {
g_atype1237_0,
g_atype1237_1,
};

static const long offsets1237 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names1238[];
static const uint32 types1238 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1238 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1238_0 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1238 [] = {
g_atype1238_0,
g_atype1238_1,
g_atype1238_2,
g_atype1238_3,
};

static const long offsets1238 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names1239[];
static const uint32 types1239 [] =
{
SK_REF,
};

static const uint16 attr_flags1239 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1239_0 [] = {0xFF01,1161,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1239 [] = {
g_atype1239_0,
};

static const long offsets1239 [] =
{
0,
};

extern const char *names1240[];
static const uint32 types1240 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1240 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1240_0 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1240_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1240_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1240 [] = {
g_atype1240_0,
g_atype1240_1,
g_atype1240_2,
};

static const long offsets1240 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names1241[];
static const uint32 types1241 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1241 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1241_0 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1241_1 [] = {0xFF01,0,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1241 [] = {
g_atype1241_0,
g_atype1241_1,
};

static const long offsets1241 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1242[];
static const uint32 types1242 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1242 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1242_0 [] = {0xFF01,814,0xFFFF};
static const EIF_TYPE_INDEX g_atype1242_1 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1242_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1242_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1242 [] = {
g_atype1242_0,
g_atype1242_1,
g_atype1242_2,
g_atype1242_3,
};

static const long offsets1242 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names1243[];
static const uint32 types1243 [] =
{
SK_REF,
};

static const uint16 attr_flags1243 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1243_0 [] = {0xFF01,1191,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1243 [] = {
g_atype1243_0,
};

static const long offsets1243 [] =
{
0,
};

extern const char *names1244[];
static const uint32 types1244 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1244 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1244_0 [] = {0xFF01,1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1244_1 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1244 [] = {
g_atype1244_0,
g_atype1244_1,
};

static const long offsets1244 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names1245[];
static const uint32 types1245 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1245 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1245_0 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_1 [] = {1200,0xFF01,1158,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_2 [] = {1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_3 [] = {0xFF01,1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1245_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1245 [] = {
g_atype1245_0,
g_atype1245_1,
g_atype1245_2,
g_atype1245_3,
g_atype1245_4,
g_atype1245_5,
};

static const long offsets1245 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
};

extern const char *names1246[];
static const uint32 types1246 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1246 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1246_0 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1246_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1246 [] = {
g_atype1246_0,
g_atype1246_1,
g_atype1246_2,
g_atype1246_3,
};

static const long offsets1246 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names1247[];
static const uint32 types1247 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1247 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1247_0 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_2 [] = {1200,0xFF01,1245,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_3 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_4 [] = {0xFF01,1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1247 [] = {
g_atype1247_0,
g_atype1247_1,
g_atype1247_2,
g_atype1247_3,
g_atype1247_4,
g_atype1247_5,
g_atype1247_6,
g_atype1247_7,
};

static const long offsets1247 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @LNGOFF(5,0,0,0),
+ @LNGOFF(5,0,0,1),
+ @LNGOFF(5,0,0,2),
};

extern const char *names1248[];
static const uint32 types1248 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1248 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1248_0 [] = {0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_1 [] = {1165,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1248 [] = {
g_atype1248_0,
g_atype1248_1,
g_atype1248_2,
g_atype1248_3,
};

static const long offsets1248 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
};

extern const char *names1249[];
static const uint32 types1249 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1249 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1249_0 [] = {0xFF01,1200,0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_1 [] = {1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_2 [] = {1212,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1249 [] = {
g_atype1249_0,
g_atype1249_1,
g_atype1249_2,
g_atype1249_3,
g_atype1249_4,
};

static const long offsets1249 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
};

extern const char *names1250[];
static const uint32 types1250 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1250 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1250_0 [] = {1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_1 [] = {1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1250 [] = {
g_atype1250_0,
g_atype1250_1,
g_atype1250_2,
};

static const long offsets1250 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1251[];
static const uint32 types1251 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1251 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1251_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_1 [] = {1212,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_2 [] = {1212,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_3 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_4 [] = {0xFF01,1200,0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1251 [] = {
g_atype1251_0,
g_atype1251_1,
g_atype1251_2,
g_atype1251_3,
g_atype1251_4,
g_atype1251_5,
g_atype1251_6,
};

static const long offsets1251 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @LNGOFF(5,0,0,0),
+ @LNGOFF(5,0,0,1),
};

extern const char *names1252[];
static const uint32 types1252 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1252 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1252_0 [] = {0xFF01,1200,0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_1 [] = {1212,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_3 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1252 [] = {
g_atype1252_0,
g_atype1252_1,
g_atype1252_2,
g_atype1252_3,
};

static const long offsets1252 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names1253[];
static const uint32 types1253 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1253 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1253_0 [] = {1200,0xFF01,1256,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_1 [] = {0xFF01,1144,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_2 [] = {1200,0xFF01,1256,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_3 [] = {1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_4 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_5 [] = {1257,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_6 [] = {1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_7 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_10 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1253 [] = {
g_atype1253_0,
g_atype1253_1,
g_atype1253_2,
g_atype1253_3,
g_atype1253_4,
g_atype1253_5,
g_atype1253_6,
g_atype1253_7,
g_atype1253_8,
g_atype1253_9,
g_atype1253_10,
};

static const long offsets1253 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @LNGOFF(7,1,0,0),
+ @LNGOFF(7,1,0,1),
+ @LNGOFF(7,1,0,2),
};

extern const char *names1254[];
static const uint32 types1254 [] =
{
SK_UINT16,
SK_UINT16,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1254 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1254_0 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_1 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_2 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_3 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1254 [] = {
g_atype1254_0,
g_atype1254_1,
g_atype1254_2,
g_atype1254_3,
g_atype1254_4,
g_atype1254_5,
g_atype1254_6,
g_atype1254_7,
};

static const long offsets1254 [] =
{
+ @I16OFF(0,0,0),
+ @I16OFF(0,0,1),
+ @I16OFF(0,0,2),
+ @LNGOFF(0,0,3,0),
+ @LNGOFF(0,0,3,1),
+ @LNGOFF(0,0,3,2),
+ @LNGOFF(0,0,3,3),
+ @LNGOFF(0,0,3,4),
};

extern const char *names1255[];
static const uint32 types1255 [] =
{
SK_UINT16,
SK_UINT16,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1255 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1255_0 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_1 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_2 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_3 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1255 [] = {
g_atype1255_0,
g_atype1255_1,
g_atype1255_2,
g_atype1255_3,
g_atype1255_4,
g_atype1255_5,
g_atype1255_6,
g_atype1255_7,
};

static const long offsets1255 [] =
{
+ @I16OFF(0,0,0),
+ @I16OFF(0,0,1),
+ @I16OFF(0,0,2),
+ @LNGOFF(0,0,3,0),
+ @LNGOFF(0,0,3,1),
+ @LNGOFF(0,0,3,2),
+ @LNGOFF(0,0,3,3),
+ @LNGOFF(0,0,3,4),
};

extern const char *names1256[];
static const uint32 types1256 [] =
{
SK_UINT16,
SK_UINT16,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1256 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1256_0 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_1 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_2 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_3 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1256_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1256 [] = {
g_atype1256_0,
g_atype1256_1,
g_atype1256_2,
g_atype1256_3,
g_atype1256_4,
g_atype1256_5,
g_atype1256_6,
g_atype1256_7,
};

static const long offsets1256 [] =
{
+ @I16OFF(0,0,0),
+ @I16OFF(0,0,1),
+ @I16OFF(0,0,2),
+ @LNGOFF(0,0,3,0),
+ @LNGOFF(0,0,3,1),
+ @LNGOFF(0,0,3,2),
+ @LNGOFF(0,0,3,3),
+ @LNGOFF(0,0,3,4),
};

extern const char *names1257[];
static const uint32 types1257 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1257 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1257_0 [] = {1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1257_1 [] = {1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1257_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1257_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1257_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1257 [] = {
g_atype1257_0,
g_atype1257_1,
g_atype1257_2,
g_atype1257_3,
g_atype1257_4,
};

static const long offsets1257 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names1258[];
static const uint32 types1258 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1258 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1258_0 [] = {1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1258_1 [] = {1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1258_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1258_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1258_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1258_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1258 [] = {
g_atype1258_0,
g_atype1258_1,
g_atype1258_2,
g_atype1258_3,
g_atype1258_4,
g_atype1258_5,
};

static const long offsets1258 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names1259[];
static const uint32 types1259 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1259 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1259_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_1 [] = {1249,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_2 [] = {1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_3 [] = {1179,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_8 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1259 [] = {
g_atype1259_0,
g_atype1259_1,
g_atype1259_2,
g_atype1259_3,
g_atype1259_4,
g_atype1259_5,
g_atype1259_6,
g_atype1259_7,
g_atype1259_8,
};

static const long offsets1259 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @LNGOFF(4,1,0,0),
+ @LNGOFF(4,1,0,1),
+ @LNGOFF(4,1,0,2),
+ @LNGOFF(4,1,0,3),
};

extern const char *names1260[];
static const uint32 types1260 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1260 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1260_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1260_1 [] = {1249,0xFFFF};
static const EIF_TYPE_INDEX g_atype1260_2 [] = {1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1260_3 [] = {1179,0xFFFF};
static const EIF_TYPE_INDEX g_atype1260_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1260_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1260_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1260_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1260_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1260_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1260_10 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1260 [] = {
g_atype1260_0,
g_atype1260_1,
g_atype1260_2,
g_atype1260_3,
g_atype1260_4,
g_atype1260_5,
g_atype1260_6,
g_atype1260_7,
g_atype1260_8,
g_atype1260_9,
g_atype1260_10,
};

static const long offsets1260 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @LNGOFF(4,1,0,0),
+ @LNGOFF(4,1,0,1),
+ @LNGOFF(4,1,0,2),
+ @LNGOFF(4,1,0,3),
+ @LNGOFF(4,1,0,4),
+ @LNGOFF(4,1,0,5),
};

extern const char *names1261[];
static const uint32 types1261 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1261 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1261_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_1 [] = {1249,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_2 [] = {1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_3 [] = {1179,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_4 [] = {0xFF01,1143,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_10 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_11 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_12 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_13 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1261 [] = {
g_atype1261_0,
g_atype1261_1,
g_atype1261_2,
g_atype1261_3,
g_atype1261_4,
g_atype1261_5,
g_atype1261_6,
g_atype1261_7,
g_atype1261_8,
g_atype1261_9,
g_atype1261_10,
g_atype1261_11,
g_atype1261_12,
g_atype1261_13,
};

static const long offsets1261 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
+ @LNGOFF(5,1,0,2),
+ @LNGOFF(5,1,0,3),
+ @LNGOFF(5,1,0,4),
+ @LNGOFF(5,1,0,5),
+ @LNGOFF(5,1,0,6),
+ @LNGOFF(5,1,0,7),
};

extern const char *names1262[];
static const uint32 types1262 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1262 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1262_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1262 [] = {
g_atype1262_0,
g_atype1262_1,
g_atype1262_2,
g_atype1262_3,
g_atype1262_4,
};

static const long offsets1262 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names1263[];
static const uint32 types1263 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1263 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1263_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1263_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1263_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1263_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1263_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1263 [] = {
g_atype1263_0,
g_atype1263_1,
g_atype1263_2,
g_atype1263_3,
g_atype1263_4,
};

static const long offsets1263 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names1264[];
static const uint32 types1264 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1264 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1264_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1264_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1264_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1264_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1264_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1264 [] = {
g_atype1264_0,
g_atype1264_1,
g_atype1264_2,
g_atype1264_3,
g_atype1264_4,
};

static const long offsets1264 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names1265[];
static const uint32 types1265 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1265 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1265_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1265_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1265_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1265_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1265_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1265 [] = {
g_atype1265_0,
g_atype1265_1,
g_atype1265_2,
g_atype1265_3,
g_atype1265_4,
};

static const long offsets1265 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names1266[];
static const uint32 types1266 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1266 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1266_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_2 [] = {0xFF01,1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1266 [] = {
g_atype1266_0,
g_atype1266_1,
g_atype1266_2,
g_atype1266_3,
g_atype1266_4,
g_atype1266_5,
};

static const long offsets1266 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names1267[];
static const uint32 types1267 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1267 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1267_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1267_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1267_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1267_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1267_4 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1267 [] = {
g_atype1267_0,
g_atype1267_1,
g_atype1267_2,
g_atype1267_3,
g_atype1267_4,
};

static const long offsets1267 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names1269[];
static const uint32 types1269 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1269 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1269_0 [] = {0xFF01,1247,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_1 [] = {1251,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_2 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1269 [] = {
g_atype1269_0,
g_atype1269_1,
g_atype1269_2,
};

static const long offsets1269 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1270[];
static const uint32 types1270 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_UINT8,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1270 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1270_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_1 [] = {0xFF01,1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_2 [] = {1182,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_3 [] = {0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_4 [] = {977,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_8 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1270 [] = {
g_atype1270_0,
g_atype1270_1,
g_atype1270_2,
g_atype1270_3,
g_atype1270_4,
g_atype1270_5,
g_atype1270_6,
g_atype1270_7,
g_atype1270_8,
};

static const long offsets1270 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @LNGOFF(4,1,0,0),
+ @LNGOFF(4,1,0,1),
+ @LNGOFF(4,1,0,2),
+ @LNGOFF(4,1,0,3),
};

extern const char *names1271[];
static const uint32 types1271 [] =
{
SK_BOOL,
SK_UINT16,
SK_UINT16,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1271 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1271_0 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_1 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_2 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_3 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_4 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_8 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1271 [] = {
g_atype1271_0,
g_atype1271_1,
g_atype1271_2,
g_atype1271_3,
g_atype1271_4,
g_atype1271_5,
g_atype1271_6,
g_atype1271_7,
g_atype1271_8,
};

static const long offsets1271 [] =
{
+ @CHROFF(0,0),
+ @I16OFF(0,1,0),
+ @I16OFF(0,1,1),
+ @I16OFF(0,1,2),
+ @LNGOFF(0,1,3,0),
+ @LNGOFF(0,1,3,1),
+ @LNGOFF(0,1,3,2),
+ @LNGOFF(0,1,3,3),
+ @LNGOFF(0,1,3,4),
};

extern const char *names1272[];
static const uint32 types1272 [] =
{
SK_UINT16,
SK_UINT16,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1272 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1272_0 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1272_1 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1272_2 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1272_3 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1272_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1272_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1272_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1272_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1272 [] = {
g_atype1272_0,
g_atype1272_1,
g_atype1272_2,
g_atype1272_3,
g_atype1272_4,
g_atype1272_5,
g_atype1272_6,
g_atype1272_7,
};

static const long offsets1272 [] =
{
+ @I16OFF(0,0,0),
+ @I16OFF(0,0,1),
+ @I16OFF(0,0,2),
+ @LNGOFF(0,0,3,0),
+ @LNGOFF(0,0,3,1),
+ @LNGOFF(0,0,3,2),
+ @LNGOFF(0,0,3,3),
+ @LNGOFF(0,0,3,4),
};

extern const char *names1273[];
static const uint32 types1273 [] =
{
SK_REF,
SK_REF,
SK_UINT16,
SK_UINT16,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1273 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1273_0 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_1 [] = {1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_2 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_3 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_4 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_5 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_9 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1273 [] = {
g_atype1273_0,
g_atype1273_1,
g_atype1273_2,
g_atype1273_3,
g_atype1273_4,
g_atype1273_5,
g_atype1273_6,
g_atype1273_7,
g_atype1273_8,
g_atype1273_9,
};

static const long offsets1273 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @I16OFF(2,0,1),
+ @I16OFF(2,0,2),
+ @LNGOFF(2,0,3,0),
+ @LNGOFF(2,0,3,1),
+ @LNGOFF(2,0,3,2),
+ @LNGOFF(2,0,3,3),
+ @LNGOFF(2,0,3,4),
};

extern const char *names1274[];
static const uint32 types1274 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_UINT16,
SK_UINT16,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags1274 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1274_0 [] = {1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_3 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_4 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_5 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_6 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_10 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_11 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_12 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_13 [] = {968,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1274 [] = {
g_atype1274_0,
g_atype1274_1,
g_atype1274_2,
g_atype1274_3,
g_atype1274_4,
g_atype1274_5,
g_atype1274_6,
g_atype1274_7,
g_atype1274_8,
g_atype1274_9,
g_atype1274_10,
g_atype1274_11,
g_atype1274_12,
g_atype1274_13,
};

static const long offsets1274 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @I16OFF(1,2,0),
+ @I16OFF(1,2,1),
+ @I16OFF(1,2,2),
+ @LNGOFF(1,2,3,0),
+ @LNGOFF(1,2,3,1),
+ @LNGOFF(1,2,3,2),
+ @LNGOFF(1,2,3,3),
+ @LNGOFF(1,2,3,4),
+ @LNGOFF(1,2,3,5),
+ @LNGOFF(1,2,3,6),
+ @I64OFF(1,2,3,7,0,0,0),
};

extern const char *names1275[];
static const uint32 types1275 [] =
{
SK_UINT16,
SK_UINT16,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1275 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1275_0 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_1 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_2 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_3 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1275 [] = {
g_atype1275_0,
g_atype1275_1,
g_atype1275_2,
g_atype1275_3,
g_atype1275_4,
g_atype1275_5,
g_atype1275_6,
g_atype1275_7,
};

static const long offsets1275 [] =
{
+ @I16OFF(0,0,0),
+ @I16OFF(0,0,1),
+ @I16OFF(0,0,2),
+ @LNGOFF(0,0,3,0),
+ @LNGOFF(0,0,3,1),
+ @LNGOFF(0,0,3,2),
+ @LNGOFF(0,0,3,3),
+ @LNGOFF(0,0,3,4),
};

extern const char *names1276[];
static const uint32 types1276 [] =
{
SK_UINT16,
SK_UINT16,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1276 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1276_0 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_1 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_2 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_3 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1276 [] = {
g_atype1276_0,
g_atype1276_1,
g_atype1276_2,
g_atype1276_3,
g_atype1276_4,
g_atype1276_5,
g_atype1276_6,
g_atype1276_7,
};

static const long offsets1276 [] =
{
+ @I16OFF(0,0,0),
+ @I16OFF(0,0,1),
+ @I16OFF(0,0,2),
+ @LNGOFF(0,0,3,0),
+ @LNGOFF(0,0,3,1),
+ @LNGOFF(0,0,3,2),
+ @LNGOFF(0,0,3,3),
+ @LNGOFF(0,0,3,4),
};

extern const char *names1277[];
static const uint32 types1277 [] =
{
SK_BOOL,
SK_UINT16,
SK_UINT16,
SK_UINT16,
SK_CHAR32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1277 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1277_0 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_1 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_2 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_3 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_5 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_8 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1277 [] = {
g_atype1277_0,
g_atype1277_1,
g_atype1277_2,
g_atype1277_3,
g_atype1277_4,
g_atype1277_5,
g_atype1277_6,
g_atype1277_7,
g_atype1277_8,
};

static const long offsets1277 [] =
{
+ @CHROFF(0,0),
+ @I16OFF(0,1,0),
+ @I16OFF(0,1,1),
+ @I16OFF(0,1,2),
+ @LNGOFF(0,1,3,0),
+ @LNGOFF(0,1,3,1),
+ @LNGOFF(0,1,3,2),
+ @LNGOFF(0,1,3,3),
+ @LNGOFF(0,1,3,4),
};

extern const char *names1278[];
static const uint32 types1278 [] =
{
SK_REF,
SK_BOOL,
SK_UINT16,
SK_UINT16,
SK_UINT16,
SK_CHAR32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1278 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1278_0 [] = {0xFF01,1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1278_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1278_2 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1278_3 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1278_4 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1278_5 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1278_6 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1278_7 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1278_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1278_9 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1278 [] = {
g_atype1278_0,
g_atype1278_1,
g_atype1278_2,
g_atype1278_3,
g_atype1278_4,
g_atype1278_5,
g_atype1278_6,
g_atype1278_7,
g_atype1278_8,
g_atype1278_9,
};

static const long offsets1278 [] =
{
0,
+ @CHROFF(1,0),
+ @I16OFF(1,1,0),
+ @I16OFF(1,1,1),
+ @I16OFF(1,1,2),
+ @LNGOFF(1,1,3,0),
+ @LNGOFF(1,1,3,1),
+ @LNGOFF(1,1,3,2),
+ @LNGOFF(1,1,3,3),
+ @LNGOFF(1,1,3,4),
};

extern const char *names1279[];
static const uint32 types1279 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_UINT16,
SK_UINT16,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1279 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1279_0 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1279_1 [] = {1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1279_2 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1279_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1279_4 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1279_5 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1279_6 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1279_7 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1279_8 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1279_9 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1279_10 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1279_11 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1279 [] = {
g_atype1279_0,
g_atype1279_1,
g_atype1279_2,
g_atype1279_3,
g_atype1279_4,
g_atype1279_5,
g_atype1279_6,
g_atype1279_7,
g_atype1279_8,
g_atype1279_9,
g_atype1279_10,
g_atype1279_11,
};

static const long offsets1279 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @I16OFF(2,2,0),
+ @I16OFF(2,2,1),
+ @I16OFF(2,2,2),
+ @LNGOFF(2,2,3,0),
+ @LNGOFF(2,2,3,1),
+ @LNGOFF(2,2,3,2),
+ @LNGOFF(2,2,3,3),
+ @LNGOFF(2,2,3,4),
};

extern const char *names1280[];
static const uint32 types1280 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT16,
SK_UINT16,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1280 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1280_0 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_1 [] = {1191,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_2 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_6 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_7 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_8 [] = {974,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_9 [] = {971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_10 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_11 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_12 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_13 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_14 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1280 [] = {
g_atype1280_0,
g_atype1280_1,
g_atype1280_2,
g_atype1280_3,
g_atype1280_4,
g_atype1280_5,
g_atype1280_6,
g_atype1280_7,
g_atype1280_8,
g_atype1280_9,
g_atype1280_10,
g_atype1280_11,
g_atype1280_12,
g_atype1280_13,
g_atype1280_14,
};

static const long offsets1280 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @I16OFF(3,3,0),
+ @I16OFF(3,3,1),
+ @I16OFF(3,3,2),
+ @LNGOFF(3,3,3,0),
+ @LNGOFF(3,3,3,1),
+ @LNGOFF(3,3,3,2),
+ @LNGOFF(3,3,3,3),
+ @LNGOFF(3,3,3,4),
+ @LNGOFF(3,3,3,5),
};

extern const char *names1281[];
static const uint32 types1281 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1281 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1281_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_2 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1281 [] = {
g_atype1281_0,
g_atype1281_1,
g_atype1281_2,
g_atype1281_3,
g_atype1281_4,
g_atype1281_5,
};

static const long offsets1281 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names1282[];
static const uint32 types1282 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1282 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1282_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_2 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1282 [] = {
g_atype1282_0,
g_atype1282_1,
g_atype1282_2,
g_atype1282_3,
g_atype1282_4,
g_atype1282_5,
};

static const long offsets1282 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names1283[];
static const uint32 types1283 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1283 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1283_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_2 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1283 [] = {
g_atype1283_0,
g_atype1283_1,
g_atype1283_2,
g_atype1283_3,
g_atype1283_4,
g_atype1283_5,
};

static const long offsets1283 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names1284[];
static const uint32 types1284 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1284 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1284_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_2 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1284 [] = {
g_atype1284_0,
g_atype1284_1,
g_atype1284_2,
g_atype1284_3,
g_atype1284_4,
g_atype1284_5,
g_atype1284_6,
};

static const long offsets1284 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
+ @LNGOFF(3,0,0,3),
};

extern const char *names1285[];
static const uint32 types1285 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1285 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1285_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1285_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1285_2 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1285_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1285_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1285_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1285 [] = {
g_atype1285_0,
g_atype1285_1,
g_atype1285_2,
g_atype1285_3,
g_atype1285_4,
g_atype1285_5,
};

static const long offsets1285 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names1286[];
static const uint32 types1286 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1286 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1286_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_2 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1286 [] = {
g_atype1286_0,
g_atype1286_1,
g_atype1286_2,
g_atype1286_3,
g_atype1286_4,
g_atype1286_5,
};

static const long offsets1286 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names1287[];
static const uint32 types1287 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1287 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1287_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_2 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_3 [] = {0xFF01,1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1287 [] = {
g_atype1287_0,
g_atype1287_1,
g_atype1287_2,
g_atype1287_3,
g_atype1287_4,
g_atype1287_5,
g_atype1287_6,
};

static const long offsets1287 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
+ @LNGOFF(4,0,0,2),
};

extern const char *names1288[];
static const uint32 types1288 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1288 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1288_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_2 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1288 [] = {
g_atype1288_0,
g_atype1288_1,
g_atype1288_2,
g_atype1288_3,
g_atype1288_4,
g_atype1288_5,
g_atype1288_6,
};

static const long offsets1288 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
+ @LNGOFF(3,0,0,3),
};

extern const char *names1289[];
static const uint32 types1289 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1289 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1289_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_2 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1289 [] = {
g_atype1289_0,
g_atype1289_1,
g_atype1289_2,
g_atype1289_3,
g_atype1289_4,
g_atype1289_5,
};

static const long offsets1289 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names1290[];
static const uint32 types1290 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1290 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1290_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_2 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1290 [] = {
g_atype1290_0,
g_atype1290_1,
g_atype1290_2,
g_atype1290_3,
g_atype1290_4,
g_atype1290_5,
};

static const long offsets1290 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names1291[];
static const uint32 types1291 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1291 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1291_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_2 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1291 [] = {
g_atype1291_0,
g_atype1291_1,
g_atype1291_2,
g_atype1291_3,
g_atype1291_4,
g_atype1291_5,
};

static const long offsets1291 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names1292[];
static const uint32 types1292 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1292 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1292_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1292_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1292_2 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1292_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1292_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1292_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1292 [] = {
g_atype1292_0,
g_atype1292_1,
g_atype1292_2,
g_atype1292_3,
g_atype1292_4,
g_atype1292_5,
};

static const long offsets1292 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names1293[];
static const uint32 types1293 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1293 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1293_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_2 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1293 [] = {
g_atype1293_0,
g_atype1293_1,
g_atype1293_2,
g_atype1293_3,
g_atype1293_4,
g_atype1293_5,
};

static const long offsets1293 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names1294[];
static const uint32 types1294 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1294 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1294_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1294_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1294_2 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1294_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1294_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1294_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1294 [] = {
g_atype1294_0,
g_atype1294_1,
g_atype1294_2,
g_atype1294_3,
g_atype1294_4,
g_atype1294_5,
};

static const long offsets1294 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names1295[];
static const uint32 types1295 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1295 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1295_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1295_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1295_2 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1295_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1295_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1295_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1295 [] = {
g_atype1295_0,
g_atype1295_1,
g_atype1295_2,
g_atype1295_3,
g_atype1295_4,
g_atype1295_5,
};

static const long offsets1295 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names1296[];
static const uint32 types1296 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1296 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1296_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1296_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1296_2 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1296_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1296_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1296_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1296 [] = {
g_atype1296_0,
g_atype1296_1,
g_atype1296_2,
g_atype1296_3,
g_atype1296_4,
g_atype1296_5,
};

static const long offsets1296 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names1297[];
static const uint32 types1297 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1297 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1297_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_2 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1297 [] = {
g_atype1297_0,
g_atype1297_1,
g_atype1297_2,
g_atype1297_3,
g_atype1297_4,
g_atype1297_5,
};

static const long offsets1297 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names1298[];
static const uint32 types1298 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1298 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1298_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_2 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1298 [] = {
g_atype1298_0,
g_atype1298_1,
g_atype1298_2,
g_atype1298_3,
g_atype1298_4,
g_atype1298_5,
};

static const long offsets1298 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names1299[];
static const uint32 types1299 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1299 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1299_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_2 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1299 [] = {
g_atype1299_0,
g_atype1299_1,
g_atype1299_2,
g_atype1299_3,
g_atype1299_4,
g_atype1299_5,
};

static const long offsets1299 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names1300[];
static const uint32 types1300 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1300 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1300_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_2 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1300 [] = {
g_atype1300_0,
g_atype1300_1,
g_atype1300_2,
g_atype1300_3,
g_atype1300_4,
g_atype1300_5,
};

static const long offsets1300 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names1301[];
static const uint32 types1301 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1301 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1301_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_2 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1301 [] = {
g_atype1301_0,
g_atype1301_1,
g_atype1301_2,
g_atype1301_3,
g_atype1301_4,
g_atype1301_5,
};

static const long offsets1301 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names1302[];
static const uint32 types1302 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1302 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1302_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_2 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1302 [] = {
g_atype1302_0,
g_atype1302_1,
g_atype1302_2,
g_atype1302_3,
g_atype1302_4,
g_atype1302_5,
};

static const long offsets1302 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names1303[];
static const uint32 types1303 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1303 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1303_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_2 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1303 [] = {
g_atype1303_0,
g_atype1303_1,
g_atype1303_2,
g_atype1303_3,
g_atype1303_4,
g_atype1303_5,
};

static const long offsets1303 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names1304[];
static const uint32 types1304 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1304 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1304_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_2 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1304 [] = {
g_atype1304_0,
g_atype1304_1,
g_atype1304_2,
g_atype1304_3,
g_atype1304_4,
g_atype1304_5,
};

static const long offsets1304 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names1305[];
static const uint32 types1305 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1305 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1305_0 [] = {842,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_1 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_2 [] = {0xFF01,1232,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1305 [] = {
g_atype1305_0,
g_atype1305_1,
g_atype1305_2,
g_atype1305_3,
g_atype1305_4,
g_atype1305_5,
};

static const long offsets1305 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names1306[];
static const uint32 types1306 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1306 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1306_0 [] = {1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_1 [] = {1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_2 [] = {1207,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_3 [] = {1207,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_4 [] = {1200,0xFF01,1135,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_5 [] = {1134,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_6 [] = {1278,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_7 [] = {1278,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_8 [] = {1200,0xFF01,1132,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_9 [] = {1205,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_10 [] = {1200,0xFF01,1145,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_11 [] = {1200,0xFF01,1306,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_12 [] = {1134,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_13 [] = {0xFF01,26,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_14 [] = {805,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_15 [] = {0xFF01,1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_16 [] = {0xFF01,786,0xFF01,1306,959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_17 [] = {0xFF01,1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_18 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_19 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_20 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_21 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_22 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_23 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_24 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_25 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_26 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_27 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_28 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_29 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_30 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_31 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_32 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_33 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_34 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_35 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_36 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_37 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_38 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_39 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_40 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_41 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_42 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_43 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_44 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1306 [] = {
g_atype1306_0,
g_atype1306_1,
g_atype1306_2,
g_atype1306_3,
g_atype1306_4,
g_atype1306_5,
g_atype1306_6,
g_atype1306_7,
g_atype1306_8,
g_atype1306_9,
g_atype1306_10,
g_atype1306_11,
g_atype1306_12,
g_atype1306_13,
g_atype1306_14,
g_atype1306_15,
g_atype1306_16,
g_atype1306_17,
g_atype1306_18,
g_atype1306_19,
g_atype1306_20,
g_atype1306_21,
g_atype1306_22,
g_atype1306_23,
g_atype1306_24,
g_atype1306_25,
g_atype1306_26,
g_atype1306_27,
g_atype1306_28,
g_atype1306_29,
g_atype1306_30,
g_atype1306_31,
g_atype1306_32,
g_atype1306_33,
g_atype1306_34,
g_atype1306_35,
g_atype1306_36,
g_atype1306_37,
g_atype1306_38,
g_atype1306_39,
g_atype1306_40,
g_atype1306_41,
g_atype1306_42,
g_atype1306_43,
g_atype1306_44,
};

static const long offsets1306 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
+ @CHROFF(18,0),
+ @CHROFF(18,1),
+ @CHROFF(18,2),
+ @CHROFF(18,3),
+ @CHROFF(18,4),
+ @CHROFF(18,5),
+ @CHROFF(18,6),
+ @LNGOFF(18,7,0,0),
+ @LNGOFF(18,7,0,1),
+ @LNGOFF(18,7,0,2),
+ @LNGOFF(18,7,0,3),
+ @LNGOFF(18,7,0,4),
+ @LNGOFF(18,7,0,5),
+ @LNGOFF(18,7,0,6),
+ @LNGOFF(18,7,0,7),
+ @LNGOFF(18,7,0,8),
+ @LNGOFF(18,7,0,9),
+ @LNGOFF(18,7,0,10),
+ @LNGOFF(18,7,0,11),
+ @LNGOFF(18,7,0,12),
+ @LNGOFF(18,7,0,13),
+ @LNGOFF(18,7,0,14),
+ @LNGOFF(18,7,0,15),
+ @LNGOFF(18,7,0,16),
+ @LNGOFF(18,7,0,17),
+ @LNGOFF(18,7,0,18),
+ @LNGOFF(18,7,0,19),
};

extern const char *names1307[];
static const uint32 types1307 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1307 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1307_0 [] = {0xFF01,1200,0xFF01,1307,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_1 [] = {0xFF01,1143,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_2 [] = {1202,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1307 [] = {
g_atype1307_0,
g_atype1307_1,
g_atype1307_2,
g_atype1307_3,
g_atype1307_4,
g_atype1307_5,
};

static const long offsets1307 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
+ @LNGOFF(3,1,0,1),
};

extern const char *names1308[];
static const uint32 types1308 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1308 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1308_0 [] = {1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_1 [] = {0xFF01,1274,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1308 [] = {
g_atype1308_0,
g_atype1308_1,
};

static const long offsets1308 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1309[];
static const uint32 types1309 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1309 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1309_0 [] = {1215,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_1 [] = {0xFF01,1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_2 [] = {0xFF01,793,0xFF01,320,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_3 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_5 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_6 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1309 [] = {
g_atype1309_0,
g_atype1309_1,
g_atype1309_2,
g_atype1309_3,
g_atype1309_4,
g_atype1309_5,
g_atype1309_6,
};

static const long offsets1309 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @LNGOFF(3,3,0,0),
};

extern const char *names1310[];
static const uint32 types1310 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1310 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1310_0 [] = {1032,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_2 [] = {45,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_3 [] = {0xFF01,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_5 [] = {992,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1310 [] = {
g_atype1310_0,
g_atype1310_1,
g_atype1310_2,
g_atype1310_3,
g_atype1310_4,
g_atype1310_5,
};

static const long offsets1310 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
};

extern const char *names1312[];
static const uint32 types1312 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1312 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1312_0 [] = {0xFF01,706,1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_1 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_2 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_3 [] = {1037,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_4 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_5 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1312 [] = {
g_atype1312_0,
g_atype1312_1,
g_atype1312_2,
g_atype1312_3,
g_atype1312_4,
g_atype1312_5,
};

static const long offsets1312 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @LNGOFF(4,1,0,0),
};

extern const char *names1313[];
static const uint32 types1313 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1313 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1313_0 [] = {0xFF01,845,989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1313_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1313 [] = {
g_atype1313_0,
g_atype1313_1,
g_atype1313_2,
g_atype1313_3,
g_atype1313_4,
g_atype1313_5,
g_atype1313_6,
g_atype1313_7,
};

static const long offsets1313 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
+ @LNGOFF(1,1,0,5),
};

extern const char *names1314[];
static const uint32 types1314 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1314 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1314_0 [] = {0xFF01,845,989,0xFFFF};
static const EIF_TYPE_INDEX g_atype1314_1 [] = {992,0xFFFF};
static const EIF_TYPE_INDEX g_atype1314_2 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1314_3 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1314_4 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1314_5 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1314_6 [] = {959,0xFFFF};
static const EIF_TYPE_INDEX g_atype1314_7 [] = {959,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1314 [] = {
g_atype1314_0,
g_atype1314_1,
g_atype1314_2,
g_atype1314_3,
g_atype1314_4,
g_atype1314_5,
g_atype1314_6,
g_atype1314_7,
};

static const long offsets1314 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
+ @LNGOFF(1,1,0,5),
};

const struct cnode egc_fsystem_init[] = {
{
	(long) 0,
	(long) 0,
	"ANY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UTF8_READER_WRITER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_FORMATTING_UTILITY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_OPERATING_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"I18N_FILE_SCOPE_INFORMATION",
	names5,
	types5,
	attr_flags5,
	gtypes5,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets5,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COMPILER_PROFILE",
	names6,
	types6,
	attr_flags6,
	gtypes6,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets6,
	NULL
},
{
	(long) 3,
	(long) 3,
	"C_DATE",
	names7,
	types7,
	attr_flags7,
	gtypes7,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets7,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_PLURAL_TOOLS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PRODUCT_NAMES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_URI_PARSER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"RESCUE_STATUS",
	names11,
	types11,
	attr_flags11,
	gtypes11,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets11,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ANY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STANDARD_FILES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_DATE_FORMATTER",
	names14,
	types14,
	attr_flags14,
	gtypes14,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets14,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_STRING_FORMATTER",
	names15,
	types15,
	attr_flags15,
	gtypes15,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets15,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_CURRENCY_FORMATTER",
	names16,
	types16,
	attr_flags16,
	gtypes16,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets16,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ERROR_DISPLAYER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"I18N_LOCALE",
	names21,
	types21,
	attr_flags21,
	gtypes21,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets21,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CACHED_PLAIN_TEXT_FILE_READER",
	names22,
	types22,
	attr_flags22,
	gtypes22,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets22,
	NULL
},
{
	(long) 0,
	(long) 0,
	"AST_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"CLICK_AST",
	names24,
	types24,
	attr_flags24,
	gtypes24,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets24,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DESCRIPTOR_CACHE",
	names25,
	types25,
	attr_flags25,
	gtypes25,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets25,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ERROR_VISITOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"SUPPLIERS_AS",
	names27,
	types27,
	attr_flags27,
	gtypes27,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets27,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ABSTRACT_CLASS_C",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ASCII",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"ERT_TOKEN_REGION",
	names30,
	types30,
	attr_flags30,
	gtypes30,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets30,
	NULL
},
{
	(long) 1,
	(long) 0,
	"VERSIONABLE",
	names31,
	types31,
	attr_flags31,
	gtypes31,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets31,
	NULL
},
{
	(long) 3,
	(long) 3,
	"AGENT_TARGET_TRIPLE",
	names32,
	types32,
	attr_flags32,
	gtypes32,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets32,
	NULL
},
{
	(long) 2,
	(long) 2,
	"PAIR",
	names33,
	types33,
	attr_flags33,
	gtypes33,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets33,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CREATION_CONSTRAIN_TRIPLE",
	names34,
	types34,
	attr_flags34,
	gtypes34,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets34,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CONSTRAINT_TRIPLE",
	names35,
	types35,
	attr_flags35,
	gtypes35,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets35,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_STRING_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CHARACTER_PROPERTY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PO_FILE_ENTRY_ID_GEN",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0100,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PO_FILE_ENTRY_ID_GEN",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0300,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CODE_PAGE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"ENCODING",
	names46,
	types46,
	attr_flags46,
	gtypes46,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets46,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_STRING",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"RT_DBG_EXECUTION_PARAMETERS",
	names48,
	types48,
	attr_flags48,
	gtypes48,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets48,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ISE_RUNTIME",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"STD_FILES",
	names62,
	types62,
	attr_flags62,
	gtypes62,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets62,
	NULL
},
{
	(long) 0,
	(long) 0,
	"FILE_UTILITIES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0100,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"FILE_UTILITIES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0300,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"PO_FILE",
	names65,
	types65,
	attr_flags65,
	gtypes65,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets65,
	NULL
},
{
	(long) 4,
	(long) 4,
	"PO_GENERATOR",
	names66,
	types66,
	attr_flags66,
	gtypes66,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets66,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UTF_CONVERTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0100,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UTF_CONVERTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0300,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_EXECUTION_ENVIRONMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ENVIRONMENT_ARGUMENTS",
	names70,
	types70,
	attr_flags70,
	gtypes70,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets70,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ES_ARGUMENTS",
	names71,
	types71,
	attr_flags71,
	gtypes71,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets71,
	NULL
},
{
	(long) 0,
	(long) 0,
	"IMPORTED_UTF8_READER_WRITER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_SHARED_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DATE_TIME_LANGUAGE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DATE_TIME_TOOLS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_I18N_FORMATTING_UTILITY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"GROUP_ELEMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_OUTPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_FILE_HANDLER",
	names80,
	types80,
	attr_flags80,
	gtypes80,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets80,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_MO_HANDLER",
	names81,
	types81,
	attr_flags81,
	gtypes81,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets81,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_OPERATING_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_FORMATTING_CHARACTERS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_CELL",
	names84,
	types84,
	attr_flags84,
	gtypes84,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets84,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_CELL",
	names85,
	types85,
	attr_flags85,
	gtypes85,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets85,
	NULL
},
{
	(long) 2,
	(long) 2,
	"KL_LINKABLE",
	names86,
	types86,
	attr_flags86,
	gtypes86,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets86,
	NULL
},
{
	(long) 2,
	(long) 2,
	"KL_LINKABLE",
	names87,
	types87,
	attr_flags87,
	gtypes87,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets87,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UTF8_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_COMPILER_PROFILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EIFFEL_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_LOCALE_CONV",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_UNIX_C_FUNCTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_POSIX_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_CODE_PAGE_INFO",
	names96,
	types96,
	attr_flags96,
	gtypes96,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets96,
	NULL
},
{
	(long) 13,
	(long) 13,
	"I18N_DATE_TIME_INFO",
	names97,
	types97,
	attr_flags97,
	gtypes97,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets97,
	NULL
},
{
	(long) 16,
	(long) 16,
	"I18N_CURRENCY_INFO",
	names98,
	types98,
	attr_flags98,
	gtypes98,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets98,
	NULL
},
{
	(long) 7,
	(long) 7,
	"I18N_NUMERIC_INFO",
	names99,
	types99,
	attr_flags99,
	gtypes99,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets99,
	NULL
},
{
	(long) 40,
	(long) 40,
	"I18N_LOCALE_INFO",
	names100,
	types100,
	attr_flags100,
	gtypes100,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets100,
	NULL
},
{
	(long) 2,
	(long) 2,
	"ID_LIST",
	names101,
	types101,
	attr_flags101,
	gtypes101,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets101,
	NULL
},
{
	(long) 2,
	(long) 2,
	"ID_SET",
	names102,
	types102,
	attr_flags102,
	gtypes102,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets102,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ID_SET_ACCESSOR",
	names103,
	types103,
	attr_flags103,
	gtypes103,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets103,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_CHARACTER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_STREAMS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ANY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_CHARACTER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UNICODE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_I18N_URI_PARSER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_HOST_LOCALE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_DATASOURCE_MANAGER",
	names112,
	types112,
	attr_flags112,
	gtypes112,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets112,
	NULL
},
{
	(long) 7,
	(long) 7,
	"I18N_FILE_MANAGER",
	names113,
	types113,
	attr_flags113,
	gtypes113,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets113,
	NULL
},
{
	(long) 6,
	(long) 6,
	"I18N_VALUE_FORMATTER",
	names114,
	types114,
	attr_flags114,
	gtypes114,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets114,
	NULL
},
{
	(long) 6,
	(long) 6,
	"I18N_CURRENCY_VALUE_FORMATTER",
	names115,
	types115,
	attr_flags115,
	gtypes115,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets115,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_RESCUE_STATUS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"YY_PARSER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BUFFER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BUFFER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_CHARACTER_BUFFER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EIFFEL_LAYOUT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 12,
	(long) 12,
	"OBJECT_GRAPH_TRAVERSABLE",
	names122,
	types122,
	attr_flags122,
	gtypes122,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets122,
	NULL
},
{
	(long) 12,
	(long) 12,
	"OBJECT_GRAPH_BREADTH_FIRST_TRAVERSABLE",
	names123,
	types123,
	attr_flags123,
	gtypes123,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets123,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CODE_SETS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_ERROR_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INTEGER_TYPE_MASKS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OBJECT_GRAPH_MARKER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MATH_CONST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DOUBLE_MATH",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS_I",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PREDEFINED_NAMES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LOCATION_AS",
	names132,
	types132,
	attr_flags132,
	gtypes132,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets132,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTION_MANAGER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ISE_EXCEPTION_MANAGER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEP_CONST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names137,
	types137,
	attr_flags137,
	gtypes137,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets137,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names138,
	types138,
	attr_flags138,
	gtypes138,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets138,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names139,
	types139,
	attr_flags139,
	gtypes139,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets139,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names140,
	types140,
	attr_flags140,
	gtypes140,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets140,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names141,
	types141,
	attr_flags141,
	gtypes141,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets141,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LINKABLE",
	names142,
	types142,
	attr_flags142,
	gtypes142,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets142,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LINKABLE",
	names143,
	types143,
	attr_flags143,
	gtypes143,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets143,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LINKABLE",
	names144,
	types144,
	attr_flags144,
	gtypes144,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets144,
	NULL
},
{
	(long) 3,
	(long) 3,
	"BI_LINKABLE",
	names145,
	types145,
	attr_flags145,
	gtypes145,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets145,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OPERATING_ENVIRONMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"IL_ENVIRONMENT",
	names147,
	types147,
	attr_flags147,
	gtypes147,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets147,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CODE_VALIDITY_CHECKER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_FILE_SYSTEM_ENTRY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TIME_UTILITY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TIME_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TIME_MEASUREMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"TIME_VALUE",
	names154,
	types154,
	attr_flags154,
	gtypes154,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets154,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DATE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DATE_MEASUREMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DATE_TIME_MEASUREMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DATE_TIME_VALUE",
	names158,
	types158,
	attr_flags158,
	gtypes158,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets158,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_DICTIONARY_ID_BUILDER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_I18N_PLURAL_TOOLS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"I18N_FILE",
	names161,
	types161,
	attr_flags161,
	gtypes161,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets161,
	NULL
},
{
	(long) 15,
	(long) 15,
	"I18N_MO_FILE",
	names162,
	types162,
	attr_flags162,
	gtypes162,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets162,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_DICTIONARY",
	names163,
	types163,
	attr_flags163,
	gtypes163,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets163,
	NULL
},
{
	(long) 5,
	(long) 5,
	"I18N_BINARY_SEARCH_ARRAY_DICTIONARY",
	names164,
	types164,
	attr_flags164,
	gtypes164,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets164,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_DUMMY_DICTIONARY",
	names165,
	types165,
	attr_flags165,
	gtypes165,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets165,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UTF32_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UTF16_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EIFFEL_LIST_WRAPPER_AS",
	names170,
	types170,
	attr_flags170,
	gtypes170,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets170,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_STANDARD_FILES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYNTAX_STRINGS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ENCODING_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS_IMP",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"BOM_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"COMPILER_EXPORTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION_COMMON",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION_GENERAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_DBG_COMMON",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_SEARCHER",
	names182,
	types182,
	attr_flags182,
	gtypes182,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets182,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_8_SEARCHER",
	names183,
	types183,
	attr_flags183,
	gtypes183,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets183,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_32_SEARCHER",
	names184,
	types184,
	attr_flags184,
	gtypes184,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets184,
	NULL
},
{
	(long) 7,
	(long) 7,
	"PO_FILE_ENTRY",
	names185,
	types185,
	attr_flags185,
	gtypes185,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets185,
	NULL
},
{
	(long) 9,
	(long) 9,
	"PO_FILE_ENTRY_PLURAL",
	names186,
	types186,
	attr_flags186,
	gtypes186,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets186,
	NULL
},
{
	(long) 8,
	(long) 8,
	"PO_FILE_ENTRY_SINGULAR",
	names187,
	types187,
	attr_flags187,
	gtypes187,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets187,
	NULL
},
{
	(long) 9,
	(long) 9,
	"PO_FILE_HEADERS",
	names188,
	types188,
	attr_flags188,
	gtypes188,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets188,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NUMERIC_INFORMATION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"INTEGER_OVERFLOW_CHECKER",
	names190,
	types190,
	attr_flags190,
	gtypes190,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets190,
	NULL
},
{
	(long) 7,
	(long) 7,
	"STRING_TO_NUMERIC_CONVERTOR",
	names191,
	types191,
	attr_flags191,
	gtypes191,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets191,
	NULL
},
{
	(long) 15,
	(long) 15,
	"STRING_TO_REAL_CONVERTOR",
	names192,
	types192,
	attr_flags192,
	gtypes192,
	(uint16) 0x6000,
	(void (*)()) 0,
	offsets192,
	NULL
},
{
	(long) 10,
	(long) 10,
	"STRING_TO_INTEGER_CONVERTOR",
	names193,
	types193,
	attr_flags193,
	gtypes193,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets193,
	NULL
},
{
	(long) 11,
	(long) 11,
	"HEXADECIMAL_STRING_TO_INTEGER_CONVERTER",
	names194,
	types194,
	attr_flags194,
	gtypes194,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets194,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ERT_REGION_MODIFIER",
	names199,
	types199,
	attr_flags199,
	gtypes199,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets199,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ERT_REMOVE_REGION_MODIFIER",
	names200,
	types200,
	attr_flags200,
	gtypes200,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets200,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ERT_REPLACE_REGION_MODIFIER",
	names201,
	types201,
	attr_flags201,
	gtypes201,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets201,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ERT_ADDITION_REGION_MODIFIER",
	names202,
	types202,
	attr_flags202,
	gtypes202,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets202,
	NULL
},
{
	(long) 10,
	(long) 10,
	"YY_BUFFER",
	names203,
	types203,
	attr_flags203,
	gtypes203,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets203,
	NULL
},
{
	(long) 10,
	(long) 10,
	"YY_UTF8_BUFFER",
	names204,
	types204,
	attr_flags204,
	gtypes204,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets204,
	NULL
},
{
	(long) 10,
	(long) 10,
	"YY_UNICODE_BUFFER",
	names205,
	types205,
	attr_flags205,
	gtypes205,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets205,
	NULL
},
{
	(long) 12,
	(long) 12,
	"YY_FILE_BUFFER",
	names206,
	types206,
	attr_flags206,
	gtypes206,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets206,
	NULL
},
{
	(long) 14,
	(long) 14,
	"YY_UTF8_FILE_BUFFER",
	names207,
	types207,
	attr_flags207,
	gtypes207,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets207,
	NULL
},
{
	(long) 15,
	(long) 15,
	"YY_UNICODE_FILE_BUFFER",
	names208,
	types208,
	attr_flags208,
	gtypes208,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets208,
	NULL
},
{
	(long) 0,
	(long) 0,
	"AST_VISITOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"AST_ITERATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"AST_NULL_VISITOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"AST_FORMAL_GENERICS_PASS2",
	names212,
	types212,
	attr_flags212,
	gtypes212,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets212,
	NULL
},
{
	(long) 7,
	(long) 7,
	"AST_ROUNDTRIP_ITERATOR",
	names213,
	types213,
	attr_flags213,
	gtypes213,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets213,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_ROUTINES",
	names214,
	types214,
	attr_flags214,
	gtypes214,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets214,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"HASH_TABLE_CURSOR",
	names216,
	types216,
	attr_flags216,
	gtypes216,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets216,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ARRAYED_LIST_CURSOR",
	names217,
	types217,
	attr_flags217,
	gtypes217,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets217,
	NULL
},
{
	(long) 3,
	(long) 3,
	"LINKED_LIST_CURSOR",
	names218,
	types218,
	attr_flags218,
	gtypes218,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets218,
	NULL
},
{
	(long) 3,
	(long) 3,
	"LINKED_LIST_CURSOR",
	names219,
	types219,
	attr_flags219,
	gtypes219,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets219,
	NULL
},
{
	(long) 3,
	(long) 3,
	"LINKED_LIST_CURSOR",
	names220,
	types220,
	attr_flags220,
	gtypes220,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets220,
	NULL
},
{
	(long) 3,
	(long) 3,
	"TWO_WAY_LIST_CURSOR",
	names221,
	types221,
	attr_flags221,
	gtypes221,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets221,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTION_MANAGER_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXCEPTION",
	names224,
	types224,
	attr_flags224,
	gtypes224,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets224,
	NULL
},
{
	(long) 7,
	(long) 7,
	"DEVELOPER_EXCEPTION",
	names225,
	types225,
	attr_flags225,
	gtypes225,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets225,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CONVERSION_FAILURE",
	names226,
	types226,
	attr_flags226,
	gtypes226,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets226,
	NULL
},
{
	(long) 7,
	(long) 7,
	"MACHINE_EXCEPTION",
	names227,
	types227,
	attr_flags227,
	gtypes227,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets227,
	NULL
},
{
	(long) 7,
	(long) 7,
	"HARDWARE_EXCEPTION",
	names228,
	types228,
	attr_flags228,
	gtypes228,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets228,
	NULL
},
{
	(long) 7,
	(long) 7,
	"FLOATING_POINT_FAILURE",
	names229,
	types229,
	attr_flags229,
	gtypes229,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets229,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OPERATING_SYSTEM_EXCEPTION",
	names230,
	types230,
	attr_flags230,
	gtypes230,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets230,
	NULL
},
{
	(long) 10,
	(long) 10,
	"COM_FAILURE",
	names231,
	types231,
	attr_flags231,
	gtypes231,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets231,
	NULL
},
{
	(long) 8,
	(long) 8,
	"OPERATING_SYSTEM_FAILURE",
	names232,
	types232,
	attr_flags232,
	gtypes232,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets232,
	NULL
},
{
	(long) 8,
	(long) 8,
	"OPERATING_SYSTEM_SIGNAL_FAILURE",
	names233,
	types233,
	attr_flags233,
	gtypes233,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets233,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OBSOLETE_EXCEPTION",
	names234,
	types234,
	attr_flags234,
	gtypes234,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets234,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXCEPTION_IN_SIGNAL_HANDLER_FAILURE",
	names235,
	types235,
	attr_flags235,
	gtypes235,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets235,
	NULL
},
{
	(long) 7,
	(long) 7,
	"RESUMPTION_FAILURE",
	names236,
	types236,
	attr_flags236,
	gtypes236,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets236,
	NULL
},
{
	(long) 7,
	(long) 7,
	"RESCUE_FAILURE",
	names237,
	types237,
	attr_flags237,
	gtypes237,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets237,
	NULL
},
{
	(long) 7,
	(long) 7,
	"SYS_EXCEPTION",
	names238,
	types238,
	attr_flags238,
	gtypes238,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets238,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OLD_VIOLATION",
	names239,
	types239,
	attr_flags239,
	gtypes239,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets239,
	NULL
},
{
	(long) 8,
	(long) 8,
	"EIFFEL_RUNTIME_PANIC",
	names240,
	types240,
	attr_flags240,
	gtypes240,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets240,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIF_EXCEPTION",
	names241,
	types241,
	attr_flags241,
	gtypes241,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets241,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIFFEL_RUNTIME_EXCEPTION",
	names242,
	types242,
	attr_flags242,
	gtypes242,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets242,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXTERNAL_FAILURE",
	names243,
	types243,
	attr_flags243,
	gtypes243,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets243,
	NULL
},
{
	(long) 8,
	(long) 8,
	"NO_MORE_MEMORY",
	names244,
	types244,
	attr_flags244,
	gtypes244,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets244,
	NULL
},
{
	(long) 7,
	(long) 7,
	"DATA_EXCEPTION",
	names245,
	types245,
	attr_flags245,
	gtypes245,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets245,
	NULL
},
{
	(long) 7,
	(long) 7,
	"MISMATCH_FAILURE",
	names246,
	types246,
	attr_flags246,
	gtypes246,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets246,
	NULL
},
{
	(long) 9,
	(long) 9,
	"IO_FAILURE",
	names247,
	types247,
	attr_flags247,
	gtypes247,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets247,
	NULL
},
{
	(long) 7,
	(long) 7,
	"SERIALIZATION_FAILURE",
	names248,
	types248,
	attr_flags248,
	gtypes248,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets248,
	NULL
},
{
	(long) 7,
	(long) 7,
	"LANGUAGE_EXCEPTION",
	names249,
	types249,
	attr_flags249,
	gtypes249,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets249,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VOID_ASSIGNED_TO_EXPANDED",
	names250,
	types250,
	attr_flags250,
	gtypes250,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets250,
	NULL
},
{
	(long) 7,
	(long) 7,
	"BAD_INSPECT_VALUE",
	names251,
	types251,
	attr_flags251,
	gtypes251,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets251,
	NULL
},
{
	(long) 9,
	(long) 9,
	"ROUTINE_FAILURE",
	names252,
	types252,
	attr_flags252,
	gtypes252,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets252,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VOID_TARGET",
	names253,
	types253,
	attr_flags253,
	gtypes253,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets253,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIFFELSTUDIO_SPECIFIC_LANGUAGE_EXCEPTION",
	names254,
	types254,
	attr_flags254,
	gtypes254,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets254,
	NULL
},
{
	(long) 7,
	(long) 7,
	"ADDRESS_APPLIED_TO_MELTED_FEATURE",
	names255,
	types255,
	attr_flags255,
	gtypes255,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets255,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CREATE_ON_DEFERRED",
	names256,
	types256,
	attr_flags256,
	gtypes256,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets256,
	NULL
},
{
	(long) 7,
	(long) 7,
	"ASSERTION_VIOLATION",
	names257,
	types257,
	attr_flags257,
	gtypes257,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets257,
	NULL
},
{
	(long) 7,
	(long) 7,
	"LOOP_INVARIANT_VIOLATION",
	names258,
	types258,
	attr_flags258,
	gtypes258,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets258,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VARIANT_VIOLATION",
	names259,
	types259,
	attr_flags259,
	gtypes259,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets259,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CHECK_VIOLATION",
	names260,
	types260,
	attr_flags260,
	gtypes260,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets260,
	NULL
},
{
	(long) 8,
	(long) 8,
	"INVARIANT_VIOLATION",
	names261,
	types261,
	attr_flags261,
	gtypes261,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets261,
	NULL
},
{
	(long) 7,
	(long) 7,
	"POSTCONDITION_VIOLATION",
	names262,
	types262,
	attr_flags262,
	gtypes262,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets262,
	NULL
},
{
	(long) 7,
	(long) 7,
	"PRECONDITION_VIOLATION",
	names263,
	types263,
	attr_flags263,
	gtypes263,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets263,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_FORMATTING_ELEMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_DATE_ELEMENT",
	names265,
	types265,
	attr_flags265,
	gtypes265,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets265,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_USERSTRING_ELEMENT",
	names266,
	types266,
	attr_flags266,
	gtypes266,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets266,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_TIME_ELEMENT",
	names267,
	types267,
	attr_flags267,
	gtypes267,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets267,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_FORMAT_STRING",
	names268,
	types268,
	attr_flags268,
	gtypes268,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets268,
	NULL
},
{
	(long) 1,
	(long) 1,
	"IDABLE",
	names269,
	types269,
	attr_flags269,
	gtypes269,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets269,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OPERATOR_KIND",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DISPOSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 2,
	"MANAGED_POINTER",
	names272,
	types272,
	attr_flags272,
	gtypes272,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets272,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PART_COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"INTERVAL",
	names274,
	types274,
	attr_flags274,
	gtypes274,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets274,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DURATION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"DATE_DURATION",
	names276,
	types276,
	attr_flags276,
	gtypes276,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets276,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DATE_TIME_DURATION",
	names277,
	types277,
	attr_flags277,
	gtypes277,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets277,
	NULL
},
{
	(long) 3,
	(long) 3,
	"TIME_DURATION",
	names278,
	types278,
	attr_flags278,
	gtypes278,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets278,
	NULL
},
{
	(long) 0,
	(long) 0,
	"COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"I18N_DICTIONARY_ENTRY",
	names280,
	types280,
	attr_flags280,
	gtypes280,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets280,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ERT_APPEND_REGION_MODIFIER",
	names281,
	types281,
	attr_flags281,
	gtypes281,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets281,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ERT_PREPEND_REGION_MODIFIER",
	names282,
	types282,
	attr_flags282,
	gtypes282,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets282,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ABSOLUTE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UNICODE_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REFLECTED_OBJECT",
	names287,
	types287,
	attr_flags287,
	gtypes287,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets287,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INTERNAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_DBG_INTERNAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"REFLECTED_COPY_SEMANTICS_OBJECT",
	names291,
	types291,
	attr_flags291,
	gtypes291,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets291,
	NULL
},
{
	(long) 3,
	(long) 3,
	"REFLECTED_REFERENCE_OBJECT",
	names292,
	types292,
	attr_flags292,
	gtypes292,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets292,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names293,
	types293,
	attr_flags293,
	gtypes293,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets293,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names294,
	types294,
	attr_flags294,
	gtypes294,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets294,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names295,
	types295,
	attr_flags295,
	gtypes295,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets295,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names296,
	types296,
	attr_flags296,
	gtypes296,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets296,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names297,
	types297,
	attr_flags297,
	gtypes297,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets297,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names298,
	types298,
	attr_flags298,
	gtypes298,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets298,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names299,
	types299,
	attr_flags299,
	gtypes299,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets299,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names300,
	types300,
	attr_flags300,
	gtypes300,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets300,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names301,
	types301,
	attr_flags301,
	gtypes301,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets301,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names302,
	types302,
	attr_flags302,
	gtypes302,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets302,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names303,
	types303,
	attr_flags303,
	gtypes303,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets303,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names304,
	types304,
	attr_flags304,
	gtypes304,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets304,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ASSERTION_FILTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_NAMES_HEAP",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"NATIVE_STRING",
	names308,
	types308,
	attr_flags308,
	gtypes308,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets308,
	NULL
},
{
	(long) 5,
	(long) 5,
	"FILE_INFO",
	names309,
	types309,
	attr_flags309,
	gtypes309,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets309,
	NULL
},
{
	(long) 5,
	(long) 5,
	"UNIX_FILE_INFO",
	names310,
	types310,
	attr_flags310,
	gtypes310,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets310,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EXECUTION_ENVIRONMENT",
	names311,
	types311,
	attr_flags311,
	gtypes311,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets311,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ENVIRONMENT_ACCESS",
	names312,
	types312,
	attr_flags312,
	gtypes312,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets312,
	NULL
},
{
	(long) 6,
	(long) 6,
	"DIRECTORY",
	names313,
	types313,
	attr_flags313,
	gtypes313,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets313,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFACTORING_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"ERROR_HANDLER",
	names315,
	types315,
	attr_flags315,
	gtypes315,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets315,
	NULL
},
{
	(long) 1,
	(long) 1,
	"AST_CLICKABLE_VISITOR",
	names316,
	types316,
	attr_flags316,
	gtypes316,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets316,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_DIRECTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INTERNAL_COMPILER_STRING_EXPORTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 11,
	(long) 11,
	"LEAF_AS_LIST",
	names320,
	types320,
	attr_flags320,
	gtypes320,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets320,
	NULL
},
{
	(long) 3,
	(long) 3,
	"FEATURE_ALIAS_NAME",
	names321,
	types321,
	attr_flags321,
	gtypes321,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets321,
	NULL
},
{
	(long) 6,
	(long) 6,
	"AST_FACTORY",
	names322,
	types322,
	attr_flags322,
	gtypes322,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets322,
	NULL
},
{
	(long) 6,
	(long) 6,
	"AST_ROUNDTRIP_LIGHT_FACTORY",
	names323,
	types323,
	attr_flags323,
	gtypes323,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets323,
	NULL
},
{
	(long) 6,
	(long) 6,
	"AST_ROUNDTRIP_FACTORY",
	names324,
	types324,
	attr_flags324,
	gtypes324,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets324,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_ENCODING_CONVERTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"NAMES_HEAP",
	names326,
	types326,
	attr_flags326,
	gtypes326,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets326,
	NULL
},
{
	(long) 8,
	(long) 8,
	"EIFFEL_COMMENT_LINE",
	names327,
	types327,
	attr_flags327,
	gtypes327,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets327,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 17,
	(long) 17,
	"ASCII_UTF8_CONVERSION_FILE_BUFFER",
	names329,
	types329,
	attr_flags329,
	gtypes329,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets329,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_QUEUE_ITERATION_CURSOR",
	names342,
	types342,
	attr_flags342,
	gtypes342,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets342,
	NULL
},
{
	(long) 2,
	(long) 2,
	"SEARCH_TABLE_ITERATION_CURSOR",
	names343,
	types343,
	attr_flags343,
	gtypes343,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets343,
	NULL
},
{
	(long) 2,
	(long) 2,
	"SEARCH_TABLE_ITERATION_CURSOR",
	names344,
	types344,
	attr_flags344,
	gtypes344,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets344,
	NULL
},
{
	(long) 2,
	(long) 2,
	"SEARCH_TABLE_ITERATION_CURSOR",
	names345,
	types345,
	attr_flags345,
	gtypes345,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets345,
	NULL
},
{
	(long) 2,
	(long) 2,
	"FILE_ITERATION_CURSOR",
	names346,
	types346,
	attr_flags346,
	gtypes346,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets346,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"STRING_ITERATION_CURSOR",
	names365,
	types365,
	attr_flags365,
	gtypes365,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets365,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENTS_32",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names397,
	types397,
	attr_flags397,
	gtypes397,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets397,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names398,
	types398,
	attr_flags398,
	gtypes398,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets398,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names399,
	types399,
	attr_flags399,
	gtypes399,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets399,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names400,
	types400,
	attr_flags400,
	gtypes400,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets400,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names401,
	types401,
	attr_flags401,
	gtypes401,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets401,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names402,
	types402,
	attr_flags402,
	gtypes402,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets402,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names403,
	types403,
	attr_flags403,
	gtypes403,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets403,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names404,
	types404,
	attr_flags404,
	gtypes404,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets404,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names405,
	types405,
	attr_flags405,
	gtypes405,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets405,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names406,
	types406,
	attr_flags406,
	gtypes406,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets406,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names407,
	types407,
	attr_flags407,
	gtypes407,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets407,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names408,
	types408,
	attr_flags408,
	gtypes408,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets408,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names409,
	types409,
	attr_flags409,
	gtypes409,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets409,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names410,
	types410,
	attr_flags410,
	gtypes410,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets410,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names411,
	types411,
	attr_flags411,
	gtypes411,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets411,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names412,
	types412,
	attr_flags412,
	gtypes412,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets412,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names413,
	types413,
	attr_flags413,
	gtypes413,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets413,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names414,
	types414,
	attr_flags414,
	gtypes414,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets414,
	NULL
},
{
	(long) 8,
	(long) 7,
	"LINKED_LIST_ITERATION_CURSOR",
	names415,
	types415,
	attr_flags415,
	gtypes415,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets415,
	NULL
},
{
	(long) 8,
	(long) 7,
	"LINKED_LIST_ITERATION_CURSOR",
	names416,
	types416,
	attr_flags416,
	gtypes416,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets416,
	NULL
},
{
	(long) 8,
	(long) 7,
	"LINKED_LIST_ITERATION_CURSOR",
	names417,
	types417,
	attr_flags417,
	gtypes417,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets417,
	NULL
},
{
	(long) 8,
	(long) 7,
	"TWO_WAY_LIST_ITERATION_CURSOR",
	names418,
	types418,
	attr_flags418,
	gtypes418,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets418,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names419,
	types419,
	attr_flags419,
	gtypes419,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets419,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names420,
	types420,
	attr_flags420,
	gtypes420,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets420,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names421,
	types421,
	attr_flags421,
	gtypes421,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets421,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names422,
	types422,
	attr_flags422,
	gtypes422,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets422,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names423,
	types423,
	attr_flags423,
	gtypes423,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets423,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names424,
	types424,
	attr_flags424,
	gtypes424,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets424,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names425,
	types425,
	attr_flags425,
	gtypes425,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets425,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names426,
	types426,
	attr_flags426,
	gtypes426,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets426,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names427,
	types427,
	attr_flags427,
	gtypes427,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets427,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names428,
	types428,
	attr_flags428,
	gtypes428,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets428,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names429,
	types429,
	attr_flags429,
	gtypes429,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets429,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names430,
	types430,
	attr_flags430,
	gtypes430,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets430,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_8_ITERATION_CURSOR",
	names431,
	types431,
	attr_flags431,
	gtypes431,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets431,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names432,
	types432,
	attr_flags432,
	gtypes432,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets432,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names433,
	types433,
	attr_flags433,
	gtypes433,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets433,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names434,
	types434,
	attr_flags434,
	gtypes434,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets434,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names435,
	types435,
	attr_flags435,
	gtypes435,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets435,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names436,
	types436,
	attr_flags436,
	gtypes436,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets436,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names437,
	types437,
	attr_flags437,
	gtypes437,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets437,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names438,
	types438,
	attr_flags438,
	gtypes438,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets438,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names439,
	types439,
	attr_flags439,
	gtypes439,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets439,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names440,
	types440,
	attr_flags440,
	gtypes440,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets440,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names441,
	types441,
	attr_flags441,
	gtypes441,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets441,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names442,
	types442,
	attr_flags442,
	gtypes442,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets442,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names443,
	types443,
	attr_flags443,
	gtypes443,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets443,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_32_ITERATION_CURSOR",
	names444,
	types444,
	attr_flags444,
	gtypes444,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets444,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names445,
	types445,
	attr_flags445,
	gtypes445,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets445,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names446,
	types446,
	attr_flags446,
	gtypes446,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets446,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names447,
	types447,
	attr_flags447,
	gtypes447,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets447,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names448,
	types448,
	attr_flags448,
	gtypes448,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets448,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names449,
	types449,
	attr_flags449,
	gtypes449,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets449,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names450,
	types450,
	attr_flags450,
	gtypes450,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets450,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names451,
	types451,
	attr_flags451,
	gtypes451,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets451,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names452,
	types452,
	attr_flags452,
	gtypes452,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets452,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names453,
	types453,
	attr_flags453,
	gtypes453,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets453,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names454,
	types454,
	attr_flags454,
	gtypes454,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets454,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names455,
	types455,
	attr_flags455,
	gtypes455,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets455,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names456,
	types456,
	attr_flags456,
	gtypes456,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets456,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names457,
	types457,
	attr_flags457,
	gtypes457,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets457,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names458,
	types458,
	attr_flags458,
	gtypes458,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets458,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names459,
	types459,
	attr_flags459,
	gtypes459,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets459,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names460,
	types460,
	attr_flags460,
	gtypes460,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets460,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names461,
	types461,
	attr_flags461,
	gtypes461,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets461,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names462,
	types462,
	attr_flags462,
	gtypes462,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets462,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names463,
	types463,
	attr_flags463,
	gtypes463,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets463,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names464,
	types464,
	attr_flags464,
	gtypes464,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets464,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names465,
	types465,
	attr_flags465,
	gtypes465,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets465,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names466,
	types466,
	attr_flags466,
	gtypes466,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets466,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names467,
	types467,
	attr_flags467,
	gtypes467,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets467,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names468,
	types468,
	attr_flags468,
	gtypes468,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets468,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names470,
	types470,
	attr_flags470,
	gtypes470,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets470,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names471,
	types471,
	attr_flags471,
	gtypes471,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets471,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names472,
	types472,
	attr_flags472,
	gtypes472,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets472,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names473,
	types473,
	attr_flags473,
	gtypes473,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets473,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names474,
	types474,
	attr_flags474,
	gtypes474,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets474,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names475,
	types475,
	attr_flags475,
	gtypes475,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets475,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names476,
	types476,
	attr_flags476,
	gtypes476,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets476,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names477,
	types477,
	attr_flags477,
	gtypes477,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets477,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names478,
	types478,
	attr_flags478,
	gtypes478,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets478,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names479,
	types479,
	attr_flags479,
	gtypes479,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets479,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names480,
	types480,
	attr_flags480,
	gtypes480,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets480,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names481,
	types481,
	attr_flags481,
	gtypes481,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets481,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names482,
	types482,
	attr_flags482,
	gtypes482,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets482,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names483,
	types483,
	attr_flags483,
	gtypes483,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets483,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names484,
	types484,
	attr_flags484,
	gtypes484,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets484,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names485,
	types485,
	attr_flags485,
	gtypes485,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets485,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names486,
	types486,
	attr_flags486,
	gtypes486,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets486,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names487,
	types487,
	attr_flags487,
	gtypes487,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets487,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names488,
	types488,
	attr_flags488,
	gtypes488,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets488,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names489,
	types489,
	attr_flags489,
	gtypes489,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets489,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names490,
	types490,
	attr_flags490,
	gtypes490,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets490,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names491,
	types491,
	attr_flags491,
	gtypes491,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets491,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names492,
	types492,
	attr_flags492,
	gtypes492,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets492,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names493,
	types493,
	attr_flags493,
	gtypes493,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets493,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names494,
	types494,
	attr_flags494,
	gtypes494,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets494,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names495,
	types495,
	attr_flags495,
	gtypes495,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets495,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names496,
	types496,
	attr_flags496,
	gtypes496,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets496,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names497,
	types497,
	attr_flags497,
	gtypes497,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets497,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names498,
	types498,
	attr_flags498,
	gtypes498,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets498,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names499,
	types499,
	attr_flags499,
	gtypes499,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets499,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names500,
	types500,
	attr_flags500,
	gtypes500,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets500,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names501,
	types501,
	attr_flags501,
	gtypes501,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets501,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names502,
	types502,
	attr_flags502,
	gtypes502,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets502,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names503,
	types503,
	attr_flags503,
	gtypes503,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets503,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names504,
	types504,
	attr_flags504,
	gtypes504,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets504,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names505,
	types505,
	attr_flags505,
	gtypes505,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets505,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names506,
	types506,
	attr_flags506,
	gtypes506,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets506,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names507,
	types507,
	attr_flags507,
	gtypes507,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets507,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names508,
	types508,
	attr_flags508,
	gtypes508,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets508,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names509,
	types509,
	attr_flags509,
	gtypes509,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets509,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names510,
	types510,
	attr_flags510,
	gtypes510,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets510,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names511,
	types511,
	attr_flags511,
	gtypes511,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets511,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names512,
	types512,
	attr_flags512,
	gtypes512,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets512,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names513,
	types513,
	attr_flags513,
	gtypes513,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets513,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names514,
	types514,
	attr_flags514,
	gtypes514,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets514,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names515,
	types515,
	attr_flags515,
	gtypes515,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets515,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names516,
	types516,
	attr_flags516,
	gtypes516,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets516,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names517,
	types517,
	attr_flags517,
	gtypes517,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets517,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names518,
	types518,
	attr_flags518,
	gtypes518,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets518,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names519,
	types519,
	attr_flags519,
	gtypes519,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets519,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names520,
	types520,
	attr_flags520,
	gtypes520,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets520,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names521,
	types521,
	attr_flags521,
	gtypes521,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets521,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names522,
	types522,
	attr_flags522,
	gtypes522,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets522,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names523,
	types523,
	attr_flags523,
	gtypes523,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets523,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names524,
	types524,
	attr_flags524,
	gtypes524,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets524,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names525,
	types525,
	attr_flags525,
	gtypes525,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets525,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names526,
	types526,
	attr_flags526,
	gtypes526,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets526,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names527,
	types527,
	attr_flags527,
	gtypes527,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets527,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names528,
	types528,
	attr_flags528,
	gtypes528,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets528,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names529,
	types529,
	attr_flags529,
	gtypes529,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets529,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SET",
	names530,
	types530,
	attr_flags530,
	gtypes530,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets530,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names531,
	types531,
	attr_flags531,
	gtypes531,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets531,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names532,
	types532,
	attr_flags532,
	gtypes532,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets532,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names533,
	types533,
	attr_flags533,
	gtypes533,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets533,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names534,
	types534,
	attr_flags534,
	gtypes534,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets534,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names535,
	types535,
	attr_flags535,
	gtypes535,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets535,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names536,
	types536,
	attr_flags536,
	gtypes536,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets536,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names537,
	types537,
	attr_flags537,
	gtypes537,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets537,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names538,
	types538,
	attr_flags538,
	gtypes538,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets538,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names539,
	types539,
	attr_flags539,
	gtypes539,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets539,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names540,
	types540,
	attr_flags540,
	gtypes540,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets540,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names541,
	types541,
	attr_flags541,
	gtypes541,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets541,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names542,
	types542,
	attr_flags542,
	gtypes542,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets542,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names543,
	types543,
	attr_flags543,
	gtypes543,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets543,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names544,
	types544,
	attr_flags544,
	gtypes544,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets544,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names545,
	types545,
	attr_flags545,
	gtypes545,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets545,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names546,
	types546,
	attr_flags546,
	gtypes546,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets546,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names547,
	types547,
	attr_flags547,
	gtypes547,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets547,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names548,
	types548,
	attr_flags548,
	gtypes548,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets548,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names549,
	types549,
	attr_flags549,
	gtypes549,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets549,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names550,
	types550,
	attr_flags550,
	gtypes550,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets550,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names551,
	types551,
	attr_flags551,
	gtypes551,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets551,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names552,
	types552,
	attr_flags552,
	gtypes552,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets552,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names553,
	types553,
	attr_flags553,
	gtypes553,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets553,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names554,
	types554,
	attr_flags554,
	gtypes554,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets554,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names555,
	types555,
	attr_flags555,
	gtypes555,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets555,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names556,
	types556,
	attr_flags556,
	gtypes556,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets556,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names557,
	types557,
	attr_flags557,
	gtypes557,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets557,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names558,
	types558,
	attr_flags558,
	gtypes558,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets558,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names559,
	types559,
	attr_flags559,
	gtypes559,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets559,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names560,
	types560,
	attr_flags560,
	gtypes560,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets560,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names561,
	types561,
	attr_flags561,
	gtypes561,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets561,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names562,
	types562,
	attr_flags562,
	gtypes562,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets562,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names563,
	types563,
	attr_flags563,
	gtypes563,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets563,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names564,
	types564,
	attr_flags564,
	gtypes564,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets564,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names565,
	types565,
	attr_flags565,
	gtypes565,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets565,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names566,
	types566,
	attr_flags566,
	gtypes566,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets566,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names567,
	types567,
	attr_flags567,
	gtypes567,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets567,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names568,
	types568,
	attr_flags568,
	gtypes568,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets568,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names569,
	types569,
	attr_flags569,
	gtypes569,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets569,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names570,
	types570,
	attr_flags570,
	gtypes570,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets570,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names571,
	types571,
	attr_flags571,
	gtypes571,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets571,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names572,
	types572,
	attr_flags572,
	gtypes572,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets572,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names573,
	types573,
	attr_flags573,
	gtypes573,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets573,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names574,
	types574,
	attr_flags574,
	gtypes574,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets574,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names575,
	types575,
	attr_flags575,
	gtypes575,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets575,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names576,
	types576,
	attr_flags576,
	gtypes576,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets576,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names577,
	types577,
	attr_flags577,
	gtypes577,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets577,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names578,
	types578,
	attr_flags578,
	gtypes578,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets578,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names579,
	types579,
	attr_flags579,
	gtypes579,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets579,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names580,
	types580,
	attr_flags580,
	gtypes580,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets580,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names581,
	types581,
	attr_flags581,
	gtypes581,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets581,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names582,
	types582,
	attr_flags582,
	gtypes582,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets582,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names583,
	types583,
	attr_flags583,
	gtypes583,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets583,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names584,
	types584,
	attr_flags584,
	gtypes584,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets584,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names585,
	types585,
	attr_flags585,
	gtypes585,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets585,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names586,
	types586,
	attr_flags586,
	gtypes586,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets586,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names587,
	types587,
	attr_flags587,
	gtypes587,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets587,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names588,
	types588,
	attr_flags588,
	gtypes588,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets588,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names589,
	types589,
	attr_flags589,
	gtypes589,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets589,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names590,
	types590,
	attr_flags590,
	gtypes590,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets590,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names591,
	types591,
	attr_flags591,
	gtypes591,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets591,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names592,
	types592,
	attr_flags592,
	gtypes592,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets592,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names593,
	types593,
	attr_flags593,
	gtypes593,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets593,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names594,
	types594,
	attr_flags594,
	gtypes594,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets594,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names595,
	types595,
	attr_flags595,
	gtypes595,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets595,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names596,
	types596,
	attr_flags596,
	gtypes596,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets596,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names597,
	types597,
	attr_flags597,
	gtypes597,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets597,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names598,
	types598,
	attr_flags598,
	gtypes598,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets598,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names599,
	types599,
	attr_flags599,
	gtypes599,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets599,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names600,
	types600,
	attr_flags600,
	gtypes600,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets600,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names601,
	types601,
	attr_flags601,
	gtypes601,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets601,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names602,
	types602,
	attr_flags602,
	gtypes602,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets602,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names603,
	types603,
	attr_flags603,
	gtypes603,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets603,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names604,
	types604,
	attr_flags604,
	gtypes604,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets604,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names605,
	types605,
	attr_flags605,
	gtypes605,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets605,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names606,
	types606,
	attr_flags606,
	gtypes606,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets606,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names607,
	types607,
	attr_flags607,
	gtypes607,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets607,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names608,
	types608,
	attr_flags608,
	gtypes608,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets608,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names609,
	types609,
	attr_flags609,
	gtypes609,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets609,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names610,
	types610,
	attr_flags610,
	gtypes610,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets610,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INFINITE",
	names611,
	types611,
	attr_flags611,
	gtypes611,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets611,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COUNTABLE",
	names612,
	types612,
	attr_flags612,
	gtypes612,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets612,
	NULL
},
{
	(long) 2,
	(long) 2,
	"COUNTABLE_SEQUENCE",
	names613,
	types613,
	attr_flags613,
	gtypes613,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets613,
	NULL
},
{
	(long) 2,
	(long) 2,
	"PRIMES",
	names614,
	types614,
	attr_flags614,
	gtypes614,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets614,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names615,
	types615,
	attr_flags615,
	gtypes615,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets615,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names616,
	types616,
	attr_flags616,
	gtypes616,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets616,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names617,
	types617,
	attr_flags617,
	gtypes617,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets617,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names618,
	types618,
	attr_flags618,
	gtypes618,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets618,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names619,
	types619,
	attr_flags619,
	gtypes619,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets619,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names620,
	types620,
	attr_flags620,
	gtypes620,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets620,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names621,
	types621,
	attr_flags621,
	gtypes621,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets621,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names622,
	types622,
	attr_flags622,
	gtypes622,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets622,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names623,
	types623,
	attr_flags623,
	gtypes623,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets623,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names624,
	types624,
	attr_flags624,
	gtypes624,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets624,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names625,
	types625,
	attr_flags625,
	gtypes625,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets625,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names626,
	types626,
	attr_flags626,
	gtypes626,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets626,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names627,
	types627,
	attr_flags627,
	gtypes627,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets627,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names628,
	types628,
	attr_flags628,
	gtypes628,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets628,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names629,
	types629,
	attr_flags629,
	gtypes629,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets629,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names630,
	types630,
	attr_flags630,
	gtypes630,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets630,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names631,
	types631,
	attr_flags631,
	gtypes631,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets631,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names632,
	types632,
	attr_flags632,
	gtypes632,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets632,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names633,
	types633,
	attr_flags633,
	gtypes633,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets633,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names634,
	types634,
	attr_flags634,
	gtypes634,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets634,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names635,
	types635,
	attr_flags635,
	gtypes635,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets635,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names636,
	types636,
	attr_flags636,
	gtypes636,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets636,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names637,
	types637,
	attr_flags637,
	gtypes637,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets637,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names638,
	types638,
	attr_flags638,
	gtypes638,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets638,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names639,
	types639,
	attr_flags639,
	gtypes639,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets639,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names640,
	types640,
	attr_flags640,
	gtypes640,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets640,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names641,
	types641,
	attr_flags641,
	gtypes641,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets641,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names642,
	types642,
	attr_flags642,
	gtypes642,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets642,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names643,
	types643,
	attr_flags643,
	gtypes643,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets643,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names644,
	types644,
	attr_flags644,
	gtypes644,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets644,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names645,
	types645,
	attr_flags645,
	gtypes645,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets645,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names646,
	types646,
	attr_flags646,
	gtypes646,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets646,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names647,
	types647,
	attr_flags647,
	gtypes647,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets647,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names648,
	types648,
	attr_flags648,
	gtypes648,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets648,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names649,
	types649,
	attr_flags649,
	gtypes649,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets649,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names650,
	types650,
	attr_flags650,
	gtypes650,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets650,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DISPENSER",
	names651,
	types651,
	attr_flags651,
	gtypes651,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets651,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DISPENSER",
	names652,
	types652,
	attr_flags652,
	gtypes652,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets652,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DISPENSER",
	names653,
	types653,
	attr_flags653,
	gtypes653,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets653,
	NULL
},
{
	(long) 1,
	(long) 1,
	"QUEUE",
	names654,
	types654,
	attr_flags654,
	gtypes654,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets654,
	NULL
},
{
	(long) 1,
	(long) 1,
	"STACK",
	names655,
	types655,
	attr_flags655,
	gtypes655,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets655,
	NULL
},
{
	(long) 1,
	(long) 1,
	"STACK",
	names656,
	types656,
	attr_flags656,
	gtypes656,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets656,
	NULL
},
{
	(long) 1,
	(long) 1,
	"STACK",
	names657,
	types657,
	attr_flags657,
	gtypes657,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets657,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names658,
	types658,
	attr_flags658,
	gtypes658,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets658,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names659,
	types659,
	attr_flags659,
	gtypes659,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets659,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names660,
	types660,
	attr_flags660,
	gtypes660,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets660,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names661,
	types661,
	attr_flags661,
	gtypes661,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets661,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names662,
	types662,
	attr_flags662,
	gtypes662,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets662,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names663,
	types663,
	attr_flags663,
	gtypes663,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets663,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names664,
	types664,
	attr_flags664,
	gtypes664,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets664,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names665,
	types665,
	attr_flags665,
	gtypes665,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets665,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names666,
	types666,
	attr_flags666,
	gtypes666,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets666,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names667,
	types667,
	attr_flags667,
	gtypes667,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets667,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names668,
	types668,
	attr_flags668,
	gtypes668,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets668,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names669,
	types669,
	attr_flags669,
	gtypes669,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets669,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names670,
	types670,
	attr_flags670,
	gtypes670,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets670,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names671,
	types671,
	attr_flags671,
	gtypes671,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets671,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names672,
	types672,
	attr_flags672,
	gtypes672,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets672,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names673,
	types673,
	attr_flags673,
	gtypes673,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets673,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names674,
	types674,
	attr_flags674,
	gtypes674,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets674,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names675,
	types675,
	attr_flags675,
	gtypes675,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets675,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names676,
	types676,
	attr_flags676,
	gtypes676,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets676,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names677,
	types677,
	attr_flags677,
	gtypes677,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets677,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names678,
	types678,
	attr_flags678,
	gtypes678,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets678,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names679,
	types679,
	attr_flags679,
	gtypes679,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets679,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names680,
	types680,
	attr_flags680,
	gtypes680,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets680,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names681,
	types681,
	attr_flags681,
	gtypes681,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets681,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names694,
	types694,
	attr_flags694,
	gtypes694,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets694,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names695,
	types695,
	attr_flags695,
	gtypes695,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets695,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names696,
	types696,
	attr_flags696,
	gtypes696,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets696,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names697,
	types697,
	attr_flags697,
	gtypes697,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets697,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names698,
	types698,
	attr_flags698,
	gtypes698,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets698,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names699,
	types699,
	attr_flags699,
	gtypes699,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets699,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names700,
	types700,
	attr_flags700,
	gtypes700,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets700,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names701,
	types701,
	attr_flags701,
	gtypes701,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets701,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names702,
	types702,
	attr_flags702,
	gtypes702,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets702,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names703,
	types703,
	attr_flags703,
	gtypes703,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets703,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names704,
	types704,
	attr_flags704,
	gtypes704,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets704,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names705,
	types705,
	attr_flags705,
	gtypes705,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets705,
	NULL
},
{
	(long) 3,
	(long) 3,
	"INTEGER_INTERVAL",
	names706,
	types706,
	attr_flags706,
	gtypes706,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets706,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names707,
	types707,
	attr_flags707,
	gtypes707,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets707,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names708,
	types708,
	attr_flags708,
	gtypes708,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets708,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names709,
	types709,
	attr_flags709,
	gtypes709,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets709,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names710,
	types710,
	attr_flags710,
	gtypes710,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets710,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names711,
	types711,
	attr_flags711,
	gtypes711,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets711,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names712,
	types712,
	attr_flags712,
	gtypes712,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets712,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names713,
	types713,
	attr_flags713,
	gtypes713,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets713,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names714,
	types714,
	attr_flags714,
	gtypes714,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets714,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names715,
	types715,
	attr_flags715,
	gtypes715,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets715,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names716,
	types716,
	attr_flags716,
	gtypes716,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets716,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names717,
	types717,
	attr_flags717,
	gtypes717,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets717,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names718,
	types718,
	attr_flags718,
	gtypes718,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets718,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names719,
	types719,
	attr_flags719,
	gtypes719,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets719,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names720,
	types720,
	attr_flags720,
	gtypes720,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets720,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names721,
	types721,
	attr_flags721,
	gtypes721,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets721,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names722,
	types722,
	attr_flags722,
	gtypes722,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets722,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names723,
	types723,
	attr_flags723,
	gtypes723,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets723,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names724,
	types724,
	attr_flags724,
	gtypes724,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets724,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names725,
	types725,
	attr_flags725,
	gtypes725,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets725,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names726,
	types726,
	attr_flags726,
	gtypes726,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets726,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names727,
	types727,
	attr_flags727,
	gtypes727,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets727,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names728,
	types728,
	attr_flags728,
	gtypes728,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets728,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names729,
	types729,
	attr_flags729,
	gtypes729,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets729,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names730,
	types730,
	attr_flags730,
	gtypes730,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets730,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names731,
	types731,
	attr_flags731,
	gtypes731,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets731,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names732,
	types732,
	attr_flags732,
	gtypes732,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets732,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names733,
	types733,
	attr_flags733,
	gtypes733,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets733,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names734,
	types734,
	attr_flags734,
	gtypes734,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets734,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names735,
	types735,
	attr_flags735,
	gtypes735,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets735,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names736,
	types736,
	attr_flags736,
	gtypes736,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets736,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names737,
	types737,
	attr_flags737,
	gtypes737,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets737,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names738,
	types738,
	attr_flags738,
	gtypes738,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets738,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names739,
	types739,
	attr_flags739,
	gtypes739,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets739,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names740,
	types740,
	attr_flags740,
	gtypes740,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets740,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names741,
	types741,
	attr_flags741,
	gtypes741,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets741,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names742,
	types742,
	attr_flags742,
	gtypes742,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets742,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names743,
	types743,
	attr_flags743,
	gtypes743,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets743,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names744,
	types744,
	attr_flags744,
	gtypes744,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets744,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names745,
	types745,
	attr_flags745,
	gtypes745,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets745,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names746,
	types746,
	attr_flags746,
	gtypes746,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets746,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names747,
	types747,
	attr_flags747,
	gtypes747,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets747,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names748,
	types748,
	attr_flags748,
	gtypes748,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets748,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names749,
	types749,
	attr_flags749,
	gtypes749,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets749,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names750,
	types750,
	attr_flags750,
	gtypes750,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets750,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names751,
	types751,
	attr_flags751,
	gtypes751,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets751,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names752,
	types752,
	attr_flags752,
	gtypes752,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets752,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names753,
	types753,
	attr_flags753,
	gtypes753,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets753,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names754,
	types754,
	attr_flags754,
	gtypes754,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets754,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names755,
	types755,
	attr_flags755,
	gtypes755,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets755,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names756,
	types756,
	attr_flags756,
	gtypes756,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets756,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names757,
	types757,
	attr_flags757,
	gtypes757,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets757,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names758,
	types758,
	attr_flags758,
	gtypes758,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets758,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names759,
	types759,
	attr_flags759,
	gtypes759,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets759,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PART_SORTED_LIST",
	names760,
	types760,
	attr_flags760,
	gtypes760,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets760,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SORTED_LIST",
	names761,
	types761,
	attr_flags761,
	gtypes761,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets761,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names762,
	types762,
	attr_flags762,
	gtypes762,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets762,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names763,
	types763,
	attr_flags763,
	gtypes763,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets763,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names764,
	types764,
	attr_flags764,
	gtypes764,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets764,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names765,
	types765,
	attr_flags765,
	gtypes765,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets765,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names766,
	types766,
	attr_flags766,
	gtypes766,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets766,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names767,
	types767,
	attr_flags767,
	gtypes767,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets767,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names768,
	types768,
	attr_flags768,
	gtypes768,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets768,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names769,
	types769,
	attr_flags769,
	gtypes769,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets769,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names770,
	types770,
	attr_flags770,
	gtypes770,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets770,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names771,
	types771,
	attr_flags771,
	gtypes771,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets771,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names772,
	types772,
	attr_flags772,
	gtypes772,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets772,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names773,
	types773,
	attr_flags773,
	gtypes773,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets773,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_LIST",
	names774,
	types774,
	attr_flags774,
	gtypes774,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets774,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_LIST",
	names775,
	types775,
	attr_flags775,
	gtypes775,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets775,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_LIST",
	names776,
	types776,
	attr_flags776,
	gtypes776,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets776,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_QUEUE",
	names777,
	types777,
	attr_flags777,
	gtypes777,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets777,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_STACK",
	names778,
	types778,
	attr_flags778,
	gtypes778,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets778,
	NULL
},
{
	(long) 8,
	(long) 8,
	"TWO_WAY_LIST",
	names779,
	types779,
	attr_flags779,
	gtypes779,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets779,
	NULL
},
{
	(long) 8,
	(long) 8,
	"SORTED_TWO_WAY_LIST",
	names780,
	types780,
	attr_flags780,
	gtypes780,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets780,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MISMATCH_CORRECTOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_QUEUE",
	names782,
	types782,
	attr_flags782,
	gtypes782,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets782,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DATE_VALUE",
	names783,
	types783,
	attr_flags783,
	gtypes783,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets783,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names784,
	types784,
	attr_flags784,
	gtypes784,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets784,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names785,
	types785,
	attr_flags785,
	gtypes785,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets785,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names786,
	types786,
	attr_flags786,
	gtypes786,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets786,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names787,
	types787,
	attr_flags787,
	gtypes787,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets787,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names788,
	types788,
	attr_flags788,
	gtypes788,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets788,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names789,
	types789,
	attr_flags789,
	gtypes789,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets789,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names790,
	types790,
	attr_flags790,
	gtypes790,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets790,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names791,
	types791,
	attr_flags791,
	gtypes791,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets791,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names792,
	types792,
	attr_flags792,
	gtypes792,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets792,
	NULL
},
{
	(long) 19,
	(long) 19,
	"MISMATCH_INFORMATION",
	names793,
	types793,
	attr_flags793,
	gtypes793,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets793,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names794,
	types794,
	attr_flags794,
	gtypes794,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets794,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names795,
	types795,
	attr_flags795,
	gtypes795,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets795,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names796,
	types796,
	attr_flags796,
	gtypes796,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets796,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names797,
	types797,
	attr_flags797,
	gtypes797,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets797,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names798,
	types798,
	attr_flags798,
	gtypes798,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets798,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names799,
	types799,
	attr_flags799,
	gtypes799,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets799,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names800,
	types800,
	attr_flags800,
	gtypes800,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets800,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names801,
	types801,
	attr_flags801,
	gtypes801,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets801,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names802,
	types802,
	attr_flags802,
	gtypes802,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets802,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names803,
	types803,
	attr_flags803,
	gtypes803,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets803,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names804,
	types804,
	attr_flags804,
	gtypes804,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets804,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names805,
	types805,
	attr_flags805,
	gtypes805,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets805,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CLICK_LIST",
	names806,
	types806,
	attr_flags806,
	gtypes806,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets806,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_STACK",
	names807,
	types807,
	attr_flags807,
	gtypes807,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets807,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_STACK",
	names808,
	types808,
	attr_flags808,
	gtypes808,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets808,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_STACK",
	names809,
	types809,
	attr_flags809,
	gtypes809,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets809,
	NULL
},
{
	(long) 3,
	(long) 3,
	"EIFFEL_COMMENTS",
	names810,
	types810,
	attr_flags810,
	gtypes810,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets810,
	NULL
},
{
	(long) 4,
	(long) 4,
	"INTERACTIVE_LIST",
	names811,
	types811,
	attr_flags811,
	gtypes811,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets811,
	NULL
},
{
	(long) 13,
	(long) 13,
	"ACTION_SEQUENCE",
	names812,
	types812,
	attr_flags812,
	gtypes812,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets812,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONSTRUCT_LIST",
	names813,
	types813,
	attr_flags813,
	gtypes813,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets813,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CONSTRUCT_LIST",
	names814,
	types814,
	attr_flags814,
	gtypes814,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets814,
	NULL
},
{
	(long) 6,
	(long) 6,
	"IDENTIFIER_LIST",
	names815,
	types815,
	attr_flags815,
	gtypes815,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets815,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_INTEGER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"KL_CHARACTER_BUFFER",
	names818,
	types818,
	attr_flags818,
	gtypes818,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets818,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_UNICODE_CHARACTER_BUFFER",
	names819,
	types819,
	attr_flags819,
	gtypes819,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets819,
	NULL
},
{
	(long) 2,
	(long) 2,
	"C_STRING",
	names820,
	types820,
	attr_flags820,
	gtypes820,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets820,
	NULL
},
{
	(long) 13,
	(long) 13,
	"IO_MEDIUM",
	names821,
	types821,
	attr_flags821,
	gtypes821,
	(uint16) 0x5400,
	(void (*)()) 0,
	offsets821,
	NULL
},
{
	(long) 20,
	(long) 19,
	"FILE",
	names822,
	types822,
	attr_flags822,
	gtypes822,
	(uint16) 0x5400,
	(void (*)()) 0,
	offsets822,
	NULL
},
{
	(long) 21,
	(long) 20,
	"RAW_FILE",
	names823,
	types823,
	attr_flags823,
	gtypes823,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets823,
	NULL
},
{
	(long) 23,
	(long) 22,
	"PLAIN_TEXT_FILE",
	names824,
	types824,
	attr_flags824,
	gtypes824,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets824,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_STRING_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_CASE_INSENSITIVE_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_CHARACTER_OUTPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_OUTPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BINARY_OUTPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_OUTPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STDERR_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STDOUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_NULL_TEXT_OUTPUT_STREAM",
	names834,
	types834,
	attr_flags834,
	gtypes834,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets834,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_OUTPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DEBUG_OUTPUT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 9,
	(long) 9,
	"DATE_TIME_CODE",
	names837,
	types837,
	attr_flags837,
	gtypes837,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets837,
	NULL
},
{
	(long) 15,
	(long) 15,
	"RT_DBG_CALL_RECORD",
	names838,
	types838,
	attr_flags838,
	gtypes838,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets838,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ABSTRACT_SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"RT_DBG_VALUE_RECORD",
	names852,
	types852,
	attr_flags852,
	gtypes852,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets852,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names853,
	types853,
	attr_flags853,
	gtypes853,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets853,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names854,
	types854,
	attr_flags854,
	gtypes854,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets854,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names855,
	types855,
	attr_flags855,
	gtypes855,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets855,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names856,
	types856,
	attr_flags856,
	gtypes856,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets856,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names857,
	types857,
	attr_flags857,
	gtypes857,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets857,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names858,
	types858,
	attr_flags858,
	gtypes858,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets858,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names859,
	types859,
	attr_flags859,
	gtypes859,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets859,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names860,
	types860,
	attr_flags860,
	gtypes860,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets860,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names861,
	types861,
	attr_flags861,
	gtypes861,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets861,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names862,
	types862,
	attr_flags862,
	gtypes862,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets862,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names863,
	types863,
	attr_flags863,
	gtypes863,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets863,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names864,
	types864,
	attr_flags864,
	gtypes864,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets864,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names865,
	types865,
	attr_flags865,
	gtypes865,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets865,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names866,
	types866,
	attr_flags866,
	gtypes866,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets866,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names867,
	types867,
	attr_flags867,
	gtypes867,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets867,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names868,
	types868,
	attr_flags868,
	gtypes868,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets868,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names869,
	types869,
	attr_flags869,
	gtypes869,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets869,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names870,
	types870,
	attr_flags870,
	gtypes870,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets870,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names871,
	types871,
	attr_flags871,
	gtypes871,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets871,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names872,
	types872,
	attr_flags872,
	gtypes872,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets872,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names873,
	types873,
	attr_flags873,
	gtypes873,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets873,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names874,
	types874,
	attr_flags874,
	gtypes874,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets874,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names875,
	types875,
	attr_flags875,
	gtypes875,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets875,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names876,
	types876,
	attr_flags876,
	gtypes876,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets876,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names877,
	types877,
	attr_flags877,
	gtypes877,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets877,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names878,
	types878,
	attr_flags878,
	gtypes878,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets878,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names879,
	types879,
	attr_flags879,
	gtypes879,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets879,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names880,
	types880,
	attr_flags880,
	gtypes880,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets880,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names881,
	types881,
	attr_flags881,
	gtypes881,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets881,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names882,
	types882,
	attr_flags882,
	gtypes882,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets882,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names883,
	types883,
	attr_flags883,
	gtypes883,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets883,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names884,
	types884,
	attr_flags884,
	gtypes884,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets884,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names885,
	types885,
	attr_flags885,
	gtypes885,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets885,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names886,
	types886,
	attr_flags886,
	gtypes886,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets886,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names887,
	types887,
	attr_flags887,
	gtypes887,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets887,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names888,
	types888,
	attr_flags888,
	gtypes888,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets888,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names889,
	types889,
	attr_flags889,
	gtypes889,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets889,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names890,
	types890,
	attr_flags890,
	gtypes890,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets890,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names891,
	types891,
	attr_flags891,
	gtypes891,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets891,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names892,
	types892,
	attr_flags892,
	gtypes892,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets892,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names893,
	types893,
	attr_flags893,
	gtypes893,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets893,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names894,
	types894,
	attr_flags894,
	gtypes894,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets894,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names895,
	types895,
	attr_flags895,
	gtypes895,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets895,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names896,
	types896,
	attr_flags896,
	gtypes896,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets896,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names897,
	types897,
	attr_flags897,
	gtypes897,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets897,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NUMERIC",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_ANY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UTF32_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UTF16_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_INTEGER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STRING_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UTF8_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_CHARACTER_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_STDIN_FILE",
	names912,
	types912,
	attr_flags912,
	gtypes912,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets912,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_STRING_INPUT_STREAM",
	names913,
	types913,
	attr_flags913,
	gtypes913,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets913,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_INPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BINARY_INPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_INPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"HASHABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UC_CHARACTER",
	names918,
	types918,
	attr_flags918,
	gtypes918,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets918,
	NULL
},
{
	(long) 5,
	(long) 5,
	"UUID",
	names919,
	types919,
	attr_flags919,
	gtypes919,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets919,
	NULL
},
{
	(long) 3,
	(long) 3,
	"PATH",
	names920,
	types920,
	attr_flags920,
	gtypes920,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets920,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names921,
	types921,
	attr_flags921,
	gtypes921,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets921,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names922,
	types922,
	attr_flags922,
	gtypes922,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets922,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names923,
	types923,
	attr_flags923,
	gtypes923,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets923,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names924,
	types924,
	attr_flags924,
	gtypes924,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets924,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names925,
	types925,
	attr_flags925,
	gtypes925,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets925,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names926,
	types926,
	attr_flags926,
	gtypes926,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets926,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names927,
	types927,
	attr_flags927,
	gtypes927,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets927,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names928,
	types928,
	attr_flags928,
	gtypes928,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets928,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names929,
	types929,
	attr_flags929,
	gtypes929,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets929,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names930,
	types930,
	attr_flags930,
	gtypes930,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets930,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names931,
	types931,
	attr_flags931,
	gtypes931,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets931,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names932,
	types932,
	attr_flags932,
	gtypes932,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets932,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names933,
	types933,
	attr_flags933,
	gtypes933,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets933,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names934,
	types934,
	attr_flags934,
	gtypes934,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets934,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names935,
	types935,
	attr_flags935,
	gtypes935,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets935,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names936,
	types936,
	attr_flags936,
	gtypes936,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets936,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names937,
	types937,
	attr_flags937,
	gtypes937,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets937,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names938,
	types938,
	attr_flags938,
	gtypes938,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets938,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names939,
	types939,
	attr_flags939,
	gtypes939,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets939,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names940,
	types940,
	attr_flags940,
	gtypes940,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets940,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names941,
	types941,
	attr_flags941,
	gtypes941,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets941,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names942,
	types942,
	attr_flags942,
	gtypes942,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets942,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names943,
	types943,
	attr_flags943,
	gtypes943,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets943,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names944,
	types944,
	attr_flags944,
	gtypes944,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets944,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names945,
	types945,
	attr_flags945,
	gtypes945,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets945,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names946,
	types946,
	attr_flags946,
	gtypes946,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets946,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names947,
	types947,
	attr_flags947,
	gtypes947,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets947,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names948,
	types948,
	attr_flags948,
	gtypes948,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets948,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names949,
	types949,
	attr_flags949,
	gtypes949,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets949,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names950,
	types950,
	attr_flags950,
	gtypes950,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets950,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names951,
	types951,
	attr_flags951,
	gtypes951,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets951,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names952,
	types952,
	attr_flags952,
	gtypes952,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets952,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names953,
	types953,
	attr_flags953,
	gtypes953,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets953,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TUPLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64_REF",
	names955,
	types955,
	attr_flags955,
	gtypes955,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets955,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64",
	names956,
	types956,
	attr_flags956,
	gtypes956,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets956,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64",
	names957,
	types957,
	attr_flags957,
	gtypes957,
	(uint16) 0x2309,
	(void (*)()) 0,
	offsets957,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32_REF",
	names958,
	types958,
	attr_flags958,
	gtypes958,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets958,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32",
	names959,
	types959,
	attr_flags959,
	gtypes959,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets959,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32",
	names960,
	types960,
	attr_flags960,
	gtypes960,
	(uint16) 0x2308,
	(void (*)()) 0,
	offsets960,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16_REF",
	names961,
	types961,
	attr_flags961,
	gtypes961,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets961,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16",
	names962,
	types962,
	attr_flags962,
	gtypes962,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets962,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16",
	names963,
	types963,
	attr_flags963,
	gtypes963,
	(uint16) 0x2307,
	(void (*)()) 0,
	offsets963,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8_REF",
	names964,
	types964,
	attr_flags964,
	gtypes964,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets964,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8",
	names965,
	types965,
	attr_flags965,
	gtypes965,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets965,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8",
	names966,
	types966,
	attr_flags966,
	gtypes966,
	(uint16) 0x2306,
	(void (*)()) 0,
	offsets966,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64_REF",
	names967,
	types967,
	attr_flags967,
	gtypes967,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets967,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64",
	names968,
	types968,
	attr_flags968,
	gtypes968,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets968,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64",
	names969,
	types969,
	attr_flags969,
	gtypes969,
	(uint16) 0x230D,
	(void (*)()) 0,
	offsets969,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32_REF",
	names970,
	types970,
	attr_flags970,
	gtypes970,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets970,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32",
	names971,
	types971,
	attr_flags971,
	gtypes971,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets971,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32",
	names972,
	types972,
	attr_flags972,
	gtypes972,
	(uint16) 0x230C,
	(void (*)()) 0,
	offsets972,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16_REF",
	names973,
	types973,
	attr_flags973,
	gtypes973,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets973,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16",
	names974,
	types974,
	attr_flags974,
	gtypes974,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets974,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16",
	names975,
	types975,
	attr_flags975,
	gtypes975,
	(uint16) 0x230B,
	(void (*)()) 0,
	offsets975,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8_REF",
	names976,
	types976,
	attr_flags976,
	gtypes976,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets976,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8",
	names977,
	types977,
	attr_flags977,
	gtypes977,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets977,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8",
	names978,
	types978,
	attr_flags978,
	gtypes978,
	(uint16) 0x230A,
	(void (*)()) 0,
	offsets978,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32_REF",
	names979,
	types979,
	attr_flags979,
	gtypes979,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets979,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32",
	names980,
	types980,
	attr_flags980,
	gtypes980,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets980,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32",
	names981,
	types981,
	attr_flags981,
	gtypes981,
	(uint16) 0x2304,
	(void (*)()) 0,
	offsets981,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64_REF",
	names982,
	types982,
	attr_flags982,
	gtypes982,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets982,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64",
	names983,
	types983,
	attr_flags983,
	gtypes983,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets983,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64",
	names984,
	types984,
	attr_flags984,
	gtypes984,
	(uint16) 0x2303,
	(void (*)()) 0,
	offsets984,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32_REF",
	names985,
	types985,
	attr_flags985,
	gtypes985,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets985,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32",
	names986,
	types986,
	attr_flags986,
	gtypes986,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets986,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32",
	names987,
	types987,
	attr_flags987,
	gtypes987,
	(uint16) 0x230E,
	(void (*)()) 0,
	offsets987,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8_REF",
	names988,
	types988,
	attr_flags988,
	gtypes988,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets988,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8",
	names989,
	types989,
	attr_flags989,
	gtypes989,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets989,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8",
	names990,
	types990,
	attr_flags990,
	gtypes990,
	(uint16) 0x2302,
	(void (*)()) 0,
	offsets990,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN_REF",
	names991,
	types991,
	attr_flags991,
	gtypes991,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets991,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN",
	names992,
	types992,
	attr_flags992,
	gtypes992,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets992,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN",
	names993,
	types993,
	attr_flags993,
	gtypes993,
	(uint16) 0x2301,
	(void (*)()) 0,
	offsets993,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER_REF",
	names994,
	types994,
	attr_flags994,
	gtypes994,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets994,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names995,
	types995,
	attr_flags995,
	gtypes995,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets995,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names996,
	types996,
	attr_flags996,
	gtypes996,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets996,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names997,
	types997,
	attr_flags997,
	gtypes997,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets997,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names998,
	types998,
	attr_flags998,
	gtypes998,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets998,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names999,
	types999,
	attr_flags999,
	gtypes999,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets999,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1000,
	types1000,
	attr_flags1000,
	gtypes1000,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1000,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1001,
	types1001,
	attr_flags1001,
	gtypes1001,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1001,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1002,
	types1002,
	attr_flags1002,
	gtypes1002,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1002,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1003,
	types1003,
	attr_flags1003,
	gtypes1003,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1003,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1004,
	types1004,
	attr_flags1004,
	gtypes1004,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1004,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1005,
	types1005,
	attr_flags1005,
	gtypes1005,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1005,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1006,
	types1006,
	attr_flags1006,
	gtypes1006,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1006,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1007,
	types1007,
	attr_flags1007,
	gtypes1007,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1007,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1008,
	types1008,
	attr_flags1008,
	gtypes1008,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1008,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1009,
	types1009,
	attr_flags1009,
	gtypes1009,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1009,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1010,
	types1010,
	attr_flags1010,
	gtypes1010,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1010,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1011,
	types1011,
	attr_flags1011,
	gtypes1011,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1011,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1012,
	types1012,
	attr_flags1012,
	gtypes1012,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1012,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1013,
	types1013,
	attr_flags1013,
	gtypes1013,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1013,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1014,
	types1014,
	attr_flags1014,
	gtypes1014,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1014,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1015,
	types1015,
	attr_flags1015,
	gtypes1015,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1015,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1016,
	types1016,
	attr_flags1016,
	gtypes1016,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1016,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1017,
	types1017,
	attr_flags1017,
	gtypes1017,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1017,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1018,
	types1018,
	attr_flags1018,
	gtypes1018,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1018,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1019,
	types1019,
	attr_flags1019,
	gtypes1019,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1019,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1020,
	types1020,
	attr_flags1020,
	gtypes1020,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1020,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1021,
	types1021,
	attr_flags1021,
	gtypes1021,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1021,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1022,
	types1022,
	attr_flags1022,
	gtypes1022,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1022,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1023,
	types1023,
	attr_flags1023,
	gtypes1023,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1023,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names1024,
	types1024,
	attr_flags1024,
	gtypes1024,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1024,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER",
	names1025,
	types1025,
	attr_flags1025,
	gtypes1025,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets1025,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER",
	names1026,
	types1026,
	attr_flags1026,
	gtypes1026,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets1026,
	NULL
},
{
	(long) 12,
	(long) 12,
	"ROUTINE",
	names1027,
	types1027,
	attr_flags1027,
	gtypes1027,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1027,
	NULL
},
{
	(long) 12,
	(long) 12,
	"PROCEDURE",
	names1028,
	types1028,
	attr_flags1028,
	gtypes1028,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1028,
	NULL
},
{
	(long) 13,
	(long) 13,
	"FUNCTION",
	names1029,
	types1029,
	attr_flags1029,
	gtypes1029,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1029,
	NULL
},
{
	(long) 13,
	(long) 13,
	"FUNCTION",
	names1030,
	types1030,
	attr_flags1030,
	gtypes1030,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1030,
	NULL
},
{
	(long) 13,
	(long) 13,
	"FUNCTION",
	names1031,
	types1031,
	attr_flags1031,
	gtypes1031,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1031,
	NULL
},
{
	(long) 13,
	(long) 13,
	"PREDICATE",
	names1032,
	types1032,
	attr_flags1032,
	gtypes1032,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1032,
	NULL
},
{
	(long) 2,
	(long) 2,
	"READABLE_STRING_GENERAL",
	names1033,
	types1033,
	attr_flags1033,
	gtypes1033,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1033,
	NULL
},
{
	(long) 2,
	(long) 2,
	"IMMUTABLE_STRING_GENERAL",
	names1034,
	types1034,
	attr_flags1034,
	gtypes1034,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1034,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_GENERAL",
	names1035,
	types1035,
	attr_flags1035,
	gtypes1035,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1035,
	NULL
},
{
	(long) 4,
	(long) 4,
	"READABLE_STRING_8",
	names1036,
	types1036,
	attr_flags1036,
	gtypes1036,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1036,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IMMUTABLE_STRING_8",
	names1037,
	types1037,
	attr_flags1037,
	gtypes1037,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1037,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_8",
	names1038,
	types1038,
	attr_flags1038,
	gtypes1038,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1038,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_STRING",
	names1039,
	types1039,
	attr_flags1039,
	gtypes1039,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1039,
	NULL
},
{
	(long) 4,
	(long) 4,
	"READABLE_STRING_32",
	names1040,
	types1040,
	attr_flags1040,
	gtypes1040,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1040,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IMMUTABLE_STRING_32",
	names1041,
	types1041,
	attr_flags1041,
	gtypes1041,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets1041,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_32",
	names1042,
	types1042,
	attr_flags1042,
	gtypes1042,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1042,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_LANGUAGE_ID",
	names1043,
	types1043,
	attr_flags1043,
	gtypes1043,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1043,
	NULL
},
{
	(long) 6,
	(long) 6,
	"I18N_LOCALE_ID",
	names1044,
	types1044,
	attr_flags1044,
	gtypes1044,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1044,
	NULL
},
{
	(long) 2,
	(long) 2,
	"I18N_LOCALE_MANAGER",
	names1045,
	types1045,
	attr_flags1045,
	gtypes1045,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1045,
	NULL
},
{
	(long) 10,
	(long) 10,
	"SEARCH_TABLE",
	names1046,
	types1046,
	attr_flags1046,
	gtypes1046,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1046,
	NULL
},
{
	(long) 10,
	(long) 10,
	"SEARCH_TABLE",
	names1047,
	types1047,
	attr_flags1047,
	gtypes1047,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1047,
	NULL
},
{
	(long) 10,
	(long) 10,
	"SEARCH_TABLE",
	names1048,
	types1048,
	attr_flags1048,
	gtypes1048,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1048,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 23,
	(long) 22,
	"CONSOLE",
	names1054,
	types1054,
	attr_flags1054,
	gtypes1054,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets1054,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_CLONABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"I18N_FORMATTING_ACTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE_TITLECASE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE_UPPERCASE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE_LOWERCASE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_CTYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ENCODING_DETECTOR",
	names1062,
	types1062,
	attr_flags1062,
	gtypes1062,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1062,
	NULL
},
{
	(long) 4,
	(long) 4,
	"BOM_ENCODING_DETECTOR",
	names1063,
	types1063,
	attr_flags1063,
	gtypes1063,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1063,
	NULL
},
{
	(long) 19,
	(long) 19,
	"ENCODING_DETECTION_FILE_BUFFER",
	names1064,
	types1064,
	attr_flags1064,
	gtypes1064,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1064,
	NULL
},
{
	(long) 4,
	(long) 4,
	"YY_SCANNER",
	names1065,
	types1065,
	attr_flags1065,
	gtypes1065,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1065,
	NULL
},
{
	(long) 22,
	(long) 22,
	"YY_SCANNER_SKELETON",
	names1066,
	types1066,
	attr_flags1066,
	gtypes1066,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1066,
	NULL
},
{
	(long) 38,
	(long) 38,
	"YY_COMPRESSED_SCANNER_SKELETON",
	names1067,
	types1067,
	attr_flags1067,
	gtypes1067,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1067,
	NULL
},
{
	(long) 0,
	(long) 0,
	"FIND_SEPARATOR_FACILITY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 7,
	"DATE_TIME_CODE_STRING",
	names1069,
	types1069,
	attr_flags1069,
	gtypes1069,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1069,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ENCODING_I",
	names1070,
	types1070,
	attr_flags1070,
	gtypes1070,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1070,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ENCODING_IMP",
	names1071,
	types1071,
	attr_flags1071,
	gtypes1071,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1071,
	NULL
},
{
	(long) 3,
	(long) 3,
	"UNICODE_CONVERSION",
	names1072,
	types1072,
	attr_flags1072,
	gtypes1072,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1072,
	NULL
},
{
	(long) 3,
	(long) 3,
	"I18N_HOST_LOCALE_IMP",
	names1073,
	types1073,
	attr_flags1073,
	gtypes1073,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1073,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 11,
	(long) 11,
	"KL_DIRECTORY",
	names1075,
	types1075,
	attr_flags1075,
	gtypes1075,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1075,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_FILE",
	names1076,
	types1076,
	attr_flags1076,
	gtypes1076,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1076,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_OUTPUT_FILE",
	names1077,
	types1077,
	attr_flags1077,
	gtypes1077,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1077,
	NULL
},
{
	(long) 22,
	(long) 21,
	"KL_BINARY_OUTPUT_FILE",
	names1078,
	types1078,
	attr_flags1078,
	gtypes1078,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1078,
	NULL
},
{
	(long) 22,
	(long) 21,
	"KL_UNIX_OUTPUT_FILE",
	names1079,
	types1079,
	attr_flags1079,
	gtypes1079,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1079,
	NULL
},
{
	(long) 22,
	(long) 21,
	"KL_WINDOWS_OUTPUT_FILE",
	names1080,
	types1080,
	attr_flags1080,
	gtypes1080,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1080,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_INPUT_FILE",
	names1081,
	types1081,
	attr_flags1081,
	gtypes1081,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1081,
	NULL
},
{
	(long) 26,
	(long) 25,
	"KL_TEXT_INPUT_FILE",
	names1082,
	types1082,
	attr_flags1082,
	gtypes1082,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1082,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_BINARY_INPUT_FILE",
	names1083,
	types1083,
	attr_flags1083,
	gtypes1083,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1083,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_UNIX_INPUT_FILE",
	names1084,
	types1084,
	attr_flags1084,
	gtypes1084,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1084,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_WINDOWS_INPUT_FILE",
	names1085,
	types1085,
	attr_flags1085,
	gtypes1085,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1085,
	NULL
},
{
	(long) 0,
	(long) 0,
	"LOCALIZED_PRINTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 21,
	(long) 21,
	"I18N_AST_ITERATOR",
	names1087,
	types1087,
	attr_flags1087,
	gtypes1087,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1087,
	NULL
},
{
	(long) 8,
	(long) 8,
	"ROOT_CLASS",
	names1088,
	types1088,
	attr_flags1088,
	gtypes1088,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1088,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_LOCALE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"I18N_FORMAT_STRING_PARSER",
	names1090,
	types1090,
	attr_flags1090,
	gtypes1090,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1090,
	NULL
},
{
	(long) 11,
	(long) 11,
	"RT_DBG_EXECUTION_RECORDER",
	names1091,
	types1091,
	attr_flags1091,
	gtypes1091,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1091,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_UNIX_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_WINDOWS_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_WINDOWS_FILE_SYSTEM_BACKSLASH_ONLY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DATE_VALIDITY_CHECKER",
	names1097,
	types1097,
	attr_flags1097,
	gtypes1097,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1097,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DATE",
	names1098,
	types1098,
	attr_flags1098,
	gtypes1098,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1098,
	NULL
},
{
	(long) 2,
	(long) 2,
	"TIME_VALIDITY_CHECKER",
	names1099,
	types1099,
	attr_flags1099,
	gtypes1099,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1099,
	NULL
},
{
	(long) 2,
	(long) 2,
	"TIME",
	names1100,
	types1100,
	attr_flags1100,
	gtypes1100,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1100,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DATE_TIME_VALIDITY_CHECKER",
	names1101,
	types1101,
	attr_flags1101,
	gtypes1101,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1101,
	NULL
},
{
	(long) 16,
	(long) 16,
	"DATE_TIME_PARSER",
	names1102,
	types1102,
	attr_flags1102,
	gtypes1102,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1102,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DATE_TIME",
	names1103,
	types1103,
	attr_flags1103,
	gtypes1103,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1103,
	NULL
},
{
	(long) 6,
	(long) 6,
	"ERROR",
	names1104,
	types1104,
	attr_flags1104,
	gtypes1104,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1104,
	NULL
},
{
	(long) 6,
	(long) 6,
	"USER_DEFINED_ERROR",
	names1105,
	types1105,
	attr_flags1105,
	gtypes1105,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1105,
	NULL
},
{
	(long) 6,
	(long) 6,
	"WARNING",
	names1106,
	types1106,
	attr_flags1106,
	gtypes1106,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1106,
	NULL
},
{
	(long) 8,
	(long) 8,
	"SYNTAX_WARNING",
	names1107,
	types1107,
	attr_flags1107,
	gtypes1107,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1107,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VALIDITY_ERROR",
	names1108,
	types1108,
	attr_flags1108,
	gtypes1108,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1108,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VVOK",
	names1109,
	types1109,
	attr_flags1109,
	gtypes1109,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1109,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VIIN",
	names1110,
	types1110,
	attr_flags1110,
	gtypes1110,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1110,
	NULL
},
{
	(long) 8,
	(long) 8,
	"SYNTAX_ERROR",
	names1111,
	types1111,
	attr_flags1111,
	gtypes1111,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1111,
	NULL
},
{
	(long) 8,
	(long) 8,
	"BASIC_GEN_TYPE_ERR",
	names1112,
	types1112,
	attr_flags1112,
	gtypes1112,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1112,
	NULL
},
{
	(long) 8,
	(long) 8,
	"STRING_EXTENSION",
	names1113,
	types1113,
	attr_flags1113,
	gtypes1113,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1113,
	NULL
},
{
	(long) 8,
	(long) 8,
	"VERBATIM_STRING_UNCOMPLETED",
	names1114,
	types1114,
	attr_flags1114,
	gtypes1114,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1114,
	NULL
},
{
	(long) 8,
	(long) 8,
	"BAD_CHARACTER",
	names1115,
	types1115,
	attr_flags1115,
	gtypes1115,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1115,
	NULL
},
{
	(long) 8,
	(long) 8,
	"STRING_UNCOMPLETED",
	names1116,
	types1116,
	attr_flags1116,
	gtypes1116,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1116,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PREFIX_INFIX_NAMES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UNICODE_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"EIFFEL_ENV",
	names1119,
	types1119,
	attr_flags1119,
	gtypes1119,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1119,
	NULL
},
{
	(long) 3,
	(long) 3,
	"EC_EIFFEL_LAYOUT",
	names1120,
	types1120,
	attr_flags1120,
	gtypes1120,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1120,
	NULL
},
{
	(long) 0,
	(long) 0,
	"YY_PARSER_TOKENS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 23,
	(long) 23,
	"YY_PARSER_SKELETON",
	names1122,
	types1122,
	attr_flags1122,
	gtypes1122,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1122,
	NULL
},
{
	(long) 15,
	(long) 15,
	"EIFFEL_TOKENS",
	names1123,
	types1123,
	attr_flags1123,
	gtypes1123,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1123,
	NULL
},
{
	(long) 81,
	(long) 81,
	"EIFFEL_SCANNER_SKELETON",
	names1124,
	types1124,
	attr_flags1124,
	gtypes1124,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1124,
	NULL
},
{
	(long) 81,
	(long) 81,
	"EIFFEL_SCANNER",
	names1125,
	types1125,
	attr_flags1125,
	gtypes1125,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1125,
	NULL
},
{
	(long) 165,
	(long) 165,
	"EIFFEL_PARSER_SKELETON",
	names1126,
	types1126,
	attr_flags1126,
	gtypes1126,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1126,
	NULL
},
{
	(long) 705,
	(long) 705,
	"EIFFEL_PARSER",
	names1127,
	types1127,
	attr_flags1127,
	gtypes1127,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1127,
	NULL
},
{
	(long) 0,
	(long) 0,
	"AST_EIFFEL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"NAMED_EXPRESSION_AS",
	names1129,
	types1129,
	attr_flags1129,
	gtypes1129,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1129,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CLIENT_AS",
	names1130,
	types1130,
	attr_flags1130,
	gtypes1130,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1130,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LOCAL_DEC_LIST_AS",
	names1131,
	types1131,
	attr_flags1131,
	gtypes1131,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1131,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EXTERNAL_LANG_AS",
	names1132,
	types1132,
	attr_flags1132,
	gtypes1132,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1132,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CREATE_AS",
	names1133,
	types1133,
	attr_flags1133,
	gtypes1133,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1133,
	NULL
},
{
	(long) 3,
	(long) 3,
	"INDEX_AS",
	names1134,
	types1134,
	attr_flags1134,
	gtypes1134,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1134,
	NULL
},
{
	(long) 6,
	(long) 6,
	"INVARIANT_AS",
	names1135,
	types1135,
	attr_flags1135,
	gtypes1135,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1135,
	NULL
},
{
	(long) 7,
	(long) 7,
	"FORMAL_DEC_AS",
	names1136,
	types1136,
	attr_flags1136,
	gtypes1136,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1136,
	NULL
},
{
	(long) 3,
	(long) 3,
	"INTERVAL_AS",
	names1137,
	types1137,
	attr_flags1137,
	gtypes1137,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1137,
	NULL
},
{
	(long) 8,
	(long) 8,
	"CONVERT_FEAT_AS",
	names1138,
	types1138,
	attr_flags1138,
	gtypes1138,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1138,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ELSIF_AS",
	names1139,
	types1139,
	attr_flags1139,
	gtypes1139,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1139,
	NULL
},
{
	(long) 2,
	(long) 2,
	"EXPORT_ITEM_AS",
	names1140,
	types1140,
	attr_flags1140,
	gtypes1140,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1140,
	NULL
},
{
	(long) 3,
	(long) 3,
	"RENAME_AS",
	names1141,
	types1141,
	attr_flags1141,
	gtypes1141,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1141,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CONSTRAINING_TYPE_AS",
	names1142,
	types1142,
	attr_flags1142,
	gtypes1142,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1142,
	NULL
},
{
	(long) 7,
	(long) 7,
	"PARENT_AS",
	names1143,
	types1143,
	attr_flags1143,
	gtypes1143,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1143,
	NULL
},
{
	(long) 8,
	(long) 8,
	"BODY_AS",
	names1144,
	types1144,
	attr_flags1144,
	gtypes1144,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1144,
	NULL
},
{
	(long) 9,
	(long) 9,
	"ITERATION_AS",
	names1145,
	types1145,
	attr_flags1145,
	gtypes1145,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1145,
	NULL
},
{
	(long) 4,
	(long) 4,
	"FEATURE_CLAUSE_AS",
	names1146,
	types1146,
	attr_flags1146,
	gtypes1146,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1146,
	NULL
},
{
	(long) 4,
	(long) 4,
	"FEATURE_ID_AS",
	names1147,
	types1147,
	attr_flags1147,
	gtypes1147,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1147,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST_DEC_AS",
	names1148,
	types1148,
	attr_flags1148,
	gtypes1148,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1148,
	NULL
},
{
	(long) 3,
	(long) 3,
	"TYPE_DEC_AS",
	names1149,
	types1149,
	attr_flags1149,
	gtypes1149,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1149,
	NULL
},
{
	(long) 2,
	(long) 2,
	"ASSERT_LIST_AS",
	names1150,
	types1150,
	attr_flags1150,
	gtypes1150,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1150,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ENSURE_AS",
	names1151,
	types1151,
	attr_flags1151,
	gtypes1151,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1151,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ENSURE_THEN_AS",
	names1152,
	types1152,
	attr_flags1152,
	gtypes1152,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1152,
	NULL
},
{
	(long) 3,
	(long) 3,
	"REQUIRE_AS",
	names1153,
	types1153,
	attr_flags1153,
	gtypes1153,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1153,
	NULL
},
{
	(long) 4,
	(long) 4,
	"REQUIRE_ELSE_AS",
	names1154,
	types1154,
	attr_flags1154,
	gtypes1154,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1154,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CONTENT_AS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 16,
	(long) 16,
	"ROUTINE_AS",
	names1156,
	types1156,
	attr_flags1156,
	gtypes1156,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1156,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONSTANT_AS",
	names1157,
	types1157,
	attr_flags1157,
	gtypes1157,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1157,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CASE_ABSTRACTION_AS",
	names1158,
	types1158,
	attr_flags1158,
	gtypes1158,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1158,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CASE_EXPRESSION_AS",
	names1159,
	types1159,
	attr_flags1159,
	gtypes1159,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1159,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CASE_AS",
	names1160,
	types1160,
	attr_flags1160,
	gtypes1160,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1160,
	NULL
},
{
	(long) 6,
	(long) 6,
	"INSPECT_ABSTRACTION_AS",
	names1161,
	types1161,
	attr_flags1161,
	gtypes1161,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1161,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CALL_AS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"NESTED_EXPR_AS",
	names1163,
	types1163,
	attr_flags1163,
	gtypes1163,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1163,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ACCESS_AS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"ACCESS_FEAT_AS",
	names1165,
	types1165,
	attr_flags1165,
	gtypes1165,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1165,
	NULL
},
{
	(long) 7,
	(long) 7,
	"ACCESS_INV_AS",
	names1166,
	types1166,
	attr_flags1166,
	gtypes1166,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1166,
	NULL
},
{
	(long) 7,
	(long) 7,
	"ACCESS_ASSERT_AS",
	names1167,
	types1167,
	attr_flags1167,
	gtypes1167,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1167,
	NULL
},
{
	(long) 7,
	(long) 7,
	"ACCESS_ID_AS",
	names1168,
	types1168,
	attr_flags1168,
	gtypes1168,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1168,
	NULL
},
{
	(long) 0,
	(long) 0,
	"FEATURE_SET_AS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ALL_AS",
	names1170,
	types1170,
	attr_flags1170,
	gtypes1170,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1170,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FEATURE_LIST_AS",
	names1171,
	types1171,
	attr_flags1171,
	gtypes1171,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1171,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ROUT_BODY_AS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"EXTERNAL_AS",
	names1173,
	types1173,
	attr_flags1173,
	gtypes1173,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1173,
	NULL
},
{
	(long) 6,
	(long) 6,
	"BUILT_IN_AS",
	names1174,
	types1174,
	attr_flags1174,
	gtypes1174,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1174,
	NULL
},
{
	(long) 2,
	(long) 2,
	"INTERNAL_AS",
	names1175,
	types1175,
	attr_flags1175,
	gtypes1175,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1175,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ONCE_AS",
	names1176,
	types1176,
	attr_flags1176,
	gtypes1176,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1176,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DO_AS",
	names1177,
	types1177,
	attr_flags1177,
	gtypes1177,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1177,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ATTRIBUTE_AS",
	names1178,
	types1178,
	attr_flags1178,
	gtypes1178,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1178,
	NULL
},
{
	(long) 3,
	(long) 3,
	"PARAN_LIST_AS",
	names1179,
	types1179,
	attr_flags1179,
	gtypes1179,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1179,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DELAYED_ACTUAL_LIST_AS",
	names1180,
	types1180,
	attr_flags1180,
	gtypes1180,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1180,
	NULL
},
{
	(long) 3,
	(long) 3,
	"KEY_LIST_AS",
	names1181,
	types1181,
	attr_flags1181,
	gtypes1181,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1181,
	NULL
},
{
	(long) 3,
	(long) 3,
	"FORMAL_ARGU_DEC_LIST_AS",
	names1182,
	types1182,
	attr_flags1182,
	gtypes1182,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1182,
	NULL
},
{
	(long) 6,
	(long) 6,
	"PARAMETER_LIST_AS",
	names1183,
	types1183,
	attr_flags1183,
	gtypes1183,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1183,
	NULL
},
{
	(long) 2,
	(long) 2,
	"INHERIT_CLAUSE_AS",
	names1184,
	types1184,
	attr_flags1184,
	gtypes1184,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1184,
	NULL
},
{
	(long) 2,
	(long) 2,
	"SELECT_CLAUSE_AS",
	names1185,
	types1185,
	attr_flags1185,
	gtypes1185,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1185,
	NULL
},
{
	(long) 2,
	(long) 2,
	"REDEFINE_CLAUSE_AS",
	names1186,
	types1186,
	attr_flags1186,
	gtypes1186,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1186,
	NULL
},
{
	(long) 2,
	(long) 2,
	"UNDEFINE_CLAUSE_AS",
	names1187,
	types1187,
	attr_flags1187,
	gtypes1187,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1187,
	NULL
},
{
	(long) 2,
	(long) 2,
	"EXPORT_CLAUSE_AS",
	names1188,
	types1188,
	attr_flags1188,
	gtypes1188,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1188,
	NULL
},
{
	(long) 2,
	(long) 2,
	"RENAME_CLAUSE_AS",
	names1189,
	types1189,
	attr_flags1189,
	gtypes1189,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1189,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CLICKABLE_AST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"PRECURSOR_AS",
	names1191,
	types1191,
	attr_flags1191,
	gtypes1191,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1191,
	NULL
},
{
	(long) 11,
	(long) 11,
	"TYPE_AS",
	names1192,
	types1192,
	attr_flags1192,
	gtypes1192,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1192,
	NULL
},
{
	(long) 13,
	(long) 13,
	"LIKE_CUR_AS",
	names1193,
	types1193,
	attr_flags1193,
	gtypes1193,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1193,
	NULL
},
{
	(long) 13,
	(long) 13,
	"LIKE_ID_AS",
	names1194,
	types1194,
	attr_flags1194,
	gtypes1194,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1194,
	NULL
},
{
	(long) 12,
	(long) 12,
	"NONE_TYPE_AS",
	names1195,
	types1195,
	attr_flags1195,
	gtypes1195,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1195,
	NULL
},
{
	(long) 13,
	(long) 13,
	"NAMED_TUPLE_TYPE_AS",
	names1196,
	types1196,
	attr_flags1196,
	gtypes1196,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1196,
	NULL
},
{
	(long) 14,
	(long) 14,
	"QUALIFIED_ANCHORED_TYPE_AS",
	names1197,
	types1197,
	attr_flags1197,
	gtypes1197,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1197,
	NULL
},
{
	(long) 16,
	(long) 16,
	"FORMAL_AS",
	names1198,
	types1198,
	attr_flags1198,
	gtypes1198,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1198,
	NULL
},
{
	(long) 14,
	(long) 14,
	"CLASS_TYPE_AS",
	names1199,
	types1199,
	attr_flags1199,
	gtypes1199,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1199,
	NULL
},
{
	(long) 15,
	(long) 15,
	"GENERIC_CLASS_TYPE_AS",
	names1200,
	types1200,
	attr_flags1200,
	gtypes1200,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1200,
	NULL
},
{
	(long) 5,
	(long) 5,
	"EIFFEL_LIST",
	names1201,
	types1201,
	attr_flags1201,
	gtypes1201,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1201,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CLASS_LIST_AS",
	names1202,
	types1202,
	attr_flags1202,
	gtypes1202,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1202,
	NULL
},
{
	(long) 7,
	(long) 7,
	"INDEXING_CLAUSE_AS",
	names1203,
	types1203,
	attr_flags1203,
	gtypes1203,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1203,
	NULL
},
{
	(long) 7,
	(long) 7,
	"LIST_DEC_LIST_AS",
	names1204,
	types1204,
	attr_flags1204,
	gtypes1204,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1204,
	NULL
},
{
	(long) 7,
	(long) 7,
	"TYPE_DEC_LIST_AS",
	names1205,
	types1205,
	attr_flags1205,
	gtypes1205,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1205,
	NULL
},
{
	(long) 6,
	(long) 6,
	"CONVERT_FEAT_LIST_AS",
	names1206,
	types1206,
	attr_flags1206,
	gtypes1206,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1206,
	NULL
},
{
	(long) 5,
	(long) 5,
	"CONSTRAINT_LIST_AS",
	names1207,
	types1207,
	attr_flags1207,
	gtypes1207,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1207,
	NULL
},
{
	(long) 9,
	(long) 9,
	"PARENT_LIST_AS",
	names1208,
	types1208,
	attr_flags1208,
	gtypes1208,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1208,
	NULL
},
{
	(long) 7,
	(long) 7,
	"FORMAL_GENERIC_LIST_AS",
	names1209,
	types1209,
	attr_flags1209,
	gtypes1209,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1209,
	NULL
},
{
	(long) 7,
	(long) 7,
	"TYPE_LIST_AS",
	names1210,
	types1210,
	attr_flags1210,
	gtypes1210,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1210,
	NULL
},
{
	(long) 7,
	(long) 7,
	"LEAF_AS",
	names1211,
	types1211,
	attr_flags1211,
	gtypes1211,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1211,
	NULL
},
{
	(long) 8,
	(long) 8,
	"BREAK_AS",
	names1212,
	types1212,
	attr_flags1212,
	gtypes1212,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1212,
	NULL
},
{
	(long) 8,
	(long) 8,
	"SYMBOL_AS",
	names1213,
	types1213,
	attr_flags1213,
	gtypes1213,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1213,
	NULL
},
{
	(long) 8,
	(long) 8,
	"LEAF_STUB_AS",
	names1214,
	types1214,
	attr_flags1214,
	gtypes1214,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1214,
	NULL
},
{
	(long) 9,
	(long) 9,
	"SYMBOL_STUB_AS",
	names1215,
	types1215,
	attr_flags1215,
	gtypes1215,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1215,
	NULL
},
{
	(long) 8,
	(long) 8,
	"KEYWORD_AS",
	names1216,
	types1216,
	attr_flags1216,
	gtypes1216,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1216,
	NULL
},
{
	(long) 8,
	(long) 8,
	"DEFERRED_AS",
	names1217,
	types1217,
	attr_flags1217,
	gtypes1217,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1217,
	NULL
},
{
	(long) 9,
	(long) 9,
	"KEYWORD_STUB_AS",
	names1218,
	types1218,
	attr_flags1218,
	gtypes1218,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1218,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INSTRUCTION_AS",
	names1219,
	types1219,
	attr_flags1219,
	gtypes1219,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1219,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ASSIGNER_CALL_AS",
	names1220,
	types1220,
	attr_flags1220,
	gtypes1220,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1220,
	NULL
},
{
	(long) 2,
	(long) 2,
	"INSTR_CALL_AS",
	names1221,
	types1221,
	attr_flags1221,
	gtypes1221,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1221,
	NULL
},
{
	(long) 6,
	(long) 6,
	"SEPARATE_INSTRUCTION_AS",
	names1222,
	types1222,
	attr_flags1222,
	gtypes1222,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1222,
	NULL
},
{
	(long) 7,
	(long) 7,
	"GUARD_AS",
	names1223,
	types1223,
	attr_flags1223,
	gtypes1223,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1223,
	NULL
},
{
	(long) 5,
	(long) 5,
	"CHECK_AS",
	names1224,
	types1224,
	attr_flags1224,
	gtypes1224,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1224,
	NULL
},
{
	(long) 6,
	(long) 6,
	"CREATION_AS",
	names1225,
	types1225,
	attr_flags1225,
	gtypes1225,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1225,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DEBUG_AS",
	names1226,
	types1226,
	attr_flags1226,
	gtypes1226,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1226,
	NULL
},
{
	(long) 14,
	(long) 14,
	"LOOP_AS",
	names1227,
	types1227,
	attr_flags1227,
	gtypes1227,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1227,
	NULL
},
{
	(long) 7,
	(long) 7,
	"INSPECT_AS",
	names1228,
	types1228,
	attr_flags1228,
	gtypes1228,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1228,
	NULL
},
{
	(long) 9,
	(long) 9,
	"IF_AS",
	names1229,
	types1229,
	attr_flags1229,
	gtypes1229,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1229,
	NULL
},
{
	(long) 9,
	(long) 9,
	"RETRY_AS",
	names1230,
	types1230,
	attr_flags1230,
	gtypes1230,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1230,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ASSIGN_AS",
	names1231,
	types1231,
	attr_flags1231,
	gtypes1231,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1231,
	NULL
},
{
	(long) 4,
	(long) 4,
	"REVERSE_AS",
	names1232,
	types1232,
	attr_flags1232,
	gtypes1232,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1232,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXPR_AS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OBJECT_TEST_AS",
	names1234,
	types1234,
	attr_flags1234,
	gtypes1234,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1234,
	NULL
},
{
	(long) 5,
	(long) 5,
	"PREDECESSOR_AS",
	names1235,
	types1235,
	attr_flags1235,
	gtypes1235,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1235,
	NULL
},
{
	(long) 9,
	(long) 9,
	"ADDRESS_AS",
	names1236,
	types1236,
	attr_flags1236,
	gtypes1236,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1236,
	NULL
},
{
	(long) 2,
	(long) 2,
	"ADDRESS_CURRENT_AS",
	names1237,
	types1237,
	attr_flags1237,
	gtypes1237,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1237,
	NULL
},
{
	(long) 4,
	(long) 4,
	"EXPR_ADDRESS_AS",
	names1238,
	types1238,
	attr_flags1238,
	gtypes1238,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1238,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EXPR_CALL_AS",
	names1239,
	types1239,
	attr_flags1239,
	gtypes1239,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1239,
	NULL
},
{
	(long) 3,
	(long) 3,
	"PARAN_AS",
	names1240,
	types1240,
	attr_flags1240,
	gtypes1240,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1240,
	NULL
},
{
	(long) 2,
	(long) 2,
	"CONVERTED_EXPR_AS",
	names1241,
	types1241,
	attr_flags1241,
	gtypes1241,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1241,
	NULL
},
{
	(long) 4,
	(long) 4,
	"UN_STRIP_AS",
	names1242,
	types1242,
	attr_flags1242,
	gtypes1242,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1242,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPE_EXPR_AS",
	names1243,
	types1243,
	attr_flags1243,
	gtypes1243,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1243,
	NULL
},
{
	(long) 2,
	(long) 2,
	"ADDRESS_RESULT_AS",
	names1244,
	types1244,
	attr_flags1244,
	gtypes1244,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1244,
	NULL
},
{
	(long) 6,
	(long) 6,
	"INSPECT_EXPRESSION_AS",
	names1245,
	types1245,
	attr_flags1245,
	gtypes1245,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1245,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ELSIF_EXPRESSION_AS",
	names1246,
	types1246,
	attr_flags1246,
	gtypes1246,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1246,
	NULL
},
{
	(long) 8,
	(long) 8,
	"IF_EXPRESSION_AS",
	names1247,
	types1247,
	attr_flags1247,
	gtypes1247,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1247,
	NULL
},
{
	(long) 4,
	(long) 4,
	"CREATION_EXPR_AS",
	names1248,
	types1248,
	attr_flags1248,
	gtypes1248,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1248,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_AS",
	names1249,
	types1249,
	attr_flags1249,
	gtypes1249,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1249,
	NULL
},
{
	(long) 3,
	(long) 3,
	"OPERAND_AS",
	names1250,
	types1250,
	attr_flags1250,
	gtypes1250,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1250,
	NULL
},
{
	(long) 7,
	(long) 7,
	"BRACKET_AS",
	names1251,
	types1251,
	attr_flags1251,
	gtypes1251,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1251,
	NULL
},
{
	(long) 4,
	(long) 4,
	"TUPLE_AS",
	names1252,
	types1252,
	attr_flags1252,
	gtypes1252,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1252,
	NULL
},
{
	(long) 11,
	(long) 11,
	"LOOP_EXPR_AS",
	names1253,
	types1253,
	attr_flags1253,
	gtypes1253,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1253,
	NULL
},
{
	(long) 8,
	(long) 8,
	"CURRENT_AS",
	names1254,
	types1254,
	attr_flags1254,
	gtypes1254,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1254,
	NULL
},
{
	(long) 8,
	(long) 8,
	"RESULT_AS",
	names1255,
	types1255,
	attr_flags1255,
	gtypes1255,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1255,
	NULL
},
{
	(long) 8,
	(long) 8,
	"VOID_AS",
	names1256,
	types1256,
	attr_flags1256,
	gtypes1256,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1256,
	NULL
},
{
	(long) 5,
	(long) 5,
	"TAGGED_AS",
	names1257,
	types1257,
	attr_flags1257,
	gtypes1257,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1257,
	NULL
},
{
	(long) 6,
	(long) 6,
	"VARIANT_AS",
	names1258,
	types1258,
	attr_flags1258,
	gtypes1258,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1258,
	NULL
},
{
	(long) 9,
	(long) 9,
	"ROUTINE_CREATION_AS",
	names1259,
	types1259,
	attr_flags1259,
	gtypes1259,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1259,
	NULL
},
{
	(long) 11,
	(long) 11,
	"AGENT_ROUTINE_CREATION_AS",
	names1260,
	types1260,
	attr_flags1260,
	gtypes1260,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1260,
	NULL
},
{
	(long) 14,
	(long) 14,
	"INLINE_AGENT_CREATION_AS",
	names1261,
	types1261,
	attr_flags1261,
	gtypes1261,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1261,
	NULL
},
{
	(long) 5,
	(long) 5,
	"UNARY_AS",
	names1262,
	types1262,
	attr_flags1262,
	gtypes1262,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1262,
	NULL
},
{
	(long) 5,
	(long) 5,
	"UN_PLUS_AS",
	names1263,
	types1263,
	attr_flags1263,
	gtypes1263,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1263,
	NULL
},
{
	(long) 5,
	(long) 5,
	"UN_OLD_AS",
	names1264,
	types1264,
	attr_flags1264,
	gtypes1264,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1264,
	NULL
},
{
	(long) 5,
	(long) 5,
	"UN_MINUS_AS",
	names1265,
	types1265,
	attr_flags1265,
	gtypes1265,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1265,
	NULL
},
{
	(long) 6,
	(long) 6,
	"UN_FREE_AS",
	names1266,
	types1266,
	attr_flags1266,
	gtypes1266,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1266,
	NULL
},
{
	(long) 5,
	(long) 5,
	"UN_NOT_AS",
	names1267,
	types1267,
	attr_flags1267,
	gtypes1267,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1267,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ATOMIC_AS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"CUSTOM_ATTRIBUTE_AS",
	names1269,
	types1269,
	attr_flags1269,
	gtypes1269,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1269,
	NULL
},
{
	(long) 9,
	(long) 9,
	"STATIC_ACCESS_AS",
	names1270,
	types1270,
	attr_flags1270,
	gtypes1270,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1270,
	NULL
},
{
	(long) 9,
	(long) 9,
	"BOOL_AS",
	names1271,
	types1271,
	attr_flags1271,
	gtypes1271,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1271,
	NULL
},
{
	(long) 8,
	(long) 8,
	"UNIQUE_AS",
	names1272,
	types1272,
	attr_flags1272,
	gtypes1272,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1272,
	NULL
},
{
	(long) 10,
	(long) 10,
	"REAL_AS",
	names1273,
	types1273,
	attr_flags1273,
	gtypes1273,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1273,
	NULL
},
{
	(long) 14,
	(long) 14,
	"INTEGER_AS",
	names1274,
	types1274,
	attr_flags1274,
	gtypes1274,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1274,
	NULL
},
{
	(long) 8,
	(long) 8,
	"ID_AS",
	names1275,
	types1275,
	attr_flags1275,
	gtypes1275,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1275,
	NULL
},
{
	(long) 8,
	(long) 8,
	"NONE_ID_AS",
	names1276,
	types1276,
	attr_flags1276,
	gtypes1276,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1276,
	NULL
},
{
	(long) 9,
	(long) 9,
	"CHAR_AS",
	names1277,
	types1277,
	attr_flags1277,
	gtypes1277,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1277,
	NULL
},
{
	(long) 10,
	(long) 10,
	"TYPED_CHAR_AS",
	names1278,
	types1278,
	attr_flags1278,
	gtypes1278,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1278,
	NULL
},
{
	(long) 12,
	(long) 12,
	"STRING_AS",
	names1279,
	types1279,
	attr_flags1279,
	gtypes1279,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1279,
	NULL
},
{
	(long) 15,
	(long) 15,
	"VERBATIM_STRING_AS",
	names1280,
	types1280,
	attr_flags1280,
	gtypes1280,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1280,
	NULL
},
{
	(long) 6,
	(long) 6,
	"BINARY_AS",
	names1281,
	types1281,
	attr_flags1281,
	gtypes1281,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1281,
	NULL
},
{
	(long) 6,
	(long) 6,
	"BIN_AND_AS",
	names1282,
	types1282,
	attr_flags1282,
	gtypes1282,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1282,
	NULL
},
{
	(long) 6,
	(long) 6,
	"BIN_XOR_AS",
	names1283,
	types1283,
	attr_flags1283,
	gtypes1283,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1283,
	NULL
},
{
	(long) 7,
	(long) 7,
	"BIN_OR_ELSE_AS",
	names1284,
	types1284,
	attr_flags1284,
	gtypes1284,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1284,
	NULL
},
{
	(long) 6,
	(long) 6,
	"BIN_OR_AS",
	names1285,
	types1285,
	attr_flags1285,
	gtypes1285,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1285,
	NULL
},
{
	(long) 6,
	(long) 6,
	"BIN_IMPLIES_AS",
	names1286,
	types1286,
	attr_flags1286,
	gtypes1286,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1286,
	NULL
},
{
	(long) 7,
	(long) 7,
	"BIN_FREE_AS",
	names1287,
	types1287,
	attr_flags1287,
	gtypes1287,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1287,
	NULL
},
{
	(long) 7,
	(long) 7,
	"BIN_AND_THEN_AS",
	names1288,
	types1288,
	attr_flags1288,
	gtypes1288,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1288,
	NULL
},
{
	(long) 6,
	(long) 6,
	"BIN_EQ_AS",
	names1289,
	types1289,
	attr_flags1289,
	gtypes1289,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1289,
	NULL
},
{
	(long) 6,
	(long) 6,
	"BIN_TILDE_AS",
	names1290,
	types1290,
	attr_flags1290,
	gtypes1290,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1290,
	NULL
},
{
	(long) 6,
	(long) 6,
	"BIN_NE_AS",
	names1291,
	types1291,
	attr_flags1291,
	gtypes1291,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1291,
	NULL
},
{
	(long) 6,
	(long) 6,
	"BIN_NOT_TILDE_AS",
	names1292,
	types1292,
	attr_flags1292,
	gtypes1292,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1292,
	NULL
},
{
	(long) 6,
	(long) 6,
	"COMPARISON_AS",
	names1293,
	types1293,
	attr_flags1293,
	gtypes1293,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1293,
	NULL
},
{
	(long) 6,
	(long) 6,
	"BIN_LT_AS",
	names1294,
	types1294,
	attr_flags1294,
	gtypes1294,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1294,
	NULL
},
{
	(long) 6,
	(long) 6,
	"BIN_LE_AS",
	names1295,
	types1295,
	attr_flags1295,
	gtypes1295,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1295,
	NULL
},
{
	(long) 6,
	(long) 6,
	"BIN_GT_AS",
	names1296,
	types1296,
	attr_flags1296,
	gtypes1296,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1296,
	NULL
},
{
	(long) 6,
	(long) 6,
	"BIN_GE_AS",
	names1297,
	types1297,
	attr_flags1297,
	gtypes1297,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1297,
	NULL
},
{
	(long) 6,
	(long) 6,
	"ARITHMETIC_AS",
	names1298,
	types1298,
	attr_flags1298,
	gtypes1298,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1298,
	NULL
},
{
	(long) 6,
	(long) 6,
	"BIN_STAR_AS",
	names1299,
	types1299,
	attr_flags1299,
	gtypes1299,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1299,
	NULL
},
{
	(long) 6,
	(long) 6,
	"BIN_SLASH_AS",
	names1300,
	types1300,
	attr_flags1300,
	gtypes1300,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1300,
	NULL
},
{
	(long) 6,
	(long) 6,
	"BIN_POWER_AS",
	names1301,
	types1301,
	attr_flags1301,
	gtypes1301,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1301,
	NULL
},
{
	(long) 6,
	(long) 6,
	"BIN_PLUS_AS",
	names1302,
	types1302,
	attr_flags1302,
	gtypes1302,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1302,
	NULL
},
{
	(long) 6,
	(long) 6,
	"BIN_MOD_AS",
	names1303,
	types1303,
	attr_flags1303,
	gtypes1303,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1303,
	NULL
},
{
	(long) 6,
	(long) 6,
	"BIN_MINUS_AS",
	names1304,
	types1304,
	attr_flags1304,
	gtypes1304,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1304,
	NULL
},
{
	(long) 6,
	(long) 6,
	"BIN_DIV_AS",
	names1305,
	types1305,
	attr_flags1305,
	gtypes1305,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1305,
	NULL
},
{
	(long) 45,
	(long) 45,
	"CLASS_AS",
	names1306,
	types1306,
	attr_flags1306,
	gtypes1306,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1306,
	NULL
},
{
	(long) 6,
	(long) 6,
	"FEATURE_AS",
	names1307,
	types1307,
	attr_flags1307,
	gtypes1307,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1307,
	NULL
},
{
	(long) 2,
	(long) 2,
	"FEATURE_NAME",
	names1308,
	types1308,
	attr_flags1308,
	gtypes1308,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1308,
	NULL
},
{
	(long) 7,
	(long) 7,
	"FEATURE_NAME_ALIAS_AS",
	names1309,
	types1309,
	attr_flags1309,
	gtypes1309,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1309,
	NULL
},
{
	(long) 6,
	(long) 6,
	"ENCODING_CONVERTER",
	names1310,
	types1310,
	attr_flags1310,
	gtypes1310,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1310,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_PATHNAME",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"KL_PATHNAME",
	names1312,
	types1312,
	attr_flags1312,
	gtypes1312,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1312,
	NULL
},
{
	(long) 8,
	(long) 8,
	"UC_STRING",
	names1313,
	types1313,
	attr_flags1313,
	gtypes1313,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1313,
	NULL
},
{
	(long) 8,
	(long) 8,
	"UC_UTF8_STRING",
	names1314,
	types1314,
	attr_flags1314,
	gtypes1314,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1314,
	NULL
},};


#ifdef __cplusplus
}
#endif
