#ifndef _estructure_h_
#define _estructure_h_

#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif

struct eif_ex_33 {union overhead overhead; char data [1];};
struct eif_ex_41 {union overhead overhead; char data [1];};
struct eif_ex_45 {union overhead overhead; char data [1];};
struct eif_ex_330 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,0,1,0)];};
struct eif_ex_333 {union overhead overhead; char data [@OBJSIZ(0,0,0,1,0,0,0,0)];};
struct eif_ex_336 {union overhead overhead; char data [@OBJSIZ(0,0,1,0,0,0,0,0)];};
struct eif_ex_339 {union overhead overhead; char data [@OBJSIZ(0,1,0,0,0,0,0,0)];};
struct eif_ex_342 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,0,1,0)];};
struct eif_ex_345 {union overhead overhead; char data [@OBJSIZ(0,0,0,1,0,0,0,0)];};
struct eif_ex_348 {union overhead overhead; char data [@OBJSIZ(0,0,1,0,0,0,0,0)];};
struct eif_ex_351 {union overhead overhead; char data [@OBJSIZ(0,1,0,0,0,0,0,0)];};
struct eif_ex_354 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,1,0,0,0)];};
struct eif_ex_357 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,0,0,1)];};
struct eif_ex_360 {union overhead overhead; char data [@OBJSIZ(0,0,0,1,0,0,0,0)];};
struct eif_ex_363 {union overhead overhead; char data [@OBJSIZ(0,1,0,0,0,0,0,0)];};
struct eif_ex_366 {union overhead overhead; char data [@OBJSIZ(0,1,0,0,0,0,0,0)];};
struct eif_ex_642 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_743 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_747 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_751 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_924 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_928 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_932 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_943 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_947 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_953 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1218 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1228 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1231 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1234 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_1237 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_369 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};

#ifdef __cplusplus
}
#endif
#endif
