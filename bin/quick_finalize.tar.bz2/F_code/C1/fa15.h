
#ifndef _C1_fa15_
#define _C1_fa15_

#ifdef __cplusplus
extern "C" {
#endif

extern void F27_491(EIF_REFERENCE, EIF_REFERENCE);
extern void F27_493(EIF_REFERENCE);
extern void EIF_Minit15(void);
extern EIF_REFERENCE F1_24(EIF_REFERENCE);
extern void F142_1734(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN);
extern EIF_REFERENCE F571_2642(EIF_REFERENCE, EIF_INTEGER_32);
extern void F142_1735(EIF_REFERENCE);
extern EIF_INTEGER_32 F571_2649(EIF_REFERENCE);
extern void F26_442(EIF_REFERENCE, EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,24)

#ifdef __cplusplus
}
#endif

#endif
