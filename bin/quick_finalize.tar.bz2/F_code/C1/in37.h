
#ifndef _C1_in37_
#define _C1_in37_

#ifdef __cplusplus
extern "C" {
#endif

extern void F55_787(EIF_REFERENCE);
extern EIF_BOOLEAN F55_788(EIF_REFERENCE, EIF_NATURAL_64, EIF_NATURAL_64, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit37(void);
extern void F556_2568(EIF_REFERENCE, EIF_NATURAL_64);

#ifdef __cplusplus
}
#endif

#endif
