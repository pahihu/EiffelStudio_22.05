
#ifndef _C1_st14_
#define _C1_st14_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,412)
static EIF_REFERENCE F26_412_body(EIF_REFERENCE);
extern EIF_REFERENCE F26_412(EIF_REFERENCE);
extern EIF_REFERENCE F26_415(EIF_REFERENCE);
extern void F26_439(EIF_REFERENCE);
extern void F26_442(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit14(void);
extern void F777_4842(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R1139[])();

#ifdef __cplusplus
}
#endif

#endif
