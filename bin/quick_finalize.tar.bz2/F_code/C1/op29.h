
#ifndef _C1_op29_
#define _C1_op29_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_CHARACTER_8,699)
static EIF_CHARACTER_8 F47_699_body(EIF_REFERENCE);
extern EIF_CHARACTER_8 F47_699(EIF_REFERENCE);
extern EIF_CHARACTER_8 F47_704(EIF_REFERENCE);
extern void EIF_Minit29(void);

#ifdef __cplusplus
}
#endif

#endif
