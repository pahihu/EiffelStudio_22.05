
#ifndef _C1_st38_
#define _C1_st38_

#ifdef __cplusplus
extern "C" {
#endif

extern void F56_804(EIF_REFERENCE, EIF_BOOLEAN);
extern void F56_805(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit38(void);

#ifdef __cplusplus
}
#endif

#endif
