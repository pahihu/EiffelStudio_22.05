
#ifndef _C1_is13_
#define _C1_is13_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F13_307(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F13_309(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F13_317(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit13(void);

#ifdef __cplusplus
}
#endif

#endif
