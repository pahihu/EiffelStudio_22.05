
#ifndef _C1_do22_
#define _C1_do22_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REAL_64 F34_550(EIF_REFERENCE, EIF_REAL_64);
extern void EIF_Minit22(void);

#ifdef __cplusplus
}
#endif

#endif
