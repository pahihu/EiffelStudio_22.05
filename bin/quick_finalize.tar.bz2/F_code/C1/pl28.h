
#ifndef _C1_pl28_
#define _C1_pl28_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F46_651(EIF_REFERENCE);
extern void EIF_Minit28(void);

#ifdef __cplusplus
}
#endif

#endif
