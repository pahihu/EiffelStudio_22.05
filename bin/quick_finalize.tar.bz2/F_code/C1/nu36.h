
#ifndef _C1_nu36_
#define _C1_nu36_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_64 F54_765(EIF_REFERENCE);
extern void EIF_Minit36(void);

#ifdef __cplusplus
}
#endif

#endif
