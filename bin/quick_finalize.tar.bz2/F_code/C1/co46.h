
#ifndef _C1_co46_
#define _C1_co46_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F64_911(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F64_912(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F64_913(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F64_916(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F64_917(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit46(void);
extern char *(*R864[])();

#ifdef __cplusplus
}
#endif

#endif
