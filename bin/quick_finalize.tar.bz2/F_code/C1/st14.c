/*
 * Code for class STD_FILES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "st14.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {STD_FILES}.output */
static EIF_REFERENCE F26_412_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("output", 25, Current, 0, 0, 497);
	RTGC;
	RTOSP (412);
#define Result RTOSR(412)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(776, 0x00).id, 776, _OBJSIZ_5_7_2_4_1_1_2_1_);
	tr2 = RTMS_EX_H("stdout",6,1912016244);
	F777_4842(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (412);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F26_412 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(412,F26_412_body,(Current));
}

/* {STD_FILES}.standard_default */
EIF_REFERENCE F26_415 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("standard_default", 25, Current, 0, 0, 500);
	RTGC;
	RTHOOK(1);
	Result = *(EIF_REFERENCE *)(Current);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		RTHOOK(3);
		Result = RTOSCF(412,F26_412, (Current));
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) Result;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {STD_FILES}.set_output_default */
void F26_439 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("set_output_default", 25, Current, 0, 0, 524);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(412,F26_412, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {STD_FILES}.put_string */
void F26_442 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("put_string", 25, Current, 0, 1, 527);
	RTGC;
	RTHOOK(1);
	tr1 = F26_415(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1139[Dtype(RTCW(tr1))-530])(tr1, arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit14 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
