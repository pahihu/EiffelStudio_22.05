/*
 * Code for class OPERATING_ENVIRONMENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "op29.h"
#include "eif_dir.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {OPERATING_ENVIRONMENT}.directory_separator */
static EIF_CHARACTER_8 F47_699_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEAA("directory_separator", 46, Current, 0, 0, 790);
	RTOSP (699);
#define Result RTOSR(699)
	RTHOOK(1);
	Result = (EIF_CHARACTER_8) eif_dir_separator();
	RTOSE (699);
	RTHOOK(2);
	RTEE;
	return Result;
#undef Result
}

EIF_CHARACTER_8 F47_699 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(699,F47_699_body,(Current));
}

/* {OPERATING_ENVIRONMENT}.c_dir_separator */
EIF_CHARACTER_8 F47_704 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("c_dir_separator", 46, Current, 0, 0, 795);Result = (EIF_CHARACTER_8) eif_dir_separator();
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit29 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
