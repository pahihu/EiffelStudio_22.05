
#ifndef _C1_st44_
#define _C1_st44_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F62_903(EIF_REFERENCE);
extern EIF_INTEGER_32 F62_904(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit44(void);
extern char *(*R3497[])();
extern char *(*R3263[])();
extern char *(*R3300[])();

#ifdef __cplusplus
}
#endif

#endif
