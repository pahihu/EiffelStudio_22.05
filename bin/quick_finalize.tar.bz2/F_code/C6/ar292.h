
#ifndef _C6_ar292_
#define _C6_ar292_

#ifdef __cplusplus
extern "C" {
#endif

extern void F635_2825(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F635_2829(EIF_REFERENCE);
extern EIF_REFERENCE F635_2830(EIF_REFERENCE);
extern EIF_REFERENCE F635_2831(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F635_2835(EIF_REFERENCE);
extern EIF_INTEGER_32 F635_2846(EIF_REFERENCE);
extern EIF_INTEGER_32 F635_2847(EIF_REFERENCE);
extern EIF_INTEGER_32 F635_2848(EIF_REFERENCE);
extern EIF_BOOLEAN F635_2849(EIF_REFERENCE, EIF_REFERENCE);
extern void F635_2856(EIF_REFERENCE);
extern void F635_2858(EIF_REFERENCE);
extern void F635_2866(EIF_REFERENCE, EIF_REFERENCE);
extern void F635_2876(EIF_REFERENCE, EIF_REFERENCE);
extern void F635_2886(EIF_REFERENCE);
extern void EIF_Minit292(void);
extern EIF_REFERENCE F633_2792(EIF_REFERENCE);
extern void F633_2791(EIF_REFERENCE);
extern EIF_REFERENCE F647_2897(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F647_2899(EIF_REFERENCE, EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,2792)
extern char *(*R1692[])();
extern char *(*R1693[])();
extern char *(*R1925[])();
extern char *(*R1891[])();
extern char *(*R2163[])();
extern char *(*R2284[])();
extern char *(*R2130[])();
extern char *(*R1442[])();
extern char *(*R2145[])();
extern char *(*R2148[])();
extern char *(*R1918[])();
extern EIF_TYPE_INDEX Y1437[];
extern EIF_TYPE_INDEX *Y1437_gen_type [];
extern EIF_TYPE_INDEX Y1443[];
extern EIF_TYPE_INDEX *Y1443_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
