
#ifndef _C6_ch269_
#define _C6_ch269_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F583_2702(EIF_REFERENCE);
extern EIF_BOOLEAN F583_2710(EIF_REFERENCE);
extern void EIF_Minit269(void);
extern char *(*R1871[])();
extern char *(*R1918[])();

#ifdef __cplusplus
}
#endif

#endif
