
#ifndef _C6_re289_
#define _C6_re289_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F494_2182(EIF_REFERENCE);
extern void EIF_Minit289(void);
extern char *(*R1921[])();

#ifdef __cplusplus
}
#endif

#endif
