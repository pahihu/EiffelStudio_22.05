
#ifndef _C6_li257_
#define _C6_li257_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F349_2090(EIF_REFERENCE);
extern EIF_REFERENCE F349_2097(EIF_REFERENCE);
extern void EIF_Minit257(void);
extern char *(*R1854[])();
extern char *(*R1875[])();

#ifdef __cplusplus
}
#endif

#endif
