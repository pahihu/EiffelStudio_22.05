
#ifndef _C6_li251_
#define _C6_li251_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F607_2734(EIF_REFERENCE);
extern void EIF_Minit251(void);
extern char *(*R1871[])();
extern char *(*R1918[])();

#ifdef __cplusplus
}
#endif

#endif
