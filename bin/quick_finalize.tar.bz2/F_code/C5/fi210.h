
#ifndef _C5_fi210_
#define _C5_fi210_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F469_2169(EIF_REFERENCE);
extern void EIF_Minit210(void);
extern char *(*R1918[])();

#ifdef __cplusplus
}
#endif

#endif
