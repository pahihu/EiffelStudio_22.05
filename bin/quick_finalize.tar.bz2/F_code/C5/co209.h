
#ifndef _C5_co209_
#define _C5_co209_

#ifdef __cplusplus
extern "C" {
#endif

extern void F326_2071(EIF_REFERENCE);
extern void EIF_Minit209(void);
extern long O1856[];

#ifdef __cplusplus
}
#endif

#endif
