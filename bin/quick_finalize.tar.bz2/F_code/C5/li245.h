
#ifndef _C5_li245_
#define _C5_li245_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F608_2734(EIF_REFERENCE);
extern void EIF_Minit245(void);
extern EIF_INTEGER_32 F646_2846(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
