
#ifndef _C5_ch243_
#define _C5_ch243_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F584_2702(EIF_REFERENCE);
extern EIF_BOOLEAN F584_2710(EIF_REFERENCE);
extern void EIF_Minit243(void);
extern EIF_INTEGER_32 F646_2846(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
