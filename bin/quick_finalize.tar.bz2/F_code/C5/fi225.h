
#ifndef _C5_fi225_
#define _C5_fi225_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F470_2169(EIF_REFERENCE);
extern void EIF_Minit225(void);
extern char *(*R1918[])();

#ifdef __cplusplus
}
#endif

#endif
