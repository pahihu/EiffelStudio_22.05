
#ifndef _C5_li226_
#define _C5_li226_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F351_2090(EIF_REFERENCE);
extern EIF_REFERENCE F351_2097(EIF_REFERENCE);
extern void EIF_Minit226(void);
extern char *(*R1854[])();
extern char *(*R1875[])();

#ifdef __cplusplus
}
#endif

#endif
