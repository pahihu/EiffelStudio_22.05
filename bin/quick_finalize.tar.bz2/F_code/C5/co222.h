
#ifndef _C5_co222_
#define _C5_co222_

#ifdef __cplusplus
extern "C" {
#endif

extern void F327_2071(EIF_REFERENCE);
extern void EIF_Minit222(void);
extern long O1856[];

#ifdef __cplusplus
}
#endif

#endif
