
#ifndef _C5_re234_
#define _C5_re234_

#ifdef __cplusplus
extern "C" {
#endif

extern void F258_1984(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F258_1986(EIF_REFERENCE);
extern EIF_INTEGER_32 F258_1987(EIF_REFERENCE);
extern EIF_INTEGER_32 F258_1988(EIF_REFERENCE);
extern EIF_INTEGER_32 F258_1989(EIF_REFERENCE);
extern EIF_BOOLEAN F258_1997(EIF_REFERENCE);
extern EIF_BOOLEAN F258_1998(EIF_REFERENCE);
extern void F258_2003(EIF_REFERENCE);
extern void EIF_Minit234(void);
extern char *(*R2131[])();
extern char *(*R2132[])();

#ifdef __cplusplus
}
#endif

#endif
