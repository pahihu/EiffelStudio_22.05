
#ifndef _C5_re213_
#define _C5_re213_

#ifdef __cplusplus
extern "C" {
#endif

extern void F257_1984(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F257_1986(EIF_REFERENCE);
extern EIF_INTEGER_32 F257_1987(EIF_REFERENCE);
extern EIF_INTEGER_32 F257_1988(EIF_REFERENCE);
extern EIF_INTEGER_32 F257_1989(EIF_REFERENCE);
extern EIF_BOOLEAN F257_1997(EIF_REFERENCE);
extern EIF_BOOLEAN F257_1998(EIF_REFERENCE);
extern void F257_2003(EIF_REFERENCE);
extern void EIF_Minit213(void);
extern char *(*R2131[])();
extern char *(*R2132[])();

#ifdef __cplusplus
}
#endif

#endif
