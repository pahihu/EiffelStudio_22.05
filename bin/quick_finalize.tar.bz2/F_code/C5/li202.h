
#ifndef _C5_li202_
#define _C5_li202_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F350_2090(EIF_REFERENCE);
extern EIF_REFERENCE F350_2097(EIF_REFERENCE);
extern void EIF_Minit202(void);
extern EIF_BOOLEAN F609_2734(EIF_REFERENCE);
extern EIF_BOOLEAN F469_2169(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
