
#ifndef _C5_ce248_
#define _C5_ce248_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F41_642(EIF_REFERENCE);
extern void F41_643(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit248(void);

#ifdef __cplusplus
}
#endif

#endif
