/*
 * Code for class CONTAINER [NATURAL_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co375.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONTAINER}.compare_objects */
void F329_2071 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("compare_objects", 328, Current, 0, 0, 3523);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O1856[Dtype(Current)-324]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	RTEE;
}

void EIF_Minit375 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
