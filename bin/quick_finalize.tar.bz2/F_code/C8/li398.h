
#ifndef _C8_li398_
#define _C8_li398_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F611_2734(EIF_REFERENCE);
extern void EIF_Minit398(void);
extern EIF_INTEGER_32 F638_2846(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
