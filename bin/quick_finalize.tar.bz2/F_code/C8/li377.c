/*
 * Code for class LINEAR [NATURAL_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li377.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LINEAR}.off */
EIF_BOOLEAN F353_2090 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("off", 352, Current, 0, 0, 3687);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	if (!F472_2169(Current)) {
		Result = F611_2734(Current);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {LINEAR}.linear_representation */
EIF_REFERENCE F353_2097 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("linear_representation", 352, Current, 0, 0, 3692);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) Current;
}

void EIF_Minit377 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
