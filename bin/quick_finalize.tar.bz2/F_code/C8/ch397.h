
#ifndef _C8_ch397_
#define _C8_ch397_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F587_2702(EIF_REFERENCE);
extern EIF_BOOLEAN F587_2710(EIF_REFERENCE);
extern void EIF_Minit397(void);
extern EIF_INTEGER_32 F638_2846(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
