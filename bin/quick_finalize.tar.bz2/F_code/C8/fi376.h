
#ifndef _C8_fi376_
#define _C8_fi376_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F472_2169(EIF_REFERENCE);
extern void EIF_Minit376(void);
extern char *(*R1918[])();

#ifdef __cplusplus
}
#endif

#endif
