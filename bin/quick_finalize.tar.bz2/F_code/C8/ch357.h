
#ifndef _C8_ch357_
#define _C8_ch357_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F586_2702(EIF_REFERENCE);
extern EIF_BOOLEAN F586_2710(EIF_REFERENCE);
extern void EIF_Minit357(void);
extern EIF_INTEGER_32 F637_2846(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
