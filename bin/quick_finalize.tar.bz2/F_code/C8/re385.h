
#ifndef _C8_re385_
#define _C8_re385_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F497_2182(EIF_REFERENCE);
extern void EIF_Minit385(void);
extern char *(*R1921[])();

#ifdef __cplusplus
}
#endif

#endif
