
#ifndef _C8_re367_
#define _C8_re367_

#ifdef __cplusplus
extern "C" {
#endif

extern void F260_1984(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F260_1986(EIF_REFERENCE);
extern EIF_INTEGER_32 F260_1987(EIF_REFERENCE);
extern EIF_INTEGER_32 F260_1988(EIF_REFERENCE);
extern EIF_INTEGER_32 F260_1989(EIF_REFERENCE);
extern EIF_BOOLEAN F260_1997(EIF_REFERENCE);
extern EIF_BOOLEAN F260_1998(EIF_REFERENCE);
extern void F260_2003(EIF_REFERENCE);
extern void EIF_Minit367(void);
extern char *(*R2131[])();
extern char *(*R2132[])();

#ifdef __cplusplus
}
#endif

#endif
