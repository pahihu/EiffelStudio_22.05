
#ifndef _C8_co375_
#define _C8_co375_

#ifdef __cplusplus
extern "C" {
#endif

extern void F329_2071(EIF_REFERENCE);
extern void EIF_Minit375(void);
extern long O1856[];

#ifdef __cplusplus
}
#endif

#endif
