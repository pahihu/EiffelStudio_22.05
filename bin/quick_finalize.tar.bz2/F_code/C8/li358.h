
#ifndef _C8_li358_
#define _C8_li358_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F610_2734(EIF_REFERENCE);
extern void EIF_Minit358(void);
extern EIF_INTEGER_32 F637_2846(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
