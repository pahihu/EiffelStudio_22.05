
#ifndef _C8_to363_
#define _C8_to363_

#ifdef __cplusplus
extern "C" {
#endif

extern void F127_1548(EIF_REFERENCE, EIF_INTEGER_32);
extern void F127_1549(EIF_REFERENCE, EIF_NATURAL_8, EIF_INTEGER_32);
extern void F127_1555(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit363(void);
extern void F549_2549(EIF_REFERENCE, EIF_NATURAL_8, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1437[];
extern EIF_TYPE_INDEX *Y1437_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
