
#ifndef _C8_li377_
#define _C8_li377_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F353_2090(EIF_REFERENCE);
extern EIF_REFERENCE F353_2097(EIF_REFERENCE);
extern void EIF_Minit377(void);
extern EIF_BOOLEAN F472_2169(EIF_REFERENCE);
extern EIF_BOOLEAN F611_2734(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
