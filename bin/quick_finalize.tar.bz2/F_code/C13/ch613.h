
#ifndef _C13_ch613_
#define _C13_ch613_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F593_2702(EIF_REFERENCE);
extern EIF_BOOLEAN F593_2710(EIF_REFERENCE);
extern void EIF_Minit613(void);
extern EIF_INTEGER_32 F644_2846(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
