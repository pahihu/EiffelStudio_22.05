
#ifndef _C13_li638_
#define _C13_li638_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F360_2090(EIF_REFERENCE);
extern EIF_REFERENCE F360_2097(EIF_REFERENCE);
extern void EIF_Minit638(void);
extern EIF_BOOLEAN F479_2169(EIF_REFERENCE);
extern EIF_BOOLEAN F618_2734(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
