
#ifndef _C13_to602_
#define _C13_to602_

#ifdef __cplusplus
extern "C" {
#endif

extern void F133_1548(EIF_REFERENCE, EIF_INTEGER_32);
extern void F133_1549(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern void F133_1555(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit602(void);
extern void F555_2549(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1437[];
extern EIF_TYPE_INDEX *Y1437_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
