
#ifndef _C13_li614_
#define _C13_li614_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F617_2734(EIF_REFERENCE);
extern void EIF_Minit614(void);
extern EIF_INTEGER_32 F644_2846(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
