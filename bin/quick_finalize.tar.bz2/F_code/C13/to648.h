
#ifndef _C13_to648_
#define _C13_to648_

#ifdef __cplusplus
extern "C" {
#endif

extern void F134_1548(EIF_REFERENCE, EIF_INTEGER_32);
extern void F134_1549(EIF_REFERENCE, EIF_NATURAL_64, EIF_INTEGER_32);
extern void F134_1555(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit648(void);
extern void F556_2549(EIF_REFERENCE, EIF_NATURAL_64, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1437[];
extern EIF_TYPE_INDEX *Y1437_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
