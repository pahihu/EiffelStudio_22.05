
#ifndef _C13_co636_
#define _C13_co636_

#ifdef __cplusplus
extern "C" {
#endif

extern void F336_2071(EIF_REFERENCE);
extern void EIF_Minit636(void);
extern long O1856[];

#ifdef __cplusplus
}
#endif

#endif
