
#ifndef _C13_re600_
#define _C13_re600_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F503_2182(EIF_REFERENCE);
extern void EIF_Minit600(void);
extern char *(*R1921[])();

#ifdef __cplusplus
}
#endif

#endif
