
#ifndef _C13_fi637_
#define _C13_fi637_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F479_2169(EIF_REFERENCE);
extern void EIF_Minit637(void);
extern char *(*R1918[])();

#ifdef __cplusplus
}
#endif

#endif
