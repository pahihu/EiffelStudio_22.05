
#ifndef _C13_re628_
#define _C13_re628_

#ifdef __cplusplus
extern "C" {
#endif

extern void F267_1984(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F267_1986(EIF_REFERENCE);
extern EIF_INTEGER_32 F267_1987(EIF_REFERENCE);
extern EIF_INTEGER_32 F267_1988(EIF_REFERENCE);
extern EIF_INTEGER_32 F267_1989(EIF_REFERENCE);
extern EIF_BOOLEAN F267_1997(EIF_REFERENCE);
extern EIF_BOOLEAN F267_1998(EIF_REFERENCE);
extern void F267_2003(EIF_REFERENCE);
extern void EIF_Minit628(void);
extern char *(*R2131[])();
extern char *(*R2132[])();

#ifdef __cplusplus
}
#endif

#endif
