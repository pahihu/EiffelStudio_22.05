

#ifdef __cplusplus
extern "C" {
#endif

char *names2 [] =
{
"cache",
"converted_pair",
};

char *names3 [] =
{
"version",
};

char *names6 [] =
{
"code_page",
"encoding_i",
};

char *names10 [] =
{
"flatten_when_closing",
"keep_calls_records",
"recording_values",
"maximum_record_count",
};

char *names26 [] =
{
"default_output",
};

char *names27 [] =
{
"top_directory",
};

char *names29 [] =
{
"root_object",
"on_processing_object_action",
"on_processing_reference_action",
"object_action",
"visited_objects",
"visited_types",
"has_failed",
"has_reference_with_copy_semantics",
"is_skip_transient",
"is_skip_copy_semantics_reference",
"is_exception_on_copy_suppressed",
"is_exception_propagated",
};

char *names30 [] =
{
"root_object",
"on_processing_object_action",
"on_processing_reference_action",
"object_action",
"visited_objects",
"visited_types",
"has_failed",
"has_reference_with_copy_semantics",
"is_skip_transient",
"is_skip_copy_semantics_reference",
"is_exception_on_copy_suppressed",
"is_exception_propagated",
};

char *names40 [] =
{
"item",
};

char *names41 [] =
{
"item",
};

char *names42 [] =
{
"item",
};

char *names43 [] =
{
"item",
};

char *names44 [] =
{
"item",
"right",
};

char *names45 [] =
{
"right",
"item",
};

char *names55 [] =
{
"integer_overflow_state1",
"integer_overflow_state2",
"natural_overflow_state1",
"natural_overflow_state2",
};

char *names56 [] =
{
"leading_separators",
"trailing_separators",
"trailing_separators_acceptable",
"leading_separators_acceptable",
"conversion_type",
"last_state",
"sign",
};

char *names57 [] =
{
"leading_separators",
"trailing_separators",
"internal_lookahead",
"trailing_separators_acceptable",
"leading_separators_acceptable",
"internal_overflowed",
"conversion_type",
"last_state",
"sign",
"part1",
"part2",
};

char *names58 [] =
{
"leading_separators",
"trailing_separators",
"trailing_separators_acceptable",
"leading_separators_acceptable",
"internal_overflowed",
"conversion_type",
"last_state",
"sign",
"part1",
"part2",
};

char *names59 [] =
{
"leading_separators",
"trailing_separators",
"trailing_separators_acceptable",
"leading_separators_acceptable",
"is_negative",
"has_negative_exponent",
"has_fractional_part",
"needs_digit",
"conversion_type",
"last_state",
"sign",
"exponent",
"natural_part",
"fractional_part",
"fractional_divider",
};

char *names60 [] =
{
"deltas",
"deltas_array",
};

char *names61 [] =
{
"deltas",
"deltas_array",
};

char *names62 [] =
{
"deltas",
"deltas_array",
};

char *names66 [] =
{
"managed_data",
"count",
};

char *names68 [] =
{
"active",
"after",
"before",
};

char *names69 [] =
{
"active",
"after",
"before",
};

char *names70 [] =
{
"position",
};

char *names71 [] =
{
"index",
};

char *names74 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names75 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names76 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names77 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names78 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names79 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names80 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names81 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
"error_code",
};

char *names82 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
"signal_code",
};

char *names83 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"exception_information",
"internal_is_ignorable",
"line_number",
"hresult",
"hresult_code",
};

char *names84 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names85 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names86 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names87 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names88 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names89 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
"internal_code",
};

char *names90 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names91 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names92 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names93 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names94 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
"internal_code",
};

char *names95 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names96 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names97 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
"error_code",
"internal_code",
};

char *names98 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names99 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names100 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names101 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names102 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"routine_name",
"class_name",
"internal_is_ignorable",
"line_number",
};

char *names103 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names104 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names105 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names106 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names107 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names108 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names109 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names110 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"is_entry",
"line_number",
};

char *names111 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names112 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names113 [] =
{
"recipient_name",
"type_name",
"throwing_exception",
"c_description",
"internal_trace",
"internal_is_ignorable",
"line_number",
};

char *names115 [] =
{
"is_shared",
"count",
"item",
"counter",
};

char *names116 [] =
{
"last_string",
"last_character",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"last_real",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names118 [] =
{
"dynamic_type",
};

char *names122 [] =
{
"referring_object",
"dynamic_type",
"physical_offset",
"referring_physical_offset",
};

char *names123 [] =
{
"enclosing_object",
"dynamic_type",
"physical_offset",
};

char *names124 [] =
{
"area",
};

char *names125 [] =
{
"area",
};

char *names126 [] =
{
"area",
};

char *names127 [] =
{
"area",
};

char *names128 [] =
{
"area",
};

char *names129 [] =
{
"area",
};

char *names130 [] =
{
"area",
};

char *names131 [] =
{
"area",
};

char *names132 [] =
{
"area",
};

char *names133 [] =
{
"area",
};

char *names134 [] =
{
"area",
};

char *names135 [] =
{
"area",
};

char *names137 [] =
{
"managed_data",
"unit_count",
};

char *names138 [] =
{
"return_code",
};

char *names139 [] =
{
"buffered_file_info",
"internal_file_name",
"internal_name_pointer",
"exists",
"is_following_symlinks",
};

char *names140 [] =
{
"buffered_file_info",
"internal_file_name",
"internal_name_pointer",
"exists",
"is_following_symlinks",
};

char *names141 [] =
{
"lastentry",
"internal_name",
"internal_detachable_name_pointer",
"mode",
"directory_pointer",
"last_entry_pointer",
};

char *names142 [] =
{
"lastentry",
"internal_name",
"internal_detachable_name_pointer",
"object_extension",
"x_files",
"c_files",
"xpp_files",
"cpp_files",
"makefile_sh",
"directories",
"big_file_name_prefix",
"is_root",
"has_finished_file",
"mode",
"directory_pointer",
"last_entry_pointer",
};

char *names144 [] =
{
"recorder",
"object",
"breakable_info",
"parent",
"steps",
"call_records",
"value_records",
"last_position",
"rt_information_available",
"is_expanded",
"is_flat",
"is_closed",
"class_type_id",
"feature_rout_id",
"depth",
};

char *names146 [] =
{
"breakable_info",
"position",
"type",
};

char *names147 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names148 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names149 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names150 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names151 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names152 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names153 [] =
{
"breakable_info",
"object",
"index",
"type",
"value",
};

char *names154 [] =
{
"breakable_info",
"object",
"index",
"type",
"value",
};

char *names155 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names156 [] =
{
"breakable_info",
"object",
"index",
"type",
"value",
};

char *names157 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names158 [] =
{
"breakable_info",
"object",
"value",
"index",
"type",
};

char *names159 [] =
{
"breakable_info",
"object",
"index",
"type",
"value",
};

char *names160 [] =
{
"breakable_info",
"object",
"index",
"type",
"value",
};

char *names161 [] =
{
"breakable_info",
"object",
"index",
"type",
"value",
};

char *names162 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names163 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names164 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names165 [] =
{
"breakable_info",
"rt_type",
"position",
"type",
"callstack_depth",
"value",
};

char *names166 [] =
{
"breakable_info",
"rt_type",
"position",
"type",
"value",
"callstack_depth",
};

char *names167 [] =
{
"breakable_info",
"rt_type",
"position",
"type",
"callstack_depth",
"value",
};

char *names168 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names169 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names170 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names171 [] =
{
"breakable_info",
"rt_type",
"position",
"type",
"callstack_depth",
"value",
};

char *names172 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names173 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names174 [] =
{
"breakable_info",
"rt_type",
"position",
"type",
"callstack_depth",
"value",
};

char *names175 [] =
{
"breakable_info",
"value",
"rt_type",
"position",
"type",
"callstack_depth",
};

char *names176 [] =
{
"breakable_info",
"rt_type",
"position",
"type",
"callstack_depth",
"value",
};

char *names177 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names178 [] =
{
"breakable_info",
"object",
"rt_type",
"offset",
"type",
"value",
};

char *names179 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names180 [] =
{
"breakable_info",
"object",
"rt_type",
"offset",
"type",
"value",
};

char *names181 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names182 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names183 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names184 [] =
{
"breakable_info",
"object",
"rt_type",
"offset",
"type",
"value",
};

char *names185 [] =
{
"breakable_info",
"object",
"rt_type",
"offset",
"type",
"value",
};

char *names186 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names187 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names188 [] =
{
"breakable_info",
"object",
"rt_type",
"offset",
"type",
"value",
};

char *names189 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names190 [] =
{
"breakable_info",
"object",
"value",
"rt_type",
"offset",
"type",
};

char *names191 [] =
{
"breakable_info",
"object",
"rt_type",
"offset",
"type",
"value",
};

char *names205 [] =
{
"area",
"area_index",
"remaining_count",
};

char *names206 [] =
{
"byte",
"file_pointer",
};

char *names226 [] =
{
"target",
"target_index",
"start_index",
"end_index",
};

char *names256 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names257 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names258 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names259 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names260 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names261 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names262 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names263 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names264 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names265 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names266 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names267 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names268 [] =
{
"target",
"active",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names269 [] =
{
"target",
"active",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"target_index",
};

char *names270 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"iteration_position",
};

char *names271 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"iteration_position",
};

char *names272 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"iteration_position",
};

char *names273 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"iteration_position",
};

char *names274 [] =
{
"target",
"is_reversed",
"version",
"step",
"last_index",
"first_index",
"iteration_position",
};

char *names275 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names276 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names277 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names278 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names279 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names280 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names281 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names282 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names283 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names284 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names285 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names286 [] =
{
"area",
"area_index",
"area_last_index",
};

char *names287 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names288 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names289 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names290 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names291 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names292 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names293 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names294 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names295 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names296 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names297 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names298 [] =
{
"area",
"target",
"area_index",
"area_last_index",
};

char *names299 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"area_first_index",
};

char *names300 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"area_first_index",
};

char *names301 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names302 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names303 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names304 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names305 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names306 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names307 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names308 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names309 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names310 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names311 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names312 [] =
{
"area",
"target",
"area_index",
"area_last_index",
"first_index",
};

char *names313 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names314 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names315 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names316 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names317 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names318 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names319 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names320 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names321 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names322 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names323 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names324 [] =
{
"target",
"area_index",
"area_last_index",
};

char *names325 [] =
{
"object_comparison",
};

char *names326 [] =
{
"object_comparison",
};

char *names327 [] =
{
"object_comparison",
};

char *names328 [] =
{
"object_comparison",
};

char *names329 [] =
{
"object_comparison",
};

char *names330 [] =
{
"object_comparison",
};

char *names331 [] =
{
"object_comparison",
};

char *names332 [] =
{
"object_comparison",
};

char *names333 [] =
{
"object_comparison",
};

char *names334 [] =
{
"object_comparison",
};

char *names335 [] =
{
"object_comparison",
};

char *names336 [] =
{
"object_comparison",
};

char *names337 [] =
{
"object_comparison",
};

char *names338 [] =
{
"object_comparison",
};

char *names339 [] =
{
"object_comparison",
};

char *names340 [] =
{
"object_comparison",
};

char *names341 [] =
{
"object_comparison",
};

char *names342 [] =
{
"object_comparison",
};

char *names343 [] =
{
"object_comparison",
};

char *names344 [] =
{
"object_comparison",
};

char *names345 [] =
{
"object_comparison",
};

char *names346 [] =
{
"object_comparison",
};

char *names347 [] =
{
"object_comparison",
};

char *names348 [] =
{
"object_comparison",
};

char *names349 [] =
{
"object_comparison",
};

char *names350 [] =
{
"object_comparison",
};

char *names351 [] =
{
"object_comparison",
};

char *names352 [] =
{
"object_comparison",
};

char *names353 [] =
{
"object_comparison",
};

char *names354 [] =
{
"object_comparison",
};

char *names355 [] =
{
"object_comparison",
};

char *names356 [] =
{
"object_comparison",
};

char *names357 [] =
{
"object_comparison",
};

char *names358 [] =
{
"object_comparison",
};

char *names359 [] =
{
"object_comparison",
};

char *names360 [] =
{
"object_comparison",
};

char *names361 [] =
{
"object_comparison",
};

char *names362 [] =
{
"object_comparison",
};

char *names363 [] =
{
"object_comparison",
};

char *names364 [] =
{
"object_comparison",
};

char *names365 [] =
{
"object_comparison",
};

char *names366 [] =
{
"object_comparison",
};

char *names367 [] =
{
"object_comparison",
};

char *names368 [] =
{
"object_comparison",
};

char *names369 [] =
{
"object_comparison",
};

char *names370 [] =
{
"object_comparison",
};

char *names371 [] =
{
"object_comparison",
};

char *names372 [] =
{
"object_comparison",
};

char *names373 [] =
{
"object_comparison",
};

char *names374 [] =
{
"object_comparison",
};

char *names375 [] =
{
"object_comparison",
};

char *names376 [] =
{
"object_comparison",
};

char *names377 [] =
{
"object_comparison",
};

char *names378 [] =
{
"object_comparison",
};

char *names379 [] =
{
"object_comparison",
};

char *names380 [] =
{
"object_comparison",
};

char *names381 [] =
{
"object_comparison",
};

char *names382 [] =
{
"object_comparison",
};

char *names383 [] =
{
"object_comparison",
};

char *names384 [] =
{
"object_comparison",
};

char *names385 [] =
{
"object_comparison",
};

char *names386 [] =
{
"object_comparison",
};

char *names387 [] =
{
"object_comparison",
};

char *names388 [] =
{
"object_comparison",
};

char *names389 [] =
{
"object_comparison",
};

char *names390 [] =
{
"object_comparison",
};

char *names391 [] =
{
"object_comparison",
};

char *names392 [] =
{
"object_comparison",
};

char *names393 [] =
{
"object_comparison",
};

char *names394 [] =
{
"object_comparison",
};

char *names395 [] =
{
"object_comparison",
};

char *names396 [] =
{
"object_comparison",
};

char *names397 [] =
{
"object_comparison",
};

char *names398 [] =
{
"object_comparison",
};

char *names399 [] =
{
"object_comparison",
};

char *names400 [] =
{
"object_comparison",
};

char *names401 [] =
{
"object_comparison",
};

char *names402 [] =
{
"object_comparison",
};

char *names403 [] =
{
"object_comparison",
};

char *names404 [] =
{
"object_comparison",
};

char *names405 [] =
{
"object_comparison",
};

char *names406 [] =
{
"object_comparison",
};

char *names407 [] =
{
"object_comparison",
};

char *names408 [] =
{
"object_comparison",
};

char *names409 [] =
{
"object_comparison",
};

char *names410 [] =
{
"object_comparison",
};

char *names411 [] =
{
"object_comparison",
};

char *names412 [] =
{
"object_comparison",
};

char *names413 [] =
{
"object_comparison",
};

char *names414 [] =
{
"object_comparison",
};

char *names415 [] =
{
"object_comparison",
};

char *names416 [] =
{
"object_comparison",
};

char *names417 [] =
{
"object_comparison",
};

char *names418 [] =
{
"object_comparison",
};

char *names419 [] =
{
"object_comparison",
};

char *names420 [] =
{
"object_comparison",
};

char *names421 [] =
{
"object_comparison",
};

char *names422 [] =
{
"object_comparison",
};

char *names423 [] =
{
"object_comparison",
};

char *names424 [] =
{
"object_comparison",
};

char *names425 [] =
{
"object_comparison",
};

char *names426 [] =
{
"object_comparison",
};

char *names427 [] =
{
"object_comparison",
};

char *names428 [] =
{
"object_comparison",
};

char *names429 [] =
{
"object_comparison",
};

char *names430 [] =
{
"object_comparison",
};

char *names431 [] =
{
"object_comparison",
};

char *names432 [] =
{
"object_comparison",
};

char *names433 [] =
{
"object_comparison",
};

char *names434 [] =
{
"object_comparison",
};

char *names435 [] =
{
"object_comparison",
};

char *names436 [] =
{
"object_comparison",
};

char *names437 [] =
{
"object_comparison",
};

char *names438 [] =
{
"object_comparison",
};

char *names439 [] =
{
"object_comparison",
};

char *names440 [] =
{
"object_comparison",
};

char *names441 [] =
{
"object_comparison",
};

char *names442 [] =
{
"object_comparison",
};

char *names443 [] =
{
"object_comparison",
};

char *names444 [] =
{
"object_comparison",
};

char *names445 [] =
{
"object_comparison",
};

char *names446 [] =
{
"object_comparison",
};

char *names447 [] =
{
"object_comparison",
};

char *names448 [] =
{
"object_comparison",
};

char *names449 [] =
{
"object_comparison",
};

char *names450 [] =
{
"object_comparison",
};

char *names451 [] =
{
"object_comparison",
};

char *names452 [] =
{
"object_comparison",
};

char *names453 [] =
{
"object_comparison",
};

char *names454 [] =
{
"object_comparison",
};

char *names455 [] =
{
"object_comparison",
};

char *names456 [] =
{
"object_comparison",
};

char *names457 [] =
{
"object_comparison",
};

char *names458 [] =
{
"object_comparison",
};

char *names459 [] =
{
"object_comparison",
};

char *names460 [] =
{
"object_comparison",
};

char *names461 [] =
{
"object_comparison",
};

char *names462 [] =
{
"object_comparison",
};

char *names463 [] =
{
"object_comparison",
};

char *names464 [] =
{
"object_comparison",
};

char *names465 [] =
{
"object_comparison",
};

char *names466 [] =
{
"object_comparison",
"index",
};

char *names467 [] =
{
"object_comparison",
"index",
};

char *names468 [] =
{
"object_comparison",
};

char *names469 [] =
{
"object_comparison",
};

char *names470 [] =
{
"object_comparison",
};

char *names471 [] =
{
"object_comparison",
};

char *names472 [] =
{
"object_comparison",
};

char *names473 [] =
{
"object_comparison",
};

char *names474 [] =
{
"object_comparison",
};

char *names475 [] =
{
"object_comparison",
};

char *names476 [] =
{
"object_comparison",
};

char *names477 [] =
{
"object_comparison",
};

char *names478 [] =
{
"object_comparison",
};

char *names479 [] =
{
"object_comparison",
};

char *names480 [] =
{
"object_comparison",
};

char *names481 [] =
{
"object_comparison",
};

char *names482 [] =
{
"object_comparison",
};

char *names483 [] =
{
"object_comparison",
};

char *names484 [] =
{
"object_comparison",
};

char *names485 [] =
{
"object_comparison",
};

char *names486 [] =
{
"object_comparison",
};

char *names487 [] =
{
"object_comparison",
};

char *names488 [] =
{
"object_comparison",
};

char *names489 [] =
{
"object_comparison",
};

char *names490 [] =
{
"object_comparison",
};

char *names491 [] =
{
"object_comparison",
};

char *names492 [] =
{
"object_comparison",
};

char *names493 [] =
{
"object_comparison",
};

char *names494 [] =
{
"object_comparison",
};

char *names495 [] =
{
"object_comparison",
};

char *names496 [] =
{
"object_comparison",
};

char *names497 [] =
{
"object_comparison",
};

char *names498 [] =
{
"object_comparison",
};

char *names499 [] =
{
"object_comparison",
};

char *names500 [] =
{
"object_comparison",
};

char *names501 [] =
{
"object_comparison",
};

char *names502 [] =
{
"object_comparison",
};

char *names503 [] =
{
"object_comparison",
};

char *names504 [] =
{
"object_comparison",
};

char *names505 [] =
{
"object_comparison",
};

char *names506 [] =
{
"object_comparison",
};

char *names507 [] =
{
"object_comparison",
};

char *names508 [] =
{
"object_comparison",
};

char *names509 [] =
{
"object_comparison",
};

char *names510 [] =
{
"object_comparison",
};

char *names511 [] =
{
"object_comparison",
};

char *names512 [] =
{
"object_comparison",
};

char *names513 [] =
{
"object_comparison",
};

char *names514 [] =
{
"object_comparison",
};

char *names515 [] =
{
"object_comparison",
};

char *names516 [] =
{
"object_comparison",
};

char *names517 [] =
{
"object_comparison",
};

char *names518 [] =
{
"object_comparison",
};

char *names519 [] =
{
"object_comparison",
};

char *names520 [] =
{
"object_comparison",
};

char *names521 [] =
{
"object_comparison",
};

char *names522 [] =
{
"object_comparison",
};

char *names523 [] =
{
"object_comparison",
};

char *names524 [] =
{
"object_comparison",
};

char *names525 [] =
{
"object_comparison",
};

char *names526 [] =
{
"object_comparison",
};

char *names527 [] =
{
"object_comparison",
};

char *names528 [] =
{
"object_comparison",
};

char *names529 [] =
{
"object_comparison",
};

char *names530 [] =
{
"last_string",
"internal_name",
"internal_detachable_name_pointer",
"last_character",
"separator",
"object_comparison",
"descriptor_available",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names531 [] =
{
"last_string",
"internal_name",
"internal_detachable_name_pointer",
"last_string_32",
"internal_encoding",
"last_character",
"separator",
"object_comparison",
"descriptor_available",
"is_sequence_an_expected_numeric",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names532 [] =
{
"last_string",
"internal_name",
"internal_detachable_name_pointer",
"internal_integer_buffer",
"last_character",
"separator",
"object_comparison",
"descriptor_available",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names533 [] =
{
"last_string",
"internal_name",
"internal_detachable_name_pointer",
"internal_integer_buffer",
"last_character",
"separator",
"object_comparison",
"descriptor_available",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names558 [] =
{
"object_comparison",
};

char *names559 [] =
{
"object_comparison",
};

char *names560 [] =
{
"object_comparison",
};

char *names561 [] =
{
"object_comparison",
};

char *names562 [] =
{
"object_comparison",
};

char *names563 [] =
{
"object_comparison",
};

char *names564 [] =
{
"object_comparison",
};

char *names565 [] =
{
"object_comparison",
};

char *names566 [] =
{
"object_comparison",
};

char *names567 [] =
{
"object_comparison",
};

char *names568 [] =
{
"object_comparison",
};

char *names569 [] =
{
"object_comparison",
};

char *names570 [] =
{
"object_comparison",
"upper",
"lower",
};

char *names571 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names572 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names573 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names574 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names575 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names576 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names577 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names578 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names579 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names580 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names581 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names582 [] =
{
"area",
"object_comparison",
"upper",
"lower",
};

char *names583 [] =
{
"object_comparison",
};

char *names584 [] =
{
"object_comparison",
};

char *names585 [] =
{
"object_comparison",
};

char *names586 [] =
{
"object_comparison",
};

char *names587 [] =
{
"object_comparison",
};

char *names588 [] =
{
"object_comparison",
};

char *names589 [] =
{
"object_comparison",
};

char *names590 [] =
{
"object_comparison",
};

char *names591 [] =
{
"object_comparison",
};

char *names592 [] =
{
"object_comparison",
};

char *names593 [] =
{
"object_comparison",
};

char *names594 [] =
{
"object_comparison",
};

char *names595 [] =
{
"object_comparison",
};

char *names596 [] =
{
"object_comparison",
};

char *names597 [] =
{
"object_comparison",
};

char *names598 [] =
{
"object_comparison",
};

char *names599 [] =
{
"object_comparison",
};

char *names600 [] =
{
"object_comparison",
};

char *names601 [] =
{
"object_comparison",
};

char *names602 [] =
{
"object_comparison",
};

char *names603 [] =
{
"object_comparison",
};

char *names604 [] =
{
"object_comparison",
};

char *names605 [] =
{
"object_comparison",
};

char *names606 [] =
{
"object_comparison",
};

char *names607 [] =
{
"object_comparison",
};

char *names608 [] =
{
"object_comparison",
};

char *names609 [] =
{
"object_comparison",
};

char *names610 [] =
{
"object_comparison",
};

char *names611 [] =
{
"object_comparison",
};

char *names612 [] =
{
"object_comparison",
};

char *names613 [] =
{
"object_comparison",
};

char *names614 [] =
{
"object_comparison",
};

char *names615 [] =
{
"object_comparison",
};

char *names616 [] =
{
"object_comparison",
};

char *names617 [] =
{
"object_comparison",
};

char *names618 [] =
{
"object_comparison",
};

char *names619 [] =
{
"object_comparison",
};

char *names620 [] =
{
"object_comparison",
};

char *names621 [] =
{
"object_comparison",
};

char *names622 [] =
{
"object_comparison",
};

char *names623 [] =
{
"object_comparison",
};

char *names624 [] =
{
"object_comparison",
};

char *names625 [] =
{
"object_comparison",
};

char *names626 [] =
{
"object_comparison",
};

char *names627 [] =
{
"object_comparison",
};

char *names628 [] =
{
"object_comparison",
};

char *names629 [] =
{
"object_comparison",
};

char *names630 [] =
{
"object_comparison",
};

char *names631 [] =
{
"first_element",
"active",
"object_comparison",
"before",
"after",
"count",
};

char *names632 [] =
{
"first_element",
"active",
"object_comparison",
"before",
"after",
"count",
};

char *names634 [] =
{
"area",
"object_comparison",
"out_index",
"count",
};

char *names635 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names636 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names637 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names638 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names639 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names640 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names641 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names642 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names643 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names644 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names645 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names646 [] =
{
"area_v2",
"object_comparison",
"index",
};

char *names647 [] =
{
"found_item",
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_item",
"ht_deleted_key",
"object_comparison",
"hash_table_version_64",
"has_default",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"count",
};

char *names648 [] =
{
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_key",
"object_comparison",
"hash_table_version_64",
"has_default",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"count",
"found_item",
"ht_deleted_item",
};

char *names649 [] =
{
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_key",
"object_comparison",
"hash_table_version_64",
"has_default",
"found_item",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"ht_deleted_item",
"count",
};

char *names650 [] =
{
"found_item",
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_item",
"object_comparison",
"hash_table_version_64",
"has_default",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"ht_deleted_key",
"count",
};

char *names651 [] =
{
"content",
"keys",
"indexes_map",
"deleted_marks",
"object_comparison",
"hash_table_version_64",
"has_default",
"found_item",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"ht_deleted_item",
"ht_deleted_key",
"count",
};

char *names652 [] =
{
"found_item",
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_item",
"ht_deleted_key",
"object_comparison",
"hash_table_version_64",
"has_default",
"is_case_insensitive",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"count",
};

char *names653 [] =
{
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_key",
"object_comparison",
"hash_table_version_64",
"has_default",
"is_case_insensitive",
"found_item",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"ht_deleted_item",
"count",
};

char *names654 [] =
{
"found_item",
"content",
"keys",
"indexes_map",
"deleted_marks",
"ht_deleted_item",
"ht_deleted_key",
"stored_version",
"current_version",
"object_comparison",
"hash_table_version_64",
"has_default",
"capacity",
"item_position",
"iteration_position",
"control",
"deleted_item_position",
"ht_lowest_deleted_position",
"count",
};

char *names656 [] =
{
"storage",
"internal_name",
"is_normalized",
};

char *names657 [] =
{
"internal_name_32",
"internal_name",
};

char *names658 [] =
{
"internal_name_32",
"internal_name",
};

char *names659 [] =
{
"internal_name_32",
"internal_name",
};

char *names660 [] =
{
"internal_name_32",
"internal_name",
};

char *names661 [] =
{
"internal_name_32",
"internal_name",
};

char *names662 [] =
{
"internal_name_32",
"internal_name",
};

char *names663 [] =
{
"internal_name_32",
"internal_name",
};

char *names664 [] =
{
"internal_name_32",
"internal_name",
};

char *names665 [] =
{
"internal_name_32",
"internal_name",
};

char *names666 [] =
{
"internal_name_32",
"internal_name",
};

char *names667 [] =
{
"internal_name_32",
"internal_name",
};

char *names668 [] =
{
"internal_name_32",
"internal_name",
};

char *names669 [] =
{
"internal_name_32",
"internal_name",
};

char *names670 [] =
{
"internal_name_32",
"internal_name",
};

char *names671 [] =
{
"internal_name_32",
"internal_name",
};

char *names672 [] =
{
"internal_name_32",
"internal_name",
};

char *names673 [] =
{
"internal_name_32",
"internal_name",
};

char *names674 [] =
{
"internal_name_32",
"internal_name",
};

char *names675 [] =
{
"internal_name_32",
"internal_name",
};

char *names676 [] =
{
"internal_name_32",
"internal_name",
};

char *names677 [] =
{
"internal_name_32",
"internal_name",
};

char *names678 [] =
{
"internal_name_32",
"internal_name",
};

char *names679 [] =
{
"internal_name_32",
"internal_name",
};

char *names680 [] =
{
"internal_name_32",
"internal_name",
};

char *names681 [] =
{
"internal_name_32",
"internal_name",
};

char *names682 [] =
{
"internal_name_32",
"internal_name",
};

char *names683 [] =
{
"internal_name_32",
"internal_name",
};

char *names684 [] =
{
"internal_name_32",
"internal_name",
};

char *names685 [] =
{
"internal_name_32",
"internal_name",
};

char *names686 [] =
{
"internal_name_32",
"internal_name",
};

char *names687 [] =
{
"internal_name_32",
"internal_name",
};

char *names689 [] =
{
"item",
};

char *names690 [] =
{
"item",
};

char *names691 [] =
{
"item",
};

char *names692 [] =
{
"item",
};

char *names693 [] =
{
"item",
};

char *names694 [] =
{
"item",
};

char *names695 [] =
{
"item",
};

char *names696 [] =
{
"item",
};

char *names697 [] =
{
"item",
};

char *names698 [] =
{
"item",
};

char *names699 [] =
{
"item",
};

char *names700 [] =
{
"item",
};

char *names701 [] =
{
"item",
};

char *names702 [] =
{
"item",
};

char *names703 [] =
{
"item",
};

char *names704 [] =
{
"item",
};

char *names705 [] =
{
"item",
};

char *names706 [] =
{
"item",
};

char *names707 [] =
{
"item",
};

char *names708 [] =
{
"item",
};

char *names709 [] =
{
"item",
};

char *names710 [] =
{
"item",
};

char *names711 [] =
{
"item",
};

char *names712 [] =
{
"item",
};

char *names713 [] =
{
"item",
};

char *names714 [] =
{
"item",
};

char *names715 [] =
{
"item",
};

char *names716 [] =
{
"item",
};

char *names717 [] =
{
"item",
};

char *names718 [] =
{
"item",
};

char *names719 [] =
{
"item",
};

char *names720 [] =
{
"item",
};

char *names721 [] =
{
"item",
};

char *names722 [] =
{
"item",
};

char *names723 [] =
{
"item",
};

char *names724 [] =
{
"item",
};

char *names725 [] =
{
"item",
};

char *names726 [] =
{
"item",
};

char *names727 [] =
{
"item",
};

char *names728 [] =
{
"item",
};

char *names729 [] =
{
"to_pointer",
};

char *names730 [] =
{
"to_pointer",
};

char *names731 [] =
{
"to_pointer",
};

char *names732 [] =
{
"to_pointer",
};

char *names733 [] =
{
"to_pointer",
};

char *names734 [] =
{
"to_pointer",
};

char *names735 [] =
{
"to_pointer",
};

char *names736 [] =
{
"to_pointer",
};

char *names737 [] =
{
"to_pointer",
};

char *names738 [] =
{
"to_pointer",
};

char *names739 [] =
{
"to_pointer",
};

char *names740 [] =
{
"to_pointer",
};

char *names741 [] =
{
"to_pointer",
};

char *names742 [] =
{
"to_pointer",
};

char *names743 [] =
{
"to_pointer",
};

char *names744 [] =
{
"to_pointer",
};

char *names745 [] =
{
"to_pointer",
};

char *names746 [] =
{
"to_pointer",
};

char *names747 [] =
{
"to_pointer",
};

char *names748 [] =
{
"to_pointer",
};

char *names749 [] =
{
"to_pointer",
};

char *names750 [] =
{
"to_pointer",
};

char *names751 [] =
{
"to_pointer",
};

char *names752 [] =
{
"to_pointer",
};

char *names753 [] =
{
"to_pointer",
};

char *names754 [] =
{
"to_pointer",
};

char *names755 [] =
{
"to_pointer",
};

char *names756 [] =
{
"to_pointer",
};

char *names757 [] =
{
"to_pointer",
};

char *names758 [] =
{
"to_pointer",
};

char *names759 [] =
{
"item",
};

char *names760 [] =
{
"item",
};

char *names761 [] =
{
"operands",
"closed_operands",
"open_map",
"open_types",
"is_target_closed",
"is_basic",
"open_count",
"routine_id",
"written_type_id_inline_agent",
"rout_disp",
"calc_rout_addr",
"encaps_rout_disp",
};

char *names762 [] =
{
"operands",
"closed_operands",
"open_map",
"open_types",
"is_target_closed",
"is_basic",
"open_count",
"routine_id",
"written_type_id_inline_agent",
"rout_disp",
"calc_rout_addr",
"encaps_rout_disp",
};

char *names763 [] =
{
"operands",
"closed_operands",
"open_map",
"open_types",
"last_result",
"is_target_closed",
"is_basic",
"open_count",
"routine_id",
"written_type_id_inline_agent",
"rout_disp",
"calc_rout_addr",
"encaps_rout_disp",
};

char *names764 [] =
{
"operands",
"closed_operands",
"open_map",
"open_types",
"is_target_closed",
"is_basic",
"last_result",
"open_count",
"routine_id",
"written_type_id_inline_agent",
"rout_disp",
"calc_rout_addr",
"encaps_rout_disp",
};

char *names765 [] =
{
"operands",
"closed_operands",
"open_map",
"open_types",
"is_target_closed",
"is_basic",
"last_result",
"open_count",
"routine_id",
"written_type_id_inline_agent",
"rout_disp",
"calc_rout_addr",
"encaps_rout_disp",
};

char *names766 [] =
{
"internal_hash_code",
"internal_case_insensitive_hash_code",
};

char *names767 [] =
{
"internal_hash_code",
"internal_case_insensitive_hash_code",
};

char *names768 [] =
{
"internal_hash_code",
"internal_case_insensitive_hash_code",
};

char *names769 [] =
{
"area",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
};

char *names770 [] =
{
"area",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
"area_lower",
};

char *names771 [] =
{
"area",
"object_comparison",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
};

char *names772 [] =
{
"area",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
};

char *names773 [] =
{
"area",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
"area_lower",
};

char *names774 [] =
{
"area",
"object_comparison",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
};

char *names775 [] =
{
"area",
"object_comparison",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
};

char *names776 [] =
{
"area",
"object_comparison",
"internal_hash_code",
"internal_case_insensitive_hash_code",
"count",
};

char *names777 [] =
{
"last_string",
"internal_name",
"internal_detachable_name_pointer",
"last_string_32",
"internal_encoding",
"last_character",
"separator",
"object_comparison",
"descriptor_available",
"is_sequence_an_expected_numeric",
"last_natural_8",
"last_integer_8",
"last_natural_16",
"last_integer_16",
"last_natural",
"last_integer",
"bytes_read",
"mode",
"last_real",
"file_pointer",
"last_natural_64",
"last_integer_64",
"last_double",
};

char *names778 [] =
{
"last_converted_string",
"last_conversion_successful",
"last_was_wide_string",
};

char *names779 [] =
{
"last_converted_string",
"last_conversion_successful",
"last_was_wide_string",
};

char *names780 [] =
{
"last_converted_string",
"last_conversion_successful",
"last_was_wide_string",
};

char *names781 [] =
{
"top_callstack_record",
"bottom_callstack_record",
"replayed_call",
"replay_stack",
"flatten_when_closing",
"keep_calls_records",
"recording_values",
"is_replaying",
"last_replay_operation_failed",
"record_count",
"maximum_record_count",
};



#ifdef __cplusplus
}
#endif
