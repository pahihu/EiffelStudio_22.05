#include "eif_eiffel.h"
#include "eif_rout_obj.h"

#ifdef __cplusplus
extern "C" {
#endif

extern void F647_2945(EIF_REFERENCE);
extern void F654_3019(EIF_REFERENCE, EIF_POINTER, EIF_POINTER);
extern void F654_3018(EIF_REFERENCE, EIF_REFERENCE, EIF_POINTER);

#ifdef __cplusplus
}
#endif
