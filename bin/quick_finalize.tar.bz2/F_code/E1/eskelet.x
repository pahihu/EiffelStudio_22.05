#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif
extern const char *names2[];
static const uint32 types2 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags2 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype2_0 [] = {647,759,771,0xFFFF};
static const EIF_TYPE_INDEX g_atype2_1 [] = {646,771,771,0xFFFF};

static const EIF_TYPE_INDEX *gtypes2 [] = {
g_atype2_0,
g_atype2_1,
};

static const long offsets2 [] =
{
0,
 + @REFACS(1),
};

extern const char *names3[];
static const uint32 types3 [] =
{
SK_UINT32,
};

static const uint16 attr_flags3 [] =
{1,};

static const EIF_TYPE_INDEX g_atype3_0 [] = {702,0xFFFF};

static const EIF_TYPE_INDEX *gtypes3 [] = {
g_atype3_0,
};

static const long offsets3 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names6[];
static const uint32 types6 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags6 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype6_0 [] = {771,0xFFFF};
static const EIF_TYPE_INDEX g_atype6_1 [] = {777,0xFFFF};

static const EIF_TYPE_INDEX *gtypes6 [] = {
g_atype6_0,
g_atype6_1,
};

static const long offsets6 [] =
{
0,
 + @REFACS(1),
};

extern const char *names10[];
static const uint32 types10 [] =
{
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags10 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype10_0 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype10_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype10_2 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype10_3 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes10 [] = {
g_atype10_0,
g_atype10_1,
g_atype10_2,
g_atype10_3,
};

static const long offsets10 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
+ @CHROFF(0,2),
+ @LNGOFF(0,3,0,0),
};

extern const char *names26[];
static const uint32 types26 [] =
{
SK_REF,
};

static const uint16 attr_flags26 [] =
{0,};

static const EIF_TYPE_INDEX g_atype26_0 [] = {530,0xFFFF};

static const EIF_TYPE_INDEX *gtypes26 [] = {
g_atype26_0,
};

static const long offsets26 [] =
{
0,
};

extern const char *names27[];
static const uint32 types27 [] =
{
SK_REF,
};

static const uint16 attr_flags27 [] =
{0,};

static const EIF_TYPE_INDEX g_atype27_0 [] = {141,0xFFFF};

static const EIF_TYPE_INDEX *gtypes27 [] = {
g_atype27_0,
};

static const long offsets27 [] =
{
0,
};

extern const char *names29[];
static const uint32 types29 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags29 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype29_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype29_1 [] = {761,0xFFF9,1,687,117,0xFFFF};
static const EIF_TYPE_INDEX g_atype29_2 [] = {761,0xFFF9,2,687,117,117,0xFFFF};
static const EIF_TYPE_INDEX g_atype29_3 [] = {761,0xFFF9,1,687,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype29_4 [] = {634,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype29_5 [] = {650,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype29_6 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype29_7 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype29_8 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype29_9 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype29_10 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype29_11 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes29 [] = {
g_atype29_0,
g_atype29_1,
g_atype29_2,
g_atype29_3,
g_atype29_4,
g_atype29_5,
g_atype29_6,
g_atype29_7,
g_atype29_8,
g_atype29_9,
g_atype29_10,
g_atype29_11,
};

static const long offsets29 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
};

extern const char *names30[];
static const uint32 types30 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags30 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype30_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype30_1 [] = {761,0xFFF9,1,687,117,0xFFFF};
static const EIF_TYPE_INDEX g_atype30_2 [] = {761,0xFFF9,2,687,117,117,0xFFFF};
static const EIF_TYPE_INDEX g_atype30_3 [] = {761,0xFFF9,1,687,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype30_4 [] = {634,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype30_5 [] = {650,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype30_6 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype30_7 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype30_8 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype30_9 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype30_10 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype30_11 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes30 [] = {
g_atype30_0,
g_atype30_1,
g_atype30_2,
g_atype30_3,
g_atype30_4,
g_atype30_5,
g_atype30_6,
g_atype30_7,
g_atype30_8,
g_atype30_9,
g_atype30_10,
g_atype30_11,
};

static const long offsets30 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
};

extern const char *names40[];
static const uint32 types40 [] =
{
SK_REF,
};

static const uint16 attr_flags40 [] =
{0,};

static const EIF_TYPE_INDEX g_atype40_0 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes40 [] = {
g_atype40_0,
};

static const long offsets40 [] =
{
0,
};

extern const char *names41[];
static const uint32 types41 [] =
{
SK_INT32,
};

static const uint16 attr_flags41 [] =
{0,};

static const EIF_TYPE_INDEX g_atype41_0 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes41 [] = {
g_atype41_0,
};

static const long offsets41 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names42[];
static const uint32 types42 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags42 [] =
{0,};

static const EIF_TYPE_INDEX g_atype42_0 [] = {717,0xFFFF};

static const EIF_TYPE_INDEX *gtypes42 [] = {
g_atype42_0,
};

static const long offsets42 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names43[];
static const uint32 types43 [] =
{
SK_UINT64,
};

static const uint16 attr_flags43 [] =
{0,};

static const EIF_TYPE_INDEX g_atype43_0 [] = {699,0xFFFF};

static const EIF_TYPE_INDEX *gtypes43 [] = {
g_atype43_0,
};

static const long offsets43 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names44[];
static const uint32 types44 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags44 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype44_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype44_1 [] = {43,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes44 [] = {
g_atype44_0,
g_atype44_1,
};

static const long offsets44 [] =
{
0,
 + @REFACS(1),
};

extern const char *names45[];
static const uint32 types45 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags45 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype45_0 [] = {44,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype45_1 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes45 [] = {
g_atype45_0,
g_atype45_1,
};

static const long offsets45 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names55[];
static const uint32 types55 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags55 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype55_0 [] = {555,699,0xFFFF};
static const EIF_TYPE_INDEX g_atype55_1 [] = {555,699,0xFFFF};
static const EIF_TYPE_INDEX g_atype55_2 [] = {555,699,0xFFFF};
static const EIF_TYPE_INDEX g_atype55_3 [] = {555,699,0xFFFF};

static const EIF_TYPE_INDEX *gtypes55 [] = {
g_atype55_0,
g_atype55_1,
g_atype55_2,
g_atype55_3,
};

static const long offsets55 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names56[];
static const uint32 types56 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags56 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype56_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype56_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype56_2 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype56_3 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype56_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype56_5 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype56_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes56 [] = {
g_atype56_0,
g_atype56_1,
g_atype56_2,
g_atype56_3,
g_atype56_4,
g_atype56_5,
g_atype56_6,
};

static const long offsets56 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
+ @LNGOFF(2,2,0,1),
+ @LNGOFF(2,2,0,2),
};

extern const char *names57[];
static const uint32 types57 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
SK_UINT64,
};

static const uint16 attr_flags57 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype57_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype57_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype57_2 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype57_3 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype57_4 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype57_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype57_6 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype57_7 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype57_8 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype57_9 [] = {699,0xFFFF};
static const EIF_TYPE_INDEX g_atype57_10 [] = {699,0xFFFF};

static const EIF_TYPE_INDEX *gtypes57 [] = {
g_atype57_0,
g_atype57_1,
g_atype57_2,
g_atype57_3,
g_atype57_4,
g_atype57_5,
g_atype57_6,
g_atype57_7,
g_atype57_8,
g_atype57_9,
g_atype57_10,
};

static const long offsets57 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
+ @LNGOFF(2,4,0,2),
+ @I64OFF(2,4,0,3,0,0,0),
+ @I64OFF(2,4,0,3,0,0,1),
};

extern const char *names58[];
static const uint32 types58 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
SK_UINT64,
};

static const uint16 attr_flags58 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype58_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype58_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype58_2 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype58_3 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype58_4 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype58_5 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype58_6 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype58_7 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype58_8 [] = {699,0xFFFF};
static const EIF_TYPE_INDEX g_atype58_9 [] = {699,0xFFFF};

static const EIF_TYPE_INDEX *gtypes58 [] = {
g_atype58_0,
g_atype58_1,
g_atype58_2,
g_atype58_3,
g_atype58_4,
g_atype58_5,
g_atype58_6,
g_atype58_7,
g_atype58_8,
g_atype58_9,
};

static const long offsets58 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
+ @LNGOFF(2,3,0,1),
+ @LNGOFF(2,3,0,2),
+ @I64OFF(2,3,0,3,0,0,0),
+ @I64OFF(2,3,0,3,0,0,1),
};

extern const char *names59[];
static const uint32 types59 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL64,
SK_REAL64,
SK_REAL64,
};

static const uint16 attr_flags59 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype59_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype59_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype59_2 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype59_3 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype59_4 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype59_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype59_6 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype59_7 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype59_8 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype59_9 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype59_10 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype59_11 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype59_12 [] = {714,0xFFFF};
static const EIF_TYPE_INDEX g_atype59_13 [] = {714,0xFFFF};
static const EIF_TYPE_INDEX g_atype59_14 [] = {714,0xFFFF};

static const EIF_TYPE_INDEX *gtypes59 [] = {
g_atype59_0,
g_atype59_1,
g_atype59_2,
g_atype59_3,
g_atype59_4,
g_atype59_5,
g_atype59_6,
g_atype59_7,
g_atype59_8,
g_atype59_9,
g_atype59_10,
g_atype59_11,
g_atype59_12,
g_atype59_13,
g_atype59_14,
};

static const long offsets59 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @CHROFF(2,4),
+ @CHROFF(2,5),
+ @LNGOFF(2,6,0,0),
+ @LNGOFF(2,6,0,1),
+ @LNGOFF(2,6,0,2),
+ @LNGOFF(2,6,0,3),
+ @R64OFF(2,6,0,4,0,0,0,0),
+ @R64OFF(2,6,0,4,0,0,0,1),
+ @R64OFF(2,6,0,4,0,0,0,2),
};

extern const char *names60[];
static const uint32 types60 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags60 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype60_0 [] = {556,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype60_1 [] = {545,556,690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes60 [] = {
g_atype60_0,
g_atype60_1,
};

static const long offsets60 [] =
{
0,
 + @REFACS(1),
};

extern const char *names61[];
static const uint32 types61 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags61 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype61_0 [] = {556,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype61_1 [] = {545,556,690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes61 [] = {
g_atype61_0,
g_atype61_1,
};

static const long offsets61 [] =
{
0,
 + @REFACS(1),
};

extern const char *names62[];
static const uint32 types62 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags62 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype62_0 [] = {556,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype62_1 [] = {545,556,690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes62 [] = {
g_atype62_0,
g_atype62_1,
};

static const long offsets62 [] =
{
0,
 + @REFACS(1),
};

extern const char *names66[];
static const uint32 types66 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags66 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype66_0 [] = {114,0xFFFF};
static const EIF_TYPE_INDEX g_atype66_1 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes66 [] = {
g_atype66_0,
g_atype66_1,
};

static const long offsets66 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names68[];
static const uint32 types68 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags68 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype68_0 [] = {43,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype68_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype68_2 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes68 [] = {
g_atype68_0,
g_atype68_1,
g_atype68_2,
};

static const long offsets68 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names69[];
static const uint32 types69 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags69 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype69_0 [] = {44,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype69_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype69_2 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes69 [] = {
g_atype69_0,
g_atype69_1,
g_atype69_2,
};

static const long offsets69 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names70[];
static const uint32 types70 [] =
{
SK_INT32,
};

static const uint16 attr_flags70 [] =
{0,};

static const EIF_TYPE_INDEX g_atype70_0 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes70 [] = {
g_atype70_0,
};

static const long offsets70 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names71[];
static const uint32 types71 [] =
{
SK_INT32,
};

static const uint16 attr_flags71 [] =
{0,};

static const EIF_TYPE_INDEX g_atype71_0 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes71 [] = {
g_atype71_0,
};

static const long offsets71 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names74[];
static const uint32 types74 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags74 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype74_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype74_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype74_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype74_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype74_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype74_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype74_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes74 [] = {
g_atype74_0,
g_atype74_1,
g_atype74_2,
g_atype74_3,
g_atype74_4,
g_atype74_5,
g_atype74_6,
};

static const long offsets74 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names75[];
static const uint32 types75 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags75 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype75_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype75_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype75_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype75_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype75_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype75_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype75_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes75 [] = {
g_atype75_0,
g_atype75_1,
g_atype75_2,
g_atype75_3,
g_atype75_4,
g_atype75_5,
g_atype75_6,
};

static const long offsets75 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names76[];
static const uint32 types76 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags76 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype76_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype76_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype76_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype76_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype76_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype76_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype76_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes76 [] = {
g_atype76_0,
g_atype76_1,
g_atype76_2,
g_atype76_3,
g_atype76_4,
g_atype76_5,
g_atype76_6,
};

static const long offsets76 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names77[];
static const uint32 types77 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags77 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype77_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype77_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype77_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype77_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype77_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype77_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype77_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes77 [] = {
g_atype77_0,
g_atype77_1,
g_atype77_2,
g_atype77_3,
g_atype77_4,
g_atype77_5,
g_atype77_6,
};

static const long offsets77 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names78[];
static const uint32 types78 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags78 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype78_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype78_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype78_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype78_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype78_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype78_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype78_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes78 [] = {
g_atype78_0,
g_atype78_1,
g_atype78_2,
g_atype78_3,
g_atype78_4,
g_atype78_5,
g_atype78_6,
};

static const long offsets78 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names79[];
static const uint32 types79 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags79 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype79_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype79_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype79_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype79_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype79_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype79_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype79_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes79 [] = {
g_atype79_0,
g_atype79_1,
g_atype79_2,
g_atype79_3,
g_atype79_4,
g_atype79_5,
g_atype79_6,
};

static const long offsets79 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names80[];
static const uint32 types80 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags80 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype80_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype80_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype80_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype80_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype80_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype80_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype80_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes80 [] = {
g_atype80_0,
g_atype80_1,
g_atype80_2,
g_atype80_3,
g_atype80_4,
g_atype80_5,
g_atype80_6,
};

static const long offsets80 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names81[];
static const uint32 types81 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags81 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype81_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype81_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype81_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype81_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype81_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype81_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype81_6 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype81_7 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes81 [] = {
g_atype81_0,
g_atype81_1,
g_atype81_2,
g_atype81_3,
g_atype81_4,
g_atype81_5,
g_atype81_6,
g_atype81_7,
};

static const long offsets81 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names82[];
static const uint32 types82 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags82 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype82_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype82_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype82_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype82_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype82_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype82_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype82_6 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype82_7 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes82 [] = {
g_atype82_0,
g_atype82_1,
g_atype82_2,
g_atype82_3,
g_atype82_4,
g_atype82_5,
g_atype82_6,
g_atype82_7,
};

static const long offsets82 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names83[];
static const uint32 types83 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags83 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype83_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype83_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype83_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype83_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype83_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype83_5 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype83_6 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype83_7 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype83_8 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype83_9 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes83 [] = {
g_atype83_0,
g_atype83_1,
g_atype83_2,
g_atype83_3,
g_atype83_4,
g_atype83_5,
g_atype83_6,
g_atype83_7,
g_atype83_8,
g_atype83_9,
};

static const long offsets83 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @LNGOFF(6,1,0,0),
+ @LNGOFF(6,1,0,1),
+ @LNGOFF(6,1,0,2),
};

extern const char *names84[];
static const uint32 types84 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags84 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype84_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype84_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype84_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype84_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype84_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype84_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype84_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes84 [] = {
g_atype84_0,
g_atype84_1,
g_atype84_2,
g_atype84_3,
g_atype84_4,
g_atype84_5,
g_atype84_6,
};

static const long offsets84 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names85[];
static const uint32 types85 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags85 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype85_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype85_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype85_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype85_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype85_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype85_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype85_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes85 [] = {
g_atype85_0,
g_atype85_1,
g_atype85_2,
g_atype85_3,
g_atype85_4,
g_atype85_5,
g_atype85_6,
};

static const long offsets85 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names86[];
static const uint32 types86 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags86 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype86_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype86_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype86_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype86_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype86_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype86_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype86_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes86 [] = {
g_atype86_0,
g_atype86_1,
g_atype86_2,
g_atype86_3,
g_atype86_4,
g_atype86_5,
g_atype86_6,
};

static const long offsets86 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names87[];
static const uint32 types87 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags87 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype87_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype87_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype87_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype87_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype87_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype87_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype87_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes87 [] = {
g_atype87_0,
g_atype87_1,
g_atype87_2,
g_atype87_3,
g_atype87_4,
g_atype87_5,
g_atype87_6,
};

static const long offsets87 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names88[];
static const uint32 types88 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags88 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype88_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype88_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype88_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype88_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype88_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype88_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype88_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes88 [] = {
g_atype88_0,
g_atype88_1,
g_atype88_2,
g_atype88_3,
g_atype88_4,
g_atype88_5,
g_atype88_6,
};

static const long offsets88 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names89[];
static const uint32 types89 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags89 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype89_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype89_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype89_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype89_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype89_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype89_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype89_6 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype89_7 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes89 [] = {
g_atype89_0,
g_atype89_1,
g_atype89_2,
g_atype89_3,
g_atype89_4,
g_atype89_5,
g_atype89_6,
g_atype89_7,
};

static const long offsets89 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names90[];
static const uint32 types90 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags90 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype90_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype90_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype90_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype90_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype90_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype90_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype90_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes90 [] = {
g_atype90_0,
g_atype90_1,
g_atype90_2,
g_atype90_3,
g_atype90_4,
g_atype90_5,
g_atype90_6,
};

static const long offsets90 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names91[];
static const uint32 types91 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags91 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype91_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype91_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype91_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype91_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype91_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype91_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype91_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes91 [] = {
g_atype91_0,
g_atype91_1,
g_atype91_2,
g_atype91_3,
g_atype91_4,
g_atype91_5,
g_atype91_6,
};

static const long offsets91 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names92[];
static const uint32 types92 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags92 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype92_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype92_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype92_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype92_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype92_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype92_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype92_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes92 [] = {
g_atype92_0,
g_atype92_1,
g_atype92_2,
g_atype92_3,
g_atype92_4,
g_atype92_5,
g_atype92_6,
};

static const long offsets92 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names93[];
static const uint32 types93 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags93 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype93_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype93_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype93_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype93_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype93_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype93_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype93_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes93 [] = {
g_atype93_0,
g_atype93_1,
g_atype93_2,
g_atype93_3,
g_atype93_4,
g_atype93_5,
g_atype93_6,
};

static const long offsets93 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names94[];
static const uint32 types94 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags94 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype94_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype94_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype94_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype94_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype94_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype94_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype94_6 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype94_7 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes94 [] = {
g_atype94_0,
g_atype94_1,
g_atype94_2,
g_atype94_3,
g_atype94_4,
g_atype94_5,
g_atype94_6,
g_atype94_7,
};

static const long offsets94 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names95[];
static const uint32 types95 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags95 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype95_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype95_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes95 [] = {
g_atype95_0,
g_atype95_1,
g_atype95_2,
g_atype95_3,
g_atype95_4,
g_atype95_5,
g_atype95_6,
};

static const long offsets95 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names96[];
static const uint32 types96 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags96 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype96_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype96_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes96 [] = {
g_atype96_0,
g_atype96_1,
g_atype96_2,
g_atype96_3,
g_atype96_4,
g_atype96_5,
g_atype96_6,
};

static const long offsets96 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names97[];
static const uint32 types97 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags97 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype97_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_6 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_7 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype97_8 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes97 [] = {
g_atype97_0,
g_atype97_1,
g_atype97_2,
g_atype97_3,
g_atype97_4,
g_atype97_5,
g_atype97_6,
g_atype97_7,
g_atype97_8,
};

static const long offsets97 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
+ @LNGOFF(5,1,0,2),
};

extern const char *names98[];
static const uint32 types98 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags98 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype98_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype98_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes98 [] = {
g_atype98_0,
g_atype98_1,
g_atype98_2,
g_atype98_3,
g_atype98_4,
g_atype98_5,
g_atype98_6,
};

static const long offsets98 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names99[];
static const uint32 types99 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags99 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype99_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype99_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype99_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype99_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype99_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype99_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype99_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes99 [] = {
g_atype99_0,
g_atype99_1,
g_atype99_2,
g_atype99_3,
g_atype99_4,
g_atype99_5,
g_atype99_6,
};

static const long offsets99 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names100[];
static const uint32 types100 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags100 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype100_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype100_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes100 [] = {
g_atype100_0,
g_atype100_1,
g_atype100_2,
g_atype100_3,
g_atype100_4,
g_atype100_5,
g_atype100_6,
};

static const long offsets100 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names101[];
static const uint32 types101 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags101 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype101_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype101_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype101_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype101_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype101_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype101_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype101_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes101 [] = {
g_atype101_0,
g_atype101_1,
g_atype101_2,
g_atype101_3,
g_atype101_4,
g_atype101_5,
g_atype101_6,
};

static const long offsets101 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names102[];
static const uint32 types102 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags102 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype102_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype102_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype102_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype102_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype102_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype102_5 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype102_6 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype102_7 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype102_8 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes102 [] = {
g_atype102_0,
g_atype102_1,
g_atype102_2,
g_atype102_3,
g_atype102_4,
g_atype102_5,
g_atype102_6,
g_atype102_7,
g_atype102_8,
};

static const long offsets102 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @LNGOFF(7,1,0,0),
};

extern const char *names103[];
static const uint32 types103 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags103 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype103_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype103_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype103_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype103_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype103_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype103_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype103_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes103 [] = {
g_atype103_0,
g_atype103_1,
g_atype103_2,
g_atype103_3,
g_atype103_4,
g_atype103_5,
g_atype103_6,
};

static const long offsets103 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names104[];
static const uint32 types104 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags104 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype104_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype104_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype104_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype104_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype104_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype104_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype104_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes104 [] = {
g_atype104_0,
g_atype104_1,
g_atype104_2,
g_atype104_3,
g_atype104_4,
g_atype104_5,
g_atype104_6,
};

static const long offsets104 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names105[];
static const uint32 types105 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags105 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype105_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype105_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype105_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype105_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype105_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype105_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype105_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes105 [] = {
g_atype105_0,
g_atype105_1,
g_atype105_2,
g_atype105_3,
g_atype105_4,
g_atype105_5,
g_atype105_6,
};

static const long offsets105 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names106[];
static const uint32 types106 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags106 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype106_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype106_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype106_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype106_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype106_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype106_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype106_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes106 [] = {
g_atype106_0,
g_atype106_1,
g_atype106_2,
g_atype106_3,
g_atype106_4,
g_atype106_5,
g_atype106_6,
};

static const long offsets106 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names107[];
static const uint32 types107 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags107 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype107_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype107_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes107 [] = {
g_atype107_0,
g_atype107_1,
g_atype107_2,
g_atype107_3,
g_atype107_4,
g_atype107_5,
g_atype107_6,
};

static const long offsets107 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names108[];
static const uint32 types108 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags108 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype108_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype108_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype108_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype108_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype108_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype108_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype108_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes108 [] = {
g_atype108_0,
g_atype108_1,
g_atype108_2,
g_atype108_3,
g_atype108_4,
g_atype108_5,
g_atype108_6,
};

static const long offsets108 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names109[];
static const uint32 types109 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags109 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype109_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype109_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype109_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype109_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype109_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype109_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype109_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes109 [] = {
g_atype109_0,
g_atype109_1,
g_atype109_2,
g_atype109_3,
g_atype109_4,
g_atype109_5,
g_atype109_6,
};

static const long offsets109 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names110[];
static const uint32 types110 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags110 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype110_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype110_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype110_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype110_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype110_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype110_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype110_6 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype110_7 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes110 [] = {
g_atype110_0,
g_atype110_1,
g_atype110_2,
g_atype110_3,
g_atype110_4,
g_atype110_5,
g_atype110_6,
g_atype110_7,
};

static const long offsets110 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
};

extern const char *names111[];
static const uint32 types111 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags111 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype111_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype111_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype111_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype111_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype111_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype111_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype111_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes111 [] = {
g_atype111_0,
g_atype111_1,
g_atype111_2,
g_atype111_3,
g_atype111_4,
g_atype111_5,
g_atype111_6,
};

static const long offsets111 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names112[];
static const uint32 types112 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags112 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype112_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype112_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype112_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype112_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype112_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype112_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype112_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes112 [] = {
g_atype112_0,
g_atype112_1,
g_atype112_2,
g_atype112_3,
g_atype112_4,
g_atype112_5,
g_atype112_6,
};

static const long offsets112 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names113[];
static const uint32 types113 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags113 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype113_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype113_1 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype113_2 [] = {73,0xFFFF};
static const EIF_TYPE_INDEX g_atype113_3 [] = {65,0xFFFF};
static const EIF_TYPE_INDEX g_atype113_4 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype113_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype113_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes113 [] = {
g_atype113_0,
g_atype113_1,
g_atype113_2,
g_atype113_3,
g_atype113_4,
g_atype113_5,
g_atype113_6,
};

static const long offsets113 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names115[];
static const uint32 types115 [] =
{
SK_BOOL,
SK_INT32,
SK_POINTER,
SK_UINT64,
};

static const uint16 attr_flags115 [] =
{0,0,1,1,};

static const EIF_TYPE_INDEX g_atype115_0 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype115_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype115_2 [] = {759,0xFFFF};
static const EIF_TYPE_INDEX g_atype115_3 [] = {699,0xFFFF};

static const EIF_TYPE_INDEX *gtypes115 [] = {
g_atype115_0,
g_atype115_1,
g_atype115_2,
g_atype115_3,
};

static const long offsets115 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
+ @PTROFF(0,1,0,1,0,0),
+ @I64OFF(0,1,0,1,0,1,0),
};

extern const char *names116[];
static const uint32 types116 [] =
{
SK_REF,
SK_CHAR8,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags116 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype116_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_2 [] = {708,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_3 [] = {696,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_4 [] = {705,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_5 [] = {693,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_6 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_7 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_8 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_9 [] = {711,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_10 [] = {699,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_11 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype116_12 [] = {714,0xFFFF};

static const EIF_TYPE_INDEX *gtypes116 [] = {
g_atype116_0,
g_atype116_1,
g_atype116_2,
g_atype116_3,
g_atype116_4,
g_atype116_5,
g_atype116_6,
g_atype116_7,
g_atype116_8,
g_atype116_9,
g_atype116_10,
g_atype116_11,
g_atype116_12,
};

static const long offsets116 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @I16OFF(1,3,0),
+ @I16OFF(1,3,1),
+ @LNGOFF(1,3,2,0),
+ @LNGOFF(1,3,2,1),
+ @LNGOFF(1,3,2,2),
+ @R32OFF(1,3,2,3,0),
+ @I64OFF(1,3,2,3,1,0,0),
+ @I64OFF(1,3,2,3,1,0,1),
+ @R64OFF(1,3,2,3,1,0,2,0),
};

extern const char *names118[];
static const uint32 types118 [] =
{
SK_INT32,
};

static const uint16 attr_flags118 [] =
{0,};

static const EIF_TYPE_INDEX g_atype118_0 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes118 [] = {
g_atype118_0,
};

static const long offsets118 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names122[];
static const uint32 types122 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags122 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype122_0 [] = {117,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype122_3 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes122 [] = {
g_atype122_0,
g_atype122_1,
g_atype122_2,
g_atype122_3,
};

static const long offsets122 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names123[];
static const uint32 types123 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags123 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype123_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype123_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype123_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes123 [] = {
g_atype123_0,
g_atype123_1,
g_atype123_2,
};

static const long offsets123 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names124[];
static const uint32 types124 [] =
{
SK_REF,
};

static const uint16 attr_flags124 [] =
{0,};

static const EIF_TYPE_INDEX g_atype124_0 [] = {545,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes124 [] = {
g_atype124_0,
};

static const long offsets124 [] =
{
0,
};

extern const char *names125[];
static const uint32 types125 [] =
{
SK_REF,
};

static const uint16 attr_flags125 [] =
{0,};

static const EIF_TYPE_INDEX g_atype125_0 [] = {546,717,0xFFFF};

static const EIF_TYPE_INDEX *gtypes125 [] = {
g_atype125_0,
};

static const long offsets125 [] =
{
0,
};

extern const char *names126[];
static const uint32 types126 [] =
{
SK_REF,
};

static const uint16 attr_flags126 [] =
{0,};

static const EIF_TYPE_INDEX g_atype126_0 [] = {547,720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes126 [] = {
g_atype126_0,
};

static const long offsets126 [] =
{
0,
};

extern const char *names127[];
static const uint32 types127 [] =
{
SK_REF,
};

static const uint16 attr_flags127 [] =
{0,};

static const EIF_TYPE_INDEX g_atype127_0 [] = {548,708,0xFFFF};

static const EIF_TYPE_INDEX *gtypes127 [] = {
g_atype127_0,
};

static const long offsets127 [] =
{
0,
};

extern const char *names128[];
static const uint32 types128 [] =
{
SK_REF,
};

static const uint16 attr_flags128 [] =
{0,};

static const EIF_TYPE_INDEX g_atype128_0 [] = {549,705,0xFFFF};

static const EIF_TYPE_INDEX *gtypes128 [] = {
g_atype128_0,
};

static const long offsets128 [] =
{
0,
};

extern const char *names129[];
static const uint32 types129 [] =
{
SK_REF,
};

static const uint16 attr_flags129 [] =
{0,};

static const EIF_TYPE_INDEX g_atype129_0 [] = {550,759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes129 [] = {
g_atype129_0,
};

static const long offsets129 [] =
{
0,
};

extern const char *names130[];
static const uint32 types130 [] =
{
SK_REF,
};

static const uint16 attr_flags130 [] =
{0,};

static const EIF_TYPE_INDEX g_atype130_0 [] = {551,711,0xFFFF};

static const EIF_TYPE_INDEX *gtypes130 [] = {
g_atype130_0,
};

static const long offsets130 [] =
{
0,
};

extern const char *names131[];
static const uint32 types131 [] =
{
SK_REF,
};

static const uint16 attr_flags131 [] =
{0,};

static const EIF_TYPE_INDEX g_atype131_0 [] = {552,714,0xFFFF};

static const EIF_TYPE_INDEX *gtypes131 [] = {
g_atype131_0,
};

static const long offsets131 [] =
{
0,
};

extern const char *names132[];
static const uint32 types132 [] =
{
SK_REF,
};

static const uint16 attr_flags132 [] =
{0,};

static const EIF_TYPE_INDEX g_atype132_0 [] = {553,702,0xFFFF};

static const EIF_TYPE_INDEX *gtypes132 [] = {
g_atype132_0,
};

static const long offsets132 [] =
{
0,
};

extern const char *names133[];
static const uint32 types133 [] =
{
SK_REF,
};

static const uint16 attr_flags133 [] =
{0,};

static const EIF_TYPE_INDEX g_atype133_0 [] = {554,723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes133 [] = {
g_atype133_0,
};

static const long offsets133 [] =
{
0,
};

extern const char *names134[];
static const uint32 types134 [] =
{
SK_REF,
};

static const uint16 attr_flags134 [] =
{0,};

static const EIF_TYPE_INDEX g_atype134_0 [] = {555,699,0xFFFF};

static const EIF_TYPE_INDEX *gtypes134 [] = {
g_atype134_0,
};

static const long offsets134 [] =
{
0,
};

extern const char *names135[];
static const uint32 types135 [] =
{
SK_REF,
};

static const uint16 attr_flags135 [] =
{0,};

static const EIF_TYPE_INDEX g_atype135_0 [] = {556,690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes135 [] = {
g_atype135_0,
};

static const long offsets135 [] =
{
0,
};

extern const char *names137[];
static const uint32 types137 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags137 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype137_0 [] = {114,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_1 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes137 [] = {
g_atype137_0,
g_atype137_1,
};

static const long offsets137 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names138[];
static const uint32 types138 [] =
{
SK_INT32,
};

static const uint16 attr_flags138 [] =
{0,};

static const EIF_TYPE_INDEX g_atype138_0 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes138 [] = {
g_atype138_0,
};

static const long offsets138 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names139[];
static const uint32 types139 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags139 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype139_0 [] = {548,708,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_1 [] = {765,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_2 [] = {114,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_3 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_4 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes139 [] = {
g_atype139_0,
g_atype139_1,
g_atype139_2,
g_atype139_3,
g_atype139_4,
};

static const long offsets139 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names140[];
static const uint32 types140 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags140 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype140_0 [] = {548,708,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_1 [] = {765,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_2 [] = {114,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_3 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_4 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes140 [] = {
g_atype140_0,
g_atype140_1,
g_atype140_2,
g_atype140_3,
g_atype140_4,
};

static const long offsets140 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names141[];
static const uint32 types141 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags141 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype141_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_1 [] = {765,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_2 [] = {114,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_4 [] = {759,0xFFFF};
static const EIF_TYPE_INDEX g_atype141_5 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes141 [] = {
g_atype141_0,
g_atype141_1,
g_atype141_2,
g_atype141_3,
g_atype141_4,
g_atype141_5,
};

static const long offsets141 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @PTROFF(3,0,0,1,0,0),
+ @PTROFF(3,0,0,1,0,1),
};

extern const char *names142[];
static const uint32 types142 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags142 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype142_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_1 [] = {765,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_2 [] = {114,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_3 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_4 [] = {634,773,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_5 [] = {634,773,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_6 [] = {634,773,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_7 [] = {634,773,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_8 [] = {530,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_9 [] = {634,141,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_10 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_11 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_12 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_13 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_14 [] = {759,0xFFFF};
static const EIF_TYPE_INDEX g_atype142_15 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes142 [] = {
g_atype142_0,
g_atype142_1,
g_atype142_2,
g_atype142_3,
g_atype142_4,
g_atype142_5,
g_atype142_6,
g_atype142_7,
g_atype142_8,
g_atype142_9,
g_atype142_10,
g_atype142_11,
g_atype142_12,
g_atype142_13,
g_atype142_14,
g_atype142_15,
};

static const long offsets142 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @CHROFF(11,0),
+ @CHROFF(11,1),
+ @LNGOFF(11,2,0,0),
+ @PTROFF(11,2,0,1,0,0),
+ @PTROFF(11,2,0,1,0,1),
};

extern const char *names144[];
static const uint32 types144 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags144 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype144_0 [] = {780,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_2 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_3 [] = {143,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_4 [] = {643,723,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_5 [] = {634,143,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_6 [] = {634,145,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_7 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_8 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_9 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_10 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_11 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_12 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_13 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype144_14 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes144 [] = {
g_atype144_0,
g_atype144_1,
g_atype144_2,
g_atype144_3,
g_atype144_4,
g_atype144_5,
g_atype144_6,
g_atype144_7,
g_atype144_8,
g_atype144_9,
g_atype144_10,
g_atype144_11,
g_atype144_12,
g_atype144_13,
g_atype144_14,
};

static const long offsets144 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @CHROFF(8,1),
+ @CHROFF(8,2),
+ @CHROFF(8,3),
+ @LNGOFF(8,4,0,0),
+ @LNGOFF(8,4,0,1),
+ @LNGOFF(8,4,0,2),
};

extern const char *names146[];
static const uint32 types146 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags146 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype146_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype146_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes146 [] = {
g_atype146_0,
g_atype146_1,
g_atype146_2,
};

static const long offsets146 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names147[];
static const uint32 types147 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags147 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype147_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_2 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype147_4 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes147 [] = {
g_atype147_0,
g_atype147_1,
g_atype147_2,
g_atype147_3,
g_atype147_4,
};

static const long offsets147 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
};

extern const char *names148[];
static const uint32 types148 [] =
{
SK_REF,
SK_REF,
SK_INT16,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags148 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype148_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype148_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype148_2 [] = {693,0xFFFF};
static const EIF_TYPE_INDEX g_atype148_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype148_4 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes148 [] = {
g_atype148_0,
g_atype148_1,
g_atype148_2,
g_atype148_3,
g_atype148_4,
};

static const long offsets148 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
};

extern const char *names149[];
static const uint32 types149 [] =
{
SK_REF,
SK_REF,
SK_CHAR32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags149 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype149_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_2 [] = {717,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype149_4 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes149 [] = {
g_atype149_0,
g_atype149_1,
g_atype149_2,
g_atype149_3,
g_atype149_4,
};

static const long offsets149 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names150[];
static const uint32 types150 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags150 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype150_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype150_4 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes150 [] = {
g_atype150_0,
g_atype150_1,
g_atype150_2,
g_atype150_3,
g_atype150_4,
};

static const long offsets150 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names151[];
static const uint32 types151 [] =
{
SK_REF,
SK_REF,
SK_UINT16,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags151 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype151_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype151_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype151_2 [] = {705,0xFFFF};
static const EIF_TYPE_INDEX g_atype151_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype151_4 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes151 [] = {
g_atype151_0,
g_atype151_1,
g_atype151_2,
g_atype151_3,
g_atype151_4,
};

static const long offsets151 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
};

extern const char *names152[];
static const uint32 types152 [] =
{
SK_REF,
SK_REF,
SK_UINT8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags152 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype152_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype152_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype152_2 [] = {708,0xFFFF};
static const EIF_TYPE_INDEX g_atype152_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype152_4 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes152 [] = {
g_atype152_0,
g_atype152_1,
g_atype152_2,
g_atype152_3,
g_atype152_4,
};

static const long offsets152 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names153[];
static const uint32 types153 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags153 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype153_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype153_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype153_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype153_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype153_4 [] = {711,0xFFFF};

static const EIF_TYPE_INDEX *gtypes153 [] = {
g_atype153_0,
g_atype153_1,
g_atype153_2,
g_atype153_3,
g_atype153_4,
};

static const long offsets153 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @R32OFF(2,0,0,2,0),
};

extern const char *names154[];
static const uint32 types154 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags154 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype154_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_4 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes154 [] = {
g_atype154_0,
g_atype154_1,
g_atype154_2,
g_atype154_3,
g_atype154_4,
};

static const long offsets154 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names155[];
static const uint32 types155 [] =
{
SK_REF,
SK_REF,
SK_INT8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags155 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype155_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_2 [] = {696,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_4 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes155 [] = {
g_atype155_0,
g_atype155_1,
g_atype155_2,
g_atype155_3,
g_atype155_4,
};

static const long offsets155 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names156[];
static const uint32 types156 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags156 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype156_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_4 [] = {699,0xFFFF};

static const EIF_TYPE_INDEX *gtypes156 [] = {
g_atype156_0,
g_atype156_1,
g_atype156_2,
g_atype156_3,
g_atype156_4,
};

static const long offsets156 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @I64OFF(2,0,0,2,0,0,0),
};

extern const char *names157[];
static const uint32 types157 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags157 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype157_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_2 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_4 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes157 [] = {
g_atype157_0,
g_atype157_1,
g_atype157_2,
g_atype157_3,
g_atype157_4,
};

static const long offsets157 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names158[];
static const uint32 types158 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags158 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype158_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_2 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype158_4 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes158 [] = {
g_atype158_0,
g_atype158_1,
g_atype158_2,
g_atype158_3,
g_atype158_4,
};

static const long offsets158 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names159[];
static const uint32 types159 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags159 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype159_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype159_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype159_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype159_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype159_4 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes159 [] = {
g_atype159_0,
g_atype159_1,
g_atype159_2,
g_atype159_3,
g_atype159_4,
};

static const long offsets159 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @I64OFF(2,0,0,2,0,0,0),
};

extern const char *names160[];
static const uint32 types160 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags160 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype160_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype160_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype160_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype160_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype160_4 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes160 [] = {
g_atype160_0,
g_atype160_1,
g_atype160_2,
g_atype160_3,
g_atype160_4,
};

static const long offsets160 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @PTROFF(2,0,0,2,0,0),
};

extern const char *names161[];
static const uint32 types161 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags161 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype161_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype161_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype161_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype161_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype161_4 [] = {714,0xFFFF};

static const EIF_TYPE_INDEX *gtypes161 [] = {
g_atype161_0,
g_atype161_1,
g_atype161_2,
g_atype161_3,
g_atype161_4,
};

static const long offsets161 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @R64OFF(2,0,0,2,0,0,0,0),
};

extern const char *names162[];
static const uint32 types162 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags162 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype162_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype162_1 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype162_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype162_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype162_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype162_5 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes162 [] = {
g_atype162_0,
g_atype162_1,
g_atype162_2,
g_atype162_3,
g_atype162_4,
g_atype162_5,
};

static const long offsets162 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names163[];
static const uint32 types163 [] =
{
SK_REF,
SK_CHAR32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags163 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype163_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_1 [] = {717,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_5 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes163 [] = {
g_atype163_0,
g_atype163_1,
g_atype163_2,
g_atype163_3,
g_atype163_4,
g_atype163_5,
};

static const long offsets163 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names164[];
static const uint32 types164 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags164 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype164_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_5 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes164 [] = {
g_atype164_0,
g_atype164_1,
g_atype164_2,
g_atype164_3,
g_atype164_4,
g_atype164_5,
};

static const long offsets164 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names165[];
static const uint32 types165 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags165 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype165_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_1 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_5 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes165 [] = {
g_atype165_0,
g_atype165_1,
g_atype165_2,
g_atype165_3,
g_atype165_4,
g_atype165_5,
};

static const long offsets165 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @I64OFF(1,0,0,4,0,0,0),
};

extern const char *names166[];
static const uint32 types166 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags166 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype166_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_1 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_5 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes166 [] = {
g_atype166_0,
g_atype166_1,
g_atype166_2,
g_atype166_3,
g_atype166_4,
g_atype166_5,
};

static const long offsets166 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names167[];
static const uint32 types167 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags167 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype167_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_1 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_5 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes167 [] = {
g_atype167_0,
g_atype167_1,
g_atype167_2,
g_atype167_3,
g_atype167_4,
g_atype167_5,
};

static const long offsets167 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @PTROFF(1,0,0,4,0,0),
};

extern const char *names168[];
static const uint32 types168 [] =
{
SK_REF,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags168 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype168_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype168_1 [] = {705,0xFFFF};
static const EIF_TYPE_INDEX g_atype168_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype168_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype168_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype168_5 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes168 [] = {
g_atype168_0,
g_atype168_1,
g_atype168_2,
g_atype168_3,
g_atype168_4,
g_atype168_5,
};

static const long offsets168 [] =
{
0,
+ @I16OFF(1,0,0),
+ @LNGOFF(1,0,1,0),
+ @LNGOFF(1,0,1,1),
+ @LNGOFF(1,0,1,2),
+ @LNGOFF(1,0,1,3),
};

extern const char *names169[];
static const uint32 types169 [] =
{
SK_REF,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags169 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype169_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_1 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_5 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes169 [] = {
g_atype169_0,
g_atype169_1,
g_atype169_2,
g_atype169_3,
g_atype169_4,
g_atype169_5,
};

static const long offsets169 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names170[];
static const uint32 types170 [] =
{
SK_REF,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags170 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype170_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_1 [] = {693,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_5 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes170 [] = {
g_atype170_0,
g_atype170_1,
g_atype170_2,
g_atype170_3,
g_atype170_4,
g_atype170_5,
};

static const long offsets170 [] =
{
0,
+ @I16OFF(1,0,0),
+ @LNGOFF(1,0,1,0),
+ @LNGOFF(1,0,1,1),
+ @LNGOFF(1,0,1,2),
+ @LNGOFF(1,0,1,3),
};

extern const char *names171[];
static const uint32 types171 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags171 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype171_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_1 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype171_5 [] = {699,0xFFFF};

static const EIF_TYPE_INDEX *gtypes171 [] = {
g_atype171_0,
g_atype171_1,
g_atype171_2,
g_atype171_3,
g_atype171_4,
g_atype171_5,
};

static const long offsets171 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @I64OFF(1,0,0,4,0,0,0),
};

extern const char *names172[];
static const uint32 types172 [] =
{
SK_REF,
SK_INT8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags172 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype172_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype172_1 [] = {696,0xFFFF};
static const EIF_TYPE_INDEX g_atype172_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype172_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype172_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype172_5 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes172 [] = {
g_atype172_0,
g_atype172_1,
g_atype172_2,
g_atype172_3,
g_atype172_4,
g_atype172_5,
};

static const long offsets172 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names173[];
static const uint32 types173 [] =
{
SK_REF,
SK_CHAR8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags173 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype173_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype173_1 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype173_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype173_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype173_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype173_5 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes173 [] = {
g_atype173_0,
g_atype173_1,
g_atype173_2,
g_atype173_3,
g_atype173_4,
g_atype173_5,
};

static const long offsets173 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names174[];
static const uint32 types174 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags174 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype174_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype174_1 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype174_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype174_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype174_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype174_5 [] = {711,0xFFFF};

static const EIF_TYPE_INDEX *gtypes174 [] = {
g_atype174_0,
g_atype174_1,
g_atype174_2,
g_atype174_3,
g_atype174_4,
g_atype174_5,
};

static const long offsets174 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @R32OFF(1,0,0,4,0),
};

extern const char *names175[];
static const uint32 types175 [] =
{
SK_REF,
SK_UINT8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags175 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype175_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype175_1 [] = {708,0xFFFF};
static const EIF_TYPE_INDEX g_atype175_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype175_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype175_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype175_5 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes175 [] = {
g_atype175_0,
g_atype175_1,
g_atype175_2,
g_atype175_3,
g_atype175_4,
g_atype175_5,
};

static const long offsets175 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names176[];
static const uint32 types176 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags176 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype176_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype176_1 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype176_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype176_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype176_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype176_5 [] = {714,0xFFFF};

static const EIF_TYPE_INDEX *gtypes176 [] = {
g_atype176_0,
g_atype176_1,
g_atype176_2,
g_atype176_3,
g_atype176_4,
g_atype176_5,
};

static const long offsets176 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @R64OFF(1,0,0,4,0,0,0,0),
};

extern const char *names177[];
static const uint32 types177 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags177 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype177_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype177_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype177_2 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype177_3 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype177_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype177_5 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes177 [] = {
g_atype177_0,
g_atype177_1,
g_atype177_2,
g_atype177_3,
g_atype177_4,
g_atype177_5,
};

static const long offsets177 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names178[];
static const uint32 types178 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags178 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype178_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype178_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype178_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype178_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype178_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype178_5 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes178 [] = {
g_atype178_0,
g_atype178_1,
g_atype178_2,
g_atype178_3,
g_atype178_4,
g_atype178_5,
};

static const long offsets178 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @PTROFF(2,0,0,3,0,0),
};

extern const char *names179[];
static const uint32 types179 [] =
{
SK_REF,
SK_REF,
SK_UINT8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags179 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype179_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_2 [] = {708,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_3 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_5 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes179 [] = {
g_atype179_0,
g_atype179_1,
g_atype179_2,
g_atype179_3,
g_atype179_4,
g_atype179_5,
};

static const long offsets179 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names180[];
static const uint32 types180 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags180 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype180_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_5 [] = {711,0xFFFF};

static const EIF_TYPE_INDEX *gtypes180 [] = {
g_atype180_0,
g_atype180_1,
g_atype180_2,
g_atype180_3,
g_atype180_4,
g_atype180_5,
};

static const long offsets180 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @R32OFF(2,0,0,3,0),
};

extern const char *names181[];
static const uint32 types181 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags181 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype181_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_3 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_5 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes181 [] = {
g_atype181_0,
g_atype181_1,
g_atype181_2,
g_atype181_3,
g_atype181_4,
g_atype181_5,
};

static const long offsets181 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names182[];
static const uint32 types182 [] =
{
SK_REF,
SK_REF,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags182 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype182_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_2 [] = {705,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_3 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_5 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes182 [] = {
g_atype182_0,
g_atype182_1,
g_atype182_2,
g_atype182_3,
g_atype182_4,
g_atype182_5,
};

static const long offsets182 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
+ @LNGOFF(2,0,1,2),
};

extern const char *names183[];
static const uint32 types183 [] =
{
SK_REF,
SK_REF,
SK_INT8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags183 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype183_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_2 [] = {696,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_3 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_5 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes183 [] = {
g_atype183_0,
g_atype183_1,
g_atype183_2,
g_atype183_3,
g_atype183_4,
g_atype183_5,
};

static const long offsets183 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names184[];
static const uint32 types184 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags184 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype184_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_5 [] = {699,0xFFFF};

static const EIF_TYPE_INDEX *gtypes184 [] = {
g_atype184_0,
g_atype184_1,
g_atype184_2,
g_atype184_3,
g_atype184_4,
g_atype184_5,
};

static const long offsets184 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @I64OFF(2,0,0,3,0,0,0),
};

extern const char *names185[];
static const uint32 types185 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags185 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype185_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_5 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes185 [] = {
g_atype185_0,
g_atype185_1,
g_atype185_2,
g_atype185_3,
g_atype185_4,
g_atype185_5,
};

static const long offsets185 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names186[];
static const uint32 types186 [] =
{
SK_REF,
SK_REF,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags186 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype186_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_2 [] = {693,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_3 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_5 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes186 [] = {
g_atype186_0,
g_atype186_1,
g_atype186_2,
g_atype186_3,
g_atype186_4,
g_atype186_5,
};

static const long offsets186 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
+ @LNGOFF(2,0,1,2),
};

extern const char *names187[];
static const uint32 types187 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags187 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype187_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_2 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_3 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype187_5 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes187 [] = {
g_atype187_0,
g_atype187_1,
g_atype187_2,
g_atype187_3,
g_atype187_4,
g_atype187_5,
};

static const long offsets187 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names188[];
static const uint32 types188 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags188 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype188_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype188_5 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes188 [] = {
g_atype188_0,
g_atype188_1,
g_atype188_2,
g_atype188_3,
g_atype188_4,
g_atype188_5,
};

static const long offsets188 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @I64OFF(2,0,0,3,0,0,0),
};

extern const char *names189[];
static const uint32 types189 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags189 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype189_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype189_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype189_2 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype189_3 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype189_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype189_5 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes189 [] = {
g_atype189_0,
g_atype189_1,
g_atype189_2,
g_atype189_3,
g_atype189_4,
g_atype189_5,
};

static const long offsets189 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names190[];
static const uint32 types190 [] =
{
SK_REF,
SK_REF,
SK_CHAR32,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags190 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype190_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype190_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype190_2 [] = {717,0xFFFF};
static const EIF_TYPE_INDEX g_atype190_3 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype190_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype190_5 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes190 [] = {
g_atype190_0,
g_atype190_1,
g_atype190_2,
g_atype190_3,
g_atype190_4,
g_atype190_5,
};

static const long offsets190 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names191[];
static const uint32 types191 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags191 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype191_0 [] = {0xFFF9,2,687,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype191_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype191_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype191_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype191_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype191_5 [] = {714,0xFFFF};

static const EIF_TYPE_INDEX *gtypes191 [] = {
g_atype191_0,
g_atype191_1,
g_atype191_2,
g_atype191_3,
g_atype191_4,
g_atype191_5,
};

static const long offsets191 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @R64OFF(2,0,0,3,0,0,0,0),
};

extern const char *names205[];
static const uint32 types205 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags205 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype205_0 [] = {545,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_1 [] = {0xFFF5,1,545,0xFFF8,1,2131,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_2 [] = {0xFFF5,1,633,0xFFF8,1,2275,0xFFFF};

static const EIF_TYPE_INDEX *gtypes205 [] = {
g_atype205_0,
g_atype205_1,
g_atype205_2,
};

static const long offsets205 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names206[];
static const uint32 types206 [] =
{
SK_UINT8,
SK_POINTER,
};

static const uint16 attr_flags206 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype206_0 [] = {708,0xFFFF};
static const EIF_TYPE_INDEX g_atype206_1 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes206 [] = {
g_atype206_0,
g_atype206_1,
};

static const long offsets206 [] =
{
+ @CHROFF(0,0),
+ @PTROFF(0,1,0,0,0,0),
};

extern const char *names226[];
static const uint32 types226 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags226 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype226_0 [] = {765,0xFFFF};
static const EIF_TYPE_INDEX g_atype226_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype226_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype226_3 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes226 [] = {
g_atype226_0,
g_atype226_1,
g_atype226_2,
g_atype226_3,
};

static const long offsets226 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names256[];
static const uint32 types256 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags256 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype256_0 [] = {533,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype256_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype256_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype256_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype256_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype256_5 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype256_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes256 [] = {
g_atype256_0,
g_atype256_1,
g_atype256_2,
g_atype256_3,
g_atype256_4,
g_atype256_5,
g_atype256_6,
};

static const long offsets256 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names257[];
static const uint32 types257 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags257 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype257_0 [] = {534,717,0xFFFF};
static const EIF_TYPE_INDEX g_atype257_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype257_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype257_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype257_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype257_5 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype257_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes257 [] = {
g_atype257_0,
g_atype257_1,
g_atype257_2,
g_atype257_3,
g_atype257_4,
g_atype257_5,
g_atype257_6,
};

static const long offsets257 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names258[];
static const uint32 types258 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags258 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype258_0 [] = {535,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype258_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype258_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype258_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype258_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype258_5 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype258_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes258 [] = {
g_atype258_0,
g_atype258_1,
g_atype258_2,
g_atype258_3,
g_atype258_4,
g_atype258_5,
g_atype258_6,
};

static const long offsets258 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names259[];
static const uint32 types259 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags259 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype259_0 [] = {536,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype259_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype259_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype259_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype259_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype259_5 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype259_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes259 [] = {
g_atype259_0,
g_atype259_1,
g_atype259_2,
g_atype259_3,
g_atype259_4,
g_atype259_5,
g_atype259_6,
};

static const long offsets259 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names260[];
static const uint32 types260 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags260 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype260_0 [] = {537,708,0xFFFF};
static const EIF_TYPE_INDEX g_atype260_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype260_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype260_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype260_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype260_5 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype260_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes260 [] = {
g_atype260_0,
g_atype260_1,
g_atype260_2,
g_atype260_3,
g_atype260_4,
g_atype260_5,
g_atype260_6,
};

static const long offsets260 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names261[];
static const uint32 types261 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags261 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype261_0 [] = {538,705,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_5 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes261 [] = {
g_atype261_0,
g_atype261_1,
g_atype261_2,
g_atype261_3,
g_atype261_4,
g_atype261_5,
g_atype261_6,
};

static const long offsets261 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names262[];
static const uint32 types262 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags262 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype262_0 [] = {539,759,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_5 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes262 [] = {
g_atype262_0,
g_atype262_1,
g_atype262_2,
g_atype262_3,
g_atype262_4,
g_atype262_5,
g_atype262_6,
};

static const long offsets262 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names263[];
static const uint32 types263 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags263 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype263_0 [] = {540,711,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_5 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes263 [] = {
g_atype263_0,
g_atype263_1,
g_atype263_2,
g_atype263_3,
g_atype263_4,
g_atype263_5,
g_atype263_6,
};

static const long offsets263 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names264[];
static const uint32 types264 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags264 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype264_0 [] = {541,714,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_5 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes264 [] = {
g_atype264_0,
g_atype264_1,
g_atype264_2,
g_atype264_3,
g_atype264_4,
g_atype264_5,
g_atype264_6,
};

static const long offsets264 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names265[];
static const uint32 types265 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags265 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype265_0 [] = {542,702,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_5 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes265 [] = {
g_atype265_0,
g_atype265_1,
g_atype265_2,
g_atype265_3,
g_atype265_4,
g_atype265_5,
g_atype265_6,
};

static const long offsets265 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names266[];
static const uint32 types266 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags266 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype266_0 [] = {543,723,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_5 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes266 [] = {
g_atype266_0,
g_atype266_1,
g_atype266_2,
g_atype266_3,
g_atype266_4,
g_atype266_5,
g_atype266_6,
};

static const long offsets266 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names267[];
static const uint32 types267 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags267 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype267_0 [] = {544,699,0xFFFF};
static const EIF_TYPE_INDEX g_atype267_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype267_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype267_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype267_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype267_5 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype267_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes267 [] = {
g_atype267_0,
g_atype267_1,
g_atype267_2,
g_atype267_3,
g_atype267_4,
g_atype267_5,
g_atype267_6,
};

static const long offsets267 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names268[];
static const uint32 types268 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags268 [] =
{0,0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype268_0 [] = {630,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype268_1 [] = {43,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype268_2 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype268_3 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype268_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype268_5 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype268_6 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype268_7 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes268 [] = {
g_atype268_0,
g_atype268_1,
g_atype268_2,
g_atype268_3,
g_atype268_4,
g_atype268_5,
g_atype268_6,
g_atype268_7,
};

static const long offsets268 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
+ @LNGOFF(2,1,0,4),
};

extern const char *names269[];
static const uint32 types269 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags269 [] =
{0,0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype269_0 [] = {631,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype269_1 [] = {44,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype269_2 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype269_3 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype269_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype269_5 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype269_6 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype269_7 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes269 [] = {
g_atype269_0,
g_atype269_1,
g_atype269_2,
g_atype269_3,
g_atype269_4,
g_atype269_5,
g_atype269_6,
g_atype269_7,
};

static const long offsets269 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
+ @LNGOFF(2,1,0,4),
};

extern const char *names270[];
static const uint32 types270 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags270 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype270_0 [] = {646,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_5 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes270 [] = {
g_atype270_0,
g_atype270_1,
g_atype270_2,
g_atype270_3,
g_atype270_4,
g_atype270_5,
g_atype270_6,
};

static const long offsets270 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names271[];
static const uint32 types271 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags271 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype271_0 [] = {647,759,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_5 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes271 [] = {
g_atype271_0,
g_atype271_1,
g_atype271_2,
g_atype271_3,
g_atype271_4,
g_atype271_5,
g_atype271_6,
};

static const long offsets271 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names272[];
static const uint32 types272 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags272 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype272_0 [] = {648,690,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype272_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype272_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype272_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype272_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype272_5 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype272_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes272 [] = {
g_atype272_0,
g_atype272_1,
g_atype272_2,
g_atype272_3,
g_atype272_4,
g_atype272_5,
g_atype272_6,
};

static const long offsets272 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names273[];
static const uint32 types273 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags273 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype273_0 [] = {649,0xFFF8,1,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_5 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes273 [] = {
g_atype273_0,
g_atype273_1,
g_atype273_2,
g_atype273_3,
g_atype273_4,
g_atype273_5,
g_atype273_6,
};

static const long offsets273 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names274[];
static const uint32 types274 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags274 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype274_0 [] = {650,690,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype274_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype274_2 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype274_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype274_4 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype274_5 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype274_6 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes274 [] = {
g_atype274_0,
g_atype274_1,
g_atype274_2,
g_atype274_3,
g_atype274_4,
g_atype274_5,
g_atype274_6,
};

static const long offsets274 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names275[];
static const uint32 types275 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags275 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype275_0 [] = {545,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes275 [] = {
g_atype275_0,
g_atype275_1,
g_atype275_2,
};

static const long offsets275 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names276[];
static const uint32 types276 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags276 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype276_0 [] = {546,717,0xFFFF};
static const EIF_TYPE_INDEX g_atype276_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype276_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes276 [] = {
g_atype276_0,
g_atype276_1,
g_atype276_2,
};

static const long offsets276 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names277[];
static const uint32 types277 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags277 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype277_0 [] = {547,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype277_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype277_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes277 [] = {
g_atype277_0,
g_atype277_1,
g_atype277_2,
};

static const long offsets277 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names278[];
static const uint32 types278 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags278 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype278_0 [] = {548,708,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes278 [] = {
g_atype278_0,
g_atype278_1,
g_atype278_2,
};

static const long offsets278 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names279[];
static const uint32 types279 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags279 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype279_0 [] = {549,705,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes279 [] = {
g_atype279_0,
g_atype279_1,
g_atype279_2,
};

static const long offsets279 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names280[];
static const uint32 types280 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags280 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype280_0 [] = {550,759,0xFFFF};
static const EIF_TYPE_INDEX g_atype280_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype280_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes280 [] = {
g_atype280_0,
g_atype280_1,
g_atype280_2,
};

static const long offsets280 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names281[];
static const uint32 types281 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags281 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype281_0 [] = {551,711,0xFFFF};
static const EIF_TYPE_INDEX g_atype281_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype281_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes281 [] = {
g_atype281_0,
g_atype281_1,
g_atype281_2,
};

static const long offsets281 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names282[];
static const uint32 types282 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags282 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype282_0 [] = {552,714,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype282_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes282 [] = {
g_atype282_0,
g_atype282_1,
g_atype282_2,
};

static const long offsets282 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names283[];
static const uint32 types283 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags283 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype283_0 [] = {553,702,0xFFFF};
static const EIF_TYPE_INDEX g_atype283_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype283_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes283 [] = {
g_atype283_0,
g_atype283_1,
g_atype283_2,
};

static const long offsets283 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names284[];
static const uint32 types284 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags284 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype284_0 [] = {554,723,0xFFFF};
static const EIF_TYPE_INDEX g_atype284_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype284_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes284 [] = {
g_atype284_0,
g_atype284_1,
g_atype284_2,
};

static const long offsets284 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names285[];
static const uint32 types285 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags285 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype285_0 [] = {555,699,0xFFFF};
static const EIF_TYPE_INDEX g_atype285_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype285_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes285 [] = {
g_atype285_0,
g_atype285_1,
g_atype285_2,
};

static const long offsets285 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names286[];
static const uint32 types286 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags286 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype286_0 [] = {556,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype286_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype286_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes286 [] = {
g_atype286_0,
g_atype286_1,
g_atype286_2,
};

static const long offsets286 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names287[];
static const uint32 types287 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags287 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype287_0 [] = {545,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_1 [] = {634,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype287_3 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes287 [] = {
g_atype287_0,
g_atype287_1,
g_atype287_2,
g_atype287_3,
};

static const long offsets287 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names288[];
static const uint32 types288 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags288 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype288_0 [] = {546,717,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_1 [] = {635,717,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_3 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes288 [] = {
g_atype288_0,
g_atype288_1,
g_atype288_2,
g_atype288_3,
};

static const long offsets288 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names289[];
static const uint32 types289 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags289 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype289_0 [] = {547,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_1 [] = {636,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_3 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes289 [] = {
g_atype289_0,
g_atype289_1,
g_atype289_2,
g_atype289_3,
};

static const long offsets289 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names290[];
static const uint32 types290 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags290 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype290_0 [] = {548,708,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_1 [] = {637,708,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype290_3 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes290 [] = {
g_atype290_0,
g_atype290_1,
g_atype290_2,
g_atype290_3,
};

static const long offsets290 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names291[];
static const uint32 types291 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags291 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype291_0 [] = {549,705,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_1 [] = {638,705,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype291_3 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes291 [] = {
g_atype291_0,
g_atype291_1,
g_atype291_2,
g_atype291_3,
};

static const long offsets291 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names292[];
static const uint32 types292 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags292 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype292_0 [] = {550,759,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_1 [] = {639,759,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype292_3 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes292 [] = {
g_atype292_0,
g_atype292_1,
g_atype292_2,
g_atype292_3,
};

static const long offsets292 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names293[];
static const uint32 types293 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags293 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype293_0 [] = {551,711,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_1 [] = {640,711,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype293_3 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes293 [] = {
g_atype293_0,
g_atype293_1,
g_atype293_2,
g_atype293_3,
};

static const long offsets293 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names294[];
static const uint32 types294 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags294 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype294_0 [] = {552,714,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_1 [] = {641,714,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_3 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes294 [] = {
g_atype294_0,
g_atype294_1,
g_atype294_2,
g_atype294_3,
};

static const long offsets294 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names295[];
static const uint32 types295 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags295 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype295_0 [] = {553,702,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_1 [] = {642,702,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_3 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes295 [] = {
g_atype295_0,
g_atype295_1,
g_atype295_2,
g_atype295_3,
};

static const long offsets295 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names296[];
static const uint32 types296 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags296 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype296_0 [] = {554,723,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_1 [] = {643,723,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_3 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes296 [] = {
g_atype296_0,
g_atype296_1,
g_atype296_2,
g_atype296_3,
};

static const long offsets296 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names297[];
static const uint32 types297 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags297 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype297_0 [] = {555,699,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_1 [] = {644,699,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_3 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes297 [] = {
g_atype297_0,
g_atype297_1,
g_atype297_2,
g_atype297_3,
};

static const long offsets297 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names298[];
static const uint32 types298 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags298 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype298_0 [] = {556,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_1 [] = {645,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype298_3 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes298 [] = {
g_atype298_0,
g_atype298_1,
g_atype298_2,
g_atype298_3,
};

static const long offsets298 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names299[];
static const uint32 types299 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags299 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype299_0 [] = {546,717,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_1 [] = {768,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype299_4 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes299 [] = {
g_atype299_0,
g_atype299_1,
g_atype299_2,
g_atype299_3,
g_atype299_4,
};

static const long offsets299 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names300[];
static const uint32 types300 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags300 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype300_0 [] = {547,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_1 [] = {771,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_4 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes300 [] = {
g_atype300_0,
g_atype300_1,
g_atype300_2,
g_atype300_3,
g_atype300_4,
};

static const long offsets300 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names301[];
static const uint32 types301 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags301 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype301_0 [] = {545,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype301_1 [] = {570,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype301_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype301_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype301_4 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes301 [] = {
g_atype301_0,
g_atype301_1,
g_atype301_2,
g_atype301_3,
g_atype301_4,
};

static const long offsets301 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names302[];
static const uint32 types302 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags302 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype302_0 [] = {546,717,0xFFFF};
static const EIF_TYPE_INDEX g_atype302_1 [] = {571,717,0xFFFF};
static const EIF_TYPE_INDEX g_atype302_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype302_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype302_4 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes302 [] = {
g_atype302_0,
g_atype302_1,
g_atype302_2,
g_atype302_3,
g_atype302_4,
};

static const long offsets302 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names303[];
static const uint32 types303 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags303 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype303_0 [] = {547,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype303_1 [] = {572,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype303_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype303_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype303_4 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes303 [] = {
g_atype303_0,
g_atype303_1,
g_atype303_2,
g_atype303_3,
g_atype303_4,
};

static const long offsets303 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names304[];
static const uint32 types304 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags304 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype304_0 [] = {548,708,0xFFFF};
static const EIF_TYPE_INDEX g_atype304_1 [] = {573,708,0xFFFF};
static const EIF_TYPE_INDEX g_atype304_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype304_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype304_4 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes304 [] = {
g_atype304_0,
g_atype304_1,
g_atype304_2,
g_atype304_3,
g_atype304_4,
};

static const long offsets304 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names305[];
static const uint32 types305 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags305 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype305_0 [] = {549,705,0xFFFF};
static const EIF_TYPE_INDEX g_atype305_1 [] = {574,705,0xFFFF};
static const EIF_TYPE_INDEX g_atype305_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype305_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype305_4 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes305 [] = {
g_atype305_0,
g_atype305_1,
g_atype305_2,
g_atype305_3,
g_atype305_4,
};

static const long offsets305 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names306[];
static const uint32 types306 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags306 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype306_0 [] = {550,759,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_1 [] = {575,759,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_4 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes306 [] = {
g_atype306_0,
g_atype306_1,
g_atype306_2,
g_atype306_3,
g_atype306_4,
};

static const long offsets306 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names307[];
static const uint32 types307 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags307 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype307_0 [] = {551,711,0xFFFF};
static const EIF_TYPE_INDEX g_atype307_1 [] = {576,711,0xFFFF};
static const EIF_TYPE_INDEX g_atype307_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype307_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype307_4 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes307 [] = {
g_atype307_0,
g_atype307_1,
g_atype307_2,
g_atype307_3,
g_atype307_4,
};

static const long offsets307 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names308[];
static const uint32 types308 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags308 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype308_0 [] = {552,714,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_1 [] = {577,714,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_4 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes308 [] = {
g_atype308_0,
g_atype308_1,
g_atype308_2,
g_atype308_3,
g_atype308_4,
};

static const long offsets308 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names309[];
static const uint32 types309 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags309 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype309_0 [] = {553,702,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_1 [] = {578,702,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype309_4 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes309 [] = {
g_atype309_0,
g_atype309_1,
g_atype309_2,
g_atype309_3,
g_atype309_4,
};

static const long offsets309 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names310[];
static const uint32 types310 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags310 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype310_0 [] = {554,723,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_1 [] = {579,723,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_4 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes310 [] = {
g_atype310_0,
g_atype310_1,
g_atype310_2,
g_atype310_3,
g_atype310_4,
};

static const long offsets310 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names311[];
static const uint32 types311 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags311 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype311_0 [] = {555,699,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_1 [] = {580,699,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_4 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes311 [] = {
g_atype311_0,
g_atype311_1,
g_atype311_2,
g_atype311_3,
g_atype311_4,
};

static const long offsets311 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names312[];
static const uint32 types312 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags312 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype312_0 [] = {556,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_1 [] = {581,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_4 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes312 [] = {
g_atype312_0,
g_atype312_1,
g_atype312_2,
g_atype312_3,
g_atype312_4,
};

static const long offsets312 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names313[];
static const uint32 types313 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags313 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype313_0 [] = {545,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes313 [] = {
g_atype313_0,
g_atype313_1,
g_atype313_2,
};

static const long offsets313 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names314[];
static const uint32 types314 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags314 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype314_0 [] = {546,717,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes314 [] = {
g_atype314_0,
g_atype314_1,
g_atype314_2,
};

static const long offsets314 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names315[];
static const uint32 types315 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags315 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype315_0 [] = {547,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype315_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype315_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes315 [] = {
g_atype315_0,
g_atype315_1,
g_atype315_2,
};

static const long offsets315 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names316[];
static const uint32 types316 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags316 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype316_0 [] = {548,708,0xFFFF};
static const EIF_TYPE_INDEX g_atype316_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype316_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes316 [] = {
g_atype316_0,
g_atype316_1,
g_atype316_2,
};

static const long offsets316 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names317[];
static const uint32 types317 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags317 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype317_0 [] = {549,705,0xFFFF};
static const EIF_TYPE_INDEX g_atype317_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype317_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes317 [] = {
g_atype317_0,
g_atype317_1,
g_atype317_2,
};

static const long offsets317 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names318[];
static const uint32 types318 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags318 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype318_0 [] = {550,759,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes318 [] = {
g_atype318_0,
g_atype318_1,
g_atype318_2,
};

static const long offsets318 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names319[];
static const uint32 types319 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags319 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype319_0 [] = {551,711,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes319 [] = {
g_atype319_0,
g_atype319_1,
g_atype319_2,
};

static const long offsets319 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names320[];
static const uint32 types320 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags320 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype320_0 [] = {552,714,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes320 [] = {
g_atype320_0,
g_atype320_1,
g_atype320_2,
};

static const long offsets320 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names321[];
static const uint32 types321 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags321 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype321_0 [] = {553,702,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes321 [] = {
g_atype321_0,
g_atype321_1,
g_atype321_2,
};

static const long offsets321 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names322[];
static const uint32 types322 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags322 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype322_0 [] = {554,723,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes322 [] = {
g_atype322_0,
g_atype322_1,
g_atype322_2,
};

static const long offsets322 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names323[];
static const uint32 types323 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags323 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype323_0 [] = {555,699,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes323 [] = {
g_atype323_0,
g_atype323_1,
g_atype323_2,
};

static const long offsets323 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names324[];
static const uint32 types324 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags324 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype324_0 [] = {556,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes324 [] = {
g_atype324_0,
g_atype324_1,
g_atype324_2,
};

static const long offsets324 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names325[];
static const uint32 types325 [] =
{
SK_BOOL,
};

static const uint16 attr_flags325 [] =
{0,};

static const EIF_TYPE_INDEX g_atype325_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes325 [] = {
g_atype325_0,
};

static const long offsets325 [] =
{
+ @CHROFF(0,0),
};

extern const char *names326[];
static const uint32 types326 [] =
{
SK_BOOL,
};

static const uint16 attr_flags326 [] =
{0,};

static const EIF_TYPE_INDEX g_atype326_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes326 [] = {
g_atype326_0,
};

static const long offsets326 [] =
{
+ @CHROFF(0,0),
};

extern const char *names327[];
static const uint32 types327 [] =
{
SK_BOOL,
};

static const uint16 attr_flags327 [] =
{0,};

static const EIF_TYPE_INDEX g_atype327_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes327 [] = {
g_atype327_0,
};

static const long offsets327 [] =
{
+ @CHROFF(0,0),
};

extern const char *names328[];
static const uint32 types328 [] =
{
SK_BOOL,
};

static const uint16 attr_flags328 [] =
{0,};

static const EIF_TYPE_INDEX g_atype328_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes328 [] = {
g_atype328_0,
};

static const long offsets328 [] =
{
+ @CHROFF(0,0),
};

extern const char *names329[];
static const uint32 types329 [] =
{
SK_BOOL,
};

static const uint16 attr_flags329 [] =
{0,};

static const EIF_TYPE_INDEX g_atype329_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes329 [] = {
g_atype329_0,
};

static const long offsets329 [] =
{
+ @CHROFF(0,0),
};

extern const char *names330[];
static const uint32 types330 [] =
{
SK_BOOL,
};

static const uint16 attr_flags330 [] =
{0,};

static const EIF_TYPE_INDEX g_atype330_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes330 [] = {
g_atype330_0,
};

static const long offsets330 [] =
{
+ @CHROFF(0,0),
};

extern const char *names331[];
static const uint32 types331 [] =
{
SK_BOOL,
};

static const uint16 attr_flags331 [] =
{0,};

static const EIF_TYPE_INDEX g_atype331_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes331 [] = {
g_atype331_0,
};

static const long offsets331 [] =
{
+ @CHROFF(0,0),
};

extern const char *names332[];
static const uint32 types332 [] =
{
SK_BOOL,
};

static const uint16 attr_flags332 [] =
{0,};

static const EIF_TYPE_INDEX g_atype332_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes332 [] = {
g_atype332_0,
};

static const long offsets332 [] =
{
+ @CHROFF(0,0),
};

extern const char *names333[];
static const uint32 types333 [] =
{
SK_BOOL,
};

static const uint16 attr_flags333 [] =
{0,};

static const EIF_TYPE_INDEX g_atype333_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes333 [] = {
g_atype333_0,
};

static const long offsets333 [] =
{
+ @CHROFF(0,0),
};

extern const char *names334[];
static const uint32 types334 [] =
{
SK_BOOL,
};

static const uint16 attr_flags334 [] =
{0,};

static const EIF_TYPE_INDEX g_atype334_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes334 [] = {
g_atype334_0,
};

static const long offsets334 [] =
{
+ @CHROFF(0,0),
};

extern const char *names335[];
static const uint32 types335 [] =
{
SK_BOOL,
};

static const uint16 attr_flags335 [] =
{0,};

static const EIF_TYPE_INDEX g_atype335_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes335 [] = {
g_atype335_0,
};

static const long offsets335 [] =
{
+ @CHROFF(0,0),
};

extern const char *names336[];
static const uint32 types336 [] =
{
SK_BOOL,
};

static const uint16 attr_flags336 [] =
{0,};

static const EIF_TYPE_INDEX g_atype336_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes336 [] = {
g_atype336_0,
};

static const long offsets336 [] =
{
+ @CHROFF(0,0),
};

extern const char *names337[];
static const uint32 types337 [] =
{
SK_BOOL,
};

static const uint16 attr_flags337 [] =
{0,};

static const EIF_TYPE_INDEX g_atype337_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes337 [] = {
g_atype337_0,
};

static const long offsets337 [] =
{
+ @CHROFF(0,0),
};

extern const char *names338[];
static const uint32 types338 [] =
{
SK_BOOL,
};

static const uint16 attr_flags338 [] =
{0,};

static const EIF_TYPE_INDEX g_atype338_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes338 [] = {
g_atype338_0,
};

static const long offsets338 [] =
{
+ @CHROFF(0,0),
};

extern const char *names339[];
static const uint32 types339 [] =
{
SK_BOOL,
};

static const uint16 attr_flags339 [] =
{0,};

static const EIF_TYPE_INDEX g_atype339_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes339 [] = {
g_atype339_0,
};

static const long offsets339 [] =
{
+ @CHROFF(0,0),
};

extern const char *names340[];
static const uint32 types340 [] =
{
SK_BOOL,
};

static const uint16 attr_flags340 [] =
{0,};

static const EIF_TYPE_INDEX g_atype340_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes340 [] = {
g_atype340_0,
};

static const long offsets340 [] =
{
+ @CHROFF(0,0),
};

extern const char *names341[];
static const uint32 types341 [] =
{
SK_BOOL,
};

static const uint16 attr_flags341 [] =
{0,};

static const EIF_TYPE_INDEX g_atype341_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes341 [] = {
g_atype341_0,
};

static const long offsets341 [] =
{
+ @CHROFF(0,0),
};

extern const char *names342[];
static const uint32 types342 [] =
{
SK_BOOL,
};

static const uint16 attr_flags342 [] =
{0,};

static const EIF_TYPE_INDEX g_atype342_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes342 [] = {
g_atype342_0,
};

static const long offsets342 [] =
{
+ @CHROFF(0,0),
};

extern const char *names343[];
static const uint32 types343 [] =
{
SK_BOOL,
};

static const uint16 attr_flags343 [] =
{0,};

static const EIF_TYPE_INDEX g_atype343_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes343 [] = {
g_atype343_0,
};

static const long offsets343 [] =
{
+ @CHROFF(0,0),
};

extern const char *names344[];
static const uint32 types344 [] =
{
SK_BOOL,
};

static const uint16 attr_flags344 [] =
{0,};

static const EIF_TYPE_INDEX g_atype344_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes344 [] = {
g_atype344_0,
};

static const long offsets344 [] =
{
+ @CHROFF(0,0),
};

extern const char *names345[];
static const uint32 types345 [] =
{
SK_BOOL,
};

static const uint16 attr_flags345 [] =
{0,};

static const EIF_TYPE_INDEX g_atype345_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes345 [] = {
g_atype345_0,
};

static const long offsets345 [] =
{
+ @CHROFF(0,0),
};

extern const char *names346[];
static const uint32 types346 [] =
{
SK_BOOL,
};

static const uint16 attr_flags346 [] =
{0,};

static const EIF_TYPE_INDEX g_atype346_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes346 [] = {
g_atype346_0,
};

static const long offsets346 [] =
{
+ @CHROFF(0,0),
};

extern const char *names347[];
static const uint32 types347 [] =
{
SK_BOOL,
};

static const uint16 attr_flags347 [] =
{0,};

static const EIF_TYPE_INDEX g_atype347_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes347 [] = {
g_atype347_0,
};

static const long offsets347 [] =
{
+ @CHROFF(0,0),
};

extern const char *names348[];
static const uint32 types348 [] =
{
SK_BOOL,
};

static const uint16 attr_flags348 [] =
{0,};

static const EIF_TYPE_INDEX g_atype348_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes348 [] = {
g_atype348_0,
};

static const long offsets348 [] =
{
+ @CHROFF(0,0),
};

extern const char *names349[];
static const uint32 types349 [] =
{
SK_BOOL,
};

static const uint16 attr_flags349 [] =
{0,};

static const EIF_TYPE_INDEX g_atype349_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes349 [] = {
g_atype349_0,
};

static const long offsets349 [] =
{
+ @CHROFF(0,0),
};

extern const char *names350[];
static const uint32 types350 [] =
{
SK_BOOL,
};

static const uint16 attr_flags350 [] =
{0,};

static const EIF_TYPE_INDEX g_atype350_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes350 [] = {
g_atype350_0,
};

static const long offsets350 [] =
{
+ @CHROFF(0,0),
};

extern const char *names351[];
static const uint32 types351 [] =
{
SK_BOOL,
};

static const uint16 attr_flags351 [] =
{0,};

static const EIF_TYPE_INDEX g_atype351_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes351 [] = {
g_atype351_0,
};

static const long offsets351 [] =
{
+ @CHROFF(0,0),
};

extern const char *names352[];
static const uint32 types352 [] =
{
SK_BOOL,
};

static const uint16 attr_flags352 [] =
{0,};

static const EIF_TYPE_INDEX g_atype352_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes352 [] = {
g_atype352_0,
};

static const long offsets352 [] =
{
+ @CHROFF(0,0),
};

extern const char *names353[];
static const uint32 types353 [] =
{
SK_BOOL,
};

static const uint16 attr_flags353 [] =
{0,};

static const EIF_TYPE_INDEX g_atype353_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes353 [] = {
g_atype353_0,
};

static const long offsets353 [] =
{
+ @CHROFF(0,0),
};

extern const char *names354[];
static const uint32 types354 [] =
{
SK_BOOL,
};

static const uint16 attr_flags354 [] =
{0,};

static const EIF_TYPE_INDEX g_atype354_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes354 [] = {
g_atype354_0,
};

static const long offsets354 [] =
{
+ @CHROFF(0,0),
};

extern const char *names355[];
static const uint32 types355 [] =
{
SK_BOOL,
};

static const uint16 attr_flags355 [] =
{0,};

static const EIF_TYPE_INDEX g_atype355_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes355 [] = {
g_atype355_0,
};

static const long offsets355 [] =
{
+ @CHROFF(0,0),
};

extern const char *names356[];
static const uint32 types356 [] =
{
SK_BOOL,
};

static const uint16 attr_flags356 [] =
{0,};

static const EIF_TYPE_INDEX g_atype356_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes356 [] = {
g_atype356_0,
};

static const long offsets356 [] =
{
+ @CHROFF(0,0),
};

extern const char *names357[];
static const uint32 types357 [] =
{
SK_BOOL,
};

static const uint16 attr_flags357 [] =
{0,};

static const EIF_TYPE_INDEX g_atype357_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes357 [] = {
g_atype357_0,
};

static const long offsets357 [] =
{
+ @CHROFF(0,0),
};

extern const char *names358[];
static const uint32 types358 [] =
{
SK_BOOL,
};

static const uint16 attr_flags358 [] =
{0,};

static const EIF_TYPE_INDEX g_atype358_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes358 [] = {
g_atype358_0,
};

static const long offsets358 [] =
{
+ @CHROFF(0,0),
};

extern const char *names359[];
static const uint32 types359 [] =
{
SK_BOOL,
};

static const uint16 attr_flags359 [] =
{0,};

static const EIF_TYPE_INDEX g_atype359_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes359 [] = {
g_atype359_0,
};

static const long offsets359 [] =
{
+ @CHROFF(0,0),
};

extern const char *names360[];
static const uint32 types360 [] =
{
SK_BOOL,
};

static const uint16 attr_flags360 [] =
{0,};

static const EIF_TYPE_INDEX g_atype360_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes360 [] = {
g_atype360_0,
};

static const long offsets360 [] =
{
+ @CHROFF(0,0),
};

extern const char *names361[];
static const uint32 types361 [] =
{
SK_BOOL,
};

static const uint16 attr_flags361 [] =
{0,};

static const EIF_TYPE_INDEX g_atype361_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes361 [] = {
g_atype361_0,
};

static const long offsets361 [] =
{
+ @CHROFF(0,0),
};

extern const char *names362[];
static const uint32 types362 [] =
{
SK_BOOL,
};

static const uint16 attr_flags362 [] =
{0,};

static const EIF_TYPE_INDEX g_atype362_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes362 [] = {
g_atype362_0,
};

static const long offsets362 [] =
{
+ @CHROFF(0,0),
};

extern const char *names363[];
static const uint32 types363 [] =
{
SK_BOOL,
};

static const uint16 attr_flags363 [] =
{0,};

static const EIF_TYPE_INDEX g_atype363_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes363 [] = {
g_atype363_0,
};

static const long offsets363 [] =
{
+ @CHROFF(0,0),
};

extern const char *names364[];
static const uint32 types364 [] =
{
SK_BOOL,
};

static const uint16 attr_flags364 [] =
{0,};

static const EIF_TYPE_INDEX g_atype364_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes364 [] = {
g_atype364_0,
};

static const long offsets364 [] =
{
+ @CHROFF(0,0),
};

extern const char *names365[];
static const uint32 types365 [] =
{
SK_BOOL,
};

static const uint16 attr_flags365 [] =
{0,};

static const EIF_TYPE_INDEX g_atype365_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes365 [] = {
g_atype365_0,
};

static const long offsets365 [] =
{
+ @CHROFF(0,0),
};

extern const char *names366[];
static const uint32 types366 [] =
{
SK_BOOL,
};

static const uint16 attr_flags366 [] =
{0,};

static const EIF_TYPE_INDEX g_atype366_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes366 [] = {
g_atype366_0,
};

static const long offsets366 [] =
{
+ @CHROFF(0,0),
};

extern const char *names367[];
static const uint32 types367 [] =
{
SK_BOOL,
};

static const uint16 attr_flags367 [] =
{0,};

static const EIF_TYPE_INDEX g_atype367_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes367 [] = {
g_atype367_0,
};

static const long offsets367 [] =
{
+ @CHROFF(0,0),
};

extern const char *names368[];
static const uint32 types368 [] =
{
SK_BOOL,
};

static const uint16 attr_flags368 [] =
{0,};

static const EIF_TYPE_INDEX g_atype368_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes368 [] = {
g_atype368_0,
};

static const long offsets368 [] =
{
+ @CHROFF(0,0),
};

extern const char *names369[];
static const uint32 types369 [] =
{
SK_BOOL,
};

static const uint16 attr_flags369 [] =
{0,};

static const EIF_TYPE_INDEX g_atype369_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes369 [] = {
g_atype369_0,
};

static const long offsets369 [] =
{
+ @CHROFF(0,0),
};

extern const char *names370[];
static const uint32 types370 [] =
{
SK_BOOL,
};

static const uint16 attr_flags370 [] =
{0,};

static const EIF_TYPE_INDEX g_atype370_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes370 [] = {
g_atype370_0,
};

static const long offsets370 [] =
{
+ @CHROFF(0,0),
};

extern const char *names371[];
static const uint32 types371 [] =
{
SK_BOOL,
};

static const uint16 attr_flags371 [] =
{0,};

static const EIF_TYPE_INDEX g_atype371_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes371 [] = {
g_atype371_0,
};

static const long offsets371 [] =
{
+ @CHROFF(0,0),
};

extern const char *names372[];
static const uint32 types372 [] =
{
SK_BOOL,
};

static const uint16 attr_flags372 [] =
{0,};

static const EIF_TYPE_INDEX g_atype372_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes372 [] = {
g_atype372_0,
};

static const long offsets372 [] =
{
+ @CHROFF(0,0),
};

extern const char *names373[];
static const uint32 types373 [] =
{
SK_BOOL,
};

static const uint16 attr_flags373 [] =
{0,};

static const EIF_TYPE_INDEX g_atype373_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes373 [] = {
g_atype373_0,
};

static const long offsets373 [] =
{
+ @CHROFF(0,0),
};

extern const char *names374[];
static const uint32 types374 [] =
{
SK_BOOL,
};

static const uint16 attr_flags374 [] =
{0,};

static const EIF_TYPE_INDEX g_atype374_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes374 [] = {
g_atype374_0,
};

static const long offsets374 [] =
{
+ @CHROFF(0,0),
};

extern const char *names375[];
static const uint32 types375 [] =
{
SK_BOOL,
};

static const uint16 attr_flags375 [] =
{0,};

static const EIF_TYPE_INDEX g_atype375_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes375 [] = {
g_atype375_0,
};

static const long offsets375 [] =
{
+ @CHROFF(0,0),
};

extern const char *names376[];
static const uint32 types376 [] =
{
SK_BOOL,
};

static const uint16 attr_flags376 [] =
{0,};

static const EIF_TYPE_INDEX g_atype376_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes376 [] = {
g_atype376_0,
};

static const long offsets376 [] =
{
+ @CHROFF(0,0),
};

extern const char *names377[];
static const uint32 types377 [] =
{
SK_BOOL,
};

static const uint16 attr_flags377 [] =
{0,};

static const EIF_TYPE_INDEX g_atype377_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes377 [] = {
g_atype377_0,
};

static const long offsets377 [] =
{
+ @CHROFF(0,0),
};

extern const char *names378[];
static const uint32 types378 [] =
{
SK_BOOL,
};

static const uint16 attr_flags378 [] =
{0,};

static const EIF_TYPE_INDEX g_atype378_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes378 [] = {
g_atype378_0,
};

static const long offsets378 [] =
{
+ @CHROFF(0,0),
};

extern const char *names379[];
static const uint32 types379 [] =
{
SK_BOOL,
};

static const uint16 attr_flags379 [] =
{0,};

static const EIF_TYPE_INDEX g_atype379_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes379 [] = {
g_atype379_0,
};

static const long offsets379 [] =
{
+ @CHROFF(0,0),
};

extern const char *names380[];
static const uint32 types380 [] =
{
SK_BOOL,
};

static const uint16 attr_flags380 [] =
{0,};

static const EIF_TYPE_INDEX g_atype380_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes380 [] = {
g_atype380_0,
};

static const long offsets380 [] =
{
+ @CHROFF(0,0),
};

extern const char *names381[];
static const uint32 types381 [] =
{
SK_BOOL,
};

static const uint16 attr_flags381 [] =
{0,};

static const EIF_TYPE_INDEX g_atype381_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes381 [] = {
g_atype381_0,
};

static const long offsets381 [] =
{
+ @CHROFF(0,0),
};

extern const char *names382[];
static const uint32 types382 [] =
{
SK_BOOL,
};

static const uint16 attr_flags382 [] =
{0,};

static const EIF_TYPE_INDEX g_atype382_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes382 [] = {
g_atype382_0,
};

static const long offsets382 [] =
{
+ @CHROFF(0,0),
};

extern const char *names383[];
static const uint32 types383 [] =
{
SK_BOOL,
};

static const uint16 attr_flags383 [] =
{0,};

static const EIF_TYPE_INDEX g_atype383_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes383 [] = {
g_atype383_0,
};

static const long offsets383 [] =
{
+ @CHROFF(0,0),
};

extern const char *names384[];
static const uint32 types384 [] =
{
SK_BOOL,
};

static const uint16 attr_flags384 [] =
{0,};

static const EIF_TYPE_INDEX g_atype384_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes384 [] = {
g_atype384_0,
};

static const long offsets384 [] =
{
+ @CHROFF(0,0),
};

extern const char *names385[];
static const uint32 types385 [] =
{
SK_BOOL,
};

static const uint16 attr_flags385 [] =
{0,};

static const EIF_TYPE_INDEX g_atype385_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes385 [] = {
g_atype385_0,
};

static const long offsets385 [] =
{
+ @CHROFF(0,0),
};

extern const char *names386[];
static const uint32 types386 [] =
{
SK_BOOL,
};

static const uint16 attr_flags386 [] =
{0,};

static const EIF_TYPE_INDEX g_atype386_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes386 [] = {
g_atype386_0,
};

static const long offsets386 [] =
{
+ @CHROFF(0,0),
};

extern const char *names387[];
static const uint32 types387 [] =
{
SK_BOOL,
};

static const uint16 attr_flags387 [] =
{0,};

static const EIF_TYPE_INDEX g_atype387_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes387 [] = {
g_atype387_0,
};

static const long offsets387 [] =
{
+ @CHROFF(0,0),
};

extern const char *names388[];
static const uint32 types388 [] =
{
SK_BOOL,
};

static const uint16 attr_flags388 [] =
{0,};

static const EIF_TYPE_INDEX g_atype388_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes388 [] = {
g_atype388_0,
};

static const long offsets388 [] =
{
+ @CHROFF(0,0),
};

extern const char *names389[];
static const uint32 types389 [] =
{
SK_BOOL,
};

static const uint16 attr_flags389 [] =
{0,};

static const EIF_TYPE_INDEX g_atype389_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes389 [] = {
g_atype389_0,
};

static const long offsets389 [] =
{
+ @CHROFF(0,0),
};

extern const char *names390[];
static const uint32 types390 [] =
{
SK_BOOL,
};

static const uint16 attr_flags390 [] =
{0,};

static const EIF_TYPE_INDEX g_atype390_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes390 [] = {
g_atype390_0,
};

static const long offsets390 [] =
{
+ @CHROFF(0,0),
};

extern const char *names391[];
static const uint32 types391 [] =
{
SK_BOOL,
};

static const uint16 attr_flags391 [] =
{0,};

static const EIF_TYPE_INDEX g_atype391_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes391 [] = {
g_atype391_0,
};

static const long offsets391 [] =
{
+ @CHROFF(0,0),
};

extern const char *names392[];
static const uint32 types392 [] =
{
SK_BOOL,
};

static const uint16 attr_flags392 [] =
{0,};

static const EIF_TYPE_INDEX g_atype392_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes392 [] = {
g_atype392_0,
};

static const long offsets392 [] =
{
+ @CHROFF(0,0),
};

extern const char *names393[];
static const uint32 types393 [] =
{
SK_BOOL,
};

static const uint16 attr_flags393 [] =
{0,};

static const EIF_TYPE_INDEX g_atype393_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes393 [] = {
g_atype393_0,
};

static const long offsets393 [] =
{
+ @CHROFF(0,0),
};

extern const char *names394[];
static const uint32 types394 [] =
{
SK_BOOL,
};

static const uint16 attr_flags394 [] =
{0,};

static const EIF_TYPE_INDEX g_atype394_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes394 [] = {
g_atype394_0,
};

static const long offsets394 [] =
{
+ @CHROFF(0,0),
};

extern const char *names395[];
static const uint32 types395 [] =
{
SK_BOOL,
};

static const uint16 attr_flags395 [] =
{0,};

static const EIF_TYPE_INDEX g_atype395_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes395 [] = {
g_atype395_0,
};

static const long offsets395 [] =
{
+ @CHROFF(0,0),
};

extern const char *names396[];
static const uint32 types396 [] =
{
SK_BOOL,
};

static const uint16 attr_flags396 [] =
{0,};

static const EIF_TYPE_INDEX g_atype396_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes396 [] = {
g_atype396_0,
};

static const long offsets396 [] =
{
+ @CHROFF(0,0),
};

extern const char *names397[];
static const uint32 types397 [] =
{
SK_BOOL,
};

static const uint16 attr_flags397 [] =
{0,};

static const EIF_TYPE_INDEX g_atype397_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes397 [] = {
g_atype397_0,
};

static const long offsets397 [] =
{
+ @CHROFF(0,0),
};

extern const char *names398[];
static const uint32 types398 [] =
{
SK_BOOL,
};

static const uint16 attr_flags398 [] =
{0,};

static const EIF_TYPE_INDEX g_atype398_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes398 [] = {
g_atype398_0,
};

static const long offsets398 [] =
{
+ @CHROFF(0,0),
};

extern const char *names399[];
static const uint32 types399 [] =
{
SK_BOOL,
};

static const uint16 attr_flags399 [] =
{0,};

static const EIF_TYPE_INDEX g_atype399_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes399 [] = {
g_atype399_0,
};

static const long offsets399 [] =
{
+ @CHROFF(0,0),
};

extern const char *names400[];
static const uint32 types400 [] =
{
SK_BOOL,
};

static const uint16 attr_flags400 [] =
{0,};

static const EIF_TYPE_INDEX g_atype400_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes400 [] = {
g_atype400_0,
};

static const long offsets400 [] =
{
+ @CHROFF(0,0),
};

extern const char *names401[];
static const uint32 types401 [] =
{
SK_BOOL,
};

static const uint16 attr_flags401 [] =
{0,};

static const EIF_TYPE_INDEX g_atype401_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes401 [] = {
g_atype401_0,
};

static const long offsets401 [] =
{
+ @CHROFF(0,0),
};

extern const char *names402[];
static const uint32 types402 [] =
{
SK_BOOL,
};

static const uint16 attr_flags402 [] =
{0,};

static const EIF_TYPE_INDEX g_atype402_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes402 [] = {
g_atype402_0,
};

static const long offsets402 [] =
{
+ @CHROFF(0,0),
};

extern const char *names403[];
static const uint32 types403 [] =
{
SK_BOOL,
};

static const uint16 attr_flags403 [] =
{0,};

static const EIF_TYPE_INDEX g_atype403_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes403 [] = {
g_atype403_0,
};

static const long offsets403 [] =
{
+ @CHROFF(0,0),
};

extern const char *names404[];
static const uint32 types404 [] =
{
SK_BOOL,
};

static const uint16 attr_flags404 [] =
{0,};

static const EIF_TYPE_INDEX g_atype404_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes404 [] = {
g_atype404_0,
};

static const long offsets404 [] =
{
+ @CHROFF(0,0),
};

extern const char *names405[];
static const uint32 types405 [] =
{
SK_BOOL,
};

static const uint16 attr_flags405 [] =
{0,};

static const EIF_TYPE_INDEX g_atype405_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes405 [] = {
g_atype405_0,
};

static const long offsets405 [] =
{
+ @CHROFF(0,0),
};

extern const char *names406[];
static const uint32 types406 [] =
{
SK_BOOL,
};

static const uint16 attr_flags406 [] =
{0,};

static const EIF_TYPE_INDEX g_atype406_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes406 [] = {
g_atype406_0,
};

static const long offsets406 [] =
{
+ @CHROFF(0,0),
};

extern const char *names407[];
static const uint32 types407 [] =
{
SK_BOOL,
};

static const uint16 attr_flags407 [] =
{0,};

static const EIF_TYPE_INDEX g_atype407_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes407 [] = {
g_atype407_0,
};

static const long offsets407 [] =
{
+ @CHROFF(0,0),
};

extern const char *names408[];
static const uint32 types408 [] =
{
SK_BOOL,
};

static const uint16 attr_flags408 [] =
{0,};

static const EIF_TYPE_INDEX g_atype408_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes408 [] = {
g_atype408_0,
};

static const long offsets408 [] =
{
+ @CHROFF(0,0),
};

extern const char *names409[];
static const uint32 types409 [] =
{
SK_BOOL,
};

static const uint16 attr_flags409 [] =
{0,};

static const EIF_TYPE_INDEX g_atype409_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes409 [] = {
g_atype409_0,
};

static const long offsets409 [] =
{
+ @CHROFF(0,0),
};

extern const char *names410[];
static const uint32 types410 [] =
{
SK_BOOL,
};

static const uint16 attr_flags410 [] =
{0,};

static const EIF_TYPE_INDEX g_atype410_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes410 [] = {
g_atype410_0,
};

static const long offsets410 [] =
{
+ @CHROFF(0,0),
};

extern const char *names411[];
static const uint32 types411 [] =
{
SK_BOOL,
};

static const uint16 attr_flags411 [] =
{0,};

static const EIF_TYPE_INDEX g_atype411_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes411 [] = {
g_atype411_0,
};

static const long offsets411 [] =
{
+ @CHROFF(0,0),
};

extern const char *names412[];
static const uint32 types412 [] =
{
SK_BOOL,
};

static const uint16 attr_flags412 [] =
{0,};

static const EIF_TYPE_INDEX g_atype412_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes412 [] = {
g_atype412_0,
};

static const long offsets412 [] =
{
+ @CHROFF(0,0),
};

extern const char *names413[];
static const uint32 types413 [] =
{
SK_BOOL,
};

static const uint16 attr_flags413 [] =
{0,};

static const EIF_TYPE_INDEX g_atype413_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes413 [] = {
g_atype413_0,
};

static const long offsets413 [] =
{
+ @CHROFF(0,0),
};

extern const char *names414[];
static const uint32 types414 [] =
{
SK_BOOL,
};

static const uint16 attr_flags414 [] =
{0,};

static const EIF_TYPE_INDEX g_atype414_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes414 [] = {
g_atype414_0,
};

static const long offsets414 [] =
{
+ @CHROFF(0,0),
};

extern const char *names415[];
static const uint32 types415 [] =
{
SK_BOOL,
};

static const uint16 attr_flags415 [] =
{0,};

static const EIF_TYPE_INDEX g_atype415_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes415 [] = {
g_atype415_0,
};

static const long offsets415 [] =
{
+ @CHROFF(0,0),
};

extern const char *names416[];
static const uint32 types416 [] =
{
SK_BOOL,
};

static const uint16 attr_flags416 [] =
{0,};

static const EIF_TYPE_INDEX g_atype416_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes416 [] = {
g_atype416_0,
};

static const long offsets416 [] =
{
+ @CHROFF(0,0),
};

extern const char *names417[];
static const uint32 types417 [] =
{
SK_BOOL,
};

static const uint16 attr_flags417 [] =
{0,};

static const EIF_TYPE_INDEX g_atype417_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes417 [] = {
g_atype417_0,
};

static const long offsets417 [] =
{
+ @CHROFF(0,0),
};

extern const char *names418[];
static const uint32 types418 [] =
{
SK_BOOL,
};

static const uint16 attr_flags418 [] =
{0,};

static const EIF_TYPE_INDEX g_atype418_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes418 [] = {
g_atype418_0,
};

static const long offsets418 [] =
{
+ @CHROFF(0,0),
};

extern const char *names419[];
static const uint32 types419 [] =
{
SK_BOOL,
};

static const uint16 attr_flags419 [] =
{0,};

static const EIF_TYPE_INDEX g_atype419_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes419 [] = {
g_atype419_0,
};

static const long offsets419 [] =
{
+ @CHROFF(0,0),
};

extern const char *names420[];
static const uint32 types420 [] =
{
SK_BOOL,
};

static const uint16 attr_flags420 [] =
{0,};

static const EIF_TYPE_INDEX g_atype420_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes420 [] = {
g_atype420_0,
};

static const long offsets420 [] =
{
+ @CHROFF(0,0),
};

extern const char *names421[];
static const uint32 types421 [] =
{
SK_BOOL,
};

static const uint16 attr_flags421 [] =
{0,};

static const EIF_TYPE_INDEX g_atype421_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes421 [] = {
g_atype421_0,
};

static const long offsets421 [] =
{
+ @CHROFF(0,0),
};

extern const char *names422[];
static const uint32 types422 [] =
{
SK_BOOL,
};

static const uint16 attr_flags422 [] =
{0,};

static const EIF_TYPE_INDEX g_atype422_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes422 [] = {
g_atype422_0,
};

static const long offsets422 [] =
{
+ @CHROFF(0,0),
};

extern const char *names423[];
static const uint32 types423 [] =
{
SK_BOOL,
};

static const uint16 attr_flags423 [] =
{0,};

static const EIF_TYPE_INDEX g_atype423_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes423 [] = {
g_atype423_0,
};

static const long offsets423 [] =
{
+ @CHROFF(0,0),
};

extern const char *names424[];
static const uint32 types424 [] =
{
SK_BOOL,
};

static const uint16 attr_flags424 [] =
{0,};

static const EIF_TYPE_INDEX g_atype424_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes424 [] = {
g_atype424_0,
};

static const long offsets424 [] =
{
+ @CHROFF(0,0),
};

extern const char *names425[];
static const uint32 types425 [] =
{
SK_BOOL,
};

static const uint16 attr_flags425 [] =
{0,};

static const EIF_TYPE_INDEX g_atype425_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes425 [] = {
g_atype425_0,
};

static const long offsets425 [] =
{
+ @CHROFF(0,0),
};

extern const char *names426[];
static const uint32 types426 [] =
{
SK_BOOL,
};

static const uint16 attr_flags426 [] =
{0,};

static const EIF_TYPE_INDEX g_atype426_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes426 [] = {
g_atype426_0,
};

static const long offsets426 [] =
{
+ @CHROFF(0,0),
};

extern const char *names427[];
static const uint32 types427 [] =
{
SK_BOOL,
};

static const uint16 attr_flags427 [] =
{0,};

static const EIF_TYPE_INDEX g_atype427_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes427 [] = {
g_atype427_0,
};

static const long offsets427 [] =
{
+ @CHROFF(0,0),
};

extern const char *names428[];
static const uint32 types428 [] =
{
SK_BOOL,
};

static const uint16 attr_flags428 [] =
{0,};

static const EIF_TYPE_INDEX g_atype428_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes428 [] = {
g_atype428_0,
};

static const long offsets428 [] =
{
+ @CHROFF(0,0),
};

extern const char *names429[];
static const uint32 types429 [] =
{
SK_BOOL,
};

static const uint16 attr_flags429 [] =
{0,};

static const EIF_TYPE_INDEX g_atype429_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes429 [] = {
g_atype429_0,
};

static const long offsets429 [] =
{
+ @CHROFF(0,0),
};

extern const char *names430[];
static const uint32 types430 [] =
{
SK_BOOL,
};

static const uint16 attr_flags430 [] =
{0,};

static const EIF_TYPE_INDEX g_atype430_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes430 [] = {
g_atype430_0,
};

static const long offsets430 [] =
{
+ @CHROFF(0,0),
};

extern const char *names431[];
static const uint32 types431 [] =
{
SK_BOOL,
};

static const uint16 attr_flags431 [] =
{0,};

static const EIF_TYPE_INDEX g_atype431_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes431 [] = {
g_atype431_0,
};

static const long offsets431 [] =
{
+ @CHROFF(0,0),
};

extern const char *names432[];
static const uint32 types432 [] =
{
SK_BOOL,
};

static const uint16 attr_flags432 [] =
{0,};

static const EIF_TYPE_INDEX g_atype432_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes432 [] = {
g_atype432_0,
};

static const long offsets432 [] =
{
+ @CHROFF(0,0),
};

extern const char *names433[];
static const uint32 types433 [] =
{
SK_BOOL,
};

static const uint16 attr_flags433 [] =
{0,};

static const EIF_TYPE_INDEX g_atype433_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes433 [] = {
g_atype433_0,
};

static const long offsets433 [] =
{
+ @CHROFF(0,0),
};

extern const char *names434[];
static const uint32 types434 [] =
{
SK_BOOL,
};

static const uint16 attr_flags434 [] =
{0,};

static const EIF_TYPE_INDEX g_atype434_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes434 [] = {
g_atype434_0,
};

static const long offsets434 [] =
{
+ @CHROFF(0,0),
};

extern const char *names435[];
static const uint32 types435 [] =
{
SK_BOOL,
};

static const uint16 attr_flags435 [] =
{0,};

static const EIF_TYPE_INDEX g_atype435_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes435 [] = {
g_atype435_0,
};

static const long offsets435 [] =
{
+ @CHROFF(0,0),
};

extern const char *names436[];
static const uint32 types436 [] =
{
SK_BOOL,
};

static const uint16 attr_flags436 [] =
{0,};

static const EIF_TYPE_INDEX g_atype436_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes436 [] = {
g_atype436_0,
};

static const long offsets436 [] =
{
+ @CHROFF(0,0),
};

extern const char *names437[];
static const uint32 types437 [] =
{
SK_BOOL,
};

static const uint16 attr_flags437 [] =
{0,};

static const EIF_TYPE_INDEX g_atype437_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes437 [] = {
g_atype437_0,
};

static const long offsets437 [] =
{
+ @CHROFF(0,0),
};

extern const char *names438[];
static const uint32 types438 [] =
{
SK_BOOL,
};

static const uint16 attr_flags438 [] =
{0,};

static const EIF_TYPE_INDEX g_atype438_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes438 [] = {
g_atype438_0,
};

static const long offsets438 [] =
{
+ @CHROFF(0,0),
};

extern const char *names439[];
static const uint32 types439 [] =
{
SK_BOOL,
};

static const uint16 attr_flags439 [] =
{0,};

static const EIF_TYPE_INDEX g_atype439_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes439 [] = {
g_atype439_0,
};

static const long offsets439 [] =
{
+ @CHROFF(0,0),
};

extern const char *names440[];
static const uint32 types440 [] =
{
SK_BOOL,
};

static const uint16 attr_flags440 [] =
{0,};

static const EIF_TYPE_INDEX g_atype440_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes440 [] = {
g_atype440_0,
};

static const long offsets440 [] =
{
+ @CHROFF(0,0),
};

extern const char *names441[];
static const uint32 types441 [] =
{
SK_BOOL,
};

static const uint16 attr_flags441 [] =
{0,};

static const EIF_TYPE_INDEX g_atype441_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes441 [] = {
g_atype441_0,
};

static const long offsets441 [] =
{
+ @CHROFF(0,0),
};

extern const char *names442[];
static const uint32 types442 [] =
{
SK_BOOL,
};

static const uint16 attr_flags442 [] =
{0,};

static const EIF_TYPE_INDEX g_atype442_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes442 [] = {
g_atype442_0,
};

static const long offsets442 [] =
{
+ @CHROFF(0,0),
};

extern const char *names443[];
static const uint32 types443 [] =
{
SK_BOOL,
};

static const uint16 attr_flags443 [] =
{0,};

static const EIF_TYPE_INDEX g_atype443_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes443 [] = {
g_atype443_0,
};

static const long offsets443 [] =
{
+ @CHROFF(0,0),
};

extern const char *names444[];
static const uint32 types444 [] =
{
SK_BOOL,
};

static const uint16 attr_flags444 [] =
{0,};

static const EIF_TYPE_INDEX g_atype444_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes444 [] = {
g_atype444_0,
};

static const long offsets444 [] =
{
+ @CHROFF(0,0),
};

extern const char *names445[];
static const uint32 types445 [] =
{
SK_BOOL,
};

static const uint16 attr_flags445 [] =
{0,};

static const EIF_TYPE_INDEX g_atype445_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes445 [] = {
g_atype445_0,
};

static const long offsets445 [] =
{
+ @CHROFF(0,0),
};

extern const char *names446[];
static const uint32 types446 [] =
{
SK_BOOL,
};

static const uint16 attr_flags446 [] =
{0,};

static const EIF_TYPE_INDEX g_atype446_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes446 [] = {
g_atype446_0,
};

static const long offsets446 [] =
{
+ @CHROFF(0,0),
};

extern const char *names447[];
static const uint32 types447 [] =
{
SK_BOOL,
};

static const uint16 attr_flags447 [] =
{0,};

static const EIF_TYPE_INDEX g_atype447_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes447 [] = {
g_atype447_0,
};

static const long offsets447 [] =
{
+ @CHROFF(0,0),
};

extern const char *names448[];
static const uint32 types448 [] =
{
SK_BOOL,
};

static const uint16 attr_flags448 [] =
{0,};

static const EIF_TYPE_INDEX g_atype448_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes448 [] = {
g_atype448_0,
};

static const long offsets448 [] =
{
+ @CHROFF(0,0),
};

extern const char *names449[];
static const uint32 types449 [] =
{
SK_BOOL,
};

static const uint16 attr_flags449 [] =
{0,};

static const EIF_TYPE_INDEX g_atype449_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes449 [] = {
g_atype449_0,
};

static const long offsets449 [] =
{
+ @CHROFF(0,0),
};

extern const char *names450[];
static const uint32 types450 [] =
{
SK_BOOL,
};

static const uint16 attr_flags450 [] =
{0,};

static const EIF_TYPE_INDEX g_atype450_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes450 [] = {
g_atype450_0,
};

static const long offsets450 [] =
{
+ @CHROFF(0,0),
};

extern const char *names451[];
static const uint32 types451 [] =
{
SK_BOOL,
};

static const uint16 attr_flags451 [] =
{0,};

static const EIF_TYPE_INDEX g_atype451_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes451 [] = {
g_atype451_0,
};

static const long offsets451 [] =
{
+ @CHROFF(0,0),
};

extern const char *names452[];
static const uint32 types452 [] =
{
SK_BOOL,
};

static const uint16 attr_flags452 [] =
{0,};

static const EIF_TYPE_INDEX g_atype452_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes452 [] = {
g_atype452_0,
};

static const long offsets452 [] =
{
+ @CHROFF(0,0),
};

extern const char *names453[];
static const uint32 types453 [] =
{
SK_BOOL,
};

static const uint16 attr_flags453 [] =
{0,};

static const EIF_TYPE_INDEX g_atype453_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes453 [] = {
g_atype453_0,
};

static const long offsets453 [] =
{
+ @CHROFF(0,0),
};

extern const char *names454[];
static const uint32 types454 [] =
{
SK_BOOL,
};

static const uint16 attr_flags454 [] =
{0,};

static const EIF_TYPE_INDEX g_atype454_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes454 [] = {
g_atype454_0,
};

static const long offsets454 [] =
{
+ @CHROFF(0,0),
};

extern const char *names455[];
static const uint32 types455 [] =
{
SK_BOOL,
};

static const uint16 attr_flags455 [] =
{0,};

static const EIF_TYPE_INDEX g_atype455_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes455 [] = {
g_atype455_0,
};

static const long offsets455 [] =
{
+ @CHROFF(0,0),
};

extern const char *names456[];
static const uint32 types456 [] =
{
SK_BOOL,
};

static const uint16 attr_flags456 [] =
{0,};

static const EIF_TYPE_INDEX g_atype456_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes456 [] = {
g_atype456_0,
};

static const long offsets456 [] =
{
+ @CHROFF(0,0),
};

extern const char *names457[];
static const uint32 types457 [] =
{
SK_BOOL,
};

static const uint16 attr_flags457 [] =
{0,};

static const EIF_TYPE_INDEX g_atype457_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes457 [] = {
g_atype457_0,
};

static const long offsets457 [] =
{
+ @CHROFF(0,0),
};

extern const char *names458[];
static const uint32 types458 [] =
{
SK_BOOL,
};

static const uint16 attr_flags458 [] =
{0,};

static const EIF_TYPE_INDEX g_atype458_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes458 [] = {
g_atype458_0,
};

static const long offsets458 [] =
{
+ @CHROFF(0,0),
};

extern const char *names459[];
static const uint32 types459 [] =
{
SK_BOOL,
};

static const uint16 attr_flags459 [] =
{0,};

static const EIF_TYPE_INDEX g_atype459_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes459 [] = {
g_atype459_0,
};

static const long offsets459 [] =
{
+ @CHROFF(0,0),
};

extern const char *names460[];
static const uint32 types460 [] =
{
SK_BOOL,
};

static const uint16 attr_flags460 [] =
{0,};

static const EIF_TYPE_INDEX g_atype460_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes460 [] = {
g_atype460_0,
};

static const long offsets460 [] =
{
+ @CHROFF(0,0),
};

extern const char *names461[];
static const uint32 types461 [] =
{
SK_BOOL,
};

static const uint16 attr_flags461 [] =
{0,};

static const EIF_TYPE_INDEX g_atype461_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes461 [] = {
g_atype461_0,
};

static const long offsets461 [] =
{
+ @CHROFF(0,0),
};

extern const char *names462[];
static const uint32 types462 [] =
{
SK_BOOL,
};

static const uint16 attr_flags462 [] =
{0,};

static const EIF_TYPE_INDEX g_atype462_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes462 [] = {
g_atype462_0,
};

static const long offsets462 [] =
{
+ @CHROFF(0,0),
};

extern const char *names463[];
static const uint32 types463 [] =
{
SK_BOOL,
};

static const uint16 attr_flags463 [] =
{0,};

static const EIF_TYPE_INDEX g_atype463_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes463 [] = {
g_atype463_0,
};

static const long offsets463 [] =
{
+ @CHROFF(0,0),
};

extern const char *names464[];
static const uint32 types464 [] =
{
SK_BOOL,
};

static const uint16 attr_flags464 [] =
{0,};

static const EIF_TYPE_INDEX g_atype464_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes464 [] = {
g_atype464_0,
};

static const long offsets464 [] =
{
+ @CHROFF(0,0),
};

extern const char *names465[];
static const uint32 types465 [] =
{
SK_BOOL,
};

static const uint16 attr_flags465 [] =
{0,};

static const EIF_TYPE_INDEX g_atype465_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes465 [] = {
g_atype465_0,
};

static const long offsets465 [] =
{
+ @CHROFF(0,0),
};

extern const char *names466[];
static const uint32 types466 [] =
{
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags466 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype466_0 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype466_1 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes466 [] = {
g_atype466_0,
g_atype466_1,
};

static const long offsets466 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
};

extern const char *names467[];
static const uint32 types467 [] =
{
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags467 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype467_0 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_1 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes467 [] = {
g_atype467_0,
g_atype467_1,
};

static const long offsets467 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
};

extern const char *names468[];
static const uint32 types468 [] =
{
SK_BOOL,
};

static const uint16 attr_flags468 [] =
{0,};

static const EIF_TYPE_INDEX g_atype468_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes468 [] = {
g_atype468_0,
};

static const long offsets468 [] =
{
+ @CHROFF(0,0),
};

extern const char *names469[];
static const uint32 types469 [] =
{
SK_BOOL,
};

static const uint16 attr_flags469 [] =
{0,};

static const EIF_TYPE_INDEX g_atype469_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes469 [] = {
g_atype469_0,
};

static const long offsets469 [] =
{
+ @CHROFF(0,0),
};

extern const char *names470[];
static const uint32 types470 [] =
{
SK_BOOL,
};

static const uint16 attr_flags470 [] =
{0,};

static const EIF_TYPE_INDEX g_atype470_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes470 [] = {
g_atype470_0,
};

static const long offsets470 [] =
{
+ @CHROFF(0,0),
};

extern const char *names471[];
static const uint32 types471 [] =
{
SK_BOOL,
};

static const uint16 attr_flags471 [] =
{0,};

static const EIF_TYPE_INDEX g_atype471_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes471 [] = {
g_atype471_0,
};

static const long offsets471 [] =
{
+ @CHROFF(0,0),
};

extern const char *names472[];
static const uint32 types472 [] =
{
SK_BOOL,
};

static const uint16 attr_flags472 [] =
{0,};

static const EIF_TYPE_INDEX g_atype472_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes472 [] = {
g_atype472_0,
};

static const long offsets472 [] =
{
+ @CHROFF(0,0),
};

extern const char *names473[];
static const uint32 types473 [] =
{
SK_BOOL,
};

static const uint16 attr_flags473 [] =
{0,};

static const EIF_TYPE_INDEX g_atype473_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes473 [] = {
g_atype473_0,
};

static const long offsets473 [] =
{
+ @CHROFF(0,0),
};

extern const char *names474[];
static const uint32 types474 [] =
{
SK_BOOL,
};

static const uint16 attr_flags474 [] =
{0,};

static const EIF_TYPE_INDEX g_atype474_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes474 [] = {
g_atype474_0,
};

static const long offsets474 [] =
{
+ @CHROFF(0,0),
};

extern const char *names475[];
static const uint32 types475 [] =
{
SK_BOOL,
};

static const uint16 attr_flags475 [] =
{0,};

static const EIF_TYPE_INDEX g_atype475_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes475 [] = {
g_atype475_0,
};

static const long offsets475 [] =
{
+ @CHROFF(0,0),
};

extern const char *names476[];
static const uint32 types476 [] =
{
SK_BOOL,
};

static const uint16 attr_flags476 [] =
{0,};

static const EIF_TYPE_INDEX g_atype476_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes476 [] = {
g_atype476_0,
};

static const long offsets476 [] =
{
+ @CHROFF(0,0),
};

extern const char *names477[];
static const uint32 types477 [] =
{
SK_BOOL,
};

static const uint16 attr_flags477 [] =
{0,};

static const EIF_TYPE_INDEX g_atype477_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes477 [] = {
g_atype477_0,
};

static const long offsets477 [] =
{
+ @CHROFF(0,0),
};

extern const char *names478[];
static const uint32 types478 [] =
{
SK_BOOL,
};

static const uint16 attr_flags478 [] =
{0,};

static const EIF_TYPE_INDEX g_atype478_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes478 [] = {
g_atype478_0,
};

static const long offsets478 [] =
{
+ @CHROFF(0,0),
};

extern const char *names479[];
static const uint32 types479 [] =
{
SK_BOOL,
};

static const uint16 attr_flags479 [] =
{0,};

static const EIF_TYPE_INDEX g_atype479_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes479 [] = {
g_atype479_0,
};

static const long offsets479 [] =
{
+ @CHROFF(0,0),
};

extern const char *names480[];
static const uint32 types480 [] =
{
SK_BOOL,
};

static const uint16 attr_flags480 [] =
{0,};

static const EIF_TYPE_INDEX g_atype480_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes480 [] = {
g_atype480_0,
};

static const long offsets480 [] =
{
+ @CHROFF(0,0),
};

extern const char *names481[];
static const uint32 types481 [] =
{
SK_BOOL,
};

static const uint16 attr_flags481 [] =
{0,};

static const EIF_TYPE_INDEX g_atype481_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes481 [] = {
g_atype481_0,
};

static const long offsets481 [] =
{
+ @CHROFF(0,0),
};

extern const char *names482[];
static const uint32 types482 [] =
{
SK_BOOL,
};

static const uint16 attr_flags482 [] =
{0,};

static const EIF_TYPE_INDEX g_atype482_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes482 [] = {
g_atype482_0,
};

static const long offsets482 [] =
{
+ @CHROFF(0,0),
};

extern const char *names483[];
static const uint32 types483 [] =
{
SK_BOOL,
};

static const uint16 attr_flags483 [] =
{0,};

static const EIF_TYPE_INDEX g_atype483_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes483 [] = {
g_atype483_0,
};

static const long offsets483 [] =
{
+ @CHROFF(0,0),
};

extern const char *names484[];
static const uint32 types484 [] =
{
SK_BOOL,
};

static const uint16 attr_flags484 [] =
{0,};

static const EIF_TYPE_INDEX g_atype484_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes484 [] = {
g_atype484_0,
};

static const long offsets484 [] =
{
+ @CHROFF(0,0),
};

extern const char *names485[];
static const uint32 types485 [] =
{
SK_BOOL,
};

static const uint16 attr_flags485 [] =
{0,};

static const EIF_TYPE_INDEX g_atype485_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes485 [] = {
g_atype485_0,
};

static const long offsets485 [] =
{
+ @CHROFF(0,0),
};

extern const char *names486[];
static const uint32 types486 [] =
{
SK_BOOL,
};

static const uint16 attr_flags486 [] =
{0,};

static const EIF_TYPE_INDEX g_atype486_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes486 [] = {
g_atype486_0,
};

static const long offsets486 [] =
{
+ @CHROFF(0,0),
};

extern const char *names487[];
static const uint32 types487 [] =
{
SK_BOOL,
};

static const uint16 attr_flags487 [] =
{0,};

static const EIF_TYPE_INDEX g_atype487_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes487 [] = {
g_atype487_0,
};

static const long offsets487 [] =
{
+ @CHROFF(0,0),
};

extern const char *names488[];
static const uint32 types488 [] =
{
SK_BOOL,
};

static const uint16 attr_flags488 [] =
{0,};

static const EIF_TYPE_INDEX g_atype488_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes488 [] = {
g_atype488_0,
};

static const long offsets488 [] =
{
+ @CHROFF(0,0),
};

extern const char *names489[];
static const uint32 types489 [] =
{
SK_BOOL,
};

static const uint16 attr_flags489 [] =
{0,};

static const EIF_TYPE_INDEX g_atype489_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes489 [] = {
g_atype489_0,
};

static const long offsets489 [] =
{
+ @CHROFF(0,0),
};

extern const char *names490[];
static const uint32 types490 [] =
{
SK_BOOL,
};

static const uint16 attr_flags490 [] =
{0,};

static const EIF_TYPE_INDEX g_atype490_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes490 [] = {
g_atype490_0,
};

static const long offsets490 [] =
{
+ @CHROFF(0,0),
};

extern const char *names491[];
static const uint32 types491 [] =
{
SK_BOOL,
};

static const uint16 attr_flags491 [] =
{0,};

static const EIF_TYPE_INDEX g_atype491_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes491 [] = {
g_atype491_0,
};

static const long offsets491 [] =
{
+ @CHROFF(0,0),
};

extern const char *names492[];
static const uint32 types492 [] =
{
SK_BOOL,
};

static const uint16 attr_flags492 [] =
{0,};

static const EIF_TYPE_INDEX g_atype492_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes492 [] = {
g_atype492_0,
};

static const long offsets492 [] =
{
+ @CHROFF(0,0),
};

extern const char *names493[];
static const uint32 types493 [] =
{
SK_BOOL,
};

static const uint16 attr_flags493 [] =
{0,};

static const EIF_TYPE_INDEX g_atype493_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes493 [] = {
g_atype493_0,
};

static const long offsets493 [] =
{
+ @CHROFF(0,0),
};

extern const char *names494[];
static const uint32 types494 [] =
{
SK_BOOL,
};

static const uint16 attr_flags494 [] =
{0,};

static const EIF_TYPE_INDEX g_atype494_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes494 [] = {
g_atype494_0,
};

static const long offsets494 [] =
{
+ @CHROFF(0,0),
};

extern const char *names495[];
static const uint32 types495 [] =
{
SK_BOOL,
};

static const uint16 attr_flags495 [] =
{0,};

static const EIF_TYPE_INDEX g_atype495_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes495 [] = {
g_atype495_0,
};

static const long offsets495 [] =
{
+ @CHROFF(0,0),
};

extern const char *names496[];
static const uint32 types496 [] =
{
SK_BOOL,
};

static const uint16 attr_flags496 [] =
{0,};

static const EIF_TYPE_INDEX g_atype496_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes496 [] = {
g_atype496_0,
};

static const long offsets496 [] =
{
+ @CHROFF(0,0),
};

extern const char *names497[];
static const uint32 types497 [] =
{
SK_BOOL,
};

static const uint16 attr_flags497 [] =
{0,};

static const EIF_TYPE_INDEX g_atype497_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes497 [] = {
g_atype497_0,
};

static const long offsets497 [] =
{
+ @CHROFF(0,0),
};

extern const char *names498[];
static const uint32 types498 [] =
{
SK_BOOL,
};

static const uint16 attr_flags498 [] =
{0,};

static const EIF_TYPE_INDEX g_atype498_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes498 [] = {
g_atype498_0,
};

static const long offsets498 [] =
{
+ @CHROFF(0,0),
};

extern const char *names499[];
static const uint32 types499 [] =
{
SK_BOOL,
};

static const uint16 attr_flags499 [] =
{0,};

static const EIF_TYPE_INDEX g_atype499_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes499 [] = {
g_atype499_0,
};

static const long offsets499 [] =
{
+ @CHROFF(0,0),
};

extern const char *names500[];
static const uint32 types500 [] =
{
SK_BOOL,
};

static const uint16 attr_flags500 [] =
{0,};

static const EIF_TYPE_INDEX g_atype500_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes500 [] = {
g_atype500_0,
};

static const long offsets500 [] =
{
+ @CHROFF(0,0),
};

extern const char *names501[];
static const uint32 types501 [] =
{
SK_BOOL,
};

static const uint16 attr_flags501 [] =
{0,};

static const EIF_TYPE_INDEX g_atype501_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes501 [] = {
g_atype501_0,
};

static const long offsets501 [] =
{
+ @CHROFF(0,0),
};

extern const char *names502[];
static const uint32 types502 [] =
{
SK_BOOL,
};

static const uint16 attr_flags502 [] =
{0,};

static const EIF_TYPE_INDEX g_atype502_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes502 [] = {
g_atype502_0,
};

static const long offsets502 [] =
{
+ @CHROFF(0,0),
};

extern const char *names503[];
static const uint32 types503 [] =
{
SK_BOOL,
};

static const uint16 attr_flags503 [] =
{0,};

static const EIF_TYPE_INDEX g_atype503_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes503 [] = {
g_atype503_0,
};

static const long offsets503 [] =
{
+ @CHROFF(0,0),
};

extern const char *names504[];
static const uint32 types504 [] =
{
SK_BOOL,
};

static const uint16 attr_flags504 [] =
{0,};

static const EIF_TYPE_INDEX g_atype504_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes504 [] = {
g_atype504_0,
};

static const long offsets504 [] =
{
+ @CHROFF(0,0),
};

extern const char *names505[];
static const uint32 types505 [] =
{
SK_BOOL,
};

static const uint16 attr_flags505 [] =
{0,};

static const EIF_TYPE_INDEX g_atype505_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes505 [] = {
g_atype505_0,
};

static const long offsets505 [] =
{
+ @CHROFF(0,0),
};

extern const char *names506[];
static const uint32 types506 [] =
{
SK_BOOL,
};

static const uint16 attr_flags506 [] =
{0,};

static const EIF_TYPE_INDEX g_atype506_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes506 [] = {
g_atype506_0,
};

static const long offsets506 [] =
{
+ @CHROFF(0,0),
};

extern const char *names507[];
static const uint32 types507 [] =
{
SK_BOOL,
};

static const uint16 attr_flags507 [] =
{0,};

static const EIF_TYPE_INDEX g_atype507_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes507 [] = {
g_atype507_0,
};

static const long offsets507 [] =
{
+ @CHROFF(0,0),
};

extern const char *names508[];
static const uint32 types508 [] =
{
SK_BOOL,
};

static const uint16 attr_flags508 [] =
{0,};

static const EIF_TYPE_INDEX g_atype508_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes508 [] = {
g_atype508_0,
};

static const long offsets508 [] =
{
+ @CHROFF(0,0),
};

extern const char *names509[];
static const uint32 types509 [] =
{
SK_BOOL,
};

static const uint16 attr_flags509 [] =
{0,};

static const EIF_TYPE_INDEX g_atype509_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes509 [] = {
g_atype509_0,
};

static const long offsets509 [] =
{
+ @CHROFF(0,0),
};

extern const char *names510[];
static const uint32 types510 [] =
{
SK_BOOL,
};

static const uint16 attr_flags510 [] =
{0,};

static const EIF_TYPE_INDEX g_atype510_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes510 [] = {
g_atype510_0,
};

static const long offsets510 [] =
{
+ @CHROFF(0,0),
};

extern const char *names511[];
static const uint32 types511 [] =
{
SK_BOOL,
};

static const uint16 attr_flags511 [] =
{0,};

static const EIF_TYPE_INDEX g_atype511_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes511 [] = {
g_atype511_0,
};

static const long offsets511 [] =
{
+ @CHROFF(0,0),
};

extern const char *names512[];
static const uint32 types512 [] =
{
SK_BOOL,
};

static const uint16 attr_flags512 [] =
{0,};

static const EIF_TYPE_INDEX g_atype512_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes512 [] = {
g_atype512_0,
};

static const long offsets512 [] =
{
+ @CHROFF(0,0),
};

extern const char *names513[];
static const uint32 types513 [] =
{
SK_BOOL,
};

static const uint16 attr_flags513 [] =
{0,};

static const EIF_TYPE_INDEX g_atype513_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes513 [] = {
g_atype513_0,
};

static const long offsets513 [] =
{
+ @CHROFF(0,0),
};

extern const char *names514[];
static const uint32 types514 [] =
{
SK_BOOL,
};

static const uint16 attr_flags514 [] =
{0,};

static const EIF_TYPE_INDEX g_atype514_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes514 [] = {
g_atype514_0,
};

static const long offsets514 [] =
{
+ @CHROFF(0,0),
};

extern const char *names515[];
static const uint32 types515 [] =
{
SK_BOOL,
};

static const uint16 attr_flags515 [] =
{0,};

static const EIF_TYPE_INDEX g_atype515_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes515 [] = {
g_atype515_0,
};

static const long offsets515 [] =
{
+ @CHROFF(0,0),
};

extern const char *names516[];
static const uint32 types516 [] =
{
SK_BOOL,
};

static const uint16 attr_flags516 [] =
{0,};

static const EIF_TYPE_INDEX g_atype516_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes516 [] = {
g_atype516_0,
};

static const long offsets516 [] =
{
+ @CHROFF(0,0),
};

extern const char *names517[];
static const uint32 types517 [] =
{
SK_BOOL,
};

static const uint16 attr_flags517 [] =
{0,};

static const EIF_TYPE_INDEX g_atype517_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes517 [] = {
g_atype517_0,
};

static const long offsets517 [] =
{
+ @CHROFF(0,0),
};

extern const char *names518[];
static const uint32 types518 [] =
{
SK_BOOL,
};

static const uint16 attr_flags518 [] =
{0,};

static const EIF_TYPE_INDEX g_atype518_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes518 [] = {
g_atype518_0,
};

static const long offsets518 [] =
{
+ @CHROFF(0,0),
};

extern const char *names519[];
static const uint32 types519 [] =
{
SK_BOOL,
};

static const uint16 attr_flags519 [] =
{0,};

static const EIF_TYPE_INDEX g_atype519_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes519 [] = {
g_atype519_0,
};

static const long offsets519 [] =
{
+ @CHROFF(0,0),
};

extern const char *names520[];
static const uint32 types520 [] =
{
SK_BOOL,
};

static const uint16 attr_flags520 [] =
{0,};

static const EIF_TYPE_INDEX g_atype520_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes520 [] = {
g_atype520_0,
};

static const long offsets520 [] =
{
+ @CHROFF(0,0),
};

extern const char *names521[];
static const uint32 types521 [] =
{
SK_BOOL,
};

static const uint16 attr_flags521 [] =
{0,};

static const EIF_TYPE_INDEX g_atype521_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes521 [] = {
g_atype521_0,
};

static const long offsets521 [] =
{
+ @CHROFF(0,0),
};

extern const char *names522[];
static const uint32 types522 [] =
{
SK_BOOL,
};

static const uint16 attr_flags522 [] =
{0,};

static const EIF_TYPE_INDEX g_atype522_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes522 [] = {
g_atype522_0,
};

static const long offsets522 [] =
{
+ @CHROFF(0,0),
};

extern const char *names523[];
static const uint32 types523 [] =
{
SK_BOOL,
};

static const uint16 attr_flags523 [] =
{0,};

static const EIF_TYPE_INDEX g_atype523_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes523 [] = {
g_atype523_0,
};

static const long offsets523 [] =
{
+ @CHROFF(0,0),
};

extern const char *names524[];
static const uint32 types524 [] =
{
SK_BOOL,
};

static const uint16 attr_flags524 [] =
{0,};

static const EIF_TYPE_INDEX g_atype524_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes524 [] = {
g_atype524_0,
};

static const long offsets524 [] =
{
+ @CHROFF(0,0),
};

extern const char *names525[];
static const uint32 types525 [] =
{
SK_BOOL,
};

static const uint16 attr_flags525 [] =
{0,};

static const EIF_TYPE_INDEX g_atype525_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes525 [] = {
g_atype525_0,
};

static const long offsets525 [] =
{
+ @CHROFF(0,0),
};

extern const char *names526[];
static const uint32 types526 [] =
{
SK_BOOL,
};

static const uint16 attr_flags526 [] =
{0,};

static const EIF_TYPE_INDEX g_atype526_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes526 [] = {
g_atype526_0,
};

static const long offsets526 [] =
{
+ @CHROFF(0,0),
};

extern const char *names527[];
static const uint32 types527 [] =
{
SK_BOOL,
};

static const uint16 attr_flags527 [] =
{0,};

static const EIF_TYPE_INDEX g_atype527_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes527 [] = {
g_atype527_0,
};

static const long offsets527 [] =
{
+ @CHROFF(0,0),
};

extern const char *names528[];
static const uint32 types528 [] =
{
SK_BOOL,
};

static const uint16 attr_flags528 [] =
{0,};

static const EIF_TYPE_INDEX g_atype528_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes528 [] = {
g_atype528_0,
};

static const long offsets528 [] =
{
+ @CHROFF(0,0),
};

extern const char *names529[];
static const uint32 types529 [] =
{
SK_BOOL,
};

static const uint16 attr_flags529 [] =
{0,};

static const EIF_TYPE_INDEX g_atype529_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes529 [] = {
g_atype529_0,
};

static const long offsets529 [] =
{
+ @CHROFF(0,0),
};

extern const char *names530[];
static const uint32 types530 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags530 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype530_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype530_1 [] = {765,0xFFFF};
static const EIF_TYPE_INDEX g_atype530_2 [] = {114,0xFFFF};
static const EIF_TYPE_INDEX g_atype530_3 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype530_4 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype530_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype530_6 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype530_7 [] = {708,0xFFFF};
static const EIF_TYPE_INDEX g_atype530_8 [] = {696,0xFFFF};
static const EIF_TYPE_INDEX g_atype530_9 [] = {705,0xFFFF};
static const EIF_TYPE_INDEX g_atype530_10 [] = {693,0xFFFF};
static const EIF_TYPE_INDEX g_atype530_11 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype530_12 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype530_13 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype530_14 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype530_15 [] = {711,0xFFFF};
static const EIF_TYPE_INDEX g_atype530_16 [] = {759,0xFFFF};
static const EIF_TYPE_INDEX g_atype530_17 [] = {699,0xFFFF};
static const EIF_TYPE_INDEX g_atype530_18 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype530_19 [] = {714,0xFFFF};

static const EIF_TYPE_INDEX *gtypes530 [] = {
g_atype530_0,
g_atype530_1,
g_atype530_2,
g_atype530_3,
g_atype530_4,
g_atype530_5,
g_atype530_6,
g_atype530_7,
g_atype530_8,
g_atype530_9,
g_atype530_10,
g_atype530_11,
g_atype530_12,
g_atype530_13,
g_atype530_14,
g_atype530_15,
g_atype530_16,
g_atype530_17,
g_atype530_18,
g_atype530_19,
};

static const long offsets530 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @CHROFF(3,3),
+ @CHROFF(3,4),
+ @CHROFF(3,5),
+ @I16OFF(3,6,0),
+ @I16OFF(3,6,1),
+ @LNGOFF(3,6,2,0),
+ @LNGOFF(3,6,2,1),
+ @LNGOFF(3,6,2,2),
+ @LNGOFF(3,6,2,3),
+ @R32OFF(3,6,2,4,0),
+ @PTROFF(3,6,2,4,1,0),
+ @I64OFF(3,6,2,4,1,1,0),
+ @I64OFF(3,6,2,4,1,1,1),
+ @R64OFF(3,6,2,4,1,1,2,0),
};

extern const char *names531[];
static const uint32 types531 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags531 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype531_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype531_1 [] = {765,0xFFFF};
static const EIF_TYPE_INDEX g_atype531_2 [] = {114,0xFFFF};
static const EIF_TYPE_INDEX g_atype531_3 [] = {770,0xFFFF};
static const EIF_TYPE_INDEX g_atype531_4 [] = {5,0xFFFF};
static const EIF_TYPE_INDEX g_atype531_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype531_6 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype531_7 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype531_8 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype531_9 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype531_10 [] = {708,0xFFFF};
static const EIF_TYPE_INDEX g_atype531_11 [] = {696,0xFFFF};
static const EIF_TYPE_INDEX g_atype531_12 [] = {705,0xFFFF};
static const EIF_TYPE_INDEX g_atype531_13 [] = {693,0xFFFF};
static const EIF_TYPE_INDEX g_atype531_14 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype531_15 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype531_16 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype531_17 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype531_18 [] = {711,0xFFFF};
static const EIF_TYPE_INDEX g_atype531_19 [] = {759,0xFFFF};
static const EIF_TYPE_INDEX g_atype531_20 [] = {699,0xFFFF};
static const EIF_TYPE_INDEX g_atype531_21 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype531_22 [] = {714,0xFFFF};

static const EIF_TYPE_INDEX *gtypes531 [] = {
g_atype531_0,
g_atype531_1,
g_atype531_2,
g_atype531_3,
g_atype531_4,
g_atype531_5,
g_atype531_6,
g_atype531_7,
g_atype531_8,
g_atype531_9,
g_atype531_10,
g_atype531_11,
g_atype531_12,
g_atype531_13,
g_atype531_14,
g_atype531_15,
g_atype531_16,
g_atype531_17,
g_atype531_18,
g_atype531_19,
g_atype531_20,
g_atype531_21,
g_atype531_22,
};

static const long offsets531 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @I16OFF(5,7,0),
+ @I16OFF(5,7,1),
+ @LNGOFF(5,7,2,0),
+ @LNGOFF(5,7,2,1),
+ @LNGOFF(5,7,2,2),
+ @LNGOFF(5,7,2,3),
+ @R32OFF(5,7,2,4,0),
+ @PTROFF(5,7,2,4,1,0),
+ @I64OFF(5,7,2,4,1,1,0),
+ @I64OFF(5,7,2,4,1,1,1),
+ @R64OFF(5,7,2,4,1,1,2,0),
};

extern const char *names532[];
static const uint32 types532 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags532 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype532_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype532_1 [] = {765,0xFFFF};
static const EIF_TYPE_INDEX g_atype532_2 [] = {114,0xFFFF};
static const EIF_TYPE_INDEX g_atype532_3 [] = {114,0xFFFF};
static const EIF_TYPE_INDEX g_atype532_4 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype532_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype532_6 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype532_7 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype532_8 [] = {708,0xFFFF};
static const EIF_TYPE_INDEX g_atype532_9 [] = {696,0xFFFF};
static const EIF_TYPE_INDEX g_atype532_10 [] = {705,0xFFFF};
static const EIF_TYPE_INDEX g_atype532_11 [] = {693,0xFFFF};
static const EIF_TYPE_INDEX g_atype532_12 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype532_13 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype532_14 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype532_15 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype532_16 [] = {711,0xFFFF};
static const EIF_TYPE_INDEX g_atype532_17 [] = {759,0xFFFF};
static const EIF_TYPE_INDEX g_atype532_18 [] = {699,0xFFFF};
static const EIF_TYPE_INDEX g_atype532_19 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype532_20 [] = {714,0xFFFF};

static const EIF_TYPE_INDEX *gtypes532 [] = {
g_atype532_0,
g_atype532_1,
g_atype532_2,
g_atype532_3,
g_atype532_4,
g_atype532_5,
g_atype532_6,
g_atype532_7,
g_atype532_8,
g_atype532_9,
g_atype532_10,
g_atype532_11,
g_atype532_12,
g_atype532_13,
g_atype532_14,
g_atype532_15,
g_atype532_16,
g_atype532_17,
g_atype532_18,
g_atype532_19,
g_atype532_20,
};

static const long offsets532 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @I16OFF(4,6,0),
+ @I16OFF(4,6,1),
+ @LNGOFF(4,6,2,0),
+ @LNGOFF(4,6,2,1),
+ @LNGOFF(4,6,2,2),
+ @LNGOFF(4,6,2,3),
+ @R32OFF(4,6,2,4,0),
+ @PTROFF(4,6,2,4,1,0),
+ @I64OFF(4,6,2,4,1,1,0),
+ @I64OFF(4,6,2,4,1,1,1),
+ @R64OFF(4,6,2,4,1,1,2,0),
};

extern const char *names533[];
static const uint32 types533 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags533 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype533_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype533_1 [] = {765,0xFFFF};
static const EIF_TYPE_INDEX g_atype533_2 [] = {114,0xFFFF};
static const EIF_TYPE_INDEX g_atype533_3 [] = {114,0xFFFF};
static const EIF_TYPE_INDEX g_atype533_4 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype533_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype533_6 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype533_7 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype533_8 [] = {708,0xFFFF};
static const EIF_TYPE_INDEX g_atype533_9 [] = {696,0xFFFF};
static const EIF_TYPE_INDEX g_atype533_10 [] = {705,0xFFFF};
static const EIF_TYPE_INDEX g_atype533_11 [] = {693,0xFFFF};
static const EIF_TYPE_INDEX g_atype533_12 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype533_13 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype533_14 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype533_15 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype533_16 [] = {711,0xFFFF};
static const EIF_TYPE_INDEX g_atype533_17 [] = {759,0xFFFF};
static const EIF_TYPE_INDEX g_atype533_18 [] = {699,0xFFFF};
static const EIF_TYPE_INDEX g_atype533_19 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype533_20 [] = {714,0xFFFF};

static const EIF_TYPE_INDEX *gtypes533 [] = {
g_atype533_0,
g_atype533_1,
g_atype533_2,
g_atype533_3,
g_atype533_4,
g_atype533_5,
g_atype533_6,
g_atype533_7,
g_atype533_8,
g_atype533_9,
g_atype533_10,
g_atype533_11,
g_atype533_12,
g_atype533_13,
g_atype533_14,
g_atype533_15,
g_atype533_16,
g_atype533_17,
g_atype533_18,
g_atype533_19,
g_atype533_20,
};

static const long offsets533 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @I16OFF(4,6,0),
+ @I16OFF(4,6,1),
+ @LNGOFF(4,6,2,0),
+ @LNGOFF(4,6,2,1),
+ @LNGOFF(4,6,2,2),
+ @LNGOFF(4,6,2,3),
+ @R32OFF(4,6,2,4,0),
+ @PTROFF(4,6,2,4,1,0),
+ @I64OFF(4,6,2,4,1,1,0),
+ @I64OFF(4,6,2,4,1,1,1),
+ @R64OFF(4,6,2,4,1,1,2,0),
};

extern const char *names558[];
static const uint32 types558 [] =
{
SK_BOOL,
};

static const uint16 attr_flags558 [] =
{0,};

static const EIF_TYPE_INDEX g_atype558_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes558 [] = {
g_atype558_0,
};

static const long offsets558 [] =
{
+ @CHROFF(0,0),
};

extern const char *names559[];
static const uint32 types559 [] =
{
SK_BOOL,
};

static const uint16 attr_flags559 [] =
{0,};

static const EIF_TYPE_INDEX g_atype559_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes559 [] = {
g_atype559_0,
};

static const long offsets559 [] =
{
+ @CHROFF(0,0),
};

extern const char *names560[];
static const uint32 types560 [] =
{
SK_BOOL,
};

static const uint16 attr_flags560 [] =
{0,};

static const EIF_TYPE_INDEX g_atype560_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes560 [] = {
g_atype560_0,
};

static const long offsets560 [] =
{
+ @CHROFF(0,0),
};

extern const char *names561[];
static const uint32 types561 [] =
{
SK_BOOL,
};

static const uint16 attr_flags561 [] =
{0,};

static const EIF_TYPE_INDEX g_atype561_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes561 [] = {
g_atype561_0,
};

static const long offsets561 [] =
{
+ @CHROFF(0,0),
};

extern const char *names562[];
static const uint32 types562 [] =
{
SK_BOOL,
};

static const uint16 attr_flags562 [] =
{0,};

static const EIF_TYPE_INDEX g_atype562_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes562 [] = {
g_atype562_0,
};

static const long offsets562 [] =
{
+ @CHROFF(0,0),
};

extern const char *names563[];
static const uint32 types563 [] =
{
SK_BOOL,
};

static const uint16 attr_flags563 [] =
{0,};

static const EIF_TYPE_INDEX g_atype563_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes563 [] = {
g_atype563_0,
};

static const long offsets563 [] =
{
+ @CHROFF(0,0),
};

extern const char *names564[];
static const uint32 types564 [] =
{
SK_BOOL,
};

static const uint16 attr_flags564 [] =
{0,};

static const EIF_TYPE_INDEX g_atype564_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes564 [] = {
g_atype564_0,
};

static const long offsets564 [] =
{
+ @CHROFF(0,0),
};

extern const char *names565[];
static const uint32 types565 [] =
{
SK_BOOL,
};

static const uint16 attr_flags565 [] =
{0,};

static const EIF_TYPE_INDEX g_atype565_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes565 [] = {
g_atype565_0,
};

static const long offsets565 [] =
{
+ @CHROFF(0,0),
};

extern const char *names566[];
static const uint32 types566 [] =
{
SK_BOOL,
};

static const uint16 attr_flags566 [] =
{0,};

static const EIF_TYPE_INDEX g_atype566_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes566 [] = {
g_atype566_0,
};

static const long offsets566 [] =
{
+ @CHROFF(0,0),
};

extern const char *names567[];
static const uint32 types567 [] =
{
SK_BOOL,
};

static const uint16 attr_flags567 [] =
{0,};

static const EIF_TYPE_INDEX g_atype567_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes567 [] = {
g_atype567_0,
};

static const long offsets567 [] =
{
+ @CHROFF(0,0),
};

extern const char *names568[];
static const uint32 types568 [] =
{
SK_BOOL,
};

static const uint16 attr_flags568 [] =
{0,};

static const EIF_TYPE_INDEX g_atype568_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes568 [] = {
g_atype568_0,
};

static const long offsets568 [] =
{
+ @CHROFF(0,0),
};

extern const char *names569[];
static const uint32 types569 [] =
{
SK_BOOL,
};

static const uint16 attr_flags569 [] =
{0,};

static const EIF_TYPE_INDEX g_atype569_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes569 [] = {
g_atype569_0,
};

static const long offsets569 [] =
{
+ @CHROFF(0,0),
};

extern const char *names570[];
static const uint32 types570 [] =
{
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags570 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype570_0 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype570_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes570 [] = {
g_atype570_0,
g_atype570_1,
g_atype570_2,
};

static const long offsets570 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
+ @LNGOFF(0,1,0,1),
};

extern const char *names571[];
static const uint32 types571 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags571 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype571_0 [] = {545,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype571_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype571_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype571_3 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes571 [] = {
g_atype571_0,
g_atype571_1,
g_atype571_2,
g_atype571_3,
};

static const long offsets571 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names572[];
static const uint32 types572 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags572 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype572_0 [] = {546,717,0xFFFF};
static const EIF_TYPE_INDEX g_atype572_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype572_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype572_3 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes572 [] = {
g_atype572_0,
g_atype572_1,
g_atype572_2,
g_atype572_3,
};

static const long offsets572 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names573[];
static const uint32 types573 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags573 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype573_0 [] = {547,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype573_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype573_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype573_3 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes573 [] = {
g_atype573_0,
g_atype573_1,
g_atype573_2,
g_atype573_3,
};

static const long offsets573 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names574[];
static const uint32 types574 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags574 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype574_0 [] = {548,708,0xFFFF};
static const EIF_TYPE_INDEX g_atype574_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype574_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype574_3 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes574 [] = {
g_atype574_0,
g_atype574_1,
g_atype574_2,
g_atype574_3,
};

static const long offsets574 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names575[];
static const uint32 types575 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags575 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype575_0 [] = {549,705,0xFFFF};
static const EIF_TYPE_INDEX g_atype575_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype575_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype575_3 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes575 [] = {
g_atype575_0,
g_atype575_1,
g_atype575_2,
g_atype575_3,
};

static const long offsets575 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names576[];
static const uint32 types576 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags576 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype576_0 [] = {550,759,0xFFFF};
static const EIF_TYPE_INDEX g_atype576_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype576_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype576_3 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes576 [] = {
g_atype576_0,
g_atype576_1,
g_atype576_2,
g_atype576_3,
};

static const long offsets576 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names577[];
static const uint32 types577 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags577 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype577_0 [] = {551,711,0xFFFF};
static const EIF_TYPE_INDEX g_atype577_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype577_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype577_3 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes577 [] = {
g_atype577_0,
g_atype577_1,
g_atype577_2,
g_atype577_3,
};

static const long offsets577 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names578[];
static const uint32 types578 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags578 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype578_0 [] = {552,714,0xFFFF};
static const EIF_TYPE_INDEX g_atype578_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype578_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype578_3 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes578 [] = {
g_atype578_0,
g_atype578_1,
g_atype578_2,
g_atype578_3,
};

static const long offsets578 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names579[];
static const uint32 types579 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags579 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype579_0 [] = {553,702,0xFFFF};
static const EIF_TYPE_INDEX g_atype579_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype579_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype579_3 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes579 [] = {
g_atype579_0,
g_atype579_1,
g_atype579_2,
g_atype579_3,
};

static const long offsets579 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names580[];
static const uint32 types580 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags580 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype580_0 [] = {554,723,0xFFFF};
static const EIF_TYPE_INDEX g_atype580_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype580_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype580_3 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes580 [] = {
g_atype580_0,
g_atype580_1,
g_atype580_2,
g_atype580_3,
};

static const long offsets580 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names581[];
static const uint32 types581 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags581 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype581_0 [] = {555,699,0xFFFF};
static const EIF_TYPE_INDEX g_atype581_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype581_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype581_3 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes581 [] = {
g_atype581_0,
g_atype581_1,
g_atype581_2,
g_atype581_3,
};

static const long offsets581 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names582[];
static const uint32 types582 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags582 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype582_0 [] = {556,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype582_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype582_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype582_3 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes582 [] = {
g_atype582_0,
g_atype582_1,
g_atype582_2,
g_atype582_3,
};

static const long offsets582 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names583[];
static const uint32 types583 [] =
{
SK_BOOL,
};

static const uint16 attr_flags583 [] =
{0,};

static const EIF_TYPE_INDEX g_atype583_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes583 [] = {
g_atype583_0,
};

static const long offsets583 [] =
{
+ @CHROFF(0,0),
};

extern const char *names584[];
static const uint32 types584 [] =
{
SK_BOOL,
};

static const uint16 attr_flags584 [] =
{0,};

static const EIF_TYPE_INDEX g_atype584_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes584 [] = {
g_atype584_0,
};

static const long offsets584 [] =
{
+ @CHROFF(0,0),
};

extern const char *names585[];
static const uint32 types585 [] =
{
SK_BOOL,
};

static const uint16 attr_flags585 [] =
{0,};

static const EIF_TYPE_INDEX g_atype585_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes585 [] = {
g_atype585_0,
};

static const long offsets585 [] =
{
+ @CHROFF(0,0),
};

extern const char *names586[];
static const uint32 types586 [] =
{
SK_BOOL,
};

static const uint16 attr_flags586 [] =
{0,};

static const EIF_TYPE_INDEX g_atype586_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes586 [] = {
g_atype586_0,
};

static const long offsets586 [] =
{
+ @CHROFF(0,0),
};

extern const char *names587[];
static const uint32 types587 [] =
{
SK_BOOL,
};

static const uint16 attr_flags587 [] =
{0,};

static const EIF_TYPE_INDEX g_atype587_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes587 [] = {
g_atype587_0,
};

static const long offsets587 [] =
{
+ @CHROFF(0,0),
};

extern const char *names588[];
static const uint32 types588 [] =
{
SK_BOOL,
};

static const uint16 attr_flags588 [] =
{0,};

static const EIF_TYPE_INDEX g_atype588_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes588 [] = {
g_atype588_0,
};

static const long offsets588 [] =
{
+ @CHROFF(0,0),
};

extern const char *names589[];
static const uint32 types589 [] =
{
SK_BOOL,
};

static const uint16 attr_flags589 [] =
{0,};

static const EIF_TYPE_INDEX g_atype589_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes589 [] = {
g_atype589_0,
};

static const long offsets589 [] =
{
+ @CHROFF(0,0),
};

extern const char *names590[];
static const uint32 types590 [] =
{
SK_BOOL,
};

static const uint16 attr_flags590 [] =
{0,};

static const EIF_TYPE_INDEX g_atype590_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes590 [] = {
g_atype590_0,
};

static const long offsets590 [] =
{
+ @CHROFF(0,0),
};

extern const char *names591[];
static const uint32 types591 [] =
{
SK_BOOL,
};

static const uint16 attr_flags591 [] =
{0,};

static const EIF_TYPE_INDEX g_atype591_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes591 [] = {
g_atype591_0,
};

static const long offsets591 [] =
{
+ @CHROFF(0,0),
};

extern const char *names592[];
static const uint32 types592 [] =
{
SK_BOOL,
};

static const uint16 attr_flags592 [] =
{0,};

static const EIF_TYPE_INDEX g_atype592_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes592 [] = {
g_atype592_0,
};

static const long offsets592 [] =
{
+ @CHROFF(0,0),
};

extern const char *names593[];
static const uint32 types593 [] =
{
SK_BOOL,
};

static const uint16 attr_flags593 [] =
{0,};

static const EIF_TYPE_INDEX g_atype593_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes593 [] = {
g_atype593_0,
};

static const long offsets593 [] =
{
+ @CHROFF(0,0),
};

extern const char *names594[];
static const uint32 types594 [] =
{
SK_BOOL,
};

static const uint16 attr_flags594 [] =
{0,};

static const EIF_TYPE_INDEX g_atype594_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes594 [] = {
g_atype594_0,
};

static const long offsets594 [] =
{
+ @CHROFF(0,0),
};

extern const char *names595[];
static const uint32 types595 [] =
{
SK_BOOL,
};

static const uint16 attr_flags595 [] =
{0,};

static const EIF_TYPE_INDEX g_atype595_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes595 [] = {
g_atype595_0,
};

static const long offsets595 [] =
{
+ @CHROFF(0,0),
};

extern const char *names596[];
static const uint32 types596 [] =
{
SK_BOOL,
};

static const uint16 attr_flags596 [] =
{0,};

static const EIF_TYPE_INDEX g_atype596_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes596 [] = {
g_atype596_0,
};

static const long offsets596 [] =
{
+ @CHROFF(0,0),
};

extern const char *names597[];
static const uint32 types597 [] =
{
SK_BOOL,
};

static const uint16 attr_flags597 [] =
{0,};

static const EIF_TYPE_INDEX g_atype597_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes597 [] = {
g_atype597_0,
};

static const long offsets597 [] =
{
+ @CHROFF(0,0),
};

extern const char *names598[];
static const uint32 types598 [] =
{
SK_BOOL,
};

static const uint16 attr_flags598 [] =
{0,};

static const EIF_TYPE_INDEX g_atype598_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes598 [] = {
g_atype598_0,
};

static const long offsets598 [] =
{
+ @CHROFF(0,0),
};

extern const char *names599[];
static const uint32 types599 [] =
{
SK_BOOL,
};

static const uint16 attr_flags599 [] =
{0,};

static const EIF_TYPE_INDEX g_atype599_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes599 [] = {
g_atype599_0,
};

static const long offsets599 [] =
{
+ @CHROFF(0,0),
};

extern const char *names600[];
static const uint32 types600 [] =
{
SK_BOOL,
};

static const uint16 attr_flags600 [] =
{0,};

static const EIF_TYPE_INDEX g_atype600_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes600 [] = {
g_atype600_0,
};

static const long offsets600 [] =
{
+ @CHROFF(0,0),
};

extern const char *names601[];
static const uint32 types601 [] =
{
SK_BOOL,
};

static const uint16 attr_flags601 [] =
{0,};

static const EIF_TYPE_INDEX g_atype601_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes601 [] = {
g_atype601_0,
};

static const long offsets601 [] =
{
+ @CHROFF(0,0),
};

extern const char *names602[];
static const uint32 types602 [] =
{
SK_BOOL,
};

static const uint16 attr_flags602 [] =
{0,};

static const EIF_TYPE_INDEX g_atype602_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes602 [] = {
g_atype602_0,
};

static const long offsets602 [] =
{
+ @CHROFF(0,0),
};

extern const char *names603[];
static const uint32 types603 [] =
{
SK_BOOL,
};

static const uint16 attr_flags603 [] =
{0,};

static const EIF_TYPE_INDEX g_atype603_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes603 [] = {
g_atype603_0,
};

static const long offsets603 [] =
{
+ @CHROFF(0,0),
};

extern const char *names604[];
static const uint32 types604 [] =
{
SK_BOOL,
};

static const uint16 attr_flags604 [] =
{0,};

static const EIF_TYPE_INDEX g_atype604_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes604 [] = {
g_atype604_0,
};

static const long offsets604 [] =
{
+ @CHROFF(0,0),
};

extern const char *names605[];
static const uint32 types605 [] =
{
SK_BOOL,
};

static const uint16 attr_flags605 [] =
{0,};

static const EIF_TYPE_INDEX g_atype605_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes605 [] = {
g_atype605_0,
};

static const long offsets605 [] =
{
+ @CHROFF(0,0),
};

extern const char *names606[];
static const uint32 types606 [] =
{
SK_BOOL,
};

static const uint16 attr_flags606 [] =
{0,};

static const EIF_TYPE_INDEX g_atype606_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes606 [] = {
g_atype606_0,
};

static const long offsets606 [] =
{
+ @CHROFF(0,0),
};

extern const char *names607[];
static const uint32 types607 [] =
{
SK_BOOL,
};

static const uint16 attr_flags607 [] =
{0,};

static const EIF_TYPE_INDEX g_atype607_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes607 [] = {
g_atype607_0,
};

static const long offsets607 [] =
{
+ @CHROFF(0,0),
};

extern const char *names608[];
static const uint32 types608 [] =
{
SK_BOOL,
};

static const uint16 attr_flags608 [] =
{0,};

static const EIF_TYPE_INDEX g_atype608_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes608 [] = {
g_atype608_0,
};

static const long offsets608 [] =
{
+ @CHROFF(0,0),
};

extern const char *names609[];
static const uint32 types609 [] =
{
SK_BOOL,
};

static const uint16 attr_flags609 [] =
{0,};

static const EIF_TYPE_INDEX g_atype609_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes609 [] = {
g_atype609_0,
};

static const long offsets609 [] =
{
+ @CHROFF(0,0),
};

extern const char *names610[];
static const uint32 types610 [] =
{
SK_BOOL,
};

static const uint16 attr_flags610 [] =
{0,};

static const EIF_TYPE_INDEX g_atype610_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes610 [] = {
g_atype610_0,
};

static const long offsets610 [] =
{
+ @CHROFF(0,0),
};

extern const char *names611[];
static const uint32 types611 [] =
{
SK_BOOL,
};

static const uint16 attr_flags611 [] =
{0,};

static const EIF_TYPE_INDEX g_atype611_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes611 [] = {
g_atype611_0,
};

static const long offsets611 [] =
{
+ @CHROFF(0,0),
};

extern const char *names612[];
static const uint32 types612 [] =
{
SK_BOOL,
};

static const uint16 attr_flags612 [] =
{0,};

static const EIF_TYPE_INDEX g_atype612_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes612 [] = {
g_atype612_0,
};

static const long offsets612 [] =
{
+ @CHROFF(0,0),
};

extern const char *names613[];
static const uint32 types613 [] =
{
SK_BOOL,
};

static const uint16 attr_flags613 [] =
{0,};

static const EIF_TYPE_INDEX g_atype613_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes613 [] = {
g_atype613_0,
};

static const long offsets613 [] =
{
+ @CHROFF(0,0),
};

extern const char *names614[];
static const uint32 types614 [] =
{
SK_BOOL,
};

static const uint16 attr_flags614 [] =
{0,};

static const EIF_TYPE_INDEX g_atype614_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes614 [] = {
g_atype614_0,
};

static const long offsets614 [] =
{
+ @CHROFF(0,0),
};

extern const char *names615[];
static const uint32 types615 [] =
{
SK_BOOL,
};

static const uint16 attr_flags615 [] =
{0,};

static const EIF_TYPE_INDEX g_atype615_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes615 [] = {
g_atype615_0,
};

static const long offsets615 [] =
{
+ @CHROFF(0,0),
};

extern const char *names616[];
static const uint32 types616 [] =
{
SK_BOOL,
};

static const uint16 attr_flags616 [] =
{0,};

static const EIF_TYPE_INDEX g_atype616_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes616 [] = {
g_atype616_0,
};

static const long offsets616 [] =
{
+ @CHROFF(0,0),
};

extern const char *names617[];
static const uint32 types617 [] =
{
SK_BOOL,
};

static const uint16 attr_flags617 [] =
{0,};

static const EIF_TYPE_INDEX g_atype617_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes617 [] = {
g_atype617_0,
};

static const long offsets617 [] =
{
+ @CHROFF(0,0),
};

extern const char *names618[];
static const uint32 types618 [] =
{
SK_BOOL,
};

static const uint16 attr_flags618 [] =
{0,};

static const EIF_TYPE_INDEX g_atype618_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes618 [] = {
g_atype618_0,
};

static const long offsets618 [] =
{
+ @CHROFF(0,0),
};

extern const char *names619[];
static const uint32 types619 [] =
{
SK_BOOL,
};

static const uint16 attr_flags619 [] =
{0,};

static const EIF_TYPE_INDEX g_atype619_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes619 [] = {
g_atype619_0,
};

static const long offsets619 [] =
{
+ @CHROFF(0,0),
};

extern const char *names620[];
static const uint32 types620 [] =
{
SK_BOOL,
};

static const uint16 attr_flags620 [] =
{0,};

static const EIF_TYPE_INDEX g_atype620_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes620 [] = {
g_atype620_0,
};

static const long offsets620 [] =
{
+ @CHROFF(0,0),
};

extern const char *names621[];
static const uint32 types621 [] =
{
SK_BOOL,
};

static const uint16 attr_flags621 [] =
{0,};

static const EIF_TYPE_INDEX g_atype621_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes621 [] = {
g_atype621_0,
};

static const long offsets621 [] =
{
+ @CHROFF(0,0),
};

extern const char *names622[];
static const uint32 types622 [] =
{
SK_BOOL,
};

static const uint16 attr_flags622 [] =
{0,};

static const EIF_TYPE_INDEX g_atype622_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes622 [] = {
g_atype622_0,
};

static const long offsets622 [] =
{
+ @CHROFF(0,0),
};

extern const char *names623[];
static const uint32 types623 [] =
{
SK_BOOL,
};

static const uint16 attr_flags623 [] =
{0,};

static const EIF_TYPE_INDEX g_atype623_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes623 [] = {
g_atype623_0,
};

static const long offsets623 [] =
{
+ @CHROFF(0,0),
};

extern const char *names624[];
static const uint32 types624 [] =
{
SK_BOOL,
};

static const uint16 attr_flags624 [] =
{0,};

static const EIF_TYPE_INDEX g_atype624_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes624 [] = {
g_atype624_0,
};

static const long offsets624 [] =
{
+ @CHROFF(0,0),
};

extern const char *names625[];
static const uint32 types625 [] =
{
SK_BOOL,
};

static const uint16 attr_flags625 [] =
{0,};

static const EIF_TYPE_INDEX g_atype625_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes625 [] = {
g_atype625_0,
};

static const long offsets625 [] =
{
+ @CHROFF(0,0),
};

extern const char *names626[];
static const uint32 types626 [] =
{
SK_BOOL,
};

static const uint16 attr_flags626 [] =
{0,};

static const EIF_TYPE_INDEX g_atype626_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes626 [] = {
g_atype626_0,
};

static const long offsets626 [] =
{
+ @CHROFF(0,0),
};

extern const char *names627[];
static const uint32 types627 [] =
{
SK_BOOL,
};

static const uint16 attr_flags627 [] =
{0,};

static const EIF_TYPE_INDEX g_atype627_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes627 [] = {
g_atype627_0,
};

static const long offsets627 [] =
{
+ @CHROFF(0,0),
};

extern const char *names628[];
static const uint32 types628 [] =
{
SK_BOOL,
};

static const uint16 attr_flags628 [] =
{0,};

static const EIF_TYPE_INDEX g_atype628_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes628 [] = {
g_atype628_0,
};

static const long offsets628 [] =
{
+ @CHROFF(0,0),
};

extern const char *names629[];
static const uint32 types629 [] =
{
SK_BOOL,
};

static const uint16 attr_flags629 [] =
{0,};

static const EIF_TYPE_INDEX g_atype629_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes629 [] = {
g_atype629_0,
};

static const long offsets629 [] =
{
+ @CHROFF(0,0),
};

extern const char *names630[];
static const uint32 types630 [] =
{
SK_BOOL,
};

static const uint16 attr_flags630 [] =
{0,};

static const EIF_TYPE_INDEX g_atype630_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes630 [] = {
g_atype630_0,
};

static const long offsets630 [] =
{
+ @CHROFF(0,0),
};

extern const char *names631[];
static const uint32 types631 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags631 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype631_0 [] = {43,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype631_1 [] = {43,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype631_2 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype631_3 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype631_4 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype631_5 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes631 [] = {
g_atype631_0,
g_atype631_1,
g_atype631_2,
g_atype631_3,
g_atype631_4,
g_atype631_5,
};

static const long offsets631 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names632[];
static const uint32 types632 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags632 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype632_0 [] = {44,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype632_1 [] = {44,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype632_2 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype632_3 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype632_4 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype632_5 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes632 [] = {
g_atype632_0,
g_atype632_1,
g_atype632_2,
g_atype632_3,
g_atype632_4,
g_atype632_5,
};

static const long offsets632 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names634[];
static const uint32 types634 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags634 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype634_0 [] = {545,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype634_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype634_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype634_3 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes634 [] = {
g_atype634_0,
g_atype634_1,
g_atype634_2,
g_atype634_3,
};

static const long offsets634 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names635[];
static const uint32 types635 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags635 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype635_0 [] = {545,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype635_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype635_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes635 [] = {
g_atype635_0,
g_atype635_1,
g_atype635_2,
};

static const long offsets635 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names636[];
static const uint32 types636 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags636 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype636_0 [] = {546,717,0xFFFF};
static const EIF_TYPE_INDEX g_atype636_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype636_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes636 [] = {
g_atype636_0,
g_atype636_1,
g_atype636_2,
};

static const long offsets636 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names637[];
static const uint32 types637 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags637 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype637_0 [] = {547,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype637_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype637_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes637 [] = {
g_atype637_0,
g_atype637_1,
g_atype637_2,
};

static const long offsets637 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names638[];
static const uint32 types638 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags638 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype638_0 [] = {548,708,0xFFFF};
static const EIF_TYPE_INDEX g_atype638_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype638_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes638 [] = {
g_atype638_0,
g_atype638_1,
g_atype638_2,
};

static const long offsets638 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names639[];
static const uint32 types639 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags639 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype639_0 [] = {549,705,0xFFFF};
static const EIF_TYPE_INDEX g_atype639_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype639_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes639 [] = {
g_atype639_0,
g_atype639_1,
g_atype639_2,
};

static const long offsets639 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names640[];
static const uint32 types640 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags640 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype640_0 [] = {550,759,0xFFFF};
static const EIF_TYPE_INDEX g_atype640_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype640_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes640 [] = {
g_atype640_0,
g_atype640_1,
g_atype640_2,
};

static const long offsets640 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names641[];
static const uint32 types641 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags641 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype641_0 [] = {551,711,0xFFFF};
static const EIF_TYPE_INDEX g_atype641_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype641_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes641 [] = {
g_atype641_0,
g_atype641_1,
g_atype641_2,
};

static const long offsets641 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names642[];
static const uint32 types642 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags642 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype642_0 [] = {552,714,0xFFFF};
static const EIF_TYPE_INDEX g_atype642_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype642_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes642 [] = {
g_atype642_0,
g_atype642_1,
g_atype642_2,
};

static const long offsets642 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names643[];
static const uint32 types643 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags643 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype643_0 [] = {553,702,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype643_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes643 [] = {
g_atype643_0,
g_atype643_1,
g_atype643_2,
};

static const long offsets643 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names644[];
static const uint32 types644 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags644 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype644_0 [] = {554,723,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype644_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes644 [] = {
g_atype644_0,
g_atype644_1,
g_atype644_2,
};

static const long offsets644 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names645[];
static const uint32 types645 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags645 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype645_0 [] = {555,699,0xFFFF};
static const EIF_TYPE_INDEX g_atype645_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype645_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes645 [] = {
g_atype645_0,
g_atype645_1,
g_atype645_2,
};

static const long offsets645 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names646[];
static const uint32 types646 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags646 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype646_0 [] = {556,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype646_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype646_2 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes646 [] = {
g_atype646_0,
g_atype646_1,
g_atype646_2,
};

static const long offsets646 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names647[];
static const uint32 types647 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags647 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype647_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype647_1 [] = {545,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype647_2 [] = {545,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype647_3 [] = {556,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype647_4 [] = {554,723,0xFFFF};
static const EIF_TYPE_INDEX g_atype647_5 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype647_6 [] = {0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype647_7 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype647_8 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype647_9 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype647_10 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype647_11 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype647_12 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype647_13 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype647_14 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype647_15 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype647_16 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes647 [] = {
g_atype647_0,
g_atype647_1,
g_atype647_2,
g_atype647_3,
g_atype647_4,
g_atype647_5,
g_atype647_6,
g_atype647_7,
g_atype647_8,
g_atype647_9,
g_atype647_10,
g_atype647_11,
g_atype647_12,
g_atype647_13,
g_atype647_14,
g_atype647_15,
g_atype647_16,
};

static const long offsets647 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @LNGOFF(7,3,0,0),
+ @LNGOFF(7,3,0,1),
+ @LNGOFF(7,3,0,2),
+ @LNGOFF(7,3,0,3),
+ @LNGOFF(7,3,0,4),
+ @LNGOFF(7,3,0,5),
+ @LNGOFF(7,3,0,6),
};

extern const char *names648[];
static const uint32 types648 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags648 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype648_0 [] = {550,759,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_1 [] = {545,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_2 [] = {556,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_3 [] = {554,723,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_4 [] = {0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_6 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_7 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_8 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_9 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_10 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_11 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_12 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_13 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_14 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_15 [] = {759,0xFFFF};
static const EIF_TYPE_INDEX g_atype648_16 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes648 [] = {
g_atype648_0,
g_atype648_1,
g_atype648_2,
g_atype648_3,
g_atype648_4,
g_atype648_5,
g_atype648_6,
g_atype648_7,
g_atype648_8,
g_atype648_9,
g_atype648_10,
g_atype648_11,
g_atype648_12,
g_atype648_13,
g_atype648_14,
g_atype648_15,
g_atype648_16,
};

static const long offsets648 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @LNGOFF(5,3,0,0),
+ @LNGOFF(5,3,0,1),
+ @LNGOFF(5,3,0,2),
+ @LNGOFF(5,3,0,3),
+ @LNGOFF(5,3,0,4),
+ @LNGOFF(5,3,0,5),
+ @LNGOFF(5,3,0,6),
+ @PTROFF(5,3,0,7,0,0),
+ @PTROFF(5,3,0,7,0,1),
};

extern const char *names649[];
static const uint32 types649 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags649 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype649_0 [] = {556,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype649_1 [] = {545,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype649_2 [] = {556,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype649_3 [] = {554,723,0xFFFF};
static const EIF_TYPE_INDEX g_atype649_4 [] = {0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype649_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype649_6 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype649_7 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype649_8 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype649_9 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype649_10 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype649_11 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype649_12 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype649_13 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype649_14 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype649_15 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype649_16 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes649 [] = {
g_atype649_0,
g_atype649_1,
g_atype649_2,
g_atype649_3,
g_atype649_4,
g_atype649_5,
g_atype649_6,
g_atype649_7,
g_atype649_8,
g_atype649_9,
g_atype649_10,
g_atype649_11,
g_atype649_12,
g_atype649_13,
g_atype649_14,
g_atype649_15,
g_atype649_16,
};

static const long offsets649 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @LNGOFF(5,3,0,0),
+ @LNGOFF(5,3,0,1),
+ @LNGOFF(5,3,0,2),
+ @LNGOFF(5,3,0,3),
+ @LNGOFF(5,3,0,4),
+ @LNGOFF(5,3,0,5),
+ @LNGOFF(5,3,0,6),
+ @LNGOFF(5,3,0,7),
+ @LNGOFF(5,3,0,8),
};

extern const char *names650[];
static const uint32 types650 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags650 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype650_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype650_1 [] = {545,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype650_2 [] = {556,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype650_3 [] = {556,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype650_4 [] = {554,723,0xFFFF};
static const EIF_TYPE_INDEX g_atype650_5 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype650_6 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype650_7 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype650_8 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype650_9 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype650_10 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype650_11 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype650_12 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype650_13 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype650_14 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype650_15 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype650_16 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes650 [] = {
g_atype650_0,
g_atype650_1,
g_atype650_2,
g_atype650_3,
g_atype650_4,
g_atype650_5,
g_atype650_6,
g_atype650_7,
g_atype650_8,
g_atype650_9,
g_atype650_10,
g_atype650_11,
g_atype650_12,
g_atype650_13,
g_atype650_14,
g_atype650_15,
g_atype650_16,
};

static const long offsets650 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @LNGOFF(6,3,0,0),
+ @LNGOFF(6,3,0,1),
+ @LNGOFF(6,3,0,2),
+ @LNGOFF(6,3,0,3),
+ @LNGOFF(6,3,0,4),
+ @LNGOFF(6,3,0,5),
+ @LNGOFF(6,3,0,6),
+ @LNGOFF(6,3,0,7),
};

extern const char *names651[];
static const uint32 types651 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags651 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype651_0 [] = {556,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype651_1 [] = {556,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype651_2 [] = {556,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype651_3 [] = {554,723,0xFFFF};
static const EIF_TYPE_INDEX g_atype651_4 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype651_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype651_6 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype651_7 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype651_8 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype651_9 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype651_10 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype651_11 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype651_12 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype651_13 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype651_14 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype651_15 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype651_16 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes651 [] = {
g_atype651_0,
g_atype651_1,
g_atype651_2,
g_atype651_3,
g_atype651_4,
g_atype651_5,
g_atype651_6,
g_atype651_7,
g_atype651_8,
g_atype651_9,
g_atype651_10,
g_atype651_11,
g_atype651_12,
g_atype651_13,
g_atype651_14,
g_atype651_15,
g_atype651_16,
};

static const long offsets651 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @LNGOFF(4,3,0,3),
+ @LNGOFF(4,3,0,4),
+ @LNGOFF(4,3,0,5),
+ @LNGOFF(4,3,0,6),
+ @LNGOFF(4,3,0,7),
+ @LNGOFF(4,3,0,8),
+ @LNGOFF(4,3,0,9),
};

extern const char *names652[];
static const uint32 types652 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags652 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype652_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_1 [] = {545,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_2 [] = {545,765,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_3 [] = {556,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_4 [] = {554,723,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_5 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_6 [] = {765,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_7 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_8 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_9 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_10 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_11 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_12 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_13 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_14 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_15 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_16 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype652_17 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes652 [] = {
g_atype652_0,
g_atype652_1,
g_atype652_2,
g_atype652_3,
g_atype652_4,
g_atype652_5,
g_atype652_6,
g_atype652_7,
g_atype652_8,
g_atype652_9,
g_atype652_10,
g_atype652_11,
g_atype652_12,
g_atype652_13,
g_atype652_14,
g_atype652_15,
g_atype652_16,
g_atype652_17,
};

static const long offsets652 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @LNGOFF(7,4,0,0),
+ @LNGOFF(7,4,0,1),
+ @LNGOFF(7,4,0,2),
+ @LNGOFF(7,4,0,3),
+ @LNGOFF(7,4,0,4),
+ @LNGOFF(7,4,0,5),
+ @LNGOFF(7,4,0,6),
};

extern const char *names653[];
static const uint32 types653 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags653 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype653_0 [] = {556,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_1 [] = {545,765,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_2 [] = {556,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_3 [] = {554,723,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_4 [] = {765,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_6 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_7 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_8 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_9 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_10 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_11 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_12 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_13 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_14 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_15 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_16 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype653_17 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes653 [] = {
g_atype653_0,
g_atype653_1,
g_atype653_2,
g_atype653_3,
g_atype653_4,
g_atype653_5,
g_atype653_6,
g_atype653_7,
g_atype653_8,
g_atype653_9,
g_atype653_10,
g_atype653_11,
g_atype653_12,
g_atype653_13,
g_atype653_14,
g_atype653_15,
g_atype653_16,
g_atype653_17,
};

static const long offsets653 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @LNGOFF(5,4,0,0),
+ @LNGOFF(5,4,0,1),
+ @LNGOFF(5,4,0,2),
+ @LNGOFF(5,4,0,3),
+ @LNGOFF(5,4,0,4),
+ @LNGOFF(5,4,0,5),
+ @LNGOFF(5,4,0,6),
+ @LNGOFF(5,4,0,7),
+ @LNGOFF(5,4,0,8),
};

extern const char *names654[];
static const uint32 types654 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags654 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype654_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_1 [] = {545,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_2 [] = {545,773,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_3 [] = {556,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_4 [] = {554,723,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_5 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_6 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_7 [] = {772,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_8 [] = {772,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_9 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_10 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_11 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_12 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_13 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_14 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_15 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_16 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_17 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype654_18 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes654 [] = {
g_atype654_0,
g_atype654_1,
g_atype654_2,
g_atype654_3,
g_atype654_4,
g_atype654_5,
g_atype654_6,
g_atype654_7,
g_atype654_8,
g_atype654_9,
g_atype654_10,
g_atype654_11,
g_atype654_12,
g_atype654_13,
g_atype654_14,
g_atype654_15,
g_atype654_16,
g_atype654_17,
g_atype654_18,
};

static const long offsets654 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
+ @CHROFF(9,1),
+ @CHROFF(9,2),
+ @LNGOFF(9,3,0,0),
+ @LNGOFF(9,3,0,1),
+ @LNGOFF(9,3,0,2),
+ @LNGOFF(9,3,0,3),
+ @LNGOFF(9,3,0,4),
+ @LNGOFF(9,3,0,5),
+ @LNGOFF(9,3,0,6),
};

extern const char *names656[];
static const uint32 types656 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags656 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype656_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype656_1 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype656_2 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes656 [] = {
g_atype656_0,
g_atype656_1,
g_atype656_2,
};

static const long offsets656 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
};

extern const char *names657[];
static const uint32 types657 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags657 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype657_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype657_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes657 [] = {
g_atype657_0,
g_atype657_1,
};

static const long offsets657 [] =
{
0,
 + @REFACS(1),
};

extern const char *names658[];
static const uint32 types658 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags658 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype658_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype658_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes658 [] = {
g_atype658_0,
g_atype658_1,
};

static const long offsets658 [] =
{
0,
 + @REFACS(1),
};

extern const char *names659[];
static const uint32 types659 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags659 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype659_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype659_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes659 [] = {
g_atype659_0,
g_atype659_1,
};

static const long offsets659 [] =
{
0,
 + @REFACS(1),
};

extern const char *names660[];
static const uint32 types660 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags660 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype660_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype660_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes660 [] = {
g_atype660_0,
g_atype660_1,
};

static const long offsets660 [] =
{
0,
 + @REFACS(1),
};

extern const char *names661[];
static const uint32 types661 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags661 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype661_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype661_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes661 [] = {
g_atype661_0,
g_atype661_1,
};

static const long offsets661 [] =
{
0,
 + @REFACS(1),
};

extern const char *names662[];
static const uint32 types662 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags662 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype662_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype662_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes662 [] = {
g_atype662_0,
g_atype662_1,
};

static const long offsets662 [] =
{
0,
 + @REFACS(1),
};

extern const char *names663[];
static const uint32 types663 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags663 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype663_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype663_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes663 [] = {
g_atype663_0,
g_atype663_1,
};

static const long offsets663 [] =
{
0,
 + @REFACS(1),
};

extern const char *names664[];
static const uint32 types664 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags664 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype664_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype664_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes664 [] = {
g_atype664_0,
g_atype664_1,
};

static const long offsets664 [] =
{
0,
 + @REFACS(1),
};

extern const char *names665[];
static const uint32 types665 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags665 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype665_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype665_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes665 [] = {
g_atype665_0,
g_atype665_1,
};

static const long offsets665 [] =
{
0,
 + @REFACS(1),
};

extern const char *names666[];
static const uint32 types666 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags666 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype666_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype666_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes666 [] = {
g_atype666_0,
g_atype666_1,
};

static const long offsets666 [] =
{
0,
 + @REFACS(1),
};

extern const char *names667[];
static const uint32 types667 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags667 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype667_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype667_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes667 [] = {
g_atype667_0,
g_atype667_1,
};

static const long offsets667 [] =
{
0,
 + @REFACS(1),
};

extern const char *names668[];
static const uint32 types668 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags668 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype668_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype668_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes668 [] = {
g_atype668_0,
g_atype668_1,
};

static const long offsets668 [] =
{
0,
 + @REFACS(1),
};

extern const char *names669[];
static const uint32 types669 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags669 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype669_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype669_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes669 [] = {
g_atype669_0,
g_atype669_1,
};

static const long offsets669 [] =
{
0,
 + @REFACS(1),
};

extern const char *names670[];
static const uint32 types670 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags670 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype670_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype670_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes670 [] = {
g_atype670_0,
g_atype670_1,
};

static const long offsets670 [] =
{
0,
 + @REFACS(1),
};

extern const char *names671[];
static const uint32 types671 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags671 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype671_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype671_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes671 [] = {
g_atype671_0,
g_atype671_1,
};

static const long offsets671 [] =
{
0,
 + @REFACS(1),
};

extern const char *names672[];
static const uint32 types672 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags672 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype672_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype672_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes672 [] = {
g_atype672_0,
g_atype672_1,
};

static const long offsets672 [] =
{
0,
 + @REFACS(1),
};

extern const char *names673[];
static const uint32 types673 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags673 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype673_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype673_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes673 [] = {
g_atype673_0,
g_atype673_1,
};

static const long offsets673 [] =
{
0,
 + @REFACS(1),
};

extern const char *names674[];
static const uint32 types674 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags674 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype674_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype674_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes674 [] = {
g_atype674_0,
g_atype674_1,
};

static const long offsets674 [] =
{
0,
 + @REFACS(1),
};

extern const char *names675[];
static const uint32 types675 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags675 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype675_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype675_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes675 [] = {
g_atype675_0,
g_atype675_1,
};

static const long offsets675 [] =
{
0,
 + @REFACS(1),
};

extern const char *names676[];
static const uint32 types676 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags676 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype676_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype676_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes676 [] = {
g_atype676_0,
g_atype676_1,
};

static const long offsets676 [] =
{
0,
 + @REFACS(1),
};

extern const char *names677[];
static const uint32 types677 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags677 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype677_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype677_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes677 [] = {
g_atype677_0,
g_atype677_1,
};

static const long offsets677 [] =
{
0,
 + @REFACS(1),
};

extern const char *names678[];
static const uint32 types678 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags678 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype678_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype678_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes678 [] = {
g_atype678_0,
g_atype678_1,
};

static const long offsets678 [] =
{
0,
 + @REFACS(1),
};

extern const char *names679[];
static const uint32 types679 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags679 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype679_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype679_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes679 [] = {
g_atype679_0,
g_atype679_1,
};

static const long offsets679 [] =
{
0,
 + @REFACS(1),
};

extern const char *names680[];
static const uint32 types680 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags680 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype680_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype680_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes680 [] = {
g_atype680_0,
g_atype680_1,
};

static const long offsets680 [] =
{
0,
 + @REFACS(1),
};

extern const char *names681[];
static const uint32 types681 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags681 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype681_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype681_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes681 [] = {
g_atype681_0,
g_atype681_1,
};

static const long offsets681 [] =
{
0,
 + @REFACS(1),
};

extern const char *names682[];
static const uint32 types682 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags682 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype682_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype682_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes682 [] = {
g_atype682_0,
g_atype682_1,
};

static const long offsets682 [] =
{
0,
 + @REFACS(1),
};

extern const char *names683[];
static const uint32 types683 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags683 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype683_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype683_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes683 [] = {
g_atype683_0,
g_atype683_1,
};

static const long offsets683 [] =
{
0,
 + @REFACS(1),
};

extern const char *names684[];
static const uint32 types684 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags684 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype684_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype684_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes684 [] = {
g_atype684_0,
g_atype684_1,
};

static const long offsets684 [] =
{
0,
 + @REFACS(1),
};

extern const char *names685[];
static const uint32 types685 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags685 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype685_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype685_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes685 [] = {
g_atype685_0,
g_atype685_1,
};

static const long offsets685 [] =
{
0,
 + @REFACS(1),
};

extern const char *names686[];
static const uint32 types686 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags686 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype686_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype686_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes686 [] = {
g_atype686_0,
g_atype686_1,
};

static const long offsets686 [] =
{
0,
 + @REFACS(1),
};

extern const char *names687[];
static const uint32 types687 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags687 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype687_0 [] = {769,0xFFFF};
static const EIF_TYPE_INDEX g_atype687_1 [] = {772,0xFFFF};

static const EIF_TYPE_INDEX *gtypes687 [] = {
g_atype687_0,
g_atype687_1,
};

static const long offsets687 [] =
{
0,
 + @REFACS(1),
};

extern const char *names689[];
static const uint32 types689 [] =
{
SK_INT32,
};

static const uint16 attr_flags689 [] =
{0,};

static const EIF_TYPE_INDEX g_atype689_0 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes689 [] = {
g_atype689_0,
};

static const long offsets689 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names690[];
static const uint32 types690 [] =
{
SK_INT32,
};

static const uint16 attr_flags690 [] =
{0,};

static const EIF_TYPE_INDEX g_atype690_0 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes690 [] = {
g_atype690_0,
};

static const long offsets690 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names691[];
static const uint32 types691 [] =
{
SK_INT32,
};

static const uint16 attr_flags691 [] =
{0,};

static const EIF_TYPE_INDEX g_atype691_0 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes691 [] = {
g_atype691_0,
};

static const long offsets691 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names692[];
static const uint32 types692 [] =
{
SK_INT16,
};

static const uint16 attr_flags692 [] =
{0,};

static const EIF_TYPE_INDEX g_atype692_0 [] = {693,0xFFFF};

static const EIF_TYPE_INDEX *gtypes692 [] = {
g_atype692_0,
};

static const long offsets692 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names693[];
static const uint32 types693 [] =
{
SK_INT16,
};

static const uint16 attr_flags693 [] =
{0,};

static const EIF_TYPE_INDEX g_atype693_0 [] = {693,0xFFFF};

static const EIF_TYPE_INDEX *gtypes693 [] = {
g_atype693_0,
};

static const long offsets693 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names694[];
static const uint32 types694 [] =
{
SK_INT16,
};

static const uint16 attr_flags694 [] =
{0,};

static const EIF_TYPE_INDEX g_atype694_0 [] = {693,0xFFFF};

static const EIF_TYPE_INDEX *gtypes694 [] = {
g_atype694_0,
};

static const long offsets694 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names695[];
static const uint32 types695 [] =
{
SK_INT8,
};

static const uint16 attr_flags695 [] =
{0,};

static const EIF_TYPE_INDEX g_atype695_0 [] = {696,0xFFFF};

static const EIF_TYPE_INDEX *gtypes695 [] = {
g_atype695_0,
};

static const long offsets695 [] =
{
+ @CHROFF(0,0),
};

extern const char *names696[];
static const uint32 types696 [] =
{
SK_INT8,
};

static const uint16 attr_flags696 [] =
{0,};

static const EIF_TYPE_INDEX g_atype696_0 [] = {696,0xFFFF};

static const EIF_TYPE_INDEX *gtypes696 [] = {
g_atype696_0,
};

static const long offsets696 [] =
{
+ @CHROFF(0,0),
};

extern const char *names697[];
static const uint32 types697 [] =
{
SK_INT8,
};

static const uint16 attr_flags697 [] =
{0,};

static const EIF_TYPE_INDEX g_atype697_0 [] = {696,0xFFFF};

static const EIF_TYPE_INDEX *gtypes697 [] = {
g_atype697_0,
};

static const long offsets697 [] =
{
+ @CHROFF(0,0),
};

extern const char *names698[];
static const uint32 types698 [] =
{
SK_UINT64,
};

static const uint16 attr_flags698 [] =
{0,};

static const EIF_TYPE_INDEX g_atype698_0 [] = {699,0xFFFF};

static const EIF_TYPE_INDEX *gtypes698 [] = {
g_atype698_0,
};

static const long offsets698 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names699[];
static const uint32 types699 [] =
{
SK_UINT64,
};

static const uint16 attr_flags699 [] =
{0,};

static const EIF_TYPE_INDEX g_atype699_0 [] = {699,0xFFFF};

static const EIF_TYPE_INDEX *gtypes699 [] = {
g_atype699_0,
};

static const long offsets699 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names700[];
static const uint32 types700 [] =
{
SK_UINT64,
};

static const uint16 attr_flags700 [] =
{0,};

static const EIF_TYPE_INDEX g_atype700_0 [] = {699,0xFFFF};

static const EIF_TYPE_INDEX *gtypes700 [] = {
g_atype700_0,
};

static const long offsets700 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names701[];
static const uint32 types701 [] =
{
SK_UINT32,
};

static const uint16 attr_flags701 [] =
{0,};

static const EIF_TYPE_INDEX g_atype701_0 [] = {702,0xFFFF};

static const EIF_TYPE_INDEX *gtypes701 [] = {
g_atype701_0,
};

static const long offsets701 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names702[];
static const uint32 types702 [] =
{
SK_UINT32,
};

static const uint16 attr_flags702 [] =
{0,};

static const EIF_TYPE_INDEX g_atype702_0 [] = {702,0xFFFF};

static const EIF_TYPE_INDEX *gtypes702 [] = {
g_atype702_0,
};

static const long offsets702 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names703[];
static const uint32 types703 [] =
{
SK_UINT32,
};

static const uint16 attr_flags703 [] =
{0,};

static const EIF_TYPE_INDEX g_atype703_0 [] = {702,0xFFFF};

static const EIF_TYPE_INDEX *gtypes703 [] = {
g_atype703_0,
};

static const long offsets703 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names704[];
static const uint32 types704 [] =
{
SK_UINT16,
};

static const uint16 attr_flags704 [] =
{0,};

static const EIF_TYPE_INDEX g_atype704_0 [] = {705,0xFFFF};

static const EIF_TYPE_INDEX *gtypes704 [] = {
g_atype704_0,
};

static const long offsets704 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names705[];
static const uint32 types705 [] =
{
SK_UINT16,
};

static const uint16 attr_flags705 [] =
{0,};

static const EIF_TYPE_INDEX g_atype705_0 [] = {705,0xFFFF};

static const EIF_TYPE_INDEX *gtypes705 [] = {
g_atype705_0,
};

static const long offsets705 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names706[];
static const uint32 types706 [] =
{
SK_UINT16,
};

static const uint16 attr_flags706 [] =
{0,};

static const EIF_TYPE_INDEX g_atype706_0 [] = {705,0xFFFF};

static const EIF_TYPE_INDEX *gtypes706 [] = {
g_atype706_0,
};

static const long offsets706 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names707[];
static const uint32 types707 [] =
{
SK_UINT8,
};

static const uint16 attr_flags707 [] =
{0,};

static const EIF_TYPE_INDEX g_atype707_0 [] = {708,0xFFFF};

static const EIF_TYPE_INDEX *gtypes707 [] = {
g_atype707_0,
};

static const long offsets707 [] =
{
+ @CHROFF(0,0),
};

extern const char *names708[];
static const uint32 types708 [] =
{
SK_UINT8,
};

static const uint16 attr_flags708 [] =
{0,};

static const EIF_TYPE_INDEX g_atype708_0 [] = {708,0xFFFF};

static const EIF_TYPE_INDEX *gtypes708 [] = {
g_atype708_0,
};

static const long offsets708 [] =
{
+ @CHROFF(0,0),
};

extern const char *names709[];
static const uint32 types709 [] =
{
SK_UINT8,
};

static const uint16 attr_flags709 [] =
{0,};

static const EIF_TYPE_INDEX g_atype709_0 [] = {708,0xFFFF};

static const EIF_TYPE_INDEX *gtypes709 [] = {
g_atype709_0,
};

static const long offsets709 [] =
{
+ @CHROFF(0,0),
};

extern const char *names710[];
static const uint32 types710 [] =
{
SK_REAL32,
};

static const uint16 attr_flags710 [] =
{0,};

static const EIF_TYPE_INDEX g_atype710_0 [] = {711,0xFFFF};

static const EIF_TYPE_INDEX *gtypes710 [] = {
g_atype710_0,
};

static const long offsets710 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names711[];
static const uint32 types711 [] =
{
SK_REAL32,
};

static const uint16 attr_flags711 [] =
{0,};

static const EIF_TYPE_INDEX g_atype711_0 [] = {711,0xFFFF};

static const EIF_TYPE_INDEX *gtypes711 [] = {
g_atype711_0,
};

static const long offsets711 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names712[];
static const uint32 types712 [] =
{
SK_REAL32,
};

static const uint16 attr_flags712 [] =
{0,};

static const EIF_TYPE_INDEX g_atype712_0 [] = {711,0xFFFF};

static const EIF_TYPE_INDEX *gtypes712 [] = {
g_atype712_0,
};

static const long offsets712 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names713[];
static const uint32 types713 [] =
{
SK_REAL64,
};

static const uint16 attr_flags713 [] =
{0,};

static const EIF_TYPE_INDEX g_atype713_0 [] = {714,0xFFFF};

static const EIF_TYPE_INDEX *gtypes713 [] = {
g_atype713_0,
};

static const long offsets713 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names714[];
static const uint32 types714 [] =
{
SK_REAL64,
};

static const uint16 attr_flags714 [] =
{0,};

static const EIF_TYPE_INDEX g_atype714_0 [] = {714,0xFFFF};

static const EIF_TYPE_INDEX *gtypes714 [] = {
g_atype714_0,
};

static const long offsets714 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names715[];
static const uint32 types715 [] =
{
SK_REAL64,
};

static const uint16 attr_flags715 [] =
{0,};

static const EIF_TYPE_INDEX g_atype715_0 [] = {714,0xFFFF};

static const EIF_TYPE_INDEX *gtypes715 [] = {
g_atype715_0,
};

static const long offsets715 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names716[];
static const uint32 types716 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags716 [] =
{0,};

static const EIF_TYPE_INDEX g_atype716_0 [] = {717,0xFFFF};

static const EIF_TYPE_INDEX *gtypes716 [] = {
g_atype716_0,
};

static const long offsets716 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names717[];
static const uint32 types717 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags717 [] =
{0,};

static const EIF_TYPE_INDEX g_atype717_0 [] = {717,0xFFFF};

static const EIF_TYPE_INDEX *gtypes717 [] = {
g_atype717_0,
};

static const long offsets717 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names718[];
static const uint32 types718 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags718 [] =
{0,};

static const EIF_TYPE_INDEX g_atype718_0 [] = {717,0xFFFF};

static const EIF_TYPE_INDEX *gtypes718 [] = {
g_atype718_0,
};

static const long offsets718 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names719[];
static const uint32 types719 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags719 [] =
{0,};

static const EIF_TYPE_INDEX g_atype719_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes719 [] = {
g_atype719_0,
};

static const long offsets719 [] =
{
+ @CHROFF(0,0),
};

extern const char *names720[];
static const uint32 types720 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags720 [] =
{0,};

static const EIF_TYPE_INDEX g_atype720_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes720 [] = {
g_atype720_0,
};

static const long offsets720 [] =
{
+ @CHROFF(0,0),
};

extern const char *names721[];
static const uint32 types721 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags721 [] =
{0,};

static const EIF_TYPE_INDEX g_atype721_0 [] = {720,0xFFFF};

static const EIF_TYPE_INDEX *gtypes721 [] = {
g_atype721_0,
};

static const long offsets721 [] =
{
+ @CHROFF(0,0),
};

extern const char *names722[];
static const uint32 types722 [] =
{
SK_BOOL,
};

static const uint16 attr_flags722 [] =
{0,};

static const EIF_TYPE_INDEX g_atype722_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes722 [] = {
g_atype722_0,
};

static const long offsets722 [] =
{
+ @CHROFF(0,0),
};

extern const char *names723[];
static const uint32 types723 [] =
{
SK_BOOL,
};

static const uint16 attr_flags723 [] =
{0,};

static const EIF_TYPE_INDEX g_atype723_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes723 [] = {
g_atype723_0,
};

static const long offsets723 [] =
{
+ @CHROFF(0,0),
};

extern const char *names724[];
static const uint32 types724 [] =
{
SK_BOOL,
};

static const uint16 attr_flags724 [] =
{0,};

static const EIF_TYPE_INDEX g_atype724_0 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes724 [] = {
g_atype724_0,
};

static const long offsets724 [] =
{
+ @CHROFF(0,0),
};

extern const char *names725[];
static const uint32 types725 [] =
{
SK_INT64,
};

static const uint16 attr_flags725 [] =
{0,};

static const EIF_TYPE_INDEX g_atype725_0 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes725 [] = {
g_atype725_0,
};

static const long offsets725 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names726[];
static const uint32 types726 [] =
{
SK_INT64,
};

static const uint16 attr_flags726 [] =
{0,};

static const EIF_TYPE_INDEX g_atype726_0 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes726 [] = {
g_atype726_0,
};

static const long offsets726 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names727[];
static const uint32 types727 [] =
{
SK_INT64,
};

static const uint16 attr_flags727 [] =
{0,};

static const EIF_TYPE_INDEX g_atype727_0 [] = {726,0xFFFF};

static const EIF_TYPE_INDEX *gtypes727 [] = {
g_atype727_0,
};

static const long offsets727 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names728[];
static const uint32 types728 [] =
{
SK_POINTER,
};

static const uint16 attr_flags728 [] =
{0,};

static const EIF_TYPE_INDEX g_atype728_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes728 [] = {
g_atype728_0,
};

static const long offsets728 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names729[];
static const uint32 types729 [] =
{
SK_POINTER,
};

static const uint16 attr_flags729 [] =
{0,};

static const EIF_TYPE_INDEX g_atype729_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes729 [] = {
g_atype729_0,
};

static const long offsets729 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names730[];
static const uint32 types730 [] =
{
SK_POINTER,
};

static const uint16 attr_flags730 [] =
{0,};

static const EIF_TYPE_INDEX g_atype730_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes730 [] = {
g_atype730_0,
};

static const long offsets730 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names731[];
static const uint32 types731 [] =
{
SK_POINTER,
};

static const uint16 attr_flags731 [] =
{0,};

static const EIF_TYPE_INDEX g_atype731_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes731 [] = {
g_atype731_0,
};

static const long offsets731 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names732[];
static const uint32 types732 [] =
{
SK_POINTER,
};

static const uint16 attr_flags732 [] =
{0,};

static const EIF_TYPE_INDEX g_atype732_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes732 [] = {
g_atype732_0,
};

static const long offsets732 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names733[];
static const uint32 types733 [] =
{
SK_POINTER,
};

static const uint16 attr_flags733 [] =
{0,};

static const EIF_TYPE_INDEX g_atype733_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes733 [] = {
g_atype733_0,
};

static const long offsets733 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names734[];
static const uint32 types734 [] =
{
SK_POINTER,
};

static const uint16 attr_flags734 [] =
{0,};

static const EIF_TYPE_INDEX g_atype734_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes734 [] = {
g_atype734_0,
};

static const long offsets734 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names735[];
static const uint32 types735 [] =
{
SK_POINTER,
};

static const uint16 attr_flags735 [] =
{0,};

static const EIF_TYPE_INDEX g_atype735_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes735 [] = {
g_atype735_0,
};

static const long offsets735 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names736[];
static const uint32 types736 [] =
{
SK_POINTER,
};

static const uint16 attr_flags736 [] =
{0,};

static const EIF_TYPE_INDEX g_atype736_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes736 [] = {
g_atype736_0,
};

static const long offsets736 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names737[];
static const uint32 types737 [] =
{
SK_POINTER,
};

static const uint16 attr_flags737 [] =
{0,};

static const EIF_TYPE_INDEX g_atype737_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes737 [] = {
g_atype737_0,
};

static const long offsets737 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names738[];
static const uint32 types738 [] =
{
SK_POINTER,
};

static const uint16 attr_flags738 [] =
{0,};

static const EIF_TYPE_INDEX g_atype738_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes738 [] = {
g_atype738_0,
};

static const long offsets738 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names739[];
static const uint32 types739 [] =
{
SK_POINTER,
};

static const uint16 attr_flags739 [] =
{0,};

static const EIF_TYPE_INDEX g_atype739_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes739 [] = {
g_atype739_0,
};

static const long offsets739 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names740[];
static const uint32 types740 [] =
{
SK_POINTER,
};

static const uint16 attr_flags740 [] =
{0,};

static const EIF_TYPE_INDEX g_atype740_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes740 [] = {
g_atype740_0,
};

static const long offsets740 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names741[];
static const uint32 types741 [] =
{
SK_POINTER,
};

static const uint16 attr_flags741 [] =
{0,};

static const EIF_TYPE_INDEX g_atype741_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes741 [] = {
g_atype741_0,
};

static const long offsets741 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names742[];
static const uint32 types742 [] =
{
SK_POINTER,
};

static const uint16 attr_flags742 [] =
{0,};

static const EIF_TYPE_INDEX g_atype742_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes742 [] = {
g_atype742_0,
};

static const long offsets742 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names743[];
static const uint32 types743 [] =
{
SK_POINTER,
};

static const uint16 attr_flags743 [] =
{0,};

static const EIF_TYPE_INDEX g_atype743_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes743 [] = {
g_atype743_0,
};

static const long offsets743 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names744[];
static const uint32 types744 [] =
{
SK_POINTER,
};

static const uint16 attr_flags744 [] =
{0,};

static const EIF_TYPE_INDEX g_atype744_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes744 [] = {
g_atype744_0,
};

static const long offsets744 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names745[];
static const uint32 types745 [] =
{
SK_POINTER,
};

static const uint16 attr_flags745 [] =
{0,};

static const EIF_TYPE_INDEX g_atype745_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes745 [] = {
g_atype745_0,
};

static const long offsets745 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names746[];
static const uint32 types746 [] =
{
SK_POINTER,
};

static const uint16 attr_flags746 [] =
{0,};

static const EIF_TYPE_INDEX g_atype746_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes746 [] = {
g_atype746_0,
};

static const long offsets746 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names747[];
static const uint32 types747 [] =
{
SK_POINTER,
};

static const uint16 attr_flags747 [] =
{0,};

static const EIF_TYPE_INDEX g_atype747_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes747 [] = {
g_atype747_0,
};

static const long offsets747 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names748[];
static const uint32 types748 [] =
{
SK_POINTER,
};

static const uint16 attr_flags748 [] =
{0,};

static const EIF_TYPE_INDEX g_atype748_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes748 [] = {
g_atype748_0,
};

static const long offsets748 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names749[];
static const uint32 types749 [] =
{
SK_POINTER,
};

static const uint16 attr_flags749 [] =
{0,};

static const EIF_TYPE_INDEX g_atype749_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes749 [] = {
g_atype749_0,
};

static const long offsets749 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names750[];
static const uint32 types750 [] =
{
SK_POINTER,
};

static const uint16 attr_flags750 [] =
{0,};

static const EIF_TYPE_INDEX g_atype750_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes750 [] = {
g_atype750_0,
};

static const long offsets750 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names751[];
static const uint32 types751 [] =
{
SK_POINTER,
};

static const uint16 attr_flags751 [] =
{0,};

static const EIF_TYPE_INDEX g_atype751_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes751 [] = {
g_atype751_0,
};

static const long offsets751 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names752[];
static const uint32 types752 [] =
{
SK_POINTER,
};

static const uint16 attr_flags752 [] =
{0,};

static const EIF_TYPE_INDEX g_atype752_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes752 [] = {
g_atype752_0,
};

static const long offsets752 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names753[];
static const uint32 types753 [] =
{
SK_POINTER,
};

static const uint16 attr_flags753 [] =
{0,};

static const EIF_TYPE_INDEX g_atype753_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes753 [] = {
g_atype753_0,
};

static const long offsets753 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names754[];
static const uint32 types754 [] =
{
SK_POINTER,
};

static const uint16 attr_flags754 [] =
{0,};

static const EIF_TYPE_INDEX g_atype754_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes754 [] = {
g_atype754_0,
};

static const long offsets754 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names755[];
static const uint32 types755 [] =
{
SK_POINTER,
};

static const uint16 attr_flags755 [] =
{0,};

static const EIF_TYPE_INDEX g_atype755_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes755 [] = {
g_atype755_0,
};

static const long offsets755 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names756[];
static const uint32 types756 [] =
{
SK_POINTER,
};

static const uint16 attr_flags756 [] =
{0,};

static const EIF_TYPE_INDEX g_atype756_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes756 [] = {
g_atype756_0,
};

static const long offsets756 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names757[];
static const uint32 types757 [] =
{
SK_POINTER,
};

static const uint16 attr_flags757 [] =
{0,};

static const EIF_TYPE_INDEX g_atype757_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes757 [] = {
g_atype757_0,
};

static const long offsets757 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names758[];
static const uint32 types758 [] =
{
SK_POINTER,
};

static const uint16 attr_flags758 [] =
{0,};

static const EIF_TYPE_INDEX g_atype758_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes758 [] = {
g_atype758_0,
};

static const long offsets758 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names759[];
static const uint32 types759 [] =
{
SK_POINTER,
};

static const uint16 attr_flags759 [] =
{0,};

static const EIF_TYPE_INDEX g_atype759_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes759 [] = {
g_atype759_0,
};

static const long offsets759 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names760[];
static const uint32 types760 [] =
{
SK_POINTER,
};

static const uint16 attr_flags760 [] =
{0,};

static const EIF_TYPE_INDEX g_atype760_0 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes760 [] = {
g_atype760_0,
};

static const long offsets760 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names761[];
static const uint32 types761 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags761 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype761_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype761_1 [] = {0xFFF9,0,687,0xFFFF};
static const EIF_TYPE_INDEX g_atype761_2 [] = {581,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype761_3 [] = {581,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype761_4 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype761_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype761_6 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype761_7 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype761_8 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype761_9 [] = {759,0xFFFF};
static const EIF_TYPE_INDEX g_atype761_10 [] = {759,0xFFFF};
static const EIF_TYPE_INDEX g_atype761_11 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes761 [] = {
g_atype761_0,
g_atype761_1,
g_atype761_2,
g_atype761_3,
g_atype761_4,
g_atype761_5,
g_atype761_6,
g_atype761_7,
g_atype761_8,
g_atype761_9,
g_atype761_10,
g_atype761_11,
};

static const long offsets761 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
+ @LNGOFF(4,2,0,1),
+ @LNGOFF(4,2,0,2),
+ @PTROFF(4,2,0,3,0,0),
+ @PTROFF(4,2,0,3,0,1),
+ @PTROFF(4,2,0,3,0,2),
};

extern const char *names762[];
static const uint32 types762 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags762 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype762_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype762_1 [] = {0xFFF9,0,687,0xFFFF};
static const EIF_TYPE_INDEX g_atype762_2 [] = {581,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype762_3 [] = {581,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype762_4 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype762_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype762_6 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype762_7 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype762_8 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype762_9 [] = {759,0xFFFF};
static const EIF_TYPE_INDEX g_atype762_10 [] = {759,0xFFFF};
static const EIF_TYPE_INDEX g_atype762_11 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes762 [] = {
g_atype762_0,
g_atype762_1,
g_atype762_2,
g_atype762_3,
g_atype762_4,
g_atype762_5,
g_atype762_6,
g_atype762_7,
g_atype762_8,
g_atype762_9,
g_atype762_10,
g_atype762_11,
};

static const long offsets762 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
+ @LNGOFF(4,2,0,1),
+ @LNGOFF(4,2,0,2),
+ @PTROFF(4,2,0,3,0,0),
+ @PTROFF(4,2,0,3,0,1),
+ @PTROFF(4,2,0,3,0,2),
};

extern const char *names763[];
static const uint32 types763 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags763 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype763_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype763_1 [] = {0xFFF9,0,687,0xFFFF};
static const EIF_TYPE_INDEX g_atype763_2 [] = {581,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype763_3 [] = {581,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype763_4 [] = {0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype763_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype763_6 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype763_7 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype763_8 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype763_9 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype763_10 [] = {759,0xFFFF};
static const EIF_TYPE_INDEX g_atype763_11 [] = {759,0xFFFF};
static const EIF_TYPE_INDEX g_atype763_12 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes763 [] = {
g_atype763_0,
g_atype763_1,
g_atype763_2,
g_atype763_3,
g_atype763_4,
g_atype763_5,
g_atype763_6,
g_atype763_7,
g_atype763_8,
g_atype763_9,
g_atype763_10,
g_atype763_11,
g_atype763_12,
};

static const long offsets763 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
+ @LNGOFF(5,2,0,1),
+ @LNGOFF(5,2,0,2),
+ @PTROFF(5,2,0,3,0,0),
+ @PTROFF(5,2,0,3,0,1),
+ @PTROFF(5,2,0,3,0,2),
};

extern const char *names764[];
static const uint32 types764 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags764 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype764_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype764_1 [] = {0xFFF9,0,687,0xFFFF};
static const EIF_TYPE_INDEX g_atype764_2 [] = {581,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype764_3 [] = {581,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype764_4 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype764_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype764_6 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype764_7 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype764_8 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype764_9 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype764_10 [] = {759,0xFFFF};
static const EIF_TYPE_INDEX g_atype764_11 [] = {759,0xFFFF};
static const EIF_TYPE_INDEX g_atype764_12 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes764 [] = {
g_atype764_0,
g_atype764_1,
g_atype764_2,
g_atype764_3,
g_atype764_4,
g_atype764_5,
g_atype764_6,
g_atype764_7,
g_atype764_8,
g_atype764_9,
g_atype764_10,
g_atype764_11,
g_atype764_12,
};

static const long offsets764 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @PTROFF(4,3,0,3,0,0),
+ @PTROFF(4,3,0,3,0,1),
+ @PTROFF(4,3,0,3,0,2),
};

extern const char *names765[];
static const uint32 types765 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags765 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype765_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype765_1 [] = {0xFFF9,0,687,0xFFFF};
static const EIF_TYPE_INDEX g_atype765_2 [] = {581,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype765_3 [] = {581,690,0xFFFF};
static const EIF_TYPE_INDEX g_atype765_4 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype765_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype765_6 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype765_7 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype765_8 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype765_9 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype765_10 [] = {759,0xFFFF};
static const EIF_TYPE_INDEX g_atype765_11 [] = {759,0xFFFF};
static const EIF_TYPE_INDEX g_atype765_12 [] = {759,0xFFFF};

static const EIF_TYPE_INDEX *gtypes765 [] = {
g_atype765_0,
g_atype765_1,
g_atype765_2,
g_atype765_3,
g_atype765_4,
g_atype765_5,
g_atype765_6,
g_atype765_7,
g_atype765_8,
g_atype765_9,
g_atype765_10,
g_atype765_11,
g_atype765_12,
};

static const long offsets765 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @PTROFF(4,3,0,3,0,0),
+ @PTROFF(4,3,0,3,0,1),
+ @PTROFF(4,3,0,3,0,2),
};

extern const char *names766[];
static const uint32 types766 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags766 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype766_0 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype766_1 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes766 [] = {
g_atype766_0,
g_atype766_1,
};

static const long offsets766 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names767[];
static const uint32 types767 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags767 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype767_0 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype767_1 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes767 [] = {
g_atype767_0,
g_atype767_1,
};

static const long offsets767 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names768[];
static const uint32 types768 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags768 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype768_0 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype768_1 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes768 [] = {
g_atype768_0,
g_atype768_1,
};

static const long offsets768 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names769[];
static const uint32 types769 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags769 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype769_0 [] = {546,717,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype769_3 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes769 [] = {
g_atype769_0,
g_atype769_1,
g_atype769_2,
g_atype769_3,
};

static const long offsets769 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names770[];
static const uint32 types770 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags770 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype770_0 [] = {546,717,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype770_4 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes770 [] = {
g_atype770_0,
g_atype770_1,
g_atype770_2,
g_atype770_3,
g_atype770_4,
};

static const long offsets770 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
};

extern const char *names771[];
static const uint32 types771 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags771 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype771_0 [] = {546,717,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_4 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes771 [] = {
g_atype771_0,
g_atype771_1,
g_atype771_2,
g_atype771_3,
g_atype771_4,
};

static const long offsets771 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names772[];
static const uint32 types772 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags772 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype772_0 [] = {547,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_3 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes772 [] = {
g_atype772_0,
g_atype772_1,
g_atype772_2,
g_atype772_3,
};

static const long offsets772 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names773[];
static const uint32 types773 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags773 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype773_0 [] = {547,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_1 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_4 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes773 [] = {
g_atype773_0,
g_atype773_1,
g_atype773_2,
g_atype773_3,
g_atype773_4,
};

static const long offsets773 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
};

extern const char *names774[];
static const uint32 types774 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags774 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype774_0 [] = {547,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_4 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes774 [] = {
g_atype774_0,
g_atype774_1,
g_atype774_2,
g_atype774_3,
g_atype774_4,
};

static const long offsets774 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names775[];
static const uint32 types775 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags775 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype775_0 [] = {547,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype775_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype775_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype775_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype775_4 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes775 [] = {
g_atype775_0,
g_atype775_1,
g_atype775_2,
g_atype775_3,
g_atype775_4,
};

static const long offsets775 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names776[];
static const uint32 types776 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags776 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype776_0 [] = {547,720,0xFFFF};
static const EIF_TYPE_INDEX g_atype776_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype776_2 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype776_3 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype776_4 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes776 [] = {
g_atype776_0,
g_atype776_1,
g_atype776_2,
g_atype776_3,
g_atype776_4,
};

static const long offsets776 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names777[];
static const uint32 types777 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags777 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype777_0 [] = {773,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_1 [] = {765,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_2 [] = {114,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_3 [] = {770,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_4 [] = {5,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_5 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_6 [] = {720,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_7 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_8 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_9 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_10 [] = {708,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_11 [] = {696,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_12 [] = {705,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_13 [] = {693,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_14 [] = {702,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_15 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_16 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_17 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_18 [] = {711,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_19 [] = {759,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_20 [] = {699,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_21 [] = {726,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_22 [] = {714,0xFFFF};

static const EIF_TYPE_INDEX *gtypes777 [] = {
g_atype777_0,
g_atype777_1,
g_atype777_2,
g_atype777_3,
g_atype777_4,
g_atype777_5,
g_atype777_6,
g_atype777_7,
g_atype777_8,
g_atype777_9,
g_atype777_10,
g_atype777_11,
g_atype777_12,
g_atype777_13,
g_atype777_14,
g_atype777_15,
g_atype777_16,
g_atype777_17,
g_atype777_18,
g_atype777_19,
g_atype777_20,
g_atype777_21,
g_atype777_22,
};

static const long offsets777 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @I16OFF(5,7,0),
+ @I16OFF(5,7,1),
+ @LNGOFF(5,7,2,0),
+ @LNGOFF(5,7,2,1),
+ @LNGOFF(5,7,2,2),
+ @LNGOFF(5,7,2,3),
+ @R32OFF(5,7,2,4,0),
+ @PTROFF(5,7,2,4,1,0),
+ @I64OFF(5,7,2,4,1,1,0),
+ @I64OFF(5,7,2,4,1,1,1),
+ @R64OFF(5,7,2,4,1,1,2,0),
};

extern const char *names778[];
static const uint32 types778 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags778 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype778_0 [] = {765,0xFFFF};
static const EIF_TYPE_INDEX g_atype778_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype778_2 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes778 [] = {
g_atype778_0,
g_atype778_1,
g_atype778_2,
};

static const long offsets778 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names779[];
static const uint32 types779 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags779 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype779_0 [] = {765,0xFFFF};
static const EIF_TYPE_INDEX g_atype779_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype779_2 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes779 [] = {
g_atype779_0,
g_atype779_1,
g_atype779_2,
};

static const long offsets779 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names780[];
static const uint32 types780 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags780 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype780_0 [] = {765,0xFFFF};
static const EIF_TYPE_INDEX g_atype780_1 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype780_2 [] = {723,0xFFFF};

static const EIF_TYPE_INDEX *gtypes780 [] = {
g_atype780_0,
g_atype780_1,
g_atype780_2,
};

static const long offsets780 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names781[];
static const uint32 types781 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags781 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype781_0 [] = {143,0xFFFF};
static const EIF_TYPE_INDEX g_atype781_1 [] = {143,0xFFFF};
static const EIF_TYPE_INDEX g_atype781_2 [] = {143,0xFFFF};
static const EIF_TYPE_INDEX g_atype781_3 [] = {630,0xFFF9,2,687,143,634,0xFFF9,2,687,145,145,0xFFFF};
static const EIF_TYPE_INDEX g_atype781_4 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype781_5 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype781_6 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype781_7 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype781_8 [] = {723,0xFFFF};
static const EIF_TYPE_INDEX g_atype781_9 [] = {690,0xFFFF};
static const EIF_TYPE_INDEX g_atype781_10 [] = {690,0xFFFF};

static const EIF_TYPE_INDEX *gtypes781 [] = {
g_atype781_0,
g_atype781_1,
g_atype781_2,
g_atype781_3,
g_atype781_4,
g_atype781_5,
g_atype781_6,
g_atype781_7,
g_atype781_8,
g_atype781_9,
g_atype781_10,
};

static const long offsets781 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @LNGOFF(4,5,0,0),
+ @LNGOFF(4,5,0,1),
};

const struct cnode egc_fsystem_init[] = {
{
	(long) 0,
	(long) 0,
	"ANY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DESCRIPTOR_CACHE",
	names2,
	types2,
	attr_flags2,
	gtypes2,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets2,
	NULL
},
{
	(long) 1,
	(long) 0,
	"VERSIONABLE",
	names3,
	types3,
	attr_flags3,
	gtypes3,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets3,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CODE_PAGE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"ENCODING",
	names6,
	types6,
	attr_flags6,
	gtypes6,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets6,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_STRING_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CHARACTER_PROPERTY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_STRING",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"RT_DBG_EXECUTION_PARAMETERS",
	names10,
	types10,
	attr_flags10,
	gtypes10,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets10,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UTF_CONVERTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0100,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UTF_CONVERTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0300,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ISE_RUNTIME",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"STD_FILES",
	names26,
	types26,
	attr_flags26,
	gtypes26,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets26,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FAST_COMPILE",
	names27,
	types27,
	attr_flags27,
	gtypes27,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets27,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CODE_SETS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 12,
	(long) 12,
	"OBJECT_GRAPH_TRAVERSABLE",
	names29,
	types29,
	attr_flags29,
	gtypes29,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets29,
	NULL
},
{
	(long) 12,
	(long) 12,
	"OBJECT_GRAPH_BREADTH_FIRST_TRAVERSABLE",
	names30,
	types30,
	attr_flags30,
	gtypes30,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets30,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS_I",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OBJECT_GRAPH_MARKER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MATH_CONST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DOUBLE_MATH",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFACTORING_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTION_MANAGER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ISE_EXCEPTION_MANAGER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEP_CONST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names40,
	types40,
	attr_flags40,
	gtypes40,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets40,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names41,
	types41,
	attr_flags41,
	gtypes41,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets41,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names42,
	types42,
	attr_flags42,
	gtypes42,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets42,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names43,
	types43,
	attr_flags43,
	gtypes43,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets43,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LINKABLE",
	names44,
	types44,
	attr_flags44,
	gtypes44,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets44,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LINKABLE",
	names45,
	types45,
	attr_flags45,
	gtypes45,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets45,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OPERATING_ENVIRONMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ENCODING_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS_IMP",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION_COMMON",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION_GENERAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_DBG_COMMON",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NUMERIC_INFORMATION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"INTEGER_OVERFLOW_CHECKER",
	names55,
	types55,
	attr_flags55,
	gtypes55,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets55,
	NULL
},
{
	(long) 7,
	(long) 7,
	"STRING_TO_NUMERIC_CONVERTOR",
	names56,
	types56,
	attr_flags56,
	gtypes56,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets56,
	NULL
},
{
	(long) 11,
	(long) 11,
	"HEXADECIMAL_STRING_TO_INTEGER_CONVERTER",
	names57,
	types57,
	attr_flags57,
	gtypes57,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets57,
	NULL
},
{
	(long) 10,
	(long) 10,
	"STRING_TO_INTEGER_CONVERTOR",
	names58,
	types58,
	attr_flags58,
	gtypes58,
	(uint16) 0x6000,
	(void (*)()) 0,
	offsets58,
	NULL
},
{
	(long) 15,
	(long) 15,
	"STRING_TO_REAL_CONVERTOR",
	names59,
	types59,
	attr_flags59,
	gtypes59,
	(uint16) 0x6000,
	(void (*)()) 0,
	offsets59,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_SEARCHER",
	names60,
	types60,
	attr_flags60,
	gtypes60,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets60,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_32_SEARCHER",
	names61,
	types61,
	attr_flags61,
	gtypes61,
	(uint16) 0x6000,
	(void (*)()) 0,
	offsets61,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_8_SEARCHER",
	names62,
	types62,
	attr_flags62,
	gtypes62,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets62,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PART_COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"C_STRING",
	names66,
	types66,
	attr_flags66,
	gtypes66,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets66,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"LINKED_LIST_CURSOR",
	names68,
	types68,
	attr_flags68,
	gtypes68,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets68,
	NULL
},
{
	(long) 3,
	(long) 3,
	"LINKED_LIST_CURSOR",
	names69,
	types69,
	attr_flags69,
	gtypes69,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets69,
	NULL
},
{
	(long) 1,
	(long) 1,
	"HASH_TABLE_CURSOR",
	names70,
	types70,
	attr_flags70,
	gtypes70,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets70,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ARRAYED_LIST_CURSOR",
	names71,
	types71,
	attr_flags71,
	gtypes71,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets71,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTION_MANAGER_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXCEPTION",
	names74,
	types74,
	attr_flags74,
	gtypes74,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets74,
	NULL
},
{
	(long) 7,
	(long) 7,
	"DEVELOPER_EXCEPTION",
	names75,
	types75,
	attr_flags75,
	gtypes75,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets75,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CONVERSION_FAILURE",
	names76,
	types76,
	attr_flags76,
	gtypes76,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets76,
	NULL
},
{
	(long) 7,
	(long) 7,
	"MACHINE_EXCEPTION",
	names77,
	types77,
	attr_flags77,
	gtypes77,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets77,
	NULL
},
{
	(long) 7,
	(long) 7,
	"HARDWARE_EXCEPTION",
	names78,
	types78,
	attr_flags78,
	gtypes78,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets78,
	NULL
},
{
	(long) 7,
	(long) 7,
	"FLOATING_POINT_FAILURE",
	names79,
	types79,
	attr_flags79,
	gtypes79,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets79,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OPERATING_SYSTEM_EXCEPTION",
	names80,
	types80,
	attr_flags80,
	gtypes80,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets80,
	NULL
},
{
	(long) 8,
	(long) 8,
	"OPERATING_SYSTEM_FAILURE",
	names81,
	types81,
	attr_flags81,
	gtypes81,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets81,
	NULL
},
{
	(long) 8,
	(long) 8,
	"OPERATING_SYSTEM_SIGNAL_FAILURE",
	names82,
	types82,
	attr_flags82,
	gtypes82,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets82,
	NULL
},
{
	(long) 10,
	(long) 10,
	"COM_FAILURE",
	names83,
	types83,
	attr_flags83,
	gtypes83,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets83,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OBSOLETE_EXCEPTION",
	names84,
	types84,
	attr_flags84,
	gtypes84,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets84,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXCEPTION_IN_SIGNAL_HANDLER_FAILURE",
	names85,
	types85,
	attr_flags85,
	gtypes85,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets85,
	NULL
},
{
	(long) 7,
	(long) 7,
	"RESUMPTION_FAILURE",
	names86,
	types86,
	attr_flags86,
	gtypes86,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets86,
	NULL
},
{
	(long) 7,
	(long) 7,
	"RESCUE_FAILURE",
	names87,
	types87,
	attr_flags87,
	gtypes87,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets87,
	NULL
},
{
	(long) 7,
	(long) 7,
	"SYS_EXCEPTION",
	names88,
	types88,
	attr_flags88,
	gtypes88,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets88,
	NULL
},
{
	(long) 8,
	(long) 8,
	"EIFFEL_RUNTIME_PANIC",
	names89,
	types89,
	attr_flags89,
	gtypes89,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets89,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OLD_VIOLATION",
	names90,
	types90,
	attr_flags90,
	gtypes90,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets90,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIF_EXCEPTION",
	names91,
	types91,
	attr_flags91,
	gtypes91,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets91,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIFFEL_RUNTIME_EXCEPTION",
	names92,
	types92,
	attr_flags92,
	gtypes92,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets92,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXTERNAL_FAILURE",
	names93,
	types93,
	attr_flags93,
	gtypes93,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets93,
	NULL
},
{
	(long) 8,
	(long) 8,
	"NO_MORE_MEMORY",
	names94,
	types94,
	attr_flags94,
	gtypes94,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets94,
	NULL
},
{
	(long) 7,
	(long) 7,
	"DATA_EXCEPTION",
	names95,
	types95,
	attr_flags95,
	gtypes95,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets95,
	NULL
},
{
	(long) 7,
	(long) 7,
	"MISMATCH_FAILURE",
	names96,
	types96,
	attr_flags96,
	gtypes96,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets96,
	NULL
},
{
	(long) 9,
	(long) 9,
	"IO_FAILURE",
	names97,
	types97,
	attr_flags97,
	gtypes97,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets97,
	NULL
},
{
	(long) 7,
	(long) 7,
	"SERIALIZATION_FAILURE",
	names98,
	types98,
	attr_flags98,
	gtypes98,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets98,
	NULL
},
{
	(long) 7,
	(long) 7,
	"LANGUAGE_EXCEPTION",
	names99,
	types99,
	attr_flags99,
	gtypes99,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets99,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VOID_ASSIGNED_TO_EXPANDED",
	names100,
	types100,
	attr_flags100,
	gtypes100,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets100,
	NULL
},
{
	(long) 7,
	(long) 7,
	"BAD_INSPECT_VALUE",
	names101,
	types101,
	attr_flags101,
	gtypes101,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets101,
	NULL
},
{
	(long) 9,
	(long) 9,
	"ROUTINE_FAILURE",
	names102,
	types102,
	attr_flags102,
	gtypes102,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets102,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VOID_TARGET",
	names103,
	types103,
	attr_flags103,
	gtypes103,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets103,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIFFELSTUDIO_SPECIFIC_LANGUAGE_EXCEPTION",
	names104,
	types104,
	attr_flags104,
	gtypes104,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets104,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CREATE_ON_DEFERRED",
	names105,
	types105,
	attr_flags105,
	gtypes105,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets105,
	NULL
},
{
	(long) 7,
	(long) 7,
	"ADDRESS_APPLIED_TO_MELTED_FEATURE",
	names106,
	types106,
	attr_flags106,
	gtypes106,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets106,
	NULL
},
{
	(long) 7,
	(long) 7,
	"ASSERTION_VIOLATION",
	names107,
	types107,
	attr_flags107,
	gtypes107,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets107,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VARIANT_VIOLATION",
	names108,
	types108,
	attr_flags108,
	gtypes108,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets108,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CHECK_VIOLATION",
	names109,
	types109,
	attr_flags109,
	gtypes109,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets109,
	NULL
},
{
	(long) 8,
	(long) 8,
	"INVARIANT_VIOLATION",
	names110,
	types110,
	attr_flags110,
	gtypes110,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets110,
	NULL
},
{
	(long) 7,
	(long) 7,
	"POSTCONDITION_VIOLATION",
	names111,
	types111,
	attr_flags111,
	gtypes111,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets111,
	NULL
},
{
	(long) 7,
	(long) 7,
	"PRECONDITION_VIOLATION",
	names112,
	types112,
	attr_flags112,
	gtypes112,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets112,
	NULL
},
{
	(long) 7,
	(long) 7,
	"LOOP_INVARIANT_VIOLATION",
	names113,
	types113,
	attr_flags113,
	gtypes113,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets113,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DISPOSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 2,
	"MANAGED_POINTER",
	names115,
	types115,
	attr_flags115,
	gtypes115,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets115,
	NULL
},
{
	(long) 13,
	(long) 13,
	"IO_MEDIUM",
	names116,
	types116,
	attr_flags116,
	gtypes116,
	(uint16) 0x5400,
	(void (*)()) 0,
	offsets116,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REFLECTED_OBJECT",
	names118,
	types118,
	attr_flags118,
	gtypes118,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets118,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INTERNAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_DBG_INTERNAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"REFLECTED_COPY_SEMANTICS_OBJECT",
	names122,
	types122,
	attr_flags122,
	gtypes122,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets122,
	NULL
},
{
	(long) 3,
	(long) 3,
	"REFLECTED_REFERENCE_OBJECT",
	names123,
	types123,
	attr_flags123,
	gtypes123,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets123,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names124,
	types124,
	attr_flags124,
	gtypes124,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets124,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names125,
	types125,
	attr_flags125,
	gtypes125,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets125,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names126,
	types126,
	attr_flags126,
	gtypes126,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets126,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names127,
	types127,
	attr_flags127,
	gtypes127,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets127,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names128,
	types128,
	attr_flags128,
	gtypes128,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets128,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names129,
	types129,
	attr_flags129,
	gtypes129,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets129,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names130,
	types130,
	attr_flags130,
	gtypes130,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets130,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names131,
	types131,
	attr_flags131,
	gtypes131,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets131,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names132,
	types132,
	attr_flags132,
	gtypes132,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets132,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names133,
	types133,
	attr_flags133,
	gtypes133,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets133,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names134,
	types134,
	attr_flags134,
	gtypes134,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets134,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names135,
	types135,
	attr_flags135,
	gtypes135,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets135,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"NATIVE_STRING",
	names137,
	types137,
	attr_flags137,
	gtypes137,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets137,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EXECUTION_ENVIRONMENT",
	names138,
	types138,
	attr_flags138,
	gtypes138,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets138,
	NULL
},
{
	(long) 5,
	(long) 5,
	"FILE_INFO",
	names139,
	types139,
	attr_flags139,
	gtypes139,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets139,
	NULL
},
{
	(long) 5,
	(long) 5,
	"UNIX_FILE_INFO",
	names140,
	types140,
	attr_flags140,
	gtypes140,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets140,
	NULL
},
{
	(long) 6,
	(long) 6,
	"DIRECTORY",
	names141,
	types141,
	attr_flags141,
	gtypes141,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets141,
	NULL
},
{
	(long) 16,
	(long) 16,
	"EIFFEL_F_CODE_DIRECTORY",
	names142,
	types142,
	attr_flags142,
	gtypes142,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets142,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DEBUG_OUTPUT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 15,
	(long) 15,
	"RT_DBG_CALL_RECORD",
	names144,
	types144,
	attr_flags144,
	gtypes144,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets144,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ABSTRACT_SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"RT_DBG_VALUE_RECORD",
	names146,
	types146,
	attr_flags146,
	gtypes146,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets146,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names147,
	types147,
	attr_flags147,
	gtypes147,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets147,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names148,
	types148,
	attr_flags148,
	gtypes148,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets148,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names149,
	types149,
	attr_flags149,
	gtypes149,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets149,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names150,
	types150,
	attr_flags150,
	gtypes150,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets150,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names151,
	types151,
	attr_flags151,
	gtypes151,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets151,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names152,
	types152,
	attr_flags152,
	gtypes152,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets152,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names153,
	types153,
	attr_flags153,
	gtypes153,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets153,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names154,
	types154,
	attr_flags154,
	gtypes154,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets154,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names155,
	types155,
	attr_flags155,
	gtypes155,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets155,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names156,
	types156,
	attr_flags156,
	gtypes156,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets156,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names157,
	types157,
	attr_flags157,
	gtypes157,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets157,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names158,
	types158,
	attr_flags158,
	gtypes158,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets158,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names159,
	types159,
	attr_flags159,
	gtypes159,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets159,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names160,
	types160,
	attr_flags160,
	gtypes160,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets160,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names161,
	types161,
	attr_flags161,
	gtypes161,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets161,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names162,
	types162,
	attr_flags162,
	gtypes162,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets162,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names163,
	types163,
	attr_flags163,
	gtypes163,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets163,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names164,
	types164,
	attr_flags164,
	gtypes164,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets164,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names165,
	types165,
	attr_flags165,
	gtypes165,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets165,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names166,
	types166,
	attr_flags166,
	gtypes166,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets166,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names167,
	types167,
	attr_flags167,
	gtypes167,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets167,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names168,
	types168,
	attr_flags168,
	gtypes168,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets168,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names169,
	types169,
	attr_flags169,
	gtypes169,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets169,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names170,
	types170,
	attr_flags170,
	gtypes170,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets170,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names171,
	types171,
	attr_flags171,
	gtypes171,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets171,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names172,
	types172,
	attr_flags172,
	gtypes172,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets172,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names173,
	types173,
	attr_flags173,
	gtypes173,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets173,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names174,
	types174,
	attr_flags174,
	gtypes174,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets174,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names175,
	types175,
	attr_flags175,
	gtypes175,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets175,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names176,
	types176,
	attr_flags176,
	gtypes176,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets176,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names177,
	types177,
	attr_flags177,
	gtypes177,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets177,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names178,
	types178,
	attr_flags178,
	gtypes178,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets178,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names179,
	types179,
	attr_flags179,
	gtypes179,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets179,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names180,
	types180,
	attr_flags180,
	gtypes180,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets180,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names181,
	types181,
	attr_flags181,
	gtypes181,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets181,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names182,
	types182,
	attr_flags182,
	gtypes182,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets182,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names183,
	types183,
	attr_flags183,
	gtypes183,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets183,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names184,
	types184,
	attr_flags184,
	gtypes184,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets184,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names185,
	types185,
	attr_flags185,
	gtypes185,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets185,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names186,
	types186,
	attr_flags186,
	gtypes186,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets186,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names187,
	types187,
	attr_flags187,
	gtypes187,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets187,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names188,
	types188,
	attr_flags188,
	gtypes188,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets188,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names189,
	types189,
	attr_flags189,
	gtypes189,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets189,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names190,
	types190,
	attr_flags190,
	gtypes190,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets190,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names191,
	types191,
	attr_flags191,
	gtypes191,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets191,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NUMERIC",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_QUEUE_ITERATION_CURSOR",
	names205,
	types205,
	attr_flags205,
	gtypes205,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets205,
	NULL
},
{
	(long) 2,
	(long) 2,
	"FILE_ITERATION_CURSOR",
	names206,
	types206,
	attr_flags206,
	gtypes206,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets206,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENTS_32",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"STRING_ITERATION_CURSOR",
	names226,
	types226,
	attr_flags226,
	gtypes226,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets226,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names256,
	types256,
	attr_flags256,
	gtypes256,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets256,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names257,
	types257,
	attr_flags257,
	gtypes257,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets257,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names258,
	types258,
	attr_flags258,
	gtypes258,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets258,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names259,
	types259,
	attr_flags259,
	gtypes259,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets259,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names260,
	types260,
	attr_flags260,
	gtypes260,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets260,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names261,
	types261,
	attr_flags261,
	gtypes261,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets261,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names262,
	types262,
	attr_flags262,
	gtypes262,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets262,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names263,
	types263,
	attr_flags263,
	gtypes263,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets263,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names264,
	types264,
	attr_flags264,
	gtypes264,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets264,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names265,
	types265,
	attr_flags265,
	gtypes265,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets265,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names266,
	types266,
	attr_flags266,
	gtypes266,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets266,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names267,
	types267,
	attr_flags267,
	gtypes267,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets267,
	NULL
},
{
	(long) 8,
	(long) 7,
	"LINKED_LIST_ITERATION_CURSOR",
	names268,
	types268,
	attr_flags268,
	gtypes268,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets268,
	NULL
},
{
	(long) 8,
	(long) 7,
	"LINKED_LIST_ITERATION_CURSOR",
	names269,
	types269,
	attr_flags269,
	gtypes269,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets269,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names270,
	types270,
	attr_flags270,
	gtypes270,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets270,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names271,
	types271,
	attr_flags271,
	gtypes271,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets271,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names272,
	types272,
	attr_flags272,
	gtypes272,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets272,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names273,
	types273,
	attr_flags273,
	gtypes273,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets273,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names274,
	types274,
	attr_flags274,
	gtypes274,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets274,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names275,
	types275,
	attr_flags275,
	gtypes275,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets275,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names276,
	types276,
	attr_flags276,
	gtypes276,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets276,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names277,
	types277,
	attr_flags277,
	gtypes277,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets277,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names278,
	types278,
	attr_flags278,
	gtypes278,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets278,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names279,
	types279,
	attr_flags279,
	gtypes279,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets279,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names280,
	types280,
	attr_flags280,
	gtypes280,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets280,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names281,
	types281,
	attr_flags281,
	gtypes281,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets281,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names282,
	types282,
	attr_flags282,
	gtypes282,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets282,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names283,
	types283,
	attr_flags283,
	gtypes283,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets283,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names284,
	types284,
	attr_flags284,
	gtypes284,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets284,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names285,
	types285,
	attr_flags285,
	gtypes285,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets285,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names286,
	types286,
	attr_flags286,
	gtypes286,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets286,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names287,
	types287,
	attr_flags287,
	gtypes287,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets287,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names288,
	types288,
	attr_flags288,
	gtypes288,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets288,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names289,
	types289,
	attr_flags289,
	gtypes289,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets289,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names290,
	types290,
	attr_flags290,
	gtypes290,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets290,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names291,
	types291,
	attr_flags291,
	gtypes291,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets291,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names292,
	types292,
	attr_flags292,
	gtypes292,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets292,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names293,
	types293,
	attr_flags293,
	gtypes293,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets293,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names294,
	types294,
	attr_flags294,
	gtypes294,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets294,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names295,
	types295,
	attr_flags295,
	gtypes295,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets295,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names296,
	types296,
	attr_flags296,
	gtypes296,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets296,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names297,
	types297,
	attr_flags297,
	gtypes297,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets297,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names298,
	types298,
	attr_flags298,
	gtypes298,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets298,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_32_ITERATION_CURSOR",
	names299,
	types299,
	attr_flags299,
	gtypes299,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets299,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_8_ITERATION_CURSOR",
	names300,
	types300,
	attr_flags300,
	gtypes300,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets300,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names301,
	types301,
	attr_flags301,
	gtypes301,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets301,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names302,
	types302,
	attr_flags302,
	gtypes302,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets302,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names303,
	types303,
	attr_flags303,
	gtypes303,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets303,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names304,
	types304,
	attr_flags304,
	gtypes304,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets304,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names305,
	types305,
	attr_flags305,
	gtypes305,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets305,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names306,
	types306,
	attr_flags306,
	gtypes306,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets306,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names307,
	types307,
	attr_flags307,
	gtypes307,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets307,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names308,
	types308,
	attr_flags308,
	gtypes308,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets308,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names309,
	types309,
	attr_flags309,
	gtypes309,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets309,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names310,
	types310,
	attr_flags310,
	gtypes310,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets310,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names311,
	types311,
	attr_flags311,
	gtypes311,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets311,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names312,
	types312,
	attr_flags312,
	gtypes312,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets312,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names313,
	types313,
	attr_flags313,
	gtypes313,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets313,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names314,
	types314,
	attr_flags314,
	gtypes314,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets314,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names315,
	types315,
	attr_flags315,
	gtypes315,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets315,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names316,
	types316,
	attr_flags316,
	gtypes316,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets316,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names317,
	types317,
	attr_flags317,
	gtypes317,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets317,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names318,
	types318,
	attr_flags318,
	gtypes318,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets318,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names319,
	types319,
	attr_flags319,
	gtypes319,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets319,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names320,
	types320,
	attr_flags320,
	gtypes320,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets320,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names321,
	types321,
	attr_flags321,
	gtypes321,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets321,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names322,
	types322,
	attr_flags322,
	gtypes322,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets322,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names323,
	types323,
	attr_flags323,
	gtypes323,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets323,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names324,
	types324,
	attr_flags324,
	gtypes324,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets324,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names325,
	types325,
	attr_flags325,
	gtypes325,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets325,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names326,
	types326,
	attr_flags326,
	gtypes326,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets326,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names327,
	types327,
	attr_flags327,
	gtypes327,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets327,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names328,
	types328,
	attr_flags328,
	gtypes328,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets328,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names329,
	types329,
	attr_flags329,
	gtypes329,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets329,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names330,
	types330,
	attr_flags330,
	gtypes330,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets330,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names331,
	types331,
	attr_flags331,
	gtypes331,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets331,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names332,
	types332,
	attr_flags332,
	gtypes332,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets332,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names333,
	types333,
	attr_flags333,
	gtypes333,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets333,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names334,
	types334,
	attr_flags334,
	gtypes334,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets334,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names335,
	types335,
	attr_flags335,
	gtypes335,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets335,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names336,
	types336,
	attr_flags336,
	gtypes336,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets336,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names337,
	types337,
	attr_flags337,
	gtypes337,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets337,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names338,
	types338,
	attr_flags338,
	gtypes338,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets338,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names339,
	types339,
	attr_flags339,
	gtypes339,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets339,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names340,
	types340,
	attr_flags340,
	gtypes340,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets340,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names341,
	types341,
	attr_flags341,
	gtypes341,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets341,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names342,
	types342,
	attr_flags342,
	gtypes342,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets342,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names343,
	types343,
	attr_flags343,
	gtypes343,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets343,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names344,
	types344,
	attr_flags344,
	gtypes344,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets344,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names345,
	types345,
	attr_flags345,
	gtypes345,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets345,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names346,
	types346,
	attr_flags346,
	gtypes346,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets346,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names347,
	types347,
	attr_flags347,
	gtypes347,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets347,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names348,
	types348,
	attr_flags348,
	gtypes348,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets348,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names349,
	types349,
	attr_flags349,
	gtypes349,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets349,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names350,
	types350,
	attr_flags350,
	gtypes350,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets350,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names351,
	types351,
	attr_flags351,
	gtypes351,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets351,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names352,
	types352,
	attr_flags352,
	gtypes352,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets352,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names353,
	types353,
	attr_flags353,
	gtypes353,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets353,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names354,
	types354,
	attr_flags354,
	gtypes354,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets354,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names355,
	types355,
	attr_flags355,
	gtypes355,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets355,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names356,
	types356,
	attr_flags356,
	gtypes356,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets356,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names357,
	types357,
	attr_flags357,
	gtypes357,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets357,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names358,
	types358,
	attr_flags358,
	gtypes358,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets358,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names359,
	types359,
	attr_flags359,
	gtypes359,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets359,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names360,
	types360,
	attr_flags360,
	gtypes360,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets360,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names361,
	types361,
	attr_flags361,
	gtypes361,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets361,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names362,
	types362,
	attr_flags362,
	gtypes362,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets362,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names363,
	types363,
	attr_flags363,
	gtypes363,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets363,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names364,
	types364,
	attr_flags364,
	gtypes364,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets364,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names365,
	types365,
	attr_flags365,
	gtypes365,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets365,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names366,
	types366,
	attr_flags366,
	gtypes366,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets366,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names367,
	types367,
	attr_flags367,
	gtypes367,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets367,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names368,
	types368,
	attr_flags368,
	gtypes368,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets368,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names369,
	types369,
	attr_flags369,
	gtypes369,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets369,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names370,
	types370,
	attr_flags370,
	gtypes370,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets370,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names371,
	types371,
	attr_flags371,
	gtypes371,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets371,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names372,
	types372,
	attr_flags372,
	gtypes372,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets372,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names373,
	types373,
	attr_flags373,
	gtypes373,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets373,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names374,
	types374,
	attr_flags374,
	gtypes374,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets374,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names375,
	types375,
	attr_flags375,
	gtypes375,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets375,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names376,
	types376,
	attr_flags376,
	gtypes376,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets376,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names377,
	types377,
	attr_flags377,
	gtypes377,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets377,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names378,
	types378,
	attr_flags378,
	gtypes378,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets378,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names379,
	types379,
	attr_flags379,
	gtypes379,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets379,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names380,
	types380,
	attr_flags380,
	gtypes380,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets380,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names381,
	types381,
	attr_flags381,
	gtypes381,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets381,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names382,
	types382,
	attr_flags382,
	gtypes382,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets382,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names383,
	types383,
	attr_flags383,
	gtypes383,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets383,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names384,
	types384,
	attr_flags384,
	gtypes384,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets384,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SET",
	names385,
	types385,
	attr_flags385,
	gtypes385,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets385,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names386,
	types386,
	attr_flags386,
	gtypes386,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets386,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names387,
	types387,
	attr_flags387,
	gtypes387,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets387,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names388,
	types388,
	attr_flags388,
	gtypes388,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets388,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names389,
	types389,
	attr_flags389,
	gtypes389,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets389,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names390,
	types390,
	attr_flags390,
	gtypes390,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets390,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names391,
	types391,
	attr_flags391,
	gtypes391,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets391,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names392,
	types392,
	attr_flags392,
	gtypes392,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets392,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names393,
	types393,
	attr_flags393,
	gtypes393,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets393,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names394,
	types394,
	attr_flags394,
	gtypes394,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets394,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names395,
	types395,
	attr_flags395,
	gtypes395,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets395,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names396,
	types396,
	attr_flags396,
	gtypes396,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets396,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names397,
	types397,
	attr_flags397,
	gtypes397,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets397,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names398,
	types398,
	attr_flags398,
	gtypes398,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets398,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names399,
	types399,
	attr_flags399,
	gtypes399,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets399,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names400,
	types400,
	attr_flags400,
	gtypes400,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets400,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names401,
	types401,
	attr_flags401,
	gtypes401,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets401,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names402,
	types402,
	attr_flags402,
	gtypes402,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets402,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names403,
	types403,
	attr_flags403,
	gtypes403,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets403,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names404,
	types404,
	attr_flags404,
	gtypes404,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets404,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names405,
	types405,
	attr_flags405,
	gtypes405,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets405,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names406,
	types406,
	attr_flags406,
	gtypes406,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets406,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names407,
	types407,
	attr_flags407,
	gtypes407,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets407,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names408,
	types408,
	attr_flags408,
	gtypes408,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets408,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names409,
	types409,
	attr_flags409,
	gtypes409,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets409,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names410,
	types410,
	attr_flags410,
	gtypes410,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets410,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names411,
	types411,
	attr_flags411,
	gtypes411,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets411,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names412,
	types412,
	attr_flags412,
	gtypes412,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets412,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names413,
	types413,
	attr_flags413,
	gtypes413,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets413,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names414,
	types414,
	attr_flags414,
	gtypes414,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets414,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names415,
	types415,
	attr_flags415,
	gtypes415,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets415,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names416,
	types416,
	attr_flags416,
	gtypes416,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets416,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names417,
	types417,
	attr_flags417,
	gtypes417,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets417,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names418,
	types418,
	attr_flags418,
	gtypes418,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets418,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names419,
	types419,
	attr_flags419,
	gtypes419,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets419,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names420,
	types420,
	attr_flags420,
	gtypes420,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets420,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names421,
	types421,
	attr_flags421,
	gtypes421,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets421,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names422,
	types422,
	attr_flags422,
	gtypes422,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets422,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names423,
	types423,
	attr_flags423,
	gtypes423,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets423,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names424,
	types424,
	attr_flags424,
	gtypes424,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets424,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names425,
	types425,
	attr_flags425,
	gtypes425,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets425,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names426,
	types426,
	attr_flags426,
	gtypes426,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets426,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names427,
	types427,
	attr_flags427,
	gtypes427,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets427,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names428,
	types428,
	attr_flags428,
	gtypes428,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets428,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names429,
	types429,
	attr_flags429,
	gtypes429,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets429,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names430,
	types430,
	attr_flags430,
	gtypes430,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets430,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names431,
	types431,
	attr_flags431,
	gtypes431,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets431,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names432,
	types432,
	attr_flags432,
	gtypes432,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets432,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names433,
	types433,
	attr_flags433,
	gtypes433,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets433,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names434,
	types434,
	attr_flags434,
	gtypes434,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets434,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names435,
	types435,
	attr_flags435,
	gtypes435,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets435,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names436,
	types436,
	attr_flags436,
	gtypes436,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets436,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names437,
	types437,
	attr_flags437,
	gtypes437,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets437,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names438,
	types438,
	attr_flags438,
	gtypes438,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets438,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names439,
	types439,
	attr_flags439,
	gtypes439,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets439,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names440,
	types440,
	attr_flags440,
	gtypes440,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets440,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names441,
	types441,
	attr_flags441,
	gtypes441,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets441,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names442,
	types442,
	attr_flags442,
	gtypes442,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets442,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names443,
	types443,
	attr_flags443,
	gtypes443,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets443,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names444,
	types444,
	attr_flags444,
	gtypes444,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets444,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names445,
	types445,
	attr_flags445,
	gtypes445,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets445,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names446,
	types446,
	attr_flags446,
	gtypes446,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets446,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names447,
	types447,
	attr_flags447,
	gtypes447,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets447,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names448,
	types448,
	attr_flags448,
	gtypes448,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets448,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names449,
	types449,
	attr_flags449,
	gtypes449,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets449,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names450,
	types450,
	attr_flags450,
	gtypes450,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets450,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names451,
	types451,
	attr_flags451,
	gtypes451,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets451,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names452,
	types452,
	attr_flags452,
	gtypes452,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets452,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names453,
	types453,
	attr_flags453,
	gtypes453,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets453,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names454,
	types454,
	attr_flags454,
	gtypes454,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets454,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names455,
	types455,
	attr_flags455,
	gtypes455,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets455,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names456,
	types456,
	attr_flags456,
	gtypes456,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets456,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names457,
	types457,
	attr_flags457,
	gtypes457,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets457,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names458,
	types458,
	attr_flags458,
	gtypes458,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets458,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names459,
	types459,
	attr_flags459,
	gtypes459,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets459,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names460,
	types460,
	attr_flags460,
	gtypes460,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets460,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names461,
	types461,
	attr_flags461,
	gtypes461,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets461,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names462,
	types462,
	attr_flags462,
	gtypes462,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets462,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names463,
	types463,
	attr_flags463,
	gtypes463,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets463,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INFINITE",
	names464,
	types464,
	attr_flags464,
	gtypes464,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets464,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COUNTABLE",
	names465,
	types465,
	attr_flags465,
	gtypes465,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets465,
	NULL
},
{
	(long) 2,
	(long) 2,
	"COUNTABLE_SEQUENCE",
	names466,
	types466,
	attr_flags466,
	gtypes466,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets466,
	NULL
},
{
	(long) 2,
	(long) 2,
	"PRIMES",
	names467,
	types467,
	attr_flags467,
	gtypes467,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets467,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names468,
	types468,
	attr_flags468,
	gtypes468,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets468,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names469,
	types469,
	attr_flags469,
	gtypes469,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets469,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names470,
	types470,
	attr_flags470,
	gtypes470,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets470,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names471,
	types471,
	attr_flags471,
	gtypes471,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets471,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names472,
	types472,
	attr_flags472,
	gtypes472,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets472,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names473,
	types473,
	attr_flags473,
	gtypes473,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets473,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names474,
	types474,
	attr_flags474,
	gtypes474,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets474,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names475,
	types475,
	attr_flags475,
	gtypes475,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets475,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names476,
	types476,
	attr_flags476,
	gtypes476,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets476,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names477,
	types477,
	attr_flags477,
	gtypes477,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets477,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names478,
	types478,
	attr_flags478,
	gtypes478,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets478,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names479,
	types479,
	attr_flags479,
	gtypes479,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets479,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DISPENSER",
	names480,
	types480,
	attr_flags480,
	gtypes480,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets480,
	NULL
},
{
	(long) 1,
	(long) 1,
	"QUEUE",
	names481,
	types481,
	attr_flags481,
	gtypes481,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets481,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names482,
	types482,
	attr_flags482,
	gtypes482,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets482,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names483,
	types483,
	attr_flags483,
	gtypes483,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets483,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names484,
	types484,
	attr_flags484,
	gtypes484,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets484,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names485,
	types485,
	attr_flags485,
	gtypes485,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets485,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names486,
	types486,
	attr_flags486,
	gtypes486,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets486,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names487,
	types487,
	attr_flags487,
	gtypes487,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets487,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names488,
	types488,
	attr_flags488,
	gtypes488,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets488,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names489,
	types489,
	attr_flags489,
	gtypes489,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets489,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names490,
	types490,
	attr_flags490,
	gtypes490,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets490,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names491,
	types491,
	attr_flags491,
	gtypes491,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets491,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names492,
	types492,
	attr_flags492,
	gtypes492,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets492,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names493,
	types493,
	attr_flags493,
	gtypes493,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets493,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names494,
	types494,
	attr_flags494,
	gtypes494,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets494,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names495,
	types495,
	attr_flags495,
	gtypes495,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets495,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names496,
	types496,
	attr_flags496,
	gtypes496,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets496,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names497,
	types497,
	attr_flags497,
	gtypes497,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets497,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names498,
	types498,
	attr_flags498,
	gtypes498,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets498,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names499,
	types499,
	attr_flags499,
	gtypes499,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets499,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names500,
	types500,
	attr_flags500,
	gtypes500,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets500,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names501,
	types501,
	attr_flags501,
	gtypes501,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets501,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names502,
	types502,
	attr_flags502,
	gtypes502,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets502,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names503,
	types503,
	attr_flags503,
	gtypes503,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets503,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names504,
	types504,
	attr_flags504,
	gtypes504,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets504,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names505,
	types505,
	attr_flags505,
	gtypes505,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets505,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names506,
	types506,
	attr_flags506,
	gtypes506,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets506,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names507,
	types507,
	attr_flags507,
	gtypes507,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets507,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names508,
	types508,
	attr_flags508,
	gtypes508,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets508,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names509,
	types509,
	attr_flags509,
	gtypes509,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets509,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names510,
	types510,
	attr_flags510,
	gtypes510,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets510,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names511,
	types511,
	attr_flags511,
	gtypes511,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets511,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names512,
	types512,
	attr_flags512,
	gtypes512,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets512,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names513,
	types513,
	attr_flags513,
	gtypes513,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets513,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names514,
	types514,
	attr_flags514,
	gtypes514,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets514,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names515,
	types515,
	attr_flags515,
	gtypes515,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets515,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names516,
	types516,
	attr_flags516,
	gtypes516,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets516,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names517,
	types517,
	attr_flags517,
	gtypes517,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets517,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names518,
	types518,
	attr_flags518,
	gtypes518,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets518,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names519,
	types519,
	attr_flags519,
	gtypes519,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets519,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names520,
	types520,
	attr_flags520,
	gtypes520,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets520,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names521,
	types521,
	attr_flags521,
	gtypes521,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets521,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names522,
	types522,
	attr_flags522,
	gtypes522,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets522,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names523,
	types523,
	attr_flags523,
	gtypes523,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets523,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names524,
	types524,
	attr_flags524,
	gtypes524,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets524,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names525,
	types525,
	attr_flags525,
	gtypes525,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets525,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names526,
	types526,
	attr_flags526,
	gtypes526,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets526,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names527,
	types527,
	attr_flags527,
	gtypes527,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets527,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names528,
	types528,
	attr_flags528,
	gtypes528,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets528,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names529,
	types529,
	attr_flags529,
	gtypes529,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets529,
	NULL
},
{
	(long) 20,
	(long) 19,
	"FILE",
	names530,
	types530,
	attr_flags530,
	gtypes530,
	(uint16) 0x5400,
	(void (*)()) 0,
	offsets530,
	NULL
},
{
	(long) 23,
	(long) 22,
	"PLAIN_TEXT_FILE",
	names531,
	types531,
	attr_flags531,
	gtypes531,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets531,
	NULL
},
{
	(long) 21,
	(long) 20,
	"RAW_FILE",
	names532,
	types532,
	attr_flags532,
	gtypes532,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets532,
	NULL
},
{
	(long) 21,
	(long) 20,
	"C_FILE",
	names533,
	types533,
	attr_flags533,
	gtypes533,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets533,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names558,
	types558,
	attr_flags558,
	gtypes558,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets558,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names559,
	types559,
	attr_flags559,
	gtypes559,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets559,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names560,
	types560,
	attr_flags560,
	gtypes560,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets560,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names561,
	types561,
	attr_flags561,
	gtypes561,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets561,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names562,
	types562,
	attr_flags562,
	gtypes562,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets562,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names563,
	types563,
	attr_flags563,
	gtypes563,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets563,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names564,
	types564,
	attr_flags564,
	gtypes564,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets564,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names565,
	types565,
	attr_flags565,
	gtypes565,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets565,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names566,
	types566,
	attr_flags566,
	gtypes566,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets566,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names567,
	types567,
	attr_flags567,
	gtypes567,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets567,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names568,
	types568,
	attr_flags568,
	gtypes568,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets568,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names569,
	types569,
	attr_flags569,
	gtypes569,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets569,
	NULL
},
{
	(long) 3,
	(long) 3,
	"INTEGER_INTERVAL",
	names570,
	types570,
	attr_flags570,
	gtypes570,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets570,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names571,
	types571,
	attr_flags571,
	gtypes571,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets571,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names572,
	types572,
	attr_flags572,
	gtypes572,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets572,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names573,
	types573,
	attr_flags573,
	gtypes573,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets573,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names574,
	types574,
	attr_flags574,
	gtypes574,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets574,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names575,
	types575,
	attr_flags575,
	gtypes575,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets575,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names576,
	types576,
	attr_flags576,
	gtypes576,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets576,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names577,
	types577,
	attr_flags577,
	gtypes577,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets577,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names578,
	types578,
	attr_flags578,
	gtypes578,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets578,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names579,
	types579,
	attr_flags579,
	gtypes579,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets579,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names580,
	types580,
	attr_flags580,
	gtypes580,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets580,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names581,
	types581,
	attr_flags581,
	gtypes581,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets581,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names582,
	types582,
	attr_flags582,
	gtypes582,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets582,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names583,
	types583,
	attr_flags583,
	gtypes583,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets583,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names584,
	types584,
	attr_flags584,
	gtypes584,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets584,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names585,
	types585,
	attr_flags585,
	gtypes585,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets585,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names586,
	types586,
	attr_flags586,
	gtypes586,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets586,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names587,
	types587,
	attr_flags587,
	gtypes587,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets587,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names588,
	types588,
	attr_flags588,
	gtypes588,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets588,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names589,
	types589,
	attr_flags589,
	gtypes589,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets589,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names590,
	types590,
	attr_flags590,
	gtypes590,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets590,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names591,
	types591,
	attr_flags591,
	gtypes591,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets591,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names592,
	types592,
	attr_flags592,
	gtypes592,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets592,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names593,
	types593,
	attr_flags593,
	gtypes593,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets593,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names594,
	types594,
	attr_flags594,
	gtypes594,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets594,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names595,
	types595,
	attr_flags595,
	gtypes595,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets595,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names596,
	types596,
	attr_flags596,
	gtypes596,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets596,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names597,
	types597,
	attr_flags597,
	gtypes597,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets597,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names598,
	types598,
	attr_flags598,
	gtypes598,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets598,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names599,
	types599,
	attr_flags599,
	gtypes599,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets599,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names600,
	types600,
	attr_flags600,
	gtypes600,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets600,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names601,
	types601,
	attr_flags601,
	gtypes601,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets601,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names602,
	types602,
	attr_flags602,
	gtypes602,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets602,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names603,
	types603,
	attr_flags603,
	gtypes603,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets603,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names604,
	types604,
	attr_flags604,
	gtypes604,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets604,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names605,
	types605,
	attr_flags605,
	gtypes605,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets605,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names606,
	types606,
	attr_flags606,
	gtypes606,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets606,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names607,
	types607,
	attr_flags607,
	gtypes607,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets607,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names608,
	types608,
	attr_flags608,
	gtypes608,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets608,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names609,
	types609,
	attr_flags609,
	gtypes609,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets609,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names610,
	types610,
	attr_flags610,
	gtypes610,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets610,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names611,
	types611,
	attr_flags611,
	gtypes611,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets611,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names612,
	types612,
	attr_flags612,
	gtypes612,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets612,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names613,
	types613,
	attr_flags613,
	gtypes613,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets613,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names614,
	types614,
	attr_flags614,
	gtypes614,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets614,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names615,
	types615,
	attr_flags615,
	gtypes615,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets615,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names616,
	types616,
	attr_flags616,
	gtypes616,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets616,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names617,
	types617,
	attr_flags617,
	gtypes617,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets617,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names618,
	types618,
	attr_flags618,
	gtypes618,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets618,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names619,
	types619,
	attr_flags619,
	gtypes619,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets619,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names620,
	types620,
	attr_flags620,
	gtypes620,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets620,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names621,
	types621,
	attr_flags621,
	gtypes621,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets621,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names622,
	types622,
	attr_flags622,
	gtypes622,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets622,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names623,
	types623,
	attr_flags623,
	gtypes623,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets623,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names624,
	types624,
	attr_flags624,
	gtypes624,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets624,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names625,
	types625,
	attr_flags625,
	gtypes625,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets625,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names626,
	types626,
	attr_flags626,
	gtypes626,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets626,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names627,
	types627,
	attr_flags627,
	gtypes627,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets627,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names628,
	types628,
	attr_flags628,
	gtypes628,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets628,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names629,
	types629,
	attr_flags629,
	gtypes629,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets629,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names630,
	types630,
	attr_flags630,
	gtypes630,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets630,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_LIST",
	names631,
	types631,
	attr_flags631,
	gtypes631,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets631,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_LIST",
	names632,
	types632,
	attr_flags632,
	gtypes632,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets632,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MISMATCH_CORRECTOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_QUEUE",
	names634,
	types634,
	attr_flags634,
	gtypes634,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets634,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names635,
	types635,
	attr_flags635,
	gtypes635,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets635,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names636,
	types636,
	attr_flags636,
	gtypes636,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets636,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names637,
	types637,
	attr_flags637,
	gtypes637,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets637,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names638,
	types638,
	attr_flags638,
	gtypes638,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets638,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names639,
	types639,
	attr_flags639,
	gtypes639,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets639,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names640,
	types640,
	attr_flags640,
	gtypes640,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets640,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names641,
	types641,
	attr_flags641,
	gtypes641,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets641,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names642,
	types642,
	attr_flags642,
	gtypes642,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets642,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names643,
	types643,
	attr_flags643,
	gtypes643,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets643,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names644,
	types644,
	attr_flags644,
	gtypes644,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets644,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names645,
	types645,
	attr_flags645,
	gtypes645,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets645,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names646,
	types646,
	attr_flags646,
	gtypes646,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets646,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names647,
	types647,
	attr_flags647,
	gtypes647,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets647,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names648,
	types648,
	attr_flags648,
	gtypes648,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets648,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names649,
	types649,
	attr_flags649,
	gtypes649,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets649,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names650,
	types650,
	attr_flags650,
	gtypes650,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets650,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names651,
	types651,
	attr_flags651,
	gtypes651,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets651,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names652,
	types652,
	attr_flags652,
	gtypes652,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets652,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names653,
	types653,
	attr_flags653,
	gtypes653,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets653,
	NULL
},
{
	(long) 19,
	(long) 19,
	"MISMATCH_INFORMATION",
	names654,
	types654,
	attr_flags654,
	gtypes654,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets654,
	NULL
},
{
	(long) 0,
	(long) 0,
	"HASHABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"PATH",
	names656,
	types656,
	attr_flags656,
	gtypes656,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets656,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names657,
	types657,
	attr_flags657,
	gtypes657,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets657,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names658,
	types658,
	attr_flags658,
	gtypes658,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets658,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names659,
	types659,
	attr_flags659,
	gtypes659,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets659,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names660,
	types660,
	attr_flags660,
	gtypes660,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets660,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names661,
	types661,
	attr_flags661,
	gtypes661,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets661,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names662,
	types662,
	attr_flags662,
	gtypes662,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets662,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names663,
	types663,
	attr_flags663,
	gtypes663,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets663,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names664,
	types664,
	attr_flags664,
	gtypes664,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets664,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names665,
	types665,
	attr_flags665,
	gtypes665,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets665,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names666,
	types666,
	attr_flags666,
	gtypes666,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets666,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names667,
	types667,
	attr_flags667,
	gtypes667,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets667,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names668,
	types668,
	attr_flags668,
	gtypes668,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets668,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names669,
	types669,
	attr_flags669,
	gtypes669,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets669,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names670,
	types670,
	attr_flags670,
	gtypes670,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets670,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names671,
	types671,
	attr_flags671,
	gtypes671,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets671,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names672,
	types672,
	attr_flags672,
	gtypes672,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets672,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names673,
	types673,
	attr_flags673,
	gtypes673,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets673,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names674,
	types674,
	attr_flags674,
	gtypes674,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets674,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names675,
	types675,
	attr_flags675,
	gtypes675,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets675,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names676,
	types676,
	attr_flags676,
	gtypes676,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets676,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names677,
	types677,
	attr_flags677,
	gtypes677,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets677,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names678,
	types678,
	attr_flags678,
	gtypes678,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets678,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names679,
	types679,
	attr_flags679,
	gtypes679,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets679,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names680,
	types680,
	attr_flags680,
	gtypes680,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets680,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names681,
	types681,
	attr_flags681,
	gtypes681,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets681,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names682,
	types682,
	attr_flags682,
	gtypes682,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets682,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names683,
	types683,
	attr_flags683,
	gtypes683,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets683,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names684,
	types684,
	attr_flags684,
	gtypes684,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets684,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names685,
	types685,
	attr_flags685,
	gtypes685,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets685,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names686,
	types686,
	attr_flags686,
	gtypes686,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets686,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names687,
	types687,
	attr_flags687,
	gtypes687,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets687,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TUPLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32_REF",
	names689,
	types689,
	attr_flags689,
	gtypes689,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets689,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32",
	names690,
	types690,
	attr_flags690,
	gtypes690,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets690,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32",
	names691,
	types691,
	attr_flags691,
	gtypes691,
	(uint16) 0x2308,
	(void (*)()) 0,
	offsets691,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16_REF",
	names692,
	types692,
	attr_flags692,
	gtypes692,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets692,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16",
	names693,
	types693,
	attr_flags693,
	gtypes693,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets693,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16",
	names694,
	types694,
	attr_flags694,
	gtypes694,
	(uint16) 0x2307,
	(void (*)()) 0,
	offsets694,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8_REF",
	names695,
	types695,
	attr_flags695,
	gtypes695,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets695,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8",
	names696,
	types696,
	attr_flags696,
	gtypes696,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets696,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8",
	names697,
	types697,
	attr_flags697,
	gtypes697,
	(uint16) 0x2306,
	(void (*)()) 0,
	offsets697,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64_REF",
	names698,
	types698,
	attr_flags698,
	gtypes698,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets698,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64",
	names699,
	types699,
	attr_flags699,
	gtypes699,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets699,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64",
	names700,
	types700,
	attr_flags700,
	gtypes700,
	(uint16) 0x230D,
	(void (*)()) 0,
	offsets700,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32_REF",
	names701,
	types701,
	attr_flags701,
	gtypes701,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets701,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32",
	names702,
	types702,
	attr_flags702,
	gtypes702,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets702,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32",
	names703,
	types703,
	attr_flags703,
	gtypes703,
	(uint16) 0x230C,
	(void (*)()) 0,
	offsets703,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16_REF",
	names704,
	types704,
	attr_flags704,
	gtypes704,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets704,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16",
	names705,
	types705,
	attr_flags705,
	gtypes705,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets705,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16",
	names706,
	types706,
	attr_flags706,
	gtypes706,
	(uint16) 0x230B,
	(void (*)()) 0,
	offsets706,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8_REF",
	names707,
	types707,
	attr_flags707,
	gtypes707,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets707,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8",
	names708,
	types708,
	attr_flags708,
	gtypes708,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets708,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8",
	names709,
	types709,
	attr_flags709,
	gtypes709,
	(uint16) 0x230A,
	(void (*)()) 0,
	offsets709,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32_REF",
	names710,
	types710,
	attr_flags710,
	gtypes710,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets710,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32",
	names711,
	types711,
	attr_flags711,
	gtypes711,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets711,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32",
	names712,
	types712,
	attr_flags712,
	gtypes712,
	(uint16) 0x2304,
	(void (*)()) 0,
	offsets712,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64_REF",
	names713,
	types713,
	attr_flags713,
	gtypes713,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets713,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64",
	names714,
	types714,
	attr_flags714,
	gtypes714,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets714,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64",
	names715,
	types715,
	attr_flags715,
	gtypes715,
	(uint16) 0x2303,
	(void (*)()) 0,
	offsets715,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32_REF",
	names716,
	types716,
	attr_flags716,
	gtypes716,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets716,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32",
	names717,
	types717,
	attr_flags717,
	gtypes717,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets717,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32",
	names718,
	types718,
	attr_flags718,
	gtypes718,
	(uint16) 0x230E,
	(void (*)()) 0,
	offsets718,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8_REF",
	names719,
	types719,
	attr_flags719,
	gtypes719,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets719,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8",
	names720,
	types720,
	attr_flags720,
	gtypes720,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets720,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8",
	names721,
	types721,
	attr_flags721,
	gtypes721,
	(uint16) 0x2302,
	(void (*)()) 0,
	offsets721,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN_REF",
	names722,
	types722,
	attr_flags722,
	gtypes722,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets722,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN",
	names723,
	types723,
	attr_flags723,
	gtypes723,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets723,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN",
	names724,
	types724,
	attr_flags724,
	gtypes724,
	(uint16) 0x2301,
	(void (*)()) 0,
	offsets724,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64_REF",
	names725,
	types725,
	attr_flags725,
	gtypes725,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets725,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64",
	names726,
	types726,
	attr_flags726,
	gtypes726,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets726,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64",
	names727,
	types727,
	attr_flags727,
	gtypes727,
	(uint16) 0x2309,
	(void (*)()) 0,
	offsets727,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER_REF",
	names728,
	types728,
	attr_flags728,
	gtypes728,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets728,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names729,
	types729,
	attr_flags729,
	gtypes729,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets729,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names730,
	types730,
	attr_flags730,
	gtypes730,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets730,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names731,
	types731,
	attr_flags731,
	gtypes731,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets731,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names732,
	types732,
	attr_flags732,
	gtypes732,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets732,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names733,
	types733,
	attr_flags733,
	gtypes733,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets733,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names734,
	types734,
	attr_flags734,
	gtypes734,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets734,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names735,
	types735,
	attr_flags735,
	gtypes735,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets735,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names736,
	types736,
	attr_flags736,
	gtypes736,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets736,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names737,
	types737,
	attr_flags737,
	gtypes737,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets737,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names738,
	types738,
	attr_flags738,
	gtypes738,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets738,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names739,
	types739,
	attr_flags739,
	gtypes739,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets739,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names740,
	types740,
	attr_flags740,
	gtypes740,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets740,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names741,
	types741,
	attr_flags741,
	gtypes741,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets741,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names742,
	types742,
	attr_flags742,
	gtypes742,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets742,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names743,
	types743,
	attr_flags743,
	gtypes743,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets743,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names744,
	types744,
	attr_flags744,
	gtypes744,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets744,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names745,
	types745,
	attr_flags745,
	gtypes745,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets745,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names746,
	types746,
	attr_flags746,
	gtypes746,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets746,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names747,
	types747,
	attr_flags747,
	gtypes747,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets747,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names748,
	types748,
	attr_flags748,
	gtypes748,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets748,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names749,
	types749,
	attr_flags749,
	gtypes749,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets749,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names750,
	types750,
	attr_flags750,
	gtypes750,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets750,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names751,
	types751,
	attr_flags751,
	gtypes751,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets751,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names752,
	types752,
	attr_flags752,
	gtypes752,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets752,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names753,
	types753,
	attr_flags753,
	gtypes753,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets753,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names754,
	types754,
	attr_flags754,
	gtypes754,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets754,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names755,
	types755,
	attr_flags755,
	gtypes755,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets755,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names756,
	types756,
	attr_flags756,
	gtypes756,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets756,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names757,
	types757,
	attr_flags757,
	gtypes757,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets757,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names758,
	types758,
	attr_flags758,
	gtypes758,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets758,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER",
	names759,
	types759,
	attr_flags759,
	gtypes759,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets759,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER",
	names760,
	types760,
	attr_flags760,
	gtypes760,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets760,
	NULL
},
{
	(long) 12,
	(long) 12,
	"ROUTINE",
	names761,
	types761,
	attr_flags761,
	gtypes761,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets761,
	NULL
},
{
	(long) 12,
	(long) 12,
	"PROCEDURE",
	names762,
	types762,
	attr_flags762,
	gtypes762,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets762,
	NULL
},
{
	(long) 13,
	(long) 13,
	"FUNCTION",
	names763,
	types763,
	attr_flags763,
	gtypes763,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets763,
	NULL
},
{
	(long) 13,
	(long) 13,
	"FUNCTION",
	names764,
	types764,
	attr_flags764,
	gtypes764,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets764,
	NULL
},
{
	(long) 13,
	(long) 13,
	"PREDICATE",
	names765,
	types765,
	attr_flags765,
	gtypes765,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets765,
	NULL
},
{
	(long) 2,
	(long) 2,
	"READABLE_STRING_GENERAL",
	names766,
	types766,
	attr_flags766,
	gtypes766,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets766,
	NULL
},
{
	(long) 2,
	(long) 2,
	"IMMUTABLE_STRING_GENERAL",
	names767,
	types767,
	attr_flags767,
	gtypes767,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets767,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_GENERAL",
	names768,
	types768,
	attr_flags768,
	gtypes768,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets768,
	NULL
},
{
	(long) 4,
	(long) 4,
	"READABLE_STRING_32",
	names769,
	types769,
	attr_flags769,
	gtypes769,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets769,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IMMUTABLE_STRING_32",
	names770,
	types770,
	attr_flags770,
	gtypes770,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets770,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_32",
	names771,
	types771,
	attr_flags771,
	gtypes771,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets771,
	NULL
},
{
	(long) 4,
	(long) 4,
	"READABLE_STRING_8",
	names772,
	types772,
	attr_flags772,
	gtypes772,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets772,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IMMUTABLE_STRING_8",
	names773,
	types773,
	attr_flags773,
	gtypes773,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets773,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_8",
	names774,
	types774,
	attr_flags774,
	gtypes774,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets774,
	NULL
},
{
	(long) 5,
	(long) 5,
	"PATH_NAME",
	names775,
	types775,
	attr_flags775,
	gtypes775,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets775,
	NULL
},
{
	(long) 5,
	(long) 5,
	"FILE_NAME",
	names776,
	types776,
	attr_flags776,
	gtypes776,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets776,
	NULL
},
{
	(long) 23,
	(long) 22,
	"CONSOLE",
	names777,
	types777,
	attr_flags777,
	gtypes777,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets777,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ENCODING_I",
	names778,
	types778,
	attr_flags778,
	gtypes778,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets778,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ENCODING_IMP",
	names779,
	types779,
	attr_flags779,
	gtypes779,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets779,
	NULL
},
{
	(long) 3,
	(long) 3,
	"UNICODE_CONVERSION",
	names780,
	types780,
	attr_flags780,
	gtypes780,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets780,
	NULL
},
{
	(long) 11,
	(long) 11,
	"RT_DBG_EXECUTION_RECORDER",
	names781,
	types781,
	attr_flags781,
	gtypes781,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets781,
	NULL
},};


#ifdef __cplusplus
}
#endif
