
#ifndef _C9_co437_
#define _C9_co437_

#ifdef __cplusplus
extern "C" {
#endif

extern void F331_2071(EIF_REFERENCE);
extern void EIF_Minit437(void);
extern long O1856[];

#ifdef __cplusplus
}
#endif

#endif
