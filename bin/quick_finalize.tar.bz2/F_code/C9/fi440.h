
#ifndef _C9_fi440_
#define _C9_fi440_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F474_2169(EIF_REFERENCE);
extern void EIF_Minit440(void);
extern char *(*R1918[])();

#ifdef __cplusplus
}
#endif

#endif
