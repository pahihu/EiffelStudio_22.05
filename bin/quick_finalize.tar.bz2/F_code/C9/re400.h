
#ifndef _C9_re400_
#define _C9_re400_

#ifdef __cplusplus
extern "C" {
#endif

extern void F261_1984(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F261_1986(EIF_REFERENCE);
extern EIF_INTEGER_32 F261_1987(EIF_REFERENCE);
extern EIF_INTEGER_32 F261_1988(EIF_REFERENCE);
extern EIF_INTEGER_32 F261_1989(EIF_REFERENCE);
extern EIF_BOOLEAN F261_1997(EIF_REFERENCE);
extern EIF_BOOLEAN F261_1998(EIF_REFERENCE);
extern void F261_2003(EIF_REFERENCE);
extern void EIF_Minit400(void);
extern char *(*R2131[])();
extern char *(*R2132[])();

#ifdef __cplusplus
}
#endif

#endif
