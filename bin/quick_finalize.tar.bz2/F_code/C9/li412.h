
#ifndef _C9_li412_
#define _C9_li412_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F354_2090(EIF_REFERENCE);
extern EIF_REFERENCE F354_2097(EIF_REFERENCE);
extern void EIF_Minit412(void);
extern EIF_BOOLEAN F473_2169(EIF_REFERENCE);
extern EIF_BOOLEAN F612_2734(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
