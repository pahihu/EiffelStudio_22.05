
#ifndef _C9_li441_
#define _C9_li441_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F355_2090(EIF_REFERENCE);
extern EIF_REFERENCE F355_2097(EIF_REFERENCE);
extern void EIF_Minit441(void);
extern EIF_BOOLEAN F613_2734(EIF_REFERENCE);
extern EIF_BOOLEAN F474_2169(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
