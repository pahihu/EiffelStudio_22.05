
#ifndef _C9_to422_
#define _C9_to422_

#ifdef __cplusplus
extern "C" {
#endif

extern void F128_1548(EIF_REFERENCE, EIF_INTEGER_32);
extern void F128_1549(EIF_REFERENCE, EIF_NATURAL_16, EIF_INTEGER_32);
extern void F128_1555(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit422(void);
extern void F550_2549(EIF_REFERENCE, EIF_NATURAL_16, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1437[];
extern EIF_TYPE_INDEX *Y1437_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
