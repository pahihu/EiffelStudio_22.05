
#ifndef _C9_re449_
#define _C9_re449_

#ifdef __cplusplus
extern "C" {
#endif

extern void F262_1984(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F262_1986(EIF_REFERENCE);
extern EIF_INTEGER_32 F262_1987(EIF_REFERENCE);
extern EIF_INTEGER_32 F262_1988(EIF_REFERENCE);
extern EIF_INTEGER_32 F262_1989(EIF_REFERENCE);
extern EIF_BOOLEAN F262_1997(EIF_REFERENCE);
extern EIF_BOOLEAN F262_1998(EIF_REFERENCE);
extern void F262_2003(EIF_REFERENCE);
extern void EIF_Minit449(void);
extern char *(*R2131[])();
extern char *(*R2132[])();

#ifdef __cplusplus
}
#endif

#endif
