
#ifndef _C9_co410_
#define _C9_co410_

#ifdef __cplusplus
extern "C" {
#endif

extern void F330_2071(EIF_REFERENCE);
extern void EIF_Minit410(void);
extern long O1856[];

#ifdef __cplusplus
}
#endif

#endif
