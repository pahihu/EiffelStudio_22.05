
#ifndef _C9_li434_
#define _C9_li434_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F612_2734(EIF_REFERENCE);
extern void EIF_Minit434(void);
extern EIF_INTEGER_32 F639_2846(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
