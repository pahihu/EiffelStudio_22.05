
#ifndef _C9_ch433_
#define _C9_ch433_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F588_2702(EIF_REFERENCE);
extern EIF_BOOLEAN F588_2710(EIF_REFERENCE);
extern void EIF_Minit433(void);
extern EIF_INTEGER_32 F639_2846(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
