
#ifndef _C9_fi411_
#define _C9_fi411_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F473_2169(EIF_REFERENCE);
extern void EIF_Minit411(void);
extern char *(*R1918[])();

#ifdef __cplusplus
}
#endif

#endif
