
#ifndef _C9_re420_
#define _C9_re420_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F498_2182(EIF_REFERENCE);
extern void EIF_Minit420(void);
extern char *(*R1921[])();

#ifdef __cplusplus
}
#endif

#endif
