#include "epoly1.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R11[767])();
void R11_init () {
	{long i; for (i = 0; i < 3; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 15; i < 17; i++) R11[i] = (char *(*)()) F1_8;}
	R11[23] = (char *(*)()) F1_8;
	{long i; for (i = 27; i < 33; i++) R11[i] = (char *(*)()) F1_8;}
	R11[35] = (char *(*)()) F1_8;
	{long i; for (i = 43; i < 45; i++) R11[i] = (char *(*)()) F1_8;}
	R11[46] = (char *(*)()) F1_8;
	R11[51] = (char *(*)()) F1_8;
	R11[55] = (char *(*)()) F1_8;
	{long i; for (i = 62; i < 65; i++) R11[i] = (char *(*)()) F1_8;}
	R11[68] = (char *(*)()) F1_8;
	{long i; for (i = 70; i < 73; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 74; i < 77; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 78; i < 80; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 82; i < 84; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 85; i < 88; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 89; i < 93; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 94; i < 96; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 97; i < 103; i++) R11[i] = (char *(*)()) F1_8;}
	R11[104] = (char *(*)()) F115_1119;
	R11[108] = (char *(*)()) F1_8;
	R11[128] = (char *(*)()) F139_1658;
	{long i; for (i = 130; i < 132; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 259; i < 264; i++) R11[i] = (char *(*)()) F1_8;}
	R11[456] = (char *(*)()) F1_8;
	{long i; for (i = 520; i < 523; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 535; i < 547; i++) R11[i] = (char *(*)()) F1_8;}
	R11[560] = (char *(*)()) F571_2652;
	R11[561] = (char *(*)()) F572_2652;
	R11[562] = (char *(*)()) F573_2652;
	R11[563] = (char *(*)()) F574_2652;
	R11[564] = (char *(*)()) F575_2652;
	R11[565] = (char *(*)()) F576_2652;
	R11[566] = (char *(*)()) F577_2652;
	R11[567] = (char *(*)()) F578_2652;
	R11[568] = (char *(*)()) F579_2652;
	R11[569] = (char *(*)()) F580_2652;
	R11[570] = (char *(*)()) F581_2652;
	R11[571] = (char *(*)()) F582_2652;
	R11[624] = (char *(*)()) F635_2849;
	R11[625] = (char *(*)()) F636_2849;
	R11[626] = (char *(*)()) F637_2849;
	R11[627] = (char *(*)()) F638_2849;
	R11[628] = (char *(*)()) F639_2849;
	R11[629] = (char *(*)()) F640_2849;
	R11[630] = (char *(*)()) F641_2849;
	R11[631] = (char *(*)()) F642_2849;
	R11[632] = (char *(*)()) F643_2849;
	R11[633] = (char *(*)()) F644_2849;
	R11[634] = (char *(*)()) F645_2849;
	R11[635] = (char *(*)()) F646_2849;
	R11[636] = (char *(*)()) F647_2914;
	R11[637] = (char *(*)()) F648_2914;
	R11[638] = (char *(*)()) F649_2914;
	R11[639] = (char *(*)()) F650_2914;
	R11[640] = (char *(*)()) F651_2914;
	R11[643] = (char *(*)()) F647_2914;
	R11[646] = (char *(*)()) F657_3096;
	R11[647] = (char *(*)()) F658_3096;
	R11[648] = (char *(*)()) F659_3096;
	R11[649] = (char *(*)()) F660_3096;
	R11[650] = (char *(*)()) F661_3096;
	R11[651] = (char *(*)()) F662_3096;
	R11[652] = (char *(*)()) F663_3096;
	R11[653] = (char *(*)()) F664_3096;
	R11[654] = (char *(*)()) F665_3096;
	R11[655] = (char *(*)()) F666_3096;
	R11[656] = (char *(*)()) F667_3096;
	R11[657] = (char *(*)()) F668_3096;
	R11[658] = (char *(*)()) F669_3096;
	R11[659] = (char *(*)()) F670_3096;
	R11[660] = (char *(*)()) F671_3096;
	R11[661] = (char *(*)()) F672_3096;
	R11[662] = (char *(*)()) F673_3096;
	R11[663] = (char *(*)()) F674_3096;
	R11[664] = (char *(*)()) F675_3096;
	R11[665] = (char *(*)()) F676_3096;
	R11[666] = (char *(*)()) F677_3096;
	R11[667] = (char *(*)()) F678_3096;
	R11[668] = (char *(*)()) F679_3096;
	R11[669] = (char *(*)()) F680_3096;
	R11[670] = (char *(*)()) F681_3096;
	R11[671] = (char *(*)()) F682_3096;
	R11[672] = (char *(*)()) F683_3096;
	R11[673] = (char *(*)()) F684_3096;
	R11[674] = (char *(*)()) F685_3096;
	R11[675] = (char *(*)()) F686_3096;
	R11[676] = (char *(*)()) F687_3096;
	R11[677] = (char *(*)()) F688_3139;
	{long i; for (i = 679; i < 681; i++) R11[i] = (char *(*)()) F689_3257;}
	{long i; for (i = 682; i < 684; i++) R11[i] = (char *(*)()) F692_3356;}
	{long i; for (i = 685; i < 687; i++) R11[i] = (char *(*)()) F695_3455;}
	{long i; for (i = 688; i < 690; i++) R11[i] = (char *(*)()) F698_3554;}
	{long i; for (i = 691; i < 693; i++) R11[i] = (char *(*)()) F701_3648;}
	{long i; for (i = 694; i < 696; i++) R11[i] = (char *(*)()) F704_3742;}
	{long i; for (i = 697; i < 699; i++) R11[i] = (char *(*)()) F707_3837;}
	{long i; for (i = 700; i < 702; i++) R11[i] = (char *(*)()) F710_3936;}
	{long i; for (i = 703; i < 705; i++) R11[i] = (char *(*)()) F713_4002;}
	{long i; for (i = 706; i < 708; i++) R11[i] = (char *(*)()) F716_4063;}
	{long i; for (i = 709; i < 711; i++) R11[i] = (char *(*)()) F719_4103;}
	{long i; for (i = 712; i < 714; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 715; i < 717; i++) R11[i] = (char *(*)()) F725_4175;}
	{long i; for (i = 718; i < 750; i++) R11[i] = (char *(*)()) F728_4267;}
	{long i; for (i = 759; i < 761; i++) R11[i] = (char *(*)()) F769_4503;}
	{long i; for (i = 762; i < 764; i++) R11[i] = (char *(*)()) F772_4671;}
	R11[765] = (char *(*)()) F775_4812;
	R11[766] = (char *(*)()) F1_8;
}

char *(*R634[4])();
void R634_init () {
	R634[0] = (char *(*)()) F40_642;
	R634[1] = (char *(*)()) F41_642_634_1;
	R634[2] = (char *(*)()) F42_642_634_1;
	R634[3] = (char *(*)()) F43_642_634_1;
}
static EIF_REFERENCE F41_642_634_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F41_642(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(690, 0x00).id, 690, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F42_642_634_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F42_642(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(717, 0x00).id, 717, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F43_642_634_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F43_642(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(699, 0x00).id, 699, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}

char *(*R864[87])();
void R864_init () {
	R864[0] = (char *(*)()) F690_3319_864_2;
	R864[1] = (char *(*)()) F691_3319_864_2;
	R864[3] = (char *(*)()) F693_3418_864_2;
	R864[4] = (char *(*)()) F694_3418_864_2;
	R864[6] = (char *(*)()) F696_3517_864_2;
	R864[7] = (char *(*)()) F697_3517_864_2;
	R864[9] = (char *(*)()) F699_3612_864_2;
	R864[10] = (char *(*)()) F700_3612_864_2;
	R864[12] = (char *(*)()) F702_3706_864_2;
	R864[13] = (char *(*)()) F703_3706_864_2;
	R864[15] = (char *(*)()) F705_3801_864_2;
	R864[16] = (char *(*)()) F706_3801_864_2;
	R864[18] = (char *(*)()) F708_3896_864_2;
	R864[19] = (char *(*)()) F709_3896_864_2;
	R864[21] = (char *(*)()) F711_3965_864_2;
	R864[22] = (char *(*)()) F712_3965_864_2;
	R864[24] = (char *(*)()) F714_4031_864_2;
	R864[25] = (char *(*)()) F715_4031_864_2;
	{long i; for (i = 27; i < 29; i++) R864[i] = (char *(*)()) F716_4062;}
	{long i; for (i = 30; i < 32; i++) R864[i] = (char *(*)()) F719_4102;}
	R864[36] = (char *(*)()) F726_4236_864_2;
	R864[37] = (char *(*)()) F727_4236_864_2;
	{long i; for (i = 80; i < 82; i++) R864[i] = (char *(*)()) F769_4508;}
	{long i; for (i = 83; i < 85; i++) R864[i] = (char *(*)()) F772_4676;}
	R864[86] = (char *(*)()) F772_4676;
}
static EIF_BOOLEAN F690_3319_864_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F690_3319(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F691_3319_864_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F691_3319(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F693_3418_864_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F693_3418(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F694_3418_864_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F694_3418(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F696_3517_864_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F696_3517(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F697_3517_864_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F697_3517(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F699_3612_864_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F699_3612(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F700_3612_864_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F700_3612(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F702_3706_864_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F702_3706(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F703_3706_864_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F703_3706(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F705_3801_864_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F705_3801(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F706_3801_864_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F706_3801(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F708_3896_864_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F708_3896(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F709_3896_864_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F709_3896(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F711_3965_864_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F711_3965(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F712_3965_864_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F712_3965(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F714_4031_864_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F714_4031(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F715_4031_864_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F715_4031(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F726_4236_864_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F726_4236(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F727_4236_864_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F727_4236(Current, *(EIF_INTEGER_64 *)arg1);
}

char *(*R948[40])();
void R948_init () {
	R948[0] = (char *(*)()) F74_994;
	R948[1] = (char *(*)()) F75_1018;
	R948[5] = (char *(*)()) F79_1021;
	R948[7] = (char *(*)()) F81_1023;
	R948[8] = (char *(*)()) F82_1027;
	R948[9] = (char *(*)()) F83_1033;
	R948[11] = (char *(*)()) F85_1050;
	R948[12] = (char *(*)()) F86_1052;
	R948[13] = (char *(*)()) F87_1054;
	R948[15] = (char *(*)()) F89_1056;
	R948[16] = (char *(*)()) F90_1060;
	R948[19] = (char *(*)()) F93_1062;
	R948[20] = (char *(*)()) F94_1064;
	R948[22] = (char *(*)()) F96_1068;
	R948[23] = (char *(*)()) F97_1070;
	R948[24] = (char *(*)()) F98_1076;
	R948[26] = (char *(*)()) F100_1078;
	R948[27] = (char *(*)()) F101_1080;
	R948[28] = (char *(*)()) F102_1084;
	R948[29] = (char *(*)()) F103_1088;
	R948[31] = (char *(*)()) F105_1090;
	R948[32] = (char *(*)()) F106_1092;
	R948[34] = (char *(*)()) F108_1094;
	R948[35] = (char *(*)()) F109_1096;
	R948[36] = (char *(*)()) F110_1098;
	R948[37] = (char *(*)()) F111_1102;
	R948[38] = (char *(*)()) F112_1104;
	R948[39] = (char *(*)()) F113_1106;
}

char *(*R1126[247])();
void R1126_init () {
	{long i; for (i = 0; i < 3; i++) R1126[i] = (char *(*)()) F530_2230;}
	R1126[246] = (char *(*)()) F777_4847;
}

char *(*R1139[247])();
void R1139_init () {
	{long i; for (i = 0; i < 3; i++) R1139[i] = (char *(*)()) F530_2304;}
	R1139[246] = (char *(*)()) F777_4870;
}

char *(*R1169[247])();
void R1169_init () {
	{long i; for (i = 0; i < 3; i++) R1169[i] = (char *(*)()) F530_2337;}
	R1169[246] = (char *(*)()) F777_4865;
}

char *(*R1182[247])();
void R1182_init () {
	{long i; for (i = 0; i < 3; i++) R1182[i] = (char *(*)()) F530_2344;}
	R1182[246] = (char *(*)()) F777_4859;
}

char *(*R1435[638])();
void R1435_init () {
	R1435[0] = (char *(*)()) F127_1548;
	R1435[432] = (char *(*)()) F124_1548;
	R1435[433] = (char *(*)()) F125_1548;
	R1435[434] = (char *(*)()) F126_1548;
	R1435[435] = (char *(*)()) F127_1548;
	R1435[436] = (char *(*)()) F128_1548;
	R1435[437] = (char *(*)()) F129_1548;
	R1435[438] = (char *(*)()) F130_1548;
	R1435[439] = (char *(*)()) F131_1548;
	R1435[440] = (char *(*)()) F132_1548;
	R1435[441] = (char *(*)()) F133_1548;
	R1435[442] = (char *(*)()) F134_1548;
	R1435[443] = (char *(*)()) F135_1548;
	R1435[496] = (char *(*)()) F124_1548;
	R1435[497] = (char *(*)()) F125_1548;
	R1435[498] = (char *(*)()) F126_1548;
	R1435[499] = (char *(*)()) F127_1548;
	R1435[500] = (char *(*)()) F128_1548;
	R1435[501] = (char *(*)()) F129_1548;
	R1435[502] = (char *(*)()) F130_1548;
	R1435[503] = (char *(*)()) F131_1548;
	R1435[504] = (char *(*)()) F132_1548;
	R1435[505] = (char *(*)()) F133_1548;
	R1435[506] = (char *(*)()) F134_1548;
	R1435[507] = (char *(*)()) F135_1548;
	R1435[632] = (char *(*)()) F125_1548;
	R1435[635] = (char *(*)()) F126_1548;
	R1435[637] = (char *(*)()) F126_1548;
}

char *(*R1436[638])();
void R1436_init () {
	R1436[0] = (char *(*)()) F127_1549_1436_106;
	R1436[432] = (char *(*)()) F124_1549;
	R1436[433] = (char *(*)()) F125_1549_1436_106;
	R1436[434] = (char *(*)()) F126_1549_1436_106;
	R1436[435] = (char *(*)()) F127_1549_1436_106;
	R1436[436] = (char *(*)()) F128_1549_1436_106;
	R1436[437] = (char *(*)()) F129_1549_1436_106;
	R1436[438] = (char *(*)()) F130_1549_1436_106;
	R1436[439] = (char *(*)()) F131_1549_1436_106;
	R1436[440] = (char *(*)()) F132_1549_1436_106;
	R1436[441] = (char *(*)()) F133_1549_1436_106;
	R1436[442] = (char *(*)()) F134_1549_1436_106;
	R1436[443] = (char *(*)()) F135_1549_1436_106;
	R1436[496] = (char *(*)()) F124_1549;
	R1436[497] = (char *(*)()) F125_1549_1436_106;
	R1436[498] = (char *(*)()) F126_1549_1436_106;
	R1436[499] = (char *(*)()) F127_1549_1436_106;
	R1436[500] = (char *(*)()) F128_1549_1436_106;
	R1436[501] = (char *(*)()) F129_1549_1436_106;
	R1436[502] = (char *(*)()) F130_1549_1436_106;
	R1436[503] = (char *(*)()) F131_1549_1436_106;
	R1436[504] = (char *(*)()) F132_1549_1436_106;
	R1436[505] = (char *(*)()) F133_1549_1436_106;
	R1436[506] = (char *(*)()) F134_1549_1436_106;
	R1436[507] = (char *(*)()) F135_1549_1436_106;
	R1436[632] = (char *(*)()) F125_1549_1436_106;
	R1436[635] = (char *(*)()) F126_1549_1436_106;
	R1436[637] = (char *(*)()) F126_1549_1436_106;
}
static void F127_1549_1436_106 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F127_1549(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F125_1549_1436_106 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F125_1549(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F126_1549_1436_106 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F126_1549(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F128_1549_1436_106 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F128_1549(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F129_1549_1436_106 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F129_1549(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F130_1549_1436_106 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F130_1549(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F131_1549_1436_106 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F131_1549(Current, *(EIF_REAL_64 *)arg1, arg2);
}
static void F132_1549_1436_106 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F132_1549(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F133_1549_1436_106 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F133_1549(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F134_1549_1436_106 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F134_1549(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F135_1549_1436_106 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F135_1549(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R1442[638])();
void R1442_init () {
	R1442[0] = (char *(*)()) F127_1555;
	R1442[432] = (char *(*)()) F124_1555;
	R1442[433] = (char *(*)()) F125_1555;
	R1442[434] = (char *(*)()) F126_1555;
	R1442[435] = (char *(*)()) F127_1555;
	R1442[436] = (char *(*)()) F128_1555;
	R1442[437] = (char *(*)()) F129_1555;
	R1442[438] = (char *(*)()) F130_1555;
	R1442[439] = (char *(*)()) F131_1555;
	R1442[440] = (char *(*)()) F132_1555;
	R1442[441] = (char *(*)()) F133_1555;
	R1442[442] = (char *(*)()) F134_1555;
	R1442[443] = (char *(*)()) F135_1555;
	R1442[496] = (char *(*)()) F124_1555;
	R1442[497] = (char *(*)()) F125_1555;
	R1442[498] = (char *(*)()) F126_1555;
	R1442[499] = (char *(*)()) F127_1555;
	R1442[500] = (char *(*)()) F128_1555;
	R1442[501] = (char *(*)()) F129_1555;
	R1442[502] = (char *(*)()) F130_1555;
	R1442[503] = (char *(*)()) F131_1555;
	R1442[504] = (char *(*)()) F132_1555;
	R1442[505] = (char *(*)()) F133_1555;
	R1442[506] = (char *(*)()) F134_1555;
	R1442[507] = (char *(*)()) F135_1555;
	R1442[632] = (char *(*)()) F125_1555;
	R1442[635] = (char *(*)()) F126_1555;
	R1442[637] = (char *(*)()) F126_1555;
}

static EIF_TYPE_INDEX Y1443_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype12[] = {708,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype13[] = {708,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype38[] = {717,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype39[] = {720,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype40[] = {720,0xFFFF};
static EIF_TYPE_INDEX Y1443_pgtype41[] = {720,0xFFFF};
EIF_TYPE_INDEX *Y1443_gen_type [653];
EIF_TYPE_INDEX Y1443 [653];
void Y1443_init (void)
{
	egc_routines_types [1443] = Y1443;
	egc_routines_gen_types [1443] = Y1443_gen_type;
	egc_routines_offset [1443] = 123;
	Y1443_gen_type [0] = Y1443_pgtype0;
	Y1443_gen_type [1] = Y1443_pgtype1;
	Y1443_gen_type [2] = Y1443_pgtype2;
	Y1443_gen_type [3] = Y1443_pgtype3;
	Y1443_gen_type [4] = Y1443_pgtype4;
	Y1443_gen_type [5] = Y1443_pgtype5;
	Y1443_gen_type [6] = Y1443_pgtype6;
	Y1443_gen_type [7] = Y1443_pgtype7;
	Y1443_gen_type [8] = Y1443_pgtype8;
	Y1443_gen_type [9] = Y1443_pgtype9;
	Y1443_gen_type [10] = Y1443_pgtype10;
	Y1443_gen_type [11] = Y1443_pgtype11;
	Y1443_gen_type [15] = Y1443_pgtype12;
	Y1443_gen_type [16] = Y1443_pgtype13;
	Y1443_gen_type [447] = Y1443_pgtype14;
	Y1443_gen_type [448] = Y1443_pgtype15;
	Y1443_gen_type [449] = Y1443_pgtype16;
	Y1443_gen_type [450] = Y1443_pgtype17;
	Y1443_gen_type [451] = Y1443_pgtype18;
	Y1443_gen_type [452] = Y1443_pgtype19;
	Y1443_gen_type [453] = Y1443_pgtype20;
	Y1443_gen_type [454] = Y1443_pgtype21;
	Y1443_gen_type [455] = Y1443_pgtype22;
	Y1443_gen_type [456] = Y1443_pgtype23;
	Y1443_gen_type [457] = Y1443_pgtype24;
	Y1443_gen_type [458] = Y1443_pgtype25;
	Y1443_gen_type [511] = Y1443_pgtype26;
	Y1443_gen_type [512] = Y1443_pgtype27;
	Y1443_gen_type [513] = Y1443_pgtype28;
	Y1443_gen_type [514] = Y1443_pgtype29;
	Y1443_gen_type [515] = Y1443_pgtype30;
	Y1443_gen_type [516] = Y1443_pgtype31;
	Y1443_gen_type [517] = Y1443_pgtype32;
	Y1443_gen_type [518] = Y1443_pgtype33;
	Y1443_gen_type [519] = Y1443_pgtype34;
	Y1443_gen_type [520] = Y1443_pgtype35;
	Y1443_gen_type [521] = Y1443_pgtype36;
	Y1443_gen_type [522] = Y1443_pgtype37;
	Y1443_gen_type [647] = Y1443_pgtype38;
	Y1443_gen_type [650] = Y1443_pgtype39;
	Y1443_gen_type [651] = Y1443_pgtype40;
	Y1443_gen_type [652] = Y1443_pgtype41;
	{long i; for (i = 15; i < 17; i++) Y1443[i] = 708;};
	Y1443[647] = 717;
	{long i; for (i = 650; i < 653; i++) Y1443[i] = 720;};
}

char *(*R1692[12])();
void R1692_init () {
	R1692[0] = (char *(*)()) F546_2561;
	R1692[1] = (char *(*)()) F547_2561;
	R1692[2] = (char *(*)()) F548_2561;
	R1692[3] = (char *(*)()) F549_2561;
	R1692[4] = (char *(*)()) F550_2561;
	R1692[5] = (char *(*)()) F551_2561;
	R1692[6] = (char *(*)()) F552_2561;
	R1692[7] = (char *(*)()) F553_2561;
	R1692[8] = (char *(*)()) F554_2561;
	R1692[9] = (char *(*)()) F555_2561;
	R1692[10] = (char *(*)()) F556_2561;
	R1692[11] = (char *(*)()) F557_2561;
}

char *(*R1693[12])();
void R1693_init () {
	R1693[0] = (char *(*)()) F546_2562;
	R1693[1] = (char *(*)()) F547_2562;
	R1693[2] = (char *(*)()) F548_2562;
	R1693[3] = (char *(*)()) F549_2562;
	R1693[4] = (char *(*)()) F550_2562;
	R1693[5] = (char *(*)()) F551_2562;
	R1693[6] = (char *(*)()) F552_2562;
	R1693[7] = (char *(*)()) F553_2562;
	R1693[8] = (char *(*)()) F554_2562;
	R1693[9] = (char *(*)()) F555_2562;
	R1693[10] = (char *(*)()) F556_2562;
	R1693[11] = (char *(*)()) F557_2562;
}

char *(*R1742[198])();
void R1742_init () {
	R1742[0] = (char *(*)()) F270_2012;
	R1742[1] = (char *(*)()) F271_2012_1742_1;
	R1742[2] = (char *(*)()) F272_2012_1742_1;
	R1742[3] = (char *(*)()) F273_2012;
	R1742[4] = (char *(*)()) F274_2012_1742_1;
	R1742[197] = (char *(*)()) F466_2140_1742_1;
}
static EIF_REFERENCE F271_2012_1742_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F271_2012(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(759, 0x00).id, 759, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F272_2012_1742_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F272_2012(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(690, 0x00).id, 690, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F274_2012_1742_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F274_2012(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(690, 0x00).id, 690, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F466_2140_1742_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F466_2140(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(690, 0x00).id, 690, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R1743[198])();
void R1743_init () {
	R1743[0] = (char *(*)()) F270_2015;
	R1743[1] = (char *(*)()) F271_2015;
	R1743[2] = (char *(*)()) F272_2015;
	R1743[3] = (char *(*)()) F273_2015;
	R1743[4] = (char *(*)()) F274_2015;
	R1743[197] = (char *(*)()) F466_2141;
}

char *(*R1744[198])();
void R1744_init () {
	R1744[0] = (char *(*)()) F270_2016;
	R1744[1] = (char *(*)()) F271_2016;
	R1744[2] = (char *(*)()) F272_2016;
	R1744[3] = (char *(*)()) F273_2016;
	R1744[4] = (char *(*)()) F274_2016;
	R1744[197] = (char *(*)()) F466_2147;
}

char *(*R1755[5])();
void R1755_init () {
	R1755[0] = (char *(*)()) F270_2013;
	R1755[1] = (char *(*)()) F271_2013;
	R1755[2] = (char *(*)()) F272_2013;
	R1755[3] = (char *(*)()) F273_2013_1755_1;
	R1755[4] = (char *(*)()) F274_2013_1755_1;
}
static EIF_REFERENCE F273_2013_1755_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F273_2013(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(690, 0x00).id, 690, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F274_2013_1755_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F274_2013(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(690, 0x00).id, 690, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R1757[8])();
void R1757_init () {
	R1757[0] = (char *(*)()) F647_2906;
	R1757[1] = (char *(*)()) F648_2906;
	R1757[2] = (char *(*)()) F649_2906;
	R1757[3] = (char *(*)()) F650_2906;
	R1757[4] = (char *(*)()) F651_2906;
	R1757[7] = (char *(*)()) F647_2906;
}

static EIF_TYPE_INDEX Y1758_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype12[] = {773,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype13[] = {769,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype14[] = {717,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype87[] = {717,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype88[] = {720,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype123[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype124[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype125[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype126[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype127[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype128[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype129[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype130[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype131[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype132[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype133[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype134[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype135[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype136[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype137[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype138[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype139[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype140[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype141[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype142[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype143[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype144[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype145[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype146[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype147[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype148[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype149[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype150[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype151[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype152[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype153[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype154[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype155[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype156[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype157[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype158[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype159[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype160[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype161[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype162[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype163[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype164[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype165[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype166[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype167[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype168[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype169[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype170[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype171[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype172[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype173[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype174[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype175[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype176[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype177[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype178[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype179[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype180[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype181[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype182[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype183[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype184[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype185[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype186[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype187[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype188[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype189[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype190[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype191[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype192[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype193[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype194[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype195[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype196[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype197[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype198[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype199[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype200[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype201[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype202[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype203[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype204[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype205[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype206[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype207[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype208[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype209[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype210[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype211[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype212[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype213[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype214[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype215[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype216[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype217[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype218[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype219[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype220[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype221[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype222[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype223[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype224[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype225[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype226[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype227[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype228[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype229[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype230[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype231[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype232[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype233[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype234[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype235[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype236[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype237[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype238[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype239[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype240[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype241[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype242[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype243[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype244[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype245[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype246[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype247[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype248[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype249[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype250[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype251[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype252[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype253[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype254[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype255[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype256[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype257[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype258[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype259[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype260[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype261[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype262[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype263[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype264[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype265[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype266[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype267[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype268[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype269[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype270[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype271[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype272[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype273[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype274[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype275[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype276[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype277[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype278[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype279[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype280[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype281[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype282[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype283[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype284[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype285[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype286[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype287[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype288[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype289[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype290[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype291[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype292[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype293[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype294[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype295[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype296[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype297[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype298[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype299[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype300[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype301[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype302[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype303[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype304[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype305[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype306[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype307[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype308[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype309[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype310[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype311[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype312[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype313[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype314[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype315[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype316[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype317[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype318[] = {720,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype319[] = {720,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype320[] = {720,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype321[] = {720,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype322[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype323[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype324[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype325[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype326[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype327[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype328[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype329[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype330[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype331[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype332[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype333[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype334[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype335[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype336[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype337[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype338[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype339[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype340[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype341[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype342[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype343[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype344[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype345[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype346[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype347[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype348[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype349[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype350[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype351[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype352[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype353[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype354[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype355[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype356[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype357[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype358[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype359[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype360[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype361[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype362[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype363[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype364[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype365[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype366[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype367[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype368[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype369[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype370[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype371[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype372[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype373[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype374[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype375[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype376[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype377[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype378[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype379[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype380[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype381[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype382[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype383[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype384[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype385[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype386[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype387[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype388[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype389[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype390[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype391[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype392[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype393[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype394[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype395[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype396[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype397[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype398[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype399[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype400[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype401[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype402[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype403[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype404[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype405[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype406[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype407[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype408[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype409[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype410[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype411[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype412[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype413[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype414[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype415[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype416[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype417[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype418[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype419[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype420[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype421[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype422[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype423[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype424[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype425[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype426[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype427[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype428[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype429[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype430[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype431[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype432[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype433[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype434[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype435[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype436[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype437[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype438[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype439[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype440[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype441[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype442[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype443[] = {717,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype444[] = {717,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype445[] = {717,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype446[] = {720,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype447[] = {720,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype448[] = {720,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype449[] = {720,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype450[] = {720,0xFFFF};
static EIF_TYPE_INDEX Y1758_pgtype451[] = {720,0xFFFF};
EIF_TYPE_INDEX *Y1758_gen_type [566];
EIF_TYPE_INDEX Y1758 [566];
void Y1758_init (void)
{
	egc_routines_types [1758] = Y1758;
	egc_routines_gen_types [1758] = Y1758_gen_type;
	egc_routines_offset [1758] = 211;
	Y1758_gen_type [0] = Y1758_pgtype0;
	Y1758_gen_type [1] = Y1758_pgtype1;
	Y1758_gen_type [2] = Y1758_pgtype2;
	Y1758_gen_type [3] = Y1758_pgtype3;
	Y1758_gen_type [4] = Y1758_pgtype4;
	Y1758_gen_type [5] = Y1758_pgtype5;
	Y1758_gen_type [6] = Y1758_pgtype6;
	Y1758_gen_type [7] = Y1758_pgtype7;
	Y1758_gen_type [8] = Y1758_pgtype8;
	Y1758_gen_type [9] = Y1758_pgtype9;
	Y1758_gen_type [10] = Y1758_pgtype10;
	Y1758_gen_type [11] = Y1758_pgtype11;
	Y1758_gen_type [12] = Y1758_pgtype12;
	Y1758_gen_type [13] = Y1758_pgtype13;
	Y1758_gen_type [14] = Y1758_pgtype14;
	Y1758_gen_type [15] = Y1758_pgtype15;
	Y1758_gen_type [16] = Y1758_pgtype16;
	Y1758_gen_type [17] = Y1758_pgtype17;
	Y1758_gen_type [18] = Y1758_pgtype18;
	Y1758_gen_type [19] = Y1758_pgtype19;
	Y1758_gen_type [20] = Y1758_pgtype20;
	Y1758_gen_type [21] = Y1758_pgtype21;
	Y1758_gen_type [22] = Y1758_pgtype22;
	Y1758_gen_type [23] = Y1758_pgtype23;
	Y1758_gen_type [24] = Y1758_pgtype24;
	Y1758_gen_type [25] = Y1758_pgtype25;
	Y1758_gen_type [26] = Y1758_pgtype26;
	Y1758_gen_type [27] = Y1758_pgtype27;
	Y1758_gen_type [28] = Y1758_pgtype28;
	Y1758_gen_type [29] = Y1758_pgtype29;
	Y1758_gen_type [30] = Y1758_pgtype30;
	Y1758_gen_type [31] = Y1758_pgtype31;
	Y1758_gen_type [32] = Y1758_pgtype32;
	Y1758_gen_type [33] = Y1758_pgtype33;
	Y1758_gen_type [34] = Y1758_pgtype34;
	Y1758_gen_type [35] = Y1758_pgtype35;
	Y1758_gen_type [36] = Y1758_pgtype36;
	Y1758_gen_type [37] = Y1758_pgtype37;
	Y1758_gen_type [38] = Y1758_pgtype38;
	Y1758_gen_type [39] = Y1758_pgtype39;
	Y1758_gen_type [40] = Y1758_pgtype40;
	Y1758_gen_type [41] = Y1758_pgtype41;
	Y1758_gen_type [42] = Y1758_pgtype42;
	Y1758_gen_type [43] = Y1758_pgtype43;
	Y1758_gen_type [44] = Y1758_pgtype44;
	Y1758_gen_type [45] = Y1758_pgtype45;
	Y1758_gen_type [46] = Y1758_pgtype46;
	Y1758_gen_type [47] = Y1758_pgtype47;
	Y1758_gen_type [48] = Y1758_pgtype48;
	Y1758_gen_type [49] = Y1758_pgtype49;
	Y1758_gen_type [50] = Y1758_pgtype50;
	Y1758_gen_type [51] = Y1758_pgtype51;
	Y1758_gen_type [52] = Y1758_pgtype52;
	Y1758_gen_type [53] = Y1758_pgtype53;
	Y1758_gen_type [54] = Y1758_pgtype54;
	Y1758_gen_type [55] = Y1758_pgtype55;
	Y1758_gen_type [56] = Y1758_pgtype56;
	Y1758_gen_type [57] = Y1758_pgtype57;
	Y1758_gen_type [58] = Y1758_pgtype58;
	Y1758_gen_type [59] = Y1758_pgtype59;
	Y1758_gen_type [60] = Y1758_pgtype60;
	Y1758_gen_type [61] = Y1758_pgtype61;
	Y1758_gen_type [62] = Y1758_pgtype62;
	Y1758_gen_type [63] = Y1758_pgtype63;
	Y1758_gen_type [64] = Y1758_pgtype64;
	Y1758_gen_type [65] = Y1758_pgtype65;
	Y1758_gen_type [66] = Y1758_pgtype66;
	Y1758_gen_type [67] = Y1758_pgtype67;
	Y1758_gen_type [68] = Y1758_pgtype68;
	Y1758_gen_type [69] = Y1758_pgtype69;
	Y1758_gen_type [70] = Y1758_pgtype70;
	Y1758_gen_type [71] = Y1758_pgtype71;
	Y1758_gen_type [72] = Y1758_pgtype72;
	Y1758_gen_type [73] = Y1758_pgtype73;
	Y1758_gen_type [74] = Y1758_pgtype74;
	Y1758_gen_type [75] = Y1758_pgtype75;
	Y1758_gen_type [76] = Y1758_pgtype76;
	Y1758_gen_type [77] = Y1758_pgtype77;
	Y1758_gen_type [78] = Y1758_pgtype78;
	Y1758_gen_type [79] = Y1758_pgtype79;
	Y1758_gen_type [80] = Y1758_pgtype80;
	Y1758_gen_type [81] = Y1758_pgtype81;
	Y1758_gen_type [82] = Y1758_pgtype82;
	Y1758_gen_type [83] = Y1758_pgtype83;
	Y1758_gen_type [84] = Y1758_pgtype84;
	Y1758_gen_type [85] = Y1758_pgtype85;
	Y1758_gen_type [86] = Y1758_pgtype86;
	Y1758_gen_type [87] = Y1758_pgtype87;
	Y1758_gen_type [88] = Y1758_pgtype88;
	Y1758_gen_type [89] = Y1758_pgtype89;
	Y1758_gen_type [90] = Y1758_pgtype90;
	Y1758_gen_type [91] = Y1758_pgtype91;
	Y1758_gen_type [92] = Y1758_pgtype92;
	Y1758_gen_type [93] = Y1758_pgtype93;
	Y1758_gen_type [94] = Y1758_pgtype94;
	Y1758_gen_type [95] = Y1758_pgtype95;
	Y1758_gen_type [96] = Y1758_pgtype96;
	Y1758_gen_type [97] = Y1758_pgtype97;
	Y1758_gen_type [98] = Y1758_pgtype98;
	Y1758_gen_type [99] = Y1758_pgtype99;
	Y1758_gen_type [100] = Y1758_pgtype100;
	Y1758_gen_type [101] = Y1758_pgtype101;
	Y1758_gen_type [102] = Y1758_pgtype102;
	Y1758_gen_type [103] = Y1758_pgtype103;
	Y1758_gen_type [104] = Y1758_pgtype104;
	Y1758_gen_type [105] = Y1758_pgtype105;
	Y1758_gen_type [106] = Y1758_pgtype106;
	Y1758_gen_type [107] = Y1758_pgtype107;
	Y1758_gen_type [108] = Y1758_pgtype108;
	Y1758_gen_type [109] = Y1758_pgtype109;
	Y1758_gen_type [110] = Y1758_pgtype110;
	Y1758_gen_type [111] = Y1758_pgtype111;
	Y1758_gen_type [112] = Y1758_pgtype112;
	Y1758_gen_type [113] = Y1758_pgtype113;
	Y1758_gen_type [114] = Y1758_pgtype114;
	Y1758_gen_type [115] = Y1758_pgtype115;
	Y1758_gen_type [116] = Y1758_pgtype116;
	Y1758_gen_type [117] = Y1758_pgtype117;
	Y1758_gen_type [118] = Y1758_pgtype118;
	Y1758_gen_type [119] = Y1758_pgtype119;
	Y1758_gen_type [120] = Y1758_pgtype120;
	Y1758_gen_type [121] = Y1758_pgtype121;
	Y1758_gen_type [122] = Y1758_pgtype122;
	Y1758_gen_type [123] = Y1758_pgtype123;
	Y1758_gen_type [124] = Y1758_pgtype124;
	Y1758_gen_type [125] = Y1758_pgtype125;
	Y1758_gen_type [126] = Y1758_pgtype126;
	Y1758_gen_type [127] = Y1758_pgtype127;
	Y1758_gen_type [128] = Y1758_pgtype128;
	Y1758_gen_type [129] = Y1758_pgtype129;
	Y1758_gen_type [130] = Y1758_pgtype130;
	Y1758_gen_type [131] = Y1758_pgtype131;
	Y1758_gen_type [132] = Y1758_pgtype132;
	Y1758_gen_type [133] = Y1758_pgtype133;
	Y1758_gen_type [134] = Y1758_pgtype134;
	Y1758_gen_type [135] = Y1758_pgtype135;
	Y1758_gen_type [136] = Y1758_pgtype136;
	Y1758_gen_type [137] = Y1758_pgtype137;
	Y1758_gen_type [138] = Y1758_pgtype138;
	Y1758_gen_type [139] = Y1758_pgtype139;
	Y1758_gen_type [140] = Y1758_pgtype140;
	Y1758_gen_type [141] = Y1758_pgtype141;
	Y1758_gen_type [142] = Y1758_pgtype142;
	Y1758_gen_type [143] = Y1758_pgtype143;
	Y1758_gen_type [144] = Y1758_pgtype144;
	Y1758_gen_type [145] = Y1758_pgtype145;
	Y1758_gen_type [146] = Y1758_pgtype146;
	Y1758_gen_type [147] = Y1758_pgtype147;
	Y1758_gen_type [148] = Y1758_pgtype148;
	Y1758_gen_type [149] = Y1758_pgtype149;
	Y1758_gen_type [150] = Y1758_pgtype150;
	Y1758_gen_type [151] = Y1758_pgtype151;
	Y1758_gen_type [152] = Y1758_pgtype152;
	Y1758_gen_type [153] = Y1758_pgtype153;
	Y1758_gen_type [154] = Y1758_pgtype154;
	Y1758_gen_type [155] = Y1758_pgtype155;
	Y1758_gen_type [156] = Y1758_pgtype156;
	Y1758_gen_type [157] = Y1758_pgtype157;
	Y1758_gen_type [158] = Y1758_pgtype158;
	Y1758_gen_type [159] = Y1758_pgtype159;
	Y1758_gen_type [160] = Y1758_pgtype160;
	Y1758_gen_type [161] = Y1758_pgtype161;
	Y1758_gen_type [162] = Y1758_pgtype162;
	Y1758_gen_type [163] = Y1758_pgtype163;
	Y1758_gen_type [164] = Y1758_pgtype164;
	Y1758_gen_type [165] = Y1758_pgtype165;
	Y1758_gen_type [166] = Y1758_pgtype166;
	Y1758_gen_type [167] = Y1758_pgtype167;
	Y1758_gen_type [168] = Y1758_pgtype168;
	Y1758_gen_type [169] = Y1758_pgtype169;
	Y1758_gen_type [170] = Y1758_pgtype170;
	Y1758_gen_type [171] = Y1758_pgtype171;
	Y1758_gen_type [172] = Y1758_pgtype172;
	Y1758_gen_type [173] = Y1758_pgtype173;
	Y1758_gen_type [174] = Y1758_pgtype174;
	Y1758_gen_type [175] = Y1758_pgtype175;
	Y1758_gen_type [176] = Y1758_pgtype176;
	Y1758_gen_type [177] = Y1758_pgtype177;
	Y1758_gen_type [178] = Y1758_pgtype178;
	Y1758_gen_type [179] = Y1758_pgtype179;
	Y1758_gen_type [180] = Y1758_pgtype180;
	Y1758_gen_type [181] = Y1758_pgtype181;
	Y1758_gen_type [182] = Y1758_pgtype182;
	Y1758_gen_type [183] = Y1758_pgtype183;
	Y1758_gen_type [184] = Y1758_pgtype184;
	Y1758_gen_type [185] = Y1758_pgtype185;
	Y1758_gen_type [186] = Y1758_pgtype186;
	Y1758_gen_type [187] = Y1758_pgtype187;
	Y1758_gen_type [188] = Y1758_pgtype188;
	Y1758_gen_type [189] = Y1758_pgtype189;
	Y1758_gen_type [190] = Y1758_pgtype190;
	Y1758_gen_type [191] = Y1758_pgtype191;
	Y1758_gen_type [192] = Y1758_pgtype192;
	Y1758_gen_type [193] = Y1758_pgtype193;
	Y1758_gen_type [194] = Y1758_pgtype194;
	Y1758_gen_type [195] = Y1758_pgtype195;
	Y1758_gen_type [196] = Y1758_pgtype196;
	Y1758_gen_type [197] = Y1758_pgtype197;
	Y1758_gen_type [198] = Y1758_pgtype198;
	Y1758_gen_type [199] = Y1758_pgtype199;
	Y1758_gen_type [200] = Y1758_pgtype200;
	Y1758_gen_type [201] = Y1758_pgtype201;
	Y1758_gen_type [202] = Y1758_pgtype202;
	Y1758_gen_type [203] = Y1758_pgtype203;
	Y1758_gen_type [204] = Y1758_pgtype204;
	Y1758_gen_type [205] = Y1758_pgtype205;
	Y1758_gen_type [206] = Y1758_pgtype206;
	Y1758_gen_type [207] = Y1758_pgtype207;
	Y1758_gen_type [208] = Y1758_pgtype208;
	Y1758_gen_type [209] = Y1758_pgtype209;
	Y1758_gen_type [210] = Y1758_pgtype210;
	Y1758_gen_type [211] = Y1758_pgtype211;
	Y1758_gen_type [212] = Y1758_pgtype212;
	Y1758_gen_type [213] = Y1758_pgtype213;
	Y1758_gen_type [214] = Y1758_pgtype214;
	Y1758_gen_type [215] = Y1758_pgtype215;
	Y1758_gen_type [216] = Y1758_pgtype216;
	Y1758_gen_type [217] = Y1758_pgtype217;
	Y1758_gen_type [218] = Y1758_pgtype218;
	Y1758_gen_type [219] = Y1758_pgtype219;
	Y1758_gen_type [220] = Y1758_pgtype220;
	Y1758_gen_type [221] = Y1758_pgtype221;
	Y1758_gen_type [222] = Y1758_pgtype222;
	Y1758_gen_type [223] = Y1758_pgtype223;
	Y1758_gen_type [224] = Y1758_pgtype224;
	Y1758_gen_type [225] = Y1758_pgtype225;
	Y1758_gen_type [226] = Y1758_pgtype226;
	Y1758_gen_type [227] = Y1758_pgtype227;
	Y1758_gen_type [228] = Y1758_pgtype228;
	Y1758_gen_type [229] = Y1758_pgtype229;
	Y1758_gen_type [230] = Y1758_pgtype230;
	Y1758_gen_type [231] = Y1758_pgtype231;
	Y1758_gen_type [232] = Y1758_pgtype232;
	Y1758_gen_type [233] = Y1758_pgtype233;
	Y1758_gen_type [234] = Y1758_pgtype234;
	Y1758_gen_type [235] = Y1758_pgtype235;
	Y1758_gen_type [236] = Y1758_pgtype236;
	Y1758_gen_type [237] = Y1758_pgtype237;
	Y1758_gen_type [238] = Y1758_pgtype238;
	Y1758_gen_type [239] = Y1758_pgtype239;
	Y1758_gen_type [240] = Y1758_pgtype240;
	Y1758_gen_type [241] = Y1758_pgtype241;
	Y1758_gen_type [242] = Y1758_pgtype242;
	Y1758_gen_type [243] = Y1758_pgtype243;
	Y1758_gen_type [244] = Y1758_pgtype244;
	Y1758_gen_type [245] = Y1758_pgtype245;
	Y1758_gen_type [246] = Y1758_pgtype246;
	Y1758_gen_type [247] = Y1758_pgtype247;
	Y1758_gen_type [248] = Y1758_pgtype248;
	Y1758_gen_type [249] = Y1758_pgtype249;
	Y1758_gen_type [250] = Y1758_pgtype250;
	Y1758_gen_type [251] = Y1758_pgtype251;
	Y1758_gen_type [252] = Y1758_pgtype252;
	Y1758_gen_type [253] = Y1758_pgtype253;
	Y1758_gen_type [254] = Y1758_pgtype254;
	Y1758_gen_type [255] = Y1758_pgtype255;
	Y1758_gen_type [256] = Y1758_pgtype256;
	Y1758_gen_type [257] = Y1758_pgtype257;
	Y1758_gen_type [258] = Y1758_pgtype258;
	Y1758_gen_type [259] = Y1758_pgtype259;
	Y1758_gen_type [260] = Y1758_pgtype260;
	Y1758_gen_type [261] = Y1758_pgtype261;
	Y1758_gen_type [262] = Y1758_pgtype262;
	Y1758_gen_type [263] = Y1758_pgtype263;
	Y1758_gen_type [264] = Y1758_pgtype264;
	Y1758_gen_type [265] = Y1758_pgtype265;
	Y1758_gen_type [266] = Y1758_pgtype266;
	Y1758_gen_type [267] = Y1758_pgtype267;
	Y1758_gen_type [268] = Y1758_pgtype268;
	Y1758_gen_type [269] = Y1758_pgtype269;
	Y1758_gen_type [270] = Y1758_pgtype270;
	Y1758_gen_type [271] = Y1758_pgtype271;
	Y1758_gen_type [272] = Y1758_pgtype272;
	Y1758_gen_type [273] = Y1758_pgtype273;
	Y1758_gen_type [274] = Y1758_pgtype274;
	Y1758_gen_type [275] = Y1758_pgtype275;
	Y1758_gen_type [276] = Y1758_pgtype276;
	Y1758_gen_type [277] = Y1758_pgtype277;
	Y1758_gen_type [278] = Y1758_pgtype278;
	Y1758_gen_type [279] = Y1758_pgtype279;
	Y1758_gen_type [280] = Y1758_pgtype280;
	Y1758_gen_type [281] = Y1758_pgtype281;
	Y1758_gen_type [282] = Y1758_pgtype282;
	Y1758_gen_type [283] = Y1758_pgtype283;
	Y1758_gen_type [284] = Y1758_pgtype284;
	Y1758_gen_type [285] = Y1758_pgtype285;
	Y1758_gen_type [286] = Y1758_pgtype286;
	Y1758_gen_type [287] = Y1758_pgtype287;
	Y1758_gen_type [288] = Y1758_pgtype288;
	Y1758_gen_type [289] = Y1758_pgtype289;
	Y1758_gen_type [290] = Y1758_pgtype290;
	Y1758_gen_type [291] = Y1758_pgtype291;
	Y1758_gen_type [292] = Y1758_pgtype292;
	Y1758_gen_type [293] = Y1758_pgtype293;
	Y1758_gen_type [294] = Y1758_pgtype294;
	Y1758_gen_type [295] = Y1758_pgtype295;
	Y1758_gen_type [296] = Y1758_pgtype296;
	Y1758_gen_type [297] = Y1758_pgtype297;
	Y1758_gen_type [298] = Y1758_pgtype298;
	Y1758_gen_type [299] = Y1758_pgtype299;
	Y1758_gen_type [300] = Y1758_pgtype300;
	Y1758_gen_type [301] = Y1758_pgtype301;
	Y1758_gen_type [302] = Y1758_pgtype302;
	Y1758_gen_type [303] = Y1758_pgtype303;
	Y1758_gen_type [304] = Y1758_pgtype304;
	Y1758_gen_type [305] = Y1758_pgtype305;
	Y1758_gen_type [306] = Y1758_pgtype306;
	Y1758_gen_type [307] = Y1758_pgtype307;
	Y1758_gen_type [308] = Y1758_pgtype308;
	Y1758_gen_type [309] = Y1758_pgtype309;
	Y1758_gen_type [310] = Y1758_pgtype310;
	Y1758_gen_type [311] = Y1758_pgtype311;
	Y1758_gen_type [312] = Y1758_pgtype312;
	Y1758_gen_type [313] = Y1758_pgtype313;
	Y1758_gen_type [314] = Y1758_pgtype314;
	Y1758_gen_type [315] = Y1758_pgtype315;
	Y1758_gen_type [316] = Y1758_pgtype316;
	Y1758_gen_type [317] = Y1758_pgtype317;
	Y1758_gen_type [318] = Y1758_pgtype318;
	Y1758_gen_type [319] = Y1758_pgtype319;
	Y1758_gen_type [320] = Y1758_pgtype320;
	Y1758_gen_type [321] = Y1758_pgtype321;
	Y1758_gen_type [322] = Y1758_pgtype322;
	Y1758_gen_type [323] = Y1758_pgtype323;
	Y1758_gen_type [324] = Y1758_pgtype324;
	Y1758_gen_type [325] = Y1758_pgtype325;
	Y1758_gen_type [326] = Y1758_pgtype326;
	Y1758_gen_type [327] = Y1758_pgtype327;
	Y1758_gen_type [328] = Y1758_pgtype328;
	Y1758_gen_type [329] = Y1758_pgtype329;
	Y1758_gen_type [330] = Y1758_pgtype330;
	Y1758_gen_type [331] = Y1758_pgtype331;
	Y1758_gen_type [332] = Y1758_pgtype332;
	Y1758_gen_type [333] = Y1758_pgtype333;
	Y1758_gen_type [334] = Y1758_pgtype334;
	Y1758_gen_type [335] = Y1758_pgtype335;
	Y1758_gen_type [336] = Y1758_pgtype336;
	Y1758_gen_type [337] = Y1758_pgtype337;
	Y1758_gen_type [338] = Y1758_pgtype338;
	Y1758_gen_type [339] = Y1758_pgtype339;
	Y1758_gen_type [340] = Y1758_pgtype340;
	Y1758_gen_type [341] = Y1758_pgtype341;
	Y1758_gen_type [342] = Y1758_pgtype342;
	Y1758_gen_type [343] = Y1758_pgtype343;
	Y1758_gen_type [344] = Y1758_pgtype344;
	Y1758_gen_type [345] = Y1758_pgtype345;
	Y1758_gen_type [346] = Y1758_pgtype346;
	Y1758_gen_type [347] = Y1758_pgtype347;
	Y1758_gen_type [348] = Y1758_pgtype348;
	Y1758_gen_type [349] = Y1758_pgtype349;
	Y1758_gen_type [350] = Y1758_pgtype350;
	Y1758_gen_type [351] = Y1758_pgtype351;
	Y1758_gen_type [352] = Y1758_pgtype352;
	Y1758_gen_type [353] = Y1758_pgtype353;
	Y1758_gen_type [354] = Y1758_pgtype354;
	Y1758_gen_type [355] = Y1758_pgtype355;
	Y1758_gen_type [356] = Y1758_pgtype356;
	Y1758_gen_type [357] = Y1758_pgtype357;
	Y1758_gen_type [358] = Y1758_pgtype358;
	Y1758_gen_type [359] = Y1758_pgtype359;
	Y1758_gen_type [360] = Y1758_pgtype360;
	Y1758_gen_type [361] = Y1758_pgtype361;
	Y1758_gen_type [362] = Y1758_pgtype362;
	Y1758_gen_type [363] = Y1758_pgtype363;
	Y1758_gen_type [364] = Y1758_pgtype364;
	Y1758_gen_type [365] = Y1758_pgtype365;
	Y1758_gen_type [366] = Y1758_pgtype366;
	Y1758_gen_type [367] = Y1758_pgtype367;
	Y1758_gen_type [368] = Y1758_pgtype368;
	Y1758_gen_type [369] = Y1758_pgtype369;
	Y1758_gen_type [370] = Y1758_pgtype370;
	Y1758_gen_type [371] = Y1758_pgtype371;
	Y1758_gen_type [372] = Y1758_pgtype372;
	Y1758_gen_type [373] = Y1758_pgtype373;
	Y1758_gen_type [374] = Y1758_pgtype374;
	Y1758_gen_type [375] = Y1758_pgtype375;
	Y1758_gen_type [376] = Y1758_pgtype376;
	Y1758_gen_type [377] = Y1758_pgtype377;
	Y1758_gen_type [378] = Y1758_pgtype378;
	Y1758_gen_type [379] = Y1758_pgtype379;
	Y1758_gen_type [380] = Y1758_pgtype380;
	Y1758_gen_type [381] = Y1758_pgtype381;
	Y1758_gen_type [382] = Y1758_pgtype382;
	Y1758_gen_type [383] = Y1758_pgtype383;
	Y1758_gen_type [384] = Y1758_pgtype384;
	Y1758_gen_type [385] = Y1758_pgtype385;
	Y1758_gen_type [386] = Y1758_pgtype386;
	Y1758_gen_type [387] = Y1758_pgtype387;
	Y1758_gen_type [388] = Y1758_pgtype388;
	Y1758_gen_type [389] = Y1758_pgtype389;
	Y1758_gen_type [390] = Y1758_pgtype390;
	Y1758_gen_type [391] = Y1758_pgtype391;
	Y1758_gen_type [392] = Y1758_pgtype392;
	Y1758_gen_type [393] = Y1758_pgtype393;
	Y1758_gen_type [394] = Y1758_pgtype394;
	Y1758_gen_type [395] = Y1758_pgtype395;
	Y1758_gen_type [396] = Y1758_pgtype396;
	Y1758_gen_type [397] = Y1758_pgtype397;
	Y1758_gen_type [398] = Y1758_pgtype398;
	Y1758_gen_type [399] = Y1758_pgtype399;
	Y1758_gen_type [400] = Y1758_pgtype400;
	Y1758_gen_type [401] = Y1758_pgtype401;
	Y1758_gen_type [402] = Y1758_pgtype402;
	Y1758_gen_type [403] = Y1758_pgtype403;
	Y1758_gen_type [404] = Y1758_pgtype404;
	Y1758_gen_type [405] = Y1758_pgtype405;
	Y1758_gen_type [406] = Y1758_pgtype406;
	Y1758_gen_type [407] = Y1758_pgtype407;
	Y1758_gen_type [408] = Y1758_pgtype408;
	Y1758_gen_type [409] = Y1758_pgtype409;
	Y1758_gen_type [410] = Y1758_pgtype410;
	Y1758_gen_type [411] = Y1758_pgtype411;
	Y1758_gen_type [412] = Y1758_pgtype412;
	Y1758_gen_type [413] = Y1758_pgtype413;
	Y1758_gen_type [414] = Y1758_pgtype414;
	Y1758_gen_type [415] = Y1758_pgtype415;
	Y1758_gen_type [416] = Y1758_pgtype416;
	Y1758_gen_type [417] = Y1758_pgtype417;
	Y1758_gen_type [418] = Y1758_pgtype418;
	Y1758_gen_type [419] = Y1758_pgtype419;
	Y1758_gen_type [420] = Y1758_pgtype420;
	Y1758_gen_type [422] = Y1758_pgtype421;
	Y1758_gen_type [423] = Y1758_pgtype422;
	Y1758_gen_type [424] = Y1758_pgtype423;
	Y1758_gen_type [425] = Y1758_pgtype424;
	Y1758_gen_type [426] = Y1758_pgtype425;
	Y1758_gen_type [427] = Y1758_pgtype426;
	Y1758_gen_type [428] = Y1758_pgtype427;
	Y1758_gen_type [429] = Y1758_pgtype428;
	Y1758_gen_type [430] = Y1758_pgtype429;
	Y1758_gen_type [431] = Y1758_pgtype430;
	Y1758_gen_type [432] = Y1758_pgtype431;
	Y1758_gen_type [433] = Y1758_pgtype432;
	Y1758_gen_type [434] = Y1758_pgtype433;
	Y1758_gen_type [435] = Y1758_pgtype434;
	Y1758_gen_type [436] = Y1758_pgtype435;
	Y1758_gen_type [437] = Y1758_pgtype436;
	Y1758_gen_type [438] = Y1758_pgtype437;
	Y1758_gen_type [439] = Y1758_pgtype438;
	Y1758_gen_type [440] = Y1758_pgtype439;
	Y1758_gen_type [441] = Y1758_pgtype440;
	Y1758_gen_type [442] = Y1758_pgtype441;
	Y1758_gen_type [476] = Y1758_pgtype442;
	Y1758_gen_type [557] = Y1758_pgtype443;
	Y1758_gen_type [558] = Y1758_pgtype444;
	Y1758_gen_type [559] = Y1758_pgtype445;
	Y1758_gen_type [560] = Y1758_pgtype446;
	Y1758_gen_type [561] = Y1758_pgtype447;
	Y1758_gen_type [562] = Y1758_pgtype448;
	Y1758_gen_type [563] = Y1758_pgtype449;
	Y1758_gen_type [564] = Y1758_pgtype450;
	Y1758_gen_type [565] = Y1758_pgtype451;
	Y1758[12] = 773;
	Y1758[13] = 769;
	Y1758[14] = 717;
	Y1758[87] = 717;
	Y1758[88] = 720;
	Y1758[255] = 690;
	{long i; for (i = 318; i < 322; i++) Y1758[i] = 720;};
	Y1758[358] = 690;
	Y1758[442] = 0;
	Y1758[476] = 0;
	{long i; for (i = 557; i < 560; i++) Y1758[i] = 717;};
	{long i; for (i = 560; i < 566; i++) Y1758[i] = 720;};
}

char *(*R1820[5])();
void R1820_init () {
	R1820[0] = (char *(*)()) F256_1998;
	R1820[1] = (char *(*)()) F262_1998;
	R1820[2] = (char *(*)()) F258_1998;
	R1820[3] = (char *(*)()) F256_1998;
	R1820[4] = (char *(*)()) F258_1998;
}

char *(*R1823[5])();
void R1823_init () {
	R1823[0] = (char *(*)()) F256_2003;
	R1823[1] = (char *(*)()) F262_2003;
	R1823[2] = (char *(*)()) F258_2003;
	R1823[3] = (char *(*)()) F256_2003;
	R1823[4] = (char *(*)()) F258_2003;
}

char *(*R1826[5])();
void R1826_init () {
	R1826[0] = (char *(*)()) F256_1984;
	R1826[1] = (char *(*)()) F262_1984;
	R1826[2] = (char *(*)()) F258_1984;
	R1826[3] = (char *(*)()) F256_1984;
	R1826[4] = (char *(*)()) F258_1984;
}

char *(*R1854[311])();
void R1854_init () {
	R1854[0] = (char *(*)()) F464_2136;
	{long i; for (i = 64; i < 67; i++) R1854[i] = (char *(*)()) F471_2169;}
	R1854[104] = (char *(*)()) F468_2169;
	R1854[105] = (char *(*)()) F469_2169;
	R1854[106] = (char *(*)()) F471_2169;
	R1854[107] = (char *(*)()) F472_2169;
	R1854[108] = (char *(*)()) F473_2169;
	R1854[109] = (char *(*)()) F474_2169;
	R1854[110] = (char *(*)()) F475_2169;
	R1854[111] = (char *(*)()) F476_2169;
	R1854[112] = (char *(*)()) F477_2169;
	R1854[113] = (char *(*)()) F478_2169;
	R1854[114] = (char *(*)()) F479_2169;
	R1854[115] = (char *(*)()) F470_2169;
	R1854[168] = (char *(*)()) F468_2169;
	R1854[169] = (char *(*)()) F469_2169;
	R1854[170] = (char *(*)()) F471_2169;
	R1854[171] = (char *(*)()) F472_2169;
	R1854[172] = (char *(*)()) F473_2169;
	R1854[173] = (char *(*)()) F474_2169;
	R1854[174] = (char *(*)()) F475_2169;
	R1854[175] = (char *(*)()) F476_2169;
	R1854[176] = (char *(*)()) F477_2169;
	R1854[177] = (char *(*)()) F478_2169;
	R1854[178] = (char *(*)()) F479_2169;
	R1854[179] = (char *(*)()) F470_2169;
	R1854[180] = (char *(*)()) F468_2169;
	R1854[181] = (char *(*)()) F474_2169;
	R1854[182] = (char *(*)()) F470_2169;
	R1854[183] = (char *(*)()) F468_2169;
	R1854[184] = (char *(*)()) F470_2169;
	R1854[187] = (char *(*)()) F468_2169;
	R1854[304] = (char *(*)()) F469_2169;
	R1854[307] = (char *(*)()) F471_2169;
	R1854[309] = (char *(*)()) F471_2169;
	R1854[310] = (char *(*)()) F777_4880;
}

char *(*R1858[311])();
void R1858_init () {
	R1858[0] = (char *(*)()) F327_2071;
	{long i; for (i = 64; i < 67; i++) R1858[i] = (char *(*)()) F328_2071;}
	R1858[104] = (char *(*)()) F325_2071;
	R1858[105] = (char *(*)()) F326_2071;
	R1858[106] = (char *(*)()) F328_2071;
	R1858[107] = (char *(*)()) F329_2071;
	R1858[108] = (char *(*)()) F330_2071;
	R1858[109] = (char *(*)()) F331_2071;
	R1858[110] = (char *(*)()) F332_2071;
	R1858[111] = (char *(*)()) F333_2071;
	R1858[112] = (char *(*)()) F334_2071;
	R1858[113] = (char *(*)()) F335_2071;
	R1858[114] = (char *(*)()) F336_2071;
	R1858[115] = (char *(*)()) F327_2071;
	R1858[168] = (char *(*)()) F325_2071;
	R1858[169] = (char *(*)()) F326_2071;
	R1858[170] = (char *(*)()) F328_2071;
	R1858[171] = (char *(*)()) F329_2071;
	R1858[172] = (char *(*)()) F330_2071;
	R1858[173] = (char *(*)()) F331_2071;
	R1858[174] = (char *(*)()) F332_2071;
	R1858[175] = (char *(*)()) F333_2071;
	R1858[176] = (char *(*)()) F334_2071;
	R1858[177] = (char *(*)()) F335_2071;
	R1858[178] = (char *(*)()) F336_2071;
	R1858[179] = (char *(*)()) F327_2071;
	R1858[180] = (char *(*)()) F325_2071;
	R1858[181] = (char *(*)()) F331_2071;
	R1858[182] = (char *(*)()) F327_2071;
	R1858[183] = (char *(*)()) F325_2071;
	R1858[184] = (char *(*)()) F327_2071;
	R1858[187] = (char *(*)()) F325_2071;
	R1858[304] = (char *(*)()) F326_2071;
	R1858[307] = (char *(*)()) F328_2071;
	{long i; for (i = 309; i < 311; i++) R1858[i] = (char *(*)()) F328_2071;}
}

char *(*R1871[180])();
void R1871_init () {
	R1871[0] = (char *(*)()) F466_2139;
	R1871[168] = (char *(*)()) F635_2835;
	R1871[169] = (char *(*)()) F636_2835;
	R1871[170] = (char *(*)()) F637_2835;
	R1871[171] = (char *(*)()) F638_2835;
	R1871[172] = (char *(*)()) F639_2835;
	R1871[173] = (char *(*)()) F640_2835;
	R1871[174] = (char *(*)()) F641_2835;
	R1871[175] = (char *(*)()) F642_2835;
	R1871[176] = (char *(*)()) F643_2835;
	R1871[177] = (char *(*)()) F644_2835;
	R1871[178] = (char *(*)()) F645_2835;
	R1871[179] = (char *(*)()) F646_2835;
}

char *(*R1875[311])();
void R1875_init () {
	R1875[0] = (char *(*)()) F466_2141;
	{long i; for (i = 64; i < 67; i++) R1875[i] = (char *(*)()) F530_2226;}
	R1875[168] = (char *(*)()) F607_2734;
	R1875[169] = (char *(*)()) F609_2734;
	R1875[170] = (char *(*)()) F610_2734;
	R1875[171] = (char *(*)()) F611_2734;
	R1875[172] = (char *(*)()) F612_2734;
	R1875[173] = (char *(*)()) F613_2734;
	R1875[174] = (char *(*)()) F614_2734;
	R1875[175] = (char *(*)()) F615_2734;
	R1875[176] = (char *(*)()) F616_2734;
	R1875[177] = (char *(*)()) F617_2734;
	R1875[178] = (char *(*)()) F618_2734;
	R1875[179] = (char *(*)()) F608_2734;
	R1875[310] = (char *(*)()) F530_2226;
}

char *(*R1879[247])();
void R1879_init () {
	{long i; for (i = 0; i < 3; i++) R1879[i] = (char *(*)()) F530_2286;}
	R1879[246] = (char *(*)()) F777_4850;
}

char *(*R1891[201])();
void R1891_init () {
	R1891[0] = (char *(*)()) F571_2642_1891_5;
	R1891[1] = (char *(*)()) F572_2642_1891_5;
	R1891[2] = (char *(*)()) F573_2642_1891_5;
	R1891[3] = (char *(*)()) F574_2642_1891_5;
	R1891[4] = (char *(*)()) F575_2642_1891_5;
	R1891[5] = (char *(*)()) F576_2642_1891_5;
	R1891[6] = (char *(*)()) F577_2642_1891_5;
	R1891[7] = (char *(*)()) F578_2642_1891_5;
	R1891[8] = (char *(*)()) F579_2642_1891_5;
	R1891[9] = (char *(*)()) F580_2642_1891_5;
	R1891[10] = (char *(*)()) F581_2642_1891_5;
	R1891[11] = (char *(*)()) F582_2642_1891_5;
	R1891[64] = (char *(*)()) F635_2831_1891_5;
	R1891[65] = (char *(*)()) F636_2831_1891_5;
	R1891[66] = (char *(*)()) F637_2831_1891_5;
	R1891[67] = (char *(*)()) F638_2831_1891_5;
	R1891[68] = (char *(*)()) F639_2831_1891_5;
	R1891[69] = (char *(*)()) F640_2831_1891_5;
	R1891[70] = (char *(*)()) F641_2831_1891_5;
	R1891[71] = (char *(*)()) F642_2831_1891_5;
	R1891[72] = (char *(*)()) F643_2831_1891_5;
	R1891[73] = (char *(*)()) F644_2831_1891_5;
	R1891[74] = (char *(*)()) F645_2831_1891_5;
	R1891[75] = (char *(*)()) F646_2831_1891_5;
	R1891[200] = (char *(*)()) F771_4561_1891_5;
}
static EIF_REFERENCE F571_2642_1891_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F571_2642(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F572_2642_1891_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F572_2642(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(717, 0x00).id, 717, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F573_2642_1891_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F573_2642(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(720, 0x00).id, 720, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F574_2642_1891_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F574_2642(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(708, 0x00).id, 708, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F575_2642_1891_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F575_2642(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(705, 0x00).id, 705, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F576_2642_1891_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F576_2642(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(759, 0x00).id, 759, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F577_2642_1891_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F577_2642(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(711, 0x00).id, 711, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F578_2642_1891_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F578_2642(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(714, 0x00).id, 714, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F579_2642_1891_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F579_2642(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(702, 0x00).id, 702, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F580_2642_1891_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F580_2642(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(723, 0x00).id, 723, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F581_2642_1891_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F581_2642(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(699, 0x00).id, 699, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F582_2642_1891_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F582_2642(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(690, 0x00).id, 690, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F635_2831_1891_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F635_2831(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F636_2831_1891_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F636_2831(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(717, 0x00).id, 717, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F637_2831_1891_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F637_2831(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(720, 0x00).id, 720, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F638_2831_1891_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F638_2831(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(708, 0x00).id, 708, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F639_2831_1891_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F639_2831(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(705, 0x00).id, 705, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F640_2831_1891_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F640_2831(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(759, 0x00).id, 759, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F641_2831_1891_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F641_2831(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(711, 0x00).id, 711, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F642_2831_1891_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F642_2831(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(714, 0x00).id, 714, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F643_2831_1891_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F643_2831(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(702, 0x00).id, 702, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F644_2831_1891_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F644_2831(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(723, 0x00).id, 723, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F645_2831_1891_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F645_2831(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(699, 0x00).id, 699, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F646_2831_1891_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F646_2831(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(690, 0x00).id, 690, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F771_4561_1891_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F771_4561(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(717, 0x00).id, 717, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}

char *(*R1894[206])();
void R1894_init () {
	R1894[0] = (char *(*)()) F571_2661_1894_9;
	R1894[1] = (char *(*)()) F572_2661_1894_9;
	R1894[2] = (char *(*)()) F573_2661_1894_9;
	R1894[3] = (char *(*)()) F574_2661_1894_9;
	R1894[4] = (char *(*)()) F575_2661_1894_9;
	R1894[5] = (char *(*)()) F576_2661_1894_9;
	R1894[6] = (char *(*)()) F577_2661_1894_9;
	R1894[7] = (char *(*)()) F578_2661_1894_9;
	R1894[8] = (char *(*)()) F579_2661_1894_9;
	R1894[9] = (char *(*)()) F580_2661_1894_9;
	R1894[10] = (char *(*)()) F581_2661_1894_9;
	R1894[11] = (char *(*)()) F582_2661_1894_9;
	R1894[76] = (char *(*)()) F647_2937;
	R1894[77] = (char *(*)()) F648_2937_1894_9;
	R1894[78] = (char *(*)()) F649_2937_1894_9;
	R1894[79] = (char *(*)()) F650_2937_1894_9;
	R1894[80] = (char *(*)()) F651_2937_1894_9;
	R1894[83] = (char *(*)()) F647_2937;
	R1894[203] = (char *(*)()) F774_4746_1894_9;
	R1894[205] = (char *(*)()) F774_4746_1894_9;
}
static void F571_2661_1894_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F571_2661(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F572_2661_1894_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F572_2661(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F573_2661_1894_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F573_2661(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F574_2661_1894_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F574_2661(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F575_2661_1894_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F575_2661(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F576_2661_1894_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F576_2661(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F577_2661_1894_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F577_2661(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F578_2661_1894_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F578_2661(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F579_2661_1894_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F579_2661(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F580_2661_1894_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F580_2661(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F581_2661_1894_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F581_2661(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F582_2661_1894_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F582_2661(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F648_2937_1894_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F648_2937(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F649_2937_1894_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F649_2937(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F650_2937_1894_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F650_2937(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F651_2937_1894_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F651_2937(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F774_4746_1894_9 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F774_4746(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

static EIF_TYPE_INDEX Y1896_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype30[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype31[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype32[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype33[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype34[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype35[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype36[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype37[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype38[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype39[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype40[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype41[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype42[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype43[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype44[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype45[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype46[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype47[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype48[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype49[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype50[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype51[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype52[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype53[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype54[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype55[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype56[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype57[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype58[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype59[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype60[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype61[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype62[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype63[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype64[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype65[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype66[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype67[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype68[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype69[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype70[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype71[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype72[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype73[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype74[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype75[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype76[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype77[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype78[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype79[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype80[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype81[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype82[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype83[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype84[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype85[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype86[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype87[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype88[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype89[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype90[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype91[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype92[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype93[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype94[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype95[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype96[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype97[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype98[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype99[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype100[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype101[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype102[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype103[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype104[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype105[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype106[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype107[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype108[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype109[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype110[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype111[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype112[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype113[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype114[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype115[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype116[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype117[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype118[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype119[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype120[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype121[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype122[] = {765,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype123[] = {765,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype124[] = {773,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype125[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype126[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype127[] = {690,0xFFFF};
static EIF_TYPE_INDEX Y1896_pgtype128[] = {690,0xFFFF};
EIF_TYPE_INDEX *Y1896_gen_type [379];
EIF_TYPE_INDEX Y1896 [379];
void Y1896_init (void)
{
	egc_routines_types [1896] = Y1896;
	egc_routines_gen_types [1896] = Y1896_gen_type;
	egc_routines_offset [1896] = 397;
	Y1896_gen_type [0] = Y1896_pgtype0;
	Y1896_gen_type [1] = Y1896_pgtype1;
	Y1896_gen_type [2] = Y1896_pgtype2;
	Y1896_gen_type [3] = Y1896_pgtype3;
	Y1896_gen_type [4] = Y1896_pgtype4;
	Y1896_gen_type [5] = Y1896_pgtype5;
	Y1896_gen_type [6] = Y1896_pgtype6;
	Y1896_gen_type [7] = Y1896_pgtype7;
	Y1896_gen_type [8] = Y1896_pgtype8;
	Y1896_gen_type [9] = Y1896_pgtype9;
	Y1896_gen_type [10] = Y1896_pgtype10;
	Y1896_gen_type [11] = Y1896_pgtype11;
	Y1896_gen_type [12] = Y1896_pgtype12;
	Y1896_gen_type [13] = Y1896_pgtype13;
	Y1896_gen_type [14] = Y1896_pgtype14;
	Y1896_gen_type [15] = Y1896_pgtype15;
	Y1896_gen_type [16] = Y1896_pgtype16;
	Y1896_gen_type [17] = Y1896_pgtype17;
	Y1896_gen_type [18] = Y1896_pgtype18;
	Y1896_gen_type [19] = Y1896_pgtype19;
	Y1896_gen_type [20] = Y1896_pgtype20;
	Y1896_gen_type [21] = Y1896_pgtype21;
	Y1896_gen_type [22] = Y1896_pgtype22;
	Y1896_gen_type [23] = Y1896_pgtype23;
	Y1896_gen_type [24] = Y1896_pgtype24;
	Y1896_gen_type [25] = Y1896_pgtype25;
	Y1896_gen_type [26] = Y1896_pgtype26;
	Y1896_gen_type [27] = Y1896_pgtype27;
	Y1896_gen_type [28] = Y1896_pgtype28;
	Y1896_gen_type [29] = Y1896_pgtype29;
	Y1896_gen_type [160] = Y1896_pgtype30;
	Y1896_gen_type [161] = Y1896_pgtype31;
	Y1896_gen_type [162] = Y1896_pgtype32;
	Y1896_gen_type [163] = Y1896_pgtype33;
	Y1896_gen_type [164] = Y1896_pgtype34;
	Y1896_gen_type [165] = Y1896_pgtype35;
	Y1896_gen_type [166] = Y1896_pgtype36;
	Y1896_gen_type [167] = Y1896_pgtype37;
	Y1896_gen_type [168] = Y1896_pgtype38;
	Y1896_gen_type [169] = Y1896_pgtype39;
	Y1896_gen_type [170] = Y1896_pgtype40;
	Y1896_gen_type [171] = Y1896_pgtype41;
	Y1896_gen_type [172] = Y1896_pgtype42;
	Y1896_gen_type [173] = Y1896_pgtype43;
	Y1896_gen_type [174] = Y1896_pgtype44;
	Y1896_gen_type [175] = Y1896_pgtype45;
	Y1896_gen_type [176] = Y1896_pgtype46;
	Y1896_gen_type [177] = Y1896_pgtype47;
	Y1896_gen_type [178] = Y1896_pgtype48;
	Y1896_gen_type [179] = Y1896_pgtype49;
	Y1896_gen_type [180] = Y1896_pgtype50;
	Y1896_gen_type [181] = Y1896_pgtype51;
	Y1896_gen_type [182] = Y1896_pgtype52;
	Y1896_gen_type [183] = Y1896_pgtype53;
	Y1896_gen_type [184] = Y1896_pgtype54;
	Y1896_gen_type [185] = Y1896_pgtype55;
	Y1896_gen_type [186] = Y1896_pgtype56;
	Y1896_gen_type [187] = Y1896_pgtype57;
	Y1896_gen_type [188] = Y1896_pgtype58;
	Y1896_gen_type [189] = Y1896_pgtype59;
	Y1896_gen_type [190] = Y1896_pgtype60;
	Y1896_gen_type [191] = Y1896_pgtype61;
	Y1896_gen_type [192] = Y1896_pgtype62;
	Y1896_gen_type [193] = Y1896_pgtype63;
	Y1896_gen_type [194] = Y1896_pgtype64;
	Y1896_gen_type [195] = Y1896_pgtype65;
	Y1896_gen_type [196] = Y1896_pgtype66;
	Y1896_gen_type [197] = Y1896_pgtype67;
	Y1896_gen_type [198] = Y1896_pgtype68;
	Y1896_gen_type [199] = Y1896_pgtype69;
	Y1896_gen_type [200] = Y1896_pgtype70;
	Y1896_gen_type [201] = Y1896_pgtype71;
	Y1896_gen_type [202] = Y1896_pgtype72;
	Y1896_gen_type [203] = Y1896_pgtype73;
	Y1896_gen_type [204] = Y1896_pgtype74;
	Y1896_gen_type [205] = Y1896_pgtype75;
	Y1896_gen_type [206] = Y1896_pgtype76;
	Y1896_gen_type [207] = Y1896_pgtype77;
	Y1896_gen_type [208] = Y1896_pgtype78;
	Y1896_gen_type [209] = Y1896_pgtype79;
	Y1896_gen_type [210] = Y1896_pgtype80;
	Y1896_gen_type [211] = Y1896_pgtype81;
	Y1896_gen_type [212] = Y1896_pgtype82;
	Y1896_gen_type [213] = Y1896_pgtype83;
	Y1896_gen_type [214] = Y1896_pgtype84;
	Y1896_gen_type [215] = Y1896_pgtype85;
	Y1896_gen_type [216] = Y1896_pgtype86;
	Y1896_gen_type [217] = Y1896_pgtype87;
	Y1896_gen_type [218] = Y1896_pgtype88;
	Y1896_gen_type [219] = Y1896_pgtype89;
	Y1896_gen_type [220] = Y1896_pgtype90;
	Y1896_gen_type [221] = Y1896_pgtype91;
	Y1896_gen_type [222] = Y1896_pgtype92;
	Y1896_gen_type [223] = Y1896_pgtype93;
	Y1896_gen_type [224] = Y1896_pgtype94;
	Y1896_gen_type [225] = Y1896_pgtype95;
	Y1896_gen_type [226] = Y1896_pgtype96;
	Y1896_gen_type [227] = Y1896_pgtype97;
	Y1896_gen_type [228] = Y1896_pgtype98;
	Y1896_gen_type [229] = Y1896_pgtype99;
	Y1896_gen_type [230] = Y1896_pgtype100;
	Y1896_gen_type [231] = Y1896_pgtype101;
	Y1896_gen_type [232] = Y1896_pgtype102;
	Y1896_gen_type [233] = Y1896_pgtype103;
	Y1896_gen_type [234] = Y1896_pgtype104;
	Y1896_gen_type [237] = Y1896_pgtype105;
	Y1896_gen_type [238] = Y1896_pgtype106;
	Y1896_gen_type [239] = Y1896_pgtype107;
	Y1896_gen_type [240] = Y1896_pgtype108;
	Y1896_gen_type [241] = Y1896_pgtype109;
	Y1896_gen_type [242] = Y1896_pgtype110;
	Y1896_gen_type [243] = Y1896_pgtype111;
	Y1896_gen_type [244] = Y1896_pgtype112;
	Y1896_gen_type [245] = Y1896_pgtype113;
	Y1896_gen_type [246] = Y1896_pgtype114;
	Y1896_gen_type [247] = Y1896_pgtype115;
	Y1896_gen_type [248] = Y1896_pgtype116;
	Y1896_gen_type [249] = Y1896_pgtype117;
	Y1896_gen_type [250] = Y1896_pgtype118;
	Y1896_gen_type [251] = Y1896_pgtype119;
	Y1896_gen_type [252] = Y1896_pgtype120;
	Y1896_gen_type [253] = Y1896_pgtype121;
	Y1896_gen_type [254] = Y1896_pgtype122;
	Y1896_gen_type [255] = Y1896_pgtype123;
	Y1896_gen_type [256] = Y1896_pgtype124;
	Y1896_gen_type [373] = Y1896_pgtype125;
	Y1896_gen_type [376] = Y1896_pgtype126;
	Y1896_gen_type [377] = Y1896_pgtype127;
	Y1896_gen_type [378] = Y1896_pgtype128;
	{long i; for (i = 160; i < 235; i++) Y1896[i] = 690;};
	{long i; for (i = 237; i < 249; i++) Y1896[i] = 690;};
	{long i; for (i = 254; i < 256; i++) Y1896[i] = 765;};
	Y1896[256] = 773;
	Y1896[373] = 690;
	{long i; for (i = 376; i < 379; i++) Y1896[i] = 690;};
}

char *(*R1918[247])();
void R1918_init () {
	{long i; for (i = 0; i < 3; i++) R1918[i] = (char *(*)()) F530_2225;}
	R1918[40] = (char *(*)()) F571_2649;
	R1918[41] = (char *(*)()) F572_2649;
	R1918[42] = (char *(*)()) F573_2649;
	R1918[43] = (char *(*)()) F574_2649;
	R1918[44] = (char *(*)()) F575_2649;
	R1918[45] = (char *(*)()) F576_2649;
	R1918[46] = (char *(*)()) F577_2649;
	R1918[47] = (char *(*)()) F578_2649;
	R1918[48] = (char *(*)()) F579_2649;
	R1918[49] = (char *(*)()) F580_2649;
	R1918[50] = (char *(*)()) F581_2649;
	R1918[51] = (char *(*)()) F582_2649;
	R1918[104] = (char *(*)()) F635_2846;
	R1918[105] = (char *(*)()) F636_2846;
	R1918[106] = (char *(*)()) F637_2846;
	R1918[107] = (char *(*)()) F638_2846;
	R1918[108] = (char *(*)()) F639_2846;
	R1918[109] = (char *(*)()) F640_2846;
	R1918[110] = (char *(*)()) F641_2846;
	R1918[111] = (char *(*)()) F642_2846;
	R1918[112] = (char *(*)()) F643_2846;
	R1918[113] = (char *(*)()) F644_2846;
	R1918[114] = (char *(*)()) F645_2846;
	R1918[115] = (char *(*)()) F646_2846;
	R1918[116] = (char *(*)()) F647_2909;
	R1918[117] = (char *(*)()) F648_2909;
	R1918[118] = (char *(*)()) F649_2909;
	R1918[119] = (char *(*)()) F650_2909;
	R1918[120] = (char *(*)()) F651_2909;
	R1918[123] = (char *(*)()) F647_2909;
	R1918[240] = (char *(*)()) F769_4500;
	R1918[243] = (char *(*)()) F772_4668;
	R1918[245] = (char *(*)()) F772_4668;
	R1918[246] = (char *(*)()) F777_4848;
}

char *(*R1921[206])();
void R1921_init () {
	R1921[0] = (char *(*)()) F571_2650;
	R1921[1] = (char *(*)()) F572_2650;
	R1921[2] = (char *(*)()) F573_2650;
	R1921[3] = (char *(*)()) F574_2650;
	R1921[4] = (char *(*)()) F575_2650;
	R1921[5] = (char *(*)()) F576_2650;
	R1921[6] = (char *(*)()) F577_2650;
	R1921[7] = (char *(*)()) F578_2650;
	R1921[8] = (char *(*)()) F579_2650;
	R1921[9] = (char *(*)()) F580_2650;
	R1921[10] = (char *(*)()) F581_2650;
	R1921[11] = (char *(*)()) F582_2650;
	R1921[64] = (char *(*)()) F635_2847;
	R1921[65] = (char *(*)()) F636_2847;
	R1921[66] = (char *(*)()) F637_2847;
	R1921[67] = (char *(*)()) F638_2847;
	R1921[68] = (char *(*)()) F639_2847;
	R1921[69] = (char *(*)()) F640_2847;
	R1921[70] = (char *(*)()) F641_2847;
	R1921[71] = (char *(*)()) F642_2847;
	R1921[72] = (char *(*)()) F643_2847;
	R1921[73] = (char *(*)()) F644_2847;
	R1921[74] = (char *(*)()) F645_2847;
	R1921[75] = (char *(*)()) F646_2847;
	R1921[200] = (char *(*)()) F769_4499;
	R1921[203] = (char *(*)()) F772_4667;
	R1921[205] = (char *(*)()) F772_4667;
}

char *(*R1925[206])();
void R1925_init () {
	R1925[0] = (char *(*)()) F494_2182;
	R1925[1] = (char *(*)()) F495_2182;
	R1925[2] = (char *(*)()) F496_2182;
	R1925[3] = (char *(*)()) F497_2182;
	R1925[4] = (char *(*)()) F498_2182;
	R1925[5] = (char *(*)()) F499_2182;
	R1925[6] = (char *(*)()) F500_2182;
	R1925[7] = (char *(*)()) F501_2182;
	R1925[8] = (char *(*)()) F502_2182;
	R1925[9] = (char *(*)()) F503_2182;
	R1925[10] = (char *(*)()) F504_2182;
	R1925[11] = (char *(*)()) F505_2182;
	R1925[64] = (char *(*)()) F494_2182;
	R1925[65] = (char *(*)()) F495_2182;
	R1925[66] = (char *(*)()) F496_2182;
	R1925[67] = (char *(*)()) F497_2182;
	R1925[68] = (char *(*)()) F498_2182;
	R1925[69] = (char *(*)()) F499_2182;
	R1925[70] = (char *(*)()) F500_2182;
	R1925[71] = (char *(*)()) F501_2182;
	R1925[72] = (char *(*)()) F502_2182;
	R1925[73] = (char *(*)()) F503_2182;
	R1925[74] = (char *(*)()) F504_2182;
	R1925[75] = (char *(*)()) F505_2182;
	R1925[200] = (char *(*)()) F495_2182;
	R1925[203] = (char *(*)()) F496_2182;
	R1925[205] = (char *(*)()) F496_2182;
}

char *(*R1932[247])();
void R1932_init () {
	R1932[0] = (char *(*)()) F531_2423;
	{long i; for (i = 1; i < 3; i++) R1932[i] = (char *(*)()) F530_2195;}
	R1932[246] = (char *(*)()) F531_2423;
}

char *(*R1957[247])();
void R1957_init () {
	{long i; for (i = 0; i < 3; i++) R1957[i] = (char *(*)()) F530_2229;}
	R1957[246] = (char *(*)()) F777_4846;
}

char *(*R2026[247])();
void R2026_init () {
	R2026[0] = (char *(*)()) F530_2353;
	{long i; for (i = 1; i < 3; i++) R2026[i] = (char *(*)()) F532_2534;}
	R2026[246] = (char *(*)()) F530_2353;
}

char *(*R2027[247])();
void R2027_init () {
	{long i; for (i = 0; i < 3; i++) R2027[i] = (char *(*)()) F530_2354;}
	R2027[246] = (char *(*)()) F777_4902;
}

char *(*R2130[226])();
void R2130_init () {
	R2130[0] = (char *(*)()) F546_2551;
	R2130[1] = (char *(*)()) F547_2551_2130_32;
	R2130[2] = (char *(*)()) F548_2551_2130_32;
	R2130[3] = (char *(*)()) F549_2551_2130_32;
	R2130[4] = (char *(*)()) F550_2551_2130_32;
	R2130[5] = (char *(*)()) F551_2551_2130_32;
	R2130[6] = (char *(*)()) F552_2551_2130_32;
	R2130[7] = (char *(*)()) F553_2551_2130_32;
	R2130[8] = (char *(*)()) F554_2551_2130_32;
	R2130[9] = (char *(*)()) F555_2551_2130_32;
	R2130[10] = (char *(*)()) F556_2551_2130_32;
	R2130[11] = (char *(*)()) F557_2551_2130_32;
	R2130[25] = (char *(*)()) F571_2642;
	R2130[26] = (char *(*)()) F572_2642_2130_32;
	R2130[27] = (char *(*)()) F573_2642_2130_32;
	R2130[28] = (char *(*)()) F574_2642_2130_32;
	R2130[29] = (char *(*)()) F575_2642_2130_32;
	R2130[30] = (char *(*)()) F576_2642_2130_32;
	R2130[31] = (char *(*)()) F577_2642_2130_32;
	R2130[32] = (char *(*)()) F578_2642_2130_32;
	R2130[33] = (char *(*)()) F579_2642_2130_32;
	R2130[34] = (char *(*)()) F580_2642_2130_32;
	R2130[35] = (char *(*)()) F581_2642_2130_32;
	R2130[36] = (char *(*)()) F582_2642_2130_32;
	R2130[89] = (char *(*)()) F635_2831;
	R2130[90] = (char *(*)()) F636_2831_2130_32;
	R2130[91] = (char *(*)()) F637_2831_2130_32;
	R2130[92] = (char *(*)()) F638_2831_2130_32;
	R2130[93] = (char *(*)()) F639_2831_2130_32;
	R2130[94] = (char *(*)()) F640_2831_2130_32;
	R2130[95] = (char *(*)()) F641_2831_2130_32;
	R2130[96] = (char *(*)()) F642_2831_2130_32;
	R2130[97] = (char *(*)()) F643_2831_2130_32;
	R2130[98] = (char *(*)()) F644_2831_2130_32;
	R2130[99] = (char *(*)()) F645_2831_2130_32;
	R2130[100] = (char *(*)()) F646_2831_2130_32;
	R2130[142] = (char *(*)()) F688_3116;
	R2130[224] = (char *(*)()) F770_4538_2130_32;
	R2130[225] = (char *(*)()) F771_4561_2130_32;
}
static EIF_REFERENCE F547_2551_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F547_2551(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(717, 0x00).id, 717, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F548_2551_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F548_2551(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(720, 0x00).id, 720, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F549_2551_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F549_2551(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(708, 0x00).id, 708, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F550_2551_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F550_2551(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(705, 0x00).id, 705, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F551_2551_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F551_2551(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(759, 0x00).id, 759, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F552_2551_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F552_2551(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(711, 0x00).id, 711, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F553_2551_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F553_2551(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(714, 0x00).id, 714, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F554_2551_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F554_2551(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(702, 0x00).id, 702, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F555_2551_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F555_2551(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(723, 0x00).id, 723, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F556_2551_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F556_2551(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(699, 0x00).id, 699, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F557_2551_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F557_2551(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(690, 0x00).id, 690, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F572_2642_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F572_2642(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(717, 0x00).id, 717, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F573_2642_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F573_2642(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(720, 0x00).id, 720, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F574_2642_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F574_2642(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(708, 0x00).id, 708, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F575_2642_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F575_2642(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(705, 0x00).id, 705, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F576_2642_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F576_2642(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(759, 0x00).id, 759, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F577_2642_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F577_2642(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(711, 0x00).id, 711, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F578_2642_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F578_2642(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(714, 0x00).id, 714, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F579_2642_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F579_2642(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(702, 0x00).id, 702, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F580_2642_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F580_2642(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(723, 0x00).id, 723, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F581_2642_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F581_2642(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(699, 0x00).id, 699, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F582_2642_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F582_2642(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(690, 0x00).id, 690, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F636_2831_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F636_2831(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(717, 0x00).id, 717, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F637_2831_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F637_2831(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(720, 0x00).id, 720, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F638_2831_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F638_2831(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(708, 0x00).id, 708, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F639_2831_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F639_2831(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(705, 0x00).id, 705, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F640_2831_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F640_2831(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(759, 0x00).id, 759, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F641_2831_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F641_2831(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(711, 0x00).id, 711, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F642_2831_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F642_2831(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(714, 0x00).id, 714, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F643_2831_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F643_2831(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(702, 0x00).id, 702, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F644_2831_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F644_2831(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(723, 0x00).id, 723, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F645_2831_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F645_2831(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(699, 0x00).id, 699, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F646_2831_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F646_2831(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(690, 0x00).id, 690, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F770_4538_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F770_4538(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(717, 0x00).id, 717, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F771_4561_2130_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F771_4561(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(717, 0x00).id, 717, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}

char *(*R2131[231])();
void R2131_init () {
	R2131[0] = (char *(*)()) F546_2559;
	R2131[1] = (char *(*)()) F547_2559;
	R2131[2] = (char *(*)()) F548_2559;
	R2131[3] = (char *(*)()) F549_2559;
	R2131[4] = (char *(*)()) F550_2559;
	R2131[5] = (char *(*)()) F551_2559;
	R2131[6] = (char *(*)()) F552_2559;
	R2131[7] = (char *(*)()) F553_2559;
	R2131[8] = (char *(*)()) F554_2559;
	R2131[9] = (char *(*)()) F555_2559;
	R2131[10] = (char *(*)()) F556_2559;
	R2131[11] = (char *(*)()) F557_2559;
	R2131[25] = (char *(*)()) F571_2647;
	R2131[26] = (char *(*)()) F572_2647;
	R2131[27] = (char *(*)()) F573_2647;
	R2131[28] = (char *(*)()) F574_2647;
	R2131[29] = (char *(*)()) F575_2647;
	R2131[30] = (char *(*)()) F576_2647;
	R2131[31] = (char *(*)()) F577_2647;
	R2131[32] = (char *(*)()) F578_2647;
	R2131[33] = (char *(*)()) F579_2647;
	R2131[34] = (char *(*)()) F580_2647;
	R2131[35] = (char *(*)()) F581_2647;
	R2131[36] = (char *(*)()) F582_2647;
	R2131[89] = (char *(*)()) F583_2702;
	R2131[90] = (char *(*)()) F585_2702;
	R2131[91] = (char *(*)()) F586_2702;
	R2131[92] = (char *(*)()) F587_2702;
	R2131[93] = (char *(*)()) F588_2702;
	R2131[94] = (char *(*)()) F589_2702;
	R2131[95] = (char *(*)()) F590_2702;
	R2131[96] = (char *(*)()) F591_2702;
	R2131[97] = (char *(*)()) F592_2702;
	R2131[98] = (char *(*)()) F593_2702;
	R2131[99] = (char *(*)()) F594_2702;
	R2131[100] = (char *(*)()) F584_2702;
	R2131[101] = (char *(*)()) F647_2912;
	R2131[102] = (char *(*)()) F648_2912;
	R2131[103] = (char *(*)()) F649_2912;
	R2131[104] = (char *(*)()) F650_2912;
	R2131[105] = (char *(*)()) F651_2912;
	R2131[108] = (char *(*)()) F647_2912;
	R2131[142] = (char *(*)()) F688_3146;
	{long i; for (i = 224; i < 226; i++) R2131[i] = (char *(*)()) F769_4502;}
	{long i; for (i = 227; i < 229; i++) R2131[i] = (char *(*)()) F772_4670;}
	R2131[230] = (char *(*)()) F772_4670;
}

EIF_TYPE_INDEX *Y2131_gen_type [243];
EIF_TYPE_INDEX Y2131 [243];
void Y2131_init (void)
{
	egc_routines_types [2131] = Y2131;
	egc_routines_gen_types [2131] = Y2131_gen_type;
	egc_routines_offset [2131] = 533;
	{long i; for (i = 0; i < 99; i++) Y2131[i] = 690;};
	{long i; for (i = 101; i < 121; i++) Y2131[i] = 690;};
	Y2131[154] = 690;
	{long i; for (i = 235; i < 243; i++) Y2131[i] = 690;};
}


#ifdef __cplusplus
}
#endif
