#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O634[6];
void O634_init () {
	O634[0] = 0;
	{long i; for (i = 1; i < 3; i++) O634[i] = + _LNGOFF_0_0_0_0_;}
	O634[3] = + _I64OFF_0_0_0_0_0_0_0_;
	O634[4] = 0;
	O634[5] = + _LNGOFF_1_0_0_0_;
}

long O1109[662];
void O1109_init () {
	O1109[0] = + _CHROFF_1_0_;
	O1109[414] = + _CHROFF_3_0_;
	O1109[415] = + _CHROFF_5_0_;
	{long i; for (i = 416; i < 418; i++) O1109[i] = + _CHROFF_4_0_;}
	O1109[661] = + _CHROFF_5_0_;
}

static EIF_TYPE_INDEX Y1437_pgtype0[] = {545,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype1[] = {546,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype2[] = {547,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype3[] = {548,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype4[] = {549,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype5[] = {550,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype6[] = {551,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype7[] = {552,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype8[] = {553,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype9[] = {554,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype10[] = {555,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype11[] = {556,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype12[] = {548,708,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype13[] = {548,708,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype14[] = {545,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype15[] = {546,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype16[] = {547,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype17[] = {548,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype18[] = {549,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype19[] = {550,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype20[] = {551,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype21[] = {552,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype22[] = {553,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype23[] = {554,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype24[] = {555,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype25[] = {556,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype26[] = {545,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype27[] = {546,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype28[] = {547,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype29[] = {548,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype30[] = {549,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype31[] = {550,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype32[] = {551,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype33[] = {552,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype34[] = {553,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype35[] = {554,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype36[] = {555,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype37[] = {556,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype38[] = {546,717,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype39[] = {547,720,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype40[] = {547,720,0xFFFF};
static EIF_TYPE_INDEX Y1437_pgtype41[] = {547,720,0xFFFF};
EIF_TYPE_INDEX *Y1437_gen_type [653];
EIF_TYPE_INDEX Y1437 [653];
void Y1437_init (void)
{
	egc_routines_types [1437] = Y1437;
	egc_routines_gen_types [1437] = Y1437_gen_type;
	egc_routines_offset [1437] = 123;
	Y1437_gen_type [0] = Y1437_pgtype0;
	Y1437_gen_type [1] = Y1437_pgtype1;
	Y1437_gen_type [2] = Y1437_pgtype2;
	Y1437_gen_type [3] = Y1437_pgtype3;
	Y1437_gen_type [4] = Y1437_pgtype4;
	Y1437_gen_type [5] = Y1437_pgtype5;
	Y1437_gen_type [6] = Y1437_pgtype6;
	Y1437_gen_type [7] = Y1437_pgtype7;
	Y1437_gen_type [8] = Y1437_pgtype8;
	Y1437_gen_type [9] = Y1437_pgtype9;
	Y1437_gen_type [10] = Y1437_pgtype10;
	Y1437_gen_type [11] = Y1437_pgtype11;
	Y1437_gen_type [15] = Y1437_pgtype12;
	Y1437_gen_type [16] = Y1437_pgtype13;
	Y1437_gen_type [447] = Y1437_pgtype14;
	Y1437_gen_type [448] = Y1437_pgtype15;
	Y1437_gen_type [449] = Y1437_pgtype16;
	Y1437_gen_type [450] = Y1437_pgtype17;
	Y1437_gen_type [451] = Y1437_pgtype18;
	Y1437_gen_type [452] = Y1437_pgtype19;
	Y1437_gen_type [453] = Y1437_pgtype20;
	Y1437_gen_type [454] = Y1437_pgtype21;
	Y1437_gen_type [455] = Y1437_pgtype22;
	Y1437_gen_type [456] = Y1437_pgtype23;
	Y1437_gen_type [457] = Y1437_pgtype24;
	Y1437_gen_type [458] = Y1437_pgtype25;
	Y1437_gen_type [511] = Y1437_pgtype26;
	Y1437_gen_type [512] = Y1437_pgtype27;
	Y1437_gen_type [513] = Y1437_pgtype28;
	Y1437_gen_type [514] = Y1437_pgtype29;
	Y1437_gen_type [515] = Y1437_pgtype30;
	Y1437_gen_type [516] = Y1437_pgtype31;
	Y1437_gen_type [517] = Y1437_pgtype32;
	Y1437_gen_type [518] = Y1437_pgtype33;
	Y1437_gen_type [519] = Y1437_pgtype34;
	Y1437_gen_type [520] = Y1437_pgtype35;
	Y1437_gen_type [521] = Y1437_pgtype36;
	Y1437_gen_type [522] = Y1437_pgtype37;
	Y1437_gen_type [647] = Y1437_pgtype38;
	Y1437_gen_type [650] = Y1437_pgtype39;
	Y1437_gen_type [651] = Y1437_pgtype40;
	Y1437_gen_type [652] = Y1437_pgtype41;
	Y1437[0] = 545;
	Y1437[1] = 546;
	Y1437[2] = 547;
	Y1437[3] = 548;
	Y1437[4] = 549;
	Y1437[5] = 550;
	Y1437[6] = 551;
	Y1437[7] = 552;
	Y1437[8] = 553;
	Y1437[9] = 554;
	Y1437[10] = 555;
	Y1437[11] = 556;
	{long i; for (i = 15; i < 17; i++) Y1437[i] = 548;};
	Y1437[447] = 545;
	Y1437[448] = 546;
	Y1437[449] = 547;
	Y1437[450] = 548;
	Y1437[451] = 549;
	Y1437[452] = 550;
	Y1437[453] = 551;
	Y1437[454] = 552;
	Y1437[455] = 553;
	Y1437[456] = 554;
	Y1437[457] = 555;
	Y1437[458] = 556;
	Y1437[511] = 545;
	Y1437[512] = 546;
	Y1437[513] = 547;
	Y1437[514] = 548;
	Y1437[515] = 549;
	Y1437[516] = 550;
	Y1437[517] = 551;
	Y1437[518] = 552;
	Y1437[519] = 553;
	Y1437[520] = 554;
	Y1437[521] = 555;
	Y1437[522] = 556;
	Y1437[647] = 546;
	{long i; for (i = 650; i < 653; i++) Y1437[i] = 547;};
}

long O1594[2];
void O1594_init () {
	O1594[0] = + _PTROFF_3_0_0_1_0_0_;
	O1594[1] = + _PTROFF_11_2_0_1_0_0_;
}

long O1595[2];
void O1595_init () {
	O1595[0] = + _PTROFF_3_0_0_1_0_1_;
	O1595[1] = + _PTROFF_11_2_0_1_0_1_;
}

long O1600[2];
void O1600_init () {
	O1600[0] = + _LNGOFF_3_0_0_0_;
	O1600[1] = + _LNGOFF_11_2_0_0_;
}

long O1856[453];
void O1856_init () {
	{long i; for (i = 0; i < 205; i++) O1856[i] = + _CHROFF_0_0_;}
	O1856[205] = + _CHROFF_3_2_;
	O1856[206] = + _CHROFF_5_2_;
	{long i; for (i = 207; i < 209; i++) O1856[i] = + _CHROFF_4_2_;}
	{long i; for (i = 233; i < 246; i++) O1856[i] = + _CHROFF_0_0_;}
	{long i; for (i = 246; i < 258; i++) O1856[i] = + _CHROFF_1_0_;}
	{long i; for (i = 258; i < 306; i++) O1856[i] = + _CHROFF_0_0_;}
	{long i; for (i = 306; i < 308; i++) O1856[i] = + _CHROFF_2_0_;}
	{long i; for (i = 309; i < 322; i++) O1856[i] = + _CHROFF_1_0_;}
	O1856[322] = + _CHROFF_7_0_;
	{long i; for (i = 323; i < 325; i++) O1856[i] = + _CHROFF_5_0_;}
	O1856[325] = + _CHROFF_6_0_;
	O1856[326] = + _CHROFF_4_0_;
	O1856[327] = + _CHROFF_7_0_;
	O1856[328] = + _CHROFF_5_0_;
	O1856[329] = + _CHROFF_9_0_;
	O1856[446] = + _CHROFF_1_0_;
	{long i; for (i = 449; i < 452; i++) O1856[i] = + _CHROFF_1_0_;}
	O1856[452] = + _CHROFF_5_2_;
}

long O1945[248];
void O1945_init () {
	O1945[0] = + _PTROFF_3_6_2_4_1_0_;
	O1945[1] = + _PTROFF_5_7_2_4_1_0_;
	{long i; for (i = 2; i < 4; i++) O1945[i] = + _PTROFF_4_6_2_4_1_0_;}
	O1945[247] = + _PTROFF_5_7_2_4_1_0_;
}

long O2084[248];
void O2084_init () {
	O2084[0] = + _LNGOFF_3_6_2_3_;
	O2084[1] = + _LNGOFF_5_7_2_3_;
	{long i; for (i = 2; i < 4; i++) O2084[i] = + _LNGOFF_4_6_2_3_;}
	O2084[247] = + _LNGOFF_5_7_2_3_;
}

long O2093[248];
void O2093_init () {
	O2093[0] = + _CHROFF_3_3_;
	O2093[1] = + _CHROFF_5_3_;
	{long i; for (i = 2; i < 4; i++) O2093[i] = + _CHROFF_4_3_;}
	O2093[247] = + _CHROFF_5_3_;
}

EIF_TYPE_INDEX *Y2275_gen_type [1];
EIF_TYPE_INDEX Y2275 [1];
void Y2275_init (void)
{
	egc_routines_types [2275] = Y2275;
	egc_routines_gen_types [2275] = Y2275_gen_type;
	egc_routines_offset [2275] = 633;
	Y2275[0] = 690;
}

long O2295[8];
void O2295_init () {
	O2295[0] = 0;
	O2295[1] = + _PTROFF_5_3_0_7_0_0_;
	O2295[2] = + _LNGOFF_5_3_0_0_;
	O2295[3] = 0;
	O2295[4] = + _LNGOFF_4_3_0_0_;
	O2295[5] = 0;
	O2295[6] = + _LNGOFF_5_4_0_0_;
	O2295[7] = 0;
}

long O2304[8];
void O2304_init () {
	O2304[0] = + _LNGOFF_7_3_0_0_;
	O2304[1] = + _LNGOFF_5_3_0_0_;
	O2304[2] = + _LNGOFF_5_3_0_1_;
	O2304[3] = + _LNGOFF_6_3_0_0_;
	O2304[4] = + _LNGOFF_4_3_0_1_;
	O2304[5] = + _LNGOFF_7_4_0_0_;
	O2304[6] = + _LNGOFF_5_4_0_1_;
	O2304[7] = + _LNGOFF_9_3_0_0_;
}

long O2331[8];
void O2331_init () {
	O2331[0] =  + _REFACS_1_;
	{long i; for (i = 1; i < 3; i++) O2331[i] = 0;}
	O2331[3] =  + _REFACS_1_;
	O2331[4] = 0;
	O2331[5] =  + _REFACS_1_;
	O2331[6] = 0;
	O2331[7] =  + _REFACS_1_;
}

static EIF_TYPE_INDEX Y2331_pgtype0[] = {545,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2331_pgtype1[] = {550,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2331_pgtype2[] = {556,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2331_pgtype3[] = {545,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2331_pgtype4[] = {556,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2331_pgtype5[] = {545,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2331_pgtype6[] = {556,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2331_pgtype7[] = {545,0,0xFFFF};
EIF_TYPE_INDEX *Y2331_gen_type [8];
EIF_TYPE_INDEX Y2331 [8];
void Y2331_init (void)
{
	egc_routines_types [2331] = Y2331;
	egc_routines_gen_types [2331] = Y2331_gen_type;
	egc_routines_offset [2331] = 646;
	Y2331_gen_type [0] = Y2331_pgtype0;
	Y2331_gen_type [1] = Y2331_pgtype1;
	Y2331_gen_type [2] = Y2331_pgtype2;
	Y2331_gen_type [3] = Y2331_pgtype3;
	Y2331_gen_type [4] = Y2331_pgtype4;
	Y2331_gen_type [5] = Y2331_pgtype5;
	Y2331_gen_type [6] = Y2331_pgtype6;
	Y2331_gen_type [7] = Y2331_pgtype7;
	Y2331[0] = 545;
	Y2331[1] = 550;
	Y2331[2] = 556;
	Y2331[3] = 545;
	Y2331[4] = 556;
	Y2331[5] = 545;
	Y2331[6] = 556;
	Y2331[7] = 545;
}

long O2332[8];
void O2332_init () {
	O2332[0] =  + _REFACS_2_;
	{long i; for (i = 1; i < 3; i++) O2332[i] =  + _REFACS_1_;}
	O2332[3] =  + _REFACS_2_;
	O2332[4] =  + _REFACS_1_;
	O2332[5] =  + _REFACS_2_;
	O2332[6] =  + _REFACS_1_;
	O2332[7] =  + _REFACS_2_;
}

static EIF_TYPE_INDEX Y2332_pgtype0[] = {545,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2332_pgtype1[] = {545,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2332_pgtype2[] = {545,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2332_pgtype3[] = {556,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2332_pgtype4[] = {556,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2332_pgtype5[] = {545,765,0xFFFF};
static EIF_TYPE_INDEX Y2332_pgtype6[] = {545,765,0xFFFF};
static EIF_TYPE_INDEX Y2332_pgtype7[] = {545,773,0xFFFF};
EIF_TYPE_INDEX *Y2332_gen_type [8];
EIF_TYPE_INDEX Y2332 [8];
void Y2332_init (void)
{
	egc_routines_types [2332] = Y2332;
	egc_routines_gen_types [2332] = Y2332_gen_type;
	egc_routines_offset [2332] = 646;
	Y2332_gen_type [0] = Y2332_pgtype0;
	Y2332_gen_type [1] = Y2332_pgtype1;
	Y2332_gen_type [2] = Y2332_pgtype2;
	Y2332_gen_type [3] = Y2332_pgtype3;
	Y2332_gen_type [4] = Y2332_pgtype4;
	Y2332_gen_type [5] = Y2332_pgtype5;
	Y2332_gen_type [6] = Y2332_pgtype6;
	Y2332_gen_type [7] = Y2332_pgtype7;
	{long i; for (i = 0; i < 3; i++) Y2332[i] = 545;};
	{long i; for (i = 3; i < 5; i++) Y2332[i] = 556;};
	{long i; for (i = 5; i < 8; i++) Y2332[i] = 545;};
}

long O2333[8];
void O2333_init () {
	O2333[0] =  + _REFACS_3_;
	{long i; for (i = 1; i < 3; i++) O2333[i] =  + _REFACS_2_;}
	O2333[3] =  + _REFACS_3_;
	O2333[4] =  + _REFACS_2_;
	O2333[5] =  + _REFACS_3_;
	O2333[6] =  + _REFACS_2_;
	O2333[7] =  + _REFACS_3_;
}

long O2334[8];
void O2334_init () {
	O2334[0] =  + _REFACS_4_;
	{long i; for (i = 1; i < 3; i++) O2334[i] =  + _REFACS_3_;}
	O2334[3] =  + _REFACS_4_;
	O2334[4] =  + _REFACS_3_;
	O2334[5] =  + _REFACS_4_;
	O2334[6] =  + _REFACS_3_;
	O2334[7] =  + _REFACS_4_;
}

long O2335[8];
void O2335_init () {
	O2335[0] = + _LNGOFF_7_3_0_1_;
	O2335[1] = + _LNGOFF_5_3_0_1_;
	O2335[2] = + _LNGOFF_5_3_0_2_;
	O2335[3] = + _LNGOFF_6_3_0_1_;
	O2335[4] = + _LNGOFF_4_3_0_2_;
	O2335[5] = + _LNGOFF_7_4_0_1_;
	O2335[6] = + _LNGOFF_5_4_0_2_;
	O2335[7] = + _LNGOFF_9_3_0_1_;
}

long O2336[8];
void O2336_init () {
	O2336[0] = + _CHROFF_7_2_;
	{long i; for (i = 1; i < 3; i++) O2336[i] = + _CHROFF_5_2_;}
	O2336[3] = + _CHROFF_6_2_;
	O2336[4] = + _CHROFF_4_2_;
	O2336[5] = + _CHROFF_7_2_;
	O2336[6] = + _CHROFF_5_2_;
	O2336[7] = + _CHROFF_9_2_;
}

long O2337[8];
void O2337_init () {
	O2337[0] = + _LNGOFF_7_3_0_2_;
	O2337[1] = + _LNGOFF_5_3_0_2_;
	O2337[2] = + _LNGOFF_5_3_0_3_;
	O2337[3] = + _LNGOFF_6_3_0_2_;
	O2337[4] = + _LNGOFF_4_3_0_3_;
	O2337[5] = + _LNGOFF_7_4_0_2_;
	O2337[6] = + _LNGOFF_5_4_0_3_;
	O2337[7] = + _LNGOFF_9_3_0_2_;
}

long O2340[8];
void O2340_init () {
	O2340[0] = + _LNGOFF_7_3_0_3_;
	O2340[1] = + _LNGOFF_5_3_0_3_;
	O2340[2] = + _LNGOFF_5_3_0_4_;
	O2340[3] = + _LNGOFF_6_3_0_3_;
	O2340[4] = + _LNGOFF_4_3_0_4_;
	O2340[5] = + _LNGOFF_7_4_0_3_;
	O2340[6] = + _LNGOFF_5_4_0_4_;
	O2340[7] = + _LNGOFF_9_3_0_3_;
}

long O2341[8];
void O2341_init () {
	O2341[0] = + _LNGOFF_7_3_0_4_;
	O2341[1] = + _LNGOFF_5_3_0_4_;
	O2341[2] = + _LNGOFF_5_3_0_5_;
	O2341[3] = + _LNGOFF_6_3_0_4_;
	O2341[4] = + _LNGOFF_4_3_0_5_;
	O2341[5] = + _LNGOFF_7_4_0_4_;
	O2341[6] = + _LNGOFF_5_4_0_5_;
	O2341[7] = + _LNGOFF_9_3_0_4_;
}

long O2345[8];
void O2345_init () {
	O2345[0] = + _LNGOFF_7_3_0_5_;
	O2345[1] = + _LNGOFF_5_3_0_5_;
	O2345[2] = + _LNGOFF_5_3_0_6_;
	O2345[3] = + _LNGOFF_6_3_0_5_;
	O2345[4] = + _LNGOFF_4_3_0_6_;
	O2345[5] = + _LNGOFF_7_4_0_5_;
	O2345[6] = + _LNGOFF_5_4_0_6_;
	O2345[7] = + _LNGOFF_9_3_0_5_;
}

long O2346[8];
void O2346_init () {
	O2346[0] =  + _REFACS_5_;
	O2346[1] = + _PTROFF_5_3_0_7_0_1_;
	O2346[2] = + _LNGOFF_5_3_0_7_;
	O2346[3] =  + _REFACS_5_;
	O2346[4] = + _LNGOFF_4_3_0_7_;
	O2346[5] =  + _REFACS_5_;
	O2346[6] = + _LNGOFF_5_4_0_7_;
	O2346[7] =  + _REFACS_5_;
}

long O2347[8];
void O2347_init () {
	O2347[0] =  + _REFACS_6_;
	{long i; for (i = 1; i < 3; i++) O2347[i] =  + _REFACS_4_;}
	O2347[3] = + _LNGOFF_6_3_0_6_;
	O2347[4] = + _LNGOFF_4_3_0_8_;
	O2347[5] =  + _REFACS_6_;
	O2347[6] =  + _REFACS_4_;
	O2347[7] =  + _REFACS_6_;
}

long O2381[8];
void O2381_init () {
	O2381[0] = + _LNGOFF_7_3_0_6_;
	O2381[1] = + _LNGOFF_5_3_0_6_;
	O2381[2] = + _LNGOFF_5_3_0_8_;
	O2381[3] = + _LNGOFF_6_3_0_7_;
	O2381[4] = + _LNGOFF_4_3_0_9_;
	O2381[5] = + _LNGOFF_7_4_0_6_;
	O2381[6] = + _LNGOFF_5_4_0_8_;
	O2381[7] = + _LNGOFF_9_3_0_6_;
}

long O3353[11];
void O3353_init () {
	{long i; for (i = 0; i < 3; i++) O3353[i] = + _LNGOFF_0_0_0_0_;}
	{long i; for (i = 3; i < 5; i++) O3353[i] = + _LNGOFF_1_0_0_0_;}
	O3353[5] = + _LNGOFF_1_1_0_0_;
	{long i; for (i = 6; i < 8; i++) O3353[i] = + _LNGOFF_1_0_0_0_;}
	{long i; for (i = 8; i < 11; i++) O3353[i] = + _LNGOFF_1_1_0_0_;}
}

long O3354[11];
void O3354_init () {
	{long i; for (i = 0; i < 3; i++) O3354[i] = + _LNGOFF_0_0_0_1_;}
	{long i; for (i = 3; i < 5; i++) O3354[i] = + _LNGOFF_1_0_0_1_;}
	O3354[5] = + _LNGOFF_1_1_0_1_;
	{long i; for (i = 6; i < 8; i++) O3354[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 8; i < 11; i++) O3354[i] = + _LNGOFF_1_1_0_1_;}
}

long O3419[3];
void O3419_init () {
	{long i; for (i = 0; i < 2; i++) O3419[i] = + _LNGOFF_1_0_0_2_;}
	O3419[2] = + _LNGOFF_1_1_0_2_;
}

long O3499[5];
void O3499_init () {
	{long i; for (i = 0; i < 2; i++) O3499[i] = + _LNGOFF_1_0_0_2_;}
	{long i; for (i = 2; i < 5; i++) O3499[i] = + _LNGOFF_1_1_0_2_;}
}


#ifdef __cplusplus
}
#endif
