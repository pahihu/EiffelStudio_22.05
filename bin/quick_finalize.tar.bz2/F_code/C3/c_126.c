/*
 * Code for class C_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "c_126.h"
#include "stdio.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {C_FILE}.read_all */
void F533_2540 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTEAA("read_all", 532, Current, 2, 1, 4483);
	RTGC;
	RTHOOK(1);
	ti4_1 = F772_4667(RTCW(arg1));
	if ((EIF_BOOLEAN) (F530_2225(Current) > ti4_1)) {
		RTHOOK(2);
		ti4_1 = F530_2225(Current);
		F774_4791(RTCW(arg1), ti4_1);
	}
	RTHOOK(3);
	loc2 = *(EIF_REFERENCE *)(RTCW(arg1));
	RTHOOK(4);
	ti4_1 = F530_2225(Current);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_4_6_2_4_1_0_);
	loc1 = (EIF_INTEGER_32) fread(((void *) loc2), ((size_t) ((EIF_INTEGER_32) 1L)), ((size_t) ti4_1), ((FILE *) tp1));
	RTHOOK(5);
	F774_4808(RTCW(arg1), loc1);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {C_FILE}.fread */
EIF_INTEGER_32 F533_2541 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("fread", 532, Current, 0, 4, 4484);
	Result = (EIF_INTEGER_32) fread(((void *) arg1), ((size_t) arg2), ((size_t) arg3), ((FILE *) arg4));
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit126 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
