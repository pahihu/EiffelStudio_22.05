/*
 * Code for class MISMATCH_CORRECTOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "mi128.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {MISMATCH_CORRECTOR}.correct_mismatch */
void F633_2791 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("correct_mismatch", 632, Current, 2, 0, 6429);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(770, 0x00).id, 770, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = RTMS_EX_H("Mismatch: ",10,1538098208);
	F771_4555(RTCW(loc1), tr1);
	RTHOOK(2);
	loc2 = RTLNS(eif_new_type(72, 0x00).id, 72, _OBJSIZ_0_0_0_0_0_0_0_0_);
	RTHOOK(3);
	tr1 = F657_3086(RTCV((EIF_REFERENCE) eif_builtin_ANY_generating_type__t (Current)));
	F771_4594(RTCW(loc1), tr1);
	RTHOOK(4);
	F73_980(RTCW(loc2), loc1);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {MISMATCH_CORRECTOR}.mismatch_information */
static EIF_REFERENCE F633_2792_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("mismatch_information", 632, Current, 0, 0, 6430);
	RTGC;
	RTOSP (2792);
#define Result RTOSR(2792)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(653, 0x00).id, 653, _OBJSIZ_9_3_0_7_0_0_0_0_);
	F654_3010(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2792);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F633_2792 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2792,F633_2792_body,(Current));
}

void EIF_Minit128 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
