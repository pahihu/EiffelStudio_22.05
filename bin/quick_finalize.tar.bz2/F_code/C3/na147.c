/*
 * Code for class reference NATURAL_32
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "na147.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {NATURAL_32}.is_less */
EIF_BOOLEAN F702_3706 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_less", 701, Current, 0, 1, 9583);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(702, 0x00).id, 702, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_NATURAL_32 *)tr1 = arg1;
	Result = F701_3647(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_32}.plus */
EIF_NATURAL_32 F702_3707 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("plus", 701, Current, 0, 1, 9584);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(702, 0x00).id, 702, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_NATURAL_32 *)tr1 = arg1;
	tr1 = F701_3656(Current, tr1);
	Result = *(EIF_NATURAL_32 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_32}.integer_quotient */
EIF_NATURAL_32 F702_3712 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("integer_quotient", 701, Current, 0, 1, 9589);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(702, 0x00).id, 702, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_NATURAL_32 *)tr1 = arg1;
	tr1 = F701_3662(Current, tr1);
	Result = *(EIF_NATURAL_32 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_32}.integer_remainder */
EIF_NATURAL_32 F702_3713 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("integer_remainder", 701, Current, 0, 1, 9590);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(702, 0x00).id, 702, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_NATURAL_32 *)tr1 = arg1;
	tr1 = F701_3663(Current, tr1);
	Result = *(EIF_NATURAL_32 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_32}.as_natural_8 */
EIF_NATURAL_8 F702_3715 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_natural_8", 701, Current, 0, 0, 9592);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_8) F701_3668(Current);
}

/* {NATURAL_32}.as_natural_16 */
EIF_NATURAL_16 F702_3716 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_natural_16", 701, Current, 0, 0, 9593);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_16) F701_3669(Current);
}

/* {NATURAL_32}.as_natural_64 */
EIF_NATURAL_64 F702_3718 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_natural_64", 701, Current, 0, 0, 9595);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_64) F701_3671(Current);
}

/* {NATURAL_32}.as_integer_32 */
EIF_INTEGER_32 F702_3721 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("as_integer_32", 701, Current, 0, 0, 9598);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) F701_3674(Current);
}

/* {NATURAL_32}.to_character_8 */
EIF_CHARACTER_8 F702_3725 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("to_character_8", 701, Current, 0, 0, 9602);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_CHARACTER_8) F701_3693(Current);
}

/* {NATURAL_32}.to_character_32 */
EIF_CHARACTER_32 F702_3726 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("to_character_32", 701, Current, 0, 0, 9603);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_CHARACTER_32) F701_3694(Current);
}

/* {NATURAL_32}.bit_and */
EIF_NATURAL_32 F702_3727 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("bit_and", 701, Current, 0, 1, 9604);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(702, 0x00).id, 702, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_NATURAL_32 *)tr1 = arg1;
	tr1 = F701_3695(Current, tr1);
	Result = *(EIF_NATURAL_32 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_32}.bit_or */
EIF_NATURAL_32 F702_3728 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("bit_or", 701, Current, 0, 1, 9605);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(702, 0x00).id, 702, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_NATURAL_32 *)tr1 = arg1;
	tr1 = F701_3696(Current, tr1);
	Result = *(EIF_NATURAL_32 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {NATURAL_32}.bit_shift_right */
EIF_NATURAL_32 F702_3732 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("bit_shift_right", 701, Current, 0, 1, 9609);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return *(EIF_NATURAL_32 *)F701_3701(Current, arg1);
}

void EIF_Minit147 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
