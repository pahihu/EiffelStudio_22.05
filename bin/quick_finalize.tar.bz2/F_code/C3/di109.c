/*
 * Code for class DIRECTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "di109.h"
#include "eif_dir.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DIRECTORY}.make */
void F141_1675 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("make", 140, Current, 0, 1, 1780);
	RTHOOK(1);
	F141_1676(Current, arg1);
	RTHOOK(3);
	RTEE;
}

/* {DIRECTORY}.make_with_name */
void F141_1676 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("make_with_name", 140, Current, 0, 1, 1781);
	RTGC;
	RTHOOK(1);
	F141_1712(Current, arg1);
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current + O1600[Dtype(Current)-140]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {DIRECTORY}.make_open_read */
void F141_1678 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("make_open_read", 140, Current, 0, 1, 1783);
	RTGC;
	RTHOOK(1);
	F141_1675(Current, arg1);
	RTHOOK(2);
	F141_1685(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {DIRECTORY}.readentry */
void F141_1682 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("readentry", 140, Current, 0, 0, 1787);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O1594[dtype-140]);
	tp1 = (EIF_POINTER) eif_dir_next(tp1);
	*(EIF_POINTER *)(Current + O1595[dtype-140]) = (EIF_POINTER) tp1;
	RTHOOK(2);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current + O1595[dtype-140]) == tp1)) {
		RTHOOK(3);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) NULL;
	} else {
		RTHOOK(4);
		tr1 = RTOSCF(1722,F141_1722, (Current));
		tr1 = F139_1635(RTCW(tr1), *(EIF_POINTER *)(Current + O1595[dtype-140]));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {DIRECTORY}.name */
EIF_REFERENCE F141_1683 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("name", 140, Current, 0, 0, 1788);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F766_4405(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {DIRECTORY}.open_read */
void F141_1685 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("open_read", 140, Current, 0, 0, 1790);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(RTCV(F141_1714(Current))+ _PTROFF_0_1_0_1_0_0_);
	tp1 = (EIF_POINTER) eif_dir_open((EIF_FILENAME) tp1);
	*(EIF_POINTER *)(Current + O1594[dtype-140]) = (EIF_POINTER) tp1;
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current + O1600[dtype-140]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {DIRECTORY}.close */
void F141_1686 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("close", 140, Current, 0, 0, 1791);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O1594[dtype-140]);
	eif_dir_close(tp1);
	RTHOOK(2);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	*(EIF_POINTER *)(Current + O1594[dtype-140]) = (EIF_POINTER) tp2;
	RTHOOK(3);
	*(EIF_INTEGER_32 *)(Current + O1600[dtype-140]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {DIRECTORY}.start */
void F141_1687 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("start", 140, Current, 0, 0, 1792);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O1594[dtype-140]);
	tp2 = *(EIF_POINTER *)(RTCV(F141_1714(Current))+ _PTROFF_0_1_0_1_0_0_);
	tp1 = (EIF_POINTER) eif_dir_rewind((EIF_POINTER) tp1, (EIF_FILENAME) tp2);
	*(EIF_POINTER *)(Current + O1594[dtype-140]) = (EIF_POINTER) tp1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {DIRECTORY}.linear_representation */
EIF_REFERENCE F141_1693 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("linear_representation", 140, Current, 2, 0, 1798);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(140, 0x00).id, 140, _OBJSIZ_3_0_0_1_0_2_0_0_);
	F141_1678(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_1_));
	RTHOOK(2);
	{
		static EIF_TYPE_INDEX typarr0[] = {634,773,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 634, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F635_2825(RTCW(Result), ((EIF_INTEGER_32) 16L));
	RTHOOK(3);
	F141_1687(RTCW(loc1));
	RTHOOK(4);
	F141_1682(RTCW(loc1));
	RTHOOK(5);
	loc2 = *(EIF_POINTER *)(RTCW(loc1) + O1595[Dtype(loc1)-140]);
	for (;;) {
		RTHOOK(6);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(loc2 == tp1)) break;
		RTHOOK(7);
		tr1 = RTOSCF(1722,F141_1722, (Current));
		tr1 = F139_1635(RTCW(tr1), loc2);
		F635_2866(RTCW(Result), tr1);
		RTHOOK(8);
		F141_1682(RTCW(loc1));
		RTHOOK(9);
		loc2 = *(EIF_POINTER *)(RTCW(loc1) + O1595[Dtype(loc1)-140]);
	}
	RTHOOK(10);
	F141_1686(RTCW(loc1));
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {DIRECTORY}.is_closed */
EIF_BOOLEAN F141_1698 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_closed", 140, Current, 0, 0, 1803);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O1600[Dtype(Current)-140]) == ((EIF_INTEGER_32) 1L));
}

/* {DIRECTORY}.dispose */
void F141_1709 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("dispose", 140, Current, 0, 0, 1814);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !F141_1698(Current)) {
		RTHOOK(2);
		F141_1686(Current);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {DIRECTORY}.set_name */
void F141_1712 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_name", 140, Current, 0, 1, 1817);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	tr1 = RTOSCF(1722,F141_1722, (Current));
	tr1 = F139_1633(RTCW(tr1), arg1, *(EIF_REFERENCE *)(Current + _REFACS_2_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {DIRECTORY}.internal_name_pointer */
EIF_REFERENCE F141_1714 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("internal_name_pointer", 140, Current, 1, 0, 1819);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) loc1;
	} else {
		RTHOOK(4);
		RTCT0("internal_name_pointer_set", EX_CHECK);
			RTCF0;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {DIRECTORY}.file_info */
static EIF_REFERENCE F141_1722_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("file_info", 140, Current, 0, 0, 1827);
	RTGC;
	RTOSP (1722);
#define Result RTOSR(1722)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(138, 0x00).id, 138, _OBJSIZ_3_2_0_0_0_0_0_0_);
	F139_1616(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1722);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F141_1722 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1722,F141_1722_body,(Current));
}

/* {DIRECTORY}.dir_open */
EIF_POINTER F141_1724 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("dir_open", 140, Current, 0, 1, 1829);Result = (EIF_POINTER) eif_dir_open((EIF_FILENAME) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {DIRECTORY}.dir_rewind */
EIF_POINTER F141_1725 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("dir_rewind", 140, Current, 0, 2, 1830);Result = (EIF_POINTER) eif_dir_rewind((EIF_POINTER) arg1, (EIF_FILENAME) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {DIRECTORY}.dir_close */
void F141_1726 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("dir_close", 140, Current, 0, 1, 1831);eif_dir_close(arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {DIRECTORY}.eif_dir_next */
EIF_POINTER F141_1727 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("eif_dir_next", 140, Current, 0, 1, 1832);Result = (EIF_POINTER) eif_dir_next(arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit109 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
