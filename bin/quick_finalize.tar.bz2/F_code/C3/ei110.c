/*
 * Code for class EIFFEL_F_CODE_DIRECTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ei110.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EIFFEL_F_CODE_DIRECTORY}.make */
RTEOMS(1733,1);
void F142_1734 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN tb6;
	EIF_CHARACTER_8 tc1;
	RTCFDT;
	RTLD;
	
	RTLI(13);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLR(5,loc10);
	RTLR(6,loc9);
	RTLR(7,loc3);
	RTLR(8,loc5);
	RTLR(9,loc1);
	RTLR(10,tr2);
	RTLR(11,loc6);
	RTLR(12,loc2);
	RTLIU(13);
	
	RTEAA("make", 141, Current, 10, 3, 1857);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_) = (EIF_BOOLEAN) arg3;
	RTHOOK(2);
	tc1 = RTOSCF(699,F47_699, (Current));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	loc7 = F772_4660(RTCW(arg1), tc1, ti4_1);
	RTHOOK(3);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	loc4 = F774_4806(RTCW(arg1), (EIF_INTEGER_32) (loc7 + ((EIF_INTEGER_32) 1L)), ti4_1);
	RTHOOK(4);
	tr1 = RTOSCF(1747,F142_1747, (Current));
	tr1 = F774_4778(RTCW(tr1), loc4);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	RTHOOK(5);
	F141_1675(Current, arg1);
	RTHOOK(6);
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (arg2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(7);
	loc10 = RTLNS(eif_new_type(775, 0x00).id, 775, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F772_4648(RTCW(loc10), arg1);
	RTHOOK(8);
	tr1 = RTMS_EX_H("finished",8,1338032740);
	F776_4834(RTCW(loc10), tr1);
	RTHOOK(9);
	loc9 = RTLNS(eif_new_type(530, 0x00).id, 530, _OBJSIZ_5_7_2_4_1_1_2_1_);
	F530_2194(RTCW(loc9), loc10);
	RTHOOK(10);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1126[Dtype(RTCW(loc9))-530])(loc9);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_) = (EIF_BOOLEAN) tb1;
	RTHOOK(11);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_))) {
		RTHOOK(12);
		tr1 = F142_1749(Current, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0);
		loc3 = F142_1736(Current, tr1);
		RTHOOK(13);
		loc5 = RTLNS(eif_new_type(531, 0x00).id, 531, _OBJSIZ_4_6_2_4_1_1_2_1_);
		F530_2194(RTCW(loc5), loc3);
		RTHOOK(14);
		tb1 = F530_2230(RTCW(loc5));
		if (tb1) {
			RTHOOK(15);
			F530_2328(RTCW(loc5));
		}
		RTHOOK(16);
		tr1 = F142_1749(Current, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 1);
		loc3 = F142_1736(Current, tr1);
		RTHOOK(17);
		loc5 = RTLNS(eif_new_type(531, 0x00).id, 531, _OBJSIZ_4_6_2_4_1_1_2_1_);
		F530_2194(RTCW(loc5), loc3);
		RTHOOK(18);
		tb1 = F530_2230(RTCW(loc5));
		if (tb1) {
			RTHOOK(19);
			F530_2328(RTCW(loc5));
		}
		RTHOOK(20);
		tr1 = F142_1749(Current, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
		loc3 = F142_1736(Current, tr1);
		RTHOOK(21);
		loc5 = RTLNS(eif_new_type(531, 0x00).id, 531, _OBJSIZ_4_6_2_4_1_1_2_1_);
		F530_2194(RTCW(loc5), loc3);
		RTHOOK(22);
		tb1 = F530_2230(RTCW(loc5));
		if (tb1) {
			RTHOOK(23);
			F530_2328(RTCW(loc5));
		}
		RTHOOK(24);
		tr1 = F142_1749(Current, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 1);
		loc3 = F142_1736(Current, tr1);
		RTHOOK(25);
		loc5 = RTLNS(eif_new_type(531, 0x00).id, 531, _OBJSIZ_4_6_2_4_1_1_2_1_);
		F530_2194(RTCW(loc5), loc3);
		RTHOOK(26);
		tb1 = F530_2230(RTCW(loc5));
		if (tb1) {
			RTHOOK(27);
			F530_2328(RTCW(loc5));
		}
	}
	RTHOOK(28);
	{
		static EIF_TYPE_INDEX typarr0[] = {634,773,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F635_2825(RTCW(tr1), ((EIF_INTEGER_32) 100L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTHOOK(29);
	{
		static EIF_TYPE_INDEX typarr0[] = {634,773,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F635_2825(RTCW(tr1), ((EIF_INTEGER_32) 100L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	RTHOOK(30);
	{
		static EIF_TYPE_INDEX typarr0[] = {634,773,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F635_2825(RTCW(tr1), ((EIF_INTEGER_32) 100L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTHOOK(31);
	{
		static EIF_TYPE_INDEX typarr0[] = {634,773,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F635_2825(RTCW(tr1), ((EIF_INTEGER_32) 100L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	RTHOOK(32);
	{
		static EIF_TYPE_INDEX typarr0[] = {634,141,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F635_2825(RTCW(tr1), ((EIF_INTEGER_32) 100L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	RTHOOK(33);
	loc1 = F141_1693(Current);
	RTHOOK(34);
	F635_2856(RTCW(loc1));
	for (;;) {
		RTHOOK(35);
		tb1 = F583_2710(RTCW(loc1));
		if (tb1) break;
		RTHOOK(36);
		tb2 = '\0';
		tr1 = F635_2830(RTCW(loc1));
		tr2 = RTMS_EX_H(".",1,46);
		tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(tr1))-10])(tr1, tr2);
		if ((EIF_BOOLEAN) !tb3) {
			tr1 = F635_2830(RTCW(loc1));
			tr2 = RTMS_EX_H("..",2,11822);
			tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(tr1))-10])(tr1, tr2);
			tb2 = (EIF_BOOLEAN) !tb3;
		}
		if (tb2) {
			RTHOOK(37);
			tr1 = F635_2830(RTCW(loc1));
			loc3 = F142_1736(Current, tr1);
			RTHOOK(38);
			loc5 = RTLNS(eif_new_type(531, 0x00).id, 531, _OBJSIZ_4_6_2_4_1_1_2_1_);
			F530_2194(RTCW(loc5), loc3);
			RTHOOK(39);
			tb2 = '\0';
			tb3 = F530_2239(RTCW(loc5));
			if (tb3) {
				tb3 = '\01';
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_1_1_0_2_);
				if (!(EIF_BOOLEAN) (ti4_1 < ((EIF_INTEGER_32) 2L))) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_1_1_0_2_);
					ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_1_1_0_2_);
					tr1 = F774_4806(RTCW(loc3), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)), ti4_2);
					tb4 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(tr1))-10])(tr1, RTOMS(1733,0));
					tb3 = (EIF_BOOLEAN) !tb4;
				}
				tb2 = tb3;
			}
			if (tb2) {
				RTHOOK(40);
				loc6 = RTLNS(eif_new_type(141, 0x00).id, 141, _OBJSIZ_11_2_0_1_0_2_0_0_);
				F142_1734(RTCW(loc6), loc3, arg2, (EIF_BOOLEAN) 0);
				RTHOOK(41);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
				F635_2866(RTCW(tr1), loc6);
				RTHOOK(42);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
				F635_2858(RTCW(tr1));
			} else {
				RTHOOK(43);
				tr1 = F635_2830(RTCW(loc1));
				tr2 = RTMS_EX_H("Makefile.SH",11,49987912);
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(tr1))-10])(tr1, tr2);
				if (tb2) {
					RTHOOK(44);
					tr1 = RTLNSMART(eif_new_type(530, 0).id);
					F530_2194(RTCW(tr1), loc3);
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
				} else {
					RTHOOK(45);
					loc2 = F635_2830(RTCW(loc1));
					RTHOOK(46);
					loc8 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
					RTHOOK(47);
					tb2 = '\0';
					tb3 = '\0';
					tb4 = '\0';
					tb5 = '\0';
					tr1 = RTMS_EX_H("edynlib.c",9,147342947);
					tb6 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(loc2))-10])(loc2, tr1);
					if ((EIF_BOOLEAN) !tb6) {
						tr1 = RTMS_EX_H("egc_dynlib.c",12,1185231715);
						tb6 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(loc2))-10])(loc2, tr1);
						tb5 = (EIF_BOOLEAN) !tb6;
					}
					if (tb5) {
						tr1 = RTMS_EX_H("emain.c",7,1279325283);
						tb5 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(loc2))-10])(loc2, tr1);
						tb4 = (EIF_BOOLEAN) !tb5;
					}
					if (tb4) {
						tb3 = (EIF_BOOLEAN) (loc8 > ((EIF_INTEGER_32) 3L));
					}
					if (tb3) {
						tr1 = RTMS_EX_H(".",1,46);
						ti4_1 = F772_4664(RTCW(loc2), tr1, ((EIF_INTEGER_32) 1L));
						tb2 = (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L));
					}
					if (tb2) {
						RTHOOK(48);
						tr1 = RTMS_EX_H(".c",2,11875);
						ti4_1 = F772_4664(RTCW(loc2), tr1, ((EIF_INTEGER_32) 1L));
						if ((EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (loc8 - ((EIF_INTEGER_32) 1L)))) {
							RTHOOK(49);
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
							F635_2866(RTCW(tr1), loc2);
							RTHOOK(50);
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
							F635_2858(RTCW(tr1));
						} else {
							RTHOOK(51);
							tr1 = RTMS_EX_H(".cpp",4,778268784);
							ti4_1 = F772_4664(RTCW(loc2), tr1, ((EIF_INTEGER_32) 1L));
							if ((EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (loc8 - ((EIF_INTEGER_32) 3L)))) {
								RTHOOK(52);
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
								F635_2866(RTCW(tr1), loc2);
								RTHOOK(53);
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
								F635_2858(RTCW(tr1));
							} else {
								RTHOOK(54);
								tr1 = RTMS_EX_H(".x",2,11896);
								ti4_1 = F772_4664(RTCW(loc2), tr1, ((EIF_INTEGER_32) 1L));
								if ((EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (loc8 - ((EIF_INTEGER_32) 1L)))) {
									RTHOOK(55);
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
									F635_2866(RTCW(tr1), loc3);
									RTHOOK(56);
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
									F635_2858(RTCW(tr1));
								} else {
									RTHOOK(57);
									tr1 = RTMS_EX_H(".xpp",4,779645040);
									ti4_1 = F772_4664(RTCW(loc2), tr1, ((EIF_INTEGER_32) 1L));
									if ((EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (loc8 - ((EIF_INTEGER_32) 3L)))) {
										RTHOOK(58);
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
										F635_2866(RTCW(tr1), loc3);
										RTHOOK(59);
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
										F635_2858(RTCW(tr1));
									}
								}
							}
						}
					}
				}
			}
		}
		RTHOOK(60);
		F635_2858(RTCW(loc1));
	}
	RTHOOK(62);
	RTLE;
	RTEE;
}

/* {EIFFEL_F_CODE_DIRECTORY}.concat */
void F142_1735 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc6);
	RTLIU(5);
	
	RTEAA("concat", 141, Current, 6, 0, 1858);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		loc1 = F349_2097(RTCW(tr1));
		RTHOOK(3);
		F635_2856(RTCW(loc1));
		for (;;) {
			RTHOOK(4);
			tb1 = F583_2710(RTCW(loc1));
			if (tb1) break;
			RTHOOK(5);
			tr1 = F635_2830(RTCW(loc1));
			F142_1735(RTCW(tr1));
			RTHOOK(6);
			F635_2858(RTCW(loc1));
		}
	} else {
		RTHOOK(7);
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_8_) != NULL)) {
			RTHOOK(8);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			tb2 = F468_2169(RTCW(tr1));
			if ((EIF_BOOLEAN) !tb2) {
				RTHOOK(9);
				loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				RTHOOK(10);
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_)) {
					RTHOOK(11);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
					tr2 = F142_1749(Current, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
					F142_1750(Current, tr1, tr2);
				}
			}
			RTHOOK(12);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			tb2 = F468_2169(RTCW(tr1));
			if ((EIF_BOOLEAN) !tb2) {
				RTHOOK(13);
				loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				RTHOOK(14);
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_)) {
					RTHOOK(15);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
					tr2 = F142_1749(Current, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 1);
					F142_1750(Current, tr1, tr2);
				}
			}
			RTHOOK(16);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tb2 = F468_2169(RTCW(tr1));
			if ((EIF_BOOLEAN) !tb2) {
				RTHOOK(17);
				loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				RTHOOK(18);
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_)) {
					RTHOOK(19);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
					tr2 = F142_1749(Current, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0);
					F142_1751(Current, tr1, tr2);
				}
			}
			RTHOOK(20);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			tb2 = F468_2169(RTCW(tr1));
			if ((EIF_BOOLEAN) !tb2) {
				RTHOOK(21);
				loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				RTHOOK(22);
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_)) {
					RTHOOK(23);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
					tr2 = F142_1749(Current, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 1);
					F142_1751(Current, tr1, tr2);
				}
			}
			RTHOOK(24);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			F530_2265(RTCW(tr1));
			RTHOOK(25);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R1918[Dtype(RTCW(tr2))-530])(tr2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R1182[Dtype(RTCW(tr1))-530])(tr1, ti4_1);
			RTHOOK(26);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			F530_2282(RTCW(tr1));
			RTHOOK(27);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			tr2 = RTMS_EX_H("OLDOBJECTS",10,1464389715);
			ti4_1 = F772_4664(RTCW(tr1), tr2, ((EIF_INTEGER_32) 1L));
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
				RTHOOK(28);
				loc6 = RTMS_EX_H("OBJECTS = ",10,372367136);
				RTHOOK(29);
				if (loc2) {
					RTHOOK(30);
					tr1 = F142_1749(Current, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
					F774_4759(RTCW(loc6), tr1);
					RTHOOK(31);
					tr1 = RTMS_EX_H(" ",1,32);
					F774_4759(RTCW(loc6), tr1);
				}
				RTHOOK(32);
				if (loc3) {
					RTHOOK(33);
					tr1 = F142_1749(Current, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 1);
					F774_4759(RTCW(loc6), tr1);
					RTHOOK(34);
					tr1 = RTMS_EX_H(" ",1,32);
					F774_4759(RTCW(loc6), tr1);
				}
				RTHOOK(35);
				if (loc4) {
					RTHOOK(36);
					tr1 = F142_1749(Current, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0);
					F774_4759(RTCW(loc6), tr1);
					RTHOOK(37);
					tr1 = RTMS_EX_H(" ",1,32);
					F774_4759(RTCW(loc6), tr1);
				}
				RTHOOK(38);
				if (loc5) {
					RTHOOK(39);
					tr1 = F142_1749(Current, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 1);
					F774_4759(RTCW(loc6), tr1);
				}
				RTHOOK(40);
				tr1 = RTMS_EX_H("\012\012",2,2570);
				tr2 = RTMS_EX_H("OLDOBJECTS = ",13,229234720);
				tr1 = F774_4778(tr1, tr2);
				F774_4759(RTCW(loc6), tr1);
				RTHOOK(41);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
				tr2 = RTMS_EX_H("OBJECTS =",9,521547325);
				F774_4736(RTCW(tr1), tr2, loc6);
				RTHOOK(42);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
				F530_2266(RTCW(tr1));
				RTHOOK(43);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
				tr2 = *(EIF_REFERENCE *)(RTCW(tr2));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1139[Dtype(RTCW(tr1))-530])(tr1, tr2);
				RTHOOK(44);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
				tr2 = RTMS_EX_H("\012",1,10);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1139[Dtype(RTCW(tr1))-530])(tr1, tr2);
				RTHOOK(45);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
				F530_2282(RTCW(tr1));
			}
		} else {
			RTHOOK(46);
			tr1 = RTOSCF(24,F1_24, (Current));
			tr2 = RTMS_EX_H("WARNING: Directory \'",20,744494375);
			F26_442(RTCW(tr1), tr2);
			RTHOOK(47);
			tr1 = RTOSCF(24,F1_24, (Current));
			tr2 = F141_1683(Current);
			F26_442(RTCW(tr1), tr2);
			RTHOOK(48);
			tr1 = RTOSCF(24,F1_24, (Current));
			tr2 = RTMS_EX_H("\'\012has not been generated by the ISE Eiffel compiler.\012",53,965516042);
			F26_442(RTCW(tr1), tr2);
		}
	}
	RTHOOK(49);
	RTLE;
	RTEE;
}

/* {EIFFEL_F_CODE_DIRECTORY}.path_name */
EIF_REFERENCE F142_1736 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("path_name", 141, Current, 0, 1, 1840);
	RTGC;
	RTHOOK(1);
	Result = (EIF_REFERENCE) eif_builtin_ANY_twin__o (F141_1683(Current));
	RTHOOK(2);
	tc1 = RTOSCF(699,F47_699, (Current));
	F774_4772(RTCW(Result), tc1);
	RTHOOK(3);
	F774_4759(RTCW(Result), arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {EIFFEL_F_CODE_DIRECTORY}.big_file_prefix */

EIF_REFERENCE F142_1747 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1747,RTMS_EX_H("big_file_",9,1620382303));
}

/* {EIFFEL_F_CODE_DIRECTORY}.buffered_input_string */
static EIF_REFERENCE F142_1748_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("buffered_input_string", 141, Current, 0, 0, 1852);
	RTGC;
	RTOSP (1748);
#define Result RTOSR(1748)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(773, 0x00).id, 773, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F772_4646(RTCW(tr1), ((EIF_INTEGER_32) 10000000L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1748);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F142_1748 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1748,F142_1748_body,(Current));
}

/* {EIFFEL_F_CODE_DIRECTORY}.big_file_name */
EIF_REFERENCE F142_1749 (EIF_REFERENCE Current, EIF_BOOLEAN arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("big_file_name", 141, Current, 0, 3, 1853);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(773, 0x00).id, 773, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	F772_4646(RTCW(Result), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 8L)));
	RTHOOK(2);
	F774_4759(RTCW(Result), *(EIF_REFERENCE *)(Current + _REFACS_10_));
	RTHOOK(3);
	if (arg2) {
		RTHOOK(4);
		if (arg3) {
			RTHOOK(5);
			if (arg1) {
				RTHOOK(6);
				tr1 = RTMS_EX_H("_cpp.",5,1669042734);
				tr1 = F774_4778(tr1, *(EIF_REFERENCE *)(Current + _REFACS_3_));
				F774_4759(RTCW(Result), tr1);
			} else {
				RTHOOK(7);
				tr1 = RTMS_EX_H("_cpp.cpp",8,1457513840);
				F774_4759(RTCW(Result), tr1);
			}
		} else {
			RTHOOK(8);
			if (arg1) {
				RTHOOK(9);
				tr1 = RTMS_EX_H("_c.",3,6251310);
				tr1 = F774_4778(tr1, *(EIF_REFERENCE *)(Current + _REFACS_3_));
				F774_4759(RTCW(Result), tr1);
			} else {
				RTHOOK(10);
				tr1 = RTMS_EX_H("_c.c",4,1600335459);
				F774_4759(RTCW(Result), tr1);
			}
		}
	} else {
		RTHOOK(11);
		if (arg3) {
			RTHOOK(12);
			if (arg1) {
				RTHOOK(13);
				tr1 = RTMS_EX_H("_xpp.",5,2021364270);
				tr1 = F774_4778(tr1, *(EIF_REFERENCE *)(Current + _REFACS_3_));
				F774_4759(RTCW(Result), tr1);
			} else {
				RTHOOK(14);
				tr1 = RTMS_EX_H("_xpp.xpp",8,1291137136);
				F774_4759(RTCW(Result), tr1);
			}
		} else {
			RTHOOK(15);
			if (arg1) {
				RTHOOK(16);
				tr1 = RTMS_EX_H("_x.",3,6256686);
				tr1 = F774_4778(tr1, *(EIF_REFERENCE *)(Current + _REFACS_3_));
				F774_4759(RTCW(Result), tr1);
			} else {
				RTHOOK(17);
				tr1 = RTMS_EX_H("_x.x",4,1601711736);
				F774_4759(RTCW(Result), tr1);
			}
		}
	}
	RTHOOK(20);
	RTLE;
	RTEE;
	return Result;
}

/* {EIFFEL_F_CODE_DIRECTORY}.fake_concat_files */
void F142_1750 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,arg2);
	RTLR(4,loc2);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTEAA("fake_concat_files", 141, Current, 2, 2, 1854);
	RTGC;
	RTHOOK(1);
	tb1 = F468_2169(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(2);
		loc1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (F141_1683(Current));
		RTHOOK(3);
		tc1 = RTOSCF(699,F47_699, (Current));
		F774_4772(RTCW(loc1), tc1);
		RTHOOK(4);
		F774_4759(RTCW(loc1), arg2);
		RTHOOK(5);
		loc2 = RTLNS(eif_new_type(531, 0x00).id, 531, _OBJSIZ_4_6_2_4_1_1_2_1_);
		F530_2198(RTCW(loc2), loc1);
		RTHOOK(6);
		F635_2856(RTCW(arg1));
		for (;;) {
			RTHOOK(7);
			tb1 = F583_2710(RTCW(arg1));
			if (tb1) break;
			RTHOOK(8);
			tr1 = RTMS_EX_H("#include \"",10,164728098);
			F530_2304(RTCW(loc2), tr1);
			RTHOOK(9);
			tr1 = F635_2830(RTCW(arg1));
			F530_2304(RTCW(loc2), tr1);
			RTHOOK(10);
			tr1 = RTMS_EX_H("\"\012",2,8714);
			F530_2304(RTCW(loc2), tr1);
			RTHOOK(11);
			F635_2858(RTCW(arg1));
		}
		RTHOOK(12);
		F530_2282(RTCW(loc2));
	}
	RTHOOK(13);
	RTLE;
	RTEE;
}

/* {EIFFEL_F_CODE_DIRECTORY}.concat_files */
void F142_1751 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(8);
	RTLR(0,arg1);
	RTLR(1,loc2);
	RTLR(2,Current);
	RTLR(3,loc1);
	RTLR(4,arg2);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,tr1);
	RTLIU(8);
	
	RTEAA("concat_files", 141, Current, 4, 2, 1855);
	RTGC;
	RTHOOK(1);
	tb1 = F468_2169(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(2);
		loc2 = RTOSCF(1748,F142_1748, (Current));
		RTHOOK(3);
		loc1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (F141_1683(Current));
		RTHOOK(4);
		tc1 = RTOSCF(699,F47_699, (Current));
		F774_4772(RTCW(loc1), tc1);
		RTHOOK(5);
		F774_4759(RTCW(loc1), arg2);
		RTHOOK(6);
		loc3 = RTLNS(eif_new_type(531, 0x00).id, 531, _OBJSIZ_4_6_2_4_1_1_2_1_);
		F530_2198(RTCW(loc3), loc1);
		RTHOOK(7);
		loc4 = RTLNS(eif_new_type(532, 0x00).id, 532, _OBJSIZ_4_6_2_4_1_1_2_1_);
		tr1 = RTMS_EX_H("test",4,1952805748);
		F530_2194(RTCW(loc4), tr1);
		RTHOOK(8);
		F635_2856(RTCW(arg1));
		for (;;) {
			RTHOOK(9);
			tb1 = F583_2710(RTCW(arg1));
			if (tb1) break;
			RTHOOK(10);
			tr1 = F635_2830(RTCW(arg1));
			F530_2194(RTCW(loc4), tr1);
			RTHOOK(11);
			F530_2265(RTCW(loc4));
			RTHOOK(12);
			F533_2540(RTCW(loc4), loc2);
			RTHOOK(13);
			F530_2304(RTCW(loc3), loc2);
			RTHOOK(14);
			F530_2282(RTCW(loc4));
			RTHOOK(15);
			F635_2858(RTCW(arg1));
		}
		RTHOOK(16);
		F530_2282(RTCW(loc3));
	}
	RTHOOK(17);
	RTLE;
	RTEE;
}

void EIF_Minit110 (void)
{
	GTCX
	RTPOMS(1733,0,"E1",2,17713);
}


#ifdef __cplusplus
}
#endif
