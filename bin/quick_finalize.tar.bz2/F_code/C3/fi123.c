/*
 * Code for class FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "fi123.h"
#include "eif_file.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {FILE}.make */
void F530_2194 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("make", 529, Current, 0, 1, 4356);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1932[Dtype(Current)-530])(Current, arg1);
	RTHOOK(4);
	RTEE;
}

/* {FILE}.make_with_name */
void F530_2195 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("make_with_name", 529, Current, 0, 1, 4357);
	RTGC;
	RTHOOK(1);
	F530_2358(Current, arg1);
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current + O2084[dtype-529]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(3);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	*(EIF_POINTER *)(Current + O1945[dtype-529]) = (EIF_POINTER) tp2;
	RTHOOK(4);
	tr1 = RTLNSMART(eif_new_type(773, 0).id);
	F766_4349(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {FILE}.make_open_write */
void F530_2198 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("make_open_write", 529, Current, 0, 1, 4360);
	RTGC;
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1932[Dtype(Current)-530])(Current, arg1);
	RTHOOK(2);
	F530_2266(Current);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {FILE}.item */
EIF_CHARACTER_8 F530_2207 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("item", 529, Current, 0, 0, 4156);
	RTGC;
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R1169[dtype-530])(Current);
	RTHOOK(2);
	Result = *(EIF_CHARACTER_8 *)(Current + O1109[dtype-115]);
	RTHOOK(3);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R1879[dtype-530])(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {FILE}.descriptor_available */
EIF_BOOLEAN F530_2210 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current + O2093[Dtype(Current)-529]);
}


/* {FILE}.count */
EIF_INTEGER_32 F530_2225 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("count", 529, Current, 0, 0, 4174);
	RTGC;
	RTHOOK(1);
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1126[dtype-530])(Current)) {
		RTHOOK(2);
		if ((EIF_BOOLEAN) !F530_2256(Current)) {
			RTHOOK(3);
			F530_2366(Current);
			RTHOOK(4);
			Result = F139_1620(RTCV(RTOSCF(2364,F530_2364, (Current))));
		} else {
			RTHOOK(5);
			tp1 = *(EIF_POINTER *)(Current + O1945[dtype-529]);
			Result = (EIF_INTEGER_32) eif_file_size((FILE*) tp1);
			RTHOOK(6);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) Result;
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {FILE}.after */
EIF_BOOLEAN F530_2226 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("after", 529, Current, 0, 0, 4175);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	if ((EIF_BOOLEAN) !F530_2254(Current)) {
		tb1 = '\01';
		if (!(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1957[dtype-530])(Current)) {
			tb1 = (EIF_BOOLEAN)((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R1918[dtype-530])(Current) == ((EIF_INTEGER_32) 0L));
		}
		Result = tb1;
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {FILE}.off */
EIF_BOOLEAN F530_2228 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("off", 529, Current, 0, 0, 4177);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	tb1 = '\01';
	if (!(EIF_BOOLEAN)((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R1918[dtype-530])(Current) == ((EIF_INTEGER_32) 0L))) {
		tb1 = F530_2254(Current);
	}
	if (!tb1) {
		Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1957[dtype-530])(Current);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {FILE}.end_of_file */
EIF_BOOLEAN F530_2229 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	
	
	RTEAA("end_of_file", 529, Current, 0, 0, 4178);
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O1945[Dtype(Current)-529]);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) EIF_TEST(eif_file_feof((FILE*) tp1));
}

/* {FILE}.exists */
EIF_BOOLEAN F530_2230 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("exists", 529, Current, 0, 0, 4179);
	RTGC;
	RTHOOK(1);
	if (F530_2254(Current)) {
		RTHOOK(2);
		tp1 = *(EIF_POINTER *)(RTCV(F530_2356(Current))+ _PTROFF_0_1_0_1_0_0_);
		Result = (EIF_BOOLEAN) EIF_TEST(eif_file_exists((EIF_FILENAME) tp1));
	} else {
		RTHOOK(3);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {FILE}.is_directory */
EIF_BOOLEAN F530_2239 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_directory", 529, Current, 0, 0, 4188);
	RTGC;
	RTHOOK(1);
	F530_2366(Current);
	RTHOOK(2);
	Result = F139_1641(RTCV(RTOSCF(2364,F530_2364, (Current))));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {FILE}.is_closed */
EIF_BOOLEAN F530_2254 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_closed", 529, Current, 0, 0, 4203);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O2084[Dtype(Current)-529]) == ((EIF_INTEGER_32) 0L));
}

/* {FILE}.is_open_write */
EIF_BOOLEAN F530_2256 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTCDT;
	
	
	RTEAA("is_open_write", 529, Current, 0, 0, 4205);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O2084[dtype-529]) == ((EIF_INTEGER_32) 2L)) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O2084[dtype-529]) == ((EIF_INTEGER_32) 4L))) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O2084[dtype-529]) == ((EIF_INTEGER_32) 5L))) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O2084[dtype-529]) == ((EIF_INTEGER_32) 3L)));
}

/* {FILE}.open_read */
void F530_2265 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("open_read", 529, Current, 0, 0, 4214);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(RTCV(F530_2356(Current))+ _PTROFF_0_1_0_1_0_0_);
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32)) R2026[dtype-530])(Current, tp1, ((EIF_INTEGER_32) 0L));
	*(EIF_POINTER *)(Current + O1945[dtype-529]) = (EIF_POINTER) tp1;
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current + O2084[dtype-529]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {FILE}.open_write */
void F530_2266 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("open_write", 529, Current, 0, 0, 4215);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(RTCV(F530_2356(Current))+ _PTROFF_0_1_0_1_0_0_);
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32)) R2026[dtype-530])(Current, tp1, ((EIF_INTEGER_32) 1L));
	*(EIF_POINTER *)(Current + O1945[dtype-529]) = (EIF_POINTER) tp1;
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current + O2084[dtype-529]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {FILE}.close */
void F530_2282 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("close", 529, Current, 0, 0, 4231);
	RTGC;
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER)) R2027[dtype-530])(Current, *(EIF_POINTER *)(Current + O1945[dtype-529]));
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current + O2084[dtype-529]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(3);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	*(EIF_POINTER *)(Current + O1945[dtype-529]) = (EIF_POINTER) tp2;
	RTHOOK(4);
	*(EIF_BOOLEAN *)(Current + O2093[dtype-529]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {FILE}.start */
void F530_2283 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	
	
	RTEAA("start", 529, Current, 0, 0, 4232);
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O1945[Dtype(Current)-529]);
	eif_file_go((FILE*) tp1, (EIF_INTEGER) ((EIF_INTEGER_32) 0L));
	RTHOOK(2);
	RTEE;
}

/* {FILE}.forth */
void F530_2285 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_CHARACTER_8 tc1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("forth", 529, Current, 0, 0, 4234);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O1945[dtype-529]);
	eif_file_move((FILE*) tp1, (EIF_INTEGER) ((EIF_INTEGER_32) 1L));
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current + O1945[dtype-529]);
	tc1 = (EIF_CHARACTER_8) eif_file_gc((FILE*) tp1);
	eif_do_nothing_value.it_c1 = tc1;
	RTHOOK(3);
	if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1957[dtype-530])(Current)) {
		RTHOOK(4);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R1879[dtype-530])(Current);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {FILE}.back */
void F530_2286 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	
	
	RTEAA("back", 529, Current, 0, 0, 4235);
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O1945[Dtype(Current)-529]);
	eif_file_move((FILE*) tp1, (EIF_INTEGER) ((EIF_INTEGER_32) -1L));
	RTHOOK(2);
	RTEE;
}

/* {FILE}.put_string */
void F530_2304 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,loc2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("put_string", 529, Current, 2, 1, 4245);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O3499[Dtype(arg1)-771]);
	RTHOOK(2);
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(3);
		loc2 = *(EIF_REFERENCE *)(RTCW(arg1));
		RTHOOK(4);
		tp1 = *(EIF_POINTER *)(Current + O1945[Dtype(Current)-529]);
		eif_file_ps((FILE*) tp1, (char*) loc2, (EIF_INTEGER) loc1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {FILE}.delete */
void F530_2328 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("delete", 529, Current, 0, 0, 4269);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(RTCV(F530_2356(Current))+ _PTROFF_0_1_0_1_0_0_);
	eif_file_unlink((EIF_FILENAME) tp1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {FILE}.read_character */
void F530_2337 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_CHARACTER_8 tc1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("read_character", 529, Current, 0, 0, 4272);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O1945[dtype-529]);
	tc1 = (EIF_CHARACTER_8) eif_file_gc((FILE*) tp1);
	*(EIF_CHARACTER_8 *)(Current + O1109[dtype-115]) = (EIF_CHARACTER_8) tc1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {FILE}.read_stream */
void F530_2344 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTEAA("read_stream", 529, Current, 2, 1, 4277);
	RTGC;
	RTHOOK(1);
	loc2 = *(EIF_REFERENCE *)(Current);
	RTHOOK(2);
	F774_4792(RTCW(loc2), arg1);
	RTHOOK(3);
	loc1 = *(EIF_REFERENCE *)(RTCW(loc2));
	RTHOOK(4);
	tp1 = *(EIF_POINTER *)(Current + O1945[Dtype(Current)-529]);
	ti4_1 = (EIF_INTEGER_32) eif_file_gss((FILE*) tp1, (char*) loc1, (EIF_INTEGER) arg1);
	F774_4808(RTCW(loc2), ti4_1);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {FILE}.file_open */
EIF_POINTER F530_2353 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("file_open", 529, Current, 0, 2, 4285);Result = (EIF_POINTER) eif_file_open((EIF_FILENAME) arg1, (int) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {FILE}.file_close */
void F530_2354 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("file_close", 529, Current, 0, 1, 4286);eif_file_close((FILE*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {FILE}.internal_name_pointer */
EIF_REFERENCE F530_2356 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("internal_name_pointer", 529, Current, 1, 0, 4288);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) loc1;
	} else {
		RTHOOK(4);
		RTCT0("internal_name_pointer_set", EX_CHECK);
			RTCF0;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {FILE}.set_name */
void F530_2358 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_name", 529, Current, 0, 1, 4290);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	tr1 = RTOSCF(2364,F530_2364, (Current));
	tr1 = F139_1633(RTCW(tr1), arg1, *(EIF_REFERENCE *)(Current + _REFACS_2_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {FILE}.buffered_file_info */
static EIF_REFERENCE F530_2364_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("buffered_file_info", 529, Current, 0, 0, 4296);
	RTGC;
	RTOSP (2364);
#define Result RTOSR(2364)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(138, 0x00).id, 138, _OBJSIZ_3_2_0_0_0_0_0_0_);
	F139_1616(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2364);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F530_2364 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2364,F530_2364_body,(Current));
}

/* {FILE}.read_data_buffer */
static EIF_REFERENCE F530_2365_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("read_data_buffer", 529, Current, 0, 0, 4297);
	RTGC;
	RTOSP (2365);
#define Result RTOSR(2365)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(65, 0x00).id, 65, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F66_919(RTCW(tr1), ((EIF_INTEGER_32) 256L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2365);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F530_2365 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2365,F530_2365_body,(Current));
}

/* {FILE}.set_buffer */
void F530_2366 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("set_buffer", 529, Current, 0, 0, 4298);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(2364,F530_2364, (Current));
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr3 = F530_2356(Current);
	F139_1663(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {FILE}.file_unlink */
void F530_2368 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("file_unlink", 529, Current, 0, 1, 4300);eif_file_unlink((EIF_FILENAME) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {FILE}.file_gc */
EIF_CHARACTER_8 F530_2373 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("file_gc", 529, Current, 0, 1, 4305);
	EIF_ENTER_C;Result = (EIF_CHARACTER_8) eif_file_gc((FILE*) arg1);
	
	EIF_EXIT_C;
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {FILE}.file_gss */
EIF_INTEGER_32 F530_2375 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("file_gss", 529, Current, 0, 3, 4307);Result = (EIF_INTEGER_32) eif_file_gss((FILE*) arg1, (char*) arg2, (EIF_INTEGER) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {FILE}.file_size */
EIF_INTEGER_32 F530_2381 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("file_size", 529, Current, 0, 1, 4313);Result = (EIF_INTEGER_32) eif_file_size((FILE*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {FILE}.file_ps */
void F530_2393 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("file_ps", 529, Current, 0, 3, 4325);
	EIF_ENTER_C;eif_file_ps((FILE*) arg1, (char*) arg2, (EIF_INTEGER) arg3);
	
	EIF_EXIT_C;
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {FILE}.file_go */
void F530_2395 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("file_go", 529, Current, 0, 2, 4327);eif_file_go((FILE*) arg1, (EIF_INTEGER) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {FILE}.file_move */
void F530_2397 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("file_move", 529, Current, 0, 2, 4329);eif_file_move((FILE*) arg1, (EIF_INTEGER) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {FILE}.file_feof */
EIF_BOOLEAN F530_2398 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("file_feof", 529, Current, 0, 1, 4330);Result = (EIF_BOOLEAN) EIF_TEST(eif_file_feof((FILE*) arg1));
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {FILE}.file_exists */
EIF_BOOLEAN F530_2399 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("file_exists", 529, Current, 0, 1, 4331);Result = (EIF_BOOLEAN) EIF_TEST(eif_file_exists((EIF_FILENAME) arg1));
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {FILE}.set_write_mode */
void F530_2422 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_write_mode", 529, Current, 0, 0, 4354);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O2084[Dtype(Current)-529]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	RTHOOK(2);
	RTEE;
}

void EIF_Minit123 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
