
#ifndef _C3_mi128_
#define _C3_mi128_

#ifdef __cplusplus
extern "C" {
#endif

extern void F633_2791(EIF_REFERENCE);
RTOSHF (EIF_REFERENCE,2792)
static EIF_REFERENCE F633_2792_body(EIF_REFERENCE);
extern EIF_REFERENCE F633_2792(EIF_REFERENCE);
extern void EIF_Minit128(void);
extern EIF_REFERENCE F657_3086(EIF_REFERENCE);
extern void F654_3010(EIF_REFERENCE);
extern void F771_4555(EIF_REFERENCE, EIF_REFERENCE);
extern void F73_980(EIF_REFERENCE, EIF_REFERENCE);
extern void F771_4594(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
