
#ifndef _C3_c_126_
#define _C3_c_126_

#ifdef __cplusplus
extern "C" {
#endif

extern void F533_2540(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F533_2541(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32, EIF_INTEGER_32, EIF_POINTER);
extern void EIF_Minit126(void);
extern void F774_4808(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F772_4667(EIF_REFERENCE);
extern void F774_4791(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F530_2225(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
