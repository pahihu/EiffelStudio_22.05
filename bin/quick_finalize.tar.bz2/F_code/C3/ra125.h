
#ifndef _C3_ra125_
#define _C3_ra125_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F532_2534(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32);
extern void EIF_Minit125(void);

#ifdef __cplusplus
}
#endif

#endif
