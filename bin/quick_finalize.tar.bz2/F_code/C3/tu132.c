/*
 * Code for class TUPLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "tu132.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TUPLE}.item */
EIF_REFERENCE F688_3116 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("item", 687, Current, 0, 1, 8852);
	RTGC;
	RTHOOK(1);
	switch ((EIF_NATURAL_8) eif_builtin_TUPLE_item_code__i4_u1 (Current, arg1)) {
		case 1U:
			RTHOOK(2);
			Result = RTLNS(eif_new_type(723, 0x00).id, 723, _OBJSIZ_0_1_0_0_0_0_0_0_);
			*(EIF_BOOLEAN *)Result = (EIF_BOOLEAN) eif_builtin_TUPLE_boolean_item__i4_b (Current, arg1);
			break;
		case 2U:
			RTHOOK(3);
			Result = RTLNS(eif_new_type(720, 0x00).id, 720, _OBJSIZ_0_1_0_0_0_0_0_0_);
			*(EIF_CHARACTER_8 *)Result = (EIF_CHARACTER_8) eif_builtin_TUPLE_character_8_item__i4_c1 (Current, arg1);
			break;
		case 14U:
			RTHOOK(4);
			Result = RTLNS(eif_new_type(717, 0x00).id, 717, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)Result = (EIF_CHARACTER_32) eif_builtin_TUPLE_character_32_item__i4_c4 (Current, arg1);
			break;
		case 3U:
			RTHOOK(5);
			Result = RTLNS(eif_new_type(714, 0x00).id, 714, _OBJSIZ_0_0_0_0_0_0_0_1_);
			*(EIF_REAL_64 *)Result = (EIF_REAL_64) eif_builtin_TUPLE_real_64_item__i4_r8 (Current, arg1);
			break;
		case 4U:
			RTHOOK(6);
			Result = RTLNS(eif_new_type(711, 0x00).id, 711, _OBJSIZ_0_0_0_0_1_0_0_0_);
			*(EIF_REAL_32 *)Result = (EIF_REAL_32) eif_builtin_TUPLE_real_32_item__i4_r4 (Current, arg1);
			break;
		case 5U:
			RTHOOK(7);
			Result = RTLNS(eif_new_type(759, 0x00).id, 759, _OBJSIZ_0_0_0_0_0_1_0_0_);
			*(EIF_POINTER *)Result = (EIF_POINTER) eif_builtin_TUPLE_pointer_item__i4_p (Current, arg1);
			break;
		case 10U:
			RTHOOK(8);
			Result = RTLNS(eif_new_type(708, 0x00).id, 708, _OBJSIZ_0_1_0_0_0_0_0_0_);
			*(EIF_NATURAL_8 *)Result = (EIF_NATURAL_8) eif_builtin_TUPLE_natural_8_item__i4_u1 (Current, arg1);
			break;
		case 11U:
			RTHOOK(9);
			Result = RTLNS(eif_new_type(705, 0x00).id, 705, _OBJSIZ_0_0_1_0_0_0_0_0_);
			*(EIF_NATURAL_16 *)Result = (EIF_NATURAL_16) eif_builtin_TUPLE_natural_16_item__i4_u2 (Current, arg1);
			break;
		case 12U:
			RTHOOK(10);
			Result = RTLNS(eif_new_type(702, 0x00).id, 702, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_NATURAL_32 *)Result = (EIF_NATURAL_32) eif_builtin_TUPLE_natural_32_item__i4_u4 (Current, arg1);
			break;
		case 13U:
			RTHOOK(11);
			Result = RTLNS(eif_new_type(699, 0x00).id, 699, _OBJSIZ_0_0_0_0_0_0_1_0_);
			*(EIF_NATURAL_64 *)Result = (EIF_NATURAL_64) eif_builtin_TUPLE_natural_64_item__i4_u8 (Current, arg1);
			break;
		case 6U:
			RTHOOK(12);
			Result = RTLNS(eif_new_type(696, 0x00).id, 696, _OBJSIZ_0_1_0_0_0_0_0_0_);
			*(EIF_INTEGER_8 *)Result = (EIF_INTEGER_8) eif_builtin_TUPLE_integer_8_item__i4_i1 (Current, arg1);
			break;
		case 7U:
			RTHOOK(13);
			Result = RTLNS(eif_new_type(693, 0x00).id, 693, _OBJSIZ_0_0_1_0_0_0_0_0_);
			*(EIF_INTEGER_16 *)Result = (EIF_INTEGER_16) eif_builtin_TUPLE_integer_16_item__i4_i2 (Current, arg1);
			break;
		case 8U:
			RTHOOK(14);
			Result = RTLNS(eif_new_type(690, 0x00).id, 690, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_INTEGER_32 *)Result = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (Current, arg1);
			break;
		case 9U:
			RTHOOK(15);
			Result = RTLNS(eif_new_type(726, 0x00).id, 726, _OBJSIZ_0_0_0_0_0_0_1_0_);
			*(EIF_INTEGER_64 *)Result = (EIF_INTEGER_64) eif_builtin_TUPLE_integer_64_item__i4_i8 (Current, arg1);
			break;
		case 0U:
			RTHOOK(16);
			Result = (EIF_REFERENCE) eif_builtin_TUPLE_reference_item__i4_o (Current, arg1);
			break;
		default:
			RTEC(EN_WHEN);
	}
	RTHOOK(17);
	RTLE;
	RTEE;
	return Result;
}

/* {TUPLE}.reference_item */
EIF_REFERENCE F688_3118 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("reference_item", 687, Current, 0, 1, 8854);
	Result = (EIF_REFERENCE) eif_builtin_TUPLE_reference_item__i4_o (Current, arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {TUPLE}.boolean_item */
EIF_BOOLEAN F688_3119 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("boolean_item", 687, Current, 0, 1, 8855);
	Result = (EIF_BOOLEAN) eif_builtin_TUPLE_boolean_item__i4_b (Current, arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {TUPLE}.character_8_item */
EIF_CHARACTER_8 F688_3120 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("character_8_item", 687, Current, 0, 1, 8856);
	Result = (EIF_CHARACTER_8) eif_builtin_TUPLE_character_8_item__i4_c1 (Current, arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {TUPLE}.character_32_item */
EIF_CHARACTER_32 F688_3122 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("character_32_item", 687, Current, 0, 1, 8858);
	Result = (EIF_CHARACTER_32) eif_builtin_TUPLE_character_32_item__i4_c4 (Current, arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {TUPLE}.real_64_item */
EIF_REAL_64 F688_3124 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("real_64_item", 687, Current, 0, 1, 8860);
	Result = (EIF_REAL_64) eif_builtin_TUPLE_real_64_item__i4_r8 (Current, arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {TUPLE}.natural_8_item */
EIF_NATURAL_8 F688_3126 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("natural_8_item", 687, Current, 0, 1, 8862);
	Result = (EIF_NATURAL_8) eif_builtin_TUPLE_natural_8_item__i4_u1 (Current, arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {TUPLE}.natural_16_item */
EIF_NATURAL_16 F688_3127 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_16 Result = ((EIF_NATURAL_16) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("natural_16_item", 687, Current, 0, 1, 8863);
	Result = (EIF_NATURAL_16) eif_builtin_TUPLE_natural_16_item__i4_u2 (Current, arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {TUPLE}.natural_32_item */
EIF_NATURAL_32 F688_3128 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("natural_32_item", 687, Current, 0, 1, 8864);
	Result = (EIF_NATURAL_32) eif_builtin_TUPLE_natural_32_item__i4_u4 (Current, arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {TUPLE}.natural_64_item */
EIF_NATURAL_64 F688_3129 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_64 Result = ((EIF_NATURAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("natural_64_item", 687, Current, 0, 1, 8865);
	Result = (EIF_NATURAL_64) eif_builtin_TUPLE_natural_64_item__i4_u8 (Current, arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {TUPLE}.integer_8_item */
EIF_INTEGER_8 F688_3130 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("integer_8_item", 687, Current, 0, 1, 8866);
	Result = (EIF_INTEGER_8) eif_builtin_TUPLE_integer_8_item__i4_i1 (Current, arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {TUPLE}.integer_16_item */
EIF_INTEGER_16 F688_3131 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_16 Result = ((EIF_INTEGER_16) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("integer_16_item", 687, Current, 0, 1, 8867);
	Result = (EIF_INTEGER_16) eif_builtin_TUPLE_integer_16_item__i4_i2 (Current, arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {TUPLE}.integer_32_item */
EIF_INTEGER_32 F688_3132 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("integer_32_item", 687, Current, 0, 1, 8868);
	Result = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (Current, arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {TUPLE}.integer_64_item */
EIF_INTEGER_64 F688_3134 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_64 Result = ((EIF_INTEGER_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("integer_64_item", 687, Current, 0, 1, 8870);
	Result = (EIF_INTEGER_64) eif_builtin_TUPLE_integer_64_item__i4_i8 (Current, arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {TUPLE}.pointer_item */
EIF_POINTER F688_3135 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("pointer_item", 687, Current, 0, 1, 8871);
	Result = (EIF_POINTER) eif_builtin_TUPLE_pointer_item__i4_p (Current, arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {TUPLE}.real_32_item */
EIF_REAL_32 F688_3136 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REAL_32 Result = ((EIF_REAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("real_32_item", 687, Current, 0, 1, 8872);
	Result = (EIF_REAL_32) eif_builtin_TUPLE_real_32_item__i4_r4 (Current, arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {TUPLE}.object_comparison */
EIF_BOOLEAN F688_3138 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("object_comparison", 687, Current, 0, 0, 8874);
	Result = (EIF_BOOLEAN) eif_builtin_TUPLE_object_comparison__b (Current);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {TUPLE}.is_equal */
EIF_BOOLEAN F688_3139 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("is_equal", 687, Current, 3, 1, 8875);
	RTGC;
	RTHOOK(1);
	loc3 = (EIF_BOOLEAN) eif_builtin_TUPLE_object_comparison__b (Current);
	RTHOOK(2);
	tb1 = (EIF_BOOLEAN) eif_builtin_TUPLE_object_comparison__b (arg1);
	if ((EIF_BOOLEAN)(loc3 == tb1)) {
		RTHOOK(3);
		if (loc3) {
			RTHOOK(4);
			loc2 = (EIF_INTEGER_32) eif_builtin_TUPLE_count__i4 (Current);
			RTHOOK(5);
			ti4_1 = (EIF_INTEGER_32) eif_builtin_TUPLE_count__i4 (arg1);
			if ((EIF_BOOLEAN)(loc2 == ti4_1)) {
				RTHOOK(6);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				RTHOOK(7);
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					RTHOOK(8);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > loc2) || (EIF_BOOLEAN) !Result)) break;
					RTHOOK(9);
					tr1 = F688_3116(Current, loc1);
					tr2 = F688_3116(RTCW(arg1), loc1);
					Result = (EIF_BOOLEAN) RTEQ(tr1, tr2);
					RTHOOK(10);
					loc1++;
				}
			}
		} else {
			RTHOOK(11);
			Result = (EIF_BOOLEAN) eif_builtin_ANY_is_equal__o_b (Current, arg1);
			RTHOOK(12);
			RTLE;
			RTEE;
			return (EIF_BOOLEAN) Result;
		}
	}
	RTHOOK(13);
	RTLE;
	RTEE;
	return Result;
}

/* {TUPLE}.hash_code */
EIF_INTEGER_32 F688_3142 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_INTEGER_64 ti8_1;
	EIF_NATURAL_64 tu8_1;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_CHARACTER_32 tw1;
	EIF_INTEGER_16 ti2_1;
	EIF_NATURAL_16 tu2_1;
	EIF_INTEGER_8 ti1_1;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc4);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("hash_code", 687, Current, 4, 0, 8878);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(2);
	loc2 = (EIF_INTEGER_32) eif_builtin_TUPLE_count__i4 (Current);
	for (;;) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		RTHOOK(4);
		switch ((EIF_NATURAL_8) eif_builtin_TUPLE_item_code__i4_u1 (Current, loc1)) {
			case 1U:
				RTHOOK(5);
				tb1 = (EIF_BOOLEAN) eif_builtin_TUPLE_boolean_item__i4_b (Current, loc1);
				loc3 = (tb1 ? 1L : 0L);
				break;
			case 2U:
				RTHOOK(6);
				tc1 = (EIF_CHARACTER_8) eif_builtin_TUPLE_character_8_item__i4_c1 (Current, loc1);
				loc3 = (EIF_INTEGER_32) (tc1);
				break;
			case 14U:
				RTHOOK(7);
				tw1 = (EIF_CHARACTER_32) eif_builtin_TUPLE_character_32_item__i4_c4 (Current, loc1);
				loc3 = (EIF_INTEGER_32) (tw1);
				break;
			case 3U:
				RTHOOK(8);
				tr8_1 = (EIF_REAL_64) eif_builtin_TUPLE_real_64_item__i4_r8 (Current, loc1);
				loc3 = (EIF_INTEGER_32) (0x7FFFFFFF & (EIF_INTEGER_32) ((rt_int_ptr) (tr8_1)));
				break;
			case 4U:
				RTHOOK(9);
				tr4_1 = (EIF_REAL_32) eif_builtin_TUPLE_real_32_item__i4_r4 (Current, loc1);
				loc3 = (EIF_INTEGER_32) (0x7FFFFFFF & (EIF_INTEGER_32) ((rt_int_ptr) (tr4_1)));
				break;
			case 5U:
				RTHOOK(10);
				tp1 = (EIF_POINTER) eif_builtin_TUPLE_pointer_item__i4_p (Current, loc1);
				loc3 = (EIF_INTEGER_32) (0x7FFFFFFF & (EIF_INTEGER_32) ((rt_int_ptr) (tp1)));
				break;
			case 10U:
				RTHOOK(11);
				tu1_1 = (EIF_NATURAL_8) eif_builtin_TUPLE_natural_8_item__i4_u1 (Current, loc1);
				loc3 = (EIF_INTEGER_32) (0x7FFFFFFF & (EIF_INTEGER_32) ((rt_int_ptr) (tu1_1)));
				break;
			case 11U:
				RTHOOK(12);
				tu2_1 = (EIF_NATURAL_16) eif_builtin_TUPLE_natural_16_item__i4_u2 (Current, loc1);
				loc3 = (EIF_INTEGER_32) (0x7FFFFFFF & (EIF_INTEGER_32) ((rt_int_ptr) (tu2_1)));
				break;
			case 12U:
				RTHOOK(13);
				tu4_1 = (EIF_NATURAL_32) eif_builtin_TUPLE_natural_32_item__i4_u4 (Current, loc1);
				loc3 = (EIF_INTEGER_32) (0x7FFFFFFF & (EIF_INTEGER_32) ((rt_int_ptr) (tu4_1)));
				break;
			case 13U:
				RTHOOK(14);
				tu8_1 = (EIF_NATURAL_64) eif_builtin_TUPLE_natural_64_item__i4_u8 (Current, loc1);
				loc3 = (EIF_INTEGER_32) (0x7FFFFFFF & (EIF_INTEGER_32) ((rt_int_ptr) (tu8_1)));
				break;
			case 6U:
				RTHOOK(15);
				ti1_1 = (EIF_INTEGER_8) eif_builtin_TUPLE_integer_8_item__i4_i1 (Current, loc1);
				loc3 = (EIF_INTEGER_32) (0x7FFFFFFF & (EIF_INTEGER_32) ((rt_int_ptr) (ti1_1)));
				break;
			case 7U:
				RTHOOK(16);
				ti2_1 = (EIF_INTEGER_16) eif_builtin_TUPLE_integer_16_item__i4_i2 (Current, loc1);
				loc3 = (EIF_INTEGER_32) (0x7FFFFFFF & (EIF_INTEGER_32) ((rt_int_ptr) (ti2_1)));
				break;
			case 8U:
				RTHOOK(17);
				ti4_1 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (Current, loc1);
				loc3 = (EIF_INTEGER_32) (0x7FFFFFFF & (EIF_INTEGER_32) ((rt_int_ptr) (ti4_1)));
				break;
			case 9U:
				RTHOOK(18);
				ti8_1 = (EIF_INTEGER_64) eif_builtin_TUPLE_integer_64_item__i4_i8 (Current, loc1);
				loc3 = (EIF_INTEGER_32) (0x7FFFFFFF & (EIF_INTEGER_32) ((rt_int_ptr) (ti8_1)));
				break;
			case 0U:
				RTHOOK(19);
				tr1 = (EIF_REFERENCE) eif_builtin_TUPLE_reference_item__i4_o (Current, loc1);
				loc4 = RTCCL(tr1);
				loc4 = RTRV(eif_new_type(654, 0x00),loc4);
				if (EIF_TEST(loc4)) {
					RTHOOK(20);
					loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R2395[Dtype(loc4)-656])(loc4);
				} else {
					RTHOOK(21);
					loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				}
				break;
			default:
				RTEC(EN_WHEN);
		}
		RTHOOK(22);
		tr1 = RTOSCF(3246,F688_3246, (Current));
		ti4_1 = F467_2163(RTCW(tr1), loc1);
		Result += (EIF_INTEGER_32) (loc3 * ti4_1);
		RTHOOK(23);
		loc1++;
	}
	RTHOOK(24);
	ti4_1 = (EIF_INTEGER_32) (0x7FFFFFFF & (EIF_INTEGER_32) ((rt_int_ptr) (Result)));
	RTHOOK(25);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) ti4_1;
}

/* {TUPLE}.valid_type_for_index */
EIF_BOOLEAN F688_3144 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(18);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,loc4);
	RTLR(5,loc5);
	RTLR(6,loc6);
	RTLR(7,loc7);
	RTLR(8,loc8);
	RTLR(9,loc9);
	RTLR(10,loc10);
	RTLR(11,loc11);
	RTLR(12,loc12);
	RTLR(13,loc13);
	RTLR(14,loc14);
	RTLR(15,loc15);
	RTLR(16,loc16);
	RTLR(17,loc1);
	RTLIU(18);
	
	RTEAA("valid_type_for_index", 687, Current, 16, 2, 8880);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		RTHOOK(2);
		if ((EIF_BOOLEAN)((EIF_NATURAL_8) eif_builtin_TUPLE_item_code__i4_u1 (Current, arg2) == ((EIF_NATURAL_8) 0U))) {
			RTHOOK(3);
			tr1 = (EIF_REFERENCE) eif_builtin_ANY_generating_type__t (Current);
			tr1 = (EIF_REFERENCE) eif_builtin_TYPE_generic_parameter_type__i4_t (tr1, arg2);
			Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2461[Dtype(RTCW(tr1))-656])(tr1);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
		}
	} else {
		RTHOOK(4);
		switch ((EIF_NATURAL_8) eif_builtin_TUPLE_item_code__i4_u1 (Current, arg2)) {
			case 1U:
				RTHOOK(5);
				loc3 = RTCCL(arg1);
				loc3 = RTRV(eif_new_type(721, 0x00),loc3);
				Result = (EIF_BOOLEAN) EIF_TEST(loc3);
				break;
			case 2U:
				RTHOOK(6);
				loc4 = RTCCL(arg1);
				loc4 = RTRV(eif_new_type(718, 0x00),loc4);
				Result = (EIF_BOOLEAN) EIF_TEST(loc4);
				break;
			case 14U:
				RTHOOK(7);
				loc5 = RTCCL(arg1);
				loc5 = RTRV(eif_new_type(715, 0x00),loc5);
				Result = (EIF_BOOLEAN) EIF_TEST(loc5);
				break;
			case 3U:
				RTHOOK(8);
				loc6 = RTCCL(arg1);
				loc6 = RTRV(eif_new_type(712, 0x00),loc6);
				Result = (EIF_BOOLEAN) EIF_TEST(loc6);
				break;
			case 4U:
				RTHOOK(9);
				loc7 = RTCCL(arg1);
				loc7 = RTRV(eif_new_type(709, 0x00),loc7);
				Result = (EIF_BOOLEAN) EIF_TEST(loc7);
				break;
			case 5U:
				RTHOOK(10);
				loc8 = RTCCL(arg1);
				loc8 = RTRV(eif_new_type(727, 0x00),loc8);
				Result = (EIF_BOOLEAN) EIF_TEST(loc8);
				break;
			case 10U:
				RTHOOK(11);
				loc9 = RTCCL(arg1);
				loc9 = RTRV(eif_new_type(706, 0x00),loc9);
				Result = (EIF_BOOLEAN) EIF_TEST(loc9);
				break;
			case 11U:
				RTHOOK(12);
				loc10 = RTCCL(arg1);
				loc10 = RTRV(eif_new_type(703, 0x00),loc10);
				Result = (EIF_BOOLEAN) EIF_TEST(loc10);
				break;
			case 12U:
				RTHOOK(13);
				loc11 = RTCCL(arg1);
				loc11 = RTRV(eif_new_type(700, 0x00),loc11);
				Result = (EIF_BOOLEAN) EIF_TEST(loc11);
				break;
			case 13U:
				RTHOOK(14);
				loc12 = RTCCL(arg1);
				loc12 = RTRV(eif_new_type(697, 0x00),loc12);
				Result = (EIF_BOOLEAN) EIF_TEST(loc12);
				break;
			case 6U:
				RTHOOK(15);
				loc13 = RTCCL(arg1);
				loc13 = RTRV(eif_new_type(694, 0x00),loc13);
				Result = (EIF_BOOLEAN) EIF_TEST(loc13);
				break;
			case 7U:
				RTHOOK(16);
				loc14 = RTCCL(arg1);
				loc14 = RTRV(eif_new_type(691, 0x00),loc14);
				Result = (EIF_BOOLEAN) EIF_TEST(loc14);
				break;
			case 8U:
				RTHOOK(17);
				loc15 = RTCCL(arg1);
				loc15 = RTRV(eif_new_type(688, 0x00),loc15);
				Result = (EIF_BOOLEAN) EIF_TEST(loc15);
				break;
			case 9U:
				RTHOOK(18);
				loc16 = RTCCL(arg1);
				loc16 = RTRV(eif_new_type(724, 0x00),loc16);
				Result = (EIF_BOOLEAN) EIF_TEST(loc16);
				break;
			case 0U:
				RTHOOK(19);
				loc1 = RTLNS(eif_new_type(118, 0x00).id, 118, _OBJSIZ_0_0_0_0_0_0_0_0_);
				RTHOOK(20);
				tr1 = RTCCL(arg1);
				loc2 = (EIF_INTEGER_32) eif_builtin_ISE_RUNTIME_dynamic_type__o_i4 (tr1);
				RTHOOK(21);
				tr1 = (EIF_REFERENCE) eif_builtin_ANY_generating_type__t (Current);
				tr1 = (EIF_REFERENCE) eif_builtin_TYPE_generic_parameter_type__i4_t (tr1, arg2);
				ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R2456[Dtype(RTCW(tr1))-656])(tr1);
				Result = F119_1392(RTCW(loc1), loc2, ti4_1);
				break;
			default:
				RTEC(EN_WHEN);
		}
	}
	RTHOOK(22);
	RTLE;
	RTEE;
	return Result;
}

/* {TUPLE}.count */
EIF_INTEGER_32 F688_3145 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("count", 687, Current, 0, 0, 8881);
	Result = (EIF_INTEGER_32) eif_builtin_TUPLE_count__i4 (Current);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {TUPLE}.lower */
EIF_INTEGER_32 F688_3146 (EIF_REFERENCE Current)
{
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
}

/* {TUPLE}.put */
void F688_3149 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_INTEGER_64 ti8_1;
	EIF_NATURAL_64 tu8_1;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_CHARACTER_32 tw1;
	EIF_INTEGER_16 ti2_1;
	EIF_NATURAL_16 tu2_1;
	EIF_INTEGER_8 ti1_1;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(17);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLR(6,loc5);
	RTLR(7,loc6);
	RTLR(8,loc7);
	RTLR(9,loc8);
	RTLR(10,loc9);
	RTLR(11,loc10);
	RTLR(12,loc11);
	RTLR(13,loc12);
	RTLR(14,loc13);
	RTLR(15,loc14);
	RTLR(16,tr1);
	RTLIU(17);
	
	RTEAA("put", 687, Current, 14, 2, 8885);
	RTGC;
	RTHOOK(1);
	switch ((EIF_NATURAL_8) eif_builtin_TUPLE_item_code__i4_u1 (Current, arg2)) {
		case 1U:
			RTHOOK(2);
			loc1 = RTCCL(arg1);
			loc1 = RTRV(eif_new_type(721, 0x00),loc1);
			if (EIF_TEST(loc1)) {
				RTHOOK(3);
				tb1 = *(EIF_BOOLEAN *)(loc1+ _CHROFF_0_0_);
				eif_builtin_TUPLE_put_boolean__b_i4_ (Current, tb1, arg2);
			}
			break;
		case 2U:
			RTHOOK(4);
			loc2 = RTCCL(arg1);
			loc2 = RTRV(eif_new_type(718, 0x00),loc2);
			if (EIF_TEST(loc2)) {
				RTHOOK(5);
				tc1 = *(EIF_CHARACTER_8 *)(loc2+ _CHROFF_0_0_);
				eif_builtin_TUPLE_put_character_8__c1_i4_ (Current, tc1, arg2);
			}
			break;
		case 14U:
			RTHOOK(6);
			loc3 = RTCCL(arg1);
			loc3 = RTRV(eif_new_type(715, 0x00),loc3);
			if (EIF_TEST(loc3)) {
				RTHOOK(7);
				tw1 = *(EIF_CHARACTER_32 *)(loc3+ _LNGOFF_0_0_0_0_);
				eif_builtin_TUPLE_put_character_32__c4_i4_ (Current, tw1, arg2);
			}
			break;
		case 3U:
			RTHOOK(8);
			loc4 = RTCCL(arg1);
			loc4 = RTRV(eif_new_type(712, 0x00),loc4);
			if (EIF_TEST(loc4)) {
				RTHOOK(9);
				tr8_1 = *(EIF_REAL_64 *)(loc4+ _R64OFF_0_0_0_0_0_0_0_0_);
				eif_builtin_TUPLE_put_real_64__r8_i4_ (Current, tr8_1, arg2);
			}
			break;
		case 4U:
			RTHOOK(10);
			loc5 = RTCCL(arg1);
			loc5 = RTRV(eif_new_type(709, 0x00),loc5);
			if (EIF_TEST(loc5)) {
				RTHOOK(11);
				tr4_1 = *(EIF_REAL_32 *)(loc5+ _R32OFF_0_0_0_0_0_);
				eif_builtin_TUPLE_put_real_32__r4_i4_ (Current, tr4_1, arg2);
			}
			break;
		case 5U:
			RTHOOK(12);
			loc6 = RTCCL(arg1);
			loc6 = RTRV(eif_new_type(727, 0x00),loc6);
			if (EIF_TEST(loc6)) {
				RTHOOK(13);
				tp1 = *(EIF_POINTER *)(loc6+ _PTROFF_0_0_0_0_0_0_);
				eif_builtin_TUPLE_put_pointer__p_i4_ (Current, tp1, arg2);
			}
			break;
		case 10U:
			RTHOOK(14);
			loc7 = RTCCL(arg1);
			loc7 = RTRV(eif_new_type(706, 0x00),loc7);
			if (EIF_TEST(loc7)) {
				RTHOOK(15);
				tu1_1 = *(EIF_NATURAL_8 *)(loc7+ _CHROFF_0_0_);
				eif_builtin_TUPLE_put_natural_8__u1_i4_ (Current, tu1_1, arg2);
			}
			break;
		case 11U:
			RTHOOK(16);
			loc8 = RTCCL(arg1);
			loc8 = RTRV(eif_new_type(703, 0x00),loc8);
			if (EIF_TEST(loc8)) {
				RTHOOK(17);
				tu2_1 = *(EIF_NATURAL_16 *)(loc8+ _I16OFF_0_0_0_);
				eif_builtin_TUPLE_put_natural_16__u2_i4_ (Current, tu2_1, arg2);
			}
			break;
		case 12U:
			RTHOOK(18);
			loc9 = RTCCL(arg1);
			loc9 = RTRV(eif_new_type(700, 0x00),loc9);
			if (EIF_TEST(loc9)) {
				RTHOOK(19);
				tu4_1 = *(EIF_NATURAL_32 *)(loc9+ _LNGOFF_0_0_0_0_);
				eif_builtin_TUPLE_put_natural_32__u4_i4_ (Current, tu4_1, arg2);
			}
			break;
		case 13U:
			RTHOOK(20);
			loc10 = RTCCL(arg1);
			loc10 = RTRV(eif_new_type(697, 0x00),loc10);
			if (EIF_TEST(loc10)) {
				RTHOOK(21);
				tu8_1 = *(EIF_NATURAL_64 *)(loc10+ _I64OFF_0_0_0_0_0_0_0_);
				eif_builtin_TUPLE_put_natural_64__u8_i4_ (Current, tu8_1, arg2);
			}
			break;
		case 6U:
			RTHOOK(22);
			loc11 = RTCCL(arg1);
			loc11 = RTRV(eif_new_type(694, 0x00),loc11);
			if (EIF_TEST(loc11)) {
				RTHOOK(23);
				ti1_1 = *(EIF_INTEGER_8 *)(loc11+ _CHROFF_0_0_);
				eif_builtin_TUPLE_put_integer_8__i1_i4_ (Current, ti1_1, arg2);
			}
			break;
		case 7U:
			RTHOOK(24);
			loc12 = RTCCL(arg1);
			loc12 = RTRV(eif_new_type(691, 0x00),loc12);
			if (EIF_TEST(loc12)) {
				RTHOOK(25);
				ti2_1 = *(EIF_INTEGER_16 *)(loc12+ _I16OFF_0_0_0_);
				eif_builtin_TUPLE_put_integer_16__i2_i4_ (Current, ti2_1, arg2);
			}
			break;
		case 8U:
			RTHOOK(26);
			loc13 = RTCCL(arg1);
			loc13 = RTRV(eif_new_type(688, 0x00),loc13);
			if (EIF_TEST(loc13)) {
				RTHOOK(27);
				ti4_1 = *(EIF_INTEGER_32 *)(loc13+ _LNGOFF_0_0_0_0_);
				eif_builtin_TUPLE_put_integer_32__i4_i4_ (Current, ti4_1, arg2);
			}
			break;
		case 9U:
			RTHOOK(28);
			loc14 = RTCCL(arg1);
			loc14 = RTRV(eif_new_type(724, 0x00),loc14);
			if (EIF_TEST(loc14)) {
				RTHOOK(29);
				ti8_1 = *(EIF_INTEGER_64 *)(loc14+ _I64OFF_0_0_0_0_0_0_0_);
				eif_builtin_TUPLE_put_integer_64__i8_i4_ (Current, ti8_1, arg2);
			}
			break;
		case 0U:
			RTHOOK(30);
			tr1 = RTCCL(arg1);
			eif_builtin_TUPLE_put_reference__o_i4_ (Current, tr1, arg2);
			break;
		default:
			RTEC(EN_WHEN);
	}
	RTHOOK(31);
	RTLE;
	RTEE;
}

/* {TUPLE}.put_reference */
void F688_3150 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("put_reference", 687, Current, 0, 2, 8886);
	eif_builtin_TUPLE_put_reference__o_i4_ (Current, arg1, arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {TUPLE}.put_boolean */
void F688_3151 (EIF_REFERENCE Current, EIF_BOOLEAN arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("put_boolean", 687, Current, 0, 2, 8887);
	eif_builtin_TUPLE_put_boolean__b_i4_ (Current, arg1, arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {TUPLE}.put_character_8 */
void F688_3152 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("put_character_8", 687, Current, 0, 2, 8888);
	eif_builtin_TUPLE_put_character_8__c1_i4_ (Current, arg1, arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {TUPLE}.put_character_32 */
void F688_3154 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("put_character_32", 687, Current, 0, 2, 8890);
	eif_builtin_TUPLE_put_character_32__c4_i4_ (Current, arg1, arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {TUPLE}.put_real_64 */
void F688_3156 (EIF_REFERENCE Current, EIF_REAL_64 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("put_real_64", 687, Current, 0, 2, 8892);
	eif_builtin_TUPLE_put_real_64__r8_i4_ (Current, arg1, arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {TUPLE}.put_real_32 */
void F688_3158 (EIF_REFERENCE Current, EIF_REAL_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("put_real_32", 687, Current, 0, 2, 8894);
	eif_builtin_TUPLE_put_real_32__r4_i4_ (Current, arg1, arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {TUPLE}.put_pointer */
void F688_3160 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("put_pointer", 687, Current, 0, 2, 8896);
	eif_builtin_TUPLE_put_pointer__p_i4_ (Current, arg1, arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {TUPLE}.put_natural_8 */
void F688_3161 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("put_natural_8", 687, Current, 0, 2, 8897);
	eif_builtin_TUPLE_put_natural_8__u1_i4_ (Current, arg1, arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {TUPLE}.put_natural_16 */
void F688_3162 (EIF_REFERENCE Current, EIF_NATURAL_16 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("put_natural_16", 687, Current, 0, 2, 8898);
	eif_builtin_TUPLE_put_natural_16__u2_i4_ (Current, arg1, arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {TUPLE}.put_natural_32 */
void F688_3163 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("put_natural_32", 687, Current, 0, 2, 8899);
	eif_builtin_TUPLE_put_natural_32__u4_i4_ (Current, arg1, arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {TUPLE}.put_natural_64 */
void F688_3164 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("put_natural_64", 687, Current, 0, 2, 8900);
	eif_builtin_TUPLE_put_natural_64__u8_i4_ (Current, arg1, arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {TUPLE}.put_integer_32 */
void F688_3165 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("put_integer_32", 687, Current, 0, 2, 8901);
	eif_builtin_TUPLE_put_integer_32__i4_i4_ (Current, arg1, arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {TUPLE}.put_integer_8 */
void F688_3167 (EIF_REFERENCE Current, EIF_INTEGER_8 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("put_integer_8", 687, Current, 0, 2, 8903);
	eif_builtin_TUPLE_put_integer_8__i1_i4_ (Current, arg1, arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {TUPLE}.put_integer_16 */
void F688_3168 (EIF_REFERENCE Current, EIF_INTEGER_16 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("put_integer_16", 687, Current, 0, 2, 8904);
	eif_builtin_TUPLE_put_integer_16__i2_i4_ (Current, arg1, arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {TUPLE}.put_integer_64 */
void F688_3169 (EIF_REFERENCE Current, EIF_INTEGER_64 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("put_integer_64", 687, Current, 0, 2, 8905);
	eif_builtin_TUPLE_put_integer_64__i8_i4_ (Current, arg1, arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {TUPLE}.correct_mismatch */
void F688_3224 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTEAA("correct_mismatch", 687, Current, 4, 0, 8960);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(2792,F633_2792, (Current));
	tr2 = RTOSCF(3244,F688_3244, (Current));
	tr1 = F647_2897(RTCW(tr1), tr2);
	loc4 = RTCCL(tr1);
	{
		static EIF_TYPE_INDEX typarr0[] = {545,0,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc4 = RTRV(typres0,loc4);
	}
	if (EIF_TEST(loc4)) {
		RTHOOK(2);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		RTHOOK(3);
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R1692[Dtype(loc4)-545])(loc4);
		for (;;) {
			RTHOOK(4);
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			RTHOOK(5);
			loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R2130[Dtype(loc4)-545])(loc4, (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
			RTHOOK(6);
			tr1 = RTCCL(loc3);
			if (F688_3144(Current, tr1, loc1)) {
				RTHOOK(7);
				tr1 = RTCCL(loc3);
				F688_3149(Current, tr1, loc1);
			} else {
				RTHOOK(8);
				F633_2791(Current);
			}
			RTHOOK(9);
			loc1++;
		}
	} else {
		RTHOOK(10);
		F633_2791(Current);
	}
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {TUPLE}.item_code */
EIF_NATURAL_8 F688_3225 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("item_code", 687, Current, 0, 1, 8961);
	Result = (EIF_NATURAL_8) eif_builtin_TUPLE_item_code__i4_u1 (Current, arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {TUPLE}.area_name */

EIF_REFERENCE F688_3244 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (3244,RTMS_EX_H("area",4,1634887009));
}

/* {TUPLE}.internal_primes */
static EIF_REFERENCE F688_3246_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("internal_primes", 687, Current, 0, 0, 8982);
	RTGC;
	RTOSP (3246);
#define Result RTOSR(3246)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(466, 0x00).id, 466, _OBJSIZ_0_1_0_1_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3246);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F688_3246 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3246,F688_3246_body,(Current));
}

void EIF_Minit132 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
