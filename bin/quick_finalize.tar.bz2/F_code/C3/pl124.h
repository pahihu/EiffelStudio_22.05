
#ifndef _C3_pl124_
#define _C3_pl124_

#ifdef __cplusplus
extern "C" {
#endif

extern void F531_2423(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit124(void);
extern void F530_2195(EIF_REFERENCE, EIF_REFERENCE);
extern void F766_4349(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
