
#ifndef _C15_in736_
#define _C15_in736_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F464_2136(EIF_REFERENCE);
extern void EIF_Minit736(void);

#ifdef __cplusplus
}
#endif

#endif
