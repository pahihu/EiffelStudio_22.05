
#ifndef _C15_re701_
#define _C15_re701_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F505_2182(EIF_REFERENCE);
extern void EIF_Minit701(void);
extern char *(*R1921[])();

#ifdef __cplusplus
}
#endif

#endif
