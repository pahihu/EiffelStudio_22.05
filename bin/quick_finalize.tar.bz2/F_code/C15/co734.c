/*
 * Code for class COUNTABLE_SEQUENCE [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co734.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {COUNTABLE_SEQUENCE}.index */
EIF_INTEGER_32 F466_2139 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_0_);
}


/* {COUNTABLE_SEQUENCE}.item */
EIF_INTEGER_32 F466_2140 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("item", 465, Current, 0, 0, 3915);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) F467_2163(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_0_));
}

/* {COUNTABLE_SEQUENCE}.after */
EIF_BOOLEAN F466_2141 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_FALSE;
}

/* {COUNTABLE_SEQUENCE}.forth */
void F466_2147 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("forth", 465, Current, 0, 0, 3922);
	RTHOOK(1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_0_))++;
	RTHOOK(2);
	RTEE;
}

/* {COUNTABLE_SEQUENCE}.start */
void F466_2148 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("start", 465, Current, 0, 0, 3923);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(2);
	RTEE;
}

void EIF_Minit734 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
