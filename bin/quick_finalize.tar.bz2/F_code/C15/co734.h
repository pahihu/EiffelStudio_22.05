
#ifndef _C15_co734_
#define _C15_co734_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F466_2139(EIF_REFERENCE);
extern EIF_INTEGER_32 F466_2140(EIF_REFERENCE);
extern EIF_BOOLEAN F466_2141(EIF_REFERENCE);
extern void F466_2147(EIF_REFERENCE);
extern void F466_2148(EIF_REFERENCE);
extern void EIF_Minit734(void);
extern EIF_INTEGER_32 F467_2163(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
