
#ifndef _C15_to703_
#define _C15_to703_

#ifdef __cplusplus
extern "C" {
#endif

extern void F135_1548(EIF_REFERENCE, EIF_INTEGER_32);
extern void F135_1549(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F135_1555(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit703(void);
extern void F557_2549(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1437[];
extern EIF_TYPE_INDEX *Y1437_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
