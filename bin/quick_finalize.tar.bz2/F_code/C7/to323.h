
#ifndef _C7_to323_
#define _C7_to323_

#ifdef __cplusplus
extern "C" {
#endif

extern void F126_1548(EIF_REFERENCE, EIF_INTEGER_32);
extern void F126_1549(EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32);
extern void F126_1555(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit323(void);
extern void F548_2549(EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1437[];
extern EIF_TYPE_INDEX *Y1437_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
