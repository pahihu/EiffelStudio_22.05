
#ifndef _C7_li337_
#define _C7_li337_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F352_2090(EIF_REFERENCE);
extern EIF_REFERENCE F352_2097(EIF_REFERENCE);
extern void EIF_Minit337(void);
extern char *(*R1854[])();
extern char *(*R1875[])();

#ifdef __cplusplus
}
#endif

#endif
