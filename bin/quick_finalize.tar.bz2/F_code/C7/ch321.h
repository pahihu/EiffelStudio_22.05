
#ifndef _C7_ch321_
#define _C7_ch321_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F585_2702(EIF_REFERENCE);
extern EIF_BOOLEAN F585_2710(EIF_REFERENCE);
extern void EIF_Minit321(void);
extern EIF_INTEGER_32 F636_2846(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
