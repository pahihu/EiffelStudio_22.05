
#ifndef _C7_re345_
#define _C7_re345_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F496_2182(EIF_REFERENCE);
extern void EIF_Minit345(void);
extern char *(*R1921[])();

#ifdef __cplusplus
}
#endif

#endif
