
#ifndef _C7_to302_
#define _C7_to302_

#ifdef __cplusplus
extern "C" {
#endif

extern void F125_1548(EIF_REFERENCE, EIF_INTEGER_32);
extern void F125_1549(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern void F125_1555(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit302(void);
extern void F547_2549(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1437[];
extern EIF_TYPE_INDEX *Y1437_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
