
#ifndef _C7_re309_
#define _C7_re309_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F495_2182(EIF_REFERENCE);
extern void EIF_Minit309(void);
extern char *(*R1921[])();

#ifdef __cplusplus
}
#endif

#endif
