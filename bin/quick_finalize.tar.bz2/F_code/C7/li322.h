
#ifndef _C7_li322_
#define _C7_li322_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F609_2734(EIF_REFERENCE);
extern void EIF_Minit322(void);
extern EIF_INTEGER_32 F636_2846(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
