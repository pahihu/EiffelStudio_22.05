/*
 * Code for class SPECIAL [CHARACTER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sp303.h"
#include "eif_built_in.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SPECIAL}.make_empty */
void F547_2548 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make_empty", 546, Current, 0, 1, 4613);
	RTGC;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {SPECIAL}.make_filled */
void F547_2549 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make_filled", 546, Current, 0, 2, 4614);
	RTGC;
	RTHOOK(1);
	{
		/* INLINED CODE (SPECIAL.make_empty) */
		/* END INLINED CODE */
	}
	;
	RTHOOK(2);
	F547_2570(Current, arg1, ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)));
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {SPECIAL}.item */
EIF_CHARACTER_32 F547_2551 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	return *((EIF_CHARACTER_32 *) Current + arg1);
}

EIF_REFERENCE F547_25511 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	EIF_REFERENCE Result;
	EIF_CHARACTER_32 r = *((EIF_CHARACTER_32 *) Current + arg1);
	Result = RTLNS(eif_new_type(717, 0x00).id, 717, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_CHARACTER_32 *)Result = r;
	return Result;
}

/* {SPECIAL}.at */
EIF_CHARACTER_32 F547_2552 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	return *((EIF_CHARACTER_32 *) Current + arg1);
}

EIF_REFERENCE F547_25521 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	EIF_REFERENCE Result;
	EIF_CHARACTER_32 r = *((EIF_CHARACTER_32 *) Current + arg1);
	Result = RTLNS(eif_new_type(717, 0x00).id, 717, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_CHARACTER_32 *)Result = r;
	return Result;
}

/* {SPECIAL}.item_address */
EIF_POINTER F547_2554 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	return (EIF_POINTER) (Current + (rt_uint_ptr) arg1 * (rt_uint_ptr)sizeof(EIF_CHARACTER_32));
}

/* {SPECIAL}.base_address */
EIF_POINTER F547_2555 (EIF_REFERENCE Current)
{
	return (EIF_POINTER) Current;
}

/* {SPECIAL}.to_array */
EIF_REFERENCE F547_2557 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("to_array", 546, Current, 0, 0, 4572);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {571,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y1758,Y1758_gen_type,Dftype(Current),211);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		tr1 = RTLNS(typres0.id, 571, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F572_2640(RTCW(tr1), Current);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {SPECIAL}.lower */
EIF_INTEGER_32 F547_2559 (EIF_REFERENCE Current)
{
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
}

/* {SPECIAL}.upper */
EIF_INTEGER_32 F547_2560 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("upper", 546, Current, 0, 0, 4575);
	RTGC;
	RTHOOK(1);
	Result = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result - ((EIF_INTEGER_32) 1L));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {SPECIAL}.count */
EIF_INTEGER_32 F547_2561 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("count", 546, Current, 0, 0, 4576);
	Result = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {SPECIAL}.capacity */
EIF_INTEGER_32 F547_2562 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("capacity", 546, Current, 0, 0, 4577);
	Result = (EIF_INTEGER_32) eif_builtin_SPECIAL_capacity__i4 (Current);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {SPECIAL}.same_items */
EIF_BOOLEAN F547_2564 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_CHARACTER_32 tw3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("same_items", 546, Current, 3, 4, 4579);
	RTGC;
	RTHOOK(1);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		RTHOOK(3);
		loc1 = (EIF_INTEGER_32) arg2;
		RTHOOK(4);
		loc2 = (EIF_INTEGER_32) arg3;
		RTHOOK(5);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + arg4);
		for (;;) {
			RTHOOK(6);
			if ((EIF_BOOLEAN)(loc1 == loc3)) break;
			RTHOOK(7);
			/* INLINED CODE (SPECIAL.item) */
			tw2 = *((EIF_CHARACTER_32 *)RTCW(arg1) + (loc1));
			/* END INLINED CODE */
			tw1 = tw2;
			/* INLINED CODE (SPECIAL.item) */
			tw3 = *((EIF_CHARACTER_32 *)Current + (loc2));
			/* END INLINED CODE */
			if ((EIF_BOOLEAN)(tw1 != tw3)) {
				RTHOOK(8);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				RTHOOK(9);
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L));
			}
			RTHOOK(10);
			loc1++;
			RTHOOK(11);
			loc2++;
		}
	}
	RTHOOK(13);
	RTLE;
	RTEE;
	return Result;
}

/* {SPECIAL}.put */
void F547_2566 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	*((EIF_CHARACTER_32 *) Current + arg2) = arg1;
}

void F547_25662 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	*((EIF_CHARACTER_32 *) Current + arg2) = *(EIF_CHARACTER_32 *)arg1;
}

/* {SPECIAL}.force */
void F547_2567 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 arg3 = RT_SPECIAL_COUNT(Current);
	*((EIF_CHARACTER_32 *) Current + arg2) = arg1;
	if (arg2 == arg3) { RT_SPECIAL_COUNT(Current) = arg3 + 1; }
}

void F547_25672 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	*((EIF_CHARACTER_32 *) Current + arg2) = *(EIF_CHARACTER_32 *)arg1;
}

/* {SPECIAL}.extend */
void F547_2568 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 arg2 = RT_SPECIAL_COUNT(Current)++;
	*((EIF_CHARACTER_32 *) Current + arg2) = arg1;
}

void F547_25682 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	
	EIF_INTEGER_32 arg2 = RT_SPECIAL_COUNT(Current)++;
	*((EIF_CHARACTER_32 *) Current + arg2) = *(EIF_CHARACTER_32 *)arg1;
}

/* {SPECIAL}.fill_with */
void F547_2570 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 i;
	for (i = arg2; i <= arg3; i++) {
		*((EIF_CHARACTER_32 *) Current + i) = arg1;
	}
	RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), arg3 + 1);
}

void F547_25702 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	EIF_INTEGER_32 i;
	EIF_CHARACTER_32 arg1x = *(EIF_CHARACTER_32 *)arg1;
	for (i = arg2; i < arg3; i++) {
	*((EIF_CHARACTER_32 *) Current + i) = arg1x;
	}
	RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), arg3 + 1);
}

/* {SPECIAL}.copy_data */
void F547_2573 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("copy_data", 546, Current, 3, 4, 4588);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == Current)) {
		RTHOOK(2);
		/* INLINED CODE (SPECIAL.overlapping_move) */
		memmove((EIF_CHARACTER_32 *)Current + (arg3),(EIF_CHARACTER_32 *)Current + arg2, (rt_uint_ptr)sizeof(EIF_CHARACTER_32) * (rt_uint_ptr)arg4);
		RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), arg3 + arg4);
		/* END INLINED CODE */
		;
	} else {
		RTHOOK(3);
		loc1 = (EIF_INTEGER_32) arg2;
		RTHOOK(4);
		loc2 = (EIF_INTEGER_32) arg3;
		RTHOOK(5);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + arg4);
		for (;;) {
			RTHOOK(6);
			if ((EIF_BOOLEAN)(loc1 == loc3)) break;
			RTHOOK(7);
			/* INLINED CODE (SPECIAL.item) */
			tw2 = *((EIF_CHARACTER_32 *)RTCW(arg1) + (loc1));
			/* END INLINED CODE */
			tw1 = tw2;
			F547_2567(Current, tw1, loc2);
			RTHOOK(8);
			loc1++;
			RTHOOK(9);
			loc2++;
		}
	}
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {SPECIAL}.move_data */
void F547_2574 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("move_data", 546, Current, 0, 3, 4589);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == arg2)) {
	} else {
		RTHOOK(2);
		if ((EIF_BOOLEAN) (arg1 > arg2)) {
			RTHOOK(3);
			if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (arg2 + arg3) < arg1)) {
				RTHOOK(4);
				/* INLINED CODE (SPECIAL.move_data) */
				memcpy((EIF_CHARACTER_32 *)Current + (arg2),(EIF_CHARACTER_32 *)Current + arg1, (rt_uint_ptr)sizeof(EIF_CHARACTER_32) * (rt_uint_ptr)arg3);
				RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), arg2 + arg3);
				/* END INLINED CODE */
				;
			} else {
				RTHOOK(5);
				/* INLINED CODE (SPECIAL.overlapping_move) */
				memmove((EIF_CHARACTER_32 *)Current + (arg2),(EIF_CHARACTER_32 *)Current + arg1, (rt_uint_ptr)sizeof(EIF_CHARACTER_32) * (rt_uint_ptr)arg3);
				RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), arg2 + arg3);
				/* END INLINED CODE */
				;
			}
		} else {
			RTHOOK(6);
			if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 + arg3) < arg2)) {
				RTHOOK(7);
				/* INLINED CODE (SPECIAL.move_data) */
				memcpy((EIF_CHARACTER_32 *)Current + (arg2),(EIF_CHARACTER_32 *)Current + arg1, (rt_uint_ptr)sizeof(EIF_CHARACTER_32) * (rt_uint_ptr)arg3);
				RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), arg2 + arg3);
				/* END INLINED CODE */
				;
			} else {
				RTHOOK(8);
				/* INLINED CODE (SPECIAL.overlapping_move) */
				memmove((EIF_CHARACTER_32 *)Current + (arg2),(EIF_CHARACTER_32 *)Current + arg1, (rt_uint_ptr)sizeof(EIF_CHARACTER_32) * (rt_uint_ptr)arg3);
				RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), arg2 + arg3);
				/* END INLINED CODE */
				;
			}
		}
	}
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {SPECIAL}.overlapping_move */
void F547_2575 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("overlapping_move", 546, Current, 3, 3, 4590);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg1 < arg2)) {
		RTHOOK(2);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 + arg3) - ((EIF_INTEGER_32) 1L));
		RTHOOK(3);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L));
		RTHOOK(4);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 - arg1);
		RTHOOK(5);
		if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (arg2 + arg3) >= (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current))) {
			RTHOOK(6);
			/* INLINED CODE (SPECIAL.item) */
			tw2 = *((EIF_CHARACTER_32 *)Current + (arg1));
			/* END INLINED CODE */
			tw1 = tw2;
			ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current);
			F547_2570(Current, tw1, ti4_1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg2 + arg3) - ((EIF_INTEGER_32) 1L)));
		}
		
		for (;;) {
			RTHOOK(8);
			if ((EIF_BOOLEAN)(loc1 == loc2)) break;
			RTHOOK(9);
			/* INLINED CODE (SPECIAL.item) */
			tw2 = *((EIF_CHARACTER_32 *)Current + (loc1));
			/* END INLINED CODE */
			tw1 = tw2;
			/* INLINED CODE (SPECIAL.put) */
			*((EIF_CHARACTER_32 *)Current + ((EIF_INTEGER_32) (loc1 + loc3))) = tw1;
			/* END INLINED CODE */
			;
			RTHOOK(10);
			loc1--;
		}
	} else {
		RTHOOK(11);
		loc1 = (EIF_INTEGER_32) arg1;
		RTHOOK(12);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + arg3);
		RTHOOK(13);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 - arg2);
		
		for (;;) {
			RTHOOK(15);
			if ((EIF_BOOLEAN)(loc1 == loc2)) break;
			RTHOOK(16);
			/* INLINED CODE (SPECIAL.item) */
			tw2 = *((EIF_CHARACTER_32 *)Current + (loc1));
			/* END INLINED CODE */
			tw1 = tw2;
			F547_2567(Current, tw1, (EIF_INTEGER_32) (loc1 - loc3));
			RTHOOK(17);
			loc1++;
		}
	}
	RTHOOK(20);
	RTLE;
	RTEE;
}

/* {SPECIAL}.non_overlapping_move */
void F547_2576 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("non_overlapping_move", 546, Current, 3, 3, 4591);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + arg3);
	RTHOOK(3);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 - arg1);
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN)(loc1 == loc2)) break;
		RTHOOK(5);
		/* INLINED CODE (SPECIAL.item) */
		tw2 = *((EIF_CHARACTER_32 *)Current + (loc1));
		/* END INLINED CODE */
		tw1 = tw2;
		F547_2567(Current, tw1, (EIF_INTEGER_32) (loc1 + loc3));
		RTHOOK(6);
		loc1++;
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {SPECIAL}.resized_area */
EIF_REFERENCE F547_2581 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_CHARACTER_32 tw1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("resized_area", 546, Current, 0, 1, 4596);
	RTGC;
	RTHOOK(1);
	Result = RTLNSP2(Dftype(Current),0,arg1,sizeof(EIF_CHARACTER_32), EIF_TRUE);
	RT_SPECIAL_COUNT(Result) = 0;
	RTHOOK(2);
	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current);
	ti4_1 = eif_min_int32 (arg1,ti4_1);
	/* INLINED CODE (SPECIAL.copy_data) */
	memmove((EIF_CHARACTER_32 *)RTCW(Result) + (((EIF_INTEGER_32) 0L)),(EIF_CHARACTER_32 *)Current + ((EIF_INTEGER_32) 0L), (rt_uint_ptr)sizeof(EIF_CHARACTER_32) * (rt_uint_ptr)ti4_1);
	RT_SPECIAL_COUNT(Result) = eif_max_int32(RT_SPECIAL_COUNT(Result), ((EIF_INTEGER_32) 0L) + ti4_1);
	/* END INLINED CODE */
	;
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {SPECIAL}.resized_area_with_default */
EIF_REFERENCE F547_2582 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_CHARACTER_32 tw1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("resized_area_with_default", 546, Current, 0, 2, 4597);
	RTGC;
	RTHOOK(1);
	Result = RTLNSP2(Dftype(Current),0,arg2,sizeof(EIF_CHARACTER_32), EIF_TRUE);
	RT_SPECIAL_COUNT(Result) = 0;
	RTHOOK(2);
	if ((EIF_BOOLEAN) (arg2 > (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current))) {
		RTHOOK(3);
		ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current);
		/* INLINED CODE (SPECIAL.copy_data) */
		memmove((EIF_CHARACTER_32 *)RTCW(Result) + (((EIF_INTEGER_32) 0L)),(EIF_CHARACTER_32 *)Current + ((EIF_INTEGER_32) 0L), (rt_uint_ptr)sizeof(EIF_CHARACTER_32) * (rt_uint_ptr)ti4_1);
		RT_SPECIAL_COUNT(Result) = eif_max_int32(RT_SPECIAL_COUNT(Result), ((EIF_INTEGER_32) 0L) + ti4_1);
		/* END INLINED CODE */
		;
		RTHOOK(4);
		ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current);
		F547_2570(RTCW(Result), arg1, ti4_1, (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)));
	} else {
		RTHOOK(5);
		/* INLINED CODE (SPECIAL.copy_data) */
		memmove((EIF_CHARACTER_32 *)RTCW(Result) + (((EIF_INTEGER_32) 0L)),(EIF_CHARACTER_32 *)Current + ((EIF_INTEGER_32) 0L), (rt_uint_ptr)sizeof(EIF_CHARACTER_32) * (rt_uint_ptr)arg2);
		RT_SPECIAL_COUNT(Result) = eif_max_int32(RT_SPECIAL_COUNT(Result), ((EIF_INTEGER_32) 0L) + arg2);
		/* END INLINED CODE */
		;
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {SPECIAL}.aliased_resized_area */
EIF_REFERENCE F547_2583 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("aliased_resized_area", 546, Current, 0, 1, 4598);
	Result = (EIF_REFERENCE) eif_builtin_SPECIAL_aliased_resized_area__i4_s (Current, arg1);
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {SPECIAL}.aliased_resized_area_with_default */
EIF_REFERENCE F547_2584 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("aliased_resized_area_with_default", 546, Current, 0, 2, 4599);
	RTGC;
	RTHOOK(1);
	Result = (EIF_REFERENCE) eif_builtin_SPECIAL_aliased_resized_area__i4_s (Current, arg2);
	RTHOOK(2);
	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Result);
	F547_2570(RTCW(Result), arg1, ti4_1, (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)));
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {SPECIAL}.wipe_out */
void F547_2586 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("wipe_out", 546, Current, 0, 0, 4601);
	RTHOOK(1);
	eif_builtin_SPECIAL_set_count__i4_ (Current, ((EIF_INTEGER_32) 0L));
	RTHOOK(4);
	RTEE;
}

/* {SPECIAL}.clear_all */
void F547_2587 (EIF_REFERENCE Current)
{
	memset (Current, 0, RT_SPECIAL_VISIBLE_SIZE(Current));
}

/* {SPECIAL}.element_size */
EIF_INTEGER_32 F547_2595 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("element_size", 546, Current, 0, 0, 4610);
	Result = (EIF_INTEGER_32) eif_builtin_SPECIAL_element_size__i4 (Current);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {SPECIAL}.set_count */
void F547_2596 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_count", 546, Current, 0, 1, 4611);
	eif_builtin_SPECIAL_set_count__i4_ (Current, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit303 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
