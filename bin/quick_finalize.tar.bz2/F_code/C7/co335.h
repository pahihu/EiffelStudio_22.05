
#ifndef _C7_co335_
#define _C7_co335_

#ifdef __cplusplus
extern "C" {
#endif

extern void F328_2071(EIF_REFERENCE);
extern void EIF_Minit335(void);
extern long O1856[];

#ifdef __cplusplus
}
#endif

#endif
