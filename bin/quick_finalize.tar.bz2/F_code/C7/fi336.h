
#ifndef _C7_fi336_
#define _C7_fi336_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F471_2169(EIF_REFERENCE);
extern void EIF_Minit336(void);
extern char *(*R1918[])();

#ifdef __cplusplus
}
#endif

#endif
