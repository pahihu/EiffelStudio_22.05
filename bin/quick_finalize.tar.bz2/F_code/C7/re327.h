
#ifndef _C7_re327_
#define _C7_re327_

#ifdef __cplusplus
extern "C" {
#endif

extern void F259_1984(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F259_1986(EIF_REFERENCE);
extern EIF_INTEGER_32 F259_1987(EIF_REFERENCE);
extern EIF_INTEGER_32 F259_1988(EIF_REFERENCE);
extern EIF_INTEGER_32 F259_1989(EIF_REFERENCE);
extern EIF_BOOLEAN F259_1997(EIF_REFERENCE);
extern EIF_BOOLEAN F259_1998(EIF_REFERENCE);
extern void F259_2003(EIF_REFERENCE);
extern void EIF_Minit327(void);
extern char *(*R2131[])();
extern char *(*R2132[])();

#ifdef __cplusplus
}
#endif

#endif
