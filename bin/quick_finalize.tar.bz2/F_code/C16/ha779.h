
#ifndef _C16_ha779_
#define _C16_ha779_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F273_2012(EIF_REFERENCE);
extern EIF_INTEGER_32 F273_2013(EIF_REFERENCE);
extern EIF_BOOLEAN F273_2015(EIF_REFERENCE);
extern void F273_2016(EIF_REFERENCE);
extern EIF_REFERENCE F273_2017(EIF_REFERENCE);
extern void EIF_Minit779(void);
extern char *(*R2322[])();
extern char *(*R1820[])();
extern char *(*R2323[])();
extern char *(*R2130[])();
extern long O2331[];
extern long O2332[];

#ifdef __cplusplus
}
#endif

#endif
