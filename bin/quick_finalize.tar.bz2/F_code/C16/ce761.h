
#ifndef _C16_ce761_
#define _C16_ce761_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_32 F42_642(EIF_REFERENCE);
extern void F42_643(EIF_REFERENCE, EIF_CHARACTER_32);
extern void EIF_Minit761(void);

#ifdef __cplusplus
}
#endif

#endif
