
#ifndef _C16_ha753_
#define _C16_ha753_

#ifdef __cplusplus
extern "C" {
#endif

extern void F649_2891(EIF_REFERENCE, EIF_INTEGER_32);
extern void F649_2894(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F649_2895(EIF_REFERENCE);
extern EIF_INTEGER_32 F649_2897(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F649_2899(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F649_2906(EIF_REFERENCE);
extern EIF_INTEGER_32 F649_2908(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F649_2909(EIF_REFERENCE);
extern EIF_INTEGER_32 F649_2912(EIF_REFERENCE);
extern EIF_INTEGER_32 F649_2913(EIF_REFERENCE);
extern EIF_BOOLEAN F649_2914(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F649_2915(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F649_2923(EIF_REFERENCE);
extern EIF_BOOLEAN F649_2924(EIF_REFERENCE);
extern void F649_2933(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F649_2935(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F649_2936(EIF_REFERENCE, EIF_INTEGER_32);
extern void F649_2937(EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE);
extern void F649_2938(EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE);
extern void F649_2945(EIF_REFERENCE);
extern void F649_2948(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F649_2949(EIF_REFERENCE, EIF_INTEGER_32);
extern void F649_2950(EIF_REFERENCE);
extern EIF_INTEGER_32 F649_2959(EIF_REFERENCE);
extern EIF_BOOLEAN F649_2960(EIF_REFERENCE);
extern EIF_INTEGER_32 F649_2967(EIF_REFERENCE);
extern EIF_REFERENCE F649_2968(EIF_REFERENCE);
extern EIF_INTEGER_32 F649_2969(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F649_2970(EIF_REFERENCE, EIF_INTEGER_32);
extern void F649_2973(EIF_REFERENCE, EIF_REFERENCE);
extern void F649_2975(EIF_REFERENCE, EIF_REFERENCE);
extern void F649_2976(EIF_REFERENCE, EIF_REFERENCE);
extern void F649_2977(EIF_REFERENCE, EIF_REFERENCE);
extern void F649_2981(EIF_REFERENCE, EIF_REFERENCE);
extern void F649_2987(EIF_REFERENCE);
extern void F649_3000(EIF_REFERENCE);
extern void EIF_Minit753(void);
extern void F557_2549(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_REFERENCE F633_2792(EIF_REFERENCE);
extern void F557_2586(EIF_REFERENCE);
extern void F555_2567(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern void F633_2791(EIF_REFERENCE);
extern void F555_2570(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F258_2003(EIF_REFERENCE);
extern void F258_1984(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F467_2159(EIF_REFERENCE, EIF_INTEGER_32);
extern void F327_2071(EIF_REFERENCE);
extern void F555_2549(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern EIF_REFERENCE F647_2897(EIF_REFERENCE, EIF_REFERENCE);
extern void F557_2570(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_BOOLEAN F647_2899(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F555_2560(EIF_REFERENCE);
extern void F557_2567(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
RTOSHF(EIF_REFERENCE,2792)
extern char *(*R2303[])();
extern char *(*R2305[])();
extern char *(*R1692[])();
extern char *(*R1693[])();
extern char *(*R2295[])();
extern char *(*R2352[])();
extern char *(*R1894[])();
extern char *(*R2354[])();
extern char *(*R2355[])();
extern char *(*R2356[])();
extern char *(*R2166[])();
extern char *(*R2366[])();
extern char *(*R2348[])();
extern char *(*R2349[])();
extern char *(*R1742[])();
extern char *(*R1743[])();
extern char *(*R1744[])();
extern char *(*R2320[])();
extern char *(*R2322[])();
extern char *(*R2323[])();
extern char *(*R2130[])();
extern char *(*R2329[])();
extern char *(*R2291[])();
extern char *(*R2294[])();
extern char *(*R2311[])();
extern char *(*R2312[])();
extern char *(*R1755[])();
extern char *(*R2147[])();
extern char *(*R1757[])();
extern char *(*R2379[])();
extern char *(*R2338[])();
extern char *(*R2360[])();
extern char *(*R2339[])();
extern char *(*R2395[])();
extern long O2295[];
extern long O2335[];
extern long O2336[];
extern long O2337[];
extern long O2381[];
extern long O2340[];
extern long O2341[];
extern long O2347[];
extern long O2345[];
extern long O2346[];
extern long O2304[];
extern long O1856[];
extern EIF_TYPE_INDEX Y2331[];
extern EIF_TYPE_INDEX *Y2331_gen_type [];
extern EIF_TYPE_INDEX Y2332[];
extern EIF_TYPE_INDEX *Y2332_gen_type [];
extern EIF_TYPE_INDEX Y1758[];
extern EIF_TYPE_INDEX *Y1758_gen_type [];
extern EIF_TYPE_INDEX Y1896[];
extern EIF_TYPE_INDEX *Y1896_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
