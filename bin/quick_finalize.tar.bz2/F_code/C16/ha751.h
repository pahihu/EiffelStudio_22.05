
#ifndef _C16_ha751_
#define _C16_ha751_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F272_2012(EIF_REFERENCE);
extern EIF_REFERENCE F272_2013(EIF_REFERENCE);
extern EIF_BOOLEAN F272_2015(EIF_REFERENCE);
extern void F272_2016(EIF_REFERENCE);
extern EIF_REFERENCE F272_2017(EIF_REFERENCE);
extern void EIF_Minit751(void);
extern EIF_BOOLEAN F258_1998(EIF_REFERENCE);
extern char *(*R1692[])();
extern char *(*R2322[])();
extern char *(*R2323[])();
extern char *(*R2130[])();

#ifdef __cplusplus
}
#endif

#endif
