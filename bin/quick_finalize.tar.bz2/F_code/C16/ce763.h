
#ifndef _C16_ce763_
#define _C16_ce763_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_64 F43_642(EIF_REFERENCE);
extern void F43_643(EIF_REFERENCE, EIF_NATURAL_64);
extern void EIF_Minit763(void);

#ifdef __cplusplus
}
#endif

#endif
