
#ifndef _C10_li477_
#define _C10_li477_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F356_2090(EIF_REFERENCE);
extern EIF_REFERENCE F356_2097(EIF_REFERENCE);
extern void EIF_Minit477(void);
extern EIF_BOOLEAN F475_2169(EIF_REFERENCE);
extern EIF_BOOLEAN F614_2734(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
