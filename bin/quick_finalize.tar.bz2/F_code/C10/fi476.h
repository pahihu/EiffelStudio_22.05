
#ifndef _C10_fi476_
#define _C10_fi476_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F475_2169(EIF_REFERENCE);
extern void EIF_Minit476(void);
extern char *(*R1918[])();

#ifdef __cplusplus
}
#endif

#endif
