
#ifndef _C10_ch469_
#define _C10_ch469_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F589_2702(EIF_REFERENCE);
extern EIF_BOOLEAN F589_2710(EIF_REFERENCE);
extern void EIF_Minit469(void);
extern EIF_INTEGER_32 F640_2846(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
