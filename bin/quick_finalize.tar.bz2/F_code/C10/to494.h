
#ifndef _C10_to494_
#define _C10_to494_

#ifdef __cplusplus
extern "C" {
#endif

extern void F130_1548(EIF_REFERENCE, EIF_INTEGER_32);
extern void F130_1549(EIF_REFERENCE, EIF_REAL_32, EIF_INTEGER_32);
extern void F130_1555(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit494(void);
extern void F552_2549(EIF_REFERENCE, EIF_REAL_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1437[];
extern EIF_TYPE_INDEX *Y1437_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
