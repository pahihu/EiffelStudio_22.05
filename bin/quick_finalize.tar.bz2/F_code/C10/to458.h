
#ifndef _C10_to458_
#define _C10_to458_

#ifdef __cplusplus
extern "C" {
#endif

extern void F129_1548(EIF_REFERENCE, EIF_INTEGER_32);
extern void F129_1549(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32);
extern void F129_1555(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit458(void);
extern void F551_2549(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1437[];
extern EIF_TYPE_INDEX *Y1437_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
