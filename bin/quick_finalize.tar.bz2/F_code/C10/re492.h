
#ifndef _C10_re492_
#define _C10_re492_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F500_2182(EIF_REFERENCE);
extern void EIF_Minit492(void);
extern char *(*R1921[])();

#ifdef __cplusplus
}
#endif

#endif
