/*
 * Code for class CONTAINER [REAL_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co473.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONTAINER}.compare_objects */
void F332_2071 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("compare_objects", 331, Current, 0, 0, 3541);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O1856[Dtype(Current)-324]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	RTEE;
}

void EIF_Minit473 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
