
#ifndef _C10_re485_
#define _C10_re485_

#ifdef __cplusplus
extern "C" {
#endif

extern void F263_1984(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F263_1986(EIF_REFERENCE);
extern EIF_INTEGER_32 F263_1987(EIF_REFERENCE);
extern EIF_INTEGER_32 F263_1988(EIF_REFERENCE);
extern EIF_INTEGER_32 F263_1989(EIF_REFERENCE);
extern EIF_BOOLEAN F263_1997(EIF_REFERENCE);
extern EIF_BOOLEAN F263_1998(EIF_REFERENCE);
extern void F263_2003(EIF_REFERENCE);
extern void EIF_Minit485(void);
extern char *(*R2131[])();
extern char *(*R2132[])();

#ifdef __cplusplus
}
#endif

#endif
