
#ifndef _C10_co473_
#define _C10_co473_

#ifdef __cplusplus
extern "C" {
#endif

extern void F332_2071(EIF_REFERENCE);
extern void EIF_Minit473(void);
extern long O1856[];

#ifdef __cplusplus
}
#endif

#endif
