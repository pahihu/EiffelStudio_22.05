
#ifndef _C10_li470_
#define _C10_li470_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F613_2734(EIF_REFERENCE);
extern void EIF_Minit470(void);
extern EIF_INTEGER_32 F640_2846(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
