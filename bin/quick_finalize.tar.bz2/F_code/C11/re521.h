
#ifndef _C11_re521_
#define _C11_re521_

#ifdef __cplusplus
extern "C" {
#endif

extern void F264_1984(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F264_1986(EIF_REFERENCE);
extern EIF_INTEGER_32 F264_1987(EIF_REFERENCE);
extern EIF_INTEGER_32 F264_1988(EIF_REFERENCE);
extern EIF_INTEGER_32 F264_1989(EIF_REFERENCE);
extern EIF_BOOLEAN F264_1997(EIF_REFERENCE);
extern EIF_BOOLEAN F264_1998(EIF_REFERENCE);
extern void F264_2003(EIF_REFERENCE);
extern void EIF_Minit521(void);
extern char *(*R2131[])();
extern char *(*R2132[])();

#ifdef __cplusplus
}
#endif

#endif
