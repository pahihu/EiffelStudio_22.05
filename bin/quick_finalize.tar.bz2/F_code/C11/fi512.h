
#ifndef _C11_fi512_
#define _C11_fi512_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F476_2169(EIF_REFERENCE);
extern void EIF_Minit512(void);
extern char *(*R1918[])();

#ifdef __cplusplus
}
#endif

#endif
