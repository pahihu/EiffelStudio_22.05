
#ifndef _C11_ch541_
#define _C11_ch541_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F591_2702(EIF_REFERENCE);
extern EIF_BOOLEAN F591_2710(EIF_REFERENCE);
extern void EIF_Minit541(void);
extern EIF_INTEGER_32 F642_2846(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
