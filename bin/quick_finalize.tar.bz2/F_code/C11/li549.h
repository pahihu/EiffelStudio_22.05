
#ifndef _C11_li549_
#define _C11_li549_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F358_2090(EIF_REFERENCE);
extern EIF_REFERENCE F358_2097(EIF_REFERENCE);
extern void EIF_Minit549(void);
extern EIF_BOOLEAN F477_2169(EIF_REFERENCE);
extern EIF_BOOLEAN F616_2734(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
