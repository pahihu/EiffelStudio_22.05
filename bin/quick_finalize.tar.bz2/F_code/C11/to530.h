
#ifndef _C11_to530_
#define _C11_to530_

#ifdef __cplusplus
extern "C" {
#endif

extern void F131_1548(EIF_REFERENCE, EIF_INTEGER_32);
extern void F131_1549(EIF_REFERENCE, EIF_REAL_64, EIF_INTEGER_32);
extern void F131_1555(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit530(void);
extern void F553_2549(EIF_REFERENCE, EIF_REAL_64, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1437[];
extern EIF_TYPE_INDEX *Y1437_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
