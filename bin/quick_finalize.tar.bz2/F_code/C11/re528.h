
#ifndef _C11_re528_
#define _C11_re528_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F501_2182(EIF_REFERENCE);
extern void EIF_Minit528(void);
extern char *(*R1921[])();

#ifdef __cplusplus
}
#endif

#endif
