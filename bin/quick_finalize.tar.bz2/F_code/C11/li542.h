
#ifndef _C11_li542_
#define _C11_li542_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F615_2734(EIF_REFERENCE);
extern void EIF_Minit542(void);
extern EIF_INTEGER_32 F642_2846(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
