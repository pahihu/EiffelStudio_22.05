
#ifndef _C11_co509_
#define _C11_co509_

#ifdef __cplusplus
extern "C" {
#endif

extern void F333_2071(EIF_REFERENCE);
extern void EIF_Minit509(void);
extern long O1856[];

#ifdef __cplusplus
}
#endif

#endif
