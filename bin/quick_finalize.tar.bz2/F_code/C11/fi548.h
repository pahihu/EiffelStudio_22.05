
#ifndef _C11_fi548_
#define _C11_fi548_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F477_2169(EIF_REFERENCE);
extern void EIF_Minit548(void);
extern char *(*R1918[])();

#ifdef __cplusplus
}
#endif

#endif
