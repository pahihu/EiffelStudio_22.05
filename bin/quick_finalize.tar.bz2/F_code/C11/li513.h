
#ifndef _C11_li513_
#define _C11_li513_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F357_2090(EIF_REFERENCE);
extern EIF_REFERENCE F357_2097(EIF_REFERENCE);
extern void EIF_Minit513(void);
extern EIF_BOOLEAN F476_2169(EIF_REFERENCE);
extern EIF_BOOLEAN F615_2734(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
