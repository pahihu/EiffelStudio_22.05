
#ifndef _C11_li506_
#define _C11_li506_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F614_2734(EIF_REFERENCE);
extern void EIF_Minit506(void);
extern EIF_INTEGER_32 F641_2846(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
