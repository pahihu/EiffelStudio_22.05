
#ifndef _C11_ch505_
#define _C11_ch505_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F590_2702(EIF_REFERENCE);
extern EIF_BOOLEAN F590_2710(EIF_REFERENCE);
extern void EIF_Minit505(void);
extern EIF_INTEGER_32 F641_2846(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
