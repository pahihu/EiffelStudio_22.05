
#ifndef _C11_co545_
#define _C11_co545_

#ifdef __cplusplus
extern "C" {
#endif

extern void F334_2071(EIF_REFERENCE);
extern void EIF_Minit545(void);
extern long O1856[];

#ifdef __cplusplus
}
#endif

#endif
