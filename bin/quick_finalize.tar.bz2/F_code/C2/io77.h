
#ifndef _C2_io77_
#define _C2_io77_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F97_1070(EIF_REFERENCE);
extern void F97_1073(EIF_REFERENCE, EIF_INTEGER_32);
extern void F97_1074(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit77(void);

#ifdef __cplusplus
}
#endif

#endif
