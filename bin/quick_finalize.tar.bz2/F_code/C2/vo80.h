
#ifndef _C2_vo80_
#define _C2_vo80_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F100_1078(EIF_REFERENCE);
extern void EIF_Minit80(void);

#ifdef __cplusplus
}
#endif

#endif
