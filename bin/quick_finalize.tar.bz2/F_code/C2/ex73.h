
#ifndef _C2_ex73_
#define _C2_ex73_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F93_1062(EIF_REFERENCE);
extern void EIF_Minit73(void);

#ifdef __cplusplus
}
#endif

#endif
