
#ifndef _C2_ch89_
#define _C2_ch89_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F109_1096(EIF_REFERENCE);
extern void EIF_Minit89(void);

#ifdef __cplusplus
}
#endif

#endif
