
#ifndef _C2_re99_
#define _C2_re99_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F119_1392(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit99(void);

#ifdef __cplusplus
}
#endif

#endif
