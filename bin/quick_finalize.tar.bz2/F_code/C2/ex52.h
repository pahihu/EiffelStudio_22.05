
#ifndef _C2_ex52_
#define _C2_ex52_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,960)
static EIF_REFERENCE F72_960_body(EIF_REFERENCE);
extern EIF_REFERENCE F72_960(EIF_REFERENCE);
extern void EIF_Minit52(void);

#ifdef __cplusplus
}
#endif

#endif
