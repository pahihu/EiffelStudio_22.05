
#ifndef _C2_op61_
#define _C2_op61_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F81_1023(EIF_REFERENCE);
extern void F81_1026(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit61(void);

#ifdef __cplusplus
}
#endif

#endif
