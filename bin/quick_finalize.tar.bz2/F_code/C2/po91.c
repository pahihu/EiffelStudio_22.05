/*
 * Code for class POSTCONDITION_VIOLATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "po91.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {POSTCONDITION_VIOLATION}.code */
EIF_INTEGER_32 F111_1102 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("code", 110, Current, 0, 0, 1190);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
}

void EIF_Minit91 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
