
#ifndef _C2_ol70_
#define _C2_ol70_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F90_1060(EIF_REFERENCE);
extern void EIF_Minit70(void);

#ifdef __cplusplus
}
#endif

#endif
