
#ifndef _C2_no74_
#define _C2_no74_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F94_1064(EIF_REFERENCE);
extern void F94_1066(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit74(void);

#ifdef __cplusplus
}
#endif

#endif
