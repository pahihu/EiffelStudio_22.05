
#ifndef _C2_pr92_
#define _C2_pr92_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F112_1104(EIF_REFERENCE);
extern void EIF_Minit92(void);

#ifdef __cplusplus
}
#endif

#endif
