
#ifndef _C2_vo83_
#define _C2_vo83_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F103_1088(EIF_REFERENCE);
extern void EIF_Minit83(void);

#ifdef __cplusplus
}
#endif

#endif
