
#ifndef _C2_po91_
#define _C2_po91_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F111_1102(EIF_REFERENCE);
extern void EIF_Minit91(void);

#ifdef __cplusplus
}
#endif

#endif
