/*
 * Code for class IO_MEDIUM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "io96.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IO_MEDIUM}.dispose */
void F116_1241 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("dispose", 115, Current, 0, 0, 1311);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !F530_2254(Current)) {
		RTHOOK(2);
		F530_2282(Current);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit96 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
