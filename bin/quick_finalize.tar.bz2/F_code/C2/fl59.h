
#ifndef _C2_fl59_
#define _C2_fl59_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F79_1021(EIF_REFERENCE);
extern void EIF_Minit59(void);

#ifdef __cplusplus
}
#endif

#endif
