
#ifndef _C2_va88_
#define _C2_va88_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F108_1094(EIF_REFERENCE);
extern void EIF_Minit88(void);

#ifdef __cplusplus
}
#endif

#endif
