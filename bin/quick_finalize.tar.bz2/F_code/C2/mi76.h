
#ifndef _C2_mi76_
#define _C2_mi76_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F96_1068(EIF_REFERENCE);
extern void EIF_Minit76(void);

#ifdef __cplusplus
}
#endif

#endif
