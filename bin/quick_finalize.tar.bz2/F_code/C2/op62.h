
#ifndef _C2_op62_
#define _C2_op62_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F82_1027(EIF_REFERENCE);
extern void F82_1030(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit62(void);

#ifdef __cplusplus
}
#endif

#endif
