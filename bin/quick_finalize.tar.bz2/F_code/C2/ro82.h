
#ifndef _C2_ro82_
#define _C2_ro82_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F102_1084(EIF_REFERENCE);
extern void F102_1086(EIF_REFERENCE, EIF_REFERENCE);
extern void F102_1087(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit82(void);

#ifdef __cplusplus
}
#endif

#endif
