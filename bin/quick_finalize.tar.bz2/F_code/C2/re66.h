
#ifndef _C2_re66_
#define _C2_re66_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F86_1052(EIF_REFERENCE);
extern void EIF_Minit66(void);

#ifdef __cplusplus
}
#endif

#endif
