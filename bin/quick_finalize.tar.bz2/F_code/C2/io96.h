
#ifndef _C2_io96_
#define _C2_io96_

#ifdef __cplusplus
extern "C" {
#endif

extern void F116_1241(EIF_REFERENCE);
extern void EIF_Minit96(void);
extern EIF_BOOLEAN F530_2254(EIF_REFERENCE);
extern void F530_2282(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
