/*
 * Code for class EXCEPTIONS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ex53.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EXCEPTIONS}.raise */
void F73_979 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("raise", 72, Current, 1, 1, 1067);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(74, 0x00).id, 74, _OBJSIZ_5_1_0_1_0_0_0_0_);
	RTHOOK(2);
	F74_1002(RTCW(loc1), arg1);
	RTHOOK(3);
	F74_987(RTCW(loc1));
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EXCEPTIONS}.raise_retrieval_exception */
void F73_980 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("raise_retrieval_exception", 72, Current, 1, 1, 1068);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(960,F72_960, (Current));
	tr1 = F38_592(RTCW(tr1), ((EIF_INTEGER_32) 31L));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		F74_1002(loc1, arg1);
		RTHOOK(3);
		F74_987(loc1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

void EIF_Minit53 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
