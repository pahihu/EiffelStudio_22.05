
#ifndef _C2_in90_
#define _C2_in90_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F110_1098(EIF_REFERENCE);
extern void F110_1099(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit90(void);

#ifdef __cplusplus
}
#endif

#endif
