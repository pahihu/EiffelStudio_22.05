
#ifndef _C2_ex65_
#define _C2_ex65_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F85_1050(EIF_REFERENCE);
extern void EIF_Minit65(void);

#ifdef __cplusplus
}
#endif

#endif
