
#ifndef _C2_ei69_
#define _C2_ei69_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F89_1056(EIF_REFERENCE);
extern void F89_1058(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit69(void);

#ifdef __cplusplus
}
#endif

#endif
