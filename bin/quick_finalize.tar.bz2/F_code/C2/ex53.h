
#ifndef _C2_ex53_
#define _C2_ex53_

#ifdef __cplusplus
extern "C" {
#endif

extern void F73_979(EIF_REFERENCE, EIF_REFERENCE);
extern void F73_980(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit53(void);
extern EIF_REFERENCE F38_592(EIF_REFERENCE, EIF_INTEGER_32);
extern void F74_987(EIF_REFERENCE);
extern EIF_REFERENCE F72_960(EIF_REFERENCE);
extern void F74_1002(EIF_REFERENCE, EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,960)

#ifdef __cplusplus
}
#endif

#endif
