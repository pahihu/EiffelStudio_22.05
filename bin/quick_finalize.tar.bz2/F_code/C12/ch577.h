
#ifndef _C12_ch577_
#define _C12_ch577_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F592_2702(EIF_REFERENCE);
extern EIF_BOOLEAN F592_2710(EIF_REFERENCE);
extern void EIF_Minit577(void);
extern EIF_INTEGER_32 F643_2846(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
