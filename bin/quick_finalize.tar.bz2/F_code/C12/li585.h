
#ifndef _C12_li585_
#define _C12_li585_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F359_2090(EIF_REFERENCE);
extern EIF_REFERENCE F359_2097(EIF_REFERENCE);
extern void EIF_Minit585(void);
extern EIF_BOOLEAN F478_2169(EIF_REFERENCE);
extern EIF_BOOLEAN F617_2734(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
