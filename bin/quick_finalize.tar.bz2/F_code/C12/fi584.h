
#ifndef _C12_fi584_
#define _C12_fi584_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F478_2169(EIF_REFERENCE);
extern void EIF_Minit584(void);
extern char *(*R1918[])();

#ifdef __cplusplus
}
#endif

#endif
