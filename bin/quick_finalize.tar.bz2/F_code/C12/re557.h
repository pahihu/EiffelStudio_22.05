
#ifndef _C12_re557_
#define _C12_re557_

#ifdef __cplusplus
extern "C" {
#endif

extern void F265_1984(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F265_1986(EIF_REFERENCE);
extern EIF_INTEGER_32 F265_1987(EIF_REFERENCE);
extern EIF_INTEGER_32 F265_1988(EIF_REFERENCE);
extern EIF_INTEGER_32 F265_1989(EIF_REFERENCE);
extern EIF_BOOLEAN F265_1997(EIF_REFERENCE);
extern EIF_BOOLEAN F265_1998(EIF_REFERENCE);
extern void F265_2003(EIF_REFERENCE);
extern void EIF_Minit557(void);
extern char *(*R2131[])();
extern char *(*R2132[])();

#ifdef __cplusplus
}
#endif

#endif
