
#ifndef _C12_re593_
#define _C12_re593_

#ifdef __cplusplus
extern "C" {
#endif

extern void F266_1984(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F266_1986(EIF_REFERENCE);
extern EIF_INTEGER_32 F266_1987(EIF_REFERENCE);
extern EIF_INTEGER_32 F266_1988(EIF_REFERENCE);
extern EIF_INTEGER_32 F266_1989(EIF_REFERENCE);
extern EIF_BOOLEAN F266_1997(EIF_REFERENCE);
extern EIF_BOOLEAN F266_1998(EIF_REFERENCE);
extern void F266_2003(EIF_REFERENCE);
extern void EIF_Minit593(void);
extern char *(*R2131[])();
extern char *(*R2132[])();

#ifdef __cplusplus
}
#endif

#endif
