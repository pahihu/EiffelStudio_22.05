
#ifndef _C12_co581_
#define _C12_co581_

#ifdef __cplusplus
extern "C" {
#endif

extern void F335_2071(EIF_REFERENCE);
extern void EIF_Minit581(void);
extern long O1856[];

#ifdef __cplusplus
}
#endif

#endif
