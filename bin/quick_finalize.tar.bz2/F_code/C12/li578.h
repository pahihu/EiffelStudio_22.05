
#ifndef _C12_li578_
#define _C12_li578_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F616_2734(EIF_REFERENCE);
extern void EIF_Minit578(void);
extern EIF_INTEGER_32 F643_2846(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
