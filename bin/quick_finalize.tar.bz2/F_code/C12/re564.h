
#ifndef _C12_re564_
#define _C12_re564_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F502_2182(EIF_REFERENCE);
extern void EIF_Minit564(void);
extern char *(*R1921[])();

#ifdef __cplusplus
}
#endif

#endif
