
#ifndef _C12_to566_
#define _C12_to566_

#ifdef __cplusplus
extern "C" {
#endif

extern void F132_1548(EIF_REFERENCE, EIF_INTEGER_32);
extern void F132_1549(EIF_REFERENCE, EIF_NATURAL_32, EIF_INTEGER_32);
extern void F132_1555(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit566(void);
extern void F554_2549(EIF_REFERENCE, EIF_NATURAL_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y1437[];
extern EIF_TYPE_INDEX *Y1437_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
