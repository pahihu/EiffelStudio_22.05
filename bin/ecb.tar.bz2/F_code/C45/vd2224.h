
#ifndef _C45_vd2224_
#define _C45_vd2224_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3270_38682(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F3270_38684(EIF_REFERENCE);
extern EIF_BOOLEAN F3270_38685(EIF_REFERENCE);
extern void F3270_38686(EIF_REFERENCE, EIF_REFERENCE);
extern void F3270_38687(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2224(void);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R14537[])();
extern char *(*R13453[])();
extern long O27854[];
extern long O27855[];
extern long O13528[];
extern long O13529[];

#ifdef __cplusplus
}
#endif

#endif
