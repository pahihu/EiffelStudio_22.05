
#ifndef _C45_fi2230_
#define _C45_fi2230_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F3276_38709(EIF_REFERENCE);
extern void F3276_38710(EIF_REFERENCE, EIF_REFERENCE);
extern void F3276_38712(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2230(void);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R14537[])();

#ifdef __cplusplus
}
#endif

#endif
