
#ifndef _C45_vn2241_
#define _C45_vn2241_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3287_38769(EIF_REFERENCE, EIF_REFERENCE);RTOSHF (EIF_REFERENCE, 38770)


extern EIF_REFERENCE F3287_38770(EIF_REFERENCE);
extern void F3287_38772(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2241(void);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R14537[])();

#ifdef __cplusplus
}
#endif

#endif
