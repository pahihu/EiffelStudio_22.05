/*
 * Code for class CLASS_ERROR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "cl2232.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CLASS_ERROR}.put_class_name */
void F3278_38715 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("Class name: ",12,457664288);
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {CLASS_ERROR}.build_explain */
void F3278_38716 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F3272_38692(Current, arg1);
	{
		/* INLINED CODE (CLASS_ERROR.put_class_name) */
		tr1 = RTMS_EX_H("Class name: ",12,457664288);
		F402_5843(RTCW(arg1), tr1);
		F402_5843(RTCW(arg1), *(EIF_REFERENCE *)(Current + _REFACS_5_));
		F1907_18034(RTCW(arg1));
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {CLASS_ERROR}.set_class_name */
void F3278_38717 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
}

void EIF_Minit2232 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
