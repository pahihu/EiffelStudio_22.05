/*
 * Code for class VTCT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "vt2248.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {VTCT}.make */
void F3294_38806 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg3);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLR(3,arg1);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	{
		/* INLINED CODE (EIFFEL_ERROR.set_class) */
		RTAR(Current, arg3);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg3;
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (ERROR.set_location) */
		ti4_1 = F323_4763(RTCW(arg2));
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_0_0_0_) = (EIF_INTEGER_32) ti4_1;
		ti4_1 = F323_4764(RTCW(arg2));
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_0_0_1_) = (EIF_INTEGER_32) ti4_1;
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (VTCT.set_class_name) */
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R17015[Dtype(RTCW(arg1))-2246])(arg1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {VTCT}.code */

EIF_REFERENCE F3294_38808 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (38808,RTMS_EX_H("VTCT",4,1448362836));
}

/* {VTCT}.less_than */
EIF_BOOLEAN F3294_38809 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	{
		/* INLINED CODE (CLASS_C.name) */
		tr2 = (EIF_REFERENCE)  0;
		(void) RTCW(tr1);
		tr2 = *(EIF_REFERENCE *)(RTCV(F2525_27079(tr1)) + _REFACS_1_);
		/* END INLINED CODE */
	}
	tr1 = tr2;
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
	{
		/* INLINED CODE (CLASS_C.name) */
		tr3 = (EIF_REFERENCE)  0;
		(void) RTCW(tr2);
		tr3 = *(EIF_REFERENCE *)(RTCV(F2525_27079(tr2)) + _REFACS_1_);
		/* END INLINED CODE */
	}
	tr2 = tr3;
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R9812[Dtype(RTCW(tr1))-798])(tr1, tr2);
	RTLE;
	return Result;
}

/* {VTCT}.build_explain */
void F3294_38810 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTMS_EX_H("Unknown class name: ",20,304267040);
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_0_0_0_) > ((EIF_INTEGER_32) 0L))) {
		{
			/* INLINED CODE (TEXT_FORMATTER.add_class_syntax) */
			tr1 = *(EIF_REFERENCE *)(Current);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			(void) RTCW(arg1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R14549[Dtype(arg1)-1908])(arg1, tr2, Current, tr1);
			/* END INLINED CODE */
		}
		;
	} else {
		{
			/* INLINED CODE (TEXT_OPERATOR.add) */
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			(void) RTCW(arg1);
			F1907_18035(arg1, tr1);
			/* END INLINED CODE */
		}
		;
		tr1 = RTMS_EX_H(" in ",4,543780384);
		{
			/* INLINED CODE (TEXT_OPERATOR.add) */
			(void) RTCW(arg1);
			F1907_18035(arg1, tr1);
			/* END INLINED CODE */
		}
		;
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R20610[Dtype(RTCW(tr1))-2525])(tr1);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O16110[Dtype(tr1)-2089]);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
		{
			/* INLINED CODE (TEXT_OPERATOR.add) */
			(void) RTCW(arg1);
			F1907_18035(arg1, tr1);
			/* END INLINED CODE */
		}
		;
	}
	{
		/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {VTCT}.print_single_line_error_message */
void F3294_38811 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_REFERENCE tr6 = NULL;
	EIF_REFERENCE tr7 = NULL;
	EIF_REFERENCE tr8 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(11);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,tr5);
	RTLR(8,tr6);
	RTLR(9,tr7);
	RTLR(10,tr8);
	RTLIU(11);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		{
			/* INLINED CODE (SHARED_LOCALE.locale) */
			tr1 = (EIF_REFERENCE)  0;
			tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(34789,F3069_34789, (Current))));
			/* END INLINED CODE */
		}
		tr2 = tr1;
		tr3 = RTMS_EX_H("Type is based on unknown class {1}.",35,214486574);
		tr4 = RTMS_EX_H("compiler.error",14,1616564082);
		tr1 = F111_2171(RTCW(tr2), tr3, tr4);
		{
			static EIF_TYPE_INDEX typarr0[] = {1928,2204,0xFFF9,2,2049,78,1906,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_0_0_0_) > ((EIF_INTEGER_32) 0L))) {
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,2049,3237,2524,2242,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4 = RTLNTS(typres0.id, 4, 0);
			}
			((EIF_TYPED_VALUE *)tr4+1)->it_r = Current;
			RTAR(tr4,Current);
			tr5 = *(EIF_REFERENCE *)(Current);
			((EIF_TYPED_VALUE *)tr4+2)->it_r = tr5;
			RTAR(tr4,tr5);
			((EIF_TYPED_VALUE *)tr4+3)->it_r = loc1;
			RTAR(tr4,loc1);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {2204,0xFFF9,1,2049,1906,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr7= RTLNRF(typres0.id, (EIF_POINTER) __A1092_307_1, (EIF_POINTER) _A1092_307_1, 0, tr4, 0, 1);
			}
			tr4 = tr7;
		} else {
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,2049,2242,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr5 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr5+1)->it_r = loc1;
			RTAR(tr5,loc1);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {2204,0xFFF9,1,2049,1906,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr8= RTLNRF(typres0.id, (EIF_POINTER) __A1092_208_1, (EIF_POINTER) _A1092_208_1, 0, tr5, 0, 1);
			}
			tr4 = tr8;
		}
		tr4 = F642_8384(Current, tr4);
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1929_18455)(tr3);
		{
			/* INLINED CODE (FORMATTED_MESSAGE.format) */
			tr4 = RTOSCF(8391,F642_8391, (Current));
			F78_1402(RTCW(tr4), arg1, tr1, tr2);
			/* END INLINED CODE */
		}
		;
	} else {
		{
			/* INLINED CODE (COMPILER_ERROR.print_single_line_error_message) */
			tr1 = F3240_38549(Current);
			F402_5843(RTCW(arg1), tr1);
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
}

/* {VTCT}.set_class_name */
void F3294_38812 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R17015[Dtype(RTCW(arg1))-2246])(arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {VTCT}.set_dotnet_class_name */
void F3294_38813 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
}

void EIF_Minit2248 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
