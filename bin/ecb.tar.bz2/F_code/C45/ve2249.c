/*
 * Code for class VE04
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ve2249.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {VE04}.code */

EIF_REFERENCE F3295_38815 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (38815,RTMS_EX_H("VHPR",4,1447579730));
}

/* {VE04}.subcode */
EIF_INTEGER_32 F3295_38816 (EIF_REFERENCE Current)
{
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
}

/* {VE04}.set_parent_type */
void F3295_38817 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
}

void EIF_Minit2249 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
