
#ifndef _C45_vd2211_
#define _C45_vd2211_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3257_38647(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2211(void);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R14537[])();

#ifdef __cplusplus
}
#endif

#endif
