/*
 * Code for class CLUSTER_ERROR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "cl2226.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CLUSTER_ERROR}.put_cluster_name */
void F3272_38692 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_4_) != NULL)) {
		tb1 = '\01';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R16098[Dtype(RTCW(tr1))-2091])(tr1);
		if (!tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R16099[Dtype(RTCW(tr1))-2091])(tr1);
			tb1 = tb2;
		}
		if (tb1) {
			tr1 = RTMS_EX_H("Assembly cluster name: ",23,529609504);
			{
				/* INLINED CODE (TEXT_OPERATOR.add) */
				(void) RTCW(arg1);
				F1907_18035(arg1, tr1);
				/* END INLINED CODE */
			}
			;
		} else {
			tr1 = RTMS_EX_H("Cluster name: ",14,867682592);
			{
				/* INLINED CODE (TEXT_OPERATOR.add) */
				(void) RTCW(arg1);
				F1907_18035(arg1, tr1);
				/* END INLINED CODE */
			}
			;
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O16106[Dtype(tr1)-2089]);
		{
			/* INLINED CODE (TEXT_OPERATOR.add) */
			(void) RTCW(arg1);
			F1907_18035(arg1, tr1);
			/* END INLINED CODE */
		}
		;
		{
			/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
			(void) RTCW(arg1);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
}

/* {CLUSTER_ERROR}.set_cluster */
void F3272_38694 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
}

void EIF_Minit2226 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
