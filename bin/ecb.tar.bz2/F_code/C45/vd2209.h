
#ifndef _C45_vd2209_
#define _C45_vd2209_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3255_38643(EIF_REFERENCE, EIF_REFERENCE);
extern void F3255_38645(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2209(void);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R14537[])();

#ifdef __cplusplus
}
#endif

#endif
