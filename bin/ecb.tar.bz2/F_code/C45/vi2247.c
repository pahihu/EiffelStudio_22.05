/*
 * Code for class VICR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "vi2247.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {VICR}.make */
void F3293_38801 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg2;
	RTLE;
}

/* {VICR}.code */

EIF_REFERENCE F3293_38803 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (38803,RTMS_EX_H("VICR",4,1447641938));
}

/* {VICR}.build_explain */
void F3293_38804 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLIU(6);
	
	RTGC;
	tr1 = RTMS_EX_H("No creation routine with name `",31,1336830816);
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	tr1 = F1769_16449(Current);
	{
		/* INLINED CODE (UNICODE_CONVERSION.utf8_to_utf32) */
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tr3 = (EIF_REFERENCE)  0;
		(void) RTCW(tr1);
		tr4 = RTLNS(eif_new_type(163, 0x00).id, 163, _OBJSIZ_0_0_0_0_0_0_0_0_);
		tr3 = F164_2793(RTCW(tr4), tr2);
		/* END INLINED CODE */
	}
	tr1 = tr3;
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	tr1 = RTMS_EX_H("\' in ",5,544079904);
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	tr1 = *(EIF_REFERENCE *)(Current);
	{
		/* INLINED CODE (CLASS_C.append_signature) */
		(void) RTCW(tr1);
		F2525_27256(tr1, arg1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0);
		/* END INLINED CODE */
	}
	;
	tr1 = RTMS_EX_H(".",1,46);
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

void EIF_Minit2247 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
