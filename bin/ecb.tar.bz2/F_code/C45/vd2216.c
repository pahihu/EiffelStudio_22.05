/*
 * Code for class VD15
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "vd2216.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {VD15}.build_explain */
void F3262_38656 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("Option: ",8,506059040);
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
		/* END INLINED CODE */
	}
	;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_5_) != NULL)) {
		tr1 = RTMS_EX_H("Invalid option value: ",22,734755616);
		{
			/* INLINED CODE (TEXT_OPERATOR.add) */
			(void) RTCW(arg1);
			F1907_18035(arg1, tr1);
			/* END INLINED CODE */
		}
		;
		{
			/* INLINED CODE (TEXT_OPERATOR.add) */
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			(void) RTCW(arg1);
			F1907_18035(arg1, tr1);
			/* END INLINED CODE */
		}
		;
	} else {
		tr1 = RTMS_EX_H("No option value",15,1611656293);
		{
			/* INLINED CODE (TEXT_OPERATOR.add) */
			(void) RTCW(arg1);
			F1907_18035(arg1, tr1);
			/* END INLINED CODE */
		}
		;
	}
	{
		/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {VD15}.set_option_name */
void F3262_38657 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
}

/* {VD15}.set_option_value */
void F3262_38658 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
}

void EIF_Minit2216 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
