
#ifndef _C45_vd2228_
#define _C45_vd2228_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3274_38701(EIF_REFERENCE, EIF_REFERENCE);
extern void F3274_38702(EIF_REFERENCE, EIF_REFERENCE);
extern void F3274_38703(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2228(void);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R14537[])();
extern long O16106[];

#ifdef __cplusplus
}
#endif

#endif
