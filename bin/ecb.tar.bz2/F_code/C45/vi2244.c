/*
 * Code for class VIIC
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "vi2244.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {VIIC}.make */
void F3290_38785 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {VIIC}.code */

EIF_REFERENCE F3290_38786 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (38786,RTMS_EX_H("VIIC",4,1447643459));
}

/* {VIIC}.build_explain */
void F3290_38787 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("Could not analyze .NET class ",29,66958624);
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	tr1 = *(EIF_REFERENCE *)(Current);
	{
		/* INLINED CODE (CLASS_C.append_signature) */
		(void) RTCW(tr1);
		F2525_27256(tr1, arg1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0);
		/* END INLINED CODE */
	}
	;
	tr1 = RTMS_EX_H(".",1,46);
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

void EIF_Minit2244 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
