
#ifndef _C45_vs2229_
#define _C45_vs2229_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3275_38706(EIF_REFERENCE, EIF_REFERENCE);
extern void F3275_38707(EIF_REFERENCE, EIF_REFERENCE);
extern void F3275_38708(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2229(void);
extern void F2098_20367(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F2014_18990(EIF_REFERENCE);
extern void F2250_22050(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern void F3272_38692(EIF_REFERENCE, EIF_REFERENCE);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R16911[])();
extern char *(*R14528[])();
extern char *(*R5674[])();
extern char *(*R14537[])();
extern char *(*R14516[])();
extern long O16110[];
extern long O16106[];

#ifdef __cplusplus
}
#endif

#endif
