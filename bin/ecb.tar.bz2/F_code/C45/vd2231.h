
#ifndef _C45_vd2231_
#define _C45_vd2231_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3277_38713(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2231(void);
extern void F1907_18034(EIF_REFERENCE);
extern void F402_5843(EIF_REFERENCE, EIF_REFERENCE);
extern void F3272_38692(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
