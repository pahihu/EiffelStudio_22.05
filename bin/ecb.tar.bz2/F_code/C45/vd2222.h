
#ifndef _C45_vd2222_
#define _C45_vd2222_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3268_38675(EIF_REFERENCE, EIF_REFERENCE);
extern void F3268_38676(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2222(void);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R14537[])();

#ifdef __cplusplus
}
#endif

#endif
