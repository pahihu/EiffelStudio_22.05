/*
 * Code for class VHPR1
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "vh2200.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {VHPR1}.code */

EIF_REFERENCE F3246_38604 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (38604,RTMS_EX_H("VHPR",4,1447579730));
}

/* {VHPR1}.subcode */
EIF_INTEGER_32 F3246_38605 (EIF_REFERENCE Current)
{
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
}

/* {VHPR1}.file_name */
EIF_REFERENCE F3246_38606 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

/* {VHPR1}.build_explain */
void F3246_38607 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	tr1 = RTMS_EX_H("Names of classes involved in cycle:",35,1918102586);
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
		/* END INLINED CODE */
	}
	;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	{
		/* INLINED CODE (LINKED_LIST.start) */
		(void) RTCW(tr1);
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(tr1) != NULL)) {
			tr2 = *(EIF_REFERENCE *)(tr1);
			RTAR(tr1, tr2);
			*(EIF_REFERENCE *)(tr1 + _REFACS_1_) = (EIF_REFERENCE) tr2;
			*(EIF_BOOLEAN *)(tr1 + O12203[Dtype(tr1)-1539]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			*(EIF_BOOLEAN *)(tr1 + O12203[Dtype(tr1)-1539]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		*(EIF_BOOLEAN *)(tr1 + O12202[Dtype(tr1)-1539]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		/* END INLINED CODE */
	}
	;
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O12203[Dtype(tr1)-1539]);
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		ti4_1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11812[Dtype(RTCW(tr1))-1344])(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		ti4_2 = F1543_14698(RTCW(tr1));
		if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(ti4_1 == ti4_2)) {
			tr1 = RTMS_EX_H(", ",2,11296);
			{
				/* INLINED CODE (TEXT_OPERATOR.add) */
				(void) RTCW(arg1);
				F1907_18035(arg1, tr1);
				/* END INLINED CODE */
			}
			;
		}
		tr1 = RTOSCF(17610,F1891_17610, (Current));
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		ti4_1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11812[Dtype(RTCW(tr2))-1344])(tr2));
		{
			/* INLINED CODE (E_SYSTEM.class_of_id) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(tr1);
			tr3 = RTOSCF(8191,F604_8191, (tr1));
			tr2 = F2493_26230(RTCW(tr3), ti4_1);
			/* END INLINED CODE */
		}
		tr1 = tr2;
		{
			/* INLINED CODE (CLASS_C.append_name) */
			(void) RTCW(tr1);
			tr2 = F2525_27079(tr1);
			F1907_18043(RTCW(arg1), tr2);
			/* END INLINED CODE */
		}
		;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11789[Dtype(RTCW(tr1))-1322])(tr1);
	}
	{
		/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {VHPR1}.set_involved_classes */
void F3246_38608 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
}

void EIF_Minit2200 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
