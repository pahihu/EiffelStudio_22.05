
#ifndef _C45_vd2212_
#define _C45_vd2212_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3258_38648(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2212(void);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R14537[])();

#ifdef __cplusplus
}
#endif

#endif
