
#ifndef _C45_vi2244_
#define _C45_vi2244_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3290_38785(EIF_REFERENCE, EIF_REFERENCE);RTOSHF (EIF_REFERENCE, 38786)


extern EIF_REFERENCE F3290_38786(EIF_REFERENCE);
extern void F3290_38787(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2244(void);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern void F2525_27256(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_BOOLEAN);
extern char *(*R14537[])();

#ifdef __cplusplus
}
#endif

#endif
