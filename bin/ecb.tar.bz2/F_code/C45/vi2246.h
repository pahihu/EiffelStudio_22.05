
#ifndef _C45_vi2246_
#define _C45_vi2246_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3292_38795(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);RTOSHF (EIF_REFERENCE, 38798)


extern EIF_REFERENCE F3292_38798(EIF_REFERENCE);
extern void F3292_38799(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2246(void);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern void F2525_27256(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_BOOLEAN);
extern char *(*R14531[])();
extern char *(*R14537[])();

#ifdef __cplusplus
}
#endif

#endif
