
#ifndef _C45_vd2220_
#define _C45_vd2220_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3266_38668(EIF_REFERENCE, EIF_REFERENCE);
extern void F3266_38670(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2220(void);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R14537[])();
extern char *(*R13453[])();

#ifdef __cplusplus
}
#endif

#endif
