/*
 * Code for class VDRD8
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "vd2237.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {VDRD8}.code */

EIF_REFERENCE F3283_38740 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (38740,RTMS_EX_H("VDRD",4,1447318084));
}

/* {VDRD8}.subcode */
EIF_INTEGER_32 F3283_38741 (EIF_REFERENCE Current)
{
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
}

/* {VDRD8}.build_explain */
void F3283_38743 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("Feature: ",9,1434942240);
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F3578_40168(RTCW(tr1), arg1);
	{
		/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
		/* END INLINED CODE */
	}
	;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_)) {
			tr1 = RTMS_EX_H("Invalid assertion clauses: precondition and postcondition",57,428246894);
			{
				/* INLINED CODE (TEXT_OPERATOR.add) */
				(void) RTCW(arg1);
				F1907_18035(arg1, tr1);
				/* END INLINED CODE */
			}
			;
		} else {
			tr1 = RTMS_EX_H("Invalid assertion clause: postcondition",39,1053350510);
			{
				/* INLINED CODE (TEXT_OPERATOR.add) */
				(void) RTCW(arg1);
				F1907_18035(arg1, tr1);
				/* END INLINED CODE */
			}
			;
		}
	} else {
		tr1 = RTMS_EX_H("Invalid assertion clause: precondition",38,1814372974);
		{
			/* INLINED CODE (TEXT_OPERATOR.add) */
			(void) RTCW(arg1);
			F1907_18035(arg1, tr1);
			/* END INLINED CODE */
		}
		;
	}
	{
		/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {VDRD8}.trace_primary_context */
void F3283_38744 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc1 = tr1;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = tr1;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && EIF_TEST(loc1)) && EIF_TEST(loc2))) {
		F503_7111(Current, arg1, loc1, loc2);
	} else {
		F3281_38726(Current, arg1);
	}
	RTLE;
}

/* {VDRD8}.print_single_line_error_message */
void F3283_38745 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	{
		/* INLINED CODE (COMPILER_ERROR.print_single_line_error_message) */
		tr1 = F3240_38549(Current);
		F402_5843(RTCW(arg1), tr1);
		/* END INLINED CODE */
	}
	;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_4_) != NULL)) {
		{
			/* INLINED CODE (TEXT_OPERATOR.add_space) */
			(void) RTCW(arg1);
			tr1 = RTOSCF(5830,F401_5830, (arg1));
			F402_5843(arg1, tr1);
			/* END INLINED CODE */
		}
		;
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_)) {
				tr1 = RTMS_EX_H("Invalid precondition and postcondition in feature ",50,838521376);
				{
					/* INLINED CODE (TEXT_OPERATOR.add) */
					(void) RTCW(arg1);
					F1907_18035(arg1, tr1);
					/* END INLINED CODE */
				}
				;
			} else {
				tr1 = RTMS_EX_H("Invalid postcondition in feature ",33,1065579296);
				{
					/* INLINED CODE (TEXT_OPERATOR.add) */
					(void) RTCW(arg1);
					F1907_18035(arg1, tr1);
					/* END INLINED CODE */
				}
				;
			}
		} else {
			tr1 = RTMS_EX_H("Invalid precondition in feature ",32,534054688);
			{
				/* INLINED CODE (TEXT_OPERATOR.add) */
				(void) RTCW(arg1);
				F1907_18035(arg1, tr1);
				/* END INLINED CODE */
			}
			;
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F3578_40168(RTCW(tr1), arg1);
	}
	RTLE;
}

/* {VDRD8}.set_feature */
void F3283_38746 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O21156[Dtype(arg1)-2542]);
	tr1 = F2543_28342(RTCW(arg1), ti4_1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {VDRD8}.set_postcondition */
void F3283_38747 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {VDRD8}.set_precondition */
void F3283_38748 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

void EIF_Minit2237 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
