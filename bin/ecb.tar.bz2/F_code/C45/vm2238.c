/*
 * Code for class VMFN2
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "vm2238.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {VMFN2}.code */

EIF_REFERENCE F3284_38750 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (38750,RTMS_EX_H("VMFN",4,1447904846));
}

/* {VMFN2}.build_explain */
void F3284_38752 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLR(6,arg1);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	{
		/* INLINED CODE (LINKED_LIST.start) */
		(void) RTCW(tr1);
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(tr1) != NULL)) {
			tr2 = *(EIF_REFERENCE *)(tr1);
			RTAR(tr1, tr2);
			*(EIF_REFERENCE *)(tr1 + _REFACS_1_) = (EIF_REFERENCE) tr2;
			*(EIF_BOOLEAN *)(tr1 + O12203[Dtype(tr1)-1539]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			*(EIF_BOOLEAN *)(tr1 + O12203[Dtype(tr1)-1539]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		*(EIF_BOOLEAN *)(tr1 + O12202[Dtype(tr1)-1539]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		/* END INLINED CODE */
	}
	;
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O12203[Dtype(tr1)-1539]);
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11812[Dtype(RTCW(tr1))-1344])(tr1);
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
		loc3 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
		tr1 = RTMS_EX_H("Feature: ",9,1434942240);
		{
			/* INLINED CODE (TEXT_OPERATOR.add) */
			(void) RTCW(arg1);
			F1907_18035(arg1, tr1);
			/* END INLINED CODE */
		}
		;
		{
			/* INLINED CODE (E_FEATURE.append_signature) */
			(void) RTCW(loc2);
			F3578_40169(loc2, arg1);
			F3578_40165(loc2, arg1);
			/* END INLINED CODE */
		}
		;
		tr1 = RTMS_EX_H(" inherited from: ",17,99049504);
		{
			/* INLINED CODE (TEXT_OPERATOR.add) */
			(void) RTCW(arg1);
			F1907_18035(arg1, tr1);
			/* END INLINED CODE */
		}
		;
		{
			/* INLINED CODE (CLASS_C.append_name) */
			(void) RTCW(loc3);
			tr1 = F2525_27079(loc3);
			F1907_18043(RTCW(arg1), tr1);
			/* END INLINED CODE */
		}
		;
		tr1 = RTMS_EX_H(" Version from: ",15,338440736);
		{
			/* INLINED CODE (TEXT_OPERATOR.add) */
			(void) RTCW(arg1);
			F1907_18035(arg1, tr1);
			/* END INLINED CODE */
		}
		;
		{
			/* INLINED CODE (E_FEATURE.written_class) */
			tr1 = (EIF_REFERENCE)  0;
			(void) RTCW(loc2);
			tr2 = RTOSCF(17610,F1891_17610, (loc2));
			tr1 = F2308_23150(RTCW(tr2), *(EIF_INTEGER_32 *)(loc2 + O28748[Dtype(loc2)-3577]));
			/* END INLINED CODE */
		}
		tr1 = tr1;
		{
			/* INLINED CODE (CLASS_C.append_name) */
			(void) RTCW(tr1);
			tr2 = F2525_27079(tr1);
			F1907_18043(RTCW(arg1), tr2);
			/* END INLINED CODE */
		}
		;
		{
			/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
			(void) RTCW(arg1);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
			/* END INLINED CODE */
		}
		;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11789[Dtype(RTCW(tr1))-1322])(tr1);
	}
	RTLE;
}

/* {VMFN2}.set_features */
void F3284_38753 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,loc4);
	RTLR(7,tr3);
	RTLR(8,loc3);
	RTLR(9,loc1);
	RTLIU(10);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {1539,559,3577,2524,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc5 = RTLNSMART(typres0.id);
	}
	F1540_14695(RTCW(loc5));
	{
		/* INLINED CODE (ARRAYED_LIST.start) */
		(void) RTCW(arg1);
		*(EIF_INTEGER_32 *)(arg1 + O12312[Dtype(arg1)-1565]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		/* END INLINED CODE */
	}
	;
	for (;;) {
		{
			/* INLINED CODE (LIST.after) */
			tb1 = (EIF_BOOLEAN)  0;
			(void) RTCW(arg1);
			ti4_1 = *(EIF_INTEGER_32 *)(arg1 + O12312[Dtype(arg1)-1565]);
			ti4_2 = F1566_14933(arg1);
			tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
			/* END INLINED CODE */
		}
		tb1 = tb1;
		if (tb1) break;
		{
			/* INLINED CODE (ARRAYED_LIST.item) */
			tr1 = (EIF_REFERENCE)  0;
			(void) RTCW(arg1);
			tr2 = *(EIF_REFERENCE *)(arg1);
			tr1 = 
				/* INLINED CODE (SPECIAL.item) */
				*((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(arg1 + O12312[Dtype(arg1)-1565]) - ((EIF_INTEGER_32) 1L))))
				/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		loc2 = tr1;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_1_);
		{
			/* INLINED CODE (PARENT_C.parent) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(tr1);
			tr3 = *(EIF_REFERENCE *)(tr1 + _REFACS_1_);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R21714[Dtype(RTCW(tr3))-2613])(tr3);
			/* END INLINED CODE */
		}
		loc4 = tr2;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
		tr2 = *(EIF_REFERENCE *)(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2) + O12662[Dtype(tr2)-1663]);
		loc3 = F2543_28342(RTCW(tr1), ti4_1);
		{
			static EIF_TYPE_INDEX typarr0[] = {559,3577,2524,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNS(typres0.id, 559, _OBJSIZ_2_0_0_0_0_0_0_0_);
		}
		F560_7471(RTCW(loc1), loc3, loc4);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11799[Dtype(RTCW(loc5))-1322])(loc5, loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11789[Dtype(RTCW(loc5))-1322])(loc5);
		{
			/* INLINED CODE (ARRAYED_LIST.forth) */
			(void) RTCW(arg1);
			(*(EIF_INTEGER_32 *)(arg1 + O12312[Dtype(arg1)-1565]))++;
			/* END INLINED CODE */
		}
		;
	}
	RTAR(Current, loc5);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) loc5;
	RTLE;
}

void EIF_Minit2238 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
