/*
 * Code for class VD24
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "vd2234.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {VD24}.build_explain */
void F3280_38719 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	{
		/* INLINED CODE (CLASS_ERROR.put_class_name) */
		tr1 = RTMS_EX_H("Class name: ",12,457664288);
		F402_5843(RTCW(arg1), tr1);
		F402_5843(RTCW(arg1), *(EIF_REFERENCE *)(Current + _REFACS_5_));
		F1907_18034(RTCW(arg1));
		/* END INLINED CODE */
	}
	;
	tr1 = RTMS_EX_H("First cluster: ",15,1263663136);
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O16106[Dtype(tr1)-2089]);
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
		/* END INLINED CODE */
	}
	;
	tr1 = RTMS_EX_H("Second cluster: ",16,1365845024);
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O16106[Dtype(tr1)-2089]);
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {VD24}.set_other_cluster */
void F3280_38720 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg1;
}

void EIF_Minit2234 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
