/*
 * Code for class VSCN
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "vs2229.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {VSCN}.build_explain */
void F3275_38706 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc2 = RTRV(eif_new_type(2526, 0x00), loc2);
	F3272_38692(Current, arg1);
	tr1 = RTMS_EX_H("First class: ",13,1127071776);
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	{
		/* INLINED CODE (TEXT_FORMATTER.add_classi) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R14528[Dtype(arg1)-1908])(arg1, tr1, loc2, (EIF_BOOLEAN) 0);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
		/* END INLINED CODE */
	}
	;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc1 = RTRV(eif_new_type(2527, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = RTMS_EX_H("In assembly: \"",14,522946850);
		{
			/* INLINED CODE (TEXT_OPERATOR.add) */
			(void) RTCW(arg1);
			F1907_18035(arg1, tr1);
			/* END INLINED CODE */
		}
		;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_3_);
		F2098_20367(RTCW(tr1), arg1);
	} else {
		tr1 = RTMS_EX_H("First file: \"",13,245104418);
		{
			/* INLINED CODE (TEXT_OPERATOR.add) */
			(void) RTCW(arg1);
			F1907_18035(arg1, tr1);
			/* END INLINED CODE */
		}
		;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R16911[Dtype(RTCW(tr1))-2239])(tr1);
		tr1 = F2014_18990(RTCW(tr1));
		{
			/* INLINED CODE (TEXT_OPERATOR.add) */
			(void) RTCW(arg1);
			F1907_18035(arg1, tr1);
			/* END INLINED CODE */
		}
		;
		tr1 = RTMS_EX_H("\"",1,34);
		{
			/* INLINED CODE (TEXT_OPERATOR.add) */
			(void) RTCW(arg1);
			F1907_18035(arg1, tr1);
			/* END INLINED CODE */
		}
		;
		{
			/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
			(void) RTCW(arg1);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
			/* END INLINED CODE */
		}
		;
		tr1 = RTMS_EX_H("Referenced from: ",17,562235936);
		{
			/* INLINED CODE (TEXT_OPERATOR.add) */
			(void) RTCW(arg1);
			F1907_18035(arg1, tr1);
			/* END INLINED CODE */
		}
		;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O16110[Dtype(tr1)-2089]);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_8_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		{
			/* INLINED CODE (TEXT_OPERATOR.add) */
			(void) RTCW(arg1);
			F1907_18035(arg1, tr1);
			/* END INLINED CODE */
		}
		;
		tr1 = RTMS_EX_H(" (",2,8232);
		{
			/* INLINED CODE (TEXT_FORMATTER.add_string) */
			(void) RTCW(arg1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R14516[Dtype(arg1)-1908])(arg1, tr1);
			/* END INLINED CODE */
		}
		;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O16106[Dtype(tr1)-2089]);
		{
			/* INLINED CODE (TEXT_OPERATOR.add) */
			(void) RTCW(arg1);
			F1907_18035(arg1, tr1);
			/* END INLINED CODE */
		}
		;
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ')';
		{
			/* INLINED CODE (TEXT_FORMATTER.add_char) */
			(void) RTCW(arg1);
			tr1 = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F2250_22050(RTCW(tr1), tw1, ((EIF_INTEGER_32) 1L));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5674[Dtype(arg1)-1908])(arg1, tr1);
			/* END INLINED CODE */
		}
		;
	}
	{
		/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
		/* END INLINED CODE */
	}
	;
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc2 = RTRV(eif_new_type(2526, 0x00), loc2);
	tr1 = RTMS_EX_H("Second class: ",14,137874720);
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	{
		/* INLINED CODE (TEXT_FORMATTER.add_classi) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R14528[Dtype(arg1)-1908])(arg1, tr1, loc2, (EIF_BOOLEAN) 0);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
		/* END INLINED CODE */
	}
	;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = RTRV(eif_new_type(2527, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = RTMS_EX_H("In assembly: \"",14,522946850);
		{
			/* INLINED CODE (TEXT_OPERATOR.add) */
			(void) RTCW(arg1);
			F1907_18035(arg1, tr1);
			/* END INLINED CODE */
		}
		;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_3_);
		F2098_20367(RTCW(tr1), arg1);
	} else {
		tr1 = RTMS_EX_H("Second file: \"",14,1403387170);
		{
			/* INLINED CODE (TEXT_OPERATOR.add) */
			(void) RTCW(arg1);
			F1907_18035(arg1, tr1);
			/* END INLINED CODE */
		}
		;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R16911[Dtype(RTCW(tr1))-2239])(tr1);
		tr1 = F2014_18990(RTCW(tr1));
		{
			/* INLINED CODE (TEXT_OPERATOR.add) */
			(void) RTCW(arg1);
			F1907_18035(arg1, tr1);
			/* END INLINED CODE */
		}
		;
		tr1 = RTMS_EX_H("\"",1,34);
		{
			/* INLINED CODE (TEXT_OPERATOR.add) */
			(void) RTCW(arg1);
			F1907_18035(arg1, tr1);
			/* END INLINED CODE */
		}
		;
		{
			/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
			(void) RTCW(arg1);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
			/* END INLINED CODE */
		}
		;
		tr1 = RTMS_EX_H("Referenced from: ",17,562235936);
		{
			/* INLINED CODE (TEXT_OPERATOR.add) */
			(void) RTCW(arg1);
			F1907_18035(arg1, tr1);
			/* END INLINED CODE */
		}
		;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O16110[Dtype(tr1)-2089]);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_8_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		{
			/* INLINED CODE (TEXT_OPERATOR.add) */
			(void) RTCW(arg1);
			F1907_18035(arg1, tr1);
			/* END INLINED CODE */
		}
		;
		tr1 = RTMS_EX_H(" (",2,8232);
		{
			/* INLINED CODE (TEXT_FORMATTER.add_string) */
			(void) RTCW(arg1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R14516[Dtype(arg1)-1908])(arg1, tr1);
			/* END INLINED CODE */
		}
		;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O16106[Dtype(tr1)-2089]);
		{
			/* INLINED CODE (TEXT_OPERATOR.add) */
			(void) RTCW(arg1);
			F1907_18035(arg1, tr1);
			/* END INLINED CODE */
		}
		;
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ')';
		{
			/* INLINED CODE (TEXT_FORMATTER.add_char) */
			(void) RTCW(arg1);
			tr1 = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F2250_22050(RTCW(tr1), tw1, ((EIF_INTEGER_32) 1L));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5674[Dtype(arg1)-1908])(arg1, tr1);
			/* END INLINED CODE */
		}
		;
	}
	{
		/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {VSCN}.set_first */
void F3275_38707 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
}

/* {VSCN}.set_second */
void F3275_38708 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg1;
}

void EIF_Minit2229 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
