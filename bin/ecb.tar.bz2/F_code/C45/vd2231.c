/*
 * Code for class VD21
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "vd2231.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {VD21}.build_explain */
void F3277_38713 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_4_) != NULL)) {
		F3272_38692(Current, arg1);
	}
	{
		/* INLINED CODE (FILE_ERROR.put_file_name) */
		tr1 = RTMS_EX_H("File name: ",11,2020237088);
		F402_5843(RTCW(arg1), tr1);
		F402_5843(RTCW(arg1), *(EIF_REFERENCE *)(Current + _REFACS_5_));
		F1907_18034(RTCW(arg1));
		/* END INLINED CODE */
	}
	;
	RTLE;
}

void EIF_Minit2231 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
