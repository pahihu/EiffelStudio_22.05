
#ifndef _C45_vl2245_
#define _C45_vl2245_

#ifdef __cplusplus
extern "C" {
#endif
RTOSHF (EIF_REFERENCE, 38790)


extern EIF_REFERENCE F3291_38790(EIF_REFERENCE);
extern EIF_BOOLEAN F3291_38791(EIF_REFERENCE);
extern void F3291_38793(EIF_REFERENCE, EIF_REFERENCE);
extern void F3291_38794(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2245(void);
extern EIF_REFERENCE F2525_27079(EIF_REFERENCE);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern void F1907_18043(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R14537[])();

#ifdef __cplusplus
}
#endif

#endif
