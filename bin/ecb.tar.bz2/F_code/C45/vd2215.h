
#ifndef _C45_vd2215_
#define _C45_vd2215_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3261_38653(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2215(void);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R14537[])();

#ifdef __cplusplus
}
#endif

#endif
