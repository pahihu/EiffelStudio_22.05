
#ifndef _C45_vd2227_
#define _C45_vd2227_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3273_38695(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F3273_38698(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2227(void);
extern void F2098_20367(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F2014_18990(EIF_REFERENCE);
extern void F3272_38692(EIF_REFERENCE, EIF_REFERENCE);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R20763[])();
extern char *(*R14528[])();
extern char *(*R14537[])();

#ifdef __cplusplus
}
#endif

#endif
