
#ifndef _C45_vd2204_
#define _C45_vd2204_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3250_38622(EIF_REFERENCE, EIF_REFERENCE);
extern void F3250_38623(EIF_REFERENCE, EIF_REFERENCE);
extern void F3250_38624(EIF_REFERENCE, EIF_REFERENCE);
extern void F3250_38625(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2204(void);
extern void F2243_21753(EIF_REFERENCE);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R14537[])();

#ifdef __cplusplus
}
#endif

#endif
