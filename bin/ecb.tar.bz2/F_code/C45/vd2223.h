
#ifndef _C45_vd2223_
#define _C45_vd2223_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3269_38679(EIF_REFERENCE, EIF_REFERENCE);
extern void F3269_38680(EIF_REFERENCE, EIF_REFERENCE);
extern void F3269_38681(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2223(void);
extern EIF_REFERENCE F2525_27079(EIF_REFERENCE);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern void F1907_18043(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R14537[])();

#ifdef __cplusplus
}
#endif

#endif
