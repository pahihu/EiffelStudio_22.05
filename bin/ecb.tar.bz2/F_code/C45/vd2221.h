
#ifndef _C45_vd2221_
#define _C45_vd2221_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3267_38671(EIF_REFERENCE, EIF_REFERENCE);
extern void F3267_38673(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2221(void);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R14537[])();

#ifdef __cplusplus
}
#endif

#endif
