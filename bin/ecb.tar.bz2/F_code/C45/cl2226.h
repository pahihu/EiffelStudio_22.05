
#ifndef _C45_cl2226_
#define _C45_cl2226_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3272_38692(EIF_REFERENCE, EIF_REFERENCE);
extern void F3272_38694(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2226(void);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R16098[])();
extern char *(*R16099[])();
extern char *(*R14537[])();
extern long O16106[];

#ifdef __cplusplus
}
#endif

#endif
