
#ifndef _C45_vd2207_
#define _C45_vd2207_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3253_38639(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2207(void);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R14537[])();

#ifdef __cplusplus
}
#endif

#endif
