/*
 * Code for class VD74
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "vd2211.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {VD74}.build_explain */
void F3257_38647 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
		/* END INLINED CODE */
	}
	;
	tr1 = RTMS_EX_H("Precompile was added to a compiled system.",42,1453253934);
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

void EIF_Minit2211 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
