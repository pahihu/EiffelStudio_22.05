
#ifndef _C45_la2201_
#define _C45_la2201_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F3247_38609(EIF_REFERENCE);
extern EIF_REFERENCE F3247_38610(EIF_REFERENCE);
extern EIF_REFERENCE F3247_38611(EIF_REFERENCE);
extern void EIF_Minit2201(void);
extern EIF_REFERENCE F2525_27174(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
