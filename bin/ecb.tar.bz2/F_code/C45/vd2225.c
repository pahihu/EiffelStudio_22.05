/*
 * Code for class VD77
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "vd2225.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {VD77}.make */
void F3271_38688 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
	{
		/* INLINED CODE (VD00.make_error) */
		F3270_38687(Current, arg2);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {VD77}.build_explain */
void F3271_38690 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_REFERENCE tr6 = NULL;
	RTLD;
	
	RTLI(8);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLR(7,tr6);
	RTLIU(8);
	
	RTGC;
	{
		/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
		/* END INLINED CODE */
	}
	;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13453[Dtype(RTCW(tr1))-1729])(tr1);
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (SHARED_LOCALE.locale) */
		tr1 = (EIF_REFERENCE)  0;
		tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(34789,F3069_34789, (Current))));
		/* END INLINED CODE */
	}
	tr2 = tr1;
	{
		/* INLINED CODE (SHARED_LOCALE.locale) */
		tr3 = (EIF_REFERENCE)  0;
		tr3 = *(EIF_REFERENCE *)(RTCV(RTOSCF(34789,F3069_34789, (Current))));
		/* END INLINED CODE */
	}
	tr4 = tr3;
	tr5 = RTMS_EX_H("Specified location: $1",22,1519638321);
	tr6 = RTMS_EX_H("compiler",8,2040338290);
	tr3 = F111_2171(RTCW(tr4), tr5, tr6);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,2049,2251,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr4 = RTLNTS(typres0.id, 2, 0);
	}
	tr5 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	((EIF_TYPED_VALUE *)tr4+1)->it_r = tr5;
	RTAR(tr4,tr5);
	{
		/* INLINED CODE (I18N_LOCALE.formatted_string) */
		tr5 = (EIF_REFERENCE)  0;
		(void) RTCW(tr2);
		tr6 = *(EIF_REFERENCE *)(tr2 + _REFACS_4_);
		tr5 = F63_957(RTCW(tr6), tr3, tr4);
		/* END INLINED CODE */
	}
	tr1 = tr5;
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

void EIF_Minit2225 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
