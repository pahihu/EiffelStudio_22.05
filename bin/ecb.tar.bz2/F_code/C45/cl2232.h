
#ifndef _C45_cl2232_
#define _C45_cl2232_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3278_38715(EIF_REFERENCE, EIF_REFERENCE);
extern void F3278_38716(EIF_REFERENCE, EIF_REFERENCE);
extern void F3278_38717(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2232(void);
extern void F1907_18034(EIF_REFERENCE);
extern void F402_5843(EIF_REFERENCE, EIF_REFERENCE);
extern void F3272_38692(EIF_REFERENCE, EIF_REFERENCE);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R14537[])();

#ifdef __cplusplus
}
#endif

#endif
