
#ifndef _C45_vd2208_
#define _C45_vd2208_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3254_38640(EIF_REFERENCE, EIF_REFERENCE);
extern void F3254_38642(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2208(void);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R14537[])();

#ifdef __cplusplus
}
#endif

#endif
