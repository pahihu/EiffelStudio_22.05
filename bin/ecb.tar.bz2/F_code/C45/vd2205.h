
#ifndef _C45_vd2205_
#define _C45_vd2205_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3251_38630(EIF_REFERENCE, EIF_REFERENCE);
extern void F3251_38631(EIF_REFERENCE, EIF_REFERENCE);
extern void F3251_38632(EIF_REFERENCE, EIF_REFERENCE);
extern void F3251_38633(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2205(void);
extern void F2248_22022(EIF_REFERENCE, EIF_CHARACTER_8);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R14537[])();

#ifdef __cplusplus
}
#endif

#endif
