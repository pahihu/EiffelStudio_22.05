
#ifndef _C45_vd2206_
#define _C45_vd2206_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3252_38636(EIF_REFERENCE, EIF_REFERENCE);
extern void F3252_38637(EIF_REFERENCE, EIF_REFERENCE);
extern void F3252_38638(EIF_REFERENCE);
extern void EIF_Minit2206(void);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R14537[])();

#ifdef __cplusplus
}
#endif

#endif
