/*
 * Code for class VCCH1
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "vc2236.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {VCCH1}.code */

EIF_REFERENCE F3282_38730 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (38730,RTMS_EX_H("VCCH",4,1447248712));
}

/* {VCCH1}.subcode */
EIF_INTEGER_32 F3282_38731 (EIF_REFERENCE Current)
{
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
}

/* {VCCH1}.is_defined */
EIF_BOOLEAN F3282_38732 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = '\0';
	{
		/* INLINED CODE (EIFFEL_ERROR.is_class_defined) */
		tb1 = (EIF_BOOLEAN)  0;
		tr1 = *(EIF_REFERENCE *)(Current);
		tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 != NULL);
		/* END INLINED CODE */
	}
	if (tb1) {
		Result = (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_4_) != NULL);
	}
	RTLE;
	return Result;
}

/* {VCCH1}.build_explain */
void F3282_38733 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	{
		/* INLINED CODE (E_FEATURE.written_class) */
		tr2 = (EIF_REFERENCE)  0;
		(void) RTCW(tr1);
		tr3 = RTOSCF(17610,F1891_17610, (tr1));
		tr2 = F2308_23150(RTCW(tr3), *(EIF_INTEGER_32 *)(tr1 + O28748[Dtype(tr1)-3577]));
		/* END INLINED CODE */
	}
	loc1 = tr2;
	tr1 = RTMS_EX_H("Deferred feature: ",18,1032146208);
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F3578_40168(RTCW(tr1), arg1);
	tr1 = RTMS_EX_H(" From: ",7,934219296);
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (CLASS_C.append_name) */
		(void) RTCW(loc1);
		tr1 = F2525_27079(loc1);
		F1907_18043(RTCW(arg1), tr1);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {VCCH1}.trace_primary_context */
void F3282_38734 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc1 = tr1;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = tr1;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && EIF_TEST(loc1)) && EIF_TEST(loc2))) {
		F503_7111(Current, arg1, loc1, loc2);
	} else {
		F3281_38726(Current, arg1);
	}
	RTLE;
}

/* {VCCH1}.print_single_line_error_message */
void F3282_38735 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	{
		/* INLINED CODE (COMPILER_ERROR.print_single_line_error_message) */
		tr1 = F3240_38549(Current);
		F402_5843(RTCW(arg1), tr1);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (VCCH1.is_defined) */
		tb1 = (EIF_BOOLEAN)  0;
		tb1 = '\0';
		tb2 = F3281_38723(Current);
		if (tb2) {
			tb1 = (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_4_) != NULL);
		}
		/* END INLINED CODE */
	}
	if (tb1) {
		{
			/* INLINED CODE (TEXT_OPERATOR.add_space) */
			(void) RTCW(arg1);
			tr1 = RTOSCF(5830,F401_5830, (arg1));
			F402_5843(arg1, tr1);
			/* END INLINED CODE */
		}
		;
		tr1 = RTMS_EX_H("Check deferred feature ",23,858580768);
		{
			/* INLINED CODE (TEXT_OPERATOR.add) */
			(void) RTCW(arg1);
			F1907_18035(arg1, tr1);
			/* END INLINED CODE */
		}
		;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F3578_40168(RTCW(tr1), arg1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		{
			/* INLINED CODE (E_FEATURE.written_class) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(tr1);
			tr3 = RTOSCF(17610,F1891_17610, (tr1));
			tr2 = F2308_23150(RTCW(tr3), *(EIF_INTEGER_32 *)(tr1 + O28748[Dtype(tr1)-3577]));
			/* END INLINED CODE */
		}
		tr1 = tr2;
		if ((EIF_BOOLEAN)(tr1 != *(EIF_REFERENCE *)(Current))) {
			tr1 = RTMS_EX_H(" from class ",12,1443645472);
			{
				/* INLINED CODE (TEXT_OPERATOR.add) */
				(void) RTCW(arg1);
				F1907_18035(arg1, tr1);
				/* END INLINED CODE */
			}
			;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			{
				/* INLINED CODE (E_FEATURE.written_class) */
				tr2 = (EIF_REFERENCE)  0;
				(void) RTCW(tr1);
				tr3 = RTOSCF(17610,F1891_17610, (tr1));
				tr2 = F2308_23150(RTCW(tr3), *(EIF_INTEGER_32 *)(tr1 + O28748[Dtype(tr1)-3577]));
				/* END INLINED CODE */
			}
			tr1 = tr2;
			{
				/* INLINED CODE (CLASS_C.append_name) */
				(void) RTCW(tr1);
				tr2 = F2525_27079(tr1);
				F1907_18043(RTCW(arg1), tr2);
				/* END INLINED CODE */
			}
			;
		}
		tr1 = RTMS_EX_H(".",1,46);
		{
			/* INLINED CODE (TEXT_OPERATOR.add) */
			(void) RTCW(arg1);
			F1907_18035(arg1, tr1);
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
}

/* {VCCH1}.set_a_feature */
void F3282_38736 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O21156[Dtype(arg1)-2542]);
	tr1 = F2543_28342(RTCW(arg1), ti4_1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit2236 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
