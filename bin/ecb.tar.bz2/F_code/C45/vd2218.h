
#ifndef _C45_vd2218_
#define _C45_vd2218_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3264_38662(EIF_REFERENCE, EIF_REFERENCE);
extern void F3264_38664(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2218(void);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R14537[])();
extern char *(*R13453[])();

#ifdef __cplusplus
}
#endif

#endif
