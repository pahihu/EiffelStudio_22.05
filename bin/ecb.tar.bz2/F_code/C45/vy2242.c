/*
 * Code for class VYCQ
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "vy2242.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {VYCQ}.make */
void F3288_38773 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,arg3);
	RTLR(6,arg4);
	RTLIU(7);
	
	RTGC;
	{
		/* INLINED CODE (EIFFEL_ERROR.set_class) */
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (FEATURE_NAME.visual_name) */
		tr1 = (EIF_REFERENCE)  0;
		(void) RTCW(arg2);
		tr2 = *(EIF_REFERENCE *)(arg2 + _REFACS_1_);
		tr1 = F3771_44603(RTCW(tr2));
		/* END INLINED CODE */
	}
	tr1 = tr1;
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg3;
	{
		/* INLINED CODE (ERROR.set_location) */
		ti4_1 = F323_4763(RTCW(arg4));
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_0_0_0_) = (EIF_INTEGER_32) ti4_1;
		ti4_1 = F323_4764(RTCW(arg4));
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_0_0_1_) = (EIF_INTEGER_32) ti4_1;
		/* END INLINED CODE */
	}
	;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_0_0_2_) = (EIF_INTEGER_32) arg5;
	RTLE;
}

/* {VYCQ}.code */

EIF_REFERENCE F3288_38774 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (38774,RTMS_EX_H("VYCQ",4,1448690513));
}

/* {VYCQ}.subcode */
EIF_INTEGER_32 F3288_38775 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_0_0_2_);
}


/* {VYCQ}.build_explain */
void F3288_38778 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLIU(6);
	
	RTGC;
	{
		/* INLINED CODE (EIFFEL_ERROR.build_explain) */
		/* END INLINED CODE */
	}
	;
	tr1 = RTMS_EX_H("Feature name: ",14,84195872);
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	tr1 = F1769_16449(Current);
	{
		/* INLINED CODE (UNICODE_CONVERSION.utf8_to_utf32) */
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tr3 = (EIF_REFERENCE)  0;
		(void) RTCW(tr1);
		tr4 = RTLNS(eif_new_type(163, 0x00).id, 163, _OBJSIZ_0_0_0_0_0_0_0_0_);
		tr3 = F164_2793(RTCW(tr4), tr2);
		/* END INLINED CODE */
	}
	tr1 = tr3;
	tr2 = *(EIF_REFERENCE *)(Current);
	{
		/* INLINED CODE (TEXT_FORMATTER.add_feature_name) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R14531[Dtype(arg1)-1908])(arg1, tr1, tr2);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
		/* END INLINED CODE */
	}
	;
	tr1 = RTMS_EX_H("Conversion type: ",17,1262665760);
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	{
		/* INLINED CODE (TYPE_A.append_to) */
		(void) RTCW(tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R21744[Dtype(tr1)-2613])(tr1, arg1, NULL);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

void EIF_Minit2242 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
