
#ifndef _C45_ve2249_
#define _C45_ve2249_

#ifdef __cplusplus
extern "C" {
#endif
RTOSHF (EIF_REFERENCE, 38815)


extern EIF_REFERENCE F3295_38815(EIF_REFERENCE);
extern EIF_INTEGER_32 F3295_38816(EIF_REFERENCE);
extern void F3295_38817(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2249(void);

#ifdef __cplusplus
}
#endif

#endif
