
#ifndef _C45_vd2202_
#define _C45_vd2202_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3248_38613(EIF_REFERENCE, EIF_REFERENCE);
extern void F3248_38614(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2202(void);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R14537[])();

#ifdef __cplusplus
}
#endif

#endif
