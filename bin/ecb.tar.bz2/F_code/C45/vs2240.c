/*
 * Code for class VSTA1
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "vs2240.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {VSTA1}.make */
void F3286_38762 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg2;
	RTLE;
}

/* {VSTA1}.code */

EIF_REFERENCE F3286_38763 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (38763,RTMS_EX_H("VSTA",4,1448301633));
}

/* {VSTA1}.subcode */
EIF_INTEGER_32 F3286_38764 (EIF_REFERENCE Current)
{
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
}

/* {VSTA1}.build_explain */
void F3286_38768 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTMS_EX_H("Invalid class name \"",20,1196987426);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R17015[Dtype(RTCW(tr2))-2246])(tr2);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R17105[Dtype(tr1)-2246])(tr1, tr2);
	tr2 = RTMS_EX_H("\" in direct access of ",22,1947353632);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R17105[Dtype(RTCW(tr1))-2246])(tr1, tr2);
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (TEXT_FORMATTER.add_feature_name) */
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		tr2 = *(EIF_REFERENCE *)(Current);
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R14531[Dtype(arg1)-1908])(arg1, tr1, tr2);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

void EIF_Minit2240 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
