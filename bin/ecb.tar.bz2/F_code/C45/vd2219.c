/*
 * Code for class VD25
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "vd2219.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {VD25}.make */
void F3265_38665 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
}

/* {VD25}.build_explain */
void F3265_38667 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	{
		/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
		/* END INLINED CODE */
	}
	;
	tr1 = RTMS_EX_H("Target with name ",17,1480072224);
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	tr1 = RTMS_EX_H(" does not specify a root class.",31,1286643246);
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

void EIF_Minit2219 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
