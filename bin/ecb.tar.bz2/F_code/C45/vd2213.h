
#ifndef _C45_vd2213_
#define _C45_vd2213_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3259_38649(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2213(void);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R14537[])();

#ifdef __cplusplus
}
#endif

#endif
