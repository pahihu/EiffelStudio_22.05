/*
 * Code for class EIFFEL_ERROR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ei2235.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EIFFEL_ERROR}.file_name */
EIF_REFERENCE F3281_38721 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	{
		/* INLINED CODE (CLASS_C.file_name) */
		tr2 = (EIF_REFERENCE)  0;
		(void) RTCW(tr1);
		tr3 = F2525_27079(tr1);
		tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R20763[Dtype(RTCW(tr3))-2527])(tr3);
		tr2 = F2014_18990(RTCW(tr3));
		/* END INLINED CODE */
	}
	Result = tr2;
	RTLE;
	return Result;
}

/* {EIFFEL_ERROR}.has_associated_file */
EIF_BOOLEAN F3281_38722 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		/* INLINED CODE (EIFFEL_ERROR.is_class_defined) */
		tb1 = (EIF_BOOLEAN)  0;
		tr1 = *(EIF_REFERENCE *)(Current);
		tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 != NULL);
		/* END INLINED CODE */
	}
	RTLE;
	return (EIF_BOOLEAN) tb1;
}

/* {EIFFEL_ERROR}.is_class_defined */
EIF_BOOLEAN F3281_38723 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) != NULL);
}

/* {EIFFEL_ERROR}.build_explain */
void F3281_38724 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {EIFFEL_ERROR}.trace */
void F3281_38725 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R27892[dtype-3240])(Current, arg1);
	{
		/* INLINED CODE (EIFFEL_ERROR.is_class_defined) */
		tb1 = (EIF_BOOLEAN)  0;
		tr1 = *(EIF_REFERENCE *)(Current);
		tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 != NULL);
		/* END INLINED CODE */
	}
	if (tb1) {
		tr1 = RTMS_EX_H("Class: ",7,1512540192);
		{
			/* INLINED CODE (TEXT_OPERATOR.add) */
			(void) RTCW(arg1);
			F1907_18035(arg1, tr1);
			/* END INLINED CODE */
		}
		;
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			/* INLINED CODE (CLASS_C.append_signature) */
			(void) RTCW(tr1);
			F2525_27256(tr1, arg1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0);
			/* END INLINED CODE */
		}
		;
		{
			/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
			(void) RTCW(arg1);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
			/* END INLINED CODE */
		}
		;
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R27886[dtype-3240])(Current, arg1);
	tb1 = '\0';
	{
		/* INLINED CODE (EIFFEL_ERROR.is_class_defined) */
		tb2 = (EIF_BOOLEAN)  0;
		tr1 = *(EIF_REFERENCE *)(Current);
		tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 != NULL);
		/* END INLINED CODE */
	}
	if (tb2) {
		tb1 = (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O27854[dtype-3237]) > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		F3240_38560(Current, *(EIF_REFERENCE *)(Current), arg1);
	}
	RTLE;
}

/* {EIFFEL_ERROR}.trace_primary_context */
void F3281_38726 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	if ((EIF_BOOLEAN) (EIF_TEST(loc1) && (EIF_BOOLEAN)(arg1 != NULL))) {
		F503_7109(Current, arg1, loc1);
	} else {
		{
			/* INLINED CODE (COMPILER_ERROR.trace_primary_context) */
			{
			EIF_TYPE_INDEX inlined_dtype = Dtype(Current);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R27865[inlined_dtype-3240])(Current);
			if (tb1) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R27856[inlined_dtype-3240])(Current);
				F1907_18035(RTCW(arg1), tr1);
			}
			}
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
}

/* {EIFFEL_ERROR}.set_class */
void F3281_38727 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

void EIF_Minit2235 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
