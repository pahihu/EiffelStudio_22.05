
#ifndef _C45_vd2234_
#define _C45_vd2234_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3280_38719(EIF_REFERENCE, EIF_REFERENCE);
extern void F3280_38720(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2234(void);
extern void F1907_18034(EIF_REFERENCE);
extern void F402_5843(EIF_REFERENCE, EIF_REFERENCE);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R14537[])();
extern long O16106[];

#ifdef __cplusplus
}
#endif

#endif
