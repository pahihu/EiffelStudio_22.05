/*
 * Code for class VDRS2
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "vd2239.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {VDRS2}.code */

EIF_REFERENCE F3285_38755 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (38755,RTMS_EX_H("VDRS",4,1447318099));
}

/* {VDRS2}.subcode */
EIF_INTEGER_32 F3285_38756 (EIF_REFERENCE Current)
{
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
}

/* {VDRS2}.build_explain */
void F3285_38759 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLIU(6);
	
	RTGC;
	tr1 = RTMS_EX_H("Feature name: ",14,84195872);
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	tr1 = F1769_16449(Current);
	{
		/* INLINED CODE (UNICODE_CONVERSION.utf8_to_utf32) */
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		tr3 = (EIF_REFERENCE)  0;
		(void) RTCW(tr1);
		tr4 = RTLNS(eif_new_type(163, 0x00).id, 163, _OBJSIZ_0_0_0_0_0_0_0_0_);
		tr3 = F164_2793(RTCW(tr4), tr2);
		/* END INLINED CODE */
	}
	tr1 = tr3;
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
		/* END INLINED CODE */
	}
	;
	tr1 = RTMS_EX_H("In Redefine clause for parent: ",31,1373253408);
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	{
		/* INLINED CODE (CLASS_C.append_name) */
		(void) RTCW(tr1);
		tr2 = F2525_27079(tr1);
		F1907_18043(RTCW(arg1), tr2);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {VDRS2}.set_feature_name */
void F3285_38760 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
}

/* {VDRS2}.set_parent */
void F3285_38761 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
}

void EIF_Minit2239 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
