/*
 * Code for class VD42
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "vd2206.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {VD42}.build_explain */
void F3252_38636 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_)) {
		tr1 = RTMS_EX_H("Directory: ",11,1819935520);
		{
			/* INLINED CODE (TEXT_OPERATOR.add) */
			(void) RTCW(arg1);
			F1907_18035(arg1, tr1);
			/* END INLINED CODE */
		}
		;
	} else {
		tr1 = RTMS_EX_H("File: ",6,1957005344);
		{
			/* INLINED CODE (TEXT_OPERATOR.add) */
			(void) RTCW(arg1);
			F1907_18035(arg1, tr1);
			/* END INLINED CODE */
		}
		;
	}
	{
		/* INLINED CODE (TEXT_OPERATOR.add) */
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		(void) RTCW(arg1);
		F1907_18035(arg1, tr1);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
		(void) RTCW(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14537[Dtype(arg1)-1908])(arg1);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {VD42}.set_path */
void F3252_38637 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
}

/* {VD42}.set_is_directory */
void F3252_38638 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

void EIF_Minit2206 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
