
#ifndef _C45_vd2216_
#define _C45_vd2216_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3262_38656(EIF_REFERENCE, EIF_REFERENCE);
extern void F3262_38657(EIF_REFERENCE, EIF_REFERENCE);
extern void F3262_38658(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2216(void);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R14537[])();

#ifdef __cplusplus
}
#endif

#endif
