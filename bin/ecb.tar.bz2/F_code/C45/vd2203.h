
#ifndef _C45_vd2203_
#define _C45_vd2203_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3249_38616(EIF_REFERENCE, EIF_REFERENCE);
extern void F3249_38617(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2203(void);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R14537[])();

#ifdef __cplusplus
}
#endif

#endif
