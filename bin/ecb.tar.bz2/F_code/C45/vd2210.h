
#ifndef _C45_vd2210_
#define _C45_vd2210_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3256_38646(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2210(void);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R14537[])();

#ifdef __cplusplus
}
#endif

#endif
