
#ifndef _C45_vs2240_
#define _C45_vs2240_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3286_38762(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);RTOSHF (EIF_REFERENCE, 38763)


extern EIF_REFERENCE F3286_38763(EIF_REFERENCE);
extern EIF_INTEGER_32 F3286_38764(EIF_REFERENCE);
extern void F3286_38768(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2240(void);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R17105[])();
extern char *(*R17015[])();
extern char *(*R14531[])();
extern char *(*R14537[])();

#ifdef __cplusplus
}
#endif

#endif
