
#ifndef _C45_vd2219_
#define _C45_vd2219_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3265_38665(EIF_REFERENCE, EIF_REFERENCE);
extern void F3265_38667(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2219(void);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R14537[])();

#ifdef __cplusplus
}
#endif

#endif
