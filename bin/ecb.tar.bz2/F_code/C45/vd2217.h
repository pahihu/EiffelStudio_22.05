
#ifndef _C45_vd2217_
#define _C45_vd2217_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3263_38660(EIF_REFERENCE, EIF_REFERENCE);
extern void F3263_38661(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2217(void);
extern void F1907_18035(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R14537[])();

#ifdef __cplusplus
}
#endif

#endif
