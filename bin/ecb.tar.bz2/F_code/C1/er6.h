
#ifndef _C1_er6_
#define _C1_er6_

#ifdef __cplusplus
extern "C" {
#endif

extern void F8_98(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit6(void);
extern void F1540_14695(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
