/*
 * Code for class AST_ARGUMENT_SCOPE_TRACKER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "as22.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {AST_ARGUMENT_SCOPE_TRACKER}.make */
void F26_238 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(243,F26_243, (Current));
	{
		/* INLINED CODE (AST_SCOPE_KEEPER_FACTORY.create_scope_keeper) */
		ti4_1 = arg1;
		tr2 = (EIF_REFERENCE)  0;
		(void) RTCW(tr1);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 63L))) {
			tr2 = RTLNS(eif_new_type(353, 0x00).id, 353, _OBJSIZ_3_0_0_1_0_0_0_0_);
			F352_5055(RTCW(tr2), ti4_1);
		} else {
			tr2 = RTLNS(eif_new_type(354, 0x00).id, 354, _OBJSIZ_2_0_0_1_0_0_1_0_);
			F353_5055(RTCW(tr2), ti4_1);
		}
		/* END INLINED CODE */
	}
	tr1 = tr2;
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {AST_ARGUMENT_SCOPE_TRACKER}.argument_count */
EIF_INTEGER_32 F26_240 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1) + O4930[Dtype(tr1)-349]);
	RTLE;
	return Result;
}

/* {AST_ARGUMENT_SCOPE_TRACKER}.start_argument_scope */
void F26_241 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R4932[Dtype(RTCW(tr1))-353])(tr1, arg1);
	RTLE;
}

/* {AST_ARGUMENT_SCOPE_TRACKER}.factory */
static EIF_REFERENCE F26_243_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (243);
#define Result RTOSR(243)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(26, 0x00).id, 26, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (243);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F26_243 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(243,F26_243_body,(Current));
}

void EIF_Minit22 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
