/*
 * Code for class ROUTINE_ASSERTIONS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ro32.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ROUTINE_ASSERTIONS}.make_for_feature */
void F36_312 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_1_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
		loc1 = tr1;
		loc1 = RTRV(eif_new_type(3649, 0x00),loc1);
		tb1 = EIF_TEST(loc1);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_2_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_4_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	}
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	RTLE;
}

/* {ROUTINE_ASSERTIONS}.make_for_inline_agent */
void F36_313 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_2_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_4_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	RTLE;
}

/* {ROUTINE_ASSERTIONS}.format_precondition */
void F36_318 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	{
		/* INLINED CODE (SHARED_FORMAT_INFO.is_with_breakable) */
		tb1 = (EIF_BOOLEAN)  0;
		(void) RTCW(arg1);
		tr1 = RTOSCF(11429,F795_11429, (arg1));
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O6989[Dtype(tr1)-553]);
		/* END INLINED CODE */
	}
	loc1 = tb1;
	if (arg2) {
		{
			/* INLINED CODE (SHARED_FORMAT_INFO.set_is_without_breakable) */
			(void) RTCW(arg1);
			tr1 = RTOSCF(11429,F795_11429, (arg1));
			F557_7469(RTCW(tr1), (EIF_BOOLEAN) 0);
			/* END INLINED CODE */
		}
		;
	} else {
		{
			/* INLINED CODE (SHARED_FORMAT_INFO.set_is_with_breakable) */
			(void) RTCW(arg1);
			tr1 = RTOSCF(11429,F795_11429, (arg1));
			F557_7469(RTCW(tr1), (EIF_BOOLEAN) 1);
			/* END INLINED CODE */
		}
		;
	}
	{
		/* INLINED CODE (TEXT_FORMATTER_DECORATOR.format_ast) */
		tr1 = *(EIF_REFERENCE *)(Current);
		(void) RTCW(arg1);
		tr2 = *(EIF_REFERENCE *)(arg1 + _REFACS_18_);
		F2517_26608(RTCW(tr2), tr1);
		/* END INLINED CODE */
	}
	;
	if (loc1) {
		{
			/* INLINED CODE (SHARED_FORMAT_INFO.set_is_with_breakable) */
			(void) RTCW(arg1);
			tr1 = RTOSCF(11429,F795_11429, (arg1));
			F557_7469(RTCW(tr1), (EIF_BOOLEAN) 1);
			/* END INLINED CODE */
		}
		;
	} else {
		{
			/* INLINED CODE (SHARED_FORMAT_INFO.set_is_without_breakable) */
			(void) RTCW(arg1);
			tr1 = RTOSCF(11429,F795_11429, (arg1));
			F557_7469(RTCW(tr1), (EIF_BOOLEAN) 0);
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
}

/* {ROUTINE_ASSERTIONS}.format_postcondition */
void F36_319 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	{
		/* INLINED CODE (SHARED_FORMAT_INFO.is_with_breakable) */
		tb1 = (EIF_BOOLEAN)  0;
		(void) RTCW(arg1);
		tr1 = RTOSCF(11429,F795_11429, (arg1));
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O6989[Dtype(tr1)-553]);
		/* END INLINED CODE */
	}
	loc1 = tb1;
	if (arg2) {
		{
			/* INLINED CODE (SHARED_FORMAT_INFO.set_is_without_breakable) */
			(void) RTCW(arg1);
			tr1 = RTOSCF(11429,F795_11429, (arg1));
			F557_7469(RTCW(tr1), (EIF_BOOLEAN) 0);
			/* END INLINED CODE */
		}
		;
	} else {
		{
			/* INLINED CODE (SHARED_FORMAT_INFO.set_is_with_breakable) */
			(void) RTCW(arg1);
			tr1 = RTOSCF(11429,F795_11429, (arg1));
			F557_7469(RTCW(tr1), (EIF_BOOLEAN) 1);
			/* END INLINED CODE */
		}
		;
	}
	{
		/* INLINED CODE (TEXT_FORMATTER_DECORATOR.format_ast) */
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		(void) RTCW(arg1);
		tr2 = *(EIF_REFERENCE *)(arg1 + _REFACS_18_);
		F2517_26608(RTCW(tr2), tr1);
		/* END INLINED CODE */
	}
	;
	if (loc1) {
		{
			/* INLINED CODE (SHARED_FORMAT_INFO.set_is_with_breakable) */
			(void) RTCW(arg1);
			tr1 = RTOSCF(11429,F795_11429, (arg1));
			F557_7469(RTCW(tr1), (EIF_BOOLEAN) 1);
			/* END INLINED CODE */
		}
		;
	} else {
		{
			/* INLINED CODE (SHARED_FORMAT_INFO.set_is_without_breakable) */
			(void) RTCW(arg1);
			tr1 = RTOSCF(11429,F795_11429, (arg1));
			F557_7469(RTCW(tr1), (EIF_BOOLEAN) 0);
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
}

void EIF_Minit32 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
