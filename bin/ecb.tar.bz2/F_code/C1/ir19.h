
#ifndef _C1_ir19_
#define _C1_ir19_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F23_190(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit19(void);
extern void F338_4966(EIF_REFERENCE, EIF_REFERENCE);
extern void F337_4953(EIF_REFERENCE, EIF_REFERENCE);
extern long O4843[];

#ifdef __cplusplus
}
#endif

#endif
