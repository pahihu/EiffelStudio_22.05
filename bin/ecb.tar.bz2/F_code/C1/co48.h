
#ifndef _C1_co48_
#define _C1_co48_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F55_871(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit48(void);
extern void F971_13372(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
