
#ifndef _C1_as23_
#define _C1_as23_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F27_244(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit23(void);
extern void F353_5055(EIF_REFERENCE, EIF_INTEGER_32);
extern void F352_5055(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
