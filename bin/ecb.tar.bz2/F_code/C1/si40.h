
#ifndef _C1_si40_
#define _C1_si40_

#ifdef __cplusplus
extern "C" {
#endif

extern void F44_770(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F44_773(EIF_REFERENCE);
extern EIF_INTEGER_32 F44_774(EIF_REFERENCE);
extern void EIF_Minit40(void);
extern void F1603_15105(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F1566_14933(EIF_REFERENCE);
extern EIF_REFERENCE F1566_14926(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
