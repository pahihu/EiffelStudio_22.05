
#ifndef _C1_fu42_
#define _C1_fu42_

#ifdef __cplusplus
extern "C" {
#endif

extern void F46_785(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit42(void);

#ifdef __cplusplus
}
#endif

#endif
