
#ifndef _C1_re45_
#define _C1_re45_

#ifdef __cplusplus
extern "C" {
#endif

extern void F51_841(EIF_REFERENCE);
extern void F51_842(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F51_845(EIF_REFERENCE);
extern EIF_REFERENCE F51_846(EIF_REFERENCE);
extern void F51_848(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit45(void);
extern void F130_2383(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern void F130_2386(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern void F130_2375(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
