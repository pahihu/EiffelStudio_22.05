
#ifndef _C1_di9_
#define _C1_di9_

#ifdef __cplusplus
extern "C" {
#endif

extern void F11_114(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit9(void);
extern void F862_12233(EIF_REFERENCE);
extern char *(*R9257[])();

#ifdef __cplusplus
}
#endif

#endif
