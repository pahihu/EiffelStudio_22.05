
#ifndef _C1_er4_
#define _C1_er4_

#ifdef __cplusplus
extern "C" {
#endif

extern void F6_55(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F6_56(EIF_REFERENCE);
extern void EIF_Minit4(void);
extern EIF_BOOLEAN F2246_21909(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
