/*
 * Code for class CONF_LOCATION_MAPPER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co46.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_LOCATION_MAPPER}.make */
void F52_849 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {1565,245,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1566_14912(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {CONF_LOCATION_MAPPER}.mapped_path */
EIF_REFERENCE F52_850 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,loc3);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	loc1 = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = F1566_14926(RTCW(tr1));
	for (;;) {
		{
			/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.after) */
			tb1 = (EIF_BOOLEAN)  0;
			(void) loc2;
			ti4_1 = *(EIF_INTEGER_32 *)(loc2+ _LNGOFF_2_0_0_0_);
			ti4_2 = *(EIF_INTEGER_32 *)(loc2+ _LNGOFF_2_0_0_1_);
			tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ti4_2);
			/* END INLINED CODE */
		}
		tb1 = tb1;
		if (tb1) break;
		{
			/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.item) */
			tr1 = (EIF_REFERENCE)  0;
			(void) loc2;
			tr2 = *(EIF_REFERENCE *)(loc2);
			tr1 = 
				/* INLINED CODE (SPECIAL.item) */
				*((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(loc2+ _LNGOFF_2_0_0_0_)))
				/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		tr1 = tr1;
		tr1 = F247_3853(RTCW(tr1), loc1);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			loc1 = (EIF_REFERENCE) loc3;
		}
		{
			/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.forth) */
			(void) loc2;
			(*(EIF_INTEGER_32 *)(loc2+ _LNGOFF_2_0_0_0_))++;
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
	return (EIF_REFERENCE) loc1;
}

/* {CONF_LOCATION_MAPPER}.expected_action */
EIF_REFERENCE F52_851 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,loc3);
	RTLR(6,tr2);
	RTLR(7,Result);
	RTLIU(8);
	
	RTGC;
	loc1 = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = F1566_14926(RTCW(tr1));
	for (;;) {
		{
			/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.after) */
			tb1 = (EIF_BOOLEAN)  0;
			(void) loc2;
			ti4_1 = *(EIF_INTEGER_32 *)(loc2+ _LNGOFF_2_0_0_0_);
			ti4_2 = *(EIF_INTEGER_32 *)(loc2+ _LNGOFF_2_0_0_1_);
			tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ti4_2);
			/* END INLINED CODE */
		}
		tb1 = tb1;
		if (tb1) break;
		if ((EIF_BOOLEAN)(Result != NULL)) break;
		{
			/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.item) */
			tr1 = (EIF_REFERENCE)  0;
			(void) loc2;
			tr2 = *(EIF_REFERENCE *)(loc2);
			tr1 = 
				/* INLINED CODE (SPECIAL.item) */
				*((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(loc2+ _LNGOFF_2_0_0_0_)))
				/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		tr1 = tr1;
		tr1 = F247_3854(RTCW(tr1), arg1);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			Result = (EIF_REFERENCE) loc3;
		}
		{
			/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.forth) */
			(void) loc2;
			(*(EIF_INTEGER_32 *)(loc2+ _LNGOFF_2_0_0_0_))++;
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
	return Result;
}

/* {CONF_LOCATION_MAPPER}.refresh */
void F52_853 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = F1566_14926(RTCW(tr1));
	for (;;) {
		{
			/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.after) */
			tb1 = (EIF_BOOLEAN)  0;
			(void) loc1;
			ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_0_0_0_);
			ti4_2 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_0_0_1_);
			tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ti4_2);
			/* END INLINED CODE */
		}
		tb1 = tb1;
		if (tb1) break;
		{
			/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.item) */
			tr1 = (EIF_REFERENCE)  0;
			(void) loc1;
			tr2 = *(EIF_REFERENCE *)(loc1);
			tr1 = 
				/* INLINED CODE (SPECIAL.item) */
				*((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_0_0_0_)))
				/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		tr1 = tr1;
		F247_3855(RTCW(tr1));
		{
			/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.forth) */
			(void) loc1;
			(*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_0_0_0_))++;
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
}

/* {CONF_LOCATION_MAPPER}.register */
void F52_854 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	F1566_14952(RTCW(tr1), arg1);
	RTLE;
}

void EIF_Minit46 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
