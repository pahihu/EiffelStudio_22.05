/*
 * Code for class ERROR_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "er36.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ERROR_CONSTANTS}.err_msg_0 */

EIF_REFERENCE F40_687 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (687,RTMS_EX_H("compilation successfully",24,297046137));
}

/* {ERROR_CONSTANTS}.err_msg_1 */

EIF_REFERENCE F40_688 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (688,RTMS_EX_H("\\ at end of pattern",19,1082148462));
}

/* {ERROR_CONSTANTS}.err_msg_2 */

EIF_REFERENCE F40_689 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (689,RTMS_EX_H("\\c at end of pattern",20,586514030));
}

/* {ERROR_CONSTANTS}.err_msg_3 */

EIF_REFERENCE F40_690 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (690,RTMS_EX_H("unrecognized character follows \\",32,1794949212));
}

/* {ERROR_CONSTANTS}.err_msg_4 */

EIF_REFERENCE F40_691 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (691,RTMS_EX_H("numbers out of order in {} quantifier",37,1764177010));
}

/* {ERROR_CONSTANTS}.err_msg_5 */

EIF_REFERENCE F40_692 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (692,RTMS_EX_H("number too big in {} quantifier",31,236715890));
}

/* {ERROR_CONSTANTS}.err_msg_6 */

EIF_REFERENCE F40_693 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (693,RTMS_EX_H("missing terminating ] for character class",41,461852531));
}

/* {ERROR_CONSTANTS}.err_msg_7 */

EIF_REFERENCE F40_694 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (694,RTMS_EX_H("invalid escape sequence in character class",42,267449459));
}

/* {ERROR_CONSTANTS}.err_msg_8 */

EIF_REFERENCE F40_695 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (695,RTMS_EX_H("range out of order in character class",37,652901747));
}

/* {ERROR_CONSTANTS}.err_msg_9 */

EIF_REFERENCE F40_696 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (696,RTMS_EX_H("nothing to repeat",17,825052276));
}

/* {ERROR_CONSTANTS}.err_msg_11 */

EIF_REFERENCE F40_698 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (698,RTMS_EX_H("internal error: unexpected repeat",33,1855335540));
}

/* {ERROR_CONSTANTS}.err_msg_12 */

EIF_REFERENCE F40_699 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (699,RTMS_EX_H("unrecognized character after (\?",31,636561471));
}

/* {ERROR_CONSTANTS}.err_msg_13 */

EIF_REFERENCE F40_700 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (700,RTMS_EX_H("too many capturing parenthesized sub-patterns",45,1757158771));
}

/* {ERROR_CONSTANTS}.err_msg_14 */

EIF_REFERENCE F40_701 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (701,RTMS_EX_H("missing )",9,1989432361));
}

/* {ERROR_CONSTANTS}.err_msg_15 */

EIF_REFERENCE F40_702 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (702,RTMS_EX_H("back reference to non-existent subpattern",41,1930188142));
}

/* {ERROR_CONSTANTS}.err_msg_18 */

EIF_REFERENCE F40_705 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (705,RTMS_EX_H("missing ) after comment",23,1848893300));
}

/* {ERROR_CONSTANTS}.err_msg_22 */

EIF_REFERENCE F40_709 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (709,RTMS_EX_H("unmatched parentheses",21,366512243));
}

/* {ERROR_CONSTANTS}.err_msg_24 */

EIF_REFERENCE F40_711 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (711,RTMS_EX_H("unrecognized character after (\?<",32,1898751036));
}

/* {ERROR_CONSTANTS}.err_msg_25 */

EIF_REFERENCE F40_712 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (712,RTMS_EX_H("lookbehind assertion is not fixed length",40,831850344));
}

/* {ERROR_CONSTANTS}.err_msg_26 */

EIF_REFERENCE F40_713 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (713,RTMS_EX_H("malformed number after (\?(",26,217491240));
}

/* {ERROR_CONSTANTS}.err_msg_27 */

EIF_REFERENCE F40_714 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (714,RTMS_EX_H("conditional group contains more than two branches",49,572996467));
}

/* {ERROR_CONSTANTS}.err_msg_28 */

EIF_REFERENCE F40_715 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (715,RTMS_EX_H("assertion expected after (\?(",28,1018686248));
}

/* {ERROR_CONSTANTS}.err_msg_30 */

EIF_REFERENCE F40_717 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (717,RTMS_EX_H("unknown POSIX class name",24,1984937317));
}

/* {ERROR_CONSTANTS}.err_msg_31 */

EIF_REFERENCE F40_718 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (718,RTMS_EX_H("POSIX collating elements are not supported",42,1477603940));
}

/* {ERROR_CONSTANTS}.err_msg_35 */

EIF_REFERENCE F40_722 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (722,RTMS_EX_H("invalid condition (\?(0)",23,1170936617));
}

/* {ERROR_CONSTANTS}.err_msg_99 */

EIF_REFERENCE F40_724 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (724,RTMS_EX_H("no pattern compiled",19,1370646116));
}

void EIF_Minit36 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
