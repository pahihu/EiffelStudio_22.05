
#ifndef _C1_lo43_
#define _C1_lo43_

#ifdef __cplusplus
extern "C" {
#endif

extern void F47_788(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F47_791(EIF_REFERENCE);
extern EIF_BOOLEAN F47_792(EIF_REFERENCE);
extern EIF_BOOLEAN F47_793(EIF_REFERENCE);
extern void F47_795(EIF_REFERENCE, EIF_REFERENCE);
extern void F47_796(EIF_REFERENCE);
extern void F47_797(EIF_REFERENCE, EIF_BOOLEAN);
extern void F47_798(EIF_REFERENCE);
extern void F47_799(EIF_REFERENCE);
extern void F47_800(EIF_REFERENCE);
extern void F47_801(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit43(void);

#ifdef __cplusplus
}
#endif

#endif
