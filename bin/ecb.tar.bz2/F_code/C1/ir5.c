/*
 * Code for class IRON_PACKAGE_INFO_FILE_PARSER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir5.h"
#include "eif_file.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_PACKAGE_INFO_FILE_PARSER}.make */
void F7_59 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(2251, 0).id);
	F2243_21753(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.set_callbacks */
void F7_62 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.package_token */

EIF_REFERENCE F7_63 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (63,RTMS_EX_H("package",7,382506597));
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.setup_token */

EIF_REFERENCE F7_64 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (64,RTMS_EX_H("setup",5,1703014256));
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.project_token */

EIF_REFERENCE F7_65 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (65,RTMS_EX_H("project",7,399506036));
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.note_token */

EIF_REFERENCE F7_66 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (66,RTMS_EX_H("note",4,1852798053));
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.end_token */

EIF_REFERENCE F7_67 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (67,RTMS_EX_H("end",3,6647396));
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse */
void F7_68 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1438, 0x00).id, 1438, _OBJSIZ_5_7_2_4_1_1_2_1_);
	F1439_14450(RTCW(loc1), arg1);
	tb1 = '\0';
	tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11190[Dtype(RTCW(loc1))-921])(loc1);
	if (tb2) {
		{
			/* INLINED CODE (FILE.is_readable) */
			tb2 = (EIF_BOOLEAN)  0;
			(void) RTCW(loc1);
			F1437_14339(loc1);
			tb2 = F836_11798(RTCV(RTOSCF(14337,F1437_14337, (loc1))));
			/* END INLINED CODE */
		}
		tb2 = tb2;
		tb1 = tb2;
	}
	if (tb1) {
		{
			/* INLINED CODE (FILE.open_read) */
			(void) RTCW(loc1);
			tp1 = *(EIF_POINTER *)(RTCV(F1437_14329(loc1))+ _PTROFF_0_1_0_1_0_0_);
			tp1 = (EIF_POINTER) eif_file_open((EIF_FILENAME) tp1, (int) ((EIF_INTEGER_32) 0L));
			*(EIF_POINTER *)(loc1 + O11932[Dtype(loc1)-1436]) = (EIF_POINTER) tp1;
			*(EIF_INTEGER_32 *)(loc1 + O12071[Dtype(loc1)-1436]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			/* END INLINED CODE */
		}
		;
		F7_69(Current, loc1);
		{
			/* INLINED CODE (FILE.close) */
			(void) RTCW(loc1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER)) R12014[Dtype(loc1)-1437])(loc1, *(EIF_POINTER *)(loc1 + O11932[Dtype(loc1)-1436]));
			*(EIF_INTEGER_32 *)(loc1 + O12071[Dtype(loc1)-1436]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			tp1 = F1_33(loc1);
			*(EIF_POINTER *)(loc1 + O11932[Dtype(loc1)-1436]) = (EIF_POINTER) tp1;
			*(EIF_BOOLEAN *)(loc1 + O12080[Dtype(loc1)-1436]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_file */
void F7_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	loc2 = RTLNS(eif_new_type(2247, 0x00).id, 2247, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F2246_21883(RTCW(loc2), ((EIF_INTEGER_32) 2046L));
	{
		/* INLINED CODE (LINEAR.exhausted) */
		tb1 = (EIF_BOOLEAN)  0;
		(void) RTCW(arg1);
		tb1 = F1437_14201(arg1);
		/* END INLINED CODE */
	}
	loc1 = tb1;
	for (;;) {
		if (loc1) break;
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R11246[Dtype(RTCW(arg1))-1437])(arg1, ((EIF_INTEGER_32) 2046L));
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O11174[Dtype(arg1)-920]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17141[Dtype(RTCW(loc2))-2247])(loc2, tr1);
		loc1 = '\01';
		{
			/* INLINED CODE (LINEAR.exhausted) */
			tb1 = (EIF_BOOLEAN)  0;
			(void) RTCW(arg1);
			tb1 = F1437_14201(arg1);
			/* END INLINED CODE */
		}
		tb1 = tb1;
		if (!tb1) {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O11174[Dtype(arg1)-920]);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
			loc1 = (EIF_BOOLEAN) (ti4_1 < ((EIF_INTEGER_32) 2046L));
		}
	}
	F7_70(Current, loc2);
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_text */
void F7_70 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	struct eif_ex_131 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(163, 0x00).id);
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	{
		/* INLINED CODE (STRING_32.wipe_out) */
		(void) RTCW(tr1);
		*(EIF_INTEGER_32 *)(tr1+ _LNGOFF_1_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		F2245_21851(tr1);
		/* END INLINED CODE */
	}
	;
	F164_2796(RTCW(loc1), arg1, *(EIF_REFERENCE *)(Current + _REFACS_1_));
	F7_71(Current);
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_buffer */
void F7_71 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLIU(7);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	{
		/* INLINED CODE (FINITE.is_empty) */
		tb1 = (EIF_BOOLEAN)  0;
		(void) RTCW(tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(tr1+ _LNGOFF_1_1_0_2_);
		tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
		/* END INLINED CODE */
	}
	tb1 = tb1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) tb1;
	for (;;) {
		if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_))) break;
		loc1 = F7_84(Current);
		switch (loc1) {
			case (EIF_CHARACTER_8) '-':
				loc1 = F7_81(Current);
				F7_72(Current);
				break;
			case (EIF_CHARACTER_8) 'p':
				loc1 = F7_81(Current);
				loc2 = F7_87(Current);
				tr1 = F2243_21812(RTCV(RTOSCF(63,F7_63, (Current))));
				tb1 = F2250_22074(RTCW(loc2), tr1);
				if (tb1) {
					F7_73(Current);
				} else {
					tr1 = F2243_21812(RTCV(RTOSCF(65,F7_65, (Current))));
					tb1 = F2250_22074(RTCW(loc2), tr1);
					if (tb1) {
						F7_76(Current);
					} else {
						tr1 = F2243_21812(RTMS_EX_H("Unexpected character [p].",25,883275054));
						F7_80(Current, tr1);
					}
				}
				break;
			case (EIF_CHARACTER_8) 's':
				loc1 = F7_81(Current);
				loc2 = F7_87(Current);
				tr1 = RTOSCF(64,F7_64, (Current));
				tb1 = F2243_21795(RTCW(loc2), tr1);
				if (tb1) {
					F7_74(Current);
				} else {
					tr1 = F2243_21812(RTMS_EX_H("Unexpected character [s].",25,883471662));
					F7_80(Current, tr1);
				}
				break;
			case (EIF_CHARACTER_8) 'n':
				loc1 = F7_81(Current);
				loc2 = F7_87(Current);
				tr1 = RTOSCF(66,F7_66, (Current));
				tb1 = F2243_21795(RTCW(loc2), tr1);
				if (tb1) {
					F7_78(Current);
				} else {
					tr1 = F2243_21812(RTMS_EX_H("Unexpected character [n].",25,883143982));
					F7_80(Current, tr1);
				}
				break;
			case (EIF_CHARACTER_8) 'e':
				loc1 = F7_81(Current);
				loc2 = F7_87(Current);
				tr1 = F2243_21812(RTCV(RTOSCF(67,F7_67, (Current))));
				tb1 = F2250_22074(RTCW(loc2), tr1);
				if ((EIF_BOOLEAN) !tb1) {
					tr1 = F2243_21812(RTMS_EX_H("Unexpected character [e].",25,882554158));
					F7_80(Current, tr1);
				}
				break;
			case (EIF_CHARACTER_8) '\000':
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
					tr1 = F2243_21812(RTMS_EX_H("Unexpected null character.",26,830567726));
					F7_80(Current, tr1);
				}
				break;
			default:
				tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
				{
					/* INLINED CODE (IRON_PACKAGE_INFO_FILE_PARSER.character_to_string) */
					tw1 = loc1;
					tr2 = (EIF_REFERENCE)  0;
					tr2 = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F2250_22049(RTCW(tr2), ((EIF_INTEGER_32) 1L));
					F2252_22177(RTCW(tr2), tw1);
					/* END INLINED CODE */
				}
				tr3 = tr2;
				{
					/* INLINED CODE (STRING_32.plus) */
					tr4 = (EIF_REFERENCE)  0;
					tr5 = tr1;
					(void) RTCW(tr5);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr3) + O17190[Dtype(tr3)-2249]);
					tr4 = F2252_22214(tr5, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(tr5+ _LNGOFF_1_1_0_2_) + ti4_1));
					F2252_22164(RTCW(tr4), tr5);
					F2252_22164(RTCW(tr4), tr3);
					/* END INLINED CODE */
				}
				tr1 = tr4;
				tr2 = F2243_21812(RTMS_EX_H("].",2,23854));
				{
					/* INLINED CODE (STRING_32.plus) */
					tr3 = (EIF_REFERENCE)  0;
					(void) RTCW(tr1);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2) + O17190[Dtype(tr2)-2249]);
					tr3 = F2252_22214(tr1, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(tr1+ _LNGOFF_1_1_0_2_) + ti4_1));
					F2252_22164(RTCW(tr3), tr1);
					F2252_22164(RTCW(tr3), tr2);
					/* END INLINED CODE */
				}
				tr1 = tr3;
				F7_80(Current, tr1);
				break;
		}
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_comment */
void F7_72 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,tr5);
	RTLIU(8);
	
	RTGC;
	loc1 = F7_82(Current);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
	if ((EIF_BOOLEAN)(loc1 == tw1)) {
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			loc1 = F7_82(Current);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
			if ((EIF_BOOLEAN)(loc1 == tw1)) {
				loc2 = F7_86(Current);
				tr1 = *(EIF_REFERENCE *)(Current);
				loc3 = tr1;
				if (EIF_TEST(loc3)) {
					{
						/* INLINED CODE (IRON_PACKAGE_INFO_FILE_PARSER_CALLBACKS.on_comment) */
						(void) loc3;
						/* END INLINED CODE */
					}
					;
				}
			} else {
				tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
				{
					/* INLINED CODE (IRON_PACKAGE_INFO_FILE_PARSER.character_to_string) */
					tw1 = loc1;
					tr2 = (EIF_REFERENCE)  0;
					tr2 = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F2250_22049(RTCW(tr2), ((EIF_INTEGER_32) 1L));
					F2252_22177(RTCW(tr2), tw1);
					/* END INLINED CODE */
				}
				tr3 = tr2;
				{
					/* INLINED CODE (STRING_32.plus) */
					tr4 = (EIF_REFERENCE)  0;
					tr5 = tr1;
					(void) RTCW(tr5);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr3) + O17190[Dtype(tr3)-2249]);
					tr4 = F2252_22214(tr5, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(tr5+ _LNGOFF_1_1_0_2_) + ti4_1));
					F2252_22164(RTCW(tr4), tr5);
					F2252_22164(RTCW(tr4), tr3);
					/* END INLINED CODE */
				}
				tr1 = tr4;
				tr2 = F2243_21812(RTMS_EX_H("].",2,23854));
				{
					/* INLINED CODE (STRING_32.plus) */
					tr3 = (EIF_REFERENCE)  0;
					(void) RTCW(tr1);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2) + O17190[Dtype(tr2)-2249]);
					tr3 = F2252_22214(tr1, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(tr1+ _LNGOFF_1_1_0_2_) + ti4_1));
					F2252_22164(RTCW(tr3), tr1);
					F2252_22164(RTCW(tr3), tr2);
					/* END INLINED CODE */
				}
				tr1 = tr3;
				F7_80(Current, tr1);
			}
		}
	} else {
		tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
		{
			/* INLINED CODE (IRON_PACKAGE_INFO_FILE_PARSER.character_to_string) */
			tw1 = loc1;
			tr2 = (EIF_REFERENCE)  0;
			tr2 = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F2250_22049(RTCW(tr2), ((EIF_INTEGER_32) 1L));
			F2252_22177(RTCW(tr2), tw1);
			/* END INLINED CODE */
		}
		tr3 = tr2;
		{
			/* INLINED CODE (STRING_32.plus) */
			tr4 = (EIF_REFERENCE)  0;
			tr5 = tr1;
			(void) RTCW(tr5);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr3) + O17190[Dtype(tr3)-2249]);
			tr4 = F2252_22214(tr5, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(tr5+ _LNGOFF_1_1_0_2_) + ti4_1));
			F2252_22164(RTCW(tr4), tr5);
			F2252_22164(RTCW(tr4), tr3);
			/* END INLINED CODE */
		}
		tr1 = tr4;
		tr2 = F2243_21812(RTMS_EX_H("].",2,23854));
		{
			/* INLINED CODE (STRING_32.plus) */
			tr3 = (EIF_REFERENCE)  0;
			(void) RTCW(tr1);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2) + O17190[Dtype(tr2)-2249]);
			tr3 = F2252_22214(tr1, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(tr1+ _LNGOFF_1_1_0_2_) + ti4_1));
			F2252_22164(RTCW(tr3), tr1);
			F2252_22164(RTCW(tr3), tr2);
			/* END INLINED CODE */
		}
		tr1 = tr3;
		F7_80(Current, tr1);
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_package_declaration */
void F7_73 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 loc2 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLIU(4);
	
	RTGC;
	loc2 = F7_84(Current);
	tb1 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(loc2 != tw1)) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_);
	}
	if (tb1) {
		loc2 = F7_81(Current);
		loc1 = F7_89(Current);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R16970[Dtype(RTCW(loc1))-2246])(loc1);
		if (tb1) {
			tr1 = F2243_21812(RTMS_EX_H("Invalid package name",20,1534212709));
			F7_80(Current, tr1);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				{
					/* INLINED CODE (IRON_PACKAGE_INFO_FILE_PARSER_CALLBACKS.on_package) */
					(void) loc3;
					tr1 = RTLNSMART(eif_new_type(2250, 0).id);
					F2250_22051(RTCW(tr1), loc1);
					RTAR(loc3, tr1);
					*(EIF_REFERENCE *)(loc3 + _REFACS_4_) = (EIF_REFERENCE) tr1;
					/* END INLINED CODE */
				}
				;
			}
		}
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_setup_declaration */
void F7_74 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_32 loc5 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc5 = F7_84(Current);
	tb1 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(loc5 != tw1)) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_);
	}
	if (tb1) {
		loc5 = F7_81(Current);
		loc1 = F7_91(Current);
		loc5 = F7_81(Current);
		for (;;) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || loc4) || *(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_))) break;
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R16970[Dtype(RTCW(loc1))-2246])(loc1);
			if (tb1) {
				loc5 = F7_82(Current);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				if ((EIF_BOOLEAN)(loc5 == tw1)) {
					loc5 = F7_81(Current);
					F7_72(Current);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_))) {
						loc5 = F7_84(Current);
						loc5 = F7_81(Current);
						loc1 = F7_91(Current);
						loc5 = F7_81(Current);
					}
				} else {
					tr1 = F2243_21812(RTMS_EX_H("Invalid setup name",18,1945739621));
					F7_80(Current, tr1);
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			} else {
				tr1 = F2243_21812(RTCV(RTOSCF(65,F7_65, (Current))));
				tb1 = F2250_22074(RTCW(loc1), tr1);
				if (tb1) {
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					tr1 = F2243_21812(RTCV(RTOSCF(66,F7_66, (Current))));
					tb1 = F2250_22074(RTCW(loc1), tr1);
					if (tb1) {
						loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						tr1 = F2243_21812(RTCV(RTOSCF(67,F7_67, (Current))));
						tb1 = F2250_22074(RTCW(loc1), tr1);
						if (tb1) {
							loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						} else {
							F7_75(Current, loc1);
							loc5 = F7_81(Current);
							loc5 = F7_84(Current);
							for (;;) {
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
								if ((EIF_BOOLEAN)(loc5 != tw1)) break;
								loc5 = F7_81(Current);
								F7_72(Current);
								loc5 = F7_84(Current);
							}
							loc5 = F7_81(Current);
							loc1 = F7_91(Current);
							loc5 = F7_81(Current);
						}
					}
				}
			}
		}
		if (loc2) {
			F7_78(Current);
		} else {
			if (loc3) {
				F7_76(Current);
			}
		}
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_setup_item_declaration */
void F7_75 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_32 loc4 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(10);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc5);
	RTLR(5,arg1);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,tr4);
	RTLR(9,tr5);
	RTLIU(10);
	
	RTGC;
	loc4 = F7_84(Current);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '=';
	if ((EIF_BOOLEAN)(loc4 == tw1)) {
		loc4 = F7_85(Current);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		if ((EIF_BOOLEAN)(loc4 == tw1)) {
			tr1 = F2243_21812(RTMS_EX_H("Syntax error in setup declaration",33,1339518062));
			F7_80(Current, tr1);
		} else {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
			if ((EIF_BOOLEAN)(loc4 == tw1)) {
				loc4 = F7_82(Current);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
				if ((EIF_BOOLEAN)(loc4 == tw1)) {
					loc1 = F7_86(Current);
					{
						/* INLINED CODE (READABLE_STRING_GENERAL.is_whitespace) */
						tb1 = (EIF_BOOLEAN)  0;
						(void) RTCW(loc1);
						ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_2_);
						tb1 = F2250_22082(loc1, ((EIF_INTEGER_32) 1L), ti4_1);
						/* END INLINED CODE */
					}
					tb1 = tb1;
					if (tb1) {
						loc2 = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
						F2243_21753(RTCW(loc2));
						for (;;) {
							if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || loc3)) break;
							loc1 = F7_86(Current);
							F2252_22149(RTCW(loc1));
							tr1 = F2243_21812(RTMS_EX_H("]\"",2,23842));
							tb1 = F2250_22085(RTCW(loc1), tr1);
							if (tb1) {
								tb1 = '\01';
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
								if (!(EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
									ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
									tb2 = F2250_22082(RTCW(loc1), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 2L)));
									tb1 = tb2;
								}
								if (tb1) {
									loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								} else {
									F2252_22164(RTCW(loc2), loc1);
									tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
									F2252_22177(RTCW(loc2), tw1);
								}
							} else {
								F2252_22164(RTCW(loc2), loc1);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
								F2252_22177(RTCW(loc2), tw1);
							}
						}
						if (loc3) {
							F7_94(Current, loc2);
						}
					} else {
						F2252_22155(RTCW(loc1), loc4);
						F2252_22149(RTCW(loc1));
						tr1 = F2243_21812(RTMS_EX_H("\"",1,34));
						tb1 = F2250_22085(RTCW(loc1), tr1);
						if (tb1) {
							{
								/* INLINED CODE (STRING_32.remove_tail) */
								ti4_1 = (EIF_INTEGER_32)  0;
								(void) RTCW(loc1);
								ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_2_);
								if ((EIF_BOOLEAN) (((EIF_INTEGER_32) 1L) > ti4_1)) {
									*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
									F2245_21851(loc1);
								} else {
									F2252_22146(loc1, (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
								}
								/* END INLINED CODE */
							}
							;
						} else {
							tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
							F2252_22155(RTCW(loc1), tw1);
						}
						loc2 = (EIF_REFERENCE) loc1;
					}
				} else {
					loc1 = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F2243_21753(RTCW(loc1));
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
					F2252_22177(RTCW(loc1), tw1);
					F2252_22177(RTCW(loc1), loc4);
					tr1 = F7_86(Current);
					F2252_22164(RTCW(loc1), tr1);
					F2252_22148(RTCW(loc1));
					F2252_22149(RTCW(loc1));
					tb1 = '\0';
					tb2 = '\0';
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 2L))) {
						{
							/* INLINED CODE (STRING_32.item) */
							tw1 = (EIF_CHARACTER_32)  0;
							(void) RTCW(loc1);
							tr1 = *(EIF_REFERENCE *)(loc1);
							tw1 = 
								/* INLINED CODE (SPECIAL.item) */
								*((EIF_CHARACTER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (((EIF_INTEGER_32) 1L) - ((EIF_INTEGER_32) 1L))))
								/* END INLINED CODE */;
							/* END INLINED CODE */
						}
						tw1 = tw1;
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb2 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb2) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						{
							/* INLINED CODE (STRING_32.item) */
							tw1 = (EIF_CHARACTER_32)  0;
							(void) RTCW(loc1);
							tr1 = *(EIF_REFERENCE *)(loc1);
							tw1 = 
								/* INLINED CODE (SPECIAL.item) */
								*((EIF_CHARACTER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L))))
								/* END INLINED CODE */;
							/* END INLINED CODE */
						}
						tw1 = tw1;
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb1 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb1) {
						{
							/* INLINED CODE (STRING_32.remove_head) */
							(void) RTCW(loc1);
							if ((EIF_BOOLEAN) (((EIF_INTEGER_32) 1L) > *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_2_))) {
								*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
								F2245_21851(loc1);
							} else {
								F2252_22147(loc1, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_2_) - ((EIF_INTEGER_32) 1L)));
							}
							/* END INLINED CODE */
						}
						;
						{
							/* INLINED CODE (STRING_32.remove_tail) */
							ti4_1 = (EIF_INTEGER_32)  0;
							(void) RTCW(loc1);
							ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_2_);
							if ((EIF_BOOLEAN) (((EIF_INTEGER_32) 1L) > ti4_1)) {
								*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
								F2245_21851(loc1);
							} else {
								F2252_22146(loc1, (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
							}
							/* END INLINED CODE */
						}
						;
					}
					loc2 = (EIF_REFERENCE) loc1;
					loc4 = F7_84(Current);
				}
			} else {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
				if ((EIF_BOOLEAN)(loc4 == tw1)) {
					loc1 = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F2243_21753(RTCW(loc1));
					loc2 = (EIF_REFERENCE) loc1;
				} else {
					loc4 = F7_81(Current);
					loc1 = F7_86(Current);
					F2252_22148(RTCW(loc1));
					F2252_22149(RTCW(loc1));
					loc2 = (EIF_REFERENCE) loc1;
				}
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			if ((EIF_BOOLEAN)(loc2 == NULL)) {
				loc2 = F2243_21812(RTMS_EX_H("",0,0));
			}
			{
				/* INLINED CODE (IRON_PACKAGE_INFO_FILE_PARSER_CALLBACKS.on_setup) */
				(void) loc5;
				F336_4945(loc5, arg1, loc2);
				/* END INLINED CODE */
			}
			;
		}
	} else {
		tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
		{
			/* INLINED CODE (IRON_PACKAGE_INFO_FILE_PARSER.character_to_string) */
			tw1 = loc4;
			tr2 = (EIF_REFERENCE)  0;
			tr2 = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F2250_22049(RTCW(tr2), ((EIF_INTEGER_32) 1L));
			F2252_22177(RTCW(tr2), tw1);
			/* END INLINED CODE */
		}
		tr3 = tr2;
		{
			/* INLINED CODE (STRING_32.plus) */
			tr4 = (EIF_REFERENCE)  0;
			tr5 = tr1;
			(void) RTCW(tr5);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr3) + O17190[Dtype(tr3)-2249]);
			tr4 = F2252_22214(tr5, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(tr5+ _LNGOFF_1_1_0_2_) + ti4_1));
			F2252_22164(RTCW(tr4), tr5);
			F2252_22164(RTCW(tr4), tr3);
			/* END INLINED CODE */
		}
		tr1 = tr4;
		tr2 = F2243_21812(RTMS_EX_H("].",2,23854));
		{
			/* INLINED CODE (STRING_32.plus) */
			tr3 = (EIF_REFERENCE)  0;
			(void) RTCW(tr1);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2) + O17190[Dtype(tr2)-2249]);
			tr3 = F2252_22214(tr1, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(tr1+ _LNGOFF_1_1_0_2_) + ti4_1));
			F2252_22164(RTCW(tr3), tr1);
			F2252_22164(RTCW(tr3), tr2);
			/* END INLINED CODE */
		}
		tr1 = tr3;
		F7_80(Current, tr1);
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_projects_declaration */
void F7_76 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_32 loc5 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc5 = F7_84(Current);
	tb1 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(loc5 != tw1)) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_);
	}
	if (tb1) {
		loc5 = F7_81(Current);
		loc1 = F7_91(Current);
		loc5 = F7_81(Current);
		for (;;) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || loc4) || *(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_))) break;
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R16970[Dtype(RTCW(loc1))-2246])(loc1);
			if (tb1) {
				loc5 = F7_82(Current);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				if ((EIF_BOOLEAN)(loc5 == tw1)) {
					loc5 = F7_81(Current);
					F7_72(Current);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_))) {
						loc5 = F7_84(Current);
						loc5 = F7_81(Current);
						loc1 = F7_91(Current);
						loc5 = F7_81(Current);
					}
				} else {
					tr1 = F2243_21812(RTMS_EX_H("Invalid project name",20,415510117));
					F7_80(Current, tr1);
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			} else {
				tr1 = F2243_21812(RTCV(RTOSCF(64,F7_64, (Current))));
				tb1 = F2250_22074(RTCW(loc1), tr1);
				if (tb1) {
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					tr1 = F2243_21812(RTCV(RTOSCF(66,F7_66, (Current))));
					tb1 = F2250_22074(RTCW(loc1), tr1);
					if (tb1) {
						loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						tr1 = F2243_21812(RTCV(RTOSCF(67,F7_67, (Current))));
						tb1 = F2250_22074(RTCW(loc1), tr1);
						if (tb1) {
							loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						} else {
							F7_77(Current, loc1);
							loc5 = F7_81(Current);
							loc5 = F7_84(Current);
							for (;;) {
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
								if ((EIF_BOOLEAN)(loc5 != tw1)) break;
								loc5 = F7_81(Current);
								F7_72(Current);
								loc5 = F7_84(Current);
							}
							loc5 = F7_81(Current);
							loc1 = F7_91(Current);
							loc5 = F7_81(Current);
						}
					}
				}
			}
		}
		if (loc2) {
			F7_78(Current);
		} else {
			if (loc3) {
				F7_74(Current);
			}
		}
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_project_item_declaration */
void F7_77 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 loc2 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(10);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc3);
	RTLR(4,arg1);
	RTLR(5,loc4);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,tr4);
	RTLR(9,tr5);
	RTLIU(10);
	
	RTGC;
	loc2 = F7_84(Current);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '=';
	if ((EIF_BOOLEAN)(loc2 == tw1)) {
		loc2 = F7_84(Current);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		if ((EIF_BOOLEAN)(loc2 == tw1)) {
			tr1 = F2243_21812(RTMS_EX_H("Syntax error in project declaration",35,1660760430));
			F7_80(Current, tr1);
		} else {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
			if ((EIF_BOOLEAN)(loc2 == tw1)) {
				loc1 = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
				F2243_21753(RTCW(loc1));
				loc2 = F7_82(Current);
				for (;;) {
					tb1 = '\01';
					if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb1 = (EIF_BOOLEAN)(loc2 == tw1);
					}
					if (tb1) break;
					F2252_22177(RTCW(loc1), loc2);
					loc2 = F7_82(Current);
				}
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
				if ((EIF_BOOLEAN)(loc2 == tw1)) {
					tr1 = *(EIF_REFERENCE *)(Current);
					loc3 = tr1;
					if (EIF_TEST(loc3)) {
						{
							/* INLINED CODE (IRON_PACKAGE_INFO_FILE_PARSER_CALLBACKS.on_project) */
							(void) loc3;
							F336_4943(loc3, arg1, loc1);
							/* END INLINED CODE */
						}
						;
					}
					loc2 = F7_84(Current);
				}
			} else {
				loc1 = F7_86(Current);
				F2252_22148(RTCW(loc1));
				F2252_22149(RTCW(loc1));
				tr1 = *(EIF_REFERENCE *)(Current);
				loc4 = tr1;
				if (EIF_TEST(loc4)) {
					{
						/* INLINED CODE (IRON_PACKAGE_INFO_FILE_PARSER_CALLBACKS.on_project) */
						(void) loc4;
						F336_4943(loc4, arg1, loc1);
						/* END INLINED CODE */
					}
					;
				}
			}
		}
	} else {
		tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
		{
			/* INLINED CODE (IRON_PACKAGE_INFO_FILE_PARSER.character_to_string) */
			tw1 = loc2;
			tr2 = (EIF_REFERENCE)  0;
			tr2 = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F2250_22049(RTCW(tr2), ((EIF_INTEGER_32) 1L));
			F2252_22177(RTCW(tr2), tw1);
			/* END INLINED CODE */
		}
		tr3 = tr2;
		{
			/* INLINED CODE (STRING_32.plus) */
			tr4 = (EIF_REFERENCE)  0;
			tr5 = tr1;
			(void) RTCW(tr5);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr3) + O17190[Dtype(tr3)-2249]);
			tr4 = F2252_22214(tr5, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(tr5+ _LNGOFF_1_1_0_2_) + ti4_1));
			F2252_22164(RTCW(tr4), tr5);
			F2252_22164(RTCW(tr4), tr3);
			/* END INLINED CODE */
		}
		tr1 = tr4;
		tr2 = F2243_21812(RTMS_EX_H("].",2,23854));
		{
			/* INLINED CODE (STRING_32.plus) */
			tr3 = (EIF_REFERENCE)  0;
			(void) RTCW(tr1);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2) + O17190[Dtype(tr2)-2249]);
			tr3 = F2252_22214(tr1, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(tr1+ _LNGOFF_1_1_0_2_) + ti4_1));
			F2252_22164(RTCW(tr3), tr1);
			F2252_22164(RTCW(tr3), tr2);
			/* END INLINED CODE */
		}
		tr1 = tr3;
		F7_80(Current, tr1);
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_notes_declaration */
void F7_78 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 loc2 = (EIF_CHARACTER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc2 = F7_84(Current);
	tb1 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(loc2 != tw1)) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_);
	}
	if (tb1) {
		loc2 = F7_81(Current);
		loc1 = F7_92(Current);
		loc2 = F7_81(Current);
		for (;;) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || loc3) || *(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_))) break;
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R16970[Dtype(RTCW(loc1))-2246])(loc1);
			if (tb1) {
				loc2 = F7_82(Current);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				if ((EIF_BOOLEAN)(loc2 == tw1)) {
					loc2 = F7_81(Current);
					F7_72(Current);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_))) {
						loc2 = F7_84(Current);
						loc2 = F7_81(Current);
						loc1 = F7_92(Current);
						loc2 = F7_81(Current);
					}
				} else {
					tr1 = F2243_21812(RTMS_EX_H("Invalid note name",17,17618021));
					F7_80(Current, tr1);
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			} else {
				tr1 = F2243_21812(RTCV(RTOSCF(63,F7_63, (Current))));
				tb1 = F2250_22074(RTCW(loc1), tr1);
				if (tb1) {
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					tr1 = F2243_21812(RTCV(RTOSCF(64,F7_64, (Current))));
					tb1 = F2250_22074(RTCW(loc1), tr1);
					if (tb1) {
						loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						tr1 = F2243_21812(RTCV(RTOSCF(67,F7_67, (Current))));
						tb1 = F2250_22074(RTCW(loc1), tr1);
						if (tb1) {
							loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						} else {
							F7_79(Current, loc1);
							loc2 = F7_81(Current);
							loc2 = F7_84(Current);
							for (;;) {
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
								if ((EIF_BOOLEAN)(loc2 != tw1)) break;
								loc2 = F7_81(Current);
								F7_72(Current);
								loc2 = F7_84(Current);
							}
							loc2 = F7_81(Current);
							loc1 = F7_92(Current);
							loc2 = F7_81(Current);
						}
					}
				}
			}
		}
		if (loc3) {
			tr1 = F2243_21812(RTCV(RTOSCF(63,F7_63, (Current))));
			tb1 = F2250_22074(RTCW(loc1), tr1);
			if (tb1) {
				F7_73(Current);
			} else {
				tr1 = F2243_21812(RTCV(RTOSCF(64,F7_64, (Current))));
				tb1 = F2250_22074(RTCW(loc1), tr1);
				if (tb1) {
					F7_74(Current);
				}
			}
		}
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_note_item_declaration */
void F7_79 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_32 loc4 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(10);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc5);
	RTLR(5,arg1);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,tr4);
	RTLR(9,tr5);
	RTLIU(10);
	
	RTGC;
	loc4 = F7_84(Current);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
	if ((EIF_BOOLEAN)(loc4 == tw1)) {
		loc4 = F7_85(Current);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		if ((EIF_BOOLEAN)(loc4 == tw1)) {
			tr1 = F2243_21812(RTMS_EX_H("Syntax error in note declaration",32,1224969838));
			F7_80(Current, tr1);
		} else {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
			if ((EIF_BOOLEAN)(loc4 == tw1)) {
				loc4 = F7_82(Current);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
				if ((EIF_BOOLEAN)(loc4 == tw1)) {
					loc1 = F7_86(Current);
					{
						/* INLINED CODE (READABLE_STRING_GENERAL.is_whitespace) */
						tb1 = (EIF_BOOLEAN)  0;
						(void) RTCW(loc1);
						ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_2_);
						tb1 = F2250_22082(loc1, ((EIF_INTEGER_32) 1L), ti4_1);
						/* END INLINED CODE */
					}
					tb1 = tb1;
					if (tb1) {
						loc2 = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
						F2243_21753(RTCW(loc2));
						for (;;) {
							if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || loc3)) break;
							loc1 = F7_86(Current);
							F2252_22149(RTCW(loc1));
							tr1 = F2243_21812(RTMS_EX_H("]\"",2,23842));
							tb1 = F2250_22085(RTCW(loc1), tr1);
							if (tb1) {
								tb1 = '\01';
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
								if (!(EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
									ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
									tb2 = F2250_22082(RTCW(loc1), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 2L)));
									tb1 = tb2;
								}
								if (tb1) {
									loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								} else {
									F2252_22164(RTCW(loc2), loc1);
									tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
									F2252_22177(RTCW(loc2), tw1);
								}
							} else {
								F2252_22164(RTCW(loc2), loc1);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
								F2252_22177(RTCW(loc2), tw1);
							}
						}
						if (loc3) {
							F7_94(Current, loc2);
						}
					} else {
						F2252_22155(RTCW(loc1), loc4);
						F2252_22149(RTCW(loc1));
						tr1 = F2243_21812(RTMS_EX_H("\"",1,34));
						tb1 = F2250_22085(RTCW(loc1), tr1);
						if (tb1) {
							{
								/* INLINED CODE (STRING_32.remove_tail) */
								ti4_1 = (EIF_INTEGER_32)  0;
								(void) RTCW(loc1);
								ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_2_);
								if ((EIF_BOOLEAN) (((EIF_INTEGER_32) 1L) > ti4_1)) {
									*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
									F2245_21851(loc1);
								} else {
									F2252_22146(loc1, (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
								}
								/* END INLINED CODE */
							}
							;
						} else {
							tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
							F2252_22155(RTCW(loc1), tw1);
						}
						loc2 = (EIF_REFERENCE) loc1;
					}
				} else {
					loc1 = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F2243_21753(RTCW(loc1));
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
					F2252_22177(RTCW(loc1), tw1);
					F2252_22177(RTCW(loc1), loc4);
					tr1 = F7_86(Current);
					F2252_22164(RTCW(loc1), tr1);
					F2252_22148(RTCW(loc1));
					F2252_22149(RTCW(loc1));
					tb1 = '\0';
					tb2 = '\0';
					tb3 = '\0';
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 2L))) {
						{
							/* INLINED CODE (STRING_32.item) */
							tw1 = (EIF_CHARACTER_32)  0;
							(void) RTCW(loc1);
							tr1 = *(EIF_REFERENCE *)(loc1);
							tw1 = 
								/* INLINED CODE (SPECIAL.item) */
								*((EIF_CHARACTER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (((EIF_INTEGER_32) 1L) - ((EIF_INTEGER_32) 1L))))
								/* END INLINED CODE */;
							/* END INLINED CODE */
						}
						tw1 = tw1;
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb3 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb3) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						{
							/* INLINED CODE (STRING_32.item) */
							tw1 = (EIF_CHARACTER_32)  0;
							(void) RTCW(loc1);
							tr1 = *(EIF_REFERENCE *)(loc1);
							tw1 = 
								/* INLINED CODE (SPECIAL.item) */
								*((EIF_CHARACTER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L))))
								/* END INLINED CODE */;
							/* END INLINED CODE */
						}
						tw1 = tw1;
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb2 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb2) {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						ti4_1 = F2250_22061(RTCW(loc1), tw1, ((EIF_INTEGER_32) 2L));
						ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						tb1 = (EIF_BOOLEAN)(ti4_1 == ti4_2);
					}
					if (tb1) {
						{
							/* INLINED CODE (STRING_32.remove_head) */
							(void) RTCW(loc1);
							if ((EIF_BOOLEAN) (((EIF_INTEGER_32) 1L) > *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_2_))) {
								*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
								F2245_21851(loc1);
							} else {
								F2252_22147(loc1, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_2_) - ((EIF_INTEGER_32) 1L)));
							}
							/* END INLINED CODE */
						}
						;
						{
							/* INLINED CODE (STRING_32.remove_tail) */
							ti4_1 = (EIF_INTEGER_32)  0;
							(void) RTCW(loc1);
							ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_2_);
							if ((EIF_BOOLEAN) (((EIF_INTEGER_32) 1L) > ti4_1)) {
								*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
								F2245_21851(loc1);
							} else {
								F2252_22146(loc1, (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
							}
							/* END INLINED CODE */
						}
						;
					}
					loc2 = (EIF_REFERENCE) loc1;
					loc4 = F7_84(Current);
				}
			} else {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
				if ((EIF_BOOLEAN)(loc4 == tw1)) {
					loc1 = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F2243_21753(RTCW(loc1));
					loc2 = (EIF_REFERENCE) loc1;
				} else {
					loc4 = F7_81(Current);
					loc1 = F7_86(Current);
					F2252_22148(RTCW(loc1));
					F2252_22149(RTCW(loc1));
					loc2 = (EIF_REFERENCE) loc1;
				}
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			if ((EIF_BOOLEAN)(loc2 == NULL)) {
				loc2 = F2243_21812(RTMS_EX_H("",0,0));
			}
			{
				/* INLINED CODE (IRON_PACKAGE_INFO_FILE_PARSER_CALLBACKS.on_note) */
				(void) loc5;
				tr1 = *(EIF_REFERENCE *)(loc5 + _REFACS_3_);
				F1626_15246(RTCW(tr1), loc2, arg1);
				/* END INLINED CODE */
			}
			;
		}
	} else {
		tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
		{
			/* INLINED CODE (IRON_PACKAGE_INFO_FILE_PARSER.character_to_string) */
			tw1 = loc4;
			tr2 = (EIF_REFERENCE)  0;
			tr2 = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F2250_22049(RTCW(tr2), ((EIF_INTEGER_32) 1L));
			F2252_22177(RTCW(tr2), tw1);
			/* END INLINED CODE */
		}
		tr3 = tr2;
		{
			/* INLINED CODE (STRING_32.plus) */
			tr4 = (EIF_REFERENCE)  0;
			tr5 = tr1;
			(void) RTCW(tr5);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr3) + O17190[Dtype(tr3)-2249]);
			tr4 = F2252_22214(tr5, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(tr5+ _LNGOFF_1_1_0_2_) + ti4_1));
			F2252_22164(RTCW(tr4), tr5);
			F2252_22164(RTCW(tr4), tr3);
			/* END INLINED CODE */
		}
		tr1 = tr4;
		tr2 = F2243_21812(RTMS_EX_H("].",2,23854));
		{
			/* INLINED CODE (STRING_32.plus) */
			tr3 = (EIF_REFERENCE)  0;
			(void) RTCW(tr1);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2) + O17190[Dtype(tr2)-2249]);
			tr3 = F2252_22214(tr1, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(tr1+ _LNGOFF_1_1_0_2_) + ti4_1));
			F2252_22164(RTCW(tr3), tr1);
			F2252_22164(RTCW(tr3), tr2);
			/* END INLINED CODE */
		}
		tr1 = tr3;
		F7_80(Current, tr1);
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.report_error */
void F7_80 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		{
			/* INLINED CODE (IRON_PACKAGE_INFO_FILE_PARSER_CALLBACKS.on_error) */
			(void) loc1;
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.previous_character */
EIF_CHARACTER_32 F7_81 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_) >= ((EIF_INTEGER_32) 1L))) {
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_))--;
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_) > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			{
				/* INLINED CODE (STRING_32.item) */
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_);
				tw1 = (EIF_CHARACTER_32)  0;
				(void) RTCW(tr1);
				tr2 = *(EIF_REFERENCE *)(tr1);
				tw1 = 
					/* INLINED CODE (SPECIAL.item) */
					*((EIF_CHARACTER_32 *)RTCW(tr2) + ((EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L))))
					/* END INLINED CODE */;
				/* END INLINED CODE */
			}
			Result = tw1;
		} else {
			Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		}
		{
			/* INLINED CODE (IRON_PACKAGE_INFO_FILE_PARSER.update_end_of_input) */
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_) > ti4_1);
			/* END INLINED CODE */
		}
		;
	} else {
		Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		tr1 = F2243_21812(RTMS_EX_H("out of input",12,330662516));
		F7_80(Current, tr1);
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_character */
EIF_CHARACTER_32 F7_82 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
		tr1 = F2243_21812(RTMS_EX_H("out of input",12,330662516));
		F7_80(Current, tr1);
		Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	} else {
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_))++;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		{
			/* INLINED CODE (STRING_32.item) */
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_);
			tw1 = (EIF_CHARACTER_32)  0;
			(void) RTCW(tr1);
			tr2 = *(EIF_REFERENCE *)(tr1);
			tw1 = 
				/* INLINED CODE (SPECIAL.item) */
				*((EIF_CHARACTER_32 *)RTCW(tr2) + ((EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L))))
				/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		Result = tw1;
		{
			/* INLINED CODE (IRON_PACKAGE_INFO_FILE_PARSER.update_end_of_input) */
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_) > ti4_1);
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.update_end_of_input */
void F7_83 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_) > ti4_1);
	RTLE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_non_whitespace_character */
EIF_CHARACTER_32 F7_84 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
		tr1 = F2243_21812(RTMS_EX_H("out of input",12,330662516));
		F7_80(Current, tr1);
		Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	} else {
		Result = F7_82(Current);
		for (;;) {
			tb1 = '\01';
			if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
				tr1 = RTLNS(eif_new_type(2082, 0x00).id, 2082, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = Result;
				tb2 = F2081_20110(RTCW(tr1));
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) break;
			Result = F7_82(Current);
		}
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_non_whitespace_character_until_eol */
EIF_CHARACTER_32 F7_85 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
		tr1 = F2243_21812(RTMS_EX_H("out of input",12,330662516));
		F7_80(Current, tr1);
		Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	} else {
		Result = F7_82(Current);
		for (;;) {
			tb1 = '\01';
			tb2 = '\01';
			if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
				tr1 = RTLNS(eif_new_type(2082, 0x00).id, 2082, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = Result;
				tb3 = F2081_20110(RTCW(tr1));
				tb2 = (EIF_BOOLEAN) !tb3;
			}
			if (!tb2) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
				tb1 = (EIF_BOOLEAN)(Result == tw1);
			}
			if (tb1) break;
			Result = F7_82(Current);
		}
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_text_until_eol */
EIF_REFERENCE F7_86 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F2243_21753(RTCW(Result));
	loc1 = F7_82(Current);
	for (;;) {
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
			tb1 = (EIF_BOOLEAN)(loc1 == tw1);
		}
		if (tb1) break;
		F2252_22177(RTCW(Result), loc1);
		loc1 = F7_82(Current);
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_alphabetic */
EIF_REFERENCE F7_87 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F2243_21753(RTCW(Result));
	loc1 = F7_82(Current);
	for (;;) {
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tr1 = RTLNS(eif_new_type(2082, 0x00).id, 2082, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = loc1;
			tb2 = F2081_20104(RTCW(tr1));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) break;
		F2252_22177(RTCW(Result), loc1);
		loc1 = F7_82(Current);
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_package_name */
EIF_REFERENCE F7_89 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F2243_21753(RTCW(Result));
	loc1 = F7_82(Current);
	for (;;) {
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tb2 = '\01';
			tb3 = '\01';
			tb4 = '\01';
			tr1 = RTLNS(eif_new_type(2082, 0x00).id, 2082, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = loc1;
			tb5 = F2081_20112(RTCW(tr1));
			if (!tb5) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
				tb4 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb4) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				tb3 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb3) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '+';
				tb2 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) break;
		F2252_22177(RTCW(Result), loc1);
		loc1 = F7_82(Current);
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_alpha_numeric_or_dash */
EIF_REFERENCE F7_91 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F2243_21753(RTCW(Result));
	loc1 = F7_82(Current);
	for (;;) {
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tb2 = '\01';
			tb3 = '\01';
			tr1 = RTLNS(eif_new_type(2082, 0x00).id, 2082, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = loc1;
			tb4 = F2081_20112(RTCW(tr1));
			if (!tb4) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
				tb3 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb3) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				tb2 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) break;
		F2252_22177(RTCW(Result), loc1);
		loc1 = F7_82(Current);
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_alpha_numeric_with_bracket */
EIF_REFERENCE F7_92 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	Result = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F2243_21753(RTCW(Result));
	loc1 = F7_82(Current);
	for (;;) {
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tb2 = '\01';
			tb3 = '\01';
			tb4 = '\01';
			tr1 = RTLNS(eif_new_type(2082, 0x00).id, 2082, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = loc1;
			tb5 = F2081_20112(RTCW(tr1));
			if (!tb5) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
				tb4 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb4) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
				tb3 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb3) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
				tb2 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) break;
		F2252_22177(RTCW(Result), loc1);
		loc1 = F7_82(Current);
		if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
			if ((EIF_BOOLEAN)(loc1 != tw1)) {
				loc2--;
			}
		} else {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
			if ((EIF_BOOLEAN)(loc1 == tw1)) {
				loc2++;
			}
		}
	}
	if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
		tr1 = RTMS32_EX_H("I\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000n\000\000\000o\000\000\000t\000\000\000e\000\000\000 \000\000\000n\000\000\000a\000\000\000m\000\000\000e\000\000\000 \000\000\000w\000\000\000i\000\000\000t\000\000\000h\000\000\000 \000\000\000b\000\000\000r\000\000\000a\000\000\000c\000\000\000k\000\000\000e\000\000\000t\000\000\000 \000\000\000\"\000\000\000",32,304418082);
		{
			/* INLINED CODE (STRING_32.plus) */
			tr2 = (EIF_REFERENCE)  0;
			tr3 = tr1;
			(void) RTCW(tr3);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result) + O17190[Dtype(Result)-2249]);
			tr2 = F2252_22214(tr3, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(tr3+ _LNGOFF_1_1_0_2_) + ti4_1));
			F2252_22164(RTCW(tr2), tr3);
			F2252_22164(RTCW(tr2), Result);
			/* END INLINED CODE */
		}
		tr1 = tr2;
		tr2 = F2243_21812(RTMS_EX_H("\"",1,34));
		{
			/* INLINED CODE (STRING_32.plus) */
			tr3 = (EIF_REFERENCE)  0;
			(void) RTCW(tr1);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2) + O17190[Dtype(tr2)-2249]);
			tr3 = F2252_22214(tr1, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(tr1+ _LNGOFF_1_1_0_2_) + ti4_1));
			F2252_22164(RTCW(tr3), tr1);
			F2252_22164(RTCW(tr3), tr2);
			/* END INLINED CODE */
		}
		tr1 = tr3;
		F7_80(Current, tr1);
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.character_to_string */
EIF_REFERENCE F7_93 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	RTGC;
	Result = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F2250_22049(RTCW(Result), ((EIF_INTEGER_32) 1L));
	F2252_22177(RTCW(Result), arg1);
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.normalize_multiline */
void F7_94 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,loc6);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc2 = (EIF_INTEGER_32) loc1;
	loc5 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc5)) break;
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
		loc3 = F2250_22061(RTCW(arg1), tw1, loc1);
		if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
			loc3 = (EIF_INTEGER_32) loc5;
		}
		if ((EIF_BOOLEAN)(loc3 == loc1)) {
		} else {
			if ((EIF_BOOLEAN)(loc6 == NULL)) {
				loc2 = (EIF_INTEGER_32) loc1;
				for (;;) {
					{
						/* INLINED CODE (STRING_32.item) */
						tw1 = (EIF_CHARACTER_32)  0;
						(void) RTCW(arg1);
						tr1 = *(EIF_REFERENCE *)(arg1);
						tw1 = 
							/* INLINED CODE (SPECIAL.item) */
							*((EIF_CHARACTER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L))))
							/* END INLINED CODE */;
						/* END INLINED CODE */
					}
					tw1 = tw1;
					tr1 = RTLNS(eif_new_type(2082, 0x00).id, 2082, _OBJSIZ_0_0_0_1_0_0_0_0_);
					*(EIF_CHARACTER_32 *)tr1 = tw1;
					tb1 = F2081_20110(RTCW(tr1));
					if ((EIF_BOOLEAN) !tb1) break;
					loc2++;
				}
				loc6 = F2252_22211(RTCW(arg1), loc1, (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
			} else {
				loc2 = (EIF_INTEGER_32) loc1;
				loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					tb2 = '\01';
					tb3 = '\01';
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
					if (!(EIF_BOOLEAN) (loc4 > ti4_1)) {
						{
							/* INLINED CODE (STRING_32.item) */
							tw1 = (EIF_CHARACTER_32)  0;
							(void) RTCW(loc6);
							tr1 = *(EIF_REFERENCE *)(loc6);
							tw1 = 
								/* INLINED CODE (SPECIAL.item) */
								*((EIF_CHARACTER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (loc4 - ((EIF_INTEGER_32) 1L))))
								/* END INLINED CODE */;
							/* END INLINED CODE */
						}
						tw1 = tw1;
						{
							/* INLINED CODE (STRING_32.item) */
							tw2 = (EIF_CHARACTER_32)  0;
							(void) RTCW(arg1);
							tr1 = *(EIF_REFERENCE *)(arg1);
							tw2 = 
								/* INLINED CODE (SPECIAL.item) */
								*((EIF_CHARACTER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L))))
								/* END INLINED CODE */;
							/* END INLINED CODE */
						}
						tw2 = tw2;
						tb3 = (EIF_BOOLEAN)(tw1 != tw2);
					}
					if (!tb3) {
						tb2 = (EIF_BOOLEAN) (loc2 > loc3);
					}
					if (tb2) break;
					loc4++;
					loc2++;
				}
				tb3 = '\0';
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (loc4 <= ti4_1)) {
					{
						/* INLINED CODE (STRING_32.item) */
						tw1 = (EIF_CHARACTER_32)  0;
						(void) RTCW(loc6);
						tr1 = *(EIF_REFERENCE *)(loc6);
						tw1 = 
							/* INLINED CODE (SPECIAL.item) */
							*((EIF_CHARACTER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (loc4 - ((EIF_INTEGER_32) 1L))))
							/* END INLINED CODE */;
						/* END INLINED CODE */
					}
					tw1 = tw1;
					{
						/* INLINED CODE (STRING_32.item) */
						tw2 = (EIF_CHARACTER_32)  0;
						(void) RTCW(arg1);
						tr1 = *(EIF_REFERENCE *)(arg1);
						tw2 = 
							/* INLINED CODE (SPECIAL.item) */
							*((EIF_CHARACTER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L))))
							/* END INLINED CODE */;
						/* END INLINED CODE */
					}
					tw2 = tw2;
					tb3 = (EIF_BOOLEAN)(tw1 != tw2);
				}
				if (tb3) {
					{
						/* INLINED CODE (STRING_32.keep_head) */
						ti4_1 = (EIF_INTEGER_32) (loc4 - ((EIF_INTEGER_32) 1L));
						(void) RTCW(loc6);
						if ((EIF_BOOLEAN) (ti4_1 < *(EIF_INTEGER_32 *)(loc6+ _LNGOFF_1_1_0_2_))) {
							*(EIF_INTEGER_32 *)(loc6+ _LNGOFF_1_1_0_2_) = (EIF_INTEGER_32) ti4_1;
							F2245_21851(loc6);
						}
						/* END INLINED CODE */
					}
					;
				}
			}
		}
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
	}
	tb3 = '\0';
	if ((EIF_BOOLEAN)(loc6 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
		tb3 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb3) {
		tb3 = F2250_22084(RTCW(arg1), loc6);
		if (tb3) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
			{
				/* INLINED CODE (STRING_32.remove_head) */
				(void) RTCW(arg1);
				if ((EIF_BOOLEAN) (ti4_1 > *(EIF_INTEGER_32 *)(arg1+ _LNGOFF_1_1_0_2_))) {
					*(EIF_INTEGER_32 *)(arg1+ _LNGOFF_1_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					F2245_21851(arg1);
				} else {
					F2252_22147(arg1, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(arg1+ _LNGOFF_1_1_0_2_) - ti4_1));
				}
				/* END INLINED CODE */
			}
			;
		}
		tr1 = RTMS32_EX_H("\012\000\000\000",1,10);
		{
			/* INLINED CODE (STRING_32.plus) */
			tr2 = (EIF_REFERENCE)  0;
			tr3 = tr1;
			(void) RTCW(tr3);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6) + O17190[Dtype(loc6)-2249]);
			tr2 = F2252_22214(tr3, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(tr3+ _LNGOFF_1_1_0_2_) + ti4_1));
			F2252_22164(RTCW(tr2), tr3);
			F2252_22164(RTCW(tr2), loc6);
			/* END INLINED CODE */
		}
		tr1 = tr2;
		tr2 = RTMS32_EX_H("\012\000\000\000",1,10);
		F2252_22141(RTCW(arg1), tr1, tr2);
	}
	RTLE;
}

void EIF_Minit5 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
