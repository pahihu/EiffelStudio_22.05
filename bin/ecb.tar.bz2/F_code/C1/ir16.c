/*
 * Code for class IRON_REPOSITORY_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir16.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_REPOSITORY_FACTORY}.new_repository */
EIF_REFERENCE F20_159 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tb1 = '\01';
	tr1 = RTMS_EX_H("https://",8,441357103);
	tb2 = F2243_21800(RTCW(arg1), tr1);
	if (!tb2) {
		tr1 = RTMS_EX_H("http://",7,769736239);
		tb2 = F2243_21800(RTCW(arg1), tr1);
		tb1 = tb2;
	}
	if (tb1) {
		loc1 = RTLNS(eif_new_type(3226, 0x00).id, 3226, _OBJSIZ_6_2_0_1_0_0_0_0_);
		F3227_38289(RTCW(loc1), arg1);
		Result = RTLNS(eif_new_type(1916, 0x00).id, 1916, _OBJSIZ_4_0_0_0_0_0_0_0_);
		tr1 = F3227_38307(RTCW(loc1));
		F1917_18165(RTCW(Result), tr1);
	} else {
		tr1 = RTMS_EX_H("file://",7,1704345391);
		tb1 = F2243_21800(RTCW(arg1), tr1);
		if (tb1) {
			loc1 = RTLNS(eif_new_type(3226, 0x00).id, 3226, _OBJSIZ_6_2_0_1_0_0_0_0_);
			F3227_38289(RTCW(loc1), arg1);
			Result = RTLNS(eif_new_type(1917, 0x00).id, 1917, _OBJSIZ_3_0_0_0_0_0_0_0_);
			tr1 = F3227_38307(RTCW(loc1));
			F1918_18178(RTCW(Result), tr1);
		} else {
			Result = RTLNS(eif_new_type(1917, 0x00).id, 1917, _OBJSIZ_3_0_0_0_0_0_0_0_);
			F1918_18176(RTCW(Result), arg1);
			RTLE;
			return (EIF_REFERENCE) Result;
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit16 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
