/*
 * Code for class AST_ATTRIBUTE_INITIALIZATION_TRACKER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "as44.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {AST_ATTRIBUTE_INITIALIZATION_TRACKER}.make */
void F48_809 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(817,F48_817, (Current));
	{
		/* INLINED CODE (AST_SCOPE_KEEPER_FACTORY.create_scope_keeper) */
		ti4_1 = arg1;
		tr2 = (EIF_REFERENCE)  0;
		(void) RTCW(tr1);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 63L))) {
			tr2 = RTLNS(eif_new_type(353, 0x00).id, 353, _OBJSIZ_3_0_0_1_0_0_0_0_);
			F352_5055(RTCW(tr2), ti4_1);
		} else {
			tr2 = RTLNS(eif_new_type(354, 0x00).id, 354, _OBJSIZ_2_0_0_1_0_0_1_0_);
			F353_5055(RTCW(tr2), ti4_1);
		}
		/* END INLINED CODE */
	}
	tr1 = tr2;
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {AST_ATTRIBUTE_INITIALIZATION_TRACKER}.is_attribute_set */
EIF_BOOLEAN F48_810 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	{
		/* INLINED CODE (AST_ATTRIBUTE_INITIALIZATION_TRACKER.keeper) */
		tr1 = (EIF_REFERENCE)  0;
		tr1 = *(EIF_REFERENCE *)(Current);
		/* END INLINED CODE */
	}
	tr2 = tr1;
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_INTEGER_32)) R4927[Dtype(RTCW(tr2))-353])(tr2, arg1);
	RTLE;
	return Result;
}

/* {AST_ATTRIBUTE_INITIALIZATION_TRACKER}.has_unset_index */
EIF_BOOLEAN F48_811 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	{
		/* INLINED CODE (AST_ATTRIBUTE_INITIALIZATION_TRACKER.keeper) */
		tr1 = (EIF_REFERENCE)  0;
		tr1 = *(EIF_REFERENCE *)(Current);
		/* END INLINED CODE */
	}
	tr2 = tr1;
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R4929[Dtype(RTCW(tr2))-353])(tr2, arg1, arg2);
	RTLE;
	return Result;
}

/* {AST_ATTRIBUTE_INITIALIZATION_TRACKER}.set_attribute */
void F48_813 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	{
		/* INLINED CODE (AST_ATTRIBUTE_INITIALIZATION_TRACKER.keeper) */
		tr1 = (EIF_REFERENCE)  0;
		tr1 = *(EIF_REFERENCE *)(Current);
		/* END INLINED CODE */
	}
	tr2 = tr1;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R4932[Dtype(RTCW(tr2))-353])(tr2, arg1);
	RTLE;
}

/* {AST_ATTRIBUTE_INITIALIZATION_TRACKER}.set_all */
void F48_814 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	{
		/* INLINED CODE (AST_ATTRIBUTE_INITIALIZATION_TRACKER.keeper) */
		tr1 = (EIF_REFERENCE)  0;
		tr1 = *(EIF_REFERENCE *)(Current);
		/* END INLINED CODE */
	}
	tr2 = tr1;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4934[Dtype(RTCW(tr2))-353])(tr2);
	RTLE;
}

/* {AST_ATTRIBUTE_INITIALIZATION_TRACKER}.keeper */
EIF_REFERENCE F48_815 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current);
}

/* {AST_ATTRIBUTE_INITIALIZATION_TRACKER}.factory */
static EIF_REFERENCE F48_817_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (817);
#define Result RTOSR(817)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(26, 0x00).id, 26, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (817);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F48_817 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(817,F48_817_body,(Current));
}

void EIF_Minit44 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
