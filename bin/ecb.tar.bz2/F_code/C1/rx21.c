/*
 * Code for class RX_CHARACTER_SET
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "rx21.h"
#include "eif_built_in.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RX_CHARACTER_SET}.make_empty */
void F25_219 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {RX_CHARACTER_SET}.make */
void F25_220 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	{
		/* INLINED CODE (RX_CHARACTER_SET.make_empty) */
		*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		/* END INLINED CODE */
	}
	;
	F25_226(Current, arg1);
	RTLE;
}

/* {RX_CHARACTER_SET}.has */
EIF_BOOLEAN F25_223 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_NATURAL_64 tu8_3;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
		Result = '\0';
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_)) {
			tr1 = RTLNS(eif_new_type(3585, 0x00).id, 3585, _OBJSIZ_0_0_0_0_0_0_0_0_);
			{
				/* INLINED CODE (UC_UNICODE_ROUTINES.valid_non_surrogate_natural_32_code) */
				tb1 = (EIF_BOOLEAN)  0;
				(void) RTCW(tr1);
				tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (arg1 >= ((EIF_NATURAL_32) 0U)) && (EIF_BOOLEAN) (arg1 < ((EIF_NATURAL_32) 55296U))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) (arg1 > ((EIF_NATURAL_32) 57343U)) && (EIF_BOOLEAN) (arg1 <= ((EIF_NATURAL_32) 1114111U))));
				/* END INLINED CODE */
			}
			Result = tb1;
		}
	} else {
		if ((EIF_BOOLEAN) (arg1 < (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L))) {
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_0_);
			tr1 = RTOSCF(237,F25_237, (Current));
			ti4_1 = (EIF_INTEGER_32) arg1;
			/* INLINED CODE (SPECIAL.item) */
			tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (ti4_1));
			/* END INLINED CODE */
			tu8_2 = tu8_3;
			tu8_1 = eif_bit_and(tu8_1,tu8_2);
			Result = *(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L)) != Result);
		} else {
			if ((EIF_BOOLEAN) (arg1 < (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L))) {
				tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_1_);
				tr1 = RTOSCF(237,F25_237, (Current));
				ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_32) (arg1 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)));
				/* INLINED CODE (SPECIAL.item) */
				tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (ti4_1));
				/* END INLINED CODE */
				tu8_2 = tu8_3;
				tu8_1 = eif_bit_and(tu8_1,tu8_2);
				Result = *(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L)) != Result);
			} else {
				if ((EIF_BOOLEAN) (arg1 < (EIF_NATURAL_32) ((EIF_INTEGER_32) 192L))) {
					tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_2_);
					tr1 = RTOSCF(237,F25_237, (Current));
					ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_32) (arg1 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)));
					/* INLINED CODE (SPECIAL.item) */
					tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (ti4_1));
					/* END INLINED CODE */
					tu8_2 = tu8_3;
					tu8_1 = eif_bit_and(tu8_1,tu8_2);
					Result = *(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_);
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L)) != Result);
				} else {
					if ((EIF_BOOLEAN) (arg1 < (EIF_NATURAL_32) ((EIF_INTEGER_32) 256L))) {
						tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_3_);
						tr1 = RTOSCF(237,F25_237, (Current));
						ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_32) (arg1 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)));
						/* INLINED CODE (SPECIAL.item) */
						tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (ti4_1));
						/* END INLINED CODE */
						tu8_2 = tu8_3;
						tu8_1 = eif_bit_and(tu8_1,tu8_2);
						Result = *(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_);
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L)) != Result);
					} else {
						loc1 = (EIF_NATURAL_32) (EIF_NATURAL_32) (arg1 / (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L));
						tb1 = '\0';
						tr1 = *(EIF_REFERENCE *)(Current);
						loc2 = tr1;
						if (EIF_TEST(loc2)) {
							{
								/* INLINED CODE (DS_SPARSE_TABLE.has) */
								tb2 = (EIF_BOOLEAN)  0;
								(void) loc2;
								F3036_34459(loc2, loc1);
								ti4_1 = *(EIF_INTEGER_32 *)(loc2+ _LNGOFF_11_0_0_3_);
								tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) -1L));
								/* END INLINED CODE */
							}
							tb2 = tb2;
							tb1 = tb2;
						}
						if (tb1) {
							{
								/* INLINED CODE (DS_SPARSE_TABLE.item) */
								tu8_1 = (EIF_NATURAL_64)  0;
								(void) loc2;
								F3036_34459(loc2, loc1);
								
								tu8_1 = F3040_34563(loc2, *(EIF_INTEGER_32 *)(loc2+ _LNGOFF_11_0_0_3_));
								/* END INLINED CODE */
							}
							tu8_1 = tu8_1;
							tr1 = RTOSCF(237,F25_237, (Current));
							ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_32) (arg1 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)));
							/* INLINED CODE (SPECIAL.item) */
							tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (ti4_1));
							/* END INLINED CODE */
							tu8_2 = tu8_3;
							tu8_1 = eif_bit_and(tu8_1,tu8_2);
							Result = *(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_);
							Result = (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L)) != Result);
						} else {
							Result = '\0';
							if ((EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) != *(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_))) {
								tr1 = RTLNS(eif_new_type(3585, 0x00).id, 3585, _OBJSIZ_0_0_0_0_0_0_0_0_);
								{
									/* INLINED CODE (UC_UNICODE_ROUTINES.valid_non_surrogate_natural_32_code) */
									tb1 = (EIF_BOOLEAN)  0;
									(void) RTCW(tr1);
									tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (arg1 >= ((EIF_NATURAL_32) 0U)) && (EIF_BOOLEAN) (arg1 < ((EIF_NATURAL_32) 55296U))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) (arg1 > ((EIF_NATURAL_32) 57343U)) && (EIF_BOOLEAN) (arg1 <= ((EIF_NATURAL_32) 1114111U))));
									/* END INLINED CODE */
								}
								Result = tb1;
							}
						}
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {RX_CHARACTER_SET}.set_negated */
void F25_225 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_) = (EIF_BOOLEAN) arg1;
}

/* {RX_CHARACTER_SET}.add_string */
void F25_226 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R16992[Dtype(RTCW(arg1))-2246])(arg1);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R16955[Dtype(RTCW(arg1))-2246])(arg1, loc1);
		F25_227(Current, tu4_1);
		loc1++;
	}
	RTLE;
}

/* {RX_CHARACTER_SET}.add_character */
void F25_227 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_32 loc2 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_NATURAL_64 tu8_3;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 < (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L))) {
		tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_0_);
		tr1 = RTOSCF(237,F25_237, (Current));
		ti4_1 = (EIF_INTEGER_32) arg1;
		/* INLINED CODE (SPECIAL.item) */
		tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (ti4_1));
		/* END INLINED CODE */
		tu8_2 = tu8_3;
		tu8_1 = eif_bit_or(tu8_1,tu8_2);
		*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_0_) = (EIF_NATURAL_64) tu8_1;
	} else {
		if ((EIF_BOOLEAN) (arg1 < (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L))) {
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_1_);
			tr1 = RTOSCF(237,F25_237, (Current));
			ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_32) (arg1 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)));
			/* INLINED CODE (SPECIAL.item) */
			tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (ti4_1));
			/* END INLINED CODE */
			tu8_2 = tu8_3;
			tu8_1 = eif_bit_or(tu8_1,tu8_2);
			*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_1_) = (EIF_NATURAL_64) tu8_1;
		} else {
			if ((EIF_BOOLEAN) (arg1 < (EIF_NATURAL_32) ((EIF_INTEGER_32) 192L))) {
				tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_2_);
				tr1 = RTOSCF(237,F25_237, (Current));
				ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_32) (arg1 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)));
				/* INLINED CODE (SPECIAL.item) */
				tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (ti4_1));
				/* END INLINED CODE */
				tu8_2 = tu8_3;
				tu8_1 = eif_bit_or(tu8_1,tu8_2);
				*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_2_) = (EIF_NATURAL_64) tu8_1;
			} else {
				if ((EIF_BOOLEAN) (arg1 < (EIF_NATURAL_32) ((EIF_INTEGER_32) 256L))) {
					tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_3_);
					tr1 = RTOSCF(237,F25_237, (Current));
					ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_32) (arg1 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)));
					/* INLINED CODE (SPECIAL.item) */
					tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (ti4_1));
					/* END INLINED CODE */
					tu8_2 = tu8_3;
					tu8_1 = eif_bit_or(tu8_1,tu8_2);
					*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_3_) = (EIF_NATURAL_64) tu8_1;
				} else {
					loc2 = (EIF_NATURAL_32) (EIF_NATURAL_32) (arg1 / (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L));
					loc1 = *(EIF_REFERENCE *)(Current);
					if ((EIF_BOOLEAN)(loc1 == NULL)) {
						if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_)) {
							{
								static EIF_TYPE_INDEX typarr0[] = {3041,2064,2067,0xFFFF};
								EIF_TYPE typres0;
								static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
								
								typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
								loc1 = RTLNSMART(typres0.id);
							}
							F3038_34520(RTCW(loc1), ((EIF_INTEGER_32) 50L));
							RTAR(Current, loc1);
							*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
						}
					} else {
						tb1 = '\0';
						if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_)) {
							{
								/* INLINED CODE (DS_SPARSE_TABLE.has) */
								tb2 = (EIF_BOOLEAN)  0;
								(void) RTCW(loc1);
								F3036_34459(loc1, loc2);
								ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_11_0_0_3_);
								tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) -1L));
								/* END INLINED CODE */
							}
							tb2 = tb2;
							tb1 = (EIF_BOOLEAN) !tb2;
						}
						if (tb1) {
							loc1 = (EIF_REFERENCE) NULL;
						}
					}
					if ((EIF_BOOLEAN)(loc1 != NULL)) {
						{
							/* INLINED CODE (DS_SPARSE_TABLE.value) */
							ti4_1 = (EIF_INTEGER_32)  0;
							tu8_1 = (EIF_NATURAL_64)  0;
							(void) RTCW(loc1);
							ti4_1 = F3036_34460(loc1, loc2);
							if ((EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) -1L))) {
								tu8_1 = F3040_34563(loc1, ti4_1);
							}
							/* END INLINED CODE */
						}
						tu8_1 = tu8_1;
						tr1 = RTOSCF(237,F25_237, (Current));
						ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_32) (arg1 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)));
						/* INLINED CODE (SPECIAL.item) */
						tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (ti4_1));
						/* END INLINED CODE */
						tu8_2 = tu8_3;
						tu8_1 = eif_bit_or(tu8_1,tu8_2);
						F3038_34545(RTCW(loc1), tu8_1, loc2);
					}
				}
			}
		}
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {RX_CHARACTER_SET}.add_set */
void F25_228 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,loc5);
	RTLR(6,loc6);
	RTLIU(7);
	
	RTGC;
	tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_0_);
	tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_3_0_0_0_0_0_);
	tu8_1 = eif_bit_or(tu8_1,tu8_2);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_0_) = (EIF_NATURAL_64) tu8_1;
	tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_1_);
	tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_3_0_0_0_0_1_);
	tu8_1 = eif_bit_or(tu8_1,tu8_2);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_1_) = (EIF_NATURAL_64) tu8_1;
	tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_2_);
	tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_3_0_0_0_0_2_);
	tu8_1 = eif_bit_or(tu8_1,tu8_2);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_2_) = (EIF_NATURAL_64) tu8_1;
	tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_3_);
	tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_3_0_0_0_0_3_);
	tu8_1 = eif_bit_or(tu8_1,tu8_2);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_3_) = (EIF_NATURAL_64) tu8_1;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		{
			/* INLINED CODE (DS_CONTAINER.is_empty) */
			tb2 = (EIF_BOOLEAN)  0;
			(void) loc4;
			ti4_1 = *(EIF_INTEGER_32 *)(loc4+ _LNGOFF_11_0_0_8_);
			tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
			/* END INLINED CODE */
		}
		tb2 = tb2;
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		loc2 = *(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_);
		loc3 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_2_);
		loc1 = *(EIF_REFERENCE *)(Current);
		if ((EIF_BOOLEAN)(loc1 == NULL)) {
			if ((EIF_BOOLEAN) !loc2) {
				tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc4);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
				*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) = (EIF_BOOLEAN) loc3;
			}
		} else {
			{
				/* INLINED CODE (DS_CONTAINER.is_empty) */
				tb1 = (EIF_BOOLEAN)  0;
				(void) RTCW(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_11_0_0_8_);
				tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
				/* END INLINED CODE */
			}
			tb1 = tb1;
			if (tb1) {
				if ((EIF_BOOLEAN) !loc2) {
					{
						/* INLINED CODE (DS_SPARSE_TABLE.copy) */
						(void) RTCW(loc1);
						if ((EIF_BOOLEAN)(loc4 != loc1)) {
							F3036_34446(loc1, loc4);
							*(EIF_REFERENCE *)(loc1 + _REFACS_2_) = (EIF_REFERENCE) NULL;
						}
						/* END INLINED CODE */
					}
					;
					*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) = (EIF_BOOLEAN) loc3;
				}
			} else {
				if (loc3) {
					{
						/* INLINED CODE (DS_LINEAR.start) */
						(void) RTCW(loc1);
						tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_1_);
						F3036_34506(loc1, tr1);
						/* END INLINED CODE */
					}
					;
					for (;;) {
						{
							/* INLINED CODE (DS_LINEAR.after) */
							tb1 = (EIF_BOOLEAN)  0;
							(void) RTCW(loc1);
							tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_1_);
							tb1 = F3022_34213(loc1, tr1);
							/* END INLINED CODE */
						}
						tb1 = tb1;
						if (tb1) break;
						{
							/* INLINED CODE (DS_SPARSE_TABLE.key_for_iteration) */
							tu4_1 = (EIF_NATURAL_32)  0;
							(void) RTCW(loc1);
							tu4_1 = F3038_34561(loc1, *(EIF_REFERENCE *)(loc1 + _REFACS_1_));
							/* END INLINED CODE */
						}
						tu4_1 = tu4_1;
						{
							/* INLINED CODE (DS_SPARSE_TABLE.has) */
							tb2 = (EIF_BOOLEAN)  0;
							(void) loc4;
							F3036_34459(loc4, tu4_1);
							ti4_1 = *(EIF_INTEGER_32 *)(loc4+ _LNGOFF_11_0_0_3_);
							tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) -1L));
							/* END INLINED CODE */
						}
						tb2 = tb2;
						if ((EIF_BOOLEAN) !tb2) {
							{
								/* INLINED CODE (DS_SPARSE_TABLE.key_for_iteration) */
								tu4_1 = (EIF_NATURAL_32)  0;
								(void) RTCW(loc1);
								tu4_1 = F3038_34561(loc1, *(EIF_REFERENCE *)(loc1 + _REFACS_1_));
								/* END INLINED CODE */
							}
							tu4_1 = tu4_1;
							{
								/* INLINED CODE (DS_SPARSE_CONTAINER.remove) */
								(void) RTCW(loc1);
								F3036_34445(loc1);
								F3036_34459(loc1, tu4_1);
								if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_11_0_0_3_) != ((EIF_INTEGER_32) -1L))) {
									F3036_34464(loc1, *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_11_0_0_3_));
								}
								/* END INLINED CODE */
							}
							;
						} else {
							{
								/* INLINED CODE (DS_LINEAR.forth) */
								(void) RTCW(loc1);
								tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_1_);
								F3036_34508(loc1, tr1);
								/* END INLINED CODE */
							}
							;
						}
					}
				}
				{
					/* INLINED CODE (DS_LINEAR.new_iterator) */
					tr1 = (EIF_REFERENCE)  0;
					(void) loc4;
					tr1 = F3042_34597(loc4);
					F2950_33632(RTCW(tr1));
					/* END INLINED CODE */
				}
				loc5 = tr1;
				for (;;) {
					{
						/* INLINED CODE (DS_SPARSE_CONTAINER_CURSOR.after) */
						tb2 = (EIF_BOOLEAN)  0;
						(void) loc5;
						ti4_1 = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_2_0_0_0_);
						tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) -3L));
						/* END INLINED CODE */
					}
					tb2 = tb2;
					if (tb2) break;
					{
						/* INLINED CODE (DS_SPARSE_TABLE_CURSOR.key) */
						tu4_1 = (EIF_NATURAL_32)  0;
						(void) loc5;
						tr1 = *(EIF_REFERENCE *)(loc5 + _REFACS_1_);
						tu4_1 = F3038_34561(RTCW(tr1), loc5);
						/* END INLINED CODE */
					}
					tu4_1 = tu4_1;
					{
						/* INLINED CODE (DS_SPARSE_TABLE.search) */
						(void) RTCW(loc1);
						F3036_34459(loc1, tu4_1);
						*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_11_0_0_6_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_11_0_0_3_);
						/* END INLINED CODE */
					}
					;
					{
						/* INLINED CODE (DS_SPARSE_CONTAINER.found) */
						tb3 = (EIF_BOOLEAN)  0;
						(void) RTCW(loc1);
						ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_11_0_0_6_);
						tb3 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) -1L));
						/* END INLINED CODE */
					}
					tb3 = tb3;
					if (tb3) {
						{
							/* INLINED CODE (DS_SPARSE_CONTAINER.found_item) */
							tu8_1 = (EIF_NATURAL_64)  0;
							(void) RTCW(loc1);
							tu8_1 = F3040_34563(loc1, *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_11_0_0_6_));
							/* END INLINED CODE */
						}
						tu8_1 = tu8_1;
						{
							/* INLINED CODE (DS_CURSOR.item) */
							tu8_2 = (EIF_NATURAL_64)  0;
							(void) loc5;
							tr1 = *(EIF_REFERENCE *)(loc5 + _REFACS_1_);
							tu8_2 = F3036_34502(RTCW(tr1), loc5);
							/* END INLINED CODE */
						}
						tu8_2 = tu8_2;
						tu8_1 = eif_bit_or(tu8_1,tu8_2);
						{
							/* INLINED CODE (DS_SPARSE_TABLE.replace_found_item) */
							(void) RTCW(loc1);
							F3040_34564(loc1, tu8_1, *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_11_0_0_6_));
							/* END INLINED CODE */
						}
						;
					} else {
						if ((EIF_BOOLEAN) !loc2) {
							{
								/* INLINED CODE (DS_CURSOR.item) */
								tu8_1 = (EIF_NATURAL_64)  0;
								(void) loc5;
								tr1 = *(EIF_REFERENCE *)(loc5 + _REFACS_1_);
								tu8_1 = F3036_34502(RTCW(tr1), loc5);
								/* END INLINED CODE */
							}
							tu8_1 = tu8_1;
							{
								/* INLINED CODE (DS_SPARSE_TABLE_CURSOR.key) */
								tu4_1 = (EIF_NATURAL_32)  0;
								(void) loc5;
								tr1 = *(EIF_REFERENCE *)(loc5 + _REFACS_1_);
								tu4_1 = F3038_34561(RTCW(tr1), loc5);
								/* END INLINED CODE */
							}
							tu4_1 = tu4_1;
							F3038_34546(RTCW(loc1), tu8_1, tu4_1);
						}
					}
					{
						/* INLINED CODE (DS_LINEAR_CURSOR.forth) */
						(void) loc5;
						tr1 = *(EIF_REFERENCE *)(loc5 + _REFACS_1_);
						F3036_34508(RTCW(tr1), loc5);
						/* END INLINED CODE */
					}
					;
				}
				*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc2 || loc3);
			}
		}
	} else {
		tb3 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_2_);
		if (tb3) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			tr1 = *(EIF_REFERENCE *)(Current);
			loc6 = tr1;
			if (EIF_TEST(loc6)) {
				F3036_34449(loc6);
			}
		}
	}
	tb3 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
		tb4 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_0_);
		tb3 = tb4;
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) tb3;
	RTLE;
}

/* {RX_CHARACTER_SET}.add_negated_set */
void F25_229 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN tb6;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,loc5);
	RTLR(6,loc6);
	RTLR(7,loc7);
	RTLR(8,loc8);
	RTLIU(9);
	
	RTGC;
	tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_0_);
	tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_3_0_0_0_0_0_);
	tu8_2 = eif_bit_not(tu8_2);
	tu8_1 = eif_bit_or(tu8_1,tu8_2);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_0_) = (EIF_NATURAL_64) tu8_1;
	tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_1_);
	tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_3_0_0_0_0_1_);
	tu8_2 = eif_bit_not(tu8_2);
	tu8_1 = eif_bit_or(tu8_1,tu8_2);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_1_) = (EIF_NATURAL_64) tu8_1;
	tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_2_);
	tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_3_0_0_0_0_2_);
	tu8_2 = eif_bit_not(tu8_2);
	tu8_1 = eif_bit_or(tu8_1,tu8_2);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_2_) = (EIF_NATURAL_64) tu8_1;
	tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_3_);
	tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_3_0_0_0_0_3_);
	tu8_2 = eif_bit_not(tu8_2);
	tu8_1 = eif_bit_or(tu8_1,tu8_2);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_3_) = (EIF_NATURAL_64) tu8_1;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		{
			/* INLINED CODE (DS_CONTAINER.is_empty) */
			tb2 = (EIF_BOOLEAN)  0;
			(void) loc4;
			ti4_1 = *(EIF_INTEGER_32 *)(loc4+ _LNGOFF_11_0_0_8_);
			tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
			/* END INLINED CODE */
		}
		tb2 = tb2;
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		loc2 = *(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_);
		loc3 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_2_);
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc3;
		loc1 = *(EIF_REFERENCE *)(Current);
		if ((EIF_BOOLEAN)(loc1 == NULL)) {
			if ((EIF_BOOLEAN) !loc2) {
				loc1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc4);
				{
					/* INLINED CODE (DS_LINEAR.start) */
					(void) RTCW(loc1);
					tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_1_);
					F3036_34506(loc1, tr1);
					/* END INLINED CODE */
				}
				;
				for (;;) {
					{
						/* INLINED CODE (DS_LINEAR.after) */
						tb1 = (EIF_BOOLEAN)  0;
						(void) RTCW(loc1);
						tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_1_);
						tb1 = F3022_34213(loc1, tr1);
						/* END INLINED CODE */
					}
					tb1 = tb1;
					if (tb1) break;
					{
						/* INLINED CODE (DS_TRAVERSABLE.item_for_iteration) */
						tu8_1 = (EIF_NATURAL_64)  0;
						(void) RTCW(loc1);
						tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_1_);
						tu8_1 = F3036_34502(loc1, tr1);
						/* END INLINED CODE */
					}
					tu8_1 = tu8_1;
					tu8_1 = eif_bit_not(tu8_1);
					{
						/* INLINED CODE (DS_SPARSE_TABLE.key_for_iteration) */
						tu4_1 = (EIF_NATURAL_32)  0;
						(void) RTCW(loc1);
						tu4_1 = F3038_34561(loc1, *(EIF_REFERENCE *)(loc1 + _REFACS_1_));
						/* END INLINED CODE */
					}
					tu4_1 = tu4_1;
					{
						/* INLINED CODE (DS_SPARSE_TABLE.replace) */
						(void) RTCW(loc1);
						F3036_34445(loc1);
						F3036_34459(loc1, tu4_1);
						
						F3040_34564(loc1, tu8_1, *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_11_0_0_3_));
						/* END INLINED CODE */
					}
					;
					{
						/* INLINED CODE (DS_LINEAR.forth) */
						(void) RTCW(loc1);
						tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_1_);
						F3036_34508(loc1, tr1);
						/* END INLINED CODE */
					}
					;
				}
				RTAR(Current, loc1);
				*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
				*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) = (EIF_BOOLEAN) loc3;
			}
		} else {
			{
				/* INLINED CODE (DS_CONTAINER.is_empty) */
				tb2 = (EIF_BOOLEAN)  0;
				(void) RTCW(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_11_0_0_8_);
				tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
				/* END INLINED CODE */
			}
			tb2 = tb2;
			if (tb2) {
				if ((EIF_BOOLEAN) !loc2) {
					{
						/* INLINED CODE (DS_SPARSE_TABLE.copy) */
						(void) RTCW(loc1);
						if ((EIF_BOOLEAN)(loc4 != loc1)) {
							F3036_34446(loc1, loc4);
							*(EIF_REFERENCE *)(loc1 + _REFACS_2_) = (EIF_REFERENCE) NULL;
						}
						/* END INLINED CODE */
					}
					;
					{
						/* INLINED CODE (DS_LINEAR.start) */
						(void) RTCW(loc1);
						tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_1_);
						F3036_34506(loc1, tr1);
						/* END INLINED CODE */
					}
					;
					for (;;) {
						{
							/* INLINED CODE (DS_LINEAR.after) */
							tb2 = (EIF_BOOLEAN)  0;
							(void) RTCW(loc1);
							tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_1_);
							tb2 = F3022_34213(loc1, tr1);
							/* END INLINED CODE */
						}
						tb2 = tb2;
						if (tb2) break;
						{
							/* INLINED CODE (DS_TRAVERSABLE.item_for_iteration) */
							tu8_1 = (EIF_NATURAL_64)  0;
							(void) RTCW(loc1);
							tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_1_);
							tu8_1 = F3036_34502(loc1, tr1);
							/* END INLINED CODE */
						}
						tu8_1 = tu8_1;
						tu8_1 = eif_bit_not(tu8_1);
						{
							/* INLINED CODE (DS_SPARSE_TABLE.key_for_iteration) */
							tu4_1 = (EIF_NATURAL_32)  0;
							(void) RTCW(loc1);
							tu4_1 = F3038_34561(loc1, *(EIF_REFERENCE *)(loc1 + _REFACS_1_));
							/* END INLINED CODE */
						}
						tu4_1 = tu4_1;
						{
							/* INLINED CODE (DS_SPARSE_TABLE.replace) */
							(void) RTCW(loc1);
							F3036_34445(loc1);
							F3036_34459(loc1, tu4_1);
							
							F3040_34564(loc1, tu8_1, *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_11_0_0_3_));
							/* END INLINED CODE */
						}
						;
						{
							/* INLINED CODE (DS_LINEAR.forth) */
							(void) RTCW(loc1);
							tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_1_);
							F3036_34508(loc1, tr1);
							/* END INLINED CODE */
						}
						;
					}
					*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) = (EIF_BOOLEAN) loc3;
				}
			} else {
				if (loc3) {
					{
						/* INLINED CODE (DS_LINEAR.start) */
						(void) RTCW(loc1);
						tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_1_);
						F3036_34506(loc1, tr1);
						/* END INLINED CODE */
					}
					;
					for (;;) {
						{
							/* INLINED CODE (DS_LINEAR.after) */
							tb3 = (EIF_BOOLEAN)  0;
							(void) RTCW(loc1);
							tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_1_);
							tb3 = F3022_34213(loc1, tr1);
							/* END INLINED CODE */
						}
						tb3 = tb3;
						if (tb3) break;
						{
							/* INLINED CODE (DS_SPARSE_TABLE.key_for_iteration) */
							tu4_1 = (EIF_NATURAL_32)  0;
							(void) RTCW(loc1);
							tu4_1 = F3038_34561(loc1, *(EIF_REFERENCE *)(loc1 + _REFACS_1_));
							/* END INLINED CODE */
						}
						tu4_1 = tu4_1;
						{
							/* INLINED CODE (DS_SPARSE_TABLE.has) */
							tb4 = (EIF_BOOLEAN)  0;
							(void) loc4;
							F3036_34459(loc4, tu4_1);
							ti4_1 = *(EIF_INTEGER_32 *)(loc4+ _LNGOFF_11_0_0_3_);
							tb4 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) -1L));
							/* END INLINED CODE */
						}
						tb4 = tb4;
						if ((EIF_BOOLEAN) !tb4) {
							{
								/* INLINED CODE (DS_SPARSE_TABLE.key_for_iteration) */
								tu4_1 = (EIF_NATURAL_32)  0;
								(void) RTCW(loc1);
								tu4_1 = F3038_34561(loc1, *(EIF_REFERENCE *)(loc1 + _REFACS_1_));
								/* END INLINED CODE */
							}
							tu4_1 = tu4_1;
							{
								/* INLINED CODE (DS_SPARSE_CONTAINER.remove) */
								(void) RTCW(loc1);
								F3036_34445(loc1);
								F3036_34459(loc1, tu4_1);
								if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_11_0_0_3_) != ((EIF_INTEGER_32) -1L))) {
									F3036_34464(loc1, *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_11_0_0_3_));
								}
								/* END INLINED CODE */
							}
							;
						} else {
							{
								/* INLINED CODE (DS_LINEAR.forth) */
								(void) RTCW(loc1);
								tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_1_);
								F3036_34508(loc1, tr1);
								/* END INLINED CODE */
							}
							;
						}
					}
				}
				{
					/* INLINED CODE (DS_LINEAR.new_iterator) */
					tr1 = (EIF_REFERENCE)  0;
					(void) loc4;
					tr1 = F3042_34597(loc4);
					F2950_33632(RTCW(tr1));
					/* END INLINED CODE */
				}
				loc5 = tr1;
				for (;;) {
					{
						/* INLINED CODE (DS_SPARSE_CONTAINER_CURSOR.after) */
						tb4 = (EIF_BOOLEAN)  0;
						(void) loc5;
						ti4_1 = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_2_0_0_0_);
						tb4 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) -3L));
						/* END INLINED CODE */
					}
					tb4 = tb4;
					if (tb4) break;
					{
						/* INLINED CODE (DS_SPARSE_TABLE_CURSOR.key) */
						tu4_1 = (EIF_NATURAL_32)  0;
						(void) loc5;
						tr1 = *(EIF_REFERENCE *)(loc5 + _REFACS_1_);
						tu4_1 = F3038_34561(RTCW(tr1), loc5);
						/* END INLINED CODE */
					}
					tu4_1 = tu4_1;
					{
						/* INLINED CODE (DS_SPARSE_TABLE.search) */
						(void) RTCW(loc1);
						F3036_34459(loc1, tu4_1);
						*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_11_0_0_6_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_11_0_0_3_);
						/* END INLINED CODE */
					}
					;
					{
						/* INLINED CODE (DS_SPARSE_CONTAINER.found) */
						tb5 = (EIF_BOOLEAN)  0;
						(void) RTCW(loc1);
						ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_11_0_0_6_);
						tb5 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) -1L));
						/* END INLINED CODE */
					}
					tb5 = tb5;
					if (tb5) {
						{
							/* INLINED CODE (DS_SPARSE_CONTAINER.found_item) */
							tu8_1 = (EIF_NATURAL_64)  0;
							(void) RTCW(loc1);
							tu8_1 = F3040_34563(loc1, *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_11_0_0_6_));
							/* END INLINED CODE */
						}
						tu8_1 = tu8_1;
						{
							/* INLINED CODE (DS_CURSOR.item) */
							tu8_2 = (EIF_NATURAL_64)  0;
							(void) loc5;
							tr1 = *(EIF_REFERENCE *)(loc5 + _REFACS_1_);
							tu8_2 = F3036_34502(RTCW(tr1), loc5);
							/* END INLINED CODE */
						}
						tu8_2 = tu8_2;
						tu8_2 = eif_bit_not(tu8_2);
						tu8_1 = eif_bit_or(tu8_1,tu8_2);
						{
							/* INLINED CODE (DS_SPARSE_TABLE.replace_found_item) */
							(void) RTCW(loc1);
							F3040_34564(loc1, tu8_1, *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_11_0_0_6_));
							/* END INLINED CODE */
						}
						;
					} else {
						if ((EIF_BOOLEAN) !loc2) {
							{
								/* INLINED CODE (DS_CURSOR.item) */
								tu8_1 = (EIF_NATURAL_64)  0;
								(void) loc5;
								tr1 = *(EIF_REFERENCE *)(loc5 + _REFACS_1_);
								tu8_1 = F3036_34502(RTCW(tr1), loc5);
								/* END INLINED CODE */
							}
							tu8_1 = tu8_1;
							tu8_1 = eif_bit_not(tu8_1);
							{
								/* INLINED CODE (DS_SPARSE_TABLE_CURSOR.key) */
								tu4_1 = (EIF_NATURAL_32)  0;
								(void) loc5;
								tr1 = *(EIF_REFERENCE *)(loc5 + _REFACS_1_);
								tu4_1 = F3038_34561(RTCW(tr1), loc5);
								/* END INLINED CODE */
							}
							tu4_1 = tu4_1;
							F3038_34546(RTCW(loc1), tu8_1, tu4_1);
						}
					}
					{
						/* INLINED CODE (DS_LINEAR_CURSOR.forth) */
						(void) loc5;
						tr1 = *(EIF_REFERENCE *)(loc5 + _REFACS_1_);
						F3036_34508(RTCW(tr1), loc5);
						/* END INLINED CODE */
					}
					;
				}
				*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc2 || loc3);
			}
		}
	} else {
		tb5 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_2_);
		if ((EIF_BOOLEAN) !tb5) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			tr1 = *(EIF_REFERENCE *)(Current);
			loc6 = tr1;
			if (EIF_TEST(loc6)) {
				F3036_34449(loc6);
			}
		}
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_0_) != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L)) || (EIF_BOOLEAN)(*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_1_) != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L))) || (EIF_BOOLEAN)(*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_2_) != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L))) || (EIF_BOOLEAN)(*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_3_0_0_0_0_3_) != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L)))) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			tb5 = '\0';
			tr1 = *(EIF_REFERENCE *)(Current);
			loc7 = tr1;
			if (EIF_TEST(loc7)) {
				{
					/* INLINED CODE (DS_CONTAINER.is_empty) */
					tb6 = (EIF_BOOLEAN)  0;
					(void) loc7;
					ti4_1 = *(EIF_INTEGER_32 *)(loc7+ _LNGOFF_11_0_0_8_);
					tb6 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
					/* END INLINED CODE */
				}
				tb6 = tb6;
				tb5 = (EIF_BOOLEAN) !tb6;
			}
			if (tb5) {
				tb5 = '\01';
				if (!(EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_)) {
					ti4_1 = *(EIF_INTEGER_32 *)(loc7+ _LNGOFF_11_0_0_8_);
					tb5 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 17372L));
				}
				if (tb5) {
					{
						/* INLINED CODE (DS_LINEAR.new_iterator) */
						tr1 = (EIF_REFERENCE)  0;
						(void) loc7;
						tr1 = F3042_34597(loc7);
						F2950_33632(RTCW(tr1));
						/* END INLINED CODE */
					}
					loc8 = tr1;
					tb5 = EIF_TRUE;
					for (;;) {
						if (!tb5) break;
						{
							/* INLINED CODE (DS_SPARSE_CONTAINER_CURSOR.after) */
							tb6 = (EIF_BOOLEAN)  0;
							(void) loc8;
							ti4_1 = *(EIF_INTEGER_32 *)(loc8+ _LNGOFF_2_0_0_0_);
							tb6 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) -3L));
							/* END INLINED CODE */
						}
						tb6 = tb6;
						if (tb6) break;
						{
							/* INLINED CODE (DS_CURSOR.item) */
							tu8_1 = (EIF_NATURAL_64)  0;
							(void) loc8;
							tr1 = *(EIF_REFERENCE *)(loc8 + _REFACS_1_);
							tu8_1 = F3036_34502(RTCW(tr1), loc8);
							/* END INLINED CODE */
						}
						tu8_1 = tu8_1;
						tb5 = (EIF_BOOLEAN)(tu8_1 == (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L));
						{
							/* INLINED CODE (DS_LINEAR_CURSOR.forth) */
							(void) loc8;
							tr1 = *(EIF_REFERENCE *)(loc8 + _REFACS_1_);
							F3036_34508(RTCW(tr1), loc8);
							/* END INLINED CODE */
						}
						;
					}
					*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) tb5;
				} else {
					*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				}
			} else {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_);
			}
		}
	}
	RTLE;
}

/* {RX_CHARACTER_SET}.masks */
static EIF_REFERENCE F25_237_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_64 loc2 = (EIF_NATURAL_64) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (237);
#define Result RTOSR(237)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {1932,2064,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 64L),sizeof(EIF_NATURAL_64), EIF_TRUE);
	}
	F1933_18447(RTCW(tr1), (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 64L));
	Result = (EIF_REFERENCE) tr1;
	loc2 = (EIF_NATURAL_64) (EIF_NATURAL_64) ((EIF_INTEGER_32) 1L);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_64 *)RTCW(Result) + (((EIF_INTEGER_32) 0L))) = loc2;
	/* END INLINED CODE */
	;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 64L))) break;
		tu8_1 = eif_bit_shift_left(loc2,((EIF_INTEGER_32) 1L));
		loc2 = (EIF_NATURAL_64) tu8_1;
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_NATURAL_64 *)RTCW(Result) + (loc1)) = loc2;
		/* END INLINED CODE */
		;
		loc1++;
	}
	RTOSE (237);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F25_237 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(237,F25_237_body,(Current));
}

void EIF_Minit21 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
