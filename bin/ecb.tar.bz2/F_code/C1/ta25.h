
#ifndef _C1_ta25_
#define _C1_ta25_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F29_256(EIF_REFERENCE);
extern void F29_258(EIF_REFERENCE, EIF_INTEGER_32);
extern void F29_259(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit25(void);

#ifdef __cplusplus
}
#endif

#endif
