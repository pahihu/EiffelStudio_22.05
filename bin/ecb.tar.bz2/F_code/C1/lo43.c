/*
 * Code for class LOCAL_INFO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "lo43.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LOCAL_INFO}.make */
void F47_788 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_0_) = (EIF_INTEGER_32) arg2;
	RTLE;
}

/* {LOCAL_INFO}.is_used */
EIF_BOOLEAN F47_791 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu1_1 = *(EIF_NATURAL_8 *)(Current+ _CHROFF_2_0_);
	Result = eif_bit_test(EIF_NATURAL_8,tu1_1,((EIF_INTEGER_32) 0L));
	RTLE;
	return Result;
}

/* {LOCAL_INFO}.is_controlled */
EIF_BOOLEAN F47_792 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu1_1 = *(EIF_NATURAL_8 *)(Current+ _CHROFF_2_0_);
	Result = eif_bit_test(EIF_NATURAL_8,tu1_1,((EIF_INTEGER_32) 1L));
	RTLE;
	return Result;
}

/* {LOCAL_INFO}.is_cursor */
EIF_BOOLEAN F47_793 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu1_1 = *(EIF_NATURAL_8 *)(Current+ _CHROFF_2_0_);
	Result = eif_bit_test(EIF_NATURAL_8,tu1_1,((EIF_INTEGER_32) 2L));
	RTLE;
	return Result;
}

/* {LOCAL_INFO}.set_type */
void F47_795 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {LOCAL_INFO}.enable_is_used */
void F47_796 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu1_1 = *(EIF_NATURAL_8 *)(Current+ _CHROFF_2_0_);
	tu1_1 = eif_bit_or(tu1_1,((EIF_NATURAL_8) 1U));
	*(EIF_NATURAL_8 *)(Current+ _CHROFF_2_0_) = (EIF_NATURAL_8) tu1_1;
	RTLE;
}

/* {LOCAL_INFO}.set_is_controlled */
void F47_797 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_NATURAL_8 tu1_1;
	EIF_NATURAL_8 tu1_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (arg1) {
		tu1_1 = *(EIF_NATURAL_8 *)(Current+ _CHROFF_2_0_);
		tu1_1 = eif_bit_or(tu1_1,((EIF_NATURAL_8) 2U));
		*(EIF_NATURAL_8 *)(Current+ _CHROFF_2_0_) = (EIF_NATURAL_8) tu1_1;
	} else {
		tu1_1 = *(EIF_NATURAL_8 *)(Current+ _CHROFF_2_0_);
		tu1_2 = eif_bit_not(((EIF_NATURAL_8) 2U));
		tu1_1 = eif_bit_and(tu1_1,tu1_2);
		*(EIF_NATURAL_8 *)(Current+ _CHROFF_2_0_) = (EIF_NATURAL_8) tu1_1;
	}
	RTLE;
}

/* {LOCAL_INFO}.enable_is_controlled */
void F47_798 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu1_1 = *(EIF_NATURAL_8 *)(Current+ _CHROFF_2_0_);
	tu1_1 = eif_bit_or(tu1_1,((EIF_NATURAL_8) 2U));
	*(EIF_NATURAL_8 *)(Current+ _CHROFF_2_0_) = (EIF_NATURAL_8) tu1_1;
	RTLE;
}

/* {LOCAL_INFO}.enable_is_cursor */
void F47_799 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu1_1 = *(EIF_NATURAL_8 *)(Current+ _CHROFF_2_0_);
	tu1_1 = eif_bit_or(tu1_1,((EIF_NATURAL_8) 4U));
	*(EIF_NATURAL_8 *)(Current+ _CHROFF_2_0_) = (EIF_NATURAL_8) tu1_1;
	RTLE;
}

/* {LOCAL_INFO}.disable_is_cursor */
void F47_800 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_8 tu1_1;
	EIF_NATURAL_8 tu1_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu1_1 = *(EIF_NATURAL_8 *)(Current+ _CHROFF_2_0_);
	tu1_2 = eif_bit_not(((EIF_NATURAL_8) 4U));
	tu1_1 = eif_bit_and(tu1_1,tu1_2);
	*(EIF_NATURAL_8 *)(Current+ _CHROFF_2_0_) = (EIF_NATURAL_8) tu1_1;
	RTLE;
}

/* {LOCAL_INFO}.set_cursor */
void F47_801 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	{
		/* INLINED CODE (LOCAL_INFO.enable_is_cursor) */
		tu1_1 = *(EIF_NATURAL_8 *)(Current+ _CHROFF_2_0_);
		tu1_1 = eif_bit_or(tu1_1,((EIF_NATURAL_8) 4U));
		*(EIF_NATURAL_8 *)(Current+ _CHROFF_2_0_) = (EIF_NATURAL_8) tu1_1;
		/* END INLINED CODE */
	}
	;
	RTLE;
}

void EIF_Minit43 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
