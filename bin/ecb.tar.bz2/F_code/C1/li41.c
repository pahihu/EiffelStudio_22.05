/*
 * Code for class LIKE_CONTROLER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li41.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LIKE_CONTROLER}.make */
void F45_775 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {1590,2052,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1573_14912(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {1589,2055,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1567_14912(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {LIKE_CONTROLER}.has_argument */
EIF_BOOLEAN F45_776 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F1567_14924(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {LIKE_CONTROLER}.has_feature */
EIF_BOOLEAN F45_777 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_64 ti8_1;
	EIF_INTEGER_64 ti8_2;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O21155[Dtype(arg1)-2542]);
	ti8_1 = (EIF_INTEGER_64) ti4_1;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O21156[Dtype(arg1)-2542]);
	ti8_2 = (EIF_INTEGER_64) ti4_1;
	ti8_2 = eif_bit_shift_left((EIF_INTEGER_64) (((EIF_INTEGER_64) RTI64C(0)) + ti8_2),((EIF_INTEGER_32) 32L));
	Result = F1573_14924(RTCW(tr1), (EIF_INTEGER_64) (ti8_1 + ti8_2));
	RTLE;
	return Result;
}

/* {LIKE_CONTROLER}.put_feature */
void F45_778 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_64 ti8_1;
	EIF_INTEGER_64 ti8_2;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O21155[Dtype(arg1)-2542]);
	ti8_1 = (EIF_INTEGER_64) ti4_1;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O21156[Dtype(arg1)-2542]);
	ti8_2 = (EIF_INTEGER_64) ti4_1;
	ti8_2 = eif_bit_shift_left((EIF_INTEGER_64) (((EIF_INTEGER_64) RTI64C(0)) + ti8_2),((EIF_INTEGER_32) 32L));
	{
		/* INLINED CODE (ARRAYED_STACK.extend) */
		ti8_1 = (EIF_INTEGER_64) (ti8_1 + ti8_2);
		(void) RTCW(tr1);
		F1573_14953(tr1, ti8_1);
		F1573_14944(tr1);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {LIKE_CONTROLER}.put_argument */
void F45_779 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	{
		/* INLINED CODE (ARRAYED_STACK.extend) */
		(void) RTCW(tr1);
		F1567_14953(tr1, arg1);
		F1567_14944(tr1);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {LIKE_CONTROLER}.remove_feature */
void F45_780 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	{
		/* INLINED CODE (ARRAYED_STACK.remove) */
		(void) RTCW(tr1);
		F1573_14966(tr1);
		F1573_14944(tr1);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {LIKE_CONTROLER}.remove_argument */
void F45_781 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	{
		/* INLINED CODE (ARRAYED_STACK.remove) */
		(void) RTCW(tr1);
		F1567_14966(tr1);
		F1567_14944(tr1);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {LIKE_CONTROLER}.reset */
void F45_782 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	{
		/* INLINED CODE (ARRAYED_LIST.wipe_out) */
		(void) RTCW(tr1);
		tr2 = *(EIF_REFERENCE *)(tr1);
		F1936_18484(RTCW(tr2));
		*(EIF_INTEGER_32 *)(tr1+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		/* END INLINED CODE */
	}
	;
	tr1 = *(EIF_REFERENCE *)(Current);
	{
		/* INLINED CODE (ARRAYED_LIST.wipe_out) */
		(void) RTCW(tr1);
		tr2 = *(EIF_REFERENCE *)(tr1);
		F1930_18484(RTCW(tr2));
		*(EIF_INTEGER_32 *)(tr1+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

void EIF_Minit41 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
