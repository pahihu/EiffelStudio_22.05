
#ifndef _C1_as44_
#define _C1_as44_

#ifdef __cplusplus
extern "C" {
#endif

extern void F48_809(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F48_810(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F48_811(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F48_813(EIF_REFERENCE, EIF_INTEGER_32);
extern void F48_814(EIF_REFERENCE);
extern EIF_REFERENCE F48_815(EIF_REFERENCE);
RTOSHF (EIF_REFERENCE,817)
static EIF_REFERENCE F48_817_body(EIF_REFERENCE);
extern EIF_REFERENCE F48_817(EIF_REFERENCE);
extern void EIF_Minit44(void);
extern void F353_5055(EIF_REFERENCE, EIF_INTEGER_32);
extern void F352_5055(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R4927[])();
extern char *(*R4929[])();
extern char *(*R4932[])();
extern char *(*R4934[])();

#ifdef __cplusplus
}
#endif

#endif
