/*
 * Code for class REGISTER_MANAGER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "re45.h"
#include "eif_built_in.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {REGISTER_MANAGER}.make */
void F51_841 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(129, 0).id);
	F130_2375(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {REGISTER_MANAGER}.make_from_existing */
void F51_842 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_0_0_0_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

/* {REGISTER_MANAGER}.get_register */
EIF_INTEGER_32 F51_845 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	tr1 = *(EIF_REFERENCE *)(Current);
	{
		/* INLINED CODE (PACKED_BOOLEANS.count) */
		ti4_1 = (EIF_INTEGER_32)  0;
		(void) RTCW(tr1);
		tr2 = *(EIF_REFERENCE *)(tr1);
		ti4_2 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr2);
		ti4_1 = eif_bit_shift_left(ti4_2,((EIF_INTEGER_32) 5L));
		/* END INLINED CODE */
	}
	loc1 = ti4_1;
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (Result >= loc1)) {
			tr1 = *(EIF_REFERENCE *)(Current);
			{
				/* INLINED CODE (PACKED_BOOLEANS.item) */
				tb2 = (EIF_BOOLEAN)  0;
				(void) RTCW(tr1);
				tr2 = *(EIF_REFERENCE *)(tr1);
				ti4_1 = eif_bit_shift_right(Result,((EIF_INTEGER_32) 5L));
				ti4_1 = 
					/* INLINED CODE (SPECIAL.item) */
					*((EIF_INTEGER_32 *)RTCW(tr2) + (ti4_1))
					/* END INLINED CODE */;
				ti4_2 = eif_bit_and(Result,((EIF_INTEGER_32) 31L));
				tb2 = eif_bit_test(EIF_INTEGER_32,ti4_1,ti4_2);
				/* END INLINED CODE */
			}
			tb2 = tb2;
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) break;
		Result++;
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	F130_2386(RTCW(tr1), (EIF_BOOLEAN) 1, Result);
	if ((EIF_BOOLEAN) (Result > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_))) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_) = (EIF_INTEGER_32) Result;
	}
	RTLE;
	return Result;
}

/* {REGISTER_MANAGER}.duplicate */
EIF_REFERENCE F51_846 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(Dftype(Current));
	F51_842(RTCW(tr1), Current);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {REGISTER_MANAGER}.free_register */
void F51_848 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	F130_2383(RTCW(tr1), (EIF_BOOLEAN) 0, arg1);
	RTLE;
}

void EIF_Minit45 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
