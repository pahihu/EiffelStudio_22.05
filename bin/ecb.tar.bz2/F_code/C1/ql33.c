/*
 * Code for class QL_NAMES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ql33.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {QL_NAMES}.ql_cri_true */

EIF_REFERENCE F37_345 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (345,RTMS_EX_H("true",4,1953658213));
}

/* {QL_NAMES}.ql_cri_false */

EIF_REFERENCE F37_346 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (346,RTMS_EX_H("false",5,1635280741));
}

/* {QL_NAMES}.ql_cri_is_compiled */

EIF_REFERENCE F37_353 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (353,RTMS_EX_H("is_compiled",11,1057678180));
}

/* {QL_NAMES}.ql_cri_name_is */

EIF_REFERENCE F37_354 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (354,RTMS_EX_H("name_is",7,1422636403));
}

/* {QL_NAMES}.ql_cri_is_assembly */

EIF_REFERENCE F37_355 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (355,RTMS_EX_H("is_assembly",11,1001170809));
}

/* {QL_NAMES}.ql_cri_is_library */

EIF_REFERENCE F37_356 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (356,RTMS_EX_H("is_library",10,1619123065));
}

/* {QL_NAMES}.ql_cri_is_cluster */

EIF_REFERENCE F37_357 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (357,RTMS_EX_H("is_cluster",10,1408297586));
}

/* {QL_NAMES}.ql_cri_is_override */

EIF_REFERENCE F37_358 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (358,RTMS_EX_H("is_override",11,423783525));
}

/* {QL_NAMES}.ql_cri_is_valid */

EIF_REFERENCE F37_359 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (359,RTMS_EX_H("is_valid",8,1745811044));
}

/* {QL_NAMES}.ql_cri_is_used_in_library */

EIF_REFERENCE F37_360 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (360,RTMS_EX_H("is_used_in_library",18,272266361));
}

/* {QL_NAMES}.ql_cri_is_class_set */

EIF_REFERENCE F37_361 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (361,RTMS_EX_H("is_class_set",12,373897844));
}

/* {QL_NAMES}.ql_cri_has_invariant */

EIF_REFERENCE F37_362 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (362,RTMS_EX_H("has_immediate_invariant",23,1974740084));
}

/* {QL_NAMES}.ql_cri_ancestor_is */

EIF_REFERENCE F37_363 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (363,RTMS_EX_H("ancestor_is",11,932778867));
}

/* {QL_NAMES}.ql_cri_proper_ancestor_is */

EIF_REFERENCE F37_364 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (364,RTMS_EX_H("proper_ancestor_is",18,207427955));
}

/* {QL_NAMES}.ql_cri_parent_is */

EIF_REFERENCE F37_365 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (365,RTMS_EX_H("parent_is",9,1733890931));
}

/* {QL_NAMES}.ql_cri_indirect_parent_is */

EIF_REFERENCE F37_366 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (366,RTMS_EX_H("indirect_parent_is",18,1697651));
}

/* {QL_NAMES}.ql_cri_descendant_is */

EIF_REFERENCE F37_367 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (367,RTMS_EX_H("descendant_is",13,1495081331));
}

/* {QL_NAMES}.ql_cri_proper_descendant_is */

EIF_REFERENCE F37_368 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (368,RTMS_EX_H("proper_descendant_is",20,1510742387));
}

/* {QL_NAMES}.ql_cri_heir_is */

EIF_REFERENCE F37_369 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (369,RTMS_EX_H("heir_is",7,776154739));
}

/* {QL_NAMES}.ql_cri_indirect_heir_is */

EIF_REFERENCE F37_370 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (370,RTMS_EX_H("indirect_heir_is",16,1027130739));
}

/* {QL_NAMES}.ql_cri_client_is */

EIF_REFERENCE F37_371 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (371,RTMS_EX_H("client_is",9,734765427));
}

/* {QL_NAMES}.ql_cri_supplier_is */

EIF_REFERENCE F37_372 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (372,RTMS_EX_H("supplier_is",11,899011443));
}

/* {QL_NAMES}.ql_cri_is_deferred */

EIF_REFERENCE F37_373 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (373,RTMS_EX_H("is_deferred",11,457244516));
}

/* {QL_NAMES}.ql_cri_is_expanded */

EIF_REFERENCE F37_374 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (374,RTMS_EX_H("is_expanded",11,1382172516));
}

/* {QL_NAMES}.ql_cri_is_external */

EIF_REFERENCE F37_375 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (375,RTMS_EX_H("is_external",11,1457830764));
}

/* {QL_NAMES}.ql_cri_is_frozen */

EIF_REFERENCE F37_376 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (376,RTMS_EX_H("is_frozen",9,271946606));
}

/* {QL_NAMES}.ql_cri_is_generic */

EIF_REFERENCE F37_377 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (377,RTMS_EX_H("is_generic",10,1025256291));
}

/* {QL_NAMES}.ql_cri_is_obsolete */

EIF_REFERENCE F37_378 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (378,RTMS_EX_H("is_obsolete",11,1021433701));
}

/* {QL_NAMES}.ql_cri_is_precompiled */

EIF_REFERENCE F37_379 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (379,RTMS_EX_H("is_precompiled",14,1977735268));
}

/* {QL_NAMES}.ql_cri_has_top_indexing */

EIF_REFERENCE F37_380 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (380,RTMS_EX_H("has_top_indexing",16,52134247));
}

/* {QL_NAMES}.ql_cri_has_bottom_indexing */

EIF_REFERENCE F37_381 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (381,RTMS_EX_H("has_bottom_indexing",19,600720999));
}

/* {QL_NAMES}.ql_cri_has_indexing */

EIF_REFERENCE F37_382 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (382,RTMS_EX_H("has_indexing",12,75957351));
}

/* {QL_NAMES}.ql_cri_is_enum */

EIF_REFERENCE F37_383 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (383,RTMS_EX_H("is_enum",7,1089801837));
}

/* {QL_NAMES}.ql_cri_is_effective */

EIF_REFERENCE F37_384 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (384,RTMS_EX_H("is_effective",12,1183605349));
}

/* {QL_NAMES}.ql_cri_path_in */

EIF_REFERENCE F37_385 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (385,RTMS_EX_H("path_in",7,332174958));
}

/* {QL_NAMES}.ql_cri_path_is */

EIF_REFERENCE F37_386 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (386,RTMS_EX_H("path_is",7,332174963));
}

/* {QL_NAMES}.ql_cri_text_contain */

EIF_REFERENCE F37_387 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (387,RTMS_EX_H("text_is",7,407182707));
}

/* {QL_NAMES}.ql_cri_top_indexing_has_tag */

EIF_REFERENCE F37_388 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (388,RTMS_EX_H("top_indexing_has_tag",20,572315751));
}

/* {QL_NAMES}.ql_cri_bottom_indexing_has_tag */

EIF_REFERENCE F37_389 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (389,RTMS_EX_H("bottom_indexing_has_tag",23,1091914087));
}

/* {QL_NAMES}.ql_cri_indexing_has_tag */

EIF_REFERENCE F37_390 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (390,RTMS_EX_H("indexing_has_tag",16,1114383207));
}

/* {QL_NAMES}.ql_cri_top_indexing_contain */

EIF_REFERENCE F37_391 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (391,RTMS_EX_H("top_indexing_contain",20,581778286));
}

/* {QL_NAMES}.ql_cri_bottom_indexing_contain */

EIF_REFERENCE F37_392 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (392,RTMS_EX_H("bottom_indexing_contain",23,1101376622));
}

/* {QL_NAMES}.ql_cri_indexing_contain */

EIF_REFERENCE F37_393 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (393,RTMS_EX_H("indexing_contain",16,1123845742));
}

/* {QL_NAMES}.ql_cri_is_always_compiled */

EIF_REFERENCE F37_394 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (394,RTMS_EX_H("is_always_compiled",18,207638884));
}

/* {QL_NAMES}.ql_cri_is_partial */

EIF_REFERENCE F37_395 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (395,RTMS_EX_H("is_partial",10,1503377772));
}

/* {QL_NAMES}.ql_cri_is_read_only */

EIF_REFERENCE F37_396 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (396,RTMS_EX_H("is_read_only",12,1495485817));
}

/* {QL_NAMES}.ql_cri_is_overridden */

EIF_REFERENCE F37_397 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (397,RTMS_EX_H("is_overridden",13,1868177774));
}

/* {QL_NAMES}.ql_cri_is_overrider */

EIF_REFERENCE F37_398 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (398,RTMS_EX_H("is_overrider",12,1114592114));
}

/* {QL_NAMES}.ql_cri_is_visible */

EIF_REFERENCE F37_399 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (399,RTMS_EX_H("is_visible",10,59048037));
}

/* {QL_NAMES}.ql_cri_is_from_any */

EIF_REFERENCE F37_400 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (400,RTMS_EX_H("is_from_any",11,256257401));
}

/* {QL_NAMES}.ql_cri_has_argument */

EIF_REFERENCE F37_401 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (401,RTMS_EX_H("has_argument",12,1908589684));
}

/* {QL_NAMES}.ql_cri_has_assertion */

EIF_REFERENCE F37_402 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (402,RTMS_EX_H("has_assertion",13,938541934));
}

/* {QL_NAMES}.ql_cri_has_assigner */

EIF_REFERENCE F37_403 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (403,RTMS_EX_H("has_assigner",12,187851378));
}

/* {QL_NAMES}.ql_cri_has_comment */

EIF_REFERENCE F37_404 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (404,RTMS_EX_H("has_comment",11,1494252404));
}

/* {QL_NAMES}.ql_cri_has_local */

EIF_REFERENCE F37_405 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (405,RTMS_EX_H("has_local",9,1669910380));
}

/* {QL_NAMES}.ql_cri_has_postcondition */

EIF_REFERENCE F37_406 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (406,RTMS_EX_H("has_postcondition",17,844908910));
}

/* {QL_NAMES}.ql_cri_has_class_postcondition */

EIF_REFERENCE F37_407 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (407,RTMS_EX_H("has_class_postcondition",23,1017704046));
}

/* {QL_NAMES}.ql_cri_has_precondition */

EIF_REFERENCE F37_408 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (408,RTMS_EX_H("has_precondition",16,1016642414));
}

/* {QL_NAMES}.ql_cri_has_rescue */

EIF_REFERENCE F37_409 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (409,RTMS_EX_H("has_rescue",10,428864101));
}

/* {QL_NAMES}.ql_cri_is_attribute */

EIF_REFERENCE F37_410 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (410,RTMS_EX_H("is_attribute",12,1279293797));
}

/* {QL_NAMES}.ql_cri_is_constant */

EIF_REFERENCE F37_412 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (412,RTMS_EX_H("is_constant",11,1243498100));
}

/* {QL_NAMES}.ql_cri_is_function */

EIF_REFERENCE F37_413 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (413,RTMS_EX_H("is_function",11,2117010030));
}

/* {QL_NAMES}.ql_cri_is_immediate */

EIF_REFERENCE F37_414 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (414,RTMS_EX_H("is_immediate",12,464336997));
}

/* {QL_NAMES}.ql_cri_is_infix */

EIF_REFERENCE F37_416 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (416,RTMS_EX_H("is_infix",8,1963421816));
}

/* {QL_NAMES}.ql_cri_is_once */

EIF_REFERENCE F37_417 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (417,RTMS_EX_H("is_once",7,1257569381));
}

/* {QL_NAMES}.ql_cri_is_class */

EIF_REFERENCE F37_418 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (418,RTMS_EX_H("is_class",8,1929496179));
}

/* {QL_NAMES}.ql_cri_is_ghost */

EIF_REFERENCE F37_419 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (419,RTMS_EX_H("is_ghost",8,1863335540));
}

/* {QL_NAMES}.ql_cri_is_origin */

EIF_REFERENCE F37_420 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (420,RTMS_EX_H("is_origin",9,187733870));
}

/* {QL_NAMES}.ql_cri_is_prefix */

EIF_REFERENCE F37_421 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (421,RTMS_EX_H("is_prefix",9,122525560));
}

/* {QL_NAMES}.ql_cri_is_procedure */

EIF_REFERENCE F37_422 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (422,RTMS_EX_H("is_procedure",12,1798498405));
}

/* {QL_NAMES}.ql_cri_is_unique */

EIF_REFERENCE F37_423 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (423,RTMS_EX_H("is_unique",9,200158053));
}

/* {QL_NAMES}.ql_cri_is_feature */

EIF_REFERENCE F37_424 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (424,RTMS_EX_H("is_feature",10,773697125));
}

/* {QL_NAMES}.ql_cri_is_creator */

EIF_REFERENCE F37_426 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (426,RTMS_EX_H("is_creator",10,1117983858));
}

/* {QL_NAMES}.ql_cri_is_exported */

EIF_REFERENCE F37_427 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (427,RTMS_EX_H("is_exported",11,1450437476));
}

/* {QL_NAMES}.ql_cri_is_hidden */

EIF_REFERENCE F37_428 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (428,RTMS_EX_H("is_hidden",9,89818478));
}

/* {QL_NAMES}.ql_cri_implementors_of */

EIF_REFERENCE F37_429 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (429,RTMS_EX_H("is_implementors_of",18,1313350246));
}

/* {QL_NAMES}.ql_cri_is_exported_to */

EIF_REFERENCE F37_430 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (430,RTMS_EX_H("is_exported_to",14,100022639));
}

/* {QL_NAMES}.ql_cri_callee_is */

EIF_REFERENCE F37_431 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (431,RTMS_EX_H("callee_is",9,2004215667));
}

/* {QL_NAMES}.ql_cri_caller_is */

EIF_REFERENCE F37_432 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (432,RTMS_EX_H("caller_is",9,74839667));
}

/* {QL_NAMES}.ql_cri_assignee_is */

EIF_REFERENCE F37_433 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (433,RTMS_EX_H("assignee_is",11,238282355));
}

/* {QL_NAMES}.ql_cri_assigner_is */

EIF_REFERENCE F37_434 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (434,RTMS_EX_H("assigner_is",11,456386163));
}

/* {QL_NAMES}.ql_cri_createe_is */

EIF_REFERENCE F37_435 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (435,RTMS_EX_H("createe_is",10,1868079475));
}

/* {QL_NAMES}.ql_cri_creator_is */

EIF_REFERENCE F37_436 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (436,RTMS_EX_H("creator_is",10,2086260083));
}

/* {QL_NAMES}.ql_cri_is_invariant_feature */

EIF_REFERENCE F37_437 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (437,RTMS_EX_H("is_invariant_feature",20,1774650213));
}

/* {QL_NAMES}.ql_cri_is_query */

EIF_REFERENCE F37_438 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (438,RTMS_EX_H("is_query",8,2080860537));
}

/* {QL_NAMES}.ql_cri_is_command */

EIF_REFERENCE F37_439 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (439,RTMS_EX_H("is_command",10,1312228196));
}

/* {QL_NAMES}.ql_cri_return_type_is */

EIF_REFERENCE F37_440 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (440,RTMS_EX_H("return_type_is",14,810211699));
}

/* {QL_NAMES}.ql_cri_value_of_metric_is */

EIF_REFERENCE F37_456 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (456,RTMS_EX_H("value_of_metric_is",18,1740656243));
}

/* {QL_NAMES}.ql_cri_is_satisfied_by */

EIF_REFERENCE F37_458 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (458,RTMS_EX_H("is_satisfied_by",15,228658297));
}

void EIF_Minit33 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
