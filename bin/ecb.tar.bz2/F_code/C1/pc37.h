
#ifndef _C1_pc37_
#define _C1_pc37_

#ifdef __cplusplus
extern "C" {
#endif

extern void F41_725(EIF_REFERENCE);
extern void F41_726(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F41_728(EIF_REFERENCE, EIF_INTEGER_32);
extern void F41_729(EIF_REFERENCE, EIF_REFERENCE);
extern void F41_730(EIF_REFERENCE, EIF_INTEGER_32);
extern void F41_731(EIF_REFERENCE, EIF_REFERENCE);
extern void F41_732(EIF_REFERENCE, EIF_REFERENCE);
extern void F41_733(EIF_REFERENCE);
extern void EIF_Minit37(void);
extern void F1932_18447(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern char *(*R17091[])();

#ifdef __cplusplus
}
#endif

#endif
