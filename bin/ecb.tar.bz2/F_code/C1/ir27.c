/*
 * Code for class IRON_CLIENT_DB
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir27.h"
#include "eif_built_in.h"
#include "eif_file.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_CLIENT_DB}.make */
void F31_270 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {IRON_CLIENT_DB}.revision */
EIF_INTEGER_32 F31_272 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1437, 0x00).id, 1437, _OBJSIZ_4_6_2_4_1_1_2_1_);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = RTOSCF(13345,F969_13345, (RTCW(tr1)));
	F1437_14169(RTCW(loc1), tr1);
	tb1 = '\0';
	{
		/* INLINED CODE (FILE.exists) */
		tb2 = (EIF_BOOLEAN)  0;
		(void) RTCW(loc1);
		tb3 = F1437_14227(loc1);
		if (tb3) {
			tp1 = *(EIF_POINTER *)(RTCV(F1437_14329(loc1))+ _PTROFF_0_1_0_1_0_0_);
			tb2 = (EIF_BOOLEAN) EIF_TEST(eif_file_exists((EIF_FILENAME) tp1));
		} else {
			tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		/* END INLINED CODE */
	}
	tb2 = tb2;
	if (tb2) {
		{
			/* INLINED CODE (FILE.is_readable) */
			tb2 = (EIF_BOOLEAN)  0;
			(void) RTCW(loc1);
			F1437_14339(loc1);
			tb2 = F836_11798(RTCV(RTOSCF(14337,F1437_14337, (loc1))));
			/* END INLINED CODE */
		}
		tb2 = tb2;
		tb1 = tb2;
	}
	if (tb1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11969[Dtype(RTCW(loc1))-1437])(loc1);
		F1437_14316(RTCW(loc1));
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1) + O11174[Dtype(loc1)-920]);
		{
			/* INLINED CODE (READABLE_STRING_GENERAL.is_integer) */
			tb1 = (EIF_BOOLEAN)  0;
			(void) RTCW(loc2);
			tb1 = F2243_21838(loc2, ((EIF_INTEGER_32) 3L));
			/* END INLINED CODE */
		}
		tb1 = tb1;
		if (tb1) {
			{
				/* INLINED CODE (READABLE_STRING_GENERAL.to_integer) */
				tr1 = (EIF_REFERENCE)  0;
				ti4_1 = (EIF_INTEGER_32)  0;
				(void) RTCW(loc2);
				tr1 = RTOSCF(21841,F2243_21841, (loc2));
				F449_6553(RTCW(tr1), loc2, ((EIF_INTEGER_32) 0L));
				ti4_1 = F449_6558(RTCW(tr1));
				/* END INLINED CODE */
			}
			Result = ti4_1;
		} else {
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		}
		{
			/* INLINED CODE (FILE.close) */
			(void) RTCW(loc1);
			tp1 = *(EIF_POINTER *)(loc1 + O11932[Dtype(loc1)-1436]);
			eif_file_close((FILE*) tp1);
			*(EIF_INTEGER_32 *)(loc1 + O12071[Dtype(loc1)-1436]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			tp1 = F1_33(loc1);
			*(EIF_POINTER *)(loc1 + O11932[Dtype(loc1)-1436]) = (EIF_POINTER) tp1;
			*(EIF_BOOLEAN *)(loc1 + O12080[Dtype(loc1)-1436]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			/* END INLINED CODE */
		}
		;
	} else {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	}
	RTLE;
	return Result;
}

/* {IRON_CLIENT_DB}.repositories */
EIF_REFERENCE F31_273 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(333, 0x00).id, 333, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = RTOSCF(13344,F969_13344, (RTCW(tr1)));
	F334_4909(RTCW(loc1), tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {IRON_CLIENT_DB}.installed_packages */
EIF_REFERENCE F31_274 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(16);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLR(6,tr2);
	RTLR(7,loc6);
	RTLR(8,loc4);
	RTLR(9,loc7);
	RTLR(10,loc8);
	RTLR(11,loc9);
	RTLR(12,Result);
	RTLR(13,loc10);
	RTLR(14,tr3);
	RTLR(15,loc11);
	RTLIU(16);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {1565,1918,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc5 = RTLNSMART(typres0.id);
	}
	F1566_14912(RTCW(loc5), ((EIF_INTEGER_32) 0L));
	{
		/* INLINED CODE (CONTAINER.compare_objects) */
		(void) RTCW(loc5);
		*(EIF_BOOLEAN *)(loc5 + O11667[Dtype(loc5)-1138]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		/* END INLINED CODE */
	}
	;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = RTOSCF(13348,F969_13348, (RTCW(tr1)));
	{
		static EIF_TYPE_INDEX typarr0[] = {1565,2013,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc3 = RTLNS(typres0.id, 1565, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F1566_14912(RTCW(loc3), ((EIF_INTEGER_32) 10L));
	loc2 = RTLNS(eif_new_type(181, 0x00).id, 181, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F182_3000(RTCW(loc2), loc3);
	{
		/* INLINED CODE (PATH.absolute_path) */
		tr1 = (EIF_REFERENCE)  0;
		(void) RTCW(loc1);
		tr2 = F772_10708(RTCV(RTOSCF(19000,F2014_19000, (loc1))));
		tr1 = F2014_18971(loc1, tr2);
		/* END INLINED CODE */
	}
	tr1 = tr1;
	tr1 = F2014_18972(RTCW(tr1));
	F182_3004(RTCW(loc2), tr1);
	loc6 = F1566_14926(RTCW(loc3));
	for (;;) {
		{
			/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.after) */
			tb1 = (EIF_BOOLEAN)  0;
			(void) loc6;
			ti4_1 = *(EIF_INTEGER_32 *)(loc6+ _LNGOFF_2_0_0_0_);
			ti4_2 = *(EIF_INTEGER_32 *)(loc6+ _LNGOFF_2_0_0_1_);
			tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ti4_2);
			/* END INLINED CODE */
		}
		tb1 = tb1;
		if (tb1) break;
		loc4 = RTLNS(eif_new_type(21, 0x00).id, 21, _OBJSIZ_4_0_0_0_0_0_0_0_);
		tr1 = F1062_13661(loc6);
		F22_178(RTCW(loc4), tr1);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_3_);
		loc7 = tr1;
		if (EIF_TEST(loc7)) {
			F1566_14952(RTCW(loc5), loc7);
		} else {
			tb2 = '\0';
			{
				/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.item) */
				tr1 = (EIF_REFERENCE)  0;
				(void) loc6;
				tr2 = *(EIF_REFERENCE *)(loc6);
				tr1 = 
					/* INLINED CODE (SPECIAL.item) */
					*((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(loc6+ _LNGOFF_2_0_0_0_)))
					/* END INLINED CODE */;
				/* END INLINED CODE */
			}
			tr1 = tr1;
			tr1 = F31_281(Current, tr1);
			loc8 = tr1;
			if (EIF_TEST(loc8)) {
				{
					/* INLINED CODE (IRON_CLIENT_DB.repo_package_from_json_string) */
					tr1 = (EIF_REFERENCE)  0;
					tr2 = (EIF_REFERENCE)  0;
					tr1 = RTLNS(eif_new_type(334, 0x00).id, 334, _OBJSIZ_0_0_0_0_0_0_0_0_);
					tr2 = F335_4920(RTCW(tr1), loc8);
					/* END INLINED CODE */
				}
				tr1 = tr2;
				loc9 = tr1;
				tb2 = EIF_TEST(loc9);
			}
			if (tb2) {
				F1566_14952(RTCW(loc5), loc9);
			}
		}
		{
			/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.forth) */
			(void) loc6;
			(*(EIF_INTEGER_32 *)(loc6+ _LNGOFF_2_0_0_0_))++;
			/* END INLINED CODE */
		}
		;
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {1565,1918,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		Result = RTLNS(typres0.id, 1565, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	ti4_1 = F1566_14933(RTCW(loc5));
	F1566_14912(RTCW(Result), ti4_1);
	{
		/* INLINED CODE (CONTAINER.compare_objects) */
		(void) RTCW(Result);
		*(EIF_BOOLEAN *)(Result + O11667[Dtype(Result)-1138]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (IRON_CLIENT_DB.repositories) */
		tr1 = (EIF_REFERENCE)  0;
		tr2 = (EIF_REFERENCE)  0;
		tr1 = RTLNS(eif_new_type(333, 0x00).id, 333, _OBJSIZ_2_0_0_0_0_0_0_0_);
		tr3 = *(EIF_REFERENCE *)(Current);
		tr3 = RTOSCF(13344,F969_13344, (RTCW(tr3)));
		F334_4909(RTCW(tr1), tr3);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
		/* END INLINED CODE */
	}
	loc10 = F1566_14926(RTCV(tr2));
	for (;;) {
		{
			/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.after) */
			tb2 = (EIF_BOOLEAN)  0;
			(void) loc10;
			ti4_1 = *(EIF_INTEGER_32 *)(loc10+ _LNGOFF_2_0_0_0_);
			ti4_2 = *(EIF_INTEGER_32 *)(loc10+ _LNGOFF_2_0_0_1_);
			tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ti4_2);
			/* END INLINED CODE */
		}
		tb2 = tb2;
		if (tb2) break;
		{
			/* INLINED CODE (FINITE.is_empty) */
			tb3 = (EIF_BOOLEAN)  0;
			(void) RTCW(loc5);
			ti4_1 = F1566_14933(loc5);
			tb3 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
			/* END INLINED CODE */
		}
		tb3 = tb3;
		if (tb3) break;
		{
			/* INLINED CODE (ARRAYED_LIST.start) */
			(void) RTCW(loc5);
			*(EIF_INTEGER_32 *)(loc5 + O12312[Dtype(loc5)-1565]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			/* END INLINED CODE */
		}
		;
		for (;;) {
			{
				/* INLINED CODE (LIST.after) */
				tb4 = (EIF_BOOLEAN)  0;
				(void) RTCW(loc5);
				ti4_1 = *(EIF_INTEGER_32 *)(loc5 + O12312[Dtype(loc5)-1565]);
				ti4_2 = F1566_14933(loc5);
				tb4 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
				/* END INLINED CODE */
			}
			tb4 = tb4;
			if (tb4) break;
			{
				/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.item) */
				tr1 = (EIF_REFERENCE)  0;
				(void) loc10;
				tr2 = *(EIF_REFERENCE *)(loc10);
				tr1 = 
					/* INLINED CODE (SPECIAL.item) */
					*((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(loc10+ _LNGOFF_2_0_0_0_)))
					/* END INLINED CODE */;
				/* END INLINED CODE */
			}
			tr1 = tr1;
			{
				/* INLINED CODE (ARRAYED_LIST.item) */
				tr2 = (EIF_REFERENCE)  0;
				(void) RTCW(loc5);
				tr3 = *(EIF_REFERENCE *)(loc5);
				tr2 = 
					/* INLINED CODE (SPECIAL.item) */
					*((EIF_REFERENCE *)RTCW(tr3) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(loc5 + O12312[Dtype(loc5)-1565]) - ((EIF_INTEGER_32) 1L))))
					/* END INLINED CODE */;
				/* END INLINED CODE */
			}
			tr2 = tr2;
			tr2 = *(EIF_REFERENCE *)(RTCW(tr2));
			tb5 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11646[Dtype(RTCW(tr1))-1916])(tr1, tr2);
			if (tb5) {
				{
					/* INLINED CODE (ARRAYED_LIST.item) */
					tr1 = (EIF_REFERENCE)  0;
					(void) RTCW(loc5);
					tr2 = *(EIF_REFERENCE *)(loc5);
					tr1 = 
						/* INLINED CODE (SPECIAL.item) */
						*((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(loc5 + O12312[Dtype(loc5)-1565]) - ((EIF_INTEGER_32) 1L))))
						/* END INLINED CODE */;
					/* END INLINED CODE */
				}
				tr1 = tr1;
				F1566_14952(RTCW(Result), tr1);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R11817[Dtype(RTCW(loc5))-1415])(loc5);
			} else {
				{
					/* INLINED CODE (ARRAYED_LIST.forth) */
					(void) RTCW(loc5);
					(*(EIF_INTEGER_32 *)(loc5 + O12312[Dtype(loc5)-1565]))++;
					/* END INLINED CODE */
				}
				;
			}
		}
		{
			/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.forth) */
			(void) loc10;
			(*(EIF_INTEGER_32 *)(loc10+ _LNGOFF_2_0_0_0_))++;
			/* END INLINED CODE */
		}
		;
	}
	{
		/* INLINED CODE (FINITE.is_empty) */
		tb5 = (EIF_BOOLEAN)  0;
		(void) RTCW(loc5);
		ti4_1 = F1566_14933(loc5);
		tb5 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
		/* END INLINED CODE */
	}
	tb5 = tb5;
	if ((EIF_BOOLEAN) !tb5) {
		loc11 = F1566_14926(RTCW(loc5));
		for (;;) {
			{
				/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.after) */
				tb5 = (EIF_BOOLEAN)  0;
				(void) loc11;
				ti4_1 = *(EIF_INTEGER_32 *)(loc11+ _LNGOFF_2_0_0_0_);
				ti4_2 = *(EIF_INTEGER_32 *)(loc11+ _LNGOFF_2_0_0_1_);
				tb5 = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ti4_2);
				/* END INLINED CODE */
			}
			tb5 = tb5;
			if (tb5) break;
			{
				/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.item) */
				tr1 = (EIF_REFERENCE)  0;
				(void) loc11;
				tr2 = *(EIF_REFERENCE *)(loc11);
				tr1 = 
					/* INLINED CODE (SPECIAL.item) */
					*((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(loc11+ _LNGOFF_2_0_0_0_)))
					/* END INLINED CODE */;
				/* END INLINED CODE */
			}
			tr1 = tr1;
			F1566_14952(RTCW(Result), tr1);
			{
				/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.forth) */
				(void) loc11;
				(*(EIF_INTEGER_32 *)(loc11+ _LNGOFF_2_0_0_0_))++;
				/* END INLINED CODE */
			}
			;
		}
	}
	RTLE;
	return Result;
}

/* {IRON_CLIENT_DB}.quick_installed_package */
EIF_REFERENCE F31_275 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(17);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLR(6,tr2);
	RTLR(7,loc6);
	RTLR(8,loc7);
	RTLR(9,tr3);
	RTLR(10,arg1);
	RTLR(11,loc4);
	RTLR(12,loc8);
	RTLR(13,loc9);
	RTLR(14,loc10);
	RTLR(15,loc11);
	RTLR(16,Result);
	RTLIU(17);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {1565,1918,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc5 = RTLNS(typres0.id, 1565, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F1566_14912(RTCW(loc5), ((EIF_INTEGER_32) 0L));
	{
		/* INLINED CODE (CONTAINER.compare_objects) */
		(void) RTCW(loc5);
		*(EIF_BOOLEAN *)(loc5 + O11667[Dtype(loc5)-1138]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		/* END INLINED CODE */
	}
	;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = RTOSCF(13348,F969_13348, (RTCW(tr1)));
	{
		static EIF_TYPE_INDEX typarr0[] = {1565,2013,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc3 = RTLNS(typres0.id, 1565, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F1566_14912(RTCW(loc3), ((EIF_INTEGER_32) 10L));
	loc2 = RTLNS(eif_new_type(181, 0x00).id, 181, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F182_3000(RTCW(loc2), loc3);
	{
		/* INLINED CODE (PATH.absolute_path) */
		tr1 = (EIF_REFERENCE)  0;
		(void) RTCW(loc1);
		tr2 = F772_10708(RTCV(RTOSCF(19000,F2014_19000, (loc1))));
		tr1 = F2014_18971(loc1, tr2);
		/* END INLINED CODE */
	}
	tr1 = tr1;
	tr1 = F2014_18972(RTCW(tr1));
	F182_3004(RTCW(loc2), tr1);
	loc6 = F1566_14926(RTCW(loc3));
	for (;;) {
		{
			/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.after) */
			tb1 = (EIF_BOOLEAN)  0;
			(void) loc6;
			ti4_1 = *(EIF_INTEGER_32 *)(loc6+ _LNGOFF_2_0_0_0_);
			ti4_2 = *(EIF_INTEGER_32 *)(loc6+ _LNGOFF_2_0_0_1_);
			tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ti4_2);
			/* END INLINED CODE */
		}
		tb1 = tb1;
		if (tb1) break;
		tb2 = '\0';
		{
			/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.item) */
			tr1 = (EIF_REFERENCE)  0;
			(void) loc6;
			tr2 = *(EIF_REFERENCE *)(loc6);
			tr1 = 
				/* INLINED CODE (SPECIAL.item) */
				*((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(loc6+ _LNGOFF_2_0_0_0_)))
				/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		tr1 = tr1;
		tr1 = F31_281(Current, tr1);
		{
			/* INLINED CODE (IRON_CLIENT_DB.repo_package_identifier_from_json_string) */
			tr2 = (EIF_REFERENCE)  0;
			tr3 = (EIF_REFERENCE)  0;
			if ((EIF_BOOLEAN)(tr1 != NULL)) {
				tr2 = RTLNS(eif_new_type(334, 0x00).id, 334, _OBJSIZ_0_0_0_0_0_0_0_0_);
				tr3 = F335_4922(RTCW(tr2), tr1);
			}
			/* END INLINED CODE */
		}
		tr2 = tr3;
		loc7 = tr2;
		if (EIF_TEST(loc7)) {
			tb3 = F2243_21795(loc7, arg1);
			tb2 = tb3;
		}
		if (tb2) {
			loc4 = RTLNS(eif_new_type(21, 0x00).id, 21, _OBJSIZ_4_0_0_0_0_0_0_0_);
			tr1 = F1062_13661(loc6);
			F22_178(RTCW(loc4), tr1);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_3_);
			loc8 = tr1;
			if (EIF_TEST(loc8)) {
				F1566_14952(RTCW(loc5), loc8);
			} else {
				tb2 = '\0';
				{
					/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.item) */
					tr1 = (EIF_REFERENCE)  0;
					(void) loc6;
					tr2 = *(EIF_REFERENCE *)(loc6);
					tr1 = 
						/* INLINED CODE (SPECIAL.item) */
						*((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(loc6+ _LNGOFF_2_0_0_0_)))
						/* END INLINED CODE */;
					/* END INLINED CODE */
				}
				tr1 = tr1;
				tr1 = F31_281(Current, tr1);
				loc9 = tr1;
				if (EIF_TEST(loc9)) {
					{
						/* INLINED CODE (IRON_CLIENT_DB.repo_package_from_json_string) */
						tr1 = (EIF_REFERENCE)  0;
						tr2 = (EIF_REFERENCE)  0;
						tr1 = RTLNS(eif_new_type(334, 0x00).id, 334, _OBJSIZ_0_0_0_0_0_0_0_0_);
						tr2 = F335_4920(RTCW(tr1), loc9);
						/* END INLINED CODE */
					}
					tr1 = tr2;
					loc10 = tr1;
					tb2 = EIF_TEST(loc10);
				}
				if (tb2) {
					F1566_14952(RTCW(loc5), loc10);
				}
			}
		}
		{
			/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.forth) */
			(void) loc6;
			(*(EIF_INTEGER_32 *)(loc6+ _LNGOFF_2_0_0_0_))++;
			/* END INLINED CODE */
		}
		;
	}
	{
		/* INLINED CODE (IRON_CLIENT_DB.repositories) */
		tr1 = (EIF_REFERENCE)  0;
		tr2 = (EIF_REFERENCE)  0;
		tr1 = RTLNS(eif_new_type(333, 0x00).id, 333, _OBJSIZ_2_0_0_0_0_0_0_0_);
		tr3 = *(EIF_REFERENCE *)(Current);
		tr3 = RTOSCF(13344,F969_13344, (RTCW(tr3)));
		F334_4909(RTCW(tr1), tr3);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
		/* END INLINED CODE */
	}
	loc11 = F1566_14926(RTCV(tr2));
	for (;;) {
		{
			/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.after) */
			tb2 = (EIF_BOOLEAN)  0;
			(void) loc11;
			ti4_1 = *(EIF_INTEGER_32 *)(loc11+ _LNGOFF_2_0_0_0_);
			ti4_2 = *(EIF_INTEGER_32 *)(loc11+ _LNGOFF_2_0_0_1_);
			tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ti4_2);
			/* END INLINED CODE */
		}
		tb2 = tb2;
		if (tb2) break;
		tb3 = '\01';
		{
			/* INLINED CODE (FINITE.is_empty) */
			tb4 = (EIF_BOOLEAN)  0;
			(void) RTCW(loc5);
			ti4_1 = F1566_14933(loc5);
			tb4 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
			/* END INLINED CODE */
		}
		tb4 = tb4;
		if (!tb4) {
			tb3 = (EIF_BOOLEAN)(Result != NULL);
		}
		if (tb3) break;
		{
			/* INLINED CODE (ARRAYED_LIST.start) */
			(void) RTCW(loc5);
			*(EIF_INTEGER_32 *)(loc5 + O12312[Dtype(loc5)-1565]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			/* END INLINED CODE */
		}
		;
		for (;;) {
			tb4 = '\01';
			{
				/* INLINED CODE (LIST.after) */
				tb5 = (EIF_BOOLEAN)  0;
				(void) RTCW(loc5);
				ti4_1 = *(EIF_INTEGER_32 *)(loc5 + O12312[Dtype(loc5)-1565]);
				ti4_2 = F1566_14933(loc5);
				tb5 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
				/* END INLINED CODE */
			}
			tb5 = tb5;
			if (!tb5) {
				tb4 = (EIF_BOOLEAN)(Result != NULL);
			}
			if (tb4) break;
			{
				/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.item) */
				tr1 = (EIF_REFERENCE)  0;
				(void) loc11;
				tr2 = *(EIF_REFERENCE *)(loc11);
				tr1 = 
					/* INLINED CODE (SPECIAL.item) */
					*((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(loc11+ _LNGOFF_2_0_0_0_)))
					/* END INLINED CODE */;
				/* END INLINED CODE */
			}
			tr1 = tr1;
			{
				/* INLINED CODE (ARRAYED_LIST.item) */
				tr2 = (EIF_REFERENCE)  0;
				(void) RTCW(loc5);
				tr3 = *(EIF_REFERENCE *)(loc5);
				tr2 = 
					/* INLINED CODE (SPECIAL.item) */
					*((EIF_REFERENCE *)RTCW(tr3) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(loc5 + O12312[Dtype(loc5)-1565]) - ((EIF_INTEGER_32) 1L))))
					/* END INLINED CODE */;
				/* END INLINED CODE */
			}
			tr2 = tr2;
			tr2 = *(EIF_REFERENCE *)(RTCW(tr2));
			tb5 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11646[Dtype(RTCW(tr1))-1916])(tr1, tr2);
			if (tb5) {
				{
					/* INLINED CODE (ARRAYED_LIST.item) */
					tr1 = (EIF_REFERENCE)  0;
					(void) RTCW(loc5);
					tr2 = *(EIF_REFERENCE *)(loc5);
					tr1 = 
						/* INLINED CODE (SPECIAL.item) */
						*((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(loc5 + O12312[Dtype(loc5)-1565]) - ((EIF_INTEGER_32) 1L))))
						/* END INLINED CODE */;
					/* END INLINED CODE */
				}
				Result = tr1;
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R11817[Dtype(RTCW(loc5))-1415])(loc5);
			} else {
				{
					/* INLINED CODE (ARRAYED_LIST.forth) */
					(void) RTCW(loc5);
					(*(EIF_INTEGER_32 *)(loc5 + O12312[Dtype(loc5)-1565]))++;
					/* END INLINED CODE */
				}
				;
			}
		}
		{
			/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.forth) */
			(void) loc11;
			(*(EIF_INTEGER_32 *)(loc11+ _LNGOFF_2_0_0_0_))++;
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
	return Result;
}

/* {IRON_CLIENT_DB}.available_packages */
EIF_REFERENCE F31_276 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	struct eif_ex_131 sloc6;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) sloc6.data;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	memset (&sloc6.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc6.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc6.overhead, eif_new_type(163, 0x00).id);
	RTLI(19);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc7);
	RTLR(3,loc11);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,loc1);
	RTLR(8,tr4);
	RTLR(9,tr5);
	RTLR(10,loc3);
	RTLR(11,loc10);
	RTLR(12,loc4);
	RTLR(13,loc9);
	RTLR(14,loc5);
	RTLR(15,loc6);
	RTLR(16,loc12);
	RTLR(17,loc2);
	RTLR(18,loc8);
	RTLIU(19);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {1565,1918,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 1565, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F1566_14912(RTCW(Result), ((EIF_INTEGER_32) 0L));
	loc7 = RTLNS(eif_new_type(22, 0x00).id, 22, _OBJSIZ_0_0_0_0_0_0_0_0_);
	{
		/* INLINED CODE (IRON_CLIENT_DB.repositories) */
		tr1 = (EIF_REFERENCE)  0;
		tr2 = (EIF_REFERENCE)  0;
		tr1 = RTLNS(eif_new_type(333, 0x00).id, 333, _OBJSIZ_2_0_0_0_0_0_0_0_);
		tr3 = *(EIF_REFERENCE *)(Current);
		tr3 = RTOSCF(13344,F969_13344, (RTCW(tr3)));
		F334_4909(RTCW(tr1), tr3);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
		/* END INLINED CODE */
	}
	loc11 = F1566_14926(RTCV(tr2));
	for (;;) {
		{
			/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.after) */
			tb1 = (EIF_BOOLEAN)  0;
			(void) loc11;
			ti4_1 = *(EIF_INTEGER_32 *)(loc11+ _LNGOFF_2_0_0_0_);
			ti4_2 = *(EIF_INTEGER_32 *)(loc11+ _LNGOFF_2_0_0_1_);
			tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ti4_2);
			/* END INLINED CODE */
		}
		tb1 = tb1;
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.item) */
			tr2 = (EIF_REFERENCE)  0;
			(void) loc11;
			tr3 = *(EIF_REFERENCE *)(loc11);
			tr2 = 
				/* INLINED CODE (SPECIAL.item) */
				*((EIF_REFERENCE *)RTCW(tr3) + (*(EIF_INTEGER_32 *)(loc11+ _LNGOFF_2_0_0_0_)))
				/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		tr2 = tr2;
		{
			/* INLINED CODE (IRON_LAYOUT.repository_packages_data_index) */
			tr3 = (EIF_REFERENCE)  0;
			(void) RTCW(tr1);
			tr4 = F969_13351(tr1, tr2);
			tr5 = RTMS_EX_H("index",5,1852879736);
			tr3 = F2014_18981(RTCW(tr4), tr5);
			/* END INLINED CODE */
		}
		loc1 = tr3;
		loc3 = RTLNS(eif_new_type(1438, 0x00).id, 1438, _OBJSIZ_5_7_2_4_1_1_2_1_);
		F1439_14450(RTCW(loc3), loc1);
		tb2 = '\0';
		tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11190[Dtype(RTCW(loc3))-921])(loc3);
		if (tb3) {
			{
				/* INLINED CODE (FILE.is_access_readable) */
				tb3 = (EIF_BOOLEAN)  0;
				(void) RTCW(loc3);
				F1437_14339(loc3);
				tb3 = F836_11806(RTCV(RTOSCF(14337,F1437_14337, (loc3))));
				/* END INLINED CODE */
			}
			tb3 = tb3;
			tb2 = tb3;
		}
		if (tb2) {
			{
				/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.item) */
				tr1 = (EIF_REFERENCE)  0;
				(void) loc11;
				tr2 = *(EIF_REFERENCE *)(loc11);
				tr1 = 
					/* INLINED CODE (SPECIAL.item) */
					*((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(loc11+ _LNGOFF_2_0_0_0_)))
					/* END INLINED CODE */;
				/* END INLINED CODE */
			}
			tr1 = tr1;
			{
				/* INLINED CODE (IRON_REPOSITORY.location_string) */
				tr2 = (EIF_REFERENCE)  0;
				(void) RTCW(tr1);
				tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11641[Dtype(tr1)-1916])(tr1);
				tr2 = F3225_38249(RTCW(tr3));
				/* END INLINED CODE */
			}
			loc10 = tr2;
			{
				/* INLINED CODE (FILE.open_read) */
				(void) RTCW(loc3);
				tp1 = *(EIF_POINTER *)(RTCV(F1437_14329(loc3))+ _PTROFF_0_1_0_1_0_0_);
				tp1 = (EIF_POINTER) eif_file_open((EIF_FILENAME) tp1, (int) ((EIF_INTEGER_32) 0L));
				*(EIF_POINTER *)(loc3 + O11932[Dtype(loc3)-1436]) = (EIF_POINTER) tp1;
				*(EIF_INTEGER_32 *)(loc3 + O12071[Dtype(loc3)-1436]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				/* END INLINED CODE */
			}
			;
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R11251[Dtype(RTCW(loc3))-1437])(loc3);
			for (;;) {
				{
					/* INLINED CODE (LINEAR.exhausted) */
					tb2 = (EIF_BOOLEAN)  0;
					(void) RTCW(loc3);
					tb2 = F1437_14201(loc3);
					/* END INLINED CODE */
				}
				tb2 = tb2;
				if (tb2) break;
				loc4 = *(EIF_REFERENCE *)(RTCW(loc3));
				{
					/* INLINED CODE (FINITE.is_empty) */
					tb3 = (EIF_BOOLEAN)  0;
					(void) RTCW(loc4);
					ti4_1 = *(EIF_INTEGER_32 *)(loc4+ _LNGOFF_1_1_0_2_);
					tb3 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
					/* END INLINED CODE */
				}
				tb3 = tb3;
				if (tb3) {
				} else {
					tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R12119[Dtype(RTCW(loc4))-1471])(loc4, ((EIF_INTEGER_32) 1L)));
					tb3 = eif_builtin_CHARACTER_8_is_space__c1_b(tc1);
					if (tb3) {
						if ((EIF_BOOLEAN)(loc9 != NULL)) {
							(FUNCTION_CAST(void, (EIF_REFERENCE)) R17073[Dtype(RTCW(loc4))-2247])(loc4);
							tb3 = F2243_21800(RTCW(loc4), loc10);
							if (tb3) {
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc10) + O17115[Dtype(loc10)-2245]);
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R17077[Dtype(RTCW(loc4))-2247])(loc4, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
							} else {
							}
							tr1 = *(EIF_REFERENCE *)(RTCW(loc9) + _REFACS_5_);
							tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R17095[Dtype(RTCW(loc4))-2246])(loc4);
							F1566_14952(RTCW(tr1), tr2);
						}
					} else {
						loc9 = (EIF_REFERENCE) NULL;
						{
							/* INLINED CODE (UTF_CONVERTER.utf_8_string_8_to_string_32) */
							tr1 = (EIF_REFERENCE)  0;
							(void) RTCW(loc6);
							tr1 = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4) + O17115[Dtype(loc4)-2245]);
							F2250_22049(RTCW(tr1), ti4_1);
							F164_2794(loc6, loc4, tr1);
							/* END INLINED CODE */
						}
						loc5 = tr1;
						loc12 = F1566_14926(RTCW(Result));
						tb3 = EIF_FALSE;
						for (;;) {
							if (tb3) break;
							{
								/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.after) */
								tb4 = (EIF_BOOLEAN)  0;
								(void) loc12;
								ti4_1 = *(EIF_INTEGER_32 *)(loc12+ _LNGOFF_2_0_0_0_);
								ti4_2 = *(EIF_INTEGER_32 *)(loc12+ _LNGOFF_2_0_0_1_);
								tb4 = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ti4_2);
								/* END INLINED CODE */
							}
							tb4 = tb4;
							if (tb4) break;
							{
								/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.item) */
								tr1 = (EIF_REFERENCE)  0;
								(void) loc12;
								tr2 = *(EIF_REFERENCE *)(loc12);
								tr1 = 
									/* INLINED CODE (SPECIAL.item) */
									*((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(loc12+ _LNGOFF_2_0_0_0_)))
									/* END INLINED CODE */;
								/* END INLINED CODE */
							}
							tr1 = tr1;
							tb5 = F1919_18202(RTCW(tr1), loc5);
							tb3 = tb5;
							{
								/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.forth) */
								(void) loc12;
								(*(EIF_INTEGER_32 *)(loc12+ _LNGOFF_2_0_0_0_))++;
								/* END INLINED CODE */
							}
							;
						}
						if (tb3) {
						}
						tr1 = *(EIF_REFERENCE *)(Current);
						{
							/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.item) */
							tr2 = (EIF_REFERENCE)  0;
							(void) loc11;
							tr3 = *(EIF_REFERENCE *)(loc11);
							tr2 = 
								/* INLINED CODE (SPECIAL.item) */
								*((EIF_REFERENCE *)RTCW(tr3) + (*(EIF_INTEGER_32 *)(loc11+ _LNGOFF_2_0_0_0_)))
								/* END INLINED CODE */;
							/* END INLINED CODE */
						}
						tr2 = tr2;
						{
							/* INLINED CODE (IRON_LAYOUT.repository_packages_data_folder) */
							tr3 = (EIF_REFERENCE)  0;
							(void) RTCW(tr1);
							tr4 = F969_13349(tr1, tr2);
							tr5 = RTMS_EX_H("packages",8,1285097587);
							tr3 = F2014_18978(RTCW(tr4), tr5);
							/* END INLINED CODE */
						}
						tr1 = tr3;
						loc2 = F2014_18978(RTCW(tr1), loc5);
						loc8 = F23_190(RTCW(loc7), loc2);
						tb3 = '\0';
						tb4 = F336_4933(RTCW(loc8));
						if (tb4) {
							tb4 = *(EIF_BOOLEAN *)(RTCW(loc8) + O4843[Dtype(loc8)-335]);
							tb3 = (EIF_BOOLEAN) !tb4;
						}
						if (tb3) {
							{
								/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.item) */
								tr1 = (EIF_REFERENCE)  0;
								(void) loc11;
								tr2 = *(EIF_REFERENCE *)(loc11);
								tr1 = 
									/* INLINED CODE (SPECIAL.item) */
									*((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(loc11+ _LNGOFF_2_0_0_0_)))
									/* END INLINED CODE */;
								/* END INLINED CODE */
							}
							tr1 = tr1;
							loc9 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4852[Dtype(RTCW(loc8))-336])(loc8, tr1);
							F1566_14952(RTCW(Result), loc9);
						}
					}
				}
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R11251[Dtype(RTCW(loc3))-1437])(loc3);
			}
			{
				/* INLINED CODE (FILE.close) */
				(void) RTCW(loc3);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER)) R12014[Dtype(loc3)-1437])(loc3, *(EIF_POINTER *)(loc3 + O11932[Dtype(loc3)-1436]));
				*(EIF_INTEGER_32 *)(loc3 + O12071[Dtype(loc3)-1436]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				tp1 = F1_33(loc3);
				*(EIF_POINTER *)(loc3 + O11932[Dtype(loc3)-1436]) = (EIF_POINTER) tp1;
				*(EIF_BOOLEAN *)(loc3 + O12080[Dtype(loc3)-1436]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				/* END INLINED CODE */
			}
			;
		}
		{
			/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.forth) */
			(void) loc11;
			(*(EIF_INTEGER_32 *)(loc11+ _LNGOFF_2_0_0_0_))++;
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
	return Result;
}

/* {IRON_CLIENT_DB}.file_content */
EIF_REFERENCE F31_281 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1437, 0x00).id, 1437, _OBJSIZ_4_6_2_4_1_1_2_1_);
	F1437_14169(RTCW(loc1), arg1);
	tb1 = '\0';
	{
		/* INLINED CODE (FILE.exists) */
		tb2 = (EIF_BOOLEAN)  0;
		(void) RTCW(loc1);
		tb3 = F1437_14227(loc1);
		if (tb3) {
			tp1 = *(EIF_POINTER *)(RTCV(F1437_14329(loc1))+ _PTROFF_0_1_0_1_0_0_);
			tb2 = (EIF_BOOLEAN) EIF_TEST(eif_file_exists((EIF_FILENAME) tp1));
		} else {
			tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		/* END INLINED CODE */
	}
	tb2 = tb2;
	if (tb2) {
		{
			/* INLINED CODE (FILE.is_access_readable) */
			tb2 = (EIF_BOOLEAN)  0;
			(void) RTCW(loc1);
			F1437_14339(loc1);
			tb2 = F836_11806(RTCV(RTOSCF(14337,F1437_14337, (loc1))));
			/* END INLINED CODE */
		}
		tb2 = tb2;
		tb1 = tb2;
	}
	if (tb1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11969[Dtype(RTCW(loc1))-1437])(loc1);
		Result = RTLNS(eif_new_type(2247, 0x00).id, 2247, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F2246_21883(RTCW(Result), ((EIF_INTEGER_32) 1024L));
		for (;;) {
			{
				/* INLINED CODE (LINEAR.exhausted) */
				tb1 = (EIF_BOOLEAN)  0;
				(void) RTCW(loc1);
				tb1 = F1437_14201(loc1);
				/* END INLINED CODE */
			}
			tb1 = tb1;
			if (tb1) break;
			F1437_14317(RTCW(loc1), ((EIF_INTEGER_32) 1024L));
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O11174[Dtype(loc1)-920]);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17139[Dtype(RTCW(Result))-2247])(Result, tr1);
		}
		{
			/* INLINED CODE (FILE.close) */
			(void) RTCW(loc1);
			tp1 = *(EIF_POINTER *)(loc1 + O11932[Dtype(loc1)-1436]);
			eif_file_close((FILE*) tp1);
			*(EIF_INTEGER_32 *)(loc1 + O12071[Dtype(loc1)-1436]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			tp1 = F1_33(loc1);
			*(EIF_POINTER *)(loc1 + O11932[Dtype(loc1)-1436]) = (EIF_POINTER) tp1;
			*(EIF_BOOLEAN *)(loc1 + O12080[Dtype(loc1)-1436]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
	return Result;
}

/* {IRON_CLIENT_DB}.repo_package_from_json_string */
EIF_REFERENCE F31_282 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(334, 0x00).id, 334, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = F335_4920(RTCW(loc1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {IRON_CLIENT_DB}.repo_package_identifier_from_json_string */
EIF_REFERENCE F31_283 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		loc1 = RTLNS(eif_new_type(334, 0x00).id, 334, _OBJSIZ_0_0_0_0_0_0_0_0_);
		tr1 = F335_4922(RTCW(loc1), arg1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

void EIF_Minit27 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
