
#ifndef _C1_ca38_
#define _C1_ca38_

#ifdef __cplusplus
extern "C" {
#endif

extern void F42_735(EIF_REFERENCE);
extern void F42_736(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F42_737(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F42_739(EIF_REFERENCE, EIF_INTEGER_32);
extern void F42_740(EIF_REFERENCE);
extern void F42_741(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit38(void);
extern void F1930_18447(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern char *(*R12119[])();

#ifdef __cplusplus
}
#endif

#endif
