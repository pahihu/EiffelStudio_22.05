
#ifndef _C1_i18_
#define _C1_i18_

#ifdef __cplusplus
extern "C" {
#endif

extern void F10_107(EIF_REFERENCE, EIF_REFERENCE);
extern void F10_108(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit8(void);

#ifdef __cplusplus
}
#endif

#endif
