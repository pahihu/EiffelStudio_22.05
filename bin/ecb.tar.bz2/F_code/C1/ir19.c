/*
 * Code for class IRON_PACKAGE_FILE_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir19.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_PACKAGE_FILE_FACTORY}.new_package_file */
EIF_REFERENCE F23_190 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(337, 0x00).id, 337, _OBJSIZ_5_2_0_0_0_0_0_0_);
	F338_4966(RTCW(loc1), arg1);
	Result = (EIF_REFERENCE) loc1;
	tb1 = *(EIF_BOOLEAN *)(RTCW(Result) + O4843[Dtype(Result)-335]);
	if (tb1) {
		Result = RTLNS(eif_new_type(336, 0x00).id, 336, _OBJSIZ_4_2_0_0_0_0_0_0_);
		F337_4953(RTCW(Result), arg1);
		tb1 = *(EIF_BOOLEAN *)(RTCW(Result) + O4843[Dtype(Result)-335]);
		if (tb1) {
			RTLE;
			return (EIF_REFERENCE) loc1;
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit19 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
