
#ifndef _C1_ro32_
#define _C1_ro32_

#ifdef __cplusplus
extern "C" {
#endif

extern void F36_312(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F36_313(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F36_318(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN);
extern void F36_319(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit32(void);
extern void F557_7469(EIF_REFERENCE, EIF_BOOLEAN);
extern EIF_REFERENCE F795_11429(EIF_REFERENCE);
extern void F2517_26608(EIF_REFERENCE, EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,11429)
extern long O6989[];

#ifdef __cplusplus
}
#endif

#endif
