/*
 * Code for class IRON_PACKAGE_INSTALLATION_INFO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir18.h"
#include "eif_dir.h"
#include "eif_file.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_PACKAGE_INSTALLATION_INFO}.make_with_file */
void F22_178 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	F22_184(Current);
	RTLE;
}

/* {IRON_PACKAGE_INSTALLATION_INFO}.load */
void F22_184 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	struct eif_ex_281 sloc7;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) sloc7.data;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	memset (&sloc7.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc7.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc7.overhead, eif_new_type(325, 0x00).id);
	RTLI(22);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc10);
	RTLR(3,loc1);
	RTLR(4,loc11);
	RTLR(5,loc12);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,loc13);
	RTLR(9,loc2);
	RTLR(10,loc3);
	RTLR(11,loc14);
	RTLR(12,loc5);
	RTLR(13,loc15);
	RTLR(14,loc6);
	RTLR(15,loc16);
	RTLR(16,loc17);
	RTLR(17,loc8);
	RTLR(18,loc9);
	RTLR(19,loc7);
	RTLR(20,loc4);
	RTLR(21,loc18);
	RTLIU(22);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(2013, 0).id);
	F2014_18949(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	tr1 = F22_189(Current, *(EIF_REFERENCE *)(Current));
	loc10 = tr1;
	if (EIF_TEST(loc10)) {
		loc1 = RTLNS(eif_new_type(3204, 0x00).id, 3204, _OBJSIZ_9_2_0_3_0_0_0_0_);
		F3205_37615(RTCW(loc1), loc10);
		F3205_37635(RTCW(loc1));
		tb1 = '\0';
		{
			/* INLINED CODE (JSON_PARSER.is_valid) */
			tb2 = (EIF_BOOLEAN)  0;
			(void) RTCW(loc1);
			tb2 = *(EIF_BOOLEAN *)(loc1+ _CHROFF_9_1_);
			tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN) !tb2;
			/* END INLINED CODE */
		}
		tb2 = tb2;
		if (tb2) {
			tr1 = F3205_37631(RTCW(loc1));
			loc11 = tr1;
			tb1 = EIF_TEST(loc11);
		}
		if (tb1) {
			tb1 = '\0';
			tr1 = RTLNS(eif_new_type(2262, 0x00).id, 2262, _OBJSIZ_1_0_0_0_0_0_0_0_);
			tr2 = RTMS_EX_H("repository",10,818164089);
			F2263_22300(RTCW(tr1), tr2);
			{
				/* INLINED CODE (JSON_OBJECT.item) */
				tr2 = (EIF_REFERENCE)  0;
				(void) loc11;
				tr3 = *(EIF_REFERENCE *)(loc11);
				tr2 = F1626_15205(RTCW(tr3), tr1);
				/* END INLINED CODE */
			}
			tr1 = tr2;
			loc12 = tr1;
			loc12 = RTRV(eif_new_type(2264, 0x00),loc12);
			if (EIF_TEST(loc12)) {
				tr1 = RTLNS(eif_new_type(2262, 0x00).id, 2262, _OBJSIZ_1_0_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("uri",3,7697001);
				F2263_22300(RTCW(tr1), tr2);
				{
					/* INLINED CODE (JSON_OBJECT.item) */
					tr2 = (EIF_REFERENCE)  0;
					(void) loc12;
					tr3 = *(EIF_REFERENCE *)(loc12);
					tr2 = F1626_15205(RTCW(tr3), tr1);
					/* END INLINED CODE */
				}
				tr1 = tr2;
				loc13 = tr1;
				loc13 = RTRV(eif_new_type(2262, 0x00),loc13);
				tb1 = EIF_TEST(loc13);
			}
			if (tb1) {
				loc2 = RTLNS(eif_new_type(19, 0x00).id, 19, _OBJSIZ_0_0_0_0_0_0_0_0_);
				tr1 = *(EIF_REFERENCE *)(loc13);
				tr1 = F2243_21812(RTCW(tr1));
				loc3 = F20_159(RTCW(loc2), tr1);
			}
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11641[Dtype(RTCW(loc3))-1916])(loc3);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
				tr1 = RTLNS(eif_new_type(2262, 0x00).id, 2262, _OBJSIZ_1_0_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("package-id",10,287790948);
				F2263_22300(RTCW(tr1), tr2);
				{
					/* INLINED CODE (JSON_OBJECT.item) */
					tr2 = (EIF_REFERENCE)  0;
					(void) loc11;
					tr3 = *(EIF_REFERENCE *)(loc11);
					tr2 = F1626_15205(RTCW(tr3), tr1);
					/* END INLINED CODE */
				}
				tr1 = tr2;
				loc14 = tr1;
				loc14 = RTRV(eif_new_type(2262, 0x00),loc14);
				if (EIF_TEST(loc14)) {
					tr1 = *(EIF_REFERENCE *)(loc14);
					loc5 = F2243_21812(RTCW(tr1));
				}
				tr1 = RTLNS(eif_new_type(2262, 0x00).id, 2262, _OBJSIZ_1_0_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("package-name",12,1583611749);
				F2263_22300(RTCW(tr1), tr2);
				{
					/* INLINED CODE (JSON_OBJECT.item) */
					tr2 = (EIF_REFERENCE)  0;
					(void) loc11;
					tr3 = *(EIF_REFERENCE *)(loc11);
					tr2 = F1626_15205(RTCW(tr3), tr1);
					/* END INLINED CODE */
				}
				tr1 = tr2;
				loc15 = tr1;
				loc15 = RTRV(eif_new_type(2262, 0x00),loc15);
				if (EIF_TEST(loc15)) {
					tr1 = *(EIF_REFERENCE *)(loc15);
					loc6 = F2243_21812(RTCW(tr1));
				}
				tr1 = RTLNS(eif_new_type(2262, 0x00).id, 2262, _OBJSIZ_1_0_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("local-path",10,315937896);
				F2263_22300(RTCW(tr1), tr2);
				{
					/* INLINED CODE (JSON_OBJECT.item) */
					tr2 = (EIF_REFERENCE)  0;
					(void) loc11;
					tr3 = *(EIF_REFERENCE *)(loc11);
					tr2 = F1626_15205(RTCW(tr3), tr1);
					/* END INLINED CODE */
				}
				tr1 = tr2;
				loc16 = tr1;
				loc16 = RTRV(eif_new_type(2262, 0x00),loc16);
				if (EIF_TEST(loc16)) {
					loc17 = loc3;
					loc17 = RTRV(eif_new_type(1917, 0x00),loc17);
					if (EIF_TEST(loc17)) {
						tr1 = RTLNSMART(eif_new_type(2013, 0).id);
						tr2 = F2263_22313(loc16);
						F2014_18951(RTCW(tr1), tr2);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
						if ((EIF_BOOLEAN)(loc6 != NULL)) {
							loc8 = RTLNS(eif_new_type(22, 0x00).id, 22, _OBJSIZ_0_0_0_0_0_0_0_0_);
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							tr2 = RTMS_EX_H("package",7,382506597);
							tr1 = F2014_18978(RTCW(tr1), tr2);
							tr2 = RTMS_EX_H("iron",4,1769107310);
							loc9 = F2014_18981(RTCW(tr1), tr2);
							tb1 = F326_4838(RTCW(loc7), loc9);
							if ((EIF_BOOLEAN) !tb1) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								tr1 = F2014_18978(RTCW(tr1), loc6);
								tr2 = RTMS_EX_H("iron",4,1769107310);
								loc9 = F2014_18981(RTCW(tr1), tr2);
							}
							tb1 = F326_4838(RTCW(loc7), loc9);
							if ((EIF_BOOLEAN) !tb1) {
								loc9 = F22_187(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_));
							}
							tb1 = '\0';
							if ((EIF_BOOLEAN)(loc9 != NULL)) {
								tb2 = F326_4838(RTCW(loc7), loc9);
								tb1 = tb2;
							}
							if (tb1) {
								loc4 = F23_190(RTCW(loc8), loc9);
								tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4852[Dtype(RTCW(loc4))-336])(loc4, loc17);
								RTAR(Current, tr1);
								*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
							}
						}
					} else {
						tr1 = RTLNSMART(eif_new_type(2013, 0).id);
						tr2 = F2263_22313(loc16);
						F2014_18951(RTCW(tr1), tr2);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
						tr1 = RTLNS(eif_new_type(2262, 0x00).id, 2262, _OBJSIZ_1_0_0_0_0_0_0_0_);
						tr2 = RTMS_EX_H("package",7,382506597);
						F2263_22300(RTCW(tr1), tr2);
						{
							/* INLINED CODE (JSON_OBJECT.item) */
							tr2 = (EIF_REFERENCE)  0;
							(void) loc11;
							tr3 = *(EIF_REFERENCE *)(loc11);
							tr2 = F1626_15205(RTCW(tr3), tr1);
							/* END INLINED CODE */
						}
						tr1 = tr2;
						loc18 = tr1;
						loc18 = RTRV(eif_new_type(2264, 0x00),loc18);
						if (EIF_TEST(loc18)) {
							tr1 = F22_186(Current, loc18, loc3);
							RTAR(Current, tr1);
							*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
						}
					}
				} else {
					tr1 = RTLNSMART(eif_new_type(2013, 0).id);
					F2014_18949(RTCW(tr1));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
				}
			}
		}
	}
	RTLE;
}

/* {IRON_PACKAGE_INSTALLATION_INFO}.json_object_to_package */
EIF_REFERENCE F22_186 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(29);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,loc3);
	RTLR(6,arg2);
	RTLR(7,Result);
	RTLR(8,loc4);
	RTLR(9,loc5);
	RTLR(10,loc6);
	RTLR(11,loc1);
	RTLR(12,loc7);
	RTLR(13,loc8);
	RTLR(14,loc9);
	RTLR(15,loc10);
	RTLR(16,loc11);
	RTLR(17,loc12);
	RTLR(18,loc13);
	RTLR(19,loc14);
	RTLR(20,loc15);
	RTLR(21,loc16);
	RTLR(22,loc17);
	RTLR(23,loc18);
	RTLR(24,tr4);
	RTLR(25,tr5);
	RTLR(26,loc19);
	RTLR(27,loc20);
	RTLR(28,loc21);
	RTLIU(29);
	
	RTGC;
	tb1 = '\0';
	tr1 = RTLNS(eif_new_type(2262, 0x00).id, 2262, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("id",2,26980);
	F2263_22300(RTCW(tr1), tr2);
	{
		/* INLINED CODE (JSON_OBJECT.item) */
		tr2 = (EIF_REFERENCE)  0;
		(void) RTCW(arg1);
		tr3 = *(EIF_REFERENCE *)(arg1);
		tr2 = F1626_15205(RTCW(tr3), tr1);
		/* END INLINED CODE */
	}
	tr1 = tr2;
	loc2 = tr1;
	loc2 = RTRV(eif_new_type(2262, 0x00),loc2);
	if (EIF_TEST(loc2)) {
		tr1 = RTLNS(eif_new_type(2262, 0x00).id, 2262, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("name",4,1851878757);
		F2263_22300(RTCW(tr1), tr2);
		{
			/* INLINED CODE (JSON_OBJECT.item) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(arg1);
			tr3 = *(EIF_REFERENCE *)(arg1);
			tr2 = F1626_15205(RTCW(tr3), tr1);
			/* END INLINED CODE */
		}
		tr1 = tr2;
		loc3 = tr1;
		loc3 = RTRV(eif_new_type(2262, 0x00),loc3);
		tb1 = EIF_TEST(loc3);
	}
	if (tb1) {
		Result = RTLNS(eif_new_type(1918, 0x00).id, 1918, _OBJSIZ_10_0_0_2_0_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(loc2);
		F1919_18193(RTCW(Result), tr1, arg2);
		tr1 = F2265_22384(RTCW(arg1));
		tr1 = F2243_21812(RTCW(tr1));
		{
			/* INLINED CODE (IRON_PACKAGE.put_json_item) */
			(void) RTCW(Result);
			tr2 = RTMS_EX_H("_json",5,1786679662);
			F1919_18227(Result, tr1, tr2);
			/* END INLINED CODE */
		}
		;
		tr1 = *(EIF_REFERENCE *)(loc3);
		F1919_18228(RTCW(Result), tr1);
		tr1 = RTLNS(eif_new_type(2262, 0x00).id, 2262, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("title",5,1770128485);
		F2263_22300(RTCW(tr1), tr2);
		{
			/* INLINED CODE (JSON_OBJECT.item) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(arg1);
			tr3 = *(EIF_REFERENCE *)(arg1);
			tr2 = F1626_15205(RTCW(tr3), tr1);
			/* END INLINED CODE */
		}
		tr1 = tr2;
		loc4 = tr1;
		loc4 = RTRV(eif_new_type(2262, 0x00),loc4);
		if (EIF_TEST(loc4)) {
			{
				/* INLINED CODE (JSON_STRING.unescaped_string_32) */
				tr1 = (EIF_REFERENCE)  0;
				tr2 = (EIF_REFERENCE)  0;
				(void) loc4;
				tr1 = *(EIF_REFERENCE *)(loc4);
				tr2 = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O17115[Dtype(tr1)-2245]);
				F2250_22049(RTCW(tr2), ti4_1);
				F2263_22316(loc4, tr2);
				/* END INLINED CODE */
			}
			tr1 = tr2;
			F1919_18229(RTCW(Result), tr1);
		}
		tr1 = RTLNS(eif_new_type(2262, 0x00).id, 2262, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("description",11,801826414);
		F2263_22300(RTCW(tr1), tr2);
		{
			/* INLINED CODE (JSON_OBJECT.item) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(arg1);
			tr3 = *(EIF_REFERENCE *)(arg1);
			tr2 = F1626_15205(RTCW(tr3), tr1);
			/* END INLINED CODE */
		}
		tr1 = tr2;
		loc5 = tr1;
		loc5 = RTRV(eif_new_type(2262, 0x00),loc5);
		if (EIF_TEST(loc5)) {
			{
				/* INLINED CODE (JSON_STRING.unescaped_string_32) */
				tr1 = (EIF_REFERENCE)  0;
				tr2 = (EIF_REFERENCE)  0;
				(void) loc5;
				tr1 = *(EIF_REFERENCE *)(loc5);
				tr2 = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O17115[Dtype(tr1)-2245]);
				F2250_22049(RTCW(tr2), ti4_1);
				F2263_22316(loc5, tr2);
				/* END INLINED CODE */
			}
			tr1 = tr2;
			F1919_18230(RTCW(Result), tr1);
		}
		tr1 = RTLNS(eif_new_type(2262, 0x00).id, 2262, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("archive_revision",16,1455418222);
		F2263_22300(RTCW(tr1), tr2);
		{
			/* INLINED CODE (JSON_OBJECT.item) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(arg1);
			tr3 = *(EIF_REFERENCE *)(arg1);
			tr2 = F1626_15205(RTCW(tr3), tr1);
			/* END INLINED CODE */
		}
		tr1 = tr2;
		loc6 = tr1;
		loc6 = RTRV(eif_new_type(2263, 0x00),loc6);
		if (EIF_TEST(loc6)) {
			loc1 = *(EIF_REFERENCE *)(loc6);
			{
				/* INLINED CODE (READABLE_STRING_GENERAL.is_natural) */
				tb1 = (EIF_BOOLEAN)  0;
				(void) RTCW(loc1);
				tb1 = F2243_21838(loc1, ((EIF_INTEGER_32) 13L));
				/* END INLINED CODE */
			}
			tb1 = tb1;
			if (tb1) {
				{
					/* INLINED CODE (READABLE_STRING_GENERAL.to_natural) */
					tr1 = (EIF_REFERENCE)  0;
					tu4_1 = (EIF_NATURAL_32)  0;
					(void) RTCW(loc1);
					tr1 = RTOSCF(21841,F2243_21841, (loc1));
					F449_6553(RTCW(tr1), loc1, ((EIF_INTEGER_32) 0L));
					tu4_1 = F449_6562(RTCW(tr1));
					/* END INLINED CODE */
				}
				tu4_1 = tu4_1;
				{
					/* INLINED CODE (IRON_PACKAGE.set_archive_revision) */
					(void) RTCW(Result);
					*(EIF_NATURAL_32 *)(Result+ _LNGOFF_10_0_0_0_) = (EIF_NATURAL_32) tu4_1;
					/* END INLINED CODE */
				}
				;
			}
		}
		tr1 = RTLNS(eif_new_type(2262, 0x00).id, 2262, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("archive",7,1406298469);
		F2263_22300(RTCW(tr1), tr2);
		{
			/* INLINED CODE (JSON_OBJECT.item) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(arg1);
			tr3 = *(EIF_REFERENCE *)(arg1);
			tr2 = F1626_15205(RTCW(tr3), tr1);
			/* END INLINED CODE */
		}
		tr1 = tr2;
		loc7 = tr1;
		loc7 = RTRV(eif_new_type(2262, 0x00),loc7);
		if (EIF_TEST(loc7)) {
			tr1 = *(EIF_REFERENCE *)(loc7);
			F1919_18233(RTCW(Result), tr1);
		}
		tr1 = RTLNS(eif_new_type(2262, 0x00).id, 2262, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("archive_hash",12,1760719464);
		F2263_22300(RTCW(tr1), tr2);
		{
			/* INLINED CODE (JSON_OBJECT.item) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(arg1);
			tr3 = *(EIF_REFERENCE *)(arg1);
			tr2 = F1626_15205(RTCW(tr3), tr1);
			/* END INLINED CODE */
		}
		tr1 = tr2;
		loc8 = tr1;
		loc8 = RTRV(eif_new_type(2262, 0x00),loc8);
		if (EIF_TEST(loc8)) {
			tr1 = *(EIF_REFERENCE *)(loc8);
			F1919_18235(RTCW(Result), tr1);
		}
		tr1 = RTLNS(eif_new_type(2262, 0x00).id, 2262, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("archive_size",12,1945794917);
		F2263_22300(RTCW(tr1), tr2);
		{
			/* INLINED CODE (JSON_OBJECT.item) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(arg1);
			tr3 = *(EIF_REFERENCE *)(arg1);
			tr2 = F1626_15205(RTCW(tr3), tr1);
			/* END INLINED CODE */
		}
		tr1 = tr2;
		loc9 = tr1;
		loc9 = RTRV(eif_new_type(2263, 0x00),loc9);
		if (EIF_TEST(loc9)) {
			loc1 = *(EIF_REFERENCE *)(loc9);
			{
				/* INLINED CODE (READABLE_STRING_GENERAL.is_integer) */
				tb1 = (EIF_BOOLEAN)  0;
				(void) RTCW(loc1);
				tb1 = F2243_21838(loc1, ((EIF_INTEGER_32) 3L));
				/* END INLINED CODE */
			}
			tb1 = tb1;
			if (tb1) {
				{
					/* INLINED CODE (READABLE_STRING_GENERAL.to_integer) */
					tr1 = (EIF_REFERENCE)  0;
					ti4_1 = (EIF_INTEGER_32)  0;
					(void) RTCW(loc1);
					tr1 = RTOSCF(21841,F2243_21841, (loc1));
					F449_6553(RTCW(tr1), loc1, ((EIF_INTEGER_32) 0L));
					ti4_1 = F449_6558(RTCW(tr1));
					/* END INLINED CODE */
				}
				ti4_1 = ti4_1;
				{
					/* INLINED CODE (IRON_PACKAGE.set_archive_size) */
					(void) RTCW(Result);
					*(EIF_INTEGER_32 *)(Result+ _LNGOFF_10_0_0_1_) = (EIF_INTEGER_32) ti4_1;
					/* END INLINED CODE */
				}
				;
			}
		}
		tr1 = RTLNS(eif_new_type(2262, 0x00).id, 2262, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("paths",5,1635879027);
		F2263_22300(RTCW(tr1), tr2);
		{
			/* INLINED CODE (JSON_OBJECT.item) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(arg1);
			tr3 = *(EIF_REFERENCE *)(arg1);
			tr2 = F1626_15205(RTCW(tr3), tr1);
			/* END INLINED CODE */
		}
		tr1 = tr2;
		loc10 = tr1;
		loc10 = RTRV(eif_new_type(2261, 0x00),loc10);
		if (EIF_TEST(loc10)) {
			{
				/* INLINED CODE (JSON_ARRAY.array_representation) */
				tr1 = (EIF_REFERENCE)  0;
				(void) loc10;
				tr1 = *(EIF_REFERENCE *)(loc10);
				/* END INLINED CODE */
			}
			tr1 = tr1;
			loc11 = F1566_14926(RTCW(tr1));
			for (;;) {
				{
					/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.after) */
					tb1 = (EIF_BOOLEAN)  0;
					(void) loc11;
					ti4_1 = *(EIF_INTEGER_32 *)(loc11+ _LNGOFF_2_0_0_0_);
					ti4_2 = *(EIF_INTEGER_32 *)(loc11+ _LNGOFF_2_0_0_1_);
					tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ti4_2);
					/* END INLINED CODE */
				}
				tb1 = tb1;
				if (tb1) break;
				{
					/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.item) */
					tr1 = (EIF_REFERENCE)  0;
					(void) loc11;
					tr2 = *(EIF_REFERENCE *)(loc11);
					tr1 = 
						/* INLINED CODE (SPECIAL.item) */
						*((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(loc11+ _LNGOFF_2_0_0_0_)))
						/* END INLINED CODE */;
					/* END INLINED CODE */
				}
				tr1 = tr1;
				loc12 = tr1;
				loc12 = RTRV(eif_new_type(2262, 0x00),loc12);
				if (EIF_TEST(loc12)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_5_);
					tr2 = *(EIF_REFERENCE *)(loc12);
					F1566_14952(RTCW(tr1), tr2);
				}
				{
					/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.forth) */
					(void) loc11;
					(*(EIF_INTEGER_32 *)(loc11+ _LNGOFF_2_0_0_0_))++;
					/* END INLINED CODE */
				}
				;
			}
		}
		tr1 = RTLNS(eif_new_type(2262, 0x00).id, 2262, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("tags",4,1952540531);
		F2263_22300(RTCW(tr1), tr2);
		{
			/* INLINED CODE (JSON_OBJECT.item) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(arg1);
			tr3 = *(EIF_REFERENCE *)(arg1);
			tr2 = F1626_15205(RTCW(tr3), tr1);
			/* END INLINED CODE */
		}
		tr1 = tr2;
		loc13 = tr1;
		loc13 = RTRV(eif_new_type(2261, 0x00),loc13);
		if (EIF_TEST(loc13)) {
			{
				/* INLINED CODE (JSON_ARRAY.array_representation) */
				tr1 = (EIF_REFERENCE)  0;
				(void) loc13;
				tr1 = *(EIF_REFERENCE *)(loc13);
				/* END INLINED CODE */
			}
			tr1 = tr1;
			loc14 = F1566_14926(RTCW(tr1));
			for (;;) {
				{
					/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.after) */
					tb2 = (EIF_BOOLEAN)  0;
					(void) loc14;
					ti4_1 = *(EIF_INTEGER_32 *)(loc14+ _LNGOFF_2_0_0_0_);
					ti4_2 = *(EIF_INTEGER_32 *)(loc14+ _LNGOFF_2_0_0_1_);
					tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ti4_2);
					/* END INLINED CODE */
				}
				tb2 = tb2;
				if (tb2) break;
				{
					/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.item) */
					tr1 = (EIF_REFERENCE)  0;
					(void) loc14;
					tr2 = *(EIF_REFERENCE *)(loc14);
					tr1 = 
						/* INLINED CODE (SPECIAL.item) */
						*((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(loc14+ _LNGOFF_2_0_0_0_)))
						/* END INLINED CODE */;
					/* END INLINED CODE */
				}
				tr1 = tr1;
				loc15 = tr1;
				loc15 = RTRV(eif_new_type(2262, 0x00),loc15);
				if (EIF_TEST(loc15)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_6_);
					{
						/* INLINED CODE (JSON_STRING.unescaped_string_32) */
						tr2 = (EIF_REFERENCE)  0;
						tr3 = (EIF_REFERENCE)  0;
						(void) loc15;
						tr2 = *(EIF_REFERENCE *)(loc15);
						tr3 = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2) + O17115[Dtype(tr2)-2245]);
						F2250_22049(RTCW(tr3), ti4_1);
						F2263_22316(loc15, tr3);
						/* END INLINED CODE */
					}
					tr2 = tr3;
					F1566_14952(RTCW(tr1), tr2);
				}
				{
					/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.forth) */
					(void) loc14;
					(*(EIF_INTEGER_32 *)(loc14+ _LNGOFF_2_0_0_0_))++;
					/* END INLINED CODE */
				}
				;
			}
		}
		tr1 = RTLNS(eif_new_type(2262, 0x00).id, 2262, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("links",5,1769673587);
		F2263_22300(RTCW(tr1), tr2);
		{
			/* INLINED CODE (JSON_OBJECT.item) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(arg1);
			tr3 = *(EIF_REFERENCE *)(arg1);
			tr2 = F1626_15205(RTCW(tr3), tr1);
			/* END INLINED CODE */
		}
		tr1 = tr2;
		loc16 = tr1;
		loc16 = RTRV(eif_new_type(2264, 0x00),loc16);
		if (EIF_TEST(loc16)) {
			{
				/* INLINED CODE (JSON_OBJECT.new_cursor) */
				tr1 = (EIF_REFERENCE)  0;
				(void) loc16;
				tr2 = *(EIF_REFERENCE *)(loc16);
				tr1 = F1626_15214(RTCW(tr2));
				/* END INLINED CODE */
			}
			loc17 = tr1;
			for (;;) {
				tb3 = F1042_13646(loc17);
				if (tb3) break;
				{
					/* INLINED CODE (ITERATION_CURSOR.item) */
					tr1 = (EIF_REFERENCE)  0;
					(void) loc17;
					tr2 = *(EIF_REFERENCE *)(loc17);
					tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_1_);
					tr1 = 
						/* INLINED CODE (SPECIAL.item) */
						*((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(loc17+ _LNGOFF_1_1_0_4_)))
						/* END INLINED CODE */;
					/* END INLINED CODE */
				}
				tr1 = tr1;
				loc18 = tr1;
				loc18 = RTRV(eif_new_type(2262, 0x00),loc18);
				if (EIF_TEST(loc18)) {
					{
						/* INLINED CODE (JSON_STRING.unescaped_string_32) */
						tr1 = (EIF_REFERENCE)  0;
						tr2 = (EIF_REFERENCE)  0;
						(void) loc18;
						tr1 = *(EIF_REFERENCE *)(loc18);
						tr2 = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O17115[Dtype(tr1)-2245]);
						F2250_22049(RTCW(tr2), ti4_1);
						F2263_22316(loc18, tr2);
						/* END INLINED CODE */
					}
					tr1 = tr2;
					tr2 = RTMS32_EX_H("l\000\000\000i\000\000\000n\000\000\000k\000\000\000[\000\000\000",5,1769673563);
					{
						/* INLINED CODE (TABLE_ITERATION_CURSOR.key) */
						tr3 = (EIF_REFERENCE)  0;
						(void) loc17;
						tr4 = *(EIF_REFERENCE *)(loc17);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + _REFACS_2_);
						tr3 = 
							/* INLINED CODE (SPECIAL.item) */
							*((EIF_REFERENCE *)RTCW(tr4) + (*(EIF_INTEGER_32 *)(loc17+ _LNGOFF_1_1_0_4_)))
							/* END INLINED CODE */;
						/* END INLINED CODE */
					}
					tr3 = tr3;
					{
						/* INLINED CODE (JSON_STRING.unescaped_string_32) */
						tr4 = (EIF_REFERENCE)  0;
						tr5 = (EIF_REFERENCE)  0;
						(void) RTCW(tr3);
						tr4 = *(EIF_REFERENCE *)(tr3);
						tr5 = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr4) + O17115[Dtype(tr4)-2245]);
						F2250_22049(RTCW(tr5), ti4_1);
						F2263_22316(tr3, tr5);
						/* END INLINED CODE */
					}
					tr3 = tr5;
					{
						/* INLINED CODE (STRING_32.plus) */
						tr4 = (EIF_REFERENCE)  0;
						tr5 = tr2;
						(void) RTCW(tr5);
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr3) + O17190[Dtype(tr3)-2249]);
						tr4 = F2252_22214(tr5, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(tr5+ _LNGOFF_1_1_0_2_) + ti4_1));
						F2252_22164(RTCW(tr4), tr5);
						F2252_22164(RTCW(tr4), tr3);
						/* END INLINED CODE */
					}
					tr2 = tr4;
					tr3 = F2243_21812(RTMS_EX_H("]",1,93));
					{
						/* INLINED CODE (STRING_32.plus) */
						tr4 = (EIF_REFERENCE)  0;
						(void) RTCW(tr2);
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr3) + O17190[Dtype(tr3)-2249]);
						tr4 = F2252_22214(tr2, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(tr2+ _LNGOFF_1_1_0_2_) + ti4_1));
						F2252_22164(RTCW(tr4), tr2);
						F2252_22164(RTCW(tr4), tr3);
						/* END INLINED CODE */
					}
					tr2 = tr4;
					F1919_18227(RTCW(Result), tr1, tr2);
				}
				F1042_13647(loc17);
			}
		}
		tr1 = RTLNS(eif_new_type(2262, 0x00).id, 2262, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("notes",5,1870743923);
		F2263_22300(RTCW(tr1), tr2);
		{
			/* INLINED CODE (JSON_OBJECT.item) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(arg1);
			tr3 = *(EIF_REFERENCE *)(arg1);
			tr2 = F1626_15205(RTCW(tr3), tr1);
			/* END INLINED CODE */
		}
		tr1 = tr2;
		loc19 = tr1;
		loc19 = RTRV(eif_new_type(2264, 0x00),loc19);
		if (EIF_TEST(loc19)) {
			{
				/* INLINED CODE (JSON_OBJECT.new_cursor) */
				tr1 = (EIF_REFERENCE)  0;
				(void) loc19;
				tr2 = *(EIF_REFERENCE *)(loc19);
				tr1 = F1626_15214(RTCW(tr2));
				/* END INLINED CODE */
			}
			loc20 = tr1;
			for (;;) {
				tb4 = F1042_13646(loc20);
				if (tb4) break;
				{
					/* INLINED CODE (ITERATION_CURSOR.item) */
					tr1 = (EIF_REFERENCE)  0;
					(void) loc20;
					tr2 = *(EIF_REFERENCE *)(loc20);
					tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_1_);
					tr1 = 
						/* INLINED CODE (SPECIAL.item) */
						*((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(loc20+ _LNGOFF_1_1_0_4_)))
						/* END INLINED CODE */;
					/* END INLINED CODE */
				}
				tr1 = tr1;
				loc21 = tr1;
				loc21 = RTRV(eif_new_type(2262, 0x00),loc21);
				if (EIF_TEST(loc21)) {
					{
						/* INLINED CODE (JSON_STRING.unescaped_string_32) */
						tr1 = (EIF_REFERENCE)  0;
						tr2 = (EIF_REFERENCE)  0;
						(void) loc21;
						tr1 = *(EIF_REFERENCE *)(loc21);
						tr2 = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O17115[Dtype(tr1)-2245]);
						F2250_22049(RTCW(tr2), ti4_1);
						F2263_22316(loc21, tr2);
						/* END INLINED CODE */
					}
					tr1 = tr2;
					{
						/* INLINED CODE (TABLE_ITERATION_CURSOR.key) */
						tr2 = (EIF_REFERENCE)  0;
						(void) loc20;
						tr3 = *(EIF_REFERENCE *)(loc20);
						tr3 = *(EIF_REFERENCE *)(RTCW(tr3) + _REFACS_2_);
						tr2 = 
							/* INLINED CODE (SPECIAL.item) */
							*((EIF_REFERENCE *)RTCW(tr3) + (*(EIF_INTEGER_32 *)(loc20+ _LNGOFF_1_1_0_4_)))
							/* END INLINED CODE */;
						/* END INLINED CODE */
					}
					tr2 = tr2;
					{
						/* INLINED CODE (JSON_STRING.unescaped_string_32) */
						tr3 = (EIF_REFERENCE)  0;
						tr4 = (EIF_REFERENCE)  0;
						(void) RTCW(tr2);
						tr3 = *(EIF_REFERENCE *)(tr2);
						tr4 = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr3) + O17115[Dtype(tr3)-2245]);
						F2250_22049(RTCW(tr4), ti4_1);
						F2263_22316(tr2, tr4);
						/* END INLINED CODE */
					}
					tr2 = tr4;
					F1919_18227(RTCW(Result), tr1, tr2);
				}
				F1042_13647(loc20);
			}
		}
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INSTALLATION_INFO}.first_iron_file_path_from */
EIF_REFERENCE F22_187 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc3);
	RTLR(6,Result);
	RTLIU(7);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(783, 0x00).id, 783, _OBJSIZ_3_0_0_1_0_2_0_0_);
	F784_10987(RTCW(loc1), arg1);
	{
		/* INLINED CODE (DIRECTORY.exists) */
		tb1 = (EIF_BOOLEAN)  0;
		(void) RTCW(loc1);
		tp1 = *(EIF_POINTER *)(RTCV(F784_11024(loc1))+ _PTROFF_0_1_0_1_0_0_);
		tb1 = (EIF_BOOLEAN) EIF_TEST(eif_dir_exists((EIF_FILENAME) tp1));
		/* END INLINED CODE */
	}
	tb1 = tb1;
	if (tb1) {
		tr1 = F784_11001(RTCW(loc1));
		tr1 = F1566_14926(RTCW(tr1));
		loc2 = (EIF_REFERENCE) tr1;
		for (;;) {
			{
				/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.after) */
				tb1 = (EIF_BOOLEAN)  0;
				(void) loc2;
				ti4_1 = *(EIF_INTEGER_32 *)(loc2+ _LNGOFF_2_0_0_0_);
				ti4_2 = *(EIF_INTEGER_32 *)(loc2+ _LNGOFF_2_0_0_1_);
				tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ti4_2);
				/* END INLINED CODE */
			}
			tb1 = tb1;
			if (tb1) break;
			if ((EIF_BOOLEAN)(Result != NULL)) break;
			tb2 = '\01';
			{
				/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.item) */
				tr1 = (EIF_REFERENCE)  0;
				(void) loc2;
				tr2 = *(EIF_REFERENCE *)(loc2);
				tr1 = 
					/* INLINED CODE (SPECIAL.item) */
					*((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(loc2+ _LNGOFF_2_0_0_0_)))
					/* END INLINED CODE */;
				/* END INLINED CODE */
			}
			tr1 = tr1;
			{
				/* INLINED CODE (PATH.is_current_symbol) */
				tb3 = (EIF_BOOLEAN)  0;
				(void) RTCW(tr1);
				tr2 = *(EIF_REFERENCE *)(tr1);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_1_1_0_2_);
				ti4_2 = F2014_18995(tr1);
				if ((EIF_BOOLEAN)(ti4_1 == ti4_2)) {
					tb3 = F2014_19007(tr1, *(EIF_REFERENCE *)(tr1), ((EIF_INTEGER_32) 1L), (EIF_CHARACTER_8) '.');
				}
				/* END INLINED CODE */
			}
			tb3 = tb3;
			if (!tb3) {
				{
					/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.item) */
					tr1 = (EIF_REFERENCE)  0;
					(void) loc2;
					tr2 = *(EIF_REFERENCE *)(loc2);
					tr1 = 
						/* INLINED CODE (SPECIAL.item) */
						*((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(loc2+ _LNGOFF_2_0_0_0_)))
						/* END INLINED CODE */;
					/* END INLINED CODE */
				}
				tr1 = tr1;
				tb3 = F2014_18957(RTCW(tr1));
				tb2 = tb3;
			}
			if (tb2) {
			} else {
				tb2 = '\0';
				{
					/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.item) */
					tr1 = (EIF_REFERENCE)  0;
					(void) loc2;
					tr2 = *(EIF_REFERENCE *)(loc2);
					tr1 = 
						/* INLINED CODE (SPECIAL.item) */
						*((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(loc2+ _LNGOFF_2_0_0_0_)))
						/* END INLINED CODE */;
					/* END INLINED CODE */
				}
				tr1 = tr1;
				tr1 = F2014_18968(RTCW(tr1));
				loc3 = tr1;
				if (EIF_TEST(loc3)) {
					tr1 = RTMS_EX_H("iron",4,1769107310);
					tb3 = F2243_21795(loc3, tr1);
					tb2 = tb3;
				}
				if (tb2) {
					{
						/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.item) */
						tr1 = (EIF_REFERENCE)  0;
						(void) loc2;
						tr2 = *(EIF_REFERENCE *)(loc2);
						tr1 = 
							/* INLINED CODE (SPECIAL.item) */
							*((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(loc2+ _LNGOFF_2_0_0_0_)))
							/* END INLINED CODE */;
						/* END INLINED CODE */
					}
					tr1 = tr1;
					Result = F2014_18979(RTCW(arg1), tr1);
				}
			}
			{
				/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.forth) */
				(void) loc2;
				(*(EIF_INTEGER_32 *)(loc2+ _LNGOFF_2_0_0_0_))++;
				/* END INLINED CODE */
			}
			;
		}
	}
	RTLE;
	return Result;
}

/* {IRON_PACKAGE_INSTALLATION_INFO}.file_content */
EIF_REFERENCE F22_189 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1437, 0x00).id, 1437, _OBJSIZ_4_6_2_4_1_1_2_1_);
	F1437_14169(RTCW(loc1), arg1);
	tb1 = '\0';
	{
		/* INLINED CODE (FILE.exists) */
		tb2 = (EIF_BOOLEAN)  0;
		(void) RTCW(loc1);
		tb3 = F1437_14227(loc1);
		if (tb3) {
			tp1 = *(EIF_POINTER *)(RTCV(F1437_14329(loc1))+ _PTROFF_0_1_0_1_0_0_);
			tb2 = (EIF_BOOLEAN) EIF_TEST(eif_file_exists((EIF_FILENAME) tp1));
		} else {
			tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		/* END INLINED CODE */
	}
	tb2 = tb2;
	if (tb2) {
		{
			/* INLINED CODE (FILE.is_access_readable) */
			tb2 = (EIF_BOOLEAN)  0;
			(void) RTCW(loc1);
			F1437_14339(loc1);
			tb2 = F836_11806(RTCV(RTOSCF(14337,F1437_14337, (loc1))));
			/* END INLINED CODE */
		}
		tb2 = tb2;
		tb1 = tb2;
	}
	if (tb1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11969[Dtype(RTCW(loc1))-1437])(loc1);
		Result = RTLNS(eif_new_type(2247, 0x00).id, 2247, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F2246_21883(RTCW(Result), ((EIF_INTEGER_32) 1024L));
		for (;;) {
			{
				/* INLINED CODE (LINEAR.exhausted) */
				tb1 = (EIF_BOOLEAN)  0;
				(void) RTCW(loc1);
				tb1 = F1437_14201(loc1);
				/* END INLINED CODE */
			}
			tb1 = tb1;
			if (tb1) break;
			F1437_14317(RTCW(loc1), ((EIF_INTEGER_32) 1024L));
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O11174[Dtype(loc1)-920]);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17139[Dtype(RTCW(Result))-2247])(Result, tr1);
		}
		{
			/* INLINED CODE (FILE.close) */
			(void) RTCW(loc1);
			tp1 = *(EIF_POINTER *)(loc1 + O11932[Dtype(loc1)-1436]);
			eif_file_close((FILE*) tp1);
			*(EIF_INTEGER_32 *)(loc1 + O12071[Dtype(loc1)-1436]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			tp1 = F1_33(loc1);
			*(EIF_POINTER *)(loc1 + O11932[Dtype(loc1)-1436]) = (EIF_POINTER) tp1;
			*(EIF_BOOLEAN *)(loc1 + O12080[Dtype(loc1)-1436]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
	return Result;
}

void EIF_Minit18 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
