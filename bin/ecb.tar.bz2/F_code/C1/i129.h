
#ifndef _C1_i129_
#define _C1_i129_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F33_303(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit29(void);
extern void F255_3962(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
