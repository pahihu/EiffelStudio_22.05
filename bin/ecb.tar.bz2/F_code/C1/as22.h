
#ifndef _C1_as22_
#define _C1_as22_

#ifdef __cplusplus
extern "C" {
#endif

extern void F26_238(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F26_240(EIF_REFERENCE);
extern void F26_241(EIF_REFERENCE, EIF_INTEGER_32);
RTOSHF (EIF_REFERENCE,243)
static EIF_REFERENCE F26_243_body(EIF_REFERENCE);
extern EIF_REFERENCE F26_243(EIF_REFERENCE);
extern void EIF_Minit22(void);
extern void F353_5055(EIF_REFERENCE, EIF_INTEGER_32);
extern void F352_5055(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R4932[])();
extern long O4930[];

#ifdef __cplusplus
}
#endif

#endif
