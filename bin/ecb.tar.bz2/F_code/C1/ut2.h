
#ifndef _C1_ut2_
#define _C1_ut2_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F4_47(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit2(void);
extern void F164_2794(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F2243_21753(EIF_REFERENCE);
extern void F2250_22049(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R11246[])();
extern long O17115[];
extern long O11174[];

#ifdef __cplusplus
}
#endif

#endif
