/*
 * Code for class DISPOSABLE_UTILITIES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "di9.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DISPOSABLE_UTILITIES}.dispose */
void F11_114 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	loc1 = RTCCL(arg1);
	loc1 = RTRV(eif_new_type(860, 0x00),loc1);
	if (EIF_TEST(loc1)) {
		F862_12233(loc1);
	} else {
		loc2 = RTCCL(arg1);
		loc2 = RTRV(eif_new_type(780, 0x00),loc2);
		if (EIF_TEST(loc2)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R9257[Dtype(loc2)-781])(loc2);
		}
	}
	RTLE;
}

void EIF_Minit9 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
