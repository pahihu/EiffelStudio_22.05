/*
 * Code for class AST_SCOPE_KEEPER_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "as23.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {AST_SCOPE_KEEPER_FACTORY}.create_scope_keeper */
EIF_REFERENCE F27_244 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 > ((EIF_INTEGER_32) 63L))) {
		tr1 = RTLNS(eif_new_type(353, 0x00).id, 353, _OBJSIZ_3_0_0_1_0_0_0_0_);
		F352_5055(RTCW(tr1), arg1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = RTLNS(eif_new_type(354, 0x00).id, 354, _OBJSIZ_2_0_0_1_0_0_1_0_);
		F353_5055(RTCW(tr1), arg1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

void EIF_Minit23 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
