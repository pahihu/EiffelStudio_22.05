/*
 * Code for class INVARIANT_ADAPTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "in31.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {INVARIANT_ADAPTER}.register */
void F35_307 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_3_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	{
		/* INLINED CODE (FORMAT_REGISTRATION.record_invariant) */
		(void) RTCW(arg2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(arg2 + _REFACS_1_) == tr1)) {
			tr1 = *(EIF_REFERENCE *)(arg2 + _REFACS_12_);
			F1540_14721(RTCW(tr1), Current);
		} else {
			tr1 = *(EIF_REFERENCE *)(arg2 + _REFACS_12_);
			F1540_14722(RTCW(tr1), Current);
		}
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {INVARIANT_ADAPTER}.format */
void F35_310 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	{
		/* INLINED CODE (TEXT_FORMATTER_DECORATOR.begin) */
		tr1 = (EIF_REFERENCE)  0;
		(void) RTCW(arg1);
		tr2 = *(EIF_REFERENCE *)(arg1 + _REFACS_14_);
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr2);
		tr2 = *(EIF_REFERENCE *)(arg1 + _REFACS_4_);
		F1548_14766(RTCW(tr2), tr1);
		RTAR(arg1, tr1);
		*(EIF_REFERENCE *)(arg1 + _REFACS_14_) = (EIF_REFERENCE) tr1;
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (TEXT_FORMATTER_DECORATOR.init_variant_context) */
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		(void) RTCW(arg1);
		F2354_23674(arg1, tr1);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_45_);
		RTAR(arg1, tr2);
		*(EIF_REFERENCE *)(arg1 + _REFACS_12_) = (EIF_REFERENCE) tr2;
		F2354_23750(arg1);
		F795_11420(arg1);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (TEXT_FORMATTER_DECORATOR.format_ast) */
		tr1 = *(EIF_REFERENCE *)(Current);
		(void) RTCW(arg1);
		tr2 = *(EIF_REFERENCE *)(arg1 + _REFACS_18_);
		F2517_26608(RTCW(tr2), tr1);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (TEXT_FORMATTER_DECORATOR.commit) */
		(void) RTCW(arg1);
		tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_4_);
		F1548_14768(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_4_);
		tr1 = F1548_14764(RTCW(tr1));
		RTAR(arg1, tr1);
		*(EIF_REFERENCE *)(arg1 + _REFACS_14_) = (EIF_REFERENCE) tr1;
		/* END INLINED CODE */
	}
	;
	RTLE;
}

void EIF_Minit31 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
