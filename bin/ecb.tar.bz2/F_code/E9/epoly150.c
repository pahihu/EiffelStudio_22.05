#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O20606[579];
void O20606_init () {
	O20606[0] = + _CHROFF_53_22_;
	O20606[1] = + _CHROFF_56_22_;
	{long i; for (i = 564; i < 579; i++) O20606[i] = + _CHROFF_54_22_;}
}

long O20649[579];
void O20649_init () {
	O20649[0] = + _CHROFF_53_23_;
	O20649[1] = + _CHROFF_56_23_;
	{long i; for (i = 564; i < 579; i++) O20649[i] = + _CHROFF_54_23_;}
}

long O20650[579];
void O20650_init () {
	O20650[0] = + _CHROFF_53_24_;
	O20650[1] = + _CHROFF_56_24_;
	{long i; for (i = 564; i < 579; i++) O20650[i] = + _CHROFF_54_24_;}
}

long O20654[579];
void O20654_init () {
	O20654[0] = + _CHROFF_53_25_;
	O20654[1] = + _CHROFF_56_25_;
	{long i; for (i = 564; i < 579; i++) O20654[i] = + _CHROFF_54_25_;}
}

long O20655[579];
void O20655_init () {
	O20655[0] = + _CHROFF_53_26_;
	O20655[1] = + _CHROFF_56_26_;
	{long i; for (i = 564; i < 579; i++) O20655[i] = + _CHROFF_54_26_;}
}

long O20662[579];
void O20662_init () {
	O20662[0] = + _CHROFF_53_27_;
	O20662[1] = + _CHROFF_56_27_;
	{long i; for (i = 564; i < 579; i++) O20662[i] = + _CHROFF_54_27_;}
}

long O20663[579];
void O20663_init () {
	O20663[0] = + _CHROFF_53_28_;
	O20663[1] = + _CHROFF_56_28_;
	{long i; for (i = 564; i < 579; i++) O20663[i] = + _CHROFF_54_28_;}
}

long O20664[579];
void O20664_init () {
	O20664[0] = + _CHROFF_53_29_;
	O20664[1] = + _CHROFF_56_29_;
	{long i; for (i = 564; i < 579; i++) O20664[i] = + _CHROFF_54_29_;}
}

long O20665[579];
void O20665_init () {
	O20665[0] = + _CHROFF_53_30_;
	O20665[1] = + _CHROFF_56_30_;
	{long i; for (i = 564; i < 579; i++) O20665[i] = + _CHROFF_54_30_;}
}

long O20675[579];
void O20675_init () {
	O20675[0] = + _CHROFF_53_31_;
	O20675[1] = + _CHROFF_56_31_;
	{long i; for (i = 564; i < 579; i++) O20675[i] = + _CHROFF_54_31_;}
}

long O20678[579];
void O20678_init () {
	O20678[0] = + _CHROFF_53_32_;
	O20678[1] = + _CHROFF_56_32_;
	{long i; for (i = 564; i < 579; i++) O20678[i] = + _CHROFF_54_32_;}
}

long O20681[579];
void O20681_init () {
	O20681[0] = + _CHROFF_53_33_;
	O20681[1] = + _CHROFF_56_33_;
	{long i; for (i = 564; i < 579; i++) O20681[i] = + _CHROFF_54_33_;}
}

long O20684[579];
void O20684_init () {
	O20684[0] = + _CHROFF_53_34_;
	O20684[1] = + _CHROFF_56_34_;
	{long i; for (i = 564; i < 579; i++) O20684[i] = + _CHROFF_54_34_;}
}

long O20685[579];
void O20685_init () {
	O20685[0] = + _CHROFF_53_35_;
	O20685[1] = + _CHROFF_56_35_;
	{long i; for (i = 564; i < 579; i++) O20685[i] = + _CHROFF_54_35_;}
}

long O20688[579];
void O20688_init () {
	O20688[0] = + _LNGOFF_53_36_0_4_;
	O20688[1] = + _LNGOFF_56_38_0_4_;
	O20688[564] = + _LNGOFF_54_37_0_4_;
	O20688[565] = + _LNGOFF_54_39_0_4_;
	{long i; for (i = 566; i < 575; i++) O20688[i] = + _LNGOFF_54_37_0_4_;}
	{long i; for (i = 575; i < 577; i++) O20688[i] = + _LNGOFF_54_38_0_4_;}
	{long i; for (i = 577; i < 579; i++) O20688[i] = + _LNGOFF_54_37_0_4_;}
}

long O20727[4];
void O20727_init () {
	O20727[0] = + _CHROFF_4_0_;
	O20727[1] = + _CHROFF_17_6_;
	O20727[2] = + _CHROFF_16_6_;
	O20727[3] = + _CHROFF_18_6_;
}

long O20728[4];
void O20728_init () {
	O20728[0] = 0;
	O20728[1] =  + _REFACS_12_;
	O20728[2] =  + _REFACS_11_;
	O20728[3] =  + _REFACS_13_;
}

long O20756[4];
void O20756_init () {
	O20756[0] = + _CHROFF_4_1_;
	O20756[1] = + _CHROFF_17_7_;
	O20756[2] = + _CHROFF_16_7_;
	O20756[3] = + _CHROFF_18_7_;
}

long O20760[4];
void O20760_init () {
	O20760[0] =  + _REFACS_1_;
	O20760[1] =  + _REFACS_13_;
	O20760[2] =  + _REFACS_12_;
	O20760[3] =  + _REFACS_14_;
}

long O20766[4];
void O20766_init () {
	O20766[0] =  + _REFACS_2_;
	O20766[1] =  + _REFACS_14_;
	O20766[2] =  + _REFACS_13_;
	O20766[3] =  + _REFACS_15_;
}

long O20767[4];
void O20767_init () {
	O20767[0] =  + _REFACS_3_;
	O20767[1] =  + _REFACS_15_;
	O20767[2] =  + _REFACS_14_;
	O20767[3] =  + _REFACS_16_;
}

long O20785[2];
void O20785_init () {
	O20785[0] =  + _REFACS_15_;
	O20785[1] =  + _REFACS_17_;
}

long O20912[106];
void O20912_init () {
	{long i; for (i = 0; i < 8; i++) O20912[i] = + _LNGOFF_2_2_0_0_;}
	O20912[105] = + _LNGOFF_6_4_0_0_;
}

long O20913[106];
void O20913_init () {
	{long i; for (i = 0; i < 8; i++) O20913[i] = + _LNGOFF_2_2_0_1_;}
	O20913[105] = + _LNGOFF_6_4_0_1_;
}

long O20922[106];
void O20922_init () {
	{long i; for (i = 0; i < 8; i++) O20922[i] = + _CHROFF_2_0_;}
	O20922[105] = + _CHROFF_6_0_;
}

long O20956[106];
void O20956_init () {
	{long i; for (i = 0; i < 8; i++) O20956[i] = + _CHROFF_2_1_;}
	O20956[105] = + _CHROFF_6_1_;
}

long O21155[60];
void O21155_init () {
	O21155[0] = + _LNGOFF_3_0_0_1_;
	{long i; for (i = 1; i < 3; i++) O21155[i] = + _LNGOFF_4_0_0_1_;}
	{long i; for (i = 3; i < 8; i++) O21155[i] = + _LNGOFF_6_0_0_1_;}
	{long i; for (i = 8; i < 18; i++) O21155[i] = + _LNGOFF_7_0_0_1_;}
	O21155[18] = + _LNGOFF_5_0_0_1_;
	{long i; for (i = 19; i < 24; i++) O21155[i] = + _LNGOFF_6_0_0_1_;}
	{long i; for (i = 24; i < 29; i++) O21155[i] = + _LNGOFF_7_0_0_1_;}
	{long i; for (i = 29; i < 34; i++) O21155[i] = + _LNGOFF_6_1_0_1_;}
	{long i; for (i = 34; i < 39; i++) O21155[i] = + _LNGOFF_7_1_0_1_;}
	{long i; for (i = 39; i < 45; i++) O21155[i] = + _LNGOFF_5_0_0_1_;}
	{long i; for (i = 45; i < 50; i++) O21155[i] = + _LNGOFF_6_0_0_1_;}
	{long i; for (i = 50; i < 55; i++) O21155[i] = + _LNGOFF_5_2_0_1_;}
	{long i; for (i = 55; i < 60; i++) O21155[i] = + _LNGOFF_6_2_0_1_;}
}

long O21156[60];
void O21156_init () {
	O21156[0] = + _LNGOFF_3_0_0_2_;
	{long i; for (i = 1; i < 3; i++) O21156[i] = + _LNGOFF_4_0_0_2_;}
	{long i; for (i = 3; i < 8; i++) O21156[i] = + _LNGOFF_6_0_0_2_;}
	{long i; for (i = 8; i < 18; i++) O21156[i] = + _LNGOFF_7_0_0_2_;}
	O21156[18] = + _LNGOFF_5_0_0_2_;
	{long i; for (i = 19; i < 24; i++) O21156[i] = + _LNGOFF_6_0_0_2_;}
	{long i; for (i = 24; i < 29; i++) O21156[i] = + _LNGOFF_7_0_0_2_;}
	{long i; for (i = 29; i < 34; i++) O21156[i] = + _LNGOFF_6_1_0_2_;}
	{long i; for (i = 34; i < 39; i++) O21156[i] = + _LNGOFF_7_1_0_2_;}
	{long i; for (i = 39; i < 45; i++) O21156[i] = + _LNGOFF_5_0_0_2_;}
	{long i; for (i = 45; i < 50; i++) O21156[i] = + _LNGOFF_6_0_0_2_;}
	{long i; for (i = 50; i < 55; i++) O21156[i] = + _LNGOFF_5_2_0_2_;}
	{long i; for (i = 55; i < 60; i++) O21156[i] = + _LNGOFF_6_2_0_2_;}
}

long O21157[60];
void O21157_init () {
	O21157[0] = + _LNGOFF_3_0_0_3_;
	{long i; for (i = 1; i < 3; i++) O21157[i] = + _LNGOFF_4_0_0_3_;}
	{long i; for (i = 3; i < 8; i++) O21157[i] = + _LNGOFF_6_0_0_3_;}
	{long i; for (i = 8; i < 18; i++) O21157[i] = + _LNGOFF_7_0_0_3_;}
	O21157[18] = + _LNGOFF_5_0_0_3_;
	{long i; for (i = 19; i < 24; i++) O21157[i] = + _LNGOFF_6_0_0_3_;}
	{long i; for (i = 24; i < 29; i++) O21157[i] = + _LNGOFF_7_0_0_3_;}
	{long i; for (i = 29; i < 34; i++) O21157[i] = + _LNGOFF_6_1_0_3_;}
	{long i; for (i = 34; i < 39; i++) O21157[i] = + _LNGOFF_7_1_0_3_;}
	{long i; for (i = 39; i < 45; i++) O21157[i] = + _LNGOFF_5_0_0_3_;}
	{long i; for (i = 45; i < 50; i++) O21157[i] = + _LNGOFF_6_0_0_3_;}
	{long i; for (i = 50; i < 55; i++) O21157[i] = + _LNGOFF_5_2_0_3_;}
	{long i; for (i = 55; i < 60; i++) O21157[i] = + _LNGOFF_6_2_0_3_;}
}

long O21158[60];
void O21158_init () {
	O21158[0] = + _LNGOFF_3_0_0_4_;
	{long i; for (i = 1; i < 3; i++) O21158[i] = + _LNGOFF_4_0_0_4_;}
	{long i; for (i = 3; i < 8; i++) O21158[i] = + _LNGOFF_6_0_0_4_;}
	{long i; for (i = 8; i < 18; i++) O21158[i] = + _LNGOFF_7_0_0_4_;}
	O21158[18] = + _LNGOFF_5_0_0_4_;
	{long i; for (i = 19; i < 24; i++) O21158[i] = + _LNGOFF_6_0_0_4_;}
	{long i; for (i = 24; i < 29; i++) O21158[i] = + _LNGOFF_7_0_0_4_;}
	{long i; for (i = 29; i < 34; i++) O21158[i] = + _LNGOFF_6_1_0_4_;}
	{long i; for (i = 34; i < 39; i++) O21158[i] = + _LNGOFF_7_1_0_4_;}
	{long i; for (i = 39; i < 45; i++) O21158[i] = + _LNGOFF_5_0_0_4_;}
	{long i; for (i = 45; i < 50; i++) O21158[i] = + _LNGOFF_6_0_0_4_;}
	{long i; for (i = 50; i < 55; i++) O21158[i] = + _LNGOFF_5_2_0_4_;}
	{long i; for (i = 55; i < 60; i++) O21158[i] = + _LNGOFF_6_2_0_4_;}
}

long O21162[60];
void O21162_init () {
	O21162[0] = + _LNGOFF_3_0_0_5_;
	{long i; for (i = 1; i < 3; i++) O21162[i] = + _LNGOFF_4_0_0_5_;}
	{long i; for (i = 3; i < 8; i++) O21162[i] = + _LNGOFF_6_0_0_5_;}
	{long i; for (i = 8; i < 18; i++) O21162[i] = + _LNGOFF_7_0_0_5_;}
	O21162[18] = + _LNGOFF_5_0_0_5_;
	{long i; for (i = 19; i < 24; i++) O21162[i] = + _LNGOFF_6_0_0_5_;}
	{long i; for (i = 24; i < 29; i++) O21162[i] = + _LNGOFF_7_0_0_5_;}
	{long i; for (i = 29; i < 34; i++) O21162[i] = + _LNGOFF_6_1_0_5_;}
	{long i; for (i = 34; i < 39; i++) O21162[i] = + _LNGOFF_7_1_0_5_;}
	{long i; for (i = 39; i < 45; i++) O21162[i] = + _LNGOFF_5_0_0_5_;}
	{long i; for (i = 45; i < 50; i++) O21162[i] = + _LNGOFF_6_0_0_5_;}
	{long i; for (i = 50; i < 55; i++) O21162[i] = + _LNGOFF_5_2_0_5_;}
	{long i; for (i = 55; i < 60; i++) O21162[i] = + _LNGOFF_6_2_0_5_;}
}

long O21163[60];
void O21163_init () {
	O21163[0] = + _LNGOFF_3_0_0_6_;
	{long i; for (i = 1; i < 3; i++) O21163[i] = + _LNGOFF_4_0_0_6_;}
	{long i; for (i = 3; i < 8; i++) O21163[i] = + _LNGOFF_6_0_0_6_;}
	{long i; for (i = 8; i < 18; i++) O21163[i] = + _LNGOFF_7_0_0_6_;}
	O21163[18] = + _LNGOFF_5_0_0_6_;
	{long i; for (i = 19; i < 24; i++) O21163[i] = + _LNGOFF_6_0_0_6_;}
	{long i; for (i = 24; i < 29; i++) O21163[i] = + _LNGOFF_7_0_0_6_;}
	{long i; for (i = 29; i < 34; i++) O21163[i] = + _LNGOFF_6_1_0_6_;}
	{long i; for (i = 34; i < 39; i++) O21163[i] = + _LNGOFF_7_1_0_6_;}
	{long i; for (i = 39; i < 45; i++) O21163[i] = + _LNGOFF_5_0_0_6_;}
	{long i; for (i = 45; i < 50; i++) O21163[i] = + _LNGOFF_6_0_0_6_;}
	{long i; for (i = 50; i < 55; i++) O21163[i] = + _LNGOFF_5_2_0_6_;}
	{long i; for (i = 55; i < 60; i++) O21163[i] = + _LNGOFF_6_2_0_6_;}
}

long O21164[60];
void O21164_init () {
	O21164[0] = + _LNGOFF_3_0_0_7_;
	{long i; for (i = 1; i < 3; i++) O21164[i] = + _LNGOFF_4_0_0_7_;}
	{long i; for (i = 3; i < 8; i++) O21164[i] = + _LNGOFF_6_0_0_7_;}
	{long i; for (i = 8; i < 18; i++) O21164[i] = + _LNGOFF_7_0_0_7_;}
	O21164[18] = + _LNGOFF_5_0_0_7_;
	{long i; for (i = 19; i < 24; i++) O21164[i] = + _LNGOFF_6_0_0_7_;}
	{long i; for (i = 24; i < 29; i++) O21164[i] = + _LNGOFF_7_0_0_7_;}
	{long i; for (i = 29; i < 34; i++) O21164[i] = + _LNGOFF_6_1_0_7_;}
	{long i; for (i = 34; i < 39; i++) O21164[i] = + _LNGOFF_7_1_0_7_;}
	{long i; for (i = 39; i < 45; i++) O21164[i] = + _LNGOFF_5_0_0_7_;}
	{long i; for (i = 45; i < 50; i++) O21164[i] = + _LNGOFF_6_0_0_7_;}
	{long i; for (i = 50; i < 55; i++) O21164[i] = + _LNGOFF_5_2_0_7_;}
	{long i; for (i = 55; i < 60; i++) O21164[i] = + _LNGOFF_6_2_0_7_;}
}

long O21186[60];
void O21186_init () {
	O21186[0] = + _LNGOFF_3_0_0_8_;
	{long i; for (i = 1; i < 3; i++) O21186[i] = + _LNGOFF_4_0_0_8_;}
	{long i; for (i = 3; i < 8; i++) O21186[i] = + _LNGOFF_6_0_0_8_;}
	{long i; for (i = 8; i < 18; i++) O21186[i] = + _LNGOFF_7_0_0_8_;}
	O21186[18] = + _LNGOFF_5_0_0_8_;
	{long i; for (i = 19; i < 24; i++) O21186[i] = + _LNGOFF_6_0_0_8_;}
	{long i; for (i = 24; i < 29; i++) O21186[i] = + _LNGOFF_7_0_0_8_;}
	{long i; for (i = 29; i < 34; i++) O21186[i] = + _LNGOFF_6_1_0_8_;}
	{long i; for (i = 34; i < 39; i++) O21186[i] = + _LNGOFF_7_1_0_8_;}
	{long i; for (i = 39; i < 45; i++) O21186[i] = + _LNGOFF_5_0_0_8_;}
	{long i; for (i = 45; i < 50; i++) O21186[i] = + _LNGOFF_6_0_0_8_;}
	{long i; for (i = 50; i < 55; i++) O21186[i] = + _LNGOFF_5_2_0_8_;}
	{long i; for (i = 55; i < 60; i++) O21186[i] = + _LNGOFF_6_2_0_8_;}
}

long O21188[60];
void O21188_init () {
	O21188[0] = + _LNGOFF_3_0_0_9_;
	{long i; for (i = 1; i < 3; i++) O21188[i] = + _LNGOFF_4_0_0_9_;}
	{long i; for (i = 3; i < 8; i++) O21188[i] = + _LNGOFF_6_0_0_9_;}
	{long i; for (i = 8; i < 18; i++) O21188[i] = + _LNGOFF_7_0_0_9_;}
	O21188[18] = + _LNGOFF_5_0_0_9_;
	{long i; for (i = 19; i < 24; i++) O21188[i] = + _LNGOFF_6_0_0_9_;}
	{long i; for (i = 24; i < 29; i++) O21188[i] = + _LNGOFF_7_0_0_9_;}
	{long i; for (i = 29; i < 34; i++) O21188[i] = + _LNGOFF_6_1_0_9_;}
	{long i; for (i = 34; i < 39; i++) O21188[i] = + _LNGOFF_7_1_0_9_;}
	{long i; for (i = 39; i < 45; i++) O21188[i] = + _LNGOFF_5_0_0_9_;}
	{long i; for (i = 45; i < 50; i++) O21188[i] = + _LNGOFF_6_0_0_9_;}
	{long i; for (i = 50; i < 55; i++) O21188[i] = + _LNGOFF_5_2_0_9_;}
	{long i; for (i = 55; i < 60; i++) O21188[i] = + _LNGOFF_6_2_0_9_;}
}

long O21445[60];
void O21445_init () {
	O21445[0] = + _I64OFF_3_0_0_12_0_0_0_;
	{long i; for (i = 1; i < 3; i++) O21445[i] = + _I64OFF_4_0_0_13_0_0_0_;}
	O21445[3] = + _I64OFF_6_0_0_15_0_0_0_;
	O21445[4] = + _I64OFF_6_0_0_16_0_0_0_;
	{long i; for (i = 5; i < 8; i++) O21445[i] = + _I64OFF_6_0_0_17_0_0_0_;}
	O21445[8] = + _I64OFF_7_0_0_14_0_0_0_;
	O21445[9] = + _I64OFF_7_0_0_15_0_0_0_;
	{long i; for (i = 10; i < 13; i++) O21445[i] = + _I64OFF_7_0_0_16_0_0_0_;}
	O21445[13] = + _I64OFF_7_0_0_14_0_0_0_;
	O21445[14] = + _I64OFF_7_0_0_15_0_0_0_;
	{long i; for (i = 15; i < 18; i++) O21445[i] = + _I64OFF_7_0_0_16_0_0_0_;}
	O21445[18] = + _I64OFF_5_0_0_13_0_0_0_;
	O21445[19] = + _I64OFF_6_0_0_13_0_0_0_;
	O21445[20] = + _I64OFF_6_0_0_14_0_0_0_;
	{long i; for (i = 21; i < 24; i++) O21445[i] = + _I64OFF_6_0_0_15_0_0_0_;}
	O21445[24] = + _I64OFF_7_0_0_14_0_0_0_;
	O21445[25] = + _I64OFF_7_0_0_15_0_0_0_;
	{long i; for (i = 26; i < 29; i++) O21445[i] = + _I64OFF_7_0_0_16_0_0_0_;}
	O21445[29] = + _I64OFF_6_1_0_13_0_0_0_;
	O21445[30] = + _I64OFF_6_1_0_14_0_0_0_;
	{long i; for (i = 31; i < 34; i++) O21445[i] = + _I64OFF_6_1_0_15_0_0_0_;}
	O21445[34] = + _I64OFF_7_1_0_14_0_0_0_;
	O21445[35] = + _I64OFF_7_1_0_15_0_0_0_;
	{long i; for (i = 36; i < 39; i++) O21445[i] = + _I64OFF_7_1_0_16_0_0_0_;}
	{long i; for (i = 39; i < 41; i++) O21445[i] = + _I64OFF_5_0_0_13_0_0_0_;}
	O21445[41] = + _I64OFF_5_0_0_14_0_0_0_;
	{long i; for (i = 42; i < 45; i++) O21445[i] = + _I64OFF_5_0_0_15_0_0_0_;}
	O21445[45] = + _I64OFF_6_0_0_14_0_0_0_;
	{long i; for (i = 46; i < 48; i++) O21445[i] = + _I64OFF_6_0_0_16_0_0_0_;}
	O21445[48] = + _I64OFF_6_0_0_15_0_0_0_;
	O21445[49] = + _I64OFF_6_0_0_16_0_0_0_;
	O21445[50] = + _I64OFF_5_2_0_13_0_0_0_;
	O21445[51] = + _I64OFF_5_2_0_14_0_0_0_;
	{long i; for (i = 52; i < 55; i++) O21445[i] = + _I64OFF_5_2_0_15_0_0_0_;}
	O21445[55] = + _I64OFF_6_2_0_14_0_0_0_;
	O21445[56] = + _I64OFF_6_2_0_15_0_0_0_;
	{long i; for (i = 57; i < 60; i++) O21445[i] = + _I64OFF_6_2_0_16_0_0_0_;}
}

long O21450[60];
void O21450_init () {
	O21450[0] = + _LNGOFF_3_0_0_10_;
	{long i; for (i = 1; i < 3; i++) O21450[i] = + _LNGOFF_4_0_0_10_;}
	{long i; for (i = 3; i < 8; i++) O21450[i] = + _LNGOFF_6_0_0_10_;}
	{long i; for (i = 8; i < 18; i++) O21450[i] = + _LNGOFF_7_0_0_10_;}
	O21450[18] = + _LNGOFF_5_0_0_10_;
	{long i; for (i = 19; i < 24; i++) O21450[i] = + _LNGOFF_6_0_0_10_;}
	{long i; for (i = 24; i < 29; i++) O21450[i] = + _LNGOFF_7_0_0_10_;}
	{long i; for (i = 29; i < 34; i++) O21450[i] = + _LNGOFF_6_1_0_10_;}
	{long i; for (i = 34; i < 39; i++) O21450[i] = + _LNGOFF_7_1_0_10_;}
	{long i; for (i = 39; i < 45; i++) O21450[i] = + _LNGOFF_5_0_0_10_;}
	{long i; for (i = 45; i < 50; i++) O21450[i] = + _LNGOFF_6_0_0_10_;}
	{long i; for (i = 50; i < 55; i++) O21450[i] = + _LNGOFF_5_2_0_10_;}
	{long i; for (i = 55; i < 60; i++) O21450[i] = + _LNGOFF_6_2_0_10_;}
}

long O21452[60];
void O21452_init () {
	O21452[0] = + _LNGOFF_3_0_0_11_;
	{long i; for (i = 1; i < 3; i++) O21452[i] = + _LNGOFF_4_0_0_11_;}
	{long i; for (i = 3; i < 8; i++) O21452[i] = + _LNGOFF_6_0_0_11_;}
	{long i; for (i = 8; i < 18; i++) O21452[i] = + _LNGOFF_7_0_0_11_;}
	O21452[18] = + _LNGOFF_5_0_0_11_;
	{long i; for (i = 19; i < 24; i++) O21452[i] = + _LNGOFF_6_0_0_11_;}
	{long i; for (i = 24; i < 29; i++) O21452[i] = + _LNGOFF_7_0_0_11_;}
	{long i; for (i = 29; i < 34; i++) O21452[i] = + _LNGOFF_6_1_0_11_;}
	{long i; for (i = 34; i < 39; i++) O21452[i] = + _LNGOFF_7_1_0_11_;}
	{long i; for (i = 39; i < 45; i++) O21452[i] = + _LNGOFF_5_0_0_11_;}
	{long i; for (i = 45; i < 50; i++) O21452[i] = + _LNGOFF_6_0_0_11_;}
	{long i; for (i = 50; i < 55; i++) O21452[i] = + _LNGOFF_5_2_0_11_;}
	{long i; for (i = 55; i < 60; i++) O21452[i] = + _LNGOFF_6_2_0_11_;}
}

EIF_TYPE_INDEX *Y21452_gen_type [60];
EIF_TYPE_INDEX Y21452 [60];
void Y21452_init (void)
{
	egc_routines_types [21452] = Y21452;
	egc_routines_gen_types [21452] = Y21452_gen_type;
	egc_routines_offset [21452] = 2542;
	{long i; for (i = 0; i < 60; i++) Y21452[i] = 2055;};
}

long O21458[16];
void O21458_init () {
	O21458[0] = + _LNGOFF_4_0_0_12_;
	{long i; for (i = 1; i < 6; i++) O21458[i] = + _LNGOFF_6_0_0_12_;}
	{long i; for (i = 6; i < 16; i++) O21458[i] = + _LNGOFF_7_0_0_12_;}
}

long O21496[42];
void O21496_init () {
	O21496[0] = + _LNGOFF_5_0_0_12_;
	{long i; for (i = 1; i < 6; i++) O21496[i] = + _LNGOFF_6_0_0_12_;}
	{long i; for (i = 6; i < 11; i++) O21496[i] = + _LNGOFF_7_0_0_12_;}
	{long i; for (i = 11; i < 16; i++) O21496[i] = + _LNGOFF_6_1_0_12_;}
	{long i; for (i = 16; i < 21; i++) O21496[i] = + _LNGOFF_7_1_0_12_;}
	{long i; for (i = 21; i < 27; i++) O21496[i] = + _LNGOFF_5_0_0_12_;}
	{long i; for (i = 27; i < 32; i++) O21496[i] = + _LNGOFF_6_0_0_12_;}
	{long i; for (i = 32; i < 37; i++) O21496[i] = + _LNGOFF_5_2_0_12_;}
	{long i; for (i = 37; i < 42; i++) O21496[i] = + _LNGOFF_6_2_0_12_;}
}

long O21520[10];
void O21520_init () {
	{long i; for (i = 0; i < 5; i++) O21520[i] = + _CHROFF_6_0_;}
	{long i; for (i = 5; i < 10; i++) O21520[i] = + _CHROFF_7_0_;}
}

long O21549[10];
void O21549_init () {
	{long i; for (i = 0; i < 5; i++) O21549[i] = + _CHROFF_5_0_;}
	{long i; for (i = 5; i < 10; i++) O21549[i] = + _CHROFF_6_0_;}
}

long O21550[10];
void O21550_init () {
	{long i; for (i = 0; i < 5; i++) O21550[i] = + _CHROFF_5_1_;}
	{long i; for (i = 5; i < 10; i++) O21550[i] = + _CHROFF_6_1_;}
}


#ifdef __cplusplus
}
#endif
