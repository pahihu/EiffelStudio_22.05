#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O18395[1240];
void O18395_init () {
	O18395[0] = + _CHROFF_20_8_;
	O18395[1] = + _CHROFF_21_8_;
	O18395[2] = + _CHROFF_20_8_;
	{long i; for (i = 1238; i < 1240; i++) O18395[i] = + _CHROFF_22_8_;}
}

long O18400[1240];
void O18400_init () {
	O18400[0] = + _LNGOFF_20_11_0_0_;
	O18400[1] = + _LNGOFF_21_12_0_0_;
	O18400[2] = + _LNGOFF_20_12_0_0_;
	O18400[1238] = + _LNGOFF_22_11_0_0_;
	O18400[1239] = + _LNGOFF_22_12_0_0_;
}

long O18418[1240];
void O18418_init () {
	O18418[0] = + _CHROFF_20_9_;
	O18418[1] = + _CHROFF_21_9_;
	O18418[2] = + _CHROFF_20_9_;
	{long i; for (i = 1238; i < 1240; i++) O18418[i] = + _CHROFF_22_9_;}
}

long O18441[1240];
void O18441_init () {
	O18441[0] = + _CHROFF_20_10_;
	O18441[1] = + _CHROFF_21_10_;
	O18441[2] = + _CHROFF_20_10_;
	{long i; for (i = 1238; i < 1240; i++) O18441[i] = + _CHROFF_22_10_;}
}

long O18494[7];
void O18494_init () {
	O18494[0] = + _LNGOFF_0_0_0_0_;
	O18494[1] = + _LNGOFF_1_0_0_0_;
	{long i; for (i = 2; i < 6; i++) O18494[i] = + _LNGOFF_0_0_0_0_;}
	O18494[6] = + _LNGOFF_1_0_0_0_;
}

long O18495[7];
void O18495_init () {
	O18495[0] = + _LNGOFF_0_0_0_1_;
	O18495[1] = + _LNGOFF_1_0_0_1_;
	{long i; for (i = 2; i < 6; i++) O18495[i] = + _LNGOFF_0_0_0_1_;}
	O18495[6] = + _LNGOFF_1_0_0_1_;
}

long O18621[463];
void O18621_init () {
	O18621[0] = + _LNGOFF_2_0_0_0_;
	O18621[1] = + _LNGOFF_4_4_0_0_;
	O18621[2] = + _LNGOFF_2_0_0_0_;
	O18621[3] = + _LNGOFF_4_0_0_0_;
	O18621[4] = + _LNGOFF_3_0_0_0_;
	O18621[218] = + _LNGOFF_2_0_0_0_;
	O18621[219] = + _LNGOFF_4_0_0_0_;
	O18621[220] = + _LNGOFF_5_0_0_0_;
	O18621[221] = + _LNGOFF_9_0_0_0_;
	{long i; for (i = 222; i < 225; i++) O18621[i] = + _LNGOFF_7_0_0_0_;}
	O18621[225] = + _LNGOFF_2_0_0_0_;
	O18621[226] = + _LNGOFF_4_0_0_0_;
	O18621[227] = + _LNGOFF_3_0_0_0_;
	O18621[462] = + _LNGOFF_8_1_0_0_;
}

static EIF_TYPE_INDEX Y18673_pgtype0[] = {1594,0xFFF9,1,2049,2384,0xFFFF};
static EIF_TYPE_INDEX Y18673_pgtype1[] = {1594,0xFFF9,1,2049,2385,0xFFFF};
static EIF_TYPE_INDEX Y18673_pgtype2[] = {1594,0xFFF9,1,2049,2603,0xFFFF};
static EIF_TYPE_INDEX Y18673_pgtype3[] = {1594,0xFFF9,1,2049,2605,0xFFFF};
static EIF_TYPE_INDEX Y18673_pgtype4[] = {1594,0xFFF9,1,2049,2608,0xFFFF};
static EIF_TYPE_INDEX Y18673_pgtype5[] = {1594,0xFFF9,1,2049,2607,0xFFFF};
static EIF_TYPE_INDEX Y18673_pgtype6[] = {1594,0xFFF9,1,2049,2386,0xFFFF};
static EIF_TYPE_INDEX Y18673_pgtype7[] = {1594,0xFFF9,1,2049,2388,0xFFFF};
static EIF_TYPE_INDEX Y18673_pgtype8[] = {1594,0xFFF9,1,2049,2387,0xFFFF};
static EIF_TYPE_INDEX Y18673_pgtype9[] = {1594,0xFFF9,1,2049,2846,0xFFFF};
static EIF_TYPE_INDEX Y18673_pgtype10[] = {1594,0xFFF9,1,2049,2609,0xFFFF};
EIF_TYPE_INDEX *Y18673_gen_type [11];
EIF_TYPE_INDEX Y18673 [11];
void Y18673_init (void)
{
	egc_routines_types [18673] = Y18673;
	egc_routines_gen_types [18673] = Y18673_gen_type;
	egc_routines_offset [18673] = 2389;
	Y18673_gen_type [0] = Y18673_pgtype0;
	Y18673_gen_type [1] = Y18673_pgtype1;
	Y18673_gen_type [2] = Y18673_pgtype2;
	Y18673_gen_type [3] = Y18673_pgtype3;
	Y18673_gen_type [4] = Y18673_pgtype4;
	Y18673_gen_type [5] = Y18673_pgtype5;
	Y18673_gen_type [6] = Y18673_pgtype6;
	Y18673_gen_type [7] = Y18673_pgtype7;
	Y18673_gen_type [8] = Y18673_pgtype8;
	Y18673_gen_type [9] = Y18673_pgtype9;
	Y18673_gen_type [10] = Y18673_pgtype10;
	{long i; for (i = 0; i < 11; i++) Y18673[i] = 1594;};
}

static EIF_TYPE_INDEX Y18685_pgtype0[] = {2425,0xFFFF};
static EIF_TYPE_INDEX Y18685_pgtype1[] = {2430,0xFFFF};
static EIF_TYPE_INDEX Y18685_pgtype2[] = {2429,0xFFFF};
static EIF_TYPE_INDEX Y18685_pgtype3[] = {2426,0xFFFF};
static EIF_TYPE_INDEX Y18685_pgtype4[] = {2428,0xFFFF};
static EIF_TYPE_INDEX Y18685_pgtype5[] = {2427,0xFFFF};
static EIF_TYPE_INDEX Y18685_pgtype6[] = {2432,0xFFFF};
static EIF_TYPE_INDEX Y18685_pgtype7[] = {2431,0xFFFF};
static EIF_TYPE_INDEX Y18685_pgtype8[] = {2433,0xFFFF};
static EIF_TYPE_INDEX Y18685_pgtype9[] = {2434,0xFFFF};
static EIF_TYPE_INDEX Y18685_pgtype10[] = {2435,0xFFFF};
EIF_TYPE_INDEX *Y18685_gen_type [11];
EIF_TYPE_INDEX Y18685 [11];
void Y18685_init (void)
{
	egc_routines_types [18685] = Y18685;
	egc_routines_gen_types [18685] = Y18685_gen_type;
	egc_routines_offset [18685] = 2389;
	Y18685_gen_type [0] = Y18685_pgtype0;
	Y18685_gen_type [1] = Y18685_pgtype1;
	Y18685_gen_type [2] = Y18685_pgtype2;
	Y18685_gen_type [3] = Y18685_pgtype3;
	Y18685_gen_type [4] = Y18685_pgtype4;
	Y18685_gen_type [5] = Y18685_pgtype5;
	Y18685_gen_type [6] = Y18685_pgtype6;
	Y18685_gen_type [7] = Y18685_pgtype7;
	Y18685_gen_type [8] = Y18685_pgtype8;
	Y18685_gen_type [9] = Y18685_pgtype9;
	Y18685_gen_type [10] = Y18685_pgtype10;
	Y18685[0] = 2425;
	Y18685[1] = 2430;
	Y18685[2] = 2429;
	Y18685[3] = 2426;
	Y18685[4] = 2428;
	Y18685[5] = 2427;
	Y18685[6] = 2432;
	Y18685[7] = 2431;
	Y18685[8] = 2433;
	Y18685[9] = 2434;
	Y18685[10] = 2435;
}

static EIF_TYPE_INDEX Y18689_pgtype0[] = {2425,0xFFFF};
static EIF_TYPE_INDEX Y18689_pgtype1[] = {2430,0xFFFF};
static EIF_TYPE_INDEX Y18689_pgtype2[] = {2429,0xFFFF};
static EIF_TYPE_INDEX Y18689_pgtype3[] = {2426,0xFFFF};
static EIF_TYPE_INDEX Y18689_pgtype4[] = {2428,0xFFFF};
static EIF_TYPE_INDEX Y18689_pgtype5[] = {2427,0xFFFF};
static EIF_TYPE_INDEX Y18689_pgtype6[] = {2432,0xFFFF};
static EIF_TYPE_INDEX Y18689_pgtype7[] = {2431,0xFFFF};
static EIF_TYPE_INDEX Y18689_pgtype8[] = {2433,0xFFFF};
static EIF_TYPE_INDEX Y18689_pgtype9[] = {2434,0xFFFF};
static EIF_TYPE_INDEX Y18689_pgtype10[] = {2435,0xFFFF};
EIF_TYPE_INDEX *Y18689_gen_type [11];
EIF_TYPE_INDEX Y18689 [11];
void Y18689_init (void)
{
	egc_routines_types [18689] = Y18689;
	egc_routines_gen_types [18689] = Y18689_gen_type;
	egc_routines_offset [18689] = 2389;
	Y18689_gen_type [0] = Y18689_pgtype0;
	Y18689_gen_type [1] = Y18689_pgtype1;
	Y18689_gen_type [2] = Y18689_pgtype2;
	Y18689_gen_type [3] = Y18689_pgtype3;
	Y18689_gen_type [4] = Y18689_pgtype4;
	Y18689_gen_type [5] = Y18689_pgtype5;
	Y18689_gen_type [6] = Y18689_pgtype6;
	Y18689_gen_type [7] = Y18689_pgtype7;
	Y18689_gen_type [8] = Y18689_pgtype8;
	Y18689_gen_type [9] = Y18689_pgtype9;
	Y18689_gen_type [10] = Y18689_pgtype10;
	Y18689[0] = 2425;
	Y18689[1] = 2430;
	Y18689[2] = 2429;
	Y18689[3] = 2426;
	Y18689[4] = 2428;
	Y18689[5] = 2427;
	Y18689[6] = 2432;
	Y18689[7] = 2431;
	Y18689[8] = 2433;
	Y18689[9] = 2434;
	Y18689[10] = 2435;
}

EIF_TYPE_INDEX *Y18777_gen_type [22];
EIF_TYPE_INDEX Y18777 [22];
void Y18777_init (void)
{
	egc_routines_types [18777] = Y18777;
	egc_routines_gen_types [18777] = Y18777_gen_type;
	egc_routines_offset [18777] = 2425;
	Y18777[0] = 2384;
	Y18777[1] = 2605;
	Y18777[2] = 2607;
	Y18777[3] = 2608;
	Y18777[4] = 2603;
	Y18777[5] = 2385;
	Y18777[6] = 2388;
	Y18777[7] = 2386;
	Y18777[8] = 2387;
	Y18777[9] = 2846;
	Y18777[10] = 2609;
	Y18777[11] = 2384;
	Y18777[12] = 2386;
	Y18777[13] = 2605;
	Y18777[14] = 2607;
	Y18777[15] = 2608;
	Y18777[16] = 2603;
	Y18777[17] = 2385;
	Y18777[18] = 2609;
	Y18777[19] = 2846;
	Y18777[20] = 2387;
	Y18777[21] = 2388;
}

long O20190[2];
void O20190_init () {
	O20190[0] = + _LNGOFF_1_3_0_7_;
	O20190[1] = + _LNGOFF_1_4_0_7_;
}

long O20258[3];
void O20258_init () {
	O20258[0] = + _CHROFF_14_0_;
	O20258[1] = + _CHROFF_15_0_;
	O20258[2] = + _CHROFF_16_0_;
}

long O20259[3];
void O20259_init () {
	O20259[0] = + _CHROFF_14_1_;
	O20259[1] = + _CHROFF_15_1_;
	O20259[2] = + _CHROFF_16_1_;
}

long O20260[3];
void O20260_init () {
	O20260[0] = + _CHROFF_14_2_;
	O20260[1] = + _CHROFF_15_2_;
	O20260[2] = + _CHROFF_16_2_;
}

long O20261[3];
void O20261_init () {
	O20261[0] = + _CHROFF_14_3_;
	O20261[1] = + _CHROFF_15_3_;
	O20261[2] = + _CHROFF_16_3_;
}

long O20262[3];
void O20262_init () {
	O20262[0] = + _CHROFF_14_4_;
	O20262[1] = + _CHROFF_15_4_;
	O20262[2] = + _CHROFF_16_4_;
}

long O20263[3];
void O20263_init () {
	O20263[0] = + _CHROFF_14_5_;
	O20263[1] = + _CHROFF_15_5_;
	O20263[2] = + _CHROFF_16_5_;
}

long O20273[3];
void O20273_init () {
	O20273[0] = + _CHROFF_14_6_;
	O20273[1] = + _CHROFF_15_6_;
	O20273[2] = + _CHROFF_16_6_;
}

long O20308[3];
void O20308_init () {
	O20308[0] = + _CHROFF_14_7_;
	O20308[1] = + _CHROFF_15_7_;
	O20308[2] = + _CHROFF_16_7_;
}

long O20324[715];
void O20324_init () {
	{long i; for (i = 0; i < 2; i++) O20324[i] = 0;}
	O20324[333] =  + _REFACS_5_;
	O20324[714] =  + _REFACS_5_;
}

long O20328[715];
void O20328_init () {
	{long i; for (i = 0; i < 2; i++) O20328[i] =  + _REFACS_1_;}
	O20328[333] =  + _REFACS_6_;
	O20328[714] =  + _REFACS_6_;
}

long O20351[579];
void O20351_init () {
	O20351[0] = + _CHROFF_53_0_;
	O20351[1] = + _CHROFF_56_0_;
	{long i; for (i = 564; i < 579; i++) O20351[i] = + _CHROFF_54_0_;}
}

long O20353[579];
void O20353_init () {
	O20353[0] = + _CHROFF_53_1_;
	O20353[1] = + _CHROFF_56_1_;
	{long i; for (i = 564; i < 579; i++) O20353[i] = + _CHROFF_54_1_;}
}

long O20354[579];
void O20354_init () {
	O20354[0] = + _CHROFF_53_2_;
	O20354[1] = + _CHROFF_56_2_;
	{long i; for (i = 564; i < 579; i++) O20354[i] = + _CHROFF_54_2_;}
}

long O20355[579];
void O20355_init () {
	O20355[0] = + _CHROFF_53_3_;
	O20355[1] = + _CHROFF_56_3_;
	{long i; for (i = 564; i < 579; i++) O20355[i] = + _CHROFF_54_3_;}
}

long O20358[579];
void O20358_init () {
	O20358[0] = + _CHROFF_53_4_;
	O20358[1] = + _CHROFF_56_4_;
	{long i; for (i = 564; i < 579; i++) O20358[i] = + _CHROFF_54_4_;}
}

long O20361[579];
void O20361_init () {
	O20361[0] = + _CHROFF_53_5_;
	O20361[1] = + _CHROFF_56_5_;
	{long i; for (i = 564; i < 579; i++) O20361[i] = + _CHROFF_54_5_;}
}


#ifdef __cplusplus
}
#endif
