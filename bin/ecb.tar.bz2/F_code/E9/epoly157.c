#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O21691[255];
void O21691_init () {
	{long i; for (i = 0; i < 3; i++) O21691[i] = + _CHROFF_0_0_;}
	O21691[3] = + _CHROFF_4_0_;
	{long i; for (i = 4; i < 19; i++) O21691[i] = + _CHROFF_0_0_;}
	O21691[19] = + _CHROFF_1_0_;
	O21691[20] = + _CHROFF_4_0_;
	{long i; for (i = 21; i < 24; i++) O21691[i] = + _CHROFF_1_0_;}
	O21691[24] = + _CHROFF_3_0_;
	O21691[25] = + _CHROFF_2_0_;
	{long i; for (i = 250; i < 254; i++) O21691[i] = + _CHROFF_1_0_;}
	O21691[254] = + _CHROFF_2_0_;
}

long O21793[255];
void O21793_init () {
	{long i; for (i = 0; i < 3; i++) O21793[i] = + _CHROFF_0_1_;}
	O21793[3] = + _CHROFF_4_2_;
	{long i; for (i = 4; i < 6; i++) O21793[i] = + _CHROFF_0_1_;}
	{long i; for (i = 6; i < 8; i++) O21793[i] = + _CHROFF_0_4_;}
	{long i; for (i = 8; i < 10; i++) O21793[i] = + _CHROFF_0_1_;}
	O21793[10] = + _CHROFF_0_2_;
	{long i; for (i = 11; i < 18; i++) O21793[i] = + _CHROFF_0_1_;}
	O21793[18] = + _CHROFF_0_2_;
	O21793[19] = + _CHROFF_1_1_;
	O21793[20] = + _CHROFF_4_1_;
	{long i; for (i = 21; i < 24; i++) O21793[i] = + _CHROFF_1_1_;}
	O21793[24] = + _CHROFF_3_1_;
	O21793[25] = + _CHROFF_2_1_;
	{long i; for (i = 250; i < 254; i++) O21793[i] = + _CHROFF_1_1_;}
	O21793[254] = + _CHROFF_2_1_;
}

long O21798[255];
void O21798_init () {
	{long i; for (i = 0; i < 3; i++) O21798[i] = + _CHROFF_0_2_;}
	O21798[3] = + _CHROFF_4_3_;
	{long i; for (i = 4; i < 6; i++) O21798[i] = + _CHROFF_0_2_;}
	{long i; for (i = 6; i < 8; i++) O21798[i] = + _CHROFF_0_5_;}
	{long i; for (i = 8; i < 10; i++) O21798[i] = + _CHROFF_0_2_;}
	O21798[10] = + _CHROFF_0_3_;
	{long i; for (i = 11; i < 18; i++) O21798[i] = + _CHROFF_0_2_;}
	O21798[18] = + _CHROFF_0_3_;
	O21798[19] = + _CHROFF_1_2_;
	O21798[20] = + _CHROFF_4_2_;
	{long i; for (i = 21; i < 24; i++) O21798[i] = + _CHROFF_1_2_;}
	O21798[24] = + _CHROFF_3_2_;
	O21798[25] = + _CHROFF_2_2_;
	{long i; for (i = 250; i < 254; i++) O21798[i] = + _CHROFF_1_2_;}
	O21798[254] = + _CHROFF_2_2_;
}

EIF_TYPE_INDEX *Y21804_gen_type [1];
EIF_TYPE_INDEX Y21804 [1];
void Y21804_init (void)
{
	egc_routines_types [21804] = Y21804;
	egc_routines_gen_types [21804] = Y21804_gen_type;
	egc_routines_offset [21804] = 2615;
	Y21804[0] = 2055;
}

long O21852[247];
void O21852_init () {
	{long i; for (i = 0; i < 2; i++) O21852[i] = + _LNGOFF_0_5_0_0_;}
	O21852[2] = + _LNGOFF_0_6_0_0_;
	{long i; for (i = 3; i < 5; i++) O21852[i] = + _LNGOFF_0_5_0_0_;}
	{long i; for (i = 5; i < 10; i++) O21852[i] = + _LNGOFF_0_6_0_0_;}
	O21852[10] = + _LNGOFF_0_7_0_0_;
	{long i; for (i = 242; i < 246; i++) O21852[i] = + _LNGOFF_1_5_0_0_;}
	O21852[246] = + _LNGOFF_2_5_0_0_;
}

long O21867[247];
void O21867_init () {
	{long i; for (i = 0; i < 2; i++) O21867[i] = + _CHROFF_0_3_;}
	O21867[2] = + _CHROFF_0_4_;
	{long i; for (i = 3; i < 10; i++) O21867[i] = + _CHROFF_0_3_;}
	O21867[10] = + _CHROFF_0_4_;
	{long i; for (i = 242; i < 246; i++) O21867[i] = + _CHROFF_1_3_;}
	O21867[246] = + _CHROFF_2_3_;
}

long O21868[247];
void O21868_init () {
	{long i; for (i = 0; i < 2; i++) O21868[i] = + _CHROFF_0_4_;}
	O21868[2] = + _CHROFF_0_5_;
	{long i; for (i = 3; i < 10; i++) O21868[i] = + _CHROFF_0_4_;}
	O21868[10] = + _CHROFF_0_5_;
	{long i; for (i = 242; i < 246; i++) O21868[i] = + _CHROFF_1_4_;}
	O21868[246] = + _CHROFF_2_4_;
}

long O21885[2];
void O21885_init () {
	O21885[0] = + _CHROFF_0_5_;
	O21885[1] = + _CHROFF_0_6_;
}

long O22005[5];
void O22005_init () {
	O22005[0] = + _LNGOFF_5_2_0_0_;
	O22005[1] = + _LNGOFF_7_2_0_0_;
	{long i; for (i = 2; i < 5; i++) O22005[i] = + _LNGOFF_6_2_0_0_;}
}

long O22006[5];
void O22006_init () {
	O22006[0] = + _LNGOFF_5_2_0_1_;
	O22006[1] = + _LNGOFF_7_2_0_1_;
	{long i; for (i = 2; i < 5; i++) O22006[i] = + _LNGOFF_6_2_0_1_;}
}

long O22007[5];
void O22007_init () {
	O22007[0] = + _LNGOFF_5_2_0_2_;
	O22007[1] = + _LNGOFF_7_2_0_2_;
	{long i; for (i = 2; i < 5; i++) O22007[i] = + _LNGOFF_6_2_0_2_;}
}

long O22010[5];
void O22010_init () {
	O22010[0] = + _CHROFF_5_1_;
	O22010[1] = + _CHROFF_7_1_;
	{long i; for (i = 2; i < 5; i++) O22010[i] = + _CHROFF_6_1_;}
}

long O22022[9];
void O22022_init () {
	O22022[0] = + _LNGOFF_5_2_0_0_;
	O22022[1] = + _LNGOFF_7_2_0_0_;
	{long i; for (i = 2; i < 4; i++) O22022[i] = + _LNGOFF_6_2_0_0_;}
	{long i; for (i = 4; i < 7; i++) O22022[i] = + _LNGOFF_5_3_0_0_;}
	O22022[7] = + _LNGOFF_5_2_0_0_;
	O22022[8] = + _LNGOFF_5_3_0_0_;
}

long O22024[9];
void O22024_init () {
	O22024[0] = + _CHROFF_5_0_;
	O22024[1] = + _CHROFF_7_0_;
	{long i; for (i = 2; i < 4; i++) O22024[i] = + _CHROFF_6_0_;}
	{long i; for (i = 4; i < 9; i++) O22024[i] = + _CHROFF_5_0_;}
}

long O22025[9];
void O22025_init () {
	O22025[0] = + _CHROFF_5_1_;
	O22025[1] = + _CHROFF_7_1_;
	{long i; for (i = 2; i < 4; i++) O22025[i] = + _CHROFF_6_1_;}
	{long i; for (i = 4; i < 9; i++) O22025[i] = + _CHROFF_5_1_;}
}

long O22085[913];
void O22085_init () {
	O22085[0] = + _LNGOFF_2_1_0_0_;
	{long i; for (i = 1; i < 3; i++) O22085[i] = + _LNGOFF_3_1_0_0_;}
	{long i; for (i = 3; i < 5; i++) O22085[i] = + _LNGOFF_2_2_0_0_;}
	O22085[5] = + _LNGOFF_2_1_0_0_;
	O22085[6] = + _LNGOFF_3_2_0_0_;
	O22085[7] = + _LNGOFF_3_1_0_0_;
	O22085[8] = + _LNGOFF_4_1_0_0_;
	O22085[912] = + _LNGOFF_2_2_0_0_;
}

long O22087[913];
void O22087_init () {
	O22087[0] = + _LNGOFF_2_1_0_1_;
	{long i; for (i = 1; i < 3; i++) O22087[i] = + _LNGOFF_3_1_0_1_;}
	{long i; for (i = 3; i < 5; i++) O22087[i] = + _LNGOFF_2_2_0_1_;}
	O22087[5] = + _LNGOFF_2_1_0_1_;
	O22087[6] = + _LNGOFF_3_2_0_1_;
	O22087[7] = + _LNGOFF_3_1_0_1_;
	O22087[8] = + _LNGOFF_4_1_0_1_;
	O22087[912] = + _LNGOFF_2_2_0_1_;
}

long O22088[913];
void O22088_init () {
	O22088[0] = + _CHROFF_2_0_;
	{long i; for (i = 1; i < 3; i++) O22088[i] = + _CHROFF_3_0_;}
	{long i; for (i = 3; i < 6; i++) O22088[i] = + _CHROFF_2_0_;}
	{long i; for (i = 6; i < 8; i++) O22088[i] = + _CHROFF_3_0_;}
	O22088[8] = + _CHROFF_4_0_;
	O22088[912] = + _CHROFF_2_0_;
}

long O22136[2];
void O22136_init () {
	O22136[0] = + _LNGOFF_3_1_0_2_;
	O22136[1] = + _LNGOFF_4_1_0_2_;
}

long O22211[10];
void O22211_init () {
	O22211[0] = + _LNGOFF_0_0_0_0_;
	O22211[1] = + _I64OFF_0_0_0_0_0_0_0_;
	O22211[2] = + _LNGOFF_0_0_0_0_;
	O22211[3] = + _I64OFF_0_0_0_0_0_0_0_;
	{long i; for (i = 4; i < 6; i++) O22211[i] = + _LNGOFF_0_0_0_0_;}
	O22211[6] = + _I64OFF_0_0_0_0_0_0_0_;
	{long i; for (i = 7; i < 9; i++) O22211[i] = + _LNGOFF_0_0_0_0_;}
	O22211[9] = + _I64OFF_0_0_0_0_0_0_0_;
}

static EIF_TYPE_INDEX Y22217_pgtype0[] = {2688,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y22217_pgtype1[] = {2688,2687,0xFFFF};
static EIF_TYPE_INDEX Y22217_pgtype2[] = {2688,2686,0xFFFF};
EIF_TYPE_INDEX *Y22217_gen_type [33];
EIF_TYPE_INDEX Y22217 [33];
void Y22217_init (void)
{
	egc_routines_types [22217] = Y22217;
	egc_routines_gen_types [22217] = Y22217_gen_type;
	egc_routines_offset [22217] = 2684;
	Y22217_gen_type [0] = Y22217_pgtype0;
	Y22217_gen_type [11] = Y22217_pgtype1;
	Y22217_gen_type [32] = Y22217_pgtype2;
	Y22217[0] = 2688;
	Y22217[11] = 2688;
	Y22217[32] = 2688;
}

long O22243[21];
void O22243_init () {
	{long i; for (i = 0; i < 4; i++) O22243[i] = 0;}
	O22243[4] =  + _REFACS_4_;
	{long i; for (i = 5; i < 21; i++) O22243[i] = 0;}
}

long O22245[21];
void O22245_init () {
	{long i; for (i = 0; i < 2; i++) O22245[i] = + _LNGOFF_1_0_0_0_;}
	O22245[2] = + _LNGOFF_4_0_0_0_;
	O22245[3] = + _LNGOFF_2_0_0_0_;
	O22245[4] = + _LNGOFF_5_0_0_0_;
	O22245[5] = + _LNGOFF_4_0_0_0_;
	O22245[6] = + _LNGOFF_3_1_0_0_;
	O22245[7] = + _LNGOFF_3_0_0_0_;
	O22245[8] = + _LNGOFF_2_0_0_0_;
	O22245[9] = + _LNGOFF_3_0_0_0_;
	O22245[10] = + _LNGOFF_4_0_0_0_;
	{long i; for (i = 11; i < 13; i++) O22245[i] = + _LNGOFF_6_0_0_0_;}
	O22245[13] = + _LNGOFF_10_0_0_0_;
	O22245[14] = + _LNGOFF_13_0_0_0_;
	O22245[15] = + _LNGOFF_10_0_0_0_;
	O22245[16] = + _LNGOFF_13_0_0_0_;
	O22245[17] = + _LNGOFF_3_0_0_0_;
	O22245[18] = + _LNGOFF_4_0_0_0_;
	O22245[19] = + _LNGOFF_4_5_0_0_;
	O22245[20] = + _LNGOFF_5_5_0_0_;
}

long O22331[2];
void O22331_init () {
	O22331[0] = + _LNGOFF_10_0_0_1_;
	O22331[1] = + _LNGOFF_13_0_0_1_;
}

long O22345[2];
void O22345_init () {
	O22345[0] = + _CHROFF_4_0_;
	O22345[1] = + _CHROFF_5_0_;
}

long O22346[2];
void O22346_init () {
	O22346[0] = + _CHROFF_4_1_;
	O22346[1] = + _CHROFF_5_1_;
}

long O22347[2];
void O22347_init () {
	O22347[0] = + _CHROFF_4_2_;
	O22347[1] = + _CHROFF_5_2_;
}

long O22348[2];
void O22348_init () {
	O22348[0] = + _CHROFF_4_3_;
	O22348[1] = + _CHROFF_5_3_;
}

long O22349[2];
void O22349_init () {
	O22349[0] = + _CHROFF_4_4_;
	O22349[1] = + _CHROFF_5_4_;
}

long O22350[2];
void O22350_init () {
	O22350[0] = + _LNGOFF_4_5_0_1_;
	O22350[1] = + _LNGOFF_5_5_0_1_;
}

long O22369[2];
void O22369_init () {
	O22369[0] =  + _REFACS_3_;
	O22369[1] =  + _REFACS_4_;
}

long O22471[2];
void O22471_init () {
	O22471[0] = + _CHROFF_1_0_;
	O22471[1] = + _CHROFF_2_0_;
}

long O22472[2];
void O22472_init () {
	O22472[0] = + _CHROFF_1_1_;
	O22472[1] = + _CHROFF_2_1_;
}

long O22473[2];
void O22473_init () {
	O22473[0] = + _CHROFF_1_2_;
	O22473[1] = + _CHROFF_2_2_;
}

long O22489[2];
void O22489_init () {
	O22489[0] = + _LNGOFF_5_3_0_1_;
	O22489[1] = + _LNGOFF_6_3_0_1_;
}

long O22490[2];
void O22490_init () {
	O22490[0] = + _LNGOFF_5_3_0_2_;
	O22490[1] = + _LNGOFF_6_3_0_2_;
}

long O22491[2];
void O22491_init () {
	O22491[0] = + _LNGOFF_5_3_0_3_;
	O22491[1] = + _LNGOFF_6_3_0_3_;
}

long O22495[2];
void O22495_init () {
	O22495[0] = + _CHROFF_5_0_;
	O22495[1] = + _CHROFF_6_0_;
}

long O22496[2];
void O22496_init () {
	O22496[0] = + _CHROFF_5_1_;
	O22496[1] = + _CHROFF_6_1_;
}

long O22497[2];
void O22497_init () {
	O22497[0] = + _CHROFF_5_2_;
	O22497[1] = + _CHROFF_6_2_;
}

long O22514[2];
void O22514_init () {
	O22514[0] = + _LNGOFF_1_3_0_0_;
	O22514[1] = + _LNGOFF_2_3_0_0_;
}

long O22515[2];
void O22515_init () {
	O22515[0] = + _CHROFF_1_0_;
	O22515[1] = + _CHROFF_2_0_;
}

long O22516[2];
void O22516_init () {
	O22516[0] = + _CHROFF_1_1_;
	O22516[1] = + _CHROFF_2_1_;
}

long O22517[2];
void O22517_init () {
	O22517[0] = + _CHROFF_1_2_;
	O22517[1] = + _CHROFF_2_2_;
}

long O22532[2];
void O22532_init () {
	O22532[0] = + _CHROFF_3_0_;
	O22532[1] = + _CHROFF_5_0_;
}

long O22534[2];
void O22534_init () {
	O22534[0] = + _CHROFF_3_1_;
	O22534[1] = + _CHROFF_5_1_;
}

long O22552[2];
void O22552_init () {
	O22552[0] = + _CHROFF_7_0_;
	O22552[1] = + _CHROFF_8_0_;
}

long O22568[2];
void O22568_init () {
	O22568[0] = + _CHROFF_3_0_;
	O22568[1] = + _CHROFF_4_0_;
}

long O22569[2];
void O22569_init () {
	O22569[0] = + _CHROFF_3_1_;
	O22569[1] = + _CHROFF_4_1_;
}

long O22673[2];
void O22673_init () {
	O22673[0] = + _LNGOFF_4_0_0_0_;
	O22673[1] = + _LNGOFF_6_0_0_0_;
}

long O22676[2];
void O22676_init () {
	O22676[0] = + _LNGOFF_4_0_0_1_;
	O22676[1] = + _LNGOFF_6_0_0_1_;
}

long O22687[6];
void O22687_init () {
	O22687[0] = + _LNGOFF_2_0_0_0_;
	{long i; for (i = 1; i < 6; i++) O22687[i] = + _LNGOFF_3_0_0_0_;}
}

long O22709[5];
void O22709_init () {
	{long i; for (i = 0; i < 4; i++) O22709[i] = + _LNGOFF_2_0_0_0_;}
	O22709[4] = + _LNGOFF_4_0_0_0_;
}

EIF_TYPE_INDEX *Y22757_gen_type [8];
EIF_TYPE_INDEX Y22757 [8];
void Y22757_init (void)
{
	egc_routines_types [22757] = Y22757;
	egc_routines_gen_types [22757] = Y22757_gen_type;
	egc_routines_offset [22757] = 2811;
	{long i; for (i = 0; i < 5; i++) Y22757[i] = 2712;};
	Y22757[5] = 2749;
	{long i; for (i = 6; i < 8; i++) Y22757[i] = 2712;};
}

long O22766[2];
void O22766_init () {
	O22766[0] = + _LNGOFF_2_0_0_0_;
	O22766[1] = + _LNGOFF_4_0_0_0_;
}

long O22768[2];
void O22768_init () {
	O22768[0] = + _LNGOFF_2_0_0_1_;
	O22768[1] = + _LNGOFF_4_0_0_1_;
}

long O22776[11];
void O22776_init () {
	{long i; for (i = 0; i < 7; i++) O22776[i] = + _LNGOFF_0_0_0_0_;}
	O22776[7] = + _LNGOFF_1_0_0_0_;
	O22776[8] = + _LNGOFF_0_0_0_0_;
	O22776[9] = + _LNGOFF_3_0_0_0_;
	O22776[10] = + _LNGOFF_1_0_0_0_;
}

long O22777[11];
void O22777_init () {
	{long i; for (i = 0; i < 7; i++) O22777[i] = + _LNGOFF_0_0_0_1_;}
	O22777[7] = + _LNGOFF_1_0_0_1_;
	O22777[8] = + _LNGOFF_0_0_0_1_;
	O22777[9] = + _LNGOFF_3_0_0_1_;
	O22777[10] = + _LNGOFF_1_0_0_1_;
}

long O22779[11];
void O22779_init () {
	{long i; for (i = 0; i < 7; i++) O22779[i] = + _LNGOFF_0_0_0_2_;}
	O22779[7] = + _LNGOFF_1_0_0_2_;
	O22779[8] = + _LNGOFF_0_0_0_2_;
	O22779[9] = + _LNGOFF_3_0_0_2_;
	O22779[10] = + _LNGOFF_1_0_0_2_;
}

long O22796[11];
void O22796_init () {
	{long i; for (i = 0; i < 7; i++) O22796[i] = + _LNGOFF_0_0_0_3_;}
	O22796[7] = + _LNGOFF_1_0_0_3_;
	O22796[8] = + _LNGOFF_0_0_0_3_;
	O22796[9] = + _LNGOFF_3_0_0_3_;
	O22796[10] = + _LNGOFF_1_0_0_3_;
}

long O22925[36];
void O22925_init () {
	O22925[0] = + _LNGOFF_4_0_0_0_;
	O22925[1] = + _LNGOFF_4_2_0_0_;
	{long i; for (i = 2; i < 5; i++) O22925[i] = + _LNGOFF_5_2_0_0_;}
	O22925[5] = + _LNGOFF_5_1_0_0_;
	O22925[6] = + _LNGOFF_6_2_0_0_;
	O22925[7] = + _LNGOFF_8_1_0_0_;
	O22925[8] = + _LNGOFF_10_2_0_0_;
	{long i; for (i = 22; i < 24; i++) O22925[i] = + _LNGOFF_5_4_0_0_;}
	O22925[24] = + _LNGOFF_6_6_0_0_;
	O22925[25] = + _LNGOFF_5_5_0_0_;
	O22925[26] = + _LNGOFF_8_4_0_0_;
	O22925[27] = + _LNGOFF_9_6_0_0_;
	O22925[28] = + _LNGOFF_11_4_0_0_;
	{long i; for (i = 29; i < 31; i++) O22925[i] = + _LNGOFF_8_4_0_0_;}
	{long i; for (i = 31; i < 33; i++) O22925[i] = + _LNGOFF_9_4_0_0_;}
	O22925[33] = + _LNGOFF_16_8_0_0_;
	{long i; for (i = 34; i < 36; i++) O22925[i] = + _LNGOFF_18_5_0_0_;}
}

long O22926[36];
void O22926_init () {
	O22926[0] = + _LNGOFF_4_0_0_1_;
	O22926[1] = + _LNGOFF_4_2_0_1_;
	{long i; for (i = 2; i < 5; i++) O22926[i] = + _LNGOFF_5_2_0_1_;}
	O22926[5] = + _LNGOFF_5_1_0_1_;
	O22926[6] = + _LNGOFF_6_2_0_1_;
	O22926[7] = + _LNGOFF_8_1_0_1_;
	O22926[8] = + _LNGOFF_10_2_0_1_;
	{long i; for (i = 22; i < 24; i++) O22926[i] = + _LNGOFF_5_4_0_1_;}
	O22926[24] = + _LNGOFF_6_6_0_1_;
	O22926[25] = + _LNGOFF_5_5_0_1_;
	O22926[26] = + _LNGOFF_8_4_0_1_;
	O22926[27] = + _LNGOFF_9_6_0_1_;
	O22926[28] = + _LNGOFF_11_4_0_1_;
	{long i; for (i = 29; i < 31; i++) O22926[i] = + _LNGOFF_8_4_0_1_;}
	{long i; for (i = 31; i < 33; i++) O22926[i] = + _LNGOFF_9_4_0_1_;}
	O22926[33] = + _LNGOFF_16_8_0_1_;
	{long i; for (i = 34; i < 36; i++) O22926[i] = + _LNGOFF_18_5_0_1_;}
}

long O22927[36];
void O22927_init () {
	O22927[0] = + _LNGOFF_4_0_0_2_;
	O22927[1] = + _LNGOFF_4_2_0_2_;
	{long i; for (i = 2; i < 5; i++) O22927[i] = + _LNGOFF_5_2_0_2_;}
	O22927[5] = + _LNGOFF_5_1_0_2_;
	O22927[6] = + _LNGOFF_6_2_0_2_;
	O22927[7] = + _LNGOFF_8_1_0_2_;
	O22927[8] = + _LNGOFF_10_2_0_2_;
	{long i; for (i = 22; i < 24; i++) O22927[i] = + _LNGOFF_5_4_0_2_;}
	O22927[24] = + _LNGOFF_6_6_0_2_;
	O22927[25] = + _LNGOFF_5_5_0_2_;
	O22927[26] = + _LNGOFF_8_4_0_2_;
	O22927[27] = + _LNGOFF_9_6_0_2_;
	O22927[28] = + _LNGOFF_11_4_0_2_;
	{long i; for (i = 29; i < 31; i++) O22927[i] = + _LNGOFF_8_4_0_2_;}
	{long i; for (i = 31; i < 33; i++) O22927[i] = + _LNGOFF_9_4_0_2_;}
	O22927[33] = + _LNGOFF_16_8_0_2_;
	{long i; for (i = 34; i < 36; i++) O22927[i] = + _LNGOFF_18_5_0_2_;}
}

long O22928[36];
void O22928_init () {
	O22928[0] = + _LNGOFF_4_0_0_3_;
	O22928[1] = + _LNGOFF_4_2_0_3_;
	{long i; for (i = 2; i < 5; i++) O22928[i] = + _LNGOFF_5_2_0_3_;}
	O22928[5] = + _LNGOFF_5_1_0_3_;
	O22928[6] = + _LNGOFF_6_2_0_3_;
	O22928[7] = + _LNGOFF_8_1_0_3_;
	O22928[8] = + _LNGOFF_10_2_0_3_;
	{long i; for (i = 22; i < 24; i++) O22928[i] = + _LNGOFF_5_4_0_3_;}
	O22928[24] = + _LNGOFF_6_6_0_3_;
	O22928[25] = + _LNGOFF_5_5_0_3_;
	O22928[26] = + _LNGOFF_8_4_0_3_;
	O22928[27] = + _LNGOFF_9_6_0_3_;
	O22928[28] = + _LNGOFF_11_4_0_3_;
	{long i; for (i = 29; i < 31; i++) O22928[i] = + _LNGOFF_8_4_0_3_;}
	{long i; for (i = 31; i < 33; i++) O22928[i] = + _LNGOFF_9_4_0_3_;}
	O22928[33] = + _LNGOFF_16_8_0_3_;
	{long i; for (i = 34; i < 36; i++) O22928[i] = + _LNGOFF_18_5_0_3_;}
}

long O22951[4];
void O22951_init () {
	O22951[0] = + _CHROFF_4_0_;
	{long i; for (i = 1; i < 4; i++) O22951[i] = + _CHROFF_5_0_;}
}

long O22954[4];
void O22954_init () {
	O22954[0] = + _CHROFF_4_1_;
	{long i; for (i = 1; i < 4; i++) O22954[i] = + _CHROFF_5_1_;}
}

long O22965[31];
void O22965_init () {
	O22965[0] = + _CHROFF_5_0_;
	O22965[1] = + _CHROFF_6_0_;
	O22965[2] = + _CHROFF_8_0_;
	O22965[3] = + _CHROFF_10_0_;
	{long i; for (i = 17; i < 19; i++) O22965[i] = + _CHROFF_5_0_;}
	O22965[19] = + _CHROFF_6_0_;
	O22965[20] = + _CHROFF_5_0_;
	O22965[21] = + _CHROFF_8_0_;
	O22965[22] = + _CHROFF_9_0_;
	O22965[23] = + _CHROFF_11_0_;
	{long i; for (i = 24; i < 26; i++) O22965[i] = + _CHROFF_8_0_;}
	{long i; for (i = 26; i < 28; i++) O22965[i] = + _CHROFF_9_0_;}
	O22965[28] = + _CHROFF_16_0_;
	{long i; for (i = 29; i < 31; i++) O22965[i] = + _CHROFF_18_0_;}
}

long O22967[3];
void O22967_init () {
	O22967[0] = + _LNGOFF_6_2_0_4_;
	O22967[2] = + _LNGOFF_10_2_0_4_;
}

long O22968[3];
void O22968_init () {
	O22968[0] = + _CHROFF_6_1_;
	O22968[2] = + _CHROFF_10_1_;
}

long O22978[29];
void O22978_init () {
	O22978[0] =  + _REFACS_5_;
	O22978[1] =  + _REFACS_6_;
	{long i; for (i = 19; i < 29; i++) O22978[i] =  + _REFACS_5_;}
}

long O22986[29];
void O22986_init () {
	O22986[0] = + _LNGOFF_8_1_0_4_;
	O22986[1] = + _LNGOFF_10_2_0_5_;
	O22986[19] = + _LNGOFF_8_4_0_4_;
	O22986[20] = + _LNGOFF_9_6_0_4_;
	O22986[21] = + _LNGOFF_11_4_0_4_;
	{long i; for (i = 22; i < 24; i++) O22986[i] = + _LNGOFF_8_4_0_4_;}
	{long i; for (i = 24; i < 26; i++) O22986[i] = + _LNGOFF_9_4_0_4_;}
	O22986[26] = + _LNGOFF_16_8_0_4_;
	{long i; for (i = 27; i < 29; i++) O22986[i] = + _LNGOFF_18_5_0_4_;}
}

long O22987[29];
void O22987_init () {
	O22987[0] =  + _REFACS_6_;
	O22987[1] =  + _REFACS_7_;
	{long i; for (i = 19; i < 29; i++) O22987[i] =  + _REFACS_6_;}
}

long O22988[29];
void O22988_init () {
	O22988[0] =  + _REFACS_7_;
	O22988[1] =  + _REFACS_8_;
	{long i; for (i = 19; i < 29; i++) O22988[i] =  + _REFACS_7_;}
}

long O23018[8];
void O23018_init () {
	{long i; for (i = 0; i < 3; i++) O23018[i] = + _LNGOFF_12_2_0_1_;}
	O23018[3] = + _LNGOFF_13_2_0_1_;
	O23018[4] = + _LNGOFF_13_3_0_1_;
	O23018[5] = + _LNGOFF_13_2_0_1_;
	{long i; for (i = 6; i < 8; i++) O23018[i] = + _LNGOFF_13_4_0_1_;}
}

long O23019[8];
void O23019_init () {
	{long i; for (i = 0; i < 3; i++) O23019[i] = + _LNGOFF_12_2_0_2_;}
	O23019[3] = + _LNGOFF_13_2_0_2_;
	O23019[4] = + _LNGOFF_13_3_0_2_;
	O23019[5] = + _LNGOFF_13_2_0_2_;
	{long i; for (i = 6; i < 8; i++) O23019[i] = + _LNGOFF_13_4_0_2_;}
}

long O23020[8];
void O23020_init () {
	{long i; for (i = 0; i < 3; i++) O23020[i] = + _LNGOFF_12_2_0_3_;}
	O23020[3] = + _LNGOFF_13_2_0_3_;
	O23020[4] = + _LNGOFF_13_3_0_3_;
	O23020[5] = + _LNGOFF_13_2_0_3_;
	{long i; for (i = 6; i < 8; i++) O23020[i] = + _LNGOFF_13_4_0_3_;}
}

long O23022[8];
void O23022_init () {
	{long i; for (i = 0; i < 3; i++) O23022[i] = + _LNGOFF_12_2_0_4_;}
	O23022[3] = + _LNGOFF_13_2_0_4_;
	O23022[4] = + _LNGOFF_13_3_0_4_;
	O23022[5] = + _LNGOFF_13_2_0_4_;
	{long i; for (i = 6; i < 8; i++) O23022[i] = + _LNGOFF_13_4_0_4_;}
}

long O23023[8];
void O23023_init () {
	{long i; for (i = 0; i < 3; i++) O23023[i] = + _LNGOFF_12_2_0_5_;}
	O23023[3] = + _LNGOFF_13_2_0_5_;
	O23023[4] = + _LNGOFF_13_3_0_5_;
	O23023[5] = + _LNGOFF_13_2_0_5_;
	{long i; for (i = 6; i < 8; i++) O23023[i] = + _LNGOFF_13_4_0_5_;}
}

long O23024[8];
void O23024_init () {
	{long i; for (i = 0; i < 3; i++) O23024[i] = + _LNGOFF_12_2_0_6_;}
	O23024[3] = + _LNGOFF_13_2_0_6_;
	O23024[4] = + _LNGOFF_13_3_0_6_;
	O23024[5] = + _LNGOFF_13_2_0_6_;
	{long i; for (i = 6; i < 8; i++) O23024[i] = + _LNGOFF_13_4_0_6_;}
}

long O23028[8];
void O23028_init () {
	{long i; for (i = 0; i < 3; i++) O23028[i] = + _LNGOFF_12_2_0_7_;}
	O23028[3] = + _LNGOFF_13_2_0_7_;
	O23028[4] = + _LNGOFF_13_3_0_7_;
	O23028[5] = + _LNGOFF_13_2_0_7_;
	{long i; for (i = 6; i < 8; i++) O23028[i] = + _LNGOFF_13_4_0_7_;}
}

long O23033[8];
void O23033_init () {
	{long i; for (i = 0; i < 3; i++) O23033[i] = + _LNGOFF_12_2_0_8_;}
	O23033[3] = + _LNGOFF_13_2_0_8_;
	O23033[4] = + _LNGOFF_13_3_0_8_;
	O23033[5] = + _LNGOFF_13_2_0_8_;
	{long i; for (i = 6; i < 8; i++) O23033[i] = + _LNGOFF_13_4_0_8_;}
}

long O23045[8];
void O23045_init () {
	{long i; for (i = 0; i < 3; i++) O23045[i] = + _LNGOFF_12_2_0_9_;}
	O23045[3] = + _LNGOFF_13_2_0_9_;
	O23045[4] = + _LNGOFF_13_3_0_9_;
	O23045[5] = + _LNGOFF_13_2_0_9_;
	{long i; for (i = 6; i < 8; i++) O23045[i] = + _LNGOFF_13_4_0_9_;}
}

long O23088[8];
void O23088_init () {
	{long i; for (i = 0; i < 3; i++) O23088[i] = + _CHROFF_12_0_;}
	{long i; for (i = 3; i < 8; i++) O23088[i] = + _CHROFF_13_0_;}
}

long O23091[8];
void O23091_init () {
	{long i; for (i = 0; i < 3; i++) O23091[i] = + _CHROFF_12_1_;}
	{long i; for (i = 3; i < 8; i++) O23091[i] = + _CHROFF_13_1_;}
}

long O23174[14];
void O23174_init () {
	{long i; for (i = 0; i < 2; i++) O23174[i] = + _CHROFF_5_1_;}
	O23174[2] = + _CHROFF_6_1_;
	O23174[3] = + _CHROFF_5_1_;
	O23174[4] = + _CHROFF_8_1_;
	O23174[5] = + _CHROFF_9_1_;
	O23174[6] = + _CHROFF_11_1_;
	{long i; for (i = 7; i < 9; i++) O23174[i] = + _CHROFF_8_1_;}
	{long i; for (i = 9; i < 11; i++) O23174[i] = + _CHROFF_9_1_;}
	O23174[11] = + _CHROFF_16_1_;
	{long i; for (i = 12; i < 14; i++) O23174[i] = + _CHROFF_18_1_;}
}

long O23175[14];
void O23175_init () {
	{long i; for (i = 0; i < 2; i++) O23175[i] = + _CHROFF_5_2_;}
	O23175[2] = + _CHROFF_6_2_;
	O23175[3] = + _CHROFF_5_2_;
	O23175[4] = + _CHROFF_8_2_;
	O23175[5] = + _CHROFF_9_2_;
	O23175[6] = + _CHROFF_11_2_;
	{long i; for (i = 7; i < 9; i++) O23175[i] = + _CHROFF_8_2_;}
	{long i; for (i = 9; i < 11; i++) O23175[i] = + _CHROFF_9_2_;}
	O23175[11] = + _CHROFF_16_2_;
	{long i; for (i = 12; i < 14; i++) O23175[i] = + _CHROFF_18_2_;}
}

long O23176[14];
void O23176_init () {
	{long i; for (i = 0; i < 2; i++) O23176[i] = + _CHROFF_5_3_;}
	O23176[2] = + _CHROFF_6_3_;
	O23176[3] = + _CHROFF_5_3_;
	O23176[4] = + _CHROFF_8_3_;
	O23176[5] = + _CHROFF_9_3_;
	O23176[6] = + _CHROFF_11_3_;
	{long i; for (i = 7; i < 9; i++) O23176[i] = + _CHROFF_8_3_;}
	{long i; for (i = 9; i < 11; i++) O23176[i] = + _CHROFF_9_3_;}
	O23176[11] = + _CHROFF_16_3_;
	{long i; for (i = 12; i < 14; i++) O23176[i] = + _CHROFF_18_3_;}
}

long O23180[4];
void O23180_init () {
	O23180[0] =  + _REFACS_5_;
	O23180[3] =  + _REFACS_8_;
}

long O23181[4];
void O23181_init () {
	O23181[0] = + _CHROFF_6_4_;
	O23181[3] = + _CHROFF_9_4_;
}

long O23182[4];
void O23182_init () {
	O23182[0] = + _CHROFF_6_5_;
	O23182[3] = + _CHROFF_9_5_;
}

long O23184[9];
void O23184_init () {
	O23184[0] = + _CHROFF_5_4_;
	O23184[8] = + _CHROFF_16_4_;
}

long O23605[884];
void O23605_init () {
	O23605[0] = + _LNGOFF_1_1_0_1_;
	O23605[1] = + _LNGOFF_5_2_0_1_;
	O23605[2] = + _LNGOFF_14_3_0_1_;
	{long i; for (i = 3; i < 5; i++) O23605[i] = + _LNGOFF_16_4_0_1_;}
	{long i; for (i = 5; i < 7; i++) O23605[i] = + _LNGOFF_18_6_0_1_;}
	O23605[676] = + _LNGOFF_19_4_0_1_;
	{long i; for (i = 678; i < 680; i++) O23605[i] = + _LNGOFF_41_6_0_1_;}
	O23605[680] = + _LNGOFF_41_7_0_1_;
	O23605[682] = + _LNGOFF_31_5_0_1_;
	O23605[683] = + _LNGOFF_49_5_0_1_;
	O23605[684] = + _LNGOFF_81_27_0_1_;
	O23605[685] = + _LNGOFF_351_27_0_1_;
	O23605[883] = + _LNGOFF_353_28_0_1_;
}

long O23684[883];
void O23684_init () {
	O23684[0] = + _LNGOFF_5_2_0_2_;
	O23684[1] = + _LNGOFF_14_3_0_2_;
	{long i; for (i = 2; i < 4; i++) O23684[i] = + _LNGOFF_16_4_0_2_;}
	{long i; for (i = 4; i < 6; i++) O23684[i] = + _LNGOFF_18_6_0_2_;}
	O23684[675] = + _LNGOFF_19_4_0_2_;
	{long i; for (i = 677; i < 679; i++) O23684[i] = + _LNGOFF_41_6_0_2_;}
	O23684[679] = + _LNGOFF_41_7_0_2_;
	O23684[681] = + _LNGOFF_31_5_0_2_;
	O23684[682] = + _LNGOFF_49_5_0_2_;
	O23684[683] = + _LNGOFF_81_27_0_2_;
	O23684[684] = + _LNGOFF_351_27_0_2_;
	O23684[882] = + _LNGOFF_353_28_0_2_;
}

long O23688[883];
void O23688_init () {
	O23688[0] = + _LNGOFF_5_2_0_3_;
	O23688[1] = + _LNGOFF_14_3_0_3_;
	{long i; for (i = 2; i < 4; i++) O23688[i] = + _LNGOFF_16_4_0_3_;}
	{long i; for (i = 4; i < 6; i++) O23688[i] = + _LNGOFF_18_6_0_3_;}
	O23688[675] = + _LNGOFF_19_4_0_3_;
	{long i; for (i = 677; i < 679; i++) O23688[i] = + _LNGOFF_41_6_0_3_;}
	O23688[679] = + _LNGOFF_41_7_0_3_;
	O23688[681] = + _LNGOFF_31_5_0_3_;
	O23688[682] = + _LNGOFF_49_5_0_3_;
	O23688[683] = + _LNGOFF_81_27_0_3_;
	O23688[684] = + _LNGOFF_351_27_0_3_;
	O23688[882] = + _LNGOFF_353_28_0_3_;
}

long O23689[883];
void O23689_init () {
	O23689[0] = + _LNGOFF_5_2_0_4_;
	O23689[1] = + _LNGOFF_14_3_0_4_;
	{long i; for (i = 2; i < 4; i++) O23689[i] = + _LNGOFF_16_4_0_4_;}
	{long i; for (i = 4; i < 6; i++) O23689[i] = + _LNGOFF_18_6_0_4_;}
	O23689[675] = + _LNGOFF_19_4_0_4_;
	{long i; for (i = 677; i < 679; i++) O23689[i] = + _LNGOFF_41_6_0_4_;}
	O23689[679] = + _LNGOFF_41_7_0_4_;
	O23689[681] = + _LNGOFF_31_5_0_4_;
	O23689[682] = + _LNGOFF_49_5_0_4_;
	O23689[683] = + _LNGOFF_81_27_0_4_;
	O23689[684] = + _LNGOFF_351_27_0_4_;
	O23689[882] = + _LNGOFF_353_28_0_4_;
}

long O23690[883];
void O23690_init () {
	O23690[0] = + _LNGOFF_5_2_0_5_;
	O23690[1] = + _LNGOFF_14_3_0_5_;
	{long i; for (i = 2; i < 4; i++) O23690[i] = + _LNGOFF_16_4_0_5_;}
	{long i; for (i = 4; i < 6; i++) O23690[i] = + _LNGOFF_18_6_0_5_;}
	O23690[675] = + _LNGOFF_19_4_0_5_;
	{long i; for (i = 677; i < 679; i++) O23690[i] = + _LNGOFF_41_6_0_5_;}
	O23690[679] = + _LNGOFF_41_7_0_5_;
	O23690[681] = + _LNGOFF_31_5_0_5_;
	O23690[682] = + _LNGOFF_49_5_0_5_;
	O23690[683] = + _LNGOFF_81_27_0_5_;
	O23690[684] = + _LNGOFF_351_27_0_5_;
	O23690[882] = + _LNGOFF_353_28_0_5_;
}

long O23691[883];
void O23691_init () {
	O23691[0] = + _LNGOFF_5_2_0_6_;
	O23691[1] = + _LNGOFF_14_3_0_6_;
	{long i; for (i = 2; i < 4; i++) O23691[i] = + _LNGOFF_16_4_0_6_;}
	{long i; for (i = 4; i < 6; i++) O23691[i] = + _LNGOFF_18_6_0_6_;}
	O23691[675] = + _LNGOFF_19_4_0_6_;
	{long i; for (i = 677; i < 679; i++) O23691[i] = + _LNGOFF_41_6_0_6_;}
	O23691[679] = + _LNGOFF_41_7_0_6_;
	O23691[681] = + _LNGOFF_31_5_0_6_;
	O23691[682] = + _LNGOFF_49_5_0_6_;
	O23691[683] = + _LNGOFF_81_27_0_6_;
	O23691[684] = + _LNGOFF_351_27_0_6_;
	O23691[882] = + _LNGOFF_353_28_0_6_;
}


#ifdef __cplusplus
}
#endif
