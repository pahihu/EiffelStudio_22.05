#include "epoly142.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R17156[1567])();
void R17156_init () {
	R17156[0] = (char *(*)()) F2248_22038;
	R17156[1566] = (char *(*)()) F3814_45405;
}

char *(*R17169[2])();
void R17169_init () {
	R17169[0] = (char *(*)()) F2251_22109;
	R17169[1] = (char *(*)()) F2252_22132;
}

char *(*R17180[2])();
void R17180_init () {
	R17180[0] = (char *(*)()) F2251_22112;
	R17180[1] = (char *(*)()) F2252_22183;
}

char *(*R17188[2])();
void R17188_init () {
	R17188[0] = (char *(*)()) F2251_22123;
	R17188[1] = (char *(*)()) F2250_22100;
}

char *(*R17281[6])();
void R17281_init () {
	R17281[0] = (char *(*)()) F2260_22266;
	R17281[1] = (char *(*)()) F2261_22276;
	R17281[2] = (char *(*)()) F2262_22285;
	R17281[3] = (char *(*)()) F2263_22314;
	R17281[4] = (char *(*)()) F2264_22340;
	R17281[5] = (char *(*)()) F2265_22384;
}

char *(*R17409[2])();
void R17409_init () {
	R17409[0] = (char *(*)()) F2269_22438;
	R17409[1] = (char *(*)()) F2270_22507;
}

char *(*R17411[2])();
void R17411_init () {
	R17411[0] = (char *(*)()) F2269_22440;
	R17411[1] = (char *(*)()) F2270_22508;
}

char *(*R17424[2])();
void R17424_init () {
	R17424[0] = (char *(*)()) F2269_22453;
	R17424[1] = (char *(*)()) F2270_22512;
}

char *(*R17429[2])();
void R17429_init () {
	R17429[0] = (char *(*)()) F2269_22458;
	R17429[1] = (char *(*)()) F2270_22517;
}

char *(*R17434[2])();
void R17434_init () {
	R17434[0] = (char *(*)()) F2269_22463;
	R17434[1] = (char *(*)()) F2270_22515;
}

char *(*R17435[2])();
void R17435_init () {
	R17435[0] = (char *(*)()) F2269_22464;
	R17435[1] = (char *(*)()) F2270_22509;
}

char *(*R17436[2])();
void R17436_init () {
	R17436[0] = (char *(*)()) F2269_22465;
	R17436[1] = (char *(*)()) F2270_22510;
}

char *(*R17437[2])();
void R17437_init () {
	R17437[0] = (char *(*)()) F2269_22466;
	R17437[1] = (char *(*)()) F2270_22511;
}

char *(*R17439[2])();
void R17439_init () {
	R17439[0] = (char *(*)()) F2269_22468;
	R17439[1] = (char *(*)()) F2270_22514;
}

char *(*R17443[2])();
void R17443_init () {
	R17443[0] = (char *(*)()) F2269_22472;
	R17443[1] = (char *(*)()) F2270_22513;
}

char *(*R17449[2])();
void R17449_init () {
	R17449[0] = (char *(*)()) F2269_22478;
	R17449[1] = (char *(*)()) F2270_22516;
}

char *(*R18161[136])();
void R18161_init () {
	R18161[0] = (char *(*)()) F2314_23302;
	R18161[134] = (char *(*)()) F2314_23302;
	R18161[135] = (char *(*)()) F2450_24637;
}

char *(*R18170[2])();
void R18170_init () {
	R18170[0] = (char *(*)()) F2317_23322;
	R18170[1] = (char *(*)()) F2318_23327;
}

char *(*R18184[161])();
void R18184_init () {
	R18184[0] = (char *(*)()) F2320_23371;
	R18184[2] = (char *(*)()) F2323_23393;
	R18184[3] = (char *(*)()) F2324_23408;
	R18184[4] = (char *(*)()) F2325_23441;
	R18184[5] = (char *(*)()) F2326_23445;
	R18184[6] = (char *(*)()) F2327_23447;
	R18184[7] = (char *(*)()) F2328_23449;
	R18184[8] = (char *(*)()) F2329_23451;
	R18184[9] = (char *(*)()) F2330_23453;
	R18184[10] = (char *(*)()) F2331_23461;
	R18184[11] = (char *(*)()) F2332_23463;
	R18184[12] = (char *(*)()) F2333_23469;
	R18184[13] = (char *(*)()) F2334_23471;
	R18184[14] = (char *(*)()) F2335_23478;
	R18184[15] = (char *(*)()) F2336_23489;
	R18184[16] = (char *(*)()) F2337_23495;
	R18184[17] = (char *(*)()) F2338_23497;
	R18184[18] = (char *(*)()) F2339_23499;
	R18184[19] = (char *(*)()) F2340_23505;
	R18184[20] = (char *(*)()) F2341_23507;
	R18184[21] = (char *(*)()) F2342_23512;
	R18184[160] = (char *(*)()) F2481_25470;
}

char *(*R18185[161])();
void R18185_init () {
	R18185[0] = (char *(*)()) F2321_23372;
	R18185[2] = (char *(*)()) F2323_23392;
	R18185[3] = (char *(*)()) F2324_23404;
	R18185[4] = (char *(*)()) F2325_23432;
	R18185[5] = (char *(*)()) F2326_23444;
	R18185[6] = (char *(*)()) F2327_23446;
	R18185[7] = (char *(*)()) F2328_23448;
	R18185[8] = (char *(*)()) F2329_23450;
	R18185[9] = (char *(*)()) F2330_23452;
	R18185[10] = (char *(*)()) F2331_23460;
	R18185[11] = (char *(*)()) F2332_23462;
	R18185[12] = (char *(*)()) F2333_23466;
	R18185[13] = (char *(*)()) F2334_23470;
	R18185[14] = (char *(*)()) F2335_23479;
	R18185[15] = (char *(*)()) F2336_23482;
	R18185[16] = (char *(*)()) F2337_23490;
	R18185[17] = (char *(*)()) F2338_23496;
	R18185[18] = (char *(*)()) F2339_23498;
	R18185[19] = (char *(*)()) F2340_23500;
	R18185[20] = (char *(*)()) F2341_23506;
	R18185[21] = (char *(*)()) F2342_23508;
	R18185[160] = (char *(*)()) F2481_25468;
}

static EIF_TYPE_INDEX Y18185_pgtype0[] = {847,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y18185_pgtype1[] = {847,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y18185_pgtype2[] = {847,3627,0xFFFF};
static EIF_TYPE_INDEX Y18185_pgtype3[] = {847,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y18185_pgtype4[] = {847,2867,0xFFFF};
static EIF_TYPE_INDEX Y18185_pgtype5[] = {847,2542,0xFFFF};
static EIF_TYPE_INDEX Y18185_pgtype6[] = {847,3798,0xFFFF};
static EIF_TYPE_INDEX Y18185_pgtype7[] = {847,1666,0xFFFF};
static EIF_TYPE_INDEX Y18185_pgtype8[] = {847,2344,2313,0xFFFF};
static EIF_TYPE_INDEX Y18185_pgtype9[] = {847,2867,0xFFFF};
static EIF_TYPE_INDEX Y18185_pgtype10[] = {847,1670,0xFFFF};
static EIF_TYPE_INDEX Y18185_pgtype11[] = {847,1667,0xFFFF};
static EIF_TYPE_INDEX Y18185_pgtype12[] = {847,1664,0xFFFF};
static EIF_TYPE_INDEX Y18185_pgtype13[] = {847,1668,0xFFFF};
static EIF_TYPE_INDEX Y18185_pgtype14[] = {847,2670,0xFFFF};
static EIF_TYPE_INDEX Y18185_pgtype15[] = {847,1667,0xFFFF};
static EIF_TYPE_INDEX Y18185_pgtype16[] = {847,1664,0xFFFF};
static EIF_TYPE_INDEX Y18185_pgtype17[] = {847,1668,0xFFFF};
static EIF_TYPE_INDEX Y18185_pgtype18[] = {847,2670,0xFFFF};
static EIF_TYPE_INDEX Y18185_pgtype19[] = {847,1666,0xFFFF};
static EIF_TYPE_INDEX Y18185_pgtype20[] = {847,1670,0xFFFF};
static EIF_TYPE_INDEX Y18185_pgtype21[] = {847,2867,0xFFFF};
static EIF_TYPE_INDEX Y18185_pgtype22[] = {847,3798,0xFFFF};
static EIF_TYPE_INDEX Y18185_pgtype23[] = {847,2542,0xFFFF};
static EIF_TYPE_INDEX Y18185_pgtype24[] = {847,2491,0xFFFF};
EIF_TYPE_INDEX *Y18185_gen_type [163];
EIF_TYPE_INDEX Y18185 [163];
void Y18185_init (void)
{
	egc_routines_types [18185] = Y18185;
	egc_routines_gen_types [18185] = Y18185_gen_type;
	egc_routines_offset [18185] = 2318;
	Y18185_gen_type [0] = Y18185_pgtype0;
	Y18185_gen_type [1] = Y18185_pgtype1;
	Y18185_gen_type [2] = Y18185_pgtype2;
	Y18185_gen_type [3] = Y18185_pgtype3;
	Y18185_gen_type [4] = Y18185_pgtype4;
	Y18185_gen_type [5] = Y18185_pgtype5;
	Y18185_gen_type [6] = Y18185_pgtype6;
	Y18185_gen_type [7] = Y18185_pgtype7;
	Y18185_gen_type [8] = Y18185_pgtype8;
	Y18185_gen_type [9] = Y18185_pgtype9;
	Y18185_gen_type [10] = Y18185_pgtype10;
	Y18185_gen_type [11] = Y18185_pgtype11;
	Y18185_gen_type [12] = Y18185_pgtype12;
	Y18185_gen_type [13] = Y18185_pgtype13;
	Y18185_gen_type [14] = Y18185_pgtype14;
	Y18185_gen_type [15] = Y18185_pgtype15;
	Y18185_gen_type [16] = Y18185_pgtype16;
	Y18185_gen_type [17] = Y18185_pgtype17;
	Y18185_gen_type [18] = Y18185_pgtype18;
	Y18185_gen_type [19] = Y18185_pgtype19;
	Y18185_gen_type [20] = Y18185_pgtype20;
	Y18185_gen_type [21] = Y18185_pgtype21;
	Y18185_gen_type [22] = Y18185_pgtype22;
	Y18185_gen_type [23] = Y18185_pgtype23;
	Y18185_gen_type [162] = Y18185_pgtype24;
	{long i; for (i = 0; i < 24; i++) Y18185[i] = 847;};
	Y18185[162] = 847;
}

static EIF_TYPE_INDEX Y18206_pgtype0[] = {1626,0xFFF8,1,2055,0xFFFF};
static EIF_TYPE_INDEX Y18206_pgtype1[] = {1626,242,2055,0xFFFF};
static EIF_TYPE_INDEX Y18206_pgtype2[] = {1626,242,2055,0xFFFF};
static EIF_TYPE_INDEX Y18206_pgtype3[] = {1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18206_pgtype4[] = {1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18206_pgtype5[] = {1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18206_pgtype6[] = {1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18206_pgtype7[] = {1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18206_pgtype8[] = {1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18206_pgtype9[] = {1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18206_pgtype10[] = {1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18206_pgtype11[] = {1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18206_pgtype12[] = {1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18206_pgtype13[] = {1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18206_pgtype14[] = {1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18206_pgtype15[] = {1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18206_pgtype16[] = {1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18206_pgtype17[] = {1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18206_pgtype18[] = {1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18206_pgtype19[] = {1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18206_pgtype20[] = {1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18206_pgtype21[] = {1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18206_pgtype22[] = {1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18206_pgtype23[] = {1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18206_pgtype24[] = {1626,241,2055,0xFFFF};
EIF_TYPE_INDEX *Y18206_gen_type [163];
EIF_TYPE_INDEX Y18206 [163];
void Y18206_init (void)
{
	egc_routines_types [18206] = Y18206;
	egc_routines_gen_types [18206] = Y18206_gen_type;
	egc_routines_offset [18206] = 2318;
	Y18206_gen_type [0] = Y18206_pgtype0;
	Y18206_gen_type [1] = Y18206_pgtype1;
	Y18206_gen_type [2] = Y18206_pgtype2;
	Y18206_gen_type [3] = Y18206_pgtype3;
	Y18206_gen_type [4] = Y18206_pgtype4;
	Y18206_gen_type [5] = Y18206_pgtype5;
	Y18206_gen_type [6] = Y18206_pgtype6;
	Y18206_gen_type [7] = Y18206_pgtype7;
	Y18206_gen_type [8] = Y18206_pgtype8;
	Y18206_gen_type [9] = Y18206_pgtype9;
	Y18206_gen_type [10] = Y18206_pgtype10;
	Y18206_gen_type [11] = Y18206_pgtype11;
	Y18206_gen_type [12] = Y18206_pgtype12;
	Y18206_gen_type [13] = Y18206_pgtype13;
	Y18206_gen_type [14] = Y18206_pgtype14;
	Y18206_gen_type [15] = Y18206_pgtype15;
	Y18206_gen_type [16] = Y18206_pgtype16;
	Y18206_gen_type [17] = Y18206_pgtype17;
	Y18206_gen_type [18] = Y18206_pgtype18;
	Y18206_gen_type [19] = Y18206_pgtype19;
	Y18206_gen_type [20] = Y18206_pgtype20;
	Y18206_gen_type [21] = Y18206_pgtype21;
	Y18206_gen_type [22] = Y18206_pgtype22;
	Y18206_gen_type [23] = Y18206_pgtype23;
	Y18206_gen_type [162] = Y18206_pgtype24;
	{long i; for (i = 0; i < 24; i++) Y18206[i] = 1626;};
	Y18206[162] = 1626;
}

static EIF_TYPE_INDEX Y18215_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y18215_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y18215_pgtype2[] = {3627,0xFFFF};
static EIF_TYPE_INDEX Y18215_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y18215_pgtype4[] = {2867,0xFFFF};
static EIF_TYPE_INDEX Y18215_pgtype5[] = {2542,0xFFFF};
static EIF_TYPE_INDEX Y18215_pgtype6[] = {3798,0xFFFF};
static EIF_TYPE_INDEX Y18215_pgtype7[] = {1666,0xFFFF};
static EIF_TYPE_INDEX Y18215_pgtype8[] = {2344,2313,0xFFFF};
static EIF_TYPE_INDEX Y18215_pgtype9[] = {2867,0xFFFF};
static EIF_TYPE_INDEX Y18215_pgtype10[] = {1670,0xFFFF};
static EIF_TYPE_INDEX Y18215_pgtype11[] = {1667,0xFFFF};
static EIF_TYPE_INDEX Y18215_pgtype12[] = {1664,0xFFFF};
static EIF_TYPE_INDEX Y18215_pgtype13[] = {1668,0xFFFF};
static EIF_TYPE_INDEX Y18215_pgtype14[] = {2670,0xFFFF};
static EIF_TYPE_INDEX Y18215_pgtype15[] = {1667,0xFFFF};
static EIF_TYPE_INDEX Y18215_pgtype16[] = {1664,0xFFFF};
static EIF_TYPE_INDEX Y18215_pgtype17[] = {1668,0xFFFF};
static EIF_TYPE_INDEX Y18215_pgtype18[] = {2670,0xFFFF};
static EIF_TYPE_INDEX Y18215_pgtype19[] = {1666,0xFFFF};
static EIF_TYPE_INDEX Y18215_pgtype20[] = {1670,0xFFFF};
static EIF_TYPE_INDEX Y18215_pgtype21[] = {2867,0xFFFF};
static EIF_TYPE_INDEX Y18215_pgtype22[] = {3798,0xFFFF};
static EIF_TYPE_INDEX Y18215_pgtype23[] = {2542,0xFFFF};
static EIF_TYPE_INDEX Y18215_pgtype24[] = {2491,0xFFFF};
EIF_TYPE_INDEX *Y18215_gen_type [163];
EIF_TYPE_INDEX Y18215 [163];
void Y18215_init (void)
{
	egc_routines_types [18215] = Y18215;
	egc_routines_gen_types [18215] = Y18215_gen_type;
	egc_routines_offset [18215] = 2318;
	Y18215_gen_type [0] = Y18215_pgtype0;
	Y18215_gen_type [1] = Y18215_pgtype1;
	Y18215_gen_type [2] = Y18215_pgtype2;
	Y18215_gen_type [3] = Y18215_pgtype3;
	Y18215_gen_type [4] = Y18215_pgtype4;
	Y18215_gen_type [5] = Y18215_pgtype5;
	Y18215_gen_type [6] = Y18215_pgtype6;
	Y18215_gen_type [7] = Y18215_pgtype7;
	Y18215_gen_type [8] = Y18215_pgtype8;
	Y18215_gen_type [9] = Y18215_pgtype9;
	Y18215_gen_type [10] = Y18215_pgtype10;
	Y18215_gen_type [11] = Y18215_pgtype11;
	Y18215_gen_type [12] = Y18215_pgtype12;
	Y18215_gen_type [13] = Y18215_pgtype13;
	Y18215_gen_type [14] = Y18215_pgtype14;
	Y18215_gen_type [15] = Y18215_pgtype15;
	Y18215_gen_type [16] = Y18215_pgtype16;
	Y18215_gen_type [17] = Y18215_pgtype17;
	Y18215_gen_type [18] = Y18215_pgtype18;
	Y18215_gen_type [19] = Y18215_pgtype19;
	Y18215_gen_type [20] = Y18215_pgtype20;
	Y18215_gen_type [21] = Y18215_pgtype21;
	Y18215_gen_type [22] = Y18215_pgtype22;
	Y18215_gen_type [23] = Y18215_pgtype23;
	Y18215_gen_type [162] = Y18215_pgtype24;
	Y18215[2] = 3627;
	Y18215[4] = 2867;
	Y18215[5] = 2542;
	Y18215[6] = 3798;
	Y18215[7] = 1666;
	Y18215[8] = 2344;
	Y18215[9] = 2867;
	Y18215[10] = 1670;
	Y18215[11] = 1667;
	Y18215[12] = 1664;
	Y18215[13] = 1668;
	Y18215[14] = 2670;
	Y18215[15] = 1667;
	Y18215[16] = 1664;
	Y18215[17] = 1668;
	Y18215[18] = 2670;
	Y18215[19] = 1666;
	Y18215[20] = 1670;
	Y18215[21] = 2867;
	Y18215[22] = 3798;
	Y18215[23] = 2542;
	Y18215[162] = 2491;
}

char *(*R18223[159])();
void R18223_init () {
	R18223[0] = (char *(*)()) F2322_23389;
	R18223[1] = (char *(*)()) F2324_23400;
	R18223[2] = (char *(*)()) F2325_23437;
	{long i; for (i = 3; i < 10; i++) R18223[i] = (char *(*)()) F2322_23389;}
	R18223[10] = (char *(*)()) F2333_23468;
	{long i; for (i = 11; i < 20; i++) R18223[i] = (char *(*)()) F2322_23389;}
	R18223[158] = (char *(*)()) F2322_23389;
}

char *(*R18224[159])();
void R18224_init () {
	{long i; for (i = 0; i < 2; i++) R18224[i] = (char *(*)()) F2322_23390;}
	R18224[2] = (char *(*)()) F2325_23435;
	{long i; for (i = 3; i < 20; i++) R18224[i] = (char *(*)()) F2322_23390;}
	R18224[158] = (char *(*)()) F2322_23390;
}

char *(*R18225[159])();
void R18225_init () {
	{long i; for (i = 0; i < 2; i++) R18225[i] = (char *(*)()) F2322_23391;}
	R18225[2] = (char *(*)()) F2325_23436;
	{long i; for (i = 3; i < 20; i++) R18225[i] = (char *(*)()) F2322_23391;}
	R18225[158] = (char *(*)()) F2322_23391;
}

char *(*R18276[142])();
void R18276_init () {
	R18276[0] = (char *(*)()) F2344_23525;
	R18276[141] = (char *(*)()) F2485_25720;
}

char *(*R18278[142])();
void R18278_init () {
	R18278[0] = (char *(*)()) F2344_23526;
	R18278[141] = (char *(*)()) F2485_25726;
}

char *(*R18283[157])();
void R18283_init () {
	R18283[0] = (char *(*)()) F2346_23571;
	R18283[155] = (char *(*)()) F2501_26530;
	R18283[156] = (char *(*)()) F2502_26560;
}

char *(*R18284[157])();
void R18284_init () {
	R18284[0] = (char *(*)()) F2346_23578;
	R18284[155] = (char *(*)()) F2501_26554;
	R18284[156] = (char *(*)()) F2502_26562;
}

char *(*R18285[157])();
void R18285_init () {
	R18285[0] = (char *(*)()) F2346_23579;
	R18285[155] = (char *(*)()) F2501_26555;
	R18285[156] = (char *(*)()) F2346_23579;
}

char *(*R18296[157])();
void R18296_init () {
	R18296[0] = (char *(*)()) F2345_23543;
	R18296[155] = (char *(*)()) F2501_26527;
	R18296[156] = (char *(*)()) F2502_26558;
}

char *(*R18310[157])();
void R18310_init () {
	R18310[0] = (char *(*)()) F2345_23557;
	{long i; for (i = 155; i < 157; i++) R18310[i] = (char *(*)()) F2501_26525;}
}

char *(*R18311[157])();
void R18311_init () {
	R18311[0] = (char *(*)()) F2345_23558;
	{long i; for (i = 155; i < 157; i++) R18311[i] = (char *(*)()) F2501_26526;}
}

char *(*R18313[157])();
void R18313_init () {
	R18313[0] = (char *(*)()) F2346_23574;
	R18313[155] = (char *(*)()) F2501_26540;
	R18313[156] = (char *(*)()) F2502_26561;
}

char *(*R18318[157])();
void R18318_init () {
	R18318[0] = (char *(*)()) F2346_23576;
	{long i; for (i = 155; i < 157; i++) R18318[i] = (char *(*)()) F2501_26549;}
}

char *(*R18342[4])();
void R18342_init () {
	R18342[0] = (char *(*)()) F2350_23599;
	R18342[1] = (char *(*)()) F2351_23618;
	{long i; for (i = 2; i < 4; i++) R18342[i] = (char *(*)()) F2350_23599;}
}

char *(*R18343[4])();
void R18343_init () {
	R18343[0] = (char *(*)()) F2350_23600;
	R18343[1] = (char *(*)()) F2351_23619;
	R18343[2] = (char *(*)()) F2352_23621;
	R18343[3] = (char *(*)()) F2350_23600;
}

char *(*R18345[4])();
void R18345_init () {
	{long i; for (i = 0; i < 3; i++) R18345[i] = (char *(*)()) F2350_23602;}
	R18345[3] = (char *(*)()) F2353_23623;
}

char *(*R18363[1240])();
void R18363_init () {
	R18363[0] = (char *(*)()) F2354_23627;
	R18363[2] = (char *(*)()) F2354_23627;
	R18363[1238] = (char *(*)()) F2354_23627;
	R18363[1239] = (char *(*)()) F3593_40464;
}

char *(*R18364[1240])();
void R18364_init () {
	R18364[0] = (char *(*)()) F2354_23628;
	R18364[2] = (char *(*)()) F2356_23759;
	{long i; for (i = 1238; i < 1240; i++) R18364[i] = (char *(*)()) F2354_23628;}
}

char *(*R18365[1240])();
void R18365_init () {
	R18365[0] = (char *(*)()) F2354_23629;
	R18365[2] = (char *(*)()) F2356_23760;
	{long i; for (i = 1238; i < 1240; i++) R18365[i] = (char *(*)()) F2354_23629;}
}

char *(*R18396[1240])();
void R18396_init () {
	R18396[0] = (char *(*)()) F2354_23661;
	R18396[2] = (char *(*)()) F2356_23763;
	R18396[1238] = (char *(*)()) F2354_23661;
	R18396[1239] = (char *(*)()) F3593_40468;
}

char *(*R18397[1240])();
void R18397_init () {
	R18397[0] = (char *(*)()) F2354_23662;
	R18397[2] = (char *(*)()) F2354_23662;
	{long i; for (i = 1238; i < 1240; i++) R18397[i] = (char *(*)()) F3592_40461;}
}


#ifdef __cplusplus
}
#endif
