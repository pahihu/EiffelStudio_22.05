#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O17046[1573];
void O17046_init () {
	{long i; for (i = 0; i < 3; i++) O17046[i] = + _LNGOFF_0_0_0_1_;}
	{long i; for (i = 3; i < 5; i++) O17046[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 5; i < 7; i++) O17046[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 7; i < 9; i++) O17046[i] = + _LNGOFF_1_0_0_1_;}
	O17046[9] = + _LNGOFF_1_1_0_1_;
	{long i; for (i = 1571; i < 1573; i++) O17046[i] = + _LNGOFF_1_1_0_1_;}
}

long O17115[1570];
void O17115_init () {
	{long i; for (i = 0; i < 2; i++) O17115[i] = + _LNGOFF_1_0_0_2_;}
	{long i; for (i = 2; i < 4; i++) O17115[i] = + _LNGOFF_1_1_0_2_;}
	{long i; for (i = 1568; i < 1570; i++) O17115[i] = + _LNGOFF_1_1_0_2_;}
}

long O17190[3];
void O17190_init () {
	{long i; for (i = 0; i < 2; i++) O17190[i] = + _LNGOFF_1_0_0_2_;}
	O17190[2] = + _LNGOFF_1_1_0_2_;
}

long O17244[6];
void O17244_init () {
	{long i; for (i = 0; i < 2; i++) O17244[i] = + _LNGOFF_2_0_0_0_;}
	O17244[2] = + _LNGOFF_4_1_0_0_;
	O17244[3] = + _LNGOFF_4_0_0_0_;
	{long i; for (i = 4; i < 6; i++) O17244[i] = + _LNGOFF_3_0_0_0_;}
}

long O17399[2];
void O17399_init () {
	O17399[0] = + _LNGOFF_0_2_0_0_;
	O17399[1] = + _LNGOFF_2_2_0_0_;
}

long O17400[2];
void O17400_init () {
	O17400[0] = + _LNGOFF_0_2_0_1_;
	O17400[1] = + _LNGOFF_2_2_0_1_;
}

long O17401[2];
void O17401_init () {
	O17401[0] = + _LNGOFF_0_2_0_2_;
	O17401[1] = + _LNGOFF_2_2_0_2_;
}

long O17402[2];
void O17402_init () {
	O17402[0] = + _LNGOFF_0_2_0_3_;
	O17402[1] = + _LNGOFF_2_2_0_3_;
}

long O17403[2];
void O17403_init () {
	O17403[0] = + _CHROFF_0_0_;
	O17403[1] = + _CHROFF_2_0_;
}

long O17404[2];
void O17404_init () {
	O17404[0] = + _CHROFF_0_1_;
	O17404[1] = + _CHROFF_2_1_;
}

long O18151[137];
void O18151_init () {
	O18151[0] = + _LNGOFF_1_2_0_0_;
	O18151[1] = + _LNGOFF_1_3_0_0_;
	{long i; for (i = 135; i < 137; i++) O18151[i] = + _LNGOFF_1_4_0_0_;}
}

long O18157[137];
void O18157_init () {
	O18157[0] = + _LNGOFF_1_2_0_1_;
	O18157[1] = + _LNGOFF_1_3_0_1_;
	{long i; for (i = 135; i < 137; i++) O18157[i] = + _LNGOFF_1_4_0_1_;}
}

long O18158[137];
void O18158_init () {
	O18158[0] = + _LNGOFF_1_2_0_2_;
	O18158[1] = + _LNGOFF_1_3_0_2_;
	{long i; for (i = 135; i < 137; i++) O18158[i] = + _LNGOFF_1_4_0_2_;}
}

long O18169[3];
void O18169_init () {
	{long i; for (i = 0; i < 2; i++) O18169[i] = + _LNGOFF_0_1_0_0_;}
	O18169[2] = + _LNGOFF_1_1_0_0_;
}

long O18194[163];
void O18194_init () {
	{long i; for (i = 0; i < 5; i++) O18194[i] = + _CHROFF_3_0_;}
	O18194[5] = + _CHROFF_6_0_;
	O18194[6] = + _CHROFF_9_0_;
	{long i; for (i = 7; i < 14; i++) O18194[i] = + _CHROFF_3_0_;}
	O18194[14] = + _CHROFF_4_0_;
	{long i; for (i = 15; i < 17; i++) O18194[i] = + _CHROFF_3_0_;}
	O18194[17] = + _CHROFF_4_0_;
	{long i; for (i = 18; i < 24; i++) O18194[i] = + _CHROFF_3_0_;}
	O18194[162] = + _CHROFF_3_0_;
}

static EIF_TYPE_INDEX Y18207_pgtype0[] = {1928,1626,0xFFF8,1,2055,0xFFFF};
static EIF_TYPE_INDEX Y18207_pgtype1[] = {1928,1626,242,2055,0xFFFF};
static EIF_TYPE_INDEX Y18207_pgtype2[] = {1928,1626,242,2055,0xFFFF};
static EIF_TYPE_INDEX Y18207_pgtype3[] = {1928,1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18207_pgtype4[] = {1928,1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18207_pgtype5[] = {1928,1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18207_pgtype6[] = {1928,1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18207_pgtype7[] = {1928,1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18207_pgtype8[] = {1928,1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18207_pgtype9[] = {1928,1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18207_pgtype10[] = {1928,1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18207_pgtype11[] = {1928,1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18207_pgtype12[] = {1928,1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18207_pgtype13[] = {1928,1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18207_pgtype14[] = {1928,1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18207_pgtype15[] = {1928,1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18207_pgtype16[] = {1928,1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18207_pgtype17[] = {1928,1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18207_pgtype18[] = {1928,1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18207_pgtype19[] = {1928,1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18207_pgtype20[] = {1928,1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18207_pgtype21[] = {1928,1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18207_pgtype22[] = {1928,1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18207_pgtype23[] = {1928,1626,241,2055,0xFFFF};
static EIF_TYPE_INDEX Y18207_pgtype24[] = {1928,1626,241,2055,0xFFFF};
EIF_TYPE_INDEX *Y18207_gen_type [163];
EIF_TYPE_INDEX Y18207 [163];
void Y18207_init (void)
{
	egc_routines_types [18207] = Y18207;
	egc_routines_gen_types [18207] = Y18207_gen_type;
	egc_routines_offset [18207] = 2318;
	Y18207_gen_type [0] = Y18207_pgtype0;
	Y18207_gen_type [1] = Y18207_pgtype1;
	Y18207_gen_type [2] = Y18207_pgtype2;
	Y18207_gen_type [3] = Y18207_pgtype3;
	Y18207_gen_type [4] = Y18207_pgtype4;
	Y18207_gen_type [5] = Y18207_pgtype5;
	Y18207_gen_type [6] = Y18207_pgtype6;
	Y18207_gen_type [7] = Y18207_pgtype7;
	Y18207_gen_type [8] = Y18207_pgtype8;
	Y18207_gen_type [9] = Y18207_pgtype9;
	Y18207_gen_type [10] = Y18207_pgtype10;
	Y18207_gen_type [11] = Y18207_pgtype11;
	Y18207_gen_type [12] = Y18207_pgtype12;
	Y18207_gen_type [13] = Y18207_pgtype13;
	Y18207_gen_type [14] = Y18207_pgtype14;
	Y18207_gen_type [15] = Y18207_pgtype15;
	Y18207_gen_type [16] = Y18207_pgtype16;
	Y18207_gen_type [17] = Y18207_pgtype17;
	Y18207_gen_type [18] = Y18207_pgtype18;
	Y18207_gen_type [19] = Y18207_pgtype19;
	Y18207_gen_type [20] = Y18207_pgtype20;
	Y18207_gen_type [21] = Y18207_pgtype21;
	Y18207_gen_type [22] = Y18207_pgtype22;
	Y18207_gen_type [23] = Y18207_pgtype23;
	Y18207_gen_type [162] = Y18207_pgtype24;
	{long i; for (i = 0; i < 24; i++) Y18207[i] = 1928;};
	Y18207[162] = 1928;
}

long O18209[163];
void O18209_init () {
	{long i; for (i = 0; i < 5; i++) O18209[i] = + _LNGOFF_3_1_0_0_;}
	O18209[5] = + _LNGOFF_6_1_0_0_;
	O18209[6] = + _LNGOFF_9_1_0_0_;
	{long i; for (i = 7; i < 14; i++) O18209[i] = + _LNGOFF_3_1_0_0_;}
	O18209[14] = + _LNGOFF_4_1_0_0_;
	{long i; for (i = 15; i < 17; i++) O18209[i] = + _LNGOFF_3_1_0_0_;}
	O18209[17] = + _LNGOFF_4_1_0_0_;
	{long i; for (i = 18; i < 24; i++) O18209[i] = + _LNGOFF_3_1_0_0_;}
	O18209[162] = + _LNGOFF_3_1_0_0_;
}

long O18216[160];
void O18216_init () {
	{long i; for (i = 0; i < 2; i++) O18216[i] = + _LNGOFF_3_1_0_1_;}
	O18216[2] = + _LNGOFF_6_1_0_1_;
	O18216[3] = + _LNGOFF_9_1_0_1_;
	{long i; for (i = 4; i < 11; i++) O18216[i] = + _LNGOFF_3_1_0_1_;}
	O18216[11] = + _LNGOFF_4_1_0_1_;
	{long i; for (i = 12; i < 14; i++) O18216[i] = + _LNGOFF_3_1_0_1_;}
	O18216[14] = + _LNGOFF_4_1_0_1_;
	{long i; for (i = 15; i < 21; i++) O18216[i] = + _LNGOFF_3_1_0_1_;}
	O18216[159] = + _LNGOFF_3_1_0_1_;
}

long O18272[143];
void O18272_init () {
	{long i; for (i = 0; i < 2; i++) O18272[i] = + _LNGOFF_1_0_0_0_;}
	O18272[142] = + _LNGOFF_2_2_0_0_;
}

long O18273[143];
void O18273_init () {
	{long i; for (i = 0; i < 2; i++) O18273[i] = + _LNGOFF_1_0_0_1_;}
	O18273[142] = + _LNGOFF_2_2_0_1_;
}

long O18274[143];
void O18274_init () {
	{long i; for (i = 0; i < 2; i++) O18274[i] = + _LNGOFF_1_0_0_2_;}
	O18274[142] = + _LNGOFF_2_2_0_2_;
}

long O18279[143];
void O18279_init () {
	{long i; for (i = 0; i < 2; i++) O18279[i] = + _LNGOFF_1_0_0_3_;}
	O18279[142] = + _LNGOFF_2_2_0_3_;
}

long O18291[158];
void O18291_init () {
	{long i; for (i = 0; i < 2; i++) O18291[i] = + _LNGOFF_1_3_0_3_;}
	O18291[156] = + _LNGOFF_1_3_0_3_;
	O18291[157] = + _LNGOFF_1_4_0_3_;
}

long O18305[158];
void O18305_init () {
	{long i; for (i = 0; i < 2; i++) O18305[i] = + _LNGOFF_1_3_0_4_;}
	O18305[156] = + _LNGOFF_1_3_0_4_;
	O18305[157] = + _LNGOFF_1_4_0_4_;
}

long O18306[158];
void O18306_init () {
	{long i; for (i = 0; i < 2; i++) O18306[i] = + _LNGOFF_1_3_0_5_;}
	O18306[156] = + _LNGOFF_1_3_0_5_;
	O18306[157] = + _LNGOFF_1_4_0_5_;
}

long O18309[158];
void O18309_init () {
	{long i; for (i = 0; i < 2; i++) O18309[i] = + _LNGOFF_1_3_0_6_;}
	O18309[156] = + _LNGOFF_1_3_0_6_;
	O18309[157] = + _LNGOFF_1_4_0_6_;
}

long O18330[3];
void O18330_init () {
	{long i; for (i = 0; i < 2; i++) O18330[i] =  + _REFACS_28_;}
	O18330[2] =  + _REFACS_30_;
}

long O18334[4];
void O18334_init () {
	{long i; for (i = 0; i < 2; i++) O18334[i] = + _LNGOFF_2_0_0_0_;}
	O18334[2] = + _LNGOFF_3_0_0_0_;
	O18334[3] = + _LNGOFF_2_0_0_0_;
}

long O18335[4];
void O18335_init () {
	{long i; for (i = 0; i < 2; i++) O18335[i] = + _LNGOFF_2_0_0_1_;}
	O18335[2] = + _LNGOFF_3_0_0_1_;
	O18335[3] = + _LNGOFF_2_0_0_1_;
}

long O18339[4];
void O18339_init () {
	{long i; for (i = 0; i < 2; i++) O18339[i] = + _LNGOFF_2_0_0_2_;}
	O18339[2] = + _LNGOFF_3_0_0_2_;
	O18339[3] = + _LNGOFF_2_0_0_2_;
}

long O18340[4];
void O18340_init () {
	{long i; for (i = 0; i < 2; i++) O18340[i] = + _LNGOFF_2_0_0_3_;}
	O18340[2] = + _LNGOFF_3_0_0_3_;
	O18340[3] = + _LNGOFF_2_0_0_3_;
}

long O18341[4];
void O18341_init () {
	{long i; for (i = 0; i < 2; i++) O18341[i] = + _LNGOFF_2_0_0_4_;}
	O18341[2] = + _LNGOFF_3_0_0_4_;
	O18341[3] = + _LNGOFF_2_0_0_4_;
}

long O18374[1240];
void O18374_init () {
	O18374[0] = + _CHROFF_20_3_;
	O18374[1] = + _CHROFF_21_3_;
	O18374[2] = + _CHROFF_20_3_;
	{long i; for (i = 1238; i < 1240; i++) O18374[i] = + _CHROFF_22_3_;}
}

long O18375[1240];
void O18375_init () {
	O18375[0] = + _CHROFF_20_4_;
	O18375[1] = + _CHROFF_21_4_;
	O18375[2] = + _CHROFF_20_4_;
	{long i; for (i = 1238; i < 1240; i++) O18375[i] = + _CHROFF_22_4_;}
}

long O18376[1240];
void O18376_init () {
	O18376[0] = + _CHROFF_20_5_;
	O18376[1] = + _CHROFF_21_5_;
	O18376[2] = + _CHROFF_20_5_;
	{long i; for (i = 1238; i < 1240; i++) O18376[i] = + _CHROFF_22_5_;}
}

long O18377[1240];
void O18377_init () {
	O18377[0] = + _CHROFF_20_6_;
	O18377[1] = + _CHROFF_21_6_;
	O18377[2] = + _CHROFF_20_6_;
	{long i; for (i = 1238; i < 1240; i++) O18377[i] = + _CHROFF_22_6_;}
}


#ifdef __cplusplus
}
#endif
