#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O20362[579];
void O20362_init () {
	O20362[0] = + _CHROFF_53_6_;
	O20362[1] = + _CHROFF_56_6_;
	{long i; for (i = 564; i < 579; i++) O20362[i] = + _CHROFF_54_6_;}
}

long O20371[579];
void O20371_init () {
	O20371[0] = + _CHROFF_53_7_;
	O20371[1] = + _CHROFF_56_7_;
	{long i; for (i = 564; i < 579; i++) O20371[i] = + _CHROFF_54_7_;}
}

long O20512[579];
void O20512_init () {
	O20512[0] = + _LNGOFF_53_36_0_1_;
	O20512[1] = + _LNGOFF_56_38_0_1_;
	O20512[564] = + _LNGOFF_54_37_0_1_;
	O20512[565] = + _LNGOFF_54_39_0_1_;
	{long i; for (i = 566; i < 575; i++) O20512[i] = + _LNGOFF_54_37_0_1_;}
	{long i; for (i = 575; i < 577; i++) O20512[i] = + _LNGOFF_54_38_0_1_;}
	{long i; for (i = 577; i < 579; i++) O20512[i] = + _LNGOFF_54_37_0_1_;}
}

long O20523[579];
void O20523_init () {
	O20523[0] = + _LNGOFF_53_36_0_2_;
	O20523[1] = + _LNGOFF_56_38_0_2_;
	O20523[564] = + _LNGOFF_54_37_0_2_;
	O20523[565] = + _LNGOFF_54_39_0_2_;
	{long i; for (i = 566; i < 575; i++) O20523[i] = + _LNGOFF_54_37_0_2_;}
	{long i; for (i = 575; i < 577; i++) O20523[i] = + _LNGOFF_54_38_0_2_;}
	{long i; for (i = 577; i < 579; i++) O20523[i] = + _LNGOFF_54_37_0_2_;}
}

long O20527[579];
void O20527_init () {
	O20527[0] = + _CHROFF_53_8_;
	O20527[1] = + _CHROFF_56_8_;
	{long i; for (i = 564; i < 579; i++) O20527[i] = + _CHROFF_54_8_;}
}

long O20544[579];
void O20544_init () {
	O20544[0] = + _CHROFF_53_9_;
	O20544[1] = + _CHROFF_56_9_;
	{long i; for (i = 564; i < 579; i++) O20544[i] = + _CHROFF_54_9_;}
}

long O20546[579];
void O20546_init () {
	O20546[0] = + _LNGOFF_53_36_0_3_;
	O20546[1] = + _LNGOFF_56_38_0_3_;
	O20546[564] = + _LNGOFF_54_37_0_3_;
	O20546[565] = + _LNGOFF_54_39_0_3_;
	{long i; for (i = 566; i < 575; i++) O20546[i] = + _LNGOFF_54_37_0_3_;}
	{long i; for (i = 575; i < 577; i++) O20546[i] = + _LNGOFF_54_38_0_3_;}
	{long i; for (i = 577; i < 579; i++) O20546[i] = + _LNGOFF_54_37_0_3_;}
}

long O20547[579];
void O20547_init () {
	O20547[0] = + _CHROFF_53_10_;
	O20547[1] = + _CHROFF_56_10_;
	{long i; for (i = 564; i < 579; i++) O20547[i] = + _CHROFF_54_10_;}
}

long O20548[579];
void O20548_init () {
	O20548[0] = + _CHROFF_53_11_;
	O20548[1] = + _CHROFF_56_11_;
	{long i; for (i = 564; i < 579; i++) O20548[i] = + _CHROFF_54_11_;}
}

long O20549[579];
void O20549_init () {
	O20549[0] = + _CHROFF_53_12_;
	O20549[1] = + _CHROFF_56_12_;
	{long i; for (i = 564; i < 579; i++) O20549[i] = + _CHROFF_54_12_;}
}

long O20550[579];
void O20550_init () {
	O20550[0] = + _CHROFF_53_13_;
	O20550[1] = + _CHROFF_56_13_;
	{long i; for (i = 564; i < 579; i++) O20550[i] = + _CHROFF_54_13_;}
}

long O20551[579];
void O20551_init () {
	O20551[0] = + _CHROFF_53_14_;
	O20551[1] = + _CHROFF_56_14_;
	{long i; for (i = 564; i < 579; i++) O20551[i] = + _CHROFF_54_14_;}
}

long O20553[579];
void O20553_init () {
	O20553[0] = + _CHROFF_53_15_;
	O20553[1] = + _CHROFF_56_15_;
	{long i; for (i = 564; i < 579; i++) O20553[i] = + _CHROFF_54_15_;}
}

long O20554[579];
void O20554_init () {
	O20554[0] = + _CHROFF_53_16_;
	O20554[1] = + _CHROFF_56_16_;
	{long i; for (i = 564; i < 579; i++) O20554[i] = + _CHROFF_54_16_;}
}

long O20555[579];
void O20555_init () {
	O20555[0] = + _CHROFF_53_17_;
	O20555[1] = + _CHROFF_56_17_;
	{long i; for (i = 564; i < 579; i++) O20555[i] = + _CHROFF_54_17_;}
}

long O20557[579];
void O20557_init () {
	O20557[0] = + _CHROFF_53_18_;
	O20557[1] = + _CHROFF_56_18_;
	{long i; for (i = 564; i < 579; i++) O20557[i] = + _CHROFF_54_18_;}
}

long O20559[579];
void O20559_init () {
	O20559[0] = + _CHROFF_53_19_;
	O20559[1] = + _CHROFF_56_19_;
	{long i; for (i = 564; i < 579; i++) O20559[i] = + _CHROFF_54_19_;}
}

long O20605[579];
void O20605_init () {
	O20605[0] = + _CHROFF_53_21_;
	O20605[1] = + _CHROFF_56_21_;
	{long i; for (i = 564; i < 579; i++) O20605[i] = + _CHROFF_54_21_;}
}


#ifdef __cplusplus
}
#endif
