#include "epoly6.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4910[1371])();
void R4910_init () {
	R4910[0] = (char *(*)()) F1691_15666;
	R4910[1] = (char *(*)()) F1692_15679;
	R4910[1370] = (char *(*)()) F1688_15653;
}

char *(*R4913[1371])();
void R4913_init () {
	R4913[0] = (char *(*)()) F1691_15662_4913_1;
	R4913[1] = (char *(*)()) F1692_15682_4913_1;
	R4913[1370] = (char *(*)()) F3058_34735_4913_1;
}
static EIF_REFERENCE F1691_15662_4913_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1691_15662(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(2085, 0x00).id, 2085, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1692_15682_4913_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1692_15682(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(2085, 0x00).id, 2085, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F3058_34735_4913_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F3058_34735(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(2085, 0x00).id, 2085, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R4918[8])();
void R4918_init () {
	R4918[0] = (char *(*)()) F349_5038;
	R4918[5] = (char *(*)()) F352_5059;
	R4918[6] = (char *(*)()) F353_5059;
	R4918[7] = (char *(*)()) F352_5059;
}

char *(*R4919[3])();
void R4919_init () {
	R4919[0] = (char *(*)()) F352_5060;
	R4919[1] = (char *(*)()) F353_5060;
	R4919[2] = (char *(*)()) F352_5060;
}

char *(*R4920[8])();
void R4920_init () {
	R4920[0] = (char *(*)()) F349_5040;
	R4920[5] = (char *(*)()) F352_5061;
	R4920[6] = (char *(*)()) F353_5061;
	R4920[7] = (char *(*)()) F352_5061;
}

char *(*R4921[3])();
void R4921_init () {
	R4921[0] = (char *(*)()) F352_5062;
	R4921[1] = (char *(*)()) F353_5062;
	R4921[2] = (char *(*)()) F352_5062;
}

char *(*R4922[8])();
void R4922_init () {
	R4922[0] = (char *(*)()) F349_5042;
	R4922[5] = (char *(*)()) F352_5063;
	R4922[6] = (char *(*)()) F353_5063;
	R4922[7] = (char *(*)()) F352_5063;
}

char *(*R4923[8])();
void R4923_init () {
	R4923[0] = (char *(*)()) F349_5043;
	R4923[5] = (char *(*)()) F352_5064;
	R4923[6] = (char *(*)()) F353_5064;
	R4923[7] = (char *(*)()) F352_5064;
}

char *(*R4927[3])();
void R4927_init () {
	R4927[0] = (char *(*)()) F354_5072;
	R4927[1] = (char *(*)()) F355_5082;
	R4927[2] = (char *(*)()) F356_5094;
}

char *(*R4929[3])();
void R4929_init () {
	R4929[0] = (char *(*)()) F354_5074;
	R4929[1] = (char *(*)()) F355_5084;
	R4929[2] = (char *(*)()) F356_5096;
}

char *(*R4932[3])();
void R4932_init () {
	R4932[0] = (char *(*)()) F354_5077;
	R4932[1] = (char *(*)()) F355_5087;
	R4932[2] = (char *(*)()) F356_5102;
}

char *(*R4933[3])();
void R4933_init () {
	R4933[0] = (char *(*)()) F354_5078;
	R4933[1] = (char *(*)()) F355_5088;
	R4933[2] = (char *(*)()) F356_5104;
}

char *(*R4934[3])();
void R4934_init () {
	R4934[0] = (char *(*)()) F354_5079;
	R4934[1] = (char *(*)()) F355_5089;
	R4934[2] = (char *(*)()) F356_5105;
}

char *(*R4935[3])();
void R4935_init () {
	R4935[0] = (char *(*)()) F352_5057;
	R4935[1] = (char *(*)()) F353_5057;
	R4935[2] = (char *(*)()) F352_5057;
}

char *(*R4937[3])();
void R4937_init () {
	R4937[0] = (char *(*)()) F354_5076;
	R4937[1] = (char *(*)()) F355_5086;
	R4937[2] = (char *(*)()) F356_5100;
}

char *(*R4938[3])();
void R4938_init () {
	R4938[0] = (char *(*)()) F354_5080;
	R4938[1] = (char *(*)()) F355_5090;
	R4938[2] = (char *(*)()) F356_5106;
}

char *(*R4939[3])();
void R4939_init () {
	R4939[0] = (char *(*)()) F352_5066;
	R4939[1] = (char *(*)()) F353_5066;
	R4939[2] = (char *(*)()) F352_5066;
}

char *(*R4940[3])();
void R4940_init () {
	R4940[0] = (char *(*)()) F352_5067;
	R4940[1] = (char *(*)()) F353_5067_4940_1;
	R4940[2] = (char *(*)()) F352_5067;
}
static EIF_REFERENCE F353_5067_4940_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F353_5067(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(2064, 0x00).id, 2064, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}

char *(*R4943[3])();
void R4943_init () {
	R4943[0] = (char *(*)()) F354_5081;
	R4943[1] = (char *(*)()) F355_5091_4943_32;
	R4943[2] = (char *(*)()) F356_5107;
}
static EIF_REFERENCE F355_5091_4943_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F355_5091(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(2064, 0x00).id, 2064, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}

char *(*R4944[3])();
void R4944_init () {
	R4944[0] = (char *(*)()) F352_5071;
	R4944[1] = (char *(*)()) F355_5092_4944_5;
	R4944[2] = (char *(*)()) F352_5071;
}
static EIF_REFERENCE F355_5092_4944_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F355_5092(Current, *(EIF_NATURAL_64 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(2064, 0x00).id, 2064, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}

char *(*R4979[2])();
void R4979_init () {
	R4979[0] = (char *(*)()) F359_5136;
	R4979[1] = (char *(*)()) F362_5167;
}

char *(*R4980[2])();
void R4980_init () {
	R4980[0] = (char *(*)()) F359_5137;
	R4980[1] = (char *(*)()) F362_5166;
}

char *(*R4982[2])();
void R4982_init () {
	R4982[0] = (char *(*)()) F361_5163;
	R4982[1] = (char *(*)()) F362_5168;
}

char *(*R5048[2])();
void R5048_init () {
	R5048[0] = (char *(*)()) F368_5237;
	R5048[1] = (char *(*)()) F369_5248;
}

char *(*R5055[2])();
void R5055_init () {
	R5055[0] = (char *(*)()) F368_5241;
	R5055[1] = (char *(*)()) F369_5250;
}

char *(*R5056[2])();
void R5056_init () {
	R5056[0] = (char *(*)()) F368_5242;
	R5056[1] = (char *(*)()) F369_5251;
}

static EIF_TYPE_INDEX Y5070_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5070_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5070_pgtype2[] = {0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y5070_gen_type [496];
EIF_TYPE_INDEX Y5070 [496];
void Y5070_init (void)
{
	egc_routines_types [5070] = Y5070;
	egc_routines_gen_types [5070] = Y5070_gen_type;
	egc_routines_offset [5070] = 369;
	Y5070_gen_type [0] = Y5070_pgtype0;
	Y5070_gen_type [1] = Y5070_pgtype1;
	Y5070_gen_type [495] = Y5070_pgtype2;
}

char *(*R5185[2436])();
void R5185_init () {
	R5185[0] = (char *(*)()) F802_11513;
	R5185[2427] = (char *(*)()) F376_5377;
	R5185[2434] = (char *(*)()) F376_5377;
	R5185[2435] = (char *(*)()) F378_5414;
}

char *(*R5186[2436])();
void R5186_init () {
	R5186[0] = (char *(*)()) F802_11514;
	R5186[2427] = (char *(*)()) F376_5378;
	R5186[2434] = (char *(*)()) F376_5378;
	R5186[2435] = (char *(*)()) F378_5415;
}

char *(*R5187[2436])();
void R5187_init () {
	R5187[0] = (char *(*)()) F802_11515;
	R5187[2427] = (char *(*)()) F376_5379;
	R5187[2434] = (char *(*)()) F376_5379;
	R5187[2435] = (char *(*)()) F378_5416;
}


#ifdef __cplusplus
}
#endif
