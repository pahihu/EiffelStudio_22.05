#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O5237[3298];
void O5237_init () {
	O5237[0] = 0;
	{long i; for (i = 3287; i < 3291; i++) O5237[i] = 0;}
	O5237[3291] =  + _REFACS_1_;
	{long i; for (i = 3292; i < 3298; i++) O5237[i] = 0;}
}

long O5285[3];
void O5285_init () {
	O5285[0] = + _CHROFF_0_0_;
	O5285[1] = + _CHROFF_3_0_;
	O5285[2] = + _CHROFF_1_0_;
}

long O5745[381];
void O5745_init () {
	{long i; for (i = 0; i < 2; i++) O5745[i] = + _CHROFF_1_1_;}
	O5745[380] = + _CHROFF_3_1_;
}

long O6275[4];
void O6275_init () {
	{long i; for (i = 0; i < 3; i++) O6275[i] = + _CHROFF_2_0_;}
	O6275[3] = + _CHROFF_2_1_;
}

long O6276[4];
void O6276_init () {
	{long i; for (i = 0; i < 3; i++) O6276[i] = + _CHROFF_2_1_;}
	O6276[3] = + _CHROFF_2_2_;
}

long O6384[473];
void O6384_init () {
	{long i; for (i = 0; i < 2; i++) O6384[i] = + _CHROFF_7_0_;}
	O6384[2] = + _CHROFF_8_0_;
	O6384[472] = + _CHROFF_12_0_;
}

long O6386[473];
void O6386_init () {
	{long i; for (i = 0; i < 2; i++) O6386[i] = + _LNGOFF_7_1_0_0_;}
	O6386[2] = + _LNGOFF_8_1_0_0_;
	O6386[472] = + _LNGOFF_12_5_0_0_;
}

long O6643[1975];
void O6643_init () {
	{long i; for (i = 0; i < 2; i++) O6643[i] = + _LNGOFF_0_0_0_0_;}
	O6643[2] = + _LNGOFF_1_0_0_0_;
	O6643[1974] = + _LNGOFF_3_0_0_0_;
}

long O6650[4];
void O6650_init () {
	O6650[0] = + _LNGOFF_1_0_0_0_;
	O6650[1] = + _LNGOFF_2_0_0_0_;
	{long i; for (i = 2; i < 4; i++) O6650[i] = + _LNGOFF_1_0_0_0_;}
}

long O6651[4];
void O6651_init () {
	O6651[0] = + _R64OFF_1_0_0_1_0_0_0_0_;
	O6651[1] = + _R64OFF_2_0_0_1_0_0_0_0_;
	{long i; for (i = 2; i < 4; i++) O6651[i] = + _R64OFF_1_0_0_1_0_0_0_0_;}
}

long O6652[4];
void O6652_init () {
	O6652[0] = + _R64OFF_1_0_0_1_0_0_0_1_;
	O6652[1] = + _R64OFF_2_0_0_1_0_0_0_1_;
	{long i; for (i = 2; i < 4; i++) O6652[i] = + _R64OFF_1_0_0_1_0_0_0_1_;}
}

long O6653[4];
void O6653_init () {
	O6653[0] = + _R64OFF_1_0_0_1_0_0_0_2_;
	O6653[1] = + _R64OFF_2_0_0_1_0_0_0_2_;
	{long i; for (i = 2; i < 4; i++) O6653[i] = + _R64OFF_1_0_0_1_0_0_0_2_;}
}

long O6654[4];
void O6654_init () {
	O6654[0] = + _R64OFF_1_0_0_1_0_0_0_3_;
	O6654[1] = + _R64OFF_2_0_0_1_0_0_0_3_;
	{long i; for (i = 2; i < 4; i++) O6654[i] = + _R64OFF_1_0_0_1_0_0_0_3_;}
}

long O6899[281];
void O6899_init () {
	{long i; for (i = 0; i < 2; i++) O6899[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 2; i < 4; i++) O6899[i] = + _LNGOFF_2_1_0_0_;}
	{long i; for (i = 279; i < 281; i++) O6899[i] = + _LNGOFF_2_1_0_0_;}
}

EIF_TYPE_INDEX *Y6922_gen_type [2397];
EIF_TYPE_INDEX Y6922 [2397];
void Y6922_init (void)
{
	egc_routines_types [6922] = Y6922;
	egc_routines_gen_types [6922] = Y6922_gen_type;
	egc_routines_offset [6922] = 535;
	{long i; for (i = 0; i < 2; i++) Y6922[i] = 236;};
	Y6922[2] = 917;
	{long i; for (i = 3; i < 5; i++) Y6922[i] = 236;};
	Y6922[5] = 917;
	Y6922[253] = 917;
	Y6922[2396] = 917;
}

long O6923[2397];
void O6923_init () {
	{long i; for (i = 0; i < 3; i++) O6923[i] = + _LNGOFF_1_3_0_0_;}
	{long i; for (i = 3; i < 5; i++) O6923[i] = + _LNGOFF_2_4_0_0_;}
	O6923[5] = + _LNGOFF_2_5_0_0_;
	O6923[253] = + _LNGOFF_3_5_0_0_;
	O6923[2396] = + _LNGOFF_4_6_0_0_;
}


#ifdef __cplusplus
}
#endif
