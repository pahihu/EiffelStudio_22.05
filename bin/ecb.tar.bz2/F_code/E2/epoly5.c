#include "epoly5.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R2074[2])();
void R2074_init () {
	R2074[0] = (char *(*)()) F95_2067;
	R2074[1] = (char *(*)()) F96_2067_2074_1;
}
static EIF_REFERENCE F96_2067_2074_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F96_2067(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(2055, 0x00).id, 2055, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R2079[6])();
void R2079_init () {
	R2079[0] = (char *(*)()) F97_2070;
	R2079[1] = (char *(*)()) F98_2070;
	R2079[2] = (char *(*)()) F99_2070;
	R2079[3] = (char *(*)()) F100_2070;
	R2079[4] = (char *(*)()) F101_2070;
	R2079[5] = (char *(*)()) F102_2070;
}

char *(*R2084[6])();
void R2084_init () {
	R2084[0] = (char *(*)()) F97_2075;
	R2084[1] = (char *(*)()) F98_2075_2084_55;
	R2084[2] = (char *(*)()) F99_2075_2084_55;
	R2084[3] = (char *(*)()) F100_2075_2084_55;
	R2084[4] = (char *(*)()) F101_2075_2084_55;
	R2084[5] = (char *(*)()) F102_2075_2084_55;
}
static void F98_2075_2084_55 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F98_2075(Current, arg1, *(EIF_NATURAL_32 *)arg2, arg3);
}
static void F99_2075_2084_55 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F99_2075(Current, arg1, *(EIF_NATURAL_64 *)arg2, arg3);
}
static void F100_2075_2084_55 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F100_2075(Current, arg1, *(EIF_INTEGER_32 *)arg2, arg3);
}
static void F101_2075_2084_55 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F101_2075(Current, arg1, *(EIF_BOOLEAN *)arg2, arg3);
}
static void F102_2075_2084_55 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F102_2075(Current, arg1, *(EIF_CHARACTER_8 *)arg2, arg3);
}

char *(*R2087[6])();
void R2087_init () {
	R2087[0] = (char *(*)()) F97_2078;
	R2087[1] = (char *(*)()) F98_2078;
	R2087[2] = (char *(*)()) F99_2078;
	R2087[3] = (char *(*)()) F100_2078;
	R2087[4] = (char *(*)()) F101_2078;
	R2087[5] = (char *(*)()) F102_2078;
}

char *(*R2898[2158])();
void R2898_init () {
	R2898[0] = (char *(*)()) F1657_15386;
	R2898[1] = (char *(*)()) F1658_15394;
	R2898[2157] = (char *(*)()) F3814_45370;
}

char *(*R3161[2])();
void R3161_init () {
	R3161[0] = (char *(*)()) F200_3194;
	R3161[1] = (char *(*)()) F201_3206;
}

char *(*R3163[2])();
void R3163_init () {
	R3163[0] = (char *(*)()) F200_3199;
	R3163[1] = (char *(*)()) F201_3209;
}

char *(*R3166[2])();
void R3166_init () {
	R3166[0] = (char *(*)()) F199_3189;
	R3166[1] = (char *(*)()) F201_3212;
}

char *(*R3169[2])();
void R3169_init () {
	R3169[0] = (char *(*)()) F200_3202;
	R3169[1] = (char *(*)()) F201_3217;
}

char *(*R3492[201])();
void R3492_init () {
	R3492[0] = (char *(*)()) F3605_41077;
	R3492[2] = (char *(*)()) F3607_41297;
	R3492[200] = (char *(*)()) F3607_41297;
}

char *(*R3496[201])();
void R3496_init () {
	R3496[0] = (char *(*)()) F3605_41079;
	R3496[2] = (char *(*)()) F3607_41378;
	R3496[200] = (char *(*)()) F3607_41378;
}

char *(*R3765[2])();
void R3765_init () {
	R3765[0] = (char *(*)()) F917_12944_3765_32;
	R3765[1] = (char *(*)()) F918_12963_3765_32;
}
static EIF_REFERENCE F917_12944_3765_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F917_12944(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(2085, 0x00).id, 2085, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F918_12963_3765_32 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F918_12963(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(2085, 0x00).id, 2085, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R3766[2])();
void R3766_init () {
	R3766[0] = (char *(*)()) F917_12948;
	R3766[1] = (char *(*)()) F918_12971;
}

char *(*R3767[2])();
void R3767_init () {
	R3767[0] = (char *(*)()) F917_12950_3767_43;
	R3767[1] = (char *(*)()) F918_12975_3767_43;
}
static void F917_12950_3767_43 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F917_12950(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F918_12975_3767_43 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F918_12975(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}

char *(*R3768[2])();
void R3768_init () {
	R3768[0] = (char *(*)()) F917_12955;
	R3768[1] = (char *(*)()) F918_12984;
}

char *(*R3769[2])();
void R3769_init () {
	R3769[0] = (char *(*)()) F917_12956;
	R3769[1] = (char *(*)()) F918_12986;
}

char *(*R3771[2])();
void R3771_init () {
	R3771[0] = (char *(*)()) F917_12958;
	R3771[1] = (char *(*)()) F918_12988;
}

char *(*R3775[2])();
void R3775_init () {
	R3775[0] = (char *(*)()) F237_3804;
	R3775[1] = (char *(*)()) F918_12964;
}

char *(*R3776[2])();
void R3776_init () {
	R3776[0] = (char *(*)()) F237_3805;
	R3776[1] = (char *(*)()) F918_12965;
}

char *(*R3777[2])();
void R3777_init () {
	R3777[0] = (char *(*)()) F917_12945;
	R3777[1] = (char *(*)()) F918_12966;
}

char *(*R3778[2])();
void R3778_init () {
	R3778[0] = (char *(*)()) F917_12946;
	R3778[1] = (char *(*)()) F918_12967;
}

char *(*R3779[2])();
void R3779_init () {
	R3779[0] = (char *(*)()) F917_12947;
	R3779[1] = (char *(*)()) F918_12968;
}

char *(*R3782[2])();
void R3782_init () {
	R3782[0] = (char *(*)()) F917_12949;
	R3782[1] = (char *(*)()) F237_3811;
}

char *(*R3783[2])();
void R3783_init () {
	R3783[0] = (char *(*)()) F237_3812;
	R3783[1] = (char *(*)()) F918_12972;
}

char *(*R3784[2])();
void R3784_init () {
	R3784[0] = (char *(*)()) F917_12951;
	R3784[1] = (char *(*)()) F918_12977;
}

char *(*R3786[2])();
void R3786_init () {
	R3786[0] = (char *(*)()) F917_12953;
	R3786[1] = (char *(*)()) F918_12979;
}

char *(*R3788[2])();
void R3788_init () {
	R3788[0] = (char *(*)()) F917_12954;
	R3788[1] = (char *(*)()) F918_12982;
}

char *(*R3978[4])();
void R3978_init () {
	R3978[0] = (char *(*)()) F2397_24272;
	R3978[1] = (char *(*)()) F2398_24291;
	R3978[2] = (char *(*)()) F2399_24311;
	R3978[3] = (char *(*)()) F2400_24330;
}

char *(*R3979[4])();
void R3979_init () {
	R3979[0] = (char *(*)()) F2397_24273;
	R3979[1] = (char *(*)()) F2398_24292;
	R3979[2] = (char *(*)()) F2399_24312;
	R3979[3] = (char *(*)()) F2400_24331;
}

char *(*R3980[4])();
void R3980_init () {
	R3980[0] = (char *(*)()) F2397_24274;
	R3980[1] = (char *(*)()) F2398_24293;
	R3980[2] = (char *(*)()) F2399_24313;
	R3980[3] = (char *(*)()) F2400_24332;
}

char *(*R3982[4])();
void R3982_init () {
	R3982[0] = (char *(*)()) F2397_24276;
	R3982[1] = (char *(*)()) F2398_24295;
	R3982[2] = (char *(*)()) F2399_24315;
	R3982[3] = (char *(*)()) F2400_24334;
}

char *(*R3983[4])();
void R3983_init () {
	R3983[0] = (char *(*)()) F2397_24277;
	R3983[1] = (char *(*)()) F2398_24296;
	R3983[2] = (char *(*)()) F2399_24316;
	R3983[3] = (char *(*)()) F2400_24335;
}

char *(*R4093[3517])();
void R4093_init () {
	R4093[0] = (char *(*)()) F281_4171;
	R4093[2022] = (char *(*)()) F2303_23026;
	R4093[3351] = (char *(*)()) F282_4177;
	{long i; for (i = 3376; i < 3380; i++) R4093[i] = (char *(*)()) F282_4177;}
	R4093[3391] = (char *(*)()) F282_4177;
	R4093[3399] = (char *(*)()) F282_4177;
	R4093[3452] = (char *(*)()) F282_4177;
	R4093[3455] = (char *(*)()) F282_4177;
	R4093[3458] = (char *(*)()) F282_4177;
	{long i; for (i = 3466; i < 3468; i++) R4093[i] = (char *(*)()) F282_4177;}
	{long i; for (i = 3473; i < 3478; i++) R4093[i] = (char *(*)()) F282_4177;}
	R4093[3480] = (char *(*)()) F282_4177;
	{long i; for (i = 3493; i < 3504; i++) R4093[i] = (char *(*)()) F282_4177;}
	{long i; for (i = 3505; i < 3509; i++) R4093[i] = (char *(*)()) F282_4177;}
	{long i; for (i = 3510; i < 3517; i++) R4093[i] = (char *(*)()) F282_4177;}
}

static EIF_TYPE_INDEX Y4354_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4354_pgtype1[] = {435,0xFFFF};
static EIF_TYPE_INDEX Y4354_pgtype2[] = {435,0xFFFF};
static EIF_TYPE_INDEX Y4354_pgtype3[] = {435,0xFFFF};
static EIF_TYPE_INDEX Y4354_pgtype4[] = {435,0xFFFF};
static EIF_TYPE_INDEX Y4354_pgtype5[] = {435,0xFFFF};
EIF_TYPE_INDEX *Y4354_gen_type [568];
EIF_TYPE_INDEX Y4354 [568];
void Y4354_init (void)
{
	egc_routines_types [4354] = Y4354;
	egc_routines_gen_types [4354] = Y4354_gen_type;
	egc_routines_offset [4354] = 302;
	Y4354_gen_type [0] = Y4354_pgtype0;
	Y4354_gen_type [563] = Y4354_pgtype1;
	Y4354_gen_type [564] = Y4354_pgtype2;
	Y4354_gen_type [565] = Y4354_pgtype3;
	Y4354_gen_type [566] = Y4354_pgtype4;
	Y4354_gen_type [567] = Y4354_pgtype5;
	{long i; for (i = 563; i < 568; i++) Y4354[i] = 435;};
}

char *(*R4409[2])();
void R4409_init () {
	R4409[0] = (char *(*)()) F311_4495;
	R4409[1] = (char *(*)()) F312_4499;
}

char *(*R4410[2])();
void R4410_init () {
	R4410[0] = (char *(*)()) F311_4496;
	R4410[1] = (char *(*)()) F312_4500;
}

char *(*R4411[2])();
void R4411_init () {
	R4411[0] = (char *(*)()) F311_4497;
	R4411[1] = (char *(*)()) F312_4501;
}

char *(*R4852[2])();
void R4852_init () {
	R4852[0] = (char *(*)()) F337_4959;
	R4852[1] = (char *(*)()) F338_4980;
}

static EIF_TYPE_INDEX Y4874_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4874_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4874_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4874_pgtype3[] = {2247,0xFFFF};
static EIF_TYPE_INDEX Y4874_pgtype4[] = {2247,0xFFFF};
static EIF_TYPE_INDEX Y4874_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4874_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4874_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4874_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4874_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4874_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4874_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4874_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4874_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4874_pgtype14[] = {0xFFF8,2,0xFFFF};
EIF_TYPE_INDEX *Y4874_gen_type [2705];
EIF_TYPE_INDEX Y4874 [2705];
void Y4874_init (void)
{
	egc_routines_types [4874] = Y4874;
	egc_routines_gen_types [4874] = Y4874_gen_type;
	egc_routines_offset [4874] = 338;
	Y4874_gen_type [0] = Y4874_pgtype0;
	Y4874_gen_type [1] = Y4874_pgtype1;
	Y4874_gen_type [2] = Y4874_pgtype2;
	Y4874_gen_type [1346] = Y4874_pgtype3;
	Y4874_gen_type [1347] = Y4874_pgtype4;
	Y4874_gen_type [2668] = Y4874_pgtype5;
	Y4874_gen_type [2669] = Y4874_pgtype6;
	Y4874_gen_type [2691] = Y4874_pgtype7;
	Y4874_gen_type [2692] = Y4874_pgtype8;
	Y4874_gen_type [2699] = Y4874_pgtype9;
	Y4874_gen_type [2700] = Y4874_pgtype10;
	Y4874_gen_type [2701] = Y4874_pgtype11;
	Y4874_gen_type [2702] = Y4874_pgtype12;
	Y4874_gen_type [2703] = Y4874_pgtype13;
	Y4874_gen_type [2704] = Y4874_pgtype14;
	{long i; for (i = 1346; i < 1348; i++) Y4874[i] = 2247;};
}

char *(*R4904[1371])();
void R4904_init () {
	R4904[0] = (char *(*)()) F1691_15667;
	R4904[1] = (char *(*)()) F1692_15685;
	R4904[1370] = (char *(*)()) F3056_34712;
}


#ifdef __cplusplus
}
#endif
