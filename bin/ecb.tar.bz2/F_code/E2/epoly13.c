#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O6924[2397];
void O6924_init () {
	{long i; for (i = 0; i < 3; i++) O6924[i] = + _LNGOFF_1_3_0_1_;}
	{long i; for (i = 3; i < 5; i++) O6924[i] = + _LNGOFF_2_4_0_1_;}
	O6924[5] = + _LNGOFF_2_5_0_1_;
	O6924[253] = + _LNGOFF_3_5_0_1_;
	O6924[2396] = + _LNGOFF_4_6_0_1_;
}

long O6925[2397];
void O6925_init () {
	{long i; for (i = 0; i < 3; i++) O6925[i] = + _LNGOFF_1_3_0_2_;}
	{long i; for (i = 3; i < 5; i++) O6925[i] = + _LNGOFF_2_4_0_2_;}
	O6925[5] = + _LNGOFF_2_5_0_2_;
	O6925[253] = + _LNGOFF_3_5_0_2_;
	O6925[2396] = + _LNGOFF_4_6_0_2_;
}

long O6926[2397];
void O6926_init () {
	{long i; for (i = 0; i < 3; i++) O6926[i] = + _LNGOFF_1_3_0_3_;}
	{long i; for (i = 3; i < 5; i++) O6926[i] = + _LNGOFF_2_4_0_3_;}
	O6926[5] = + _LNGOFF_2_5_0_3_;
	O6926[253] = + _LNGOFF_3_5_0_3_;
	O6926[2396] = + _LNGOFF_4_6_0_3_;
}

long O6927[2397];
void O6927_init () {
	{long i; for (i = 0; i < 3; i++) O6927[i] = + _LNGOFF_1_3_0_4_;}
	{long i; for (i = 3; i < 5; i++) O6927[i] = + _LNGOFF_2_4_0_4_;}
	O6927[5] = + _LNGOFF_2_5_0_4_;
	O6927[253] = + _LNGOFF_3_5_0_4_;
	O6927[2396] = + _LNGOFF_4_6_0_4_;
}

long O6928[2397];
void O6928_init () {
	{long i; for (i = 0; i < 3; i++) O6928[i] = + _LNGOFF_1_3_0_5_;}
	{long i; for (i = 3; i < 5; i++) O6928[i] = + _LNGOFF_2_4_0_5_;}
	O6928[5] = + _LNGOFF_2_5_0_5_;
	O6928[253] = + _LNGOFF_3_5_0_5_;
	O6928[2396] = + _LNGOFF_4_6_0_5_;
}


#ifdef __cplusplus
}
#endif
