#include "epoly11.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R6642[1974])();
void R6642_init () {
	{long i; for (i = 0; i < 2; i++) R6642[i] = (char *(*)()) F481_6937;}
	R6642[1973] = (char *(*)()) F2455_24675;
}

char *(*R6649[3])();
void R6649_init () {
	R6649[0] = (char *(*)()) F485_6956;
	R6649[1] = (char *(*)()) F486_6963;
	R6649[2] = (char *(*)()) F487_6966;
}

char *(*R6663[13])();
void R6663_init () {
	R6663[0] = (char *(*)()) F490_6982;
	R6663[1] = (char *(*)()) F491_6984;
	R6663[3] = (char *(*)()) F493_6993;
	R6663[4] = (char *(*)()) F494_6995;
	R6663[5] = (char *(*)()) F495_6997;
	{long i; for (i = 7; i < 13; i++) R6663[i] = (char *(*)()) F496_6999;}
}

char *(*R6664[13])();
void R6664_init () {
	R6664[0] = (char *(*)()) F490_6983;
	R6664[1] = (char *(*)()) F491_6985;
	{long i; for (i = 3; i < 6; i++) R6664[i] = (char *(*)()) F492_6986;}
	{long i; for (i = 7; i < 13; i++) R6664[i] = (char *(*)()) F496_7000;}
}

char *(*R6666[13])();
void R6666_init () {
	{long i; for (i = 0; i < 2; i++) R6666[i] = (char *(*)()) F489_6976;}
	{long i; for (i = 3; i < 6; i++) R6666[i] = (char *(*)()) F492_6991;}
	{long i; for (i = 7; i < 13; i++) R6666[i] = (char *(*)()) F496_7018;}
}

char *(*R6667[13])();
void R6667_init () {
	{long i; for (i = 0; i < 2; i++) R6667[i] = (char *(*)()) F489_6979;}
	{long i; for (i = 3; i < 6; i++) R6667[i] = (char *(*)()) F492_6988;}
	{long i; for (i = 7; i < 13; i++) R6667[i] = (char *(*)()) F496_7012;}
}

char *(*R6668[13])();
void R6668_init () {
	{long i; for (i = 0; i < 2; i++) R6668[i] = (char *(*)()) F489_6980;}
	{long i; for (i = 3; i < 6; i++) R6668[i] = (char *(*)()) F492_6989;}
	R6668[7] = (char *(*)()) F497_7023;
	R6668[8] = (char *(*)()) F498_7037;
	R6668[9] = (char *(*)()) F499_7052;
	R6668[10] = (char *(*)()) F500_7067;
	R6668[11] = (char *(*)()) F501_7082;
	R6668[12] = (char *(*)()) F502_7097;
}

char *(*R6669[13])();
void R6669_init () {
	{long i; for (i = 0; i < 2; i++) R6669[i] = (char *(*)()) F489_6981;}
	{long i; for (i = 3; i < 6; i++) R6669[i] = (char *(*)()) F492_6990;}
	R6669[7] = (char *(*)()) F497_7022;
	R6669[8] = (char *(*)()) F498_7046;
	R6669[9] = (char *(*)()) F499_7051;
	R6669[10] = (char *(*)()) F500_7066;
	R6669[11] = (char *(*)()) F501_7081;
	R6669[12] = (char *(*)()) F502_7096;
}

char *(*R6675[6])();
void R6675_init () {
	R6675[0] = (char *(*)()) F497_7020;
	R6675[1] = (char *(*)()) F498_7035;
	R6675[2] = (char *(*)()) F499_7049;
	R6675[3] = (char *(*)()) F500_7064;
	R6675[4] = (char *(*)()) F501_7079;
	R6675[5] = (char *(*)()) F502_7094;
}

char *(*R6676[6])();
void R6676_init () {
	R6676[0] = (char *(*)()) F497_7028;
	R6676[1] = (char *(*)()) F498_7042;
	R6676[2] = (char *(*)()) F499_7057;
	R6676[3] = (char *(*)()) F500_7072;
	R6676[4] = (char *(*)()) F501_7087;
	R6676[5] = (char *(*)()) F502_7102;
}

char *(*R6680[6])();
void R6680_init () {
	R6680[0] = (char *(*)()) F497_7024;
	R6680[1] = (char *(*)()) F498_7038;
	R6680[2] = (char *(*)()) F499_7053;
	R6680[3] = (char *(*)()) F500_7068;
	R6680[4] = (char *(*)()) F501_7083;
	R6680[5] = (char *(*)()) F502_7098;
}

char *(*R6685[6])();
void R6685_init () {
	R6685[0] = (char *(*)()) F497_7029;
	R6685[1] = (char *(*)()) F498_7043;
	R6685[2] = (char *(*)()) F499_7058;
	R6685[3] = (char *(*)()) F500_7073;
	R6685[4] = (char *(*)()) F501_7088;
	R6685[5] = (char *(*)()) F502_7103;
}

char *(*R6727[1809])();
void R6727_init () {
	R6727[0] = (char *(*)()) F504_7115;
	R6727[1] = (char *(*)()) F506_7127;
	{long i; for (i = 1807; i < 1809; i++) R6727[i] = (char *(*)()) F504_7115;}
}

char *(*R6728[1809])();
void R6728_init () {
	R6728[0] = (char *(*)()) F504_7116;
	R6728[1] = (char *(*)()) F506_7126;
	{long i; for (i = 1807; i < 1809; i++) R6728[i] = (char *(*)()) F504_7116;}
}

char *(*R6729[1809])();
void R6729_init () {
	R6729[0] = (char *(*)()) F505_7119;
	R6729[1] = (char *(*)()) F506_7128;
	R6729[1807] = (char *(*)()) F2312_23289;
	R6729[1808] = (char *(*)()) F2313_23290;
}

char *(*R6748[7])();
void R6748_init () {
	R6748[0] = (char *(*)()) F511_7143;
	R6748[1] = (char *(*)()) F512_7145;
	R6748[2] = (char *(*)()) F513_7145;
	R6748[3] = (char *(*)()) F514_7145;
	R6748[4] = (char *(*)()) F515_7147;
	R6748[5] = (char *(*)()) F516_7147;
	R6748[6] = (char *(*)()) F517_7147;
}

static EIF_TYPE_INDEX Y6750_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6750_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6750_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6750_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6750_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6750_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6750_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6750_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6750_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6750_pgtype9[] = {0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y6750_gen_type [10];
EIF_TYPE_INDEX Y6750 [10];
void Y6750_init (void)
{
	egc_routines_types [6750] = Y6750;
	egc_routines_gen_types [6750] = Y6750_gen_type;
	egc_routines_offset [6750] = 507;
	Y6750_gen_type [0] = Y6750_pgtype0;
	Y6750_gen_type [1] = Y6750_pgtype1;
	Y6750_gen_type [2] = Y6750_pgtype2;
	Y6750_gen_type [3] = Y6750_pgtype3;
	Y6750_gen_type [4] = Y6750_pgtype4;
	Y6750_gen_type [5] = Y6750_pgtype5;
	Y6750_gen_type [6] = Y6750_pgtype6;
	Y6750_gen_type [7] = Y6750_pgtype7;
	Y6750_gen_type [8] = Y6750_pgtype8;
	Y6750_gen_type [9] = Y6750_pgtype9;
}

char *(*R6859[1398])();
void R6859_init () {
	R6859[0] = (char *(*)()) F524_7299;
	R6859[1396] = (char *(*)()) F1921_18278;
	R6859[1397] = (char *(*)()) F1922_18306;
}

char *(*R6860[1398])();
void R6860_init () {
	R6860[0] = (char *(*)()) F524_7300;
	R6860[1396] = (char *(*)()) F1921_18282;
	R6860[1397] = (char *(*)()) F1922_18308;
}


#ifdef __cplusplus
}
#endif
