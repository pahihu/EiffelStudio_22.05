#include "epoly16.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R6939[2397])();
void R6939_init () {
	R6939[0] = (char *(*)()) F536_7385;
	R6939[2] = (char *(*)()) F536_7385;
	R6939[3] = (char *(*)()) F539_7412;
	R6939[253] = (char *(*)()) F539_7412;
	R6939[2396] = (char *(*)()) F539_7412;
}

char *(*R6940[2397])();
void R6940_init () {
	R6940[0] = (char *(*)()) F536_7386;
	{long i; for (i = 2; i < 4; i++) R6940[i] = (char *(*)()) F536_7386;}
	R6940[253] = (char *(*)()) F541_7439;
	R6940[2396] = (char *(*)()) F541_7439;
}

char *(*R6942[2397])();
void R6942_init () {
	R6942[0] = (char *(*)()) F536_7388;
	R6942[2] = (char *(*)()) F538_7400;
	R6942[3] = (char *(*)()) F536_7388;
	R6942[253] = (char *(*)()) F538_7400;
	R6942[2396] = (char *(*)()) F538_7400;
}

char *(*R6954[2394])();
void R6954_init () {
	R6954[0] = (char *(*)()) F539_7402;
	R6954[250] = (char *(*)()) F789_11157;
	R6954[2393] = (char *(*)()) F539_7402;
}

char *(*R6983[3])();
void R6983_init () {
	R6983[0] = (char *(*)()) F549_7455;
	R6983[1] = (char *(*)()) F550_7458;
	R6983[2] = (char *(*)()) F551_7461;
}

char *(*R6984[3])();
void R6984_init () {
	R6984[0] = (char *(*)()) F549_7456;
	R6984[1] = (char *(*)()) F550_7459;
	R6984[2] = (char *(*)()) F551_7462;
}

char *(*R6985[3])();
void R6985_init () {
	R6985[0] = (char *(*)()) F549_7457;
	R6985[1] = (char *(*)()) F550_7460;
	R6985[2] = (char *(*)()) F551_7463;
}

char *(*R6989[603])();
void R6989_init () {
	R6989[0] = (char *(*)()) F554_7468;
	R6989[1] = (char *(*)()) F555_7468_6989_1;
	R6989[2] = (char *(*)()) F556_7468_6989_1;
	R6989[3] = (char *(*)()) F557_7468_6989_1;
	R6989[4] = (char *(*)()) F558_7468_6989_1;
	R6989[5] = (char *(*)()) F559_7468_6989_1;
	{long i; for (i = 6; i < 8; i++) R6989[i] = (char *(*)()) F554_7468;}
	R6989[8] = (char *(*)()) F557_7468_6989_1;
	R6989[9] = (char *(*)()) F558_7468_6989_1;
	R6989[10] = (char *(*)()) F555_7468_6989_1;
	R6989[11] = (char *(*)()) F559_7468_6989_1;
	R6989[12] = (char *(*)()) F554_7468;
	R6989[13] = (char *(*)()) F555_7468_6989_1;
	R6989[602] = (char *(*)()) F555_7468_6989_1;
}
static EIF_REFERENCE F555_7468_6989_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F555_7468(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(2055, 0x00).id, 2055, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F556_7468_6989_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F556_7468(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(2067, 0x00).id, 2067, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F557_7468_6989_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F557_7468(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(2088, 0x00).id, 2088, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F558_7468_6989_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F558_7468(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(2064, 0x00).id, 2064, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F559_7468_6989_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F559_7468(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(2082, 0x00).id, 2082, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}


#ifdef __cplusplus
}
#endif
