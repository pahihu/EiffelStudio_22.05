#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O6929[2397];
void O6929_init () {
	{long i; for (i = 0; i < 3; i++) O6929[i] = + _CHROFF_1_0_;}
	{long i; for (i = 3; i < 6; i++) O6929[i] = + _CHROFF_2_0_;}
	O6929[253] = + _CHROFF_3_0_;
	O6929[2396] = + _CHROFF_4_0_;
}

long O6934[2397];
void O6934_init () {
	{long i; for (i = 0; i < 3; i++) O6934[i] = + _CHROFF_1_1_;}
	{long i; for (i = 3; i < 6; i++) O6934[i] = + _CHROFF_2_1_;}
	O6934[253] = + _CHROFF_3_1_;
	O6934[2396] = + _CHROFF_4_1_;
}

long O6935[2397];
void O6935_init () {
	{long i; for (i = 0; i < 3; i++) O6935[i] = + _CHROFF_1_2_;}
	{long i; for (i = 3; i < 6; i++) O6935[i] = + _CHROFF_2_2_;}
	O6935[253] = + _CHROFF_3_2_;
	O6935[2396] = + _CHROFF_4_2_;
}

long O6956[2394];
void O6956_init () {
	{long i; for (i = 0; i < 3; i++) O6956[i] = + _CHROFF_2_3_;}
	O6956[250] = + _CHROFF_3_3_;
	O6956[2393] = + _CHROFF_4_3_;
}

long O6966[2392];
void O6966_init () {
	O6966[0] = + _LNGOFF_2_5_0_6_;
	O6966[248] = + _LNGOFF_3_5_0_6_;
	O6966[2391] = + _LNGOFF_4_6_0_6_;
}


#ifdef __cplusplus
}
#endif
