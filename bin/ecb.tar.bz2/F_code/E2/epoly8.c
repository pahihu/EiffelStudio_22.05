#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O4756[2];
void O4756_init () {
	O4756[0] = + _LNGOFF_1_0_0_0_;
	O4756[1] = + _LNGOFF_2_0_0_0_;
}

long O4794[2];
void O4794_init () {
	O4794[0] = + _LNGOFF_11_0_0_0_;
	O4794[1] = + _LNGOFF_12_0_0_0_;
}

long O4843[3];
void O4843_init () {
	O4843[0] = + _CHROFF_3_0_;
	O4843[1] = + _CHROFF_4_0_;
	O4843[2] = + _CHROFF_5_0_;
}

long O4930[7];
void O4930_init () {
	{long i; for (i = 0; i < 2; i++) O4930[i] = + _LNGOFF_0_0_0_0_;}
	O4930[2] = + _LNGOFF_3_0_0_0_;
	O4930[3] = + _LNGOFF_2_0_0_0_;
	O4930[4] = + _LNGOFF_3_0_0_0_;
	O4930[5] = + _LNGOFF_2_0_0_0_;
	O4930[6] = + _LNGOFF_3_0_0_0_;
}

long O4940[5];
void O4940_init () {
	O4940[0] = 0;
	O4940[1] = + _I64OFF_2_0_0_1_0_0_0_;
	O4940[2] = 0;
	O4940[3] = + _I64OFF_2_0_0_1_0_0_0_;
	O4940[4] = 0;
}

static EIF_TYPE_INDEX Y4940_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4940_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4940_pgtype2[] = {1604,2088,0xFFFF};
static EIF_TYPE_INDEX Y4940_pgtype3[] = {0xFFF9,3,2049,2088,322,2542,0xFFFF};
EIF_TYPE_INDEX *Y4940_gen_type [5];
EIF_TYPE_INDEX Y4940 [5];
void Y4940_init (void)
{
	egc_routines_types [4940] = Y4940;
	egc_routines_gen_types [4940] = Y4940_gen_type;
	egc_routines_offset [4940] = 351;
	Y4940_gen_type [0] = Y4940_pgtype0;
	Y4940_gen_type [1] = Y4940_pgtype1;
	Y4940_gen_type [2] = Y4940_pgtype2;
	Y4940_gen_type [4] = Y4940_pgtype3;
	Y4940[2] = 1604;
	Y4940[3] = 2064;
	Y4940[4] = 2049;
}

long O4941[5];
void O4941_init () {
	O4941[0] =  + _REFACS_1_;
	O4941[1] = 0;
	O4941[2] =  + _REFACS_1_;
	O4941[3] = 0;
	O4941[4] =  + _REFACS_1_;
}

long O4942[5];
void O4942_init () {
	O4942[0] =  + _REFACS_2_;
	O4942[1] =  + _REFACS_1_;
	O4942[2] =  + _REFACS_2_;
	O4942[3] =  + _REFACS_1_;
	O4942[4] =  + _REFACS_2_;
}

long O5057[3];
void O5057_init () {
	O5057[0] = + _LNGOFF_1_0_0_0_;
	O5057[1] = + _LNGOFF_2_0_0_0_;
	O5057[2] = + _LNGOFF_1_0_0_0_;
}

long O5061[3];
void O5061_init () {
	O5061[0] = + _LNGOFF_1_0_0_1_;
	O5061[1] = + _LNGOFF_2_0_0_1_;
	O5061[2] = + _LNGOFF_1_0_0_1_;
}

long O5194[2862];
void O5194_init () {
	O5194[0] = + _R64OFF_0_0_0_1_0_0_0_0_;
	{long i; for (i = 2852; i < 2854; i++) O5194[i] = + _R64OFF_0_0_0_1_0_0_0_0_;}
	O5194[2859] = + _R64OFF_0_0_0_2_0_0_0_0_;
	O5194[2860] = + _R64OFF_5_1_0_8_0_0_0_0_;
	O5194[2861] = + _R64OFF_2_0_0_2_0_0_0_0_;
}

long O5195[2862];
void O5195_init () {
	O5195[0] = + _LNGOFF_0_0_0_0_;
	{long i; for (i = 2852; i < 2854; i++) O5195[i] = + _LNGOFF_0_0_0_0_;}
	O5195[2859] = + _LNGOFF_0_0_0_0_;
	O5195[2860] = + _LNGOFF_5_1_0_0_;
	O5195[2861] = + _LNGOFF_2_0_0_0_;
}

EIF_TYPE_INDEX *Y5227_gen_type [2859];
EIF_TYPE_INDEX Y5227 [2859];
void Y5227_init (void)
{
	egc_routines_types [5227] = Y5227;
	egc_routines_gen_types [5227] = Y5227_gen_type;
	egc_routines_offset [5227] = 378;
	Y5227[0] = 375;
	Y5227[2858] = 3228;
}

EIF_TYPE_INDEX *Y5228_gen_type [2859];
EIF_TYPE_INDEX Y5228 [2859];
void Y5228_init (void)
{
	egc_routines_types [5228] = Y5228;
	egc_routines_gen_types [5228] = Y5228_gen_type;
	egc_routines_offset [5228] = 378;
	Y5228[0] = 925;
	Y5228[2858] = 3232;
}


#ifdef __cplusplus
}
#endif
