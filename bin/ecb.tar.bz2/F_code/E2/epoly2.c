#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O2074[2];
void O2074_init () {
	O2074[0] =  + _REFACS_1_;
	O2074[1] = + _LNGOFF_1_0_0_0_;
}

EIF_TYPE_INDEX *Y3018_gen_type [2];
EIF_TYPE_INDEX Y3018 [2];
void Y3018_init (void)
{
	egc_routines_types [3018] = Y3018;
	egc_routines_gen_types [3018] = Y3018_gen_type;
	egc_routines_offset [3018] = 183;
	Y3018[0] = 364;
	Y3018[1] = 365;
}

long O3165[3];
void O3165_init () {
	O3165[0] = + _CHROFF_2_0_;
	O3165[1] = + _CHROFF_4_0_;
	O3165[2] = + _CHROFF_6_0_;
}

long O3170[3];
void O3170_init () {
	O3170[0] = + _LNGOFF_2_1_0_0_;
	O3170[1] = + _LNGOFF_4_2_0_0_;
	O3170[2] = + _LNGOFF_6_2_0_2_;
}

long O3174[2];
void O3174_init () {
	O3174[0] = + _CHROFF_4_1_;
	O3174[1] = + _CHROFF_6_1_;
}

long O3646[2];
void O3646_init () {
	O3646[0] = 0;
	O3646[1] =  + _REFACS_22_;
}

long O3647[2];
void O3647_init () {
	O3647[0] = + _LNGOFF_12_0_0_0_;
	O3647[1] = + _LNGOFF_35_0_0_1_;
}

long O3651[2];
void O3651_init () {
	O3651[0] =  + _REFACS_1_;
	O3651[1] =  + _REFACS_23_;
}

long O3652[2];
void O3652_init () {
	O3652[0] = + _LNGOFF_12_0_0_1_;
	O3652[1] = + _LNGOFF_35_0_0_2_;
}

long O3653[2];
void O3653_init () {
	O3653[0] =  + _REFACS_2_;
	O3653[1] =  + _REFACS_24_;
}

long O3654[2];
void O3654_init () {
	O3654[0] =  + _REFACS_3_;
	O3654[1] =  + _REFACS_25_;
}

long O3655[2];
void O3655_init () {
	O3655[0] =  + _REFACS_4_;
	O3655[1] =  + _REFACS_26_;
}

long O3656[2];
void O3656_init () {
	O3656[0] =  + _REFACS_5_;
	O3656[1] =  + _REFACS_27_;
}

long O3657[2];
void O3657_init () {
	O3657[0] =  + _REFACS_6_;
	O3657[1] =  + _REFACS_28_;
}

long O3658[2];
void O3658_init () {
	O3658[0] =  + _REFACS_7_;
	O3658[1] =  + _REFACS_29_;
}

long O3659[2];
void O3659_init () {
	O3659[0] = + _LNGOFF_12_0_0_2_;
	O3659[1] = + _LNGOFF_35_0_0_3_;
}

long O3663[2];
void O3663_init () {
	O3663[0] =  + _REFACS_8_;
	O3663[1] =  + _REFACS_30_;
}

long O3664[2];
void O3664_init () {
	O3664[0] = + _LNGOFF_12_0_0_3_;
	O3664[1] = + _LNGOFF_35_0_0_4_;
}

long O3665[2];
void O3665_init () {
	O3665[0] =  + _REFACS_9_;
	O3665[1] =  + _REFACS_31_;
}

long O3666[2];
void O3666_init () {
	O3666[0] =  + _REFACS_10_;
	O3666[1] =  + _REFACS_32_;
}

long O3667[2];
void O3667_init () {
	O3667[0] =  + _REFACS_11_;
	O3667[1] =  + _REFACS_33_;
}

EIF_TYPE_INDEX *Y3974_gen_type [2135];
EIF_TYPE_INDEX Y3974 [2135];
void Y3974_init (void)
{
	egc_routines_types [3974] = Y3974;
	egc_routines_gen_types [3974] = Y3974_gen_type;
	egc_routines_offset [3974] = 265;
	Y3974[0] = 0;
	Y3974[2124] = 2384;
	Y3974[2125] = 2385;
	Y3974[2126] = 2603;
	Y3974[2127] = 2605;
	Y3974[2128] = 2608;
	Y3974[2129] = 2607;
	Y3974[2130] = 2386;
	Y3974[2131] = 2388;
	Y3974[2132] = 2387;
	Y3974[2133] = 2846;
	Y3974[2134] = 2609;
}

long O4080[3517];
void O4080_init () {
	{long i; for (i = 0; i < 3; i++) O4080[i] = + _LNGOFF_1_0_0_0_;}
	O4080[2022] = + _LNGOFF_1_0_0_0_;
	O4080[3351] = + _LNGOFF_2_0_0_0_;
	{long i; for (i = 3376; i < 3380; i++) O4080[i] = + _LNGOFF_3_1_0_0_;}
	O4080[3391] = + _LNGOFF_2_0_0_0_;
	O4080[3399] = + _LNGOFF_4_0_0_0_;
	O4080[3452] = + _LNGOFF_2_0_0_0_;
	O4080[3455] = + _LNGOFF_2_3_0_0_;
	O4080[3458] = + _LNGOFF_5_0_0_0_;
	{long i; for (i = 3465; i < 3467; i++) O4080[i] = + _LNGOFF_4_1_0_0_;}
	O4080[3467] = + _LNGOFF_5_1_0_0_;
	{long i; for (i = 3472; i < 3474; i++) O4080[i] = + _LNGOFF_2_0_0_0_;}
	O4080[3474] = + _LNGOFF_3_0_0_0_;
	{long i; for (i = 3475; i < 3478; i++) O4080[i] = + _LNGOFF_2_0_0_0_;}
	O4080[3480] = + _LNGOFF_4_1_0_0_;
	{long i; for (i = 3492; i < 3496; i++) O4080[i] = + _LNGOFF_3_0_0_0_;}
	O4080[3496] = + _LNGOFF_4_0_0_0_;
	{long i; for (i = 3497; i < 3517; i++) O4080[i] = + _LNGOFF_3_0_0_0_;}
}

EIF_TYPE_INDEX *Y4080_gen_type [3517];
EIF_TYPE_INDEX Y4080 [3517];
void Y4080_init (void)
{
	egc_routines_types [4080] = Y4080;
	egc_routines_gen_types [4080] = Y4080_gen_type;
	egc_routines_offset [4080] = 280;
	{long i; for (i = 0; i < 3; i++) Y4080[i] = 2055;};
	Y4080[2022] = 2055;
	Y4080[3351] = 2055;
	{long i; for (i = 3376; i < 3380; i++) Y4080[i] = 2055;};
	Y4080[3391] = 2055;
	Y4080[3399] = 2055;
	Y4080[3452] = 2055;
	Y4080[3455] = 2055;
	Y4080[3458] = 2055;
	{long i; for (i = 3465; i < 3468; i++) Y4080[i] = 2055;};
	{long i; for (i = 3472; i < 3478; i++) Y4080[i] = 2055;};
	Y4080[3480] = 2055;
	{long i; for (i = 3492; i < 3517; i++) Y4080[i] = 2055;};
}

long O4100[3515];
void O4100_init () {
	O4100[0] = + _LNGOFF_1_0_0_1_;
	O4100[3349] = + _LNGOFF_2_0_0_1_;
	{long i; for (i = 3374; i < 3378; i++) O4100[i] = + _LNGOFF_3_1_0_1_;}
	O4100[3389] = + _LNGOFF_2_0_0_1_;
	O4100[3397] = + _LNGOFF_4_0_0_1_;
	O4100[3450] = + _LNGOFF_2_0_0_1_;
	O4100[3453] = + _LNGOFF_2_3_0_1_;
	O4100[3456] = + _LNGOFF_5_0_0_1_;
	{long i; for (i = 3463; i < 3465; i++) O4100[i] = + _LNGOFF_4_1_0_1_;}
	O4100[3465] = + _LNGOFF_5_1_0_1_;
	{long i; for (i = 3470; i < 3472; i++) O4100[i] = + _LNGOFF_2_0_0_1_;}
	O4100[3472] = + _LNGOFF_3_0_0_1_;
	{long i; for (i = 3473; i < 3476; i++) O4100[i] = + _LNGOFF_2_0_0_1_;}
	O4100[3478] = + _LNGOFF_4_1_0_1_;
	{long i; for (i = 3490; i < 3494; i++) O4100[i] = + _LNGOFF_3_0_0_1_;}
	O4100[3494] = + _LNGOFF_4_0_0_1_;
	{long i; for (i = 3495; i < 3515; i++) O4100[i] = + _LNGOFF_3_0_0_1_;}
}


#ifdef __cplusplus
}
#endif
