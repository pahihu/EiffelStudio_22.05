
#ifndef _C53_ke2621_
#define _C53_ke2621_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3671_43503(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2621(void);
extern char *(*R7802[])();

#ifdef __cplusplus
}
#endif

#endif
