/*
 * Code for class FORMAL_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "fo2636.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {FORMAL_AS}.initialize */
void F3687_43631 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN arg3, EIF_BOOLEAN arg4, EIF_REFERENCE arg5)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg5);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_6_) = (EIF_BOOLEAN) arg2;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_7_) = (EIF_BOOLEAN) arg3;
	if (arg4) {
		{
			/* INLINED CODE (TYPE_AS.set_variance_mark) */
			if ((EIF_BOOLEAN)(arg5 == NULL)) {
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_8_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			} else {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg5) + O31853[Dtype(arg5)-3689]);
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_8_0_3_) = (EIF_INTEGER_32) ti4_1;
			}
			*(EIF_BOOLEAN *)(Current+ _CHROFF_1_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			*(EIF_BOOLEAN *)(Current+ _CHROFF_1_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			/* END INLINED CODE */
		}
		;
	}
	if ((EIF_BOOLEAN)(arg5 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg5) + O31853[Dtype(arg5)-3689]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_8_0_5_) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

/* {FORMAL_AS}.process */
void F3687_43632 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7885[Dtype(RTCW(arg1))-674])(arg1, Current);
}

/* {FORMAL_AS}.formal_keyword */
EIF_REFERENCE F3687_43634 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F3615_42860(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_8_0_5_));
}

/* {FORMAL_AS}.index */
EIF_INTEGER_32 F3687_43635 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_0_0_3_3_);
	RTLE;
	return Result;
}

/* {FORMAL_AS}.first_token */
EIF_REFERENCE F3687_43640 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	Result = F3681_43553(Current, arg1);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_8_0_5_) != ((EIF_INTEGER_32) 0L)))) {
			{
				/* INLINED CODE (FORMAL_AS.formal_keyword) */
				tr1 = (EIF_REFERENCE)  0;
				tr1 = F3615_42860(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_8_0_5_));
				/* END INLINED CODE */
			}
			Result = tr1;
			RTLE;
			return (EIF_REFERENCE) Result;
		} else {
			tr1 = *(EIF_REFERENCE *)(Current);
			{
				/* INLINED CODE (LEAF_AS.first_token) */
				tr2 = (EIF_REFERENCE)  0;
				(void) RTCW(tr1);
				tr2 = (EIF_REFERENCE) tr1;
				/* END INLINED CODE */
			}
			Result = tr2;
		}
	}
	RTLE;
	return Result;
}

/* {FORMAL_AS}.last_token */
EIF_REFERENCE F3687_43641 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	{
		/* INLINED CODE (TYPE_AS.last_token) */
		tr1 = (EIF_REFERENCE)  0;
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O31780[Dtype(Current)-3680]) != ((EIF_INTEGER_32) 0L)))) {
			tr1 = F3681_43545(Current, arg1);
		}
		/* END INLINED CODE */
	}
	Result = tr1;
	if ((EIF_BOOLEAN)(Result == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			/* INLINED CODE (LEAF_AS.last_token) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(tr1);
			tr2 = (EIF_REFERENCE) tr1;
			/* END INLINED CODE */
		}
		Result = tr2;
	}
	RTLE;
	return Result;
}

/* {FORMAL_AS}.is_equivalent */
EIF_BOOLEAN F3687_43642 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	tb2 = '\0';
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_8_0_6_);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_8_0_6_) == ti4_1)) {
		tb3 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_6_);
		tb2 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current+ _CHROFF_1_6_) == tb3);
	}
	if (tb2) {
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_7_);
		tb1 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current+ _CHROFF_1_7_) == tb2);
	}
	if (tb1) {
		Result = F3681_43563(Current, arg1);
	}
	RTLE;
	return Result;
}

/* {FORMAL_AS}.dump */
EIF_REFERENCE F3687_43643 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(2247, 0x00).id, 2247, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F2246_21883(RTCW(Result), ((EIF_INTEGER_32) 3L));
	F3681_43568(Current, Result);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_7_)) {
		tr1 = RTMS_EX_H("expanded ",9,1955322656);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17139[Dtype(RTCW(Result))-2247])(Result, tr1);
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_6_)) {
		tr1 = RTMS_EX_H("reference ",10,2121684768);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17139[Dtype(RTCW(Result))-2247])(Result, tr1);
	}
	tr1 = RTMS_EX_H("G#",2,18211);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17139[Dtype(RTCW(Result))-2247])(Result, tr1);
	F2248_21999(RTCW(Result), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_8_0_6_));
	RTLE;
	return Result;
}

/* {FORMAL_AS}.set_position */
void F3687_43644 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_8_0_6_) = (EIF_INTEGER_32) arg1;
}

void EIF_Minit2636 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
