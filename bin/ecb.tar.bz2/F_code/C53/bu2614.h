
#ifndef _C53_bu2614_
#define _C53_bu2614_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3663_43440(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F3663_43441(EIF_REFERENCE);
extern void F3663_43443(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F3663_43444(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2614(void);
extern EIF_BOOLEAN F3615_42842(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R7754[])();

#ifdef __cplusplus
}
#endif

#endif
