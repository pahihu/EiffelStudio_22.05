/*
 * Code for class LEAF_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "le2639.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LEAF_AS}.first_token */
EIF_REFERENCE F3690_43669 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) Current;
}

/* {LEAF_AS}.last_token */
EIF_REFERENCE F3690_43670 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) Current;
}

/* {LEAF_AS}.literal_text */
EIF_REFERENCE F3690_43672 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = F2492_26087(RTCW(arg1), *(EIF_INTEGER_32 *)(Current + O31853[Dtype(Current)-3689]));
		Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R31851[Dtype(RTCW(tr1))-3690])(tr1, NULL);
	}
	RTLE;
	return Result;
}

/* {LEAF_AS}.index */
EIF_INTEGER_32 F3690_43673 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O31853[Dtype(Current)-3689]);
}


/* {LEAF_AS}.set_index */
void F3690_43674 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O31853[Dtype(Current)-3689]) = (EIF_INTEGER_32) arg1;
}

void EIF_Minit2639 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
