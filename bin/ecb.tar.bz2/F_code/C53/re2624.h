
#ifndef _C53_re2624_
#define _C53_re2624_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3675_43514(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2624(void);
extern char *(*R7809[])();

#ifdef __cplusplus
}
#endif

#endif
