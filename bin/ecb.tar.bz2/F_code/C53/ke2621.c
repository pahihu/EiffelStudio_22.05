/*
 * Code for class KEY_LIST_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ke2621.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KEY_LIST_AS}.process */
void F3671_43503 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7802[Dtype(RTCW(arg1))-674])(arg1, Current);
}

void EIF_Minit2621 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
