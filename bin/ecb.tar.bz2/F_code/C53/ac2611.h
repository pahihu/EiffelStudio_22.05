
#ifndef _C53_ac2611_
#define _C53_ac2611_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3660_43415(EIF_REFERENCE, EIF_REFERENCE);
extern void F3660_43416(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2611(void);
extern void F3657_43397(EIF_REFERENCE, EIF_REFERENCE);
extern void F3632_43118(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R7759[])();

#ifdef __cplusplus
}
#endif

#endif
