/*
 * Code for class ALL_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "al2604.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ALL_AS}.initialize */
void F3653_43356 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O31853[Dtype(arg1)-3689]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

/* {ALL_AS}.process */
void F3653_43357 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7771[Dtype(RTCW(arg1))-674])(arg1, Current);
}

/* {ALL_AS}.all_keyword */
EIF_REFERENCE F3653_43359 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F3615_42860(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_));
}

/* {ALL_AS}.index */
EIF_INTEGER_32 F3653_43360 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_);
}

/* {ALL_AS}.is_equivalent */
EIF_BOOLEAN F3653_43361 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {ALL_AS}.first_token */
EIF_REFERENCE F3653_43362 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) != ((EIF_INTEGER_32) 0L)))) {
		{
			/* INLINED CODE (ALL_AS.all_keyword) */
			tr1 = (EIF_REFERENCE)  0;
			tr1 = F3615_42860(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_));
			/* END INLINED CODE */
		}
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {ALL_AS}.last_token */
EIF_REFERENCE F3653_43363 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) != ((EIF_INTEGER_32) 0L)))) {
		{
			/* INLINED CODE (ALL_AS.all_keyword) */
			tr1 = (EIF_REFERENCE)  0;
			tr1 = F3615_42860(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_));
			/* END INLINED CODE */
		}
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

void EIF_Minit2604 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
