
#ifndef _C53_ac2607_
#define _C53_ac2607_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F3656_43374(EIF_REFERENCE);
extern EIF_REFERENCE F3656_43375(EIF_REFERENCE);
extern void EIF_Minit2607(void);
extern EIF_REFERENCE F1769_16449(EIF_REFERENCE);
extern EIF_REFERENCE F164_2793(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R31682[])();

#ifdef __cplusplus
}
#endif

#endif
