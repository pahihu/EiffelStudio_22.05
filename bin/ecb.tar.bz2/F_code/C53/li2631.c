/*
 * Code for class LIKE_CUR_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li2631.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LIKE_CUR_AS}.make */
void F3682_43569 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2) + O31853[Dtype(arg2)-3689]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_6_0_5_) = (EIF_INTEGER_32) ti4_1;
	}
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTLE;
}

/* {LIKE_CUR_AS}.has_anchor */
EIF_BOOLEAN F3682_43570 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {LIKE_CUR_AS}.process */
void F3682_43571 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7780[Dtype(RTCW(arg1))-674])(arg1, Current);
}

/* {LIKE_CUR_AS}.like_keyword */
EIF_REFERENCE F3682_43573 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F3615_42860(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_6_0_5_));
}

/* {LIKE_CUR_AS}.index */
EIF_INTEGER_32 F3682_43575 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_6_0_5_);
}

/* {LIKE_CUR_AS}.is_equivalent */
EIF_BOOLEAN F3682_43576 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F3681_43563(Current, arg1);
}

/* {LIKE_CUR_AS}.first_token */
EIF_REFERENCE F3682_43577 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	Result = F3681_43553(Current, arg1);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_6_0_5_) != ((EIF_INTEGER_32) 0L)))) {
			{
				/* INLINED CODE (LIKE_CUR_AS.like_keyword) */
				tr1 = (EIF_REFERENCE)  0;
				tr1 = F3615_42860(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_6_0_5_));
				/* END INLINED CODE */
			}
			Result = tr1;
			RTLE;
			return (EIF_REFERENCE) Result;
		} else {
			tr1 = *(EIF_REFERENCE *)(Current);
			{
				/* INLINED CODE (LEAF_AS.first_token) */
				tr2 = (EIF_REFERENCE)  0;
				(void) RTCW(tr1);
				tr2 = (EIF_REFERENCE) tr1;
				/* END INLINED CODE */
			}
			Result = tr2;
		}
	}
	RTLE;
	return Result;
}

/* {LIKE_CUR_AS}.last_token */
EIF_REFERENCE F3682_43578 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	{
		/* INLINED CODE (TYPE_AS.last_token) */
		tr1 = (EIF_REFERENCE)  0;
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O31780[Dtype(Current)-3680]) != ((EIF_INTEGER_32) 0L)))) {
			tr1 = F3681_43545(Current, arg1);
		}
		/* END INLINED CODE */
	}
	Result = tr1;
	if ((EIF_BOOLEAN)(Result == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			/* INLINED CODE (LEAF_AS.last_token) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(tr1);
			tr2 = (EIF_REFERENCE) tr1;
			/* END INLINED CODE */
		}
		Result = tr2;
	}
	RTLE;
	return Result;
}

/* {LIKE_CUR_AS}.dump */
EIF_REFERENCE F3682_43579 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(2247, 0x00).id, 2247, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F2246_21883(RTCW(Result), ((EIF_INTEGER_32) 12L));
	F3681_43568(Current, Result);
	tr1 = RTMS_EX_H("like Current",12,331478388);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17141[Dtype(RTCW(Result))-2247])(Result, tr1);
	RTLE;
	return Result;
}

void EIF_Minit2631 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
