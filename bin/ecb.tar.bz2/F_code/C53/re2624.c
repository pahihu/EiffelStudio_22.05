/*
 * Code for class REDEFINE_CLAUSE_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "re2624.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {REDEFINE_CLAUSE_AS}.process */
void F3675_43514 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7809[Dtype(RTCW(arg1))-674])(arg1, Current);
}

void EIF_Minit2624 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
