/*
 * Code for class ROUT_BODY_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ro2612.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ROUT_BODY_AS}.is_attribute */
EIF_BOOLEAN F3661_43417 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_BOOLEAN) 0;
}

/* {ROUT_BODY_AS}.is_once */
EIF_BOOLEAN F3661_43418 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_BOOLEAN) 0;
}

/* {ROUT_BODY_AS}.is_deferred */
EIF_BOOLEAN F3661_43419 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_BOOLEAN) 0;
}

/* {ROUT_BODY_AS}.is_external */
EIF_BOOLEAN F3661_43420 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_BOOLEAN) 0;
}

/* {ROUT_BODY_AS}.is_built_in */
EIF_BOOLEAN F3661_43421 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_BOOLEAN) 0;
}

/* {ROUT_BODY_AS}.as_once */
EIF_REFERENCE F3661_43422 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

/* {ROUT_BODY_AS}.index_of_instruction */
EIF_INTEGER_32 F3661_43424 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
	return (EIF_INTEGER_32) 0;
}

/* {ROUT_BODY_AS}.is_empty */
EIF_BOOLEAN F3661_43425 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

void EIF_Minit2612 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
