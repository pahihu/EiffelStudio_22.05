/*
 * Code for class CLASS_TYPE_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "cl2637.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CLASS_TYPE_AS}.initialize */
void F3688_43645 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {CLASS_TYPE_AS}.process */
void F3688_43647 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7881[Dtype(RTCW(arg1))-674])(arg1, Current);
}

/* {CLASS_TYPE_AS}.class_name */
EIF_REFERENCE F3688_43648 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current);
}


/* {CLASS_TYPE_AS}.generics */
EIF_REFERENCE F3688_43649 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

/* {CLASS_TYPE_AS}.expanded_keyword */
EIF_REFERENCE F3688_43653 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F3615_42860(Current, arg1, *(EIF_INTEGER_32 *)(Current + O31843[Dtype(Current)-3687]));
}

/* {CLASS_TYPE_AS}.index */
EIF_INTEGER_32 F3688_43654 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_0_0_3_3_);
	RTLE;
	return Result;
}

/* {CLASS_TYPE_AS}.first_token */
EIF_REFERENCE F3688_43655 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	Result = F3681_43553(Current, arg1);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		if ((EIF_BOOLEAN)(arg1 != NULL)) {
			{
				/* INLINED CODE (CLASS_TYPE_AS.expanded_keyword) */
				tr1 = (EIF_REFERENCE)  0;
				tr1 = F3615_42860(Current, arg1, *(EIF_INTEGER_32 *)(Current + O31843[Dtype(Current)-3687]));
				/* END INLINED CODE */
			}
			Result = tr1;
		}
		if ((EIF_BOOLEAN)(Result == NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current);
			{
				/* INLINED CODE (LEAF_AS.first_token) */
				tr2 = (EIF_REFERENCE)  0;
				(void) RTCW(tr1);
				tr2 = (EIF_REFERENCE) tr1;
				/* END INLINED CODE */
			}
			Result = tr2;
		}
	}
	RTLE;
	return Result;
}

/* {CLASS_TYPE_AS}.last_token */
EIF_REFERENCE F3688_43656 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	{
		/* INLINED CODE (TYPE_AS.last_token) */
		tr1 = (EIF_REFERENCE)  0;
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O31780[Dtype(Current)-3680]) != ((EIF_INTEGER_32) 0L)))) {
			tr1 = F3681_43545(Current, arg1);
		}
		/* END INLINED CODE */
	}
	Result = tr1;
	if ((EIF_BOOLEAN)(Result == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			/* INLINED CODE (LEAF_AS.last_token) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(tr1);
			tr2 = (EIF_REFERENCE) tr1;
			/* END INLINED CODE */
		}
		Result = tr2;
	}
	RTLE;
	return Result;
}

/* {CLASS_TYPE_AS}.is_equivalent */
EIF_BOOLEAN F3688_43657 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	tb2 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if (F3615_42842(Current, *(EIF_REFERENCE *)(Current), tr1)) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R31841[dtype-3687])(Current);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R31841[Dtype(RTCW(arg1))-3687])(arg1);
		tb2 = F3615_42842(Current, tr1, tr2);
	}
	if (tb2) {
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O31842[Dtype(arg1)-3687]);
		tb1 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O31842[dtype-3687]) == tb2);
	}
	if (tb1) {
		Result = F3681_43563(Current, arg1);
	}
	RTLE;
	return Result;
}

/* {CLASS_TYPE_AS}.dump */
EIF_REFERENCE F3688_43658 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	Result = RTLNS(eif_new_type(2247, 0x00).id, 2247, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = F3771_44603(RTCW(tr1));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	F2246_21883(RTCW(Result), ti4_1);
	F3681_43568(Current, Result);
	tr1 = *(EIF_REFERENCE *)(Current);
	{
		/* INLINED CODE (ID_AS.name) */
		tr2 = (EIF_REFERENCE)  0;
		(void) RTCW(tr1);
		tr3 = F2271_22520(tr1);
		tr2 = F1792_17093(RTCW(tr3), *(EIF_INTEGER_32 *)(tr1+ _LNGOFF_0_0_3_4_));
		if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(tr2 != NULL)) {
			RTCT0("from_class_invariant_and_postcondition_of_names_heap_item", EX_CHECK);
				RTCF0;
		}
		/* END INLINED CODE */
	}
	tr1 = tr2;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17139[Dtype(RTCW(Result))-2247])(Result, tr1);
	RTLE;
	return Result;
}

/* {CLASS_TYPE_AS}.set_is_expanded */
void F3688_43659 (EIF_REFERENCE Current, EIF_BOOLEAN arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLIU(2);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O31842[dtype-3687]) = (EIF_BOOLEAN) arg1;
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2) + O31853[Dtype(arg2)-3689]);
		*(EIF_INTEGER_32 *)(Current + O31843[dtype-3687]) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

void EIF_Minit2637 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
