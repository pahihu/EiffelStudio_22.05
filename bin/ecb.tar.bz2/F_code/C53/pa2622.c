/*
 * Code for class PARAMETER_LIST_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pa2622.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PARAMETER_LIST_AS}.initialize */
void F3672_43504 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	{
		/* INLINED CODE (ID_LIST.make_id_set) */
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		/* END INLINED CODE */
	}
	;
	F3668_43492(Current, arg1, arg2, arg3);
	RTLE;
}

/* {PARAMETER_LIST_AS}.process */
void F3672_43505 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7804[Dtype(RTCW(arg1))-674])(arg1, Current);
}

void EIF_Minit2622 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
