/*
 * Code for class ACCESS_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ac2607.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ACCESS_AS}.access_name_32 */
EIF_REFERENCE F3656_43374 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R31682[Dtype(Current)-3656])(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1769_16449(Current);
		{
			/* INLINED CODE (UNICODE_CONVERSION.utf8_to_utf32) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(tr1);
			tr3 = RTLNS(eif_new_type(163, 0x00).id, 163, _OBJSIZ_0_0_0_0_0_0_0_0_);
			tr2 = F164_2793(RTCW(tr3), loc1);
			/* END INLINED CODE */
		}
		Result = tr2;
	}
	RTLE;
	return Result;
}

/* {ACCESS_AS}.access_name_8 */
EIF_REFERENCE F3656_43375 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R31682[Dtype(Current)-3656])(Current);
}

void EIF_Minit2607 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
