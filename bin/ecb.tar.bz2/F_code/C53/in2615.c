/*
 * Code for class INTERNAL_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "in2615.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {INTERNAL_AS}.initialize */
void F3664_43445 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {INTERNAL_AS}.is_empty */
EIF_BOOLEAN F3664_43448 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\01';
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	if (!((EIF_BOOLEAN) !EIF_TEST(loc1))) {
		{
			/* INLINED CODE (FINITE.is_empty) */
			tb1 = (EIF_BOOLEAN)  0;
			(void) loc1;
			ti4_1 = F1566_14933(loc1);
			tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
			/* END INLINED CODE */
		}
		tb1 = tb1;
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {INTERNAL_AS}.is_equivalent */
EIF_BOOLEAN F3664_43449 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	Result = F3615_42842(Current, *(EIF_REFERENCE *)(Current), tr1);
	RTLE;
	return Result;
}

/* {INTERNAL_AS}.index_of_instruction */
EIF_INTEGER_32 F3664_43451 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		{
			/* INLINED CODE (ARRAYED_LIST.start) */
			(void) loc1;
			*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			/* END INLINED CODE */
		}
		;
		for (;;) {
			tb1 = '\01';
			{
				/* INLINED CODE (CHAIN.off) */
				tb2 = (EIF_BOOLEAN)  0;
				(void) loc1;
				tb2 = '\01';
				ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_1_0_0_);
				if (!(EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
					ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_1_0_0_);
					ti4_2 = F1566_14933(loc1);
					tb2 = (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
				}
				/* END INLINED CODE */
			}
			tb2 = tb2;
			if (!tb2) {
				{
					/* INLINED CODE (ARRAYED_LIST.item) */
					tr1 = (EIF_REFERENCE)  0;
					(void) loc1;
					tr2 = *(EIF_REFERENCE *)(loc1);
					tr1 = 
						/* INLINED CODE (SPECIAL.item) */
						*((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_1_0_0_) - ((EIF_INTEGER_32) 1L))))
						/* END INLINED CODE */;
					/* END INLINED CODE */
				}
				tr1 = tr1;
				tb1 = F3615_42842(Current, arg1, tr1);
			}
			if (tb1) break;
			{
				/* INLINED CODE (ARRAYED_LIST.forth) */
				(void) loc1;
				(*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_1_0_0_))++;
				/* END INLINED CODE */
			}
			;
		}
		{
			/* INLINED CODE (CHAIN.off) */
			tb2 = (EIF_BOOLEAN)  0;
			(void) loc1;
			tb2 = '\01';
			ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_1_0_0_);
			if (!(EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
				ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_1_0_0_);
				ti4_2 = F1566_14933(loc1);
				tb2 = (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
			}
			/* END INLINED CODE */
		}
		tb2 = tb2;
		if ((EIF_BOOLEAN) !tb2) {
			ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_1_0_0_);
			RTLE;
			return (EIF_INTEGER_32) ti4_1;
		}
	}
	RTLE;
	return (EIF_INTEGER_32) 0;
}

/* {INTERNAL_AS}.set_first_breakpoint_slot_index */
void F3664_43452 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O31733[Dtype(Current)-3663]) = (EIF_INTEGER_32) arg1;
}

void EIF_Minit2615 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
