/*
 * Code for class EXTERNAL_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ex2613.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EXTERNAL_AS}.initialize */
void F3662_43426 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,arg3);
	RTLR(7,arg4);
	RTLIU(8);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		{
			/* INLINED CODE (SHARED_NAMES_HEAP.names_heap) */
			tr1 = (EIF_REFERENCE)  0;
			tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(22522,F2271_22522, (Current))));
			/* END INLINED CODE */
		}
		tr2 = tr1;
		tr3 = *(EIF_REFERENCE *)(RTCW(arg2));
		F1792_17096(RTCW(tr2), tr3);
		{
			/* INLINED CODE (SHARED_NAMES_HEAP.names_heap) */
			tr1 = (EIF_REFERENCE)  0;
			tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(22522,F2271_22522, (Current))));
			/* END INLINED CODE */
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCV(tr1)+ _LNGOFF_2_1_0_0_);
		*(EIF_INTEGER_32 *)(Current + O31728[dtype-3661]) = (EIF_INTEGER_32) ti4_1;
	}
	if ((EIF_BOOLEAN)(arg3 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg3) + O31853[Dtype(arg3)-3689]);
		*(EIF_INTEGER_32 *)(Current + O31723[dtype-3661]) = (EIF_INTEGER_32) ti4_1;
	}
	if ((EIF_BOOLEAN)(arg4 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg4) + O31853[Dtype(arg4)-3689]);
		*(EIF_INTEGER_32 *)(Current + O31722[dtype-3661]) = (EIF_INTEGER_32) ti4_1;
	}
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg2;
	RTLE;
}

/* {EXTERNAL_AS}.process */
void F3662_43427 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7878[Dtype(RTCW(arg1))-674])(arg1, Current);
}

/* {EXTERNAL_AS}.alias_keyword */
EIF_REFERENCE F3662_43430 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F3615_42860(Current, arg1, *(EIF_INTEGER_32 *)(Current + O31722[Dtype(Current)-3661]));
}

/* {EXTERNAL_AS}.external_keyword */
EIF_REFERENCE F3662_43431 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F3615_42860(Current, arg1, *(EIF_INTEGER_32 *)(Current + O31723[Dtype(Current)-3661]));
}

/* {EXTERNAL_AS}.index */
EIF_INTEGER_32 F3662_43433 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current + O31723[Dtype(Current)-3661]);
}

/* {EXTERNAL_AS}.first_token */
EIF_REFERENCE F3662_43436 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O31723[Dtype(Current)-3661]) != ((EIF_INTEGER_32) 0L)))) {
		{
			/* INLINED CODE (EXTERNAL_AS.external_keyword) */
			tr1 = (EIF_REFERENCE)  0;
			tr1 = F3615_42860(Current, arg1, *(EIF_INTEGER_32 *)(Current + O31723[Dtype(Current)-3661]));
			/* END INLINED CODE */
		}
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		{
			/* INLINED CODE (EXTERNAL_LANG_AS.first_token) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(tr1);
			tr3 = *(EIF_REFERENCE *)(tr1);
			tr2 = F3769_44588(RTCW(tr3), arg1);
			/* END INLINED CODE */
		}
		Result = tr2;
	}
	RTLE;
	return Result;
}

/* {EXTERNAL_AS}.last_token */
EIF_REFERENCE F3662_43437 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,Result);
	RTLR(6,loc1);
	RTLIU(7);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		{
			/* INLINED CODE (EXTERNAL_LANG_AS.last_token) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(tr1);
			tr3 = *(EIF_REFERENCE *)(tr1);
			tr2 = F3690_43670(RTCW(tr3), arg1);
			/* END INLINED CODE */
		}
		Result = tr2;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			{
				/* INLINED CODE (LEAF_AS.last_token) */
				tr1 = (EIF_REFERENCE)  0;
				(void) loc1;
				tr1 = (EIF_REFERENCE) loc1;
				/* END INLINED CODE */
			}
			Result = tr1;
			RTLE;
			return (EIF_REFERENCE) Result;
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			{
				/* INLINED CODE (EXTERNAL_LANG_AS.last_token) */
				tr2 = (EIF_REFERENCE)  0;
				(void) RTCW(tr1);
				tr3 = *(EIF_REFERENCE *)(tr1);
				tr2 = F3690_43670(RTCW(tr3), arg1);
				/* END INLINED CODE */
			}
			Result = tr2;
		}
	}
	RTLE;
	return Result;
}

/* {EXTERNAL_AS}.is_external */
EIF_BOOLEAN F3662_43438 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {EXTERNAL_AS}.is_equivalent */
EIF_BOOLEAN F3662_43439 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O31728[Dtype(arg1)-3661]);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O31728[Dtype(Current)-3661]) == ti4_1)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		Result = F3615_42842(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_), tr1);
	}
	RTLE;
	return Result;
}

void EIF_Minit2613 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
