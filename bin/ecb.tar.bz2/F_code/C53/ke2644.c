/*
 * Code for class KEYWORD_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ke2644.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KEYWORD_AS}.make */
void F3695_43739 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current + O31972[Dtype(Current)-3694]) = (EIF_INTEGER_32) arg1;
	{
		/* INLINED CODE (LOCATION_AS.make_with_location) */
		F323_4773(Current, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {KEYWORD_AS}.process */
void F3695_43805 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7733[Dtype(RTCW(arg1))-674])(arg1, Current);
}

/* {KEYWORD_AS}.is_equivalent */
EIF_BOOLEAN F3695_43806 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O31972[Dtype(Current)-3694]);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O31972[Dtype(arg1)-3694]);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
	RTLE;
	return Result;
}

void EIF_Minit2644 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
