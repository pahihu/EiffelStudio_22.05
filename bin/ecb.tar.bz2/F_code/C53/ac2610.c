/*
 * Code for class ACCESS_ASSERT_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ac2610.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ACCESS_ASSERT_AS}.process */
void F3659_43414 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7760[Dtype(RTCW(arg1))-674])(arg1, Current);
}

void EIF_Minit2610 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
