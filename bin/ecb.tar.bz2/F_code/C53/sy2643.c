/*
 * Code for class SYMBOL_STUB_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sy2643.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SYMBOL_STUB_AS}.process */
void F3694_43730 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7737[Dtype(RTCW(arg1))-674])(arg1, Current);
}

/* {SYMBOL_STUB_AS}.literal_text */
RTEOMS(43730,34);
EIF_REFERENCE F3694_43731 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	switch (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_3_4_)) {
		case 306L:
			Result = (EIF_REFERENCE) RTOMS(43730,0);
			break;
		case 307L:
			Result = (EIF_REFERENCE) RTOMS(43730,1);
			break;
		case 258L:
			Result = (EIF_REFERENCE) RTOMS(43730,2);
			break;
		case 290L:
			Result = (EIF_REFERENCE) RTOMS(43730,3);
			break;
		case 316L:
			Result = RTOSCF(43738,F3694_43738, (Current));
			break;
		case 319L:
			Result = RTOSCF(43733,F3694_43733, (Current));
			break;
		case 298L:
			Result = RTOSCF(43732,F3694_43732, (Current));
			break;
		case 314L:
			Result = (EIF_REFERENCE) RTOMS(43730,4);
			break;
		case 315L:
			Result = (EIF_REFERENCE) RTOMS(43730,5);
			break;
		case 317L:
			Result = (EIF_REFERENCE) RTOMS(43730,6);
			break;
		case 287L:
			Result = (EIF_REFERENCE) RTOMS(43730,7);
			break;
		case 295L:
			Result = (EIF_REFERENCE) RTOMS(43730,8);
			break;
		case 263L:
			Result = (EIF_REFERENCE) RTOMS(43730,9);
			break;
		case 277L:
			Result = (EIF_REFERENCE) RTOMS(43730,10);
			break;
		case 262L:
			Result = RTOSCF(43735,F3694_43735, (Current));
			break;
		case 261L:
			Result = RTOSCF(43734,F3694_43734, (Current));
			break;
		case 281L:
			Result = (EIF_REFERENCE) RTOMS(43730,11);
			break;
		case 279L:
			Result = (EIF_REFERENCE) RTOMS(43730,12);
			break;
		case 308L:
			Result = (EIF_REFERENCE) RTOMS(43730,13);
			break;
		case 311L:
			Result = (EIF_REFERENCE) RTOMS(43730,14);
			break;
		case 280L:
			Result = (EIF_REFERENCE) RTOMS(43730,15);
			break;
		case 297L:
			Result = (EIF_REFERENCE) RTOMS(43730,16);
			break;
		case 304L:
			Result = (EIF_REFERENCE) RTOMS(43730,17);
			break;
		case 278L:
			Result = (EIF_REFERENCE) RTOMS(43730,18);
			break;
		case 283L:
			Result = (EIF_REFERENCE) RTOMS(43730,19);
			break;
		case 286L:
			Result = (EIF_REFERENCE) RTOMS(43730,20);
			break;
		case 276L:
			Result = (EIF_REFERENCE) RTOMS(43730,21);
			break;
		case 275L:
			Result = (EIF_REFERENCE) RTOMS(43730,22);
			break;
		case 282L:
			Result = (EIF_REFERENCE) RTOMS(43730,23);
			break;
		case 288L:
			Result = (EIF_REFERENCE) RTOMS(43730,24);
			break;
		case 318L:
			Result = (EIF_REFERENCE) RTOMS(43730,25);
			break;
		case 309L:
			Result = (EIF_REFERENCE) RTOMS(43730,26);
			break;
		case 312L:
			Result = (EIF_REFERENCE) RTOMS(43730,27);
			break;
		case 260L:
			Result = RTOSCF(43737,F3694_43737, (Current));
			break;
		case 259L:
			Result = RTOSCF(43736,F3694_43736, (Current));
			break;
		case 310L:
			Result = (EIF_REFERENCE) RTOMS(43730,28);
			break;
		case 305L:
			Result = (EIF_REFERENCE) RTOMS(43730,29);
			break;
		case 313L:
			Result = (EIF_REFERENCE) RTOMS(43730,30);
			break;
		case 285L:
			Result = (EIF_REFERENCE) RTOMS(43730,31);
			break;
		case 284L:
			Result = (EIF_REFERENCE) RTOMS(43730,32);
			break;
		case 274L:
			Result = (EIF_REFERENCE) RTOMS(43730,33);
			break;
		default:
			RTEC(EN_WHEN);
	}
	RTLE;
	return Result;
}

/* {SYMBOL_STUB_AS}.mathematical_left_white_square_bracket */
static EIF_REFERENCE F3694_43732_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,tr3);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (43732);
#define Result RTOSR(43732)
	RTOC_NEW(Result);
	tr2 = RTMS32_EX_H("\346\'\000\000",1,10214);
	tr1 = RTLNS(eif_new_type(163, 0x00).id, 163, _OBJSIZ_0_0_0_0_0_0_0_0_);
	{
		/* INLINED CODE (UTF_CONVERTER.string_32_to_utf_8_string_8) */
		tr3 = (EIF_REFERENCE)  0;
		(void) RTCW(tr1);
		tr3 = F164_2779(tr1, tr2);
		/* END INLINED CODE */
	}
	Result = tr3;
	RTOSE (43732);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F3694_43732 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(43732,F3694_43732_body,(Current));
}

/* {SYMBOL_STUB_AS}.mathematical_right_white_square_bracket */
static EIF_REFERENCE F3694_43733_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,tr3);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (43733);
#define Result RTOSR(43733)
	RTOC_NEW(Result);
	tr2 = RTMS32_EX_H("\347\'\000\000",1,10215);
	tr1 = RTLNS(eif_new_type(163, 0x00).id, 163, _OBJSIZ_0_0_0_0_0_0_0_0_);
	{
		/* INLINED CODE (UTF_CONVERTER.string_32_to_utf_8_string_8) */
		tr3 = (EIF_REFERENCE)  0;
		(void) RTCW(tr1);
		tr3 = F164_2779(tr1, tr2);
		/* END INLINED CODE */
	}
	Result = tr3;
	RTOSE (43733);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F3694_43733 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(43733,F3694_43733_body,(Current));
}

/* {SYMBOL_STUB_AS}.for_all */
static EIF_REFERENCE F3694_43734_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,tr3);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (43734);
#define Result RTOSR(43734)
	RTOC_NEW(Result);
	tr2 = RTMS32_EX_H("\000\"\000\000",1,8704);
	tr1 = RTLNS(eif_new_type(163, 0x00).id, 163, _OBJSIZ_0_0_0_0_0_0_0_0_);
	{
		/* INLINED CODE (UTF_CONVERTER.string_32_to_utf_8_string_8) */
		tr3 = (EIF_REFERENCE)  0;
		(void) RTCW(tr1);
		tr3 = F164_2779(tr1, tr2);
		/* END INLINED CODE */
	}
	Result = tr3;
	RTOSE (43734);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F3694_43734 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(43734,F3694_43734_body,(Current));
}

/* {SYMBOL_STUB_AS}.there_exists */
static EIF_REFERENCE F3694_43735_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,tr3);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (43735);
#define Result RTOSR(43735)
	RTOC_NEW(Result);
	tr2 = RTMS32_EX_H("\003\"\000\000",1,8707);
	tr1 = RTLNS(eif_new_type(163, 0x00).id, 163, _OBJSIZ_0_0_0_0_0_0_0_0_);
	{
		/* INLINED CODE (UTF_CONVERTER.string_32_to_utf_8_string_8) */
		tr3 = (EIF_REFERENCE)  0;
		(void) RTCW(tr1);
		tr3 = F164_2779(tr1, tr2);
		/* END INLINED CODE */
	}
	Result = tr3;
	RTOSE (43735);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F3694_43735 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(43735,F3694_43735_body,(Current));
}

/* {SYMBOL_STUB_AS}.clockwise_gapped_circle_arrow */
static EIF_REFERENCE F3694_43736_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,tr3);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (43736);
#define Result RTOSR(43736)
	RTOC_NEW(Result);
	tr2 = RTMS32_EX_H("\363\'\000\000",1,10227);
	tr1 = RTLNS(eif_new_type(163, 0x00).id, 163, _OBJSIZ_0_0_0_0_0_0_0_0_);
	{
		/* INLINED CODE (UTF_CONVERTER.string_32_to_utf_8_string_8) */
		tr3 = (EIF_REFERENCE)  0;
		(void) RTCW(tr1);
		tr3 = F164_2779(tr1, tr2);
		/* END INLINED CODE */
	}
	Result = tr3;
	RTOSE (43736);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F3694_43736 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(43736,F3694_43736_body,(Current));
}

/* {SYMBOL_STUB_AS}.anticlockwise_gapped_circle_arrow */
static EIF_REFERENCE F3694_43737_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,tr3);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (43737);
#define Result RTOSR(43737)
	RTOC_NEW(Result);
	tr2 = RTMS32_EX_H("\362\'\000\000",1,10226);
	tr1 = RTLNS(eif_new_type(163, 0x00).id, 163, _OBJSIZ_0_0_0_0_0_0_0_0_);
	{
		/* INLINED CODE (UTF_CONVERTER.string_32_to_utf_8_string_8) */
		tr3 = (EIF_REFERENCE)  0;
		(void) RTCW(tr1);
		tr3 = F164_2779(tr1, tr2);
		/* END INLINED CODE */
	}
	Result = tr3;
	RTOSE (43737);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F3694_43737 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(43737,F3694_43737_body,(Current));
}

/* {SYMBOL_STUB_AS}.broken_bar */
static EIF_REFERENCE F3694_43738_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,tr3);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (43738);
#define Result RTOSR(43738)
	RTOC_NEW(Result);
	tr2 = RTMS32_EX_H("\246\000\000\000",1,166);
	tr1 = RTLNS(eif_new_type(163, 0x00).id, 163, _OBJSIZ_0_0_0_0_0_0_0_0_);
	{
		/* INLINED CODE (UTF_CONVERTER.string_32_to_utf_8_string_8) */
		tr3 = (EIF_REFERENCE)  0;
		(void) RTCW(tr1);
		tr3 = F164_2779(tr1, tr2);
		/* END INLINED CODE */
	}
	Result = tr3;
	RTOSE (43738);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F3694_43738 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(43738,F3694_43738_body,(Current));
}

void EIF_Minit2643 (void)
{
	GTCX
	RTPOMS(43730,33,"~",1,126);
	RTPOMS(43730,32,"*",1,42);
	RTPOMS(43730,31,"/",1,47);
	RTPOMS(43730,30,";",1,59);
	RTPOMS(43730,29,"]",1,93);
	RTPOMS(43730,28,")",1,41);
	RTPOMS(43730,27,"}",1,125);
	RTPOMS(43730,26,">>",2,15934);
	RTPOMS(43730,25,"\?",1,63);
	RTPOMS(43730,24,"^",1,94);
	RTPOMS(43730,23,"+",1,43);
	RTPOMS(43730,22,"/~",2,12158);
	RTPOMS(43730,21,"/=",2,12093);
	RTPOMS(43730,20,"\\\\",2,23644);
	RTPOMS(43730,19,"-",1,45);
	RTPOMS(43730,18,"<",1,60);
	RTPOMS(43730,17,"[",1,91);
	RTPOMS(43730,16,"(",1,40);
	RTPOMS(43730,15,"<=",2,15421);
	RTPOMS(43730,14,"{",1,123);
	RTPOMS(43730,13,"<<",2,15420);
	RTPOMS(43730,12,">",1,62);
	RTPOMS(43730,11,">=",2,15933);
	RTPOMS(43730,10,"=",1,61);
	RTPOMS(43730,9,"..",2,11822);
	RTPOMS(43730,8,".",1,46);
	RTPOMS(43730,7,"//",2,12079);
	RTPOMS(43730,6,"->",2,11582);
	RTPOMS(43730,5,",",1,44);
	RTPOMS(43730,4,":",1,58);
	RTPOMS(43730,3,"@",1,64);
	RTPOMS(43730,2,":=",2,14909);
	RTPOMS(43730,1,"$",1,36);
	RTPOMS(43730,0,"\?=",2,16189);
}


#ifdef __cplusplus
}
#endif
