/*
 * Code for class ROUTINE_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ro2601.h"
#include "eif_built_in.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ROUTINE_AS}.initialize */
void F3650_43302 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6, EIF_REFERENCE arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_REFERENCE arg10, EIF_REFERENCE arg11, EIF_REFERENCE arg12, EIF_BOOLEAN arg13, EIF_BOOLEAN arg14, EIF_BOOLEAN arg15)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(11);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,arg4);
	RTLR(5,arg5);
	RTLR(6,arg6);
	RTLR(7,arg7);
	RTLR(8,arg10);
	RTLR(9,arg11);
	RTLR(10,arg12);
	RTLIU(11);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg3;
	RTAR(Current, arg4);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg4;
	RTAR(Current, arg5);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg5;
	RTAR(Current, arg6);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg6;
	RTAR(Current, arg7);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg7;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_8_3_0_2_) = (EIF_INTEGER_32) arg8;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_8_3_0_3_) = (EIF_INTEGER_32) arg9;
	if ((EIF_BOOLEAN)(arg10 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg10) + O31853[Dtype(arg10)-3689]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_8_3_0_0_) = (EIF_INTEGER_32) ti4_1;
	}
	if ((EIF_BOOLEAN)(arg11 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg11) + O31853[Dtype(arg11)-3689]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_8_3_0_1_) = (EIF_INTEGER_32) ti4_1;
	}
	RTAR(Current, arg12);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) arg12;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_8_0_) = (EIF_BOOLEAN) arg13;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_8_1_) = (EIF_BOOLEAN) arg14;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_8_2_) = (EIF_BOOLEAN) arg15;
	RTLE;
}

/* {ROUTINE_AS}.process */
void F3650_43303 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7764[Dtype(RTCW(arg1))-674])(arg1, Current);
}

/* {ROUTINE_AS}.obsolete_keyword */
EIF_REFERENCE F3650_43306 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_8_3_0_0_);
	tb1 = '\0';
	{
		/* INLINED CODE (LEAF_AS_LIST.valid_index) */
		tb2 = (EIF_BOOLEAN)  0;
		(void) RTCW(arg1);
		ti4_1 = *(EIF_INTEGER_32 *)(arg1+ _LNGOFF_7_1_0_1_);
		tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) (((EIF_INTEGER_32) 1L) <= loc1) && (EIF_BOOLEAN) (loc1 <= ti4_1));
		/* END INLINED CODE */
	}
	tb2 = tb2;
	if (tb2) {
		tr1 = F2492_26087(RTCW(arg1), loc1);
		loc2 = tr1;
		loc2 = RTRV(eif_new_type(3694, 0),loc2);
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) loc2;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {ROUTINE_AS}.rescue_keyword */
EIF_REFERENCE F3650_43307 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_8_3_0_1_);
	tb1 = '\0';
	{
		/* INLINED CODE (LEAF_AS_LIST.valid_index) */
		tb2 = (EIF_BOOLEAN)  0;
		(void) RTCW(arg1);
		ti4_1 = *(EIF_INTEGER_32 *)(arg1+ _LNGOFF_7_1_0_1_);
		tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) (((EIF_INTEGER_32) 1L) <= loc1) && (EIF_BOOLEAN) (loc1 <= ti4_1));
		/* END INLINED CODE */
	}
	tb2 = tb2;
	if (tb2) {
		tr1 = F2492_26087(RTCW(arg1), loc1);
		loc2 = tr1;
		loc2 = RTRV(eif_new_type(3694, 0),loc2);
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) loc2;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {ROUTINE_AS}.index */
EIF_INTEGER_32 F3650_43308 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R31335[Dtype(RTCW(tr1))-3615])(tr1);
	RTLE;
	return Result;
}

/* {ROUTINE_AS}.locals */
EIF_REFERENCE F3650_43312 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(loc1);
		loc2 = tr1;
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) loc2;
	} else {
		RTLE;
		return (EIF_REFERENCE) NULL;
	}/* NOTREACHED */
	
}

/* {ROUTINE_AS}.first_token */
EIF_REFERENCE F3650_43320 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(10);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLR(4,tr1);
	RTLR(5,loc2);
	RTLR(6,loc3);
	RTLR(7,loc4);
	RTLR(8,loc5);
	RTLR(9,loc6);
	RTLIU(10);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_8_3_0_0_) != ((EIF_INTEGER_32) 0L)))) {
		Result = F3650_43306(Current, arg1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			Result = F3769_44588(loc1, arg1);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			loc2 = tr1;
			if (EIF_TEST(loc2)) {
				Result = F3642_43236(loc2, arg1);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current);
				loc3 = tr1;
				if (EIF_TEST(loc3)) {
					Result = F3617_42896(loc3, arg1);
				}
			}
		}
	}
	tb1 = '\01';
	if (!(EIF_BOOLEAN)(Result == NULL)) {
		{
			/* INLINED CODE (LOCATION_AS.is_null) */
			tb2 = (EIF_BOOLEAN)  0;
			(void) RTCW(Result);
			tu4_1 = *(EIF_NATURAL_32 *)(Result + O4696[Dtype(Result)-322]);
			tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu4_1 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L));
			/* END INLINED CODE */
		}
		tb2 = tb2;
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R31331[Dtype(RTCW(tr1))-3615])(tr1, arg1);
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(Result == NULL)) {
			{
				/* INLINED CODE (LOCATION_AS.is_null) */
				tb2 = (EIF_BOOLEAN)  0;
				(void) RTCW(Result);
				tu4_1 = *(EIF_NATURAL_32 *)(Result + O4696[Dtype(Result)-322]);
				tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu4_1 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L));
				/* END INLINED CODE */
			}
			tb2 = tb2;
			tb1 = tb2;
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			loc4 = tr1;
			if (EIF_TEST(loc4)) {
				Result = F3640_43222(loc4, arg1);
				RTLE;
				return (EIF_REFERENCE) Result;
			} else {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_8_3_0_1_) != ((EIF_INTEGER_32) 0L)))) {
					Result = F3650_43307(Current, arg1);
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
					loc5 = tr1;
					if (EIF_TEST(loc5)) {
						Result = F3698_43824(loc5, arg1);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
						loc6 = tr1;
						if (EIF_TEST(loc6)) {
							{
								/* INLINED CODE (LEAF_AS.first_token) */
								tr1 = (EIF_REFERENCE)  0;
								(void) loc6;
								tr1 = (EIF_REFERENCE) loc6;
								/* END INLINED CODE */
							}
							Result = tr1;
							RTLE;
							return (EIF_REFERENCE) Result;
						}
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {ROUTINE_AS}.last_token */
EIF_REFERENCE F3650_43321 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		{
			/* INLINED CODE (LEAF_AS.last_token) */
			tr1 = (EIF_REFERENCE)  0;
			(void) loc1;
			tr1 = (EIF_REFERENCE) loc1;
			/* END INLINED CODE */
		}
		tr1 = tr1;
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {ROUTINE_AS}.is_require_else */
EIF_BOOLEAN F3650_43322 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\01';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (!((EIF_BOOLEAN) !EIF_TEST(loc1))) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R31594[Dtype(loc1)-3641])(loc1);
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {ROUTINE_AS}.is_ensure_then */
EIF_BOOLEAN F3650_43323 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\01';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc1 = tr1;
	if (!((EIF_BOOLEAN) !EIF_TEST(loc1))) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R31586[Dtype(loc1)-3639])(loc1);
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {ROUTINE_AS}.has_precondition */
EIF_BOOLEAN F3650_43324 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	Result = '\01';
	tb1 = '\01';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (!((EIF_BOOLEAN) !EIF_TEST(loc1))) {
		tr1 = *(EIF_REFERENCE *)(loc1);
		loc2 = tr1;
		tb1 = (EIF_BOOLEAN) !EIF_TEST(loc2);
	}
	if (!tb1) {
		tb1 = '\0';
		tb2 = '\0';
		{
			/* INLINED CODE (ARRAYED_LIST.count) */
			ti4_1 = (EIF_INTEGER_32)  0;
			(void) loc2;
			tr1 = *(EIF_REFERENCE *)(loc2);
			ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
			/* END INLINED CODE */
		}
		ti4_1 = ti4_1;
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
			{
				/* INLINED CODE (ARRAYED_LIST.first) */
				tr1 = (EIF_REFERENCE)  0;
				(void) loc2;
				tr2 = *(EIF_REFERENCE *)(loc2);
				tr1 = 
					/* INLINED CODE (SPECIAL.item) */
					*((EIF_REFERENCE *)RTCW(tr2) + (((EIF_INTEGER_32) 0L)))
					/* END INLINED CODE */;
				/* END INLINED CODE */
			}
			tr1 = tr1;
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
			loc3 = tr1;
			loc3 = RTRV(eif_new_type(3763, 0x00),loc3);
			tb2 = EIF_TEST(loc3);
		}
		if (tb2) {
			tb2 = *(EIF_BOOLEAN *)(loc3+ _CHROFF_0_0_);
			tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R31594[Dtype(loc1)-3641])(loc1);
			tb1 = (EIF_BOOLEAN)(tb2 != tb3);
		}
		Result = tb1;
	}
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTLE;
	return Result;
}

/* {ROUTINE_AS}.has_postcondition */
EIF_BOOLEAN F3650_43325 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(loc1);
		Result = (EIF_BOOLEAN)(tr1 != NULL);
	}
	RTLE;
	return Result;
}

/* {ROUTINE_AS}.has_false_postcondition */
EIF_BOOLEAN F3650_43326 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_REFERENCE tr6 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,tr5);
	RTLR(8,tr6);
	RTLIU(9);
	
	RTGC;
	tb1 = '\0';
	tb2 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(loc1);
		loc2 = tr1;
		tb2 = EIF_TEST(loc2);
	}
	if (tb2) {
		{
			/* INLINED CODE (ARRAYED_LIST.count) */
			ti4_1 = (EIF_INTEGER_32)  0;
			(void) loc2;
			tr1 = *(EIF_REFERENCE *)(loc2);
			ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
			/* END INLINED CODE */
		}
		ti4_1 = ti4_1;
		tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,2049,0,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr1 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
		RTAR(tr1,Current);
		
		{
			static EIF_TYPE_INDEX typarr0[] = {2209,0xFFF9,1,2049,3748,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr4= RTLNRF(typres0.id, (EIF_POINTER) __A2601_127_2, (EIF_POINTER) _A2601_127_2, (EIF_POINTER)(0),tr1, 1, 1);
		}
		{
			/* INLINED CODE (ARRAYED_LIST.there_exists) */
			tb1 = (EIF_BOOLEAN)  0;
			(void) loc2;
			tr5 = *(EIF_REFERENCE *)(loc2);
			tr6 = *(EIF_REFERENCE *)(loc2);
			ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr6);
			tb1 = F1929_18488(RTCW(tr5), tr4, ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
			/* END INLINED CODE */
		}
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {ROUTINE_AS}.has_rescue */
EIF_BOOLEAN F3650_43327 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		{
			/* INLINED CODE (FINITE.is_empty) */
			tb1 = (EIF_BOOLEAN)  0;
			(void) loc1;
			ti4_1 = F1566_14933(loc1);
			tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
			/* END INLINED CODE */
		}
		tb1 = tb1;
		Result = (EIF_BOOLEAN) !tb1;
	}
	RTLE;
	return Result;
}

/* {ROUTINE_AS}.is_attribute */
EIF_BOOLEAN F3650_43328 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R31712[Dtype(RTCW(tr1))-3661])(tr1);
	RTLE;
	return Result;
}

/* {ROUTINE_AS}.is_deferred */
EIF_BOOLEAN F3650_43329 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R31714[Dtype(RTCW(tr1))-3661])(tr1);
	RTLE;
	return Result;
}

/* {ROUTINE_AS}.is_once */
EIF_BOOLEAN F3650_43330 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R31713[Dtype(RTCW(tr1))-3661])(tr1);
	RTLE;
	return Result;
}

/* {ROUTINE_AS}.is_external */
EIF_BOOLEAN F3650_43331 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R31715[Dtype(RTCW(tr1))-3661])(tr1);
	RTLE;
	return Result;
}

/* {ROUTINE_AS}.is_built_in */
EIF_BOOLEAN F3650_43332 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R31716[Dtype(RTCW(tr1))-3661])(tr1);
	RTLE;
	return Result;
}

/* {ROUTINE_AS}.has_class_postcondition */
EIF_BOOLEAN F3650_43333 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb1 = *(EIF_BOOLEAN *)(loc1+ _CHROFF_2_0_);
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {ROUTINE_AS}.index_of_instruction */
EIF_INTEGER_32 F3650_43339 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R31719[Dtype(RTCW(tr1))-3661])(tr1, arg1);
	RTLE;
	return Result;
}

/* {ROUTINE_AS}.is_equivalent */
EIF_BOOLEAN F3650_43340 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	if (F3650_43341(Current, arg1)) {
		{
			/* INLINED CODE (ROUTINE_AS.is_assertion_equiv) */
			tb1 = (EIF_BOOLEAN)  0;
			tb1 = '\0';
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
			tb2 = F3615_42842(Current, *(EIF_REFERENCE *)(Current + _REFACS_2_), tr1);
			if (tb2) {
				tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
				tb2 = F3615_42842(Current, *(EIF_REFERENCE *)(Current + _REFACS_4_), tr1);
				tb1 = tb2;
			}
			/* END INLINED CODE */
		}
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {ROUTINE_AS}.is_body_equiv */
EIF_BOOLEAN F3650_43341 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	tb2 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	if (F3615_42842(Current, *(EIF_REFERENCE *)(Current + _REFACS_3_), tr1)) {
		tr1 = F3650_43312(Current);
		tr2 = F3650_43312(RTCW(arg1));
		tb2 = F3615_42842(Current, tr1, tr2);
	}
	if (tb2) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
		tb1 = F3615_42842(Current, *(EIF_REFERENCE *)(Current + _REFACS_5_), tr1);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		Result = F3615_42842(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_), tr1);
	}
	RTLE;
	return Result;
}

/* {ROUTINE_AS}.is_assertion_equiv */
EIF_BOOLEAN F3650_43342 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	if (F3615_42842(Current, *(EIF_REFERENCE *)(Current + _REFACS_2_), tr1)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
		Result = F3615_42842(Current, *(EIF_REFERENCE *)(Current + _REFACS_4_), tr1);
	}
	RTLE;
	return Result;
}

/* {ROUTINE_AS}.is_empty */
EIF_BOOLEAN F3650_43343 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\01';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R31720[Dtype(loc1)-3661])(loc1);
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {ROUTINE_AS}.set_locals */
void F3650_43344 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {ROUTINE_AS}.set_rescue_clause */
void F3650_43345 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
}

/* {ROUTINE_AS}.set_routine_body */
void F3650_43346 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
}

/* {ROUTINE_AS}.set_number_of_breakpoint_slots */
void F3650_43347 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_8_3_0_4_) = (EIF_INTEGER_32) arg1;
}

/* {ROUTINE_AS}.create_default_rescue */
void F3650_43348 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_INTEGER_32 ti4_5;
	EIF_INTEGER_32 ti4_6;
	EIF_INTEGER_32 ti4_7;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_16 tu2_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc3);
	RTLR(4,loc2);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_5_) == NULL)) {
		tb2 = '\01';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R31714[Dtype(RTCW(tr1))-3661])(tr1);
		if (!tb3) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R31715[Dtype(RTCW(tr1))-3661])(tr1);
			tb2 = tb3;
		}
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		loc1 = RTLNS(eif_new_type(3770, 0x00).id, 3770, _OBJSIZ_0_0_3_5_0_0_0_0_);
		F3771_44595(RTCW(loc1), arg1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			{
				/* INLINED CODE (LOCATION_AS.line) */
				ti4_1 = (EIF_INTEGER_32)  0;
				(void) loc3;
				tu4_1 = *(EIF_NATURAL_32 *)(loc3 + O4696[Dtype(loc3)-322]);
				tu4_1 = eif_bit_and(tu4_1,((EIF_NATURAL_32) 8388607U));
				ti4_1 = (EIF_INTEGER_32) tu4_1;
				/* END INLINED CODE */
			}
			ti4_1 = ti4_1;
			{
				/* INLINED CODE (LOCATION_AS.column) */
				ti4_2 = (EIF_INTEGER_32)  0;
				(void) loc3;
				tu4_1 = *(EIF_NATURAL_32 *)(loc3 + O4696[Dtype(loc3)-322]);
				tu4_1 = eif_bit_shift_right(tu4_1,((EIF_INTEGER_32) 23L));
				ti4_2 = (EIF_INTEGER_32) tu4_1;
				/* END INLINED CODE */
			}
			ti4_2 = ti4_2;
			ti4_3 = *(EIF_INTEGER_32 *)(loc3 + O4676[Dtype(loc3)-322]);
			{
				/* INLINED CODE (LOCATION_AS.location_count) */
				ti4_4 = (EIF_INTEGER_32)  0;
				(void) loc3;
				tu2_1 = *(EIF_NATURAL_16 *)(loc3 + O4697[Dtype(loc3)-322]);
				ti4_4 = (EIF_INTEGER_32) tu2_1;
				/* END INLINED CODE */
			}
			ti4_4 = ti4_4;
			{
				/* INLINED CODE (LOCATION_AS.character_column) */
				ti4_5 = (EIF_INTEGER_32)  0;
				(void) loc3;
				tu2_1 = *(EIF_NATURAL_16 *)(loc3 + O4698[Dtype(loc3)-322]);
				ti4_5 = (EIF_INTEGER_32) tu2_1;
				/* END INLINED CODE */
			}
			ti4_5 = ti4_5;
			ti4_6 = *(EIF_INTEGER_32 *)(loc3 + O4681[Dtype(loc3)-322]);
			{
				/* INLINED CODE (LOCATION_AS.character_count) */
				ti4_7 = (EIF_INTEGER_32)  0;
				(void) loc3;
				tu2_1 = *(EIF_NATURAL_16 *)(loc3 + O4699[Dtype(loc3)-322]);
				ti4_7 = (EIF_INTEGER_32) tu2_1;
				/* END INLINED CODE */
			}
			ti4_7 = ti4_7;
			F323_4773(RTCW(loc1), ti4_1, ti4_2, ti4_3, ti4_4, ti4_5, ti4_6, ti4_7);
		}
		{
			static EIF_TYPE_INDEX typarr0[] = {3697,3708,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc2 = RTLNSMART(typres0.id);
		}
		F3698_43815(RTCW(loc2), ((EIF_INTEGER_32) 1L));
		tr1 = RTLNS(eif_new_type(3717, 0x00).id, 3717, _OBJSIZ_2_0_0_0_0_0_0_0_);
		tr2 = RTLNS(eif_new_type(3659, 0x00).id, 3659, _OBJSIZ_3_1_0_3_0_0_0_0_);
		F3657_43378(RTCW(tr2), loc1, NULL);
		F3718_44041(RTCW(tr1), tr2);
		F1566_14953(RTCW(loc2), tr1);
		RTAR(Current, loc2);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) loc2;
	}
	RTLE;
}

/* {ROUTINE_AS}.inline-agent#1 of has_false_postcondition */
EIF_BOOLEAN F3650_46191 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(3763, 0x00),loc1);
	if (EIF_TEST(loc1)) {
		tb1 = *(EIF_BOOLEAN *)(loc1+ _CHROFF_0_0_);
		Result = (EIF_BOOLEAN) !tb1;
	}
	RTLE;
	return Result;
}

void EIF_Minit2601 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
