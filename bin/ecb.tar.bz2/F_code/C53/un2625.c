/*
 * Code for class UNDEFINE_CLAUSE_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "un2625.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UNDEFINE_CLAUSE_AS}.process */
void F3676_43515 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7808[Dtype(RTCW(arg1))-674])(arg1, Current);
}

void EIF_Minit2625 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
