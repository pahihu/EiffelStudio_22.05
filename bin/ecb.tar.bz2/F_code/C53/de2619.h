
#ifndef _C53_de2619_
#define _C53_de2619_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3669_43501(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2619(void);
extern char *(*R7803[])();

#ifdef __cplusplus
}
#endif

#endif
