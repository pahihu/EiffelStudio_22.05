/*
 * Code for class ACCESS_FEAT_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ac2608.h"
#include "eif_built_in.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ACCESS_FEAT_AS}.initialize */
void F3657_43378 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	{
		/* INLINED CODE (ACCESS_FEAT_AS.set_parameters) */
		RTAR(Current, arg2);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg2;
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (FEATURE_ID_AS.make_feature_id) */
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
		F281_4155(Current);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {ACCESS_FEAT_AS}.process */
void F3657_43379 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7757[Dtype(RTCW(arg1))-674])(arg1, Current);
}

/* {ACCESS_FEAT_AS}.parameters */
EIF_REFERENCE F3657_43380 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		Result = *(EIF_REFERENCE *)(loc1 + _REFACS_1_);
		{
			/* INLINED CODE (ARRAYED_LIST.start) */
			(void) RTCW(Result);
			*(EIF_INTEGER_32 *)(Result+ _LNGOFF_2_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
	return Result;
}

/* {ACCESS_FEAT_AS}.parameter_count */
EIF_INTEGER_32 F3657_43381 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F3657_43380(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		{
			/* INLINED CODE (ARRAYED_LIST.count) */
			ti4_1 = (EIF_INTEGER_32)  0;
			(void) loc1;
			tr1 = *(EIF_REFERENCE *)(loc1);
			ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
			/* END INLINED CODE */
		}
		ti4_1 = ti4_1;
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
	return (EIF_INTEGER_32) 0;
}

/* {ACCESS_FEAT_AS}.is_qualified */
EIF_BOOLEAN F3657_43382 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {ACCESS_FEAT_AS}.is_local */
EIF_BOOLEAN F3657_43383 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu1_1 = *(EIF_NATURAL_8 *)(Current + O31703[Dtype(Current)-3656]);
	tu1_1 = eif_bit_and(tu1_1,((EIF_NATURAL_8) 1U));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu1_1 != (EIF_NATURAL_8) ((EIF_INTEGER_32) 0L));
	RTLE;
	return Result;
}

/* {ACCESS_FEAT_AS}.is_argument */
EIF_BOOLEAN F3657_43384 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu1_1 = *(EIF_NATURAL_8 *)(Current + O31703[Dtype(Current)-3656]);
	tu1_1 = eif_bit_and(tu1_1,((EIF_NATURAL_8) 2U));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu1_1 != (EIF_NATURAL_8) ((EIF_INTEGER_32) 0L));
	RTLE;
	return Result;
}

/* {ACCESS_FEAT_AS}.is_inline_local */
EIF_BOOLEAN F3657_43385 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu1_1 = *(EIF_NATURAL_8 *)(Current + O31703[Dtype(Current)-3656]);
	tu1_1 = eif_bit_and(tu1_1,((EIF_NATURAL_8) 8U));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu1_1 != (EIF_NATURAL_8) ((EIF_INTEGER_32) 0L));
	RTLE;
	return Result;
}

/* {ACCESS_FEAT_AS}.is_readonly */
EIF_BOOLEAN F3657_43386 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_8 tu1_1;
	EIF_NATURAL_8 tu1_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu1_1 = *(EIF_NATURAL_8 *)(Current + O31703[Dtype(Current)-3656]);
	tu1_2 = eif_bit_or(((EIF_NATURAL_8) 2U),((EIF_NATURAL_8) 8U));
	tu1_1 = eif_bit_and(tu1_1,tu1_2);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu1_1 != (EIF_NATURAL_8) ((EIF_INTEGER_32) 0L));
	RTLE;
	return Result;
}

/* {ACCESS_FEAT_AS}.is_tuple_access */
EIF_BOOLEAN F3657_43387 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu1_1 = *(EIF_NATURAL_8 *)(Current + O31703[Dtype(Current)-3656]);
	tu1_1 = eif_bit_and(tu1_1,((EIF_NATURAL_8) 4U));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu1_1 != (EIF_NATURAL_8) ((EIF_INTEGER_32) 0L));
	RTLE;
	return Result;
}

/* {ACCESS_FEAT_AS}.is_feature */
EIF_BOOLEAN F3657_43388 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_8 tu1_1;
	EIF_NATURAL_8 tu1_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu1_1 = *(EIF_NATURAL_8 *)(Current + O31703[Dtype(Current)-3656]);
	tu1_2 = eif_bit_or(((EIF_NATURAL_8) 1U),((EIF_NATURAL_8) 2U));
	tu1_2 = eif_bit_or(tu1_2,((EIF_NATURAL_8) 8U));
	tu1_2 = eif_bit_or(tu1_2,((EIF_NATURAL_8) 4U));
	tu1_1 = eif_bit_and(tu1_1,tu1_2);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu1_1 == (EIF_NATURAL_8) ((EIF_INTEGER_32) 0L));
	RTLE;
	return Result;
}

/* {ACCESS_FEAT_AS}.argument_position */
EIF_INTEGER_32 F3657_43389 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current + O4080[Dtype(Current)-280]);
}

/* {ACCESS_FEAT_AS}.label_position */
EIF_INTEGER_32 F3657_43390 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current + O4080[Dtype(Current)-280]);
}

/* {ACCESS_FEAT_AS}.access_name */
EIF_REFERENCE F3657_43391 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	{
		/* INLINED CODE (ID_AS.name) */
		tr2 = (EIF_REFERENCE)  0;
		(void) RTCW(tr1);
		tr3 = F2271_22520(tr1);
		tr2 = F1792_17093(RTCW(tr3), *(EIF_INTEGER_32 *)(tr1+ _LNGOFF_0_0_3_4_));
		if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(tr2 != NULL)) {
			RTCT0("from_class_invariant_and_postcondition_of_names_heap_item", EX_CHECK);
				RTCF0;
		}
		/* END INLINED CODE */
	}
	Result = tr2;
	RTLE;
	return Result;
}

/* {ACCESS_FEAT_AS}.index */
EIF_INTEGER_32 F3657_43393 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		{
			/* INLINED CODE (PARAN_LIST_AS.index) */
			ti4_1 = (EIF_INTEGER_32)  0;
			(void) loc1;
			ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_0_0_2_);
			/* END INLINED CODE */
		}
		ti4_1 = ti4_1;
	} else {
		{
			/* INLINED CODE (FEATURE_ID_AS.index) */
			ti4_2 = (EIF_INTEGER_32)  0;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_0_0_3_3_);
			/* END INLINED CODE */
		}
		ti4_1 = ti4_2;
	}
	Result = (EIF_INTEGER_32) ti4_1;
	RTLE;
	return Result;
}

/* {ACCESS_FEAT_AS}.last_token */
EIF_REFERENCE F3657_43394 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		tr1 = F3657_43380(Current);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R31332[Dtype(loc1)-3615])(loc1, arg1);
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			{
				/* INLINED CODE (FEATURE_ID_AS.last_token) */
				tr1 = (EIF_REFERENCE)  0;
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tr1 = F3690_43670(RTCW(tr2), arg1);
				/* END INLINED CODE */
			}
			RTLE;
			return (EIF_REFERENCE) tr1;
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tr1 = F3668_43500(loc2, arg1);
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			{
				/* INLINED CODE (FEATURE_ID_AS.last_token) */
				tr1 = (EIF_REFERENCE)  0;
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tr1 = F3690_43670(RTCW(tr2), arg1);
				/* END INLINED CODE */
			}
			RTLE;
			return (EIF_REFERENCE) tr1;
		}
	}/* NOTREACHED */
	
}

/* {ACCESS_FEAT_AS}.is_equivalent */
EIF_BOOLEAN F3657_43395 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	Result = '\0';
	{
		/* INLINED CODE (FEATURE_ID_AS.is_equivalent) */
		tb1 = (EIF_BOOLEAN)  0;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		tb1 = F3771_44608(RTCW(tr1), tr2);
		/* END INLINED CODE */
	}
	if (tb1) {
		tr1 = F3657_43380(Current);
		tr2 = F3657_43380(RTCW(arg1));
		Result = F3615_42842(Current, tr1, tr2);
	}
	RTLE;
	return Result;
}

/* {ACCESS_FEAT_AS}.set_parameters */
void F3657_43397 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
}

/* {ACCESS_FEAT_AS}.set_argument_position */
void F3657_43398 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O4080[Dtype(Current)-280]) = (EIF_INTEGER_32) arg1;
}

/* {ACCESS_FEAT_AS}.set_label_position */
void F3657_43399 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O4080[Dtype(Current)-280]) = (EIF_INTEGER_32) arg1;
}

/* {ACCESS_FEAT_AS}.enable_local */
void F3657_43400 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_8 tu1_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu1_1 = *(EIF_NATURAL_8 *)(Current + O31703[dtype-3656]);
	tu1_1 = eif_bit_or(tu1_1,((EIF_NATURAL_8) 1U));
	*(EIF_NATURAL_8 *)(Current + O31703[dtype-3656]) = (EIF_NATURAL_8) tu1_1;
	RTLE;
}

/* {ACCESS_FEAT_AS}.enable_inline_local */
void F3657_43401 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_8 tu1_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu1_1 = *(EIF_NATURAL_8 *)(Current + O31703[dtype-3656]);
	tu1_1 = eif_bit_or(tu1_1,((EIF_NATURAL_8) 8U));
	*(EIF_NATURAL_8 *)(Current + O31703[dtype-3656]) = (EIF_NATURAL_8) tu1_1;
	RTLE;
}

/* {ACCESS_FEAT_AS}.enable_argument */
void F3657_43402 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_8 tu1_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu1_1 = *(EIF_NATURAL_8 *)(Current + O31703[dtype-3656]);
	tu1_1 = eif_bit_or(tu1_1,((EIF_NATURAL_8) 2U));
	*(EIF_NATURAL_8 *)(Current + O31703[dtype-3656]) = (EIF_NATURAL_8) tu1_1;
	RTLE;
}

/* {ACCESS_FEAT_AS}.enable_tuple_access */
void F3657_43403 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_8 tu1_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu1_1 = *(EIF_NATURAL_8 *)(Current + O31703[dtype-3656]);
	tu1_1 = eif_bit_or(tu1_1,((EIF_NATURAL_8) 4U));
	*(EIF_NATURAL_8 *)(Current + O31703[dtype-3656]) = (EIF_NATURAL_8) tu1_1;
	RTLE;
}

void EIF_Minit2608 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
