/*
 * Code for class DEFERRED_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "de2646.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DEFERRED_AS}.process */
void F3697_43810 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7773[Dtype(RTCW(arg1))-674])(arg1, Current);
}

/* {DEFERRED_AS}.is_equivalent */
EIF_BOOLEAN F3697_43811 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {DEFERRED_AS}.is_deferred */
EIF_BOOLEAN F3697_43812 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {DEFERRED_AS}.index_of_instruction */
EIF_INTEGER_32 F3697_43814 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
}

void EIF_Minit2646 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
