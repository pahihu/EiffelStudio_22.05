
#ifndef _C53_re2627_
#define _C53_re2627_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3678_43517(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F3678_43518(EIF_REFERENCE);
extern EIF_REFERENCE F3678_43519(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F3678_43520(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2627(void);
extern void F1540_14695(EIF_REFERENCE);
extern EIF_REFERENCE F1792_17093(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F1566_14933(EIF_REFERENCE);
extern EIF_REFERENCE F2271_22520(EIF_REFERENCE);
extern char *(*R11799[])();
extern char *(*R17105[])();
extern char *(*R11[])();
extern char *(*R17139[])();
extern char *(*R7806[])();
extern char *(*R11885[])();

#ifdef __cplusplus
}
#endif

#endif
