/*
 * Code for class RENAME_CLAUSE_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "re2627.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RENAME_CLAUSE_AS}.process */
void F3678_43517 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7806[Dtype(RTCW(arg1))-674])(arg1, Current);
}

/* {RENAME_CLAUSE_AS}.dump */
EIF_REFERENCE F3678_43518 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLIU(6);
	
	RTGC;
	Result = RTMS_EX_H("rename ",7,1230102048);
	tr1 = *(EIF_REFERENCE *)(Current);
	{
		/* INLINED CODE (ARRAYED_LIST.start) */
		(void) RTCW(tr1);
		*(EIF_INTEGER_32 *)(tr1+ _LNGOFF_2_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		/* END INLINED CODE */
	}
	;
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			/* INLINED CODE (LIST.after) */
			tb1 = (EIF_BOOLEAN)  0;
			(void) RTCW(tr1);
			ti4_1 = *(EIF_INTEGER_32 *)(tr1+ _LNGOFF_2_1_0_0_);
			ti4_2 = F1566_14933(tr1);
			tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
			/* END INLINED CODE */
		}
		tb1 = tb1;
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			/* INLINED CODE (ARRAYED_LIST.item) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(tr1);
			tr3 = *(EIF_REFERENCE *)(tr1);
			tr2 = 
				/* INLINED CODE (SPECIAL.item) */
				*((EIF_REFERENCE *)RTCW(tr3) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(tr1+ _LNGOFF_2_1_0_0_) - ((EIF_INTEGER_32) 1L))))
				/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		tr1 = tr2;
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
		{
			/* INLINED CODE (ID_AS.name) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(tr1);
			tr3 = F2271_22520(tr1);
			tr2 = F1792_17093(RTCW(tr3), *(EIF_INTEGER_32 *)(tr1+ _LNGOFF_0_0_3_4_));
			if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(tr2 != NULL)) {
				RTCT0("from_class_invariant_and_postcondition_of_names_heap_item", EX_CHECK);
					RTCF0;
			}
			/* END INLINED CODE */
		}
		tr1 = tr2;
		tr2 = RTMS_EX_H(" as ",4,543257376);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R17105[Dtype(RTCW(tr1))-2246])(tr1, tr2);
		tr2 = *(EIF_REFERENCE *)(Current);
		{
			/* INLINED CODE (ARRAYED_LIST.item) */
			tr3 = (EIF_REFERENCE)  0;
			(void) RTCW(tr2);
			tr4 = *(EIF_REFERENCE *)(tr2);
			tr3 = 
				/* INLINED CODE (SPECIAL.item) */
				*((EIF_REFERENCE *)RTCW(tr4) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(tr2+ _LNGOFF_2_1_0_0_) - ((EIF_INTEGER_32) 1L))))
				/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		tr2 = tr3;
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_1_);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_1_);
		{
			/* INLINED CODE (ID_AS.name) */
			tr3 = (EIF_REFERENCE)  0;
			(void) RTCW(tr2);
			tr4 = F2271_22520(tr2);
			tr3 = F1792_17093(RTCW(tr4), *(EIF_INTEGER_32 *)(tr2+ _LNGOFF_0_0_3_4_));
			if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(tr3 != NULL)) {
				RTCT0("from_class_invariant_and_postcondition_of_names_heap_item", EX_CHECK);
					RTCF0;
			}
			/* END INLINED CODE */
		}
		tr2 = tr3;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R17105[Dtype(RTCW(tr1))-2246])(tr1, tr2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17139[Dtype(RTCW(Result))-2247])(Result, tr1);
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			/* INLINED CODE (ARRAYED_LIST.forth) */
			(void) RTCW(tr1);
			(*(EIF_INTEGER_32 *)(tr1+ _LNGOFF_2_1_0_0_))++;
			/* END INLINED CODE */
		}
		;
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			/* INLINED CODE (LIST.after) */
			tb2 = (EIF_BOOLEAN)  0;
			(void) RTCW(tr1);
			ti4_1 = *(EIF_INTEGER_32 *)(tr1+ _LNGOFF_2_1_0_0_);
			ti4_2 = F1566_14933(tr1);
			tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
			/* END INLINED CODE */
		}
		tb2 = tb2;
		if ((EIF_BOOLEAN) !tb2) {
			tr1 = RTMS_EX_H(", ",2,11296);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17139[Dtype(RTCW(Result))-2247])(Result, tr1);
		}
	}
	tr1 = RTMS_EX_H(" end",4,543518308);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17139[Dtype(RTCW(Result))-2247])(Result, tr1);
	RTLE;
	return Result;
}

/* {RENAME_CLAUSE_AS}.new_names */
EIF_REFERENCE F3678_43519 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			/* INLINED CODE (FINITE.is_empty) */
			tb2 = (EIF_BOOLEAN)  0;
			(void) RTCW(tr1);
			ti4_1 = F1566_14933(tr1);
			tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
			/* END INLINED CODE */
		}
		tb2 = tb2;
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		{
			static EIF_TYPE_INDEX typarr0[] = {1539,2247,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1539, _OBJSIZ_2_3_0_1_0_0_0_0_);
		}
		F1540_14695(RTCW(Result));
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			/* INLINED CODE (ARRAYED_LIST.start) */
			(void) RTCW(tr1);
			*(EIF_INTEGER_32 *)(tr1+ _LNGOFF_2_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			/* END INLINED CODE */
		}
		;
		for (;;) {
			tr1 = *(EIF_REFERENCE *)(Current);
			{
				/* INLINED CODE (LIST.after) */
				tb1 = (EIF_BOOLEAN)  0;
				(void) RTCW(tr1);
				ti4_1 = *(EIF_INTEGER_32 *)(tr1+ _LNGOFF_2_1_0_0_);
				ti4_2 = F1566_14933(tr1);
				tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
				/* END INLINED CODE */
			}
			tb1 = tb1;
			if (tb1) break;
			tr1 = *(EIF_REFERENCE *)(Current);
			{
				/* INLINED CODE (ARRAYED_LIST.item) */
				tr2 = (EIF_REFERENCE)  0;
				(void) RTCW(tr1);
				tr3 = *(EIF_REFERENCE *)(tr1);
				tr2 = 
					/* INLINED CODE (SPECIAL.item) */
					*((EIF_REFERENCE *)RTCW(tr3) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(tr1+ _LNGOFF_2_1_0_0_) - ((EIF_INTEGER_32) 1L))))
					/* END INLINED CODE */;
				/* END INLINED CODE */
			}
			tr1 = tr2;
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
			{
				/* INLINED CODE (ID_AS.name) */
				tr2 = (EIF_REFERENCE)  0;
				(void) RTCW(tr1);
				tr3 = F2271_22520(tr1);
				tr2 = F1792_17093(RTCW(tr3), *(EIF_INTEGER_32 *)(tr1+ _LNGOFF_0_0_3_4_));
				if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(tr2 != NULL)) {
					RTCT0("from_class_invariant_and_postcondition_of_names_heap_item", EX_CHECK);
						RTCF0;
				}
				/* END INLINED CODE */
			}
			tr1 = tr2;
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(tr1))-3])(tr1, arg1);
			if (tb2) {
				tr1 = *(EIF_REFERENCE *)(Current);
				{
					/* INLINED CODE (ARRAYED_LIST.item) */
					tr2 = (EIF_REFERENCE)  0;
					(void) RTCW(tr1);
					tr3 = *(EIF_REFERENCE *)(tr1);
					tr2 = 
						/* INLINED CODE (SPECIAL.item) */
						*((EIF_REFERENCE *)RTCW(tr3) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(tr1+ _LNGOFF_2_1_0_0_) - ((EIF_INTEGER_32) 1L))))
						/* END INLINED CODE */;
					/* END INLINED CODE */
				}
				tr1 = tr2;
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
				{
					/* INLINED CODE (ID_AS.name) */
					tr2 = (EIF_REFERENCE)  0;
					(void) RTCW(tr1);
					tr3 = F2271_22520(tr1);
					tr2 = F1792_17093(RTCW(tr3), *(EIF_INTEGER_32 *)(tr1+ _LNGOFF_0_0_3_4_));
					if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(tr2 != NULL)) {
						RTCT0("from_class_invariant_and_postcondition_of_names_heap_item", EX_CHECK);
							RTCF0;
					}
					/* END INLINED CODE */
				}
				tr1 = tr2;
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11799[Dtype(RTCW(Result))-1322])(Result, tr1);
			}
			tr1 = *(EIF_REFERENCE *)(Current);
			{
				/* INLINED CODE (ARRAYED_LIST.forth) */
				(void) RTCW(tr1);
				(*(EIF_INTEGER_32 *)(tr1+ _LNGOFF_2_1_0_0_))++;
				/* END INLINED CODE */
			}
			;
		}
	}
	tb2 = '\0';
	if ((EIF_BOOLEAN)(Result != NULL)) {
		{
			/* INLINED CODE (FINITE.is_empty) */
			tb3 = (EIF_BOOLEAN)  0;
			(void) RTCW(Result);
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R11885[Dtype(Result)-1415])(Result);
			tb3 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
			/* END INLINED CODE */
		}
		tb3 = tb3;
		tb2 = tb3;
	}
	if (tb2) {
		RTLE;
		return (EIF_REFERENCE) NULL;
	}
	RTLE;
	return Result;
}

/* {RENAME_CLAUSE_AS}.original_names */
EIF_REFERENCE F3678_43520 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			/* INLINED CODE (FINITE.is_empty) */
			tb2 = (EIF_BOOLEAN)  0;
			(void) RTCW(tr1);
			ti4_1 = F1566_14933(tr1);
			tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
			/* END INLINED CODE */
		}
		tb2 = tb2;
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		{
			static EIF_TYPE_INDEX typarr0[] = {1539,2247,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1539, _OBJSIZ_2_3_0_1_0_0_0_0_);
		}
		F1540_14695(RTCW(Result));
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			/* INLINED CODE (ARRAYED_LIST.start) */
			(void) RTCW(tr1);
			*(EIF_INTEGER_32 *)(tr1+ _LNGOFF_2_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			/* END INLINED CODE */
		}
		;
		for (;;) {
			tr1 = *(EIF_REFERENCE *)(Current);
			{
				/* INLINED CODE (LIST.after) */
				tb1 = (EIF_BOOLEAN)  0;
				(void) RTCW(tr1);
				ti4_1 = *(EIF_INTEGER_32 *)(tr1+ _LNGOFF_2_1_0_0_);
				ti4_2 = F1566_14933(tr1);
				tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
				/* END INLINED CODE */
			}
			tb1 = tb1;
			if (tb1) break;
			tr1 = *(EIF_REFERENCE *)(Current);
			{
				/* INLINED CODE (ARRAYED_LIST.item) */
				tr2 = (EIF_REFERENCE)  0;
				(void) RTCW(tr1);
				tr3 = *(EIF_REFERENCE *)(tr1);
				tr2 = 
					/* INLINED CODE (SPECIAL.item) */
					*((EIF_REFERENCE *)RTCW(tr3) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(tr1+ _LNGOFF_2_1_0_0_) - ((EIF_INTEGER_32) 1L))))
					/* END INLINED CODE */;
				/* END INLINED CODE */
			}
			tr1 = tr2;
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
			{
				/* INLINED CODE (ID_AS.name) */
				tr2 = (EIF_REFERENCE)  0;
				(void) RTCW(tr1);
				tr3 = F2271_22520(tr1);
				tr2 = F1792_17093(RTCW(tr3), *(EIF_INTEGER_32 *)(tr1+ _LNGOFF_0_0_3_4_));
				if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(tr2 != NULL)) {
					RTCT0("from_class_invariant_and_postcondition_of_names_heap_item", EX_CHECK);
						RTCF0;
				}
				/* END INLINED CODE */
			}
			tr1 = tr2;
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(tr1))-3])(tr1, arg1);
			if (tb2) {
				tr1 = *(EIF_REFERENCE *)(Current);
				{
					/* INLINED CODE (ARRAYED_LIST.item) */
					tr2 = (EIF_REFERENCE)  0;
					(void) RTCW(tr1);
					tr3 = *(EIF_REFERENCE *)(tr1);
					tr2 = 
						/* INLINED CODE (SPECIAL.item) */
						*((EIF_REFERENCE *)RTCW(tr3) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(tr1+ _LNGOFF_2_1_0_0_) - ((EIF_INTEGER_32) 1L))))
						/* END INLINED CODE */;
					/* END INLINED CODE */
				}
				tr1 = tr2;
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
				{
					/* INLINED CODE (ID_AS.name) */
					tr2 = (EIF_REFERENCE)  0;
					(void) RTCW(tr1);
					tr3 = F2271_22520(tr1);
					tr2 = F1792_17093(RTCW(tr3), *(EIF_INTEGER_32 *)(tr1+ _LNGOFF_0_0_3_4_));
					if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(tr2 != NULL)) {
						RTCT0("from_class_invariant_and_postcondition_of_names_heap_item", EX_CHECK);
							RTCF0;
					}
					/* END INLINED CODE */
				}
				tr1 = tr2;
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11799[Dtype(RTCW(Result))-1322])(Result, tr1);
			}
			tr1 = *(EIF_REFERENCE *)(Current);
			{
				/* INLINED CODE (ARRAYED_LIST.forth) */
				(void) RTCW(tr1);
				(*(EIF_INTEGER_32 *)(tr1+ _LNGOFF_2_1_0_0_))++;
				/* END INLINED CODE */
			}
			;
		}
		{
			/* INLINED CODE (FINITE.is_empty) */
			tb2 = (EIF_BOOLEAN)  0;
			(void) RTCW(Result);
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R11885[Dtype(Result)-1415])(Result);
			tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
			/* END INLINED CODE */
		}
		tb2 = tb2;
		if (tb2) {
			RTLE;
			return (EIF_REFERENCE) NULL;
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit2627 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
