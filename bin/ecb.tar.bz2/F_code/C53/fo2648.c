/*
 * Code for class FORMAL_GENERIC_LIST_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "fo2648.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {FORMAL_GENERIC_LIST_AS}.process */
void F3700_43829 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7811[Dtype(RTCW(arg1))-674])(arg1, Current);
}

/* {FORMAL_GENERIC_LIST_AS}.transform_class_types_to_formals_and_record_suppliers */
void F3700_43830 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,Current);
	RTLR(5,loc1);
	RTLR(6,tr1);
	RTLR(7,tr2);
	RTLR(8,loc3);
	RTLIU(9);
	
	RTGC;
	loc2 = RTLNS(eif_new_type(2278, 0x00).id, 2278, _OBJSIZ_5_0_0_0_0_0_0_0_);
	F2279_22611(RTCW(loc2), arg1, arg2, arg3);
	{
		/* INLINED CODE (ARRAYED_LIST.start) */
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		/* END INLINED CODE */
	}
	;
	for (;;) {
		{
			/* INLINED CODE (LIST.after) */
			tb1 = (EIF_BOOLEAN)  0;
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_0_);
			ti4_2 = F1566_14933(Current);
			tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
			/* END INLINED CODE */
		}
		if (tb1) break;
		{
			/* INLINED CODE (ARRAYED_LIST.item) */
			tr1 = (EIF_REFERENCE)  0;
			tr2 = *(EIF_REFERENCE *)(Current);
			tr1 = 
				/* INLINED CODE (SPECIAL.item) */
				*((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_0_) - ((EIF_INTEGER_32) 1L))))
				/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		loc1 = *(EIF_REFERENCE *)(RTCV(tr1) + _REFACS_1_);
		{
			/* INLINED CODE (ARRAYED_LIST.start) */
			(void) RTCW(loc1);
			*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			/* END INLINED CODE */
		}
		;
		for (;;) {
			{
				/* INLINED CODE (LIST.after) */
				tb2 = (EIF_BOOLEAN)  0;
				(void) RTCW(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_1_0_0_);
				ti4_2 = F1566_14933(loc1);
				tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
				/* END INLINED CODE */
			}
			tb2 = tb2;
			if (tb2) break;
			{
				/* INLINED CODE (ARRAYED_LIST.item) */
				tr1 = (EIF_REFERENCE)  0;
				(void) RTCW(loc1);
				tr2 = *(EIF_REFERENCE *)(loc1);
				tr1 = 
					/* INLINED CODE (SPECIAL.item) */
					*((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_1_0_0_) - ((EIF_INTEGER_32) 1L))))
					/* END INLINED CODE */;
				/* END INLINED CODE */
			}
			tr1 = tr1;
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R31316[Dtype(RTCW(tr1))-3615])(tr1, loc2);
			{
				/* INLINED CODE (AST_FORMAL_GENERICS_PASS2.has_node_changed) */
				tb3 = (EIF_BOOLEAN)  0;
				(void) RTCW(loc2);
				tr1 = *(EIF_REFERENCE *)(loc2 + _REFACS_1_);
				tb3 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 != NULL);
				/* END INLINED CODE */
			}
			tb3 = tb3;
			if (tb3) {
				{
					/* INLINED CODE (AST_FORMAL_GENERICS_PASS2.consume_node) */
					(void) RTCW(loc2);
					tr1 = *(EIF_REFERENCE *)(loc2 + _REFACS_1_);
					RTAR(loc2, tr1);
					*(EIF_REFERENCE *)(loc2) = (EIF_REFERENCE) tr1;
					*(EIF_REFERENCE *)(loc2 + _REFACS_1_) = (EIF_REFERENCE) NULL;
					/* END INLINED CODE */
				}
				;
				tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
				loc3 = tr1;
				if (EIF_TEST(loc3)) {
					{
						/* INLINED CODE (ARRAYED_LIST.item) */
						tr1 = (EIF_REFERENCE)  0;
						(void) RTCW(loc1);
						tr2 = *(EIF_REFERENCE *)(loc1);
						tr1 = 
							/* INLINED CODE (SPECIAL.item) */
							*((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_1_0_0_) - ((EIF_INTEGER_32) 1L))))
							/* END INLINED CODE */;
						/* END INLINED CODE */
					}
					tr1 = tr1;
					{
						/* INLINED CODE (CONSTRAINING_TYPE_AS.set_type) */
						(void) RTCW(tr1);
						RTAR(tr1, loc3);
						*(EIF_REFERENCE *)(tr1) = (EIF_REFERENCE) loc3;
						/* END INLINED CODE */
					}
					;
				}
			}
			{
				/* INLINED CODE (ARRAYED_LIST.forth) */
				(void) RTCW(loc1);
				(*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_1_0_0_))++;
				/* END INLINED CODE */
			}
			;
		}
		{
			/* INLINED CODE (ARRAYED_LIST.forth) */
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_0_))++;
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
}

/* {FORMAL_GENERIC_LIST_AS}.first_token */
EIF_REFERENCE F3700_43831 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		RTLE;
		return (EIF_REFERENCE) F3698_43824(Current, arg1);
	} else {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_) != ((EIF_INTEGER_32) 0L))) {
			{
				/* INLINED CODE (FORMAL_GENERIC_LIST_AS.lsqure_symbol) */
				tr1 = (EIF_REFERENCE)  0;
				tr1 = F3615_42861(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_));
				/* END INLINED CODE */
			}
			RTLE;
			return (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {FORMAL_GENERIC_LIST_AS}.last_token */
EIF_REFERENCE F3700_43832 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		RTLE;
		return (EIF_REFERENCE) F3698_43825(Current, arg1);
	} else {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_) != ((EIF_INTEGER_32) 0L))) {
			{
				/* INLINED CODE (FORMAL_GENERIC_LIST_AS.rsqure_symbol) */
				tr1 = (EIF_REFERENCE)  0;
				tr1 = F3615_42861(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_));
				/* END INLINED CODE */
			}
			RTLE;
			return (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {FORMAL_GENERIC_LIST_AS}.lsqure_symbol */
EIF_REFERENCE F3700_43835 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F3615_42861(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_));
}

/* {FORMAL_GENERIC_LIST_AS}.rsqure_symbol */
EIF_REFERENCE F3700_43836 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F3615_42861(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_));
}

/* {FORMAL_GENERIC_LIST_AS}.set_lsqure_symbol */
void F3700_43837 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O31853[Dtype(arg1)-3689]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

/* {FORMAL_GENERIC_LIST_AS}.set_rsqure_symbol */
void F3700_43838 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O31853[Dtype(arg1)-3689]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

/* {FORMAL_GENERIC_LIST_AS}.set_squre_symbols */
void F3700_43839 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	{
		/* INLINED CODE (FORMAL_GENERIC_LIST_AS.set_lsqure_symbol) */
		if ((EIF_BOOLEAN)(arg1 != NULL)) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O31853[Dtype(arg1)-3689]);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_) = (EIF_INTEGER_32) ti4_1;
		}
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (FORMAL_GENERIC_LIST_AS.set_rsqure_symbol) */
		if ((EIF_BOOLEAN)(arg2 != NULL)) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2) + O31853[Dtype(arg2)-3689]);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_) = (EIF_INTEGER_32) ti4_1;
		}
		/* END INLINED CODE */
	}
	;
	RTLE;
}

void EIF_Minit2648 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
