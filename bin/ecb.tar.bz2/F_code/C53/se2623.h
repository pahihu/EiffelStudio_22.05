
#ifndef _C53_se2623_
#define _C53_se2623_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3674_43513(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2623(void);
extern char *(*R7810[])();

#ifdef __cplusplus
}
#endif

#endif
