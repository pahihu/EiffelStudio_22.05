
#ifndef _C53_ac2610_
#define _C53_ac2610_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3659_43414(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2610(void);
extern char *(*R7760[])();

#ifdef __cplusplus
}
#endif

#endif
