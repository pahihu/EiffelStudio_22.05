/*
 * Code for class QUALIFIED_ANCHORED_TYPE_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "qu2634.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {QUALIFIED_ANCHORED_TYPE_AS}.make_anchored */
void F3685_43608 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLIU(7);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	{
		static EIF_TYPE_INDEX typarr0[] = {3697,3631,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F3698_43815(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	{
		/* INLINED CODE (QUALIFIED_ANCHORED_TYPE_AS.extend) */
		tr1 = (EIF_REFERENCE)  0;
		if ((EIF_BOOLEAN)(arg2 != NULL)) {
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			F3698_43821(RTCW(tr2), arg2);
		}
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr3 = RTLNS(eif_new_type(3631, 0x00).id, 3631, _OBJSIZ_2_0_0_2_0_0_0_0_);
		F3632_43118(RTCW(tr3), arg3);
		F1566_14953(RTCW(tr2), tr3);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {QUALIFIED_ANCHORED_TYPE_AS}.make_explicit */
void F3685_43609 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(8);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLR(4,arg3);
	RTLR(5,arg4);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLIU(8);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O31853[Dtype(arg1)-3689]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_6_0_5_) = (EIF_INTEGER_32) ti4_1;
	}
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg2;
	{
		static EIF_TYPE_INDEX typarr0[] = {3697,3631,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F3698_43815(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	{
		/* INLINED CODE (QUALIFIED_ANCHORED_TYPE_AS.extend) */
		tr1 = (EIF_REFERENCE)  0;
		if ((EIF_BOOLEAN)(arg3 != NULL)) {
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			F3698_43821(RTCW(tr2), arg3);
		}
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr3 = RTLNS(eif_new_type(3631, 0x00).id, 3631, _OBJSIZ_2_0_0_2_0_0_0_0_);
		F3632_43118(RTCW(tr3), arg4);
		F1566_14953(RTCW(tr2), tr3);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {QUALIFIED_ANCHORED_TYPE_AS}.has_anchor */
EIF_BOOLEAN F3685_43610 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {QUALIFIED_ANCHORED_TYPE_AS}.extend */
void F3685_43611 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F3698_43821(RTCW(tr1), arg1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr2 = RTLNS(eif_new_type(3631, 0x00).id, 3631, _OBJSIZ_2_0_0_2_0_0_0_0_);
	F3632_43118(RTCW(tr2), arg2);
	F1566_14953(RTCW(tr1), tr2);
	RTLE;
}

/* {QUALIFIED_ANCHORED_TYPE_AS}.process */
void F3685_43612 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7781[Dtype(RTCW(arg1))-674])(arg1, Current);
}

/* {QUALIFIED_ANCHORED_TYPE_AS}.like_keyword */
EIF_REFERENCE F3685_43614 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_6_0_5_);
	tb1 = '\0';
	tb2 = '\0';
	if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
		{
			/* INLINED CODE (LEAF_AS_LIST.valid_index) */
			tb3 = (EIF_BOOLEAN)  0;
			(void) RTCW(arg1);
			ti4_1 = *(EIF_INTEGER_32 *)(arg1+ _LNGOFF_7_1_0_1_);
			tb3 = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) (((EIF_INTEGER_32) 1L) <= loc1) && (EIF_BOOLEAN) (loc1 <= ti4_1));
			/* END INLINED CODE */
		}
		tb3 = tb3;
		tb2 = tb3;
	}
	if (tb2) {
		tr1 = F2492_26087(RTCW(arg1), loc1);
		loc2 = tr1;
		loc2 = RTRV(eif_new_type(3694, 0),loc2);
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) loc2;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {QUALIFIED_ANCHORED_TYPE_AS}.index */
EIF_INTEGER_32 F3685_43615 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_6_0_5_);
}

/* {QUALIFIED_ANCHORED_TYPE_AS}.first_token */
EIF_REFERENCE F3685_43618 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	Result = F3681_43553(Current, arg1);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		if ((EIF_BOOLEAN)(arg1 != NULL)) {
			Result = F3685_43614(Current, arg1);
		}
		if ((EIF_BOOLEAN)(Result == NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current);
			Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R31331[Dtype(RTCW(tr1))-3615])(tr1, arg1);
		}
	}
	RTLE;
	return Result;
}

/* {QUALIFIED_ANCHORED_TYPE_AS}.last_token */
EIF_REFERENCE F3685_43619 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	{
		/* INLINED CODE (TYPE_AS.last_token) */
		tr1 = (EIF_REFERENCE)  0;
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O31780[Dtype(Current)-3680]) != ((EIF_INTEGER_32) 0L)))) {
			tr1 = F3681_43545(Current, arg1);
		}
		/* END INLINED CODE */
	}
	Result = tr1;
	if ((EIF_BOOLEAN)(Result == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = F3698_43825(RTCW(tr1), arg1);
	}
	RTLE;
	return Result;
}

/* {QUALIFIED_ANCHORED_TYPE_AS}.is_equivalent */
EIF_BOOLEAN F3685_43620 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if (F3615_42842(Current, *(EIF_REFERENCE *)(Current), tr1)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		tb1 = F3615_42842(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_), tr1);
	}
	if (tb1) {
		Result = F3681_43563(Current, arg1);
	}
	RTLE;
	return Result;
}

/* {QUALIFIED_ANCHORED_TYPE_AS}.dump */
EIF_REFERENCE F3685_43621 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_REFERENCE tr6 = NULL;
	EIF_REFERENCE tr7 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(11);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc2);
	RTLR(6,tr3);
	RTLR(7,tr4);
	RTLR(8,tr5);
	RTLR(9,tr6);
	RTLR(10,tr7);
	RTLIU(11);
	
	RTGC;
	Result = RTLNS(eif_new_type(2247, 0x00).id, 2247, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F2246_21883(RTCW(Result), ((EIF_INTEGER_32) 8L));
	F3681_43568(Current, Result);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(3681, 0x00),loc1);
	if (EIF_TEST(loc1)) {
		{
			/* INLINED CODE (LIKE_CUR_AS.dump) */
			tr1 = (EIF_REFERENCE)  0;
			(void) loc1;
			tr1 = RTLNS(eif_new_type(2247, 0x00).id, 2247, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F2246_21883(RTCW(tr1), ((EIF_INTEGER_32) 12L));
			F3681_43568(loc1, tr1);
			tr2 = RTMS_EX_H("like Current",12,331478388);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17141[Dtype(RTCW(tr1))-2247])(tr1, tr2);
			/* END INLINED CODE */
		}
		tr1 = tr1;
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17141[Dtype(RTCW(Result))-2247])(Result, tr1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current);
		loc2 = tr1;
		loc2 = RTRV(eif_new_type(3682, 0x00),loc2);
		if (EIF_TEST(loc2)) {
			tr1 = F3683_43590(loc2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17141[Dtype(RTCW(Result))-2247])(Result, tr1);
		} else {
			tr1 = RTMS_EX_H("like {",6,2014932603);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17141[Dtype(RTCW(Result))-2247])(Result, tr1);
			tr1 = *(EIF_REFERENCE *)(Current);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R31805[Dtype(RTCW(tr1))-3681])(tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17141[Dtype(RTCW(Result))-2247])(Result, tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R17143[Dtype(RTCW(Result))-2247])(Result, (EIF_CHARACTER_8) '}');
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,2049,0,2247,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	((EIF_TYPED_VALUE *)tr2+2)->it_r = Result;
	RTAR(tr2,Result);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {2204,0xFFF9,1,2049,3631,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A2634_115_2, (EIF_POINTER) _A2634_115_2, (EIF_POINTER)(0),tr2, 1, 1);
	}
	{
		/* INLINED CODE (ARRAYED_LIST.do_all) */
		(void) RTCW(tr1);
		tr6 = *(EIF_REFERENCE *)(tr1);
		tr7 = *(EIF_REFERENCE *)(tr1);
		ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr7);
		F1929_18486(RTCW(tr6), tr5, ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
		/* END INLINED CODE */
	}
	;
	RTLE;
	return Result;
}

/* {QUALIFIED_ANCHORED_TYPE_AS}.inline-agent#1 of dump */
void F3685_46202 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R17143[Dtype(RTCW(arg2))-2247])(arg2, (EIF_CHARACTER_8) '.');
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	{
		/* INLINED CODE (ID_AS.name) */
		tr2 = (EIF_REFERENCE)  0;
		(void) RTCW(tr1);
		tr3 = F2271_22520(tr1);
		tr2 = F1792_17093(RTCW(tr3), *(EIF_INTEGER_32 *)(tr1+ _LNGOFF_0_0_3_4_));
		if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(tr2 != NULL)) {
			RTCT0("from_class_invariant_and_postcondition_of_names_heap_item", EX_CHECK);
				RTCF0;
		}
		/* END INLINED CODE */
	}
	tr1 = tr2;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17141[Dtype(RTCW(arg2))-2247])(arg2, tr1);
	RTLE;
}

void EIF_Minit2634 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
