/*
 * Code for class NONE_TYPE_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "no2635.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {NONE_TYPE_AS}.initialize */
void F3686_43622 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {NONE_TYPE_AS}.process */
void F3686_43624 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7785[Dtype(RTCW(arg1))-674])(arg1, Current);
}

/* {NONE_TYPE_AS}.index */
EIF_INTEGER_32 F3686_43626 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_0_0_3_3_);
	RTLE;
	return Result;
}

/* {NONE_TYPE_AS}.first_token */
EIF_REFERENCE F3686_43627 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	Result = F3681_43553(Current, arg1);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			/* INLINED CODE (LEAF_AS.first_token) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(tr1);
			tr2 = (EIF_REFERENCE) tr1;
			/* END INLINED CODE */
		}
		Result = tr2;
	}
	RTLE;
	return Result;
}

/* {NONE_TYPE_AS}.last_token */
EIF_REFERENCE F3686_43628 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	{
		/* INLINED CODE (TYPE_AS.last_token) */
		tr1 = (EIF_REFERENCE)  0;
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O31780[Dtype(Current)-3680]) != ((EIF_INTEGER_32) 0L)))) {
			tr1 = F3681_43545(Current, arg1);
		}
		/* END INLINED CODE */
	}
	Result = tr1;
	if ((EIF_BOOLEAN)(Result == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			/* INLINED CODE (LEAF_AS.last_token) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(tr1);
			tr2 = (EIF_REFERENCE) tr1;
			/* END INLINED CODE */
		}
		Result = tr2;
	}
	RTLE;
	return Result;
}

/* {NONE_TYPE_AS}.is_equivalent */
EIF_BOOLEAN F3686_43629 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F3681_43563(Current, arg1);
}

/* {NONE_TYPE_AS}.dump */
EIF_REFERENCE F3686_43630 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(2247, 0x00).id, 2247, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F2246_21883(RTCW(Result), ((EIF_INTEGER_32) 4L));
	F3681_43568(Current, Result);
	tr1 = RTMS_EX_H("NONE",4,1313820229);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17139[Dtype(RTCW(Result))-2247])(Result, tr1);
	RTLE;
	return Result;
}

void EIF_Minit2635 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
