/*
 * Code for class SELECT_CLAUSE_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "se2623.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SELECT_CLAUSE_AS}.process */
void F3674_43513 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7810[Dtype(RTCW(arg1))-674])(arg1, Current);
}

void EIF_Minit2623 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
