/*
 * Code for class TYPE_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ty2630.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TYPE_AS}.lcurly_symbol */
EIF_REFERENCE F3681_43544 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F3615_42861(Current, arg1, *(EIF_INTEGER_32 *)(Current + O31779[Dtype(Current)-3680]));
}

/* {TYPE_AS}.rcurly_symbol */
EIF_REFERENCE F3681_43545 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F3615_42861(Current, arg1, *(EIF_INTEGER_32 *)(Current + O31780[Dtype(Current)-3680]));
}

/* {TYPE_AS}.attachment_mark */
EIF_REFERENCE F3681_43546 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current + O31781[Dtype(Current)-3680]);
	{
		/* INLINED CODE (LEAF_AS_LIST.valid_index) */
		tb1 = (EIF_BOOLEAN)  0;
		(void) RTCW(arg1);
		ti4_1 = *(EIF_INTEGER_32 *)(arg1+ _LNGOFF_7_1_0_1_);
		tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) (((EIF_INTEGER_32) 1L) <= loc1) && (EIF_BOOLEAN) (loc1 <= ti4_1));
		/* END INLINED CODE */
	}
	tb1 = tb1;
	if (tb1) {
		tr1 = RTLNTY2(eif_new_type(3694, 0x00), 0x00);
		tr2 = F2492_26087(RTCW(arg1), loc1);
		Result = F2015_19025(tr1, tr2);
	}
	RTLE;
	return Result;
}

/* {TYPE_AS}.variance_mark */
EIF_REFERENCE F3681_43547 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current + O31782[Dtype(Current)-3680]);
	tb1 = '\0';
	{
		/* INLINED CODE (LEAF_AS_LIST.valid_index) */
		tb2 = (EIF_BOOLEAN)  0;
		(void) RTCW(arg1);
		ti4_1 = *(EIF_INTEGER_32 *)(arg1+ _LNGOFF_7_1_0_1_);
		tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) (((EIF_INTEGER_32) 1L) <= loc1) && (EIF_BOOLEAN) (loc1 <= ti4_1));
		/* END INLINED CODE */
	}
	tb2 = tb2;
	if (tb2) {
		tr1 = F2492_26087(RTCW(arg1), loc1);
		loc2 = tr1;
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) loc2;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {TYPE_AS}.separate_keyword */
EIF_REFERENCE F3681_43550 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current + O31783[Dtype(Current)-3680]);
	tb1 = '\0';
	{
		/* INLINED CODE (LEAF_AS_LIST.valid_index) */
		tb2 = (EIF_BOOLEAN)  0;
		(void) RTCW(arg1);
		ti4_1 = *(EIF_INTEGER_32 *)(arg1+ _LNGOFF_7_1_0_1_);
		tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) (((EIF_INTEGER_32) 1L) <= loc1) && (EIF_BOOLEAN) (loc1 <= ti4_1));
		/* END INLINED CODE */
	}
	tb2 = tb2;
	if (tb2) {
		tr1 = F2492_26087(RTCW(arg1), loc1);
		loc2 = tr1;
		loc2 = RTRV(eif_new_type(3694, 0x00),loc2);
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) loc2;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {TYPE_AS}.set_lcurly_symbol */
void F3681_43551 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O31853[Dtype(arg1)-3689]);
		*(EIF_INTEGER_32 *)(Current + O31779[Dtype(Current)-3680]) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

/* {TYPE_AS}.set_rcurly_symbol */
void F3681_43552 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O31853[Dtype(arg1)-3689]);
		*(EIF_INTEGER_32 *)(Current + O31780[Dtype(Current)-3680]) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

/* {TYPE_AS}.first_token */
EIF_REFERENCE F3681_43553 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O31779[dtype-3680]) != ((EIF_INTEGER_32) 0L))) {
			{
				/* INLINED CODE (TYPE_AS.lcurly_symbol) */
				tr1 = (EIF_REFERENCE)  0;
				tr1 = F3615_42861(Current, arg1, *(EIF_INTEGER_32 *)(Current + O31779[dtype-3680]));
				/* END INLINED CODE */
			}
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O31781[dtype-3680]) != ((EIF_INTEGER_32) 0L))) {
				{
					/* INLINED CODE (TYPE_AS.attachment_mark) */
					ti4_1 = (EIF_INTEGER_32)  0;
					tr1 = (EIF_REFERENCE)  0;
					ti4_1 = *(EIF_INTEGER_32 *)(Current + O31781[dtype-3680]);
					tb1 = F2492_26092(RTCW(arg1), ti4_1);
					if (tb1) {
						tr2 = RTLNTY2(eif_new_type(3694, 0x00), 0x00);
						tr3 = F2492_26087(RTCW(arg1), ti4_1);
						tr1 = F2015_19025(tr2, tr3);
					}
					/* END INLINED CODE */
				}
				Result = tr1;
			} else {
				if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O31782[dtype-3680]) != ((EIF_INTEGER_32) 0L))) {
					Result = F3681_43547(Current, arg1);
				} else {
					if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O31783[dtype-3680]) != ((EIF_INTEGER_32) 0L))) {
						Result = F3681_43550(Current, arg1);
						RTLE;
						return (EIF_REFERENCE) Result;
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {TYPE_AS}.last_token */
EIF_REFERENCE F3681_43554 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O31780[Dtype(Current)-3680]) != ((EIF_INTEGER_32) 0L)))) {
		{
			/* INLINED CODE (TYPE_AS.rcurly_symbol) */
			tr1 = (EIF_REFERENCE)  0;
			tr1 = F3615_42861(Current, arg1, *(EIF_INTEGER_32 *)(Current + O31780[Dtype(Current)-3680]));
			/* END INLINED CODE */
		}
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {TYPE_AS}.has_anchor */
EIF_BOOLEAN F3681_43561 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_BOOLEAN) 0;
}

/* {TYPE_AS}.has_same_marks */
EIF_BOOLEAN F3681_43563 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	tb2 = '\0';
	tb3 = '\0';
	tb4 = *(EIF_BOOLEAN *)(RTCW(arg1) + O31793[Dtype(arg1)-3680]);
	if ((EIF_BOOLEAN)(tb4 == *(EIF_BOOLEAN *)(Current + O31793[dtype-3680]))) {
		tb4 = *(EIF_BOOLEAN *)(RTCW(arg1) + O31794[Dtype(arg1)-3680]);
		tb3 = (EIF_BOOLEAN)(tb4 == *(EIF_BOOLEAN *)(Current + O31794[dtype-3680]));
	}
	if (tb3) {
		tb3 = *(EIF_BOOLEAN *)(RTCW(arg1) + O31796[Dtype(arg1)-3680]);
		tb2 = (EIF_BOOLEAN)(tb3 == *(EIF_BOOLEAN *)(Current + O31796[dtype-3680]));
	}
	if (tb2) {
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O31797[Dtype(arg1)-3680]);
		tb1 = (EIF_BOOLEAN)(tb2 == *(EIF_BOOLEAN *)(Current + O31797[dtype-3680]));
	}
	if (tb1) {
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1) + O31798[Dtype(arg1)-3680]);
		Result = (EIF_BOOLEAN)(tb1 == *(EIF_BOOLEAN *)(Current + O31798[dtype-3680]));
	}
	RTLE;
	return Result;
}

/* {TYPE_AS}.set_attachment_mark */
void F3681_43564 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		*(EIF_INTEGER_32 *)(Current + O31781[dtype-3680]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O31853[Dtype(arg1)-3689]);
		*(EIF_INTEGER_32 *)(Current + O31781[dtype-3680]) = (EIF_INTEGER_32) ti4_1;
	}
	*(EIF_BOOLEAN *)(Current + O31793[dtype-3680]) = (EIF_BOOLEAN) arg2;
	*(EIF_BOOLEAN *)(Current + O31794[dtype-3680]) = (EIF_BOOLEAN) arg3;
	RTLE;
}

/* {TYPE_AS}.set_variance_mark */
void F3681_43565 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		*(EIF_INTEGER_32 *)(Current + O31782[dtype-3680]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O31853[Dtype(arg1)-3689]);
		*(EIF_INTEGER_32 *)(Current + O31782[dtype-3680]) = (EIF_INTEGER_32) ti4_1;
	}
	*(EIF_BOOLEAN *)(Current + O31797[dtype-3680]) = (EIF_BOOLEAN) arg2;
	*(EIF_BOOLEAN *)(Current + O31798[dtype-3680]) = (EIF_BOOLEAN) arg3;
	RTLE;
}

/* {TYPE_AS}.set_separate_mark */
void F3681_43566 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		*(EIF_INTEGER_32 *)(Current + O31783[dtype-3680]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O31853[Dtype(arg1)-3689]);
		*(EIF_INTEGER_32 *)(Current + O31783[dtype-3680]) = (EIF_INTEGER_32) ti4_1;
	}
	*(EIF_BOOLEAN *)(Current + O31796[dtype-3680]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {TYPE_AS}.dump_marks */
void F3681_43568 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current + O31797[dtype-3680])) {
		tr1 = RTMS_EX_H("frozen ",7,2077218848);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17141[Dtype(RTCW(arg1))-2247])(arg1, tr1);
	} else {
		if (*(EIF_BOOLEAN *)(Current + O31798[dtype-3680])) {
			tr1 = RTMS_EX_H("variant ",8,1316418336);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17141[Dtype(RTCW(arg1))-2247])(arg1, tr1);
		}
	}
	if (*(EIF_BOOLEAN *)(Current + O31793[dtype-3680])) {
		tr1 = RTMS_EX_H("attached ",9,1651281952);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17141[Dtype(RTCW(arg1))-2247])(arg1, tr1);
	} else {
		if (*(EIF_BOOLEAN *)(Current + O31794[dtype-3680])) {
			tr1 = RTMS_EX_H("detachable ",11,1596642848);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17141[Dtype(RTCW(arg1))-2247])(arg1, tr1);
		}
	}
	if (*(EIF_BOOLEAN *)(Current + O31796[dtype-3680])) {
		tr1 = RTMS_EX_H("separate ",9,579901216);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17141[Dtype(RTCW(arg1))-2247])(arg1, tr1);
	}
	RTLE;
}

void EIF_Minit2630 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
