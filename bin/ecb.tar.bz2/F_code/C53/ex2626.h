
#ifndef _C53_ex2626_
#define _C53_ex2626_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3677_43516(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2626(void);
extern char *(*R7807[])();

#ifdef __cplusplus
}
#endif

#endif
