/*
 * Code for class ACCESS_INV_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ac2609.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ACCESS_INV_AS}.make */
void F3658_43409 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	{
		/* INLINED CODE (ACCESS_FEAT_AS.initialize) */
		F3657_43397(Current, arg2);
		F3632_43118(Current, arg1);
		/* END INLINED CODE */
	}
	;
	if ((EIF_BOOLEAN)(arg3 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg3) + O31853[Dtype(arg3)-3689]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_2_) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

/* {ACCESS_INV_AS}.is_qualified */
EIF_BOOLEAN F3658_43410 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {ACCESS_INV_AS}.process */
void F3658_43411 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7758[Dtype(RTCW(arg1))-674])(arg1, Current);
}

/* {ACCESS_INV_AS}.dot_symbol */
EIF_REFERENCE F3658_43413 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F3615_42861(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_2_));
}

void EIF_Minit2609 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
