
#ifndef _C53_pa2622_
#define _C53_pa2622_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3672_43504(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F3672_43505(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2622(void);
extern void F3668_43492(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R7804[])();

#ifdef __cplusplus
}
#endif

#endif
