/*
 * Code for class SYMBOL_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sy2641.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SYMBOL_AS}.make */
void F3692_43685 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current + O31895[Dtype(Current)-3691]) = (EIF_INTEGER_32) arg1;
	{
		/* INLINED CODE (LOCATION_AS.make_with_location) */
		F323_4773(Current, arg2, arg3, arg4, arg5, arg6, arg7, arg8);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {SYMBOL_AS}.is_plus */
EIF_BOOLEAN F3692_43711 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O31895[Dtype(Current)-3691]) == ((EIF_INTEGER_32) 282L));
}

/* {SYMBOL_AS}.process */
void F3692_43721 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7734[Dtype(RTCW(arg1))-674])(arg1, Current);
}

/* {SYMBOL_AS}.is_equivalent */
EIF_BOOLEAN F3692_43722 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O31895[Dtype(Current)-3691]);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O31895[Dtype(arg1)-3691]);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
	RTLE;
	return Result;
}

void EIF_Minit2641 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
