
#ifndef _C53_fo2620_
#define _C53_fo2620_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3670_43502(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2620(void);
extern char *(*R7801[])();

#ifdef __cplusplus
}
#endif

#endif
