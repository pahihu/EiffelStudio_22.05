/*
 * Code for class NAMED_TUPLE_TYPE_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "na2633.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {NAMED_TUPLE_TYPE_AS}.initialize */
void F3684_43592 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg2;
	RTLE;
}

/* {NAMED_TUPLE_TYPE_AS}.process */
void F3684_43593 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7883[Dtype(RTCW(arg1))-674])(arg1, Current);
}

/* {NAMED_TUPLE_TYPE_AS}.has_anchor */
EIF_BOOLEAN F3684_43594 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_REFERENCE tr6 = NULL;
	EIF_REFERENCE tr7 = NULL;
	EIF_REFERENCE tr8 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,tr5);
	RTLR(6,tr6);
	RTLR(7,tr7);
	RTLR(8,tr8);
	RTLIU(9);
	
	RTGC;
	{
		/* INLINED CODE (NAMED_TUPLE_TYPE_AS.generics) */
		tr1 = (EIF_REFERENCE)  0;
		tr2 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr2));
		/* END INLINED CODE */
	}
	tr2 = tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,2049,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = Current;
	RTAR(tr3,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {2209,0xFFF9,1,2049,3635,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr6= RTLNRF(typres0.id, (EIF_POINTER) __A2633_119_2, (EIF_POINTER) _A2633_119_2, (EIF_POINTER)(0),tr3, 1, 1);
	}
	{
		/* INLINED CODE (ARRAYED_LIST.there_exists) */
		tb1 = (EIF_BOOLEAN)  0;
		(void) RTCW(tr2);
		tr7 = *(EIF_REFERENCE *)(tr2);
		tr8 = *(EIF_REFERENCE *)(tr2);
		ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr8);
		tb1 = F1929_18488(RTCW(tr7), tr6, ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
		/* END INLINED CODE */
	}
	Result = tb1;
	RTLE;
	return Result;
}

/* {NAMED_TUPLE_TYPE_AS}.class_name */
EIF_REFERENCE F3684_43596 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


/* {NAMED_TUPLE_TYPE_AS}.generics */
EIF_REFERENCE F3684_43597 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = *(EIF_REFERENCE *)(RTCW(tr1));
	RTLE;
	return Result;
}

/* {NAMED_TUPLE_TYPE_AS}.index */
EIF_INTEGER_32 F3684_43600 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_0_0_3_3_);
	RTLE;
	return Result;
}

/* {NAMED_TUPLE_TYPE_AS}.generic_count */
EIF_INTEGER_32 F3684_43601 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	{
		/* INLINED CODE (NAMED_TUPLE_TYPE_AS.generics) */
		tr1 = (EIF_REFERENCE)  0;
		tr2 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr2));
		/* END INLINED CODE */
	}
	loc1 = tr1;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_2_1_0_0_);
	{
		/* INLINED CODE (ARRAYED_LIST.start) */
		(void) RTCW(loc1);
		*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		/* END INLINED CODE */
	}
	;
	for (;;) {
		{
			/* INLINED CODE (LIST.after) */
			tb1 = (EIF_BOOLEAN)  0;
			(void) RTCW(loc1);
			ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_1_0_0_);
			ti4_2 = F1566_14933(loc1);
			tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
			/* END INLINED CODE */
		}
		tb1 = tb1;
		if (tb1) break;
		{
			/* INLINED CODE (ARRAYED_LIST.item) */
			tr1 = (EIF_REFERENCE)  0;
			(void) RTCW(loc1);
			tr2 = *(EIF_REFERENCE *)(loc1);
			tr1 = 
				/* INLINED CODE (SPECIAL.item) */
				*((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_1_0_0_) - ((EIF_INTEGER_32) 1L))))
				/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		tr1 = tr1;
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		{
			/* INLINED CODE (ARRAYED_LIST.count) */
			ti4_1 = (EIF_INTEGER_32)  0;
			(void) RTCW(tr1);
			tr2 = *(EIF_REFERENCE *)(tr1);
			ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr2);
			/* END INLINED CODE */
		}
		ti4_1 = ti4_1;
		Result += ti4_1;
		{
			/* INLINED CODE (ARRAYED_LIST.forth) */
			(void) RTCW(loc1);
			(*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_1_0_0_))++;
			/* END INLINED CODE */
		}
		;
	}
	{
		/* INLINED CODE (ARRAYED_LIST.go_i_th) */
		(void) RTCW(loc1);
		*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_1_0_0_) = (EIF_INTEGER_32) loc2;
		/* END INLINED CODE */
	}
	;
	RTLE;
	return Result;
}

/* {NAMED_TUPLE_TYPE_AS}.i_th_type_declaration */
EIF_REFERENCE F3684_43602 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	{
		/* INLINED CODE (NAMED_TUPLE_TYPE_AS.generics) */
		tr1 = (EIF_REFERENCE)  0;
		tr2 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr2));
		/* END INLINED CODE */
	}
	loc1 = tr1;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_2_1_0_0_);
	{
		/* INLINED CODE (ARRAYED_LIST.start) */
		(void) RTCW(loc1);
		*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		/* END INLINED CODE */
	}
	;
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		{
			/* INLINED CODE (LIST.after) */
			tb1 = (EIF_BOOLEAN)  0;
			(void) RTCW(loc1);
			ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_1_0_0_);
			ti4_2 = F1566_14933(loc1);
			tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
			/* END INLINED CODE */
		}
		tb1 = tb1;
		if (tb1) break;
		{
			/* INLINED CODE (ARRAYED_LIST.item) */
			tr1 = (EIF_REFERENCE)  0;
			(void) RTCW(loc1);
			tr2 = *(EIF_REFERENCE *)(loc1);
			tr1 = 
				/* INLINED CODE (SPECIAL.item) */
				*((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_1_0_0_) - ((EIF_INTEGER_32) 1L))))
				/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		tr1 = tr1;
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		{
			/* INLINED CODE (ARRAYED_LIST.count) */
			ti4_1 = (EIF_INTEGER_32)  0;
			(void) RTCW(tr1);
			tr2 = *(EIF_REFERENCE *)(tr1);
			ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr2);
			/* END INLINED CODE */
		}
		loc4 = ti4_1;
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc3 <= arg1) && (EIF_BOOLEAN) (arg1 < (EIF_INTEGER_32) (loc3 + loc4)))) {
			{
				/* INLINED CODE (ARRAYED_LIST.item) */
				tr1 = (EIF_REFERENCE)  0;
				(void) RTCW(loc1);
				tr2 = *(EIF_REFERENCE *)(loc1);
				tr1 = 
					/* INLINED CODE (SPECIAL.item) */
					*((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_1_0_0_) - ((EIF_INTEGER_32) 1L))))
					/* END INLINED CODE */;
				/* END INLINED CODE */
			}
			Result = tr1;
		} else {
			loc3 += loc4;
		}
		{
			/* INLINED CODE (ARRAYED_LIST.forth) */
			(void) RTCW(loc1);
			(*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_1_0_0_))++;
			/* END INLINED CODE */
		}
		;
	}
	{
		/* INLINED CODE (ARRAYED_LIST.go_i_th) */
		(void) RTCW(loc1);
		*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_1_0_0_) = (EIF_INTEGER_32) loc2;
		/* END INLINED CODE */
	}
	;
	RTLE;
	return Result;
}

/* {NAMED_TUPLE_TYPE_AS}.first_token */
EIF_REFERENCE F3684_43603 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	Result = F3681_43553(Current, arg1);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		{
			/* INLINED CODE (LEAF_AS.first_token) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(tr1);
			tr2 = (EIF_REFERENCE) tr1;
			/* END INLINED CODE */
		}
		Result = tr2;
	}
	RTLE;
	return Result;
}

/* {NAMED_TUPLE_TYPE_AS}.last_token */
EIF_REFERENCE F3684_43604 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	{
		/* INLINED CODE (TYPE_AS.last_token) */
		tr1 = (EIF_REFERENCE)  0;
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O31780[Dtype(Current)-3680]) != ((EIF_INTEGER_32) 0L)))) {
			tr1 = F3681_43545(Current, arg1);
		}
		/* END INLINED CODE */
	}
	Result = tr1;
	if ((EIF_BOOLEAN)(Result == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		Result = F3668_43500(RTCW(tr1), arg1);
	}
	RTLE;
	return Result;
}

/* {NAMED_TUPLE_TYPE_AS}.is_equivalent */
EIF_BOOLEAN F3684_43605 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	if (F3615_42842(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_), tr1)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		tb1 = F3615_42842(Current, *(EIF_REFERENCE *)(Current), tr1);
	}
	if (tb1) {
		Result = F3681_43563(Current, arg1);
	}
	RTLE;
	return Result;
}

/* {NAMED_TUPLE_TYPE_AS}.dump */
EIF_REFERENCE F3684_43607 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,loc3);
	RTLR(6,tr4);
	RTLIU(7);
	
	RTGC;
	Result = RTLNS(eif_new_type(2247, 0x00).id, 2247, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = F3771_44603(RTCW(tr1));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	F2246_21883(RTCW(Result), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 4L)));
	F3681_43568(Current, Result);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	{
		/* INLINED CODE (ID_AS.name) */
		tr2 = (EIF_REFERENCE)  0;
		(void) RTCW(tr1);
		tr3 = F2271_22520(tr1);
		tr2 = F1792_17093(RTCW(tr3), *(EIF_INTEGER_32 *)(tr1+ _LNGOFF_0_0_3_4_));
		if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(tr2 != NULL)) {
			RTCT0("from_class_invariant_and_postcondition_of_names_heap_item", EX_CHECK);
				RTCF0;
		}
		/* END INLINED CODE */
	}
	tr1 = tr2;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17139[Dtype(RTCW(Result))-2247])(Result, tr1);
	{
		/* INLINED CODE (NAMED_TUPLE_TYPE_AS.generics) */
		tr1 = (EIF_REFERENCE)  0;
		tr2 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr2));
		/* END INLINED CODE */
	}
	loc3 = tr1;
	{
		/* INLINED CODE (ARRAYED_LIST.start) */
		(void) RTCW(loc3);
		*(EIF_INTEGER_32 *)(loc3+ _LNGOFF_2_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		/* END INLINED CODE */
	}
	;
	tr1 = RTMS_EX_H(" [",2,8283);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17139[Dtype(RTCW(Result))-2247])(Result, tr1);
	for (;;) {
		{
			/* INLINED CODE (LIST.after) */
			tb1 = (EIF_BOOLEAN)  0;
			(void) RTCW(loc3);
			ti4_1 = *(EIF_INTEGER_32 *)(loc3+ _LNGOFF_2_1_0_0_);
			ti4_2 = F1566_14933(loc3);
			tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
			/* END INLINED CODE */
		}
		tb1 = tb1;
		if (tb1) break;
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		{
			/* INLINED CODE (ARRAYED_LIST.item) */
			tr1 = (EIF_REFERENCE)  0;
			(void) RTCW(loc3);
			tr2 = *(EIF_REFERENCE *)(loc3);
			tr1 = 
				/* INLINED CODE (SPECIAL.item) */
				*((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(loc3+ _LNGOFF_2_1_0_0_) - ((EIF_INTEGER_32) 1L))))
				/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		tr1 = tr1;
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		{
			/* INLINED CODE (ARRAYED_LIST.count) */
			ti4_1 = (EIF_INTEGER_32)  0;
			(void) RTCW(tr1);
			tr2 = *(EIF_REFERENCE *)(tr1);
			ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr2);
			/* END INLINED CODE */
		}
		loc2 = ti4_1;
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			{
				/* INLINED CODE (ARRAYED_LIST.item) */
				tr1 = (EIF_REFERENCE)  0;
				(void) RTCW(loc3);
				tr2 = *(EIF_REFERENCE *)(loc3);
				tr1 = 
					/* INLINED CODE (SPECIAL.item) */
					*((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(loc3+ _LNGOFF_2_1_0_0_) - ((EIF_INTEGER_32) 1L))))
					/* END INLINED CODE */;
				/* END INLINED CODE */
			}
			tr1 = tr1;
			{
				/* INLINED CODE (LIST_DEC_AS.item_name) */
				tr2 = (EIF_REFERENCE)  0;
				(void) RTCW(tr1);
				tr3 = F2271_22520(tr1);
				tr4 = *(EIF_REFERENCE *)(tr1);
				ti4_1 = F1567_14918(RTCW(tr4), loc1);
				tr2 = F1792_17093(RTCW(tr3), ti4_1);
				/* END INLINED CODE */
			}
			tr1 = tr2;
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17141[Dtype(RTCW(Result))-2247])(Result, tr1);
			if ((EIF_BOOLEAN) (loc1 < loc2)) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R17143[Dtype(RTCW(Result))-2247])(Result, (EIF_CHARACTER_8) ',');
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R17143[Dtype(RTCW(Result))-2247])(Result, (EIF_CHARACTER_8) ' ');
			}
			loc1++;
		}
		tr1 = RTMS_EX_H(": ",2,14880);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17139[Dtype(RTCW(Result))-2247])(Result, tr1);
		{
			/* INLINED CODE (ARRAYED_LIST.item) */
			tr1 = (EIF_REFERENCE)  0;
			(void) RTCW(loc3);
			tr2 = *(EIF_REFERENCE *)(loc3);
			tr1 = 
				/* INLINED CODE (SPECIAL.item) */
				*((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(loc3+ _LNGOFF_2_1_0_0_) - ((EIF_INTEGER_32) 1L))))
				/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		tr1 = tr1;
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R31805[Dtype(RTCW(tr1))-3681])(tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17139[Dtype(RTCW(Result))-2247])(Result, tr1);
		{
			/* INLINED CODE (CHAIN.islast) */
			tb2 = (EIF_BOOLEAN)  0;
			(void) RTCW(loc3);
			tb2 = '\0';
			tb3 = F1347_14073(loc3);
			if ((EIF_BOOLEAN) !tb3) {
				ti4_1 = *(EIF_INTEGER_32 *)(loc3+ _LNGOFF_2_1_0_0_);
				ti4_2 = F1566_14933(loc3);
				tb2 = (EIF_BOOLEAN)(ti4_1 == ti4_2);
			}
			/* END INLINED CODE */
		}
		tb2 = tb2;
		if ((EIF_BOOLEAN) !tb2) {
			tr1 = RTMS_EX_H("; ",2,15136);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17139[Dtype(RTCW(Result))-2247])(Result, tr1);
		}
		{
			/* INLINED CODE (ARRAYED_LIST.forth) */
			(void) RTCW(loc3);
			(*(EIF_INTEGER_32 *)(loc3+ _LNGOFF_2_1_0_0_))++;
			/* END INLINED CODE */
		}
		;
	}
	tr1 = RTMS_EX_H("]",1,93);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17139[Dtype(RTCW(Result))-2247])(Result, tr1);
	RTLE;
	return Result;
}

/* {NAMED_TUPLE_TYPE_AS}.inline-agent#1 of has_anchor */
EIF_BOOLEAN F3684_46200 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R31799[Dtype(RTCW(tr1))-3681])(tr1);
	RTLE;
	return Result;
}

void EIF_Minit2633 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
