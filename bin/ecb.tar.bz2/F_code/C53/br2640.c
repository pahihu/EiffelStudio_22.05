/*
 * Code for class BREAK_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "br2640.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BREAK_AS}.make */
void F3691_43675 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R17095[Dtype(RTCW(arg1))-2246])(arg1);
	{
		/* INLINED CODE (BREAK_AS.set_internal_text) */
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (LOCATION_AS.make_with_location) */
		F323_4773(Current, arg2, arg3, arg4, arg5, arg6, arg7, arg8);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {BREAK_AS}.process */
void F3691_43677 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7735[Dtype(RTCW(arg1))-674])(arg1, Current);
}

/* {BREAK_AS}.literal_text */
EIF_REFERENCE F3691_43679 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current);
}

/* {BREAK_AS}.has_comment */
EIF_BOOLEAN F3691_43680 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R17093[Dtype(RTCW(tr1))-2246])(tr1, (EIF_CHARACTER_8) '-', ((EIF_INTEGER_32) 1L));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	RTLE;
	return Result;
}

/* {BREAK_AS}.extract_comment */
EIF_REFERENCE F3691_43681 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_8 loc6 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc7 = (EIF_CHARACTER_8) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_8 loc9 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc13 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_16 tu2_1;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLR(3,loc12);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	loc6 = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '-';
	loc7 = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\012';
	{
		/* INLINED CODE (LOCATION_AS.column) */
		ti4_1 = (EIF_INTEGER_32)  0;
		tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_1_0_3_0_);
		tu4_1 = eif_bit_shift_right(tu4_1,((EIF_INTEGER_32) 23L));
		ti4_1 = (EIF_INTEGER_32) tu4_1;
		/* END INLINED CODE */
	}
	ti4_2 = ti4_1;
	loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_2 == ((EIF_INTEGER_32) 1L));
	{
		/* INLINED CODE (LOCATION_AS.line) */
		ti4_1 = (EIF_INTEGER_32)  0;
		tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_1_0_3_0_);
		tu4_1 = eif_bit_and(tu4_1,((EIF_NATURAL_32) 8388607U));
		ti4_1 = (EIF_INTEGER_32) tu4_1;
		/* END INLINED CODE */
	}
	loc1 = ti4_1;
	{
		/* INLINED CODE (LOCATION_AS.column) */
		ti4_1 = (EIF_INTEGER_32)  0;
		tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_1_0_3_0_);
		tu4_1 = eif_bit_shift_right(tu4_1,((EIF_INTEGER_32) 23L));
		ti4_1 = (EIF_INTEGER_32) tu4_1;
		/* END INLINED CODE */
	}
	loc2 = ti4_1;
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	{
		/* INLINED CODE (LOCATION_AS.location_count) */
		ti4_1 = (EIF_INTEGER_32)  0;
		tu2_1 = *(EIF_NATURAL_16 *)(Current+ _I16OFF_1_0_0_);
		ti4_1 = (EIF_INTEGER_32) tu2_1;
		/* END INLINED CODE */
	}
	loc4 = ti4_1;
	loc10 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	Result = RTLNS(eif_new_type(1585, 0x00).id, 1585, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F1586_15000(RTCW(Result));
	loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	for (;;) {
		if ((EIF_BOOLEAN) (loc10 > loc4)) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		loc9 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R12119[Dtype(RTCW(tr1))-1471])(tr1, loc10));
		if (loc8) {
			if ((EIF_BOOLEAN)(loc9 == loc7)) {
				loc13 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc11 + ((EIF_INTEGER_32) 2L)) <= (EIF_INTEGER_32) (loc10 - ((EIF_INTEGER_32) 1L)))) {
					tr1 = *(EIF_REFERENCE *)(Current);
					loc12 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R17033[Dtype(RTCW(tr1))-2246])(tr1, (EIF_INTEGER_32) (loc11 + ((EIF_INTEGER_32) 2L)), (EIF_INTEGER_32) (loc10 - ((EIF_INTEGER_32) 1L)));
					tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R12119[Dtype(RTCW(loc12))-1471])(loc12, ((EIF_INTEGER_32) 1L)));
					if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '|')) {
						loc13 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
					tr1 = RTMS_EX_H("\015",1,13);
					tr2 = RTMS_EX_H("",0,0);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R17128[Dtype(RTCW(loc12))-2247])(loc12, tr1, tr2);
				} else {
					loc12 = RTMS_EX_H("",0,0);
				}
				tr1 = RTLNS(eif_new_type(1770, 0x00).id, 1770, _OBJSIZ_1_2_0_5_0_0_0_0_);
				F1771_16464(RTCW(tr1), loc12, loc1, loc2, (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_3_1_) + loc11) - ((EIF_INTEGER_32) 1L)), loc5, loc13, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_3_3_), loc11);
				F1566_14953(RTCW(Result), tr1);
				loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				loc1++;
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		} else {
			if ((EIF_BOOLEAN)(loc9 == loc6)) {
				loc11 = (EIF_INTEGER_32) loc10;
				loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc10++;
			} else {
				if ((EIF_BOOLEAN)(loc9 == loc7)) {
					loc1++;
					loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					loc2++;
				}
			}
		}
		loc10++;
	}
	RTLE;
	return Result;
}

/* {BREAK_AS}.is_equivalent */
EIF_BOOLEAN F3691_43682 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	{
		/* INLINED CODE (BREAK_AS.literal_text) */
		tr1 = (EIF_REFERENCE)  0;
		tr1 = *(EIF_REFERENCE *)(Current);
		/* END INLINED CODE */
	}
	tr2 = tr1;
	{
		/* INLINED CODE (BREAK_AS.literal_text) */
		tr3 = (EIF_REFERENCE)  0;
		(void) RTCW(arg1);
		tr3 = *(EIF_REFERENCE *)(arg1);
		/* END INLINED CODE */
	}
	tr3 = tr3;
	Result = (EIF_BOOLEAN) RTEQ(tr2, tr3);
	RTLE;
	return Result;
}

/* {BREAK_AS}.set_internal_text */
void F3691_43683 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

void EIF_Minit2640 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
