/*
 * Code for class ONCE_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "on2617.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ONCE_AS}.make */
void F3666_43462 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg3);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	{
		/* INLINED CODE (INTERNAL_AS.initialize) */
		RTAR(Current, arg3);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg3;
		/* END INLINED CODE */
	}
	;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O31853[Dtype(arg1)-3689]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_1_) = (EIF_INTEGER_32) ti4_1;
	}
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg2;
	RTLE;
}

/* {ONCE_AS}.process */
void F3666_43463 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7775[Dtype(RTCW(arg1))-674])(arg1, Current);
}

/* {ONCE_AS}.once_keyword */
EIF_REFERENCE F3666_43465 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F3615_42860(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_1_));
}

/* {ONCE_AS}.index */
EIF_INTEGER_32 F3666_43467 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_1_);
}

/* {ONCE_AS}.is_once */
EIF_BOOLEAN F3666_43468 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {ONCE_AS}.as_once */
EIF_REFERENCE F3666_43469 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) Current;
}

/* {ONCE_AS}.keys */
EIF_REFERENCE F3666_43470 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(loc1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {ONCE_AS}.has_invalid_key */
EIF_BOOLEAN F3666_43471 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	tr1 = F3666_43470(Current);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		{
			/* INLINED CODE (ARRAYED_LIST.start) */
			(void) loc2;
			*(EIF_INTEGER_32 *)(loc2+ _LNGOFF_2_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			/* END INLINED CODE */
		}
		;
		for (;;) {
			tb1 = '\01';
			{
				/* INLINED CODE (LIST.after) */
				tb2 = (EIF_BOOLEAN)  0;
				(void) loc2;
				ti4_1 = *(EIF_INTEGER_32 *)(loc2+ _LNGOFF_2_1_0_0_);
				ti4_2 = F1566_14933(loc2);
				tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
				/* END INLINED CODE */
			}
			tb2 = tb2;
			if (!tb2) {
				tb1 = Result;
			}
			if (tb1) break;
			{
				/* INLINED CODE (ARRAYED_LIST.item) */
				tr1 = (EIF_REFERENCE)  0;
				(void) loc2;
				tr2 = *(EIF_REFERENCE *)(loc2);
				tr1 = 
					/* INLINED CODE (SPECIAL.item) */
					*((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(loc2+ _LNGOFF_2_1_0_0_) - ((EIF_INTEGER_32) 1L))))
					/* END INLINED CODE */;
				/* END INLINED CODE */
			}
			tr1 = tr1;
			loc1 = *(EIF_REFERENCE *)(RTCW(tr1));
			tb2 = '\01';
			tb3 = '\01';
			tr1 = RTOSCF(43482,F3666_43482, (Current));
			tb4 = F2246_21909(RTCW(loc1), tr1);
			if (!tb4) {
				tr1 = RTOSCF(43483,F3666_43483, (Current));
				tb4 = F2246_21909(RTCW(loc1), tr1);
				tb3 = tb4;
			}
			if (!tb3) {
				tr1 = RTOSCF(43484,F3666_43484, (Current));
				tb3 = F2246_21909(RTCW(loc1), tr1);
				tb2 = tb3;
			}
			if (tb2) {
				{
					/* INLINED CODE (ARRAYED_LIST.forth) */
					(void) loc2;
					(*(EIF_INTEGER_32 *)(loc2+ _LNGOFF_2_1_0_0_))++;
					/* END INLINED CODE */
				}
				;
			} else {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		}
	}
	RTLE;
	return Result;
}

/* {ONCE_AS}.invalid_key */
EIF_REFERENCE F3666_43472 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = F3666_43470(Current);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		{
			/* INLINED CODE (ARRAYED_LIST.start) */
			(void) loc2;
			*(EIF_INTEGER_32 *)(loc2+ _LNGOFF_2_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			/* END INLINED CODE */
		}
		;
		for (;;) {
			tb1 = '\01';
			{
				/* INLINED CODE (LIST.after) */
				tb2 = (EIF_BOOLEAN)  0;
				(void) loc2;
				ti4_1 = *(EIF_INTEGER_32 *)(loc2+ _LNGOFF_2_1_0_0_);
				ti4_2 = F1566_14933(loc2);
				tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
				/* END INLINED CODE */
			}
			tb2 = tb2;
			if (!tb2) {
				tb1 = (EIF_BOOLEAN)(Result != NULL);
			}
			if (tb1) break;
			{
				/* INLINED CODE (ARRAYED_LIST.item) */
				tr1 = (EIF_REFERENCE)  0;
				(void) loc2;
				tr2 = *(EIF_REFERENCE *)(loc2);
				tr1 = 
					/* INLINED CODE (SPECIAL.item) */
					*((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(loc2+ _LNGOFF_2_1_0_0_) - ((EIF_INTEGER_32) 1L))))
					/* END INLINED CODE */;
				/* END INLINED CODE */
			}
			tr1 = tr1;
			loc1 = *(EIF_REFERENCE *)(RTCW(tr1));
			tb2 = '\01';
			tb3 = '\01';
			tr1 = RTOSCF(43482,F3666_43482, (Current));
			tb4 = F2246_21909(RTCW(loc1), tr1);
			if (!tb4) {
				tr1 = RTOSCF(43483,F3666_43483, (Current));
				tb4 = F2246_21909(RTCW(loc1), tr1);
				tb3 = tb4;
			}
			if (!tb3) {
				tr1 = RTOSCF(43484,F3666_43484, (Current));
				tb3 = F2246_21909(RTCW(loc1), tr1);
				tb2 = tb3;
			}
			if (tb2) {
				{
					/* INLINED CODE (ARRAYED_LIST.forth) */
					(void) loc2;
					(*(EIF_INTEGER_32 *)(loc2+ _LNGOFF_2_1_0_0_))++;
					/* END INLINED CODE */
				}
				;
			} else {
				{
					/* INLINED CODE (ARRAYED_LIST.item) */
					tr1 = (EIF_REFERENCE)  0;
					(void) loc2;
					tr2 = *(EIF_REFERENCE *)(loc2);
					tr1 = 
						/* INLINED CODE (SPECIAL.item) */
						*((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(loc2+ _LNGOFF_2_1_0_0_) - ((EIF_INTEGER_32) 1L))))
						/* END INLINED CODE */;
					/* END INLINED CODE */
				}
				Result = tr1;
			}
		}
	}
	RTLE;
	return Result;
}

/* {ONCE_AS}.has_key_conflict */
EIF_BOOLEAN F3666_43473 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc5);
	RTLR(4,arg1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	loc4 = F3666_43470(Current);
	loc1 = '\01';
	tr1 = RTOSCF(43482,F3666_43482, (Current));
	if (!F3666_43474(Current, tr1, loc4)) {
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			{
				/* INLINED CODE (INDEXING_CLAUSE_AS.has_global_once) */
				tb2 = (EIF_BOOLEAN)  0;
				(void) loc5;
				tr1 = RTOSCF(43925,F3708_43925, (loc5));
				tr2 = RTOSCF(43932,F3708_43932, (loc5));
				tb2 = F3708_43942(loc5, tr1, tr2);
				/* END INLINED CODE */
			}
			tb2 = tb2;
			tb1 = tb2;
		}
		loc1 = tb1;
	}
	tr1 = RTOSCF(43483,F3666_43483, (Current));
	loc2 = F3666_43474(Current, tr1, loc4);
	tr1 = RTOSCF(43484,F3666_43484, (Current));
	loc3 = F3666_43474(Current, tr1, loc4);
	RTLE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 && loc2) || (EIF_BOOLEAN) (loc1 && loc3)) || (EIF_BOOLEAN) (loc3 && loc2));
}

/* {ONCE_AS}.has_key_inside */
EIF_BOOLEAN F3666_43474 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg2);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		{
			/* INLINED CODE (ARRAYED_LIST.start) */
			(void) RTCW(arg2);
			*(EIF_INTEGER_32 *)(arg2+ _LNGOFF_2_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			/* END INLINED CODE */
		}
		;
		for (;;) {
			tb1 = '\01';
			{
				/* INLINED CODE (LIST.after) */
				tb2 = (EIF_BOOLEAN)  0;
				(void) RTCW(arg2);
				ti4_1 = *(EIF_INTEGER_32 *)(arg2+ _LNGOFF_2_1_0_0_);
				ti4_2 = F1566_14933(arg2);
				tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
				/* END INLINED CODE */
			}
			tb2 = tb2;
			if (!tb2) {
				tb1 = Result;
			}
			if (tb1) break;
			{
				/* INLINED CODE (ARRAYED_LIST.item) */
				tr1 = (EIF_REFERENCE)  0;
				(void) RTCW(arg2);
				tr2 = *(EIF_REFERENCE *)(arg2);
				tr1 = 
					/* INLINED CODE (SPECIAL.item) */
					*((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(arg2+ _LNGOFF_2_1_0_0_) - ((EIF_INTEGER_32) 1L))))
					/* END INLINED CODE */;
				/* END INLINED CODE */
			}
			tr1 = tr1;
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			Result = F2246_21909(RTCW(tr1), arg1);
			{
				/* INLINED CODE (ARRAYED_LIST.forth) */
				(void) RTCW(arg2);
				(*(EIF_INTEGER_32 *)(arg2+ _LNGOFF_2_1_0_0_))++;
				/* END INLINED CODE */
			}
			;
		}
	}
	RTLE;
	return Result;
}

/* {ONCE_AS}.has_key */
EIF_BOOLEAN F3666_43475 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F3666_43470(Current);
	Result = F3666_43474(Current, arg1, tr1);
	RTLE;
	return Result;
}

/* {ONCE_AS}.has_key_process */
EIF_BOOLEAN F3666_43476 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	Result = '\01';
	tr1 = RTOSCF(43482,F3666_43482, (Current));
	{
		/* INLINED CODE (ONCE_AS.has_key) */
		tb1 = (EIF_BOOLEAN)  0;
		tr2 = F3666_43470(Current);
		tb1 = F3666_43474(Current, tr1, tr2);
		/* END INLINED CODE */
	}
	if (!tb1) {
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			{
				/* INLINED CODE (INDEXING_CLAUSE_AS.has_global_once) */
				tb2 = (EIF_BOOLEAN)  0;
				(void) loc1;
				tr1 = RTOSCF(43925,F3708_43925, (loc1));
				tr2 = RTOSCF(43932,F3708_43932, (loc1));
				tb2 = F3708_43942(loc1, tr1, tr2);
				/* END INLINED CODE */
			}
			tb2 = tb2;
			tb1 = tb2;
		}
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {ONCE_AS}.has_key_object */
EIF_BOOLEAN F3666_43478 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(43484,F3666_43484, (Current));
	{
		/* INLINED CODE (ONCE_AS.has_key) */
		tb1 = (EIF_BOOLEAN)  0;
		tr2 = F3666_43470(Current);
		tb1 = F3666_43474(Current, tr1, tr2);
		/* END INLINED CODE */
	}
	Result = tb1;
	RTLE;
	return Result;
}

/* {ONCE_AS}.first_token */
EIF_REFERENCE F3666_43479 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,Result);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		{
			/* INLINED CODE (ONCE_AS.once_keyword) */
			tr1 = (EIF_REFERENCE)  0;
			tr1 = F3615_42860(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_1_));
			/* END INLINED CODE */
		}
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			Result = F3668_43499(loc1, NULL);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current);
			loc2 = tr1;
			if (EIF_TEST(loc2)) {
				Result = F3698_43824(loc2, NULL);
				RTLE;
				return (EIF_REFERENCE) Result;
			}
		}
	}
	RTLE;
	return Result;
}

/* {ONCE_AS}.last_token */
EIF_REFERENCE F3666_43480 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,loc2);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F3698_43825(loc1, arg1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			Result = F3668_43500(loc2, arg1);
		} else {
			if ((EIF_BOOLEAN)(arg1 != NULL)) {
				{
					/* INLINED CODE (ONCE_AS.once_keyword) */
					tr1 = (EIF_REFERENCE)  0;
					tr1 = F3615_42860(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_1_));
					/* END INLINED CODE */
				}
				Result = tr1;
				RTLE;
				return (EIF_REFERENCE) Result;
			}
		}
	}
	RTLE;
	return Result;
}

/* {ONCE_AS}.is_equivalent */
EIF_BOOLEAN F3666_43481 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	{
		/* INLINED CODE (INTERNAL_AS.is_equivalent) */
		tb1 = (EIF_BOOLEAN)  0;
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		tb1 = F3615_42842(Current, *(EIF_REFERENCE *)(Current), tr1);
		/* END INLINED CODE */
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		Result = F3615_42842(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_), tr1);
	}
	RTLE;
	return Result;
}

/* {ONCE_AS}.once_key_process */

EIF_REFERENCE F3666_43482 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (43482,RTMS_EX_H("PROCESS",7,753644115));
}

/* {ONCE_AS}.once_key_thread */

EIF_REFERENCE F3666_43483 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (43483,RTMS_EX_H("THREAD",6,1545974084));
}

/* {ONCE_AS}.once_key_object */

EIF_REFERENCE F3666_43484 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (43484,RTMS_EX_H("OBJECT",6,1401880404));
}

void EIF_Minit2617 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
