/*
 * Code for class GENERIC_CLASS_TYPE_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge2638.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GENERIC_CLASS_TYPE_AS}.initialize */
void F3689_43661 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	{
		/* INLINED CODE (CLASS_TYPE_AS.class_type_initialize) */
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
		/* END INLINED CODE */
	}
	;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg2;
	RTLE;
}

/* {GENERIC_CLASS_TYPE_AS}.has_anchor */
EIF_BOOLEAN F3689_43662 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_REFERENCE tr6 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLR(7,tr6);
	RTLIU(8);
	
	RTGC;
	{
		/* INLINED CODE (GENERIC_CLASS_TYPE_AS.generics) */
		tr1 = (EIF_REFERENCE)  0;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tb1 = F1347_14073(RTCW(tr1));
		if (tb1) {
			tr1 = (EIF_REFERENCE) NULL;
		}
		/* END INLINED CODE */
	}
	tr2 = tr1;
	loc1 = tr2;
	if (EIF_TEST(loc1)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,0,2049,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 1, 1);
		}
		
		{
			static EIF_TYPE_INDEX typarr0[] = {2209,0xFFF9,1,2049,3680,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr4= RTLNRF(typres0.id, (EIF_POINTER) __A2630_97_1, (EIF_POINTER) _A2630_97_1, 0, tr1, 0, 1);
		}
		{
			/* INLINED CODE (ARRAYED_LIST.there_exists) */
			tb1 = (EIF_BOOLEAN)  0;
			(void) loc1;
			tr5 = *(EIF_REFERENCE *)(loc1);
			tr6 = *(EIF_REFERENCE *)(loc1);
			ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr6);
			tb1 = F1929_18488(RTCW(tr5), tr4, ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
			/* END INLINED CODE */
		}
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {GENERIC_CLASS_TYPE_AS}.process */
void F3689_43664 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7882[Dtype(RTCW(arg1))-674])(arg1, Current);
}

/* {GENERIC_CLASS_TYPE_AS}.generics */
EIF_REFERENCE F3689_43665 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	{
		/* INLINED CODE (FINITE.is_empty) */
		tb1 = (EIF_BOOLEAN)  0;
		(void) RTCW(Result);
		ti4_1 = F1566_14933(Result);
		tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
		/* END INLINED CODE */
	}
	tb1 = tb1;
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) NULL;
	}
	RTLE;
	return Result;
}

/* {GENERIC_CLASS_TYPE_AS}.last_token */
EIF_REFERENCE F3689_43667 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_7_0_1_) != ((EIF_INTEGER_32) 0L))) {
			{
				/* INLINED CODE (TYPE_AS.rcurly_symbol) */
				tr1 = (EIF_REFERENCE)  0;
				tr1 = F3615_42861(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_7_0_1_));
				/* END INLINED CODE */
			}
			Result = tr1;
		}
		if ((EIF_BOOLEAN)(Result == NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			{
				/* INLINED CODE (TYPE_LIST_AS.last_token) */
				tr2 = (EIF_REFERENCE)  0;
				(void) RTCW(tr1);
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(tr1+ _LNGOFF_2_1_0_3_) != ((EIF_INTEGER_32) 0L)))) {
					tr2 = F3701_43847(tr1, arg1);
				} else {
					tr2 = F3698_43825(tr1, arg1);
				}
				/* END INLINED CODE */
			}
			Result = tr2;
		}
	}
	if ((EIF_BOOLEAN)(Result == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			/* INLINED CODE (LEAF_AS.last_token) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(tr1);
			tr2 = (EIF_REFERENCE) tr1;
			/* END INLINED CODE */
		}
		Result = tr2;
	}
	RTLE;
	return Result;
}

/* {GENERIC_CLASS_TYPE_AS}.dump */
EIF_REFERENCE F3689_43668 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	Result = F3688_43658(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = F1566_14926(RTCW(tr1));
	tr1 = RTMS_EX_H(" [",2,8283);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17139[Dtype(RTCW(Result))-2247])(Result, tr1);
	for (;;) {
		{
			/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.after) */
			tb1 = (EIF_BOOLEAN)  0;
			(void) loc1;
			ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_0_0_0_);
			ti4_2 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_0_0_1_);
			tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ti4_2);
			/* END INLINED CODE */
		}
		tb1 = tb1;
		if (tb1) break;
		{
			/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.item) */
			tr1 = (EIF_REFERENCE)  0;
			(void) loc1;
			tr2 = *(EIF_REFERENCE *)(loc1);
			tr1 = 
				/* INLINED CODE (SPECIAL.item) */
				*((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_0_0_0_)))
				/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		tr1 = tr1;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R31805[Dtype(RTCW(tr1))-3681])(tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17139[Dtype(RTCW(Result))-2247])(Result, tr1);
		{
			/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.is_last) */
			tb2 = (EIF_BOOLEAN)  0;
			(void) loc1;
			ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_0_0_0_);
			ti4_2 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_0_0_1_);
			tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
			/* END INLINED CODE */
		}
		tb2 = tb2;
		if ((EIF_BOOLEAN) !tb2) {
			tr1 = RTMS_EX_H(", ",2,11296);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17139[Dtype(RTCW(Result))-2247])(Result, tr1);
		}
		{
			/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.forth) */
			(void) loc1;
			(*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_0_0_0_))++;
			/* END INLINED CODE */
		}
		;
	}
	tr1 = RTMS_EX_H("]",1,93);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17139[Dtype(RTCW(Result))-2247])(Result, tr1);
	RTLE;
	return Result;
}

void EIF_Minit2638 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
