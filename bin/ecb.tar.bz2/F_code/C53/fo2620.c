/*
 * Code for class FORMAL_ARGU_DEC_LIST_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "fo2620.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {FORMAL_ARGU_DEC_LIST_AS}.process */
void F3670_43502 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7801[Dtype(RTCW(arg1))-674])(arg1, Current);
}

void EIF_Minit2620 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
