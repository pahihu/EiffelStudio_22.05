
#ifndef _C53_de2646_
#define _C53_de2646_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3697_43810(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F3697_43811(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F3697_43812(EIF_REFERENCE);
extern EIF_INTEGER_32 F3697_43814(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2646(void);
extern char *(*R7773[])();

#ifdef __cplusplus
}
#endif

#endif
