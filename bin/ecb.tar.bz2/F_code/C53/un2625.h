
#ifndef _C53_un2625_
#define _C53_un2625_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3676_43515(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2625(void);
extern char *(*R7808[])();

#ifdef __cplusplus
}
#endif

#endif
