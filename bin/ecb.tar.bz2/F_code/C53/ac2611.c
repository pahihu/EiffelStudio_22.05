/*
 * Code for class ACCESS_ID_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ac2611.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ACCESS_ID_AS}.make_inline_local */
void F3660_43415 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	{
		/* INLINED CODE (ACCESS_FEAT_AS.initialize) */
		F3657_43397(Current, NULL);
		F3632_43118(Current, arg1);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (ACCESS_FEAT_AS.enable_inline_local) */
		tu1_1 = *(EIF_NATURAL_8 *)(Current+ _CHROFF_3_0_);
		tu1_1 = eif_bit_or(tu1_1,((EIF_NATURAL_8) 8U));
		*(EIF_NATURAL_8 *)(Current+ _CHROFF_3_0_) = (EIF_NATURAL_8) tu1_1;
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {ACCESS_ID_AS}.process */
void F3660_43416 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7759[Dtype(RTCW(arg1))-674])(arg1, Current);
}

void EIF_Minit2611 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
