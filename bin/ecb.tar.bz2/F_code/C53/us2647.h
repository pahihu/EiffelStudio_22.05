
#ifndef _C53_us2647_
#define _C53_us2647_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F3699_43828(EIF_REFERENCE);
extern void EIF_Minit2647(void);
extern void F1603_15105(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F1566_14933(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
