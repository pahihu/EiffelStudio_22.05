/*
 * Code for class PRECURSOR_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pr2629.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PRECURSOR_AS}.initialize */
void F3680_43526 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	{
		/* INLINED CODE (ID_LIST.make_id_set) */
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		/* END INLINED CODE */
	}
	;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg3;
	RTLE;
}

/* {PRECURSOR_AS}.process */
void F3680_43527 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7761[Dtype(RTCW(arg1))-674])(arg1, Current);
}

/* {PRECURSOR_AS}.parameters */
EIF_REFERENCE F3680_43530 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		Result = *(EIF_REFERENCE *)(loc1 + _REFACS_1_);
		{
			/* INLINED CODE (ARRAYED_LIST.start) */
			(void) RTCW(Result);
			*(EIF_INTEGER_32 *)(Result+ _LNGOFF_2_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
	return Result;
}

/* {PRECURSOR_AS}.parameter_count */
EIF_INTEGER_32 F3680_43531 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F3680_43530(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		{
			/* INLINED CODE (ARRAYED_LIST.count) */
			ti4_1 = (EIF_INTEGER_32)  0;
			(void) loc1;
			tr1 = *(EIF_REFERENCE *)(loc1);
			ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
			/* END INLINED CODE */
		}
		ti4_1 = ti4_1;
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
	return (EIF_INTEGER_32) 0;
}

/* {PRECURSOR_AS}.access_name */
EIF_REFERENCE F3680_43533 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

/* {PRECURSOR_AS}.index */
EIF_INTEGER_32 F3680_43535 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		{
			/* INLINED CODE (PARAN_LIST_AS.index) */
			ti4_1 = (EIF_INTEGER_32)  0;
			(void) loc1;
			ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_2_0_0_2_);
			/* END INLINED CODE */
		}
		ti4_1 = ti4_1;
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			ti4_1 = *(EIF_INTEGER_32 *)(loc2 + O31853[Dtype(loc2)-3689]);
			RTLE;
			return (EIF_INTEGER_32) ti4_1;
		}
	}
	RTLE;
	return (EIF_INTEGER_32) 0;
}

/* {PRECURSOR_AS}.first_token */
EIF_REFERENCE F3680_43536 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	{
		/* INLINED CODE (LEAF_AS.first_token) */
		tr2 = (EIF_REFERENCE)  0;
		(void) RTCW(tr1);
		tr2 = (EIF_REFERENCE) tr1;
		/* END INLINED CODE */
	}
	Result = tr2;
	RTLE;
	return Result;
}

/* {PRECURSOR_AS}.last_token */
EIF_REFERENCE F3680_43537 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,tr2);
	RTLR(6,Result);
	RTLR(7,loc3);
	RTLR(8,loc4);
	RTLIU(9);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		tr1 = F3680_43530(Current);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R31332[Dtype(loc1)-3615])(loc1, arg1);
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			loc2 = tr1;
			if (EIF_TEST(loc2)) {
				tr1 = F3688_43655(loc2, arg1);
				RTLE;
				return (EIF_REFERENCE) tr1;
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				{
					/* INLINED CODE (LEAF_AS.last_token) */
					tr2 = (EIF_REFERENCE)  0;
					(void) RTCW(tr1);
					tr2 = (EIF_REFERENCE) tr1;
					/* END INLINED CODE */
				}
				Result = tr2;
			}
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			Result = F3668_43500(loc3, arg1);
			RTLE;
			return (EIF_REFERENCE) Result;
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			loc4 = tr1;
			if (EIF_TEST(loc4)) {
				Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R31332[Dtype(loc4)-3615])(loc4, arg1);
				RTLE;
				return (EIF_REFERENCE) Result;
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				{
					/* INLINED CODE (LEAF_AS.last_token) */
					tr2 = (EIF_REFERENCE)  0;
					(void) RTCW(tr1);
					tr2 = (EIF_REFERENCE) tr1;
					/* END INLINED CODE */
				}
				Result = tr2;
			}
		}
	}
	RTLE;
	return Result;
}

/* {PRECURSOR_AS}.is_equivalent */
EIF_BOOLEAN F3680_43538 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	if (F3615_42842(Current, *(EIF_REFERENCE *)(Current + _REFACS_2_), tr1)) {
		tr1 = F3680_43530(Current);
		tr2 = F3680_43530(RTCW(arg1));
		Result = F3615_42842(Current, tr1, tr2);
	}
	RTLE;
	return Result;
}

void EIF_Minit2629 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
