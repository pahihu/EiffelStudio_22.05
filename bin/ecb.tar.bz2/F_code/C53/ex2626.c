/*
 * Code for class EXPORT_CLAUSE_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ex2626.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EXPORT_CLAUSE_AS}.process */
void F3677_43516 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7807[Dtype(RTCW(arg1))-674])(arg1, Current);
}

void EIF_Minit2626 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
