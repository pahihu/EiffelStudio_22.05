/*
 * Code for class ATTRIBUTE_AS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "at2616.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ATTRIBUTE_AS}.make */
void F3665_43454 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	{
		/* INLINED CODE (INTERNAL_AS.initialize) */
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
		/* END INLINED CODE */
	}
	;
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2) + O31853[Dtype(arg2)-3689]);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_1_) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

/* {ATTRIBUTE_AS}.is_attribute */
EIF_BOOLEAN F3665_43455 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {ATTRIBUTE_AS}.process */
void F3665_43456 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7772[Dtype(RTCW(arg1))-674])(arg1, Current);
}

/* {ATTRIBUTE_AS}.attribute_keyword */
EIF_REFERENCE F3665_43458 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F3615_42860(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_1_));
}

/* {ATTRIBUTE_AS}.index */
EIF_INTEGER_32 F3665_43459 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_1_);
}

/* {ATTRIBUTE_AS}.first_token */
EIF_REFERENCE F3665_43460 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			tr1 = F3698_43824(loc1, arg1);
			RTLE;
			return (EIF_REFERENCE) tr1;
		}
	} else {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_1_) != ((EIF_INTEGER_32) 0L))) {
			{
				/* INLINED CODE (ATTRIBUTE_AS.attribute_keyword) */
				tr1 = (EIF_REFERENCE)  0;
				tr1 = F3615_42860(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_1_));
				/* END INLINED CODE */
			}
			RTLE;
			return (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {ATTRIBUTE_AS}.last_token */
EIF_REFERENCE F3665_43461 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F3698_43825(loc1, arg1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		if ((EIF_BOOLEAN)(arg1 == NULL)) {
			Result = (EIF_REFERENCE) NULL;
		} else {
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_1_) != ((EIF_INTEGER_32) 0L))) {
				{
					/* INLINED CODE (ATTRIBUTE_AS.attribute_keyword) */
					tr1 = (EIF_REFERENCE)  0;
					tr1 = F3615_42860(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_1_));
					/* END INLINED CODE */
				}
				Result = tr1;
				RTLE;
				return (EIF_REFERENCE) Result;
			}
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit2616 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
