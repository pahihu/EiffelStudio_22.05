/*
 * Code for class IDENTIFIER_LIST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "id832.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IDENTIFIER_LIST}.separator_list_i_th */
EIF_REFERENCE F1598_15087 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		{
			/* INLINED CODE (ARRAYED_LIST.i_th) */
			ti4_1 = (EIF_INTEGER_32)  0;
			(void) loc3;
			tr1 = *(EIF_REFERENCE *)(loc3);
			ti4_1 = 
				/* INLINED CODE (SPECIAL.item) */
				*((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L))))
				/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		loc1 = ti4_1;
		{
			/* INLINED CODE (LEAF_AS_LIST.valid_index) */
			tb1 = (EIF_BOOLEAN)  0;
			(void) RTCW(arg2);
			ti4_1 = *(EIF_INTEGER_32 *)(arg2+ _LNGOFF_7_1_0_1_);
			tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) (((EIF_INTEGER_32) 1L) <= loc1) && (EIF_BOOLEAN) (loc1 <= ti4_1));
			/* END INLINED CODE */
		}
		tb1 = tb1;
		if (tb1) {
			tr1 = F2492_26087(RTCW(arg2), loc1);
			RTLE;
			return (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {IDENTIFIER_LIST}.reverse_extend_separator */
void F1598_15088 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O31853[Dtype(arg1)-3689]);
		{
			/* INLINED CODE (CONSTRUCT_LIST.reverse_extend) */
			ti4_2 = (EIF_INTEGER_32)  0;
			tr1 = (EIF_REFERENCE)  0;
			(void) RTCW(loc1);
			ti4_2 = *(EIF_INTEGER_32 *)(loc1 + O12378[Dtype(loc1)-1595]);
			ti4_2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_2 - ((EIF_INTEGER_32) 1L));
			*(EIF_INTEGER_32 *)(loc1 + O12378[Dtype(loc1)-1595]) = (EIF_INTEGER_32) ti4_2;
			tr2 = F1567_14916(loc1);
			/* INLINED CODE (SPECIAL.put) */
			*((EIF_INTEGER_32 *)RTCW(tr2) + (ti4_2)) = ti4_1;
			/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1596,2055,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNSMART(typres0.id);
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O31853[Dtype(arg1)-3689]);
		ti4_2 = F1567_14934(Current);
		F1597_15081(RTCW(loc1), ti4_1, (EIF_INTEGER_32) (ti4_2 - ((EIF_INTEGER_32) 1L)));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
	}
	RTLE;
}

/* {IDENTIFIER_LIST}.reverse_extend_identifier */
void F1598_15089 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_3_3_);
		{
			/* INLINED CODE (CONSTRUCT_LIST.reverse_extend) */
			ti4_2 = (EIF_INTEGER_32)  0;
			tr1 = (EIF_REFERENCE)  0;
			(void) RTCW(loc1);
			ti4_2 = *(EIF_INTEGER_32 *)(loc1 + O12378[Dtype(loc1)-1595]);
			ti4_2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_2 - ((EIF_INTEGER_32) 1L));
			*(EIF_INTEGER_32 *)(loc1 + O12378[Dtype(loc1)-1595]) = (EIF_INTEGER_32) ti4_2;
			tr2 = F1567_14916(loc1);
			/* INLINED CODE (SPECIAL.put) */
			*((EIF_INTEGER_32 *)RTCW(tr2) + (ti4_2)) = ti4_1;
			/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1596,2055,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNSMART(typres0.id);
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_3_3_);
		ti4_2 = F1567_14934(Current);
		F1597_15081(RTCW(loc1), ti4_1, ti4_2);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc1;
	}
	RTLE;
}

void EIF_Minit832 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
