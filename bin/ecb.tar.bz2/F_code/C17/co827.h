
#ifndef _C17_co827_
#define _C17_co827_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1581_14978(EIF_REFERENCE, EIF_REFERENCE);
extern void F1581_14979(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1581_14980(EIF_REFERENCE, EIF_REFERENCE);
extern void F1581_14981(EIF_REFERENCE, EIF_REFERENCE);
extern void F1581_14982(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit827(void);
extern void F1566_14912(EIF_REFERENCE, EIF_INTEGER_32);
extern void F2243_21753(EIF_REFERENCE);
extern void F1626_15199(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F2243_21813(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
