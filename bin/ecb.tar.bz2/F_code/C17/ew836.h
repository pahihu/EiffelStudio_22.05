
#ifndef _C17_ew836_
#define _C17_ew836_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1625_15195(EIF_REFERENCE);
extern EIF_BOOLEAN F1625_15196(EIF_REFERENCE);
extern void F1625_15197(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F1625_15198(EIF_REFERENCE);
extern void EIF_Minit836(void);
extern void F821_11759(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1602_15131(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
