/*
 * Code for class SED_OBJECTS_TABLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "se837.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F1639_15315
static EIF_INTEGER_32 inline_F1639_15315 (EIF_POINTER arg1)
{
	return (EIF_INTEGER_32) (0x7FFFFFF & (((rt_uint_ptr) arg1) / sizeof(rt_uint_ptr)));
	;
}
#define INLINE_F1639_15315
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SED_OBJECTS_TABLE}.make */
void F1639_15311 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = (EIF_INTEGER_32) arg1;
	F1635_15199(Current, ti4_1);
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_4_3_0_0_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	RTLE;
}

/* {SED_OBJECTS_TABLE}.index */
EIF_NATURAL_32 F1639_15312 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_POINTER loc10 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_BOOLEAN tb1;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,loc8);
	RTLR(2,Current);
	RTLR(3,loc9);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	loc10 = (EIF_POINTER) arg1;
	loc8 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc9 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc6 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_3_);
	loc7 = (EIF_INTEGER_32) loc6;
	{
		/* INLINED CODE (SED_OBJECTS_TABLE.hash_code_of) */
		ti4_1 = (EIF_INTEGER_32)  0;
		ti4_1 = inline_F1639_15315(loc10);
		/* END INLINED CODE */
	}
	loc1 = ti4_1;
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 1L) + (EIF_INTEGER_32) (loc1 % (EIF_INTEGER_32) (loc6 - ((EIF_INTEGER_32) 1L))));
	loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 % loc6) - loc2);
	for (;;) {
		if ((EIF_BOOLEAN)(loc7 == ((EIF_INTEGER_32) 0L))) break;
		loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc5 + loc2) % loc6);
		/* INLINED CODE (SPECIAL.item) */
		ti4_2 = *((EIF_INTEGER_32 *)RTCW(loc9) + (loc5));
		/* END INLINED CODE */
		loc3 = ti4_2;
		tb1 = '\0';
		if ((EIF_BOOLEAN) (loc3 >= ((EIF_INTEGER_32) 0L))) {
			/* INLINED CODE (SPECIAL.item) */
			tp2 = *((EIF_POINTER *)RTCW(loc8) + (loc3));
			/* END INLINED CODE */
			tp1 = tp2;
			tb1 = (EIF_BOOLEAN)(tp1 == loc10);
		}
		if (tb1) {
			loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			tr1 = *(EIF_REFERENCE *)(Current);
			/* INLINED CODE (SPECIAL.item) */
			tu4_2 = *((EIF_NATURAL_32 *)RTCW(tr1) + (loc3));
			/* END INLINED CODE */
			Result = tu4_2;
		} else {
			if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) -1L))) {
				loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				Result = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_4_3_0_0_);
				Result = (EIF_NATURAL_32) (EIF_NATURAL_32) (Result + (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L));
				*(EIF_NATURAL_32 *)(Current+ _LNGOFF_4_3_0_0_) = (EIF_NATURAL_32) Result;
				loc4 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc8);
				ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_capacity__i4 (loc8);
				if ((EIF_BOOLEAN) (loc4 < ti4_1)) {
					/* INLINED CODE (SPECIAL.put) */
					*((EIF_INTEGER_32 *)RTCW(loc9) + (loc5)) = loc4;
					/* END INLINED CODE */
					;
					tr1 = *(EIF_REFERENCE *)(Current);
					{
						/* INLINED CODE (SPECIAL.force) */
						(void) RTCW(tr1);
						ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
						if ((EIF_BOOLEAN) (loc4 < ti4_1)) {
							/* INLINED CODE (SPECIAL.put) */
							*((EIF_NATURAL_32 *)tr1 + (loc4)) = Result;
							/* END INLINED CODE */;
						} else {
							F1935_18466(tr1, Result);
						}
						/* END INLINED CODE */
					}
					;
					{
						/* INLINED CODE (SPECIAL.force) */
						tp1 = arg1;
						(void) RTCW(loc8);
						ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc8);
						if ((EIF_BOOLEAN) (loc4 < ti4_1)) {
							/* INLINED CODE (SPECIAL.put) */
							*((EIF_POINTER *)loc8 + (loc4)) = tp1;
							/* END INLINED CODE */;
						} else {
							F1934_18466(loc8, tp1);
						}
						/* END INLINED CODE */
					}
					;
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_9_))++;
				} else {
					F1635_15245(Current, Result, loc10);
				}
			}
		}
		loc7--;
	}
	RTLE;
	return Result;
}

/* {SED_OBJECTS_TABLE}.wipe_out */
void F1639_15313 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_4_3_0_0_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	F1635_15253(Current);
	RTLE;
}

/* {SED_OBJECTS_TABLE}.hash_code_of */
EIF_INTEGER_32 F1639_15314 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	return (EIF_INTEGER_32) inline_F1639_15315(arg1);
}

/* {SED_OBJECTS_TABLE}.c_hash_code_of */
EIF_INTEGER_32 F1639_15315 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F1639_15315 ((EIF_POINTER) arg1);
	return Result;
}

void EIF_Minit837 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
