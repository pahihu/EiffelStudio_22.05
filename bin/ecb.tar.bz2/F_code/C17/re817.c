/*
 * Code for class REMOVED_FEAT_LOG_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "re817.h"
#include "eif_file.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {REMOVED_FEAT_LOG_FILE}.add_removed_class_type */
void F1440_14513 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("(removed)",9,1735042345);
	F1440_14515(Current, arg1, tr1);
	RTLE;
}

/* {REMOVED_FEAT_LOG_FILE}.add_empty_class_type */
void F1440_14514 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("(empty)",7,743953705);
	F1440_14515(Current, arg1, tr1);
	RTLE;
}

/* {REMOVED_FEAT_LOG_FILE}.add */
void F1440_14515 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	struct eif_ex_131 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(163, 0x00).id);
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,Current);
	RTLR(6,arg2);
	RTLIU(7);
	
	RTGC;
	{
		/* INLINED CODE (CLASS_TYPE.associated_class) */
		tr1 = (EIF_REFERENCE)  0;
		(void) RTCW(arg1);
		tr2 = RTOSCF(8191,F604_8191, (arg1));
		tr3 = *(EIF_REFERENCE *)(arg1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr3) + O21852[Dtype(tr3)-2620]);
		tr1 = F2493_26230(RTCW(tr2), ti4_1);
		/* END INLINED CODE */
	}
	tr1 = tr1;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R20610[Dtype(RTCW(tr1))-2525])(tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O16106[Dtype(tr1)-2089]);
	{
		/* INLINED CODE (UTF_CONVERTER.utf_32_string_to_utf_8_string_8) */
		tr2 = (EIF_REFERENCE)  0;
		(void) RTCW(loc1);
		tr2 = RTLNS(eif_new_type(2247, 0x00).id, 2247, _OBJSIZ_1_1_0_3_0_0_0_0_);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R16992[Dtype(RTCW(tr1))-2246])(tr1);
		F2246_21883(RTCW(tr2), ti4_1);
		F164_2780(loc1, tr1, tr2);
		/* END INLINED CODE */
	}
	tr1 = tr2;
	{
		/* INLINED CODE (FILE.put_string) */
		ti4_1 = (EIF_INTEGER_32)  0;
		tr2 = (EIF_REFERENCE)  0;
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O17115[Dtype(tr1)-2245]);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr2 = *(EIF_REFERENCE *)(RTCW(tr1));
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_5_7_2_4_1_0_);
			eif_file_ps((FILE*) tp1, (char*) tr2, (EIF_INTEGER) ti4_1);
		}
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (FILE.put_character) */
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_5_7_2_4_1_0_);
		eif_file_pc((FILE*) tp1, (EIF_CHARACTER) (EIF_CHARACTER_8) '\011');
		/* END INLINED CODE */
	}
	;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R21743[Dtype(RTCW(tr1))-2613])(tr1);
	{
		/* INLINED CODE (FILE.put_string) */
		ti4_1 = (EIF_INTEGER_32)  0;
		tr2 = (EIF_REFERENCE)  0;
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O17115[Dtype(tr1)-2245]);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr2 = *(EIF_REFERENCE *)(RTCW(tr1));
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_5_7_2_4_1_0_);
			eif_file_ps((FILE*) tp1, (char*) tr2, (EIF_INTEGER) ti4_1);
		}
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (FILE.put_character) */
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_5_7_2_4_1_0_);
		eif_file_pc((FILE*) tp1, (EIF_CHARACTER) (EIF_CHARACTER_8) '\011');
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (FILE.put_string) */
		tr2 = arg2;
		ti4_1 = (EIF_INTEGER_32)  0;
		tr1 = (EIF_REFERENCE)  0;
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2) + O17115[Dtype(tr2)-2245]);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(RTCW(tr2));
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_5_7_2_4_1_0_);
			eif_file_ps((FILE*) tp1, (char*) tr1, (EIF_INTEGER) ti4_1);
		}
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (FILE.put_new_line) */
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_5_7_2_4_1_0_);
		eif_file_tnwl((FILE*) tp1);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

void EIF_Minit817 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
