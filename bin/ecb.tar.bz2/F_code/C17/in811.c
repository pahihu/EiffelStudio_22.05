/*
 * Code for class INI_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "in811.h"
#include "eif_built_in.h"
#include "eif_file.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {INI_FILE}.make_empty */
void F1138_13725 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {1643,2249,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1644_15344(RTCW(tr1), ((EIF_INTEGER_32) 3L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {INI_FILE}.make_with_path */
void F1138_13726 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	{
		/* INLINED CODE (INI_FILE.make_empty) */
		{
			static EIF_TYPE_INDEX typarr0[] = {1643,2249,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr1 = RTLNSMART(typres0.id);
		}
		F1644_15344(RTCW(tr1), ((EIF_INTEGER_32) 3L));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		/* END INLINED CODE */
	}
	;
	F1138_13737(Current, arg1);
	RTLE;
}

/* {INI_FILE}.item */
EIF_REFERENCE F1138_13728 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F1626_15205(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {INI_FILE}.adjusted_item */
EIF_REFERENCE F1138_13729 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = F1626_15205(RTCW(tr1), arg1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		Result = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F2250_22051(RTCW(Result), loc1);
		F2252_22148(RTCW(Result));
		F2252_22149(RTCW(Result));
	}
	RTLE;
	return Result;
}

/* {INI_FILE}.new_cursor */
EIF_REFERENCE F1138_13731 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F1626_15214(RTCW(tr1));
	RTLE;
	return Result;
}

/* {INI_FILE}.import */
void F1138_13737 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	struct eif_ex_131 sloc8;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) sloc8.data;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	memset (&sloc8.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc8.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc8.overhead, eif_new_type(163, 0x00).id);
	RTLI(12);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,loc3);
	RTLR(4,loc9);
	RTLR(5,Current);
	RTLR(6,tr1);
	RTLR(7,loc10);
	RTLR(8,loc7);
	RTLR(9,loc8);
	RTLR(10,tr2);
	RTLR(11,loc6);
	RTLIU(12);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1438, 0x00).id, 1438, _OBJSIZ_5_7_2_4_1_1_2_1_);
	F1439_14450(RTCW(loc1), arg1);
	tb1 = '\0';
	tb2 = '\0';
	tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11190[Dtype(RTCW(loc1))-921])(loc1);
	if (tb3) {
		{
			/* INLINED CODE (FILE.is_directory) */
			tb3 = (EIF_BOOLEAN)  0;
			(void) RTCW(loc1);
			F1437_14339(loc1);
			tb3 = F836_11792(RTCV(RTOSCF(14337,F1437_14337, (loc1))));
			/* END INLINED CODE */
		}
		tb3 = tb3;
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		{
			/* INLINED CODE (FILE.is_access_readable) */
			tb2 = (EIF_BOOLEAN)  0;
			(void) RTCW(loc1);
			F1437_14339(loc1);
			tb2 = F836_11806(RTCV(RTOSCF(14337,F1437_14337, (loc1))));
			/* END INLINED CODE */
		}
		tb2 = tb2;
		tb1 = tb2;
	}
	if (tb1) {
		{
			/* INLINED CODE (FILE.open_read) */
			(void) RTCW(loc1);
			tp1 = *(EIF_POINTER *)(RTCV(F1437_14329(loc1))+ _PTROFF_0_1_0_1_0_0_);
			tp1 = (EIF_POINTER) eif_file_open((EIF_FILENAME) tp1, (int) ((EIF_INTEGER_32) 0L));
			*(EIF_POINTER *)(loc1 + O11932[Dtype(loc1)-1436]) = (EIF_POINTER) tp1;
			*(EIF_INTEGER_32 *)(loc1 + O12071[Dtype(loc1)-1436]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			/* END INLINED CODE */
		}
		;
		for (;;) {
			{
				/* INLINED CODE (LINEAR.exhausted) */
				tb1 = (EIF_BOOLEAN)  0;
				(void) RTCW(loc1);
				tb1 = F1437_14201(loc1);
				/* END INLINED CODE */
			}
			tb1 = tb1;
			if (tb1) break;
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R11249[Dtype(RTCW(loc1))-1437])(loc1);
			loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R17073[Dtype(RTCW(loc2))-2247])(loc2);
			{
				/* INLINED CODE (FINITE.is_empty) */
				tb2 = (EIF_BOOLEAN)  0;
				(void) RTCW(loc2);
				ti4_1 = *(EIF_INTEGER_32 *)(loc2+ _LNGOFF_1_1_0_2_);
				tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
				/* END INLINED CODE */
			}
			tb2 = tb2;
			if (tb2) {
			} else {
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R12119[Dtype(RTCW(loc2))-1471])(loc2, ((EIF_INTEGER_32) 1L)));
				if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '#')) {
				} else {
					tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R12119[Dtype(RTCW(loc2))-1471])(loc2, ((EIF_INTEGER_32) 1L)));
					if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '+')) {
						if ((EIF_BOOLEAN)(loc3 != NULL)) {
							tr1 = *(EIF_REFERENCE *)(Current);
							tr1 = F1626_15205(RTCW(tr1), loc3);
							loc9 = tr1;
							if (EIF_TEST(loc9)) {
								loc10 = loc9;
								loc10 = RTRV(eif_new_type(2251, 0x00),loc10);
								if (EIF_TEST(loc10)) {
									loc7 = (EIF_REFERENCE) loc10;
								} else {
									loc7 = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
									F2250_22051(RTCW(loc7), loc9);
								}
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
								F2252_22177(RTCW(loc7), tw1);
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
								if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L))) {
									ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
									tr1 = F2243_21835(RTCW(loc2), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
									{
										/* INLINED CODE (UTF_CONVERTER.utf_8_string_8_to_string_32) */
										tr2 = (EIF_REFERENCE)  0;
										(void) RTCW(loc8);
										tr2 = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
										ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O17115[Dtype(tr1)-2245]);
										F2250_22049(RTCW(tr2), ti4_1);
										F164_2794(loc8, tr1, tr2);
										/* END INLINED CODE */
									}
									tr1 = tr2;
									F2252_22164(RTCW(loc7), tr1);
								}
								tr1 = *(EIF_REFERENCE *)(Current);
								F1626_15246(RTCW(tr1), loc7, loc3);
							}
						} else {
							*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						}
					} else {
						loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R17093[Dtype(RTCW(loc2))-2246])(loc2, (EIF_CHARACTER_8) ':', ((EIF_INTEGER_32) 1L));
						loc5 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R17093[Dtype(RTCW(loc2))-2246])(loc2, (EIF_CHARACTER_8) '=', ((EIF_INTEGER_32) 1L));
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L)) || (EIF_BOOLEAN) ((EIF_BOOLEAN) (((EIF_INTEGER_32) 0L) < loc5) && (EIF_BOOLEAN) (loc5 < loc4)))) {
							loc4 = (EIF_INTEGER_32) loc5;
						}
						if ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 0L))) {
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
							loc6 = F2243_21835(RTCW(loc2), (EIF_INTEGER_32) (ti4_1 - loc4));
							{
								/* INLINED CODE (READABLE_STRING_GENERAL.head) */
								ti4_1 = (EIF_INTEGER_32) (loc4 - ((EIF_INTEGER_32) 1L));
								tr1 = (EIF_REFERENCE)  0;
								(void) RTCW(loc2);
								ti4_2 = *(EIF_INTEGER_32 *)(loc2+ _LNGOFF_1_1_0_2_);
								if ((EIF_BOOLEAN) (ti4_1 > ti4_2)) {
									tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc2);
								} else {
									tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R17033[Dtype(loc2)-2246])(loc2, ((EIF_INTEGER_32) 1L), ti4_1);
								}
								/* END INLINED CODE */
							}
							tr1 = tr1;
							loc2 = (EIF_REFERENCE) tr1;
							{
								/* INLINED CODE (UTF_CONVERTER.utf_8_string_8_to_string_32) */
								tr1 = (EIF_REFERENCE)  0;
								(void) RTCW(loc8);
								tr1 = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2) + O17115[Dtype(loc2)-2245]);
								F2250_22049(RTCW(tr1), ti4_1);
								F164_2794(loc8, loc2, tr1);
								/* END INLINED CODE */
							}
							loc3 = tr1;
							tr1 = *(EIF_REFERENCE *)(Current);
							{
								/* INLINED CODE (UTF_CONVERTER.utf_8_string_8_to_string_32) */
								tr2 = (EIF_REFERENCE)  0;
								(void) RTCW(loc8);
								tr2 = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6) + O17115[Dtype(loc6)-2245]);
								F2250_22049(RTCW(tr2), ti4_1);
								F164_2794(loc8, loc6, tr2);
								/* END INLINED CODE */
							}
							tr2 = tr2;
							F1626_15246(RTCW(tr1), tr2, loc3);
						} else {
							*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						}
					}
				}
			}
		}
		{
			/* INLINED CODE (FILE.close) */
			(void) RTCW(loc1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER)) R12014[Dtype(loc1)-1437])(loc1, *(EIF_POINTER *)(loc1 + O11932[Dtype(loc1)-1436]));
			*(EIF_INTEGER_32 *)(loc1 + O12071[Dtype(loc1)-1436]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			tp1 = F1_33(loc1);
			*(EIF_POINTER *)(loc1 + O11932[Dtype(loc1)-1436]) = (EIF_POINTER) tp1;
			*(EIF_BOOLEAN *)(loc1 + O12080[Dtype(loc1)-1436]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			/* END INLINED CODE */
		}
		;
	} else {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTLE;
}

void EIF_Minit811 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
