
#ifndef _C17_us818_
#define _C17_us818_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1441_14516(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit818(void);
extern EIF_REFERENCE F2493_26230(EIF_REFERENCE, EIF_INTEGER_32);
extern void F2246_21883(EIF_REFERENCE, EIF_INTEGER_32);
extern void F164_2780(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F604_8191(EIF_REFERENCE);
extern EIF_REFERENCE F2531_27443(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,8191)
extern char *(*R16992[])();
extern char *(*R21743[])();
extern char *(*R20610[])();
extern long O17115[];
extern long O16106[];
extern long O21852[];

#ifdef __cplusplus
}
#endif

#endif
