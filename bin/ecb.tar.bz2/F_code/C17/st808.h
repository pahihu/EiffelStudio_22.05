
#ifndef _C17_st808_
#define _C17_st808_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1077_13681(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F1077_13682(EIF_REFERENCE);
extern EIF_REFERENCE F1077_13683(EIF_REFERENCE);
extern EIF_REFERENCE F1077_13685(EIF_REFERENCE);
extern EIF_INTEGER_32 F1077_13686(EIF_REFERENCE);
extern void EIF_Minit808(void);
extern char *(*R17113[])();
extern long O17115[];

#ifdef __cplusplus
}
#endif

#endif
