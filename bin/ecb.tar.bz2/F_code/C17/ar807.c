/*
 * Code for class ARGUMENTS_32
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ar807.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ARGUMENTS_32}.argument */
EIF_REFERENCE F996_13578 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tr1 = RTOSCF(13596,F996_13596, (Current));
	{
		/* INLINED CODE (ARRAY.item) */
		tr2 = (EIF_REFERENCE)  0;
		(void) RTCW(tr1);
		tr3 = *(EIF_REFERENCE *)(tr1);
		tr2 = 
			/* INLINED CODE (SPECIAL.item) */
			*((EIF_REFERENCE *)RTCW(tr3) + ((EIF_INTEGER_32) (arg1 - *(EIF_INTEGER_32 *)(tr1 + O12431[Dtype(tr1)-1601]))))
			/* END INLINED CODE */;
		/* END INLINED CODE */
	}
	Result = tr2;
	RTLE;
	return Result;
}

/* {ARGUMENTS_32}.command_name */
static EIF_REFERENCE F996_13581_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (13581);
#define Result RTOSR(13581)
	RTOC_NEW(Result);
	{
		/* INLINED CODE (ARGUMENTS_32.argument) */
		tr1 = (EIF_REFERENCE)  0;
		tr2 = RTOSCF(13596,F996_13596, (Current));
		tr1 = F1602_15110(RTCW(tr2), ((EIF_INTEGER_32) 0L));
		/* END INLINED CODE */
	}
	Result = tr1;
	RTOSE (13581);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F996_13581 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(13581,F996_13581_body,(Current));
}

/* {ARGUMENTS_32}.new_cursor */
EIF_REFERENCE F996_13582 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = F1602_15114(RTCV(RTOSCF(13596,F996_13596, (Current))));
	RTLE;
	return Result;
}

/* {ARGUMENTS_32}.index_of_word_option */
EIF_INTEGER_32 F996_13583 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (loc1 > (EIF_INTEGER_32) eif_builtin_ARGUMENTS_32_argument_count__i4)) {
			tr1 = RTOSCF(13596,F996_13596, (Current));
			{
				/* INLINED CODE (ARRAY.item) */
				tr2 = (EIF_REFERENCE)  0;
				(void) RTCW(tr1);
				tr3 = *(EIF_REFERENCE *)(tr1);
				tr2 = 
					/* INLINED CODE (SPECIAL.item) */
					*((EIF_REFERENCE *)RTCW(tr3) + ((EIF_INTEGER_32) (loc1 - *(EIF_INTEGER_32 *)(tr1 + O12431[Dtype(tr1)-1601]))))
					/* END INLINED CODE */;
				/* END INLINED CODE */
			}
			tr1 = tr2;
			tb1 = F996_13593(Current, tr1, arg1);
		}
		if (tb1) break;
		loc1++;
	}
	if ((EIF_BOOLEAN) (loc1 <= (EIF_INTEGER_32) eif_builtin_ARGUMENTS_32_argument_count__i4)) {
		RTLE;
		return (EIF_INTEGER_32) loc1;
	}
	RTLE;
	return (EIF_INTEGER_32) 0;
}

/* {ARGUMENTS_32}.option_sign */
static EIF_REFERENCE F996_13590_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (13590);
#define Result RTOSR(13590)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {558,2082,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 558, _OBJSIZ_0_0_0_1_0_0_0_0_);
	}
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
	F559_7469(RTCW(tr1), tw1);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (13590);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F996_13590 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(13590,F996_13590_body,(Current));
}

/* {ARGUMENTS_32}.argument_count */
EIF_INTEGER_32 F996_13592 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) eif_builtin_ARGUMENTS_32_argument_count__i4;
	return Result;
}

/* {ARGUMENTS_32}.option_word_equal */
EIF_BOOLEAN F996_13593 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(13590,F996_13590, (Current));
	tw1 = *(EIF_CHARACTER_32 *)(RTCW(tr1) + O6989[Dtype(tr1)-553]);
	tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(tw1 == tw2)) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R16998[Dtype(RTCW(arg1))-2246])(arg1, arg2);
		RTLE;
		return (EIF_BOOLEAN) tb1;
	} else {
		tb1 = '\0';
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R16970[Dtype(RTCW(arg1))-2246])(arg1);
		if ((EIF_BOOLEAN) !tb2) {
			tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R16956[Dtype(RTCW(arg1))-2246])(arg1, ((EIF_INTEGER_32) 1L));
			tr1 = RTOSCF(13590,F996_13590, (Current));
			tw2 = *(EIF_CHARACTER_32 *)(RTCW(tr1) + O6989[Dtype(tr1)-553]);
			tb1 = (EIF_BOOLEAN)(tw1 == tw2);
		}
		if (tb1) {
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R16992[Dtype(RTCW(arg1))-2246])(arg1);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R17033[Dtype(RTCW(arg1))-2246])(arg1, ((EIF_INTEGER_32) 2L), ti4_1);
			Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R16998[Dtype(RTCW(tr1))-2246])(tr1, arg2);
		}
	}
	RTLE;
	return Result;
}

/* {ARGUMENTS_32}.internal_argument_array */
static EIF_REFERENCE F996_13596_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (13596);
#define Result RTOSR(13596)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {1601,2250,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1601, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	tr2 = RTLNS(eif_new_type(2250, 0x00).id, 2250, _OBJSIZ_1_0_0_4_0_0_0_0_);
	F2243_21753(RTCW(tr2));
	ti4_1 = (EIF_INTEGER_32) eif_builtin_ARGUMENTS_32_argument_count__i4;
	F1602_15105(RTCW(tr1), tr2, ((EIF_INTEGER_32) 0L), ti4_1);
	Result = (EIF_REFERENCE) tr1;
	{
		/* INLINED CODE (CONTAINER.compare_objects) */
		(void) RTCW(Result);
		*(EIF_BOOLEAN *)(Result+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		/* END INLINED CODE */
	}
	;
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > (EIF_INTEGER_32) eif_builtin_ARGUMENTS_32_argument_count__i4)) break;
		tr1 = F996_13597(Current, loc1);
		{
			/* INLINED CODE (ARRAY.put) */
			(void) RTCW(Result);
			tr2 = *(EIF_REFERENCE *)(Result);
			ti4_1 = *(EIF_INTEGER_32 *)(Result + O12431[Dtype(Result)-1601]);
			/* INLINED CODE (SPECIAL.put) */
			*((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (loc1 - ti4_1))) = tr1;
			RTAR(tr2,tr1);
			/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		;
		loc1++;
	}
	RTOSE (13596);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F996_13596 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(13596,F996_13596_body,(Current));
}

/* {ARGUMENTS_32}.i_th_argument_string */
EIF_REFERENCE F996_13597 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(770, 0x00).id, 770, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F771_10686(RTCW(loc1), ((EIF_INTEGER_32) 0L));
	loc2 = (EIF_POINTER) eif_builtin_ARGUMENTS_32_i_th_argument_pointer__i4_p (arg1);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc2 != tp1)) {
		{
			/* INLINED CODE (NATIVE_STRING.set_shared_from_pointer) */
			(void) RTCW(loc1);
			ti4_1 = F770_10683(loc1, loc2);
			F771_10703(loc1, loc2, ti4_1);
			/* END INLINED CODE */
		}
		;
		Result = RTLNS(eif_new_type(2250, 0x00).id, 2250, _OBJSIZ_1_0_0_4_0_0_0_0_);
		tr1 = F771_10690(RTCW(loc1));
		F2250_22051(RTCW(Result), tr1);
	} else {
		Result = RTLNS(eif_new_type(2250, 0x00).id, 2250, _OBJSIZ_1_0_0_4_0_0_0_0_);
		F2243_21753(RTCW(Result));
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {ARGUMENTS_32}.i_th_argument_pointer */
EIF_POINTER F996_13598 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = (EIF_POINTER) eif_builtin_ARGUMENTS_32_i_th_argument_pointer__i4_p (arg1);
	return Result;
}

void EIF_Minit807 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
