
#ifndef _C17_ki843_
#define _C17_ki843_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1652_15355(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1652_15359(EIF_REFERENCE, EIF_INTEGER_64);
extern void F1652_15362(EIF_REFERENCE, EIF_NATURAL_32);
extern void F1652_15363(EIF_REFERENCE, EIF_NATURAL_64);
extern void EIF_Minit843(void);
extern char *(*R2898[])();

#ifdef __cplusplus
}
#endif

#endif
