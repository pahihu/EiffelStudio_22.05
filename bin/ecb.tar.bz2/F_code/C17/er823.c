/*
 * Code for class ERT_CLIENT_SET
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "er823.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ERT_CLIENT_SET}.make */
void F1555_14834 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	{
		/* INLINED CODE (LINKED_LIST.make) */
		*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (CONTAINER.compare_objects) */
		*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {ERT_CLIENT_SET}.put */
void F1555_14835 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (arg1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R17015[Dtype(RTCW(tr1))-2246])(tr1);
	{
		/* INLINED CODE (LINKED_SET.put) */
		tb1 = '\01';
		tb2 = F1347_14073(Current);
		if (!tb2) {
			tb2 = F1473_14564(Current, tr1);
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			F1540_14722(Current, tr1);
		}
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {ERT_CLIENT_SET}.extend */
void F1555_14836 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	{
		/* INLINED CODE (ERT_CLIENT_SET.put) */
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (arg1);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R17015[Dtype(RTCW(tr1))-2246])(tr1);
		F1552_14825(Current, tr1);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {ERT_CLIENT_SET}.merge_other */
void F1555_14837 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	loc1 = F1540_14700(RTCW(arg1));
	{
		/* INLINED CODE (LINKED_LIST.start) */
		(void) RTCW(arg1);
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(arg1) != NULL)) {
			tr1 = *(EIF_REFERENCE *)(arg1);
			RTAR(arg1, tr1);
			*(EIF_REFERENCE *)(arg1 + _REFACS_1_) = (EIF_REFERENCE) tr1;
			*(EIF_BOOLEAN *)(arg1+ _CHROFF_2_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			*(EIF_BOOLEAN *)(arg1+ _CHROFF_2_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		*(EIF_BOOLEAN *)(arg1+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		/* END INLINED CODE */
	}
	;
	for (;;) {
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_2_2_);
		if (tb1) break;
		tr1 = F1540_14697(RTCW(arg1));
		{
			/* INLINED CODE (ERT_CLIENT_SET.put) */
			tr2 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R17015[Dtype(RTCW(tr2))-2246])(tr2);
			F1552_14825(Current, tr2);
			/* END INLINED CODE */
		}
		;
		F1540_14716(RTCW(arg1));
	}
	F1540_14719(RTCW(arg1), loc1);
	RTLE;
}

void EIF_Minit823 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
