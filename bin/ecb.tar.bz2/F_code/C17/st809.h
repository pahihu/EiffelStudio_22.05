
#ifndef _C17_st809_
#define _C17_st809_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1078_13687(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F1078_13688(EIF_REFERENCE);
extern EIF_REFERENCE F1078_13689(EIF_REFERENCE);
extern EIF_REFERENCE F1078_13691(EIF_REFERENCE);
extern EIF_INTEGER_32 F1078_13692(EIF_REFERENCE);
extern void EIF_Minit809(void);
extern char *(*R17188[])();
extern long O17190[];

#ifdef __cplusplus
}
#endif

#endif
