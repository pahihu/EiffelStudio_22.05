/*
 * Code for class RESOURCE_TABLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "re839.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RESOURCE_TABLE}.get_integer */
EIF_INTEGER_32 F1643_15334 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	tb1 = '\0';
	tr1 = F1626_15205(Current, arg1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		{
			/* INLINED CODE (READABLE_STRING_GENERAL.is_integer) */
			tb2 = (EIF_BOOLEAN)  0;
			(void) loc1;
			tb2 = F2243_21838(loc1, ((EIF_INTEGER_32) 3L));
			/* END INLINED CODE */
		}
		tb2 = tb2;
		tb1 = tb2;
	}
	if (tb1) {
		{
			/* INLINED CODE (READABLE_STRING_GENERAL.to_integer) */
			tr1 = (EIF_REFERENCE)  0;
			ti4_1 = (EIF_INTEGER_32)  0;
			(void) loc1;
			tr1 = RTOSCF(21841,F2243_21841, (loc1));
			F449_6553(RTCW(tr1), loc1, ((EIF_INTEGER_32) 0L));
			ti4_1 = F449_6558(RTCW(tr1));
			/* END INLINED CODE */
		}
		ti4_1 = ti4_1;
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	} else {
		RTLE;
		return (EIF_INTEGER_32) arg2;
	}/* NOTREACHED */
	
}

/* {RESOURCE_TABLE}.get_boolean */
EIF_BOOLEAN F1643_15336 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	tb1 = '\0';
	tr1 = F1626_15205(Current, arg1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb2 = F2246_21922(loc1);
		tb1 = tb2;
	}
	if (tb1) {
		{
			/* INLINED CODE (READABLE_STRING_GENERAL.to_boolean) */
			tb1 = (EIF_BOOLEAN)  0;
			(void) loc1;
			
			ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 4L))) {
				tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
			/* END INLINED CODE */
		}
		tb1 = tb1;
		RTLE;
		return (EIF_BOOLEAN) tb1;
	} else {
		RTLE;
		return (EIF_BOOLEAN) arg2;
	}/* NOTREACHED */
	
}

void EIF_Minit839 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
