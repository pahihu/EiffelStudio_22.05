/*
 * Code for class RANDOM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ra812.h"
#include <math.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RANDOM}.make */
void F1345_14039 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = RTOSCF(14041,F1345_14041, (Current));
	{
		/* INLINED CODE (RANDOM.set_seed) */
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_1_) = (EIF_INTEGER_32) ti4_1;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_3_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_1_);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (COUNTABLE_SEQUENCE.start) */
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {RANDOM}.set_seed */
void F1345_14040 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_1_) = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_3_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_1_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTLE;
}

/* {RANDOM}.default_seed */
static EIF_INTEGER_32 F1345_14041_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (14041);
#define Result RTOSR(14041)
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 123457L);
	RTOSE (14041);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F1345_14041 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14041,F1345_14041_body,(Current));
}

/* {RANDOM}.modulus */
static EIF_INTEGER_32 F1345_14042_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (14042);
#define Result RTOSR(14042)
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	RTOSE (14042);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F1345_14042 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14042,F1345_14042_body,(Current));
}

/* {RANDOM}.multiplier */
static EIF_INTEGER_32 F1345_14043_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (14043);
#define Result RTOSR(14043)
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16807L);
	RTOSE (14043);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F1345_14043 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14043,F1345_14043_body,(Current));
}

/* {RANDOM}.increment */
static EIF_INTEGER_32 F1345_14044_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (14044);
#define Result RTOSR(14044)
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTOSE (14044);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F1345_14044 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14044,F1345_14044_body,(Current));
}

/* {RANDOM}.has */
EIF_BOOLEAN F1345_14047 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\0';
	if ((EIF_BOOLEAN) (arg1 < RTOSCF(14042,F1345_14042, (Current)))) {
		Result = (EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 0L));
	}
	RTLE;
	return Result;
}

/* {RANDOM}.i_th */
EIF_INTEGER_32 F1345_14048 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_2_))) {
		Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_3_);
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_2_);
	} else {
		Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_1_);
	}
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == arg1)) break;
		ti4_1 = F1345_14054(Current, Result);
		Result = (EIF_INTEGER_32) ti4_1;
		loc1++;
	}
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_3_) = (EIF_INTEGER_32) Result;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_2_) = (EIF_INTEGER_32) arg1;
	RTLE;
	return Result;
}

/* {RANDOM}.double_item */
EIF_REAL_64 F1345_14050 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REAL_64 tr8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	{
		/* INLINED CODE (COUNTABLE_SEQUENCE.item) */
		ti4_1 = (EIF_INTEGER_32)  0;
		ti4_1 = F1345_14048(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_0_));
		/* END INLINED CODE */
	}
	Result = (EIF_REAL_64) (ti4_1);
	tr8_1 = RTOSCF(14058,F1345_14058, (Current));
	Result = (EIF_REAL_64) (EIF_REAL_64) ((EIF_REAL_64) (Result) /  (EIF_REAL_64) (tr8_1));
	RTLE;
	return Result;
}

/* {RANDOM}.new_cursor */
EIF_REFERENCE F1345_14053 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(1344, 0x00).id, 1344, _OBJSIZ_0_1_0_4_0_0_0_0_);
	F1345_14040(RTCW(Result), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_1_));
	{
		/* INLINED CODE (COUNTABLE_SEQUENCE.start) */
		(void) RTCW(Result);
		*(EIF_INTEGER_32 *)(Result+ _LNGOFF_0_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		/* END INLINED CODE */
	}
	;
	RTLE;
	return Result;
}

/* {RANDOM}.randomize */
EIF_INTEGER_32 F1345_14054 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_REAL_64 tr8_4;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tr8_1 = RTOSCF(14059,F1345_14059, (Current));
	tr8_2 = (EIF_REAL_64) (arg1);
	tr8_3 = RTOSCF(14060,F1345_14060, (Current));
	tr8_4 = RTOSCF(14058,F1345_14058, (Current));
	{
		/* INLINED CODE (RANDOM.double_mod) */
		tr8_1 = (EIF_REAL_64) ((EIF_REAL_64) (tr8_1 * tr8_2) + tr8_3);
		tr8_2 = (EIF_REAL_64)  0;
		tr8_2 = (EIF_REAL_64) floor((double) (EIF_REAL_64) ((EIF_REAL_64) (tr8_1) /  (EIF_REAL_64) (tr8_4)));
		tr8_2 = (EIF_REAL_64) (EIF_REAL_64) (tr8_1 - (EIF_REAL_64) (tr8_2 * tr8_4));
		/* END INLINED CODE */
	}
	tr8_1 = tr8_2;
	Result = (EIF_INTEGER_32) tr8_1;
	RTLE;
	return Result;
}

/* {RANDOM}.double_mod */
EIF_REAL_64 F1345_14055 (EIF_REFERENCE Current, EIF_REAL_64 arg1, EIF_REAL_64 arg2)
{
	GTCX
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	
	
	RTGC;
	Result = (EIF_REAL_64) floor((double) (EIF_REAL_64) ((EIF_REAL_64) (arg1) /  (EIF_REAL_64) (arg2)));
	Result = (EIF_REAL_64) (EIF_REAL_64) (arg1 - (EIF_REAL_64) (Result * arg2));
	return Result;
}

/* {RANDOM}.dmod */
static EIF_REAL_64 F1345_14058_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (14058);
#define Result RTOSR(14058)
	Result = (EIF_REAL_64) (RTOSCF(14042,F1345_14042, (Current)));
	RTOSE (14058);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REAL_64 F1345_14058 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14058,F1345_14058_body,(Current));
}

/* {RANDOM}.dmul */
static EIF_REAL_64 F1345_14059_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (14059);
#define Result RTOSR(14059)
	Result = (EIF_REAL_64) (RTOSCF(14043,F1345_14043, (Current)));
	RTOSE (14059);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REAL_64 F1345_14059 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14059,F1345_14059_body,(Current));
}

/* {RANDOM}.dinc */
static EIF_REAL_64 F1345_14060_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (14060);
#define Result RTOSR(14060)
	Result = (EIF_REAL_64) (RTOSCF(14044,F1345_14044, (Current)));
	RTOSE (14060);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REAL_64 F1345_14060 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14060,F1345_14060_body,(Current));
}

void EIF_Minit812 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
