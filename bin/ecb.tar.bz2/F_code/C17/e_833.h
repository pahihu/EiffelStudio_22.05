
#ifndef _C17_e_833_
#define _C17_e_833_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1600_15096(EIF_REFERENCE, EIF_REFERENCE);
extern void F1600_15097(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit833(void);

#ifdef __cplusplus
}
#endif

#endif
