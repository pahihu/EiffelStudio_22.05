/*
 * Code for class PARENT_LIST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pa834.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PARENT_LIST}.check_validity2 */
void F1601_15098 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTGC;
	{
		/* INLINED CODE (ARRAYED_LIST.count) */
		ti4_1 = (EIF_INTEGER_32)  0;
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
		/* END INLINED CODE */
	}
	loc2 = ti4_1;
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == loc2)) break;
		{
			/* INLINED CODE (ARRAYED_LIST.area) */
			tr1 = (EIF_REFERENCE)  0;
			tr1 = *(EIF_REFERENCE *)(Current);
			/* END INLINED CODE */
		}
		tr2 = tr1;
		/* INLINED CODE (SPECIAL.item) */
		tr4 = *((EIF_REFERENCE *)RTCW(tr2) + (loc1));
		/* END INLINED CODE */
		tr1 = tr4;
		F3575_40074(RTCW(tr1));
		loc1++;
	}
	RTLE;
}

/* {PARENT_LIST}.check_validity4 */
void F1601_15099 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc4);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	{
		/* INLINED CODE (ARRAYED_LIST.area) */
		tr1 = (EIF_REFERENCE)  0;
		tr1 = *(EIF_REFERENCE *)(Current);
		/* END INLINED CODE */
	}
	loc1 = tr1;
	{
		/* INLINED CODE (ARRAYED_LIST.count) */
		ti4_1 = (EIF_INTEGER_32)  0;
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
		/* END INLINED CODE */
	}
	loc3 = ti4_1;
	for (;;) {
		if ((EIF_BOOLEAN)(loc2 == loc3)) break;
		/* INLINED CODE (SPECIAL.item) */
		tr2 = *((EIF_REFERENCE *)RTCW(loc1) + (loc2));
		/* END INLINED CODE */
		loc4 = tr2;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_5_);
		if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(tr1 == NULL)) {
			F3575_40075(RTCW(loc4));
		}
		loc2++;
	}
	RTLE;
}

/* {PARENT_LIST}.are_features_undefined */
EIF_BOOLEAN F1601_15101 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTGC;
	{
		/* INLINED CODE (ARRAYED_LIST.count) */
		ti4_1 = (EIF_INTEGER_32)  0;
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
		/* END INLINED CODE */
	}
	loc2 = ti4_1;
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == loc2)) break;
		{
			/* INLINED CODE (ARRAYED_LIST.area) */
			tr1 = (EIF_REFERENCE)  0;
			tr1 = *(EIF_REFERENCE *)(Current);
			/* END INLINED CODE */
		}
		tr2 = tr1;
		/* INLINED CODE (SPECIAL.item) */
		tr4 = *((EIF_REFERENCE *)RTCW(tr2) + (loc1));
		/* END INLINED CODE */
		tr1 = tr4;
		{
			/* INLINED CODE (PARENT_C.has_undefining) */
			tb1 = (EIF_BOOLEAN)  0;
			(void) RTCW(tr1);
			tb1 = '\0';
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(tr1 + _REFACS_4_) != NULL)) {
				tr2 = *(EIF_REFERENCE *)(tr1 + _REFACS_4_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_3_1_0_1_);
				tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
			}
			/* END INLINED CODE */
		}
		Result = tb1;
		if (Result) {
			loc1 = (EIF_INTEGER_32) loc2;
		} else {
			loc1++;
		}
	}
	RTLE;
	return Result;
}

/* {PARENT_LIST}.are_features_redefined */
EIF_BOOLEAN F1601_15102 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTGC;
	{
		/* INLINED CODE (ARRAYED_LIST.count) */
		ti4_1 = (EIF_INTEGER_32)  0;
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
		/* END INLINED CODE */
	}
	loc2 = ti4_1;
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == loc2)) break;
		{
			/* INLINED CODE (ARRAYED_LIST.area) */
			tr1 = (EIF_REFERENCE)  0;
			tr1 = *(EIF_REFERENCE *)(Current);
			/* END INLINED CODE */
		}
		tr2 = tr1;
		/* INLINED CODE (SPECIAL.item) */
		tr4 = *((EIF_REFERENCE *)RTCW(tr2) + (loc1));
		/* END INLINED CODE */
		tr1 = tr4;
		{
			/* INLINED CODE (PARENT_C.has_redefining) */
			tb1 = (EIF_BOOLEAN)  0;
			(void) RTCW(tr1);
			tb1 = '\0';
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(tr1 + _REFACS_3_) != NULL)) {
				tr2 = *(EIF_REFERENCE *)(tr1 + _REFACS_3_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_3_1_0_1_);
				tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
			}
			/* END INLINED CODE */
		}
		Result = tb1;
		if (Result) {
			loc1 = (EIF_INTEGER_32) loc2;
		} else {
			loc1++;
		}
	}
	RTLE;
	return Result;
}

/* {PARENT_LIST}.is_explicitly_selecting */
EIF_BOOLEAN F1601_15103 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTGC;
	{
		/* INLINED CODE (ARRAYED_LIST.count) */
		ti4_1 = (EIF_INTEGER_32)  0;
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
		/* END INLINED CODE */
	}
	loc2 = ti4_1;
	for (;;) {
		if ((EIF_BOOLEAN) (Result || (EIF_BOOLEAN) (loc1 >= loc2))) break;
		{
			/* INLINED CODE (ARRAYED_LIST.area) */
			tr1 = (EIF_REFERENCE)  0;
			tr1 = *(EIF_REFERENCE *)(Current);
			/* END INLINED CODE */
		}
		tr2 = tr1;
		/* INLINED CODE (SPECIAL.item) */
		tr4 = *((EIF_REFERENCE *)RTCW(tr2) + (loc1));
		/* END INLINED CODE */
		tr1 = tr4;
		Result = F3575_40072(RTCW(tr1), arg1);
		loc1++;
	}
	RTLE;
	return Result;
}

void EIF_Minit834 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
