
#ifndef _C17_ge831_
#define _C17_ge831_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1593_15019(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit831(void);
extern void F2301_22942(EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE);
extern EIF_INTEGER_32 F1566_14933(EIF_REFERENCE);
extern void F2301_22943(EIF_REFERENCE);
extern char *(*R22790[])();
extern char *(*R22795[])();

#ifdef __cplusplus
}
#endif

#endif
