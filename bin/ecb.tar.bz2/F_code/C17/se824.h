
#ifndef _C17_se824_
#define _C17_se824_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1561_14876(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1561_14877(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1561_14878(EIF_REFERENCE);
extern void F1561_14879(EIF_REFERENCE);
extern EIF_REFERENCE F1561_14880(EIF_REFERENCE);
extern void EIF_Minit824(void);
extern void F1540_14731(EIF_REFERENCE);
extern void F1556_14852(EIF_REFERENCE, EIF_REFERENCE);
extern void F1566_14912(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F1540_14699(EIF_REFERENCE);
extern void F1566_14971(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
