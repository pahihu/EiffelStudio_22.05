
#ifndef _C17_re817_
#define _C17_re817_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1440_14513(EIF_REFERENCE, EIF_REFERENCE);
extern void F1440_14514(EIF_REFERENCE, EIF_REFERENCE);
extern void F1440_14515(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit817(void);
extern EIF_REFERENCE F2493_26230(EIF_REFERENCE, EIF_INTEGER_32);
extern void F2246_21883(EIF_REFERENCE, EIF_INTEGER_32);
extern void F164_2780(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F604_8191(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,8191)
extern char *(*R16992[])();
extern char *(*R21743[])();
extern char *(*R20610[])();
extern long O17115[];
extern long O16106[];
extern long O21852[];

#ifdef __cplusplus
}
#endif

#endif
