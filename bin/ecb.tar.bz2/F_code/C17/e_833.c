/*
 * Code for class E_FEATURE_ARGUMENTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "e_833.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {E_FEATURE_ARGUMENTS}.set_argument_names */
void F1600_15096 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
}

/* {E_FEATURE_ARGUMENTS}.put_i_th */
void F1600_15097 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	{
		/* INLINED CODE (ARRAYED_LIST.list_put_i_th) */
		tr1 = *(EIF_REFERENCE *)(Current);
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)))) = arg1;
		RTAR(tr1,arg1);
		/* END INLINED CODE */;
		/* END INLINED CODE */
	}
	;
	RTLE;
}

void EIF_Minit833 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
