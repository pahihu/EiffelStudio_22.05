
#ifndef _C17_ei829_
#define _C17_ei829_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1586_15000(EIF_REFERENCE);
extern EIF_BOOLEAN F1586_15001(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1586_15002(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit829(void);
extern void F1566_14912(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R11[])();
extern char *(*R9812[])();

#ifdef __cplusplus
}
#endif

#endif
