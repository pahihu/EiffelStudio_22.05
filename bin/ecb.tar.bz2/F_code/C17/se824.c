/*
 * Code for class SELECTION_LIST_CACHE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "se824.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SELECTION_LIST_CACHE}.make */
void F1561_14876 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	{
		/* INLINED CODE (LINKED_LIST.sstwl_make) */
		*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		/* END INLINED CODE */
	}
	;
	F1561_14877(Current, arg1);
	RTLE;
}

/* {SELECTION_LIST_CACHE}.reset_with_n_elements */
void F1561_14877 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_1_);
	{
		/* INLINED CODE (LINKED_LIST.start) */
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
			*(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		/* END INLINED CODE */
	}
	;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		{
			/* INLINED CODE (SELECTION_LIST.reset) */
			(void) RTCW(tr1);
			F1566_14971(tr1);
			*(EIF_NATURAL_8 *)(tr1+ _CHROFF_1_1_) = (EIF_NATURAL_8) (EIF_NATURAL_8) ((EIF_INTEGER_32) 0L);
			/* END INLINED CODE */
		}
		;
		{
			/* INLINED CODE (SELECTION_LIST_CACHE.next_item) */
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
			if ((EIF_BOOLEAN)(tr1 == NULL)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
				*(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
			}
			/* END INLINED CODE */
		}
		;
		loc1++;
	}
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_0_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 >= arg1)) break;
		{
			/* INLINED CODE (SELECTION_LIST.reset) */
			tr1 = F1561_14880(Current);
			(void) RTCW(tr1);
			F1566_14971(tr1);
			*(EIF_NATURAL_8 *)(tr1+ _CHROFF_1_1_) = (EIF_NATURAL_8) (EIF_NATURAL_8) ((EIF_INTEGER_32) 0L);
			/* END INLINED CODE */
		}
		;
		loc1++;
	}
	{
		/* INLINED CODE (LINKED_LIST.start) */
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
			*(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		/* END INLINED CODE */
	}
	;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTLE;
}

/* {SELECTION_LIST_CACHE}.reset_all */
void F1561_14878 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1561_14877(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_1_));
	{
		/* INLINED CODE (TWO_WAY_LIST.wipe_out) */
		F1540_14731(Current);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) NULL;
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {SELECTION_LIST_CACHE}.next_item */
void F1561_14879 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		*(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {SELECTION_LIST_CACHE}.new_selection_list */
EIF_REFERENCE F1561_14880 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = *(EIF_REFERENCE *)(RTCW(tr1));
		{
			/* INLINED CODE (SELECTION_LIST.reset) */
			(void) RTCW(Result);
			F1566_14971(Result);
			*(EIF_NATURAL_8 *)(Result+ _CHROFF_1_1_) = (EIF_NATURAL_8) (EIF_NATURAL_8) ((EIF_INTEGER_32) 0L);
			/* END INLINED CODE */
		}
		;
		{
			/* INLINED CODE (SELECTION_LIST_CACHE.next_item) */
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
			if ((EIF_BOOLEAN)(tr1 == NULL)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
				*(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
			}
			/* END INLINED CODE */
		}
		;
	} else {
		tr1 = RTLNS(eif_new_type(2451, 0x00).id, 2451, _OBJSIZ_1_2_0_1_0_0_0_0_);
		F1566_14912(RTCW(tr1), ((EIF_INTEGER_32) 5L));
		F1556_14852(Current, tr1);
		Result = F1540_14699(Current);
	}
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_1_))++;
	RTLE;
	return Result;
}

void EIF_Minit824 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
