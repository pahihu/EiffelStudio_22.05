
#ifndef _C17_co828_
#define _C17_co828_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1582_14988(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit828(void);
extern void F1566_14912(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
