/*
 * Code for class ASSERT_ID_SET
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "as835.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ASSERT_ID_SET}.make */
void F1624_15172 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	F1602_15106(Current, ((EIF_INTEGER_32) 1L), arg1);
}

/* {ASSERT_ID_SET}.has */
EIF_BOOLEAN F1624_15176 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_2_0_1_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_7_0_2_)) || Result)) break;
		{
			/* INLINED CODE (ARRAY.item) */
			tr1 = (EIF_REFERENCE)  0;
			tr2 = *(EIF_REFERENCE *)(Current);
			tr1 = 
				/* INLINED CODE (SPECIAL.item) */
				*((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (loc1 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_7_0_1_))))
				/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		tr2 = tr1;
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_0_2_0_1_);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == loc2);
		loc1++;
	}
	RTLE;
	return Result;
}

/* {ASSERT_ID_SET}.has_assert */
EIF_BOOLEAN F1624_15177 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_7_0_2_)) || Result)) break;
		{
			/* INLINED CODE (ARRAY.item) */
			tr1 = (EIF_REFERENCE)  0;
			tr2 = *(EIF_REFERENCE *)(Current);
			tr1 = 
				/* INLINED CODE (SPECIAL.item) */
				*((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (loc1 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_7_0_1_))))
				/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		tr2 = tr1;
		Result = F607_8210(RTCW(tr2), arg1);
		loc1++;
	}
	RTLE;
	return Result;
}

/* {ASSERT_ID_SET}.set_has_precondition */
void F1624_15184 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_) = (EIF_BOOLEAN) arg1;
}

/* {ASSERT_ID_SET}.set_has_postcondition */
void F1624_15185 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_2_) = (EIF_BOOLEAN) arg1;
}

/* {ASSERT_ID_SET}.set_has_class_postcondition */
void F1624_15186 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_3_) = (EIF_BOOLEAN) arg1;
}

/* {ASSERT_ID_SET}.set_has_false_postcondition */
void F1624_15187 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_4_) = (EIF_BOOLEAN) arg1;
}

/* {ASSERT_ID_SET}.set_has_non_object_call */
void F1624_15188 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_5_) = (EIF_BOOLEAN) arg1;
}

/* {ASSERT_ID_SET}.set_has_unqualified_call */
void F1624_15189 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_6_) = (EIF_BOOLEAN) arg1;
}

/* {ASSERT_ID_SET}.force */
void F1624_15190 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1624_15176(Current, arg1)) {
		{
			/* INLINED CODE (ARRAY.array_count) */
			ti4_1 = (EIF_INTEGER_32)  0;
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_7_0_0_);
			ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_7_0_1_);
			ti4_1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - ti4_2) + ((EIF_INTEGER_32) 1L));
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_7_0_2_) >= ti4_1)) {
			{
				/* INLINED CODE (ARRAY.array_count) */
				ti4_1 = (EIF_INTEGER_32)  0;
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_7_0_0_);
				ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_7_0_1_);
				ti4_1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - ti4_2) + ((EIF_INTEGER_32) 1L));
				/* END INLINED CODE */
			}
			ti4_2 = ti4_1;
			F1602_15150(Current, arg1, ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 5L)));
		}
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_7_0_2_))++;
		{
			/* INLINED CODE (ARRAY.array_put) */
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_7_0_2_);
			tr1 = *(EIF_REFERENCE *)(Current);
			ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_7_0_1_);
			/* INLINED CODE (SPECIAL.put) */
			*((EIF_REFERENCE *)RTCW(tr1) + ((EIF_INTEGER_32) (ti4_1 - ti4_2))) = arg1;
			RTAR(tr1,arg1);
			/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
}

/* {ASSERT_ID_SET}.merge */
void F1624_15191 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_7_0_2_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		{
			/* INLINED CODE (ARRAY.item) */
			tr1 = (EIF_REFERENCE)  0;
			(void) RTCW(arg1);
			tr2 = *(EIF_REFERENCE *)(arg1);
			tr1 = 
				/* INLINED CODE (SPECIAL.item) */
				*((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (loc1 - *(EIF_INTEGER_32 *)(arg1+ _LNGOFF_1_7_0_1_))))
				/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		tr1 = tr1;
		F1624_15190(Current, tr1);
		loc1++;
	}
	RTLE;
}

/* {ASSERT_ID_SET}.same_as */
EIF_BOOLEAN F1624_15192 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_7_0_2_);
		tb1 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_7_0_2_) == ti4_1);
	}
	if (tb1) {
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		for (;;) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_7_0_2_)) || (EIF_BOOLEAN) !Result)) break;
			{
				/* INLINED CODE (ARRAY.item) */
				tr1 = (EIF_REFERENCE)  0;
				tr2 = *(EIF_REFERENCE *)(Current);
				tr1 = 
					/* INLINED CODE (SPECIAL.item) */
					*((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (loc1 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_7_0_1_))))
					/* END INLINED CODE */;
				/* END INLINED CODE */
			}
			tr2 = tr1;
			Result = F1624_15177(RTCW(arg1), tr2);
			loc1++;
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit835 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
