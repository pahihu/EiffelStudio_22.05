/*
 * Code for class INVARIANT_SERVER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "in820.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {INVARIANT_SERVER}.format */
void F1545_14741 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	{
		/* INLINED CODE (FINITE.is_empty) */
		tb1 = (EIF_BOOLEAN)  0;
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_3_0_0_);
		tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN) !tb1) {
		loc2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_10_);
		{
			/* INLINED CODE (TEXT_FORMATTER_DECORATOR.begin) */
			tr1 = (EIF_REFERENCE)  0;
			(void) RTCW(arg1);
			tr2 = *(EIF_REFERENCE *)(arg1 + _REFACS_14_);
			tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr2);
			tr2 = *(EIF_REFERENCE *)(arg1 + _REFACS_4_);
			F1548_14766(RTCW(tr2), tr1);
			RTAR(arg1, tr1);
			*(EIF_REFERENCE *)(arg1 + _REFACS_14_) = (EIF_REFERENCE) tr1;
			/* END INLINED CODE */
		}
		;
		tr1 = RTOSCF(5691,F400_5691, (Current));
		{
			/* INLINED CODE (TEXT_FORMATTER_DECORATOR.process_filter_item) */
			(void) RTCW(arg1);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(arg1 + O18441[Dtype(arg1)-2353]) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(arg1 + O18395[Dtype(arg1)-2353]))) {
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R18396[Dtype(arg1)-2353])(arg1);
			}
			*(EIF_BOOLEAN *)(arg1 + O18441[Dtype(arg1)-2353]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			tr2 = *(EIF_REFERENCE *)(arg1 + _REFACS_19_);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R14541[Dtype(RTCW(tr2))-1908])(tr2, tr1, (EIF_BOOLEAN) 1);
			/* END INLINED CODE */
		}
		;
		tr1 = RTOSCF(5758,F401_5758, (Current));
		{
			/* INLINED CODE (TEXT_FORMATTER_DECORATOR.process_keyword_text) */
			(void) RTCW(arg1);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(arg1 + O18441[Dtype(arg1)-2353]) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(arg1 + O18395[Dtype(arg1)-2353]))) {
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R18396[Dtype(arg1)-2353])(arg1);
			}
			*(EIF_BOOLEAN *)(arg1 + O18441[Dtype(arg1)-2353]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			tr2 = *(EIF_REFERENCE *)(arg1 + _REFACS_19_);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R14545[Dtype(RTCW(tr2))-1908])(tr2, tr1, NULL);
			/* END INLINED CODE */
		}
		;
		{
			/* INLINED CODE (TEXT_FORMATTER_DECORATOR.indent) */
			(void) RTCW(arg1);
			tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_14_);
			F65_971(RTCW(tr1));
			/* END INLINED CODE */
		}
		;
		{
			/* INLINED CODE (TEXT_FORMATTER_DECORATOR.put_new_line) */
			(void) RTCW(arg1);
			tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_19_);
			F1907_18034(RTCW(tr1));
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(arg1 + _REFACS_16_) != NULL)) {
				tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_19_);
				F402_5843(RTCW(tr1), *(EIF_REFERENCE *)(arg1 + _REFACS_16_));
			}
			*(EIF_BOOLEAN *)(arg1 + O18395[Dtype(arg1)-2353]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			/* END INLINED CODE */
		}
		;
		{
			/* INLINED CODE (LINKED_LIST.start) */
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) != NULL)) {
				tr1 = *(EIF_REFERENCE *)(Current);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
				*(EIF_BOOLEAN *)(Current+ _CHROFF_2_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			} else {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_2_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
			*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			/* END INLINED CODE */
		}
		;
		for (;;) {
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_2_)) break;
			{
				/* INLINED CODE (TEXT_FORMATTER_DECORATOR.begin) */
				tr1 = (EIF_REFERENCE)  0;
				(void) RTCW(arg1);
				tr2 = *(EIF_REFERENCE *)(arg1 + _REFACS_14_);
				tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr2);
				tr2 = *(EIF_REFERENCE *)(arg1 + _REFACS_4_);
				F1548_14766(RTCW(tr2), tr1);
				RTAR(arg1, tr1);
				*(EIF_REFERENCE *)(arg1 + _REFACS_14_) = (EIF_REFERENCE) tr1;
				/* END INLINED CODE */
			}
			;
			tr1 = *(EIF_REFERENCE *)(RTCV(F1540_14697(Current)) + _REFACS_1_);
			if ((EIF_BOOLEAN)(loc2 != tr1)) {
				{
					/* INLINED CODE (TEXT_FORMATTER_DECORATOR.indent) */
					(void) RTCW(arg1);
					tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_14_);
					F65_971(RTCW(tr1));
					/* END INLINED CODE */
				}
				;
				if (loc1) {
					{
						/* INLINED CODE (TEXT_FORMATTER_DECORATOR.put_new_line) */
						(void) RTCW(arg1);
						tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_19_);
						F1907_18034(RTCW(tr1));
						if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(arg1 + _REFACS_16_) != NULL)) {
							tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_19_);
							F402_5843(RTCW(tr1), *(EIF_REFERENCE *)(arg1 + _REFACS_16_));
						}
						*(EIF_BOOLEAN *)(arg1 + O18395[Dtype(arg1)-2353]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						/* END INLINED CODE */
					}
					;
				}
				tr1 = RTOSCF(5796,F401_5796, (Current));
				{
					/* INLINED CODE (TEXT_FORMATTER_DECORATOR.process_comment_text) */
					(void) RTCW(arg1);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(arg1 + O18441[Dtype(arg1)-2353]) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(arg1 + O18395[Dtype(arg1)-2353]))) {
						(FUNCTION_CAST(void, (EIF_REFERENCE)) R18396[Dtype(arg1)-2353])(arg1);
					}
					*(EIF_BOOLEAN *)(arg1 + O18441[Dtype(arg1)-2353]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					tr2 = *(EIF_REFERENCE *)(arg1 + _REFACS_19_);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R14526[Dtype(RTCW(tr2))-1908])(tr2, tr1, NULL);
					/* END INLINED CODE */
				}
				;
				{
					/* INLINED CODE (TEXT_FORMATTER_DECORATOR.put_space) */
					(void) RTCW(arg1);
					tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_19_);
					F402_5845(RTCW(tr1));
					/* END INLINED CODE */
				}
				;
				tr1 = RTMS_EX_H("from ",5,1920688416);
				{
					/* INLINED CODE (TEXT_FORMATTER_DECORATOR.process_comment_text) */
					(void) RTCW(arg1);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(arg1 + O18441[Dtype(arg1)-2353]) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(arg1 + O18395[Dtype(arg1)-2353]))) {
						(FUNCTION_CAST(void, (EIF_REFERENCE)) R18396[Dtype(arg1)-2353])(arg1);
					}
					*(EIF_BOOLEAN *)(arg1 + O18441[Dtype(arg1)-2353]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					tr2 = *(EIF_REFERENCE *)(arg1 + _REFACS_19_);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R14526[Dtype(RTCW(tr2))-1908])(tr2, tr1, NULL);
					/* END INLINED CODE */
				}
				;
				tr1 = *(EIF_REFERENCE *)(RTCV(F1540_14697(Current)) + _REFACS_1_);
				{
					/* INLINED CODE (CLASS_C.lace_class) */
					tr2 = (EIF_REFERENCE)  0;
					(void) RTCW(tr1);
					tr3 = *(EIF_REFERENCE *)(tr1 + _REFACS_21_);
					tr2 = F2240_21707(RTCW(tr3));
					/* END INLINED CODE */
				}
				tr1 = tr2;
				{
					/* INLINED CODE (TEXT_FORMATTER_DECORATOR.put_classi) */
					(void) RTCW(arg1);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(arg1 + O18441[Dtype(arg1)-2353]) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(arg1 + O18395[Dtype(arg1)-2353]))) {
						(FUNCTION_CAST(void, (EIF_REFERENCE)) R18396[Dtype(arg1)-2353])(arg1);
					}
					*(EIF_BOOLEAN *)(arg1 + O18441[Dtype(arg1)-2353]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					tr2 = *(EIF_REFERENCE *)(arg1 + _REFACS_19_);
					F1907_18043(RTCW(tr2), tr1);
					/* END INLINED CODE */
				}
				;
				{
					/* INLINED CODE (TEXT_FORMATTER_DECORATOR.exdent) */
					(void) RTCW(arg1);
					tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_14_);
					F65_972(RTCW(tr1));
					/* END INLINED CODE */
				}
				;
				{
					/* INLINED CODE (TEXT_FORMATTER_DECORATOR.put_new_line) */
					(void) RTCW(arg1);
					tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_19_);
					F1907_18034(RTCW(tr1));
					if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(arg1 + _REFACS_16_) != NULL)) {
						tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_19_);
						F402_5843(RTCW(tr1), *(EIF_REFERENCE *)(arg1 + _REFACS_16_));
					}
					*(EIF_BOOLEAN *)(arg1 + O18395[Dtype(arg1)-2353]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					/* END INLINED CODE */
				}
				;
			}
			tr1 = F1540_14697(Current);
			{
				/* INLINED CODE (INVARIANT_ADAPTER.format) */
				(void) RTCW(tr1);
				F2354_23689(RTCW(arg1));
				F2354_23630(RTCW(arg1), *(EIF_REFERENCE *)(tr1 + _REFACS_1_));
				F2354_23698(RTCW(arg1), *(EIF_REFERENCE *)(tr1));
				F2354_23690(RTCW(arg1));
				/* END INLINED CODE */
			}
			;
			{
				/* INLINED CODE (TEXT_FORMATTER_DECORATOR.put_new_line) */
				(void) RTCW(arg1);
				tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_19_);
				F1907_18034(RTCW(tr1));
				if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(arg1 + _REFACS_16_) != NULL)) {
					tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_19_);
					F402_5843(RTCW(tr1), *(EIF_REFERENCE *)(arg1 + _REFACS_16_));
				}
				*(EIF_BOOLEAN *)(arg1 + O18395[Dtype(arg1)-2353]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				/* END INLINED CODE */
			}
			;
			loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			{
				/* INLINED CODE (TEXT_FORMATTER_DECORATOR.commit) */
				(void) RTCW(arg1);
				tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_4_);
				F1548_14768(RTCW(tr1));
				tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_4_);
				tr1 = F1548_14764(RTCW(tr1));
				RTAR(arg1, tr1);
				*(EIF_REFERENCE *)(arg1 + _REFACS_14_) = (EIF_REFERENCE) tr1;
				/* END INLINED CODE */
			}
			;
			F1540_14716(Current);
		}
		if (loc1) {
			{
				/* INLINED CODE (TEXT_FORMATTER_DECORATOR.put_new_line) */
				(void) RTCW(arg1);
				tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_19_);
				F1907_18034(RTCW(tr1));
				if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(arg1 + _REFACS_16_) != NULL)) {
					tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_19_);
					F402_5843(RTCW(tr1), *(EIF_REFERENCE *)(arg1 + _REFACS_16_));
				}
				*(EIF_BOOLEAN *)(arg1 + O18395[Dtype(arg1)-2353]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				/* END INLINED CODE */
			}
			;
			{
				/* INLINED CODE (TEXT_FORMATTER_DECORATOR.set_without_tabs) */
				(void) RTCW(arg1);
				*(EIF_BOOLEAN *)(arg1 + O18441[Dtype(arg1)-2353]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				/* END INLINED CODE */
			}
			;
			tr1 = RTOSCF(5691,F400_5691, (Current));
			{
				/* INLINED CODE (TEXT_FORMATTER_DECORATOR.process_filter_item) */
				(void) RTCW(arg1);
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(arg1 + O18441[Dtype(arg1)-2353]) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(arg1 + O18395[Dtype(arg1)-2353]))) {
					(FUNCTION_CAST(void, (EIF_REFERENCE)) R18396[Dtype(arg1)-2353])(arg1);
				}
				*(EIF_BOOLEAN *)(arg1 + O18441[Dtype(arg1)-2353]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				tr2 = *(EIF_REFERENCE *)(arg1 + _REFACS_19_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R14541[Dtype(RTCW(tr2))-1908])(tr2, tr1, (EIF_BOOLEAN) 0);
				/* END INLINED CODE */
			}
			;
		}
		{
			/* INLINED CODE (TEXT_FORMATTER_DECORATOR.commit) */
			(void) RTCW(arg1);
			tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_4_);
			F1548_14768(RTCW(tr1));
			tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_4_);
			tr1 = F1548_14764(RTCW(tr1));
			RTAR(arg1, tr1);
			*(EIF_REFERENCE *)(arg1 + _REFACS_14_) = (EIF_REFERENCE) tr1;
			/* END INLINED CODE */
		}
		;
		{
			/* INLINED CODE (SHARED_FORMAT_INFO.set_not_in_assertion) */
			(void) RTCW(arg1);
			tr1 = RTOSCF(11427,F795_11427, (arg1));
			F557_7469(RTCW(tr1), (EIF_BOOLEAN) 0);
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
}

void EIF_Minit820 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
