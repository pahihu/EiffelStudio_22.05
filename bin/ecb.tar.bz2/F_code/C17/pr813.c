/*
 * Code for class PRIMES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pr813.h"
#include <math.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PRIMES}.higher_prime */
EIF_INTEGER_32 F1346_14063 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 <= ((EIF_INTEGER_32) 2L))) {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	} else {
		if ((EIF_BOOLEAN)((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 0L))) {
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L));
		} else {
			Result = (EIF_INTEGER_32) arg1;
		}
		for (;;) {
			if (F1346_14066(Current, Result)) break;
			Result += ((EIF_INTEGER_32) 2L);
		}
	}
	RTLE;
	return Result;
}

/* {PRIMES}.all_lower_primes */
EIF_REFERENCE F1346_14065 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {1604,2088,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 1604, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F1605_15105(RTCW(Result), (EIF_BOOLEAN) 0, ((EIF_INTEGER_32) 1L), arg1);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > arg1)) break;
		{
			/* INLINED CODE (ARRAY.put) */
			(void) RTCW(Result);
			tr1 = *(EIF_REFERENCE *)(Result);
			/* INLINED CODE (SPECIAL.put) */
			*((EIF_BOOLEAN *)RTCW(tr1) + ((EIF_INTEGER_32) (loc1 - *(EIF_INTEGER_32 *)(Result+ _LNGOFF_1_1_0_1_)))) = (EIF_BOOLEAN) 1;
			/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		;
		loc1 += ((EIF_INTEGER_32) 2L);
	}
	if ((EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 2L))) {
		{
			/* INLINED CODE (ARRAY.put) */
			ti4_1 = ((EIF_INTEGER_32) 2L);
			(void) RTCW(Result);
			tr1 = *(EIF_REFERENCE *)(Result);
			/* INLINED CODE (SPECIAL.put) */
			*((EIF_BOOLEAN *)RTCW(tr1) + ((EIF_INTEGER_32) (ti4_1 - *(EIF_INTEGER_32 *)(Result+ _LNGOFF_1_1_0_1_)))) = (EIF_BOOLEAN) 1;
			/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		;
	}
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 * loc1) > arg1)) break;
		{
			/* INLINED CODE (ARRAY.item) */
			tb1 = (EIF_BOOLEAN)  0;
			(void) RTCW(Result);
			tr1 = *(EIF_REFERENCE *)(Result);
			tb1 = 
				/* INLINED CODE (SPECIAL.item) */
				*((EIF_BOOLEAN *)RTCW(tr1) + ((EIF_INTEGER_32) (loc1 - *(EIF_INTEGER_32 *)(Result+ _LNGOFF_1_1_0_1_))))
				/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		tb1 = tb1;
		if (tb1) {
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 * loc1);
			for (;;) {
				if ((EIF_BOOLEAN) (loc2 > arg1)) break;
				{
					/* INLINED CODE (ARRAY.put) */
					(void) RTCW(Result);
					tr1 = *(EIF_REFERENCE *)(Result);
					/* INLINED CODE (SPECIAL.put) */
					*((EIF_BOOLEAN *)RTCW(tr1) + ((EIF_INTEGER_32) (loc2 - *(EIF_INTEGER_32 *)(Result+ _LNGOFF_1_1_0_1_)))) = (EIF_BOOLEAN) 0;
					/* END INLINED CODE */;
					/* END INLINED CODE */
				}
				;
				loc2 += (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * loc1);
			}
		}
		loc1 += ((EIF_INTEGER_32) 2L);
	}
	RTLE;
	return Result;
}

/* {PRIMES}.is_prime */
EIF_BOOLEAN F1346_14066 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 <= ((EIF_INTEGER_32) 1L))) {
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 2L))) {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			if ((EIF_BOOLEAN)((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 2L)) != ((EIF_INTEGER_32) 0L))) {
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
				for (;;) {
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN)((EIF_INTEGER_32) (arg1 % loc1) == ((EIF_INTEGER_32) 0L)) || (EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 * loc1) >= arg1))) break;
					loc1 += ((EIF_INTEGER_32) 2L);
				}
				if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 * loc1) > arg1)) {
					return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			}
		}
	}
	return Result;
}

/* {PRIMES}.i_th */
EIF_INTEGER_32 F1346_14067 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	loc3 = RTOSCF(14070,F1346_14070, (Current));
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_1_1_0_0_);
		tb1 = (EIF_BOOLEAN) (arg1 <= ti4_1);
	}
	if (tb1) {
		{
			/* INLINED CODE (ARRAY.item) */
			ti4_1 = (EIF_INTEGER_32)  0;
			(void) RTCW(loc3);
			tr1 = *(EIF_REFERENCE *)(loc3);
			ti4_1 = 
				/* INLINED CODE (SPECIAL.item) */
				*((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (arg1 - *(EIF_INTEGER_32 *)(loc3+ _LNGOFF_1_1_0_1_))))
				/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		ti4_1 = ti4_1;
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	} else {
		ti4_1 = F1346_14071(Current, arg1);
		loc1 = F1346_14065(Current, ti4_1);
		Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN)(loc2 == arg1)) break;
			Result++;
			{
				/* INLINED CODE (ARRAY.item) */
				tb1 = (EIF_BOOLEAN)  0;
				(void) RTCW(loc1);
				tr1 = *(EIF_REFERENCE *)(loc1);
				tb1 = 
					/* INLINED CODE (SPECIAL.item) */
					*((EIF_BOOLEAN *)RTCW(tr1) + ((EIF_INTEGER_32) (Result - *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_1_))))
					/* END INLINED CODE */;
				/* END INLINED CODE */
			}
			tb1 = tb1;
			if (tb1) {
				loc2++;
			}
		}
	}
	RTLE;
	return Result;
}

/* {PRIMES}.new_cursor */
EIF_REFERENCE F1346_14068 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	RTGC;
	Result = RTLNS(eif_new_type(1345, 0x00).id, 1345, _OBJSIZ_0_1_0_1_0_0_0_0_);
	{
		/* INLINED CODE (COUNTABLE_SEQUENCE.start) */
		(void) RTCW(Result);
		*(EIF_INTEGER_32 *)(Result+ _LNGOFF_0_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		/* END INLINED CODE */
	}
	;
	RTLE;
	return Result;
}

/* {PRIMES}.internal_precomputed_primes */
static EIF_REFERENCE F1346_14070_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	

	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (14070);
#define Result RTOSR(14070)
	RTOC_NEW(Result);
	ti4_1 = F1346_14071(Current, ((EIF_INTEGER_32) 200L));
	loc1 = F1346_14065(Current, ti4_1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1602,2055,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1602, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F1603_15105(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 200L));
	Result = (EIF_REFERENCE) tr1;
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 200L))) break;
		{
			/* INLINED CODE (ARRAY.item) */
			tb1 = (EIF_BOOLEAN)  0;
			(void) RTCW(loc1);
			tr1 = *(EIF_REFERENCE *)(loc1);
			tb1 = 
				/* INLINED CODE (SPECIAL.item) */
				*((EIF_BOOLEAN *)RTCW(tr1) + ((EIF_INTEGER_32) (loc2 - *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_1_))))
				/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		tb1 = tb1;
		if (tb1) {
			{
				/* INLINED CODE (ARRAY.put) */
				(void) RTCW(Result);
				tr1 = *(EIF_REFERENCE *)(Result);
				/* INLINED CODE (SPECIAL.put) */
				*((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (loc3 - *(EIF_INTEGER_32 *)(Result+ _LNGOFF_1_1_0_1_)))) = loc2;
				/* END INLINED CODE */;
				/* END INLINED CODE */
			}
			;
			loc3++;
		}
		loc2++;
	}
	RTOSE (14070);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1346_14070 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14070,F1346_14070_body,(Current));
}

/* {PRIMES}.approximated_i_th */
EIF_INTEGER_32 F1346_14071 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REAL_64 loc2 = (EIF_REAL_64) 0;
	EIF_REAL_64 loc3 = (EIF_REAL_64) 0;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,loc1);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 13L))) {
		loc1 = RTLNS(eif_new_type(300, 0x00).id, 300, _OBJSIZ_0_0_0_0_0_0_0_0_);
		tr8_1 = (EIF_REAL_64) (arg1);
		loc2 = (EIF_REAL_64) log((double) tr8_1);
		loc3 = (EIF_REAL_64) log((double) loc2);
		tr8_1 = (EIF_REAL_64) (arg1);
		tr8_2 = (EIF_REAL_64) (((EIF_INTEGER_32) 1L));
		Result = (EIF_INTEGER_32) (EIF_REAL_64) (tr8_1 * (EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) (loc2 + loc3) - tr8_2) + (EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) 1.8 * loc3)) /  (EIF_REAL_64) (loc2))));
	} else {
		RTLE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 * arg1);
	}
	RTLE;
	return Result;
}

void EIF_Minit813 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
