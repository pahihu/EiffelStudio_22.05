/*
 * Code for class CHAINED_ASSERTIONS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ch821.h"
#include "eif_built_in.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CHAINED_ASSERTIONS}.format_precondition */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F1546_14742 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc7 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc9 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN EIF_VOLATILE loc10 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_REFERENCE  EIF_VOLATILE tr2 = NULL;
	EIF_REFERENCE  EIF_VOLATILE tr3 = NULL;
	EIF_NATURAL_64  EIF_VOLATILE tu8_1;
	EIF_INTEGER_32  EIF_VOLATILE ti4_1;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_BOOLEAN  EIF_VOLATILE tb2;
	EIF_BOOLEAN  EIF_VOLATILE tb3;
	RTLD;
	RTXD;
	
	RTLI(11);
	RTLR(0,loc6);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Current);
	RTLR(5,loc7);
	RTLR(6,tr3);
	RTLR(7,loc3);
	RTLR(8,loc5);
	RTLR(9,loc1);
	RTLR(10,saved_except);
	RTLIU(11);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN) !loc10) {
		loc6 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_11_);
		{
			/* INLINED CODE (TEXT_FORMATTER_DECORATOR.begin) */
			tr1 = (EIF_REFERENCE)  0;
			(void) RTCW(arg1);
			tr2 = *(EIF_REFERENCE *)(arg1 + _REFACS_14_);
			tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr2);
			tr2 = *(EIF_REFERENCE *)(arg1 + _REFACS_4_);
			F1548_14766(RTCW(tr2), tr1);
			RTAR(arg1, tr1);
			*(EIF_REFERENCE *)(arg1 + _REFACS_14_) = (EIF_REFERENCE) tr1;
			/* END INLINED CODE */
		}
		;
		loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		{
			/* INLINED CODE (SHARED_FORMAT_INFO.set_in_assertion) */
			tr1 = RTOSCF(11427,F795_11427, (Current));
			F557_7469(RTCW(tr1), (EIF_BOOLEAN) 1);
			/* END INLINED CODE */
		}
		;
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_13_);
		{
			/* INLINED CODE (FEATURE_I.written_class) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(tr1);
			tr3 = RTOSCF(8191,F604_8191, (tr1));
			tr2 = F2493_26230(RTCW(tr3), *(EIF_INTEGER_32 *)(tr1 + O21156[Dtype(tr1)-2542]));
			/* END INLINED CODE */
		}
		loc7 = tr2;
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_10_);
		loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc7 != tr1);
		loc9 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_3_0_0_);
		{
			/* INLINED CODE (LINKED_LIST.start) */
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) != NULL)) {
				tr1 = *(EIF_REFERENCE *)(Current);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
				*(EIF_BOOLEAN *)(Current+ _CHROFF_2_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			} else {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_2_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
			*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			/* END INLINED CODE */
		}
		;
		for (;;) {
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_2_)) break;
			loc3 = F1540_14697(Current);
			loc5 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_2_);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc3));
			if ((EIF_BOOLEAN)(tr1 == NULL)) {
				if ((EIF_BOOLEAN) (loc9 > ((EIF_INTEGER_32) 1L))) {
					{
						/* INLINED CODE (FEATURE_I.written_class) */
						tr1 = (EIF_REFERENCE)  0;
						(void) RTCW(loc5);
						tr2 = RTOSCF(8191,F604_8191, (loc5));
						tr1 = F2493_26230(RTCW(tr2), *(EIF_INTEGER_32 *)(loc5 + O21156[Dtype(loc5)-2542]));
						/* END INLINED CODE */
					}
					loc1 = tr1;
					tb1 = '\0';
					{
						/* INLINED CODE (FEATURE_I.is_origin) */
						tb2 = (EIF_BOOLEAN)  0;
						(void) RTCW(loc5);
						tu8_1 = *(EIF_NATURAL_64 *)(loc5 + O21445[Dtype(loc5)-2542]);
						tu8_1 = eif_bit_and(tu8_1,((EIF_NATURAL_64) RTU64C(2)));
						tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu8_1 == ((EIF_NATURAL_64) RTU64C(2)));
						/* END INLINED CODE */
					}
					tb2 = tb2;
					if (tb2) {
						tb1 = (EIF_BOOLEAN)(loc1 != loc7);
					}
					if (tb1) {
						loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						tr1 = RTOSCF(5775,F401_5775, (Current));
						{
							/* INLINED CODE (TEXT_FORMATTER_DECORATOR.process_keyword_text) */
							(void) RTCW(arg1);
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(arg1 + O18441[Dtype(arg1)-2353]) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(arg1 + O18395[Dtype(arg1)-2353]))) {
								(FUNCTION_CAST(void, (EIF_REFERENCE)) R18396[Dtype(arg1)-2353])(arg1);
							}
							*(EIF_BOOLEAN *)(arg1 + O18441[Dtype(arg1)-2353]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							tr2 = *(EIF_REFERENCE *)(arg1 + _REFACS_19_);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R14545[Dtype(RTCW(tr2))-1908])(tr2, tr1, NULL);
							/* END INLINED CODE */
						}
						;
						{
							/* INLINED CODE (TEXT_FORMATTER_DECORATOR.put_space) */
							(void) RTCW(arg1);
							tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_19_);
							F402_5845(RTCW(tr1));
							/* END INLINED CODE */
						}
						;
						tr1 = RTOSCF(5796,F401_5796, (Current));
						{
							/* INLINED CODE (TEXT_FORMATTER_DECORATOR.process_comment_text) */
							(void) RTCW(arg1);
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(arg1 + O18441[Dtype(arg1)-2353]) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(arg1 + O18395[Dtype(arg1)-2353]))) {
								(FUNCTION_CAST(void, (EIF_REFERENCE)) R18396[Dtype(arg1)-2353])(arg1);
							}
							*(EIF_BOOLEAN *)(arg1 + O18441[Dtype(arg1)-2353]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							tr2 = *(EIF_REFERENCE *)(arg1 + _REFACS_19_);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R14526[Dtype(RTCW(tr2))-1908])(tr2, tr1, NULL);
							/* END INLINED CODE */
						}
						;
						{
							/* INLINED CODE (TEXT_FORMATTER_DECORATOR.put_space) */
							(void) RTCW(arg1);
							tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_19_);
							F402_5845(RTCW(tr1));
							/* END INLINED CODE */
						}
						;
						tr1 = RTMS_EX_H("from ",5,1920688416);
						{
							/* INLINED CODE (TEXT_FORMATTER_DECORATOR.process_comment_text) */
							(void) RTCW(arg1);
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(arg1 + O18441[Dtype(arg1)-2353]) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(arg1 + O18395[Dtype(arg1)-2353]))) {
								(FUNCTION_CAST(void, (EIF_REFERENCE)) R18396[Dtype(arg1)-2353])(arg1);
							}
							*(EIF_BOOLEAN *)(arg1 + O18441[Dtype(arg1)-2353]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							tr2 = *(EIF_REFERENCE *)(arg1 + _REFACS_19_);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R14526[Dtype(RTCW(tr2))-1908])(tr2, tr1, NULL);
							/* END INLINED CODE */
						}
						;
						{
							/* INLINED CODE (TEXT_FORMATTER_DECORATOR.put_space) */
							(void) RTCW(arg1);
							tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_19_);
							F402_5845(RTCW(tr1));
							/* END INLINED CODE */
						}
						;
						{
							/* INLINED CODE (CLASS_C.lace_class) */
							tr1 = (EIF_REFERENCE)  0;
							(void) RTCW(loc1);
							tr2 = *(EIF_REFERENCE *)(loc1 + _REFACS_21_);
							tr1 = F2240_21707(RTCW(tr2));
							/* END INLINED CODE */
						}
						tr1 = tr1;
						{
							/* INLINED CODE (TEXT_FORMATTER_DECORATOR.put_classi) */
							(void) RTCW(arg1);
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(arg1 + O18441[Dtype(arg1)-2353]) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(arg1 + O18395[Dtype(arg1)-2353]))) {
								(FUNCTION_CAST(void, (EIF_REFERENCE)) R18396[Dtype(arg1)-2353])(arg1);
							}
							*(EIF_BOOLEAN *)(arg1 + O18441[Dtype(arg1)-2353]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							tr2 = *(EIF_REFERENCE *)(arg1 + _REFACS_19_);
							F1907_18043(RTCW(tr2), tr1);
							/* END INLINED CODE */
						}
						;
						{
							/* INLINED CODE (TEXT_FORMATTER_DECORATOR.indent) */
							(void) RTCW(arg1);
							tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_14_);
							F65_971(RTCW(tr1));
							/* END INLINED CODE */
						}
						;
						{
							/* INLINED CODE (TEXT_FORMATTER_DECORATOR.put_new_line) */
							(void) RTCW(arg1);
							tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_19_);
							F1907_18034(RTCW(tr1));
							if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(arg1 + _REFACS_16_) != NULL)) {
								tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_19_);
								F402_5843(RTCW(tr1), *(EIF_REFERENCE *)(arg1 + _REFACS_16_));
							}
							*(EIF_BOOLEAN *)(arg1 + O18395[Dtype(arg1)-2353]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							/* END INLINED CODE */
						}
						;
						tr1 = RTOSCF(5784,F401_5784, (Current));
						{
							/* INLINED CODE (TEXT_FORMATTER_DECORATOR.process_keyword_text) */
							(void) RTCW(arg1);
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(arg1 + O18441[Dtype(arg1)-2353]) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(arg1 + O18395[Dtype(arg1)-2353]))) {
								(FUNCTION_CAST(void, (EIF_REFERENCE)) R18396[Dtype(arg1)-2353])(arg1);
							}
							*(EIF_BOOLEAN *)(arg1 + O18441[Dtype(arg1)-2353]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							tr2 = *(EIF_REFERENCE *)(arg1 + _REFACS_19_);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R14545[Dtype(RTCW(tr2))-1908])(tr2, tr1, NULL);
							/* END INLINED CODE */
						}
						;
						{
							/* INLINED CODE (TEXT_FORMATTER_DECORATOR.put_new_line) */
							(void) RTCW(arg1);
							tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_19_);
							F1907_18034(RTCW(tr1));
							if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(arg1 + _REFACS_16_) != NULL)) {
								tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_19_);
								F402_5843(RTCW(tr1), *(EIF_REFERENCE *)(arg1 + _REFACS_16_));
							}
							*(EIF_BOOLEAN *)(arg1 + O18395[Dtype(arg1)-2353]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							/* END INLINED CODE */
						}
						;
						{
							/* INLINED CODE (TEXT_FORMATTER_DECORATOR.exdent) */
							(void) RTCW(arg1);
							tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_14_);
							F65_972(RTCW(tr1));
							/* END INLINED CODE */
						}
						;
						{
							/* INLINED CODE (TEXT_FORMATTER_DECORATOR.set_first_assertion) */
							(void) RTCW(arg1);
							*(EIF_BOOLEAN *)(arg1 + O18374[Dtype(arg1)-2353]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							/* END INLINED CODE */
						}
						;
					}
				}
			} else {
				{
					/* INLINED CODE (TEXT_FORMATTER_DECORATOR.begin) */
					tr1 = (EIF_REFERENCE)  0;
					(void) RTCW(arg1);
					tr2 = *(EIF_REFERENCE *)(arg1 + _REFACS_14_);
					tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr2);
					tr2 = *(EIF_REFERENCE *)(arg1 + _REFACS_4_);
					F1548_14766(RTCW(tr2), tr1);
					RTAR(arg1, tr1);
					*(EIF_REFERENCE *)(arg1 + _REFACS_14_) = (EIF_REFERENCE) tr1;
					/* END INLINED CODE */
				}
				;
				loc8++;
				tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_2_);
				{
					/* INLINED CODE (FEATURE_I.written_class) */
					tr2 = (EIF_REFERENCE)  0;
					(void) RTCW(tr1);
					tr3 = RTOSCF(8191,F604_8191, (tr1));
					tr2 = F2493_26230(RTCW(tr3), *(EIF_INTEGER_32 *)(tr1 + O21156[Dtype(tr1)-2542]));
					/* END INLINED CODE */
				}
				tr1 = tr2;
				{
					/* INLINED CODE (TEXT_FORMATTER_DECORATOR.set_source_class) */
					(void) RTCW(arg1);
					tr2 = *(EIF_REFERENCE *)(arg1 + _REFACS_18_);
					F2517_26613(RTCW(tr2), tr1);
					RTAR(arg1, tr1);
					*(EIF_REFERENCE *)(arg1 + _REFACS_11_) = (EIF_REFERENCE) tr1;
					/* END INLINED CODE */
				}
				;
				if (loc4) {
					tb1 = '\01';
					if (!loc2) {
						tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_2_);
						{
							/* INLINED CODE (FEATURE_I.written_class) */
							tr2 = (EIF_REFERENCE)  0;
							(void) RTCW(tr1);
							tr3 = RTOSCF(8191,F604_8191, (tr1));
							tr2 = F2493_26230(RTCW(tr3), *(EIF_INTEGER_32 *)(tr1 + O21156[Dtype(tr1)-2542]));
							/* END INLINED CODE */
						}
						tr1 = tr2;
						{
							/* INLINED CODE (CLASS_C.simple_conform_to) */
							ti4_1 = (EIF_INTEGER_32)  0;
							tb2 = (EIF_BOOLEAN)  0;
							(void) RTCW(loc7);
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O20546[Dtype(tr1)-2524]);
							tb2 = '\0';
							if ((EIF_BOOLEAN) (ti4_1 <= *(EIF_INTEGER_32 *)(loc7 + O20546[Dtype(loc7)-2524]))) {
								tr2 = *(EIF_REFERENCE *)(loc7 + _REFACS_2_);
								tb3 = F130_2376(RTCW(tr2), ti4_1);
								tb2 = tb3;
							}
							/* END INLINED CODE */
						}
						tb2 = tb2;
						tb1 = (EIF_BOOLEAN) !tb2;
					}
					F36_318(RTCW(loc3), arg1, tb1);
				} else {
					F36_318(RTCW(loc3), arg1, loc2);
				}
				loc8--;
				{
					/* INLINED CODE (TEXT_FORMATTER_DECORATOR.commit) */
					(void) RTCW(arg1);
					tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_4_);
					F1548_14768(RTCW(tr1));
					tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_4_);
					tr1 = F1548_14764(RTCW(tr1));
					RTAR(arg1, tr1);
					*(EIF_REFERENCE *)(arg1 + _REFACS_14_) = (EIF_REFERENCE) tr1;
					/* END INLINED CODE */
				}
				;
			}
			F1540_14716(Current);
		}
	} else {
		{
			/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
			(void) RTCW(arg1);
			F2354_23730(arg1);
			/* END INLINED CODE */
		}
		;
		tr1 = RTMS_EX_H("-- Unable to show all preconditions!",36,1808867361);
		{
			/* INLINED CODE (TEXT_FORMATTER.add_comment) */
			(void) RTCW(arg1);
			F2354_23719(arg1, tr1, NULL);
			/* END INLINED CODE */
		}
		;
		{
			/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
			(void) RTCW(arg1);
			F2354_23730(arg1);
			/* END INLINED CODE */
		}
		;
	}
	{
		/* INLINED CODE (SHARED_FORMAT_INFO.set_not_in_assertion) */
		tr1 = RTOSCF(11427,F795_11427, (Current));
		F557_7469(RTCW(tr1), (EIF_BOOLEAN) 0);
		/* END INLINED CODE */
	}
	;
	if ((EIF_BOOLEAN) (loc8 > ((EIF_INTEGER_32) 0L))) {
		for (;;) {
			if ((EIF_BOOLEAN)(loc8 == ((EIF_INTEGER_32) 0L))) break;
			loc8--;
			{
				/* INLINED CODE (TEXT_FORMATTER_DECORATOR.commit) */
				(void) RTCW(arg1);
				tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_4_);
				F1548_14768(RTCW(tr1));
				tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_4_);
				tr1 = F1548_14764(RTCW(tr1));
				RTAR(arg1, tr1);
				*(EIF_REFERENCE *)(arg1 + _REFACS_14_) = (EIF_REFERENCE) tr1;
				/* END INLINED CODE */
			}
			;
		}
	}
	{
		/* INLINED CODE (TEXT_FORMATTER_DECORATOR.set_source_class) */
		(void) RTCW(arg1);
		tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_18_);
		F2517_26613(RTCW(tr1), loc6);
		RTAR(arg1, loc6);
		*(EIF_REFERENCE *)(arg1 + _REFACS_11_) = (EIF_REFERENCE) loc6;
		/* END INLINED CODE */
	}
	;
	RTE_E
	RTXSC;
	loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {CHAINED_ASSERTIONS}.format_postcondition */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F1546_14743 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTED;
	EIF_BOOLEAN EIF_VOLATILE loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc4 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN EIF_VOLATILE loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_REFERENCE  EIF_VOLATILE tr2 = NULL;
	EIF_REFERENCE  EIF_VOLATILE tr3 = NULL;
	EIF_REFERENCE  EIF_VOLATILE tr4 = NULL;
	EIF_INTEGER_32  EIF_VOLATILE ti4_1;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_BOOLEAN  EIF_VOLATILE tb2;
	EIF_BOOLEAN  EIF_VOLATILE tb3;
	RTLD;
	RTXD;
	
	RTLI(9);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,Current);
	RTLR(7,tr4);
	RTLR(8,saved_except);
	RTLIU(9);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN) !loc5) {
		loc2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_11_);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_13_);
		{
			/* INLINED CODE (FEATURE_I.written_class) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(tr1);
			tr3 = RTOSCF(8191,F604_8191, (tr1));
			tr2 = F2493_26230(RTCW(tr3), *(EIF_INTEGER_32 *)(tr1 + O21156[Dtype(tr1)-2542]));
			/* END INLINED CODE */
		}
		loc3 = tr2;
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_10_);
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc3 != tr1);
		{
			/* INLINED CODE (TEXT_FORMATTER_DECORATOR.begin) */
			tr1 = (EIF_REFERENCE)  0;
			(void) RTCW(arg1);
			tr2 = *(EIF_REFERENCE *)(arg1 + _REFACS_14_);
			tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr2);
			tr2 = *(EIF_REFERENCE *)(arg1 + _REFACS_4_);
			F1548_14766(RTCW(tr2), tr1);
			RTAR(arg1, tr1);
			*(EIF_REFERENCE *)(arg1 + _REFACS_14_) = (EIF_REFERENCE) tr1;
			/* END INLINED CODE */
		}
		;
		loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		{
			/* INLINED CODE (SHARED_FORMAT_INFO.set_in_assertion) */
			tr1 = RTOSCF(11427,F795_11427, (Current));
			F557_7469(RTCW(tr1), (EIF_BOOLEAN) 1);
			/* END INLINED CODE */
		}
		;
		{
			/* INLINED CODE (LINKED_LIST.start) */
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) != NULL)) {
				tr1 = *(EIF_REFERENCE *)(Current);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
				*(EIF_BOOLEAN *)(Current+ _CHROFF_2_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			} else {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_2_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
			*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			/* END INLINED CODE */
		}
		;
		for (;;) {
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_2_)) break;
			tr1 = *(EIF_REFERENCE *)(RTCV(F1540_14697(Current)) + _REFACS_1_);
			if ((EIF_BOOLEAN)(tr1 != NULL)) {
				{
					/* INLINED CODE (TEXT_FORMATTER_DECORATOR.begin) */
					tr1 = (EIF_REFERENCE)  0;
					(void) RTCW(arg1);
					tr2 = *(EIF_REFERENCE *)(arg1 + _REFACS_14_);
					tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr2);
					tr2 = *(EIF_REFERENCE *)(arg1 + _REFACS_4_);
					F1548_14766(RTCW(tr2), tr1);
					RTAR(arg1, tr1);
					*(EIF_REFERENCE *)(arg1 + _REFACS_14_) = (EIF_REFERENCE) tr1;
					/* END INLINED CODE */
				}
				;
				loc4++;
				tr1 = *(EIF_REFERENCE *)(RTCV(F1540_14697(Current)) + _REFACS_2_);
				{
					/* INLINED CODE (FEATURE_I.written_class) */
					tr2 = (EIF_REFERENCE)  0;
					(void) RTCW(tr1);
					tr3 = RTOSCF(8191,F604_8191, (tr1));
					tr2 = F2493_26230(RTCW(tr3), *(EIF_INTEGER_32 *)(tr1 + O21156[Dtype(tr1)-2542]));
					/* END INLINED CODE */
				}
				tr1 = tr2;
				{
					/* INLINED CODE (TEXT_FORMATTER_DECORATOR.set_source_class) */
					(void) RTCW(arg1);
					tr2 = *(EIF_REFERENCE *)(arg1 + _REFACS_18_);
					F2517_26613(RTCW(tr2), tr1);
					RTAR(arg1, tr1);
					*(EIF_REFERENCE *)(arg1 + _REFACS_11_) = (EIF_REFERENCE) tr1;
					/* END INLINED CODE */
				}
				;
				tr1 = F1540_14697(Current);
				tb1 = '\0';
				if (loc1) {
					tr2 = *(EIF_REFERENCE *)(RTCV(F1540_14697(Current)) + _REFACS_2_);
					{
						/* INLINED CODE (FEATURE_I.written_class) */
						tr3 = (EIF_REFERENCE)  0;
						(void) RTCW(tr2);
						tr4 = RTOSCF(8191,F604_8191, (tr2));
						tr3 = F2493_26230(RTCW(tr4), *(EIF_INTEGER_32 *)(tr2 + O21156[Dtype(tr2)-2542]));
						/* END INLINED CODE */
					}
					tr2 = tr3;
					{
						/* INLINED CODE (CLASS_C.simple_conform_to) */
						ti4_1 = (EIF_INTEGER_32)  0;
						tb2 = (EIF_BOOLEAN)  0;
						(void) RTCW(loc3);
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2) + O20546[Dtype(tr2)-2524]);
						tb2 = '\0';
						if ((EIF_BOOLEAN) (ti4_1 <= *(EIF_INTEGER_32 *)(loc3 + O20546[Dtype(loc3)-2524]))) {
							tr3 = *(EIF_REFERENCE *)(loc3 + _REFACS_2_);
							tb3 = F130_2376(RTCW(tr3), ti4_1);
							tb2 = tb3;
						}
						/* END INLINED CODE */
					}
					tb2 = tb2;
					tb1 = (EIF_BOOLEAN) !tb2;
				}
				F36_319(RTCW(tr1), arg1, tb1);
				loc4--;
				{
					/* INLINED CODE (TEXT_FORMATTER_DECORATOR.commit) */
					(void) RTCW(arg1);
					tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_4_);
					F1548_14768(RTCW(tr1));
					tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_4_);
					tr1 = F1548_14764(RTCW(tr1));
					RTAR(arg1, tr1);
					*(EIF_REFERENCE *)(arg1 + _REFACS_14_) = (EIF_REFERENCE) tr1;
					/* END INLINED CODE */
				}
				;
			}
			F1540_14716(Current);
		}
	} else {
		{
			/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
			(void) RTCW(arg1);
			F2354_23730(arg1);
			/* END INLINED CODE */
		}
		;
		tr1 = RTMS_EX_H("-- Unable to show all postconditions!",37,405280801);
		{
			/* INLINED CODE (TEXT_FORMATTER.add_comment) */
			(void) RTCW(arg1);
			F2354_23719(arg1, tr1, NULL);
			/* END INLINED CODE */
		}
		;
		{
			/* INLINED CODE (TEXT_FORMATTER.add_new_line) */
			(void) RTCW(arg1);
			F2354_23730(arg1);
			/* END INLINED CODE */
		}
		;
	}
	{
		/* INLINED CODE (SHARED_FORMAT_INFO.set_not_in_assertion) */
		tr1 = RTOSCF(11427,F795_11427, (Current));
		F557_7469(RTCW(tr1), (EIF_BOOLEAN) 0);
		/* END INLINED CODE */
	}
	;
	if ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 0L))) {
		for (;;) {
			if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) break;
			loc4--;
			{
				/* INLINED CODE (TEXT_FORMATTER_DECORATOR.commit) */
				(void) RTCW(arg1);
				tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_4_);
				F1548_14768(RTCW(tr1));
				tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_4_);
				tr1 = F1548_14764(RTCW(tr1));
				RTAR(arg1, tr1);
				*(EIF_REFERENCE *)(arg1 + _REFACS_14_) = (EIF_REFERENCE) tr1;
				/* END INLINED CODE */
			}
			;
		}
	}
	{
		/* INLINED CODE (TEXT_FORMATTER_DECORATOR.set_source_class) */
		(void) RTCW(arg1);
		tr1 = *(EIF_REFERENCE *)(arg1 + _REFACS_18_);
		F2517_26613(RTCW(tr1), loc2);
		RTAR(arg1, loc2);
		*(EIF_REFERENCE *)(arg1 + _REFACS_11_) = (EIF_REFERENCE) loc2;
		/* END INLINED CODE */
	}
	;
	RTE_E
	RTXSC;
	loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

void EIF_Minit821 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
