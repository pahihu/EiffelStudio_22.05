/*
 * Code for class EIFFEL_COMMENTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ei829.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EIFFEL_COMMENTS}.make */
void F1586_15000 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1566_14912(Current, ((EIF_INTEGER_32) 2L));
}

/* {EIFFEL_COMMENTS}.is_less */
EIF_BOOLEAN F1586_15001 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc3);
	RTLR(4,tr2);
	RTLR(5,loc4);
	RTLIU(6);
	
	RTGC;
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		tb1 = '\01';
		tb2 = '\01';
		if (!loc1) {
			{
				/* INLINED CODE (ARRAYED_LIST.count) */
				ti4_1 = (EIF_INTEGER_32)  0;
				tr1 = *(EIF_REFERENCE *)(Current);
				ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
				/* END INLINED CODE */
			}
			tb2 = (EIF_BOOLEAN) (loc2 > ti4_1);
		}
		if (!tb2) {
			{
				/* INLINED CODE (ARRAYED_LIST.count) */
				ti4_1 = (EIF_INTEGER_32)  0;
				(void) RTCW(arg1);
				tr1 = *(EIF_REFERENCE *)(arg1);
				ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
				/* END INLINED CODE */
			}
			ti4_1 = ti4_1;
			tb1 = (EIF_BOOLEAN) (loc2 > ti4_1);
		}
		if (tb1) break;
		{
			/* INLINED CODE (ARRAYED_LIST.i_th) */
			tr1 = (EIF_REFERENCE)  0;
			tr2 = *(EIF_REFERENCE *)(Current);
			tr1 = 
				/* INLINED CODE (SPECIAL.item) */
				*((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L))))
				/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		loc3 = tr1;
		{
			/* INLINED CODE (ARRAYED_LIST.i_th) */
			tr1 = (EIF_REFERENCE)  0;
			(void) RTCW(arg1);
			tr2 = *(EIF_REFERENCE *)(arg1);
			tr1 = 
				/* INLINED CODE (SPECIAL.item) */
				*((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L))))
				/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		loc4 = tr1;
		{
			/* INLINED CODE (EIFFEL_COMMENT_LINE.is_equal) */
			tb2 = (EIF_BOOLEAN)  0;
			(void) RTCW(loc3);
			tr1 = *(EIF_REFERENCE *)(loc3);
			tr2 = *(EIF_REFERENCE *)(RTCW(loc4));
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(tr1))-3])(tr1, tr2);
			/* END INLINED CODE */
		}
		loc1 = tb2;
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc1;
		if (loc1) {
			{
				/* INLINED CODE (EIFFEL_COMMENT_LINE.is_less) */
				tb2 = (EIF_BOOLEAN)  0;
				(void) RTCW(loc3);
				tr1 = *(EIF_REFERENCE *)(loc3);
				tr2 = *(EIF_REFERENCE *)(RTCW(loc4));
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R9812[Dtype(RTCW(tr1))-798])(tr1, tr2);
				/* END INLINED CODE */
			}
			Result = tb2;
		}
		loc2++;
	}
	if ((EIF_BOOLEAN) !loc1) {
		{
			/* INLINED CODE (ARRAYED_LIST.count) */
			ti4_1 = (EIF_INTEGER_32)  0;
			tr1 = *(EIF_REFERENCE *)(Current);
			ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
			/* END INLINED CODE */
		}
		ti4_2 = ti4_1;
		{
			/* INLINED CODE (ARRAYED_LIST.count) */
			ti4_3 = (EIF_INTEGER_32)  0;
			(void) RTCW(arg1);
			tr1 = *(EIF_REFERENCE *)(arg1);
			ti4_3 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
			/* END INLINED CODE */
		}
		ti4_3 = ti4_3;
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_2 < ti4_3);
	}
	RTLE;
	return Result;
}

/* {EIFFEL_COMMENTS}.is_equal */
EIF_BOOLEAN F1586_15002 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLIU(7);
	
	RTGC;
	{
		/* INLINED CODE (ARRAYED_LIST.count) */
		ti4_1 = (EIF_INTEGER_32)  0;
		(void) RTCW(arg1);
		tr1 = *(EIF_REFERENCE *)(arg1);
		ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
		/* END INLINED CODE */
	}
	ti4_1 = ti4_1;
	{
		/* INLINED CODE (ARRAYED_LIST.count) */
		ti4_2 = (EIF_INTEGER_32)  0;
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_2 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(ti4_1 == ti4_2)) {
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN) !Result) {
				{
					/* INLINED CODE (ARRAYED_LIST.count) */
					ti4_1 = (EIF_INTEGER_32)  0;
					tr1 = *(EIF_REFERENCE *)(Current);
					ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
					/* END INLINED CODE */
				}
				tb1 = (EIF_BOOLEAN) (loc1 > ti4_1);
			}
			if (tb1) break;
			{
				/* INLINED CODE (ARRAYED_LIST.i_th) */
				tr1 = (EIF_REFERENCE)  0;
				tr2 = *(EIF_REFERENCE *)(Current);
				tr1 = 
					/* INLINED CODE (SPECIAL.item) */
					*((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L))))
					/* END INLINED CODE */;
				/* END INLINED CODE */
			}
			tr2 = tr1;
			{
				/* INLINED CODE (ARRAYED_LIST.i_th) */
				tr3 = (EIF_REFERENCE)  0;
				(void) RTCW(arg1);
				tr4 = *(EIF_REFERENCE *)(arg1);
				tr3 = 
					/* INLINED CODE (SPECIAL.item) */
					*((EIF_REFERENCE *)RTCW(tr4) + ((EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L))))
					/* END INLINED CODE */;
				/* END INLINED CODE */
			}
			tr3 = tr3;
			{
				/* INLINED CODE (EIFFEL_COMMENT_LINE.is_equal) */
				tb2 = (EIF_BOOLEAN)  0;
				(void) RTCW(tr2);
				tr4 = *(EIF_REFERENCE *)(tr2);
				tr5 = *(EIF_REFERENCE *)(RTCW(tr3));
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(tr4))-3])(tr4, tr5);
				/* END INLINED CODE */
			}
			Result = tb2;
			loc1++;
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit829 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
