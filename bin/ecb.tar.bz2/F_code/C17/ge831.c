/*
 * Code for class GENERIC_SKELETON
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge831.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GENERIC_SKELETON}.instantiation_in */
EIF_REFERENCE F1593_15019 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	Result = RTLNS(eif_new_type(2300, 0x00).id, 2300, _OBJSIZ_3_1_0_2_0_0_0_0_);
	ti4_1 = F1566_14933(Current);
	F2301_22942(RTCW(Result), ti4_1, arg1);
	{
		/* INLINED CODE (ARRAYED_LIST.start) */
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		/* END INLINED CODE */
	}
	;
	for (;;) {
		{
			/* INLINED CODE (LIST.after) */
			tb1 = (EIF_BOOLEAN)  0;
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
			ti4_2 = F1566_14933(Current);
			tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
			/* END INLINED CODE */
		}
		if (tb1) break;
		{
			/* INLINED CODE (ARRAYED_LIST.item) */
			tr1 = (EIF_REFERENCE)  0;
			tr2 = *(EIF_REFERENCE *)(Current);
			tr1 = 
				/* INLINED CODE (SPECIAL.item) */
				*((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) - ((EIF_INTEGER_32) 1L))))
				/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		tr2 = tr1;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R22795[Dtype(RTCW(tr2))-2820])(tr2, arg1);
		{
			/* INLINED CODE (SKELETON.extend) */
			(void) RTCW(Result);
			tr2 = *(EIF_REFERENCE *)(Result + _REFACS_1_);
			ti4_1 = *(EIF_INTEGER_32 *)(Result+ _LNGOFF_3_1_0_1_);
			/* INLINED CODE (SPECIAL.put) */
			*((EIF_REFERENCE *)RTCW(tr2) + (ti4_1)) = tr1;
			RTAR(tr2,tr1);
			/* END INLINED CODE */;
			(*(EIF_INTEGER_32 *)(Result+ _LNGOFF_3_1_0_1_))++;
			tb2 = '\01';
			if (!*(EIF_BOOLEAN *)(Result+ _CHROFF_3_0_)) {
				tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R22790[Dtype(RTCW(tr1))-2820])(tr1);
				tb2 = tb3;
			}
			*(EIF_BOOLEAN *)(Result+ _CHROFF_3_0_) = (EIF_BOOLEAN) tb2;
			/* END INLINED CODE */
		}
		;
		{
			/* INLINED CODE (ARRAYED_LIST.forth) */
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_))++;
			/* END INLINED CODE */
		}
		;
	}
	F2301_22943(RTCW(Result));
	RTLE;
	return Result;
}

void EIF_Minit831 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
