/*
 * Code for class KL_IMPORTED_STRING_ROUTINES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl840.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_IMPORTED_STRING_ROUTINES}.string_ */
static EIF_REFERENCE F1649_15350_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (15350);
#define Result RTOSR(15350)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1676, 0x00).id, 1676, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (15350);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1649_15350 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15350,F1649_15350_body,(Current));
}

void EIF_Minit840 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
