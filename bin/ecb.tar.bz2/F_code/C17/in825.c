/*
 * Code for class INHERIT_FEAT_CACHE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "in825.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {INHERIT_FEAT_CACHE}.make */
void F1562_14882 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	{
		/* INLINED CODE (LINKED_LIST.sstwl_make) */
		*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		/* END INLINED CODE */
	}
	;
	F1562_14883(Current, arg1);
	RTLE;
}

/* {INHERIT_FEAT_CACHE}.reset_with_n_elements */
void F1562_14883 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_1_);
	{
		/* INLINED CODE (LINKED_LIST.start) */
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
			*(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		/* END INLINED CODE */
	}
	;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		{
			/* INLINED CODE (INHERIT_FEAT.reset) */
			(void) RTCW(tr1);
			F1566_14971(RTCV(F3570_39901(tr1)));
			tr2 = *(EIF_REFERENCE *)(tr1 + _REFACS_1_);
			F1566_14971(RTCW(tr2));
			*(EIF_REFERENCE *)(tr1 + _REFACS_2_) = (EIF_REFERENCE) NULL;
			tr2 = *(EIF_REFERENCE *)(tr1 + _REFACS_3_);
			F281_4173(RTCW(tr2));
			/* END INLINED CODE */
		}
		;
		{
			/* INLINED CODE (INHERIT_FEAT_CACHE.next_item) */
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
			if ((EIF_BOOLEAN)(tr1 == NULL)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
				*(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
			}
			/* END INLINED CODE */
		}
		;
		loc1++;
	}
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_0_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 >= arg1)) break;
		{
			/* INLINED CODE (INHERIT_FEAT.reset) */
			tr1 = F1562_14886(Current);
			(void) RTCW(tr1);
			F1566_14971(RTCV(F3570_39901(tr1)));
			tr2 = *(EIF_REFERENCE *)(tr1 + _REFACS_1_);
			F1566_14971(RTCW(tr2));
			*(EIF_REFERENCE *)(tr1 + _REFACS_2_) = (EIF_REFERENCE) NULL;
			tr2 = *(EIF_REFERENCE *)(tr1 + _REFACS_3_);
			F281_4173(RTCW(tr2));
			/* END INLINED CODE */
		}
		;
		loc1++;
	}
	{
		/* INLINED CODE (LINKED_LIST.start) */
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
			*(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		/* END INLINED CODE */
	}
	;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTLE;
}

/* {INHERIT_FEAT_CACHE}.reset_all */
void F1562_14884 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1562_14883(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_1_));
	{
		/* INLINED CODE (TWO_WAY_LIST.wipe_out) */
		F1540_14731(Current);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) NULL;
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {INHERIT_FEAT_CACHE}.next_item */
void F1562_14885 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		*(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {INHERIT_FEAT_CACHE}.new_inherit_feat */
EIF_REFERENCE F1562_14886 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = *(EIF_REFERENCE *)(RTCW(tr1));
		{
			/* INLINED CODE (INHERIT_FEAT.reset) */
			(void) RTCW(Result);
			F1566_14971(RTCV(F3570_39901(Result)));
			tr1 = *(EIF_REFERENCE *)(Result + _REFACS_1_);
			F1566_14971(RTCW(tr1));
			*(EIF_REFERENCE *)(Result + _REFACS_2_) = (EIF_REFERENCE) NULL;
			tr1 = *(EIF_REFERENCE *)(Result + _REFACS_3_);
			F281_4173(RTCW(tr1));
			/* END INLINED CODE */
		}
		;
		{
			/* INLINED CODE (INHERIT_FEAT_CACHE.next_item) */
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
			if ((EIF_BOOLEAN)(tr1 == NULL)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
				*(EIF_BOOLEAN *)(Current+ _CHROFF_4_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
			}
			/* END INLINED CODE */
		}
		;
	} else {
		tr1 = RTLNS(eif_new_type(3569, 0x00).id, 3569, _OBJSIZ_4_0_0_0_0_0_0_0_);
		F3570_39899(RTCW(tr1));
		F1556_14852(Current, tr1);
		Result = F1540_14699(Current);
	}
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_1_))++;
	RTLE;
	return Result;
}

void EIF_Minit825 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
