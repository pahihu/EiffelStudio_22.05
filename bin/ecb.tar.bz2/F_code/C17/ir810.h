
#ifndef _C17_ir810_
#define _C17_ir810_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1124_13709(EIF_REFERENCE);
extern EIF_REFERENCE F1124_13713(EIF_REFERENCE);
extern EIF_REFERENCE F1124_13715(EIF_REFERENCE);
extern void EIF_Minit810(void);
extern void F2243_21753(EIF_REFERENCE);
extern void F3225_38248(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R11641[])();
extern char *(*R11537[])();
extern char *(*R11637[])();

#ifdef __cplusplus
}
#endif

#endif
