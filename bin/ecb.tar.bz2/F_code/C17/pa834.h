
#ifndef _C17_pa834_
#define _C17_pa834_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1601_15098(EIF_REFERENCE);
extern void F1601_15099(EIF_REFERENCE);
extern EIF_BOOLEAN F1601_15101(EIF_REFERENCE);
extern EIF_BOOLEAN F1601_15102(EIF_REFERENCE);
extern EIF_BOOLEAN F1601_15103(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit834(void);
extern void F3575_40074(EIF_REFERENCE);
extern EIF_BOOLEAN F3575_40072(EIF_REFERENCE, EIF_INTEGER_32);
extern void F3575_40075(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
