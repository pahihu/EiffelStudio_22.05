/*
 * Code for class BASE_PROCESS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ba801.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BASE_PROCESS}.cancel_input_redirection */
void F973_13416 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_13_16_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = RTLNSMART(eif_new_type(2250, 0).id);
	F2243_21753(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {BASE_PROCESS}.cancel_output_redirection */
void F973_13419 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_13_16_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = RTLNSMART(eif_new_type(2250, 0).id);
	F2243_21753(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {BASE_PROCESS}.cancel_error_redirection */
void F973_13423 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_13_16_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = RTLNSMART(eif_new_type(2250, 0).id);
	F2243_21753(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {BASE_PROCESS}.launch */
void F973_13426 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_13_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	F973_13460(Current);
	F974_13509(Current);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_13_6_)) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_13_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		*(EIF_BOOLEAN *)(Current+ _CHROFF_13_9_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		*(EIF_BOOLEAN *)(Current+ _CHROFF_13_10_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		*(EIF_BOOLEAN *)(Current+ _CHROFF_13_7_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		{
			/* INLINED CODE (BASE_PROCESS.initialize_after_launch) */
			/* END INLINED CODE */
		}
		;
		F973_13464(Current);
	} else {
		F973_13463(Current);
	}
	RTLE;
}

/* {BASE_PROCESS}.check_exit */
void F973_13442 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_13_7_)) {
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_13_5_)) {
			{
				/* INLINED CODE (BASE_PROCESS.update_process_state) */
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
				F786_11101(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_13_16_0_1_), (EIF_BOOLEAN) 0);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
				tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_15_1_);
				*(EIF_BOOLEAN *)(Current+ _CHROFF_13_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) !tb1;
				/* END INLINED CODE */
			}
			;
		}
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_13_5_)) {
			{
				/* INLINED CODE (BASE_PROCESS.close_process) */
				F974_13508(Current);
				/* END INLINED CODE */
			}
			;
			*(EIF_BOOLEAN *)(Current+ _CHROFF_13_7_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_13_9_)) {
				F973_13461(Current);
			} else {
				F973_13462(Current);
			}
		}
	}
	RTLE;
}

/* {BASE_PROCESS}.set_separate_console */
void F973_13447 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_13_12_) = (EIF_BOOLEAN) arg1;
}

/* {BASE_PROCESS}.set_environment_variable_table */
void F973_13450 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
}

/* {BASE_PROCESS}.on_start */
void F973_13460 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,0,2049,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 1, 1);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R16770[Dtype(loc1)-2204])(loc1, tr1);
	}
	RTLE;
}

/* {BASE_PROCESS}.on_terminate */
void F973_13461 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,0,2049,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 1, 1);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R16770[Dtype(loc1)-2204])(loc1, tr1);
	}
	RTLE;
}

/* {BASE_PROCESS}.on_exit */
void F973_13462 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,0,2049,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 1, 1);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R16770[Dtype(loc1)-2204])(loc1, tr1);
	}
	RTLE;
}

/* {BASE_PROCESS}.on_launch_failed */
void F973_13463 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,0,2049,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 1, 1);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R16770[Dtype(loc1)-2204])(loc1, tr1);
	}
	RTLE;
}

/* {BASE_PROCESS}.on_launch_successed */
void F973_13464 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,0,2049,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 1, 1);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R16770[Dtype(loc1)-2204])(loc1, tr1);
	}
	RTLE;
}

/* {BASE_PROCESS}.platform */
static EIF_REFERENCE F973_13467_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (13467);
#define Result RTOSR(13467)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(775, 0x00).id, 775, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (13467);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F973_13467 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(13467,F973_13467_body,(Current));
}

/* {BASE_PROCESS}.initialize_working_directory */
void F973_13498 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = RTLNSMART(eif_new_type(2250, 0).id);
		F2251_22102(RTCW(tr1), arg1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	} else {
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
	}
	RTLE;
}

/* {BASE_PROCESS}.initialize_parameter */
void F973_13499 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	{
		/* INLINED CODE (BASE_PROCESS.cancel_input_redirection) */
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_13_16_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		tr1 = RTLNSMART(eif_new_type(2250, 0).id);
		F2243_21753(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (BASE_PROCESS.cancel_output_redirection) */
		tr1 = (EIF_REFERENCE)  0;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_13_16_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		tr2 = RTLNSMART(eif_new_type(2250, 0).id);
		F2243_21753(RTCW(tr2));
		RTAR(Current, tr2);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr2;
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (BASE_PROCESS.cancel_error_redirection) */
		tr1 = (EIF_REFERENCE)  0;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_13_16_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		tr2 = RTLNSMART(eif_new_type(2250, 0).id);
		F2243_21753(RTCW(tr2));
		RTAR(Current, tr2);
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr2;
		/* END INLINED CODE */
	}
	;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_13_11_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_13_12_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_13_8_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_13_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_13_9_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_13_10_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {BASE_PROCESS}.is_separator */
EIF_BOOLEAN F973_13501 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	RTGC;
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(arg1 == tw1);
	return Result;
}

/* {BASE_PROCESS}.separated_words */
EIF_REFERENCE F973_13502 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 loc9 = (EIF_CHARACTER_32) 0;
	EIF_BOOLEAN loc10 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLR(3,loc5);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {1565,2251,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 1565, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F1566_14912(RTCW(Result), ((EIF_INTEGER_32) 1L));
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R16970[Dtype(RTCW(arg1))-2246])(arg1);
	if ((EIF_BOOLEAN) !tb1) {
		loc5 = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F2250_22049(RTCW(loc5), ((EIF_INTEGER_32) 128L));
		loc8 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R16992[Dtype(RTCW(arg1))-2246])(arg1);
		loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		loc9 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R16956[Dtype(RTCW(arg1))-2246])(arg1, loc7);
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN) (loc7 > loc8)) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
				tb1 = (EIF_BOOLEAN)(loc9 == tw1);
			}
			if (tb1) break;
			loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			if (loc1) {
				if (loc4) {
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\\';
					if ((EIF_BOOLEAN)(loc9 == tw1)) {
						loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					} else {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\'';
						if ((EIF_BOOLEAN)(loc9 == tw1)) {
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
							{
								/* INLINED CODE (STRING_32.put) */
								(void) RTCW(loc5);
								tr1 = *(EIF_REFERENCE *)(loc5);
								/* INLINED CODE (SPECIAL.put) */
								*((EIF_CHARACTER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)))) = loc9;
								/* END INLINED CODE */;
								F2245_21851(loc5);
								/* END INLINED CODE */
							}
							;
							loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						}
					}
				}
				tb2 = '\0';
				if (loc10) {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\'';
					tb2 = (EIF_BOOLEAN)(loc9 == tw1);
				}
				if (tb2) {
					loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				}
			} else {
				if (loc2) {
					if (loc4) {
						loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
						{
							/* INLINED CODE (STRING_32.put) */
							(void) RTCW(loc5);
							tr1 = *(EIF_REFERENCE *)(loc5);
							/* INLINED CODE (SPECIAL.put) */
							*((EIF_CHARACTER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)))) = loc9;
							/* END INLINED CODE */;
							F2245_21851(loc5);
							/* END INLINED CODE */
						}
						;
						loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					}
					tb2 = '\0';
					if (loc10) {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb2 = (EIF_BOOLEAN)(loc9 == tw1);
					}
					if (tb2) {
						loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					}
				}
			}
			if (loc10) {
				switch (loc9) {
					case (EIF_CHARACTER_8) '\\':
						loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						F2252_22177(RTCW(loc5), loc9);
						loc6++;
						loc9 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R16956[Dtype(RTCW(arg1))-2246])(arg1, loc6);
						break;
					case (EIF_CHARACTER_8) '\'':
						loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						break;
					case (EIF_CHARACTER_8) '\"':
						if ((EIF_BOOLEAN) !loc1) {
							loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						} else {
							tb2 = (EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b;
							if (tb2) {
								if ((EIF_BOOLEAN) !loc2) {
									F2252_22177(RTCW(loc5), loc9);
									loc6++;
								} else {
									loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
									loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								}
							} else {
								F2252_22177(RTCW(loc5), loc9);
								loc6++;
							}
						}
						break;
					default:
						if ((EIF_BOOLEAN) (loc1 || loc2)) {
							F2252_22177(RTCW(loc5), loc9);
							loc6++;
						} else {
							{
								/* INLINED CODE (BASE_PROCESS.is_separator) */
								tb2 = (EIF_BOOLEAN)  0;
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
								tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc9 == tw1);
								/* END INLINED CODE */
							}
							if (tb2) {
								if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc6 > ((EIF_INTEGER_32) 1L)) || loc3)) {
									tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc5);
									(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11799[Dtype(RTCW(Result))-1322])(Result, tr1);
									{
										/* INLINED CODE (STRING_32.wipe_out) */
										(void) RTCW(loc5);
										*(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
										F2245_21851(loc5);
										/* END INLINED CODE */
									}
									;
									loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
									loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
									loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								}
							} else {
								F2252_22177(RTCW(loc5), loc9);
								loc6++;
							}
						}
						break;
				}
			}
			if (loc10) {
				loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
			loc7++;
			if ((EIF_BOOLEAN) (loc7 <= loc8)) {
				loc9 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R16956[Dtype(RTCW(arg1))-2246])(arg1, loc7);
			}
		}
		if ((EIF_BOOLEAN) (loc6 > ((EIF_INTEGER_32) 1L))) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11799[Dtype(RTCW(Result))-1322])(Result, loc5);
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit801 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
