/*
 * Code for class KL_STDERR_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl848.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_STDERR_FILE}.make */
void F1657_15382 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {KL_STDERR_FILE}.eol */

EIF_REFERENCE F1657_15384 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (15384,RTMS_EX_H("\012",1,10));
}

/* {KL_STDERR_FILE}.put_character */
void F1657_15386 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(15389,F1657_15389, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R11205[Dtype(RTCW(tr1))-1437])(tr1, arg1);
	RTLE;
}

/* {KL_STDERR_FILE}.put_string */
void F1657_15387 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(15350,F1649_15350, (Current));
	loc1 = F1677_15561(RTCW(tr1), arg1);
	tr1 = RTOSCF(15389,F1657_15389, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11203[Dtype(RTCW(tr1))-1437])(tr1, loc1);
	RTLE;
}

/* {KL_STDERR_FILE}.console */
static EIF_REFERENCE F1657_15389_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (15389);
#define Result RTOSR(15389)
	RTOC_NEW(Result);
	Result = RTOSCF(2686,F161_2686, (RTCV(RTOSCF(24,F1_24, (Current)))));
	RTOSE (15389);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1657_15389 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15389,F1657_15389_body,(Current));
}

void EIF_Minit848 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
