/*
 * Code for class FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "fi814.h"
#include "eif_retrieve.h"
#include "eif_store.h"
#include "eif_helpers.h"
#include "eif_file.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {FILE}.make_with_name */
void F1437_14168 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	{
		/* INLINED CODE (FILE.set_name) */
		{
		EIF_TYPE_INDEX inlined_dtype = Dtype(Current);
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current + O12015[inlined_dtype-1436]) = (EIF_REFERENCE) arg1;
		tr1 = RTOSCF(14337,F1437_14337, (Current));
		tr1 = F836_11784(RTCW(tr1), arg1, *(EIF_REFERENCE *)(Current + O12017[inlined_dtype-1436]));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O12017[inlined_dtype-1436]) = (EIF_REFERENCE) tr1;
		}
		/* END INLINED CODE */
	}
	;
	*(EIF_INTEGER_32 *)(Current + O12071[dtype-1436]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	*(EIF_POINTER *)(Current + O11932[dtype-1436]) = (EIF_POINTER) tp2;
	tr1 = RTLNSMART(eif_new_type(2247, 0).id);
	F2243_21753(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O11174[dtype-920]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {FILE}.make_with_path */
void F1437_14169 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	{
		/* INLINED CODE (FILE.set_path) */
		{
		EIF_TYPE_INDEX inlined_dtype = Dtype(Current);
		tr1 = F2014_18990(RTCW(arg1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O12015[inlined_dtype-1436]) = (EIF_REFERENCE) tr1;
		tr1 = F2014_18992(RTCW(arg1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O12017[inlined_dtype-1436]) = (EIF_REFERENCE) tr1;
		}
		/* END INLINED CODE */
	}
	;
	*(EIF_INTEGER_32 *)(Current + O12071[dtype-1436]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	*(EIF_POINTER *)(Current + O11932[dtype-1436]) = (EIF_POINTER) tp2;
	tr1 = RTLNSMART(eif_new_type(2247, 0).id);
	F2243_21753(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O11174[dtype-920]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {FILE}.make_open_read */
void F1437_14170 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11919[dtype-1437])(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R11969[dtype-1437])(Current);
	RTLE;
}

/* {FILE}.make_open_append */
void F1437_14172 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11919[Dtype(Current)-1437])(Current, arg1);
	{
		/* INLINED CODE (FILE.open_append) */
		{
		EIF_TYPE_INDEX inlined_dtype = Dtype(Current);
		tp1 = *(EIF_POINTER *)(RTCV(F1437_14329(Current))+ _PTROFF_0_1_0_1_0_0_);
		tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32)) R12013[inlined_dtype-1437])(Current, tp1, ((EIF_INTEGER_32) 2L));
		*(EIF_POINTER *)(Current + O11932[inlined_dtype-1436]) = (EIF_POINTER) tp1;
		*(EIF_INTEGER_32 *)(Current + O12071[inlined_dtype-1436]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
		}
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {FILE}.path */
EIF_REFERENCE F1437_14178 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(2013, 0x00).id, 2013, _OBJSIZ_2_1_0_0_0_0_0_0_);
	tp1 = *(EIF_POINTER *)(RTCV(F1437_14329(Current))+ _PTROFF_0_1_0_1_0_0_);
	F2014_18955(RTCW(Result), tp1);
	RTLE;
	return Result;
}

/* {FILE}.name */
EIF_REFERENCE F1437_14179 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O12015[Dtype(Current)-1436]);
	Result = F2243_21809(RTCW(tr1));
	RTLE;
	return Result;
}

/* {FILE}.item */
EIF_CHARACTER_8 F1437_14180 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R11233[dtype-1437])(Current);
	Result = *(EIF_CHARACTER_8 *)(Current + O11173[dtype-920]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R11791[dtype-1437])(Current);
	RTLE;
	return Result;
}

/* {FILE}.position */
EIF_INTEGER_32 F1437_14181 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	{
		/* INLINED CODE (FILE.is_closed) */
		tb1 = (EIF_BOOLEAN)  0;
		ti4_1 = *(EIF_INTEGER_32 *)(Current + O12071[Dtype(Current)-1436]);
		tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN) !tb1) {
		tp1 = *(EIF_POINTER *)(Current + O11932[Dtype(Current)-1436]);
		RTLE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) eif_file_tell((FILE*) tp1);
	}
	RTLE;
	return (EIF_INTEGER_32) 0;
}

/* {FILE}.descriptor */
EIF_INTEGER_32 F1437_14182 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O11932[dtype-1436]);
	Result = (EIF_INTEGER_32) eif_file_fd((FILE*) tp1);
	*(EIF_BOOLEAN *)(Current + O12080[dtype-1436]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
	return Result;
}

/* {FILE}.descriptor_available */
EIF_BOOLEAN F1437_14183 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current + O12080[Dtype(Current)-1436]);
}


/* {FILE}.date */
EIF_INTEGER_32 F1437_14193 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCV(F1437_14329(Current))+ _PTROFF_0_1_0_1_0_0_);
	Result = (EIF_INTEGER_32) eif_file_date((EIF_FILENAME) tp1);
	RTLE;
	return Result;
}

/* {FILE}.retrieved */
EIF_REFERENCE F1437_14195 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(923, 0x00).id, 923, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = RTOSCF(13229,F924_13229, (RTCW(tr1)));
	{
		/* INLINED CODE (ANY.do_nothing) */
		(void) RTCW(tr1);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (FILE.descriptor) */
		ti4_1 = (EIF_INTEGER_32)  0;
		{
		EIF_TYPE_INDEX inlined_dtype = Dtype(Current);
		tp1 = *(EIF_POINTER *)(Current + O11932[inlined_dtype-1436]);
		ti4_1 = (EIF_INTEGER_32) eif_file_fd((FILE*) tp1);
		*(EIF_BOOLEAN *)(Current + O12080[inlined_dtype-1436]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		/* END INLINED CODE */
	}
	ti4_2 = ti4_1;
	Result = (EIF_REFERENCE) eretrieve(ti4_2);
	RTLE;
	return Result;
}

/* {FILE}.count */
EIF_INTEGER_32 F1437_14198 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11190[dtype-921])(Current)) {
		{
			/* INLINED CODE (FILE.is_open_write) */
			tb1 = (EIF_BOOLEAN)  0;
			{
			EIF_TYPE_INDEX inlined_dtype = Dtype(Current);
			ti4_1 = *(EIF_INTEGER_32 *)(Current + O12071[inlined_dtype-1436]);
			ti4_2 = *(EIF_INTEGER_32 *)(Current + O12071[inlined_dtype-1436]);
			ti4_3 = *(EIF_INTEGER_32 *)(Current + O12071[inlined_dtype-1436]);
			ti4_4 = *(EIF_INTEGER_32 *)(Current + O12071[inlined_dtype-1436]);
			tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L)) || (EIF_BOOLEAN)(ti4_2 == ((EIF_INTEGER_32) 4L))) || (EIF_BOOLEAN)(ti4_3 == ((EIF_INTEGER_32) 5L))) || (EIF_BOOLEAN)(ti4_4 == ((EIF_INTEGER_32) 3L)));
			}
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN) !tb1) {
			{
				/* INLINED CODE (FILE.set_buffer) */
				tr1 = RTOSCF(14337,F1437_14337, (Current));
				tr2 = *(EIF_REFERENCE *)(Current + O12015[dtype-1436]);
				tr3 = F1437_14329(Current);
				F836_11814(RTCW(tr1), tr2, tr3);
				/* END INLINED CODE */
			}
			;
			{
				/* INLINED CODE (FILE_INFO.size) */
				ti4_1 = (EIF_INTEGER_32)  0;
				tr1 = RTOSCF(14337,F1437_14337, (Current));
				(void) RTCW(tr1);
				ti4_1 = (EIF_INTEGER_32) eif_file_info((rt_stat_buf*) *(EIF_REFERENCE *)(tr1), (int) ((EIF_INTEGER_32) 6L));
				/* END INLINED CODE */
			}
			Result = ti4_1;
		} else {
			tp1 = *(EIF_POINTER *)(Current + O11932[dtype-1436]);
			Result = (EIF_INTEGER_32) eif_file_size((FILE*) tp1);
			RTLE;
			return (EIF_INTEGER_32) Result;
		}
	}
	RTLE;
	return Result;
}

/* {FILE}.after */
EIF_BOOLEAN F1437_14199 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\0';
	{
		/* INLINED CODE (FILE.is_closed) */
		tb1 = (EIF_BOOLEAN)  0;
		ti4_1 = *(EIF_INTEGER_32 *)(Current + O12071[dtype-1436]);
		tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN) !tb1) {
		tb1 = '\01';
		if (!(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11944[dtype-1437])(Current)) {
			tb1 = (EIF_BOOLEAN)((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R11885[dtype-1415])(Current) == ((EIF_INTEGER_32) 0L));
		}
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {FILE}.before */
EIF_BOOLEAN F1437_14200 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	{
		/* INLINED CODE (FILE.is_closed) */
		tb1 = (EIF_BOOLEAN)  0;
		ti4_1 = *(EIF_INTEGER_32 *)(Current + O12071[Dtype(Current)-1436]);
		tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
		/* END INLINED CODE */
	}
	RTLE;
	return (EIF_BOOLEAN) tb1;
}

/* {FILE}.off */
EIF_BOOLEAN F1437_14201 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	tb1 = '\01';
	if (!(EIF_BOOLEAN)((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R11885[dtype-1415])(Current) == ((EIF_INTEGER_32) 0L))) {
		{
			/* INLINED CODE (FILE.is_closed) */
			tb2 = (EIF_BOOLEAN)  0;
			ti4_1 = *(EIF_INTEGER_32 *)(Current + O12071[dtype-1436]);
			tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
			/* END INLINED CODE */
		}
		tb1 = tb2;
	}
	if (!tb1) {
		Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11944[dtype-1437])(Current);
	}
	RTLE;
	return Result;
}

/* {FILE}.end_of_file */
EIF_BOOLEAN F1437_14202 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current + O11932[Dtype(Current)-1436]);
	return (EIF_BOOLEAN) (EIF_BOOLEAN) EIF_TEST(eif_file_feof((FILE*) tp1));
}

/* {FILE}.exists */
EIF_BOOLEAN F1437_14203 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	{
		/* INLINED CODE (FILE.is_closed) */
		tb1 = (EIF_BOOLEAN)  0;
		ti4_1 = *(EIF_INTEGER_32 *)(Current + O12071[Dtype(Current)-1436]);
		tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
		/* END INLINED CODE */
	}
	if (tb1) {
		tp1 = *(EIF_POINTER *)(RTCV(F1437_14329(Current))+ _PTROFF_0_1_0_1_0_0_);
		Result = (EIF_BOOLEAN) EIF_TEST(eif_file_exists((EIF_FILENAME) tp1));
	} else {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTLE;
	return Result;
}

/* {FILE}.is_readable */
EIF_BOOLEAN F1437_14206 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	{
		/* INLINED CODE (FILE.set_buffer) */
		tr1 = RTOSCF(14337,F1437_14337, (Current));
		tr2 = *(EIF_REFERENCE *)(Current + O12015[Dtype(Current)-1436]);
		tr3 = F1437_14329(Current);
		F836_11814(RTCW(tr1), tr2, tr3);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (FILE_INFO.is_readable) */
		tb1 = (EIF_BOOLEAN)  0;
		tr1 = RTOSCF(14337,F1437_14337, (Current));
		(void) RTCW(tr1);
		tb1 = (EIF_BOOLEAN) EIF_TEST(eif_file_eaccess((rt_stat_buf*) *(EIF_REFERENCE *)(tr1), (int) ((EIF_INTEGER_32) 0L)));
		/* END INLINED CODE */
	}
	Result = tb1;
	RTLE;
	return Result;
}

/* {FILE}.is_writable */
EIF_BOOLEAN F1437_14207 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	{
		/* INLINED CODE (FILE.set_buffer) */
		tr1 = RTOSCF(14337,F1437_14337, (Current));
		tr2 = *(EIF_REFERENCE *)(Current + O12015[Dtype(Current)-1436]);
		tr3 = F1437_14329(Current);
		F836_11814(RTCW(tr1), tr2, tr3);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (FILE_INFO.is_writable) */
		tb1 = (EIF_BOOLEAN)  0;
		tr1 = RTOSCF(14337,F1437_14337, (Current));
		(void) RTCW(tr1);
		tb1 = (EIF_BOOLEAN) EIF_TEST(eif_file_eaccess((rt_stat_buf*) *(EIF_REFERENCE *)(tr1), (int) ((EIF_INTEGER_32) 1L)));
		/* END INLINED CODE */
	}
	Result = tb1;
	RTLE;
	return Result;
}

/* {FILE}.is_creatable */
EIF_BOOLEAN F1437_14209 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCV(F1437_14329(Current))+ _PTROFF_0_1_0_1_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(F1437_14329(Current))+ _LNGOFF_0_1_0_0_);
	Result = (EIF_BOOLEAN) EIF_TEST(eif_file_creatable((EIF_FILENAME) tp1, (EIF_INTEGER) ti4_1));
	RTLE;
	return Result;
}

/* {FILE}.is_plain */
EIF_BOOLEAN F1437_14210 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	{
		/* INLINED CODE (FILE.set_buffer) */
		tr1 = RTOSCF(14337,F1437_14337, (Current));
		tr2 = *(EIF_REFERENCE *)(Current + O12015[Dtype(Current)-1436]);
		tr3 = F1437_14329(Current);
		F836_11814(RTCW(tr1), tr2, tr3);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (FILE_INFO.is_plain) */
		tb1 = (EIF_BOOLEAN)  0;
		tr1 = RTOSCF(14337,F1437_14337, (Current));
		(void) RTCW(tr1);
		ti4_1 = (EIF_INTEGER_32) eif_file_info((rt_stat_buf*) *(EIF_REFERENCE *)(tr1), (int) ((EIF_INTEGER_32) 13L));
		tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L));
		/* END INLINED CODE */
	}
	Result = tb1;
	RTLE;
	return Result;
}

/* {FILE}.is_device */
EIF_BOOLEAN F1437_14211 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	{
		/* INLINED CODE (FILE.set_buffer) */
		tr1 = RTOSCF(14337,F1437_14337, (Current));
		tr2 = *(EIF_REFERENCE *)(Current + O12015[Dtype(Current)-1436]);
		tr3 = F1437_14329(Current);
		F836_11814(RTCW(tr1), tr2, tr3);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (FILE_INFO.is_device) */
		tb1 = (EIF_BOOLEAN)  0;
		tr1 = RTOSCF(14337,F1437_14337, (Current));
		(void) RTCW(tr1);
		ti4_1 = (EIF_INTEGER_32) eif_file_info((rt_stat_buf*) *(EIF_REFERENCE *)(tr1), (int) ((EIF_INTEGER_32) 14L));
		tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L));
		/* END INLINED CODE */
	}
	Result = tb1;
	RTLE;
	return Result;
}

/* {FILE}.is_directory */
EIF_BOOLEAN F1437_14212 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	{
		/* INLINED CODE (FILE.set_buffer) */
		tr1 = RTOSCF(14337,F1437_14337, (Current));
		tr2 = *(EIF_REFERENCE *)(Current + O12015[Dtype(Current)-1436]);
		tr3 = F1437_14329(Current);
		F836_11814(RTCW(tr1), tr2, tr3);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (FILE_INFO.is_directory) */
		tb1 = (EIF_BOOLEAN)  0;
		tr1 = RTOSCF(14337,F1437_14337, (Current));
		(void) RTCW(tr1);
		ti4_1 = (EIF_INTEGER_32) eif_file_info((rt_stat_buf*) *(EIF_REFERENCE *)(tr1), (int) ((EIF_INTEGER_32) 12L));
		tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L));
		/* END INLINED CODE */
	}
	Result = tb1;
	RTLE;
	return Result;
}

/* {FILE}.is_access_readable */
EIF_BOOLEAN F1437_14222 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	{
		/* INLINED CODE (FILE.set_buffer) */
		tr1 = RTOSCF(14337,F1437_14337, (Current));
		tr2 = *(EIF_REFERENCE *)(Current + O12015[Dtype(Current)-1436]);
		tr3 = F1437_14329(Current);
		F836_11814(RTCW(tr1), tr2, tr3);
		/* END INLINED CODE */
	}
	;
	Result = F836_11806(RTCV(RTOSCF(14337,F1437_14337, (Current))));
	RTLE;
	return Result;
}

/* {FILE}.file_readable */
EIF_BOOLEAN F1437_14226 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\0';
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O12071[dtype-1436]) >= ((EIF_INTEGER_32) 4L)) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O12071[dtype-1436]) == ((EIF_INTEGER_32) 1L)))) {
		{
			/* INLINED CODE (SEQUENCE.readable) */
			tb1 = (EIF_BOOLEAN)  0;
			tb1 = F1437_14201(Current);
			tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN) !tb1;
			/* END INLINED CODE */
		}
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {FILE}.is_closed */
EIF_BOOLEAN F1437_14227 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O12071[Dtype(Current)-1436]) == ((EIF_INTEGER_32) 0L));
}

/* {FILE}.is_open_read */
EIF_BOOLEAN F1437_14228 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O12071[dtype-1436]) == ((EIF_INTEGER_32) 1L)) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O12071[dtype-1436]) == ((EIF_INTEGER_32) 4L))) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O12071[dtype-1436]) == ((EIF_INTEGER_32) 5L)));
}

/* {FILE}.is_open_write */
EIF_BOOLEAN F1437_14229 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O12071[dtype-1436]) == ((EIF_INTEGER_32) 2L)) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O12071[dtype-1436]) == ((EIF_INTEGER_32) 4L))) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O12071[dtype-1436]) == ((EIF_INTEGER_32) 5L))) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O12071[dtype-1436]) == ((EIF_INTEGER_32) 3L)));
}

/* {FILE}.is_open_append */
EIF_BOOLEAN F1437_14230 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O12071[dtype-1436]) == ((EIF_INTEGER_32) 3L)) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O12071[dtype-1436]) == ((EIF_INTEGER_32) 5L)));
}

/* {FILE}.extendible */
EIF_BOOLEAN F1437_14232 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O12071[Dtype(Current)-1436]) >= ((EIF_INTEGER_32) 2L));
}

/* {FILE}.open_read */
void F1437_14238 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCV(F1437_14329(Current))+ _PTROFF_0_1_0_1_0_0_);
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32)) R12013[dtype-1437])(Current, tp1, ((EIF_INTEGER_32) 0L));
	*(EIF_POINTER *)(Current + O11932[dtype-1436]) = (EIF_POINTER) tp1;
	*(EIF_INTEGER_32 *)(Current + O12071[dtype-1436]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTLE;
}

/* {FILE}.open_write */
void F1437_14239 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCV(F1437_14329(Current))+ _PTROFF_0_1_0_1_0_0_);
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32)) R12013[dtype-1437])(Current, tp1, ((EIF_INTEGER_32) 1L));
	*(EIF_POINTER *)(Current + O11932[dtype-1436]) = (EIF_POINTER) tp1;
	*(EIF_INTEGER_32 *)(Current + O12071[dtype-1436]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	RTLE;
}

/* {FILE}.open_append */
void F1437_14240 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCV(F1437_14329(Current))+ _PTROFF_0_1_0_1_0_0_);
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32)) R12013[dtype-1437])(Current, tp1, ((EIF_INTEGER_32) 2L));
	*(EIF_POINTER *)(Current + O11932[dtype-1436]) = (EIF_POINTER) tp1;
	*(EIF_INTEGER_32 *)(Current + O12071[dtype-1436]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	RTLE;
}

/* {FILE}.open_read_write */
void F1437_14241 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCV(F1437_14329(Current))+ _PTROFF_0_1_0_1_0_0_);
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32)) R12013[dtype-1437])(Current, tp1, ((EIF_INTEGER_32) 3L));
	*(EIF_POINTER *)(Current + O11932[dtype-1436]) = (EIF_POINTER) tp1;
	*(EIF_INTEGER_32 *)(Current + O12071[dtype-1436]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	RTLE;
}

/* {FILE}.create_read_write */
void F1437_14242 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCV(F1437_14329(Current))+ _PTROFF_0_1_0_1_0_0_);
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32)) R12013[dtype-1437])(Current, tp1, ((EIF_INTEGER_32) 4L));
	*(EIF_POINTER *)(Current + O11932[dtype-1436]) = (EIF_POINTER) tp1;
	*(EIF_INTEGER_32 *)(Current + O12071[dtype-1436]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	RTLE;
}

/* {FILE}.close */
void F1437_14255 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER)) R12014[dtype-1437])(Current, *(EIF_POINTER *)(Current + O11932[dtype-1436]));
	*(EIF_INTEGER_32 *)(Current + O12071[dtype-1436]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	*(EIF_POINTER *)(Current + O11932[dtype-1436]) = (EIF_POINTER) tp2;
	*(EIF_BOOLEAN *)(Current + O12080[dtype-1436]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {FILE}.start */
void F1437_14256 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current + O11932[Dtype(Current)-1436]);
	eif_file_go((FILE*) tp1, (EIF_INTEGER) ((EIF_INTEGER_32) 0L));
}

/* {FILE}.forth */
void F1437_14258 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_CHARACTER_8 tc1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O11932[dtype-1436]);
	eif_file_move((FILE*) tp1, (EIF_INTEGER) ((EIF_INTEGER_32) 1L));
	tp1 = *(EIF_POINTER *)(Current + O11932[dtype-1436]);
	tc1 = (EIF_CHARACTER_8) eif_file_gc((FILE*) tp1);
	eif_do_nothing_value.it_c1 = tc1;
	if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11944[dtype-1437])(Current)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11791[dtype-1437])(Current);
	}
	RTLE;
}

/* {FILE}.back */
void F1437_14259 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current + O11932[Dtype(Current)-1436]);
	eif_file_move((FILE*) tp1, (EIF_INTEGER) ((EIF_INTEGER_32) -1L));
}

/* {FILE}.go */
void F1437_14261 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current + O11932[Dtype(Current)-1436]);
	eif_file_go((FILE*) tp1, (EIF_INTEGER) arg1);
}

/* {FILE}.next_line */
void F1437_14263 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current + O11932[Dtype(Current)-1436]);
	eif_file_tnil((FILE*) tp1);
}

/* {FILE}.new_cursor */
EIF_REFERENCE F1437_14264 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(952, 0x00).id, 952, _OBJSIZ_0_1_0_0_0_1_0_0_);
	tr1 = F1437_14329(Current);
	F953_13328(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {FILE}.extend */
void F1437_14265 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R11205[Dtype(Current)-1437])(Current, arg1);
}

/* {FILE}.flush */
void F1437_14266 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current + O11932[Dtype(Current)-1436]);
	eif_file_flush((FILE*) tp1);
}

/* {FILE}.put_string */
void F1437_14277 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,loc2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O17115[Dtype(arg1)-2245]);
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
		loc2 = *(EIF_REFERENCE *)(RTCW(arg1));
		tp1 = *(EIF_POINTER *)(Current + O11932[Dtype(Current)-1436]);
		eif_file_ps((FILE*) tp1, (char*) loc2, (EIF_INTEGER) loc1);
	}
	RTLE;
}

/* {FILE}.put_managed_pointer */
void F1437_14279 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O11932[Dtype(Current)-1436]);
	tp2 = *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_0_1_0_1_0_0_);
	tp2 = RTPOF(tp2,arg2);
	eif_file_ps((FILE*) tp1, (char*) tp2, (EIF_INTEGER) arg3);
	RTLE;
}

/* {FILE}.put_character */
void F1437_14280 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current + O11932[Dtype(Current)-1436]);
	eif_file_pc((FILE*) tp1, (EIF_CHARACTER) arg1);
}

/* {FILE}.put_new_line */
void F1437_14282 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current + O11932[Dtype(Current)-1436]);
	eif_file_tnwl((FILE*) tp1);
}

/* {FILE}.new_line */
void F1437_14283 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current + O11932[Dtype(Current)-1436]);
	eif_file_tnwl((FILE*) tp1);
}

/* {FILE}.rename_path */
void F1437_14289 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = F2014_18992(RTCW(arg1));
	tp1 = *(EIF_POINTER *)(RTCV(F1437_14329(Current))+ _PTROFF_0_1_0_1_0_0_);
	tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	eif_file_rename((EIF_FILENAME) tp1, (EIF_FILENAME) tp2);
	{
		/* INLINED CODE (FILE.set_path) */
		{
		EIF_TYPE_INDEX inlined_dtype = Dtype(Current);
		tr1 = F2014_18990(RTCW(arg1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O12015[inlined_dtype-1436]) = (EIF_REFERENCE) tr1;
		tr1 = F2014_18992(RTCW(arg1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O12017[inlined_dtype-1436]) = (EIF_REFERENCE) tr1;
		}
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {FILE}.independent_store */
void F1437_14299 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	{
		/* INLINED CODE (FILE.descriptor) */
		ti4_1 = (EIF_INTEGER_32)  0;
		{
		EIF_TYPE_INDEX inlined_dtype = Dtype(Current);
		tp1 = *(EIF_POINTER *)(Current + O11932[inlined_dtype-1436]);
		ti4_1 = (EIF_INTEGER_32) eif_file_fd((FILE*) tp1);
		*(EIF_BOOLEAN *)(Current + O12080[inlined_dtype-1436]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		/* END INLINED CODE */
	}
	ti4_2 = ti4_1;
	sstore((EIF_INTEGER) ti4_2, (EIF_REFERENCE) arg1);
	RTLE;
}

/* {FILE}.delete */
void F1437_14301 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCV(F1437_14329(Current))+ _PTROFF_0_1_0_1_0_0_);
	eif_file_unlink((EIF_FILENAME) tp1);
	RTLE;
}

/* {FILE}.reset */
void F1437_14302 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	{
		/* INLINED CODE (FILE.set_name) */
		{
		EIF_TYPE_INDEX inlined_dtype = Dtype(Current);
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current + O12015[inlined_dtype-1436]) = (EIF_REFERENCE) arg1;
		tr1 = RTOSCF(14337,F1437_14337, (Current));
		tr1 = F836_11784(RTCW(tr1), arg1, *(EIF_REFERENCE *)(Current + O12017[inlined_dtype-1436]));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O12017[inlined_dtype-1436]) = (EIF_REFERENCE) tr1;
		}
		/* END INLINED CODE */
	}
	;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O12071[dtype-1436]) != ((EIF_INTEGER_32) 0L))) {
		{
			/* INLINED CODE (FILE.close) */
			{
			EIF_TYPE_INDEX inlined_dtype = Dtype(Current);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER)) R12014[inlined_dtype-1437])(Current, *(EIF_POINTER *)(Current + O11932[inlined_dtype-1436]));
			*(EIF_INTEGER_32 *)(Current + O12071[inlined_dtype-1436]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			tp1 = F1_33(Current);
			*(EIF_POINTER *)(Current + O11932[inlined_dtype-1436]) = (EIF_POINTER) tp1;
			*(EIF_BOOLEAN *)(Current + O12080[inlined_dtype-1436]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
			/* END INLINED CODE */
		}
		;
	}
	*(EIF_INTEGER_32 *)(Current + O11175[dtype-920]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_REAL_32 *)(Current + O11185[dtype-920]) = (EIF_REAL_32) (EIF_REAL_32) (EIF_REAL_64) 0.0;
	*(EIF_REAL_64 *)(Current + O11187[dtype-920]) = (EIF_REAL_64) (EIF_REAL_64) 0.0;
	*(EIF_CHARACTER_8 *)(Current + O11173[dtype-920]) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\000';
	tr1 = *(EIF_REFERENCE *)(Current + O11174[dtype-920]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R17080[Dtype(RTCW(tr1))-2247])(tr1);
	RTLE;
}

/* {FILE}.reset_path */
void F1437_14303 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	{
		/* INLINED CODE (FILE.set_path) */
		{
		EIF_TYPE_INDEX inlined_dtype = Dtype(Current);
		tr1 = F2014_18990(RTCW(arg1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O12015[inlined_dtype-1436]) = (EIF_REFERENCE) tr1;
		tr1 = F2014_18992(RTCW(arg1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O12017[inlined_dtype-1436]) = (EIF_REFERENCE) tr1;
		}
		/* END INLINED CODE */
	}
	;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O12071[dtype-1436]) != ((EIF_INTEGER_32) 0L))) {
		{
			/* INLINED CODE (FILE.close) */
			{
			EIF_TYPE_INDEX inlined_dtype = Dtype(Current);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER)) R12014[inlined_dtype-1437])(Current, *(EIF_POINTER *)(Current + O11932[inlined_dtype-1436]));
			*(EIF_INTEGER_32 *)(Current + O12071[inlined_dtype-1436]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			tp1 = F1_33(Current);
			*(EIF_POINTER *)(Current + O11932[inlined_dtype-1436]) = (EIF_POINTER) tp1;
			*(EIF_BOOLEAN *)(Current + O12080[inlined_dtype-1436]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
			/* END INLINED CODE */
		}
		;
	}
	*(EIF_INTEGER_32 *)(Current + O11175[dtype-920]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_REAL_32 *)(Current + O11185[dtype-920]) = (EIF_REAL_32) (EIF_REAL_32) (EIF_REAL_64) 0.0;
	*(EIF_REAL_64 *)(Current + O11187[dtype-920]) = (EIF_REAL_64) (EIF_REAL_64) 0.0;
	*(EIF_CHARACTER_8 *)(Current + O11173[dtype-920]) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\000';
	tr1 = *(EIF_REFERENCE *)(Current + O11174[dtype-920]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R17080[Dtype(RTCW(tr1))-2247])(tr1);
	RTLE;
}

/* {FILE}.read_character */
void F1437_14310 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_CHARACTER_8 tc1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O11932[dtype-1436]);
	tc1 = (EIF_CHARACTER_8) eif_file_gc((FILE*) tp1);
	*(EIF_CHARACTER_8 *)(Current + O11173[dtype-920]) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {FILE}.read_line */
void F1437_14314 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLIU(3);
	
	RTGC;
	loc5 = *(EIF_REFERENCE *)(Current + O11174[dtype-920]);
	loc3 = *(EIF_REFERENCE *)(RTCW(loc5));
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R16993[Dtype(RTCW(loc5))-2246])(loc5);
	for (;;) {
		if (loc4) break;
		tp1 = *(EIF_POINTER *)(Current + O11932[dtype-1436]);
		loc2 += (EIF_INTEGER_32) eif_file_gs((FILE*) tp1, (char*) loc3, (EIF_INTEGER) loc1, (EIF_INTEGER) loc2);
		if ((EIF_BOOLEAN) (loc2 > loc1)) {
			{
				/* INLINED CODE (STRING_8.set_count) */
				(void) RTCW(loc5);
				*(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_2_) = (EIF_INTEGER_32) loc1;
				F2245_21851(loc5);
				/* END INLINED CODE */
			}
			;
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 2048L))) {
				{
					/* INLINED CODE (STRING_8.grow) */
					ti4_1 = (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1024L));
					(void) RTCW(loc5);
					ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R16993[Dtype(loc5)-2246])(loc5);
					if ((EIF_BOOLEAN) (ti4_1 > ti4_2)) {
						F2248_22028(loc5, ti4_1);
					}
					/* END INLINED CODE */
				}
				;
			} else {
				{
					/* INLINED CODE (RESIZABLE.automatic_grow) */
					(void) RTCW(loc5);
					ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R11886[Dtype(loc5)-1415])(loc5);
					ti4_2 = F1386_14080(loc5);
					F2248_22029(loc5, (EIF_INTEGER_32) (ti4_1 + ti4_2));
					/* END INLINED CODE */
				}
				;
			}
			loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R16993[Dtype(RTCW(loc5))-2246])(loc5);
			loc2--;
			loc3 = *(EIF_REFERENCE *)(RTCW(loc5));
		} else {
			{
				/* INLINED CODE (STRING_8.set_count) */
				(void) RTCW(loc5);
				*(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_2_) = (EIF_INTEGER_32) loc2;
				F2245_21851(loc5);
				/* END INLINED CODE */
			}
			;
			loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	RTLE;
}

/* {FILE}.read_line_thread_aware */
void F1437_14316 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,loc7);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc4 = *(EIF_REFERENCE *)(Current + O11174[dtype-920]);
	loc7 = RTOSCF(14338,F1437_14338, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R17080[Dtype(RTCW(loc4))-2247])(loc4);
	{
		/* INLINED CODE (C_STRING.capacity) */
		ti4_1 = (EIF_INTEGER_32)  0;
		(void) RTCW(loc7);
		tr1 = *(EIF_REFERENCE *)(loc7);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_0_1_0_0_);
		/* END INLINED CODE */
	}
	loc1 = ti4_1;
	for (;;) {
		if (loc3) break;
		tp1 = *(EIF_POINTER *)(Current + O11932[dtype-1436]);
		{
			/* INLINED CODE (C_STRING.item) */
			tp2 = (EIF_POINTER)  0;
			(void) RTCW(loc7);
			tr1 = *(EIF_REFERENCE *)(loc7);
			tp2 = *(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_0_1_0_1_0_0_);
			/* END INLINED CODE */
		}
		tp2 = tp2;
		loc2 = (EIF_INTEGER_32) eif_file_gs((FILE*) tp1, (char*) tp2, (EIF_INTEGER) loc1, (EIF_INTEGER) ((EIF_INTEGER_32) 0L));
		loc5 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_1_0_2_);
		loc6 = eif_min_int32 (loc2,loc1);
		loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 + loc6);
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc2 <= loc1);
		{
			/* INLINED CODE (STRING_8.grow) */
			(void) RTCW(loc4);
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R16993[Dtype(loc4)-2246])(loc4);
			if ((EIF_BOOLEAN) (loc6 > ti4_1)) {
				F2248_22028(loc4, loc6);
			}
			/* END INLINED CODE */
		}
		;
		{
			/* INLINED CODE (STRING_8.set_count) */
			(void) RTCW(loc4);
			*(EIF_INTEGER_32 *)(loc4+ _LNGOFF_1_1_0_2_) = (EIF_INTEGER_32) loc6;
			F2245_21851(loc4);
			/* END INLINED CODE */
		}
		;
		ti4_1 = eif_min_int32 (loc2,loc1);
		F920_13020(RTCW(loc7), loc4, ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 1L)), ti4_1);
	}
	RTLE;
}

/* {FILE}.read_stream */
void F1437_14317 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTGC;
	loc2 = *(EIF_REFERENCE *)(Current + O11174[dtype-920]);
	{
		/* INLINED CODE (STRING_8.grow) */
		(void) RTCW(loc2);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R16993[Dtype(loc2)-2246])(loc2);
		if ((EIF_BOOLEAN) (arg1 > ti4_1)) {
			F2248_22028(loc2, arg1);
		}
		/* END INLINED CODE */
	}
	;
	loc1 = *(EIF_REFERENCE *)(RTCW(loc2));
	tp1 = *(EIF_POINTER *)(Current + O11932[dtype-1436]);
	ti4_1 = (EIF_INTEGER_32) eif_file_gss((FILE*) tp1, (char*) loc1, (EIF_INTEGER) arg1);
	{
		/* INLINED CODE (STRING_8.set_count) */
		(void) RTCW(loc2);
		*(EIF_INTEGER_32 *)(loc2+ _LNGOFF_1_1_0_2_) = (EIF_INTEGER_32) ti4_1;
		F2245_21851(loc2);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {FILE}.read_to_managed_pointer */
void F1437_14320 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O11932[dtype-1436]);
	tp2 = *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_0_1_0_1_0_0_);
	tp2 = RTPOF(tp2,arg2);
	ti4_1 = (EIF_INTEGER_32) eif_file_gss((FILE*) tp1, (char*) tp2, (EIF_INTEGER) arg3);
	*(EIF_INTEGER_32 *)(Current + O11189[dtype-920]) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

/* {FILE}.copy_to */
void F1437_14325 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R11885[dtype-1415])(Current);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 51200L);
	loc5 = *(EIF_REFERENCE *)(Current + O11174[dtype-920]);
	tr1 = RTLNSMART(eif_new_type(2247, 0).id);
	F2246_21883(RTCW(tr1), loc1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O11174[dtype-920]) = (EIF_REFERENCE) tr1;
	{
		/* INLINED CODE (FILE.position) */
		ti4_1 = (EIF_INTEGER_32)  0;
		tb1 = F1437_14227(Current);
		if ((EIF_BOOLEAN) !tb1) {
			tp1 = *(EIF_POINTER *)(Current + O11932[dtype-1436]);
			ti4_1 = (EIF_INTEGER_32) eif_file_tell((FILE*) tp1);
		}
		/* END INLINED CODE */
	}
	loc4 = ti4_1;
	if ((EIF_BOOLEAN)(loc4 != ((EIF_INTEGER_32) 0L))) {
		{
			/* INLINED CODE (FILE.go) */
			tp1 = *(EIF_POINTER *)(Current + O11932[dtype-1436]);
			eif_file_go((FILE*) tp1, (EIF_INTEGER) ((EIF_INTEGER_32) 0L));
			/* END INLINED CODE */
		}
		;
	}
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 >= loc3)) break;
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R11246[dtype-1437])(Current, loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11203[Dtype(RTCW(arg1))-1437])(arg1, *(EIF_REFERENCE *)(Current + O11174[dtype-920]));
		loc2 += loc1;
	}
	if ((EIF_BOOLEAN)(loc4 != ((EIF_INTEGER_32) 0L))) {
		{
			/* INLINED CODE (FILE.go) */
			tp1 = *(EIF_POINTER *)(Current + O11932[dtype-1436]);
			eif_file_go((FILE*) tp1, (EIF_INTEGER) loc4);
			/* END INLINED CODE */
		}
		;
	}
	RTAR(Current, loc5);
	*(EIF_REFERENCE *)(Current + O11174[dtype-920]) = (EIF_REFERENCE) loc5;
	RTLE;
}

/* {FILE}.file_open */
EIF_POINTER F1437_14326 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) eif_file_open((EIF_FILENAME) arg1, (int) arg2);
	
	return Result;
}

/* {FILE}.file_close */
void F1437_14327 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	eif_file_close((FILE*) arg1);
	
}

/* {FILE}.internal_name_pointer */
EIF_REFERENCE F1437_14329 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O12017[Dtype(Current)-1436]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		RTCT0("internal_name_pointer_set", EX_CHECK);
			RTCF0;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {FILE}.set_name */
void F1437_14331 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O12015[dtype-1436]) = (EIF_REFERENCE) arg1;
	tr1 = RTOSCF(14337,F1437_14337, (Current));
	tr1 = F836_11784(RTCW(tr1), arg1, *(EIF_REFERENCE *)(Current + O12017[dtype-1436]));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O12017[dtype-1436]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {FILE}.set_path */
void F1437_14332 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F2014_18990(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O12015[dtype-1436]) = (EIF_REFERENCE) tr1;
	tr1 = F2014_18992(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O12017[dtype-1436]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {FILE}.true_string */
static EIF_REFERENCE F1437_14335_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (14335);
#define Result RTOSR(14335)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("True",4,1416787301);
	RTOSE (14335);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1437_14335 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14335,F1437_14335_body,(Current));
}

/* {FILE}.false_string */
static EIF_REFERENCE F1437_14336_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (14336);
#define Result RTOSR(14336)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("False",5,1635034981);
	RTOSE (14336);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1437_14336 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14336,F1437_14336_body,(Current));
}

/* {FILE}.buffered_file_info */
static EIF_REFERENCE F1437_14337_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (14337);
#define Result RTOSR(14337)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(835, 0x00).id, 835, _OBJSIZ_3_2_0_0_0_0_0_0_);
	F836_11767(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (14337);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1437_14337 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14337,F1437_14337_body,(Current));
}

/* {FILE}.read_data_buffer */
static EIF_REFERENCE F1437_14338_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (14338);
#define Result RTOSR(14338)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(919, 0x00).id, 919, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F920_13005(RTCW(tr1), ((EIF_INTEGER_32) 256L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (14338);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1437_14338 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14338,F1437_14338_body,(Current));
}

/* {FILE}.set_buffer */
void F1437_14339 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(14337,F1437_14337, (Current));
	tr2 = *(EIF_REFERENCE *)(Current + O12015[Dtype(Current)-1436]);
	tr3 = F1437_14329(Current);
	{
		/* INLINED CODE (FILE_INFO.fast_update) */
		(void) RTCW(tr1);
		RTAR(tr1, tr2);
		*(EIF_REFERENCE *)(tr1 + _REFACS_1_) = (EIF_REFERENCE) tr2;
		RTAR(tr1, tr3);
		*(EIF_REFERENCE *)(tr1 + _REFACS_2_) = (EIF_REFERENCE) tr3;
		tp1 = *(EIF_POINTER *)(RTCW(tr3)+ _PTROFF_0_1_0_1_0_0_);
		tb1 = *(EIF_BOOLEAN *)(tr1+ _CHROFF_3_1_);
		ti4_1 = (EIF_INTEGER_32) eif_file_stat((EIF_FILENAME) tp1, (rt_stat_buf*) *(EIF_REFERENCE *)(tr1), (int) tb1);
		*(EIF_BOOLEAN *)(tr1+ _CHROFF_3_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {FILE}.file_unlink */
void F1437_14341 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	eif_file_unlink((EIF_FILENAME) arg1);
	
}

/* {FILE}.file_flush */
void F1437_14344 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	eif_file_flush((FILE*) arg1);
	
}

/* {FILE}.file_fd */
EIF_INTEGER_32 F1437_14345 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) eif_file_fd((FILE*) arg1);
	
	return Result;
}

/* {FILE}.file_gc */
EIF_CHARACTER_8 F1437_14346 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	
	
	EIF_ENTER_C;Result = (EIF_CHARACTER_8) eif_file_gc((FILE*) arg1);
	
	EIF_EXIT_C;
	RTGC;
	return Result;
}

/* {FILE}.file_gs */
EIF_INTEGER_32 F1437_14347 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) eif_file_gs((FILE*) arg1, (char*) arg2, (EIF_INTEGER) arg3, (EIF_INTEGER) arg4);
	
	return Result;
}

/* {FILE}.file_gss */
EIF_INTEGER_32 F1437_14348 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) eif_file_gss((FILE*) arg1, (char*) arg2, (EIF_INTEGER) arg3);
	
	return Result;
}

/* {FILE}.file_gs_ta */
EIF_INTEGER_32 F1437_14350 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	EIF_ENTER_C;Result = (EIF_INTEGER_32) eif_file_gs((FILE*) arg1, (char*) arg2, (EIF_INTEGER) arg3, (EIF_INTEGER) arg4);
	
	EIF_EXIT_C;
	RTGC;
	return Result;
}

/* {FILE}.file_size */
EIF_INTEGER_32 F1437_14354 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) eif_file_size((FILE*) arg1);
	
	return Result;
}

/* {FILE}.file_tnil */
void F1437_14355 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	eif_file_tnil((FILE*) arg1);
	
}

/* {FILE}.file_tell */
EIF_INTEGER_32 F1437_14356 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) eif_file_tell((FILE*) arg1);
	
	return Result;
}

/* {FILE}.file_rename */
void F1437_14358 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	eif_file_rename((EIF_FILENAME) arg1, (EIF_FILENAME) arg2);
	
}

/* {FILE}.file_tnwl */
void F1437_14364 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	EIF_ENTER_C;eif_file_tnwl((FILE*) arg1);
	
	EIF_EXIT_C;
	RTGC;
}

/* {FILE}.file_ps */
void F1437_14366 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	
	EIF_ENTER_C;eif_file_ps((FILE*) arg1, (char*) arg2, (EIF_INTEGER) arg3);
	
	EIF_EXIT_C;
	RTGC;
}

/* {FILE}.file_pc */
void F1437_14367 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_CHARACTER_8 arg2)
{
	GTCX
	
	eif_file_pc((FILE*) arg1, (EIF_CHARACTER) arg2);
	
}

/* {FILE}.file_go */
void F1437_14368 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	eif_file_go((FILE*) arg1, (EIF_INTEGER) arg2);
	
}

/* {FILE}.file_move */
void F1437_14370 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	eif_file_move((FILE*) arg1, (EIF_INTEGER) arg2);
	
}

/* {FILE}.file_feof */
EIF_BOOLEAN F1437_14371 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(eif_file_feof((FILE*) arg1));
	
	return Result;
}

/* {FILE}.file_exists */
EIF_BOOLEAN F1437_14372 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(eif_file_exists((EIF_FILENAME) arg1));
	
	return Result;
}

/* {FILE}.file_creatable */
EIF_BOOLEAN F1437_14375 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(eif_file_creatable((EIF_FILENAME) arg1, (EIF_INTEGER) arg2));
	
	return Result;
}

/* {FILE}.c_retrieved */
EIF_REFERENCE F1437_14376 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	Result = (EIF_REFERENCE) eretrieve(arg1);
	
	RTLE;
	return Result;
}

/* {FILE}.c_independent_store */
void F1437_14379 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_POINTER arg2)
{
	GTCX
	
	sstore((EIF_INTEGER) arg1, (EIF_REFERENCE) arg2);
	
}

/* {FILE}.eif_file_date */
EIF_INTEGER_32 F1437_14380 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) eif_file_date((EIF_FILENAME) arg1);
	
	return Result;
}

/* {FILE}.set_read_mode */
void F1437_14394 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O12071[Dtype(Current)-1436]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
}

/* {FILE}.set_write_mode */
void F1437_14395 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O12071[Dtype(Current)-1436]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
}

void EIF_Minit814 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
