/*
 * Code for class IRON_INSTALLATION_API
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir800.h"
#include "eif_dir.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_INSTALLATION_API}.initialize */
void F972_13377 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		/* INLINED CODE (IRON_API.initialize) */
		/* END INLINED CODE */
	}
	;
	tr1 = RTLNSMART(eif_new_type(30, 0).id);
	F31_270(RTCW(tr1), *(EIF_REFERENCE *)(Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {IRON_INSTALLATION_API}.is_up_to_date */
EIF_BOOLEAN F972_13383 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	ti4_2 = F31_272(RTCW(tr1));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
	RTLE;
	return Result;
}

/* {IRON_INSTALLATION_API}.installed_package */
EIF_REFERENCE F972_13385 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	if (arg2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		Result = F31_275(RTCW(tr1), arg1);
	} else {
		tr1 = F972_13386(Current);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11537[Dtype(loc1)-991])(loc1);
			for (;;) {
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11319[Dtype(loc2)-941])(loc2);
				if (tb1) break;
				if ((EIF_BOOLEAN)(Result != NULL)) break;
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11318[Dtype(loc2)-941])(loc2);
				tb2 = F1919_18202(RTCW(tr1), arg1);
				if (tb2) {
					Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11318[Dtype(loc2)-941])(loc2);
				}
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R11320[Dtype(loc2)-941])(loc2);
			}
		}
	}
	RTLE;
	return Result;
}

/* {IRON_INSTALLATION_API}.installed_packages */
EIF_REFERENCE F972_13386 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTGC;
	{
		/* INLINED CODE (IRON_INSTALLATION_API.is_up_to_date) */
		tb1 = (EIF_BOOLEAN)  0;
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		ti4_2 = F31_272(RTCW(tr1));
		tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN) !tb1) {
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) NULL;
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) NULL;
	}
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = F31_274(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		ti4_1 = F31_272(RTCW(tr1));
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_0_0_0_) = (EIF_INTEGER_32) ti4_1;
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) loc1;
	}
	RTLE;
	return (EIF_REFERENCE) loc1;
}

/* {IRON_INSTALLATION_API}.available_packages */
EIF_REFERENCE F972_13388 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTGC;
	{
		/* INLINED CODE (IRON_INSTALLATION_API.is_up_to_date) */
		tb1 = (EIF_BOOLEAN)  0;
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		ti4_2 = F31_272(RTCW(tr1));
		tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN) !tb1) {
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) NULL;
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) NULL;
	}
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = F31_276(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		ti4_1 = F31_272(RTCW(tr1));
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_0_0_0_) = (EIF_INTEGER_32) ti4_1;
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) loc1;
	}
	RTLE;
	return (EIF_REFERENCE) loc1;
}

/* {IRON_INSTALLATION_API}.available_package_name_for_uri */
EIF_REFERENCE F972_13398 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(16);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,loc9);
	RTLR(3,Current);
	RTLR(4,loc8);
	RTLR(5,loc7);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,loc10);
	RTLR(9,loc6);
	RTLR(10,Result);
	RTLR(11,loc1);
	RTLR(12,loc3);
	RTLR(13,loc4);
	RTLR(14,loc5);
	RTLR(15,loc11);
	RTLIU(16);
	
	RTGC;
	tb1 = '\01';
	tb2 = '\01';
	tr1 = RTMS_EX_H("http://",7,769736239);
	tb3 = F2243_21800(RTCW(arg1), tr1);
	if (!tb3) {
		tr1 = RTMS_EX_H("https://",8,441357103);
		tb3 = F2243_21800(RTCW(arg1), tr1);
		tb2 = tb3;
	}
	if (!tb2) {
		tr1 = RTMS_EX_H("file://",7,1704345391);
		tb2 = F2243_21800(RTCW(arg1), tr1);
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = F972_13388(Current);
		loc9 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11537[Dtype(RTCW(tr1))-991])(tr1);
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11319[Dtype(loc9)-941])(loc9);
			if (tb1) break;
			if ((EIF_BOOLEAN)(Result != NULL)) break;
			loc8 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11318[Dtype(loc9)-941])(loc9);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc8));
			{
				/* INLINED CODE (IRON_REPOSITORY.location_string) */
				tr2 = (EIF_REFERENCE)  0;
				(void) RTCW(tr1);
				tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11641[Dtype(tr1)-1916])(tr1);
				tr2 = F3225_38249(RTCW(tr3));
				/* END INLINED CODE */
			}
			loc7 = tr2;
			tb2 = F2243_21800(RTCW(arg1), loc7);
			if (tb2) {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc8) + _REFACS_5_);
				loc10 = F1566_14926(RTCW(tr1));
				for (;;) {
					{
						/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.after) */
						tb2 = (EIF_BOOLEAN)  0;
						(void) loc10;
						ti4_1 = *(EIF_INTEGER_32 *)(loc10+ _LNGOFF_2_0_0_0_);
						ti4_2 = *(EIF_INTEGER_32 *)(loc10+ _LNGOFF_2_0_0_1_);
						tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ti4_2);
						/* END INLINED CODE */
					}
					tb2 = tb2;
					if (tb2) break;
					if ((EIF_BOOLEAN)(Result != NULL)) break;
					{
						/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.item) */
						tr1 = (EIF_REFERENCE)  0;
						(void) loc10;
						tr2 = *(EIF_REFERENCE *)(loc10);
						tr1 = 
							/* INLINED CODE (SPECIAL.item) */
							*((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(loc10+ _LNGOFF_2_0_0_0_)))
							/* END INLINED CODE */;
						/* END INLINED CODE */
					}
					tr1 = tr1;
					loc6 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R17105[Dtype(RTCW(loc7))-2246])(loc7, tr1);
					tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R16998[Dtype(RTCW(arg1))-2246])(arg1, loc6);
					if (tb3) {
						Result = F1919_18205(RTCW(loc8));
					}
					{
						/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.forth) */
						(void) loc10;
						(*(EIF_INTEGER_32 *)(loc10+ _LNGOFF_2_0_0_0_))++;
						/* END INLINED CODE */
					}
					;
				}
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R11320[Dtype(loc9)-941])(loc9);
		}
	} else {
		tr1 = RTMS_EX_H("iron:",5,1920711738);
		tb3 = F2243_21800(RTCW(arg1), tr1);
		if (tb3) {
			loc1 = RTLNS(eif_new_type(3226, 0x00).id, 3226, _OBJSIZ_6_2_0_1_0_0_0_0_);
			F3227_38289(RTCW(loc1), arg1);
			loc3 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_3_);
			loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R17093[Dtype(RTCW(loc3))-2246])(loc3, (EIF_CHARACTER_8) ':', ((EIF_INTEGER_32) 1L));
			if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
				{
					/* INLINED CODE (READABLE_STRING_GENERAL.head) */
					ti4_1 = (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
					tr1 = (EIF_REFERENCE)  0;
					(void) RTCW(loc3);
					ti4_2 = *(EIF_INTEGER_32 *)(loc3 + O17115[Dtype(loc3)-2245]);
					if ((EIF_BOOLEAN) (ti4_1 > ti4_2)) {
						tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc3);
					} else {
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R17033[Dtype(loc3)-2246])(loc3, ((EIF_INTEGER_32) 1L), ti4_1);
					}
					/* END INLINED CODE */
				}
				loc4 = tr1;
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3) + O17115[Dtype(loc3)-2245]);
				loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R17033[Dtype(RTCW(loc3))-2246])(loc3, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)), ti4_1);
				tr1 = F972_13388(Current);
				loc11 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11537[Dtype(RTCW(tr1))-991])(tr1);
				for (;;) {
					tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11319[Dtype(loc11)-941])(loc11);
					if (tb3) break;
					if ((EIF_BOOLEAN)(Result != NULL)) break;
					loc8 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11318[Dtype(loc11)-941])(loc11);
					tb4 = F1919_18202(RTCW(loc8), loc4);
					if (tb4) {
						Result = F1919_18205(RTCW(loc8));
					}
					(FUNCTION_CAST(void, (EIF_REFERENCE)) R11320[Dtype(loc11)-941])(loc11);
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {IRON_INSTALLATION_API}.package_installation_path */
EIF_REFERENCE F972_13403 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F969_13357(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {IRON_INSTALLATION_API}.local_path_associated_with_uri */
EIF_REFERENCE F972_13408 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,loc1);
	RTLR(4,loc3);
	RTLR(5,tr2);
	RTLR(6,Result);
	RTLIU(7);
	
	RTGC;
	tb1 = '\01';
	tr1 = RTMS_EX_H("http://",7,769736239);
	tb2 = F2243_21800(RTCW(arg1), tr1);
	if (!tb2) {
		tr1 = RTMS_EX_H("https://",8,441357103);
		tb2 = F2243_21800(RTCW(arg1), tr1);
		tb1 = tb2;
	}
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) F972_13409(Current, arg1);
	} else {
		tr1 = RTMS_EX_H("iron:",5,1920711738);
		tb1 = F2243_21800(RTCW(arg1), tr1);
		if (tb1) {
			loc1 = RTLNS(eif_new_type(3226, 0x00).id, 3226, _OBJSIZ_6_2_0_1_0_0_0_0_);
			F3227_38289(RTCW(loc1), arg1);
			loc3 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_3_);
			loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R17093[Dtype(RTCW(loc3))-2246])(loc3, (EIF_CHARACTER_8) ':', ((EIF_INTEGER_32) 1L));
			if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
				{
					/* INLINED CODE (READABLE_STRING_GENERAL.head) */
					ti4_1 = (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
					tr1 = (EIF_REFERENCE)  0;
					(void) RTCW(loc3);
					ti4_2 = *(EIF_INTEGER_32 *)(loc3 + O17115[Dtype(loc3)-2245]);
					if ((EIF_BOOLEAN) (ti4_1 > ti4_2)) {
						tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc3);
					} else {
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R17033[Dtype(loc3)-2246])(loc3, ((EIF_INTEGER_32) 1L), ti4_1);
					}
					/* END INLINED CODE */
				}
				tr1 = tr1;
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3) + O17115[Dtype(loc3)-2245]);
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R17033[Dtype(RTCW(loc3))-2246])(loc3, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)), ti4_1);
				Result = F972_13410(Current, tr1, tr2);
			}
		}
	}
	RTLE;
	return Result;
}

/* {IRON_INSTALLATION_API}.local_path_associated_with_url */
EIF_REFERENCE F972_13409 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(16);
	RTLR(0,loc6);
	RTLR(1,arg1);
	RTLR(2,loc7);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,loc8);
	RTLR(6,Current);
	RTLR(7,loc9);
	RTLR(8,loc4);
	RTLR(9,loc5);
	RTLR(10,tr2);
	RTLR(11,tr3);
	RTLR(12,loc1);
	RTLR(13,loc10);
	RTLR(14,loc3);
	RTLR(15,Result);
	RTLIU(16);
	
	RTGC;
	loc6 = RTLNS(eif_new_type(3226, 0x00).id, 3226, _OBJSIZ_6_2_0_1_0_0_0_0_);
	F3227_38289(RTCW(loc6), arg1);
	{
		/* INLINED CODE (URI.uri_string) */
		tr1 = (EIF_REFERENCE)  0;
		(void) RTCW(loc6);
		tr1 = RTLNS(eif_new_type(2247, 0x00).id, 2247, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F2243_21753(RTCW(tr1));
		F3225_38248(loc6, tr1);
		/* END INLINED CODE */
	}
	loc7 = tr1;
	loc2 = RTLNS(eif_new_type(2247, 0x00).id, 2247, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F2243_21753(RTCW(loc2));
	tr1 = F972_13386(Current);
	loc8 = tr1;
	if (EIF_TEST(loc8)) {
		loc9 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11537[Dtype(loc8)-991])(loc8);
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11319[Dtype(loc9)-941])(loc9);
			if (tb1) break;
			if ((EIF_BOOLEAN)(loc4 != NULL)) break;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11318[Dtype(loc9)-941])(loc9);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			{
				/* INLINED CODE (IRON_REPOSITORY.location_string) */
				tr2 = (EIF_REFERENCE)  0;
				(void) RTCW(tr1);
				tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11641[Dtype(tr1)-1916])(tr1);
				tr2 = F3225_38249(RTCW(tr3));
				/* END INLINED CODE */
			}
			loc5 = tr2;
			tb2 = F2246_21919(RTCW(loc7), loc5);
			if (tb2) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5) + O17115[Dtype(loc5)-2245]);
				ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc7) + O17115[Dtype(loc7)-2245]);
				loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R17033[Dtype(RTCW(loc7))-2246])(loc7, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)), ti4_2);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11318[Dtype(loc9)-941])(loc9);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_5_);
				loc10 = F1566_14926(RTCW(tr1));
				for (;;) {
					{
						/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.after) */
						tb2 = (EIF_BOOLEAN)  0;
						(void) loc10;
						ti4_1 = *(EIF_INTEGER_32 *)(loc10+ _LNGOFF_2_0_0_0_);
						ti4_2 = *(EIF_INTEGER_32 *)(loc10+ _LNGOFF_2_0_0_1_);
						tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ti4_2);
						/* END INLINED CODE */
					}
					tb2 = tb2;
					if (tb2) break;
					if ((EIF_BOOLEAN)(loc4 != NULL)) break;
					{
						/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.item) */
						tr1 = (EIF_REFERENCE)  0;
						(void) loc10;
						tr2 = *(EIF_REFERENCE *)(loc10);
						tr1 = 
							/* INLINED CODE (SPECIAL.item) */
							*((EIF_REFERENCE *)RTCW(tr2) + (*(EIF_INTEGER_32 *)(loc10+ _LNGOFF_2_0_0_0_)))
							/* END INLINED CODE */;
						/* END INLINED CODE */
					}
					loc3 = tr1;
					tb3 = '\0';
					tb4 = F2246_21919(RTCW(loc1), loc3);
					if (tb4) {
						tb4 = '\01';
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O17115[Dtype(loc1)-2245]);
						ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc3) + O17115[Dtype(loc3)-2245]);
						if (!(EIF_BOOLEAN)(ti4_1 == ti4_2)) {
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3) + O17115[Dtype(loc3)-2245]);
							tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R12119[Dtype(RTCW(loc1))-1471])(loc1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L))));
							tb4 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '/');
						}
						tb3 = tb4;
					}
					if (tb3) {
						loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11318[Dtype(loc9)-941])(loc9);
						(FUNCTION_CAST(void, (EIF_REFERENCE)) R17080[Dtype(RTCW(loc2))-2247])(loc2);
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3) + O17115[Dtype(loc3)-2245]);
						ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O17115[Dtype(loc1)-2245]);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R17033[Dtype(RTCW(loc1))-2246])(loc1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)), ti4_2);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R17139[Dtype(RTCW(loc2))-2247])(loc2, tr1);
					}
					{
						/* INLINED CODE (GENERAL_SPECIAL_ITERATION_CURSOR.forth) */
						(void) loc10;
						(*(EIF_INTEGER_32 *)(loc10+ _LNGOFF_2_0_0_0_))++;
						/* END INLINED CODE */
					}
					;
				}
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R11320[Dtype(loc9)-941])(loc9);
		}
	}
	if ((EIF_BOOLEAN)(loc4 != NULL)) {
		{
			/* INLINED CODE (IRON_INSTALLATION_API.package_installation_path) */
			tr1 = (EIF_REFERENCE)  0;
			tr2 = *(EIF_REFERENCE *)(Current);
			tr1 = F969_13357(RTCW(tr2), loc4);
			/* END INLINED CODE */
		}
		Result = tr1;
		tb3 = '\0';
		if ((EIF_BOOLEAN)(Result != NULL)) {
			tr1 = RTLNS(eif_new_type(783, 0x00).id, 783, _OBJSIZ_3_0_0_1_0_2_0_0_);
			F784_10987(RTCW(tr1), Result);
			{
				/* INLINED CODE (DIRECTORY.exists) */
				tb4 = (EIF_BOOLEAN)  0;
				tr2 = tr1;
				(void) RTCW(tr2);
				tp1 = *(EIF_POINTER *)(RTCV(F784_11024(tr2))+ _PTROFF_0_1_0_1_0_0_);
				tb4 = (EIF_BOOLEAN) EIF_TEST(eif_dir_exists((EIF_FILENAME) tp1));
				/* END INLINED CODE */
			}
			tb4 = tb4;
			tb3 = tb4;
		}
		if (tb3) {
			tr1 = F2014_18978(RTCW(Result), loc2);
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			RTLE;
			return (EIF_REFERENCE) NULL;
		}
	}
	RTLE;
	return Result;
}

/* {IRON_INSTALLATION_API}.local_path_associated_with_relative_uri */
EIF_REFERENCE F972_13410 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,Result);
	RTLR(6,arg2);
	RTLIU(7);
	
	RTGC;
	loc1 = F972_13385(Current, arg1, (EIF_BOOLEAN) 0);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		{
			/* INLINED CODE (IRON_INSTALLATION_API.package_installation_path) */
			tr1 = (EIF_REFERENCE)  0;
			tr2 = *(EIF_REFERENCE *)(Current);
			tr1 = F969_13357(RTCW(tr2), loc1);
			/* END INLINED CODE */
		}
		Result = tr1;
		tb1 = '\0';
		if ((EIF_BOOLEAN)(Result != NULL)) {
			tr1 = RTLNS(eif_new_type(783, 0x00).id, 783, _OBJSIZ_3_0_0_1_0_2_0_0_);
			F784_10987(RTCW(tr1), Result);
			{
				/* INLINED CODE (DIRECTORY.exists) */
				tb2 = (EIF_BOOLEAN)  0;
				tr2 = tr1;
				(void) RTCW(tr2);
				tp1 = *(EIF_POINTER *)(RTCV(F784_11024(tr2))+ _PTROFF_0_1_0_1_0_0_);
				tb2 = (EIF_BOOLEAN) EIF_TEST(eif_dir_exists((EIF_FILENAME) tp1));
				/* END INLINED CODE */
			}
			tb2 = tb2;
			tb1 = tb2;
		}
		if (tb1) {
			tr1 = F2014_18978(RTCW(Result), arg2);
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			RTLE;
			return (EIF_REFERENCE) NULL;
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit800 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
