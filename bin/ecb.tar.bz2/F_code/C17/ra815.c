/*
 * Code for class RAW_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ra815.h"
#include <string.h>
#include <stdio.h>
#include "eif_file.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RAW_FILE}.support_storable */
EIF_BOOLEAN F1438_14396 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {RAW_FILE}.put_boolean */
void F1438_14408 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (arg1) {
		{
			/* INLINED CODE (FILE.put_character) */
			tp1 = *(EIF_POINTER *)(Current + O11932[Dtype(Current)-1436]);
			eif_file_pc((FILE*) tp1, (EIF_CHARACTER) (EIF_CHARACTER_8) '\001');
			/* END INLINED CODE */
		}
		;
	} else {
		{
			/* INLINED CODE (FILE.put_character) */
			tp1 = *(EIF_POINTER *)(Current + O11932[Dtype(Current)-1436]);
			eif_file_pc((FILE*) tp1, (EIF_CHARACTER) (EIF_CHARACTER_8) '\000');
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
}

/* {RAW_FILE}.read_integer */
void F1438_14417 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O11932[dtype-1436]);
	ti4_1 = (EIF_INTEGER_32) eif_file_gib((FILE*) tp1);
	*(EIF_INTEGER_32 *)(Current + O11175[dtype-920]) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

/* {RAW_FILE}.read_integer_8 */
void F1438_14420 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_8 ti1_1;
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	{
		/* INLINED CODE (RAW_FILE.integer_buffer) */
		tr1 = (EIF_REFERENCE)  0;
		{
		EIF_TYPE_INDEX inlined_dtype = Dtype(Current);
		tr1 = *(EIF_REFERENCE *)(Current + O12085[inlined_dtype-1437]);
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			tr1 = RTLNS(eif_new_type(781, 0x00).id, 781, _OBJSIZ_0_1_0_1_0_1_1_0_);
			F782_10881(RTCW(tr1), ((EIF_INTEGER_32) 16L));
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + O12085[inlined_dtype-1437]) = (EIF_REFERENCE) tr1;
		}
		}
		/* END INLINED CODE */
	}
	tr2 = tr1;
	{
		/* INLINED CODE (RAW_FILE.read_to_managed_pointer) */
		{
		EIF_TYPE_INDEX inlined_dtype = Dtype(Current);
		tp1 = *(EIF_POINTER *)(RTCW(tr2)+ _PTROFF_0_1_0_1_0_0_);
		tp1 = RTPOF(tp1,((EIF_INTEGER_32) 0L));
		tp2 = *(EIF_POINTER *)(Current + O11932[inlined_dtype-1436]);
		ti4_1 = (EIF_INTEGER_32) fread((void*) tp1, (size_t) ((EIF_INTEGER_32) 1L), (size_t) ((EIF_INTEGER_32) 1L), (FILE*) tp2);
		*(EIF_INTEGER_32 *)(Current + O11189[inlined_dtype-920]) = (EIF_INTEGER_32) ti4_1;
		}
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (RAW_FILE.integer_buffer) */
		tr1 = (EIF_REFERENCE)  0;
		{
		EIF_TYPE_INDEX inlined_dtype = Dtype(Current);
		tr1 = *(EIF_REFERENCE *)(Current + O12085[inlined_dtype-1437]);
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			tr1 = RTLNS(eif_new_type(781, 0x00).id, 781, _OBJSIZ_0_1_0_1_0_1_1_0_);
			F782_10881(RTCW(tr1), ((EIF_INTEGER_32) 16L));
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + O12085[inlined_dtype-1437]) = (EIF_REFERENCE) tr1;
		}
		}
		/* END INLINED CODE */
	}
	tr2 = tr1;
	{
		/* INLINED CODE (MANAGED_POINTER.read_integer_8) */
		ti1_1 = (EIF_INTEGER_8)  0;
		(void) RTCW(tr2);
		tu1_1 = F782_10892(tr2, ((EIF_INTEGER_32) 0L));
		ti1_1 = (EIF_INTEGER_8) tu1_1;
		/* END INLINED CODE */
	}
	ti1_1 = ti1_1;
	*(EIF_INTEGER_8 *)(Current + O11179[Dtype(Current)-920]) = (EIF_INTEGER_8) ti1_1;
	RTLE;
}

/* {RAW_FILE}.read_natural_8 */
void F1438_14423 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	{
		/* INLINED CODE (RAW_FILE.integer_buffer) */
		tr1 = (EIF_REFERENCE)  0;
		{
		EIF_TYPE_INDEX inlined_dtype = Dtype(Current);
		tr1 = *(EIF_REFERENCE *)(Current + O12085[inlined_dtype-1437]);
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			tr1 = RTLNS(eif_new_type(781, 0x00).id, 781, _OBJSIZ_0_1_0_1_0_1_1_0_);
			F782_10881(RTCW(tr1), ((EIF_INTEGER_32) 16L));
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + O12085[inlined_dtype-1437]) = (EIF_REFERENCE) tr1;
		}
		}
		/* END INLINED CODE */
	}
	tr2 = tr1;
	{
		/* INLINED CODE (RAW_FILE.read_to_managed_pointer) */
		{
		EIF_TYPE_INDEX inlined_dtype = Dtype(Current);
		tp1 = *(EIF_POINTER *)(RTCW(tr2)+ _PTROFF_0_1_0_1_0_0_);
		tp1 = RTPOF(tp1,((EIF_INTEGER_32) 0L));
		tp2 = *(EIF_POINTER *)(Current + O11932[inlined_dtype-1436]);
		ti4_1 = (EIF_INTEGER_32) fread((void*) tp1, (size_t) ((EIF_INTEGER_32) 1L), (size_t) ((EIF_INTEGER_32) 1L), (FILE*) tp2);
		*(EIF_INTEGER_32 *)(Current + O11189[inlined_dtype-920]) = (EIF_INTEGER_32) ti4_1;
		}
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (RAW_FILE.integer_buffer) */
		tr1 = (EIF_REFERENCE)  0;
		{
		EIF_TYPE_INDEX inlined_dtype = Dtype(Current);
		tr1 = *(EIF_REFERENCE *)(Current + O12085[inlined_dtype-1437]);
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			tr1 = RTLNS(eif_new_type(781, 0x00).id, 781, _OBJSIZ_0_1_0_1_0_1_1_0_);
			F782_10881(RTCW(tr1), ((EIF_INTEGER_32) 16L));
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + O12085[inlined_dtype-1437]) = (EIF_REFERENCE) tr1;
		}
		}
		/* END INLINED CODE */
	}
	tr2 = tr1;
	{
		/* INLINED CODE (MANAGED_POINTER.read_natural_8) */
		ti4_1 = ((EIF_INTEGER_32) 0L);
		tu1_1 = (EIF_NATURAL_8)  0;
		(void) RTCW(tr2);
		tp1 = *(EIF_POINTER *)(tr2+ _PTROFF_0_1_0_1_0_0_);
		tp1 = RTPOF(tp1,ti4_1);
		memcpy((void *)(EIF_NATURAL_8 *) &(tu1_1), (const void *) tp1, (size_t) ((EIF_INTEGER_32) 1L));
		/* END INLINED CODE */
	}
	tu1_1 = tu1_1;
	*(EIF_NATURAL_8 *)(Current + O11184[Dtype(Current)-920]) = (EIF_NATURAL_8) tu1_1;
	RTLE;
}

/* {RAW_FILE}.read_to_managed_pointer */
void F1438_14435 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_0_1_0_1_0_0_);
	tp1 = RTPOF(tp1,arg2);
	tp2 = *(EIF_POINTER *)(Current + O11932[dtype-1436]);
	ti4_1 = (EIF_INTEGER_32) fread((void*) tp1, (size_t) ((EIF_INTEGER_32) 1L), (size_t) arg3, (FILE*) tp2);
	*(EIF_INTEGER_32 *)(Current + O11189[dtype-920]) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

/* {RAW_FILE}.read_to_string */
EIF_INTEGER_32 F1438_14436 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O11932[Dtype(Current)-1436]);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	/* INLINED CODE (SPECIAL.item_address) */
	tp2 = RTCW(tr1) + (rt_uint_ptr)(EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)) * sizeof(EIF_CHARACTER_8);
	/* END INLINED CODE */
	tp2 = tp2;
	Result = (EIF_INTEGER_32) eif_file_gss((FILE*) tp1, (char*) tp2, (EIF_INTEGER) arg3);
	{
		/* INLINED CODE (STRING_GENERAL.reset_hash_codes) */
		(void) RTCW(arg1);
		*(EIF_INTEGER_32 *)(arg1+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		*(EIF_INTEGER_32 *)(arg1+ _LNGOFF_1_1_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		/* END INLINED CODE */
	}
	;
	RTLE;
	return Result;
}

/* {RAW_FILE}.file_fread */
EIF_INTEGER_32 F1438_14437 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) fread((void*) arg1, (size_t) arg2, (size_t) arg3, (FILE*) arg4);
	
	return Result;
}

/* {RAW_FILE}.integer_buffer */
EIF_REFERENCE F1438_14438 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = *(EIF_REFERENCE *)(Current + O12085[dtype-1437]);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		Result = RTLNS(eif_new_type(781, 0x00).id, 781, _OBJSIZ_0_1_0_1_0_1_1_0_);
		F782_10881(RTCW(Result), ((EIF_INTEGER_32) 16L));
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + O12085[dtype-1437]) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {RAW_FILE}.file_gib */
EIF_INTEGER_32 F1438_14440 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) eif_file_gib((FILE*) arg1);
	
	return Result;
}

/* {RAW_FILE}.file_open */
EIF_POINTER F1438_14443 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) eif_file_binary_open((EIF_FILENAME) arg1, (int) arg2);
	
	return Result;
}

void EIF_Minit815 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
