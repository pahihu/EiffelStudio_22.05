/*
 * Code for class ES_ARGUMENTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "es804.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ES_ARGUMENTS}.environment_arguments_prepended */
EIF_BOOLEAN F976_13535 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {ES_ARGUMENTS}.arguments_program_name */
EIF_REFERENCE F976_13536 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(2250, 0x00).id, 2250, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr1 = RTMS_EX_H("ec",2,25955);
	F2251_22103(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {ES_ARGUMENTS}.arguments_environment_name */
static EIF_REFERENCE F976_13537_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOSP (13537);
#define Result RTOSR(13537)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(2250, 0x00).id, 2250, _OBJSIZ_1_0_0_4_0_0_0_0_);
	tr2 = RTMS32_EX_H("I\000\000\000S\000\000\000E\000\000\000_\000\000\000",4,1230194015);
	tr3 = F2251_22116(RTCV(F976_13536(Current)));
	tr2 = F2252_22183(tr2, tr3);
	tr3 = F2243_21812(RTMS_EX_H("_FLAGS",6,1466661715));
	tr2 = F2252_22183(RTCW(tr2), tr3);
	F2251_22104(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (13537);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F976_13537 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(13537,F976_13537_body,(Current));
}

void EIF_Minit804 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
