/*
 * Code for class CONF_CONDITION_LIST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co828.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_CONDITION_LIST}.make */
void F1582_14988 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1566_14912(Current, arg1);
	{
		/* INLINED CODE (CONTAINER.compare_objects) */
		*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		/* END INLINED CODE */
	}
	;
	RTLE;
}

void EIF_Minit828 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
