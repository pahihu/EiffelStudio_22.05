/*
 * Code for class ENVIRONMENT_ARGUMENTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "en803.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ENVIRONMENT_ARGUMENTS}.argument */
EIF_REFERENCE F975_13522 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 0L))) {
		tr1 = RTOSCF(13533,F975_13533, (Current));
		{
			/* INLINED CODE (ARGUMENTS_32.argument) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(tr1);
			tr3 = RTOSCF(13596,F996_13596, (tr1));
			tr2 = F1602_15110(RTCW(tr3), ((EIF_INTEGER_32) 0L));
			/* END INLINED CODE */
		}
		Result = tr2;
	} else {
		{
			/* INLINED CODE (ARRAYED_LIST.count) */
			ti4_1 = (EIF_INTEGER_32)  0;
			tr1 = F975_13532(Current);
			(void) RTCW(tr1);
			tr2 = *(EIF_REFERENCE *)(tr1);
			ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr2);
			/* END INLINED CODE */
		}
		ti4_1 = ti4_1;
		if ((EIF_BOOLEAN) (arg1 <= ti4_1)) {
			Result = F975_13531(Current, arg1);
		} else {
			Result = F975_13530(Current, arg1);
		}
	}
	RTLE;
	return Result;
}

/* {ENVIRONMENT_ARGUMENTS}.index_of_word_option */
EIF_INTEGER_32 F975_13524 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(13533,F975_13533, (Current));
	Result = F996_13583(RTCW(tr1), arg1);
	if ((EIF_BOOLEAN) (Result > ((EIF_INTEGER_32) 0L))) {
		{
			/* INLINED CODE (ARRAYED_LIST.count) */
			ti4_1 = (EIF_INTEGER_32)  0;
			tr1 = F975_13532(Current);
			(void) RTCW(tr1);
			tr2 = *(EIF_REFERENCE *)(tr1);
			ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr2);
			/* END INLINED CODE */
		}
		ti4_1 = ti4_1;
		Result += ti4_1;
	} else {
		{
			/* INLINED CODE (ARRAYED_LIST.count) */
			ti4_1 = (EIF_INTEGER_32)  0;
			tr1 = F975_13532(Current);
			(void) RTCW(tr1);
			tr2 = *(EIF_REFERENCE *)(tr1);
			ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr2);
			/* END INLINED CODE */
		}
		loc2 = ti4_1;
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN) (loc1 > loc2)) {
				tr1 = F975_13531(Current, loc1);
				tb1 = F975_13529(Current, tr1, arg1);
			}
			if (tb1) break;
			loc1++;
		}
		if ((EIF_BOOLEAN) (loc1 <= loc2)) {
			RTLE;
			return (EIF_INTEGER_32) loc1;
		}
	}
	RTLE;
	return Result;
}

/* {ENVIRONMENT_ARGUMENTS}.option_sign */
EIF_REFERENCE F975_13525 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTOSCF(13590,F996_13590, (RTCV(RTOSCF(13533,F975_13533, (Current)))));
	RTLE;
	return Result;
}

/* {ENVIRONMENT_ARGUMENTS}.argument_count */
EIF_INTEGER_32 F975_13527 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	Result = (EIF_INTEGER_32) eif_builtin_ARGUMENTS_32_argument_count__i4;
	{
		/* INLINED CODE (ARRAYED_LIST.count) */
		ti4_1 = (EIF_INTEGER_32)  0;
		tr1 = F975_13532(Current);
		(void) RTCW(tr1);
		tr2 = *(EIF_REFERENCE *)(tr1);
		ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr2);
		/* END INLINED CODE */
	}
	ti4_1 = ti4_1;
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	RTLE;
	return Result;
}

/* {ENVIRONMENT_ARGUMENTS}.option_word_equal */
EIF_BOOLEAN F975_13529 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	{
		/* INLINED CODE (ENVIRONMENT_ARGUMENTS.option_sign) */
		tr1 = (EIF_REFERENCE)  0;
		tr1 = RTOSCF(13590,F996_13590, (RTCV(RTOSCF(13533,F975_13533, (Current)))));
		/* END INLINED CODE */
	}
	tr2 = tr1;
	tw1 = *(EIF_CHARACTER_32 *)(RTCW(tr2) + O6989[Dtype(tr2)-553]);
	tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(tw1 == tw2)) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R16998[Dtype(RTCW(arg1))-2246])(arg1, arg2);
		RTLE;
		return (EIF_BOOLEAN) tb1;
	} else {
		tb1 = '\0';
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R16970[Dtype(RTCW(arg1))-2246])(arg1);
		if ((EIF_BOOLEAN) !tb2) {
			tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R16956[Dtype(RTCW(arg1))-2246])(arg1, ((EIF_INTEGER_32) 1L));
			{
				/* INLINED CODE (ENVIRONMENT_ARGUMENTS.option_sign) */
				tr1 = (EIF_REFERENCE)  0;
				tr1 = RTOSCF(13590,F996_13590, (RTCV(RTOSCF(13533,F975_13533, (Current)))));
				/* END INLINED CODE */
			}
			tr2 = tr1;
			tw2 = *(EIF_CHARACTER_32 *)(RTCW(tr2) + O6989[Dtype(tr2)-553]);
			tb1 = (EIF_BOOLEAN)(tw1 == tw2);
		}
		if (tb1) {
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R16992[Dtype(RTCW(arg1))-2246])(arg1);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R17033[Dtype(RTCW(arg1))-2246])(arg1, ((EIF_INTEGER_32) 2L), ti4_1);
			Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R16998[Dtype(RTCW(tr1))-2246])(tr1, arg2);
		}
	}
	RTLE;
	return Result;
}

/* {ENVIRONMENT_ARGUMENTS}.base_argument_item */
EIF_REFERENCE F975_13530 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tr1 = RTOSCF(13533,F975_13533, (Current));
	{
		/* INLINED CODE (ARRAYED_LIST.count) */
		ti4_1 = (EIF_INTEGER_32)  0;
		tr2 = F975_13532(Current);
		(void) RTCW(tr2);
		tr3 = *(EIF_REFERENCE *)(tr2);
		ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr3);
		/* END INLINED CODE */
	}
	ti4_1 = ti4_1;
	{
		/* INLINED CODE (ARGUMENTS_32.argument) */
		ti4_1 = (EIF_INTEGER_32) (arg1 - ti4_1);
		tr2 = (EIF_REFERENCE)  0;
		(void) RTCW(tr1);
		tr3 = RTOSCF(13596,F996_13596, (tr1));
		tr2 = F1602_15110(RTCW(tr3), ti4_1);
		/* END INLINED CODE */
	}
	Result = tr2;
	RTLE;
	return Result;
}

/* {ENVIRONMENT_ARGUMENTS}.environment_argument_item */
EIF_REFERENCE F975_13531 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tr1 = F975_13532(Current);
	{
		/* INLINED CODE (ARRAYED_LIST.i_th) */
		tr2 = (EIF_REFERENCE)  0;
		(void) RTCW(tr1);
		tr3 = *(EIF_REFERENCE *)(tr1);
		tr2 = 
			/* INLINED CODE (SPECIAL.item) */
			*((EIF_REFERENCE *)RTCW(tr3) + ((EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L))))
			/* END INLINED CODE */;
		/* END INLINED CODE */
	}
	Result = tr2;
	RTLE;
	return Result;
}

/* {ENVIRONMENT_ARGUMENTS}.environment_arguments */
EIF_REFERENCE F975_13532 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 loc3 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc5);
	RTLIU(6);
	
	RTGC;
	Result = *(EIF_REFERENCE *)(Current);
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {1565,2250,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1565, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F1566_14912(RTCW(Result), ((EIF_INTEGER_32) 0L));
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) Result;
		tr1 = RTOSCF(13338,F968_13338, (Current));
		tr2 = RTOSCF(13537,F976_13537, (Current));
		loc4 = F772_10712(RTCW(tr1), tr2);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			{
				/* INLINED CODE (READABLE_STRING_GENERAL.is_whitespace) */
				tb2 = (EIF_BOOLEAN)  0;
				(void) RTCW(loc4);
				ti4_1 = *(EIF_INTEGER_32 *)(loc4+ _LNGOFF_1_1_0_2_);
				tb2 = F2250_22082(loc4, ((EIF_INTEGER_32) 1L), ti4_1);
				/* END INLINED CODE */
			}
			tb2 = tb2;
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			loc2 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_1_0_2_);
			loc5 = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F2243_21753(RTCW(loc5));
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > loc2)) break;
				{
					/* INLINED CODE (STRING_32.item) */
					tw1 = (EIF_CHARACTER_32)  0;
					(void) RTCW(loc4);
					tr1 = *(EIF_REFERENCE *)(loc4);
					tw1 = 
						/* INLINED CODE (SPECIAL.item) */
						*((EIF_CHARACTER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L))))
						/* END INLINED CODE */;
					/* END INLINED CODE */
				}
				loc3 = tw1;
				if (loc6) {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
					if ((EIF_BOOLEAN)(loc3 == tw1)) {
						loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					} else {
						F2252_22178(RTCW(loc5), loc3);
					}
				} else {
					switch (loc3) {
						case (EIF_CHARACTER_8) '\"':
							loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							break;
						case (EIF_CHARACTER_8) '\011':
						case (EIF_CHARACTER_8) ' ':
							{
								/* INLINED CODE (FINITE.is_empty) */
								tb1 = (EIF_BOOLEAN)  0;
								(void) RTCW(loc5);
								ti4_1 = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_2_);
								tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
								/* END INLINED CODE */
							}
							tb1 = tb1;
							if ((EIF_BOOLEAN) !tb1) {
								tr1 = RTLNS(eif_new_type(2250, 0x00).id, 2250, _OBJSIZ_1_0_0_4_0_0_0_0_);
								F2250_22051(RTCW(tr1), loc5);
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11799[Dtype(RTCW(Result))-1322])(Result, tr1);
								{
									/* INLINED CODE (STRING_32.wipe_out) */
									(void) RTCW(loc5);
									*(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
									F2245_21851(loc5);
									/* END INLINED CODE */
								}
								;
							}
							break;
						default:
							F2252_22178(RTCW(loc5), loc3);
							break;
					}
				}
				loc1++;
			}
			if (loc6) {
			} else {
				{
					/* INLINED CODE (FINITE.is_empty) */
					tb1 = (EIF_BOOLEAN)  0;
					(void) RTCW(loc5);
					ti4_1 = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_2_);
					tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
					/* END INLINED CODE */
				}
				tb1 = tb1;
				if ((EIF_BOOLEAN) !tb1) {
					tr1 = RTLNS(eif_new_type(2250, 0x00).id, 2250, _OBJSIZ_1_0_0_4_0_0_0_0_);
					F2250_22051(RTCW(tr1), loc5);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11799[Dtype(RTCW(Result))-1322])(Result, tr1);
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {ENVIRONMENT_ARGUMENTS}.base_arguments */
static EIF_REFERENCE F975_13533_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (13533);
#define Result RTOSR(13533)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(995, 0x00).id, 995, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (13533);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F975_13533 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(13533,F975_13533_body,(Current));
}

void EIF_Minit803 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
