/*
 * Code for class EWB_ARGUMENTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew836.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EWB_ARGUMENTS}.current_item */
EIF_REFERENCE F1625_15195 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	{
		/* INLINED CODE (ARRAY.item) */
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
		tr1 = (EIF_REFERENCE)  0;
		tr2 = *(EIF_REFERENCE *)(Current);
		tr1 = 
			/* INLINED CODE (SPECIAL.item) */
			*((EIF_REFERENCE *)RTCW(tr2) + ((EIF_INTEGER_32) (ti4_1 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_1_))))
			/* END INLINED CODE */;
		/* END INLINED CODE */
	}
	Result = tr1;
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_))++;
	RTLE;
	return Result;
}

/* {EWB_ARGUMENTS}.more_arguments */
EIF_BOOLEAN F1625_15196 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) <= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_)));
}

/* {EWB_ARGUMENTS}.force */
void F1625_15197 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1602_15131(Current, arg1, arg2);
	if ((EIF_BOOLEAN) (arg2 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) arg2;
	}
	RTLE;
}

/* {EWB_ARGUMENTS}.wipe_out */
void F1625_15198 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	{
		/* INLINED CODE (ARRAY.make_empty) */
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		F821_11759(Current, ((EIF_INTEGER_32) 0L));
		/* END INLINED CODE */
	}
	;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTLE;
}

void EIF_Minit836 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
