
#ifndef _C17_kl840_
#define _C17_kl840_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,15350)
static EIF_REFERENCE F1649_15350_body(EIF_REFERENCE);
extern EIF_REFERENCE F1649_15350(EIF_REFERENCE);
extern void EIF_Minit840(void);

#ifdef __cplusplus
}
#endif

#endif
