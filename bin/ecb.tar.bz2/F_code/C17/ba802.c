/*
 * Code for class BASE_PROCESS_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ba802.h"
#include "eif_built_in.h"
#include "eif_process.h"
#include <unistd.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F775_10748
static EIF_INTEGER_32 inline_F775_10748 (void)
{
	return (EIF_INTEGER_32) (getpid())
	;
}
#define INLINE_F775_10748
#endif
#ifndef INLINE_F479_6931
static void inline_F479_6931 (EIF_INTEGER_32 arg1)
{
	{
	pid_t pgid = getpgid (arg1);
	tcsetpgrp (1, pgid);
	tcsetpgrp (2, pgid);
}
	;
}
#define INLINE_F479_6931
#endif
#ifndef INLINE_F786_11140
static EIF_INTEGER_32 inline_F786_11140 (EIF_INTEGER_32 arg1)
{
	return (EIF_INTEGER_32) (WEXITSTATUS(arg1))
	;
}
#define INLINE_F786_11140
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BASE_PROCESS_IMP}.make */
void F974_13503 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLR(5,arg1);
	RTLR(6,arg3);
	RTLR(7,tr2);
	RTLIU(8);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {1565,2242,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 1565, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F1566_14912(RTCW(loc1), ((EIF_INTEGER_32) 0L));
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11537[Dtype(RTCW(arg2))-991])(arg2);
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11319[Dtype(loc2)-941])(loc2);
			if (tb1) break;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11318[Dtype(loc2)-941])(loc2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11799[Dtype(RTCW(loc1))-1322])(loc1, tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R11320[Dtype(loc2)-941])(loc2);
		}
	}
	F974_13518(Current, arg1, loc1, arg3);
	{
		/* INLINED CODE (BASE_PROCESS_IMP.create_child_process_manager) */
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = RTLNSMART(eif_new_type(785, 0).id);
		F786_11083(RTCW(tr2), arg1, loc1, tr1);
		RTAR(Current, tr2);
		*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr2;
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
		F786_11096(RTCW(tr2), (EIF_BOOLEAN) 1);
		/* END INLINED CODE */
	}
	;
	F973_13499(Current);
	RTLE;
}

/* {BASE_PROCESS_IMP}.make_with_command_line */
void F974_13504 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc1);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,arg2);
	RTLIU(7);
	
	RTGC;
	loc2 = F973_13502(Current, arg1);
	{
		/* INLINED CODE (FINITE.is_empty) */
		tb1 = (EIF_BOOLEAN)  0;
		(void) RTCW(loc2);
		ti4_1 = F1566_14933(loc2);
		tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
		/* END INLINED CODE */
	}
	tb1 = tb1;
	if (tb1) {
		loc1 = F2243_21812(RTMS_EX_H(" ",1,32));
		loc2 = (EIF_REFERENCE) NULL;
	} else {
		{
			/* INLINED CODE (ARRAYED_LIST.count) */
			ti4_1 = (EIF_INTEGER_32)  0;
			(void) RTCW(loc2);
			tr1 = *(EIF_REFERENCE *)(loc2);
			ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
			/* END INLINED CODE */
		}
		ti4_1 = ti4_1;
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
			{
				/* INLINED CODE (ARRAYED_LIST.first) */
				tr1 = (EIF_REFERENCE)  0;
				(void) RTCW(loc2);
				tr2 = *(EIF_REFERENCE *)(loc2);
				tr1 = 
					/* INLINED CODE (SPECIAL.item) */
					*((EIF_REFERENCE *)RTCW(tr2) + (((EIF_INTEGER_32) 0L)))
					/* END INLINED CODE */;
				/* END INLINED CODE */
			}
			loc1 = tr1;
			loc2 = (EIF_REFERENCE) NULL;
		} else {
			{
				/* INLINED CODE (ARRAYED_LIST.first) */
				tr1 = (EIF_REFERENCE)  0;
				(void) RTCW(loc2);
				tr2 = *(EIF_REFERENCE *)(loc2);
				tr1 = 
					/* INLINED CODE (SPECIAL.item) */
					*((EIF_REFERENCE *)RTCW(tr2) + (((EIF_INTEGER_32) 0L)))
					/* END INLINED CODE */;
				/* END INLINED CODE */
			}
			loc1 = tr1;
			{
				/* INLINED CODE (ARRAYED_LIST.start) */
				(void) RTCW(loc2);
				*(EIF_INTEGER_32 *)(loc2 + O12312[Dtype(loc2)-1565]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				/* END INLINED CODE */
			}
			;
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R11817[Dtype(RTCW(loc2))-1415])(loc2);
		}
	}
	F974_13503(Current, loc1, loc2, arg2);
	RTLE;
}

/* {BASE_PROCESS_IMP}.wait_for_exit */
void F974_13507 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	F786_11101(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_13_16_0_1_), (EIF_BOOLEAN) 1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_15_1_);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_13_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) !tb1;
	F973_13442(Current);
	RTLE;
}

/* {BASE_PROCESS_IMP}.close */
void F974_13508 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_13_15_) && *(EIF_BOOLEAN *)(Current+ _CHROFF_13_14_))) {
		{
			/* INLINED CODE (PROCESS_INFO_IMP.process_id) */
			ti4_1 = (EIF_INTEGER_32)  0;
			ti4_1 = inline_F775_10748();
			/* END INLINED CODE */
		}
		ti4_2 = ti4_1;
		inline_F479_6931(ti4_2);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	F786_11102(RTCW(tr1));
	RTLE;
}

/* {BASE_PROCESS_IMP}.platform_launch */
void F974_13509 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F974_13517(Current);
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_13_15_) && *(EIF_BOOLEAN *)(Current+ _CHROFF_13_14_))) {
		{
			/* INLINED CODE (PROCESS_INFO_IMP.process_id) */
			ti4_1 = (EIF_INTEGER_32)  0;
			ti4_1 = inline_F775_10748();
			/* END INLINED CODE */
		}
		ti4_2 = ti4_1;
		inline_F479_6931(ti4_2);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	F786_11103(RTCW(tr1), *(EIF_BOOLEAN *)(Current+ _CHROFF_13_14_), *(EIF_REFERENCE *)(Current + _REFACS_5_), *(EIF_BOOLEAN *)(Current+ _CHROFF_13_15_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_15_11_0_1_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_13_16_0_1_) = (EIF_INTEGER_32) loc1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_13_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) -1L));
	RTLE;
}

/* {BASE_PROCESS_IMP}.initialize_after_launch */
void F974_13510 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {BASE_PROCESS_IMP}.exit_code */
EIF_INTEGER_32 F974_13514 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	{
		/* INLINED CODE (PROCESS_UNIX_PROCESS_MANAGER.exit_code) */
		ti4_1 = (EIF_INTEGER_32)  0;
		(void) RTCW(tr1);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(tr1+ _CHROFF_15_1_) && *(EIF_BOOLEAN *)(tr1+ _CHROFF_15_0_)) && *(EIF_BOOLEAN *)(tr1+ _CHROFF_15_2_))) {
			ti4_2 = *(EIF_INTEGER_32 *)(tr1+ _LNGOFF_15_11_0_2_);
			ti4_1 = inline_F786_11140(ti4_2);
		}
		/* END INLINED CODE */
	}
	Result = ti4_1;
	RTLE;
	return Result;
}

/* {BASE_PROCESS_IMP}.update_process_state */
void F974_13515 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	F786_11101(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_13_16_0_1_), (EIF_BOOLEAN) 0);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_15_1_);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_13_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) !tb1;
	RTLE;
}

/* {BASE_PROCESS_IMP}.close_process */
void F974_13516 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		/* INLINED CODE (BASE_PROCESS_IMP.close) */
		if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_13_15_) && *(EIF_BOOLEAN *)(Current+ _CHROFF_13_14_))) {
			ti4_1 = F775_10747(Current);
			inline_F479_6931(ti4_1);
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
		F786_11102(RTCW(tr1));
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {BASE_PROCESS_IMP}.initialize_child_process */
void F974_13517 (EIF_REFERENCE Current)
{
	GTCX
	struct eif_ex_131 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(163, 0x00).id);
	RTLI(7);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
		{
			/* INLINED CODE (UTF_CONVERTER.escaped_utf_32_string_to_utf_8_string_8) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(loc1);
			tr2 = RTLNS(eif_new_type(2247, 0x00).id, 2247, _OBJSIZ_1_1_0_3_0_0_0_0_);
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R16992[Dtype(loc2)-2246])(loc2);
			F2246_21883(RTCW(tr2), ti4_1);
			F164_2784(loc1, loc2, tr2);
			/* END INLINED CODE */
		}
		tr2 = tr2;
		{
			/* INLINED CODE (PROCESS_UNIX_PROCESS_MANAGER.set_input_file_name) */
			(void) RTCW(tr1);
			RTAR(tr1, tr2);
			*(EIF_REFERENCE *)(tr1 + _REFACS_6_) = (EIF_REFERENCE) tr2;
			*(EIF_BOOLEAN *)(tr1+ _CHROFF_15_7_) = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr2 == NULL);
			/* END INLINED CODE */
		}
		;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
		{
			/* INLINED CODE (PROCESS_UNIX_PROCESS_MANAGER.set_input_file_name) */
			(void) RTCW(tr1);
			RTAR(tr1, NULL);
			*(EIF_REFERENCE *)(tr1 + _REFACS_6_) = (EIF_REFERENCE) NULL;
			*(EIF_BOOLEAN *)(tr1+ _CHROFF_15_7_) = (EIF_BOOLEAN) (EIF_BOOLEAN)(NULL == NULL);
			/* END INLINED CODE */
		}
		;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
		{
			/* INLINED CODE (UTF_CONVERTER.escaped_utf_32_string_to_utf_8_string_8) */
			tr2 = (EIF_REFERENCE)  0;
			(void) RTCW(loc1);
			tr2 = RTLNS(eif_new_type(2247, 0x00).id, 2247, _OBJSIZ_1_1_0_3_0_0_0_0_);
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R16992[Dtype(loc3)-2246])(loc3);
			F2246_21883(RTCW(tr2), ti4_1);
			F164_2784(loc1, loc3, tr2);
			/* END INLINED CODE */
		}
		tr2 = tr2;
		{
			/* INLINED CODE (PROCESS_UNIX_PROCESS_MANAGER.set_output_file_name) */
			(void) RTCW(tr1);
			RTAR(tr1, tr2);
			*(EIF_REFERENCE *)(tr1 + _REFACS_7_) = (EIF_REFERENCE) tr2;
			*(EIF_BOOLEAN *)(tr1+ _CHROFF_15_8_) = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr2 == NULL);
			/* END INLINED CODE */
		}
		;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
		{
			/* INLINED CODE (PROCESS_UNIX_PROCESS_MANAGER.set_output_file_name) */
			(void) RTCW(tr1);
			RTAR(tr1, NULL);
			*(EIF_REFERENCE *)(tr1 + _REFACS_7_) = (EIF_REFERENCE) NULL;
			*(EIF_BOOLEAN *)(tr1+ _CHROFF_15_8_) = (EIF_BOOLEAN) (EIF_BOOLEAN)(NULL == NULL);
			/* END INLINED CODE */
		}
		;
	}
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_13_16_0_4_) == ((EIF_INTEGER_32) 3L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
		{
			/* INLINED CODE (PROCESS_UNIX_PROCESS_MANAGER.set_error_same_as_output) */
			(void) RTCW(tr1);
			*(EIF_BOOLEAN *)(tr1+ _CHROFF_15_10_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			*(EIF_BOOLEAN *)(tr1+ _CHROFF_15_9_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			*(EIF_REFERENCE *)(tr1 + _REFACS_8_) = (EIF_REFERENCE) NULL;
			/* END INLINED CODE */
		}
		;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
			{
				/* INLINED CODE (UTF_CONVERTER.escaped_utf_32_string_to_utf_8_string_8) */
				tr2 = (EIF_REFERENCE)  0;
				(void) RTCW(loc1);
				tr2 = RTLNS(eif_new_type(2247, 0x00).id, 2247, _OBJSIZ_1_1_0_3_0_0_0_0_);
				ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R16992[Dtype(loc4)-2246])(loc4);
				F2246_21883(RTCW(tr2), ti4_1);
				F164_2784(loc1, loc4, tr2);
				/* END INLINED CODE */
			}
			tr2 = tr2;
			{
				/* INLINED CODE (PROCESS_UNIX_PROCESS_MANAGER.set_error_file_name) */
				(void) RTCW(tr1);
				RTAR(tr1, tr2);
				*(EIF_REFERENCE *)(tr1 + _REFACS_8_) = (EIF_REFERENCE) tr2;
				*(EIF_BOOLEAN *)(tr1+ _CHROFF_15_9_) = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr2 == NULL);
				*(EIF_BOOLEAN *)(tr1+ _CHROFF_15_10_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				/* END INLINED CODE */
			}
			;
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
			{
				/* INLINED CODE (PROCESS_UNIX_PROCESS_MANAGER.set_error_file_name) */
				(void) RTCW(tr1);
				RTAR(tr1, NULL);
				*(EIF_REFERENCE *)(tr1 + _REFACS_8_) = (EIF_REFERENCE) NULL;
				*(EIF_BOOLEAN *)(tr1+ _CHROFF_15_9_) = (EIF_BOOLEAN) (EIF_BOOLEAN)(NULL == NULL);
				*(EIF_BOOLEAN *)(tr1+ _CHROFF_15_10_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				/* END INLINED CODE */
			}
			;
		}
	}
	RTLE;
}

/* {BASE_PROCESS_IMP}.setup_command */
void F974_13518 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,arg3);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,arg2);
	RTLR(6,loc2);
	RTLIU(7);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(2251, 0x00).id, 2251, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R16992[Dtype(RTCW(arg1))-2246])(arg1);
	F2250_22049(RTCW(loc1), ti4_1);
	F2252_22163(RTCW(loc1), arg1);
	{
		/* INLINED CODE (BASE_PROCESS.initialize_working_directory) */
		if ((EIF_BOOLEAN)(arg3 != NULL)) {
			tr1 = RTLNSMART(eif_new_type(2250, 0).id);
			F2251_22102(RTCW(tr1), arg3);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		} else {
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
		}
		/* END INLINED CODE */
	}
	;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) arg2;
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11537[Dtype(RTCW(arg2))-991])(arg2);
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11319[Dtype(loc2)-941])(loc2);
			if (tb1) break;
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
			F2252_22177(RTCW(loc1), tw1);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11318[Dtype(loc2)-941])(loc2);
			F2252_22163(RTCW(loc1), tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R11320[Dtype(loc2)-941])(loc2);
		}
	}
	tr1 = RTLNS(eif_new_type(2250, 0x00).id, 2250, _OBJSIZ_1_0_0_4_0_0_0_0_);
	F2251_22104(RTCW(tr1), loc1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {BASE_PROCESS_IMP}.create_child_process_manager */
void F974_13519 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(785, 0).id);
	F786_11083(RTCW(tr1), arg1, arg2, arg3);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	{
		/* INLINED CODE (PROCESS_UNIX_PROCESS_MANAGER.set_close_nonstandard_files) */
		(void) RTCW(tr1);
		*(EIF_BOOLEAN *)(tr1+ _CHROFF_15_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		/* END INLINED CODE */
	}
	;
	RTLE;
}

void EIF_Minit802 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
