
#ifndef _C17_ki846_
#define _C17_ki846_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1655_15372(EIF_REFERENCE, EIF_REFERENCE);
extern void F1655_15373(EIF_REFERENCE);
extern void EIF_Minit846(void);
extern char *(*R12582[])();
extern char *(*R12602[])();

#ifdef __cplusplus
}
#endif

#endif
