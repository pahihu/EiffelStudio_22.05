/*
 * Code for class PLAIN_TEXT_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pl816.h"
#include "eif_built_in.h"
#include "eif_file.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PLAIN_TEXT_FILE}.make_with_name */
void F1439_14449 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	{
		/* INLINED CODE (FILE.make_with_name) */
		{
		EIF_TYPE_INDEX inlined_dtype = Dtype(Current);
		F1437_14331(Current, arg1);
		*(EIF_INTEGER_32 *)(Current + O12071[inlined_dtype-1436]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		tp1 = F1_33(Current);
		*(EIF_POINTER *)(Current + O11932[inlined_dtype-1436]) = (EIF_POINTER) tp1;
		tr1 = RTLNSMART(eif_new_type(2247, 0).id);
		F2243_21753(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O11174[inlined_dtype-920]) = (EIF_REFERENCE) tr1;
		}
		/* END INLINED CODE */
	}
	;
	tr1 = RTLNSMART(eif_new_type(2251, 0).id);
	F2243_21753(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {PLAIN_TEXT_FILE}.make_with_path */
void F1439_14450 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	{
		/* INLINED CODE (FILE.make_with_path) */
		{
		EIF_TYPE_INDEX inlined_dtype = Dtype(Current);
		F1437_14332(Current, arg1);
		*(EIF_INTEGER_32 *)(Current + O12071[inlined_dtype-1436]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		tp1 = F1_33(Current);
		*(EIF_POINTER *)(Current + O11932[inlined_dtype-1436]) = (EIF_POINTER) tp1;
		tr1 = RTLNSMART(eif_new_type(2247, 0).id);
		F2243_21753(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O11174[inlined_dtype-920]) = (EIF_REFERENCE) tr1;
		}
		/* END INLINED CODE */
	}
	;
	tr1 = RTLNSMART(eif_new_type(2251, 0).id);
	F2243_21753(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {PLAIN_TEXT_FILE}.support_storable */
EIF_BOOLEAN F1439_14452 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_FALSE;
}

/* {PLAIN_TEXT_FILE}.put_integer */
void F1439_14453 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = eif_out__i4_s1(arg1);
	F1439_14473(Current, tr1);
	RTLE;
}

/* {PLAIN_TEXT_FILE}.put_integer_32 */
void F1439_14455 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = eif_out__i4_s1(arg1);
	F1439_14473(Current, tr1);
	RTLE;
}

/* {PLAIN_TEXT_FILE}.put_boolean */
void F1439_14464 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if (arg1) {
		tr1 = RTOSCF(14335,F1437_14335, (Current));
	} else {
		tr1 = RTOSCF(14336,F1437_14336, (Current));
	}
	F1439_14473(Current, tr1);
	RTLE;
}

/* {PLAIN_TEXT_FILE}.put_real */
void F1439_14466 (EIF_REFERENCE Current, EIF_REAL_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current + O11932[Dtype(Current)-1436]);
	eif_file_pr((FILE*) tp1, (EIF_REAL_32) arg1);
}

/* {PLAIN_TEXT_FILE}.put_string_32 */
void F1439_14472 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1439_14473(Current, arg1);
}

/* {PLAIN_TEXT_FILE}.put_string_general */
void F1439_14473 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,arg1);
	RTLR(5,loc1);
	RTLR(6,loc3);
	RTLR(7,tr2);
	RTLR(8,tr3);
	RTLIU(9);
	
	RTGC;
	loc4 = F1439_14494(Current);
	tr1 = RTLNS(eif_new_type(787, 0x00).id, 787, _OBJSIZ_0_0_0_0_0_0_0_0_);
	loc2 = RTOSCF(11154,F788_11154, (RTCW(tr1)));
	F142_2554(RTCW(loc2), loc4, arg1);
	{
		/* INLINED CODE (ENCODING.last_conversion_successful) */
		tb1 = (EIF_BOOLEAN)  0;
		(void) RTCW(loc2);
		tr1 = *(EIF_REFERENCE *)(loc2 + _REFACS_1_);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O23938[Dtype(tr1)-2938]);
		/* END INLINED CODE */
	}
	tb1 = tb1;
	if (tb1) {
		{
			/* INLINED CODE (ENCODING.last_converted_string_8) */
			tr1 = (EIF_REFERENCE)  0;
			(void) RTCW(loc2);
			tr1 = F142_2550(loc2);
			/* END INLINED CODE */
		}
		loc1 = tr1;
	} else {
		tr1 = RTLNS(eif_new_type(787, 0x00).id, 787, _OBJSIZ_0_0_0_0_0_0_0_0_);
		loc3 = RTOSCF(11152,F788_11152, (RTCW(tr1)));
		F142_2554(RTCW(loc2), loc3, arg1);
		{
			/* INLINED CODE (ENCODING.last_conversion_successful) */
			tb1 = (EIF_BOOLEAN)  0;
			(void) RTCW(loc2);
			tr1 = *(EIF_REFERENCE *)(loc2 + _REFACS_1_);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O23938[Dtype(tr1)-2938]);
			/* END INLINED CODE */
		}
		tb1 = tb1;
		if (tb1) {
			{
				/* INLINED CODE (ENCODING.last_converted_string_8) */
				tr1 = (EIF_REFERENCE)  0;
				(void) RTCW(loc2);
				tr1 = F142_2550(loc2);
				/* END INLINED CODE */
			}
			loc1 = tr1;
			{
				/* INLINED CODE (ENCODING.same_as) */
				tb1 = (EIF_BOOLEAN)  0;
				(void) RTCW(loc3);
				tr1 = *(EIF_REFERENCE *)(loc3);
				tr2 = *(EIF_REFERENCE *)(RTCW(loc4));
				tb1 = F2246_21909(RTCW(tr1), tr2);
				/* END INLINED CODE */
			}
			tb1 = tb1;
			if ((EIF_BOOLEAN) !tb1) {
				F142_2554(RTCW(loc3), loc4, loc1);
				{
					/* INLINED CODE (ENCODING.last_conversion_successful) */
					tb1 = (EIF_BOOLEAN)  0;
					(void) RTCW(loc3);
					tr1 = *(EIF_REFERENCE *)(loc3 + _REFACS_1_);
					tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O23938[Dtype(tr1)-2938]);
					/* END INLINED CODE */
				}
				tb1 = tb1;
				if (tb1) {
					{
						/* INLINED CODE (ENCODING.last_converted_string_8) */
						tr1 = (EIF_REFERENCE)  0;
						(void) RTCW(loc3);
						tr1 = F142_2550(loc3);
						/* END INLINED CODE */
					}
					loc1 = tr1;
				}
			}
		} else {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R16969[Dtype(RTCW(arg1))-2246])(arg1);
			if (tb1) {
				loc1 = F2243_21806(RTCW(arg1));
			} else {
				tr2 = F2243_21812(RTCW(arg1));
				tr1 = RTLNS(eif_new_type(163, 0x00).id, 163, _OBJSIZ_0_0_0_0_0_0_0_0_);
				{
					/* INLINED CODE (UTF_CONVERTER.string_32_to_utf_8_string_8) */
					tr3 = (EIF_REFERENCE)  0;
					(void) RTCW(tr1);
					tr3 = F164_2779(tr1, tr2);
					/* END INLINED CODE */
				}
				loc1 = tr3;
			}
		}
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11203[Dtype(Current)-1437])(Current, loc1);
	RTLE;
}

/* {PLAIN_TEXT_FILE}.read_integer */
void F1439_14475 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R12107[dtype-1438])(Current);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R12103[dtype-1438])(Current);
	ti4_1 = F449_6557(RTCW(tr1));
	*(EIF_INTEGER_32 *)(Current + O11175[dtype-920]) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

/* {PLAIN_TEXT_FILE}.read_natural_8 */
void F1439_14484 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_8 tu1_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R12107[dtype-1438])(Current);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R12103[dtype-1438])(Current);
	{
		/* INLINED CODE (STRING_TO_INTEGER_CONVERTOR.parsed_natural_8) */
		tu1_1 = (EIF_NATURAL_8)  0;
		(void) RTCW(tr1);
		tu1_1 = (EIF_NATURAL_8) ((EIF_NATURAL_64) ((EIF_NATURAL_64) (*(EIF_NATURAL_64 *)(tr1+ _I64OFF_2_3_0_3_0_0_0_) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 10L)) + *(EIF_NATURAL_64 *)(tr1+ _I64OFF_2_3_0_3_0_0_1_)));
		/* END INLINED CODE */
	}
	tu1_1 = tu1_1;
	*(EIF_NATURAL_8 *)(Current + O11184[dtype-920]) = (EIF_NATURAL_8) tu1_1;
	RTLE;
}

/* {PLAIN_TEXT_FILE}.encoding */
EIF_REFERENCE F1439_14494 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R12097[Dtype(Current)-1438])(Current);
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {PLAIN_TEXT_FILE}.default_encoding */
static EIF_REFERENCE F1439_14495_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	

	
	RTEV;
	RTOSP (14495);
#define Result RTOSR(14495)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(787, 0x00).id, 787, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = RTOSCF(11152,F788_11152, (RTCW(tr1)));
	RTOSE (14495);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1439_14495 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14495,F1439_14495_body,(Current));
}

/* {PLAIN_TEXT_FILE}.ctoi_convertor */
static EIF_REFERENCE F1439_14501_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (14501);
#define Result RTOSR(14501)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(448, 0x00).id, 448, _OBJSIZ_2_3_0_3_0_0_2_0_);
	F449_6544(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(14502,F1439_14502, (Current));
	{
		/* INLINED CODE (STRING_TO_NUMERIC_CONVERTOR.set_leading_separators) */
		(void) RTCW(Result);
		tr2 = RTLNSMART(eif_new_type(2247, 0).id);
		F2246_21885(RTCW(tr2), tr1);
		RTAR(Result, tr2);
		*(EIF_REFERENCE *)(Result) = (EIF_REFERENCE) tr2;
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (STRING_TO_NUMERIC_CONVERTOR.set_leading_separators_acceptable) */
		(void) RTCW(Result);
		*(EIF_BOOLEAN *)(Result+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (STRING_TO_NUMERIC_CONVERTOR.set_trailing_separators_acceptable) */
		(void) RTCW(Result);
		*(EIF_BOOLEAN *)(Result+ _CHROFF_2_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		/* END INLINED CODE */
	}
	;
	RTOSE (14501);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1439_14501 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14501,F1439_14501_body,(Current));
}

/* {PLAIN_TEXT_FILE}.internal_leading_separators */

EIF_REFERENCE F1439_14502 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (14502,RTMS_EX_H(" \012\015\011",4,537529609));
}

/* {PLAIN_TEXT_FILE}.read_number_sequence */
void F1439_14504 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6285[Dtype(RTCW(arg1))-447])(arg1, arg2);
	*(EIF_BOOLEAN *)(Current + O12105[dtype-1438]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	for (;;) {
		tb1 = '\01';
		if (!(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11944[dtype-1437])(Current)) {
			tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O12105[dtype-1438]);
		}
		if (tb1) break;
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11233[dtype-1437])(Current);
		if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11944[dtype-1437])(Current)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R6291[Dtype(RTCW(arg1))-447])(arg1, *(EIF_CHARACTER_8 *)(Current + O11173[dtype-920]));
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6283[Dtype(RTCW(arg1))-447])(arg1);
			*(EIF_BOOLEAN *)(Current + O12105[dtype-1438]) = (EIF_BOOLEAN) tb2;
		}
	}
	RTLE;
}

/* {PLAIN_TEXT_FILE}.read_integer_with_no_type */
void F1439_14505 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R12103[dtype-1438])(Current);
	F1439_14504(Current, tr1, ((EIF_INTEGER_32) 0L));
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O12105[dtype-1438])) {
		{
			/* INLINED CODE (PLAIN_TEXT_FILE.return_characters) */
			{
			EIF_TYPE_INDEX inlined_dtype = Dtype(Current);
			tb1 = '\0';
			if ((EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current + O11173[inlined_dtype-920]) == (EIF_CHARACTER_8) '\012')) {
				tb2 = (EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b;
				tb1 = tb2;
			}
			if (tb1) {
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R11791[inlined_dtype-1437])(Current);
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R11791[inlined_dtype-1437])(Current);
			}
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
}

/* {PLAIN_TEXT_FILE}.return_characters */
void F1439_14506 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current + O11173[dtype-920]) == (EIF_CHARACTER_8) '\012')) {
		tb1 = (EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b;
	}
	if (tb1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11791[dtype-1437])(Current);
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R11791[dtype-1437])(Current);
	RTLE;
}

/* {PLAIN_TEXT_FILE}.file_pr */
void F1439_14511 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	GTCX
	
	eif_file_pr((FILE*) arg1, (EIF_REAL_32) arg2);
	
}

void EIF_Minit816 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
