#include "eif_eiffel.h"
#include "eif_rout_obj.h"
#include "eaddress.h"
#include "eoffsets.h"

#ifdef __cplusplus
extern "C" {
#endif

	/* I18N_PLURAL_TOOLS reduce_one_plural_form */
EIF_INTEGER_32 _A20_50_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_one_plural_form */
EIF_INTEGER_32 __A20_50_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_two_plural_forms_singular_one */
EIF_INTEGER_32 _A20_51_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_two_plural_forms_singular_one */
EIF_INTEGER_32 __A20_51_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_two_plural_forms_singular_one_zero */
EIF_INTEGER_32 _A20_52_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_two_plural_forms_singular_one_zero */
EIF_INTEGER_32 __A20_52_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_zero */
EIF_INTEGER_32 _A20_53_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_zero */
EIF_INTEGER_32 __A20_53_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_one_two */
EIF_INTEGER_32 _A20_54_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_one_two */
EIF_INTEGER_32 __A20_54_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_twelve_to_nineteen */
EIF_INTEGER_32 _A20_55_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_twelve_to_nineteen */
EIF_INTEGER_32 __A20_55_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_slavic */
EIF_INTEGER_32 _A20_56_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_slavic */
EIF_INTEGER_32 __A20_56_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_polish */
EIF_INTEGER_32 _A20_57_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_polish */
EIF_INTEGER_32 __A20_57_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_four_plural_forms_special_slovenian */
EIF_INTEGER_32 _A20_58_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_four_plural_forms_special_slovenian */
EIF_INTEGER_32 __A20_58_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* AST_ATTRIBUTE_INITIALIZATION_TRACKER is_attribute_set */
EIF_BOOLEAN _A44_33_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* AST_ATTRIBUTE_INITIALIZATION_TRACKER is_attribute_set */
EIF_BOOLEAN __A44_33_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* COMPOSITE_FORMATTER [G#1] inline-agent#1 of list */
void _A3404_48_2_5 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F78_45579)(closed [1].it_r, open [1].it_r, closed [2].it_r, closed [3].it_r, open [2].it_r);
}

	/* COMPOSITE_FORMATTER [G#1] inline-agent#1 of list */
void __A3404_48_2_5 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_5)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F78_45579)(closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r, op_5);
}

	/* DESCRIPTOR_CACHE c_iconv_close */
void _A84_42_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_p);
}

	/* DESCRIPTOR_CACHE c_iconv_close */
void __A84_42_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* SHARED_SERVICE_PROVIDER inline-agent#1 of service_provider */
EIF_REFERENCE _A381_33 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F435_45649)(closed [1].it_r, closed [2].it_r);
}

	/* SHARED_SERVICE_PROVIDER inline-agent#1 of service_provider */
EIF_REFERENCE __A381_33 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F435_45649)(closed [1].it_r, closed [2].it_r);
}

	/* SHARED_SERVICE_PROVIDER inline-agent#2 of service_provider */
EIF_REFERENCE _A381_34 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F435_45650)(closed [1].it_r, closed [2].it_r);
}

	/* SHARED_SERVICE_PROVIDER inline-agent#2 of service_provider */
EIF_REFERENCE __A381_34 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F435_45650)(closed [1].it_r, closed [2].it_r);
}

	/* FORMATTED_MESSAGE element */
EIF_REFERENCE _A551_32_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* FORMATTED_MESSAGE element */
EIF_REFERENCE __A551_32_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* FORMATTED_MESSAGE inline-agent#1 of message_formatter */
void _A551_41_2_3_4_5 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) F642_45679)(closed [1].it_r, open [1].it_r, open [2].it_r, open [3].it_i4, open [4].it_i4);
}

	/* FORMATTED_MESSAGE inline-agent#1 of message_formatter */
void __A551_41_2_3_4_5 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_3, EIF_INTEGER_32 op_4, EIF_INTEGER_32 op_5)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) F642_45679)(closed [1].it_r, op_2, op_3, op_4, op_5);
}

	/* FORMATTED_MESSAGE inline-agent#1 of add_list */
void _A551_42_2_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F642_45680)(closed [1].it_r, open [1].it_r, open [2].it_r, open [3].it_r);
}

	/* FORMATTED_MESSAGE inline-agent#1 of add_list */
void __A551_42_2_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_3, EIF_REFERENCE op_4)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F642_45680)(closed [1].it_r, op_2, op_3, op_4);
}

	/* FORMATTED_MESSAGE inline-agent#1 of element */
void _A551_43_2_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F642_45681)(closed [1].it_r, open [1].it_r, closed [2].it_r, open [2].it_r);
}

	/* FORMATTED_MESSAGE inline-agent#1 of element */
void __A551_43_2_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_4)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F642_45681)(closed [1].it_r, op_2, closed [2].it_r, op_4);
}

	/* TYPED_PREFERENCE [G#1] try_to_set_value_to_auto */
void _A2928_68 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* TYPED_PREFERENCE [INTEGER_32] try_to_set_value_to_auto */
void _A3591_68 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* TYPED_PREFERENCE [BOOLEAN] try_to_set_value_to_auto */
void _A3665_68 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* TYPED_PREFERENCE [G#1] try_to_set_value_to_auto */
void __A2928_68 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* TYPED_PREFERENCE [INTEGER_32] try_to_set_value_to_auto */
void __A3591_68 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* TYPED_PREFERENCE [BOOLEAN] try_to_set_value_to_auto */
void __A3665_68 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* TYPED_PREFERENCE [G#1] update_is_auto */
void _A2928_69 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* TYPED_PREFERENCE [INTEGER_32] update_is_auto */
void _A3591_69 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* TYPED_PREFERENCE [BOOLEAN] update_is_auto */
void _A3665_69 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* TYPED_PREFERENCE [G#1] update_is_auto */
void __A2928_69 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* TYPED_PREFERENCE [INTEGER_32] update_is_auto */
void __A3591_69 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* TYPED_PREFERENCE [BOOLEAN] update_is_auto */
void __A3665_69 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* LIST [G#1] extend */
void _A2802_91_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* LIST [INTEGER_32] extend */
void _A2877_91_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (2);
	
	RTLR(0,closed [1].it_r);
	RTLR(1,arg1);
	RTLIU(2);
	arg1 = RTLNS(eif_new_type(2055, 0x00).id, 2055, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg1 = open [1].it_i4;
	f_ptr (closed [1].it_r, arg1);
	RTLE;
}

	/* LIST [NATURAL_8] extend */
void _A2915_91_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_8), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_n1);
}

	/* LIST [BOOLEAN] extend */
void _A2985_91_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (2);
	
	RTLR(0,closed [1].it_r);
	RTLR(1,arg1);
	RTLIU(2);
	arg1 = RTLNS(eif_new_type(2088, 0x00).id, 2088, _OBJSIZ_0_1_0_0_0_0_0_0_);
	*(EIF_BOOLEAN *)arg1 = open [1].it_b;
	f_ptr (closed [1].it_r, arg1);
	RTLE;
}

	/* LIST [NATURAL_64] extend */
void _A3020_91_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (2);
	
	RTLR(0,closed [1].it_r);
	RTLR(1,arg1);
	RTLIU(2);
	arg1 = RTLNS(eif_new_type(2064, 0x00).id, 2064, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_NATURAL_64 *)arg1 = open [1].it_n8;
	f_ptr (closed [1].it_r, arg1);
	RTLE;
}

	/* LIST [POINTER] extend */
void _A3106_91_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_p);
}

	/* LIST [NATURAL_32] extend */
void _A3188_91_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_n4);
}

	/* LIST [CHARACTER_32] extend */
void _A3225_91_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (2);
	
	RTLR(0,closed [1].it_r);
	RTLR(1,arg1);
	RTLIU(2);
	arg1 = RTLNS(eif_new_type(2082, 0x00).id, 2082, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_CHARACTER_32 *)arg1 = open [1].it_c4;
	f_ptr (closed [1].it_r, arg1);
	RTLE;
}

	/* LIST [INTEGER_64] extend */
void _A3391_91_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (2);
	
	RTLR(0,closed [1].it_r);
	RTLR(1,arg1);
	RTLIU(2);
	arg1 = RTLNS(eif_new_type(2052, 0x00).id, 2052, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_INTEGER_64 *)arg1 = open [1].it_i8;
	f_ptr (closed [1].it_r, arg1);
	RTLE;
}

	/* LIST [CHARACTER_8] extend */
void _A3457_91_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_c1);
}

	/* LIST [NATURAL_16] extend */
void _A3508_91_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_16), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_n2);
}

	/* LIST [INTEGER_8] extend */
void _A3701_91_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_8), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i1);
}

	/* LIST [REAL_64] extend */
void _A3737_91_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REAL_64), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r8);
}

	/* LIST [REAL_32] extend */
void _A3773_91_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REAL_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r4);
}

	/* LIST [INTEGER_16] extend */
void _A3809_91_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_16), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i2);
}

	/* LIST [G#1] extend */
void __A2802_91_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* LIST [INTEGER_32] extend */
void __A2877_91_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (2);
	
	RTLR(0,closed [1].it_r);
	RTLR(1,arg1);
	RTLIU(2);
	arg1 = RTLNS(eif_new_type(2055, 0x00).id, 2055, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg1 = op_2;
	f_ptr (closed [1].it_r, arg1);
	RTLE;
}

	/* LIST [NATURAL_8] extend */
void __A2915_91_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_8), EIF_TYPED_VALUE * closed, EIF_NATURAL_8 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* LIST [BOOLEAN] extend */
void __A2985_91_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_BOOLEAN op_2)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (2);
	
	RTLR(0,closed [1].it_r);
	RTLR(1,arg1);
	RTLIU(2);
	arg1 = RTLNS(eif_new_type(2088, 0x00).id, 2088, _OBJSIZ_0_1_0_0_0_0_0_0_);
	*(EIF_BOOLEAN *)arg1 = op_2;
	f_ptr (closed [1].it_r, arg1);
	RTLE;
}

	/* LIST [NATURAL_64] extend */
void __A3020_91_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_NATURAL_64 op_2)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (2);
	
	RTLR(0,closed [1].it_r);
	RTLR(1,arg1);
	RTLIU(2);
	arg1 = RTLNS(eif_new_type(2064, 0x00).id, 2064, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_NATURAL_64 *)arg1 = op_2;
	f_ptr (closed [1].it_r, arg1);
	RTLE;
}

	/* LIST [POINTER] extend */
void __A3106_91_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* LIST [NATURAL_32] extend */
void __A3188_91_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_32), EIF_TYPED_VALUE * closed, EIF_NATURAL_32 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* LIST [CHARACTER_32] extend */
void __A3225_91_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_CHARACTER_32 op_2)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (2);
	
	RTLR(0,closed [1].it_r);
	RTLR(1,arg1);
	RTLIU(2);
	arg1 = RTLNS(eif_new_type(2082, 0x00).id, 2082, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_CHARACTER_32 *)arg1 = op_2;
	f_ptr (closed [1].it_r, arg1);
	RTLE;
}

	/* LIST [INTEGER_64] extend */
void __A3391_91_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_64 op_2)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (2);
	
	RTLR(0,closed [1].it_r);
	RTLR(1,arg1);
	RTLIU(2);
	arg1 = RTLNS(eif_new_type(2052, 0x00).id, 2052, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_INTEGER_64 *)arg1 = op_2;
	f_ptr (closed [1].it_r, arg1);
	RTLE;
}

	/* LIST [CHARACTER_8] extend */
void __A3457_91_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8), EIF_TYPED_VALUE * closed, EIF_CHARACTER_8 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* LIST [NATURAL_16] extend */
void __A3508_91_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_16), EIF_TYPED_VALUE * closed, EIF_NATURAL_16 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* LIST [INTEGER_8] extend */
void __A3701_91_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_8), EIF_TYPED_VALUE * closed, EIF_INTEGER_8 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* LIST [REAL_64] extend */
void __A3737_91_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REAL_64), EIF_TYPED_VALUE * closed, EIF_REAL_64 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* LIST [REAL_32] extend */
void __A3773_91_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REAL_32), EIF_TYPED_VALUE * closed, EIF_REAL_32 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* LIST [INTEGER_16] extend */
void __A3809_91_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_16), EIF_TYPED_VALUE * closed, EIF_INTEGER_16 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY value_criterion_evalaute_agent */
EIF_BOOLEAN _A637_45_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY value_criterion_evalaute_agent */
EIF_BOOLEAN __A637_45_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY true_agent */
EIF_BOOLEAN _A637_142_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY true_agent */
EIF_BOOLEAN __A637_142_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY is_visible_agent */
EIF_BOOLEAN _A637_165_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY is_visible_agent */
EIF_BOOLEAN __A637_165_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY is_overrider_agent */
EIF_BOOLEAN _A637_164_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY is_overrider_agent */
EIF_BOOLEAN __A637_164_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY is_overriden_agent */
EIF_BOOLEAN _A637_163_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY is_overriden_agent */
EIF_BOOLEAN __A637_163_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY is_read_only_agent */
EIF_BOOLEAN _A637_162_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY is_read_only_agent */
EIF_BOOLEAN __A637_162_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY is_partial_agent */
EIF_BOOLEAN _A637_161_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY is_partial_agent */
EIF_BOOLEAN __A637_161_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY is_always_compiled_agent */
EIF_BOOLEAN _A637_160_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY is_always_compiled_agent */
EIF_BOOLEAN __A637_160_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY is_valid_agent */
EIF_BOOLEAN _A637_159_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY is_valid_agent */
EIF_BOOLEAN __A637_159_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY is_precompiled_agent */
EIF_BOOLEAN _A637_158_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY is_precompiled_agent */
EIF_BOOLEAN __A637_158_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY is_obsolete_agent */
EIF_BOOLEAN _A637_157_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY is_obsolete_agent */
EIF_BOOLEAN __A637_157_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY is_generic_agent */
EIF_BOOLEAN _A637_156_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY is_generic_agent */
EIF_BOOLEAN __A637_156_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY is_frozen_agent */
EIF_BOOLEAN _A637_155_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY is_frozen_agent */
EIF_BOOLEAN __A637_155_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY is_external_agent */
EIF_BOOLEAN _A637_154_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY is_external_agent */
EIF_BOOLEAN __A637_154_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY is_once_agent */
EIF_BOOLEAN _A637_153_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY is_once_agent */
EIF_BOOLEAN __A637_153_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY is_expanded_agent */
EIF_BOOLEAN _A637_152_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY is_expanded_agent */
EIF_BOOLEAN __A637_152_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY is_enum_agent */
EIF_BOOLEAN _A637_151_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY is_enum_agent */
EIF_BOOLEAN __A637_151_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY is_effective_agent */
EIF_BOOLEAN _A637_150_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY is_effective_agent */
EIF_BOOLEAN __A637_150_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY is_deferred_agent */
EIF_BOOLEAN _A637_149_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY is_deferred_agent */
EIF_BOOLEAN __A637_149_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY is_compiled_agent */
EIF_BOOLEAN _A637_148_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY is_compiled_agent */
EIF_BOOLEAN __A637_148_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY has_top_indexing_agent */
EIF_BOOLEAN _A637_145_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY has_top_indexing_agent */
EIF_BOOLEAN __A637_145_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY has_invariant_agent */
EIF_BOOLEAN _A637_147_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY has_invariant_agent */
EIF_BOOLEAN __A637_147_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY has_indexing_agent */
EIF_BOOLEAN _A637_146_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY has_indexing_agent */
EIF_BOOLEAN __A637_146_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY has_bottom_indexing_agent */
EIF_BOOLEAN _A637_144_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY has_bottom_indexing_agent */
EIF_BOOLEAN __A637_144_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY false_agent */
EIF_BOOLEAN _A637_143_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY false_agent */
EIF_BOOLEAN __A637_143_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY new_false_criterion */
EIF_REFERENCE _A637_50 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_false_criterion */
EIF_REFERENCE __A637_50 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_has_bottom_indexing_criterion */
EIF_REFERENCE _A637_51 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_has_bottom_indexing_criterion */
EIF_REFERENCE __A637_51 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_has_indexing_criterion */
EIF_REFERENCE _A637_52 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_has_indexing_criterion */
EIF_REFERENCE __A637_52 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_has_invariant_criterion */
EIF_REFERENCE _A637_53 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_has_invariant_criterion */
EIF_REFERENCE __A637_53 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_has_top_indexing_criterion */
EIF_REFERENCE _A637_54 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_has_top_indexing_criterion */
EIF_REFERENCE __A637_54 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_compiled_criterion */
EIF_REFERENCE _A637_55 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_compiled_criterion */
EIF_REFERENCE __A637_55 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_deferred_criterion */
EIF_REFERENCE _A637_56 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_deferred_criterion */
EIF_REFERENCE __A637_56 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_effective_criterion */
EIF_REFERENCE _A637_57 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_effective_criterion */
EIF_REFERENCE __A637_57 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_enum_criterion */
EIF_REFERENCE _A637_58 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_enum_criterion */
EIF_REFERENCE __A637_58 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_expanded_criterion */
EIF_REFERENCE _A637_59 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_expanded_criterion */
EIF_REFERENCE __A637_59 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_once_criterion */
EIF_REFERENCE _A637_60 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_once_criterion */
EIF_REFERENCE __A637_60 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_external_criterion */
EIF_REFERENCE _A637_61 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_external_criterion */
EIF_REFERENCE __A637_61 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_frozen_criterion */
EIF_REFERENCE _A637_62 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_frozen_criterion */
EIF_REFERENCE __A637_62 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_generic_criterion */
EIF_REFERENCE _A637_63 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_generic_criterion */
EIF_REFERENCE __A637_63 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_obsolete_criterion */
EIF_REFERENCE _A637_64 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_obsolete_criterion */
EIF_REFERENCE __A637_64 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_precompiled_criterion */
EIF_REFERENCE _A637_65 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_precompiled_criterion */
EIF_REFERENCE __A637_65 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_true_criterion */
EIF_REFERENCE _A637_73 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_true_criterion */
EIF_REFERENCE __A637_73 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_valid_criterion */
EIF_REFERENCE _A637_66 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_valid_criterion */
EIF_REFERENCE __A637_66 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_always_compiled_criterion */
EIF_REFERENCE _A637_67 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_always_compiled_criterion */
EIF_REFERENCE __A637_67 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_partial_criterion */
EIF_REFERENCE _A637_68 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_partial_criterion */
EIF_REFERENCE __A637_68 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_read_only_criterion */
EIF_REFERENCE _A637_69 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_read_only_criterion */
EIF_REFERENCE __A637_69 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_overriden_criterion */
EIF_REFERENCE _A637_70 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_overriden_criterion */
EIF_REFERENCE __A637_70 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_overrider_criterion */
EIF_REFERENCE _A637_71 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_overrider_criterion */
EIF_REFERENCE __A637_71 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_visible_criterion */
EIF_REFERENCE _A637_72 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_is_visible_criterion */
EIF_REFERENCE __A637_72 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_path_in_criterion */
EIF_REFERENCE _A637_81_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_path_in_criterion */
EIF_REFERENCE __A637_81_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY new_path_is_criterion */
EIF_REFERENCE _A637_82_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_path_is_criterion */
EIF_REFERENCE __A637_82_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY new_ancestor_is_criterion */
EIF_REFERENCE _A637_84_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_ancestor_is_criterion */
EIF_REFERENCE __A637_84_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY new_proper_ancestor_is_criterion */
EIF_REFERENCE _A637_85_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_proper_ancestor_is_criterion */
EIF_REFERENCE __A637_85_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY new_parent_is_criterion */
EIF_REFERENCE _A637_86_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_parent_is_criterion */
EIF_REFERENCE __A637_86_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY new_indirect_parent_is_criterion */
EIF_REFERENCE _A637_87_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_indirect_parent_is_criterion */
EIF_REFERENCE __A637_87_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY new_descendant_is_criterion */
EIF_REFERENCE _A637_88_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_descendant_is_criterion */
EIF_REFERENCE __A637_88_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY new_proper_descendant_is_criterion */
EIF_REFERENCE _A637_89_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_proper_descendant_is_criterion */
EIF_REFERENCE __A637_89_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY new_heir_is_criterion */
EIF_REFERENCE _A637_90_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_heir_is_criterion */
EIF_REFERENCE __A637_90_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY new_indirect_heir_is_criterion */
EIF_REFERENCE _A637_91_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_indirect_heir_is_criterion */
EIF_REFERENCE __A637_91_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_CRITERION_FACTORY new_supplier_criterion */
EIF_REFERENCE _A637_92_2_3_4_5 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_BOOLEAN, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_b, open [3].it_b, open [4].it_b);
}

	/* QL_CLASS_CRITERION_FACTORY new_supplier_criterion */
EIF_REFERENCE __A637_92_2_3_4_5 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_BOOLEAN, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_BOOLEAN op_3, EIF_BOOLEAN op_4, EIF_BOOLEAN op_5)
{
	return f_ptr (closed [1].it_r, op_2, op_3, op_4, op_5);
}

	/* QL_CLASS_CRITERION_FACTORY new_client_criterion */
EIF_REFERENCE _A637_93_2_3_4_5 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_BOOLEAN, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_b, open [3].it_b, open [4].it_b);
}

	/* QL_CLASS_CRITERION_FACTORY new_client_criterion */
EIF_REFERENCE __A637_93_2_3_4_5 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_BOOLEAN, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_BOOLEAN op_3, EIF_BOOLEAN op_4, EIF_BOOLEAN op_5)
{
	return f_ptr (closed [1].it_r, op_2, op_3, op_4, op_5);
}

	/* QL_CLASS_CRITERION_FACTORY new_name_is_criterion */
EIF_REFERENCE _A637_74_2_3_4 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_b, open [3].it_i4);
}

	/* QL_CLASS_CRITERION_FACTORY new_name_is_criterion */
EIF_REFERENCE __A637_74_2_3_4 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_BOOLEAN op_3, EIF_INTEGER_32 op_4)
{
	return f_ptr (closed [1].it_r, op_2, op_3, op_4);
}

	/* QL_CLASS_CRITERION_FACTORY new_text_contain_criterion */
EIF_REFERENCE _A637_83_2_3_4 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_b, open [3].it_i4);
}

	/* QL_CLASS_CRITERION_FACTORY new_text_contain_criterion */
EIF_REFERENCE __A637_83_2_3_4 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_BOOLEAN op_3, EIF_INTEGER_32 op_4)
{
	return f_ptr (closed [1].it_r, op_2, op_3, op_4);
}

	/* QL_CLASS_CRITERION_FACTORY new_top_indexing_contain_criterion */
EIF_REFERENCE _A637_78_2_3_4 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_b, open [3].it_i4);
}

	/* QL_CLASS_CRITERION_FACTORY new_top_indexing_contain_criterion */
EIF_REFERENCE __A637_78_2_3_4 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_BOOLEAN op_3, EIF_INTEGER_32 op_4)
{
	return f_ptr (closed [1].it_r, op_2, op_3, op_4);
}

	/* QL_CLASS_CRITERION_FACTORY new_bottom_indexing_contain_criterion */
EIF_REFERENCE _A637_79_2_3_4 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_b, open [3].it_i4);
}

	/* QL_CLASS_CRITERION_FACTORY new_bottom_indexing_contain_criterion */
EIF_REFERENCE __A637_79_2_3_4 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_BOOLEAN op_3, EIF_INTEGER_32 op_4)
{
	return f_ptr (closed [1].it_r, op_2, op_3, op_4);
}

	/* QL_CLASS_CRITERION_FACTORY new_indexing_contain_criterion */
EIF_REFERENCE _A637_80_2_3_4 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_b, open [3].it_i4);
}

	/* QL_CLASS_CRITERION_FACTORY new_indexing_contain_criterion */
EIF_REFERENCE __A637_80_2_3_4 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_BOOLEAN op_3, EIF_INTEGER_32 op_4)
{
	return f_ptr (closed [1].it_r, op_2, op_3, op_4);
}

	/* QL_CLASS_CRITERION_FACTORY new_top_indexing_has_tag_criterion */
EIF_REFERENCE _A637_75_2_3_4 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_b, open [3].it_i4);
}

	/* QL_CLASS_CRITERION_FACTORY new_top_indexing_has_tag_criterion */
EIF_REFERENCE __A637_75_2_3_4 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_BOOLEAN op_3, EIF_INTEGER_32 op_4)
{
	return f_ptr (closed [1].it_r, op_2, op_3, op_4);
}

	/* QL_CLASS_CRITERION_FACTORY new_bottom_indexing_has_tag_criterion */
EIF_REFERENCE _A637_76_2_3_4 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_b, open [3].it_i4);
}

	/* QL_CLASS_CRITERION_FACTORY new_bottom_indexing_has_tag_criterion */
EIF_REFERENCE __A637_76_2_3_4 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_BOOLEAN op_3, EIF_INTEGER_32 op_4)
{
	return f_ptr (closed [1].it_r, op_2, op_3, op_4);
}

	/* QL_CLASS_CRITERION_FACTORY new_indexing_has_tag_criterion */
EIF_REFERENCE _A637_77_2_3_4 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_b, open [3].it_i4);
}

	/* QL_CLASS_CRITERION_FACTORY new_indexing_has_tag_criterion */
EIF_REFERENCE __A637_77_2_3_4 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_BOOLEAN op_3, EIF_INTEGER_32 op_4)
{
	return f_ptr (closed [1].it_r, op_2, op_3, op_4);
}

	/* QL_CLASS_CRITERION_FACTORY new_value_criterion */
EIF_REFERENCE _A637_94_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_CRITERION_FACTORY new_value_criterion */
EIF_REFERENCE __A637_94_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_GROUP_CRITERION_FACTORY value_criterion_evalaute_agent */
EIF_BOOLEAN _A638_45_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY value_criterion_evalaute_agent */
EIF_BOOLEAN __A638_45_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY true_agent */
EIF_BOOLEAN _A638_76_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY true_agent */
EIF_BOOLEAN __A638_76_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_GROUP_CRITERION_FACTORY is_class_set_agent */
EIF_BOOLEAN _A638_84_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY is_class_set_agent */
EIF_BOOLEAN __A638_84_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_GROUP_CRITERION_FACTORY is_used_in_library_agent */
EIF_BOOLEAN _A638_83_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY is_used_in_library_agent */
EIF_BOOLEAN __A638_83_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_GROUP_CRITERION_FACTORY is_valid_agent */
EIF_BOOLEAN _A638_82_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY is_valid_agent */
EIF_BOOLEAN __A638_82_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_GROUP_CRITERION_FACTORY is_override_agent */
EIF_BOOLEAN _A638_81_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY is_override_agent */
EIF_BOOLEAN __A638_81_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_GROUP_CRITERION_FACTORY is_library_agent */
EIF_BOOLEAN _A638_80_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY is_library_agent */
EIF_BOOLEAN __A638_80_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_GROUP_CRITERION_FACTORY is_compiled_agent */
EIF_BOOLEAN _A638_77_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY is_compiled_agent */
EIF_BOOLEAN __A638_77_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_GROUP_CRITERION_FACTORY is_cluster_agent */
EIF_BOOLEAN _A638_79_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY is_cluster_agent */
EIF_BOOLEAN __A638_79_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_GROUP_CRITERION_FACTORY is_assembly_agent */
EIF_BOOLEAN _A638_78_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY is_assembly_agent */
EIF_BOOLEAN __A638_78_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_GROUP_CRITERION_FACTORY false_agent */
EIF_BOOLEAN _A638_75_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY false_agent */
EIF_BOOLEAN __A638_75_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_GROUP_CRITERION_FACTORY new_false_criterion */
EIF_REFERENCE _A638_50 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY new_false_criterion */
EIF_REFERENCE __A638_50 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY new_is_assembly_criterion */
EIF_REFERENCE _A638_51 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY new_is_assembly_criterion */
EIF_REFERENCE __A638_51 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY new_is_cluster_criterion */
EIF_REFERENCE _A638_52 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY new_is_cluster_criterion */
EIF_REFERENCE __A638_52 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY new_is_compiled_criterion */
EIF_REFERENCE _A638_53 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY new_is_compiled_criterion */
EIF_REFERENCE __A638_53 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY new_is_library_criterion */
EIF_REFERENCE _A638_54 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY new_is_library_criterion */
EIF_REFERENCE __A638_54 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY new_is_override_criterion */
EIF_REFERENCE _A638_55 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY new_is_override_criterion */
EIF_REFERENCE __A638_55 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY new_is_valid_criterion */
EIF_REFERENCE _A638_56 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY new_is_valid_criterion */
EIF_REFERENCE __A638_56 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY new_is_used_in_library_criterion */
EIF_REFERENCE _A638_57 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY new_is_used_in_library_criterion */
EIF_REFERENCE __A638_57 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY new_true_criterion */
EIF_REFERENCE _A638_59 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY new_true_criterion */
EIF_REFERENCE __A638_59 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY new_name_is_criterion */
EIF_REFERENCE _A638_60_2_3_4 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_b, open [3].it_i4);
}

	/* QL_GROUP_CRITERION_FACTORY new_name_is_criterion */
EIF_REFERENCE __A638_60_2_3_4 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_BOOLEAN op_3, EIF_INTEGER_32 op_4)
{
	return f_ptr (closed [1].it_r, op_2, op_3, op_4);
}

	/* QL_GROUP_CRITERION_FACTORY new_value_criterion */
EIF_REFERENCE _A638_61_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_GROUP_CRITERION_FACTORY new_value_criterion */
EIF_REFERENCE __A638_61_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_TARGET_CRITERION_FACTORY value_criterion_evalaute_agent */
EIF_BOOLEAN _A639_45_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* QL_TARGET_CRITERION_FACTORY value_criterion_evalaute_agent */
EIF_BOOLEAN __A639_45_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* QL_TARGET_CRITERION_FACTORY true_agent */
EIF_BOOLEAN _A639_62_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_TARGET_CRITERION_FACTORY true_agent */
EIF_BOOLEAN __A639_62_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_TARGET_CRITERION_FACTORY is_compiled_agent */
EIF_BOOLEAN _A639_63_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_TARGET_CRITERION_FACTORY is_compiled_agent */
EIF_BOOLEAN __A639_63_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_TARGET_CRITERION_FACTORY false_agent */
EIF_BOOLEAN _A639_61_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_TARGET_CRITERION_FACTORY false_agent */
EIF_BOOLEAN __A639_61_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_TARGET_CRITERION_FACTORY new_false_criterion */
EIF_REFERENCE _A639_50 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_TARGET_CRITERION_FACTORY new_false_criterion */
EIF_REFERENCE __A639_50 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_TARGET_CRITERION_FACTORY new_is_compiled_criterion */
EIF_REFERENCE _A639_51 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_TARGET_CRITERION_FACTORY new_is_compiled_criterion */
EIF_REFERENCE __A639_51 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_TARGET_CRITERION_FACTORY new_true_criterion */
EIF_REFERENCE _A639_52 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_TARGET_CRITERION_FACTORY new_true_criterion */
EIF_REFERENCE __A639_52 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_TARGET_CRITERION_FACTORY new_name_is_criterion */
EIF_REFERENCE _A639_53_2_3_4 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_b, open [3].it_i4);
}

	/* QL_TARGET_CRITERION_FACTORY new_name_is_criterion */
EIF_REFERENCE __A639_53_2_3_4 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_BOOLEAN op_3, EIF_INTEGER_32 op_4)
{
	return f_ptr (closed [1].it_r, op_2, op_3, op_4);
}

	/* QL_TARGET_CRITERION_FACTORY new_value_criterion */
EIF_REFERENCE _A639_54_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_TARGET_CRITERION_FACTORY new_value_criterion */
EIF_REFERENCE __A639_54_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* CA_RULE_VIOLATION inline-agent#1 of make_with_rule */
void _A698_56_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F809_45705)(closed [1].it_r, open [1].it_r);
}

	/* CA_RULE_VIOLATION inline-agent#1 of make_with_rule */
void __A698_56_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F809_45705)(closed [1].it_r, op_2);
}

	/* CA_RULE format_violation_description */
void _A1192_85_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, open [1].it_r);
}

	/* CA_RULE format_violation_description */
void __A1192_85_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_3)
{
	f_ptr (closed [1].it_r, closed [2].it_r, op_3);
}

	/* CA_RULE format */
void _A1192_58_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* CA_RULE format */
void __A1192_58_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* CA_RULE format_elements */
void _A1192_59_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* CA_RULE format_elements */
void __A1192_59_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* DISPOSABLE_SAFE inline-agent#1 of dispose */
void _A732_45 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F862_45712)(closed [1].it_r);
}

	/* DISPOSABLE_SAFE inline-agent#1 of dispose */
void __A732_45 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F862_45712)(closed [1].it_r);
}

	/* HASH_TABLE [G#1, G#2] put */
void _A2828_90_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, open [1].it_r);
}

	/* HASH_TABLE [G#1, INTEGER_32] put */
void _A2941_90_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	EIF_REFERENCE arg2 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (3);
	
	RTLR(0,closed [1].it_r);
	RTLR(2,arg2);
	RTLR(1,closed [2].it_r);
	RTLIU(3);
	arg2 = RTLNS(eif_new_type(2055, 0x00).id, 2055, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg2 = open [1].it_i4;
	f_ptr (closed [1].it_r, closed [2].it_r, arg2);
	RTLE;
}

	/* HASH_TABLE [INTEGER_32, G#2] put */
void _A3039_90_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (3);
	
	RTLR(0,closed [1].it_r);
	RTLR(2,open [1].it_r);
	RTLR(1,arg1);
	RTLIU(3);
	arg1 = RTLNS(eif_new_type(2055, 0x00).id, 2055, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg1 = closed [2].it_i4;
	f_ptr (closed [1].it_r, arg1, open [1].it_r);
	RTLE;
}

	/* HASH_TABLE [INTEGER_32, INTEGER_32] put */
void _A2853_90_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, open [1].it_i4);
}

	/* HASH_TABLE [NATURAL_64, INTEGER_32] put */
void _A3053_90_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_64, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_n8, open [1].it_i4);
}

	/* HASH_TABLE [BOOLEAN, G#2] put */
void _A3234_90_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (3);
	
	RTLR(0,closed [1].it_r);
	RTLR(2,open [1].it_r);
	RTLR(1,arg1);
	RTLIU(3);
	arg1 = RTLNS(eif_new_type(2088, 0x00).id, 2088, _OBJSIZ_0_1_0_0_0_0_0_0_);
	*(EIF_BOOLEAN *)arg1 = closed [2].it_b;
	f_ptr (closed [1].it_r, arg1, open [1].it_r);
	RTLE;
}

	/* HASH_TABLE [BOOLEAN, NATURAL_64] put */
void _A3064_90_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN, EIF_NATURAL_64), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_b, open [1].it_n8);
}

	/* HASH_TABLE [POINTER, G#2] put */
void _A3073_90_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p, open [1].it_r);
}

	/* HASH_TABLE [NATURAL_32, G#2] put */
void _A3534_90_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (3);
	
	RTLR(0,closed [1].it_r);
	RTLR(2,open [1].it_r);
	RTLR(1,arg1);
	RTLIU(3);
	arg1 = RTLNS(eif_new_type(2067, 0x00).id, 2067, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_NATURAL_32 *)arg1 = closed [2].it_n4;
	f_ptr (closed [1].it_r, arg1, open [1].it_r);
	RTLE;
}

	/* HASH_TABLE [NATURAL_32, POINTER] put */
void _A3293_90_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_32, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_n4, open [1].it_p);
}

	/* HASH_TABLE [NATURAL_8, G#2] put */
void _A3347_90_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_8, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_n1, open [1].it_r);
}

	/* HASH_TABLE [BOOLEAN, INTEGER_32] put */
void _A3547_90_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_b, open [1].it_i4);
}

	/* HASH_TABLE [G#1, CHARACTER_32] put */
void _A3559_90_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_CHARACTER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, open [1].it_c4);
}

	/* HASH_TABLE [G#1, G#2] put */
void __A2828_90_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_3)
{
	f_ptr (closed [1].it_r, closed [2].it_r, op_3);
}

	/* HASH_TABLE [G#1, INTEGER_32] put */
void __A2941_90_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_3)
{
	EIF_REFERENCE arg2 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (3);
	
	RTLR(0,closed [1].it_r);
	RTLR(2,arg2);
	RTLR(1,closed [2].it_r);
	RTLIU(3);
	arg2 = RTLNS(eif_new_type(2055, 0x00).id, 2055, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg2 = op_3;
	f_ptr (closed [1].it_r, closed [2].it_r, arg2);
	RTLE;
}

	/* HASH_TABLE [INTEGER_32, G#2] put */
void __A3039_90_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_3)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (3);
	
	RTLR(0,closed [1].it_r);
	RTLR(2,op_3);
	RTLR(1,arg1);
	RTLIU(3);
	arg1 = RTLNS(eif_new_type(2055, 0x00).id, 2055, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg1 = closed [2].it_i4;
	f_ptr (closed [1].it_r, arg1, op_3);
	RTLE;
}

	/* HASH_TABLE [INTEGER_32, INTEGER_32] put */
void __A2853_90_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_3)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, op_3);
}

	/* HASH_TABLE [NATURAL_64, INTEGER_32] put */
void __A3053_90_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_64, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_3)
{
	f_ptr (closed [1].it_r, closed [2].it_n8, op_3);
}

	/* HASH_TABLE [BOOLEAN, G#2] put */
void __A3234_90_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_3)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (3);
	
	RTLR(0,closed [1].it_r);
	RTLR(2,op_3);
	RTLR(1,arg1);
	RTLIU(3);
	arg1 = RTLNS(eif_new_type(2088, 0x00).id, 2088, _OBJSIZ_0_1_0_0_0_0_0_0_);
	*(EIF_BOOLEAN *)arg1 = closed [2].it_b;
	f_ptr (closed [1].it_r, arg1, op_3);
	RTLE;
}

	/* HASH_TABLE [BOOLEAN, NATURAL_64] put */
void __A3064_90_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN, EIF_NATURAL_64), EIF_TYPED_VALUE * closed, EIF_NATURAL_64 op_3)
{
	f_ptr (closed [1].it_r, closed [2].it_b, op_3);
}

	/* HASH_TABLE [POINTER, G#2] put */
void __A3073_90_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_3)
{
	f_ptr (closed [1].it_r, closed [2].it_p, op_3);
}

	/* HASH_TABLE [NATURAL_32, G#2] put */
void __A3534_90_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_3)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (3);
	
	RTLR(0,closed [1].it_r);
	RTLR(2,op_3);
	RTLR(1,arg1);
	RTLIU(3);
	arg1 = RTLNS(eif_new_type(2067, 0x00).id, 2067, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_NATURAL_32 *)arg1 = closed [2].it_n4;
	f_ptr (closed [1].it_r, arg1, op_3);
	RTLE;
}

	/* HASH_TABLE [NATURAL_32, POINTER] put */
void __A3293_90_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_32, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_3)
{
	f_ptr (closed [1].it_r, closed [2].it_n4, op_3);
}

	/* HASH_TABLE [NATURAL_8, G#2] put */
void __A3347_90_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_8, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_3)
{
	f_ptr (closed [1].it_r, closed [2].it_n1, op_3);
}

	/* HASH_TABLE [BOOLEAN, INTEGER_32] put */
void __A3547_90_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_3)
{
	f_ptr (closed [1].it_r, closed [2].it_b, op_3);
}

	/* HASH_TABLE [G#1, CHARACTER_32] put */
void __A3559_90_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_CHARACTER_32), EIF_TYPED_VALUE * closed, EIF_CHARACTER_32 op_3)
{
	f_ptr (closed [1].it_r, closed [2].it_r, op_3);
}

	/* MISMATCH_INFORMATION wipe_out */
void A838_98 (EIF_REFERENCE Current)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1626_15253)(Current);
}

	/* MISMATCH_INFORMATION internal_put */
void A838_162 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_POINTER arg2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_POINTER)) F1642_15330)(Current, arg1, arg2);
}

	/* MISMATCH_INFORMATION set_string_versions */
void A838_163 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_POINTER)) F1642_15331)(Current, arg1, arg2);
}

	/* INHERIT_INFO inline-agent#1 of delayed_instantiate_a_feature */
void _A852_91 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1661_45787)(closed [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r);
}

	/* INHERIT_INFO inline-agent#1 of delayed_instantiate_a_feature */
void __A852_91 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1661_45787)(closed [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r);
}

	/* INHERIT_INFO has_property_getter */
EIF_BOOLEAN _A852_82_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1661_15425)(open [1].it_r);
}

	/* INHERIT_INFO has_property_getter */
EIF_BOOLEAN __A852_82_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1661_15425)(op_1);
}

	/* INHERIT_INFO has_property_setter */
EIF_BOOLEAN _A852_83_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1661_15426)(open [1].it_r);
}

	/* INHERIT_INFO has_property_setter */
EIF_BOOLEAN __A852_83_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1661_15426)(op_1);
}

	/* CA_AST_TYPE_RECORDER record_node_type */
void _A854_50_2_3_4_5_6 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, open [2].it_r, open [3].it_r, open [4].it_r, open [5].it_r);
}

	/* CA_AST_TYPE_RECORDER record_node_type */
void __A854_50_2_3_4_5_6 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_3, EIF_REFERENCE op_4, EIF_REFERENCE op_5, EIF_REFERENCE op_6)
{
	f_ptr (closed [1].it_r, op_2, op_3, op_4, op_5, op_6);
}

	/* CA_SETTINGS validate_severity_score */
EIF_BOOLEAN _A884_53_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_SETTINGS validate_severity_score */
EIF_BOOLEAN __A884_53_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* CONF_LOAD_PARSE_CALLBACKS create_external_cflag */
void _A892_562_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CONF_LOAD_PARSE_CALLBACKS create_external_cflag */
void __A892_562_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CONF_LOAD_PARSE_CALLBACKS create_external_linker_flag */
void _A892_563_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CONF_LOAD_PARSE_CALLBACKS create_external_linker_flag */
void __A892_563_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CONF_LOAD_PARSE_CALLBACKS fake inline-agent#45790#473#406# of on_start_tag_finish */
EIF_REFERENCE _A892_639_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1707_45790)(closed [1].it_r, open [1].it_r);
}

	/* CONF_LOAD_PARSE_CALLBACKS fake inline-agent#45790#473#406# of on_start_tag_finish */
EIF_REFERENCE __A892_639_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1707_45790)(closed [1].it_r, op_2);
}

	/* CONF_LOAD_PARSE_CALLBACKS fake inline-agent#45791#473#407# of on_start_tag_finish */
EIF_REFERENCE _A892_640_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1707_45791)(closed [1].it_r, open [1].it_r);
}

	/* CONF_LOAD_PARSE_CALLBACKS fake inline-agent#45791#473#407# of on_start_tag_finish */
EIF_REFERENCE __A892_640_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1707_45791)(closed [1].it_r, op_2);
}

	/* CONF_LOAD_PARSE_CALLBACKS fake inline-agent#45792#473#405# of on_start_tag_finish */
EIF_REFERENCE _A892_641_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1707_45792)(closed [1].it_r, open [1].it_r);
}

	/* CONF_LOAD_PARSE_CALLBACKS fake inline-agent#45792#473#405# of on_start_tag_finish */
EIF_REFERENCE __A892_641_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F1707_45792)(closed [1].it_r, op_2);
}

	/* CONF_PHYSICAL_ASSEMBLY reset_assemblies */
void _A1187_427_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2097_20363)(open [1].it_r);
}

	/* CONF_PHYSICAL_ASSEMBLY reset_assemblies */
void __A1187_427_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2097_20363)(op_1);
}

	/* QL_DOMAIN_CRITERION initialize_domain */
void _A990_60 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* QL_DOMAIN_CRITERION initialize_domain */
void __A990_60 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* QL_NAME_CRITERION identity_matcher */
EIF_BOOLEAN _A1058_77_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_NAME_CRITERION identity_matcher */
EIF_BOOLEAN __A1058_77_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_NAME_CRITERION containing_matcher */
EIF_BOOLEAN _A1058_78_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_NAME_CRITERION containing_matcher */
EIF_BOOLEAN __A1058_78_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_NAME_CRITERION wildcard_matcher */
EIF_BOOLEAN _A1058_79_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_NAME_CRITERION wildcard_matcher */
EIF_BOOLEAN __A1058_79_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_NAME_CRITERION regexp_matcher */
EIF_BOOLEAN _A1058_80_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_NAME_CRITERION regexp_matcher */
EIF_BOOLEAN __A1058_80_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY value_criterion_evalaute_agent */
EIF_BOOLEAN _A1078_61_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY value_criterion_evalaute_agent */
EIF_BOOLEAN __A1078_61_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY true_agent */
EIF_BOOLEAN _A1078_239_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY true_agent */
EIF_BOOLEAN __A1078_239_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY is_from_any_agent */
EIF_BOOLEAN _A1078_238_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY is_from_any_agent */
EIF_BOOLEAN __A1078_238_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY is_visible_agent */
EIF_BOOLEAN _A1078_237_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY is_visible_agent */
EIF_BOOLEAN __A1078_237_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY is_command_agent */
EIF_BOOLEAN _A1078_236_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY is_command_agent */
EIF_BOOLEAN __A1078_236_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY is_query_agent */
EIF_BOOLEAN _A1078_235_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY is_query_agent */
EIF_BOOLEAN __A1078_235_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY is_unique_agent */
EIF_BOOLEAN _A1078_234_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY is_unique_agent */
EIF_BOOLEAN __A1078_234_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY is_procedure_agent */
EIF_BOOLEAN _A1078_233_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY is_procedure_agent */
EIF_BOOLEAN __A1078_233_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY is_prefix_agent */
EIF_BOOLEAN _A1078_232_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY is_prefix_agent */
EIF_BOOLEAN __A1078_232_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY is_origin_agent */
EIF_BOOLEAN _A1078_231_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY is_origin_agent */
EIF_BOOLEAN __A1078_231_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY is_ghost_agent */
EIF_BOOLEAN _A1078_230_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY is_ghost_agent */
EIF_BOOLEAN __A1078_230_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY is_class_agent */
EIF_BOOLEAN _A1078_229_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY is_class_agent */
EIF_BOOLEAN __A1078_229_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY is_once_agent */
EIF_BOOLEAN _A1078_228_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY is_once_agent */
EIF_BOOLEAN __A1078_228_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY is_obsolete_agent */
EIF_BOOLEAN _A1078_227_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY is_obsolete_agent */
EIF_BOOLEAN __A1078_227_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY is_invariant_agent */
EIF_BOOLEAN _A1078_226_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY is_invariant_agent */
EIF_BOOLEAN __A1078_226_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY is_infix_agent */
EIF_BOOLEAN _A1078_225_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY is_infix_agent */
EIF_BOOLEAN __A1078_225_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY is_immediate_agent */
EIF_BOOLEAN _A1078_224_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY is_immediate_agent */
EIF_BOOLEAN __A1078_224_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY is_hidden_agent */
EIF_BOOLEAN _A1078_223_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY is_hidden_agent */
EIF_BOOLEAN __A1078_223_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY is_function_agent */
EIF_BOOLEAN _A1078_222_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY is_function_agent */
EIF_BOOLEAN __A1078_222_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY is_frozen_agent */
EIF_BOOLEAN _A1078_221_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY is_frozen_agent */
EIF_BOOLEAN __A1078_221_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY is_feature_agent */
EIF_BOOLEAN _A1078_220_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY is_feature_agent */
EIF_BOOLEAN __A1078_220_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY is_external_agent */
EIF_BOOLEAN _A1078_219_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY is_external_agent */
EIF_BOOLEAN __A1078_219_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY is_exported_agent */
EIF_BOOLEAN _A1078_216_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY is_exported_agent */
EIF_BOOLEAN __A1078_216_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY is_effective_agent */
EIF_BOOLEAN _A1078_218_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY is_effective_agent */
EIF_BOOLEAN __A1078_218_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY is_deferred_agent */
EIF_BOOLEAN _A1078_217_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY is_deferred_agent */
EIF_BOOLEAN __A1078_217_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY is_creator_agent */
EIF_BOOLEAN _A1078_215_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY is_creator_agent */
EIF_BOOLEAN __A1078_215_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY is_constant_agent */
EIF_BOOLEAN _A1078_214_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY is_constant_agent */
EIF_BOOLEAN __A1078_214_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY is_compiled_agent */
EIF_BOOLEAN _A1078_213_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY is_compiled_agent */
EIF_BOOLEAN __A1078_213_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY is_attribute_agent */
EIF_BOOLEAN _A1078_212_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY is_attribute_agent */
EIF_BOOLEAN __A1078_212_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY has_rescue_agent */
EIF_BOOLEAN _A1078_211_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY has_rescue_agent */
EIF_BOOLEAN __A1078_211_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY has_precondition_agent */
EIF_BOOLEAN _A1078_210_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY has_precondition_agent */
EIF_BOOLEAN __A1078_210_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY has_class_postcondition_agent */
EIF_BOOLEAN _A1078_209_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY has_class_postcondition_agent */
EIF_BOOLEAN __A1078_209_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY has_postcondition_agent */
EIF_BOOLEAN _A1078_208_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY has_postcondition_agent */
EIF_BOOLEAN __A1078_208_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY has_locals_agent */
EIF_BOOLEAN _A1078_207_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY has_locals_agent */
EIF_BOOLEAN __A1078_207_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY has_indexing_agent */
EIF_BOOLEAN _A1078_206_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY has_indexing_agent */
EIF_BOOLEAN __A1078_206_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY has_comments_agent */
EIF_BOOLEAN _A1078_205_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY has_comments_agent */
EIF_BOOLEAN __A1078_205_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY has_assigner_agent */
EIF_BOOLEAN _A1078_204_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY has_assigner_agent */
EIF_BOOLEAN __A1078_204_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY has_assertion_agent */
EIF_BOOLEAN _A1078_203_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY has_assertion_agent */
EIF_BOOLEAN __A1078_203_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY has_arguments_agent */
EIF_BOOLEAN _A1078_202_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY has_arguments_agent */
EIF_BOOLEAN __A1078_202_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY false_agent */
EIF_BOOLEAN _A1078_201_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY false_agent */
EIF_BOOLEAN __A1078_201_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY new_false_criterion */
EIF_REFERENCE _A1078_93 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_false_criterion */
EIF_REFERENCE __A1078_93 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_has_arguments_criterion */
EIF_REFERENCE _A1078_94 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_has_arguments_criterion */
EIF_REFERENCE __A1078_94 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_has_assertion_criterion */
EIF_REFERENCE _A1078_95 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_has_assertion_criterion */
EIF_REFERENCE __A1078_95 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_has_assigner_criterion */
EIF_REFERENCE _A1078_96 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_has_assigner_criterion */
EIF_REFERENCE __A1078_96 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_has_comments_criterion */
EIF_REFERENCE _A1078_97 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_has_comments_criterion */
EIF_REFERENCE __A1078_97 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_has_indexing_criterion */
EIF_REFERENCE _A1078_98 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_has_indexing_criterion */
EIF_REFERENCE __A1078_98 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_has_locals_criterion */
EIF_REFERENCE _A1078_99 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_has_locals_criterion */
EIF_REFERENCE __A1078_99 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_has_postcondition_criterion */
EIF_REFERENCE _A1078_100 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_has_postcondition_criterion */
EIF_REFERENCE __A1078_100 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_has_class_postcondition_criterion */
EIF_REFERENCE _A1078_101 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_has_class_postcondition_criterion */
EIF_REFERENCE __A1078_101 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_has_precondition_criterion */
EIF_REFERENCE _A1078_102 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_has_precondition_criterion */
EIF_REFERENCE __A1078_102 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_has_rescue_criterion */
EIF_REFERENCE _A1078_103 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_has_rescue_criterion */
EIF_REFERENCE __A1078_103 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_attribute_criterion */
EIF_REFERENCE _A1078_104 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_attribute_criterion */
EIF_REFERENCE __A1078_104 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_compiled_criterion */
EIF_REFERENCE _A1078_105 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_compiled_criterion */
EIF_REFERENCE __A1078_105 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_constant_criterion */
EIF_REFERENCE _A1078_106 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_constant_criterion */
EIF_REFERENCE __A1078_106 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_creator_criterion */
EIF_REFERENCE _A1078_107 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_creator_criterion */
EIF_REFERENCE __A1078_107 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_deferred_criterion */
EIF_REFERENCE _A1078_108 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_deferred_criterion */
EIF_REFERENCE __A1078_108 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_effective_criterion */
EIF_REFERENCE _A1078_109 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_effective_criterion */
EIF_REFERENCE __A1078_109 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_exported_criterion */
EIF_REFERENCE _A1078_110 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_exported_criterion */
EIF_REFERENCE __A1078_110 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_external_criterion */
EIF_REFERENCE _A1078_111 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_external_criterion */
EIF_REFERENCE __A1078_111 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_feature_criterion */
EIF_REFERENCE _A1078_112 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_feature_criterion */
EIF_REFERENCE __A1078_112 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_frozen_criterion */
EIF_REFERENCE _A1078_113 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_frozen_criterion */
EIF_REFERENCE __A1078_113 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_function_criterion */
EIF_REFERENCE _A1078_114 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_function_criterion */
EIF_REFERENCE __A1078_114 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_hidden_criterion */
EIF_REFERENCE _A1078_115 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_hidden_criterion */
EIF_REFERENCE __A1078_115 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_immediate_criterion */
EIF_REFERENCE _A1078_116 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_immediate_criterion */
EIF_REFERENCE __A1078_116 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_infix_criterion */
EIF_REFERENCE _A1078_117 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_infix_criterion */
EIF_REFERENCE __A1078_117 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_invariant_criterion */
EIF_REFERENCE _A1078_118 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_invariant_criterion */
EIF_REFERENCE __A1078_118 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_obsolete_criterion */
EIF_REFERENCE _A1078_119 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_obsolete_criterion */
EIF_REFERENCE __A1078_119 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_once_criterion */
EIF_REFERENCE _A1078_120 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_once_criterion */
EIF_REFERENCE __A1078_120 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_class_criterion */
EIF_REFERENCE _A1078_121 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_class_criterion */
EIF_REFERENCE __A1078_121 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_origin_criterion */
EIF_REFERENCE _A1078_123 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_origin_criterion */
EIF_REFERENCE __A1078_123 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_prefix_criterion */
EIF_REFERENCE _A1078_124 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_prefix_criterion */
EIF_REFERENCE __A1078_124 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_procedure_criterion */
EIF_REFERENCE _A1078_125 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_procedure_criterion */
EIF_REFERENCE __A1078_125 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_unique_criterion */
EIF_REFERENCE _A1078_126 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_unique_criterion */
EIF_REFERENCE __A1078_126 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_query_criterion */
EIF_REFERENCE _A1078_127 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_query_criterion */
EIF_REFERENCE __A1078_127 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_command_criterion */
EIF_REFERENCE _A1078_128 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_command_criterion */
EIF_REFERENCE __A1078_128 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_visible_criterion */
EIF_REFERENCE _A1078_129 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_visible_criterion */
EIF_REFERENCE __A1078_129 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_from_any_criterion */
EIF_REFERENCE _A1078_130 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_from_any_criterion */
EIF_REFERENCE __A1078_130 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_ghost_criterion */
EIF_REFERENCE _A1078_122 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_ghost_criterion */
EIF_REFERENCE __A1078_122 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_true_criterion */
EIF_REFERENCE _A1078_131 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_true_criterion */
EIF_REFERENCE __A1078_131 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_name_is_criterion */
EIF_REFERENCE _A1078_132_2_3_4 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_b, open [3].it_i4);
}

	/* QL_FEATURE_CRITERION_FACTORY new_name_is_criterion */
EIF_REFERENCE __A1078_132_2_3_4 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_BOOLEAN op_3, EIF_INTEGER_32 op_4)
{
	return f_ptr (closed [1].it_r, op_2, op_3, op_4);
}

	/* QL_FEATURE_CRITERION_FACTORY new_text_contain_criterion */
EIF_REFERENCE _A1078_133_2_3_4 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_b, open [3].it_i4);
}

	/* QL_FEATURE_CRITERION_FACTORY new_text_contain_criterion */
EIF_REFERENCE __A1078_133_2_3_4 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_BOOLEAN op_3, EIF_INTEGER_32 op_4)
{
	return f_ptr (closed [1].it_r, op_2, op_3, op_4);
}

	/* QL_FEATURE_CRITERION_FACTORY new_ancestor_is_criterion */
EIF_REFERENCE _A1078_134_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_ancestor_is_criterion */
EIF_REFERENCE __A1078_134_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY new_descendant_is_criterion */
EIF_REFERENCE _A1078_135_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_descendant_is_criterion */
EIF_REFERENCE __A1078_135_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY new_implementors_of_criterion */
EIF_REFERENCE _A1078_136_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_implementors_of_criterion */
EIF_REFERENCE __A1078_136_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_exported_to_criterion */
EIF_REFERENCE _A1078_137_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_is_exported_to_criterion */
EIF_REFERENCE __A1078_137_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY new_callers_of_criterion */
EIF_REFERENCE _A1078_138_2_3 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_b);
}

	/* QL_FEATURE_CRITERION_FACTORY new_callers_of_criterion */
EIF_REFERENCE __A1078_138_2_3 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_BOOLEAN op_3)
{
	return f_ptr (closed [1].it_r, op_2, op_3);
}

	/* QL_FEATURE_CRITERION_FACTORY new_caller_is_criterion */
EIF_REFERENCE _A1078_139_2_3 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_b);
}

	/* QL_FEATURE_CRITERION_FACTORY new_caller_is_criterion */
EIF_REFERENCE __A1078_139_2_3 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_BOOLEAN op_3)
{
	return f_ptr (closed [1].it_r, op_2, op_3);
}

	/* QL_FEATURE_CRITERION_FACTORY new_assigners_of_criterion */
EIF_REFERENCE _A1078_140_2_3 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_b);
}

	/* QL_FEATURE_CRITERION_FACTORY new_assigners_of_criterion */
EIF_REFERENCE __A1078_140_2_3 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_BOOLEAN op_3)
{
	return f_ptr (closed [1].it_r, op_2, op_3);
}

	/* QL_FEATURE_CRITERION_FACTORY new_assigner_is_criterion */
EIF_REFERENCE _A1078_141_2_3 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_b);
}

	/* QL_FEATURE_CRITERION_FACTORY new_assigner_is_criterion */
EIF_REFERENCE __A1078_141_2_3 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_BOOLEAN op_3)
{
	return f_ptr (closed [1].it_r, op_2, op_3);
}

	/* QL_FEATURE_CRITERION_FACTORY new_creators_of_criterion */
EIF_REFERENCE _A1078_142_2_3 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_b);
}

	/* QL_FEATURE_CRITERION_FACTORY new_creators_of_criterion */
EIF_REFERENCE __A1078_142_2_3 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_BOOLEAN op_3)
{
	return f_ptr (closed [1].it_r, op_2, op_3);
}

	/* QL_FEATURE_CRITERION_FACTORY new_creator_is_criterion */
EIF_REFERENCE _A1078_143_2_3 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_b);
}

	/* QL_FEATURE_CRITERION_FACTORY new_creator_is_criterion */
EIF_REFERENCE __A1078_143_2_3 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_BOOLEAN op_3)
{
	return f_ptr (closed [1].it_r, op_2, op_3);
}

	/* QL_FEATURE_CRITERION_FACTORY new_return_type_is_criterion */
EIF_REFERENCE _A1078_144_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_return_type_is_criterion */
EIF_REFERENCE __A1078_144_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_CRITERION_FACTORY new_value_criterion */
EIF_REFERENCE _A1078_145_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_CRITERION_FACTORY new_value_criterion */
EIF_REFERENCE __A1078_145_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* SYSTEM_STATISTICS count_number */
void _A1079_87_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* SYSTEM_STATISTICS count_number */
void __A1079_87_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* SYSTEM_STATISTICS count_class */
void _A1079_79_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_b);
}

	/* SYSTEM_STATISTICS count_class */
void __A1079_79_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_b);
}

	/* CA_CODE_ANALYZER analysis_completed */
void _A1086_64_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_CODE_ANALYZER analysis_completed */
void __A1086_64_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_OBSOLETE_FEATURE_CALL_PROCESSOR [G#1] process */
void _A3663_45_2_3_4_5 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_NATURAL_8, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, open [2].it_n1, open [3].it_r, open [4].it_r);
}

	/* CA_OBSOLETE_FEATURE_CALL_PROCESSOR [G#1] process */
void __A3663_45_2_3_4_5 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_NATURAL_8, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_NATURAL_8 op_3, EIF_REFERENCE op_4, EIF_REFERENCE op_5)
{
	f_ptr (closed [1].it_r, op_2, op_3, op_4, op_5);
}

	/* E_SHOW_CLUSTER_HIERARCHY class_name_tester */
EIF_BOOLEAN _A1088_271_2_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_r);
}

	/* E_SHOW_CLUSTER_HIERARCHY class_name_tester */
EIF_BOOLEAN __A1088_271_2_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_3)
{
	return f_ptr (closed [1].it_r, op_2, op_3);
}

	/* E_SHOW_CLUSTER_HIERARCHY group_tester */
EIF_BOOLEAN _A1088_272_2_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_r);
}

	/* E_SHOW_CLUSTER_HIERARCHY group_tester */
EIF_BOOLEAN __A1088_272_2_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_3)
{
	return f_ptr (closed [1].it_r, op_2, op_3);
}

	/* EXECUTION_ENVIRONMENT item */
EIF_REFERENCE _A662_40_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EXECUTION_ENVIRONMENT item */
EIF_REFERENCE __A662_40_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* CA_WRONG_LOOP_ITERATION_RULE process_loop */
void _A1196_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_WRONG_LOOP_ITERATION_RULE process_loop */
void __A1196_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_VOID_CHECK_USING_IS_EQUAL_RULE process_nested */
void _A1197_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_VOID_CHECK_USING_IS_EQUAL_RULE process_nested */
void __A1197_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_VERY_SHORT_IDENTIFIER_RULE process_routine */
void _A1198_106_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_VERY_SHORT_IDENTIFIER_RULE process_routine */
void __A1198_106_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_VERY_SHORT_IDENTIFIER_RULE process_body */
void _A1198_107_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_VERY_SHORT_IDENTIFIER_RULE process_body */
void __A1198_107_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_VERY_SHORT_IDENTIFIER_RULE process_feature */
void _A1198_108_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_VERY_SHORT_IDENTIFIER_RULE process_feature */
void __A1198_108_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_VERY_SHORT_IDENTIFIER_RULE is_integer_string_within_bounds */
EIF_BOOLEAN _A1198_53_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* CA_VERY_SHORT_IDENTIFIER_RULE is_integer_string_within_bounds */
EIF_BOOLEAN __A1198_53_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_i4, closed [3].it_i4);
}

	/* CA_VERY_LONG_ROUTINE_RULE is_integer_string_within_bounds */
EIF_BOOLEAN _A1199_53_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* CA_VERY_LONG_ROUTINE_RULE is_integer_string_within_bounds */
EIF_BOOLEAN __A1199_53_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_i4, closed [3].it_i4);
}

	/* CA_VERY_LONG_ROUTINE_RULE pre_process_feature */
void _A1199_108_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_VERY_LONG_ROUTINE_RULE pre_process_feature */
void __A1199_108_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_VERY_LONG_ROUTINE_RULE post_process_feature */
void _A1199_109_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_VERY_LONG_ROUTINE_RULE post_process_feature */
void __A1199_109_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_VERY_LONG_ROUTINE_RULE process_do */
void _A1199_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_VERY_LONG_ROUTINE_RULE process_do */
void __A1199_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_VERY_LONG_ROUTINE_RULE process_once */
void _A1199_111_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_VERY_LONG_ROUTINE_RULE process_once */
void __A1199_111_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_VERY_LONG_ROUTINE_RULE process_if */
void _A1199_112_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_VERY_LONG_ROUTINE_RULE process_if */
void __A1199_112_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_VERY_LONG_ROUTINE_RULE process_loop */
void _A1199_114_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_VERY_LONG_ROUTINE_RULE process_loop */
void __A1199_114_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_VERY_LONG_ROUTINE_RULE process_inspect */
void _A1199_115_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_VERY_LONG_ROUTINE_RULE process_inspect */
void __A1199_115_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_VERY_LONG_IDENTIFIER_RULE process_routine */
void _A1200_106_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_VERY_LONG_IDENTIFIER_RULE process_routine */
void __A1200_106_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_VERY_LONG_IDENTIFIER_RULE process_body */
void _A1200_107_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_VERY_LONG_IDENTIFIER_RULE process_body */
void __A1200_107_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_VERY_LONG_IDENTIFIER_RULE process_feature */
void _A1200_108_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_VERY_LONG_IDENTIFIER_RULE process_feature */
void __A1200_108_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_VERY_LONG_IDENTIFIER_RULE is_integer_string_within_bounds */
EIF_BOOLEAN _A1200_53_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* CA_VERY_LONG_IDENTIFIER_RULE is_integer_string_within_bounds */
EIF_BOOLEAN __A1200_53_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_i4, closed [3].it_i4);
}

	/* CA_VERY_BIG_CLASS_RULE is_integer_string_within_bounds */
EIF_BOOLEAN _A1201_53_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* CA_VERY_BIG_CLASS_RULE is_integer_string_within_bounds */
EIF_BOOLEAN __A1201_53_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_i4, closed [3].it_i4);
}

	/* CA_VERY_BIG_CLASS_RULE pre_process_class */
void _A1201_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_VERY_BIG_CLASS_RULE pre_process_class */
void __A1201_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_VERY_BIG_CLASS_RULE post_process_class */
void _A1201_111_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_VERY_BIG_CLASS_RULE post_process_class */
void __A1201_111_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_VERY_BIG_CLASS_RULE process_do */
void _A1201_112_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_VERY_BIG_CLASS_RULE process_do */
void __A1201_112_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_VERY_BIG_CLASS_RULE process_once */
void _A1201_113_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_VERY_BIG_CLASS_RULE process_once */
void __A1201_113_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_VERY_BIG_CLASS_RULE process_if */
void _A1201_114_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_VERY_BIG_CLASS_RULE process_if */
void __A1201_114_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_VERY_BIG_CLASS_RULE process_loop */
void _A1201_116_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_VERY_BIG_CLASS_RULE process_loop */
void __A1201_116_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_VERY_BIG_CLASS_RULE process_inspect */
void _A1201_117_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_VERY_BIG_CLASS_RULE process_inspect */
void __A1201_117_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_USELESS_CONTRACT_RULE pre_process_feature */
void _A1202_268_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_USELESS_CONTRACT_RULE pre_process_feature */
void __A1202_268_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_UNUSED_ARGUMENT_RULE process_feature */
void _A1203_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_UNUSED_ARGUMENT_RULE process_feature */
void __A1203_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_UNUSED_ARGUMENT_RULE process_body */
void _A1203_111_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_UNUSED_ARGUMENT_RULE process_body */
void __A1203_111_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_UNUSED_ARGUMENT_RULE post_process_body */
void _A1203_112_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_UNUSED_ARGUMENT_RULE post_process_body */
void __A1203_112_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_UNUSED_ARGUMENT_RULE process_access_id */
void _A1203_113_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_UNUSED_ARGUMENT_RULE process_access_id */
void __A1203_113_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_UNUSED_ARGUMENT_RULE process_converted_expr */
void _A1203_114_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_UNUSED_ARGUMENT_RULE process_converted_expr */
void __A1203_114_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_UNREACHABLE_CODE_RULE inline-agent#1 of register_actions */
void _A1204_280_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2114_45858)(closed [1].it_r, open [1].it_r);
}

	/* CA_UNREACHABLE_CODE_RULE inline-agent#1 of register_actions */
void __A1204_280_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2114_45858)(closed [1].it_r, op_2);
}

	/* CA_UNNEEDED_PARENTHESES_RULE check_routine */
void _A1205_244_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_UNNEEDED_PARENTHESES_RULE check_routine */
void __A1205_244_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_UNNEEDED_OT_LOCAL_RULE process_object_test */
void _A1206_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_UNNEEDED_OT_LOCAL_RULE process_object_test */
void __A1206_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_UNNEEDED_OBJECT_TEST_RULE process_feature */
void _A1207_111_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_UNNEEDED_OBJECT_TEST_RULE process_feature */
void __A1207_111_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_UNNEEDED_OBJECT_TEST_RULE process_object_test */
void _A1207_112_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_UNNEEDED_OBJECT_TEST_RULE process_object_test */
void __A1207_112_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_UNNEEDED_HELPER_VARIABLE_RULE pre_process_feature */
void _A1208_270_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_UNNEEDED_HELPER_VARIABLE_RULE pre_process_feature */
void __A1208_270_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_UNNEEDED_HELPER_VARIABLE_RULE post_process_feature */
void _A1208_271_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_UNNEEDED_HELPER_VARIABLE_RULE post_process_feature */
void __A1208_271_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_UNNEEDED_HELPER_VARIABLE_RULE pre_process_list */
void _A1208_272_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_UNNEEDED_HELPER_VARIABLE_RULE pre_process_list */
void __A1208_272_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_UNNEEDED_HELPER_VARIABLE_RULE process_access_id */
void _A1208_278_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_UNNEEDED_HELPER_VARIABLE_RULE process_access_id */
void __A1208_278_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_UNNEEDED_HELPER_VARIABLE_RULE is_integer_string_within_bounds */
EIF_BOOLEAN _A1208_53_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* CA_UNNEEDED_HELPER_VARIABLE_RULE is_integer_string_within_bounds */
EIF_BOOLEAN __A1208_53_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_i4, closed [3].it_i4);
}

	/* CA_UNNEEDED_ACCESSOR_FUNCTION_RULE process_feature */
void _A1209_107_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_UNNEEDED_ACCESSOR_FUNCTION_RULE process_feature */
void __A1209_107_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_UNNEEDED_ACCESSOR_FUNCTION_RULE process_do */
void _A1209_106_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_UNNEEDED_ACCESSOR_FUNCTION_RULE process_do */
void __A1209_106_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_UNNECESSARY_SIGN_OPERATOR_RULE process_unary */
void _A1210_108_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_UNNECESSARY_SIGN_OPERATOR_RULE process_unary */
void __A1210_108_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_UNNECESSARY_SIGN_OPERATOR_RULE process_int */
void _A1210_109_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_UNNECESSARY_SIGN_OPERATOR_RULE process_int */
void __A1210_109_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_UNNECESSARY_SIGN_OPERATOR_RULE process_real */
void _A1210_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_UNNECESSARY_SIGN_OPERATOR_RULE process_real */
void __A1210_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_UNDESIRABLE_COMMENT_CONTENT_RULE check_comments */
void _A1211_122_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_UNDESIRABLE_COMMENT_CONTENT_RULE check_comments */
void __A1211_122_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_UNDESIRABLE_COMMENT_CONTENT_RULE initialize_regex */
void _A1211_105 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* CA_UNDESIRABLE_COMMENT_CONTENT_RULE initialize_regex */
void __A1211_105 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* CA_TODO_RULE process_class */
void _A1212_294_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_TODO_RULE process_class */
void __A1212_294_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_SIMPLIFIABLE_BOOLEAN_RULE process_un_not */
void _A1213_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_SIMPLIFIABLE_BOOLEAN_RULE process_un_not */
void __A1213_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_SHORT_CIRCUIT_IF_RULE process_if */
void _A1214_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_SHORT_CIRCUIT_IF_RULE process_if */
void __A1214_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_SEMICOLON_ARGUMENTS_RULE process_feature */
void _A1215_111_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_SEMICOLON_ARGUMENTS_RULE process_feature */
void __A1215_111_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_SEMICOLON_ARGUMENTS_RULE process_body */
void _A1215_112_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_SEMICOLON_ARGUMENTS_RULE process_body */
void __A1215_112_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* TEXT_FORMATTER process_keyword_text */
void _A1092_273_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R14545[Dtype(open [1].it_r) - 1908])(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* TEXT_FORMATTER process_keyword_text */
void __A1092_273_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R14545[Dtype(op_1) - 1908])(op_1, closed [1].it_r, closed [2].it_r);
}

	/* TEXT_FORMATTER process_feature_text */
void _A1092_261_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R14533[Dtype(open [1].it_r) - 1908])(open [1].it_r, closed [1].it_r, closed [2].it_r, closed [3].it_b);
}

	/* TEXT_FORMATTER process_feature_text */
void __A1092_261_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R14533[Dtype(op_1) - 1908])(op_1, closed [1].it_r, closed [2].it_r, closed [3].it_b);
}

	/* TEXT_FORMATTER process_local_text */
void _A1092_247_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R14519[Dtype(open [1].it_r) - 1908])(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* TEXT_FORMATTER process_local_text */
void __A1092_247_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R14519[Dtype(op_1) - 1908])(op_1, closed [1].it_r, closed [2].it_r);
}

	/* TEXT_FORMATTER process_symbol_text */
void _A1092_272_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R14544[Dtype(open [1].it_r) - 1908])(open [1].it_r, closed [1].it_r);
}

	/* TEXT_FORMATTER process_symbol_text */
void __A1092_272_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R14544[Dtype(op_1) - 1908])(op_1, closed [1].it_r);
}

	/* TEXT_FORMATTER add_feature_name */
void _A1092_300_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1907_18047)(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* TEXT_FORMATTER add_feature_name */
void __A1092_300_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1907_18047)(op_1, closed [1].it_r, closed [2].it_r);
}

	/* TEXT_FORMATTER add_int */
void _A1092_291_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) F1907_18038)(open [1].it_r, closed [1].it_i4);
}

	/* TEXT_FORMATTER add_int */
void __A1092_291_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) F1907_18038)(op_1, closed [1].it_i4);
}

	/* TEXT_FORMATTER process_feature_name_text */
void _A1092_259_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R14531[Dtype(open [1].it_r) - 1908])(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* TEXT_FORMATTER process_feature_name_text */
void __A1092_259_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R14531[Dtype(op_1) - 1908])(op_1, closed [1].it_r, closed [2].it_r);
}

	/* TEXT_FORMATTER add */
void _A1092_208_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F402_5843)(open [1].it_r, closed [1].it_r);
}

	/* TEXT_FORMATTER add */
void __A1092_208_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F402_5843)(op_1, closed [1].it_r);
}

	/* TEXT_FORMATTER add_class_syntax */
void _A1092_307_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1907_18054)(open [1].it_r, closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* TEXT_FORMATTER add_class_syntax */
void __A1092_307_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1907_18054)(op_1, closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* TEXT_FORMATTER add_local */
void _A1092_289_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1907_18036)(open [1].it_r, closed [1].it_r);
}

	/* TEXT_FORMATTER add_local */
void __A1092_289_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1907_18036)(op_1, closed [1].it_r);
}

	/* TEXT_FORMATTER process_target_name_text */
void _A1092_258_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R14530[Dtype(open [1].it_r) - 1908])(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* TEXT_FORMATTER process_target_name_text */
void __A1092_258_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R14530[Dtype(op_1) - 1908])(op_1, closed [1].it_r, closed [2].it_r);
}

	/* TEXT_FORMATTER add_string */
void _A1092_288_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1907_18035)(open [1].it_r, closed [1].it_r);
}

	/* TEXT_FORMATTER add_string */
void __A1092_288_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1907_18035)(op_1, closed [1].it_r);
}

	/* CA_SELF_COMPARISON_RULE process_comparison */
void _A1216_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_SELF_COMPARISON_RULE process_comparison */
void __A1216_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_SELF_ASSIGNMENT_RULE pre_assign */
void _A1217_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_SELF_ASSIGNMENT_RULE pre_assign */
void __A1217_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_REAL_NAN_COMPARISON_RULE process_feature */
void _A1218_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_REAL_NAN_COMPARISON_RULE process_feature */
void __A1218_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_REAL_NAN_COMPARISON_RULE process_bin_eq */
void _A1218_106_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_REAL_NAN_COMPARISON_RULE process_bin_eq */
void __A1218_106_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_REAL_NAN_COMPARISON_RULE process_inline_agent_start */
void _A1218_107_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_REAL_NAN_COMPARISON_RULE process_inline_agent_start */
void __A1218_107_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_REAL_NAN_COMPARISON_RULE process_inline_agent_stop */
void _A1218_108_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_REAL_NAN_COMPARISON_RULE process_inline_agent_stop */
void __A1218_108_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_OBJECT_TEST_FAILING_RULE process_ot */
void _A1219_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_OBJECT_TEST_FAILING_RULE process_ot */
void __A1219_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_OBJECT_TEST_FAILING_RULE process_feature */
void _A1219_104_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_OBJECT_TEST_FAILING_RULE process_feature */
void __A1219_104_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_OBJECT_TEST_ALWAYS_SUCCEEDS_RULE pre_process_feature */
void _A1220_107_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_OBJECT_TEST_ALWAYS_SUCCEEDS_RULE pre_process_feature */
void __A1220_107_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_OBJECT_TEST_ALWAYS_SUCCEEDS_RULE inline-agent#1 of register_actions */
void _A1220_117_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2130_45859)(closed [1].it_r, open [1].it_r);
}

	/* CA_OBJECT_TEST_ALWAYS_SUCCEEDS_RULE inline-agent#1 of register_actions */
void __A1220_117_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2130_45859)(closed [1].it_r, op_2);
}

	/* CA_OBJECT_TEST_ALWAYS_SUCCEEDS_RULE pre_process_bin_ne */
void _A1220_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_OBJECT_TEST_ALWAYS_SUCCEEDS_RULE pre_process_bin_ne */
void __A1220_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_OBJECT_TEST_ALWAYS_SUCCEEDS_RULE pre_process_object_test */
void _A1220_106_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_OBJECT_TEST_ALWAYS_SUCCEEDS_RULE pre_process_object_test */
void __A1220_106_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_OBJECT_CREATION_WITHIN_LOOP_RULE process_loop */
void _A1221_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_OBJECT_CREATION_WITHIN_LOOP_RULE process_loop */
void __A1221_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_NPATH_RULE process_feature */
void _A1222_116_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_NPATH_RULE process_feature */
void __A1222_116_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_NPATH_RULE evaluate_feature */
void _A1222_117_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_NPATH_RULE evaluate_feature */
void __A1222_117_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_NPATH_RULE pre_process_if */
void _A1222_120_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_NPATH_RULE pre_process_if */
void __A1222_120_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_NPATH_RULE post_process_if */
void _A1222_121_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_NPATH_RULE post_process_if */
void __A1222_121_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_NPATH_RULE pre_process_loop */
void _A1222_122_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_NPATH_RULE pre_process_loop */
void __A1222_122_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_NPATH_RULE post_process_loop */
void _A1222_123_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_NPATH_RULE post_process_loop */
void __A1222_123_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_NPATH_RULE pre_process_inspect */
void _A1222_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_NPATH_RULE pre_process_inspect */
void __A1222_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_NPATH_RULE post_process_inspect */
void _A1222_125_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_NPATH_RULE post_process_inspect */
void __A1222_125_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_NPATH_RULE is_integer_string_within_bounds */
EIF_BOOLEAN _A1222_53_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* CA_NPATH_RULE is_integer_string_within_bounds */
EIF_BOOLEAN __A1222_53_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_i4, closed [3].it_i4);
}

	/* CA_NESTED_COMPLEXITY_RULE pre_process_feature */
void _A1223_118_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_NESTED_COMPLEXITY_RULE pre_process_feature */
void __A1223_118_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_NESTED_COMPLEXITY_RULE post_process_feature */
void _A1223_119_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_NESTED_COMPLEXITY_RULE post_process_feature */
void __A1223_119_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_NESTED_COMPLEXITY_RULE pre_process_if */
void _A1223_120_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_NESTED_COMPLEXITY_RULE pre_process_if */
void __A1223_120_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_NESTED_COMPLEXITY_RULE post_process_if */
void _A1223_121_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_NESTED_COMPLEXITY_RULE post_process_if */
void __A1223_121_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_NESTED_COMPLEXITY_RULE pre_process_loop */
void _A1223_122_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_NESTED_COMPLEXITY_RULE pre_process_loop */
void __A1223_122_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_NESTED_COMPLEXITY_RULE post_process_loop */
void _A1223_123_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_NESTED_COMPLEXITY_RULE post_process_loop */
void __A1223_123_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_NESTED_COMPLEXITY_RULE is_integer_string_within_bounds */
EIF_BOOLEAN _A1223_53_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* CA_NESTED_COMPLEXITY_RULE is_integer_string_within_bounds */
EIF_BOOLEAN __A1223_53_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_i4, closed [3].it_i4);
}

	/* CA_MISSING_IS_EQUAL_RULE process_class */
void _A1224_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_MISSING_IS_EQUAL_RULE process_class */
void __A1224_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_MISSING_CREATION_PROC_WITHOUT_ARGS_RULE process_create */
void _A1225_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_MISSING_CREATION_PROC_WITHOUT_ARGS_RULE process_create */
void __A1225_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_MISSING_CREATION_PROC_WITHOUT_ARGS_RULE process_feature_clause */
void _A1225_112_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_MISSING_CREATION_PROC_WITHOUT_ARGS_RULE process_feature_clause */
void __A1225_112_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_MISSING_CREATION_PROC_WITHOUT_ARGS_RULE do_post_class_cleanup */
void _A1225_111_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_MISSING_CREATION_PROC_WITHOUT_ARGS_RULE do_post_class_cleanup */
void __A1225_111_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_MERGEABLE_FEATURE_CLAUSES_RULE class_pre */
void _A1226_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_MERGEABLE_FEATURE_CLAUSES_RULE class_pre */
void __A1226_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_MERGEABLE_FEATURE_CLAUSES_RULE process_feature_clause */
void _A1226_107_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_MERGEABLE_FEATURE_CLAUSES_RULE process_feature_clause */
void __A1226_107_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_MANY_ARGUMENTS_RULE process_feature */
void _A1227_114_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_MANY_ARGUMENTS_RULE process_feature */
void __A1227_114_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_MANY_ARGUMENTS_RULE is_integer_string_within_bounds */
EIF_BOOLEAN _A1227_53_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* CA_MANY_ARGUMENTS_RULE is_integer_string_within_bounds */
EIF_BOOLEAN __A1227_53_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_i4, closed [3].it_i4);
}

	/* CA_LOOP_INVARIANT_COMPUTATION_RULE pre_process_loop */
void _A1228_274_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_LOOP_INVARIANT_COMPUTATION_RULE pre_process_loop */
void __A1228_274_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_LOOP_INVARIANT_COMPUTATION_RULE post_process_loop */
void _A1228_275_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_LOOP_INVARIANT_COMPUTATION_RULE post_process_loop */
void __A1228_275_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_LOOP_INVARIANT_COMPUTATION_RULE pre_process_feature */
void _A1228_273_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_LOOP_INVARIANT_COMPUTATION_RULE pre_process_feature */
void __A1228_273_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_LOOP_INVARIANT_COMPUTATION_RULE post_process_feature */
void _A1228_276_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_LOOP_INVARIANT_COMPUTATION_RULE post_process_feature */
void __A1228_276_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_LOCAL_USED_FOR_RESULT_RULE process_feature */
void _A1229_268_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_LOCAL_USED_FOR_RESULT_RULE process_feature */
void __A1229_268_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_LOCAL_NAMING_CONVENTION_RULE process_routine */
void _A1230_115_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_LOCAL_NAMING_CONVENTION_RULE process_routine */
void __A1230_115_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_ITERABLE_LOOP_RULE process_feature */
void _A1231_113_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_ITERABLE_LOOP_RULE process_feature */
void __A1231_113_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_ITERABLE_LOOP_RULE process_loop_start */
void _A1231_114_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_ITERABLE_LOOP_RULE process_loop_start */
void __A1231_114_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_ITERABLE_LOOP_RULE process_loop_end */
void _A1231_115_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_ITERABLE_LOOP_RULE process_loop_end */
void __A1231_115_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_ITERABLE_LOOP_RULE process_instruction_call */
void _A1231_119_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_ITERABLE_LOOP_RULE process_instruction_call */
void __A1231_119_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_INSPECT_NO_WHEN_RULE process_inspect */
void _A1232_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_INSPECT_NO_WHEN_RULE process_inspect */
void __A1232_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_INSPECT_INSTRUCTIONS_RULE process_inspect */
void _A1233_106_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_INSPECT_INSTRUCTIONS_RULE process_inspect */
void __A1233_106_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_INSPECT_INSTRUCTIONS_RULE is_integer_string_within_bounds */
EIF_BOOLEAN _A1233_53_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* CA_INSPECT_INSTRUCTIONS_RULE is_integer_string_within_bounds */
EIF_BOOLEAN __A1233_53_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_i4, closed [3].it_i4);
}

	/* CA_IF_ELSE_NOT_EQUAL_RULE process_if */
void _A1234_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_IF_ELSE_NOT_EQUAL_RULE process_if */
void __A1234_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_IF_ELSE_NOT_EQUAL_RULE process_if_expression */
void _A1234_106_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_IF_ELSE_NOT_EQUAL_RULE process_if_expression */
void __A1234_106_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_GENERIC_PARAMETER_TOO_LONG_RULE pre_check_class */
void _A1235_104_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_GENERIC_PARAMETER_TOO_LONG_RULE pre_check_class */
void __A1235_104_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_FEATURE_SECTION_COMMENT_RULE process_feature_clause */
void _A1236_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_FEATURE_SECTION_COMMENT_RULE process_feature_clause */
void __A1236_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_FEATURE_NOT_COMMENTED_RULE process_feature */
void _A1237_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_FEATURE_NOT_COMMENTED_RULE process_feature */
void __A1237_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_FEATURE_NEVER_CALLED_RULE class_check */
void _A1238_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_FEATURE_NEVER_CALLED_RULE class_check */
void __A1238_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_FEATURE_NAMING_CONVENTION_RULE process_feature */
void _A1239_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_FEATURE_NAMING_CONVENTION_RULE process_feature */
void __A1239_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_EXPORT_CAN_BE_RESTRICTED_RULE class_check */
void _A1240_269_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_EXPORT_CAN_BE_RESTRICTED_RULE class_check */
void __A1240_269_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_EXPLICIT_REDUNDANT_INHERITANCE_RULE process_class */
void _A1241_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_EXPLICIT_REDUNDANT_INHERITANCE_RULE process_class */
void __A1241_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_EMPTY_UNCOMMENTED_ROUTINE_RULE process_feature */
void _A1242_109_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_EMPTY_UNCOMMENTED_ROUTINE_RULE process_feature */
void __A1242_109_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_EMPTY_UNCOMMENTED_ROUTINE_RULE process_do */
void _A1242_107_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_EMPTY_UNCOMMENTED_ROUTINE_RULE process_do */
void __A1242_107_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_EMPTY_UNCOMMENTED_ROUTINE_RULE process_once */
void _A1242_108_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_EMPTY_UNCOMMENTED_ROUTINE_RULE process_once */
void __A1242_108_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_EMPTY_RESCUE_CLAUSE_RULE process_feature */
void _A1243_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_EMPTY_RESCUE_CLAUSE_RULE process_feature */
void __A1243_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_EMPTY_LOOP_RULE process_loop */
void _A1244_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_EMPTY_LOOP_RULE process_loop */
void __A1244_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_EMPTY_IF_RULE process_if */
void _A1245_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_EMPTY_IF_RULE process_if */
void __A1245_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_EMPTY_EFFECTIVE_ROUTINE_RULE process_feature */
void _A1246_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_EMPTY_EFFECTIVE_ROUTINE_RULE process_feature */
void __A1246_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_EMPTY_EFFECTIVE_ROUTINE_RULE process_do */
void _A1246_107_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_EMPTY_EFFECTIVE_ROUTINE_RULE process_do */
void __A1246_107_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_EMPTY_CREATION_PROC_RULE process_create */
void _A1247_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_EMPTY_CREATION_PROC_RULE process_create */
void __A1247_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_EMPTY_CREATION_PROC_RULE process_feature_clause */
void _A1247_112_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_EMPTY_CREATION_PROC_RULE process_feature_clause */
void __A1247_112_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_EMPTY_CREATION_PROC_RULE do_post_class_cleanup */
void _A1247_111_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_EMPTY_CREATION_PROC_RULE do_post_class_cleanup */
void __A1247_111_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_DOUBLE_NEGATION_RULE process_un_not */
void _A1248_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_DOUBLE_NEGATION_RULE process_un_not */
void __A1248_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_DEEPLY_NESTED_IF_RULE is_integer_string_within_bounds */
EIF_BOOLEAN _A1249_53_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* CA_DEEPLY_NESTED_IF_RULE is_integer_string_within_bounds */
EIF_BOOLEAN __A1249_53_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_i4, closed [3].it_i4);
}

	/* CA_DEEPLY_NESTED_IF_RULE process_feature */
void _A1249_106_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_DEEPLY_NESTED_IF_RULE process_feature */
void __A1249_106_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_DEEPLY_NESTED_IF_RULE pre_process_if */
void _A1249_108_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_DEEPLY_NESTED_IF_RULE pre_process_if */
void __A1249_108_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_DEEPLY_NESTED_IF_RULE post_process_if */
void _A1249_109_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_DEEPLY_NESTED_IF_RULE post_process_if */
void __A1249_109_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_CREATION_PROC_EXPORTED_RULE process_create */
void _A1250_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_CREATION_PROC_EXPORTED_RULE process_create */
void __A1250_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_CREATION_PROC_EXPORTED_RULE process_feature_clause */
void _A1250_112_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_CREATION_PROC_EXPORTED_RULE process_feature_clause */
void __A1250_112_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_CREATION_PROC_EXPORTED_RULE do_post_class_cleanup */
void _A1250_111_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_CREATION_PROC_EXPORTED_RULE do_post_class_cleanup */
void __A1250_111_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_CQ_SEPARATION_RULE pre_process_feature */
void _A1251_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_CQ_SEPARATION_RULE pre_process_feature */
void __A1251_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_CQ_SEPARATION_RULE post_process_feature */
void _A1251_106_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_CQ_SEPARATION_RULE post_process_feature */
void __A1251_106_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_CQ_SEPARATION_RULE process_assign */
void _A1251_109_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_CQ_SEPARATION_RULE process_assign */
void __A1251_109_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_CQ_SEPARATION_RULE process_creation */
void _A1251_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_CQ_SEPARATION_RULE process_creation */
void __A1251_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_CQ_SEPARATION_RULE process_instruction_call */
void _A1251_111_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_CQ_SEPARATION_RULE process_instruction_call */
void __A1251_111_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_COUNT_EQUALS_ZERO_RULE process_feature */
void _A1252_112_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_COUNT_EQUALS_ZERO_RULE process_feature */
void __A1252_112_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_COUNT_EQUALS_ZERO_RULE process_equality */
void _A1252_113_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_COUNT_EQUALS_ZERO_RULE process_equality */
void __A1252_113_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_COMPARISON_OF_OBJECT_REFS_RULE process_bin_eq */
void _A1253_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_COMPARISON_OF_OBJECT_REFS_RULE process_bin_eq */
void __A1253_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_COMPARISON_OF_OBJECT_REFS_RULE process_feature */
void _A1253_111_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_COMPARISON_OF_OBJECT_REFS_RULE process_feature */
void __A1253_111_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_COMMENT_NOT_WELL_PHRASED_RULE check_feature_clause_comments */
void _A1254_106_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_COMMENT_NOT_WELL_PHRASED_RULE check_feature_clause_comments */
void __A1254_106_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_COMMENT_NOT_WELL_PHRASED_RULE check_feature_comments */
void _A1254_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_COMMENT_NOT_WELL_PHRASED_RULE check_feature_comments */
void __A1254_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_CLASS_NAMING_CONVENTION_RULE process_class */
void _A1255_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_CLASS_NAMING_CONVENTION_RULE process_class */
void __A1255_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_BOOLEAN_RESULT_RULE process_if */
void _A1256_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_BOOLEAN_RESULT_RULE process_if */
void __A1256_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_BOOLEAN_COMPARISON_RULE process_bin_eq */
void _A1257_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_BOOLEAN_COMPARISON_RULE process_bin_eq */
void __A1257_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_ATTRIBUTE_TO_LOCAL_RULE process_class */
void _A1258_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_ATTRIBUTE_TO_LOCAL_RULE process_class */
void __A1258_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_ATTRIBUTE_CAN_BE_CONSTANT_RULE check_class */
void _A1259_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_ATTRIBUTE_CAN_BE_CONSTANT_RULE check_class */
void __A1259_110_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_ATTRIBUTE_CAN_BE_CONSTANT_RULE check_assign */
void _A1259_111_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_ATTRIBUTE_CAN_BE_CONSTANT_RULE check_assign */
void __A1259_111_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_ATTRIBUTE_CAN_BE_CONSTANT_RULE check_attributes */
void _A1259_113_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_ATTRIBUTE_CAN_BE_CONSTANT_RULE check_attributes */
void __A1259_113_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_ARGUMENT_NAMING_CONVENTION_RULE process_body */
void _A1260_115_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_ARGUMENT_NAMING_CONVENTION_RULE process_body */
void __A1260_115_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* TYPE_A_FEATURE_FINDER inline-agent#1 of find_by_routine_id */
EIF_REFERENCE _A1325_86_3 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE)) F2272_45881)(closed [1].it_r, closed [2].it_i4, open [1].it_r);
}

	/* TYPE_A_FEATURE_FINDER inline-agent#1 of find_by_routine_id */
EIF_REFERENCE __A1325_86_3 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_3)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE)) F2272_45881)(closed [1].it_r, closed [2].it_i4, op_3);
}

	/* TYPE_A_FEATURE_FINDER inline-agent#2 of find_by_routine_id */
void _A1325_87_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2272_45882)(closed [1].it_r, open [1].it_r);
}

	/* TYPE_A_FEATURE_FINDER inline-agent#2 of find_by_routine_id */
void __A1325_87_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2272_45882)(closed [1].it_r, op_2);
}

	/* TYPE_A_FEATURE_FINDER inline-agent#1 of find_by_alias */
EIF_REFERENCE _A1325_88_3 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE)) F2272_45883)(closed [1].it_r, closed [2].it_i4, open [1].it_r);
}

	/* TYPE_A_FEATURE_FINDER inline-agent#1 of find_by_alias */
EIF_REFERENCE __A1325_88_3 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_3)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE)) F2272_45883)(closed [1].it_r, closed [2].it_i4, op_3);
}

	/* TYPE_A_FEATURE_FINDER find_in_renamed_type_a_by_name */
void _A1325_54_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, open [1].it_r);
}

	/* TYPE_A_FEATURE_FINDER find_in_renamed_type_a_by_name */
void __A1325_54_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_3)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, op_3);
}

	/* TYPE_A_FEATURE_FINDER feature_in_class_by_name */
EIF_REFERENCE _A1325_53_3 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, closed [2].it_i4, open [1].it_r);
}

	/* TYPE_A_FEATURE_FINDER feature_in_class_by_name */
EIF_REFERENCE __A1325_53_3 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_3)
{
	return f_ptr (closed [1].it_r, closed [2].it_i4, op_3);
}

	/* DEGREE_3 insert_class */
void _A1340_55_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* DEGREE_3 insert_class */
void __A1340_55_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* DEGREE_4 inline-agent#1 of process_and_propagate */
void _A1341_128 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2288_45889)(closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* DEGREE_4 inline-agent#1 of process_and_propagate */
void __A1341_128 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2288_45889)(closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* DEGREE_4 inline-agent#1 of execute */
void _A1341_129 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2288_45890)(closed [1].it_r);
}

	/* DEGREE_4 inline-agent#1 of execute */
void __A1341_129 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2288_45890)(closed [1].it_r);
}

	/* FORMAL_DEC_AS has_constraint */
EIF_BOOLEAN _A2590_95_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F3637_43181)(open [1].it_r);
}

	/* FORMAL_DEC_AS has_constraint */
EIF_BOOLEAN __A2590_95_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F3637_43181)(op_1);
}

	/* CLASS_I is_external_class */
EIF_BOOLEAN _A1574_253_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R20755[Dtype(open [1].it_r) - 2527])(open [1].it_r);
}

	/* CLASS_I is_external_class */
EIF_BOOLEAN __A1574_253_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R20755[Dtype(op_1) - 2527])(op_1);
}

	/* SYSTEM_I set_system_object_class */
void _A1541_359_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* SYSTEM_I set_system_object_class */
void __A1541_359_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* SYSTEM_I set_system_value_type_class */
void _A1541_360_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* SYSTEM_I set_system_value_type_class */
void __A1541_360_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* SYSTEM_I set_system_exception_type_class */
void _A1541_361_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* SYSTEM_I set_system_exception_type_class */
void __A1541_361_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* SYSTEM_I set_any_class */
void _A1541_358_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* SYSTEM_I set_any_class */
void __A1541_358_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* SYSTEM_I set_boolean_class */
void _A1541_362_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* SYSTEM_I set_boolean_class */
void __A1541_362_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* SYSTEM_I set_character_class */
void _A1541_363_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_i4);
}

	/* SYSTEM_I set_character_class */
void __A1541_363_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_i4);
}

	/* SYSTEM_I set_natural_class */
void _A1541_365_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_i4);
}

	/* SYSTEM_I set_natural_class */
void __A1541_365_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_i4);
}

	/* SYSTEM_I set_integer_class */
void _A1541_364_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_i4);
}

	/* SYSTEM_I set_integer_class */
void __A1541_364_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_i4);
}

	/* SYSTEM_I set_real_class */
void _A1541_366_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_i4);
}

	/* SYSTEM_I set_real_class */
void __A1541_366_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_i4);
}

	/* SYSTEM_I set_pointer_class */
void _A1541_367_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* SYSTEM_I set_pointer_class */
void __A1541_367_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* SYSTEM_I set_typed_pointer_class */
void _A1541_374_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* SYSTEM_I set_typed_pointer_class */
void __A1541_374_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* SYSTEM_I set_string_class */
void _A1541_368_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_i4);
}

	/* SYSTEM_I set_string_class */
void __A1541_368_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_i4);
}

	/* SYSTEM_I set_immutable_string_class */
void _A1541_369_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_i4);
}

	/* SYSTEM_I set_immutable_string_class */
void __A1541_369_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_i4);
}

	/* SYSTEM_I set_array_class */
void _A1541_371_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* SYSTEM_I set_array_class */
void __A1541_371_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* SYSTEM_I set_special_class */
void _A1541_372_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* SYSTEM_I set_special_class */
void __A1541_372_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* SYSTEM_I set_tuple_class */
void _A1541_376_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* SYSTEM_I set_tuple_class */
void __A1541_376_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* SYSTEM_I set_disposable_class */
void _A1541_375_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* SYSTEM_I set_disposable_class */
void __A1541_375_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* SYSTEM_I set_routine_class */
void _A1541_377_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* SYSTEM_I set_routine_class */
void __A1541_377_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* SYSTEM_I set_procedure_class */
void _A1541_378_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* SYSTEM_I set_procedure_class */
void __A1541_378_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* SYSTEM_I set_function_class */
void _A1541_379_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* SYSTEM_I set_function_class */
void __A1541_379_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* SYSTEM_I set_predicate_class */
void _A1541_380_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* SYSTEM_I set_predicate_class */
void __A1541_380_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* SYSTEM_I set_type_class */
void _A1541_382_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* SYSTEM_I set_type_class */
void __A1541_382_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* SYSTEM_I set_rt_extension_class */
void _A1541_385_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* SYSTEM_I set_rt_extension_class */
void __A1541_385_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* SYSTEM_I set_exception_manager_class */
void _A1541_386_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* SYSTEM_I set_exception_manager_class */
void __A1541_386_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* SYSTEM_I set_exception_class */
void _A1541_384_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* SYSTEM_I set_exception_class */
void __A1541_384_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* SYSTEM_I set_system_string_class */
void _A1541_370_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* SYSTEM_I set_system_string_class */
void __A1541_370_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* SYSTEM_I set_native_array_class */
void _A1541_373_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* SYSTEM_I set_native_array_class */
void __A1541_373_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* SYSTEM_I set_arguments_class */
void _A1541_381_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* SYSTEM_I set_arguments_class */
void __A1541_381_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* SYSTEM_I set_system_type_class */
void _A1541_383_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* SYSTEM_I set_system_type_class */
void __A1541_383_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* SYSTEM_I inline-agent#1 of update_statistics */
EIF_BOOLEAN _A1541_944_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F2493_45955)(closed [1].it_r, open [1].it_r);
}

	/* SYSTEM_I inline-agent#1 of update_statistics */
EIF_BOOLEAN __A1541_944_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F2493_45955)(closed [1].it_r, op_2);
}

	/* SYSTEM_I inline-agent#1 of is_root_class */
EIF_BOOLEAN _A1541_946_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2493_45957)(closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* SYSTEM_I inline-agent#1 of is_root_class */
EIF_BOOLEAN __A1541_946_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2493_45957)(closed [1].it_r, op_2, closed [2].it_r);
}

	/* SYSTEM_I inline-agent#1 of remove_dead_code */
void _A1541_949_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2493_45960)(closed [1].it_r, open [1].it_r);
}

	/* SYSTEM_I inline-agent#1 of remove_dead_code */
void __A1541_949_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2493_45960)(closed [1].it_r, op_2);
}

	/* SYSTEM_I inline-agent#1 of process_type_system */
void _A1541_950_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2493_45961)(closed [1].it_r, open [1].it_r);
}

	/* SYSTEM_I inline-agent#1 of process_type_system */
void __A1541_950_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2493_45961)(closed [1].it_r, op_2);
}

	/* SYSTEM_I inline-agent#1 of remove_useless_classes */
void _A1541_951_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2493_45962)(closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* SYSTEM_I inline-agent#1 of remove_useless_classes */
void __A1541_951_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2493_45962)(closed [1].it_r, op_2, closed [2].it_r);
}

	/* SYSTEM_I inline-agent#1 of init_recompilation */
void _A1541_952_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2493_45963)(closed [1].it_r, open [1].it_r);
}

	/* SYSTEM_I inline-agent#1 of init_recompilation */
void __A1541_952_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2493_45963)(closed [1].it_r, op_2);
}

	/* SYSTEM_I inline-agent#2 of init_recompilation */
EIF_BOOLEAN _A1541_953_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F2493_45964)(closed [1].it_r, open [1].it_r);
}

	/* SYSTEM_I inline-agent#2 of init_recompilation */
EIF_BOOLEAN __A1541_953_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F2493_45964)(closed [1].it_r, op_2);
}

	/* SYSTEM_I inline-agent#1 of mark_only_used_precompiled_classes */
void _A1541_954_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2493_45965)(closed [1].it_r, open [1].it_r);
}

	/* SYSTEM_I inline-agent#1 of mark_only_used_precompiled_classes */
void __A1541_954_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2493_45965)(closed [1].it_r, op_2);
}

	/* SYSTEM_I inline-agent#1 of init */
void _A1541_955_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2493_45966)(closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* SYSTEM_I inline-agent#1 of init */
void __A1541_955_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2493_45966)(closed [1].it_r, op_2, closed [2].it_r);
}

	/* ISE_SERVER [G#1, G#2] tbl_has */
EIF_BOOLEAN _A2940_88_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* ISE_SERVER [G#1, G#2] tbl_has */
EIF_BOOLEAN __A2940_88_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* COMPILER_SERVER [G#1] make_index */
void A2936_107 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R18224[Dtype(Current) - 2322])(Current, arg1, arg2, arg3);
}

	/* COMPILER_SERVER [G#1] need_index */
EIF_BOOLEAN A2936_108 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R18225[Dtype(Current) - 2322])(Current, arg1);
}

	/* TMP_AST_SERVER inline-agent#1 of process_feature_as */
void _A1375_432_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2325_45908)(closed [1].it_r, closed [2].it_r, open [1].it_r);
}

	/* TMP_AST_SERVER inline-agent#1 of process_feature_as */
void __A1375_432_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_3)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2325_45908)(closed [1].it_r, closed [2].it_r, op_3);
}

	/* SEARCH_TABLE [G#1] force */
void _A3191_47_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* SEARCH_TABLE [NATURAL_64] force */
void _A3070_47_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_64), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_n8);
}

	/* SEARCH_TABLE [INTEGER_32] force */
void _A3573_47_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* SEARCH_TABLE [CHARACTER_32] force */
void _A3576_47_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_c4);
}

	/* SEARCH_TABLE [G#1] force */
void __A3191_47_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* SEARCH_TABLE [NATURAL_64] force */
void __A3070_47_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_64), EIF_TYPED_VALUE * closed, EIF_NATURAL_64 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* SEARCH_TABLE [INTEGER_32] force */
void __A3573_47_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* SEARCH_TABLE [CHARACTER_32] force */
void __A3576_47_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_32), EIF_TYPED_VALUE * closed, EIF_CHARACTER_32 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_REFERENCE_RELATION_CRI find_indirect_referenced_classes */
void _A1422_133_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_REFERENCE_RELATION_CRI find_indirect_referenced_classes */
void __A1422_133_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_REFERENCE_RELATION_CRI find_referenced_classes */
void _A1422_132_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_REFERENCE_RELATION_CRI find_referenced_classes */
void __A1422_132_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_REFERENCE_RELATION_CRI inline-agent#1 of mark_only_syntactical_classes */
EIF_BOOLEAN _A1422_138_2_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2374_45920)(closed [1].it_r, open [1].it_r, open [2].it_r);
}

	/* QL_CLASS_REFERENCE_RELATION_CRI inline-agent#1 of mark_only_syntactical_classes */
EIF_BOOLEAN __A1422_138_2_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_3)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2374_45920)(closed [1].it_r, op_2, op_3);
}

	/* QL_CLASS_DESCENDANT_RELATION_CRI find_descendant_classes */
void _A1426_130_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_DESCENDANT_RELATION_CRI find_descendant_classes */
void __A1426_130_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_DESCENDANT_RELATION_CRI find_proper_descendant_classes */
void _A1426_131_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_DESCENDANT_RELATION_CRI find_proper_descendant_classes */
void __A1426_131_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_DESCENDANT_RELATION_CRI find_heir_classes */
void _A1426_132_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_DESCENDANT_RELATION_CRI find_heir_classes */
void __A1426_132_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_DESCENDANT_RELATION_CRI find_indirect_heir_classes */
void _A1426_133_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_DESCENDANT_RELATION_CRI find_indirect_heir_classes */
void __A1426_133_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_ANCESTOR_RELATION_CRI find_ancestor_classes */
void _A1427_130_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_ANCESTOR_RELATION_CRI find_ancestor_classes */
void __A1427_130_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_ANCESTOR_RELATION_CRI find_proper_ancestor_classes */
void _A1427_131_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_ANCESTOR_RELATION_CRI find_proper_ancestor_classes */
void __A1427_131_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_ANCESTOR_RELATION_CRI find_parent_classes */
void _A1427_132_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_ANCESTOR_RELATION_CRI find_parent_classes */
void __A1427_132_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_ANCESTOR_RELATION_CRI find_indirect_parent_classes */
void _A1427_133_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_ANCESTOR_RELATION_CRI find_indirect_parent_classes */
void __A1427_133_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* QL_DOMAIN_GENERATOR evaluate_item */
void _A1438_146_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_DOMAIN_GENERATOR evaluate_item */
void __A1438_146_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* QL_DOMAIN_GENERATOR on_item_satisfied_by_criterion */
void _A1438_160_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_b);
}

	/* QL_DOMAIN_GENERATOR on_item_satisfied_by_criterion */
void __A1438_160_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_b);
}

	/* QL_GROUP_DOMAIN_GENERATOR inline-agent#1 of process_groups_from_list */
void _A1446_174_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2398_45929)(closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* QL_GROUP_DOMAIN_GENERATOR inline-agent#1 of process_groups_from_list */
void __A1446_174_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2398_45929)(closed [1].it_r, op_2, closed [2].it_r);
}

	/* QL_GROUP_DOMAIN_GENERATOR evaluate_item */
void _A1446_141_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_GROUP_DOMAIN_GENERATOR evaluate_item */
void __A1446_141_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_DOMAIN_GENERATOR evaluate_item */
void _A1447_141_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_DOMAIN_GENERATOR evaluate_item */
void __A1447_141_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* QL_CLASS_DOMAIN_GENERATOR process_group */
void _A1447_158_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_CLASS_DOMAIN_GENERATOR process_group */
void __A1447_158_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_DOMAIN_GENERATOR process_real_feature */
void _A1448_161_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_DOMAIN_GENERATOR process_real_feature */
void __A1448_161_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_DOMAIN_GENERATOR process_invariant */
void _A1448_162_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_DOMAIN_GENERATOR process_invariant */
void __A1448_162_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_DOMAIN_GENERATOR process_class */
void _A1448_159_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_DOMAIN_GENERATOR process_class */
void __A1448_159_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* QL_FEATURE_DOMAIN_GENERATOR process_group */
void _A1448_158_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_FEATURE_DOMAIN_GENERATOR process_group */
void __A1448_158_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* E_SHOW_DESCENDANTS is_class_equal */
EIF_BOOLEAN _A1451_257_2_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_r);
}

	/* E_SHOW_DESCENDANTS is_class_equal */
EIF_BOOLEAN __A1451_257_2_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_3)
{
	return f_ptr (closed [1].it_r, op_2, op_3);
}

	/* ARRAYED_LIST [G#1] extend */
void _A2794_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ARRAYED_LIST [INTEGER_32] extend */
void _A2870_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (2);
	
	RTLR(0,closed [1].it_r);
	RTLR(1,arg1);
	RTLIU(2);
	arg1 = RTLNS(eif_new_type(2055, 0x00).id, 2055, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg1 = open [1].it_i4;
	f_ptr (closed [1].it_r, arg1);
	RTLE;
}

	/* ARRAYED_LIST [NATURAL_8] extend */
void _A2907_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_8), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_n1);
}

	/* ARRAYED_LIST [BOOLEAN] extend */
void _A2952_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (2);
	
	RTLR(0,closed [1].it_r);
	RTLR(1,arg1);
	RTLIU(2);
	arg1 = RTLNS(eif_new_type(2088, 0x00).id, 2088, _OBJSIZ_0_1_0_0_0_0_0_0_);
	*(EIF_BOOLEAN *)arg1 = open [1].it_b;
	f_ptr (closed [1].it_r, arg1);
	RTLE;
}

	/* ARRAYED_LIST [NATURAL_64] extend */
void _A3012_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (2);
	
	RTLR(0,closed [1].it_r);
	RTLR(1,arg1);
	RTLIU(2);
	arg1 = RTLNS(eif_new_type(2064, 0x00).id, 2064, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_NATURAL_64 *)arg1 = open [1].it_n8;
	f_ptr (closed [1].it_r, arg1);
	RTLE;
}

	/* ARRAYED_LIST [POINTER] extend */
void _A3098_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_p);
}

	/* ARRAYED_LIST [NATURAL_32] extend */
void _A3154_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_n4);
}

	/* ARRAYED_LIST [INTEGER_64] extend */
void _A3357_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (2);
	
	RTLR(0,closed [1].it_r);
	RTLR(1,arg1);
	RTLIU(2);
	arg1 = RTLNS(eif_new_type(2052, 0x00).id, 2052, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_INTEGER_64 *)arg1 = open [1].it_i8;
	f_ptr (closed [1].it_r, arg1);
	RTLE;
}

	/* ARRAYED_LIST [CHARACTER_8] extend */
void _A3451_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_c1);
}

	/* ARRAYED_LIST [NATURAL_16] extend */
void _A3496_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_16), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_n2);
}

	/* ARRAYED_LIST [CHARACTER_32] extend */
void _A3519_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_c4);
}

	/* ARRAYED_LIST [INTEGER_8] extend */
void _A3693_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_8), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i1);
}

	/* ARRAYED_LIST [REAL_64] extend */
void _A3729_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REAL_64), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r8);
}

	/* ARRAYED_LIST [REAL_32] extend */
void _A3765_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REAL_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r4);
}

	/* ARRAYED_LIST [INTEGER_16] extend */
void _A3801_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_16), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i2);
}

	/* ARRAYED_LIST [G#1] extend */
void __A2794_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ARRAYED_LIST [INTEGER_32] extend */
void __A2870_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (2);
	
	RTLR(0,closed [1].it_r);
	RTLR(1,arg1);
	RTLIU(2);
	arg1 = RTLNS(eif_new_type(2055, 0x00).id, 2055, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg1 = op_2;
	f_ptr (closed [1].it_r, arg1);
	RTLE;
}

	/* ARRAYED_LIST [NATURAL_8] extend */
void __A2907_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_8), EIF_TYPED_VALUE * closed, EIF_NATURAL_8 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ARRAYED_LIST [BOOLEAN] extend */
void __A2952_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_BOOLEAN op_2)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (2);
	
	RTLR(0,closed [1].it_r);
	RTLR(1,arg1);
	RTLIU(2);
	arg1 = RTLNS(eif_new_type(2088, 0x00).id, 2088, _OBJSIZ_0_1_0_0_0_0_0_0_);
	*(EIF_BOOLEAN *)arg1 = op_2;
	f_ptr (closed [1].it_r, arg1);
	RTLE;
}

	/* ARRAYED_LIST [NATURAL_64] extend */
void __A3012_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_NATURAL_64 op_2)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (2);
	
	RTLR(0,closed [1].it_r);
	RTLR(1,arg1);
	RTLIU(2);
	arg1 = RTLNS(eif_new_type(2064, 0x00).id, 2064, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_NATURAL_64 *)arg1 = op_2;
	f_ptr (closed [1].it_r, arg1);
	RTLE;
}

	/* ARRAYED_LIST [POINTER] extend */
void __A3098_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ARRAYED_LIST [NATURAL_32] extend */
void __A3154_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_32), EIF_TYPED_VALUE * closed, EIF_NATURAL_32 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ARRAYED_LIST [INTEGER_64] extend */
void __A3357_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_64 op_2)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (2);
	
	RTLR(0,closed [1].it_r);
	RTLR(1,arg1);
	RTLIU(2);
	arg1 = RTLNS(eif_new_type(2052, 0x00).id, 2052, _OBJSIZ_0_0_0_0_0_0_1_0_);
	*(EIF_INTEGER_64 *)arg1 = op_2;
	f_ptr (closed [1].it_r, arg1);
	RTLE;
}

	/* ARRAYED_LIST [CHARACTER_8] extend */
void __A3451_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8), EIF_TYPED_VALUE * closed, EIF_CHARACTER_8 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ARRAYED_LIST [NATURAL_16] extend */
void __A3496_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_16), EIF_TYPED_VALUE * closed, EIF_NATURAL_16 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ARRAYED_LIST [CHARACTER_32] extend */
void __A3519_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_32), EIF_TYPED_VALUE * closed, EIF_CHARACTER_32 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ARRAYED_LIST [INTEGER_8] extend */
void __A3693_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_8), EIF_TYPED_VALUE * closed, EIF_INTEGER_8 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ARRAYED_LIST [REAL_64] extend */
void __A3729_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REAL_64), EIF_TYPED_VALUE * closed, EIF_REAL_64 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ARRAYED_LIST [REAL_32] extend */
void __A3765_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REAL_32), EIF_TYPED_VALUE * closed, EIF_REAL_32 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ARRAYED_LIST [INTEGER_16] extend */
void __A3801_124_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_16), EIF_TYPED_VALUE * closed, EIF_INTEGER_16 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* E_SHOW_SUPPLIERS class_name_tester */
EIF_BOOLEAN _A1452_271_2_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_r);
}

	/* E_SHOW_SUPPLIERS class_name_tester */
EIF_BOOLEAN __A1452_271_2_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_3)
{
	return f_ptr (closed [1].it_r, op_2, op_3);
}

	/* E_SHOW_CLIENTS class_name_tester */
EIF_BOOLEAN _A1453_271_2_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_r);
}

	/* E_SHOW_CLIENTS class_name_tester */
EIF_BOOLEAN __A1453_271_2_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_3)
{
	return f_ptr (closed [1].it_r, op_2, op_3);
}

	/* E_SHOW_ANCESTORS is_class_equal */
EIF_BOOLEAN _A1454_257_2_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_r);
}

	/* E_SHOW_ANCESTORS is_class_equal */
EIF_BOOLEAN __A1454_257_2_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_3)
{
	return f_ptr (closed [1].it_r, op_2, op_3);
}

	/* E_SHOW_CALLERS feature_name_tester */
EIF_BOOLEAN _A1460_291_2_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_r);
}

	/* E_SHOW_CALLERS feature_name_tester */
EIF_BOOLEAN __A1460_291_2_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_3)
{
	return f_ptr (closed [1].it_r, op_2, op_3);
}

	/* E_SHOW_ROUTINE_HIERARCHY feature_name_tester */
EIF_BOOLEAN _A1461_276_2_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_r);
}

	/* E_SHOW_ROUTINE_HIERARCHY feature_name_tester */
EIF_BOOLEAN __A1461_276_2_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_3)
{
	return f_ptr (closed [1].it_r, op_2, op_3);
}

	/* E_CLASS_FORMAT_CMD class_name_tester */
EIF_BOOLEAN _A1466_279_2_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_r);
}

	/* E_CLASS_FORMAT_CMD class_name_tester */
EIF_BOOLEAN __A1466_279_2_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_3)
{
	return f_ptr (closed [1].it_r, op_2, op_3);
}

	/* QL_DOMAIN are_items_equivalent */
EIF_BOOLEAN _A1474_113_2_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_r);
}

	/* QL_DOMAIN are_items_equivalent */
EIF_BOOLEAN __A1474_113_2_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_3)
{
	return f_ptr (closed [1].it_r, op_2, op_3);
}

	/* QL_DOMAIN is_item_valid */
EIF_BOOLEAN _A1474_108_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* QL_DOMAIN is_item_valid */
EIF_BOOLEAN __A1474_108_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* SELECTION_LIST inline-agent#1 of unselect */
void _A1500_177 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2452_45931)(closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* SELECTION_LIST inline-agent#1 of unselect */
void __A1500_177 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2452_45931)(closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* SELECTION_LIST inline-agent#1 of process_selection */
void _A1500_178 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2452_45932)(closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* SELECTION_LIST inline-agent#1 of process_selection */
void __A1500_178 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2452_45932)(closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* TYPE_A_CHECKER inline-agent#1 of check_type_validity */
void _A1516_122 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2468_45936)(closed [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r, closed [5].it_r);
}

	/* TYPE_A_CHECKER inline-agent#1 of check_type_validity */
void __A1516_122 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2468_45936)(closed [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r, closed [5].it_r);
}

	/* CONVERTIBILITY_CHECKER check_conversion_type */
void _A1517_62 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r, closed [5].it_r);
}

	/* CONVERTIBILITY_CHECKER check_conversion_type */
void __A1517_62 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r, closed [5].it_r);
}

	/* ADDRESS_TABLE inline-agent#1 of generate_dispatch_table */
void _A1525_306_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2477_45940)(closed [1].it_r, closed [2].it_r, open [1].it_r);
}

	/* ADDRESS_TABLE inline-agent#1 of generate_dispatch_table */
void __A1525_306_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_3)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2477_45940)(closed [1].it_r, closed [2].it_r, op_3);
}

	/* PRETTY_PRINTER do_nothing */
void _A1530_28 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* PRETTY_PRINTER do_nothing */
void __A1530_28 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* PRETTY_PRINTER inline-agent#1 of decrease_indent_with_breaks */
void _A1530_416 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2482_45943)(closed [1].it_r);
}

	/* PRETTY_PRINTER inline-agent#1 of decrease_indent_with_breaks */
void __A1530_416 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2482_45943)(closed [1].it_r);
}

	/* PRETTY_PRINTER inline-agent#1 of increase_indent_with_breaks */
void _A1530_417 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2482_45944)(closed [1].it_r);
}

	/* PRETTY_PRINTER inline-agent#1 of increase_indent_with_breaks */
void __A1530_417 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2482_45944)(closed [1].it_r);
}

	/* TYPE_SET_A inline-agent#1 of info_about_feature_by_rout_id */
EIF_REFERENCE _A1532_96_3 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE)) F2484_45946)(closed [1].it_r, closed [2].it_i4, open [1].it_r);
}

	/* TYPE_SET_A inline-agent#1 of info_about_feature_by_rout_id */
EIF_REFERENCE __A1532_96_3 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_3)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE)) F2484_45946)(closed [1].it_r, closed [2].it_i4, op_3);
}

	/* TYPE_SET_A inline-agent#1 of info_about_feature_by_alias_name_id */
EIF_REFERENCE _A1532_97_3 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE)) F2484_45947)(closed [1].it_r, closed [2].it_i4, open [1].it_r);
}

	/* TYPE_SET_A inline-agent#1 of info_about_feature_by_alias_name_id */
EIF_REFERENCE __A1532_97_3 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_3)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE)) F2484_45947)(closed [1].it_r, closed [2].it_i4, op_3);
}

	/* TYPE_SET_A inline-agent#1 of info_about_feature_by_name_id */
EIF_REFERENCE _A1532_98_3 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE)) F2484_45948)(closed [1].it_r, closed [2].it_i4, open [1].it_r);
}

	/* TYPE_SET_A inline-agent#1 of info_about_feature_by_name_id */
EIF_REFERENCE __A1532_98_3 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_3)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE)) F2484_45948)(closed [1].it_r, closed [2].it_i4, op_3);
}

	/* DEPEND_UNIT trace */
void _A1543_71_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2495_26440)(open [1].it_r);
}

	/* DEPEND_UNIT trace */
void __A1543_71_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2495_26440)(op_1);
}

	/* BYTE_CONTEXT inline-agent#1 of add_object_test_locals */
void _A1539_367_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2491_45952)(closed [1].it_r, open [1].it_r);
}

	/* BYTE_CONTEXT inline-agent#1 of add_object_test_locals */
void __A1539_367_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2491_45952)(closed [1].it_r, op_2);
}

	/* ERT_REGION_MODIFIER apply */
void _A460_33_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6888[Dtype(open [1].it_r) - 528])(open [1].it_r, closed [1].it_r);
}

	/* ERT_REGION_MODIFIER apply */
void __A460_33_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6888[Dtype(op_1) - 528])(op_1, closed [1].it_r);
}

	/* ERT_REGION_MODIFIER reset_applied */
void _A460_34_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ERT_REGION_MODIFIER reset_applied */
void __A460_34_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ERT_REGION_MODIFIER is_region_disjoint */
EIF_BOOLEAN _A460_43_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ERT_REGION_MODIFIER is_region_disjoint */
EIF_BOOLEAN __A460_43_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ERT_REGION_MODIFIER can_remove */
EIF_BOOLEAN _A460_39_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ERT_REGION_MODIFIER can_remove */
EIF_BOOLEAN __A460_39_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ERT_REGION_MODIFIER can_replace */
EIF_BOOLEAN _A460_38_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ERT_REGION_MODIFIER can_replace */
EIF_BOOLEAN __A460_38_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ERT_REGION_MODIFIER can_prepend */
EIF_BOOLEAN _A460_36_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ERT_REGION_MODIFIER can_prepend */
EIF_BOOLEAN __A460_36_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ERT_REGION_MODIFIER can_append */
EIF_BOOLEAN _A460_37_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ERT_REGION_MODIFIER can_append */
EIF_BOOLEAN __A460_37_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ERT_REGION_MODIFIER is_text_available */
EIF_BOOLEAN _A460_40_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R6895[Dtype(open [1].it_r) - 528])(open [1].it_r, closed [1].it_r);
}

	/* ERT_REGION_MODIFIER is_text_available */
EIF_BOOLEAN __A460_40_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R6895[Dtype(op_1) - 528])(op_1, closed [1].it_r);
}

	/* SYSTEM_ROOT is_class_type_set */
EIF_BOOLEAN _A93_40_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* SYSTEM_ROOT is_class_type_set */
EIF_BOOLEAN __A93_40_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* CLASS_TYPE build_binding_table */
void _A1578_241_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2531_27426)(open [1].it_r);
}

	/* CLASS_TYPE build_binding_table */
void __A1578_241_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2531_27426)(op_1);
}

	/* CLASS_TYPE reset_binding_table */
void _A1578_240_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2531_27425)(open [1].it_r);
}

	/* CLASS_TYPE reset_binding_table */
void __A1578_240_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2531_27425)(op_1);
}

	/* CLASS_TYPE build_binding_table_of */
void _A1578_242_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2531_27427)(open [1].it_r, closed [1].it_r);
}

	/* CLASS_TYPE build_binding_table_of */
void __A1578_242_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2531_27427)(op_1, closed [1].it_r);
}

	/* DEGREE_OUTPUT put_process_group */
void _A1322_80_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* DEGREE_OUTPUT put_process_group */
void __A1322_80_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* DEGREE_OUTPUT put_consume_assemblies */
void _A1322_79 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* DEGREE_OUTPUT put_consume_assemblies */
void __A1322_79 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* DEGREE_OUTPUT put_degree_6 */
void _A1322_56_2_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, open [2].it_r);
}

	/* DEGREE_OUTPUT put_degree_6 */
void __A1322_56_2_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_3)
{
	f_ptr (closed [1].it_r, op_2, op_3);
}

	/* VTCM less_than */
EIF_BOOLEAN _A2510_133_1_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F3556_39820)(open [1].it_r, open [2].it_r);
}

	/* VTCM less_than */
EIF_BOOLEAN __A2510_133_1_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F3556_39820)(op_1, op_2);
}

	/* VTCT less_than */
EIF_BOOLEAN _A2248_133_1_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F3294_38809)(open [1].it_r, open [2].it_r);
}

	/* VTCT less_than */
EIF_BOOLEAN __A2248_133_1_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F3294_38809)(op_1, op_2);
}

	/* CA_MERGEABLE_CONDITIONALS_RULE pre_process_feature */
void _A1544_268_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_MERGEABLE_CONDITIONALS_RULE pre_process_feature */
void __A1544_268_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_MERGEABLE_CONDITIONALS_RULE post_process_feature */
void _A1544_269_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_MERGEABLE_CONDITIONALS_RULE post_process_feature */
void __A1544_269_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_MERGEABLE_CONDITIONALS_RULE pre_process_eiffel_list */
void _A1544_270_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_MERGEABLE_CONDITIONALS_RULE pre_process_eiffel_list */
void __A1544_270_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_INHERIT_FROM_ANY_RULE is_rename_written_by_any */
EIF_BOOLEAN _A1545_107_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_INHERIT_FROM_ANY_RULE is_rename_written_by_any */
EIF_BOOLEAN __A1545_107_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* CA_INHERIT_FROM_ANY_RULE is_feature_written_by_any */
EIF_BOOLEAN _A1545_108_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_INHERIT_FROM_ANY_RULE is_feature_written_by_any */
EIF_BOOLEAN __A1545_108_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* CA_INHERIT_FROM_ANY_RULE check_inheritance */
void _A1545_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_INHERIT_FROM_ANY_RULE check_inheritance */
void __A1545_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* OBSOLETE_CALL_HANDLER inline-agent#1 of process_cell */
void _A1551_45_2_3_4_5 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_NATURAL_8, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_NATURAL_8, EIF_REFERENCE, EIF_REFERENCE)) F2503_45969)(closed [1].it_r, open [1].it_r, open [2].it_n1, open [3].it_r, open [4].it_r);
}

	/* OBSOLETE_CALL_HANDLER inline-agent#1 of process_cell */
void __A1551_45_2_3_4_5 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_NATURAL_8, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_NATURAL_8 op_3, EIF_REFERENCE op_4, EIF_REFERENCE op_5)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_NATURAL_8, EIF_REFERENCE, EIF_REFERENCE)) F2503_45969)(closed [1].it_r, op_2, op_3, op_4, op_5);
}

	/* OBSOLETE_CALL_HANDLER inline-agent#1 of obsolete_warning_level_cell */
void _A1551_46_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) F2503_45970)(closed [1].it_r, open [1].it_n4);
}

	/* OBSOLETE_CALL_HANDLER inline-agent#1 of obsolete_warning_level_cell */
void __A1551_46_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_32), EIF_TYPED_VALUE * closed, EIF_NATURAL_32 op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) F2503_45970)(closed [1].it_r, op_2);
}

	/* AST_DECORATED_OUTPUT_STRATEGY inline-agent#1 of process_iteration_as */
void _A1565_530 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2517_45972)(closed [1].it_r);
}

	/* AST_DECORATED_OUTPUT_STRATEGY inline-agent#1 of process_iteration_as */
void __A1565_530 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2517_45972)(closed [1].it_r);
}

	/* AST_DECORATED_OUTPUT_STRATEGY inline-agent#2 of process_iteration_as */
void _A1565_531 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2517_45973)(closed [1].it_r);
}

	/* AST_DECORATED_OUTPUT_STRATEGY inline-agent#2 of process_iteration_as */
void __A1565_531 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2517_45973)(closed [1].it_r);
}

	/* AST_DECORATED_OUTPUT_STRATEGY inline-agent#1 of process_case_expression_as */
void _A1565_532 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2517_45974)(closed [1].it_r, closed [2].it_r);
}

	/* AST_DECORATED_OUTPUT_STRATEGY inline-agent#1 of process_case_expression_as */
void __A1565_532 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2517_45974)(closed [1].it_r, closed [2].it_r);
}

	/* AST_DECORATED_OUTPUT_STRATEGY inline-agent#1 of process_case_as */
void _A1565_533 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2517_45975)(closed [1].it_r, closed [2].it_r);
}

	/* AST_DECORATED_OUTPUT_STRATEGY inline-agent#1 of process_case_as */
void __A1565_533 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2517_45975)(closed [1].it_r, closed [2].it_r);
}

	/* AST_DECORATED_OUTPUT_STRATEGY inline-agent#1 of process_loop_expr_as */
void _A1565_534 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2517_45976)(closed [1].it_r);
}

	/* AST_DECORATED_OUTPUT_STRATEGY inline-agent#1 of process_loop_expr_as */
void __A1565_534 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2517_45976)(closed [1].it_r);
}

	/* AST_DECORATED_OUTPUT_STRATEGY inline-agent#2 of process_loop_expr_as */
void _A1565_535 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2517_45977)(closed [1].it_r);
}

	/* AST_DECORATED_OUTPUT_STRATEGY inline-agent#2 of process_loop_expr_as */
void __A1565_535 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2517_45977)(closed [1].it_r);
}

	/* AST_DECORATED_OUTPUT_STRATEGY do_nothing */
void _A1565_28 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* AST_DECORATED_OUTPUT_STRATEGY do_nothing */
void __A1565_28 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* AST_DECORATED_OUTPUT_STRATEGY inline-agent#1 of process_inspect_expression_as */
void _A1565_536 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2517_45978)(closed [1].it_r, closed [2].it_r);
}

	/* AST_DECORATED_OUTPUT_STRATEGY inline-agent#1 of process_inspect_expression_as */
void __A1565_536 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2517_45978)(closed [1].it_r, closed [2].it_r);
}

	/* AST_DECORATED_OUTPUT_STRATEGY inline-agent#1 of process_inspect_as */
void _A1565_537 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2517_45979)(closed [1].it_r, closed [2].it_r);
}

	/* AST_DECORATED_OUTPUT_STRATEGY inline-agent#1 of process_inspect_as */
void __A1565_537 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2517_45979)(closed [1].it_r, closed [2].it_r);
}

	/* AST_DECORATED_OUTPUT_STRATEGY inline-agent#1 of process_if_expression_as */
void _A1565_538 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2517_45980)(closed [1].it_r);
}

	/* AST_DECORATED_OUTPUT_STRATEGY inline-agent#1 of process_if_expression_as */
void __A1565_538 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2517_45980)(closed [1].it_r);
}

	/* AST_DECORATED_OUTPUT_STRATEGY inline-agent#2 of process_if_expression_as */
void _A1565_539 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2517_45981)(closed [1].it_r);
}

	/* AST_DECORATED_OUTPUT_STRATEGY inline-agent#2 of process_if_expression_as */
void __A1565_539 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2517_45981)(closed [1].it_r);
}

	/* TEXT_FORMATTER_DECORATOR exdent */
void _A1402_396 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* TEXT_FORMATTER_DECORATOR exdent */
void __A1402_396 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* TEXT_FORMATTER_DECORATOR put_space */
void _A1402_413 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* TEXT_FORMATTER_DECORATOR put_space */
void __A1402_413 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* CA_OBSOLETE_FEATURE is_integer_string_within_bounds */
EIF_BOOLEAN _A1568_35_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* CA_OBSOLETE_FEATURE is_integer_string_within_bounds */
EIF_BOOLEAN __A1568_35_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_i4, closed [3].it_i4);
}

	/* CLASS_C inline-agent#1 of regenerate_descendants */
EIF_BOOLEAN _A1572_801_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F2525_45983)(closed [1].it_r, open [1].it_r);
}

	/* CLASS_C inline-agent#1 of regenerate_descendants */
EIF_BOOLEAN __A1572_801_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F2525_45983)(closed [1].it_r, op_2);
}

	/* CLASS_C recompile_descendants_with_condition */
void _A1572_781_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE)) F2525_27237)(open [1].it_r, closed [1].it_r, closed [2].it_b, closed [3].it_r);
}

	/* CLASS_C recompile_descendants_with_condition */
void __A1572_781_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE)) F2525_27237)(op_1, closed [1].it_r, closed [2].it_b, closed [3].it_r);
}

	/* CLASS_C inline-agent#1 of recompile_descendants_with_replication */
EIF_BOOLEAN _A1572_802_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F2525_45984)(closed [1].it_r, open [1].it_r);
}

	/* CLASS_C inline-agent#1 of recompile_descendants_with_replication */
EIF_BOOLEAN __A1572_802_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F2525_45984)(closed [1].it_r, op_2);
}

	/* CLASS_C append_name */
void _A1572_725_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CLASS_C append_name */
void __A1572_725_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* EXTERNAL_CLASS_C inline-agent#1 of add_features_of_any */
void _A1573_833 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2526_45986)(closed [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r);
}

	/* EXTERNAL_CLASS_C inline-agent#1 of add_features_of_any */
void __A1573_833 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2526_45986)(closed [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r);
}

	/* FEATURE_I process_pattern */
void _A1590_372 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* FEATURE_I process_pattern */
void __A1590_372 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* FEATURE_I update_instantiator2 */
void _A1590_368 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* FEATURE_I update_instantiator2 */
void __A1590_368 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* FEATURE_I check_assigner */
void _A1590_349 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* FEATURE_I check_assigner */
void __A1590_349 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* FEATURE_I inline-agent#1 of delayed_check_same_signature */
void _A1590_435 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2543_45992)(closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* FEATURE_I inline-agent#1 of delayed_check_same_signature */
void __A1590_435 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2543_45992)(closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* FEATURE_I inline-agent#1 of delayed_check_signature */
void _A1590_436 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2543_45993)(closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* FEATURE_I inline-agent#1 of delayed_check_signature */
void __A1590_436 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2543_45993)(closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* FEATURE_I inline-agent#1 of delayed_check_types */
void _A1590_437 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2543_45994)(closed [1].it_r);
}

	/* FEATURE_I inline-agent#1 of delayed_check_types */
void __A1590_437 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2543_45994)(closed [1].it_r);
}

	/* FEATURE_I has_arguments */
EIF_BOOLEAN _A1590_246_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2543_28201)(open [1].it_r);
}

	/* FEATURE_I has_arguments */
EIF_BOOLEAN __A1590_246_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2543_28201)(op_1);
}

	/* LOCAL_TYPE_A upper_type */
EIF_REFERENCE _A1663_463_2_3_4 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_r, open [3].it_r);
}

	/* LOCAL_TYPE_A upper_type */
EIF_REFERENCE __A1663_463_2_3_4 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_3, EIF_REFERENCE op_4)
{
	return f_ptr (closed [1].it_r, op_2, op_3, op_4);
}

	/* LOCAL_TYPE_A lower_type */
EIF_REFERENCE _A1663_464_2_3_4 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, open [2].it_r, open [3].it_r);
}

	/* LOCAL_TYPE_A lower_type */
EIF_REFERENCE __A1663_464_2_3_4 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_3, EIF_REFERENCE op_4)
{
	return f_ptr (closed [1].it_r, op_2, op_3, op_4);
}

	/* LOCAL_TYPE_A fake inline-agent#46007#1676#459# of add_upper_bound */
EIF_REFERENCE _A1663_468_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F2616_46007)(closed [1].it_r, open [1].it_r);
}

	/* LOCAL_TYPE_A fake inline-agent#46007#1676#459# of add_upper_bound */
EIF_REFERENCE __A1663_468_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F2616_46007)(closed [1].it_r, op_2);
}

	/* LOCAL_TYPE_A fake inline-agent#46008#1676#458# of add_lower_bound */
EIF_REFERENCE _A1663_469_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F2616_46008)(closed [1].it_r, open [1].it_r);
}

	/* LOCAL_TYPE_A fake inline-agent#46008#1676#458# of add_lower_bound */
EIF_REFERENCE __A1663_469_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F2616_46008)(closed [1].it_r, op_2);
}

	/* ERT_AST_MODIFIER apply */
void _A1686_38_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R21920[Dtype(open [1].it_r) - 2639])(open [1].it_r);
}

	/* ERT_AST_MODIFIER apply */
void __A1686_38_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R21920[Dtype(op_1) - 2639])(op_1);
}

	/* ERT_AST_MODIFIER can_apply */
EIF_BOOLEAN _A1686_36_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ERT_AST_MODIFIER can_apply */
EIF_BOOLEAN __A1686_36_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ERT_LIST_ITEM_MODIFIER apply */
void _A1693_64_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R21920[Dtype(open [1].it_r) - 2639])(open [1].it_r);
}

	/* ERT_LIST_ITEM_MODIFIER apply */
void __A1693_64_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R21920[Dtype(op_1) - 2639])(op_1);
}

	/* ERT_LIST_ITEM_MODIFIER is_removed */
EIF_BOOLEAN _A1693_59_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R22009[Dtype(open [1].it_r) - 2646])(open [1].it_r);
}

	/* ERT_LIST_ITEM_MODIFIER is_removed */
EIF_BOOLEAN __A1693_59_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R22009[Dtype(op_1) - 2646])(op_1);
}

	/* ERT_LIST_ITEM_MODIFIER can_apply */
EIF_BOOLEAN _A1693_63_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ERT_LIST_ITEM_MODIFIER can_apply */
EIF_BOOLEAN __A1693_63_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ERT_LIST_ITEM_MODIFIER set_arguments */
void _A1693_51_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1775_16646)(open [1].it_r, closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* ERT_LIST_ITEM_MODIFIER set_arguments */
void __A1693_51_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1775_16646)(op_1, closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* ERT_EXISTING_ITEM_MODIFIER apply */
void _A1694_64_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2647_29934)(open [1].it_r);
}

	/* ERT_EXISTING_ITEM_MODIFIER apply */
void __A1694_64_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2647_29934)(op_1);
}

	/* LOOP_EXPR_BL generate_workbench_test */
void _A1780_175 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* LOOP_EXPR_BL generate_workbench_test */
void __A1780_175 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* LOOP_EXPR_BL generate_end_workbench_test */
void _A1780_176 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* LOOP_EXPR_BL generate_end_workbench_test */
void __A1780_176 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* LOOP_EXPR_BL generate_final_mode_test */
void _A1780_177 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* LOOP_EXPR_BL generate_final_mode_test */
void __A1780_177 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* LOOP_EXPR_BL generate_end_final_mode_test */
void _A1780_178 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* LOOP_EXPR_BL generate_end_final_mode_test */
void __A1780_178 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* E_FEATURE append_name */
void _A2532_373_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* E_FEATURE append_name */
void __A2532_373_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE add_single_line */
void _A1891_139_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, open [1].it_r);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE add_single_line */
void __A1891_139_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_3)
{
	f_ptr (closed [1].it_r, closed [2].it_r, op_3);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE format_elements */
void _A1891_59_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE format_elements */
void __A1891_59_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE inline-agent#2 of report_obsolete_call */
EIF_REFERENCE _A1891_144_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2853_46052)(closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE inline-agent#2 of report_obsolete_call */
EIF_REFERENCE __A1891_144_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2853_46052)(closed [1].it_r, op_2, closed [2].it_r);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE inline-agent#3 of report_obsolete_call */
void _A1891_145_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2853_46053)(closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE inline-agent#3 of report_obsolete_call */
void __A1891_145_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2853_46053)(closed [1].it_r, op_2, closed [2].it_r);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE inline-agent#1 of report_obsolete_call */
void _A1891_143_8 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE)) F2853_46051)(closed [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r, closed [5].it_r, closed [6].it_r, closed [7].it_i4, open [1].it_r);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE inline-agent#1 of report_obsolete_call */
void __A1891_143_8 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_8)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE)) F2853_46051)(closed [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r, closed [5].it_r, closed [6].it_r, closed [7].it_i4, op_8);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE inline-agent#1 of register_actions */
void _A1891_146_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2853_46054)(closed [1].it_r, open [1].it_r);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE inline-agent#1 of register_actions */
void __A1891_146_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2853_46054)(closed [1].it_r, op_2);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE inline-agent#2 of register_actions */
void _A1891_147_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2853_46055)(closed [1].it_r, open [1].it_r);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE inline-agent#2 of register_actions */
void __A1891_147_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2853_46055)(closed [1].it_r, op_2);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE inline-agent#3 of register_actions */
void _A1891_148_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2853_46056)(closed [1].it_r, open [1].it_r);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE inline-agent#3 of register_actions */
void __A1891_148_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2853_46056)(closed [1].it_r, op_2);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE inline-agent#4 of register_actions */
void _A1891_149_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2853_46057)(closed [1].it_r, open [1].it_r);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE inline-agent#4 of register_actions */
void __A1891_149_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2853_46057)(closed [1].it_r, op_2);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE inline-agent#5 of register_actions */
void _A1891_150_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2853_46058)(closed [1].it_r, open [1].it_r);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE inline-agent#5 of register_actions */
void __A1891_150_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2853_46058)(closed [1].it_r, op_2);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE inline-agent#6 of register_actions */
void _A1891_151_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2853_46059)(closed [1].it_r, open [1].it_r);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE inline-agent#6 of register_actions */
void __A1891_151_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2853_46059)(closed [1].it_r, op_2);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE process_access */
void _A1891_128_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE process_access */
void __A1891_128_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE process_address */
void _A1891_129_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE process_address */
void __A1891_129_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE process_binary */
void _A1891_130_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE process_binary */
void __A1891_130_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE process_bracket */
void _A1891_131_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE process_bracket */
void __A1891_131_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE process_converted_expr */
void _A1891_132_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE process_converted_expr */
void __A1891_132_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE process_parameters */
void _A1891_133_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE process_parameters */
void __A1891_133_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE process_precursor */
void _A1891_134_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE process_precursor */
void __A1891_134_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE process_routine_agent */
void _A1891_135_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE process_routine_agent */
void __A1891_135_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE process_static */
void _A1891_136_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE process_static */
void __A1891_136_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE process_unary */
void _A1891_137_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_OBSOLETE_FEATURE_CALL_RULE process_unary */
void __A1891_137_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* GEN_TYPE_A delayed_creation_constraint_check */
void _A1901_548 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r, closed [5].it_r, closed [6].it_i4, closed [7].it_r);
}

	/* GEN_TYPE_A delayed_creation_constraint_check */
void __A1901_548 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r, closed [5].it_r, closed [6].it_i4, closed [7].it_r);
}

	/* GEN_TYPE_A append_to */
void _A1901_358_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* GEN_TYPE_A append_to */
void __A1901_358_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* GEN_TYPE_A ext_append_to */
void _A1901_499_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* GEN_TYPE_A ext_append_to */
void __A1901_499_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* NAMED_TUPLE_TYPE_A check_tuple_feature_clash */
void _A1905_574 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_i4, closed [5].it_r, closed [6].it_i4);
}

	/* NAMED_TUPLE_TYPE_A check_tuple_feature_clash */
void __A1905_574 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_i4, closed [5].it_r, closed [6].it_i4);
}

	/* CONSTRAINT_INFO inline-agent#1 of build_explain */
void _A1942_48_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2910_46071)(closed [1].it_r, closed [2].it_r, open [1].it_r);
}

	/* CONSTRAINT_INFO inline-agent#1 of build_explain */
void __A1942_48_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_3)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F2910_46071)(closed [1].it_r, closed [2].it_r, op_3);
}

	/* CONF_ERROR_OBSERVER report_warning */
void _A357_33_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CONF_ERROR_OBSERVER report_warning */
void __A357_33_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CONF_ERROR_OBSERVER report_error */
void _A357_32_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CONF_ERROR_OBSERVER report_error */
void __A357_32_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CONF_PRINT_VISITOR get_platform_name */
EIF_REFERENCE _A1982_329_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* CONF_PRINT_VISITOR get_platform_name */
EIF_REFERENCE __A1982_329_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* CONF_PRINT_VISITOR get_build_name */
EIF_REFERENCE _A1982_330_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* CONF_PRINT_VISITOR get_build_name */
EIF_REFERENCE __A1982_330_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* CONF_PRINT_VISITOR get_concurrency_name */
EIF_REFERENCE _A1982_331_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* CONF_PRINT_VISITOR get_concurrency_name */
EIF_REFERENCE __A1982_331_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* CONF_PRINT_VISITOR get_void_safety_name */
EIF_REFERENCE _A1982_332_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* CONF_PRINT_VISITOR get_void_safety_name */
EIF_REFERENCE __A1982_332_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* CONF_LIBRARY process */
void _A1183_400_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7292[Dtype(open [1].it_r) - 2011])(open [1].it_r, closed [1].it_r);
}

	/* CONF_LIBRARY process */
void __A1183_400_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7292[Dtype(op_1) - 2011])(op_1, closed [1].it_r);
}

	/* CONF_LIBRARY is_enabled */
EIF_BOOLEAN _A1183_300_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F881_12692)(open [1].it_r, closed [1].it_r);
}

	/* CONF_LIBRARY is_enabled */
EIF_BOOLEAN __A1183_300_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F881_12692)(op_1, closed [1].it_r);
}

	/* CONF_ASSEMBLY process */
void _A1182_408_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2092_20294)(open [1].it_r, closed [1].it_r);
}

	/* CONF_ASSEMBLY process */
void __A1182_408_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2092_20294)(op_1, closed [1].it_r);
}

	/* CONF_ASSEMBLY is_enabled */
EIF_BOOLEAN _A1182_385_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F2092_20271)(open [1].it_r, closed [1].it_r);
}

	/* CONF_ASSEMBLY is_enabled */
EIF_BOOLEAN __A1182_385_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F2092_20271)(op_1, closed [1].it_r);
}

	/* CONF_CLUSTER process */
void _A1189_416_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7292[Dtype(open [1].it_r) - 2011])(open [1].it_r, closed [1].it_r);
}

	/* CONF_CLUSTER process */
void __A1189_416_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7292[Dtype(op_1) - 2011])(op_1, closed [1].it_r);
}

	/* CONF_CLUSTER is_enabled */
EIF_BOOLEAN _A1189_300_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F881_12692)(open [1].it_r, closed [1].it_r);
}

	/* CONF_CLUSTER is_enabled */
EIF_BOOLEAN __A1189_300_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F881_12692)(op_1, closed [1].it_r);
}

	/* CONF_OVERRIDE process */
void _A1191_425_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2101_20421)(open [1].it_r, closed [1].it_r);
}

	/* CONF_OVERRIDE process */
void __A1191_425_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2101_20421)(op_1, closed [1].it_r);
}

	/* CONF_OVERRIDE is_enabled */
EIF_BOOLEAN _A1191_300_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F881_12692)(open [1].it_r, closed [1].it_r);
}

	/* CONF_OVERRIDE is_enabled */
EIF_BOOLEAN __A1191_300_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F881_12692)(op_1, closed [1].it_r);
}

	/* CONF_CLASS is_compiled */
EIF_BOOLEAN _A1293_50_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R16898[Dtype(open [1].it_r) - 2239])(open [1].it_r);
}

	/* CONF_CLASS is_compiled */
EIF_BOOLEAN __A1293_50_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R16898[Dtype(op_1) - 2239])(op_1);
}

	/* CONF_BUILD_VISITOR merge_classes */
void _A1990_420_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CONF_BUILD_VISITOR merge_classes */
void __A1990_420_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CONF_BUILD_VISITOR inline-agent#1 of process_library */
EIF_BOOLEAN _A1990_434_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F2990_46086)(closed [1].it_r, open [1].it_r);
}

	/* CONF_BUILD_VISITOR inline-agent#1 of process_library */
EIF_BOOLEAN __A1990_434_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F2990_46086)(closed [1].it_r, op_2);
}

	/* STRING_32 append_string_general */
void _A1305_217_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* STRING_32 append_string_general */
void __A1305_217_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* PRETTY_PRINTER_OUTPUT_STREAM inline-agent#1 of make_standard_output */
void _A2020_51_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F3066_46103)(closed [1].it_r, open [1].it_r);
}

	/* PRETTY_PRINTER_OUTPUT_STREAM inline-agent#1 of make_standard_output */
void __A2020_51_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F3066_46103)(closed [1].it_r, op_2);
}

	/* PRETTY_PRINTER_OUTPUT_STREAM inline-agent#1 of make_file */
void _A2020_52_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F3066_46104)(closed [1].it_r, open [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* PRETTY_PRINTER_OUTPUT_STREAM inline-agent#1 of make_file */
void __A2020_52_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F3066_46104)(closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* PLAIN_TEXT_FILE is_open_write */
EIF_BOOLEAN _A816_146 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* PLAIN_TEXT_FILE is_open_write */
EIF_BOOLEAN __A816_146 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* FILE is_open_write */
EIF_BOOLEAN _A814_146 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* FILE is_open_write */
EIF_BOOLEAN __A814_146 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* INSPECT_CONTROL format_elements */
void _A2024_403_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* INSPECT_CONTROL format_elements */
void __A2024_403_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* AST_FEATURE_CHECKER_GENERATOR inline-agent#1 of process_guard_as */
EIF_BOOLEAN _A2026_662_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F3072_46106)(closed [1].it_r, open [1].it_r);
}

	/* AST_FEATURE_CHECKER_GENERATOR inline-agent#1 of process_guard_as */
EIF_BOOLEAN __A2026_662_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F3072_46106)(closed [1].it_r, op_2);
}

	/* AST_FEATURE_CHECKER_GENERATOR format_elements */
void _A2026_313_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* AST_FEATURE_CHECKER_GENERATOR format_elements */
void __A2026_313_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* AST_FEATURE_CHECKER_GENERATOR report_vucr */
void _A2026_638 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* AST_FEATURE_CHECKER_GENERATOR report_vucr */
void __A2026_638 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* ERROR_HANDLER insert_error */
void _A979_102 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* ERROR_HANDLER insert_error */
void __A979_102 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* CA_MANIFEST_ARRAY_TYPE_RULE format_elements */
void _A2036_59_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* CA_MANIFEST_ARRAY_TYPE_RULE format_elements */
void __A2036_59_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* CA_MANIFEST_ARRAY_TYPE_RULE process_feature_start */
void _A2036_148_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_MANIFEST_ARRAY_TYPE_RULE process_feature_start */
void __A2036_148_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_MANIFEST_ARRAY_TYPE_RULE process_feature_end */
void _A2036_149_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_MANIFEST_ARRAY_TYPE_RULE process_feature_end */
void __A2036_149_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_MANIFEST_ARRAY_TYPE_RULE process_invariant_start */
void _A2036_150_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_MANIFEST_ARRAY_TYPE_RULE process_invariant_start */
void __A2036_150_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_MANIFEST_ARRAY_TYPE_RULE process_invariant_end */
void _A2036_151_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_MANIFEST_ARRAY_TYPE_RULE process_invariant_end */
void __A2036_151_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_MANIFEST_ARRAY_TYPE_RULE process_assign */
void _A2036_154_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_MANIFEST_ARRAY_TYPE_RULE process_assign */
void __A2036_154_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_MANIFEST_ARRAY_TYPE_RULE process_binary */
void _A2036_155_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_MANIFEST_ARRAY_TYPE_RULE process_binary */
void __A2036_155_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_MANIFEST_ARRAY_TYPE_RULE process_bracket */
void _A2036_156_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_MANIFEST_ARRAY_TYPE_RULE process_bracket */
void __A2036_156_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_MANIFEST_ARRAY_TYPE_RULE process_expr_call */
void _A2036_157_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_MANIFEST_ARRAY_TYPE_RULE process_expr_call */
void __A2036_157_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_MANIFEST_ARRAY_TYPE_RULE process_agent_start */
void _A2036_152_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_MANIFEST_ARRAY_TYPE_RULE process_agent_start */
void __A2036_152_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_MANIFEST_ARRAY_TYPE_RULE process_agent_end */
void _A2036_153_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_MANIFEST_ARRAY_TYPE_RULE process_agent_end */
void __A2036_153_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_MANIFEST_ARRAY_TYPE_RULE process_instr_call */
void _A2036_158_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_MANIFEST_ARRAY_TYPE_RULE process_instr_call */
void __A2036_158_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_MANIFEST_ARRAY_TYPE_RULE process_nested_expr */
void _A2036_159_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_MANIFEST_ARRAY_TYPE_RULE process_nested_expr */
void __A2036_159_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_MANIFEST_ARRAY_TYPE_RULE process_precursor */
void _A2036_160_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_MANIFEST_ARRAY_TYPE_RULE process_precursor */
void __A2036_160_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* TYPE_A ext_append_to */
void _A1660_365_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* TYPE_A ext_append_to */
void __A1660_365_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* TYPE_A append_to */
void _A1660_362_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* TYPE_A append_to */
void __A1660_362_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ES inline-agent#1 of make */
EIF_REFERENCE _A2062_529 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F3108_46116)(closed [1].it_r);
}

	/* ES inline-agent#1 of make */
EIF_REFERENCE __A2062_529 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F3108_46116)(closed [1].it_r);
}

	/* EWB_CODE_ANALYSIS print_line */
void _A2087_500_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EWB_CODE_ANALYSIS print_line */
void __A2087_500_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER day_of_month_action */
EIF_REFERENCE _A2160_113_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_month_action */
EIF_REFERENCE __A2160_113_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER day_of_month_padded_action */
EIF_REFERENCE _A2160_114_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_month_padded_action */
EIF_REFERENCE __A2160_114_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER month_action */
EIF_REFERENCE _A2160_120_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER month_action */
EIF_REFERENCE __A2160_120_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER day_name_action */
EIF_REFERENCE _A2160_116_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_name_action */
EIF_REFERENCE __A2160_116_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER week_number_sunday_as_first_action */
EIF_REFERENCE _A2160_126_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER week_number_sunday_as_first_action */
EIF_REFERENCE __A2160_126_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER year_4_action */
EIF_REFERENCE _A2160_132_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER year_4_action */
EIF_REFERENCE __A2160_132_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER abbreviated_day_name_action */
EIF_REFERENCE _A2160_115_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER abbreviated_day_name_action */
EIF_REFERENCE __A2160_115_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_year_action */
EIF_REFERENCE _A2160_117_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_year_action */
EIF_REFERENCE __A2160_117_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER day_of_week_action */
EIF_REFERENCE _A2160_118_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_week_action */
EIF_REFERENCE __A2160_118_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER day_of_week_0_action */
EIF_REFERENCE _A2160_119_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_week_0_action */
EIF_REFERENCE __A2160_119_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER month_padded_action */
EIF_REFERENCE _A2160_121_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER month_padded_action */
EIF_REFERENCE __A2160_121_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER abbreviated_month_name_action */
EIF_REFERENCE _A2160_122_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER abbreviated_month_name_action */
EIF_REFERENCE __A2160_122_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER month_name_action */
EIF_REFERENCE _A2160_123_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER month_name_action */
EIF_REFERENCE __A2160_123_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER century_number_action */
EIF_REFERENCE _A2160_124_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER century_number_action */
EIF_REFERENCE __A2160_124_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER iso_year_with_century_action */
EIF_REFERENCE _A2160_128_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER iso_year_with_century_action */
EIF_REFERENCE __A2160_128_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER iso_year_without_century_action */
EIF_REFERENCE _A2160_129_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER iso_year_without_century_action */
EIF_REFERENCE __A2160_129_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER week_number_iso_action */
EIF_REFERENCE _A2160_125_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER week_number_iso_action */
EIF_REFERENCE __A2160_125_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER week_number_monday_as_first_action */
EIF_REFERENCE _A2160_127_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER week_number_monday_as_first_action */
EIF_REFERENCE __A2160_127_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER year_1_action */
EIF_REFERENCE _A2160_130_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER year_1_action */
EIF_REFERENCE __A2160_130_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER year_2_action */
EIF_REFERENCE _A2160_131_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER year_2_action */
EIF_REFERENCE __A2160_131_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER hour_12_padded_action */
EIF_REFERENCE _A2160_102_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER hour_12_padded_action */
EIF_REFERENCE __A2160_102_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER hour_12_action */
EIF_REFERENCE _A2160_103_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER hour_12_action */
EIF_REFERENCE __A2160_103_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER hour_24_action */
EIF_REFERENCE _A2160_104_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER hour_24_action */
EIF_REFERENCE __A2160_104_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER minutes_action */
EIF_REFERENCE _A2160_106_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER minutes_action */
EIF_REFERENCE __A2160_106_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER minutes_padded_action */
EIF_REFERENCE _A2160_107_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER minutes_padded_action */
EIF_REFERENCE __A2160_107_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER seconds_action */
EIF_REFERENCE _A2160_108_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER seconds_action */
EIF_REFERENCE __A2160_108_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER seconds_padded_action */
EIF_REFERENCE _A2160_109_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER seconds_padded_action */
EIF_REFERENCE __A2160_109_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_1_action */
EIF_REFERENCE _A2160_110_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_1_action */
EIF_REFERENCE __A2160_110_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_lowercase_action */
EIF_REFERENCE _A2160_111_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_lowercase_action */
EIF_REFERENCE __A2160_111_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_uppercase_action */
EIF_REFERENCE _A2160_112_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_uppercase_action */
EIF_REFERENCE __A2160_112_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* PROJECT_DIRECTORY safe_create_directory */
void _A2165_142_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* PROJECT_DIRECTORY safe_create_directory */
void __A2165_142_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_OBSOLETE_FEATURE_RULE inline-agent#1 of process_routine */
EIF_REFERENCE _A2188_169_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F3234_46129)(closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* CA_OBSOLETE_FEATURE_RULE inline-agent#1 of process_routine */
EIF_REFERENCE __A2188_169_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F3234_46129)(closed [1].it_r, op_2, closed [2].it_r);
}

	/* CA_OBSOLETE_FEATURE_RULE inline-agent#2 of process_routine */
EIF_REFERENCE _A2188_170_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F3234_46130)(closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* CA_OBSOLETE_FEATURE_RULE inline-agent#2 of process_routine */
EIF_REFERENCE __A2188_170_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F3234_46130)(closed [1].it_r, op_2, closed [2].it_r);
}

	/* CA_OBSOLETE_FEATURE_RULE inline-agent#1 of register_actions */
void _A2188_171_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F3234_46131)(closed [1].it_r, open [1].it_r);
}

	/* CA_OBSOLETE_FEATURE_RULE inline-agent#1 of register_actions */
void __A2188_171_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F3234_46131)(closed [1].it_r, op_2);
}

	/* CA_OBSOLETE_FEATURE_RULE inline-agent#2 of register_actions */
void _A2188_172_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F3234_46132)(closed [1].it_r, open [1].it_r);
}

	/* CA_OBSOLETE_FEATURE_RULE inline-agent#2 of register_actions */
void __A2188_172_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F3234_46132)(closed [1].it_r, op_2);
}

	/* CA_OBSOLETE_FEATURE_RULE process_routine */
void _A2188_168_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CA_OBSOLETE_FEATURE_RULE process_routine */
void __A2188_168_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CA_OBSOLETE_FEATURE_RULE is_integer_string_within_bounds */
EIF_BOOLEAN _A2188_35_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* CA_OBSOLETE_FEATURE_RULE is_integer_string_within_bounds */
EIF_BOOLEAN __A2188_35_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_i4, closed [3].it_i4);
}

	/* CL_TYPE_A append_to */
void _A1668_358_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CL_TYPE_A append_to */
void __A1668_358_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* MISSING_LOCAL_TYPE_ERROR inline-agent#1 of locals */
EIF_REFERENCE _A2371_174_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) F3417_46144)(closed [1].it_r, open [1].it_i4);
}

	/* MISSING_LOCAL_TYPE_ERROR inline-agent#1 of locals */
EIF_REFERENCE __A2371_174_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) F3417_46144)(closed [1].it_r, op_2);
}

	/* VGCC2 inline-agent#1 of print_name */
void _A2482_145_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F3528_46153)(closed [1].it_r, closed [2].it_r, open [1].it_r);
}

	/* VGCC2 inline-agent#1 of print_name */
void __A2482_145_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_3)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F3528_46153)(closed [1].it_r, closed [2].it_r, op_3);
}

	/* INHERIT_FEAT inline-agent#1 of process_undefinition */
void _A2524_145 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F3570_46159)(closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* INHERIT_FEAT inline-agent#1 of process_undefinition */
void __A2524_145 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F3570_46159)(closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* EIFFEL_ENV safe_create_dir */
void _A2541_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EIFFEL_ENV safe_create_dir */
void __A2541_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ROUTINE_AS inline-agent#1 of has_false_postcondition */
EIF_BOOLEAN _A2601_127_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F3650_46191)(closed [1].it_r, open [1].it_r);
}

	/* ROUTINE_AS inline-agent#1 of has_false_postcondition */
EIF_BOOLEAN __A2601_127_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F3650_46191)(closed [1].it_r, op_2);
}

	/* NAMED_TUPLE_TYPE_AS inline-agent#1 of has_anchor */
EIF_BOOLEAN _A2633_119_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F3684_46200)(closed [1].it_r, open [1].it_r);
}

	/* NAMED_TUPLE_TYPE_AS inline-agent#1 of has_anchor */
EIF_BOOLEAN __A2633_119_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F3684_46200)(closed [1].it_r, op_2);
}

	/* QUALIFIED_ANCHORED_TYPE_AS inline-agent#1 of dump */
void _A2634_115_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F3685_46202)(closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* QUALIFIED_ANCHORED_TYPE_AS inline-agent#1 of dump */
void __A2634_115_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F3685_46202)(closed [1].it_r, op_2, closed [2].it_r);
}

	/* TYPE_AS has_anchor */
EIF_BOOLEAN _A2630_97_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R31799[Dtype(open [1].it_r) - 3681])(open [1].it_r);
}

	/* TYPE_AS has_anchor */
EIF_BOOLEAN __A2630_97_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R31799[Dtype(op_1) - 3681])(op_1);
}

	/* STRING_8 is_empty */
EIF_BOOLEAN _A1301_163_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1355_14073)(open [1].it_r);
}

	/* STRING_8 is_empty */
EIF_BOOLEAN __A1301_163_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1355_14073)(op_1);
}

	/* PROJECT_LOADER add_library_to_target */
void _A2764_248_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* PROJECT_LOADER add_library_to_target */
void __A2764_248_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* PROJECT_LOADER is_gui_library */
EIF_BOOLEAN _A2764_249_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* PROJECT_LOADER is_gui_library */
EIF_BOOLEAN __A2764_249_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}


#ifdef __cplusplus
}
#endif
