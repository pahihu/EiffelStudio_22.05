
#ifndef _C66_ds3256_
#define _C66_ds3256_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F2949_33628(EIF_REFERENCE);
extern void F2949_33632(EIF_REFERENCE);
extern void F2949_33633(EIF_REFERENCE);
extern void EIF_Minit3256(void);

#ifdef __cplusplus
}
#endif

#endif
