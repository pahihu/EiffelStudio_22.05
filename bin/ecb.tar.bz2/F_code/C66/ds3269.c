/*
 * Code for class DS_SPARSE_CONTAINER_CURSOR [NATURAL_64, NATURAL_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds3269.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_SPARSE_CONTAINER_CURSOR}.make */
void F2960_33656 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -2L);
	RTLE;
}

/* {DS_SPARSE_CONTAINER_CURSOR}.after */
EIF_BOOLEAN F2960_33658 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) == ((EIF_INTEGER_32) -3L));
}

/* {DS_SPARSE_CONTAINER_CURSOR}.before */
EIF_BOOLEAN F2960_33659 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) == ((EIF_INTEGER_32) -2L));
}

/* {DS_SPARSE_CONTAINER_CURSOR}.off */
EIF_BOOLEAN F2960_33660 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) < ((EIF_INTEGER_32) 0L));
}

/* {DS_SPARSE_CONTAINER_CURSOR}.set_position */
void F2960_33662 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) = (EIF_INTEGER_32) arg1;
}

/* {DS_SPARSE_CONTAINER_CURSOR}.set_after */
void F2960_33663 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -3L);
}

/* {DS_SPARSE_CONTAINER_CURSOR}.correct_mismatch */
void F2960_33669 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tb1 = '\01';
	tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(13229,F924_13229, (Current))) + _REFACS_7_);
	loc2 = tr1;
	if (!((EIF_BOOLEAN) !EIF_TEST(loc2))) {
		{
			/* INLINED CODE (IMMUTABLE_STRING_8.is_empty) */
			tb2 = (EIF_BOOLEAN)  0;
			(void) loc2;
			ti4_1 = *(EIF_INTEGER_32 *)(loc2+ _LNGOFF_1_0_0_2_);
			tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
			/* END INLINED CODE */
		}
		tb2 = tb2;
		tb1 = tb2;
	}
	if (tb1) {
		{
			/* INLINED CODE (DS_SPARSE_CONTAINER_CURSOR.correct_mismatch_20130823) */
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_))--;
			/* END INLINED CODE */
		}
		;
	} else {
		{
			/* INLINED CODE (READABLE_STRING_GENERAL.is_integer) */
			tb1 = (EIF_BOOLEAN)  0;
			(void) loc2;
			tb1 = F2243_21838(loc2, ((EIF_INTEGER_32) 3L));
			/* END INLINED CODE */
		}
		tb1 = tb1;
		if (tb1) {
			{
				/* INLINED CODE (READABLE_STRING_GENERAL.to_integer) */
				tr1 = (EIF_REFERENCE)  0;
				ti4_1 = (EIF_INTEGER_32)  0;
				(void) loc2;
				tr1 = RTOSCF(21841,F2243_21841, (loc2));
				F449_6553(RTCW(tr1), loc2, ((EIF_INTEGER_32) 0L));
				ti4_1 = F449_6558(RTCW(tr1));
				/* END INLINED CODE */
			}
			loc1 = ti4_1;
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 20130823L))) {
				{
					/* INLINED CODE (DS_SPARSE_CONTAINER_CURSOR.correct_mismatch_20130823) */
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_))--;
					/* END INLINED CODE */
				}
				;
			} else {
				F924_13228(Current);
			}
		} else {
			F924_13228(Current);
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER_CURSOR}.correct_mismatch_20130823 */
void F2960_33670 (EIF_REFERENCE Current)
{
	GTCX
	
	
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_))--;
}

void EIF_Minit3269 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
