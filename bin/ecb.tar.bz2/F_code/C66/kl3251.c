/*
 * Code for class KL_SPECIAL_ROUTINES [NATURAL_64]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl3251.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_SPECIAL_ROUTINES}.make */
EIF_REFERENCE F99_2070 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {1932,0xFFF8,1,0xFFFF};
		EIF_TYPE typres0;
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		tr1 = RTLNSP2(typres0.id,0,arg1,sizeof(EIF_NATURAL_64), EIF_TRUE);
		RT_SPECIAL_COUNT(tr1) = 0;
	}
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {KL_SPECIAL_ROUTINES}.make_filled */
EIF_REFERENCE F99_2071 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {1932,0xFFF8,1,0xFFFF};
		EIF_TYPE typres0;
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		tr1 = RTLNSP2(typres0.id,0,arg2,sizeof(EIF_NATURAL_64), EIF_TRUE);
	}
	F1933_18447(RTCW(tr1), arg1, arg2);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {KL_SPECIAL_ROUTINES}.to_special */
EIF_REFERENCE F99_2073 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	
	
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	return (EIF_REFERENCE) tr1;
}

/* {KL_SPECIAL_ROUTINES}.force */
void F99_2075 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_NATURAL_64 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,arg1);
	RTLIU(1);
	
	RTGC;
	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (arg1);
	if ((EIF_BOOLEAN) (arg3 < ti4_1)) {
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_NATURAL_64 *)RTCW(arg1) + (arg3)) = arg2;
		/* END INLINED CODE */
		;
	} else {
		ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (arg1);
		F1933_18468(RTCW(arg1), arg2, ti4_1, arg3);
	}
	RTLE;
}

/* {KL_SPECIAL_ROUTINES}.aliased_resized_area */
EIF_REFERENCE F99_2078 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_capacity__i4 (arg1);
	if ((EIF_BOOLEAN) (arg2 > ti4_1)) {
		tr1 = (EIF_REFERENCE) eif_builtin_SPECIAL_aliased_resized_area__i4_s (arg1, arg2);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTLE;
		return (EIF_REFERENCE) arg1;
	}/* NOTREACHED */
	
}

/* {KL_SPECIAL_ROUTINES}.aliased_resized_area_with_default */
EIF_REFERENCE F99_2079 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_NATURAL_64 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_capacity__i4 (arg1);
	if ((EIF_BOOLEAN) (arg3 > ti4_1)) {
		{
			/* INLINED CODE (SPECIAL.aliased_resized_area_with_default) */
			tr1 = (EIF_REFERENCE)  0;
			(void) RTCW(arg1);
			tr1 = (EIF_REFERENCE) eif_builtin_SPECIAL_aliased_resized_area__i4_s (arg1, arg3);
			ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
			F1933_18468(RTCW(tr1), arg2, ti4_1, (EIF_INTEGER_32) (arg3 - ((EIF_INTEGER_32) 1L)));
			/* END INLINED CODE */
		}
		tr1 = tr1;
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTLE;
		return (EIF_REFERENCE) arg1;
	}/* NOTREACHED */
	
}

void EIF_Minit3251 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
