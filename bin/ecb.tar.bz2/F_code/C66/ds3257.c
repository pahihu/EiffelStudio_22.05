/*
 * Code for class DS_CURSOR [NATURAL_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds3257.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_CURSOR}.item */
EIF_NATURAL_32 F2945_33614 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = (RTNA((Current)), ((EIF_REFERENCE) 0));
	Result = (RTNA((RTCW(tr1), Current)), ((EIF_NATURAL_32) 0));
	RTLE;
	return Result;
}

/* {DS_CURSOR}.same_position */
EIF_BOOLEAN F2945_33617 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = (RTNA((Current)), ((EIF_REFERENCE) 0));
	Result = (RTNA((RTCW(tr1), Current, arg1)), ((EIF_BOOLEAN) 0));
	RTLE;
	return Result;
}

/* {DS_CURSOR}.copy */
void F2945_33620 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)((RTNA((Current)), ((EIF_REFERENCE) 0)) != NULL)) {
		tb1 = (EIF_BOOLEAN) !(RTNA((Current)), ((EIF_BOOLEAN) 0));
	}
	if (tb1) {
		tr1 = (RTNA((Current)), ((EIF_REFERENCE) 0));
		(RTNA((RTCW(tr1), Current)));
	}
	(RTNA((Current, arg1)));
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) NULL;
	if ((EIF_BOOLEAN) !(RTNA((Current)), ((EIF_BOOLEAN) 0))) {
		tr1 = (RTNA((Current)), ((EIF_REFERENCE) 0));
		(RTNA((RTCW(tr1), Current)));
	}
	RTLE;
}

/* {DS_CURSOR}.is_equal */
EIF_BOOLEAN F2945_33621 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = (RTNA((Current)), ((EIF_REFERENCE) 0));
	{
		/* INLINED CODE (KL_ANY_ROUTINES.same_types) */
		tb1 = (EIF_BOOLEAN)  0;
		(void) RTCW(tr1);
		tr2 = RTCCL(arg1);
		tb1 = (EIF_BOOLEAN) eif_builtin_ANY_same_type__o_b (Current, tr2);
		/* END INLINED CODE */
	}
	tb1 = tb1;
	if (tb1) {
		RTLE;
		return (EIF_BOOLEAN) (RTNA((Current, arg1)), ((EIF_BOOLEAN) 0));
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

/* {DS_CURSOR}.set_next_cursor */
void F2945_33623 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

void EIF_Minit3257 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
