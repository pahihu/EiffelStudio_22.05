
#ifndef _C62_su3057_
#define _C62_su3057_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F516_7147(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit3057(void);
extern EIF_REFERENCE F1542_14701(EIF_REFERENCE);
extern void F1542_14695(EIF_REFERENCE);
extern void F1542_14720(EIF_REFERENCE, EIF_REFERENCE);
extern void F1542_14722(EIF_REFERENCE, EIF_NATURAL_64);
extern EIF_BOOLEAN F1477_14564(EIF_REFERENCE, EIF_NATURAL_64);
extern EIF_BOOLEAN F1351_14073(EIF_REFERENCE);
extern EIF_BOOLEAN F1176_13897(EIF_REFERENCE, EIF_NATURAL_64);
extern char *(*R11832[])();
extern char *(*R11833[])();
extern char *(*R11835[])();
extern char *(*R11836[])();
extern long O11667[];
extern EIF_TYPE_INDEX Y6750[];
extern EIF_TYPE_INDEX *Y6750_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
