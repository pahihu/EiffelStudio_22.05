
#ifndef _C62_se3072_
#define _C62_se3072_

#ifdef __cplusplus
extern "C" {
#endif

extern void F950_13321(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_NATURAL_64 F950_13322(EIF_REFERENCE);
extern EIF_BOOLEAN F950_13323(EIF_REFERENCE);
extern void F950_13324(EIF_REFERENCE);
extern void EIF_Minit3072(void);
extern EIF_INTEGER_32 F2993_34056(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
