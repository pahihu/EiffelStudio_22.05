
#ifndef _C62_se3099_
#define _C62_se3099_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1398_14085(EIF_REFERENCE);
extern void F1398_14087(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit3099(void);
extern void F1571_14953(EIF_REFERENCE, EIF_POINTER);
extern EIF_INTEGER_32 F1571_14933(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
