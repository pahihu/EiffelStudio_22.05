
#ifndef _C62_fi3087_
#define _C62_fi3087_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1352_14073(EIF_REFERENCE);
extern void EIF_Minit3087(void);
extern char *(*R11885[])();

#ifdef __cplusplus
}
#endif

#endif
