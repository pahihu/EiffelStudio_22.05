/*
 * Code for class CELL [NATURAL_64]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ce3061.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CELL}.item */
EIF_NATURAL_64 F558_7468 (EIF_REFERENCE Current)
{
	return *(EIF_NATURAL_64 *)(Current + O6989[Dtype(Current)-553]);
}


/* {CELL}.put */
void F558_7469 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	
	
	*(EIF_NATURAL_64 *)(Current + O6989[Dtype(Current)-553]) = (EIF_NATURAL_64) arg1;
}

/* {CELL}.replace */
void F558_7470 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	
	
	*(EIF_NATURAL_64 *)(Current + O6989[Dtype(Current)-553]) = (EIF_NATURAL_64) arg1;
}

void EIF_Minit3061 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
