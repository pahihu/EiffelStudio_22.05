
#ifndef _C62_ce3061_
#define _C62_ce3061_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_64 F558_7468(EIF_REFERENCE);
extern void F558_7469(EIF_REFERENCE, EIF_NATURAL_64);
extern void F558_7470(EIF_REFERENCE, EIF_NATURAL_64);
extern void EIF_Minit3061(void);
extern long O6989[];

#ifdef __cplusplus
}
#endif

#endif
