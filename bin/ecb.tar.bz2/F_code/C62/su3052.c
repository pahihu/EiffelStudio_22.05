/*
 * Code for class SUBSET_STRATEGY_HASHABLE [NATURAL_64]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "su3052.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SUBSET_STRATEGY_HASHABLE}.disjoint */
EIF_BOOLEAN F513_7145 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,loc3);
	RTLR(5,tr1);
	RTLR(6,loc4);
	RTLIU(7);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {1629,0,0,2055,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y6750,Y6750_gen_type,Dftype(Current),507);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		loc1 = RTLNS(typres0.id, 1629, _OBJSIZ_4_3_0_8_0_0_2_0_);
	}
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R11821[Dtype(RTCW(arg1))-1322])(arg1);
	ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R11821[Dtype(RTCW(arg2))-1322])(arg2);
	F1630_15199(RTCW(loc1), (EIF_INTEGER_32) (ti4_1 + ti4_2));
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1) + O11667[Dtype(arg1)-1138]);
	if (tb1) {
		{
			/* INLINED CODE (CONTAINER.compare_objects) */
			(void) RTCW(loc1);
			*(EIF_BOOLEAN *)(loc1+ _CHROFF_4_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			/* END INLINED CODE */
		}
		;
	}
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R11835[Dtype(RTCW(arg1))-1322])(arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R11835[Dtype(RTCW(arg2))-1322])(arg2);
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) !Result) {
			tb2 = '\0';
			tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11833[Dtype(RTCW(arg1))-1322])(arg1);
			if (tb3) {
				tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11833[Dtype(RTCW(arg2))-1322])(arg2);
				tb2 = tb3;
			}
			tb1 = tb2;
		}
		if (tb1) break;
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11833[Dtype(RTCW(arg1))-1322])(arg1);
		if ((EIF_BOOLEAN) !tb2) {
			tu8_1 = (eif_optimize_return = 1, *(EIF_NATURAL_64 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11832[Dtype(RTCW(arg1))-1322])(arg1));
			tr1 = RTLNS(eif_new_type(2064, 0x00).id, 2064, _OBJSIZ_0_0_0_0_0_0_1_0_);
			*(EIF_NATURAL_64 *)tr1 = tu8_1;loc3 = tr1;
			if ((EIF_TRUE)) {
				loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R15076[Dtype(loc3)-2004])(loc3);
			} else {
			}
			Result = F1630_15207(RTCW(loc1), loc2);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
			if (Result) {
				tu8_1 = (eif_optimize_return = 1, *(EIF_NATURAL_64 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11832[Dtype(RTCW(arg1))-1322])(arg1));
				F1630_15245(RTCW(loc1), tu8_1, loc2);
			} else {
				F1630_15241(RTCW(loc1), loc2);
				tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O11667[Dtype(arg1)-1138]);
				if (tb2) {
					tu8_1 = (eif_optimize_return = 1, *(EIF_NATURAL_64 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11832[Dtype(RTCW(arg1))-1322])(arg1));
					tu8_2 = *(EIF_NATURAL_64 *)(RTCW(loc1)+ _I64OFF_4_3_0_8_0_0_0_);
					Result = (EIF_BOOLEAN) (tu8_1 != tu8_2);
				} else {
					tu8_1 = (eif_optimize_return = 1, *(EIF_NATURAL_64 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11832[Dtype(RTCW(arg1))-1322])(arg1));
					tu8_2 = *(EIF_NATURAL_64 *)(RTCW(loc1)+ _I64OFF_4_3_0_8_0_0_0_);
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu8_1 != tu8_2);
				}
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R11836[Dtype(RTCW(arg1))-1322])(arg1);
		}
		tb2 = '\0';
		if (Result) {
			tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11833[Dtype(RTCW(arg2))-1322])(arg2);
			tb2 = (EIF_BOOLEAN) !tb3;
		}
		if (tb2) {
			tu8_1 = (eif_optimize_return = 1, *(EIF_NATURAL_64 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11832[Dtype(RTCW(arg2))-1322])(arg2));
			tr1 = RTLNS(eif_new_type(2064, 0x00).id, 2064, _OBJSIZ_0_0_0_0_0_0_1_0_);
			*(EIF_NATURAL_64 *)tr1 = tu8_1;loc4 = tr1;
			if ((EIF_TRUE)) {
				loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R15076[Dtype(loc4)-2004])(loc4);
			} else {
			}
			F1630_15241(RTCW(loc1), loc2);
			{
				/* INLINED CODE (HASH_TABLE.found) */
				tb2 = (EIF_BOOLEAN)  0;
				(void) RTCW(loc1);
				ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_4_3_0_3_);
				tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L));
				/* END INLINED CODE */
			}
			Result = tb2;
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
			if (Result) {
				tu8_1 = (eif_optimize_return = 1, *(EIF_NATURAL_64 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11832[Dtype(RTCW(arg2))-1322])(arg2));
				F1630_15245(RTCW(loc1), tu8_1, loc2);
			} else {
				tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O11667[Dtype(arg1)-1138]);
				if (tb2) {
					tu8_1 = (eif_optimize_return = 1, *(EIF_NATURAL_64 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11832[Dtype(RTCW(arg2))-1322])(arg2));
					tu8_2 = *(EIF_NATURAL_64 *)(RTCW(loc1)+ _I64OFF_4_3_0_8_0_0_0_);
					Result = (EIF_BOOLEAN) (tu8_1 != tu8_2);
				} else {
					tu8_1 = (eif_optimize_return = 1, *(EIF_NATURAL_64 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11832[Dtype(RTCW(arg2))-1322])(arg2));
					tu8_2 = *(EIF_NATURAL_64 *)(RTCW(loc1)+ _I64OFF_4_3_0_8_0_0_0_);
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu8_1 != tu8_2);
				}
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R11836[Dtype(RTCW(arg2))-1322])(arg2);
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit3052 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
