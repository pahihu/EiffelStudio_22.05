/*
 * Code for class CONTAINER [POINTER]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co3082.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONTAINER}.compare_objects */
void F1144_13744 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O11667[Dtype(Current)-1138]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {CONTAINER}.compare_references */
void F1144_13745 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O11667[Dtype(Current)-1138]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {CONTAINER}.estimated_count_of */
EIF_INTEGER_32 F1144_13747 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	loc1 = arg1;
	{
		static EIF_TYPE_INDEX typarr0[] = {1351,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y11538,Y11538_gen_type,dftype,976);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		
		typres0 = eif_compound_id(dftype, typarr0);
		loc1 = RTRV(typres0,loc1);
	}
	if (EIF_TEST(loc1)) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R11885[Dtype(loc1)-1415])(loc1);
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	} else {
		loc2 = arg1;
		{
			static EIF_TYPE_INDEX typarr0[] = {1446,0,0,0xFFFF};
			EIF_TYPE typres0;
			{
				EIF_TYPE l_type;
				l_type = eif_final_id(Y11538,Y11538_gen_type,dftype,976);
				typarr0[1] = l_type.annotations | 0xFF00;
				typarr0[2] = l_type.id;
			}
			
			typres0 = eif_compound_id(dftype, typarr0);
			loc2 = RTRV(typres0,loc2);
		}
		if (EIF_TEST(loc2)) {
			Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R12121[Dtype(loc2)-1471])(loc2);
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R12120[Dtype(loc2)-1471])(loc2);
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (Result - ti4_1) + ((EIF_INTEGER_32) 1L));
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit3082 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
