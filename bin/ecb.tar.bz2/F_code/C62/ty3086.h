
#ifndef _C62_ty3086_
#define _C62_ty3086_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F1017_13615(EIF_REFERENCE);
extern void EIF_Minit3086(void);
extern char *(*R11607[])();
extern char *(*R12119[])();
extern char *(*R11594[])();

#ifdef __cplusplus
}
#endif

#endif
