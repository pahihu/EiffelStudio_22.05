/*
 * Code for class SEARCH_TABLE [NATURAL_64]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "se3070.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SEARCH_TABLE}.make */
void F2993_34007 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	F2993_34009(Current, arg1, NULL);
}

/* {SEARCH_TABLE}.make_map */
void F2993_34008 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F2993_34009(Current, arg1, NULL);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {SEARCH_TABLE}.make_with_key_tester */
void F2993_34009 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_NATURAL_64 loc1 = (EIF_NATURAL_64) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg2;
	tr1 = RTLNS(eif_new_type(1345, 0x00).id, 1345, _OBJSIZ_0_1_0_1_0_0_0_0_);
	ti4_1 = F1346_14063(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 3L) * arg1) / ((EIF_INTEGER_32) 2L)));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_3_) = (EIF_INTEGER_32) ti4_1;
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_3_) < ((EIF_INTEGER_32) 5L))) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
	}
	tr1 = RTLNSP2(eif_final_id(Y24325,Y24325_gen_type,dftype,2991).id,0,*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_3_),sizeof(EIF_NATURAL_64), EIF_TRUE);
	F1933_18447(RTCW(tr1), loc1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_3_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {1931,2088,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSP2(typres0.id,0,*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_3_),sizeof(EIF_BOOLEAN), EIF_TRUE);
	}
	F1932_18447(RTCW(tr1), (EIF_BOOLEAN) 0, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_3_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_3_1_0_5_0_0_0_) = (EIF_NATURAL_64) loc1;
	RTLE;
}

/* {SEARCH_TABLE}.item */
EIF_NATURAL_64 F2993_34010 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_64 Result = ((EIF_NATURAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F2993_34037(Current, arg1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_2_) == ((EIF_INTEGER_32) 2L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		/* INLINED CODE (SPECIAL.item) */
		tu8_2 = *((EIF_NATURAL_64 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_1_)));
		/* END INLINED CODE */
		Result = tu8_2;
	}
	RTLE;
	return Result;
}

/* {SEARCH_TABLE}.has */
EIF_BOOLEAN F2993_34011 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) > ((EIF_INTEGER_32) 0L))) {
		F2993_34037(Current, arg1);
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_2_) == ((EIF_INTEGER_32) 2L));
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

/* {SEARCH_TABLE}.is_empty */
EIF_BOOLEAN F2993_34013 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) == ((EIF_INTEGER_32) 0L));
}

/* {SEARCH_TABLE}.search */
void F2993_34014 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	EIF_NATURAL_64 loc1 = (EIF_NATURAL_64) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F2993_34037(Current, arg1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_2_) == ((EIF_INTEGER_32) 2L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		/* INLINED CODE (SPECIAL.item) */
		tu8_2 = *((EIF_NATURAL_64 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_1_)));
		/* END INLINED CODE */
		tu8_1 = tu8_2;
		*(EIF_NATURAL_64 *)(Current+ _I64OFF_3_1_0_5_0_0_0_) = (EIF_NATURAL_64) tu8_1;
	} else {
		*(EIF_NATURAL_64 *)(Current+ _I64OFF_3_1_0_5_0_0_0_) = (EIF_NATURAL_64) loc1;
	}
	RTLE;
}

/* {SEARCH_TABLE}.go_to */
void F2993_34015 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_4_) = (EIF_INTEGER_32) arg1;
}

/* {SEARCH_TABLE}.found_item */
EIF_NATURAL_64 F2993_34016 (EIF_REFERENCE Current)
{
	return *(EIF_NATURAL_64 *)(Current+ _I64OFF_3_1_0_5_0_0_0_);
}


/* {SEARCH_TABLE}.found */
EIF_BOOLEAN F2993_34017 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_2_) == ((EIF_INTEGER_32) 2L));
}

/* {SEARCH_TABLE}.new_cursor */
EIF_REFERENCE F2993_34019 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {949,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y11538,Y11538_gen_type,Dftype(Current),976);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		tr1 = RTLNS(typres0.id, 949, _OBJSIZ_1_0_0_1_0_0_0_0_);
	}
	F950_13321(RTCW(tr1), Current);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {SEARCH_TABLE}.is_equal */
EIF_BOOLEAN F2993_34020 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_64 loc3 = (EIF_NATURAL_64) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc4);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(Current == arg1)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tb1 = '\0';
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_1_0_0_);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) == ti4_1)) {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			tb1 = RTEQ(*(EIF_REFERENCE *)(Current), tr1);
		}
		if (tb1) {
			loc4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			loc2 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc4);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			for (;;) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 >= loc2) || (EIF_BOOLEAN) !Result)) break;
				/* INLINED CODE (SPECIAL.item) */
				tu8_2 = *((EIF_NATURAL_64 *)RTCW(loc4) + (loc1));
				/* END INLINED CODE */
				loc3 = tu8_2;
				tb1 = '\0';
				if (EIF_TRUE) {
					{
						/* INLINED CODE (SEARCH_TABLE.valid_key) */
						tu8_1 = (EIF_NATURAL_64)  0;
						tb2 = (EIF_BOOLEAN)  0;
						tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc3 != tu8_1);
						/* END INLINED CODE */
					}
					tb1 = tb2;
				}
				if (tb1) {
					{
						/* INLINED CODE (SEARCH_TABLE.has) */
						tb1 = (EIF_BOOLEAN)  0;
						(void) RTCW(arg1);
						if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(arg1+ _LNGOFF_3_1_0_0_) > ((EIF_INTEGER_32) 0L))) {
							F2993_34037(arg1, loc3);
							ti4_1 = *(EIF_INTEGER_32 *)(arg1+ _LNGOFF_3_1_0_2_);
							tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L));
						}
						/* END INLINED CODE */
					}
					Result = tb1;
				}
				loc1++;
			}
		}
	}
	RTLE;
	return Result;
}

/* {SEARCH_TABLE}.same_keys */
EIF_BOOLEAN F2993_34022 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1, EIF_NATURAL_64 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb1 = (RTNA((loc1, arg1, arg2)), ((EIF_BOOLEAN) 0));
		RTLE;
		return (EIF_BOOLEAN) tb1;
	} else {
		RTLE;
		return (EIF_BOOLEAN) (arg1 == arg2);
	}/* NOTREACHED */
	
}

/* {SEARCH_TABLE}.put */
void F2993_34023 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F2993_34037(Current, arg1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_2_) == ((EIF_INTEGER_32) 2L))) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
	} else {
		{
			/* INLINED CODE (SEARCH_TABLE.soon_full) */
			tb1 = (EIF_BOOLEAN)  0;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
			ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_);
			tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_INTEGER_32) (ti4_1 * ((EIF_INTEGER_32) 80L)) <= (EIF_INTEGER_32) (((EIF_INTEGER_32) 100L) * ti4_2));
			/* END INLINED CODE */
		}
		if (tb1) {
			{
				/* INLINED CODE (SEARCH_TABLE.add_space) */
				F2993_34031(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 3L) * *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_3_)) / ((EIF_INTEGER_32) 2L)));
				/* END INLINED CODE */
			}
			;
			F2993_34037(Current, arg1);
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_NATURAL_64 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_1_))) = arg1;
		/* END INLINED CODE */
		;
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_))++;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	RTLE;
}

/* {SEARCH_TABLE}.force */
void F2993_34024 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F2993_34037(Current, arg1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_2_) != ((EIF_INTEGER_32) 2L))) {
		{
			/* INLINED CODE (SEARCH_TABLE.soon_full) */
			tb1 = (EIF_BOOLEAN)  0;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
			ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_);
			tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_INTEGER_32) (ti4_1 * ((EIF_INTEGER_32) 80L)) <= (EIF_INTEGER_32) (((EIF_INTEGER_32) 100L) * ti4_2));
			/* END INLINED CODE */
		}
		if (tb1) {
			{
				/* INLINED CODE (SEARCH_TABLE.add_space) */
				F2993_34031(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 3L) * *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_3_)) / ((EIF_INTEGER_32) 2L)));
				/* END INLINED CODE */
			}
			;
			F2993_34037(Current, arg1);
		}
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_))++;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_64 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_1_))) = arg1;
	/* END INLINED CODE */
	;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTLE;
}

/* {SEARCH_TABLE}.remove */
void F2993_34026 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	F2993_34037(Current, arg1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_2_) == ((EIF_INTEGER_32) 2L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		{
			/* INLINED CODE (SPECIAL.fill_with_default) */
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_1_);
			ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_1_);
			(void) RTCW(tr1);
			tr2 = RTLNTY2(eif_final_id(Y11538,Y11538_gen_type,Dftype(tr1),976), 0x00);
			tu8_1 = F2023_19028(tr2);
			F1933_18468(tr1, tu8_1, ti4_1, ti4_2);
			/* END INLINED CODE */
		}
		;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_BOOLEAN *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_1_))) = (EIF_BOOLEAN) 1;
		/* END INLINED CODE */
		;
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_))--;
	}
	RTLE;
}

/* {SEARCH_TABLE}.wipe_out */
void F2993_34028 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_64 loc1 = (EIF_NATURAL_64) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	{
		/* INLINED CODE (SPECIAL.upper) */
		ti4_1 = (EIF_INTEGER_32)  0;
		(void) RTCW(tr2);
		ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr2);
		ti4_1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L));
		/* END INLINED CODE */
	}
	ti4_1 = ti4_1;
	F1933_18468(RTCW(tr1), loc1, ((EIF_INTEGER_32) 0L), ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	{
		/* INLINED CODE (SPECIAL.upper) */
		ti4_1 = (EIF_INTEGER_32)  0;
		(void) RTCW(tr2);
		ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr2);
		ti4_1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L));
		/* END INLINED CODE */
	}
	ti4_1 = ti4_1;
	F1932_18468(RTCW(tr1), (EIF_BOOLEAN) 0, ((EIF_INTEGER_32) 0L), ti4_1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_3_1_0_5_0_0_0_) = (EIF_NATURAL_64) loc1;
	RTLE;
}

/* {SEARCH_TABLE}.clear_all */
void F2993_34029 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_64 loc1 = (EIF_NATURAL_64) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	{
		/* INLINED CODE (SPECIAL.upper) */
		ti4_1 = (EIF_INTEGER_32)  0;
		(void) RTCW(tr2);
		ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr2);
		ti4_1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L));
		/* END INLINED CODE */
	}
	ti4_1 = ti4_1;
	F1933_18468(RTCW(tr1), loc1, ((EIF_INTEGER_32) 0L), ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	{
		/* INLINED CODE (SPECIAL.upper) */
		ti4_1 = (EIF_INTEGER_32)  0;
		(void) RTCW(tr2);
		ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr2);
		ti4_1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L));
		/* END INLINED CODE */
	}
	ti4_1 = ti4_1;
	F1932_18468(RTCW(tr1), (EIF_BOOLEAN) 0, ((EIF_INTEGER_32) 0L), ti4_1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_3_1_0_5_0_0_0_) = (EIF_NATURAL_64) loc1;
	RTLE;
}

/* {SEARCH_TABLE}.merge */
void F2993_34030 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_64 loc7 = (EIF_NATURAL_64) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLR(4,loc3);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_1_0_0_);
	if ((EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L))) {
		loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
		loc2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc6 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc1);
		loc5 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc2);
		if ((EIF_BOOLEAN) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc5 + loc6) * ((EIF_INTEGER_32) 80L)) <= (EIF_INTEGER_32) (((EIF_INTEGER_32) 100L) * *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_)))) {
			loc3 = F2993_34034(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 3L) * (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_3_) + loc6)) / ((EIF_INTEGER_32) 2L)));
			for (;;) {
				if ((EIF_BOOLEAN) (loc4 >= loc5)) break;
				/* INLINED CODE (SPECIAL.item) */
				tu8_2 = *((EIF_NATURAL_64 *)RTCW(loc2) + (loc4));
				/* END INLINED CODE */
				loc7 = tu8_2;
				tb1 = '\0';
				if (EIF_TRUE) {
					{
						/* INLINED CODE (SEARCH_TABLE.valid_key) */
						tu8_1 = (EIF_NATURAL_64)  0;
						tb2 = (EIF_BOOLEAN)  0;
						tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc7 != tu8_1);
						/* END INLINED CODE */
					}
					tb1 = tb2;
				}
				if (tb1) {
					F2993_34023(RTCW(loc3), loc7);
				}
				loc4++;
			}
			tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_2_);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_1_);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_3_1_0_3_);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_3_) = (EIF_INTEGER_32) ti4_1;
		}
		loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc4 >= loc6)) break;
			/* INLINED CODE (SPECIAL.item) */
			tu8_2 = *((EIF_NATURAL_64 *)RTCW(loc1) + (loc4));
			/* END INLINED CODE */
			loc7 = tu8_2;
			tb1 = '\0';
			if (EIF_TRUE) {
				{
					/* INLINED CODE (SEARCH_TABLE.valid_key) */
					tu8_1 = (EIF_NATURAL_64)  0;
					tb2 = (EIF_BOOLEAN)  0;
					tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc7 != tu8_1);
					/* END INLINED CODE */
				}
				tb1 = tb2;
			}
			if (tb1) {
				F2993_34023(Current, loc7);
			}
			loc4++;
		}
	}
	RTLE;
}

/* {SEARCH_TABLE}.resize */
void F2993_34031 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_NATURAL_64 loc5 = (EIF_NATURAL_64) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc3);
	RTLR(3,loc4);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
	if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (ti4_1 * ((EIF_INTEGER_32) 80L)) <= (EIF_INTEGER_32) (((EIF_INTEGER_32) 100L) * arg1))) {
		loc3 = F2993_34034(Current, arg1);
		loc4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc2 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc4);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 >= loc2)) break;
			tb1 = '\0';
			/* INLINED CODE (SPECIAL.item) */
			tu8_2 = *((EIF_NATURAL_64 *)RTCW(loc4) + (loc1));
			/* END INLINED CODE */
			tu8_1 = tu8_2;
			loc5 = tu8_1;
			if ((EIF_TRUE)) {
				{
					/* INLINED CODE (SEARCH_TABLE.valid_key) */
					tu8_1 = (EIF_NATURAL_64)  0;
					tb2 = (EIF_BOOLEAN)  0;
					tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc5 != tu8_1);
					/* END INLINED CODE */
				}
				tb1 = tb2;
			}
			if (tb1) {
				F2993_34023(RTCW(loc3), loc5);
			}
			loc1++;
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_2_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_1_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_3_1_0_3_);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_3_) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

/* {SEARCH_TABLE}.copy */
void F2993_34033 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	eif_builtin_ANY_standard_copy__o_ (Current, arg1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {SEARCH_TABLE}.empty_duplicate */
EIF_REFERENCE F2993_34034 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(Dftype(Current));
	F2993_34009(RTCW(tr1), arg1, *(EIF_REFERENCE *)(Current));
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {SEARCH_TABLE}.linear_representation */
EIF_REFERENCE F2993_34035 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_NATURAL_64 loc4 = (EIF_NATURAL_64) 0;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	loc3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	{
		static EIF_TYPE_INDEX typarr0[] = {1569,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y11538,Y11538_gen_type,dftype,976);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		
		typres0 = eif_compound_id(dftype, typarr0);
		Result = RTLNS(typres0.id, 1569, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F1570_14912(RTCW(Result), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_));
	loc2 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc3);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tb1 = '\0';
		/* INLINED CODE (SPECIAL.item) */
		tu8_2 = *((EIF_NATURAL_64 *)RTCW(loc3) + (loc1));
		/* END INLINED CODE */
		tu8_1 = tu8_2;
		loc4 = tu8_1;
		if ((EIF_TRUE)) {
			{
				/* INLINED CODE (SEARCH_TABLE.valid_key) */
				tu8_1 = (EIF_NATURAL_64)  0;
				tb2 = (EIF_BOOLEAN)  0;
				tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc4 != tu8_1);
				/* END INLINED CODE */
			}
			tb1 = tb2;
		}
		if (tb1) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11799[Dtype(RTCW(Result))-1322])(Result, (EIF_REFERENCE) &loc4);
		}
		loc1++;
	}
	RTLE;
	return Result;
}

/* {SEARCH_TABLE}.internal_search */
void F2993_34037 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_64 loc7 = (EIF_NATURAL_64) 0;
	EIF_NATURAL_64 loc8 = (EIF_NATURAL_64) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc10);
	RTLR(1,Current);
	RTLR(2,loc11);
	RTLIU(3);
	
	RTGC;
	loc10 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc11 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_3_);
	loc2 = (EIF_INTEGER_32) (0x7FFFFFFF & (EIF_INTEGER_32) ((rt_int_ptr) (arg1)));
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 1L) + (EIF_INTEGER_32) (loc2 % (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L))));
	loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 % loc3) - loc1);
	for (;;) {
		if ((EIF_BOOLEAN) (loc9 || (EIF_BOOLEAN) (loc6 >= loc3))) break;
		loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc4 + loc1) % loc3);
		loc6++;
		/* INLINED CODE (SPECIAL.item) */
		tu8_2 = *((EIF_NATURAL_64 *)RTCW(loc10) + (loc4));
		/* END INLINED CODE */
		loc7 = tu8_2;
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc7 == loc8) || EIF_FALSE)) {
			/* INLINED CODE (SPECIAL.item) */
			tb2 = *((EIF_BOOLEAN *)RTCW(loc11) + (loc4));
			/* END INLINED CODE */
			tb1 = tb2;
			if ((EIF_BOOLEAN) !tb1) {
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
				loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				if ((EIF_BOOLEAN) (loc5 >= ((EIF_INTEGER_32) 0L))) {
					loc4 = (EIF_INTEGER_32) loc5;
				}
			} else {
				if ((EIF_BOOLEAN) (loc5 < ((EIF_INTEGER_32) 0L))) {
					loc5 = (EIF_INTEGER_32) loc4;
				}
			}
		} else {
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_)) {
				if ((EIF_BOOLEAN)(arg1 == loc7)) {
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
					loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			} else {
				if (F2993_34022(Current, arg1, loc7)) {
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
					loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			}
		}
	}
	if ((EIF_BOOLEAN) !loc9) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
		if ((EIF_BOOLEAN) (loc5 >= ((EIF_INTEGER_32) 0L))) {
			loc4 = (EIF_INTEGER_32) loc5;
		}
	}
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_1_) = (EIF_INTEGER_32) loc4;
	RTLE;
}

/* {SEARCH_TABLE}.add_space */
void F2993_34038 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F2993_34031(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 3L) * *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_3_)) / ((EIF_INTEGER_32) 2L)));
}

/* {SEARCH_TABLE}.soon_full */
EIF_BOOLEAN F2993_34040 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
	ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_INTEGER_32) (ti4_1 * ((EIF_INTEGER_32) 80L)) <= (EIF_INTEGER_32) (((EIF_INTEGER_32) 100L) * ti4_2));
	RTLE;
	return Result;
}

/* {SEARCH_TABLE}.valid_key */
EIF_BOOLEAN F2993_34041 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	EIF_NATURAL_64 loc1 = (EIF_NATURAL_64) 0;
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(arg1 != loc1);
}

/* {SEARCH_TABLE}.start */
void F2993_34054 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	{
		/* INLINED CODE (SEARCH_TABLE.forth) */
		ti4_1 = F2993_34056(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_4_));
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_4_) = (EIF_INTEGER_32) ti4_1;
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {SEARCH_TABLE}.forth */
void F2993_34055 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = F2993_34056(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_4_));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_4_) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

/* {SEARCH_TABLE}.next_iteration_position */
EIF_INTEGER_32 F2993_34056 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	Result = (EIF_INTEGER_32) arg1;
	loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_3_);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L));
	for (;;) {
		if (loc1) break;
		Result++;
		loc1 = '\01';
		if (!(EIF_BOOLEAN) (Result > loc3)) {
			/* INLINED CODE (SPECIAL.item) */
			tu8_2 = *((EIF_NATURAL_64 *)RTCW(loc2) + (Result));
			/* END INLINED CODE */
			tu8_1 = tu8_2;
			{
				/* INLINED CODE (SEARCH_TABLE.valid_key) */
				tu8_2 = (EIF_NATURAL_64)  0;
				tb1 = (EIF_BOOLEAN)  0;
				tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu8_1 != tu8_2);
				/* END INLINED CODE */
			}
			loc1 = tb1;
		}
	}
	RTLE;
	return Result;
}

/* {SEARCH_TABLE}.after */
EIF_BOOLEAN F2993_34057 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_4_) > (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_3_) - ((EIF_INTEGER_32) 1L)));
}

/* {SEARCH_TABLE}.item_for_iteration */
EIF_NATURAL_64 F2993_34059 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_64 loc1 = (EIF_NATURAL_64) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_64 Result = ((EIF_NATURAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	RTCT0("attached content.item (iteration_position) as l_item", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	/* INLINED CODE (SPECIAL.item) */
	tu8_2 = *((EIF_NATURAL_64 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_4_)));
	/* END INLINED CODE */
	tu8_1 = tu8_2;
	loc1 = tu8_1;
	if ((EIF_TRUE)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (EIF_NATURAL_64) loc1;
	RTLE;
	return Result;
}

/* {SEARCH_TABLE}.key_for_iteration */
EIF_NATURAL_64 F2993_34060 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_64 loc1 = (EIF_NATURAL_64) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_64 Result = ((EIF_NATURAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	RTCT0("attached content.item (iteration_position) as l_item", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	/* INLINED CODE (SPECIAL.item) */
	tu8_2 = *((EIF_NATURAL_64 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_4_)));
	/* END INLINED CODE */
	tu8_1 = tu8_2;
	loc1 = tu8_1;
	if ((EIF_TRUE)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (EIF_NATURAL_64) loc1;
	RTLE;
	return Result;
}

/* {SEARCH_TABLE}.cursor */
EIF_INTEGER_32 F2993_34061 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_4_);
}

void EIF_Minit3070 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
