
#ifndef _C62_li3062_
#define _C62_li3062_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_64 F1057_13649(EIF_REFERENCE);
extern EIF_BOOLEAN F1057_13650(EIF_REFERENCE);
extern void F1057_13651(EIF_REFERENCE);
extern void F1057_13652(EIF_REFERENCE);
extern EIF_REFERENCE F1057_13653(EIF_REFERENCE);
extern void EIF_Minit3062(void);
extern void F1031_13640(EIF_REFERENCE);
extern EIF_BOOLEAN F1031_13635(EIF_REFERENCE);
extern char *(*R12119[])();
extern char *(*R12123[])();
extern long O11614[];
extern long O11615[];
extern long O11618[];

#ifdef __cplusplus
}
#endif

#endif
