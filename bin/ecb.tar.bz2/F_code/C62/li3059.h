
#ifndef _C62_li3059_
#define _C62_li3059_

#ifdef __cplusplus
extern "C" {
#endif

extern void F628_8278(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_BOOLEAN);
extern void EIF_Minit3059(void);

#ifdef __cplusplus
}
#endif

#endif
