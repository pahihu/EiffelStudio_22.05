
#ifndef _C62_co3081_
#define _C62_co3081_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1209_13926(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit3081(void);
extern EIF_INTEGER_32 F1571_14933(EIF_REFERENCE);
extern char *(*R11671[])();
extern char *(*R11795[])();
extern char *(*R11799[])();

#ifdef __cplusplus
}
#endif

#endif
