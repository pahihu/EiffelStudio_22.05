/*
 * Code for class LINKED_SET [NATURAL_64]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li3063.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LINKED_SET}.make_from_iterable */
void F1553_14824 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_64 tu8_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	{
		/* INLINED CODE (LINKED_LIST.make) */
		*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		/* END INLINED CODE */
	}
	;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11537[Dtype(RTCW(arg1))-991])(arg1);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11319[Dtype(loc1)-941])(loc1);
		if (tb1) break;
		tu8_1 = (eif_optimize_return = 1, *(EIF_NATURAL_64 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11318[Dtype(loc1)-941])(loc1));
		{
			/* INLINED CODE (LINKED_SET.extend) */
			tb2 = '\01';
			tb3 = F1351_14073(Current);
			if (!tb3) {
				tb3 = F1477_14564(Current, tu8_1);
				tb2 = (EIF_BOOLEAN) !tb3;
			}
			if (tb2) {
				F1542_14722(Current, tu8_1);
			}
			/* END INLINED CODE */
		}
		;
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11320[Dtype(loc1)-941])(loc1);
	}
	RTLE;
}

/* {LINKED_SET}.put */
void F1553_14825 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tb1 = '\01';
	{
		/* INLINED CODE (FINITE.is_empty) */
		tb2 = (EIF_BOOLEAN)  0;
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_3_0_0_);
		tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
		/* END INLINED CODE */
	}
	if (!tb2) {
		{
			/* INLINED CODE (CHAIN.has) */
			tr1 = (EIF_REFERENCE)  0;
			tb2 = (EIF_BOOLEAN)  0;
			tr1 = F1542_14701(Current);
			tb2 = F1176_13897(Current, arg1);
			F1542_14720(Current, tr1);
			/* END INLINED CODE */
		}
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		F1542_14722(Current, arg1);
	}
	RTLE;
}

/* {LINKED_SET}.extend */
void F1553_14826 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tb1 = '\01';
	{
		/* INLINED CODE (FINITE.is_empty) */
		tb2 = (EIF_BOOLEAN)  0;
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_3_0_0_);
		tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
		/* END INLINED CODE */
	}
	if (!tb2) {
		{
			/* INLINED CODE (CHAIN.has) */
			tr1 = (EIF_REFERENCE)  0;
			tb2 = (EIF_BOOLEAN)  0;
			tr1 = F1542_14701(Current);
			tb2 = F1176_13897(Current, arg1);
			F1542_14720(Current, tr1);
			/* END INLINED CODE */
		}
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		F1542_14722(Current, arg1);
	}
	RTLE;
}

/* {LINKED_SET}.prune */
void F1553_14827 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		/* INLINED CODE (LINKED_LIST.start) */
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
			*(EIF_BOOLEAN *)(Current+ _CHROFF_2_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_2_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (LINKED_SET.ll_prune) */
		F1191_13916(Current, arg1);
		tb1 = F1176_13903(Current);
		if ((EIF_BOOLEAN) !tb1) {
			F1542_14728(Current);
		}
		/* END INLINED CODE */
	}
	;
	RTLE;
}

void EIF_Minit3063 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
