
#ifndef _C62_li3051_
#define _C62_li3051_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1325_14016(EIF_REFERENCE, EIF_NATURAL_64, EIF_REFERENCE);
extern void EIF_Minit3051(void);
extern void F1_29(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y11538[];
extern EIF_TYPE_INDEX *Y11538_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
