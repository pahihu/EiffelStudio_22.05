
#ifndef _C62_re3083_
#define _C62_re3083_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1447_14518(EIF_REFERENCE);
extern void EIF_Minit3083(void);
extern void F1032_13621(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R11606[])();
extern EIF_TYPE_INDEX Y11538[];
extern EIF_TYPE_INDEX *Y11538_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
