
#ifndef _C62_co3082_
#define _C62_co3082_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1144_13744(EIF_REFERENCE);
extern void F1144_13745(EIF_REFERENCE);
extern EIF_INTEGER_32 F1144_13747(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit3082(void);
extern char *(*R12121[])();
extern char *(*R12120[])();
extern char *(*R11885[])();
extern long O11667[];
extern EIF_TYPE_INDEX Y11538[];
extern EIF_TYPE_INDEX *Y11538_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
