/*
 * Code for class SUBSET_STRATEGY_GENERIC [NATURAL_64]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "su3057.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SUBSET_STRATEGY_GENERIC}.disjoint */
EIF_BOOLEAN F516_7147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {1552,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y6750,Y6750_gen_type,Dftype(Current),507);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		loc1 = RTLNS(typres0.id, 1552, _OBJSIZ_2_3_0_1_0_0_0_0_);
	}
	F1542_14695(RTCW(loc1));
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1) + O11667[Dtype(arg1)-1138]);
	if (tb1) {
		{
			/* INLINED CODE (CONTAINER.compare_objects) */
			(void) RTCW(loc1);
			*(EIF_BOOLEAN *)(loc1+ _CHROFF_2_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			/* END INLINED CODE */
		}
		;
	}
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R11835[Dtype(RTCW(arg1))-1322])(arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R11835[Dtype(RTCW(arg2))-1322])(arg2);
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) !Result) {
			tb2 = '\0';
			tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11833[Dtype(RTCW(arg1))-1322])(arg1);
			if (tb3) {
				tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11833[Dtype(RTCW(arg2))-1322])(arg2);
				tb2 = tb3;
			}
			tb1 = tb2;
		}
		if (tb1) break;
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11833[Dtype(RTCW(arg1))-1322])(arg1);
		if ((EIF_BOOLEAN) !tb2) {
			tu8_1 = (eif_optimize_return = 1, *(EIF_NATURAL_64 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11832[Dtype(RTCW(arg1))-1322])(arg1));
			{
				/* INLINED CODE (CHAIN.has) */
				tr1 = (EIF_REFERENCE)  0;
				tb2 = (EIF_BOOLEAN)  0;
				(void) RTCW(loc1);
				tr1 = F1542_14701(loc1);
				tb2 = F1176_13897(loc1, tu8_1);
				F1542_14720(loc1, tr1);
				/* END INLINED CODE */
			}
			Result = tb2;
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
			if (Result) {
				tu8_1 = (eif_optimize_return = 1, *(EIF_NATURAL_64 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11832[Dtype(RTCW(arg1))-1322])(arg1));
				{
					/* INLINED CODE (LINKED_SET.put) */
					(void) RTCW(loc1);
					tb2 = '\01';
					tb3 = F1351_14073(loc1);
					if (!tb3) {
						tb3 = F1477_14564(loc1, tu8_1);
						tb2 = (EIF_BOOLEAN) !tb3;
					}
					if (tb2) {
						F1542_14722(loc1, tu8_1);
					}
					/* END INLINED CODE */
				}
				;
			}
		}
		tb2 = '\0';
		if (Result) {
			tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11833[Dtype(RTCW(arg2))-1322])(arg2);
			tb2 = (EIF_BOOLEAN) !tb3;
		}
		if (tb2) {
			tu8_1 = (eif_optimize_return = 1, *(EIF_NATURAL_64 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11832[Dtype(RTCW(arg2))-1322])(arg2));
			{
				/* INLINED CODE (CHAIN.has) */
				tr1 = (EIF_REFERENCE)  0;
				tb2 = (EIF_BOOLEAN)  0;
				(void) RTCW(loc1);
				tr1 = F1542_14701(loc1);
				tb2 = F1176_13897(loc1, tu8_1);
				F1542_14720(loc1, tr1);
				/* END INLINED CODE */
			}
			Result = tb2;
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
			if (Result) {
				tu8_1 = (eif_optimize_return = 1, *(EIF_NATURAL_64 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11832[Dtype(RTCW(arg2))-1322])(arg2));
				{
					/* INLINED CODE (LINKED_SET.put) */
					(void) RTCW(loc1);
					tb2 = '\01';
					tb3 = F1351_14073(loc1);
					if (!tb3) {
						tb3 = F1477_14564(loc1, tu8_1);
						tb2 = (EIF_BOOLEAN) !tb3;
					}
					if (tb2) {
						F1542_14722(loc1, tu8_1);
					}
					/* END INLINED CODE */
				}
				;
			}
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11836[Dtype(RTCW(arg1))-1322])(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11836[Dtype(RTCW(arg2))-1322])(arg2);
	}
	RTLE;
	return Result;
}

void EIF_Minit3057 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
