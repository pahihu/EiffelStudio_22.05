/*
 * Code for class COLLECTION [POINTER]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co3081.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {COLLECTION}.fill */
void F1209_13926 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11671[Dtype(RTCW(arg1))-1155])(arg1);
	{
		/* INLINED CODE (TRAVERSABLE.start) */
		(void) RTCW(loc1);
		*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		/* END INLINED CODE */
	}
	;
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11795[dtype-1322])(Current)) {
			{
				/* INLINED CODE (LINEAR.off) */
				tb2 = (EIF_BOOLEAN)  0;
				(void) RTCW(loc1);
				tb2 = '\01';
				ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_0_);
				if (!(EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
					ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_0_);
					ti4_2 = F1571_14933(loc1);
					tb2 = (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
				}
				/* END INLINED CODE */
			}
			tb2 = tb2;
			tb1 = tb2;
		}
		if (tb1) break;
		{
			/* INLINED CODE (TRAVERSABLE.item) */
			tp1 = (EIF_POINTER)  0;
			(void) RTCW(loc1);
			tr1 = *(EIF_REFERENCE *)(loc1);
			tp1 = 
				/* INLINED CODE (SPECIAL.item) */
				*((EIF_POINTER *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_0_) - ((EIF_INTEGER_32) 1L))))
				/* END INLINED CODE */;
			/* END INLINED CODE */
		}
		tp1 = tp1;
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11799[dtype-1322])(Current, (EIF_REFERENCE) &tp1);
		{
			/* INLINED CODE (LINEAR.forth) */
			(void) RTCW(loc1);
			(*(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_0_))++;
			/* END INLINED CODE */
		}
		;
	}
	RTLE;
}

void EIF_Minit3081 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
