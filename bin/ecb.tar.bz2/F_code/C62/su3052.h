
#ifndef _C62_su3052_
#define _C62_su3052_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F513_7145(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit3052(void);
extern EIF_BOOLEAN F1630_15207(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1630_15241(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1630_15245(EIF_REFERENCE, EIF_NATURAL_64, EIF_INTEGER_32);
extern void F1630_15199(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R11832[])();
extern char *(*R11833[])();
extern char *(*R11835[])();
extern char *(*R11836[])();
extern char *(*R11821[])();
extern char *(*R15076[])();
extern long O11667[];
extern EIF_TYPE_INDEX Y6750[];
extern EIF_TYPE_INDEX *Y6750_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
