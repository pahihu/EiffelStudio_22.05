
#ifndef _C62_li3060_
#define _C62_li3060_

#ifdef __cplusplus
extern "C" {
#endif

extern void F563_7476(EIF_REFERENCE, EIF_REFERENCE);
extern void F563_7477(EIF_REFERENCE);
extern void EIF_Minit3060(void);

#ifdef __cplusplus
}
#endif

#endif
