/*
 * Code for class LINEAR [POINTER]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li3076.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LINEAR}.has */
EIF_BOOLEAN F1177_13897 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	{
		/* INLINED CODE (TRAVERSABLE.start) */
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (LINEAR.off) */
		tb1 = (EIF_BOOLEAN)  0;
		tb1 = '\01';
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
		if (!(EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
			ti4_2 = F1571_14933(Current);
			tb1 = (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
		}
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN) !tb1) {
		F1571_14949(Current, arg1);
	}
	{
		/* INLINED CODE (LINEAR.exhausted) */
		tb1 = (EIF_BOOLEAN)  0;
		tb1 = F1478_14577(Current);
		/* END INLINED CODE */
	}
	Result = tb1;
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTLE;
	return Result;
}

/* {LINEAR}.index_of */
EIF_INTEGER_32 F1177_13898 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O11667[Dtype(Current)-1138]) && EIF_TRUE)) {
		{
			/* INLINED CODE (TRAVERSABLE.start) */
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			/* END INLINED CODE */
		}
		;
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			tb1 = '\01';
			{
				/* INLINED CODE (LINEAR.exhausted) */
				tb2 = (EIF_BOOLEAN)  0;
				tb2 = F1478_14577(Current);
				/* END INLINED CODE */
			}
			if (!tb2) {
				tb1 = (EIF_BOOLEAN)(loc1 == arg2);
			}
			if (tb1) break;
			{
				/* INLINED CODE (TRAVERSABLE.item) */
				tp1 = (EIF_POINTER)  0;
				tr1 = *(EIF_REFERENCE *)(Current);
				tp1 = 
					/* INLINED CODE (SPECIAL.item) */
					*((EIF_POINTER *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) - ((EIF_INTEGER_32) 1L))))
					/* END INLINED CODE */;
				/* END INLINED CODE */
			}
			if ((tp1 == arg1)) {
				loc1++;
			}
			{
				/* INLINED CODE (LINEAR.forth) */
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_))++;
				/* END INLINED CODE */
			}
			;
			loc2++;
		}
	} else {
		{
			/* INLINED CODE (TRAVERSABLE.start) */
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			/* END INLINED CODE */
		}
		;
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			tb2 = '\01';
			{
				/* INLINED CODE (LINEAR.exhausted) */
				tb3 = (EIF_BOOLEAN)  0;
				tb3 = F1478_14577(Current);
				/* END INLINED CODE */
			}
			if (!tb3) {
				tb2 = (EIF_BOOLEAN)(loc1 == arg2);
			}
			if (tb2) break;
			{
				/* INLINED CODE (TRAVERSABLE.item) */
				tp1 = (EIF_POINTER)  0;
				tr1 = *(EIF_REFERENCE *)(Current);
				tp1 = 
					/* INLINED CODE (SPECIAL.item) */
					*((EIF_POINTER *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) - ((EIF_INTEGER_32) 1L))))
					/* END INLINED CODE */;
				/* END INLINED CODE */
			}
			if ((EIF_BOOLEAN)(tp1 == arg1)) {
				loc1++;
			}
			{
				/* INLINED CODE (LINEAR.forth) */
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_))++;
				/* END INLINED CODE */
			}
			;
			loc2++;
		}
	}
	if ((EIF_BOOLEAN)(loc1 == arg2)) {
		RTLE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
	}
	RTLE;
	return (EIF_INTEGER_32) 0;
}

/* {LINEAR}.search */
void F1177_13899 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current + O11667[Dtype(Current)-1138])) {
		for (;;) {
			tb1 = '\01';
			{
				/* INLINED CODE (LINEAR.exhausted) */
				tb2 = (EIF_BOOLEAN)  0;
				tb2 = F1478_14577(Current);
				/* END INLINED CODE */
			}
			if (!tb2) {
				{
					/* INLINED CODE (TRAVERSABLE.item) */
					tp1 = (EIF_POINTER)  0;
					tr1 = *(EIF_REFERENCE *)(Current);
					tp1 = 
						/* INLINED CODE (SPECIAL.item) */
						*((EIF_POINTER *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) - ((EIF_INTEGER_32) 1L))))
						/* END INLINED CODE */;
					/* END INLINED CODE */
				}
				tb1 = (arg1 == tp1);
			}
			if (tb1) break;
			{
				/* INLINED CODE (LINEAR.forth) */
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_))++;
				/* END INLINED CODE */
			}
			;
		}
	} else {
		for (;;) {
			tb2 = '\01';
			{
				/* INLINED CODE (LINEAR.exhausted) */
				tb3 = (EIF_BOOLEAN)  0;
				tb3 = F1478_14577(Current);
				/* END INLINED CODE */
			}
			if (!tb3) {
				{
					/* INLINED CODE (TRAVERSABLE.item) */
					tp1 = (EIF_POINTER)  0;
					tr1 = *(EIF_REFERENCE *)(Current);
					tp1 = 
						/* INLINED CODE (SPECIAL.item) */
						*((EIF_POINTER *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) - ((EIF_INTEGER_32) 1L))))
						/* END INLINED CODE */;
					/* END INLINED CODE */
				}
				tb2 = (EIF_BOOLEAN)(arg1 == tp1);
			}
			if (tb2) break;
			{
				/* INLINED CODE (LINEAR.forth) */
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_))++;
				/* END INLINED CODE */
			}
			;
		}
	}
	RTLE;
}

/* {LINEAR}.item_for_iteration */
EIF_POINTER F1177_13902 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		/* INLINED CODE (TRAVERSABLE.item) */
		tp1 = (EIF_POINTER)  0;
		tr1 = *(EIF_REFERENCE *)(Current);
		tp1 = 
			/* INLINED CODE (SPECIAL.item) */
			*((EIF_POINTER *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) - ((EIF_INTEGER_32) 1L))))
			/* END INLINED CODE */;
		/* END INLINED CODE */
	}
	RTLE;
	return (EIF_POINTER) tp1;
}

/* {LINEAR}.exhausted */
EIF_BOOLEAN F1177_13903 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	{
		/* INLINED CODE (LINEAR.off) */
		tb1 = (EIF_BOOLEAN)  0;
		tb1 = '\01';
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
		if (!(EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
			ti4_2 = F1571_14933(Current);
			tb1 = (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
		}
		/* END INLINED CODE */
	}
	RTLE;
	return (EIF_BOOLEAN) tb1;
}

/* {LINEAR}.off */
EIF_BOOLEAN F1177_13905 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	{
		/* INLINED CODE (CONTAINER.is_empty) */
		tb1 = (EIF_BOOLEAN)  0;
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R11885[Dtype(Current)-1415])(Current);
		tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
		/* END INLINED CODE */
	}
	if (!tb1) {
		{
			/* INLINED CODE (LINEAR.after) */
			tb1 = (EIF_BOOLEAN)  0;
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
			ti4_2 = F1571_14933(Current);
			tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
			/* END INLINED CODE */
		}
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {LINEAR}.do_all */
void F1177_13908 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc1);
	RTLR(4,tr1);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTGC;
	loc3 = Current;
	{
		static EIF_TYPE_INDEX typarr0[] = {1301,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y11538,Y11538_gen_type,dftype,976);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		
		typres0 = eif_compound_id(dftype, typarr0);
		loc3 = RTRV(typres0,loc3);
	}
	if (EIF_TEST(loc3)) {
		loc2 = (EIF_REFERENCE) loc3;
		{
			/* INLINED CODE (CURSOR_STRUCTURE.cursor) */
			tr1 = (EIF_REFERENCE)  0;
			(void) loc3;
			tr1 = RTLNS(eif_new_type(624, 0x00).id, 624, _OBJSIZ_0_0_0_1_0_0_0_0_);
			F625_8276(RTCW(tr1), *(EIF_INTEGER_32 *)(loc3+ _LNGOFF_1_1_0_0_));
			/* END INLINED CODE */
		}
		loc1 = tr1;
	}
	{
		/* INLINED CODE (TRAVERSABLE.start) */
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		/* END INLINED CODE */
	}
	;
	for (;;) {
		{
			/* INLINED CODE (LINEAR.after) */
			tb1 = (EIF_BOOLEAN)  0;
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
			ti4_2 = F1571_14933(Current);
			tb1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
			/* END INLINED CODE */
		}
		if (tb1) break;
		tp1 = F1571_14917(Current);
		(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_POINTER)) *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_0_))(
			*(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_1_),
			*(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_), tp1);
		{
			/* INLINED CODE (LINEAR.forth) */
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_))++;
			/* END INLINED CODE */
		}
		;
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 != NULL) && (EIF_BOOLEAN)(loc1 != NULL))) {
		F1571_14948(RTCW(loc2), loc1);
	}
	RTLE;
}

/* {LINEAR}.for_all */
EIF_BOOLEAN F1177_13911 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc1);
	RTLR(4,tr1);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTGC;
	loc3 = Current;
	{
		static EIF_TYPE_INDEX typarr0[] = {1301,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y11538,Y11538_gen_type,dftype,976);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		
		typres0 = eif_compound_id(dftype, typarr0);
		loc3 = RTRV(typres0,loc3);
	}
	if (EIF_TEST(loc3)) {
		loc2 = (EIF_REFERENCE) loc3;
		{
			/* INLINED CODE (CURSOR_STRUCTURE.cursor) */
			tr1 = (EIF_REFERENCE)  0;
			(void) loc3;
			tr1 = RTLNS(eif_new_type(624, 0x00).id, 624, _OBJSIZ_0_0_0_1_0_0_0_0_);
			F625_8276(RTCW(tr1), *(EIF_INTEGER_32 *)(loc3+ _LNGOFF_1_1_0_0_));
			/* END INLINED CODE */
		}
		loc1 = tr1;
	}
	{
		/* INLINED CODE (TRAVERSABLE.start) */
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		/* END INLINED CODE */
	}
	;
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	for (;;) {
		tb1 = '\01';
		{
			/* INLINED CODE (LINEAR.after) */
			tb2 = (EIF_BOOLEAN)  0;
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
			ti4_2 = F1571_14933(Current);
			tb2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
			/* END INLINED CODE */
		}
		if (!tb2) {
			tb1 = (EIF_BOOLEAN) !Result;
		}
		if (tb1) break;
		tp1 = F1571_14917(Current);
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_POINTER, EIF_REFERENCE, EIF_POINTER)) *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_3_0_3_0_0_))(
			*(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_3_0_3_0_1_),
			*(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_), tp1);
		Result = tb2;
		{
			/* INLINED CODE (LINEAR.forth) */
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_))++;
			/* END INLINED CODE */
		}
		;
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 != NULL) && (EIF_BOOLEAN)(loc1 != NULL))) {
		F1571_14948(RTCW(loc2), loc1);
	}
	RTLE;
	return Result;
}

/* {LINEAR}.linear_representation */
EIF_REFERENCE F1177_13912 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) Current;
}

void EIF_Minit3076 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
