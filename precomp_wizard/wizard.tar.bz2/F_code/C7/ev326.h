
#ifndef _C7_ev326_
#define _C7_ev326_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F374_5869(EIF_REFERENCE);
static EIF_REFERENCE F374_5872_body(EIF_REFERENCE);
extern EIF_REFERENCE F374_5872(EIF_REFERENCE);
extern void EIF_Minit326(void);
extern EIF_REFERENCE F1259_11732(EIF_REFERENCE);
extern void F1248_11522(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
