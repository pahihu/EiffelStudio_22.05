
#ifndef _C7_ei343_
#define _C7_ei343_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F391_5985(EIF_REFERENCE);
extern void F391_5987(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit343(void);

#ifdef __cplusplus
}
#endif

#endif
