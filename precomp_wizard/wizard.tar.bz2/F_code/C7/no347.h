
#ifndef _C7_no347_
#define _C7_no347_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F395_5991(EIF_REFERENCE);
extern void F395_5993(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit347(void);

#ifdef __cplusplus
}
#endif

#endif
