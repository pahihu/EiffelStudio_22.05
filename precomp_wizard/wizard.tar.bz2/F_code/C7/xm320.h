
#ifndef _C7_xm320_
#define _C7_xm320_

#ifdef __cplusplus
extern "C" {
#endif

extern void F368_5684(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F368_5686(EIF_REFERENCE);
extern EIF_BOOLEAN F368_5687(EIF_REFERENCE);
extern EIF_INTEGER_32 F368_5689(EIF_REFERENCE);
extern EIF_INTEGER_32 F368_5690(EIF_REFERENCE);
extern EIF_INTEGER_32 F368_5691(EIF_REFERENCE);
extern void EIF_Minit320(void);
extern char *(*R5408[])();
extern char *(*R5409[])();
extern char *(*R5411[])();
extern char *(*R5412[])();
extern char *(*R5413[])();

#ifdef __cplusplus
}
#endif

#endif
