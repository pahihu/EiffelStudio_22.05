
#ifndef _C7_op336_
#define _C7_op336_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F384_5954(EIF_REFERENCE);
extern void F384_5957(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit336(void);

#ifdef __cplusplus
}
#endif

#endif
