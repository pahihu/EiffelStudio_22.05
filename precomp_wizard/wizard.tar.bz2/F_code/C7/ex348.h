
#ifndef _C7_ex348_
#define _C7_ex348_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F396_5995(EIF_REFERENCE);
extern void EIF_Minit348(void);

#ifdef __cplusplus
}
#endif

#endif
