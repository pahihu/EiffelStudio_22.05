/*
 * Code for class XML_NAMESPACE_RESOLVER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm316.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XML_NAMESPACE_RESOLVER}.set_next */
void F364_5607 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("set_next", 363, Current, 0, 1, 5711);
	RTGC;
	RTHOOK(1);
	F359_5473(Current, arg1);
	RTHOOK(2);
	F364_5608(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER}.initialize */
void F364_5608 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("initialize", 363, Current, 0, 0, 5712);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_new_type(38, 0).id);
	F39_595(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	F364_5627(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER}.reset */
void F364_5609 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("reset", 363, Current, 0, 0, 5678);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F39_596(RTCW(tr1));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F781_8419(RTCW(tr1));
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F781_8419(RTCW(tr1));
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F781_8419(RTCW(tr1));
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER}.on_finish */
void F364_5610 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("on_finish", 363, Current, 0, 0, 5679);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5241[Dtype(RTCW(tr1))-355])(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER}.on_start */
void F364_5611 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("on_start", 363, Current, 0, 0, 5680);
	RTGC;
	RTHOOK(1);
	F364_5609(Current);
	RTHOOK(2);
	F359_5474(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER}.on_start_tag */
void F364_5614 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTEAA("on_start_tag", 363, Current, 0, 3, 5683);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F39_604(RTCW(tr1));
	
	RTHOOK(3);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg2;
	RTHOOK(4);
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg3;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER}.on_attribute */
void F364_5615 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,arg3);
	RTLR(3,tr1);
	RTLR(4,arg4);
	RTLIU(5);
	
	RTEAA("on_attribute", 363, Current, 0, 4, 5684);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if ((EIF_BOOLEAN) !F355_5451(Current, arg2)) {
		tb1 = F364_5622(Current, arg3);
	}
	if (tb1) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F39_597(RTCW(tr1), arg4);
		RTHOOK(3);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_8_0_)) {
			RTHOOK(4);
			F364_5628(Current, arg2, arg3, arg4);
		}
	} else {
		RTHOOK(5);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(arg2 != NULL)) {
			tb1 = F364_5622(Current, arg2);
		}
		if (tb1) {
			RTHOOK(6);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tb1 = F39_600(RTCW(tr1), arg2);
			if (tb1) {
				RTHOOK(7);
				tr1 = RTOUCR(503,F364_5640, (Current));
				F359_5477(Current, tr1);
			} else {
				RTHOOK(8);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				F39_598(RTCW(tr1), arg4, arg3);
			}
			RTHOOK(9);
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_8_0_)) {
				RTHOOK(10);
				F364_5628(Current, arg2, arg3, arg4);
			}
		} else {
			RTHOOK(11);
			F364_5628(Current, arg2, arg3, arg4);
		}
	}
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER}.on_start_tag_finish */
void F364_5616 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTEAA("on_start_tag_finish", 363, Current, 3, 0, 5685);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTHOOK(2);
		loc2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		RTHOOK(3);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			tb1 = F355_5451(Current, loc2);
		}
		if (tb1) {
			RTHOOK(4);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tb1 = F39_601(RTCW(tr1), loc2);
			if (tb1) {
				RTHOOK(5);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				tr1 = F39_603(RTCW(tr1), loc2);
				F364_5619(Current, tr1, loc2, loc3);
				RTHOOK(6);
				F364_5618(Current);
			} else {
				RTHOOK(7);
				loc1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
				F1237_11059(RTCW(loc1));
				RTHOOK(8);
				tr1 = RTOUCR(504,F364_5639, (Current));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9711[Dtype(RTCW(loc1))-1241])(loc1, tr1);
				RTHOOK(9);
				tr1 = RTMS_EX_H(" in tag <",9,992440636);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9711[Dtype(RTCW(loc1))-1241])(loc1, tr1);
				RTHOOK(10);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9711[Dtype(RTCW(loc1))-1241])(loc1, loc2);
				RTHOOK(11);
				tr1 = RTMS_EX_H(":",1,58);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9711[Dtype(RTCW(loc1))-1241])(loc1, tr1);
				RTHOOK(12);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9711[Dtype(RTCW(loc1))-1241])(loc1, loc3);
				RTHOOK(13);
				tr1 = RTMS_EX_H(">",1,62);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9711[Dtype(RTCW(loc1))-1241])(loc1, tr1);
				RTHOOK(14);
				tr1 = F1237_11118(RTCW(loc1));
				F359_5477(Current, tr1);
			}
		} else {
			RTHOOK(15);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tr1 = F39_602(RTCW(tr1));
			F364_5619(Current, tr1, loc2, loc3);
			RTHOOK(16);
			F364_5618(Current);
		}
	} else {
		
	}
	RTHOOK(18);
	F359_5482(Current);
	RTHOOK(19);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER}.on_end_tag */
void F364_5617 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTEAA("on_end_tag", 363, Current, 0, 3, 5686);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		tb1 = F355_5451(Current, arg2);
	}
	if (tb1) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr1 = F39_603(RTCW(tr1), arg2);
		F359_5483(Current, tr1, arg2, arg3);
	} else {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr1 = F39_602(RTCW(tr1));
		F359_5483(Current, tr1, arg2, arg3);
	}
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F39_605(RTCW(tr1));
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER}.on_delayed_attributes */
void F364_5618 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTEAA("on_delayed_attributes", 363, Current, 1, 0, 5687);
	RTGC;
	for (;;) {
		RTHOOK(1);
		if (F364_5630(Current)) break;
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc1 = F781_8399(RTCW(tr1));
		RTHOOK(3);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tb1 = F355_5451(Current, loc1);
		}
		if (tb1) {
			RTHOOK(4);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tb1 = F39_601(RTCW(tr1), loc1);
			if (tb1) {
				RTHOOK(5);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				tr1 = F39_603(RTCW(tr1), loc1);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
				tr2 = F781_8399(RTCW(tr2));
				tr3 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				tr3 = F781_8399(RTCW(tr3));
				F364_5620(Current, tr1, loc1, tr2, tr3);
			} else {
				RTHOOK(6);
				if (F364_5623(Current, loc1)) {
					RTHOOK(7);
					tr1 = RTOUCR(505,F364_5637, (Current));
					tr2 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
					tr2 = F781_8399(RTCW(tr2));
					tr3 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
					tr3 = F781_8399(RTCW(tr3));
					F364_5620(Current, tr1, loc1, tr2, tr3);
				} else {
					RTHOOK(8);
					if (F364_5622(Current, loc1)) {
						RTHOOK(9);
						tr1 = RTOUCR(506,F364_5638, (Current));
						tr2 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
						tr2 = F781_8399(RTCW(tr2));
						tr3 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
						tr3 = F781_8399(RTCW(tr3));
						F364_5620(Current, tr1, loc1, tr2, tr3);
					} else {
						RTHOOK(10);
						tr1 = RTOUCR(504,F364_5639, (Current));
						F359_5477(Current, tr1);
					}
				}
			}
		} else {
			RTHOOK(11);
			tr1 = F364_5624(Current);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			tr2 = F781_8399(RTCW(tr2));
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			tr3 = F781_8399(RTCW(tr3));
			F364_5620(Current, tr1, loc1, tr2, tr3);
		}
		RTHOOK(12);
		F364_5629(Current);
	}
	RTHOOK(13);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER}.on_start_tag_resolved */
void F364_5619 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTEAA("on_start_tag_resolved", 363, Current, 0, 3, 5688);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5246[Dtype(RTCW(tr1))-355])(tr1, arg1, arg2, arg3);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER}.on_attribute_resolved */
void F364_5620 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLR(5,arg4);
	RTLIU(6);
	
	RTEAA("on_attribute_resolved", 363, Current, 0, 4, 5689);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5247[Dtype(RTCW(tr1))-355])(tr1, arg1, arg2, arg3, arg4);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER}.is_xmlns */
EIF_BOOLEAN F364_5622 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("is_xmlns", 363, Current, 0, 1, 5691);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = RTOUCR(507,F364_5636, (Current));
		Result = F364_5641(Current, tr1, arg1);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_NAMESPACE_RESOLVER}.is_xml */
EIF_BOOLEAN F364_5623 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("is_xml", 363, Current, 0, 1, 5692);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = RTOUCR(508,F364_5635, (Current));
		Result = F364_5641(Current, tr1, arg1);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_NAMESPACE_RESOLVER}.unprefixed_attribute_namespace */
EIF_REFERENCE F364_5624 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("unprefixed_attribute_namespace", 363, Current, 0, 0, 5693);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) RTOUCR(509,F364_5634, (Current));
}

/* {XML_NAMESPACE_RESOLVER}.attributes_make */
void F364_5627 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("attributes_make", 363, Current, 0, 0, 5696);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {780,1239,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F781_8398(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	{
		static EIF_TYPE_INDEX typarr0[] = {780,1239,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F781_8398(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	{
		static EIF_TYPE_INDEX typarr0[] = {780,1239,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F781_8398(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER}.attributes_force */
void F364_5628 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTEAA("attributes_force", 363, Current, 0, 3, 5697);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F781_8413(RTCW(tr1), arg1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F781_8413(RTCW(tr1), arg2);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F781_8413(RTCW(tr1), arg3);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER}.attributes_remove */
void F364_5629 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("attributes_remove", 363, Current, 0, 0, 5698);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F781_8416(RTCW(tr1));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F781_8416(RTCW(tr1));
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F781_8416(RTCW(tr1));
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER}.attributes_is_empty */
EIF_BOOLEAN F364_5630 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("attributes_is_empty", 363, Current, 0, 0, 5699);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	Result = F781_8407(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_NAMESPACE_RESOLVER}.default_namespace */

EIF_REFERENCE F364_5634 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (509,RTMS32_EX_H("",0,0));
}

/* {XML_NAMESPACE_RESOLVER}.xml_prefix */

EIF_REFERENCE F364_5635 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (508,RTMS32_EX_H("x\000\000\000m\000\000\000l\000\000\000",3,7892332));
}

/* {XML_NAMESPACE_RESOLVER}.xmlns */

EIF_REFERENCE F364_5636 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (507,RTMS32_EX_H("x\000\000\000m\000\000\000l\000\000\000n\000\000\000s\000\000\000",5,1836744307));
}

/* {XML_NAMESPACE_RESOLVER}.xml_prefix_namespace */

EIF_REFERENCE F364_5637 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (505,RTMS32_EX_H("h\000\000\000t\000\000\000t\000\000\000p\000\000\000:\000\000\000/\000\000\000/\000\000\000w\000\000\000w\000\000\000w\000\000\000.\000\000\000w\000\000\0003\000\000\000.\000\000\000o\000\000\000r\000\000\000g\000\000\000/\000\000\000X\000\000\000M\000\000\000L\000\000\000/\000\000\0001\000\000\0009\000\000\0009\000\000\0008\000\000\000/\000\000\000n\000\000\000a\000\000\000m\000\000\000e\000\000\000s\000\000\000p\000\000\000a\000\000\000c\000\000\000e\000\000\000",36,212418405));
}

/* {XML_NAMESPACE_RESOLVER}.xmlns_namespace */

EIF_REFERENCE F364_5638 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (506,RTMS32_EX_H("h\000\000\000t\000\000\000t\000\000\000p\000\000\000:\000\000\000/\000\000\000/\000\000\000w\000\000\000w\000\000\000w\000\000\000.\000\000\000w\000\000\0003\000\000\000.\000\000\000o\000\000\000r\000\000\000g\000\000\000/\000\000\0002\000\000\0000\000\000\0000\000\000\0000\000\000\000/\000\000\000x\000\000\000m\000\000\000l\000\000\000n\000\000\000s\000\000\000/\000\000\000",29,1059754287));
}

/* {XML_NAMESPACE_RESOLVER}.undeclared_namespace_error */

EIF_REFERENCE F364_5639 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (504,RTMS32_EX_H("U\000\000\000n\000\000\000d\000\000\000e\000\000\000c\000\000\000l\000\000\000a\000\000\000r\000\000\000e\000\000\000d\000\000\000 \000\000\000n\000\000\000a\000\000\000m\000\000\000e\000\000\000s\000\000\000p\000\000\000a\000\000\000c\000\000\000e\000\000\000 \000\000\000e\000\000\000r\000\000\000r\000\000\000o\000\000\000r\000\000\000",26,1792447602));
}

/* {XML_NAMESPACE_RESOLVER}.duplicate_namespace_declaration_error */

EIF_REFERENCE F364_5640 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (503,RTMS32_EX_H("N\000\000\000a\000\000\000m\000\000\000e\000\000\000s\000\000\000p\000\000\000a\000\000\000c\000\000\000e\000\000\000 \000\000\000d\000\000\000e\000\000\000c\000\000\000l\000\000\000a\000\000\000r\000\000\000e\000\000\000d\000\000\000 \000\000\000t\000\000\000w\000\000\000i\000\000\000c\000\000\000e\000\000\000",24,1284969317));
}

/* {XML_NAMESPACE_RESOLVER}.same_string */
EIF_BOOLEAN F364_5641 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("same_string", 363, Current, 0, 2, 5710);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == arg2)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		RTHOOK(4);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN)(arg2 != NULL))) {
			RTHOOK(5);
			tb1 = F1240_11216(RTCW(arg1), arg2);
			RTHOOK(6);
			RTLE;
			RTEE;
			return (EIF_BOOLEAN) tb1;
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) 0;
}

void EIF_Minit316 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
