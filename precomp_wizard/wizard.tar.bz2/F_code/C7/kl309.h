
#ifndef _C7_kl309_
#define _C7_kl309_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F357_5469_body(EIF_REFERENCE);
extern EIF_REFERENCE F357_5469(EIF_REFERENCE);
extern void EIF_Minit309(void);

#ifdef __cplusplus
}
#endif

#endif
