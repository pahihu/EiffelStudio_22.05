/*
 * Code for class XML_END_TAG_CHECKER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm317.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XML_END_TAG_CHECKER}.set_next */
void F365_5642 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("set_next", 364, Current, 0, 1, 5713);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {904,1239,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F892_8780(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	{
		static EIF_TYPE_INDEX typarr0[] = {904,1239,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F892_8780(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	F359_5473(Current, arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {XML_END_TAG_CHECKER}.on_start */
void F365_5643 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("on_start", 364, Current, 0, 0, 5714);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F892_8839(RTCW(tr1));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F892_8839(RTCW(tr1));
	RTHOOK(3);
	F359_5474(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {XML_END_TAG_CHECKER}.on_finish */
void F365_5644 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("on_finish", 364, Current, 0, 0, 5715);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	ti4_1 = F892_8801(RTCW(tr1));
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr1 = F892_8785(RTCW(tr1));
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = F892_8785(RTCW(tr2));
		F365_5653(Current, tr1, tr2);
	}
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F892_8839(RTCW(tr1));
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F892_8839(RTCW(tr1));
	RTHOOK(5);
	F359_5475(Current);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {XML_END_TAG_CHECKER}.on_start_tag */
void F365_5645 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTEAA("on_start_tag", 364, Current, 0, 3, 5716);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F905_8851(RTCW(tr1), arg2);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F905_8851(RTCW(tr1), arg3);
	RTHOOK(3);
	F359_5480(Current, arg1, arg2, arg3);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {XML_END_TAG_CHECKER}.on_end_tag */
void F365_5646 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLR(5,loc3);
	RTLR(6,arg3);
	RTLR(7,tr2);
	RTLR(8,arg1);
	RTLIU(9);
	
	RTEAA("on_end_tag", 364, Current, 3, 3, 5717);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	RTHOOK(2);
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	
	RTHOOK(4);
	ti4_1 = F892_8801(RTCW(loc1));
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(5);
		tb1 = '\01';
		tb2 = '\01';
		tr1 = F892_8785(RTCW(loc1));
		if (!(EIF_BOOLEAN)(tr1 == arg2)) {
			tb3 = '\0';
			tb4 = '\0';
			if ((EIF_BOOLEAN)(arg2 != NULL)) {
				tr1 = F892_8785(RTCW(loc1));
				loc3 = tr1;
				tb4 = EIF_TEST(loc3);
			}
			if (tb4) {
				tb4 = F1240_11216(RTCW(arg2), loc3);
				tb3 = tb4;
			}
			tb2 = tb3;
		}
		if (!((EIF_BOOLEAN) !tb2)) {
			tr1 = F892_8785(RTCW(loc2));
			tb2 = F1240_11216(RTCW(arg3), tr1);
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			RTHOOK(6);
			tr1 = F892_8785(RTCW(loc1));
			tr2 = F892_8785(RTCW(loc2));
			F365_5653(Current, tr1, tr2);
		}
		RTHOOK(7);
		F905_8852(RTCW(loc1));
		RTHOOK(8);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F905_8852(RTCW(tr1));
	} else {
		RTHOOK(9);
		F365_5654(Current, arg2, arg3);
	}
	RTHOOK(10);
	F359_5483(Current, arg1, arg2, arg3);
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {XML_END_TAG_CHECKER}.on_content */
void F365_5647 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("on_content", 364, Current, 0, 1, 5718);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb2 = F724_8337(RTCW(tr1));
	if (tb2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tb2 = F724_8337(RTCW(tr1));
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(2);
		if ((EIF_BOOLEAN) !F365_5648(Current, arg1)) {
			RTHOOK(3);
			F365_5655(Current, arg1);
		}
	}
	RTHOOK(4);
	F359_5484(Current, arg1);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {XML_END_TAG_CHECKER}.is_blank_string */
EIF_BOOLEAN F365_5648 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_blank_string", 364, Current, 2, 1, 5719);
	RTGC;
	RTHOOK(1);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(3);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9759[Dtype(arg1)-1239]);
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > loc2) || (EIF_BOOLEAN) !Result)) break;
		RTHOOK(5);
		tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R9603[Dtype(RTCW(arg1))-1240])(arg1, loc1);
		switch (tu4_1) {
			case 9U:
			case 10U:
			case 13U:
			case 32U:
				break;
			default:
				RTHOOK(6);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				break;
		}
		RTHOOK(7);
		loc1++;
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_END_TAG_CHECKER}.report_custom_error */
void F365_5651 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg2);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLR(6,Current);
	RTLIU(7);
	
	RTEAA("report_custom_error", 364, Current, 3, 2, 5722);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		RTHOOK(2);
		loc1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1237_11059(RTCW(loc1));
		RTHOOK(3);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9759[Dtype(arg1)-1239]);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg2) + O9759[Dtype(arg2)-1239]);
		F1242_11336(RTCW(loc1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + ti4_2) + ((EIF_INTEGER_32) 4L)));
		RTHOOK(4);
		F1242_11304(RTCW(loc1), arg1);
		RTHOOK(5);
		tr1 = RTMS32_EX_H(":\000\000\000 \000\000\000\"\000\000\000",3,3809314);
		F1242_11304(RTCW(loc1), tr1);
		RTHOOK(6);
		F1242_11304(RTCW(loc1), arg2);
		RTHOOK(7);
		tr1 = RTMS32_EX_H("\"\000\000\000",1,34);
		F1242_11304(RTCW(loc1), tr1);
		RTHOOK(8);
		loc2 = (EIF_REFERENCE) arg1;
	} else {
		RTHOOK(9);
		loc2 = (EIF_REFERENCE) arg1;
	}
	RTHOOK(10);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTHOOK(11);
		F361_5552(loc3, loc2);
	} else {
		RTHOOK(12);
		F359_5477(Current, loc2);
	}
	RTHOOK(13);
	RTLE;
	RTEE;
}

/* {XML_END_TAG_CHECKER}.report_error */
void F365_5652 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg3);
	RTLR(2,arg2);
	RTLR(3,arg1);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("report_error", 364, Current, 1, 3, 5723);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg3) + O9759[Dtype(arg3)-1239]);
	F1240_11189(RTCW(loc1), ti4_1);
	RTHOOK(2);
	F1242_11304(RTCW(loc1), arg3);
	RTHOOK(3);
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		RTHOOK(4);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
		F1242_11295(RTCW(loc1), tw1);
		RTHOOK(5);
		F1242_11296(RTCW(loc1), arg2);
	}
	RTHOOK(6);
	F365_5651(Current, arg1, loc1);
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {XML_END_TAG_CHECKER}.report_end_tag_mismatch_error */
void F365_5653 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTEAA("report_end_tag_mismatch_error", 364, Current, 0, 2, 5724);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(500,F365_5656, (Current));
	F365_5652(Current, tr1, arg1, arg2);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_END_TAG_CHECKER}.report_extra_end_tag_error */
void F365_5654 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTEAA("report_extra_end_tag_error", 364, Current, 0, 2, 5725);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(501,F365_5657, (Current));
	F365_5652(Current, tr1, arg1, arg2);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_END_TAG_CHECKER}.report_character_data_not_allowed_outside_element */
void F365_5655 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("report_character_data_not_allowed_outside_element", 364, Current, 0, 1, 5726);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(502,F365_5658, (Current));
	F365_5651(Current, tr1, arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_END_TAG_CHECKER}.end_tag_mismatch_error */

EIF_REFERENCE F365_5656 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (500,RTMS32_EX_H("E\000\000\000n\000\000\000d\000\000\000 \000\000\000t\000\000\000a\000\000\000g\000\000\000 \000\000\000d\000\000\000o\000\000\000e\000\000\000s\000\000\000 \000\000\000n\000\000\000o\000\000\000t\000\000\000 \000\000\000m\000\000\000a\000\000\000t\000\000\000c\000\000\000h\000\000\000 \000\000\000s\000\000\000t\000\000\000a\000\000\000r\000\000\000t\000\000\000 \000\000\000t\000\000\000a\000\000\000g\000\000\000",32,1993968231));
}

/* {XML_END_TAG_CHECKER}.extra_end_tag_error */

EIF_REFERENCE F365_5657 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (501,RTMS32_EX_H("E\000\000\000n\000\000\000d\000\000\000 \000\000\000t\000\000\000a\000\000\000g\000\000\000 \000\000\000w\000\000\000i\000\000\000t\000\000\000h\000\000\000o\000\000\000u\000\000\000t\000\000\000 \000\000\000s\000\000\000t\000\000\000a\000\000\000r\000\000\000t\000\000\000 \000\000\000t\000\000\000a\000\000\000g\000\000\000",25,268382823));
}

/* {XML_END_TAG_CHECKER}.character_data_not_allowed_outside_element_error */

EIF_REFERENCE F365_5658 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (502,RTMS32_EX_H("C\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000d\000\000\000a\000\000\000t\000\000\000a\000\000\000 \000\000\000i\000\000\000s\000\000\000 \000\000\000n\000\000\000o\000\000\000t\000\000\000 \000\000\000a\000\000\000l\000\000\000l\000\000\000o\000\000\000w\000\000\000e\000\000\000d\000\000\000 \000\000\000w\000\000\000i\000\000\000t\000\000\000h\000\000\000o\000\000\000u\000\000\000t\000\000\000 \000\000\000w\000\000\000r\000\000\000a\000\000\000p\000\000\000p\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000i\000\000\000t\000\000\000 \000\000\000i\000\000\000n\000\000\000 \000\000\000a\000\000\000 \000\000\000c\000\000\000o\000\000\000n\000\000\000t\000\000\000a\000\000\000i\000\000\000n\000\000\000e\000\000\000r\000\000\000 \000\000\000e\000\000\000l\000\000\000e\000\000\000m\000\000\000e\000\000\000n\000\000\000t\000\000\000",72,209050484));
}

void EIF_Minit317 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
