
#ifndef _C7_ol344_
#define _C7_ol344_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F392_5989(EIF_REFERENCE);
extern void EIF_Minit344(void);

#ifdef __cplusplus
}
#endif

#endif
