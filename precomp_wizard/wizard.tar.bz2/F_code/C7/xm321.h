
#ifndef _C7_xm321_
#define _C7_xm321_

#ifdef __cplusplus
extern "C" {
#endif

extern void F369_5694(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_NATURAL_32 F369_5695(EIF_REFERENCE);
extern void F369_5696(EIF_REFERENCE);
extern EIF_NATURAL_32 F369_5697(EIF_REFERENCE);
extern void EIF_Minit321(void);
extern void F370_5700(EIF_REFERENCE);
extern EIF_NATURAL_32 F370_5698(EIF_REFERENCE);
extern void F368_5684(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5409[])();

#ifdef __cplusplus
}
#endif

#endif
