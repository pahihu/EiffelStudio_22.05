/*
 * Code for class XML_CHARACTER_8_INPUT_STREAM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm322.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XML_CHARACTER_8_INPUT_STREAM}.last_character_code */
EIF_NATURAL_32 F370_5698 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_8 tc1;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("last_character_code", 369, Current, 0, 0, 5760);
	RTGC;
	RTHOOK(1);
	tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE)) R5433[Dtype(Current)-1290])(Current);
	Result = (EIF_NATURAL_32) tc1;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_CHARACTER_8_INPUT_STREAM}.read_character_code */
void F370_5700 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("read_character_code", 369, Current, 0, 0, 5761);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5434[Dtype(Current)-1290])(Current);
	RTHOOK(2);
	RTEE;
}

void EIF_Minit322 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
