/*
 * Code for class EV_SHARED_APPLICATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev326.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_SHARED_APPLICATION}.ev_application */
EIF_REFERENCE F374_5869 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("ev_application", 373, Current, 1, 0, 5929);
	RTGC;
	RTHOOK(1);
	RTCT0("attached shared_environment.application as l_app", EX_CHECK);
	tr1 = F1259_11732(RTCV(RTOUCR(279,F374_5872, (Current))));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(2);
	Result = (EIF_REFERENCE) loc1;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_SHARED_APPLICATION}.shared_environment */
static EIF_REFERENCE F374_5872_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(279)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("shared_environment", 373, Current, 0, 0, 5932);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1258, 0x00).id, 1258, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1248_11522(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F374_5872 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(279,F374_5872_body,(Current));
}

void EIF_Minit326 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
