/*
 * Code for class XML_STANDARD_PARSER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm313.h"
#include <ctype.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XML_STANDARD_PARSER}.make */
void F361_5502 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 360, Current, 0, 0, 5624);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(355, 0x00).id, 355, _OBJSIZ_1_0_0_0_0_0_0_0_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTOUCR(582,F361_5577, (Current));
	F361_5525(Current, tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.parse_from_stream */
void F361_5503 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("parse_from_stream", 360, Current, 0, 1, 5625);
	RTGC;
	RTHOOK(1);
	F361_5525(Current, arg1);
	RTHOOK(2);
	F361_5529(Current);
	RTHOOK(3);
	tr1 = RTOUCR(582,F361_5577, (Current));
	F361_5525(Current, tr1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.parse_from_file */
void F361_5506 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("parse_from_file", 360, Current, 1, 1, 5628);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1291, 0x00).id, 1291, _OBJSIZ_3_3_0_7_0_0_0_0_);
	F1292_12157(RTCW(loc1), arg1);
	RTHOOK(2);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7706[Dtype(RTCW(arg1))-780])(arg1);
	F1292_12172(RTCW(loc1), ti4_1, ((EIF_INTEGER_32) 16384L));
	RTHOOK(3);
	F1292_12173(RTCW(loc1));
	RTHOOK(4);
	F361_5503(Current, loc1);
	RTHOOK(5);
	F1292_12174(RTCW(loc1));
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.set_callbacks */
void F361_5509 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_callbacks", 360, Current, 0, 1, 5631);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {XML_STANDARD_PARSER}.set_encoding */
void F361_5510 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc3);
	RTLR(5,arg1);
	RTLR(6,tr2);
	RTLR(7,loc4);
	RTLIU(8);
	
	RTEAA("set_encoding", 360, Current, 4, 1, 5632);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc2 = tr1;
	loc2 = RTRV(eif_new_type(369, 0x00),loc2);
	if (EIF_TEST(loc2)) {
		RTHOOK(2);
		loc1 = (EIF_REFERENCE) loc2;
	} else {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc3 = tr1;
		loc3 = RTRV(eif_new_type(367, 0x00),loc3);
		if (EIF_TEST(loc3)) {
			RTHOOK(4);
			loc1 = *(EIF_REFERENCE *)(loc3);
		}
	}
	RTHOOK(5);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(6);
		tr1 = RTMS32_EX_H("I\000\000\000n\000\000\000t\000\000\000e\000\000\000r\000\000\000n\000\000\000a\000\000\000l\000\000\000 \000\000\000e\000\000\000r\000\000\000r\000\000\000o\000\000\000r\000\000\000:\000\000\000 \000\000\000u\000\000\000n\000\000\000a\000\000\000b\000\000\000l\000\000\000e\000\000\000 \000\000\000t\000\000\000o\000\000\000 \000\000\000u\000\000\000s\000\000\000e\000\000\000 \000\000\000e\000\000\000n\000\000\000c\000\000\000o\000\000\000d\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000\"\000\000\000",40,1493525538);
		tr2 = F1237_11119(RTCW(arg1));
		tr1 = F1242_11323(tr1, tr2);
		tr2 = RTMS32_EX_H("\"\000\000\000.\000\000\000",2,8750);
		tr1 = F1242_11323(RTCW(tr1), tr2);
		F361_5539(Current, tr1);
	} else {
		RTHOOK(7);
		tr1 = F361_5550(Current, arg1, loc1);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			RTHOOK(8);
			RTAR(Current, loc4);
			*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc4;
		} else {
			RTHOOK(9);
			tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000s\000\000\000u\000\000\000p\000\000\000p\000\000\000o\000\000\000r\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000e\000\000\000n\000\000\000c\000\000\000o\000\000\000d\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000\"\000\000\000",22,967152674);
			tr2 = F1237_11119(RTCW(arg1));
			tr1 = F1242_11323(tr1, tr2);
			tr2 = RTMS32_EX_H("\"\000\000\000.\000\000\000",2,8750);
			tr1 = F1242_11323(RTCW(tr1), tr2);
			F361_5539(Current, tr1);
			RTHOOK(10);
			tr1 = RTLNS(eif_new_type(368, 0x00).id, 368, _OBJSIZ_1_0_0_1_0_0_0_0_);
			F369_5694(RTCW(tr1), loc1);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
		}
	}
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.truncation_reported */
EIF_BOOLEAN F361_5513 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_5_2_);
}


/* {XML_STANDARD_PARSER}.error_message */
EIF_REFERENCE F361_5516 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_4_);
}


/* {XML_STANDARD_PARSER}.error_position */
EIF_REFERENCE F361_5517 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {XML_STANDARD_PARSER}.position */
EIF_REFERENCE F361_5518 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("position", 360, Current, 1, 0, 5640);
	RTGC;
	RTHOOK(1);
	tr1 = F362_5600(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) loc1;
	} else {
		RTHOOK(4);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) F361_5519(Current);
	}/* NOTREACHED */
	
}

/* {XML_STANDARD_PARSER}.buffer_position */
EIF_REFERENCE F361_5519 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("buffer_position", 360, Current, 0, 0, 5641);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1297, 0x00).id, 1297, _OBJSIZ_1_0_0_3_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5408[Dtype(RTCW(tr1))-368])(tr1);
	tr1 = F1237_11118(RTCW(tr1));
	ti4_1 = F361_5520(Current);
	ti4_2 = F361_5522(Current);
	ti4_3 = F361_5521(Current);
	F1298_12351(RTCW(Result), tr1, ti4_1, ti4_2, ti4_3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STANDARD_PARSER}.byte_index */
EIF_INTEGER_32 F361_5520 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("byte_index", 360, Current, 0, 0, 5642);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5411[Dtype(RTCW(tr1))-368])(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STANDARD_PARSER}.line */
EIF_INTEGER_32 F361_5521 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("line", 360, Current, 0, 0, 5643);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5412[Dtype(RTCW(tr1))-368])(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STANDARD_PARSER}.column */
EIF_INTEGER_32 F361_5522 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("column", 360, Current, 0, 0, 5644);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5413[Dtype(RTCW(tr1))-368])(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STANDARD_PARSER}.reset */
void F361_5523 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("reset", 360, Current, 0, 0, 5645);
	RTGC;
	RTHOOK(1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_) = (EIF_CHARACTER_32) tw1;
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_1_) = (EIF_CHARACTER_32) tw1;
	RTHOOK(3);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(4);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) NULL;
	RTHOOK(5);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) NULL;
	RTHOOK(6);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
	RTHOOK(7);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_5_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.set_buffer */
void F361_5525 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("set_buffer", 360, Current, 0, 1, 5647);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5409[Dtype(RTCW(arg1))-368])(arg1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) = (EIF_BOOLEAN) tb1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.parse */
void F361_5529 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc4);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc5);
	RTLIU(5);
	
	RTEAA("parse", 360, Current, 5, 0, 5651);
	RTGC;
	RTHOOK(1);
	F362_5599(Current);
	RTHOOK(2);
	loc4 = *(EIF_REFERENCE *)(Current);
	RTHOOK(3);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5240[Dtype(RTCW(loc4))-355])(loc4);
	RTHOOK(4);
	loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(5);
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(6);
	loc1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1237_11059(RTCW(loc1));
	for (;;) {
		RTHOOK(7);
		if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_))) break;
		RTHOOK(8);
		F361_5557(Current);
		RTHOOK(9);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
		} else {
			RTHOOK(10);
			switch (*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_)) {
				case (EIF_CHARACTER_8) '\000':
					
					RTHOOK(12);
					tr1 = RTMS_EX_H("Null character!",15,996057121);
					F361_5544(Current, tr1);
					break;
				case (EIF_CHARACTER_8) '<':
					RTHOOK(13);
					if (loc2) {
						RTHOOK(14);
						if (loc3) {
							RTHOOK(15);
							tr1 = F361_5548(Current, loc1);
							loc5 = tr1;
							if (EIF_TEST(loc5)) {
								RTHOOK(16);
								F361_5546(Current, loc5);
								RTHOOK(17);
								ti4_1 = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_2_);
								F1242_11326(RTCW(loc1), ti4_1);
							}
							RTHOOK(18);
							loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						}
						RTHOOK(19);
						if ((EIF_BOOLEAN) !F361_5575(Current, loc1)) {
							RTHOOK(20);
							F361_5545(Current, loc1);
						}
						RTHOOK(21);
						F1242_11333(RTCW(loc1));
					} else {
						RTHOOK(22);
						tb1 = F730_8337(RTCW(loc1));
						if ((EIF_BOOLEAN) !tb1) {
							RTHOOK(23);
							tr1 = F1240_11204(RTCW(loc1));
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5250[Dtype(RTCW(loc4))-355])(loc4, tr1);
							RTHOOK(24);
							F1242_11333(RTCW(loc1));
						}
					}
					RTHOOK(25);
					F361_5557(Current);
					RTHOOK(26);
					if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
						RTHOOK(27);
						tr1 = RTMS_EX_H("Input ends with \'<\' character",29,1434827122);
						F361_5540(Current, tr1);
					} else {
						RTHOOK(28);
						switch (*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_)) {
							case (EIF_CHARACTER_8) '\?':
								RTHOOK(29);
								F361_5533(Current);
								break;
							case (EIF_CHARACTER_8) '/':
								RTHOOK(30);
								F361_5531(Current);
								break;
							case (EIF_CHARACTER_8) '!':
								RTHOOK(31);
								F361_5557(Current);
								RTHOOK(32);
								if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
									RTHOOK(33);
									tr1 = RTMS_EX_H("Input ends with \'<!\'",20,1960991271);
									F361_5540(Current, tr1);
								} else {
									RTHOOK(34);
									switch (*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_)) {
										case (EIF_CHARACTER_8) '-':
											RTHOOK(35);
											F361_5556(Current);
											RTHOOK(36);
											F361_5535(Current);
											break;
										case (EIF_CHARACTER_8) '[':
											RTHOOK(37);
											F361_5556(Current);
											RTHOOK(38);
											F361_5534(Current);
											break;
										case (EIF_CHARACTER_8) 'D':
											RTHOOK(39);
											F361_5556(Current);
											RTHOOK(40);
											F361_5536(Current);
											break;
										default:
											RTHOOK(41);
											F361_5541(Current, NULL);
											break;
									}
								}
								break;
							default:
								RTHOOK(42);
								F361_5556(Current);
								RTHOOK(43);
								loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								RTHOOK(44);
								F361_5530(Current);
								break;
						}
					}
					break;
				case (EIF_CHARACTER_8) '&':
					RTHOOK(45);
					tr1 = F361_5561(Current);
					F1242_11306(RTCW(loc1), tr1);
					break;
				case (EIF_CHARACTER_8) '>':
					RTHOOK(46);
					F361_5541(Current, NULL);
					break;
				default:
					RTHOOK(47);
					F1242_11317(RTCW(loc1), *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_));
					break;
			}
		}
	}
	RTHOOK(48);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_)) {
		RTHOOK(49);
		tb1 = '\0';
		tb2 = F730_8337(RTCW(loc1));
		if ((EIF_BOOLEAN) !tb2) {
			tb1 = (EIF_BOOLEAN) !F361_5575(Current, loc1);
		}
		if (tb1) {
			RTHOOK(50);
			tr1 = F1240_11204(RTCW(loc1));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5250[Dtype(RTCW(loc4))-355])(loc4, tr1);
			RTHOOK(51);
			F1242_11333(RTCW(loc1));
		}
		RTHOOK(52);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5241[Dtype(RTCW(loc4))-355])(loc4);
	}
	RTHOOK(53);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.parse_start_tag */
void F361_5530 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc4);
	RTLR(4,tr2);
	RTLR(5,loc2);
	RTLR(6,tr3);
	RTLIU(7);
	
	RTEAA("parse_start_tag", 360, Current, 4, 0, 5652);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
		RTHOOK(2);
		F361_5540(Current, NULL);
	} else {
		RTHOOK(3);
		loc1 = F361_5560(Current);
		RTHOOK(4);
		tr1 = eif_boxed_item(loc1,2);
		tb1 = F730_8337(RTCW(tr1));
		if (tb1) {
			RTHOOK(5);
			tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000s\000\000\000t\000\000\000a\000\000\000r\000\000\000t\000\000\000 \000\000\000t\000\000\000a\000\000\000g\000\000\000 \000\000\000v\000\000\000a\000\000\000l\000\000\000u\000\000\000e\000\000\000.\000\000\000",24,1280155182);
			F362_5606(Current, tr1);
		} else {
			RTHOOK(6);
			loc4 = *(EIF_REFERENCE *)(Current);
			RTHOOK(7);
			tr1 = eif_boxed_item(loc1,1);
			tr2 = eif_boxed_item(loc1,2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5246[Dtype(RTCW(loc4))-355])(loc4, NULL, tr1, tr2);
			RTHOOK(8);
			tw1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
			tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = tw1;
			tb1 = F1188_10895(RTCW(tr1));
			if (tb1) {
				RTHOOK(9);
				F361_5559(Current);
			}
			RTHOOK(10);
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
				RTHOOK(11);
				tr1 = RTMS_EX_H("in start tag declaration",24,735103342);
				F361_5540(Current, tr1);
			} else {
				RTHOOK(12);
				switch (*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_)) {
					case (EIF_CHARACTER_8) '>':
						RTHOOK(13);
						(FUNCTION_CAST(void, (EIF_REFERENCE)) R5248[Dtype(RTCW(loc4))-355])(loc4);
						break;
					case (EIF_CHARACTER_8) '/':
						RTHOOK(14);
						if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
							RTHOOK(15);
							tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000c\000\000\000o\000\000\000m\000\000\000p\000\000\000l\000\000\000e\000\000\000t\000\000\000e\000\000\000 \000\000\000s\000\000\000t\000\000\000a\000\000\000r\000\000\000t\000\000\000 \000\000\000t\000\000\000a\000\000\000g\000\000\000",20,618822503);
							F361_5540(Current, tr1);
						} else {
							RTHOOK(16);
							F361_5557(Current);
							RTHOOK(17);
							tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
							if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_) == tw1)) {
								RTHOOK(18);
								(FUNCTION_CAST(void, (EIF_REFERENCE)) R5248[Dtype(RTCW(loc4))-355])(loc4);
								RTHOOK(19);
								tr1 = eif_boxed_item(loc1,1);
								tr2 = eif_boxed_item(loc1,2);
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5249[Dtype(RTCW(loc4))-355])(loc4, NULL, tr1, tr2);
							} else {
								RTHOOK(20);
								tr1 = RTMS32_EX_H("u\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000\'\000\000\000",22,169384743);
								tr2 = F361_5565(Current, *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_));
								tr1 = F1242_11323(tr1, tr2);
								tr2 = RTMS32_EX_H("\'\000\000\000 \000\000\000a\000\000\000f\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000c\000\000\000l\000\000\000o\000\000\000s\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000/\000\000\000 \000\000\000i\000\000\000n\000\000\000 \000\000\000s\000\000\000t\000\000\000a\000\000\000r\000\000\000t\000\000\000 \000\000\000t\000\000\000a\000\000\000g\000\000\000.\000\000\000",31,20660270);
								tr1 = F1242_11323(RTCW(tr1), tr2);
								F362_5606(Current, tr1);
							}
						}
						break;
					default:
						RTHOOK(21);
						F361_5556(Current);
						RTHOOK(22);
						loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						for (;;) {
							RTHOOK(23);
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) || loc3) || *(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_))) break;
							RTHOOK(24);
							loc2 = F361_5564(Current);
							RTHOOK(25);
							if ((EIF_BOOLEAN)(loc2 != NULL)) {
								RTHOOK(26);
								tr1 = eif_boxed_item(loc2,1);
								tr2 = eif_boxed_item(loc2,2);
								tr3 = eif_boxed_item(loc2,3);
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5247[Dtype(RTCW(loc4))-355])(loc4, NULL, tr1, tr2, tr3);
								RTHOOK(27);
								if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
									RTHOOK(28);
									tr1 = RTMS_EX_H("in start tag declaration",24,735103342);
									F361_5540(Current, tr1);
								} else {
									RTHOOK(29);
									F361_5556(Current);
								}
							} else {
								RTHOOK(30);
								if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
									RTHOOK(31);
									tr1 = RTMS_EX_H("in start tag declaration",24,735103342);
									F361_5540(Current, tr1);
								} else {
									RTHOOK(32);
									switch (*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_)) {
										case (EIF_CHARACTER_8) '>':
											RTHOOK(33);
											(FUNCTION_CAST(void, (EIF_REFERENCE)) R5248[Dtype(RTCW(loc4))-355])(loc4);
											break;
										case (EIF_CHARACTER_8) '/':
											RTHOOK(34);
											F361_5557(Current);
											RTHOOK(35);
											if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
												RTHOOK(36);
												tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000c\000\000\000o\000\000\000m\000\000\000p\000\000\000l\000\000\000e\000\000\000t\000\000\000e\000\000\000 \000\000\000s\000\000\000t\000\000\000a\000\000\000r\000\000\000t\000\000\000 \000\000\000t\000\000\000a\000\000\000g\000\000\000 \000\000\000e\000\000\000n\000\000\000d\000\000\000i\000\000\000n\000\000\000g\000\000\000",27,2035617383);
												F361_5540(Current, tr1);
											} else {
												RTHOOK(37);
												tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
												if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_) == tw1)) {
													RTHOOK(38);
													loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
													RTHOOK(39);
													(FUNCTION_CAST(void, (EIF_REFERENCE)) R5248[Dtype(RTCW(loc4))-355])(loc4);
													RTHOOK(40);
													tr1 = eif_boxed_item(loc1,1);
													tr2 = eif_boxed_item(loc1,2);
													(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5249[Dtype(RTCW(loc4))-355])(loc4, NULL, tr1, tr2);
												} else {
													RTHOOK(41);
													tr1 = RTMS32_EX_H("u\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000\'\000\000\000",22,169384743);
													tr2 = F361_5565(Current, *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_));
													tr1 = F1242_11323(tr1, tr2);
													tr2 = RTMS32_EX_H("\'\000\000\000 \000\000\000a\000\000\000f\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000c\000\000\000l\000\000\000o\000\000\000s\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000/\000\000\000 \000\000\000i\000\000\000n\000\000\000 \000\000\000s\000\000\000t\000\000\000a\000\000\000r\000\000\000t\000\000\000 \000\000\000t\000\000\000a\000\000\000g\000\000\000",30,1266758247);
													tr1 = F1242_11323(RTCW(tr1), tr2);
													F362_5606(Current, tr1);
												}
											}
											break;
										default:
											RTHOOK(42);
											tr1 = RTMS32_EX_H("u\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000\'\000\000\000",22,169384743);
											tr2 = F361_5565(Current, *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_));
											tr1 = F1242_11323(tr1, tr2);
											tr2 = RTMS32_EX_H("\'\000\000\000 \000\000\000i\000\000\000n\000\000\000 \000\000\000s\000\000\000t\000\000\000a\000\000\000r\000\000\000t\000\000\000 \000\000\000t\000\000\000a\000\000\000g\000\000\000",14,1961969255);
											tr1 = F1242_11323(RTCW(tr1), tr2);
											F362_5606(Current, tr1);
											break;
									}
									RTHOOK(43);
									loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								}
							}
						}
						break;
				}
			}
		}
	}
	RTHOOK(44);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.parse_end_tag */
void F361_5531 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTEAA("parse_end_tag", 360, Current, 1, 0, 5653);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
		RTHOOK(2);
		F361_5540(Current, NULL);
	} else {
		RTHOOK(3);
		loc1 = F361_5560(Current);
		RTHOOK(4);
		tr1 = eif_boxed_item(loc1,2);
		tb1 = F730_8337(RTCW(tr1));
		if (tb1) {
			RTHOOK(5);
			tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000e\000\000\000n\000\000\000d\000\000\000 \000\000\000t\000\000\000a\000\000\000g\000\000\000 \000\000\000v\000\000\000a\000\000\000l\000\000\000u\000\000\000e\000\000\000.\000\000\000",22,1226534958);
			F362_5606(Current, tr1);
		} else {
			RTHOOK(6);
			tw1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
			tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = tw1;
			tb1 = F1188_10895(RTCW(tr1));
			if (tb1) {
				RTHOOK(7);
				F361_5559(Current);
			}
			RTHOOK(8);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
			if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_) == tw1)) {
				RTHOOK(9);
				tr1 = *(EIF_REFERENCE *)(Current);
				tr2 = eif_boxed_item(loc1,1);
				tr3 = eif_boxed_item(loc1,2);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5249[Dtype(RTCW(tr1))-355])(tr1, NULL, tr2, tr3);
			} else {
				RTHOOK(10);
				tr1 = RTMS32_EX_H("u\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000\'\000\000\000",22,169384743);
				tr2 = F361_5565(Current, *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_));
				tr1 = F1242_11323(tr1, tr2);
				tr2 = RTMS32_EX_H("\'\000\000\000 \000\000\000i\000\000\000n\000\000\000 \000\000\000e\000\000\000n\000\000\000d\000\000\000 \000\000\000t\000\000\000a\000\000\000g\000\000\000",12,1228033127);
				tr1 = F1242_11323(RTCW(tr1), tr2);
				F362_5606(Current, tr1);
			}
		}
	}
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.parse_declaration */
void F361_5532 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,loc6);
	RTLR(6,loc4);
	RTLIU(7);
	
	RTEAA("parse_declaration", 360, Current, 6, 0, 5654);
	RTGC;
	RTHOOK(1);
	loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_)) {
		RTHOOK(3);
		F361_5557(Current);
		RTHOOK(4);
		tw1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
		tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)tr1 = tw1;
		tb1 = F1188_10895(RTCW(tr1));
		if (tb1) {
			RTHOOK(5);
			F361_5559(Current);
		}
		RTHOOK(6);
		switch (*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_)) {
			case (EIF_CHARACTER_8) '\?':
				RTHOOK(7);
				F361_5557(Current);
				RTHOOK(8);
				if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
					RTHOOK(9);
					tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000c\000\000\000o\000\000\000m\000\000\000p\000\000\000l\000\000\000e\000\000\000t\000\000\000e\000\000\000 \000\000\000x\000\000\000m\000\000\000l\000\000\000 \000\000\000d\000\000\000e\000\000\000c\000\000\000l\000\000\000a\000\000\000r\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",26,870850158);
					F361_5540(Current, tr1);
				} else {
					RTHOOK(10);
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
					if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_) == tw1)) {
						RTHOOK(11);
						if ((EIF_BOOLEAN)(loc1 != NULL)) {
							RTHOOK(12);
							F361_5537(Current, loc1, loc2, loc3);
						} else {
							RTHOOK(13);
							tr1 = RTMS32_EX_H("m\000\000\000i\000\000\000s\000\000\000s\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000v\000\000\000e\000\000\000r\000\000\000s\000\000\000i\000\000\000o\000\000\000n\000\000\000 \000\000\000i\000\000\000n\000\000\000 \000\000\000x\000\000\000m\000\000\000l\000\000\000 \000\000\000d\000\000\000e\000\000\000c\000\000\000l\000\000\000a\000\000\000r\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",34,383714414);
							F362_5606(Current, tr1);
						}
					} else {
						RTHOOK(14);
						tr1 = RTMS32_EX_H("u\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000\'\000\000\000",22,169384743);
						tr2 = F361_5565(Current, *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_));
						tr1 = F1242_11323(tr1, tr2);
						tr2 = RTMS32_EX_H("\'\000\000\000 \000\000\000a\000\000\000f\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000c\000\000\000l\000\000\000o\000\000\000s\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000\?\000\000\000 \000\000\000i\000\000\000n\000\000\000 \000\000\000x\000\000\000m\000\000\000l\000\000\000 \000\000\000d\000\000\000e\000\000\000c\000\000\000l\000\000\000a\000\000\000r\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",36,885578862);
						tr1 = F1242_11323(RTCW(tr1), tr2);
						F362_5606(Current, tr1);
					}
				}
				break;
			default:
				RTHOOK(15);
				F361_5556(Current);
				RTHOOK(16);
				loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				for (;;) {
					RTHOOK(17);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc5 || *(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_)) || *(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_))) break;
					RTHOOK(18);
					loc6 = F361_5564(Current);
					RTHOOK(19);
					if ((EIF_BOOLEAN)(loc6 != NULL)) {
						RTHOOK(20);
						loc4 = eif_boxed_item(loc6,2);
						RTHOOK(21);
						tr1 = RTOUCR(583,F361_5582, (Current));
						tb1 = F1240_11214(RTCW(loc4), tr1);
						if (tb1) {
							RTHOOK(22);
							loc1 = eif_boxed_item(loc6,3);
						} else {
							RTHOOK(23);
							tr1 = RTOUCR(584,F361_5583, (Current));
							tb1 = F1240_11214(RTCW(loc4), tr1);
							if (tb1) {
								RTHOOK(24);
								loc2 = eif_boxed_item(loc6,3);
							} else {
								RTHOOK(25);
								tr1 = RTOUCR(585,F361_5584, (Current));
								tb1 = F1240_11214(RTCW(loc4), tr1);
								if (tb1) {
									RTHOOK(26);
									loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								} else {
									RTHOOK(27);
									tr1 = RTMS32_EX_H("u\000\000\000n\000\000\000k\000\000\000n\000\000\000o\000\000\000w\000\000\000n\000\000\000 \000\000\000x\000\000\000m\000\000\000l\000\000\000 \000\000\000d\000\000\000e\000\000\000c\000\000\000l\000\000\000a\000\000\000r\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000 \000\000\000a\000\000\000t\000\000\000t\000\000\000r\000\000\000i\000\000\000b\000\000\000u\000\000\000t\000\000\000e\000\000\000 \000\000\000[\000\000\000",35,508354139);
									tr2 = F1237_11119(RTCW(loc4));
									tr1 = F1242_11323(tr1, tr2);
									tr2 = RTMS32_EX_H("]\000\000\000",1,93);
									tr1 = F1242_11323(RTCW(tr1), tr2);
									F362_5606(Current, tr1);
								}
							}
						}
						RTHOOK(28);
						F361_5556(Current);
					} else {
						RTHOOK(29);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\?';
						if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_) == tw1)) {
							RTHOOK(30);
							F361_5559(Current);
							RTHOOK(31);
							if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
								RTHOOK(32);
								tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000c\000\000\000o\000\000\000m\000\000\000p\000\000\000l\000\000\000e\000\000\000t\000\000\000e\000\000\000 \000\000\000e\000\000\000n\000\000\000d\000\000\000 \000\000\000o\000\000\000f\000\000\000 \000\000\000x\000\000\000m\000\000\000l\000\000\000 \000\000\000d\000\000\000e\000\000\000c\000\000\000l\000\000\000a\000\000\000r\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",33,760619886);
								F361_5540(Current, tr1);
							} else {
								RTHOOK(33);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
								if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_) == tw1)) {
									RTHOOK(34);
									loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
									RTHOOK(35);
									if ((EIF_BOOLEAN)(loc1 != NULL)) {
										RTHOOK(36);
										F361_5537(Current, loc1, loc2, loc3);
									} else {
										RTHOOK(37);
										tr1 = RTMS32_EX_H("m\000\000\000i\000\000\000s\000\000\000s\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000v\000\000\000e\000\000\000r\000\000\000s\000\000\000i\000\000\000o\000\000\000n\000\000\000 \000\000\000i\000\000\000n\000\000\000 \000\000\000x\000\000\000m\000\000\000l\000\000\000 \000\000\000d\000\000\000e\000\000\000c\000\000\000l\000\000\000a\000\000\000r\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",34,383714414);
										F362_5606(Current, tr1);
									}
								} else {
									RTHOOK(38);
									tr1 = RTMS32_EX_H("u\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000\'\000\000\000",22,169384743);
									tr2 = F361_5565(Current, *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_));
									tr1 = F1242_11323(tr1, tr2);
									tr2 = RTMS32_EX_H("\'\000\000\000 \000\000\000a\000\000\000f\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000c\000\000\000l\000\000\000o\000\000\000s\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000\?\000\000\000 \000\000\000i\000\000\000n\000\000\000 \000\000\000x\000\000\000m\000\000\000l\000\000\000 \000\000\000d\000\000\000e\000\000\000c\000\000\000l\000\000\000a\000\000\000r\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",36,885578862);
									tr1 = F1242_11323(RTCW(tr1), tr2);
									F362_5606(Current, tr1);
								}
							}
						}
						RTHOOK(39);
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
				}
				break;
		}
	}
	RTHOOK(40);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.parse_processing_instruction */
void F361_5533 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,tr2);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTEAA("parse_processing_instruction", 360, Current, 4, 0, 5655);
	RTGC;
	RTHOOK(1);
	F361_5557(Current);
	RTHOOK(2);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
		RTHOOK(3);
		tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000c\000\000\000o\000\000\000m\000\000\000p\000\000\000l\000\000\000e\000\000\000t\000\000\000e\000\000\000 \000\000\000p\000\000\000r\000\000\000o\000\000\000c\000\000\000e\000\000\000s\000\000\000s\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000i\000\000\000n\000\000\000s\000\000\000t\000\000\000r\000\000\000u\000\000\000c\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",33,1635038062);
		F361_5540(Current, tr1);
	} else {
		RTHOOK(4);
		loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
		RTHOOK(5);
		loc2 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1240_11189(RTCW(loc2), ((EIF_INTEGER_32) 6L));
		for (;;) {
			RTHOOK(6);
			tb1 = '\01';
			tb2 = '\01';
			tb3 = '\01';
			if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
				tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = loc1;
				tb4 = F1188_10895(RTCW(tr1));
				tb3 = tb4;
			}
			if (!tb3) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\?';
				tb2 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb2) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
				tb1 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (tb1) break;
			RTHOOK(7);
			F1242_11317(RTCW(loc2), loc1);
			RTHOOK(8);
			F361_5557(Current);
			RTHOOK(9);
			loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
		}
		RTHOOK(10);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
			RTHOOK(11);
			tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000c\000\000\000o\000\000\000m\000\000\000p\000\000\000l\000\000\000e\000\000\000t\000\000\000e\000\000\000 \000\000\000p\000\000\000r\000\000\000o\000\000\000c\000\000\000e\000\000\000s\000\000\000s\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000i\000\000\000n\000\000\000s\000\000\000t\000\000\000r\000\000\000u\000\000\000c\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",33,1635038062);
			F361_5540(Current, tr1);
		} else {
			RTHOOK(12);
			tb2 = F730_8337(RTCW(loc2));
			if (tb2) {
				RTHOOK(13);
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
					RTHOOK(14);
					F361_5556(Current);
				}
				RTHOOK(15);
				tr1 = RTMS32_EX_H("I\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000p\000\000\000r\000\000\000o\000\000\000c\000\000\000e\000\000\000s\000\000\000s\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000i\000\000\000n\000\000\000s\000\000\000t\000\000\000r\000\000\000u\000\000\000c\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000 \000\000\000s\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000 \000\000\000<\000\000\000\?\000\000\000",40,1005310015);
				tr2 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
				F1240_11190(RTCW(tr2), *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_), ((EIF_INTEGER_32) 1L));
				tr1 = F1242_11323(tr1, tr2);
				F362_5606(Current, tr1);
			} else {
				RTHOOK(16);
				tr1 = RTOUCR(586,F361_5588, (Current));
				tb2 = F1240_11214(RTCW(loc2), tr1);
				if (tb2) {
					RTHOOK(17);
					F361_5532(Current);
				} else {
					RTHOOK(18);
					loc3 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F1237_11059(RTCW(loc3));
					RTHOOK(19);
					F361_5557(Current);
					for (;;) {
						RTHOOK(20);
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) || loc4) || *(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_))) break;
						RTHOOK(21);
						loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
						RTHOOK(22);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\?';
						if ((EIF_BOOLEAN)(loc1 == tw1)) {
							RTHOOK(23);
							F361_5557(Current);
							RTHOOK(24);
							loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
							RTHOOK(25);
							tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
							if ((EIF_BOOLEAN)(loc1 == tw1)) {
								RTHOOK(26);
								loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								RTHOOK(27);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\?';
								if ((EIF_BOOLEAN)(loc1 == tw1)) {
									RTHOOK(28);
									tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\?';
									F1242_11317(RTCW(loc3), tw1);
								} else {
									RTHOOK(29);
									tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\?';
									F1242_11317(RTCW(loc3), tw1);
									RTHOOK(30);
									F1242_11317(RTCW(loc3), loc1);
									RTHOOK(31);
									F361_5557(Current);
									RTHOOK(32);
									if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
										RTHOOK(33);
										tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000c\000\000\000o\000\000\000m\000\000\000p\000\000\000l\000\000\000e\000\000\000t\000\000\000e\000\000\000 \000\000\000p\000\000\000r\000\000\000o\000\000\000c\000\000\000e\000\000\000s\000\000\000s\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000i\000\000\000n\000\000\000s\000\000\000t\000\000\000r\000\000\000u\000\000\000c\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",33,1635038062);
										F361_5540(Current, tr1);
									}
								}
							}
						} else {
							RTHOOK(34);
							F1242_11317(RTCW(loc3), loc1);
							RTHOOK(35);
							F361_5557(Current);
						}
					}
					RTHOOK(36);
					if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_))) {
						RTHOOK(37);
						tr1 = RTMS32_EX_H("c\000\000\000o\000\000\000u\000\000\000l\000\000\000d\000\000\000 \000\000\000n\000\000\000o\000\000\000t\000\000\000 \000\000\000f\000\000\000i\000\000\000n\000\000\000d\000\000\000 \000\000\000e\000\000\000n\000\000\000d\000\000\000 \000\000\000o\000\000\000f\000\000\000 \000\000\000P\000\000\000r\000\000\000o\000\000\000c\000\000\000e\000\000\000s\000\000\000s\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000I\000\000\000n\000\000\000s\000\000\000t\000\000\000r\000\000\000u\000\000\000c\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",44,395533678);
						F362_5606(Current, tr1);
					} else {
						RTHOOK(38);
						tr1 = *(EIF_REFERENCE *)(Current);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5244[Dtype(RTCW(tr1))-355])(tr1, loc2, loc3);
					}
				}
			}
		}
	}
	RTHOOK(39);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.parse_cdata */
void F361_5534 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("parse_cdata", 360, Current, 3, 0, 5656);
	RTGC;
	RTHOOK(1);
	F361_5557(Current);
	RTHOOK(2);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
		RTHOOK(3);
		tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000c\000\000\000o\000\000\000m\000\000\000p\000\000\000l\000\000\000e\000\000\000t\000\000\000e\000\000\000 \000\000\000C\000\000\000D\000\000\000A\000\000\000T\000\000\000A\000\000\000 \000\000\000s\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000",23,2086846584);
		F361_5540(Current, tr1);
	} else {
		RTHOOK(4);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
		if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_) != tw1)) {
			RTHOOK(5);
			tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000s\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000 \000\000\000<\000\000\000!\000\000\000",17,1133362721);
			tr2 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F1240_11190(RTCW(tr2), *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_), ((EIF_INTEGER_32) 1L));
			tr1 = F1242_11323(tr1, tr2);
			F362_5606(Current, tr1);
		} else {
			RTHOOK(6);
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
				RTHOOK(7);
				tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000c\000\000\000o\000\000\000m\000\000\000p\000\000\000l\000\000\000e\000\000\000t\000\000\000e\000\000\000 \000\000\000C\000\000\000D\000\000\000A\000\000\000T\000\000\000A\000\000\000 \000\000\000s\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000",23,2086846584);
				F361_5540(Current, tr1);
			} else {
				RTHOOK(8);
				F361_5557(Current);
				RTHOOK(9);
				loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
				RTHOOK(10);
				loc2 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
				F1240_11189(RTCW(loc2), ((EIF_INTEGER_32) 6L));
				for (;;) {
					RTHOOK(11);
					tb1 = '\01';
					if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
						tb1 = (EIF_BOOLEAN)(loc1 == tw1);
					}
					if (tb1) break;
					RTHOOK(12);
					tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
					*(EIF_CHARACTER_32 *)tr1 = loc1;
					tw1 = F1188_10883(RTCW(tr1));
					F1242_11317(RTCW(loc2), tw1);
					RTHOOK(13);
					F361_5557(Current);
					RTHOOK(14);
					loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
				}
				RTHOOK(15);
				tr1 = RTOUCR(587,F361_5585, (Current));
				tb2 = F1237_11104(RTCW(loc2), tr1);
				if (tb2) {
					RTHOOK(16);
					F1242_11333(RTCW(loc2));
					RTHOOK(17);
					F361_5557(Current);
					for (;;) {
						RTHOOK(18);
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) || loc3) || *(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_))) break;
						RTHOOK(19);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
						if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_) == tw1)) {
							RTHOOK(20);
							F361_5557(Current);
							RTHOOK(21);
							tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
							if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_) == tw1)) {
								RTHOOK(22);
								F361_5557(Current);
								RTHOOK(23);
								loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
								RTHOOK(24);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
								if ((EIF_BOOLEAN)(loc1 == tw1)) {
									RTHOOK(25);
									loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								} else {
									RTHOOK(26);
									tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
									if ((EIF_BOOLEAN)(loc1 == tw1)) {
										RTHOOK(27);
										tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
										F1242_11317(RTCW(loc2), tw1);
										RTHOOK(28);
										if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
											RTHOOK(29);
											F361_5556(Current);
										}
									} else {
										RTHOOK(30);
										tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
										F1242_11317(RTCW(loc2), tw1);
										RTHOOK(31);
										tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
										F1242_11317(RTCW(loc2), tw1);
										RTHOOK(32);
										F1242_11317(RTCW(loc2), loc1);
										RTHOOK(33);
										F361_5557(Current);
									}
								}
							} else {
								RTHOOK(34);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
								F1242_11317(RTCW(loc2), tw1);
								RTHOOK(35);
								F1242_11317(RTCW(loc2), *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_));
								RTHOOK(36);
								F361_5557(Current);
							}
						} else {
							RTHOOK(37);
							F1242_11317(RTCW(loc2), *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_));
							RTHOOK(38);
							F361_5557(Current);
						}
					}
					RTHOOK(39);
					if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_))) {
						RTHOOK(40);
						tr1 = RTMS32_EX_H("c\000\000\000o\000\000\000u\000\000\000l\000\000\000d\000\000\000 \000\000\000n\000\000\000o\000\000\000t\000\000\000 \000\000\000f\000\000\000i\000\000\000n\000\000\000d\000\000\000 \000\000\000e\000\000\000n\000\000\000d\000\000\000 \000\000\000o\000\000\000f\000\000\000 \000\000\000C\000\000\000D\000\000\000A\000\000\000T\000\000\000A\000\000\000 \000\000\000c\000\000\000o\000\000\000n\000\000\000t\000\000\000e\000\000\000n\000\000\000t\000\000\000",35,1405547892);
						F362_5606(Current, tr1);
					} else {
						RTHOOK(41);
						tr1 = *(EIF_REFERENCE *)(Current);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5250[Dtype(RTCW(tr1))-355])(tr1, loc2);
					}
				} else {
					RTHOOK(42);
					tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000s\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000 \000\000\000<\000\000\000!\000\000\000[\000\000\000",18,231082587);
					tr1 = F1242_11323(tr1, loc2);
					F362_5606(Current, tr1);
				}
			}
		}
	}
	RTHOOK(43);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.parse_comment */
void F361_5535 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTEAA("parse_comment", 360, Current, 3, 0, 5657);
	RTGC;
	RTHOOK(1);
	F361_5557(Current);
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
	if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_) != tw1)) {
		RTHOOK(3);
		tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000c\000\000\000o\000\000\000m\000\000\000m\000\000\000e\000\000\000n\000\000\000t\000\000\000 \000\000\000s\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000",22,1894025080);
		F362_5606(Current, tr1);
	} else {
		RTHOOK(4);
		F361_5557(Current);
		RTHOOK(5);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
		if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_) != tw1)) {
			RTHOOK(6);
			tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000c\000\000\000o\000\000\000m\000\000\000m\000\000\000e\000\000\000n\000\000\000t\000\000\000 \000\000\000s\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000",22,1894025080);
			F362_5606(Current, tr1);
		} else {
			RTHOOK(7);
			loc2 = RTLNSMART(eif_new_type(1241, 0).id);
			F1237_11059(RTCW(loc2));
			RTHOOK(8);
			F361_5557(Current);
			for (;;) {
				RTHOOK(9);
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) || loc3) || *(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_))) break;
				RTHOOK(10);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_) == tw1)) {
					RTHOOK(11);
					F361_5557(Current);
					RTHOOK(12);
					loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
					RTHOOK(13);
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
					if ((EIF_BOOLEAN)(loc1 == tw1)) {
						RTHOOK(14);
						F361_5557(Current);
						RTHOOK(15);
						loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
						RTHOOK(16);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
						if ((EIF_BOOLEAN)(loc1 == tw1)) {
							RTHOOK(17);
							loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						} else {
							RTHOOK(18);
							tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
							if ((EIF_BOOLEAN)(loc1 == tw1)) {
								RTHOOK(19);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
								F1242_11317(RTCW(loc2), tw1);
								RTHOOK(20);
								if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
									RTHOOK(21);
									F361_5556(Current);
								}
							} else {
								RTHOOK(22);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
								F1242_11317(RTCW(loc2), tw1);
								RTHOOK(23);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
								F1242_11317(RTCW(loc2), tw1);
								RTHOOK(24);
								F1242_11317(RTCW(loc2), loc1);
								RTHOOK(25);
								if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
									RTHOOK(26);
									F361_5557(Current);
								}
							}
						}
					} else {
						RTHOOK(27);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
						F1242_11317(RTCW(loc2), tw1);
						RTHOOK(28);
						F1242_11317(RTCW(loc2), loc1);
						RTHOOK(29);
						F361_5557(Current);
					}
				} else {
					RTHOOK(30);
					F1242_11317(RTCW(loc2), *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_));
					RTHOOK(31);
					F361_5557(Current);
				}
			}
			RTHOOK(32);
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_)) {
				RTHOOK(33);
				tr1 = RTMS32_EX_H("c\000\000\000o\000\000\000u\000\000\000l\000\000\000d\000\000\000 \000\000\000n\000\000\000o\000\000\000t\000\000\000 \000\000\000f\000\000\000i\000\000\000n\000\000\000d\000\000\000 \000\000\000e\000\000\000n\000\000\000d\000\000\000 \000\000\000o\000\000\000f\000\000\000 \000\000\000c\000\000\000o\000\000\000m\000\000\000m\000\000\000e\000\000\000n\000\000\000t\000\000\000",29,1755692148);
				F362_5606(Current, tr1);
			} else {
				RTHOOK(34);
				tr1 = *(EIF_REFERENCE *)(Current);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5245[Dtype(RTCW(tr1))-355])(tr1, loc2);
			}
		}
	}
	RTHOOK(35);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.parse_doctype */
void F361_5536 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("parse_doctype", 360, Current, 5, 0, 5658);
	RTGC;
	RTHOOK(1);
	F361_5557(Current);
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'D';
	if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_) != tw1)) {
		RTHOOK(3);
		tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000s\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000 \000\000\000<\000\000\000!\000\000\000",17,1133362721);
		tr2 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1240_11190(RTCW(tr2), *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_), ((EIF_INTEGER_32) 1L));
		tr1 = F1242_11323(tr1, tr2);
		F362_5606(Current, tr1);
	} else {
		RTHOOK(4);
		loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
		RTHOOK(5);
		loc2 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1240_11189(RTCW(loc2), ((EIF_INTEGER_32) 6L));
		for (;;) {
			RTHOOK(6);
			tb1 = '\01';
			tb2 = '\01';
			if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
				tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = loc1;
				tb3 = F1188_10895(RTCW(tr1));
				tb2 = tb3;
			}
			if (!tb2) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
				tb1 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (tb1) break;
			RTHOOK(7);
			tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = loc1;
			tw1 = F1188_10883(RTCW(tr1));
			F1242_11317(RTCW(loc2), tw1);
			RTHOOK(8);
			F361_5557(Current);
			RTHOOK(9);
			loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
		}
		RTHOOK(10);
		tr1 = RTOUCR(588,F361_5586, (Current));
		tb2 = F1237_11104(RTCW(loc2), tr1);
		if (tb2) {
			RTHOOK(11);
			loc2 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F1237_11059(RTCW(loc2));
			RTHOOK(12);
			F361_5557(Current);
			for (;;) {
				RTHOOK(13);
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) || loc5) || *(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_))) break;
				RTHOOK(14);
				loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
				RTHOOK(15);
				if (loc4) {
					RTHOOK(16);
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
					if ((EIF_BOOLEAN)(loc1 == tw1)) {
						RTHOOK(17);
						loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					}
					RTHOOK(18);
					F1242_11317(RTCW(loc2), loc1);
					RTHOOK(19);
					F361_5557(Current);
				} else {
					RTHOOK(20);
					switch (loc1) {
						case (EIF_CHARACTER_8) '\"':
							RTHOOK(21);
							loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							RTHOOK(22);
							F1242_11317(RTCW(loc2), loc1);
							RTHOOK(23);
							F361_5557(Current);
							break;
						case (EIF_CHARACTER_8) '<':
							RTHOOK(24);
							loc3++;
							RTHOOK(25);
							F1242_11317(RTCW(loc2), loc1);
							RTHOOK(26);
							F361_5557(Current);
							break;
						case (EIF_CHARACTER_8) '>':
							RTHOOK(27);
							if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
								RTHOOK(28);
								loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								RTHOOK(29);
								loc3--;
								RTHOOK(30);
								F1242_11317(RTCW(loc2), loc1);
								RTHOOK(31);
								F361_5557(Current);
							}
							break;
						default:
							RTHOOK(32);
							F1242_11317(RTCW(loc2), loc1);
							RTHOOK(33);
							F361_5557(Current);
							break;
					}
				}
			}
			RTHOOK(34);
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_)) {
				RTHOOK(35);
				tr1 = RTMS32_EX_H("c\000\000\000o\000\000\000u\000\000\000l\000\000\000d\000\000\000 \000\000\000n\000\000\000o\000\000\000t\000\000\000 \000\000\000f\000\000\000i\000\000\000n\000\000\000d\000\000\000 \000\000\000e\000\000\000n\000\000\000d\000\000\000 \000\000\000o\000\000\000f\000\000\000 \000\000\000D\000\000\000O\000\000\000C\000\000\000T\000\000\000Y\000\000\000P\000\000\000E\000\000\000 \000\000\000c\000\000\000o\000\000\000n\000\000\000t\000\000\000e\000\000\000n\000\000\000t\000\000\000",37,1848231284);
				F362_5606(Current, tr1);
			} else {
				RTHOOK(36);
				{
					/* INLINED CODE (XML_STANDARD_PARSER.register_doctype) */
					/* END INLINED CODE */
				}
				;
			}
		} else {
			RTHOOK(37);
			tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000s\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000 \000\000\000<\000\000\000!\000\000\000",17,1133362721);
			tr1 = F1242_11323(tr1, loc2);
			F362_5606(Current, tr1);
		}
	}
	RTHOOK(38);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.on_xml_declaration */
void F361_5537 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Current);
	RTLR(5,arg2);
	RTLR(6,loc2);
	RTLIU(7);
	
	RTEAA("on_xml_declaration", 360, Current, 2, 3, 5659);
	RTGC;
	RTHOOK(1);
	tb1 = F1240_11221(RTCW(arg1));
	if (tb1) {
		RTHOOK(2);
		loc1 = (EIF_REFERENCE) arg1;
		RTHOOK(3);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O9759[Dtype(loc1)-1239]);
		if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 3L))) {
			RTHOOK(4);
			tb1 = '\0';
			tb2 = '\0';
			tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R9604[Dtype(RTCW(loc1))-1240])(loc1, ((EIF_INTEGER_32) 1L));
			tb3 = EIF_TEST(isdigit(tw1));
			if (tb3) {
				tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R9604[Dtype(RTCW(loc1))-1240])(loc1, ((EIF_INTEGER_32) 2L));
				tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
				tb2 = (EIF_BOOLEAN)(tw1 == tw2);
			}
			if (tb2) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O9759[Dtype(loc1)-1239]);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R9681[Dtype(RTCW(loc1))-1240])(loc1, ((EIF_INTEGER_32) 3L), ti4_1);
				tb2 = F1237_11090(RTCW(tr1));
				tb1 = tb2;
			}
			if (tb1) {
				RTHOOK(5);
				tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R9604[Dtype(RTCW(loc1))-1240])(loc1, ((EIF_INTEGER_32) 1L));
				tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '1';
				if ((EIF_BOOLEAN)(tw1 != tw2)) {
					RTHOOK(6);
					tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000s\000\000\000u\000\000\000p\000\000\000p\000\000\000o\000\000\000r\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000x\000\000\000m\000\000\000l\000\000\000 \000\000\000v\000\000\000e\000\000\000r\000\000\000s\000\000\000i\000\000\000o\000\000\000n\000\000\000 \000\000\000i\000\000\000n\000\000\000f\000\000\000o\000\000\000:\000\000\000 \000\000\000\"\000\000\000",31,1770213922);
					tr1 = F1242_11323(tr1, arg1);
					tr2 = RTMS32_EX_H("\"\000\000\000.\000\000\000",2,8750);
					tr1 = F1242_11323(RTCW(tr1), tr2);
					F362_5606(Current, tr1);
				}
			} else {
				RTHOOK(7);
				loc1 = (EIF_REFERENCE) NULL;
			}
		} else {
			RTHOOK(8);
			loc1 = (EIF_REFERENCE) NULL;
		}
	}
	RTHOOK(9);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(10);
		tr1 = RTMS32_EX_H("I\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000x\000\000\000m\000\000\000l\000\000\000 \000\000\000v\000\000\000e\000\000\000r\000\000\000s\000\000\000i\000\000\000o\000\000\000n\000\000\000 \000\000\000i\000\000\000n\000\000\000f\000\000\000o\000\000\000:\000\000\000 \000\000\000\"\000\000\000",27,1032730658);
		tr1 = F1242_11323(tr1, arg1);
		tr2 = RTMS32_EX_H("\"\000\000\000.\000\000\000",2,8750);
		tr1 = F1242_11323(RTCW(tr1), tr2);
		F362_5606(Current, tr1);
	} else {
		RTHOOK(11);
		if ((EIF_BOOLEAN)(arg2 != NULL)) {
			RTHOOK(12);
			tb1 = F1240_11221(RTCW(arg2));
			if (tb1) {
				RTHOOK(13);
				loc2 = (EIF_REFERENCE) arg2;
				RTHOOK(14);
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R9618[Dtype(RTCW(loc2))-1240])(loc2);
				if (tb1) {
					RTHOOK(15);
					loc2 = (EIF_REFERENCE) NULL;
				}
			} else {
				RTHOOK(16);
				tr1 = RTMS32_EX_H("I\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000x\000\000\000m\000\000\000l\000\000\000 \000\000\000e\000\000\000n\000\000\000c\000\000\000o\000\000\000d\000\000\000i\000\000\000n\000\000\000g\000\000\000:\000\000\000 \000\000\000\"\000\000\000",23,1382329890);
				tr1 = F1242_11323(tr1, arg2);
				tr2 = RTMS32_EX_H("\"\000\000\000.\000\000\000",2,8750);
				tr1 = F1242_11323(RTCW(tr1), tr2);
				F362_5606(Current, tr1);
			}
		}
	}
	RTHOOK(17);
	if ((EIF_BOOLEAN)(loc2 == NULL)) {
		RTHOOK(18);
		tr1 = RTOUCR(589,F361_5547, (Current));
		F361_5510(Current, tr1);
	} else {
		RTHOOK(19);
		F361_5510(Current, loc2);
	}
	RTHOOK(20);
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R5242[Dtype(RTCW(tr1))-355])(tr1, arg1, arg2, arg3);
	RTHOOK(21);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.report_error */
void F361_5538 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTEAA("report_error", 360, Current, 2, 1, 5660);
	RTGC;
	RTHOOK(1);
	loc2 = F361_5518(Current);
	RTHOOK(2);
	F362_5605(Current);
	RTHOOK(3);
	loc1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9640[Dtype(RTCW(arg1))-1240])(arg1);
	F1240_11189(RTCW(loc1), ti4_1);
	RTHOOK(4);
	F1242_11303(RTCW(loc1), arg1);
	RTHOOK(5);
	tr1 = RTLNSMART(eif_new_type(1241, 0).id);
	F1240_11191(RTCW(tr1), loc1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTHOOK(6);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_3_) == NULL)) {
		RTHOOK(7);
		RTAR(Current, loc2);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) loc2;
	}
	RTHOOK(8);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(9);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
	F1242_11317(RTCW(loc1), tw1);
	RTHOOK(10);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '(';
	F1242_11317(RTCW(loc1), tw1);
	RTHOOK(11);
	tr1 = RTMS32_EX_H("p\000\000\000o\000\000\000s\000\000\000i\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000=\000\000\000",9,2064843837);
	F1242_11306(RTCW(loc1), tr1);
	RTHOOK(12);
	tr1 = F1298_12357(RTCW(loc2));
	F1242_11306(RTCW(loc1), tr1);
	RTHOOK(13);
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5243[Dtype(RTCW(tr1))-355])(tr1, loc1);
	RTHOOK(15);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.report_warning */
void F361_5539 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("report_warning", 360, Current, 1, 1, 5661);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9759[Dtype(arg1)-1239]);
	F1240_11189(RTCW(loc1), ti4_1);
	RTHOOK(2);
	F1242_11303(RTCW(loc1), arg1);
	RTHOOK(3);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc1;
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.report_truncated_content */
void F361_5540 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("report_truncated_content", 360, Current, 0, 1, 5662);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_2_)) {
	} else {
		RTHOOK(2);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_5_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(3);
		if ((EIF_BOOLEAN)(arg1 != NULL)) {
			RTHOOK(4);
			tr1 = RTMS32_EX_H("E\000\000\000n\000\000\000d\000\000\000 \000\000\000o\000\000\000f\000\000\000 \000\000\000i\000\000\000n\000\000\000p\000\000\000u\000\000\000t\000\000\000:\000\000\000 \000\000\000",14,500258080);
			tr2 = F1237_11119(RTCW(arg1));
			tr1 = F1242_11323(tr1, tr2);
			F361_5539(Current, tr1);
		} else {
			RTHOOK(5);
			tr1 = RTMS32_EX_H("E\000\000\000n\000\000\000d\000\000\000 \000\000\000o\000\000\000f\000\000\000 \000\000\000i\000\000\000n\000\000\000p\000\000\000u\000\000\000t\000\000\000.\000\000\000",13,446549550);
			F361_5539(Current, tr1);
		}
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.report_syntax_error */
void F361_5541 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("report_syntax_error", 360, Current, 0, 1, 5663);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		tr1 = RTMS32_EX_H("S\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000 \000\000\000e\000\000\000r\000\000\000r\000\000\000o\000\000\000r\000\000\000:\000\000\000 \000\000\000",14,1046907424);
		tr2 = F1237_11119(RTCW(arg1));
		tr1 = F1242_11323(tr1, tr2);
		F361_5539(Current, tr1);
	} else {
		RTHOOK(3);
		tr1 = RTMS32_EX_H("S\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000 \000\000\000e\000\000\000r\000\000\000r\000\000\000o\000\000\000r\000\000\000.\000\000\000",13,1480481838);
		F362_5606(Current, tr1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.report_unsupported_bom_value */
void F361_5542 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,tr2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("report_unsupported_bom_value", 360, Current, 0, 1, 5572);
	RTGC;
	RTHOOK(1);
	tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000s\000\000\000u\000\000\000p\000\000\000p\000\000\000o\000\000\000r\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000B\000\000\000O\000\000\000M\000\000\000 \000\000\000v\000\000\000a\000\000\000l\000\000\000u\000\000\000e\000\000\000 \000\000\000\"\000\000\000",23,1980359714);
	tr2 = F1237_11119(RTCW(arg1));
	tr1 = F1242_11323(tr1, tr2);
	tr2 = RTMS32_EX_H("\"\000\000\000.\000\000\000",2,8750);
	tr1 = F1242_11323(RTCW(tr1), tr2);
	F362_5606(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.report_missing_attribute_value */
void F361_5543 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("report_missing_attribute_value", 360, Current, 0, 2, 5573);
	RTGC;
	RTHOOK(1);
	tr1 = RTMS32_EX_H("A\000\000\000t\000\000\000t\000\000\000r\000\000\000i\000\000\000b\000\000\000u\000\000\000t\000\000\000e\000\000\000s\000\000\000 \000\000\000w\000\000\000i\000\000\000t\000\000\000h\000\000\000o\000\000\000u\000\000\000t\000\000\000 \000\000\000a\000\000\000n\000\000\000y\000\000\000 \000\000\000v\000\000\000a\000\000\000l\000\000\000u\000\000\000e\000\000\000 \000\000\000a\000\000\000r\000\000\000e\000\000\000 \000\000\000f\000\000\000o\000\000\000r\000\000\000b\000\000\000i\000\000\000d\000\000\000d\000\000\000e\000\000\000n\000\000\000",42,1447267438);
	F362_5606(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.report_unexpected_content */
void F361_5544 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("report_unexpected_content", 360, Current, 0, 1, 5574);
	RTGC;
	RTHOOK(1);
	tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000o\000\000\000n\000\000\000t\000\000\000e\000\000\000n\000\000\000t\000\000\000 \000\000\000(\000\000\000n\000\000\000o\000\000\000t\000\000\000 \000\000\000w\000\000\000e\000\000\000l\000\000\000l\000\000\000-\000\000\000f\000\000\000o\000\000\000r\000\000\000m\000\000\000e\000\000\000d\000\000\000 \000\000\000X\000\000\000M\000\000\000L\000\000\000)\000\000\000",40,1259693865);
	F362_5606(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.report_unexpected_content_in_prolog */
void F361_5545 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("report_unexpected_content_in_prolog", 360, Current, 0, 1, 5575);
	RTGC;
	RTHOOK(1);
	tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000o\000\000\000n\000\000\000t\000\000\000e\000\000\000n\000\000\000t\000\000\000 \000\000\000i\000\000\000n\000\000\000 \000\000\000p\000\000\000r\000\000\000o\000\000\000l\000\000\000o\000\000\000g\000\000\000 \000\000\000(\000\000\000n\000\000\000o\000\000\000t\000\000\000 \000\000\000w\000\000\000e\000\000\000l\000\000\000l\000\000\000-\000\000\000f\000\000\000o\000\000\000r\000\000\000m\000\000\000e\000\000\000d\000\000\000 \000\000\000X\000\000\000M\000\000\000L\000\000\000)\000\000\000",50,176380713);
	F362_5606(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.set_encoding_from_bom */
void F361_5546 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	struct eif_ex_79 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(85, 0x00).id);
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("set_encoding_from_bom", 360, Current, 1, 1, 5576);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(46,F86_1531, (RTCW(loc1)));
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R9646[Dtype(RTCW(arg1))-1240])(arg1, tr1);
	if (tb1) {
		RTHOOK(2);
		tr1 = RTMS_EX_H("UTF-8",5,1414538040);
		F361_5510(Current, tr1);
	} else {
		RTHOOK(3);
		F361_5542(Current, arg1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.default_encoding */

EIF_REFERENCE F361_5547 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (589,RTMS32_EX_H("U\000\000\000T\000\000\000F\000\000\000-\000\000\0008\000\000\000",5,1414538040));
}

/* {XML_STANDARD_PARSER}.bom */
EIF_REFERENCE F361_5548 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("bom", 360, Current, 3, 1, 5578);
	RTGC;
	RTHOOK(1);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9759[Dtype(arg1)-1239]);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 0L))) {
	} else {
		RTHOOK(3);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			RTHOOK(4);
			tb1 = '\01';
			if (!(EIF_BOOLEAN) (loc1 > loc2)) {
				tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R9604[Dtype(RTCW(arg1))-1240])(arg1, loc1);
				tb1 = (EIF_BOOLEAN) !F361_5549(Current, tw1);
			}
			if (tb1) break;
			RTHOOK(5);
			loc1++;
		}
		RTHOOK(6);
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 1L))) {
			RTHOOK(7);
			loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R9681[Dtype(RTCW(arg1))-1240])(arg1, ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
			RTHOOK(8);
			tb2 = F1240_11221(RTCW(loc3));
			if (tb2) {
				RTHOOK(9);
				tr1 = F1237_11112(RTCW(loc3));
				RTHOOK(10);
				RTLE;
				RTEE;
				return (EIF_REFERENCE) tr1;
			}
		}
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {XML_STANDARD_PARSER}.is_bom_character */
EIF_BOOLEAN F361_5549 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_bom_character", 360, Current, 0, 1, 5579);
	RTGC;
	RTHOOK(1);
	switch (arg1) {
		case (EIF_CHARACTER_8) '\273':
		case (EIF_CHARACTER_8) '\277':
		case (EIF_CHARACTER_8) '\357':
			RTHOOK(2);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			break;
		case (EIF_CHARACTER_8) '\376':
		case (EIF_CHARACTER_8) '\377':
			RTHOOK(3);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			break;
		case (EIF_CHARACTER_8) '\000':
			RTHOOK(4);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			break;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STANDARD_PARSER}.new_encoded_buffer */
EIF_REFERENCE F361_5550 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("new_encoded_buffer", 360, Current, 0, 2, 5580);
	RTGC;
	RTHOOK(1);
	tr1 = RTMS_EX_H("UTF-8",5,1414538040);
	tb1 = F1237_11101(RTCW(arg1), tr1);
	if (tb1) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(368, 0x00).id, 368, _OBJSIZ_1_0_0_1_0_0_0_0_);
		F369_5694(RTCW(tr1), arg2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(4);
		tr1 = RTMS_EX_H("ISO-8859-1",10,1255164721);
		tb1 = F1237_11101(RTCW(arg1), tr1);
		if (tb1) {
			RTHOOK(5);
			RTHOOK(6);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) arg2;
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {XML_STANDARD_PARSER}.register_doctype */
void F361_5551 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("register_doctype", 360, Current, 0, 1, 5581);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.report_error_from_callback */
void F361_5552 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("report_error_from_callback", 360, Current, 0, 1, 5582);
	RTHOOK(1);
	F362_5606(Current, arg1);
	RTHOOK(2);
	RTEE;
}

/* {XML_STANDARD_PARSER}.rewind_character */
void F361_5556 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("rewind_character", 360, Current, 0, 0, 5586);
	RTHOOK(1);
	*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_1_) = (EIF_CHARACTER_32) *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
	RTHOOK(3);
	RTEE;
}

/* {XML_STANDARD_PARSER}.read_character */
void F361_5557 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("read_character", 360, Current, 1, 0, 5587);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_1_);
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(loc1 == tw1)) {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5409[Dtype(RTCW(tr1))-368])(tr1);
		if (tb1) {
			RTHOOK(4);
			tr1 = RTMS32_EX_H("N\000\000\000o\000\000\000 \000\000\000m\000\000\000o\000\000\000r\000\000\000e\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000s\000\000\000",18,147221875);
			F362_5606(Current, tr1);
		} else {
			RTHOOK(5);
			loc1 = F361_5558(Current, *(EIF_REFERENCE *)(Current + _REFACS_2_));
		}
	} else {
		RTHOOK(6);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_1_) = (EIF_CHARACTER_32) tw1;
		RTHOOK(7);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5409[Dtype(RTCW(tr1))-368])(tr1);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) = (EIF_BOOLEAN) tb1;
	}
	RTHOOK(8);
	*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_) = (EIF_CHARACTER_32) loc1;
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.internal_next_character */
EIF_CHARACTER_32 F361_5558 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc2 = (EIF_NATURAL_32) 0;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("internal_next_character", 360, Current, 2, 1, 5588);
	RTGC;
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5415[Dtype(RTCW(arg1))-368])(arg1);
	RTHOOK(2);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5409[Dtype(RTCW(arg1))-368])(arg1);
	if (tb1) {
		RTHOOK(3);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(4);
		loc1 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	} else {
		RTHOOK(5);
		loc2 = RTOUCB(EIF_NATURAL_32,590,F361_5593, (Current));
		RTHOOK(6);
		loc1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE)) R5414[Dtype(RTCW(arg1))-368])(arg1);
		RTHOOK(7);
		if ((EIF_BOOLEAN)(loc1 == loc2)) {
			for (;;) {
				RTHOOK(8);
				tb1 = '\01';
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5409[Dtype(RTCW(arg1))-368])(arg1);
				if (!tb2) {
					tb1 = (EIF_BOOLEAN)(loc1 != loc2);
				}
				if (tb1) break;
				RTHOOK(9);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R5415[Dtype(RTCW(arg1))-368])(arg1);
				RTHOOK(10);
				loc1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE)) R5414[Dtype(RTCW(arg1))-368])(arg1);
			}
			RTHOOK(11);
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5409[Dtype(RTCW(arg1))-368])(arg1);
			if (tb2) {
				RTHOOK(12);
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5409[Dtype(RTCW(arg1))-368])(arg1);
				*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) = (EIF_BOOLEAN) tb2;
				RTHOOK(13);
				loc1 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
			}
		}
		RTHOOK(14);
		tw1 = (EIF_CHARACTER_32) loc1;
		RTHOOK(15);
		RTLE;
		RTEE;
		return (EIF_CHARACTER_32) tw1;
	}
	RTHOOK(17);
	RTLE;
	RTEE;
	return (EIF_CHARACTER_32) 0;
}

/* {XML_STANDARD_PARSER}.read_until_non_space_character */
void F361_5559 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("read_until_non_space_character", 360, Current, 1, 0, 5589);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
		RTHOOK(2);
		tr1 = RTMS_EX_H("Out of Input data.",18,2026462766);
		F362_5606(Current, tr1);
		
	} else {
		RTHOOK(4);
		F361_5557(Current);
		RTHOOK(5);
		loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
		for (;;) {
			RTHOOK(6);
			tb1 = '\01';
			if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
				tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = loc1;
				tb2 = F1188_10895(RTCW(tr1));
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) break;
			RTHOOK(7);
			F361_5557(Current);
			RTHOOK(8);
			loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
		}
		RTHOOK(9);
		*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_) = (EIF_CHARACTER_32) loc1;
	}
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.next_tag */
EIF_REFERENCE F361_5560 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("next_tag", 360, Current, 3, 0, 5590);
	RTGC;
	RTHOOK(1);
	loc3 = F361_5578(Current);
	RTHOOK(2);
	F361_5559(Current);
	RTHOOK(3);
	loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
	RTHOOK(4);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
		RTHOOK(5);
		tr1 = RTMS_EX_H("Can not find tag name",21,636553317);
		F361_5540(Current, tr1);
	} else {
		RTHOOK(6);
		if (F361_5569(Current, loc1)) {
			for (;;) {
				RTHOOK(7);
				tb1 = '\01';
				if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
					tb1 = (EIF_BOOLEAN) !F361_5570(Current, loc1);
				}
				if (tb1) break;
				RTHOOK(8);
				tb2 = '\0';
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
				if ((EIF_BOOLEAN)(loc1 == tw1)) {
					tb2 = (EIF_BOOLEAN)(loc2 == NULL);
				}
				if (tb2) {
					RTHOOK(9);
					loc2 = F1240_11204(RTCW(loc3));
					RTHOOK(10);
					F1242_11333(RTCW(loc3));
				} else {
					RTHOOK(11);
					F1242_11317(RTCW(loc3), loc1);
				}
				RTHOOK(12);
				F361_5557(Current);
				RTHOOK(13);
				loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
			}
		}
	}
	RTHOOK(14);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1186,1241,1241,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = loc2;
	RTAR(tr1,loc2);
	tr2 = F1240_11204(RTCW(loc3));
	((EIF_TYPED_VALUE *)tr1+2)->it_r = tr2;
	RTAR(tr1,tr2);
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(15);
	F1242_11333(RTCW(loc3));
	RTHOOK(17);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STANDARD_PARSER}.next_entity */
EIF_REFERENCE F361_5561 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("next_entity", 360, Current, 4, 0, 5591);
	RTGC;
	RTHOOK(1);
	loc4 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1237_11059(RTCW(loc4));
	RTHOOK(2);
	F361_5557(Current);
	RTHOOK(3);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '#';
	if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_) == tw1)) {
		RTHOOK(4);
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(5);
		F361_5557(Current);
		RTHOOK(6);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'x';
		if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_) == tw1)) {
			RTHOOK(7);
			loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			RTHOOK(8);
			F361_5557(Current);
		}
	}
	RTHOOK(9);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
		
		RTHOOK(11);
		tr1 = RTMS32_EX_H("I\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000e\000\000\000n\000\000\000t\000\000\000i\000\000\000t\000\000\000y\000\000\000 \000\000\000s\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000",21,1738705016);
		F362_5606(Current, tr1);
		RTHOOK(12);
		Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_1_0_2_);
		F1240_11189(RTCW(Result), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 3L)));
		RTHOOK(13);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
		F1242_11317(RTCW(Result), tw1);
		RTHOOK(14);
		if (loc2) {
			RTHOOK(15);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '#';
			F1242_11317(RTCW(Result), tw1);
			RTHOOK(16);
			if (loc3) {
				RTHOOK(17);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'x';
				F1242_11317(RTCW(Result), tw1);
			}
		}
		RTHOOK(18);
		F1242_11306(RTCW(Result), loc4);
	} else {
		RTHOOK(19);
		loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
		RTHOOK(20);
		if (loc2) {
			RTHOOK(21);
			if (loc3) {
				for (;;) {
					RTHOOK(22);
					tb1 = '\01';
					tb2 = '\01';
					if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
						tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
						*(EIF_CHARACTER_32 *)tr1 = loc1;
						tb3 = F1188_10894(RTCW(tr1));
						tb2 = (EIF_BOOLEAN) !tb3;
					}
					if (!tb2) {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ';';
						tb1 = (EIF_BOOLEAN)(loc1 == tw1);
					}
					if (tb1) break;
					RTHOOK(23);
					F1242_11317(RTCW(loc4), loc1);
					RTHOOK(24);
					F361_5557(Current);
					RTHOOK(25);
					loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
				}
			} else {
				for (;;) {
					RTHOOK(26);
					tb2 = '\01';
					tb3 = '\01';
					if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
						tb4 = EIF_TEST(isdigit(loc1));
						tb3 = (EIF_BOOLEAN) !tb4;
					}
					if (!tb3) {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ';';
						tb2 = (EIF_BOOLEAN)(loc1 == tw1);
					}
					if (tb2) break;
					RTHOOK(27);
					F1242_11317(RTCW(loc4), loc1);
					RTHOOK(28);
					F361_5557(Current);
					RTHOOK(29);
					loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
				}
			}
		} else {
			for (;;) {
				RTHOOK(30);
				tb3 = '\01';
				tb4 = '\01';
				if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
					tb4 = (EIF_BOOLEAN) !F361_5571(Current, loc1);
				}
				if (!tb4) {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ';';
					tb3 = (EIF_BOOLEAN)(loc1 == tw1);
				}
				if (tb3) break;
				RTHOOK(31);
				F1242_11317(RTCW(loc4), loc1);
				RTHOOK(32);
				F361_5557(Current);
				RTHOOK(33);
				loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
			}
		}
		RTHOOK(34);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ';';
		if ((EIF_BOOLEAN)(loc1 == tw1)) {
			RTHOOK(35);
			if (loc2) {
				RTHOOK(36);
				if (loc3) {
					RTHOOK(37);
					Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F1240_11189(RTCW(Result), ((EIF_INTEGER_32) 1L));
					RTHOOK(38);
					tu4_1 = F361_5567(Current, loc4);
					F1239_11159(RTCW(Result), tu4_1);
				} else {
					RTHOOK(39);
					tb4 = F1237_11090(RTCW(loc4));
					if (tb4) {
						RTHOOK(40);
						Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
						F1240_11189(RTCW(Result), ((EIF_INTEGER_32) 1L));
						RTHOOK(41);
						tu4_1 = F1237_11130(RTCW(loc4));
						F1239_11159(RTCW(Result), tu4_1);
					} else {
						RTHOOK(42);
						Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_1_0_2_);
						F1240_11189(RTCW(Result), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 2L)));
						RTHOOK(43);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
						F1242_11317(RTCW(Result), tw1);
						RTHOOK(44);
						F1242_11306(RTCW(Result), loc4);
						RTHOOK(45);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ';';
						F1242_11317(RTCW(Result), tw1);
					}
				}
			} else {
				RTHOOK(46);
				Result = F361_5566(Current, loc4);
				RTHOOK(47);
				RTLE;
				RTEE;
				return (EIF_REFERENCE) Result;
			}
		} else {
			RTHOOK(48);
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
				RTHOOK(49);
				Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_1_0_2_);
				F1240_11189(RTCW(Result), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 3L)));
				RTHOOK(50);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
				F1242_11317(RTCW(Result), tw1);
				RTHOOK(51);
				if (loc2) {
					RTHOOK(52);
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '#';
					F1242_11317(RTCW(Result), tw1);
					RTHOOK(53);
					if (loc3) {
						RTHOOK(54);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'x';
						F1242_11317(RTCW(Result), tw1);
					}
				}
				RTHOOK(55);
				F1242_11306(RTCW(Result), loc4);
				RTHOOK(56);
				tr1 = RTMS32_EX_H("I\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000e\000\000\000n\000\000\000t\000\000\000i\000\000\000t\000\000\000y\000\000\000 \000\000\000s\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000 \000\000\000",22,580163872);
				tr1 = F1242_11323(tr1, loc4);
				F362_5606(Current, tr1);
			} else {
				RTHOOK(57);
				F361_5556(Current);
				RTHOOK(58);
				Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_1_0_2_);
				F1240_11189(RTCW(Result), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 3L)));
				RTHOOK(59);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
				F1242_11317(RTCW(Result), tw1);
				RTHOOK(60);
				if (loc2) {
					RTHOOK(61);
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '#';
					F1242_11317(RTCW(Result), tw1);
					RTHOOK(62);
					if (loc3) {
						RTHOOK(63);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'x';
						F1242_11317(RTCW(Result), tw1);
					}
				}
				RTHOOK(64);
				F1242_11306(RTCW(Result), loc4);
				RTHOOK(65);
				tr1 = RTMS32_EX_H("I\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000e\000\000\000n\000\000\000t\000\000\000i\000\000\000t\000\000\000y\000\000\000 \000\000\000s\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000 \000\000\000",22,580163872);
				tr1 = F1242_11323(tr1, loc4);
				F362_5606(Current, tr1);
			}
		}
	}
	RTHOOK(66);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STANDARD_PARSER}.next_attribute_name */
EIF_REFERENCE F361_5562 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLIU(5);
	
	RTEAA("next_attribute_name", 360, Current, 3, 0, 5592);
	RTGC;
	RTHOOK(1);
	loc2 = F361_5579(Current);
	RTHOOK(2);
	F361_5559(Current);
	RTHOOK(3);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
		RTHOOK(4);
		tr1 = RTMS_EX_H("no tag closure",14,1150800997);
		F361_5540(Current, tr1);
	} else {
		RTHOOK(5);
		loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
		RTHOOK(6);
		if (F361_5572(Current, loc1)) {
			RTHOOK(7);
			F1242_11317(RTCW(loc2), loc1);
			RTHOOK(8);
			F361_5557(Current);
			RTHOOK(9);
			loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
			for (;;) {
				RTHOOK(10);
				tb1 = '\01';
				if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
					tb1 = (EIF_BOOLEAN) !F361_5573(Current, loc1);
				}
				if (tb1) break;
				RTHOOK(11);
				F1242_11317(RTCW(loc2), loc1);
				RTHOOK(12);
				F361_5557(Current);
				RTHOOK(13);
				loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
			}
		}
	}
	RTHOOK(14);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
	loc3 = F1240_11201(RTCW(loc2), tw1, ((EIF_INTEGER_32) 1L));
	RTHOOK(15);
	if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 1L))) {
		RTHOOK(16);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1186,1241,1241,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		tr2 = F1242_11351(RTCW(loc2), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L)));
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
		tr2 = F1242_11351(RTCW(loc2), (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)), ti4_1);
		((EIF_TYPED_VALUE *)tr1+2)->it_r = tr2;
		RTAR(tr1,tr2);
		Result = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(17);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1186,65534,1241,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		tr2 = F1240_11204(RTCW(loc2));
		((EIF_TYPED_VALUE *)tr1+2)->it_r = tr2;
		RTAR(tr1,tr2);
		Result = (EIF_REFERENCE) tr1;
	}
	RTHOOK(18);
	F1242_11333(RTCW(loc2));
	RTHOOK(20);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STANDARD_PARSER}.next_attribute_value */
EIF_REFERENCE F361_5563 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("next_attribute_value", 360, Current, 5, 0, 5593);
	RTGC;
	RTHOOK(1);
	loc5 = F361_5580(Current);
	RTHOOK(2);
	F361_5557(Current);
	RTHOOK(3);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
		RTHOOK(4);
		tr1 = RTMS_EX_H("No attribute value",18,1751605349);
		F361_5540(Current, tr1);
	} else {
		RTHOOK(5);
		loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
		RTHOOK(6);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
		if ((EIF_BOOLEAN)(loc1 == tw1)) {
			RTHOOK(7);
			loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			RTHOOK(8);
			F361_5557(Current);
			RTHOOK(9);
			loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
		} else {
			RTHOOK(10);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\'';
			if ((EIF_BOOLEAN)(loc1 == tw1)) {
				RTHOOK(11);
				loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				RTHOOK(12);
				F361_5557(Current);
				RTHOOK(13);
				loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
			} else {
				RTHOOK(14);
				tb1 = '\01';
				tb2 = '\01';
				tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = loc1;
				tb3 = F1188_10895(RTCW(tr1));
				if (!tb3) {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '/';
					tb2 = (EIF_BOOLEAN)(loc1 == tw1);
				}
				if (!tb2) {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
					tb1 = (EIF_BOOLEAN)(loc1 == tw1);
				}
				if (tb1) {
					RTHOOK(15);
					tr1 = RTMS32_EX_H("u\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000s\000\000\000p\000\000\000a\000\000\000c\000\000\000e\000\000\000 \000\000\000a\000\000\000f\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000=\000\000\000 \000\000\000i\000\000\000n\000\000\000 \000\000\000a\000\000\000t\000\000\000t\000\000\000r\000\000\000i\000\000\000b\000\000\000u\000\000\000t\000\000\000e\000\000\000 \000\000\000d\000\000\000e\000\000\000c\000\000\000l\000\000\000a\000\000\000r\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",49,1583729262);
					F362_5606(Current, tr1);
				}
			}
		}
	}
	RTHOOK(16);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
		RTHOOK(17);
		tr1 = RTMS_EX_H("No attribute value",18,1751605349);
		F361_5540(Current, tr1);
	} else {
		RTHOOK(18);
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_)) {
			RTHOOK(19);
			loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			for (;;) {
				RTHOOK(20);
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) || loc4) || *(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_))) break;
				RTHOOK(21);
				tb1 = '\0';
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc2 && (EIF_BOOLEAN) !loc3)) {
					tb2 = '\01';
					tb3 = '\01';
					tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
					*(EIF_CHARACTER_32 *)tr1 = loc1;
					tb4 = F1188_10895(RTCW(tr1));
					if (!tb4) {
						tb3 = (EIF_BOOLEAN)(loc1 == (EIF_CHARACTER_32) 47U);
					}
					if (!tb3) {
						tb2 = (EIF_BOOLEAN)(loc1 == (EIF_CHARACTER_32) 62U);
					}
					tb1 = tb2;
				}
				if (tb1) {
					RTHOOK(22);
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					RTHOOK(23);
					switch (loc1) {
						case (EIF_CHARACTER_8) '&':
							RTHOOK(24);
							tr1 = F361_5561(Current);
							F1242_11306(RTCW(loc5), tr1);
							break;
						case (EIF_CHARACTER_8) '\"':
							RTHOOK(25);
							if (loc2) {
								RTHOOK(26);
								loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								RTHOOK(27);
								if (loc3) {
									RTHOOK(28);
									F1242_11317(RTCW(loc5), loc1);
								} else {
									RTHOOK(29);
									tr1 = RTMS32_EX_H("u\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000\"\000\000\000 \000\000\000i\000\000\000n\000\000\000 \000\000\000a\000\000\000t\000\000\000t\000\000\000r\000\000\000i\000\000\000b\000\000\000u\000\000\000t\000\000\000e\000\000\000 \000\000\000v\000\000\000a\000\000\000l\000\000\000u\000\000\000e\000\000\000",31,571762533);
									F362_5606(Current, tr1);
								}
							}
							break;
						case (EIF_CHARACTER_8) '\'':
							RTHOOK(30);
							if (loc3) {
								RTHOOK(31);
								loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								RTHOOK(32);
								if (loc2) {
									RTHOOK(33);
									F1242_11317(RTCW(loc5), loc1);
								} else {
									RTHOOK(34);
									tr1 = RTMS32_EX_H("u\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000\'\000\000\000 \000\000\000i\000\000\000n\000\000\000 \000\000\000a\000\000\000t\000\000\000t\000\000\000r\000\000\000i\000\000\000b\000\000\000u\000\000\000t\000\000\000e\000\000\000 \000\000\000v\000\000\000a\000\000\000l\000\000\000u\000\000\000e\000\000\000",31,1685525861);
									F362_5606(Current, tr1);
								}
							}
							break;
						default:
							RTHOOK(35);
							F1242_11317(RTCW(loc5), loc1);
							break;
					}
					RTHOOK(36);
					if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
						RTHOOK(37);
						F361_5557(Current);
					}
					RTHOOK(38);
					loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
				}
			}
			RTHOOK(39);
			if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_))) {
				RTHOOK(40);
				if (loc4) {
					RTHOOK(41);
					Result = F1240_11204(RTCW(loc5));
				} else {
					RTHOOK(42);
					tr1 = RTMS_EX_H("attribute value is truncated",28,1727624804);
					F361_5540(Current, tr1);
				}
			} else {
				RTHOOK(43);
				Result = F1240_11204(RTCW(loc5));
			}
		}
	}
	RTHOOK(44);
	F1242_11333(RTCW(loc5));
	RTHOOK(46);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STANDARD_PARSER}.next_attribute_data */
EIF_REFERENCE F361_5564 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc6);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc3);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,Result);
	RTLR(7,loc4);
	RTLIU(8);
	
	RTEAA("next_attribute_data", 360, Current, 6, 0, 5594);
	RTGC;
	RTHOOK(1);
	loc6 = F361_5562(Current);
	RTHOOK(2);
	loc2 = eif_boxed_item(loc6,2);
	RTHOOK(3);
	loc3 = eif_boxed_item(loc6,1);
	RTHOOK(4);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R9618[Dtype(RTCW(loc2))-1240])(loc2);
	if (tb1) {
		RTHOOK(5);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
			RTHOOK(6);
			tr1 = RTMS_EX_H("in start tag declaration",24,735103342);
			F361_5540(Current, tr1);
		} else {
			RTHOOK(7);
			loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
			RTHOOK(8);
			tb1 = '\01';
			tb2 = '\01';
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
			if (!(EIF_BOOLEAN)(loc1 == tw1)) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '/';
				tb2 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb2) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\?';
				tb1 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (tb1) {
			} else {
				RTHOOK(9);
				tr1 = RTMS_EX_H("Error with attribute declaration.",33,49419310);
				F362_5606(Current, tr1);
			}
		}
	} else {
		RTHOOK(10);
		F362_5604(Current);
		RTHOOK(11);
		loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
		RTHOOK(12);
		tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)tr1 = loc1;
		tb1 = F1188_10895(RTCW(tr1));
		if (tb1) {
			RTHOOK(13);
			loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			RTHOOK(14);
			F361_5559(Current);
			RTHOOK(15);
			loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
		}
		RTHOOK(16);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
			RTHOOK(17);
			tr1 = RTMS_EX_H("only attribute name",19,354778725);
			F361_5540(Current, tr1);
		} else {
			RTHOOK(18);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '=';
			if ((EIF_BOOLEAN)(loc1 == tw1)) {
				RTHOOK(19);
				F362_5605(Current);
			} else {
				RTHOOK(20);
				tb1 = '\01';
				tb2 = '\01';
				if (!loc5) {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
					tb2 = (EIF_BOOLEAN)(loc1 == tw1);
				}
				if (!tb2) {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '/';
					tb1 = (EIF_BOOLEAN)(loc1 == tw1);
				}
				if (tb1) {
					RTHOOK(21);
					F361_5543(Current, loc3, loc2);
					RTHOOK(22);
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,1186,1239,1239,1241,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr1 = RTLNTS(typres0.id, 4, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = loc3;
					RTAR(tr1,loc3);
					((EIF_TYPED_VALUE *)tr1+2)->it_r = loc2;
					RTAR(tr1,loc2);
					tr2 = RTMS32_EX_H("",0,0);
					((EIF_TYPED_VALUE *)tr1+3)->it_r = tr2;
					RTAR(tr1,tr2);
					Result = (EIF_REFERENCE) tr1;
				} else {
					RTHOOK(23);
					tr1 = RTMS32_EX_H("u\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000\'\000\000\000",22,169384743);
					tr2 = F361_5565(Current, loc1);
					tr1 = F1242_11323(tr1, tr2);
					tr2 = RTMS32_EX_H("\'\000\000\000 \000\000\000i\000\000\000n\000\000\000 \000\000\000a\000\000\000t\000\000\000t\000\000\000r\000\000\000i\000\000\000b\000\000\000u\000\000\000t\000\000\000e\000\000\000 \000\000\000n\000\000\000a\000\000\000m\000\000\000e\000\000\000",19,886221413);
					tr1 = F1242_11323(RTCW(tr1), tr2);
					F362_5606(Current, tr1);
				}
			}
			RTHOOK(24);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == NULL) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_))) {
				
				RTHOOK(26);
				F362_5604(Current);
				RTHOOK(27);
				F361_5557(Current);
				RTHOOK(28);
				loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
				RTHOOK(29);
				tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = loc1;
				tb1 = F1188_10895(RTCW(tr1));
				if (tb1) {
					RTHOOK(30);
					F361_5559(Current);
					RTHOOK(31);
					loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
				}
				RTHOOK(32);
				if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
					RTHOOK(33);
					tr1 = RTMS_EX_H("expecting attribute value after = sign",38,1641746030);
					F361_5540(Current, tr1);
				} else {
					RTHOOK(34);
					F361_5556(Current);
					RTHOOK(35);
					loc4 = F361_5563(Current);
					RTHOOK(36);
					if ((EIF_BOOLEAN)(loc4 == NULL)) {
						RTHOOK(37);
						if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_))) {
						} else {
							RTHOOK(38);
							tr1 = RTMS_EX_H("expecting valid attribute value",31,1278772069);
							F361_5541(Current, tr1);
						}
					} else {
						RTHOOK(39);
						F362_5605(Current);
						RTHOOK(40);
						{
							static EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,1186,1239,1239,1239,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr1 = RTLNTS(typres0.id, 4, 0);
						}
						((EIF_TYPED_VALUE *)tr1+1)->it_r = loc3;
						RTAR(tr1,loc3);
						((EIF_TYPED_VALUE *)tr1+2)->it_r = loc2;
						RTAR(tr1,loc2);
						((EIF_TYPED_VALUE *)tr1+3)->it_r = loc4;
						RTAR(tr1,loc4);
						Result = (EIF_REFERENCE) tr1;
						RTHOOK(41);
						if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
							RTHOOK(42);
							tr1 = RTMS_EX_H("in start tag declaration",24,735103342);
							F361_5540(Current, tr1);
						} else {
							RTHOOK(43);
							loc1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_);
							RTHOOK(44);
							tb1 = '\01';
							tb2 = '\01';
							tb3 = '\01';
							tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
							*(EIF_CHARACTER_32 *)tr1 = loc1;
							tb4 = F1188_10895(RTCW(tr1));
							if (!tb4) {
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
								tb3 = (EIF_BOOLEAN)(loc1 == tw1);
							}
							if (!tb3) {
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '/';
								tb2 = (EIF_BOOLEAN)(loc1 == tw1);
							}
							if (!tb2) {
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\?';
								tb1 = (EIF_BOOLEAN)(loc1 == tw1);
							}
							if (tb1) {
							} else {
								RTHOOK(45);
								tr1 = RTMS32_EX_H("u\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000\'\000\000\000",22,169384743);
								tr2 = F361_5565(Current, *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_5_5_0_0_));
								tr1 = F1242_11323(tr1, tr2);
								tr2 = RTMS32_EX_H("\'\000\000\000 \000\000\000a\000\000\000f\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000a\000\000\000t\000\000\000t\000\000\000r\000\000\000i\000\000\000b\000\000\000u\000\000\000t\000\000\000e\000\000\000 \000\000\000d\000\000\000e\000\000\000c\000\000\000l\000\000\000a\000\000\000r\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000 \000\000\000(\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000w\000\000\000h\000\000\000i\000\000\000t\000\000\000e\000\000\000 \000\000\000s\000\000\000p\000\000\000a\000\000\000c\000\000\000e\000\000\000 \000\000\000o\000\000\000r\000\000\000 \000\000\000\'\000\000\000>\000\000\000\'\000\000\000 \000\000\000o\000\000\000r\000\000\000 \000\000\000\'\000\000\000/\000\000\000\'\000\000\000 \000\000\000o\000\000\000r\000\000\000 \000\000\000\'\000\000\000\?\000\000\000\'\000\000\000 \000\000\000)\000\000\000",75,395492393);
								tr1 = F1242_11323(RTCW(tr1), tr2);
								F362_5606(Current, tr1);
							}
						}
					}
				}
			}
		}
	}
	RTHOOK(47);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STANDARD_PARSER}.character_output */
EIF_REFERENCE F361_5565 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 tu4_1;
	EIF_CHARACTER_32 tw1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("character_output", 360, Current, 0, 1, 5595);
	RTGC;
	RTHOOK(1);
	switch (arg1) {
		case (EIF_CHARACTER_8) '\000':
			RTHOOK(2);
			Result = RTMS32_EX_H("%\000\000\000U\000\000\000",2,9557);
			break;
		case (EIF_CHARACTER_8) '\011':
			RTHOOK(3);
			Result = RTMS32_EX_H("%\000\000\000T\000\000\000",2,9556);
			break;
		case (EIF_CHARACTER_8) '\012':
			RTHOOK(4);
			Result = RTMS32_EX_H("%\000\000\000N\000\000\000",2,9550);
			break;
		default:
			RTHOOK(5);
			if (F361_5574(Current, arg1)) {
				RTHOOK(6);
				Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
				F1237_11059(RTCW(Result));
				RTHOOK(7);
				F1242_11317(RTCW(Result), arg1);
			} else {
				RTHOOK(8);
				Result = RTMS32_EX_H("&\000\000\000#\000\000\000",2,9763);
				RTHOOK(9);
				tu4_1 = (EIF_NATURAL_32) arg1;
				F1242_11313(RTCW(Result), tu4_1);
				RTHOOK(10);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ';';
				F1242_11317(RTCW(Result), tw1);
			}
			break;
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STANDARD_PARSER}.resolved_entity */
EIF_REFERENCE F361_5566 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("resolved_entity", 360, Current, 1, 1, 5596);
	RTGC;
	RTHOOK(1);
	tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R9604[Dtype(RTCW(arg1))-1240])(arg1, ((EIF_INTEGER_32) 1L));
	tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_CHARACTER_32 *)tr1 = tw1;
	tw1 = F1188_10885(RTCW(tr1));
	switch (tw1) {
		case (EIF_CHARACTER_8) 'a':
			RTHOOK(2);
			tb1 = '\0';
			tb2 = '\0';
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9759[Dtype(arg1)-1239]);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 3L))) {
				tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R9604[Dtype(RTCW(arg1))-1240])(arg1, ((EIF_INTEGER_32) 2L));
				tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = tw1;
				tw1 = F1188_10885(RTCW(tr1));
				tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'm';
				tb2 = (EIF_BOOLEAN)(tw1 == tw2);
			}
			if (tb2) {
				tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R9604[Dtype(RTCW(arg1))-1240])(arg1, ((EIF_INTEGER_32) 3L));
				tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = tw1;
				tw1 = F1188_10885(RTCW(tr1));
				tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'p';
				tb1 = (EIF_BOOLEAN)(tw1 == tw2);
			}
			if (tb1) {
				RTHOOK(3);
				loc1 = RTMS32_EX_H("&\000\000\000",1,38);
			} else {
				RTHOOK(4);
				tb1 = '\0';
				tb2 = '\0';
				tb3 = '\0';
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9759[Dtype(arg1)-1239]);
				if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 4L))) {
					tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R9604[Dtype(RTCW(arg1))-1240])(arg1, ((EIF_INTEGER_32) 2L));
					tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
					*(EIF_CHARACTER_32 *)tr1 = tw1;
					tw1 = F1188_10885(RTCW(tr1));
					tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'p';
					tb3 = (EIF_BOOLEAN)(tw1 == tw2);
				}
				if (tb3) {
					tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R9604[Dtype(RTCW(arg1))-1240])(arg1, ((EIF_INTEGER_32) 3L));
					tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
					*(EIF_CHARACTER_32 *)tr1 = tw1;
					tw1 = F1188_10885(RTCW(tr1));
					tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'o';
					tb2 = (EIF_BOOLEAN)(tw1 == tw2);
				}
				if (tb2) {
					tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R9604[Dtype(RTCW(arg1))-1240])(arg1, ((EIF_INTEGER_32) 4L));
					tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
					*(EIF_CHARACTER_32 *)tr1 = tw1;
					tw1 = F1188_10885(RTCW(tr1));
					tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 's';
					tb1 = (EIF_BOOLEAN)(tw1 == tw2);
				}
				if (tb1) {
					RTHOOK(5);
					loc1 = RTMS32_EX_H("\'\000\000\000",1,39);
				}
			}
			break;
		case (EIF_CHARACTER_8) 'q':
			RTHOOK(6);
			tb1 = '\0';
			tb2 = '\0';
			tb3 = '\0';
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9759[Dtype(arg1)-1239]);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 4L))) {
				tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R9604[Dtype(RTCW(arg1))-1240])(arg1, ((EIF_INTEGER_32) 2L));
				tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = tw1;
				tw1 = F1188_10885(RTCW(tr1));
				tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'u';
				tb3 = (EIF_BOOLEAN)(tw1 == tw2);
			}
			if (tb3) {
				tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R9604[Dtype(RTCW(arg1))-1240])(arg1, ((EIF_INTEGER_32) 3L));
				tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = tw1;
				tw1 = F1188_10885(RTCW(tr1));
				tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'o';
				tb2 = (EIF_BOOLEAN)(tw1 == tw2);
			}
			if (tb2) {
				tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R9604[Dtype(RTCW(arg1))-1240])(arg1, ((EIF_INTEGER_32) 4L));
				tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = tw1;
				tw1 = F1188_10885(RTCW(tr1));
				tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 't';
				tb1 = (EIF_BOOLEAN)(tw1 == tw2);
			}
			if (tb1) {
				RTHOOK(7);
				loc1 = RTMS32_EX_H("\"\000\000\000",1,34);
			}
			break;
		case (EIF_CHARACTER_8) 'l':
			RTHOOK(8);
			tb1 = '\0';
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9759[Dtype(arg1)-1239]);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
				tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R9604[Dtype(RTCW(arg1))-1240])(arg1, ((EIF_INTEGER_32) 2L));
				tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = tw1;
				tw1 = F1188_10885(RTCW(tr1));
				tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 't';
				tb1 = (EIF_BOOLEAN)(tw1 == tw2);
			}
			if (tb1) {
				RTHOOK(9);
				loc1 = RTMS32_EX_H("<\000\000\000",1,60);
			}
			break;
		case (EIF_CHARACTER_8) 'g':
			RTHOOK(10);
			tb1 = '\0';
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9759[Dtype(arg1)-1239]);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
				tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R9604[Dtype(RTCW(arg1))-1240])(arg1, ((EIF_INTEGER_32) 2L));
				tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = tw1;
				tw1 = F1188_10885(RTCW(tr1));
				tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 't';
				tb1 = (EIF_BOOLEAN)(tw1 == tw2);
			}
			if (tb1) {
				RTHOOK(11);
				loc1 = RTMS32_EX_H(">\000\000\000",1,62);
			}
			break;
	}
	RTHOOK(12);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(13);
		loc1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9759[Dtype(arg1)-1239]);
		F1240_11189(RTCW(loc1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 2L)));
		RTHOOK(14);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
		F1242_11317(RTCW(loc1), tw1);
		RTHOOK(15);
		F1242_11303(RTCW(loc1), arg1);
		RTHOOK(16);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ';';
		F1242_11317(RTCW(loc1), tw1);
	}
	RTHOOK(17);
	RTHOOK(18);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) loc1;
}

/* {XML_STANDARD_PARSER}.hexa_string_to_natural_32 */
EIF_NATURAL_32 F361_5567 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("hexa_string_to_natural_32", 360, Current, 0, 1, 5597);
	RTGC;
	RTHOOK(1);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R9618[Dtype(RTCW(arg1))-1240])(arg1);
	if (tb1) {
		RTHOOK(2);
		Result = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	} else {
		RTHOOK(3);
		tr1 = RTOUCR(591,F361_5568, (Current));
		F333_5256(RTCW(tr1), ((EIF_INTEGER_32) 13L));
		RTHOOK(4);
		tr1 = RTOUCR(591,F361_5568, (Current));
		F333_5257(RTCW(tr1), arg1, ((EIF_INTEGER_32) 13L));
		RTHOOK(5);
		Result = F333_5269(RTCV(RTOUCR(591,F361_5568, (Current))));
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STANDARD_PARSER}.ctoi_convertor */
static EIF_REFERENCE F361_5568_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(591)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("ctoi_convertor", 360, Current, 0, 0, 5598);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(332, 0x00).id, 332, _OBJSIZ_2_4_0_3_0_0_2_0_);
	F333_5251(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTMS_EX_H("x ",2,30752);
	F332_5245(RTCW(Result), tr1);
	RTHOOK(3);
	tr1 = RTMS_EX_H(" ",1,32);
	F332_5246(RTCW(Result), tr1);
	RTHOOK(4);
	F332_5244(RTCW(Result), (EIF_BOOLEAN) 1);
	RTHOOK(5);
	F332_5243(RTCW(Result), (EIF_BOOLEAN) 1);
	RTOTE;
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F361_5568 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(591,F361_5568_body,(Current));
}

/* {XML_STANDARD_PARSER}.is_valid_tag_start_character */
EIF_BOOLEAN F361_5569 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_valid_tag_start_character", 360, Current, 0, 1, 5599);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) F361_5572(Current, arg1);
}

/* {XML_STANDARD_PARSER}.is_valid_tag_character */
EIF_BOOLEAN F361_5570 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_valid_tag_character", 360, Current, 0, 1, 5600);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) F361_5573(Current, arg1);
}

/* {XML_STANDARD_PARSER}.is_valid_entity_character */
EIF_BOOLEAN F361_5571 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_valid_entity_character", 360, Current, 0, 1, 5601);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) F361_5573(Current, arg1);
}

/* {XML_STANDARD_PARSER}.is_valid_name_start_character */
EIF_BOOLEAN F361_5572 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_valid_name_start_character", 360, Current, 1, 1, 5602);
	RTGC;
	RTHOOK(1);
	tb1 = '\01';
	tb2 = '\01';
	tb3 = '\01';
	tb4 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'a';
	if ((EIF_BOOLEAN) (tw1 <= arg1)) {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'z';
		tb4 = (EIF_BOOLEAN) (arg1 <= tw1);
	}
	if (!tb4) {
		tb4 = '\0';
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'A';
		if ((EIF_BOOLEAN) (tw1 <= arg1)) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'Z';
			tb4 = (EIF_BOOLEAN) (arg1 <= tw1);
		}
		tb3 = tb4;
	}
	if (!tb3) {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
		tb2 = (EIF_BOOLEAN)(arg1 == tw1);
	}
	if (!tb2) {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
		tb1 = (EIF_BOOLEAN)(arg1 == tw1);
	}
	if (tb1) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		RTHOOK(4);
		loc1 = (EIF_NATURAL_32) arg1;
		RTHOOK(5);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 192L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 214L))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 216L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 246L)))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 248L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 767L)))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 880L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 893L)))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 895L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 8191L)))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 8204L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 8205L)))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 8304L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 8591L)))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 11264L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 12271L)))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 12289L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 55295L)))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 63744L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 64975L)))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 65008L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 65533L)))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 65536L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 983039L))))) {
			RTHOOK(6);
			RTHOOK(7);
			RTLE;
			RTEE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) 0;
}

/* {XML_STANDARD_PARSER}.is_valid_name_character */
EIF_BOOLEAN F361_5573 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_valid_name_character", 360, Current, 1, 1, 5603);
	RTGC;
	RTHOOK(1);
	Result = F361_5572(Current, arg1);
	RTHOOK(2);
	if ((EIF_BOOLEAN) !Result) {
		RTHOOK(3);
		tb1 = '\01';
		tb2 = '\01';
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
		if (!(EIF_BOOLEAN)(arg1 == tw1)) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
			tb2 = (EIF_BOOLEAN)(arg1 == tw1);
		}
		if (!tb2) {
			tb2 = '\0';
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '0';
			if ((EIF_BOOLEAN) (tw1 <= arg1)) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '9';
				tb2 = (EIF_BOOLEAN) (arg1 <= tw1);
			}
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(4);
			RTHOOK(5);
			RTLE;
			RTEE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			RTHOOK(6);
			loc1 = (EIF_NATURAL_32) arg1;
			RTHOOK(7);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 183L)) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 768L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 879L)))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 8255L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 8256L))))) {
				RTHOOK(8);
				RTHOOK(9);
				RTLE;
				RTEE;
				return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		}
	}
	RTHOOK(10);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STANDARD_PARSER}.is_printable */
EIF_BOOLEAN F361_5574 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_32 loc2 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_printable", 360, Current, 2, 1, 5604);
	RTGC;
	RTHOOK(1);
	if ((EIF_FALSE)) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(1192, 0x00).id, 1192, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)tr1 = loc1;
		tb1 = F1191_10936(RTCW(tr1));
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) tb1;
	} else {
		RTHOOK(4);
		tb1 = '\0';
		loc2 = arg1;
		if ((EIF_TRUE)) {
			tb2 = (loc2 <= 0xFF);
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(5);
			tc1 = (EIF_CHARACTER_8) loc2;
			tr1 = RTLNS(eif_new_type(1192, 0x00).id, 1192, _OBJSIZ_0_1_0_0_0_0_0_0_);
			*(EIF_CHARACTER_8 *)tr1 = tc1;
			Result = F1191_10936(RTCW(tr1));
		}
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STANDARD_PARSER}.is_blank */
EIF_BOOLEAN F361_5575 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_blank", 360, Current, 2, 1, 5605);
	RTGC;
	RTHOOK(1);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(3);
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9640[Dtype(RTCW(arg1))-1240])(arg1);
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > loc2) || (EIF_BOOLEAN) !Result)) break;
		RTHOOK(5);
		tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R9603[Dtype(RTCW(arg1))-1240])(arg1, loc1);
		switch (tu4_1) {
			case 9U:
			case 10U:
			case 13U:
			case 32U:
				break;
			default:
				RTHOOK(6);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				break;
		}
		RTHOOK(7);
		loc1++;
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STANDARD_PARSER}.empty_buffer */
static EIF_REFERENCE F361_5577_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(582)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("empty_buffer", 360, Current, 0, 0, 5607);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1290, 0x00).id, 1290, _OBJSIZ_2_2_0_4_0_0_0_0_);
	F1291_12141(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = F1237_11118(RTMS_EX_H("Empty-string-buffer",19,890082162));
	F1291_12150(RTCW(Result), tr1);
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F361_5577 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(582,F361_5577_body,(Current));
}

/* {XML_STANDARD_PARSER}.new_string_tag */
EIF_REFERENCE F361_5578 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("new_string_tag", 360, Current, 0, 0, 5608);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) RTOUCR(592,F361_5589, (Current));
}

/* {XML_STANDARD_PARSER}.new_string_attribute_name */
EIF_REFERENCE F361_5579 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("new_string_attribute_name", 360, Current, 0, 0, 5609);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) RTOUCR(593,F361_5590, (Current));
}

/* {XML_STANDARD_PARSER}.new_string_attribute_value */
EIF_REFERENCE F361_5580 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("new_string_attribute_value", 360, Current, 0, 0, 5610);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) RTOUCR(594,F361_5591, (Current));
}

/* {XML_STANDARD_PARSER}.new_string_comment_value */
EIF_REFERENCE F361_5581 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("new_string_comment_value", 360, Current, 0, 0, 5611);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) RTOUCR(595,F361_5592, (Current));
}

/* {XML_STANDARD_PARSER}.str_version */

EIF_REFERENCE F361_5582 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (583,RTMS32_EX_H("v\000\000\000e\000\000\000r\000\000\000s\000\000\000i\000\000\000o\000\000\000n\000\000\000",7,1397649262));
}

/* {XML_STANDARD_PARSER}.str_encoding */

EIF_REFERENCE F361_5583 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (584,RTMS32_EX_H("e\000\000\000n\000\000\000c\000\000\000o\000\000\000d\000\000\000i\000\000\000n\000\000\000g\000\000\000",8,1433733735));
}

/* {XML_STANDARD_PARSER}.str_standalone */

EIF_REFERENCE F361_5584 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (585,RTMS32_EX_H("s\000\000\000t\000\000\000a\000\000\000n\000\000\000d\000\000\000a\000\000\000l\000\000\000o\000\000\000n\000\000\000e\000\000\000",10,1099491941));
}

/* {XML_STANDARD_PARSER}.str_cdata */

EIF_REFERENCE F361_5585 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (587,RTMS32_EX_H("C\000\000\000D\000\000\000A\000\000\000T\000\000\000A\000\000\000",5,1145646657));
}

/* {XML_STANDARD_PARSER}.str_doctype */

EIF_REFERENCE F361_5586 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (588,RTMS32_EX_H("D\000\000\000O\000\000\000C\000\000\000T\000\000\000Y\000\000\000P\000\000\000E\000\000\000",7,1436817989));
}

/* {XML_STANDARD_PARSER}.str_xml */

EIF_REFERENCE F361_5588 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (586,RTMS32_EX_H("x\000\000\000m\000\000\000l\000\000\000",3,7892332));
}

/* {XML_STANDARD_PARSER}.tmp_string_tag */
static EIF_REFERENCE F361_5589_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(592)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("tmp_string_tag", 360, Current, 0, 0, 5619);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1240_11189(RTCW(tr1), ((EIF_INTEGER_32) 25L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F361_5589 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(592,F361_5589_body,(Current));
}

/* {XML_STANDARD_PARSER}.tmp_string_attribute_name */
static EIF_REFERENCE F361_5590_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(593)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("tmp_string_attribute_name", 360, Current, 0, 0, 5620);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1240_11189(RTCW(tr1), ((EIF_INTEGER_32) 20L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F361_5590 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(593,F361_5590_body,(Current));
}

/* {XML_STANDARD_PARSER}.tmp_string_attribute_value */
static EIF_REFERENCE F361_5591_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(594)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("tmp_string_attribute_value", 360, Current, 0, 0, 5621);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1240_11189(RTCW(tr1), ((EIF_INTEGER_32) 50L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F361_5591 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(594,F361_5591_body,(Current));
}

/* {XML_STANDARD_PARSER}.tmp_string_comment_value */
static EIF_REFERENCE F361_5592_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(595)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("tmp_string_comment_value", 360, Current, 0, 0, 5622);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1240_11189(RTCW(tr1), ((EIF_INTEGER_32) 100L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F361_5592 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(595,F361_5592_body,(Current));
}

/* {XML_STANDARD_PARSER}.carriage_return_character_code */
static EIF_NATURAL_32 F361_5593_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRB(EIF_NATURAL_32)
	RTOUDB(EIF_NATURAL_32, 590)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("carriage_return_character_code", 360, Current, 0, 0, 5623);
	RTGC;
	RTOTP;
	RTHOOK(1);
	Result = (EIF_NATURAL_32) (EIF_CHARACTER_8) '\015';
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_NATURAL_32 F361_5593 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_NATURAL_32,590,F361_5593_body,(Current));
}

void EIF_Minit313 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
