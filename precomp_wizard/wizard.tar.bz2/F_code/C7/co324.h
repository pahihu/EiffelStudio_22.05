
#ifndef _C7_co324_
#define _C7_co324_

#ifdef __cplusplus
extern "C" {
#endif

extern void F372_5708(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit324(void);

#ifdef __cplusplus
}
#endif

#endif
