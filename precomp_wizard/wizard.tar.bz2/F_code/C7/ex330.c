/*
 * Code for class EXCEPTIONS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ex330.h"
#include "eif_except.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EXCEPTIONS}.is_signal */
EIF_BOOLEAN F378_5900 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("is_signal", 377, Current, 2, 0, 5960);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	tr1 = F245_4244(RTCV(RTOUCR(23,F377_5894, (Current))));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F379_5929(loc1);
		loc2 = tr1;
		loc2 = RTRV(eif_new_type(383, 0x00),loc2);
		Result = EIF_TEST(loc2);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EXCEPTIONS}.raise */
void F378_5913 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("raise", 377, Current, 1, 1, 5973);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(386, 0x00).id, 386, _OBJSIZ_5_1_0_1_0_0_0_0_);
	RTHOOK(2);
	F379_5936(RTCW(loc1), arg1);
	RTHOOK(3);
	F379_5921(RTCW(loc1));
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EXCEPTIONS}.raise_retrieval_exception */
void F378_5914 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("raise_retrieval_exception", 377, Current, 1, 1, 5974);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(23,F377_5894, (Current));
	tr1 = F245_4254(RTCW(tr1), ((EIF_INTEGER_32) 31L));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		F379_5936(loc1, arg1);
		RTHOOK(3);
		F379_5921(loc1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EXCEPTIONS}.die */
void F378_5915 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("die", 377, Current, 0, 1, 5975);esdie(arg1);
	
	RTEC (EN_POST);
	RTHOOK(1);
	RTLE;
	RTEE;
}

void EIF_Minit330 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
