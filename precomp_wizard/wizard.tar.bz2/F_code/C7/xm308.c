/*
 * Code for class XML_CALLBACKS_NULL
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm308.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XML_CALLBACKS_NULL}.make */
void F356_5457 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make", 355, Current, 0, 0, 5540);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XML_CALLBACKS_NULL}.on_start */
void F356_5458 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("on_start", 355, Current, 0, 0, 5541);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XML_CALLBACKS_NULL}.on_finish */
void F356_5459 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("on_finish", 355, Current, 0, 0, 5542);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XML_CALLBACKS_NULL}.on_xml_declaration */
void F356_5460 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("on_xml_declaration", 355, Current, 0, 3, 5543);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XML_CALLBACKS_NULL}.on_error */
void F356_5461 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("on_error", 355, Current, 0, 1, 5544);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XML_CALLBACKS_NULL}.on_processing_instruction */
void F356_5462 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("on_processing_instruction", 355, Current, 0, 2, 5545);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XML_CALLBACKS_NULL}.on_comment */
void F356_5463 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("on_comment", 355, Current, 0, 1, 5546);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XML_CALLBACKS_NULL}.on_start_tag */
void F356_5464 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("on_start_tag", 355, Current, 0, 3, 5547);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XML_CALLBACKS_NULL}.on_attribute */
void F356_5465 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("on_attribute", 355, Current, 0, 4, 5548);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XML_CALLBACKS_NULL}.on_start_tag_finish */
void F356_5466 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("on_start_tag_finish", 355, Current, 0, 0, 5549);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XML_CALLBACKS_NULL}.on_end_tag */
void F356_5467 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("on_end_tag", 355, Current, 0, 3, 5550);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XML_CALLBACKS_NULL}.on_content */
void F356_5468 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("on_content", 355, Current, 0, 1, 5551);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

void EIF_Minit308 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
