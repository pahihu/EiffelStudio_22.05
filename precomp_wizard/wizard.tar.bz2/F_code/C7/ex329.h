
#ifndef _C7_ex329_
#define _C7_ex329_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F377_5894_body(EIF_REFERENCE);
extern EIF_REFERENCE F377_5894(EIF_REFERENCE);
extern void EIF_Minit329(void);

#ifdef __cplusplus
}
#endif

#endif
