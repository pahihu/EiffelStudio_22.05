
#ifndef _C7_op338_
#define _C7_op338_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F386_5977(EIF_REFERENCE);
extern void F386_5980(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit338(void);

#ifdef __cplusplus
}
#endif

#endif
