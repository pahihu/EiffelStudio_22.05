
#ifndef _C7_xm307_
#define _C7_xm307_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F355_5451(EIF_REFERENCE, EIF_REFERENCE);
extern void F355_5455(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit307(void);
extern long O9759[];

#ifdef __cplusplus
}
#endif

#endif
