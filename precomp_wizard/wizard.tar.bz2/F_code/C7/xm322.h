
#ifndef _C7_xm322_
#define _C7_xm322_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_32 F370_5698(EIF_REFERENCE);
extern void F370_5700(EIF_REFERENCE);
extern void EIF_Minit322(void);
extern char *(*R5433[])();
extern char *(*R5434[])();

#ifdef __cplusplus
}
#endif

#endif
