
#ifndef _C7_fl334_
#define _C7_fl334_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F382_5952(EIF_REFERENCE);
extern void EIF_Minit334(void);

#ifdef __cplusplus
}
#endif

#endif
