
#ifndef _C7_xm311_
#define _C7_xm311_

#ifdef __cplusplus
extern "C" {
#endif

extern void F359_5473(EIF_REFERENCE, EIF_REFERENCE);
extern void F359_5474(EIF_REFERENCE);
extern void F359_5475(EIF_REFERENCE);
extern void F359_5476(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN);
extern void F359_5477(EIF_REFERENCE, EIF_REFERENCE);
extern void F359_5478(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F359_5479(EIF_REFERENCE, EIF_REFERENCE);
extern void F359_5480(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F359_5481(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F359_5482(EIF_REFERENCE);
extern void F359_5483(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F359_5484(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit311(void);
extern char *(*R5250[])();
extern char *(*R5240[])();
extern char *(*R5241[])();
extern char *(*R5242[])();
extern char *(*R5243[])();
extern char *(*R5244[])();
extern char *(*R5245[])();
extern char *(*R5246[])();
extern char *(*R5247[])();
extern char *(*R5248[])();
extern char *(*R5249[])();

#ifdef __cplusplus
}
#endif

#endif
