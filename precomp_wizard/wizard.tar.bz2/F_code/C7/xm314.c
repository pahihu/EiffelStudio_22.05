/*
 * Code for class XML_STOPPABLE_PARSER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm314.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XML_STOPPABLE_PARSER}.reset */
void F362_5599 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("reset", 361, Current, 0, 0, 5669);
	RTGC;
	RTHOOK(1);
	F361_5523(Current);
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_5_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {XML_STOPPABLE_PARSER}.checkpoint_position */
EIF_REFERENCE F362_5600 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("checkpoint_position", 361, Current, 0, 0, 5670);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_5_0_2_) > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		Result = RTLNS(eif_new_type(1297, 0x00).id, 1297, _OBJSIZ_1_0_0_3_0_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5408[Dtype(RTCW(tr1))-368])(tr1);
		tr1 = F1237_11118(RTCW(tr1));
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_5_0_4_);
		ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_5_0_3_);
		ti4_3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_5_0_2_);
		F1298_12351(RTCW(Result), tr1, ti4_1, ti4_2, ti4_3);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STOPPABLE_PARSER}.set_checkpoint_position */
void F362_5604 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_checkpoint_position", 361, Current, 0, 0, 5674);
	RTGC;
	RTHOOK(1);
	ti4_1 = F361_5521(Current);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_5_0_2_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(2);
	ti4_1 = F361_5522(Current);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_5_0_3_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(3);
	ti4_1 = F361_5520(Current);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_5_0_4_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {XML_STOPPABLE_PARSER}.unset_checkpoint_position */
void F362_5605 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("unset_checkpoint_position", 361, Current, 0, 0, 5675);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_5_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_5_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(3);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_5_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {XML_STOPPABLE_PARSER}.report_error */
void F362_5606 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("report_error", 361, Current, 0, 1, 5676);
	RTGC;
	RTHOOK(1);
	F361_5538(Current, arg1);
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_5_3_);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit314 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
