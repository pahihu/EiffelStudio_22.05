#include "epoly9.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R7659[1018])();
void R7659_init () {
	R7659[0] = (char *(*)()) F781_8417;
	R7659[25] = (char *(*)()) F806_8489;
	R7659[26] = (char *(*)()) F807_8489_7659_4;
	R7659[27] = (char *(*)()) F808_8489;
	R7659[28] = (char *(*)()) F809_8489_7659_4;
	R7659[29] = (char *(*)()) F810_8489_7659_4;
	R7659[30] = (char *(*)()) F811_8489_7659_4;
	R7659[31] = (char *(*)()) F812_8489_7659_4;
	R7659[32] = (char *(*)()) F813_8489_7659_4;
	R7659[33] = (char *(*)()) F814_8489_7659_4;
	R7659[34] = (char *(*)()) F806_8489;
	R7659[35] = (char *(*)()) F807_8489_7659_4;
	R7659[36] = (char *(*)()) F809_8489_7659_4;
	R7659[37] = (char *(*)()) F813_8489_7659_4;
	R7659[38] = (char *(*)()) F814_8489_7659_4;
	R7659[39] = (char *(*)()) F806_8489;
	{long i; for (i = 52; i < 54; i++) R7659[i] = (char *(*)()) F833_8602_7659_4;}
	R7659[102] = (char *(*)()) F847_8645;
	R7659[103] = (char *(*)()) F850_8645_7659_4;
	R7659[104] = (char *(*)()) F852_8645_7659_4;
	R7659[105] = (char *(*)()) F886_8714;
	R7659[106] = (char *(*)()) F847_8645;
	R7659[107] = (char *(*)()) F852_8645_7659_4;
	R7659[108] = (char *(*)()) F850_8645_7659_4;
	R7659[109] = (char *(*)()) F890_8744;
	R7659[110] = (char *(*)()) F847_8645;
	R7659[111] = (char *(*)()) F892_8833;
	R7659[112] = (char *(*)()) F893_8833_7659_4;
	R7659[113] = (char *(*)()) F894_8833_7659_4;
	R7659[114] = (char *(*)()) F895_8833_7659_4;
	R7659[115] = (char *(*)()) F896_8833_7659_4;
	R7659[116] = (char *(*)()) F897_8833_7659_4;
	R7659[117] = (char *(*)()) F898_8833_7659_4;
	R7659[118] = (char *(*)()) F899_8833_7659_4;
	R7659[119] = (char *(*)()) F900_8833_7659_4;
	R7659[120] = (char *(*)()) F901_8833_7659_4;
	R7659[121] = (char *(*)()) F902_8833_7659_4;
	R7659[122] = (char *(*)()) F903_8833_7659_4;
	{long i; for (i = 123; i < 125; i++) R7659[i] = (char *(*)()) F892_8833;}
	R7659[125] = (char *(*)()) F895_8833_7659_4;
	R7659[126] = (char *(*)()) F897_8833_7659_4;
	R7659[127] = (char *(*)()) F892_8833;
	R7659[132] = (char *(*)()) F892_8833;
	R7659[133] = (char *(*)()) F895_8833_7659_4;
	R7659[134] = (char *(*)()) F892_8833;
	{long i; for (i = 135; i < 138; i++) R7659[i] = (char *(*)()) F916_8926;}
	R7659[140] = (char *(*)()) F916_8926;
	R7659[143] = (char *(*)()) F916_8926;
	{long i; for (i = 145; i < 147; i++) R7659[i] = (char *(*)()) F916_8926;}
	R7659[149] = (char *(*)()) F916_8926;
	{long i; for (i = 151; i < 157; i++) R7659[i] = (char *(*)()) F916_8926;}
	R7659[157] = (char *(*)()) F938_9064;
	R7659[158] = (char *(*)()) F939_9064_7659_4;
	R7659[159] = (char *(*)()) F940_9064_7659_4;
	R7659[160] = (char *(*)()) F941_9064_7659_4;
	R7659[161] = (char *(*)()) F942_9064_7659_4;
	R7659[162] = (char *(*)()) F943_9064_7659_4;
	R7659[163] = (char *(*)()) F944_9064_7659_4;
	R7659[164] = (char *(*)()) F945_9064_7659_4;
	R7659[165] = (char *(*)()) F946_9064_7659_4;
	R7659[166] = (char *(*)()) F947_9064_7659_4;
	R7659[167] = (char *(*)()) F948_9064_7659_4;
	R7659[168] = (char *(*)()) F949_9064_7659_4;
	R7659[189] = (char *(*)()) F723_8331_7659_4;
	R7659[196] = (char *(*)()) F723_8331_7659_4;
	{long i; for (i = 366; i < 368; i++) R7659[i] = (char *(*)()) F1146_10260_7659_4;}
	R7659[461] = (char *(*)()) F1242_11329_7659_4;
	R7659[464] = (char *(*)()) F1245_11494_7659_4;
	{long i; for (i = 572; i < 576; i++) R7659[i] = (char *(*)()) F1348_12857;}
	{long i; for (i = 577; i < 579; i++) R7659[i] = (char *(*)()) F1348_12857;}
	{long i; for (i = 581; i < 584; i++) R7659[i] = (char *(*)()) F1348_12857;}
	{long i; for (i = 585; i < 588; i++) R7659[i] = (char *(*)()) F1348_12857;}
	{long i; for (i = 591; i < 593; i++) R7659[i] = (char *(*)()) F847_8645;}
	R7659[594] = (char *(*)()) F847_8645;
	R7659[614] = (char *(*)()) F892_8833;
	R7659[625] = (char *(*)()) F847_8645;
	R7659[935] = (char *(*)()) F1146_10260_7659_4;
	R7659[1017] = (char *(*)()) F1245_11494_7659_4;
}
static void F807_8489_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F807_8489(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F809_8489_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F809_8489(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F810_8489_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F810_8489(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F811_8489_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F811_8489(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F812_8489_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F812_8489(Current, *(EIF_POINTER *)arg1);
}
static void F813_8489_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F813_8489(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F814_8489_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F814_8489(Current, *(EIF_BOOLEAN *)arg1);
}
static void F833_8602_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F833_8602(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F850_8645_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F850_8645(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F852_8645_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F852_8645(Current, *(EIF_BOOLEAN *)arg1);
}
static void F893_8833_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F893_8833(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F894_8833_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F894_8833(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F895_8833_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F895_8833(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F896_8833_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F896_8833(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F897_8833_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F897_8833(Current, *(EIF_BOOLEAN *)arg1);
}
static void F898_8833_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F898_8833(Current, *(EIF_POINTER *)arg1);
}
static void F899_8833_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F899_8833(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F900_8833_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F900_8833(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F901_8833_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F901_8833(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F902_8833_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F902_8833(Current, *(EIF_REAL_32 *)arg1);
}
static void F903_8833_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F903_8833(Current, *(EIF_REAL_64 *)arg1);
}
static void F939_9064_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F939_9064(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F940_9064_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F940_9064(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F941_9064_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F941_9064(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F942_9064_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F942_9064(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F943_9064_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F943_9064(Current, *(EIF_BOOLEAN *)arg1);
}
static void F944_9064_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F944_9064(Current, *(EIF_POINTER *)arg1);
}
static void F945_9064_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F945_9064(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F946_9064_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F946_9064(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F947_9064_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F947_9064(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F948_9064_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F948_9064(Current, *(EIF_REAL_32 *)arg1);
}
static void F949_9064_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F949_9064(Current, *(EIF_REAL_64 *)arg1);
}
static void F723_8331_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F723_8331(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1146_10260_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1146_10260(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1242_11329_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1242_11329(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1245_11494_7659_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1245_11494(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R7660[601])();
void R7660_init () {
	R7660[0] = (char *(*)()) F618_8256;
	R7660[1] = (char *(*)()) F619_8256_7660_4;
	R7660[2] = (char *(*)()) F618_8256;
	{long i; for (i = 3; i < 6; i++) R7660[i] = (char *(*)()) F621_8256_7660_4;}
	R7660[6] = (char *(*)()) F626_8256_7660_4;
	R7660[7] = (char *(*)()) F622_8256_7660_4;
	R7660[8] = (char *(*)()) F625_8256_7660_4;
	R7660[9] = (char *(*)()) F618_8256;
	R7660[10] = (char *(*)()) F619_8256_7660_4;
	R7660[11] = (char *(*)()) F621_8256_7660_4;
	R7660[12] = (char *(*)()) F622_8256_7660_4;
	R7660[13] = (char *(*)()) F625_8256_7660_4;
	R7660[14] = (char *(*)()) F618_8256;
	{long i; for (i = 27; i < 29; i++) R7660[i] = (char *(*)()) F621_8256_7660_4;}
	R7660[77] = (char *(*)()) F847_8646;
	R7660[78] = (char *(*)()) F850_8646_7660_4;
	R7660[79] = (char *(*)()) F852_8646_7660_4;
	R7660[80] = (char *(*)()) F847_8646;
	R7660[81] = (char *(*)()) F618_8256;
	R7660[82] = (char *(*)()) F625_8256_7660_4;
	R7660[83] = (char *(*)()) F621_8256_7660_4;
	R7660[84] = (char *(*)()) F890_8745;
	R7660[85] = (char *(*)()) F847_8646;
	R7660[86] = (char *(*)()) F892_8836;
	R7660[87] = (char *(*)()) F893_8836_7660_4;
	R7660[88] = (char *(*)()) F894_8836_7660_4;
	R7660[89] = (char *(*)()) F895_8836_7660_4;
	R7660[90] = (char *(*)()) F896_8836_7660_4;
	R7660[91] = (char *(*)()) F897_8836_7660_4;
	R7660[92] = (char *(*)()) F898_8836_7660_4;
	R7660[93] = (char *(*)()) F899_8836_7660_4;
	R7660[94] = (char *(*)()) F900_8836_7660_4;
	R7660[95] = (char *(*)()) F901_8836_7660_4;
	R7660[96] = (char *(*)()) F902_8836_7660_4;
	R7660[97] = (char *(*)()) F903_8836_7660_4;
	{long i; for (i = 98; i < 100; i++) R7660[i] = (char *(*)()) F892_8836;}
	R7660[100] = (char *(*)()) F895_8836_7660_4;
	R7660[101] = (char *(*)()) F897_8836_7660_4;
	R7660[102] = (char *(*)()) F892_8836;
	R7660[107] = (char *(*)()) F909_8885;
	R7660[108] = (char *(*)()) F910_8885_7660_4;
	{long i; for (i = 109; i < 113; i++) R7660[i] = (char *(*)()) F909_8885;}
	R7660[115] = (char *(*)()) F909_8885;
	R7660[118] = (char *(*)()) F909_8885;
	{long i; for (i = 120; i < 122; i++) R7660[i] = (char *(*)()) F909_8885;}
	R7660[124] = (char *(*)()) F909_8885;
	{long i; for (i = 126; i < 132; i++) R7660[i] = (char *(*)()) F909_8885;}
	R7660[132] = (char *(*)()) F618_8256;
	R7660[133] = (char *(*)()) F619_8256_7660_4;
	R7660[134] = (char *(*)()) F620_8256_7660_4;
	R7660[135] = (char *(*)()) F621_8256_7660_4;
	R7660[136] = (char *(*)()) F622_8256_7660_4;
	R7660[137] = (char *(*)()) F625_8256_7660_4;
	R7660[138] = (char *(*)()) F626_8256_7660_4;
	R7660[139] = (char *(*)()) F623_8256_7660_4;
	R7660[140] = (char *(*)()) F624_8256_7660_4;
	R7660[141] = (char *(*)()) F627_8256_7660_4;
	R7660[142] = (char *(*)()) F628_8256_7660_4;
	R7660[143] = (char *(*)()) F629_8256_7660_4;
	R7660[164] = (char *(*)()) F621_8256_7660_4;
	R7660[171] = (char *(*)()) F621_8256_7660_4;
	R7660[436] = (char *(*)()) F1242_11330_7660_4;
	{long i; for (i = 547; i < 549; i++) R7660[i] = (char *(*)()) F847_8646;}
	{long i; for (i = 549; i < 551; i++) R7660[i] = (char *(*)()) F618_8256;}
	{long i; for (i = 552; i < 554; i++) R7660[i] = (char *(*)()) F618_8256;}
	{long i; for (i = 556; i < 559; i++) R7660[i] = (char *(*)()) F618_8256;}
	{long i; for (i = 560; i < 563; i++) R7660[i] = (char *(*)()) F618_8256;}
	{long i; for (i = 566; i < 568; i++) R7660[i] = (char *(*)()) F847_8646;}
	R7660[569] = (char *(*)()) F847_8646;
	R7660[589] = (char *(*)()) F909_8885;
	R7660[600] = (char *(*)()) F847_8646;
}
static void F619_8256_7660_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F619_8256(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F621_8256_7660_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F621_8256(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F626_8256_7660_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F626_8256(Current, *(EIF_POINTER *)arg1);
}
static void F622_8256_7660_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F622_8256(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F625_8256_7660_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F625_8256(Current, *(EIF_BOOLEAN *)arg1);
}
static void F850_8646_7660_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F850_8646(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F852_8646_7660_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F852_8646(Current, *(EIF_BOOLEAN *)arg1);
}
static void F893_8836_7660_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F893_8836(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F894_8836_7660_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F894_8836(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F895_8836_7660_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F895_8836(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F896_8836_7660_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F896_8836(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F897_8836_7660_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F897_8836(Current, *(EIF_BOOLEAN *)arg1);
}
static void F898_8836_7660_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F898_8836(Current, *(EIF_POINTER *)arg1);
}
static void F899_8836_7660_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F899_8836(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F900_8836_7660_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F900_8836(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F901_8836_7660_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F901_8836(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F902_8836_7660_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F902_8836(Current, *(EIF_REAL_32 *)arg1);
}
static void F903_8836_7660_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F903_8836(Current, *(EIF_REAL_64 *)arg1);
}
static void F910_8885_7660_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F910_8885(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F620_8256_7660_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F620_8256(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F623_8256_7660_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F623_8256(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F624_8256_7660_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F624_8256(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F627_8256_7660_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F627_8256(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F628_8256_7660_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F628_8256(Current, *(EIF_REAL_32 *)arg1);
}
static void F629_8256_7660_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F629_8256(Current, *(EIF_REAL_64 *)arg1);
}
static void F1242_11330_7660_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1242_11330(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R7661[1018])();
void R7661_init () {
	R7661[0] = (char *(*)()) F781_8419;
	R7661[25] = (char *(*)()) F806_8490;
	R7661[26] = (char *(*)()) F807_8490;
	R7661[27] = (char *(*)()) F808_8490;
	R7661[28] = (char *(*)()) F809_8490;
	R7661[29] = (char *(*)()) F810_8490;
	R7661[30] = (char *(*)()) F811_8490;
	R7661[31] = (char *(*)()) F812_8490;
	R7661[32] = (char *(*)()) F813_8490;
	R7661[33] = (char *(*)()) F814_8490;
	R7661[34] = (char *(*)()) F806_8490;
	R7661[35] = (char *(*)()) F807_8490;
	R7661[36] = (char *(*)()) F809_8490;
	R7661[37] = (char *(*)()) F813_8490;
	R7661[38] = (char *(*)()) F814_8490;
	R7661[39] = (char *(*)()) F806_8490;
	R7661[102] = (char *(*)()) F883_8701;
	R7661[103] = (char *(*)()) F884_8701;
	R7661[104] = (char *(*)()) F885_8701;
	{long i; for (i = 105; i < 107; i++) R7661[i] = (char *(*)()) F883_8701;}
	R7661[107] = (char *(*)()) F885_8701;
	R7661[108] = (char *(*)()) F884_8701;
	R7661[109] = (char *(*)()) F883_8701;
	R7661[110] = (char *(*)()) F891_8773;
	R7661[111] = (char *(*)()) F892_8839;
	R7661[112] = (char *(*)()) F893_8839;
	R7661[113] = (char *(*)()) F894_8839;
	R7661[114] = (char *(*)()) F895_8839;
	R7661[115] = (char *(*)()) F896_8839;
	R7661[116] = (char *(*)()) F897_8839;
	R7661[117] = (char *(*)()) F898_8839;
	R7661[118] = (char *(*)()) F899_8839;
	R7661[119] = (char *(*)()) F900_8839;
	R7661[120] = (char *(*)()) F901_8839;
	R7661[121] = (char *(*)()) F902_8839;
	R7661[122] = (char *(*)()) F903_8839;
	{long i; for (i = 123; i < 125; i++) R7661[i] = (char *(*)()) F892_8839;}
	R7661[125] = (char *(*)()) F895_8839;
	R7661[126] = (char *(*)()) F897_8839;
	R7661[127] = (char *(*)()) F892_8839;
	R7661[132] = (char *(*)()) F909_8887;
	R7661[133] = (char *(*)()) F910_8887;
	{long i; for (i = 134; i < 138; i++) R7661[i] = (char *(*)()) F909_8887;}
	R7661[140] = (char *(*)()) F909_8887;
	R7661[143] = (char *(*)()) F909_8887;
	{long i; for (i = 145; i < 147; i++) R7661[i] = (char *(*)()) F909_8887;}
	R7661[149] = (char *(*)()) F909_8887;
	{long i; for (i = 151; i < 157; i++) R7661[i] = (char *(*)()) F909_8887;}
	R7661[461] = (char *(*)()) F1242_11333;
	R7661[464] = (char *(*)()) F1245_11498;
	{long i; for (i = 572; i < 574; i++) R7661[i] = (char *(*)()) F1341_12751;}
	{long i; for (i = 574; i < 576; i++) R7661[i] = (char *(*)()) F1355_12919;}
	{long i; for (i = 577; i < 579; i++) R7661[i] = (char *(*)()) F1355_12919;}
	{long i; for (i = 581; i < 584; i++) R7661[i] = (char *(*)()) F1355_12919;}
	{long i; for (i = 585; i < 588; i++) R7661[i] = (char *(*)()) F1355_12919;}
	{long i; for (i = 591; i < 593; i++) R7661[i] = (char *(*)()) F1341_12751;}
	R7661[594] = (char *(*)()) F1341_12751;
	R7661[614] = (char *(*)()) F909_8887;
	R7661[625] = (char *(*)()) F1341_12751;
	R7661[1017] = (char *(*)()) F1798_20881;
}

char *(*R7663[966])();
void R7663_init () {
	{long i; for (i = 0; i < 2; i++) R7663[i] = (char *(*)()) F833_8573_7663_5;}
	R7663[50] = (char *(*)()) F835_8619_7663_5;
	R7663[51] = (char *(*)()) F838_8619_7663_5;
	R7663[52] = (char *(*)()) F840_8619_7663_5;
	{long i; for (i = 53; i < 55; i++) R7663[i] = (char *(*)()) F835_8619_7663_5;}
	R7663[55] = (char *(*)()) F840_8619_7663_5;
	R7663[56] = (char *(*)()) F838_8619_7663_5;
	{long i; for (i = 57; i < 59; i++) R7663[i] = (char *(*)()) F835_8619_7663_5;}
	R7663[59] = (char *(*)()) F892_8786_7663_5;
	R7663[60] = (char *(*)()) F893_8786_7663_5;
	R7663[61] = (char *(*)()) F894_8786_7663_5;
	R7663[62] = (char *(*)()) F895_8786_7663_5;
	R7663[63] = (char *(*)()) F896_8786_7663_5;
	R7663[64] = (char *(*)()) F897_8786_7663_5;
	R7663[65] = (char *(*)()) F898_8786_7663_5;
	R7663[66] = (char *(*)()) F899_8786_7663_5;
	R7663[67] = (char *(*)()) F900_8786_7663_5;
	R7663[68] = (char *(*)()) F901_8786_7663_5;
	R7663[69] = (char *(*)()) F902_8786_7663_5;
	R7663[70] = (char *(*)()) F903_8786_7663_5;
	{long i; for (i = 71; i < 73; i++) R7663[i] = (char *(*)()) F892_8786_7663_5;}
	R7663[73] = (char *(*)()) F895_8786_7663_5;
	R7663[74] = (char *(*)()) F897_8786_7663_5;
	R7663[75] = (char *(*)()) F892_8786_7663_5;
	R7663[80] = (char *(*)()) F892_8786_7663_5;
	R7663[81] = (char *(*)()) F895_8786_7663_5;
	{long i; for (i = 82; i < 86; i++) R7663[i] = (char *(*)()) F892_8786_7663_5;}
	R7663[88] = (char *(*)()) F892_8786_7663_5;
	R7663[91] = (char *(*)()) F892_8786_7663_5;
	{long i; for (i = 93; i < 95; i++) R7663[i] = (char *(*)()) F892_8786_7663_5;}
	R7663[97] = (char *(*)()) F892_8786_7663_5;
	{long i; for (i = 99; i < 105; i++) R7663[i] = (char *(*)()) F892_8786_7663_5;}
	R7663[105] = (char *(*)()) F938_9014_7663_5;
	R7663[106] = (char *(*)()) F939_9014_7663_5;
	R7663[107] = (char *(*)()) F940_9014_7663_5;
	R7663[108] = (char *(*)()) F941_9014_7663_5;
	R7663[109] = (char *(*)()) F942_9014_7663_5;
	R7663[110] = (char *(*)()) F943_9014_7663_5;
	R7663[111] = (char *(*)()) F944_9014_7663_5;
	R7663[112] = (char *(*)()) F945_9014_7663_5;
	R7663[113] = (char *(*)()) F946_9014_7663_5;
	R7663[114] = (char *(*)()) F947_9014_7663_5;
	R7663[115] = (char *(*)()) F948_9014_7663_5;
	R7663[116] = (char *(*)()) F949_9014_7663_5;
	R7663[409] = (char *(*)()) F1242_11271_7663_5;
	R7663[412] = (char *(*)()) F1245_11435_7663_5;
	{long i; for (i = 520; i < 522; i++) R7663[i] = (char *(*)()) F1341_12723_7663_5;}
	{long i; for (i = 539; i < 541; i++) R7663[i] = (char *(*)()) F1341_12723_7663_5;}
	R7663[542] = (char *(*)()) F1341_12723_7663_5;
	R7663[562] = (char *(*)()) F892_8786_7663_5;
	R7663[573] = (char *(*)()) F1341_12723_7663_5;
	R7663[965] = (char *(*)()) F1798_20772_7663_5;
}
static EIF_REFERENCE F833_8573_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F833_8573(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F835_8619_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F835_8619(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F838_8619_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F838_8619(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F840_8619_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F840_8619(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1195, 0x00).id, 1195, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F892_8786_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F892_8786(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F893_8786_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F893_8786(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1498, 0x00).id, 1498, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F894_8786_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F894_8786(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1495, 0x00).id, 1495, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F895_8786_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F895_8786(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F896_8786_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F896_8786(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1504, 0x00).id, 1504, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F897_8786_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F897_8786(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1195, 0x00).id, 1195, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F898_8786_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F898_8786(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F899_8786_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F899_8786(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1192, 0x00).id, 1192, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F900_8786_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F900_8786(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F901_8786_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F901_8786(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1501, 0x00).id, 1501, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F902_8786_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F902_8786(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1507, 0x00).id, 1507, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F903_8786_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F903_8786(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1510, 0x00).id, 1510, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F938_9014_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F938_9014(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F939_9014_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F939_9014(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1498, 0x00).id, 1498, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F940_9014_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F940_9014(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1495, 0x00).id, 1495, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F941_9014_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F941_9014(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F942_9014_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F942_9014(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1504, 0x00).id, 1504, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F943_9014_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F943_9014(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1195, 0x00).id, 1195, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F944_9014_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F944_9014(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F945_9014_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F945_9014(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1192, 0x00).id, 1192, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F946_9014_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F946_9014(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F947_9014_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F947_9014(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1501, 0x00).id, 1501, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F948_9014_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F948_9014(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1507, 0x00).id, 1507, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F949_9014_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F949_9014(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1510, 0x00).id, 1510, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1242_11271_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1242_11271(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1245_11435_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1245_11435(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1192, 0x00).id, 1192, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1341_12723_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1341_12723(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F1798_20772_7663_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1798_20772(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1192, 0x00).id, 1192, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R7664[524])();
void R7664_init () {
	R7664[0] = (char *(*)()) F835_8620_7664_5;
	R7664[1] = (char *(*)()) F838_8620_7664_5;
	R7664[2] = (char *(*)()) F840_8620_7664_5;
	{long i; for (i = 3; i < 5; i++) R7664[i] = (char *(*)()) F835_8620_7664_5;}
	R7664[5] = (char *(*)()) F840_8620_7664_5;
	R7664[6] = (char *(*)()) F838_8620_7664_5;
	{long i; for (i = 7; i < 9; i++) R7664[i] = (char *(*)()) F835_8620_7664_5;}
	R7664[9] = (char *(*)()) F892_8787_7664_5;
	R7664[10] = (char *(*)()) F893_8787_7664_5;
	R7664[11] = (char *(*)()) F894_8787_7664_5;
	R7664[12] = (char *(*)()) F895_8787_7664_5;
	R7664[13] = (char *(*)()) F896_8787_7664_5;
	R7664[14] = (char *(*)()) F897_8787_7664_5;
	R7664[15] = (char *(*)()) F898_8787_7664_5;
	R7664[16] = (char *(*)()) F899_8787_7664_5;
	R7664[17] = (char *(*)()) F900_8787_7664_5;
	R7664[18] = (char *(*)()) F901_8787_7664_5;
	R7664[19] = (char *(*)()) F902_8787_7664_5;
	R7664[20] = (char *(*)()) F903_8787_7664_5;
	{long i; for (i = 21; i < 23; i++) R7664[i] = (char *(*)()) F892_8787_7664_5;}
	R7664[23] = (char *(*)()) F895_8787_7664_5;
	R7664[24] = (char *(*)()) F897_8787_7664_5;
	R7664[25] = (char *(*)()) F892_8787_7664_5;
	R7664[30] = (char *(*)()) F892_8787_7664_5;
	R7664[31] = (char *(*)()) F895_8787_7664_5;
	{long i; for (i = 32; i < 36; i++) R7664[i] = (char *(*)()) F892_8787_7664_5;}
	R7664[38] = (char *(*)()) F892_8787_7664_5;
	R7664[41] = (char *(*)()) F892_8787_7664_5;
	{long i; for (i = 43; i < 45; i++) R7664[i] = (char *(*)()) F892_8787_7664_5;}
	R7664[47] = (char *(*)()) F892_8787_7664_5;
	{long i; for (i = 49; i < 55; i++) R7664[i] = (char *(*)()) F892_8787_7664_5;}
	R7664[55] = (char *(*)()) F938_9015_7664_5;
	R7664[56] = (char *(*)()) F939_9015_7664_5;
	R7664[57] = (char *(*)()) F940_9015_7664_5;
	R7664[58] = (char *(*)()) F941_9015_7664_5;
	R7664[59] = (char *(*)()) F942_9015_7664_5;
	R7664[60] = (char *(*)()) F943_9015_7664_5;
	R7664[61] = (char *(*)()) F944_9015_7664_5;
	R7664[62] = (char *(*)()) F945_9015_7664_5;
	R7664[63] = (char *(*)()) F946_9015_7664_5;
	R7664[64] = (char *(*)()) F947_9015_7664_5;
	R7664[65] = (char *(*)()) F948_9015_7664_5;
	R7664[66] = (char *(*)()) F949_9015_7664_5;
	R7664[359] = (char *(*)()) F1242_11272_7664_5;
	{long i; for (i = 470; i < 472; i++) R7664[i] = (char *(*)()) F835_8620_7664_5;}
	{long i; for (i = 489; i < 491; i++) R7664[i] = (char *(*)()) F835_8620_7664_5;}
	R7664[492] = (char *(*)()) F835_8620_7664_5;
	R7664[512] = (char *(*)()) F892_8787_7664_5;
	R7664[523] = (char *(*)()) F835_8620_7664_5;
}
static EIF_REFERENCE F835_8620_7664_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F835_8620(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F838_8620_7664_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F838_8620(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F840_8620_7664_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F840_8620(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1195, 0x00).id, 1195, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F892_8787_7664_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F892_8787(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F893_8787_7664_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F893_8787(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1498, 0x00).id, 1498, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F894_8787_7664_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F894_8787(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1495, 0x00).id, 1495, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F895_8787_7664_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F895_8787(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F896_8787_7664_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F896_8787(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1504, 0x00).id, 1504, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F897_8787_7664_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F897_8787(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1195, 0x00).id, 1195, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F898_8787_7664_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F898_8787(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F899_8787_7664_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F899_8787(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1192, 0x00).id, 1192, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F900_8787_7664_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F900_8787(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F901_8787_7664_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F901_8787(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1501, 0x00).id, 1501, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F902_8787_7664_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F902_8787(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1507, 0x00).id, 1507, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F903_8787_7664_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F903_8787(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1510, 0x00).id, 1510, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F938_9015_7664_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F938_9015(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F939_9015_7664_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F939_9015(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1498, 0x00).id, 1498, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F940_9015_7664_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F940_9015(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1495, 0x00).id, 1495, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F941_9015_7664_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F941_9015(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F942_9015_7664_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F942_9015(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1504, 0x00).id, 1504, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F943_9015_7664_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F943_9015(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1195, 0x00).id, 1195, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F944_9015_7664_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F944_9015(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F945_9015_7664_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F945_9015(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1192, 0x00).id, 1192, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F946_9015_7664_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F946_9015(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F947_9015_7664_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F947_9015(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1501, 0x00).id, 1501, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F948_9015_7664_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F948_9015(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1507, 0x00).id, 1507, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F949_9015_7664_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F949_9015(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1510, 0x00).id, 1510, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1242_11272_7664_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1242_11272(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}

char *(*R7666[993])();
void R7666_init () {
	R7666[0] = (char *(*)()) F806_8482;
	R7666[1] = (char *(*)()) F807_8482_7666_37;
	R7666[2] = (char *(*)()) F808_8482_7666_37;
	R7666[3] = (char *(*)()) F809_8482_7666_37;
	R7666[4] = (char *(*)()) F810_8482_7666_37;
	R7666[5] = (char *(*)()) F811_8482_7666_37;
	R7666[6] = (char *(*)()) F812_8482_7666_37;
	R7666[7] = (char *(*)()) F813_8482_7666_37;
	R7666[8] = (char *(*)()) F814_8482_7666_37;
	R7666[9] = (char *(*)()) F806_8482;
	R7666[10] = (char *(*)()) F807_8482_7666_37;
	R7666[11] = (char *(*)()) F809_8482_7666_37;
	R7666[12] = (char *(*)()) F813_8482_7666_37;
	R7666[13] = (char *(*)()) F814_8482_7666_37;
	R7666[14] = (char *(*)()) F806_8482;
	R7666[86] = (char *(*)()) F892_8819_7666_37;
	R7666[87] = (char *(*)()) F893_8819_7666_37;
	R7666[88] = (char *(*)()) F894_8819_7666_37;
	R7666[89] = (char *(*)()) F895_8819_7666_37;
	R7666[90] = (char *(*)()) F896_8819_7666_37;
	R7666[91] = (char *(*)()) F897_8819_7666_37;
	R7666[92] = (char *(*)()) F898_8819_7666_37;
	R7666[93] = (char *(*)()) F899_8819_7666_37;
	R7666[94] = (char *(*)()) F900_8819_7666_37;
	R7666[95] = (char *(*)()) F901_8819_7666_37;
	R7666[96] = (char *(*)()) F902_8819_7666_37;
	R7666[97] = (char *(*)()) F903_8819_7666_37;
	{long i; for (i = 98; i < 100; i++) R7666[i] = (char *(*)()) F892_8819_7666_37;}
	R7666[100] = (char *(*)()) F895_8819_7666_37;
	R7666[101] = (char *(*)()) F897_8819_7666_37;
	R7666[102] = (char *(*)()) F892_8819_7666_37;
	R7666[107] = (char *(*)()) F909_8879_7666_37;
	R7666[108] = (char *(*)()) F910_8879_7666_37;
	{long i; for (i = 109; i < 113; i++) R7666[i] = (char *(*)()) F909_8879_7666_37;}
	R7666[115] = (char *(*)()) F909_8879_7666_37;
	R7666[118] = (char *(*)()) F909_8879_7666_37;
	{long i; for (i = 120; i < 122; i++) R7666[i] = (char *(*)()) F909_8879_7666_37;}
	R7666[124] = (char *(*)()) F909_8879_7666_37;
	{long i; for (i = 126; i < 132; i++) R7666[i] = (char *(*)()) F909_8879_7666_37;}
	R7666[132] = (char *(*)()) F938_9033_7666_37;
	R7666[133] = (char *(*)()) F939_9033_7666_37;
	R7666[134] = (char *(*)()) F940_9033_7666_37;
	R7666[135] = (char *(*)()) F941_9033_7666_37;
	R7666[136] = (char *(*)()) F942_9033_7666_37;
	R7666[137] = (char *(*)()) F943_9033_7666_37;
	R7666[138] = (char *(*)()) F944_9033_7666_37;
	R7666[139] = (char *(*)()) F945_9033_7666_37;
	R7666[140] = (char *(*)()) F946_9033_7666_37;
	R7666[141] = (char *(*)()) F947_9033_7666_37;
	R7666[142] = (char *(*)()) F948_9033_7666_37;
	R7666[143] = (char *(*)()) F949_9033_7666_37;
	R7666[436] = (char *(*)()) F1242_11291_7666_37;
	R7666[439] = (char *(*)()) F1245_11456_7666_37;
	R7666[589] = (char *(*)()) F909_8879_7666_37;
	R7666[992] = (char *(*)()) F1798_20807_7666_37;
}
static void F807_8482_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F807_8482(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F808_8482_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F808_8482(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F809_8482_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F809_8482(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F810_8482_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F810_8482(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F811_8482_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F811_8482(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_NATURAL_32 *)arg2);
}
static void F812_8482_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F812_8482(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F813_8482_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F813_8482(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F814_8482_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F814_8482(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F892_8819_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F892_8819(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F893_8819_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F893_8819(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F894_8819_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F894_8819(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F895_8819_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F895_8819(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F896_8819_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F896_8819(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F897_8819_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F897_8819(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F898_8819_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F898_8819(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F899_8819_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F899_8819(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F900_8819_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F900_8819(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F901_8819_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F901_8819(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F902_8819_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F902_8819(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F903_8819_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F903_8819(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F909_8879_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F909_8879(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F910_8879_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F910_8879(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F938_9033_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F938_9033(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F939_9033_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F939_9033(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F940_9033_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F940_9033(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F941_9033_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F941_9033(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F942_9033_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F942_9033(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F943_9033_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F943_9033(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F944_9033_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F944_9033(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F945_9033_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F945_9033(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F946_9033_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F946_9033(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F947_9033_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F947_9033(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F948_9033_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F948_9033(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F949_9033_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F949_9033(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1242_11291_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1242_11291(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1245_11456_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1245_11456(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1798_20807_7666_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1798_20807(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R7667[993])();
void R7667_init () {
	R7667[0] = (char *(*)()) F806_8483;
	R7667[1] = (char *(*)()) F807_8483_7667_37;
	R7667[2] = (char *(*)()) F808_8483_7667_37;
	R7667[3] = (char *(*)()) F809_8483_7667_37;
	R7667[4] = (char *(*)()) F810_8483_7667_37;
	R7667[5] = (char *(*)()) F811_8483_7667_37;
	R7667[6] = (char *(*)()) F812_8483_7667_37;
	R7667[7] = (char *(*)()) F813_8483_7667_37;
	R7667[8] = (char *(*)()) F814_8483_7667_37;
	R7667[9] = (char *(*)()) F806_8483;
	R7667[10] = (char *(*)()) F807_8483_7667_37;
	R7667[11] = (char *(*)()) F809_8483_7667_37;
	R7667[12] = (char *(*)()) F813_8483_7667_37;
	R7667[13] = (char *(*)()) F814_8483_7667_37;
	R7667[14] = (char *(*)()) F806_8483;
	R7667[86] = (char *(*)()) F892_8819_7667_37;
	R7667[87] = (char *(*)()) F893_8819_7667_37;
	R7667[88] = (char *(*)()) F894_8819_7667_37;
	R7667[89] = (char *(*)()) F895_8819_7667_37;
	R7667[90] = (char *(*)()) F896_8819_7667_37;
	R7667[91] = (char *(*)()) F897_8819_7667_37;
	R7667[92] = (char *(*)()) F898_8819_7667_37;
	R7667[93] = (char *(*)()) F899_8819_7667_37;
	R7667[94] = (char *(*)()) F900_8819_7667_37;
	R7667[95] = (char *(*)()) F901_8819_7667_37;
	R7667[96] = (char *(*)()) F902_8819_7667_37;
	R7667[97] = (char *(*)()) F903_8819_7667_37;
	{long i; for (i = 98; i < 100; i++) R7667[i] = (char *(*)()) F892_8819_7667_37;}
	R7667[100] = (char *(*)()) F895_8819_7667_37;
	R7667[101] = (char *(*)()) F897_8819_7667_37;
	R7667[102] = (char *(*)()) F892_8819_7667_37;
	R7667[107] = (char *(*)()) F909_8879_7667_37;
	R7667[108] = (char *(*)()) F910_8879_7667_37;
	{long i; for (i = 109; i < 113; i++) R7667[i] = (char *(*)()) F909_8879_7667_37;}
	R7667[115] = (char *(*)()) F909_8879_7667_37;
	R7667[118] = (char *(*)()) F909_8879_7667_37;
	{long i; for (i = 120; i < 122; i++) R7667[i] = (char *(*)()) F909_8879_7667_37;}
	R7667[124] = (char *(*)()) F909_8879_7667_37;
	{long i; for (i = 126; i < 132; i++) R7667[i] = (char *(*)()) F909_8879_7667_37;}
	R7667[132] = (char *(*)()) F938_9033_7667_37;
	R7667[133] = (char *(*)()) F939_9033_7667_37;
	R7667[134] = (char *(*)()) F940_9033_7667_37;
	R7667[135] = (char *(*)()) F941_9033_7667_37;
	R7667[136] = (char *(*)()) F942_9033_7667_37;
	R7667[137] = (char *(*)()) F943_9033_7667_37;
	R7667[138] = (char *(*)()) F944_9033_7667_37;
	R7667[139] = (char *(*)()) F945_9033_7667_37;
	R7667[140] = (char *(*)()) F946_9033_7667_37;
	R7667[141] = (char *(*)()) F947_9033_7667_37;
	R7667[142] = (char *(*)()) F948_9033_7667_37;
	R7667[143] = (char *(*)()) F949_9033_7667_37;
	R7667[436] = (char *(*)()) F1242_11291_7667_37;
	R7667[439] = (char *(*)()) F1245_11456_7667_37;
	R7667[589] = (char *(*)()) F909_8879_7667_37;
	R7667[992] = (char *(*)()) F1798_20807_7667_37;
}
static void F807_8483_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F807_8483(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F808_8483_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F808_8483(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F809_8483_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F809_8483(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F810_8483_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F810_8483(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F811_8483_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F811_8483(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_NATURAL_32 *)arg2);
}
static void F812_8483_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F812_8483(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F813_8483_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F813_8483(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F814_8483_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F814_8483(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F892_8819_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F892_8819(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F893_8819_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F893_8819(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F894_8819_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F894_8819(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F895_8819_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F895_8819(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F896_8819_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F896_8819(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F897_8819_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F897_8819(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F898_8819_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F898_8819(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F899_8819_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F899_8819(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F900_8819_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F900_8819(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F901_8819_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F901_8819(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F902_8819_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F902_8819(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F903_8819_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F903_8819(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F909_8879_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F909_8879(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F910_8879_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F910_8879(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F938_9033_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F938_9033(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F939_9033_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F939_9033(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F940_9033_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F940_9033(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F941_9033_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F941_9033(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F942_9033_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F942_9033(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F943_9033_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F943_9033(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F944_9033_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F944_9033(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F945_9033_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F945_9033(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F946_9033_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F946_9033(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F947_9033_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F947_9033(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F948_9033_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F948_9033(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F949_9033_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F949_9033(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1242_11291_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1242_11291(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1245_11456_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1245_11456(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1798_20807_7667_37 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1798_20807(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

static EIF_TYPE_INDEX Y7668_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype30[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype31[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype32[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype33[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype34[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype35[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype36[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype37[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype38[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype39[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype40[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype41[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype42[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype43[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype44[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype45[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype46[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype47[] = {1236,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype48[] = {1236,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype49[] = {1236,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype50[] = {1236,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype51[] = {1236,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype52[] = {1244,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype53[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype54[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype55[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype56[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype57[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype58[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype59[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype60[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype61[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype62[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype63[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype64[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype65[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype66[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype67[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype68[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype69[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype70[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype71[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype72[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype73[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype74[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype75[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype76[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype77[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype78[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype79[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype80[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype81[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype82[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype83[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype84[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype85[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype86[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype87[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype88[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype89[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype90[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype91[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype92[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype93[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype94[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype95[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype96[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype97[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype98[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype99[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype100[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype101[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype102[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype103[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype104[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype105[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype106[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype107[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype108[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype109[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype110[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype111[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype112[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype113[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype114[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype115[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype116[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype117[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype118[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype119[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype120[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype121[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype122[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype123[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype124[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype125[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype126[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype127[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype128[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype129[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype130[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype131[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype132[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype133[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype134[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype135[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype136[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype137[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype138[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype139[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype140[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype141[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype142[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype143[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype144[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype145[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype146[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype147[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype148[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype149[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype150[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype151[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype152[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype153[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype154[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype155[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype156[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype157[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype158[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype159[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype160[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype161[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype162[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype163[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype164[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype165[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype166[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype167[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype168[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype169[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype170[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype171[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype172[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype173[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype174[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype175[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype176[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype177[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype178[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype179[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype180[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype181[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype182[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype183[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype184[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype185[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype186[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype187[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype188[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype189[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype190[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype191[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype192[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype193[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype194[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype195[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype196[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype197[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype198[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype199[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype200[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype201[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype202[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype203[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype204[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype205[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype206[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype207[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype208[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype209[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype210[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype211[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype212[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype213[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype214[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y7668_pgtype215[] = {1486,0xFFFF};
EIF_TYPE_INDEX *Y7668_gen_type [1158];
EIF_TYPE_INDEX Y7668 [1158];
void Y7668_init (void)
{
	egc_routines_types [7668] = Y7668;
	egc_routines_gen_types [7668] = Y7668_gen_type;
	egc_routines_offset [7668] = 641;
	Y7668_gen_type [0] = Y7668_pgtype0;
	Y7668_gen_type [1] = Y7668_pgtype1;
	Y7668_gen_type [2] = Y7668_pgtype2;
	Y7668_gen_type [3] = Y7668_pgtype3;
	Y7668_gen_type [4] = Y7668_pgtype4;
	Y7668_gen_type [5] = Y7668_pgtype5;
	Y7668_gen_type [6] = Y7668_pgtype6;
	Y7668_gen_type [7] = Y7668_pgtype7;
	Y7668_gen_type [8] = Y7668_pgtype8;
	Y7668_gen_type [9] = Y7668_pgtype9;
	Y7668_gen_type [10] = Y7668_pgtype10;
	Y7668_gen_type [11] = Y7668_pgtype11;
	Y7668_gen_type [12] = Y7668_pgtype12;
	Y7668_gen_type [13] = Y7668_pgtype13;
	Y7668_gen_type [14] = Y7668_pgtype14;
	Y7668_gen_type [15] = Y7668_pgtype15;
	Y7668_gen_type [16] = Y7668_pgtype16;
	Y7668_gen_type [17] = Y7668_pgtype17;
	Y7668_gen_type [18] = Y7668_pgtype18;
	Y7668_gen_type [19] = Y7668_pgtype19;
	Y7668_gen_type [20] = Y7668_pgtype20;
	Y7668_gen_type [21] = Y7668_pgtype21;
	Y7668_gen_type [22] = Y7668_pgtype22;
	Y7668_gen_type [23] = Y7668_pgtype23;
	Y7668_gen_type [24] = Y7668_pgtype24;
	Y7668_gen_type [25] = Y7668_pgtype25;
	Y7668_gen_type [26] = Y7668_pgtype26;
	Y7668_gen_type [27] = Y7668_pgtype27;
	Y7668_gen_type [28] = Y7668_pgtype28;
	Y7668_gen_type [29] = Y7668_pgtype29;
	Y7668_gen_type [30] = Y7668_pgtype30;
	Y7668_gen_type [31] = Y7668_pgtype31;
	Y7668_gen_type [32] = Y7668_pgtype32;
	Y7668_gen_type [33] = Y7668_pgtype33;
	Y7668_gen_type [34] = Y7668_pgtype34;
	Y7668_gen_type [35] = Y7668_pgtype35;
	Y7668_gen_type [36] = Y7668_pgtype36;
	Y7668_gen_type [37] = Y7668_pgtype37;
	Y7668_gen_type [164] = Y7668_pgtype38;
	Y7668_gen_type [165] = Y7668_pgtype39;
	Y7668_gen_type [166] = Y7668_pgtype40;
	Y7668_gen_type [167] = Y7668_pgtype41;
	Y7668_gen_type [168] = Y7668_pgtype42;
	Y7668_gen_type [169] = Y7668_pgtype43;
	Y7668_gen_type [170] = Y7668_pgtype44;
	Y7668_gen_type [171] = Y7668_pgtype45;
	Y7668_gen_type [172] = Y7668_pgtype46;
	Y7668_gen_type [173] = Y7668_pgtype47;
	Y7668_gen_type [174] = Y7668_pgtype48;
	Y7668_gen_type [175] = Y7668_pgtype49;
	Y7668_gen_type [176] = Y7668_pgtype50;
	Y7668_gen_type [177] = Y7668_pgtype51;
	Y7668_gen_type [178] = Y7668_pgtype52;
	Y7668_gen_type [179] = Y7668_pgtype53;
	Y7668_gen_type [180] = Y7668_pgtype54;
	Y7668_gen_type [181] = Y7668_pgtype55;
	Y7668_gen_type [182] = Y7668_pgtype56;
	Y7668_gen_type [183] = Y7668_pgtype57;
	Y7668_gen_type [184] = Y7668_pgtype58;
	Y7668_gen_type [185] = Y7668_pgtype59;
	Y7668_gen_type [186] = Y7668_pgtype60;
	Y7668_gen_type [187] = Y7668_pgtype61;
	Y7668_gen_type [188] = Y7668_pgtype62;
	Y7668_gen_type [189] = Y7668_pgtype63;
	Y7668_gen_type [190] = Y7668_pgtype64;
	Y7668_gen_type [191] = Y7668_pgtype65;
	Y7668_gen_type [192] = Y7668_pgtype66;
	Y7668_gen_type [193] = Y7668_pgtype67;
	Y7668_gen_type [194] = Y7668_pgtype68;
	Y7668_gen_type [195] = Y7668_pgtype69;
	Y7668_gen_type [196] = Y7668_pgtype70;
	Y7668_gen_type [197] = Y7668_pgtype71;
	Y7668_gen_type [198] = Y7668_pgtype72;
	Y7668_gen_type [199] = Y7668_pgtype73;
	Y7668_gen_type [200] = Y7668_pgtype74;
	Y7668_gen_type [201] = Y7668_pgtype75;
	Y7668_gen_type [202] = Y7668_pgtype76;
	Y7668_gen_type [203] = Y7668_pgtype77;
	Y7668_gen_type [204] = Y7668_pgtype78;
	Y7668_gen_type [205] = Y7668_pgtype79;
	Y7668_gen_type [206] = Y7668_pgtype80;
	Y7668_gen_type [207] = Y7668_pgtype81;
	Y7668_gen_type [208] = Y7668_pgtype82;
	Y7668_gen_type [209] = Y7668_pgtype83;
	Y7668_gen_type [210] = Y7668_pgtype84;
	Y7668_gen_type [211] = Y7668_pgtype85;
	Y7668_gen_type [212] = Y7668_pgtype86;
	Y7668_gen_type [213] = Y7668_pgtype87;
	Y7668_gen_type [214] = Y7668_pgtype88;
	Y7668_gen_type [215] = Y7668_pgtype89;
	Y7668_gen_type [216] = Y7668_pgtype90;
	Y7668_gen_type [217] = Y7668_pgtype91;
	Y7668_gen_type [218] = Y7668_pgtype92;
	Y7668_gen_type [219] = Y7668_pgtype93;
	Y7668_gen_type [220] = Y7668_pgtype94;
	Y7668_gen_type [221] = Y7668_pgtype95;
	Y7668_gen_type [222] = Y7668_pgtype96;
	Y7668_gen_type [223] = Y7668_pgtype97;
	Y7668_gen_type [224] = Y7668_pgtype98;
	Y7668_gen_type [225] = Y7668_pgtype99;
	Y7668_gen_type [226] = Y7668_pgtype100;
	Y7668_gen_type [227] = Y7668_pgtype101;
	Y7668_gen_type [228] = Y7668_pgtype102;
	Y7668_gen_type [229] = Y7668_pgtype103;
	Y7668_gen_type [230] = Y7668_pgtype104;
	Y7668_gen_type [231] = Y7668_pgtype105;
	Y7668_gen_type [232] = Y7668_pgtype106;
	Y7668_gen_type [233] = Y7668_pgtype107;
	Y7668_gen_type [234] = Y7668_pgtype108;
	Y7668_gen_type [235] = Y7668_pgtype109;
	Y7668_gen_type [236] = Y7668_pgtype110;
	Y7668_gen_type [237] = Y7668_pgtype111;
	Y7668_gen_type [238] = Y7668_pgtype112;
	Y7668_gen_type [239] = Y7668_pgtype113;
	Y7668_gen_type [240] = Y7668_pgtype114;
	Y7668_gen_type [241] = Y7668_pgtype115;
	Y7668_gen_type [242] = Y7668_pgtype116;
	Y7668_gen_type [243] = Y7668_pgtype117;
	Y7668_gen_type [244] = Y7668_pgtype118;
	Y7668_gen_type [245] = Y7668_pgtype119;
	Y7668_gen_type [246] = Y7668_pgtype120;
	Y7668_gen_type [247] = Y7668_pgtype121;
	Y7668_gen_type [248] = Y7668_pgtype122;
	Y7668_gen_type [249] = Y7668_pgtype123;
	Y7668_gen_type [250] = Y7668_pgtype124;
	Y7668_gen_type [251] = Y7668_pgtype125;
	Y7668_gen_type [252] = Y7668_pgtype126;
	Y7668_gen_type [253] = Y7668_pgtype127;
	Y7668_gen_type [254] = Y7668_pgtype128;
	Y7668_gen_type [255] = Y7668_pgtype129;
	Y7668_gen_type [256] = Y7668_pgtype130;
	Y7668_gen_type [257] = Y7668_pgtype131;
	Y7668_gen_type [258] = Y7668_pgtype132;
	Y7668_gen_type [259] = Y7668_pgtype133;
	Y7668_gen_type [260] = Y7668_pgtype134;
	Y7668_gen_type [261] = Y7668_pgtype135;
	Y7668_gen_type [262] = Y7668_pgtype136;
	Y7668_gen_type [263] = Y7668_pgtype137;
	Y7668_gen_type [264] = Y7668_pgtype138;
	Y7668_gen_type [265] = Y7668_pgtype139;
	Y7668_gen_type [266] = Y7668_pgtype140;
	Y7668_gen_type [267] = Y7668_pgtype141;
	Y7668_gen_type [268] = Y7668_pgtype142;
	Y7668_gen_type [269] = Y7668_pgtype143;
	Y7668_gen_type [270] = Y7668_pgtype144;
	Y7668_gen_type [271] = Y7668_pgtype145;
	Y7668_gen_type [272] = Y7668_pgtype146;
	Y7668_gen_type [273] = Y7668_pgtype147;
	Y7668_gen_type [274] = Y7668_pgtype148;
	Y7668_gen_type [275] = Y7668_pgtype149;
	Y7668_gen_type [276] = Y7668_pgtype150;
	Y7668_gen_type [277] = Y7668_pgtype151;
	Y7668_gen_type [278] = Y7668_pgtype152;
	Y7668_gen_type [279] = Y7668_pgtype153;
	Y7668_gen_type [280] = Y7668_pgtype154;
	Y7668_gen_type [281] = Y7668_pgtype155;
	Y7668_gen_type [282] = Y7668_pgtype156;
	Y7668_gen_type [283] = Y7668_pgtype157;
	Y7668_gen_type [284] = Y7668_pgtype158;
	Y7668_gen_type [285] = Y7668_pgtype159;
	Y7668_gen_type [286] = Y7668_pgtype160;
	Y7668_gen_type [287] = Y7668_pgtype161;
	Y7668_gen_type [288] = Y7668_pgtype162;
	Y7668_gen_type [289] = Y7668_pgtype163;
	Y7668_gen_type [290] = Y7668_pgtype164;
	Y7668_gen_type [291] = Y7668_pgtype165;
	Y7668_gen_type [292] = Y7668_pgtype166;
	Y7668_gen_type [293] = Y7668_pgtype167;
	Y7668_gen_type [294] = Y7668_pgtype168;
	Y7668_gen_type [295] = Y7668_pgtype169;
	Y7668_gen_type [296] = Y7668_pgtype170;
	Y7668_gen_type [297] = Y7668_pgtype171;
	Y7668_gen_type [298] = Y7668_pgtype172;
	Y7668_gen_type [299] = Y7668_pgtype173;
	Y7668_gen_type [300] = Y7668_pgtype174;
	Y7668_gen_type [301] = Y7668_pgtype175;
	Y7668_gen_type [302] = Y7668_pgtype176;
	Y7668_gen_type [303] = Y7668_pgtype177;
	Y7668_gen_type [304] = Y7668_pgtype178;
	Y7668_gen_type [305] = Y7668_pgtype179;
	Y7668_gen_type [306] = Y7668_pgtype180;
	Y7668_gen_type [307] = Y7668_pgtype181;
	Y7668_gen_type [308] = Y7668_pgtype182;
	Y7668_gen_type [309] = Y7668_pgtype183;
	Y7668_gen_type [310] = Y7668_pgtype184;
	Y7668_gen_type [311] = Y7668_pgtype185;
	Y7668_gen_type [312] = Y7668_pgtype186;
	Y7668_gen_type [313] = Y7668_pgtype187;
	Y7668_gen_type [600] = Y7668_pgtype188;
	Y7668_gen_type [603] = Y7668_pgtype189;
	Y7668_gen_type [604] = Y7668_pgtype190;
	Y7668_gen_type [605] = Y7668_pgtype191;
	Y7668_gen_type [699] = Y7668_pgtype192;
	Y7668_gen_type [700] = Y7668_pgtype193;
	Y7668_gen_type [701] = Y7668_pgtype194;
	Y7668_gen_type [702] = Y7668_pgtype195;
	Y7668_gen_type [703] = Y7668_pgtype196;
	Y7668_gen_type [707] = Y7668_pgtype197;
	Y7668_gen_type [708] = Y7668_pgtype198;
	Y7668_gen_type [709] = Y7668_pgtype199;
	Y7668_gen_type [710] = Y7668_pgtype200;
	Y7668_gen_type [711] = Y7668_pgtype201;
	Y7668_gen_type [712] = Y7668_pgtype202;
	Y7668_gen_type [728] = Y7668_pgtype203;
	Y7668_gen_type [730] = Y7668_pgtype204;
	Y7668_gen_type [731] = Y7668_pgtype205;
	Y7668_gen_type [733] = Y7668_pgtype206;
	Y7668_gen_type [740] = Y7668_pgtype207;
	Y7668_gen_type [741] = Y7668_pgtype208;
	Y7668_gen_type [744] = Y7668_pgtype209;
	Y7668_gen_type [753] = Y7668_pgtype210;
	Y7668_gen_type [754] = Y7668_pgtype211;
	Y7668_gen_type [755] = Y7668_pgtype212;
	Y7668_gen_type [764] = Y7668_pgtype213;
	Y7668_gen_type [1156] = Y7668_pgtype214;
	Y7668_gen_type [1157] = Y7668_pgtype215;
	{long i; for (i = 173; i < 178; i++) Y7668[i] = 1236;};
	Y7668[178] = 1244;
	{long i; for (i = 179; i < 314; i++) Y7668[i] = 1486;};
	Y7668[600] = 1486;
	{long i; for (i = 603; i < 606; i++) Y7668[i] = 1486;};
	{long i; for (i = 699; i < 704; i++) Y7668[i] = 1486;};
	{long i; for (i = 707; i < 713; i++) Y7668[i] = 1486;};
	Y7668[728] = 1486;
	{long i; for (i = 730; i < 732; i++) Y7668[i] = 1486;};
	Y7668[733] = 1486;
	{long i; for (i = 740; i < 742; i++) Y7668[i] = 1486;};
	Y7668[744] = 1486;
	{long i; for (i = 753; i < 756; i++) Y7668[i] = 1486;};
	Y7668[764] = 1486;
	{long i; for (i = 1156; i < 1158; i++) Y7668[i] = 1486;};
}

char *(*R7669[993])();
void R7669_init () {
	R7669[0] = (char *(*)()) F806_8488;
	R7669[1] = (char *(*)()) F807_8488;
	R7669[2] = (char *(*)()) F808_8488_7669_4;
	R7669[3] = (char *(*)()) F809_8488;
	R7669[4] = (char *(*)()) F810_8488_7669_4;
	R7669[5] = (char *(*)()) F811_8488_7669_4;
	R7669[6] = (char *(*)()) F812_8488;
	R7669[7] = (char *(*)()) F813_8488;
	R7669[8] = (char *(*)()) F814_8488;
	R7669[9] = (char *(*)()) F806_8488;
	R7669[10] = (char *(*)()) F807_8488;
	R7669[11] = (char *(*)()) F809_8488;
	R7669[12] = (char *(*)()) F813_8488;
	R7669[13] = (char *(*)()) F814_8488;
	R7669[14] = (char *(*)()) F806_8488;
	R7669[436] = (char *(*)()) F1242_11325_7669_4;
	R7669[439] = (char *(*)()) F1245_11490_7669_4;
	R7669[992] = (char *(*)()) F1798_20838_7669_4;
}
static void F808_8488_7669_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F808_8488(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F810_8488_7669_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F810_8488(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F811_8488_7669_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F811_8488(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F1242_11325_7669_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1242_11325(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1245_11490_7669_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1245_11490(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1798_20838_7669_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1798_20838(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R7670[936])();
void R7670_init () {
	R7670[0] = (char *(*)()) F781_8399;
	R7670[102] = (char *(*)()) F883_8667;
	R7670[103] = (char *(*)()) F884_8667_7670_1;
	R7670[104] = (char *(*)()) F885_8667_7670_1;
	R7670[105] = (char *(*)()) F883_8667;
	R7670[106] = (char *(*)()) F887_8722;
	R7670[107] = (char *(*)()) F888_8722_7670_1;
	R7670[108] = (char *(*)()) F889_8722_7670_1;
	R7670[109] = (char *(*)()) F890_8737;
	R7670[110] = (char *(*)()) F883_8667;
	R7670[111] = (char *(*)()) F892_8785;
	R7670[112] = (char *(*)()) F893_8785_7670_1;
	R7670[113] = (char *(*)()) F894_8785_7670_1;
	R7670[114] = (char *(*)()) F895_8785_7670_1;
	R7670[115] = (char *(*)()) F896_8785_7670_1;
	R7670[116] = (char *(*)()) F897_8785_7670_1;
	R7670[117] = (char *(*)()) F898_8785_7670_1;
	R7670[118] = (char *(*)()) F899_8785_7670_1;
	R7670[119] = (char *(*)()) F900_8785_7670_1;
	R7670[120] = (char *(*)()) F901_8785_7670_1;
	R7670[121] = (char *(*)()) F902_8785_7670_1;
	R7670[122] = (char *(*)()) F903_8785_7670_1;
	{long i; for (i = 123; i < 125; i++) R7670[i] = (char *(*)()) F892_8785;}
	R7670[125] = (char *(*)()) F895_8785_7670_1;
	R7670[126] = (char *(*)()) F897_8785_7670_1;
	R7670[127] = (char *(*)()) F892_8785;
	R7670[132] = (char *(*)()) F892_8785;
	R7670[133] = (char *(*)()) F895_8785_7670_1;
	{long i; for (i = 134; i < 138; i++) R7670[i] = (char *(*)()) F892_8785;}
	R7670[140] = (char *(*)()) F892_8785;
	R7670[143] = (char *(*)()) F892_8785;
	{long i; for (i = 145; i < 147; i++) R7670[i] = (char *(*)()) F892_8785;}
	R7670[149] = (char *(*)()) F892_8785;
	{long i; for (i = 151; i < 157; i++) R7670[i] = (char *(*)()) F892_8785;}
	R7670[189] = (char *(*)()) F723_8319_7670_1;
	R7670[196] = (char *(*)()) F723_8319_7670_1;
	{long i; for (i = 366; i < 368; i++) R7670[i] = (char *(*)()) F1146_10054_7670_1;}
	{long i; for (i = 572; i < 574; i++) R7670[i] = (char *(*)()) F1341_12720;}
	{long i; for (i = 591; i < 593; i++) R7670[i] = (char *(*)()) F1341_12720;}
	R7670[594] = (char *(*)()) F1341_12720;
	R7670[614] = (char *(*)()) F892_8785;
	R7670[625] = (char *(*)()) F1341_12720;
	R7670[935] = (char *(*)()) F1146_10054_7670_1;
}
static EIF_REFERENCE F884_8667_7670_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F884_8667(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F885_8667_7670_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F885_8667(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1195, 0x00).id, 1195, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F888_8722_7670_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F888_8722(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1195, 0x00).id, 1195, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F889_8722_7670_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F889_8722(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F893_8785_7670_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F893_8785(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1498, 0x00).id, 1498, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F894_8785_7670_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F894_8785(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1495, 0x00).id, 1495, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F895_8785_7670_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F895_8785(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F896_8785_7670_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F896_8785(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1504, 0x00).id, 1504, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F897_8785_7670_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F897_8785(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1195, 0x00).id, 1195, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F898_8785_7670_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F898_8785(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F899_8785_7670_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F899_8785(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1192, 0x00).id, 1192, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F900_8785_7670_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F900_8785(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F901_8785_7670_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F901_8785(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1501, 0x00).id, 1501, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F902_8785_7670_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F902_8785(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1507, 0x00).id, 1507, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F903_8785_7670_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F903_8785(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1510, 0x00).id, 1510, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F723_8319_7670_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F723_8319(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1146_10054_7670_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1146_10054(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1192, 0x00).id, 1192, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y7670_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype123[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype124[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype125[] = {1230,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype126[] = {1230,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype127[] = {1230,0xFFF9,1,1186,0,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype128[] = {1230,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype129[] = {1230,0xFFF9,1,1186,1486,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype130[] = {1230,0xFFF9,1,1186,1401,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype131[] = {1230,0xFFF9,1,1186,1346,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype132[] = {1230,0xFFF9,1,1186,1154,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype133[] = {1230,0xFFF9,1,1186,1265,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype134[] = {1230,0xFFF9,1,1186,1486,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype135[] = {1230,0xFFF9,1,1186,1394,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype136[] = {1230,0xFFF9,1,1186,1393,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype137[] = {1230,0xFFF9,1,1186,1241,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype138[] = {1230,0xFFF9,1,1186,1486,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype139[] = {1230,0xFFF9,1,1186,1714,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype140[] = {1230,0xFFF9,5,1186,1498,1486,1486,1486,1486,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype141[] = {1230,0xFFF9,7,1186,1486,1486,1510,1510,1510,1486,1486,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype142[] = {1230,0xFFF9,2,1186,1486,1486,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype143[] = {1230,0xFFF9,4,1186,1486,1486,1486,1486,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype144[] = {1230,0xFFF9,3,1186,1486,1486,1154,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype145[] = {1230,0xFFF9,8,1186,1486,1486,1486,1510,1510,1510,1486,1486,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype146[] = {1230,0xFFF9,0,1186,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype147[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7670_pgtype148[] = {0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y7670_gen_type [1085];
EIF_TYPE_INDEX Y7670 [1085];
void Y7670_init (void)
{
	egc_routines_types [7670] = Y7670;
	egc_routines_gen_types [7670] = Y7670_gen_type;
	egc_routines_offset [7670] = 679;
	Y7670_gen_type [0] = Y7670_pgtype0;
	Y7670_gen_type [1] = Y7670_pgtype1;
	Y7670_gen_type [2] = Y7670_pgtype2;
	Y7670_gen_type [3] = Y7670_pgtype3;
	Y7670_gen_type [4] = Y7670_pgtype4;
	Y7670_gen_type [5] = Y7670_pgtype5;
	Y7670_gen_type [6] = Y7670_pgtype6;
	Y7670_gen_type [7] = Y7670_pgtype7;
	Y7670_gen_type [8] = Y7670_pgtype8;
	Y7670_gen_type [9] = Y7670_pgtype9;
	Y7670_gen_type [10] = Y7670_pgtype10;
	Y7670_gen_type [11] = Y7670_pgtype11;
	Y7670_gen_type [12] = Y7670_pgtype12;
	Y7670_gen_type [13] = Y7670_pgtype13;
	Y7670_gen_type [14] = Y7670_pgtype14;
	Y7670_gen_type [15] = Y7670_pgtype15;
	Y7670_gen_type [16] = Y7670_pgtype16;
	Y7670_gen_type [17] = Y7670_pgtype17;
	Y7670_gen_type [18] = Y7670_pgtype18;
	Y7670_gen_type [19] = Y7670_pgtype19;
	Y7670_gen_type [20] = Y7670_pgtype20;
	Y7670_gen_type [21] = Y7670_pgtype21;
	Y7670_gen_type [22] = Y7670_pgtype22;
	Y7670_gen_type [23] = Y7670_pgtype23;
	Y7670_gen_type [43] = Y7670_pgtype24;
	Y7670_gen_type [80] = Y7670_pgtype25;
	Y7670_gen_type [81] = Y7670_pgtype26;
	Y7670_gen_type [82] = Y7670_pgtype27;
	Y7670_gen_type [83] = Y7670_pgtype28;
	Y7670_gen_type [84] = Y7670_pgtype29;
	Y7670_gen_type [85] = Y7670_pgtype30;
	Y7670_gen_type [86] = Y7670_pgtype31;
	Y7670_gen_type [87] = Y7670_pgtype32;
	Y7670_gen_type [88] = Y7670_pgtype33;
	Y7670_gen_type [89] = Y7670_pgtype34;
	Y7670_gen_type [90] = Y7670_pgtype35;
	Y7670_gen_type [91] = Y7670_pgtype36;
	Y7670_gen_type [92] = Y7670_pgtype37;
	Y7670_gen_type [93] = Y7670_pgtype38;
	Y7670_gen_type [94] = Y7670_pgtype39;
	Y7670_gen_type [95] = Y7670_pgtype40;
	Y7670_gen_type [96] = Y7670_pgtype41;
	Y7670_gen_type [97] = Y7670_pgtype42;
	Y7670_gen_type [98] = Y7670_pgtype43;
	Y7670_gen_type [99] = Y7670_pgtype44;
	Y7670_gen_type [100] = Y7670_pgtype45;
	Y7670_gen_type [101] = Y7670_pgtype46;
	Y7670_gen_type [155] = Y7670_pgtype47;
	Y7670_gen_type [156] = Y7670_pgtype48;
	Y7670_gen_type [157] = Y7670_pgtype49;
	Y7670_gen_type [158] = Y7670_pgtype50;
	Y7670_gen_type [159] = Y7670_pgtype51;
	Y7670_gen_type [160] = Y7670_pgtype52;
	Y7670_gen_type [161] = Y7670_pgtype53;
	Y7670_gen_type [162] = Y7670_pgtype54;
	Y7670_gen_type [163] = Y7670_pgtype55;
	Y7670_gen_type [164] = Y7670_pgtype56;
	Y7670_gen_type [165] = Y7670_pgtype57;
	Y7670_gen_type [166] = Y7670_pgtype58;
	Y7670_gen_type [167] = Y7670_pgtype59;
	Y7670_gen_type [168] = Y7670_pgtype60;
	Y7670_gen_type [169] = Y7670_pgtype61;
	Y7670_gen_type [170] = Y7670_pgtype62;
	Y7670_gen_type [171] = Y7670_pgtype63;
	Y7670_gen_type [172] = Y7670_pgtype64;
	Y7670_gen_type [173] = Y7670_pgtype65;
	Y7670_gen_type [174] = Y7670_pgtype66;
	Y7670_gen_type [175] = Y7670_pgtype67;
	Y7670_gen_type [176] = Y7670_pgtype68;
	Y7670_gen_type [177] = Y7670_pgtype69;
	Y7670_gen_type [178] = Y7670_pgtype70;
	Y7670_gen_type [179] = Y7670_pgtype71;
	Y7670_gen_type [180] = Y7670_pgtype72;
	Y7670_gen_type [181] = Y7670_pgtype73;
	Y7670_gen_type [182] = Y7670_pgtype74;
	Y7670_gen_type [183] = Y7670_pgtype75;
	Y7670_gen_type [184] = Y7670_pgtype76;
	Y7670_gen_type [185] = Y7670_pgtype77;
	Y7670_gen_type [186] = Y7670_pgtype78;
	Y7670_gen_type [187] = Y7670_pgtype79;
	Y7670_gen_type [188] = Y7670_pgtype80;
	Y7670_gen_type [189] = Y7670_pgtype81;
	Y7670_gen_type [190] = Y7670_pgtype82;
	Y7670_gen_type [191] = Y7670_pgtype83;
	Y7670_gen_type [192] = Y7670_pgtype84;
	Y7670_gen_type [193] = Y7670_pgtype85;
	Y7670_gen_type [194] = Y7670_pgtype86;
	Y7670_gen_type [195] = Y7670_pgtype87;
	Y7670_gen_type [196] = Y7670_pgtype88;
	Y7670_gen_type [197] = Y7670_pgtype89;
	Y7670_gen_type [198] = Y7670_pgtype90;
	Y7670_gen_type [199] = Y7670_pgtype91;
	Y7670_gen_type [200] = Y7670_pgtype92;
	Y7670_gen_type [201] = Y7670_pgtype93;
	Y7670_gen_type [202] = Y7670_pgtype94;
	Y7670_gen_type [203] = Y7670_pgtype95;
	Y7670_gen_type [204] = Y7670_pgtype96;
	Y7670_gen_type [205] = Y7670_pgtype97;
	Y7670_gen_type [206] = Y7670_pgtype98;
	Y7670_gen_type [207] = Y7670_pgtype99;
	Y7670_gen_type [208] = Y7670_pgtype100;
	Y7670_gen_type [209] = Y7670_pgtype101;
	Y7670_gen_type [210] = Y7670_pgtype102;
	Y7670_gen_type [211] = Y7670_pgtype103;
	Y7670_gen_type [212] = Y7670_pgtype104;
	Y7670_gen_type [213] = Y7670_pgtype105;
	Y7670_gen_type [214] = Y7670_pgtype106;
	Y7670_gen_type [215] = Y7670_pgtype107;
	Y7670_gen_type [216] = Y7670_pgtype108;
	Y7670_gen_type [217] = Y7670_pgtype109;
	Y7670_gen_type [218] = Y7670_pgtype110;
	Y7670_gen_type [219] = Y7670_pgtype111;
	Y7670_gen_type [220] = Y7670_pgtype112;
	Y7670_gen_type [221] = Y7670_pgtype113;
	Y7670_gen_type [222] = Y7670_pgtype114;
	Y7670_gen_type [223] = Y7670_pgtype115;
	Y7670_gen_type [225] = Y7670_pgtype116;
	Y7670_gen_type [226] = Y7670_pgtype117;
	Y7670_gen_type [227] = Y7670_pgtype118;
	Y7670_gen_type [229] = Y7670_pgtype119;
	Y7670_gen_type [230] = Y7670_pgtype120;
	Y7670_gen_type [231] = Y7670_pgtype121;
	Y7670_gen_type [232] = Y7670_pgtype122;
	Y7670_gen_type [233] = Y7670_pgtype123;
	Y7670_gen_type [234] = Y7670_pgtype124;
	Y7670_gen_type [236] = Y7670_pgtype125;
	Y7670_gen_type [237] = Y7670_pgtype126;
	Y7670_gen_type [238] = Y7670_pgtype127;
	Y7670_gen_type [239] = Y7670_pgtype128;
	Y7670_gen_type [240] = Y7670_pgtype129;
	Y7670_gen_type [241] = Y7670_pgtype130;
	Y7670_gen_type [242] = Y7670_pgtype131;
	Y7670_gen_type [243] = Y7670_pgtype132;
	Y7670_gen_type [244] = Y7670_pgtype133;
	Y7670_gen_type [245] = Y7670_pgtype134;
	Y7670_gen_type [246] = Y7670_pgtype135;
	Y7670_gen_type [247] = Y7670_pgtype136;
	Y7670_gen_type [248] = Y7670_pgtype137;
	Y7670_gen_type [249] = Y7670_pgtype138;
	Y7670_gen_type [250] = Y7670_pgtype139;
	Y7670_gen_type [251] = Y7670_pgtype140;
	Y7670_gen_type [252] = Y7670_pgtype141;
	Y7670_gen_type [253] = Y7670_pgtype142;
	Y7670_gen_type [254] = Y7670_pgtype143;
	Y7670_gen_type [255] = Y7670_pgtype144;
	Y7670_gen_type [256] = Y7670_pgtype145;
	Y7670_gen_type [257] = Y7670_pgtype146;
	Y7670_gen_type [661] = Y7670_pgtype147;
	Y7670_gen_type [662] = Y7670_pgtype148;
	Y7670[224] = 1750;
	Y7670[228] = 907;
	Y7670[235] = 1301;
	{long i; for (i = 236; i < 258; i++) Y7670[i] = 1230;};
	Y7670[290] = 1486;
	Y7670[297] = 1486;
	{long i; for (i = 466; i < 469; i++) Y7670[i] = 1192;};
	Y7670[663] = 1395;
	{long i; for (i = 664; i < 666; i++) Y7670[i] = 1401;};
	{long i; for (i = 669; i < 675; i++) Y7670[i] = 1346;};
	Y7670[690] = 1395;
	Y7670[692] = 1397;
	Y7670[693] = 1394;
	Y7670[695] = 1393;
	{long i; for (i = 702; i < 704; i++) Y7670[i] = 1392;};
	Y7670[706] = 1392;
	Y7670[715] = 1241;
	{long i; for (i = 716; i < 718; i++) Y7670[i] = 1395;};
	Y7670[726] = 1401;
	Y7670[1036] = 1192;
	{long i; for (i = 1076; i < 1079; i++) Y7670[i] = 1192;};
	{long i; for (i = 1080; i < 1085; i++) Y7670[i] = 1192;};
}


#ifdef __cplusplus
}
#endif
