#include "epoly11.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

EIF_TYPE_INDEX *Y7740_gen_type [1006];
EIF_TYPE_INDEX Y7740 [1006];
void Y7740_init (void)
{
	egc_routines_types [7740] = Y7740;
	egc_routines_gen_types [7740] = Y7740_gen_type;
	egc_routines_offset [7740] = 793;
	{long i; for (i = 0; i < 162; i++) Y7740[i] = 1486;};
	Y7740[393] = 1486;
	{long i; for (i = 446; i < 454; i++) Y7740[i] = 1486;};
	{long i; for (i = 547; i < 552; i++) Y7740[i] = 1486;};
	{long i; for (i = 555; i < 561; i++) Y7740[i] = 1486;};
	Y7740[576] = 1486;
	{long i; for (i = 578; i < 580; i++) Y7740[i] = 1486;};
	Y7740[581] = 1486;
	{long i; for (i = 588; i < 590; i++) Y7740[i] = 1486;};
	Y7740[592] = 1486;
	{long i; for (i = 601; i < 604; i++) Y7740[i] = 1486;};
	Y7740[612] = 1486;
	{long i; for (i = 614; i < 626; i++) Y7740[i] = 1486;};
	{long i; for (i = 1004; i < 1006; i++) Y7740[i] = 1486;};
}

char *(*R7741[993])();
void R7741_init () {
	R7741[0] = (char *(*)()) F806_8458;
	R7741[1] = (char *(*)()) F807_8458;
	R7741[2] = (char *(*)()) F808_8458;
	R7741[3] = (char *(*)()) F809_8458;
	R7741[4] = (char *(*)()) F810_8458;
	R7741[5] = (char *(*)()) F811_8458;
	R7741[6] = (char *(*)()) F812_8458;
	R7741[7] = (char *(*)()) F813_8458;
	R7741[8] = (char *(*)()) F814_8458;
	R7741[9] = (char *(*)()) F806_8458;
	R7741[10] = (char *(*)()) F807_8458;
	R7741[11] = (char *(*)()) F809_8458;
	R7741[12] = (char *(*)()) F813_8458;
	R7741[13] = (char *(*)()) F814_8458;
	R7741[14] = (char *(*)()) F806_8458;
	{long i; for (i = 27; i < 29; i++) R7741[i] = (char *(*)()) F833_8572;}
	R7741[77] = (char *(*)()) F883_8674;
	R7741[78] = (char *(*)()) F884_8674;
	R7741[79] = (char *(*)()) F885_8674;
	{long i; for (i = 80; i < 82; i++) R7741[i] = (char *(*)()) F883_8674;}
	R7741[82] = (char *(*)()) F885_8674;
	R7741[83] = (char *(*)()) F884_8674;
	{long i; for (i = 84; i < 86; i++) R7741[i] = (char *(*)()) F883_8674;}
	R7741[86] = (char *(*)()) F892_8801;
	R7741[87] = (char *(*)()) F893_8801;
	R7741[88] = (char *(*)()) F894_8801;
	R7741[89] = (char *(*)()) F895_8801;
	R7741[90] = (char *(*)()) F896_8801;
	R7741[91] = (char *(*)()) F897_8801;
	R7741[92] = (char *(*)()) F898_8801;
	R7741[93] = (char *(*)()) F899_8801;
	R7741[94] = (char *(*)()) F900_8801;
	R7741[95] = (char *(*)()) F901_8801;
	R7741[96] = (char *(*)()) F902_8801;
	R7741[97] = (char *(*)()) F903_8801;
	{long i; for (i = 98; i < 100; i++) R7741[i] = (char *(*)()) F892_8801;}
	R7741[100] = (char *(*)()) F895_8801;
	R7741[101] = (char *(*)()) F897_8801;
	R7741[102] = (char *(*)()) F892_8801;
	R7741[107] = (char *(*)()) F892_8801;
	R7741[108] = (char *(*)()) F895_8801;
	{long i; for (i = 109; i < 113; i++) R7741[i] = (char *(*)()) F892_8801;}
	R7741[115] = (char *(*)()) F892_8801;
	R7741[118] = (char *(*)()) F892_8801;
	{long i; for (i = 120; i < 122; i++) R7741[i] = (char *(*)()) F892_8801;}
	R7741[124] = (char *(*)()) F892_8801;
	{long i; for (i = 126; i < 132; i++) R7741[i] = (char *(*)()) F892_8801;}
	R7741[132] = (char *(*)()) F938_9020;
	R7741[133] = (char *(*)()) F939_9020;
	R7741[134] = (char *(*)()) F940_9020;
	R7741[135] = (char *(*)()) F941_9020;
	R7741[136] = (char *(*)()) F942_9020;
	R7741[137] = (char *(*)()) F943_9020;
	R7741[138] = (char *(*)()) F944_9020;
	R7741[139] = (char *(*)()) F945_9020;
	R7741[140] = (char *(*)()) F946_9020;
	R7741[141] = (char *(*)()) F947_9020;
	R7741[142] = (char *(*)()) F948_9020;
	R7741[143] = (char *(*)()) F949_9020;
	R7741[381] = (char *(*)()) F1187_10760;
	{long i; for (i = 435; i < 437; i++) R7741[i] = (char *(*)()) F1240_11210;}
	{long i; for (i = 438; i < 440; i++) R7741[i] = (char *(*)()) F1243_11378;}
	{long i; for (i = 547; i < 549; i++) R7741[i] = (char *(*)()) F1341_12727;}
	{long i; for (i = 566; i < 568; i++) R7741[i] = (char *(*)()) F1341_12727;}
	R7741[569] = (char *(*)()) F1341_12727;
	R7741[589] = (char *(*)()) F892_8801;
	R7741[600] = (char *(*)()) F1341_12727;
	R7741[602] = (char *(*)()) F1408_13458;
	R7741[603] = (char *(*)()) F1409_13458;
	R7741[604] = (char *(*)()) F1410_13458;
	R7741[605] = (char *(*)()) F1411_13458;
	R7741[606] = (char *(*)()) F1412_13458;
	R7741[607] = (char *(*)()) F1413_13458;
	R7741[608] = (char *(*)()) F1414_13458;
	R7741[609] = (char *(*)()) F1415_13458;
	R7741[610] = (char *(*)()) F1416_13458;
	R7741[611] = (char *(*)()) F1417_13458;
	R7741[612] = (char *(*)()) F1418_13458;
	R7741[613] = (char *(*)()) F1419_13458;
	R7741[992] = (char *(*)()) F1798_20788;
}

char *(*R7743[993])();
void R7743_init () {
	R7743[0] = (char *(*)()) F806_8474;
	R7743[1] = (char *(*)()) F807_8474;
	R7743[2] = (char *(*)()) F808_8474;
	R7743[3] = (char *(*)()) F809_8474;
	R7743[4] = (char *(*)()) F810_8474;
	R7743[5] = (char *(*)()) F811_8474;
	R7743[6] = (char *(*)()) F812_8474;
	R7743[7] = (char *(*)()) F813_8474;
	R7743[8] = (char *(*)()) F814_8474;
	R7743[9] = (char *(*)()) F806_8474;
	R7743[10] = (char *(*)()) F807_8474;
	R7743[11] = (char *(*)()) F809_8474;
	R7743[12] = (char *(*)()) F813_8474;
	R7743[13] = (char *(*)()) F814_8474;
	R7743[14] = (char *(*)()) F806_8474;
	{long i; for (i = 27; i < 29; i++) R7743[i] = (char *(*)()) F833_8576;}
	R7743[77] = (char *(*)()) F835_8627;
	R7743[78] = (char *(*)()) F838_8627;
	R7743[79] = (char *(*)()) F840_8627;
	{long i; for (i = 80; i < 82; i++) R7743[i] = (char *(*)()) F835_8627;}
	R7743[82] = (char *(*)()) F840_8627;
	R7743[83] = (char *(*)()) F838_8627;
	{long i; for (i = 84; i < 86; i++) R7743[i] = (char *(*)()) F835_8627;}
	R7743[86] = (char *(*)()) F892_8807;
	R7743[87] = (char *(*)()) F893_8807;
	R7743[88] = (char *(*)()) F894_8807;
	R7743[89] = (char *(*)()) F895_8807;
	R7743[90] = (char *(*)()) F896_8807;
	R7743[91] = (char *(*)()) F897_8807;
	R7743[92] = (char *(*)()) F898_8807;
	R7743[93] = (char *(*)()) F899_8807;
	R7743[94] = (char *(*)()) F900_8807;
	R7743[95] = (char *(*)()) F901_8807;
	R7743[96] = (char *(*)()) F902_8807;
	R7743[97] = (char *(*)()) F903_8807;
	{long i; for (i = 98; i < 100; i++) R7743[i] = (char *(*)()) F892_8807;}
	R7743[100] = (char *(*)()) F895_8807;
	R7743[101] = (char *(*)()) F897_8807;
	R7743[102] = (char *(*)()) F892_8807;
	R7743[107] = (char *(*)()) F892_8807;
	R7743[108] = (char *(*)()) F895_8807;
	{long i; for (i = 109; i < 113; i++) R7743[i] = (char *(*)()) F892_8807;}
	R7743[115] = (char *(*)()) F892_8807;
	R7743[118] = (char *(*)()) F892_8807;
	{long i; for (i = 120; i < 122; i++) R7743[i] = (char *(*)()) F892_8807;}
	R7743[124] = (char *(*)()) F892_8807;
	{long i; for (i = 126; i < 132; i++) R7743[i] = (char *(*)()) F892_8807;}
	R7743[132] = (char *(*)()) F938_9029;
	R7743[133] = (char *(*)()) F939_9029;
	R7743[134] = (char *(*)()) F940_9029;
	R7743[135] = (char *(*)()) F941_9029;
	R7743[136] = (char *(*)()) F942_9029;
	R7743[137] = (char *(*)()) F943_9029;
	R7743[138] = (char *(*)()) F944_9029;
	R7743[139] = (char *(*)()) F945_9029;
	R7743[140] = (char *(*)()) F946_9029;
	R7743[141] = (char *(*)()) F947_9029;
	R7743[142] = (char *(*)()) F948_9029;
	R7743[143] = (char *(*)()) F949_9029;
	R7743[381] = (char *(*)()) F1187_10758;
	{long i; for (i = 435; i < 437; i++) R7743[i] = (char *(*)()) F1237_11071;}
	{long i; for (i = 438; i < 440; i++) R7743[i] = (char *(*)()) F1237_11071;}
	{long i; for (i = 547; i < 549; i++) R7743[i] = (char *(*)()) F835_8627;}
	{long i; for (i = 566; i < 568; i++) R7743[i] = (char *(*)()) F835_8627;}
	R7743[569] = (char *(*)()) F835_8627;
	R7743[589] = (char *(*)()) F892_8807;
	R7743[600] = (char *(*)()) F835_8627;
	R7743[602] = (char *(*)()) F1408_13463;
	R7743[603] = (char *(*)()) F1409_13463;
	R7743[604] = (char *(*)()) F1410_13463;
	R7743[605] = (char *(*)()) F1411_13463;
	R7743[606] = (char *(*)()) F1412_13463;
	R7743[607] = (char *(*)()) F1413_13463;
	R7743[608] = (char *(*)()) F1414_13463;
	R7743[609] = (char *(*)()) F1415_13463;
	R7743[610] = (char *(*)()) F1416_13463;
	R7743[611] = (char *(*)()) F1417_13463;
	R7743[612] = (char *(*)()) F1418_13463;
	R7743[613] = (char *(*)()) F1419_13463;
	R7743[992] = (char *(*)()) F1237_11071;
}

char *(*R7744[15])();
void R7744_init () {
	R7744[0] = (char *(*)()) F806_8436;
	R7744[1] = (char *(*)()) F807_8436;
	R7744[2] = (char *(*)()) F808_8436;
	R7744[3] = (char *(*)()) F809_8436;
	R7744[4] = (char *(*)()) F810_8436;
	R7744[5] = (char *(*)()) F811_8436;
	R7744[6] = (char *(*)()) F812_8436;
	R7744[7] = (char *(*)()) F813_8436;
	R7744[8] = (char *(*)()) F814_8436;
	R7744[9] = (char *(*)()) F806_8436;
	R7744[10] = (char *(*)()) F807_8436;
	R7744[11] = (char *(*)()) F809_8436;
	R7744[12] = (char *(*)()) F813_8436;
	R7744[13] = (char *(*)()) F814_8436;
	R7744[14] = (char *(*)()) F806_8436;
}

char *(*R7745[15])();
void R7745_init () {
	R7745[0] = (char *(*)()) F806_8437;
	R7745[1] = (char *(*)()) F807_8437;
	R7745[2] = (char *(*)()) F808_8437;
	R7745[3] = (char *(*)()) F809_8437;
	R7745[4] = (char *(*)()) F810_8437;
	R7745[5] = (char *(*)()) F811_8437;
	R7745[6] = (char *(*)()) F812_8437;
	R7745[7] = (char *(*)()) F813_8437;
	R7745[8] = (char *(*)()) F814_8437;
	R7745[9] = (char *(*)()) F806_8437;
	R7745[10] = (char *(*)()) F807_8437;
	R7745[11] = (char *(*)()) F809_8437;
	R7745[12] = (char *(*)()) F813_8437;
	R7745[13] = (char *(*)()) F814_8437;
	R7745[14] = (char *(*)()) F806_8437;
}

char *(*R7747[15])();
void R7747_init () {
	R7747[0] = (char *(*)()) F806_8439;
	R7747[1] = (char *(*)()) F807_8439;
	R7747[2] = (char *(*)()) F808_8439;
	R7747[3] = (char *(*)()) F809_8439;
	R7747[4] = (char *(*)()) F810_8439;
	R7747[5] = (char *(*)()) F811_8439;
	R7747[6] = (char *(*)()) F812_8439;
	R7747[7] = (char *(*)()) F813_8439;
	R7747[8] = (char *(*)()) F814_8439;
	R7747[9] = (char *(*)()) F806_8439;
	R7747[10] = (char *(*)()) F807_8439;
	R7747[11] = (char *(*)()) F809_8439;
	R7747[12] = (char *(*)()) F813_8439;
	R7747[13] = (char *(*)()) F814_8439;
	R7747[14] = (char *(*)()) F806_8439;
}

char *(*R7748[15])();
void R7748_init () {
	R7748[0] = (char *(*)()) F806_8440;
	R7748[1] = (char *(*)()) F807_8440_7748_1;
	R7748[2] = (char *(*)()) F808_8440;
	R7748[3] = (char *(*)()) F809_8440_7748_1;
	R7748[4] = (char *(*)()) F810_8440_7748_1;
	R7748[5] = (char *(*)()) F811_8440_7748_1;
	R7748[6] = (char *(*)()) F812_8440_7748_1;
	R7748[7] = (char *(*)()) F813_8440_7748_1;
	R7748[8] = (char *(*)()) F814_8440_7748_1;
	R7748[9] = (char *(*)()) F806_8440;
	R7748[10] = (char *(*)()) F807_8440_7748_1;
	R7748[11] = (char *(*)()) F809_8440_7748_1;
	R7748[12] = (char *(*)()) F813_8440_7748_1;
	R7748[13] = (char *(*)()) F814_8440_7748_1;
	R7748[14] = (char *(*)()) F806_8440;
}
static EIF_REFERENCE F807_8440_7748_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F807_8440(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1498, 0x00).id, 1498, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F809_8440_7748_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F809_8440(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F810_8440_7748_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F810_8440(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F811_8440_7748_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F811_8440(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F812_8440_7748_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F812_8440(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F813_8440_7748_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F813_8440(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1504, 0x00).id, 1504, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F814_8440_7748_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F814_8440(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1195, 0x00).id, 1195, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y7749_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7749_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7749_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7749_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7749_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7749_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7749_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7749_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7749_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7749_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7749_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7749_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7749_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7749_pgtype13[] = {0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y7749_gen_type [15];
EIF_TYPE_INDEX Y7749 [15];
void Y7749_init (void)
{
	egc_routines_types [7749] = Y7749;
	egc_routines_gen_types [7749] = Y7749_gen_type;
	egc_routines_offset [7749] = 805;
	Y7749_gen_type [0] = Y7749_pgtype0;
	Y7749_gen_type [1] = Y7749_pgtype1;
	Y7749_gen_type [2] = Y7749_pgtype2;
	Y7749_gen_type [3] = Y7749_pgtype3;
	Y7749_gen_type [4] = Y7749_pgtype4;
	Y7749_gen_type [5] = Y7749_pgtype5;
	Y7749_gen_type [6] = Y7749_pgtype6;
	Y7749_gen_type [7] = Y7749_pgtype7;
	Y7749_gen_type [8] = Y7749_pgtype8;
	Y7749_gen_type [9] = Y7749_pgtype9;
	Y7749_gen_type [10] = Y7749_pgtype10;
	Y7749_gen_type [11] = Y7749_pgtype11;
	Y7749_gen_type [12] = Y7749_pgtype12;
	Y7749_gen_type [13] = Y7749_pgtype13;
	Y7749[14] = 0;
}

char *(*R7753[15])();
void R7753_init () {
	R7753[0] = (char *(*)()) F806_8448;
	R7753[1] = (char *(*)()) F807_8448_7753_1;
	R7753[2] = (char *(*)()) F808_8448;
	R7753[3] = (char *(*)()) F809_8448_7753_1;
	R7753[4] = (char *(*)()) F810_8448_7753_1;
	R7753[5] = (char *(*)()) F811_8448_7753_1;
	R7753[6] = (char *(*)()) F812_8448_7753_1;
	R7753[7] = (char *(*)()) F813_8448_7753_1;
	R7753[8] = (char *(*)()) F814_8448_7753_1;
	R7753[9] = (char *(*)()) F806_8448;
	R7753[10] = (char *(*)()) F807_8448_7753_1;
	R7753[11] = (char *(*)()) F809_8448_7753_1;
	R7753[12] = (char *(*)()) F813_8448_7753_1;
	R7753[13] = (char *(*)()) F814_8448_7753_1;
	R7753[14] = (char *(*)()) F806_8448;
}
static EIF_REFERENCE F807_8448_7753_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F807_8448(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1498, 0x00).id, 1498, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F809_8448_7753_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F809_8448(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F810_8448_7753_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F810_8448(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F811_8448_7753_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F811_8448(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F812_8448_7753_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F812_8448(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F813_8448_7753_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F813_8448(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1504, 0x00).id, 1504, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F814_8448_7753_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F814_8448(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1195, 0x00).id, 1195, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y7753_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7753_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7753_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7753_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7753_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7753_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7753_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7753_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7753_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7753_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7753_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7753_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7753_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7753_pgtype13[] = {0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y7753_gen_type [15];
EIF_TYPE_INDEX Y7753 [15];
void Y7753_init (void)
{
	egc_routines_types [7753] = Y7753;
	egc_routines_gen_types [7753] = Y7753_gen_type;
	egc_routines_offset [7753] = 805;
	Y7753_gen_type [0] = Y7753_pgtype0;
	Y7753_gen_type [1] = Y7753_pgtype1;
	Y7753_gen_type [2] = Y7753_pgtype2;
	Y7753_gen_type [3] = Y7753_pgtype3;
	Y7753_gen_type [4] = Y7753_pgtype4;
	Y7753_gen_type [5] = Y7753_pgtype5;
	Y7753_gen_type [6] = Y7753_pgtype6;
	Y7753_gen_type [7] = Y7753_pgtype7;
	Y7753_gen_type [8] = Y7753_pgtype8;
	Y7753_gen_type [9] = Y7753_pgtype9;
	Y7753_gen_type [10] = Y7753_pgtype10;
	Y7753_gen_type [11] = Y7753_pgtype11;
	Y7753_gen_type [12] = Y7753_pgtype12;
	Y7753_gen_type [13] = Y7753_pgtype13;
	Y7753[14] = 0;
}

char *(*R7754[15])();
void R7754_init () {
	R7754[0] = (char *(*)()) F806_8449;
	R7754[1] = (char *(*)()) F807_8449;
	R7754[2] = (char *(*)()) F808_8449_7754_1;
	R7754[3] = (char *(*)()) F809_8449;
	R7754[4] = (char *(*)()) F810_8449_7754_1;
	R7754[5] = (char *(*)()) F811_8449_7754_1;
	R7754[6] = (char *(*)()) F812_8449;
	R7754[7] = (char *(*)()) F813_8449;
	R7754[8] = (char *(*)()) F814_8449;
	R7754[9] = (char *(*)()) F806_8449;
	R7754[10] = (char *(*)()) F807_8449;
	R7754[11] = (char *(*)()) F809_8449;
	R7754[12] = (char *(*)()) F813_8449;
	R7754[13] = (char *(*)()) F814_8449;
	R7754[14] = (char *(*)()) F806_8449;
}
static EIF_REFERENCE F808_8449_7754_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F808_8449(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F810_8449_7754_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F810_8449(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F811_8449_7754_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F811_8449(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1498, 0x00).id, 1498, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}

char *(*R7756[15])();
void R7756_init () {
	R7756[0] = (char *(*)()) F806_8453;
	R7756[1] = (char *(*)()) F807_8453;
	R7756[2] = (char *(*)()) F808_8453_7756_109;
	R7756[3] = (char *(*)()) F809_8453;
	R7756[4] = (char *(*)()) F810_8453_7756_109;
	R7756[5] = (char *(*)()) F811_8453_7756_109;
	R7756[6] = (char *(*)()) F812_8453;
	R7756[7] = (char *(*)()) F813_8453;
	R7756[8] = (char *(*)()) F814_8453;
	R7756[9] = (char *(*)()) F815_8550;
	R7756[10] = (char *(*)()) F816_8550;
	R7756[11] = (char *(*)()) F817_8550;
	R7756[12] = (char *(*)()) F818_8550;
	R7756[13] = (char *(*)()) F819_8550;
	R7756[14] = (char *(*)()) F806_8453;
}
static EIF_INTEGER_32 F808_8453_7756_109 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F808_8453(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F810_8453_7756_109 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F810_8453(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F811_8453_7756_109 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F811_8453(Current, *(EIF_NATURAL_32 *)arg1);
}

char *(*R7758[15])();
void R7758_init () {
	R7758[0] = (char *(*)()) F806_8460;
	R7758[1] = (char *(*)()) F807_8460;
	R7758[2] = (char *(*)()) F808_8460_7758_3;
	R7758[3] = (char *(*)()) F809_8460;
	R7758[4] = (char *(*)()) F810_8460_7758_3;
	R7758[5] = (char *(*)()) F811_8460_7758_3;
	R7758[6] = (char *(*)()) F812_8460;
	R7758[7] = (char *(*)()) F813_8460;
	R7758[8] = (char *(*)()) F814_8460;
	R7758[9] = (char *(*)()) F815_8552;
	R7758[10] = (char *(*)()) F816_8552;
	R7758[11] = (char *(*)()) F817_8552;
	R7758[12] = (char *(*)()) F818_8552;
	R7758[13] = (char *(*)()) F819_8552;
	R7758[14] = (char *(*)()) F806_8460;
}
static EIF_BOOLEAN F808_8460_7758_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F808_8460(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F810_8460_7758_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F810_8460(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F811_8460_7758_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F811_8460(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_NATURAL_32 *)arg2);
}

char *(*R7764[15])();
void R7764_init () {
	R7764[0] = (char *(*)()) F806_8468;
	R7764[1] = (char *(*)()) F807_8468;
	R7764[2] = (char *(*)()) F808_8468;
	R7764[3] = (char *(*)()) F809_8468;
	R7764[4] = (char *(*)()) F810_8468;
	R7764[5] = (char *(*)()) F811_8468;
	R7764[6] = (char *(*)()) F812_8468;
	R7764[7] = (char *(*)()) F813_8468;
	R7764[8] = (char *(*)()) F814_8468;
	R7764[9] = (char *(*)()) F806_8468;
	R7764[10] = (char *(*)()) F807_8468;
	R7764[11] = (char *(*)()) F809_8468;
	R7764[12] = (char *(*)()) F813_8468;
	R7764[13] = (char *(*)()) F814_8468;
	R7764[14] = (char *(*)()) F806_8468;
}

char *(*R7765[15])();
void R7765_init () {
	R7765[0] = (char *(*)()) F806_8469;
	R7765[1] = (char *(*)()) F807_8469;
	R7765[2] = (char *(*)()) F808_8469;
	R7765[3] = (char *(*)()) F809_8469;
	R7765[4] = (char *(*)()) F810_8469;
	R7765[5] = (char *(*)()) F811_8469;
	R7765[6] = (char *(*)()) F812_8469;
	R7765[7] = (char *(*)()) F813_8469;
	R7765[8] = (char *(*)()) F814_8469;
	R7765[9] = (char *(*)()) F806_8469;
	R7765[10] = (char *(*)()) F807_8469;
	R7765[11] = (char *(*)()) F809_8469;
	R7765[12] = (char *(*)()) F813_8469;
	R7765[13] = (char *(*)()) F814_8469;
	R7765[14] = (char *(*)()) F806_8469;
}

char *(*R7766[15])();
void R7766_init () {
	R7766[0] = (char *(*)()) F806_8470;
	R7766[1] = (char *(*)()) F807_8470;
	R7766[2] = (char *(*)()) F808_8470;
	R7766[3] = (char *(*)()) F809_8470;
	R7766[4] = (char *(*)()) F810_8470;
	R7766[5] = (char *(*)()) F811_8470;
	R7766[6] = (char *(*)()) F812_8470;
	R7766[7] = (char *(*)()) F813_8470;
	R7766[8] = (char *(*)()) F814_8470;
	R7766[9] = (char *(*)()) F806_8470;
	R7766[10] = (char *(*)()) F807_8470;
	R7766[11] = (char *(*)()) F809_8470;
	R7766[12] = (char *(*)()) F813_8470;
	R7766[13] = (char *(*)()) F814_8470;
	R7766[14] = (char *(*)()) F806_8470;
}

char *(*R7767[15])();
void R7767_init () {
	R7767[0] = (char *(*)()) F806_8471;
	R7767[1] = (char *(*)()) F807_8471;
	R7767[2] = (char *(*)()) F808_8471;
	R7767[3] = (char *(*)()) F809_8471;
	R7767[4] = (char *(*)()) F810_8471;
	R7767[5] = (char *(*)()) F811_8471;
	R7767[6] = (char *(*)()) F812_8471;
	R7767[7] = (char *(*)()) F813_8471;
	R7767[8] = (char *(*)()) F814_8471;
	R7767[9] = (char *(*)()) F806_8471;
	R7767[10] = (char *(*)()) F807_8471;
	R7767[11] = (char *(*)()) F809_8471;
	R7767[12] = (char *(*)()) F813_8471;
	R7767[13] = (char *(*)()) F814_8471;
	R7767[14] = (char *(*)()) F806_8471;
}

char *(*R7770[15])();
void R7770_init () {
	R7770[0] = (char *(*)()) F806_8475;
	R7770[1] = (char *(*)()) F807_8475;
	R7770[2] = (char *(*)()) F808_8475;
	R7770[3] = (char *(*)()) F809_8475;
	R7770[4] = (char *(*)()) F810_8475;
	R7770[5] = (char *(*)()) F811_8475;
	R7770[6] = (char *(*)()) F812_8475;
	R7770[7] = (char *(*)()) F813_8475;
	R7770[8] = (char *(*)()) F814_8475;
	R7770[9] = (char *(*)()) F806_8475;
	R7770[10] = (char *(*)()) F807_8475;
	R7770[11] = (char *(*)()) F809_8475;
	R7770[12] = (char *(*)()) F813_8475;
	R7770[13] = (char *(*)()) F814_8475;
	R7770[14] = (char *(*)()) F806_8475;
}

char *(*R7771[15])();
void R7771_init () {
	R7771[0] = (char *(*)()) F806_8476;
	R7771[1] = (char *(*)()) F807_8476;
	R7771[2] = (char *(*)()) F808_8476;
	R7771[3] = (char *(*)()) F809_8476;
	R7771[4] = (char *(*)()) F810_8476;
	R7771[5] = (char *(*)()) F811_8476;
	R7771[6] = (char *(*)()) F812_8476;
	R7771[7] = (char *(*)()) F813_8476;
	R7771[8] = (char *(*)()) F814_8476;
	R7771[9] = (char *(*)()) F806_8476;
	R7771[10] = (char *(*)()) F807_8476;
	R7771[11] = (char *(*)()) F809_8476;
	R7771[12] = (char *(*)()) F813_8476;
	R7771[13] = (char *(*)()) F814_8476;
	R7771[14] = (char *(*)()) F806_8476;
}

char *(*R7773[15])();
void R7773_init () {
	R7773[0] = (char *(*)()) F806_8478;
	R7773[1] = (char *(*)()) F807_8478;
	R7773[2] = (char *(*)()) F808_8478_7773_4;
	R7773[3] = (char *(*)()) F809_8478;
	R7773[4] = (char *(*)()) F810_8478_7773_4;
	R7773[5] = (char *(*)()) F811_8478_7773_4;
	R7773[6] = (char *(*)()) F812_8478;
	R7773[7] = (char *(*)()) F813_8478;
	R7773[8] = (char *(*)()) F814_8478;
	R7773[9] = (char *(*)()) F806_8478;
	R7773[10] = (char *(*)()) F807_8478;
	R7773[11] = (char *(*)()) F809_8478;
	R7773[12] = (char *(*)()) F813_8478;
	R7773[13] = (char *(*)()) F814_8478;
	R7773[14] = (char *(*)()) F806_8478;
}
static void F808_8478_7773_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F808_8478(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F810_8478_7773_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F810_8478(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F811_8478_7773_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F811_8478(Current, *(EIF_NATURAL_32 *)arg1);
}

char *(*R7775[15])();
void R7775_init () {
	R7775[0] = (char *(*)()) F806_8480;
	R7775[1] = (char *(*)()) F807_8480;
	R7775[2] = (char *(*)()) F808_8480;
	R7775[3] = (char *(*)()) F809_8480;
	R7775[4] = (char *(*)()) F810_8480;
	R7775[5] = (char *(*)()) F811_8480;
	R7775[6] = (char *(*)()) F812_8480;
	R7775[7] = (char *(*)()) F813_8480;
	R7775[8] = (char *(*)()) F814_8480;
	R7775[9] = (char *(*)()) F806_8480;
	R7775[10] = (char *(*)()) F807_8480;
	R7775[11] = (char *(*)()) F809_8480;
	R7775[12] = (char *(*)()) F813_8480;
	R7775[13] = (char *(*)()) F814_8480;
	R7775[14] = (char *(*)()) F806_8480;
}

char *(*R7776[15])();
void R7776_init () {
	R7776[0] = (char *(*)()) F806_8481;
	R7776[1] = (char *(*)()) F807_8481;
	R7776[2] = (char *(*)()) F808_8481;
	R7776[3] = (char *(*)()) F809_8481;
	R7776[4] = (char *(*)()) F810_8481;
	R7776[5] = (char *(*)()) F811_8481;
	R7776[6] = (char *(*)()) F812_8481;
	R7776[7] = (char *(*)()) F813_8481;
	R7776[8] = (char *(*)()) F814_8481;
	R7776[9] = (char *(*)()) F806_8481;
	R7776[10] = (char *(*)()) F807_8481;
	R7776[11] = (char *(*)()) F809_8481;
	R7776[12] = (char *(*)()) F813_8481;
	R7776[13] = (char *(*)()) F814_8481;
	R7776[14] = (char *(*)()) F806_8481;
}

char *(*R7782[15])();
void R7782_init () {
	R7782[0] = (char *(*)()) F806_8494;
	R7782[1] = (char *(*)()) F807_8494;
	R7782[2] = (char *(*)()) F808_8494;
	R7782[3] = (char *(*)()) F809_8494;
	R7782[4] = (char *(*)()) F810_8494;
	R7782[5] = (char *(*)()) F811_8494;
	R7782[6] = (char *(*)()) F812_8494;
	R7782[7] = (char *(*)()) F813_8494;
	R7782[8] = (char *(*)()) F814_8494;
	R7782[9] = (char *(*)()) F815_8554;
	R7782[10] = (char *(*)()) F816_8554;
	R7782[11] = (char *(*)()) F817_8554;
	R7782[12] = (char *(*)()) F818_8554;
	R7782[13] = (char *(*)()) F819_8554;
	R7782[14] = (char *(*)()) F806_8494;
}

char *(*R7791[15])();
void R7791_init () {
	R7791[0] = (char *(*)()) F806_8504;
	R7791[1] = (char *(*)()) F807_8504;
	R7791[2] = (char *(*)()) F808_8504;
	R7791[3] = (char *(*)()) F809_8504;
	R7791[4] = (char *(*)()) F810_8504;
	R7791[5] = (char *(*)()) F811_8504;
	R7791[6] = (char *(*)()) F812_8504;
	R7791[7] = (char *(*)()) F813_8504;
	R7791[8] = (char *(*)()) F814_8504;
	R7791[9] = (char *(*)()) F806_8504;
	R7791[10] = (char *(*)()) F807_8504;
	R7791[11] = (char *(*)()) F809_8504;
	R7791[12] = (char *(*)()) F813_8504;
	R7791[13] = (char *(*)()) F814_8504;
	R7791[14] = (char *(*)()) F806_8504;
}

char *(*R7792[15])();
void R7792_init () {
	R7792[0] = (char *(*)()) F806_8505;
	R7792[1] = (char *(*)()) F807_8505;
	R7792[2] = (char *(*)()) F808_8505;
	R7792[3] = (char *(*)()) F809_8505;
	R7792[4] = (char *(*)()) F810_8505;
	R7792[5] = (char *(*)()) F811_8505;
	R7792[6] = (char *(*)()) F812_8505;
	R7792[7] = (char *(*)()) F813_8505;
	R7792[8] = (char *(*)()) F814_8505;
	R7792[9] = (char *(*)()) F806_8505;
	R7792[10] = (char *(*)()) F807_8505;
	R7792[11] = (char *(*)()) F809_8505;
	R7792[12] = (char *(*)()) F813_8505;
	R7792[13] = (char *(*)()) F814_8505;
	R7792[14] = (char *(*)()) F806_8505;
}

char *(*R7799[15])();
void R7799_init () {
	R7799[0] = (char *(*)()) F806_8512;
	R7799[1] = (char *(*)()) F807_8512_7799_1;
	R7799[2] = (char *(*)()) F808_8512;
	R7799[3] = (char *(*)()) F809_8512_7799_1;
	R7799[4] = (char *(*)()) F810_8512_7799_1;
	R7799[5] = (char *(*)()) F811_8512_7799_1;
	R7799[6] = (char *(*)()) F812_8512_7799_1;
	R7799[7] = (char *(*)()) F813_8512_7799_1;
	R7799[8] = (char *(*)()) F814_8512_7799_1;
	R7799[9] = (char *(*)()) F806_8512;
	R7799[10] = (char *(*)()) F807_8512_7799_1;
	R7799[11] = (char *(*)()) F809_8512_7799_1;
	R7799[12] = (char *(*)()) F813_8512_7799_1;
	R7799[13] = (char *(*)()) F814_8512_7799_1;
	R7799[14] = (char *(*)()) F806_8512;
}
static EIF_REFERENCE F807_8512_7799_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F807_8512(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1498, 0x00).id, 1498, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F809_8512_7799_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F809_8512(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F810_8512_7799_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F810_8512(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F811_8512_7799_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F811_8512(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F812_8512_7799_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F812_8512(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F813_8512_7799_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F813_8512(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1504, 0x00).id, 1504, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F814_8512_7799_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F814_8512(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1195, 0x00).id, 1195, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}

char *(*R7800[15])();
void R7800_init () {
	R7800[0] = (char *(*)()) F806_8513;
	R7800[1] = (char *(*)()) F807_8513;
	R7800[2] = (char *(*)()) F808_8513_7800_1;
	R7800[3] = (char *(*)()) F809_8513;
	R7800[4] = (char *(*)()) F810_8513_7800_1;
	R7800[5] = (char *(*)()) F811_8513_7800_1;
	R7800[6] = (char *(*)()) F812_8513;
	R7800[7] = (char *(*)()) F813_8513;
	R7800[8] = (char *(*)()) F814_8513;
	R7800[9] = (char *(*)()) F806_8513;
	R7800[10] = (char *(*)()) F807_8513;
	R7800[11] = (char *(*)()) F809_8513;
	R7800[12] = (char *(*)()) F813_8513;
	R7800[13] = (char *(*)()) F814_8513;
	R7800[14] = (char *(*)()) F806_8513;
}
static EIF_REFERENCE F808_8513_7800_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F808_8513(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F810_8513_7800_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F810_8513(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F811_8513_7800_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F811_8513(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1498, 0x00).id, 1498, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}

char *(*R7801[15])();
void R7801_init () {
	R7801[0] = (char *(*)()) F806_8514;
	R7801[1] = (char *(*)()) F807_8514;
	R7801[2] = (char *(*)()) F808_8514;
	R7801[3] = (char *(*)()) F809_8514;
	R7801[4] = (char *(*)()) F810_8514;
	R7801[5] = (char *(*)()) F811_8514;
	R7801[6] = (char *(*)()) F812_8514;
	R7801[7] = (char *(*)()) F813_8514;
	R7801[8] = (char *(*)()) F814_8514;
	R7801[9] = (char *(*)()) F806_8514;
	R7801[10] = (char *(*)()) F807_8514;
	R7801[11] = (char *(*)()) F809_8514;
	R7801[12] = (char *(*)()) F813_8514;
	R7801[13] = (char *(*)()) F814_8514;
	R7801[14] = (char *(*)()) F806_8514;
}

char *(*R7802[15])();
void R7802_init () {
	R7802[0] = (char *(*)()) F806_8515;
	R7802[1] = (char *(*)()) F807_8515;
	R7802[2] = (char *(*)()) F808_8515;
	R7802[3] = (char *(*)()) F809_8515;
	R7802[4] = (char *(*)()) F810_8515;
	R7802[5] = (char *(*)()) F811_8515;
	R7802[6] = (char *(*)()) F812_8515;
	R7802[7] = (char *(*)()) F813_8515;
	R7802[8] = (char *(*)()) F814_8515;
	R7802[9] = (char *(*)()) F806_8515;
	R7802[10] = (char *(*)()) F807_8515;
	R7802[11] = (char *(*)()) F809_8515;
	R7802[12] = (char *(*)()) F813_8515;
	R7802[13] = (char *(*)()) F814_8515;
	R7802[14] = (char *(*)()) F806_8515;
}

char *(*R7803[15])();
void R7803_init () {
	R7803[0] = (char *(*)()) F806_8516;
	R7803[1] = (char *(*)()) F807_8516;
	R7803[2] = (char *(*)()) F808_8516;
	R7803[3] = (char *(*)()) F809_8516;
	R7803[4] = (char *(*)()) F810_8516;
	R7803[5] = (char *(*)()) F811_8516;
	R7803[6] = (char *(*)()) F812_8516;
	R7803[7] = (char *(*)()) F813_8516;
	R7803[8] = (char *(*)()) F814_8516;
	R7803[9] = (char *(*)()) F806_8516;
	R7803[10] = (char *(*)()) F807_8516;
	R7803[11] = (char *(*)()) F809_8516;
	R7803[12] = (char *(*)()) F813_8516;
	R7803[13] = (char *(*)()) F814_8516;
	R7803[14] = (char *(*)()) F806_8516;
}

char *(*R7804[15])();
void R7804_init () {
	R7804[0] = (char *(*)()) F806_8517;
	R7804[1] = (char *(*)()) F807_8517;
	R7804[2] = (char *(*)()) F808_8517;
	R7804[3] = (char *(*)()) F809_8517;
	R7804[4] = (char *(*)()) F810_8517;
	R7804[5] = (char *(*)()) F811_8517;
	R7804[6] = (char *(*)()) F812_8517;
	R7804[7] = (char *(*)()) F813_8517;
	R7804[8] = (char *(*)()) F814_8517;
	R7804[9] = (char *(*)()) F806_8517;
	R7804[10] = (char *(*)()) F807_8517;
	R7804[11] = (char *(*)()) F809_8517;
	R7804[12] = (char *(*)()) F813_8517;
	R7804[13] = (char *(*)()) F814_8517;
	R7804[14] = (char *(*)()) F806_8517;
}

char *(*R7805[15])();
void R7805_init () {
	R7805[0] = (char *(*)()) F806_8518;
	R7805[1] = (char *(*)()) F807_8518;
	R7805[2] = (char *(*)()) F808_8518;
	R7805[3] = (char *(*)()) F809_8518;
	R7805[4] = (char *(*)()) F810_8518;
	R7805[5] = (char *(*)()) F811_8518;
	R7805[6] = (char *(*)()) F812_8518;
	R7805[7] = (char *(*)()) F813_8518;
	R7805[8] = (char *(*)()) F814_8518;
	R7805[9] = (char *(*)()) F806_8518;
	R7805[10] = (char *(*)()) F807_8518;
	R7805[11] = (char *(*)()) F809_8518;
	R7805[12] = (char *(*)()) F813_8518;
	R7805[13] = (char *(*)()) F814_8518;
	R7805[14] = (char *(*)()) F806_8518;
}

char *(*R7807[15])();
void R7807_init () {
	R7807[0] = (char *(*)()) F806_8520;
	R7807[1] = (char *(*)()) F807_8520;
	R7807[2] = (char *(*)()) F808_8520;
	R7807[3] = (char *(*)()) F809_8520;
	R7807[4] = (char *(*)()) F810_8520;
	R7807[5] = (char *(*)()) F811_8520;
	R7807[6] = (char *(*)()) F812_8520;
	R7807[7] = (char *(*)()) F813_8520;
	R7807[8] = (char *(*)()) F814_8520;
	R7807[9] = (char *(*)()) F806_8520;
	R7807[10] = (char *(*)()) F807_8520;
	R7807[11] = (char *(*)()) F809_8520;
	R7807[12] = (char *(*)()) F813_8520;
	R7807[13] = (char *(*)()) F814_8520;
	R7807[14] = (char *(*)()) F806_8520;
}

char *(*R7808[15])();
void R7808_init () {
	R7808[0] = (char *(*)()) F806_8521;
	R7808[1] = (char *(*)()) F807_8521;
	R7808[2] = (char *(*)()) F808_8521;
	R7808[3] = (char *(*)()) F809_8521;
	R7808[4] = (char *(*)()) F810_8521;
	R7808[5] = (char *(*)()) F811_8521;
	R7808[6] = (char *(*)()) F812_8521;
	R7808[7] = (char *(*)()) F813_8521;
	R7808[8] = (char *(*)()) F814_8521;
	R7808[9] = (char *(*)()) F806_8521;
	R7808[10] = (char *(*)()) F807_8521;
	R7808[11] = (char *(*)()) F809_8521;
	R7808[12] = (char *(*)()) F813_8521;
	R7808[13] = (char *(*)()) F814_8521;
	R7808[14] = (char *(*)()) F806_8521;
}

char *(*R7809[15])();
void R7809_init () {
	R7809[0] = (char *(*)()) F806_8522;
	R7809[1] = (char *(*)()) F807_8522;
	R7809[2] = (char *(*)()) F808_8522;
	R7809[3] = (char *(*)()) F809_8522;
	R7809[4] = (char *(*)()) F810_8522;
	R7809[5] = (char *(*)()) F811_8522;
	R7809[6] = (char *(*)()) F812_8522;
	R7809[7] = (char *(*)()) F813_8522;
	R7809[8] = (char *(*)()) F814_8522;
	R7809[9] = (char *(*)()) F806_8522;
	R7809[10] = (char *(*)()) F807_8522;
	R7809[11] = (char *(*)()) F809_8522;
	R7809[12] = (char *(*)()) F813_8522;
	R7809[13] = (char *(*)()) F814_8522;
	R7809[14] = (char *(*)()) F806_8522;
}

char *(*R7813[15])();
void R7813_init () {
	R7813[0] = (char *(*)()) F806_8526;
	R7813[1] = (char *(*)()) F807_8526;
	R7813[2] = (char *(*)()) F808_8526_7813_4;
	R7813[3] = (char *(*)()) F809_8526;
	R7813[4] = (char *(*)()) F810_8526_7813_4;
	R7813[5] = (char *(*)()) F811_8526_7813_4;
	R7813[6] = (char *(*)()) F812_8526;
	R7813[7] = (char *(*)()) F813_8526;
	R7813[8] = (char *(*)()) F814_8526;
	R7813[9] = (char *(*)()) F806_8526;
	R7813[10] = (char *(*)()) F807_8526;
	R7813[11] = (char *(*)()) F809_8526;
	R7813[12] = (char *(*)()) F813_8526;
	R7813[13] = (char *(*)()) F814_8526;
	R7813[14] = (char *(*)()) F806_8526;
}
static void F808_8526_7813_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F808_8526(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F810_8526_7813_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F810_8526(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F811_8526_7813_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F811_8526(Current, *(EIF_NATURAL_32 *)arg1);
}

char *(*R7814[15])();
void R7814_init () {
	R7814[0] = (char *(*)()) F806_8527;
	R7814[1] = (char *(*)()) F807_8527;
	R7814[2] = (char *(*)()) F808_8527_7814_4;
	R7814[3] = (char *(*)()) F809_8527;
	R7814[4] = (char *(*)()) F810_8527_7814_4;
	R7814[5] = (char *(*)()) F811_8527_7814_4;
	R7814[6] = (char *(*)()) F812_8527;
	R7814[7] = (char *(*)()) F813_8527;
	R7814[8] = (char *(*)()) F814_8527;
	R7814[9] = (char *(*)()) F806_8527;
	R7814[10] = (char *(*)()) F807_8527;
	R7814[11] = (char *(*)()) F809_8527;
	R7814[12] = (char *(*)()) F813_8527;
	R7814[13] = (char *(*)()) F814_8527;
	R7814[14] = (char *(*)()) F806_8527;
}
static void F808_8527_7814_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F808_8527(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F810_8527_7814_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F810_8527(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F811_8527_7814_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F811_8527(Current, *(EIF_NATURAL_32 *)arg1);
}

char *(*R7819[15])();
void R7819_init () {
	R7819[0] = (char *(*)()) F806_8532;
	R7819[1] = (char *(*)()) F807_8532;
	R7819[2] = (char *(*)()) F808_8532;
	R7819[3] = (char *(*)()) F809_8532;
	R7819[4] = (char *(*)()) F810_8532;
	R7819[5] = (char *(*)()) F811_8532;
	R7819[6] = (char *(*)()) F812_8532;
	R7819[7] = (char *(*)()) F813_8532;
	R7819[8] = (char *(*)()) F814_8532;
	R7819[9] = (char *(*)()) F806_8532;
	R7819[10] = (char *(*)()) F807_8532;
	R7819[11] = (char *(*)()) F809_8532;
	R7819[12] = (char *(*)()) F813_8532;
	R7819[13] = (char *(*)()) F814_8532;
	R7819[14] = (char *(*)()) F806_8532;
}

char *(*R7832[15])();
void R7832_init () {
	R7832[0] = (char *(*)()) F806_8545;
	R7832[1] = (char *(*)()) F807_8545;
	R7832[2] = (char *(*)()) F808_8545;
	R7832[3] = (char *(*)()) F809_8545;
	R7832[4] = (char *(*)()) F810_8545;
	R7832[5] = (char *(*)()) F811_8545;
	R7832[6] = (char *(*)()) F812_8545;
	R7832[7] = (char *(*)()) F813_8545;
	R7832[8] = (char *(*)()) F814_8545;
	R7832[9] = (char *(*)()) F806_8545;
	R7832[10] = (char *(*)()) F807_8545;
	R7832[11] = (char *(*)()) F809_8545;
	R7832[12] = (char *(*)()) F813_8545;
	R7832[13] = (char *(*)()) F814_8545;
	R7832[14] = (char *(*)()) F806_8545;
}

char *(*R7835[5])();
void R7835_init () {
	R7835[0] = (char *(*)()) F815_8548;
	R7835[1] = (char *(*)()) F816_8548;
	R7835[2] = (char *(*)()) F817_8548;
	R7835[3] = (char *(*)()) F818_8548;
	R7835[4] = (char *(*)()) F819_8548;
}

char *(*R7854[2])();
void R7854_init () {
	R7854[0] = (char *(*)()) F833_8587;
	R7854[1] = (char *(*)()) F834_8609;
}

char *(*R7871[524])();
void R7871_init () {
	R7871[0] = (char *(*)()) F883_8669;
	R7871[1] = (char *(*)()) F884_8669_7871_1;
	R7871[2] = (char *(*)()) F885_8669_7871_1;
	{long i; for (i = 3; i < 5; i++) R7871[i] = (char *(*)()) F883_8669;}
	R7871[5] = (char *(*)()) F885_8669_7871_1;
	R7871[6] = (char *(*)()) F884_8669_7871_1;
	{long i; for (i = 7; i < 9; i++) R7871[i] = (char *(*)()) F883_8669;}
	R7871[9] = (char *(*)()) F892_8789;
	R7871[10] = (char *(*)()) F893_8789_7871_1;
	R7871[11] = (char *(*)()) F894_8789_7871_1;
	R7871[12] = (char *(*)()) F895_8789_7871_1;
	R7871[13] = (char *(*)()) F896_8789_7871_1;
	R7871[14] = (char *(*)()) F897_8789_7871_1;
	R7871[15] = (char *(*)()) F898_8789_7871_1;
	R7871[16] = (char *(*)()) F899_8789_7871_1;
	R7871[17] = (char *(*)()) F900_8789_7871_1;
	R7871[18] = (char *(*)()) F901_8789_7871_1;
	R7871[19] = (char *(*)()) F902_8789_7871_1;
	R7871[20] = (char *(*)()) F903_8789_7871_1;
	{long i; for (i = 21; i < 23; i++) R7871[i] = (char *(*)()) F892_8789;}
	R7871[23] = (char *(*)()) F895_8789_7871_1;
	R7871[24] = (char *(*)()) F897_8789_7871_1;
	R7871[25] = (char *(*)()) F892_8789;
	R7871[30] = (char *(*)()) F892_8789;
	R7871[31] = (char *(*)()) F895_8789_7871_1;
	{long i; for (i = 32; i < 36; i++) R7871[i] = (char *(*)()) F892_8789;}
	R7871[38] = (char *(*)()) F892_8789;
	R7871[41] = (char *(*)()) F892_8789;
	{long i; for (i = 43; i < 45; i++) R7871[i] = (char *(*)()) F892_8789;}
	R7871[47] = (char *(*)()) F892_8789;
	{long i; for (i = 49; i < 55; i++) R7871[i] = (char *(*)()) F892_8789;}
	{long i; for (i = 470; i < 472; i++) R7871[i] = (char *(*)()) F835_8616;}
	{long i; for (i = 489; i < 491; i++) R7871[i] = (char *(*)()) F835_8616;}
	R7871[492] = (char *(*)()) F835_8616;
	R7871[512] = (char *(*)()) F892_8789;
	R7871[523] = (char *(*)()) F835_8616;
}
static EIF_REFERENCE F884_8669_7871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F884_8669(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F885_8669_7871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F885_8669(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1195, 0x00).id, 1195, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F893_8789_7871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F893_8789(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1498, 0x00).id, 1498, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F894_8789_7871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F894_8789(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1495, 0x00).id, 1495, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F895_8789_7871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F895_8789(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F896_8789_7871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F896_8789(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1504, 0x00).id, 1504, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F897_8789_7871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F897_8789(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1195, 0x00).id, 1195, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F898_8789_7871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F898_8789(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F899_8789_7871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F899_8789(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1192, 0x00).id, 1192, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F900_8789_7871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F900_8789(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F901_8789_7871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F901_8789(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1501, 0x00).id, 1501, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F902_8789_7871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F902_8789(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1507, 0x00).id, 1507, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F903_8789_7871_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F903_8789(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1510, 0x00).id, 1510, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R7872[9])();
void R7872_init () {
	R7872[0] = (char *(*)()) F883_8688;
	R7872[1] = (char *(*)()) F884_8688;
	R7872[2] = (char *(*)()) F885_8688;
	{long i; for (i = 3; i < 5; i++) R7872[i] = (char *(*)()) F883_8688;}
	R7872[5] = (char *(*)()) F885_8688;
	R7872[6] = (char *(*)()) F884_8688;
	R7872[7] = (char *(*)()) F883_8688;
	R7872[8] = (char *(*)()) F891_8763;
}

char *(*R7873[524])();
void R7873_init () {
	R7873[0] = (char *(*)()) F883_8689;
	R7873[1] = (char *(*)()) F884_8689;
	R7873[2] = (char *(*)()) F885_8689;
	{long i; for (i = 3; i < 5; i++) R7873[i] = (char *(*)()) F883_8689;}
	R7873[5] = (char *(*)()) F885_8689;
	R7873[6] = (char *(*)()) F884_8689;
	{long i; for (i = 7; i < 9; i++) R7873[i] = (char *(*)()) F883_8689;}
	R7873[9] = (char *(*)()) F892_8815;
	R7873[10] = (char *(*)()) F893_8815;
	R7873[11] = (char *(*)()) F894_8815;
	R7873[12] = (char *(*)()) F895_8815;
	R7873[13] = (char *(*)()) F896_8815;
	R7873[14] = (char *(*)()) F897_8815;
	R7873[15] = (char *(*)()) F898_8815;
	R7873[16] = (char *(*)()) F899_8815;
	R7873[17] = (char *(*)()) F900_8815;
	R7873[18] = (char *(*)()) F901_8815;
	R7873[19] = (char *(*)()) F902_8815;
	R7873[20] = (char *(*)()) F903_8815;
	{long i; for (i = 21; i < 23; i++) R7873[i] = (char *(*)()) F892_8815;}
	R7873[23] = (char *(*)()) F895_8815;
	R7873[24] = (char *(*)()) F897_8815;
	R7873[25] = (char *(*)()) F892_8815;
	R7873[30] = (char *(*)()) F892_8815;
	R7873[31] = (char *(*)()) F895_8815;
	{long i; for (i = 32; i < 36; i++) R7873[i] = (char *(*)()) F892_8815;}
	R7873[38] = (char *(*)()) F892_8815;
	R7873[41] = (char *(*)()) F892_8815;
	{long i; for (i = 43; i < 45; i++) R7873[i] = (char *(*)()) F892_8815;}
	R7873[47] = (char *(*)()) F892_8815;
	{long i; for (i = 49; i < 55; i++) R7873[i] = (char *(*)()) F892_8815;}
	{long i; for (i = 470; i < 472; i++) R7873[i] = (char *(*)()) F1341_12733;}
	{long i; for (i = 489; i < 491; i++) R7873[i] = (char *(*)()) F1341_12733;}
	R7873[492] = (char *(*)()) F1341_12733;
	R7873[512] = (char *(*)()) F892_8815;
	R7873[523] = (char *(*)()) F1341_12733;
}

char *(*R7874[524])();
void R7874_init () {
	R7874[0] = (char *(*)()) F883_8679;
	R7874[1] = (char *(*)()) F884_8679;
	R7874[2] = (char *(*)()) F885_8679;
	{long i; for (i = 3; i < 5; i++) R7874[i] = (char *(*)()) F883_8679;}
	R7874[5] = (char *(*)()) F885_8679;
	R7874[6] = (char *(*)()) F884_8679;
	{long i; for (i = 7; i < 9; i++) R7874[i] = (char *(*)()) F883_8679;}
	R7874[9] = (char *(*)()) F835_8628;
	R7874[10] = (char *(*)()) F836_8628;
	R7874[11] = (char *(*)()) F837_8628;
	R7874[12] = (char *(*)()) F838_8628;
	R7874[13] = (char *(*)()) F839_8628;
	R7874[14] = (char *(*)()) F840_8628;
	R7874[15] = (char *(*)()) F841_8628;
	R7874[16] = (char *(*)()) F842_8628;
	R7874[17] = (char *(*)()) F843_8628;
	R7874[18] = (char *(*)()) F844_8628;
	R7874[19] = (char *(*)()) F845_8628;
	R7874[20] = (char *(*)()) F846_8628;
	{long i; for (i = 21; i < 23; i++) R7874[i] = (char *(*)()) F835_8628;}
	R7874[23] = (char *(*)()) F838_8628;
	R7874[24] = (char *(*)()) F840_8628;
	R7874[25] = (char *(*)()) F835_8628;
	R7874[30] = (char *(*)()) F835_8628;
	R7874[31] = (char *(*)()) F838_8628;
	{long i; for (i = 32; i < 36; i++) R7874[i] = (char *(*)()) F835_8628;}
	R7874[38] = (char *(*)()) F835_8628;
	R7874[41] = (char *(*)()) F835_8628;
	{long i; for (i = 43; i < 45; i++) R7874[i] = (char *(*)()) F835_8628;}
	R7874[47] = (char *(*)()) F835_8628;
	{long i; for (i = 49; i < 55; i++) R7874[i] = (char *(*)()) F835_8628;}
	{long i; for (i = 470; i < 472; i++) R7874[i] = (char *(*)()) F835_8628;}
	{long i; for (i = 489; i < 491; i++) R7874[i] = (char *(*)()) F835_8628;}
	R7874[492] = (char *(*)()) F835_8628;
	R7874[512] = (char *(*)()) F835_8628;
	R7874[523] = (char *(*)()) F835_8628;
}

char *(*R7875[524])();
void R7875_init () {
	R7875[0] = (char *(*)()) F883_8680;
	R7875[1] = (char *(*)()) F884_8680;
	R7875[2] = (char *(*)()) F885_8680;
	{long i; for (i = 3; i < 5; i++) R7875[i] = (char *(*)()) F883_8680;}
	R7875[5] = (char *(*)()) F885_8680;
	R7875[6] = (char *(*)()) F884_8680;
	R7875[7] = (char *(*)()) F883_8680;
	R7875[8] = (char *(*)()) F891_8759;
	R7875[9] = (char *(*)()) F835_8629;
	R7875[10] = (char *(*)()) F836_8629;
	R7875[11] = (char *(*)()) F837_8629;
	R7875[12] = (char *(*)()) F838_8629;
	R7875[13] = (char *(*)()) F839_8629;
	R7875[14] = (char *(*)()) F840_8629;
	R7875[15] = (char *(*)()) F841_8629;
	R7875[16] = (char *(*)()) F842_8629;
	R7875[17] = (char *(*)()) F843_8629;
	R7875[18] = (char *(*)()) F844_8629;
	R7875[19] = (char *(*)()) F845_8629;
	R7875[20] = (char *(*)()) F846_8629;
	{long i; for (i = 21; i < 23; i++) R7875[i] = (char *(*)()) F835_8629;}
	R7875[23] = (char *(*)()) F838_8629;
	R7875[24] = (char *(*)()) F840_8629;
	R7875[25] = (char *(*)()) F835_8629;
	R7875[30] = (char *(*)()) F835_8629;
	R7875[31] = (char *(*)()) F838_8629;
	{long i; for (i = 32; i < 36; i++) R7875[i] = (char *(*)()) F835_8629;}
	R7875[38] = (char *(*)()) F835_8629;
	R7875[41] = (char *(*)()) F835_8629;
	{long i; for (i = 43; i < 45; i++) R7875[i] = (char *(*)()) F835_8629;}
	R7875[47] = (char *(*)()) F835_8629;
	{long i; for (i = 49; i < 55; i++) R7875[i] = (char *(*)()) F835_8629;}
	{long i; for (i = 470; i < 472; i++) R7875[i] = (char *(*)()) F835_8629;}
	{long i; for (i = 489; i < 491; i++) R7875[i] = (char *(*)()) F835_8629;}
	R7875[492] = (char *(*)()) F835_8629;
	R7875[512] = (char *(*)()) F835_8629;
	R7875[523] = (char *(*)()) F835_8629;
}

char *(*R7880[9])();
void R7880_init () {
	R7880[0] = (char *(*)()) F883_8691;
	R7880[1] = (char *(*)()) F884_8691_7880_4;
	R7880[2] = (char *(*)()) F885_8691_7880_4;
	{long i; for (i = 3; i < 5; i++) R7880[i] = (char *(*)()) F883_8691;}
	R7880[5] = (char *(*)()) F885_8691_7880_4;
	R7880[6] = (char *(*)()) F884_8691_7880_4;
	R7880[7] = (char *(*)()) F883_8691;
	R7880[8] = (char *(*)()) F891_8764;
}
static void F884_8691_7880_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F884_8691(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F885_8691_7880_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F885_8691(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R7881[504])();
void R7881_init () {
	R7881[0] = (char *(*)()) F892_8822;
	R7881[1] = (char *(*)()) F893_8822_7881_4;
	R7881[2] = (char *(*)()) F894_8822_7881_4;
	R7881[3] = (char *(*)()) F895_8822_7881_4;
	R7881[4] = (char *(*)()) F896_8822_7881_4;
	R7881[5] = (char *(*)()) F897_8822_7881_4;
	R7881[6] = (char *(*)()) F898_8822_7881_4;
	R7881[7] = (char *(*)()) F899_8822_7881_4;
	R7881[8] = (char *(*)()) F900_8822_7881_4;
	R7881[9] = (char *(*)()) F901_8822_7881_4;
	R7881[10] = (char *(*)()) F902_8822_7881_4;
	R7881[11] = (char *(*)()) F903_8822_7881_4;
	{long i; for (i = 12; i < 14; i++) R7881[i] = (char *(*)()) F892_8822;}
	R7881[14] = (char *(*)()) F895_8822_7881_4;
	R7881[15] = (char *(*)()) F897_8822_7881_4;
	R7881[16] = (char *(*)()) F892_8822;
	R7881[21] = (char *(*)()) F909_8877;
	R7881[22] = (char *(*)()) F910_8877_7881_4;
	{long i; for (i = 23; i < 27; i++) R7881[i] = (char *(*)()) F909_8877;}
	R7881[29] = (char *(*)()) F909_8877;
	R7881[32] = (char *(*)()) F909_8877;
	{long i; for (i = 34; i < 36; i++) R7881[i] = (char *(*)()) F909_8877;}
	R7881[38] = (char *(*)()) F909_8877;
	{long i; for (i = 40; i < 46; i++) R7881[i] = (char *(*)()) F909_8877;}
	R7881[503] = (char *(*)()) F909_8877;
}
static void F893_8822_7881_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F893_8822(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F894_8822_7881_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F894_8822(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F895_8822_7881_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F895_8822(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F896_8822_7881_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F896_8822(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F897_8822_7881_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F897_8822(Current, *(EIF_BOOLEAN *)arg1);
}
static void F898_8822_7881_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F898_8822(Current, *(EIF_POINTER *)arg1);
}
static void F899_8822_7881_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F899_8822(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F900_8822_7881_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F900_8822(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F901_8822_7881_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F901_8822(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F902_8822_7881_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F902_8822(Current, *(EIF_REAL_32 *)arg1);
}
static void F903_8822_7881_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F903_8822(Current, *(EIF_REAL_64 *)arg1);
}
static void F910_8877_7881_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F910_8877(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R7886[9])();
void R7886_init () {
	R7886[0] = (char *(*)()) F883_8700;
	R7886[1] = (char *(*)()) F884_8700;
	R7886[2] = (char *(*)()) F885_8700;
	{long i; for (i = 3; i < 5; i++) R7886[i] = (char *(*)()) F883_8700;}
	R7886[5] = (char *(*)()) F885_8700;
	R7886[6] = (char *(*)()) F884_8700;
	R7886[7] = (char *(*)()) F883_8700;
	R7886[8] = (char *(*)()) F891_8772;
}

char *(*R7891[9])();
void R7891_init () {
	R7891[0] = (char *(*)()) F883_8704;
	R7891[1] = (char *(*)()) F884_8704_7891_5;
	R7891[2] = (char *(*)()) F885_8704_7891_5;
	{long i; for (i = 3; i < 5; i++) R7891[i] = (char *(*)()) F883_8704;}
	R7891[5] = (char *(*)()) F885_8704_7891_5;
	R7891[6] = (char *(*)()) F884_8704_7891_5;
	R7891[7] = (char *(*)()) F883_8704;
	R7891[8] = (char *(*)()) F891_8778;
}
static EIF_REFERENCE F884_8704_7891_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F884_8704(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F885_8704_7891_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F885_8704(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R7892[9])();
void R7892_init () {
	R7892[0] = (char *(*)()) F883_8705;
	R7892[1] = (char *(*)()) F884_8705;
	R7892[2] = (char *(*)()) F885_8705;
	{long i; for (i = 3; i < 5; i++) R7892[i] = (char *(*)()) F883_8705;}
	R7892[5] = (char *(*)()) F885_8705;
	R7892[6] = (char *(*)()) F884_8705;
	R7892[7] = (char *(*)()) F883_8705;
	R7892[8] = (char *(*)()) F891_8779;
}

char *(*R7895[9])();
void R7895_init () {
	R7895[0] = (char *(*)()) F883_8708;
	R7895[1] = (char *(*)()) F884_8708;
	R7895[2] = (char *(*)()) F885_8708;
	{long i; for (i = 3; i < 5; i++) R7895[i] = (char *(*)()) F883_8708;}
	R7895[5] = (char *(*)()) F885_8708;
	R7895[6] = (char *(*)()) F884_8708;
	R7895[7] = (char *(*)()) F883_8708;
	R7895[8] = (char *(*)()) F891_8755;
}

char *(*R7896[9])();
void R7896_init () {
	R7896[0] = (char *(*)()) F883_8709;
	R7896[1] = (char *(*)()) F884_8709;
	R7896[2] = (char *(*)()) F885_8709;
	{long i; for (i = 3; i < 5; i++) R7896[i] = (char *(*)()) F883_8709;}
	R7896[5] = (char *(*)()) F885_8709;
	R7896[6] = (char *(*)()) F884_8709;
	{long i; for (i = 7; i < 9; i++) R7896[i] = (char *(*)()) F883_8709;}
}

char *(*R7897[9])();
void R7897_init () {
	R7897[0] = (char *(*)()) F883_8710;
	R7897[1] = (char *(*)()) F884_8710;
	R7897[2] = (char *(*)()) F885_8710;
	{long i; for (i = 3; i < 5; i++) R7897[i] = (char *(*)()) F883_8710;}
	R7897[5] = (char *(*)()) F885_8710;
	R7897[6] = (char *(*)()) F884_8710;
	{long i; for (i = 7; i < 9; i++) R7897[i] = (char *(*)()) F883_8710;}
}

char *(*R7905[3])();
void R7905_init () {
	R7905[0] = (char *(*)()) F883_8667;
	R7905[1] = (char *(*)()) F885_8667_7905_1;
	R7905[2] = (char *(*)()) F884_8667_7905_1;
}
static EIF_REFERENCE F885_8667_7905_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F885_8667(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1195, 0x00).id, 1195, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F884_8667_7905_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F884_8667(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R7906[3])();
void R7906_init () {
	R7906[0] = (char *(*)()) F883_8698;
	R7906[1] = (char *(*)()) F885_8698;
	R7906[2] = (char *(*)()) F884_8698;
}

char *(*R7917[504])();
void R7917_init () {
	R7917[0] = (char *(*)()) F892_8780;
	R7917[1] = (char *(*)()) F893_8780;
	R7917[2] = (char *(*)()) F894_8780;
	R7917[3] = (char *(*)()) F895_8780;
	R7917[4] = (char *(*)()) F896_8780;
	R7917[5] = (char *(*)()) F897_8780;
	R7917[6] = (char *(*)()) F898_8780;
	R7917[7] = (char *(*)()) F899_8780;
	R7917[8] = (char *(*)()) F900_8780;
	R7917[9] = (char *(*)()) F901_8780;
	R7917[10] = (char *(*)()) F902_8780;
	R7917[11] = (char *(*)()) F903_8780;
	R7917[12] = (char *(*)()) F904_8846;
	R7917[13] = (char *(*)()) F892_8780;
	R7917[14] = (char *(*)()) F895_8780;
	R7917[15] = (char *(*)()) F897_8780;
	R7917[16] = (char *(*)()) F908_8861;
	R7917[21] = (char *(*)()) F892_8780;
	R7917[22] = (char *(*)()) F895_8780;
	{long i; for (i = 23; i < 27; i++) R7917[i] = (char *(*)()) F892_8780;}
	R7917[29] = (char *(*)()) F892_8780;
	R7917[32] = (char *(*)()) F892_8780;
	{long i; for (i = 34; i < 36; i++) R7917[i] = (char *(*)()) F892_8780;}
	R7917[38] = (char *(*)()) F892_8780;
	{long i; for (i = 40; i < 46; i++) R7917[i] = (char *(*)()) F892_8780;}
	R7917[503] = (char *(*)()) F892_8780;
}

char *(*R7921[504])();
void R7921_init () {
	R7921[0] = (char *(*)()) F892_8784;
	R7921[1] = (char *(*)()) F893_8784;
	R7921[2] = (char *(*)()) F894_8784;
	R7921[3] = (char *(*)()) F895_8784;
	R7921[4] = (char *(*)()) F896_8784;
	R7921[5] = (char *(*)()) F897_8784;
	R7921[6] = (char *(*)()) F898_8784;
	R7921[7] = (char *(*)()) F899_8784;
	R7921[8] = (char *(*)()) F900_8784;
	R7921[9] = (char *(*)()) F901_8784;
	R7921[10] = (char *(*)()) F902_8784;
	R7921[11] = (char *(*)()) F903_8784;
	{long i; for (i = 12; i < 14; i++) R7921[i] = (char *(*)()) F892_8784;}
	R7921[14] = (char *(*)()) F895_8784;
	R7921[15] = (char *(*)()) F897_8784;
	R7921[16] = (char *(*)()) F892_8784;
	R7921[21] = (char *(*)()) F892_8784;
	R7921[22] = (char *(*)()) F895_8784;
	{long i; for (i = 23; i < 27; i++) R7921[i] = (char *(*)()) F892_8784;}
	R7921[29] = (char *(*)()) F892_8784;
	R7921[32] = (char *(*)()) F892_8784;
	{long i; for (i = 34; i < 36; i++) R7921[i] = (char *(*)()) F892_8784;}
	R7921[38] = (char *(*)()) F892_8784;
	{long i; for (i = 40; i < 46; i++) R7921[i] = (char *(*)()) F892_8784;}
	R7921[503] = (char *(*)()) F892_8784;
}

char *(*R7925[504])();
void R7925_init () {
	R7925[0] = (char *(*)()) F892_8803;
	R7925[1] = (char *(*)()) F893_8803;
	R7925[2] = (char *(*)()) F894_8803;
	R7925[3] = (char *(*)()) F895_8803;
	R7925[4] = (char *(*)()) F896_8803;
	R7925[5] = (char *(*)()) F897_8803;
	R7925[6] = (char *(*)()) F898_8803;
	R7925[7] = (char *(*)()) F899_8803;
	R7925[8] = (char *(*)()) F900_8803;
	R7925[9] = (char *(*)()) F901_8803;
	R7925[10] = (char *(*)()) F902_8803;
	R7925[11] = (char *(*)()) F903_8803;
	{long i; for (i = 12; i < 14; i++) R7925[i] = (char *(*)()) F892_8803;}
	R7925[14] = (char *(*)()) F895_8803;
	R7925[15] = (char *(*)()) F897_8803;
	R7925[16] = (char *(*)()) F892_8803;
	R7925[21] = (char *(*)()) F892_8803;
	R7925[22] = (char *(*)()) F895_8803;
	{long i; for (i = 23; i < 27; i++) R7925[i] = (char *(*)()) F892_8803;}
	R7925[29] = (char *(*)()) F892_8803;
	R7925[32] = (char *(*)()) F892_8803;
	{long i; for (i = 34; i < 36; i++) R7925[i] = (char *(*)()) F892_8803;}
	R7925[38] = (char *(*)()) F892_8803;
	{long i; for (i = 40; i < 46; i++) R7925[i] = (char *(*)()) F892_8803;}
	R7925[503] = (char *(*)()) F892_8803;
}

char *(*R7929[504])();
void R7929_init () {
	R7929[0] = (char *(*)()) F892_8844;
	R7929[1] = (char *(*)()) F893_8844_7929_182;
	R7929[2] = (char *(*)()) F894_8844_7929_182;
	R7929[3] = (char *(*)()) F895_8844_7929_182;
	R7929[4] = (char *(*)()) F896_8844_7929_182;
	R7929[5] = (char *(*)()) F897_8844_7929_182;
	R7929[6] = (char *(*)()) F898_8844_7929_182;
	R7929[7] = (char *(*)()) F899_8844_7929_182;
	R7929[8] = (char *(*)()) F900_8844_7929_182;
	R7929[9] = (char *(*)()) F901_8844_7929_182;
	R7929[10] = (char *(*)()) F902_8844_7929_182;
	R7929[11] = (char *(*)()) F903_8844_7929_182;
	{long i; for (i = 12; i < 14; i++) R7929[i] = (char *(*)()) F892_8844;}
	R7929[14] = (char *(*)()) F895_8844_7929_182;
	R7929[15] = (char *(*)()) F897_8844_7929_182;
	R7929[16] = (char *(*)()) F892_8844;
	R7929[21] = (char *(*)()) F892_8844;
	R7929[22] = (char *(*)()) F895_8844_7929_182;
	{long i; for (i = 23; i < 27; i++) R7929[i] = (char *(*)()) F892_8844;}
	R7929[29] = (char *(*)()) F892_8844;
	R7929[32] = (char *(*)()) F892_8844;
	{long i; for (i = 34; i < 36; i++) R7929[i] = (char *(*)()) F892_8844;}
	R7929[38] = (char *(*)()) F892_8844;
	{long i; for (i = 40; i < 46; i++) R7929[i] = (char *(*)()) F892_8844;}
	R7929[503] = (char *(*)()) F892_8844;
}
static void F893_8844_7929_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F893_8844(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F894_8844_7929_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F894_8844(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F895_8844_7929_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F895_8844(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F896_8844_7929_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F896_8844(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F897_8844_7929_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F897_8844(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F898_8844_7929_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F898_8844(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F899_8844_7929_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F899_8844(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F900_8844_7929_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F900_8844(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F901_8844_7929_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F901_8844(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F902_8844_7929_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F902_8844(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F903_8844_7929_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F903_8844(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R7934[3])();
void R7934_init () {
	R7934[0] = (char *(*)()) F892_8821;
	R7934[1] = (char *(*)()) F895_8821_7934_4;
	R7934[2] = (char *(*)()) F897_8821_7934_4;
}
static void F895_8821_7934_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F895_8821(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F897_8821_7934_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F897_8821(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R7935[3])();
void R7935_init () {
	R7935[0] = (char *(*)()) F892_8834;
	R7935[1] = (char *(*)()) F895_8834;
	R7935[2] = (char *(*)()) F897_8834;
}

char *(*R7945[483])();
void R7945_init () {
	R7945[0] = (char *(*)()) F913_8901;
	R7945[1] = (char *(*)()) F914_8901_7945_182;
	R7945[2] = (char *(*)()) F913_8901;
	{long i; for (i = 3; i < 6; i++) R7945[i] = (char *(*)()) F916_8910;}
	R7945[8] = (char *(*)()) F916_8910;
	R7945[11] = (char *(*)()) F916_8910;
	{long i; for (i = 13; i < 15; i++) R7945[i] = (char *(*)()) F916_8910;}
	R7945[17] = (char *(*)()) F916_8910;
	{long i; for (i = 19; i < 25; i++) R7945[i] = (char *(*)()) F916_8910;}
	R7945[482] = (char *(*)()) F1395_13383;
}
static void F914_8901_7945_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F914_8901(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R7946[483])();
void R7946_init () {
	R7946[0] = (char *(*)()) F913_8902;
	R7946[1] = (char *(*)()) F914_8902_7946_182;
	R7946[2] = (char *(*)()) F913_8902;
	{long i; for (i = 3; i < 6; i++) R7946[i] = (char *(*)()) F916_8911;}
	R7946[8] = (char *(*)()) F916_8911;
	R7946[11] = (char *(*)()) F916_8911;
	{long i; for (i = 13; i < 15; i++) R7946[i] = (char *(*)()) F916_8911;}
	R7946[17] = (char *(*)()) F916_8911;
	{long i; for (i = 19; i < 25; i++) R7946[i] = (char *(*)()) F916_8911;}
	R7946[482] = (char *(*)()) F1395_13384;
}
static void F914_8902_7946_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F914_8902(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R7950[483])();
void R7950_init () {
	R7950[0] = (char *(*)()) F909_8890;
	R7950[1] = (char *(*)()) F910_8890_7950_182;
	{long i; for (i = 2; i < 6; i++) R7950[i] = (char *(*)()) F909_8890;}
	R7950[8] = (char *(*)()) F909_8890;
	R7950[11] = (char *(*)()) F909_8890;
	{long i; for (i = 13; i < 15; i++) R7950[i] = (char *(*)()) F909_8890;}
	R7950[17] = (char *(*)()) F909_8890;
	{long i; for (i = 19; i < 25; i++) R7950[i] = (char *(*)()) F909_8890;}
	R7950[482] = (char *(*)()) F909_8890;
}
static void F910_8890_7950_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F910_8890(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R7951[483])();
void R7951_init () {
	R7951[0] = (char *(*)()) F909_8891;
	R7951[1] = (char *(*)()) F910_8891_7951_182;
	{long i; for (i = 2; i < 6; i++) R7951[i] = (char *(*)()) F909_8891;}
	R7951[8] = (char *(*)()) F909_8891;
	R7951[11] = (char *(*)()) F909_8891;
	{long i; for (i = 13; i < 15; i++) R7951[i] = (char *(*)()) F909_8891;}
	R7951[17] = (char *(*)()) F909_8891;
	{long i; for (i = 19; i < 25; i++) R7951[i] = (char *(*)()) F909_8891;}
	R7951[482] = (char *(*)()) F909_8891;
}
static void F910_8891_7951_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F910_8891(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}


#ifdef __cplusplus
}
#endif
