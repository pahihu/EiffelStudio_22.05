#include "epoly6.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R5413[924])();
void R5413_init () {
	R5413[0] = (char *(*)()) F368_5691;
	R5413[922] = (char *(*)()) F1291_12148;
	R5413[923] = (char *(*)()) F1292_12168;
}

char *(*R5414[924])();
void R5414_init () {
	R5414[0] = (char *(*)()) F369_5695;
	{long i; for (i = 922; i < 924; i++) R5414[i] = (char *(*)()) F370_5698;}
}

char *(*R5415[924])();
void R5415_init () {
	R5415[0] = (char *(*)()) F369_5696;
	{long i; for (i = 922; i < 924; i++) R5415[i] = (char *(*)()) F370_5700;}
}

char *(*R5433[2])();
void R5433_init () {
	R5433[0] = (char *(*)()) F1291_12149;
	R5433[1] = (char *(*)()) F1292_12169;
}

char *(*R5434[2])();
void R5434_init () {
	R5434[0] = (char *(*)()) F1291_12151;
	R5434[1] = (char *(*)()) F1292_12175;
}

char *(*R5661[41])();
void R5661_init () {
	R5661[0] = (char *(*)()) F379_5928;
	R5661[3] = (char *(*)()) F382_5952;
	R5661[5] = (char *(*)()) F384_5954;
	R5661[6] = (char *(*)()) F385_5960;
	R5661[7] = (char *(*)()) F386_5977;
	{long i; for (i = 8; i < 11; i++) R5661[i] = (char *(*)()) F387_5981;}
	R5661[12] = (char *(*)()) F391_5985;
	R5661[13] = (char *(*)()) F392_5989;
	R5661[16] = (char *(*)()) F395_5991;
	R5661[17] = (char *(*)()) F396_5995;
	R5661[19] = (char *(*)()) F398_5997;
	R5661[20] = (char *(*)()) F399_5999;
	R5661[21] = (char *(*)()) F400_6001;
	R5661[23] = (char *(*)()) F402_6007;
	R5661[24] = (char *(*)()) F403_6011;
	R5661[25] = (char *(*)()) F404_6015;
	R5661[26] = (char *(*)()) F405_6017;
	R5661[28] = (char *(*)()) F407_6019;
	R5661[29] = (char *(*)()) F408_6021;
	R5661[31] = (char *(*)()) F410_6023;
	R5661[32] = (char *(*)()) F411_6025;
	R5661[33] = (char *(*)()) F412_6027;
	R5661[35] = (char *(*)()) F414_6029;
	R5661[36] = (char *(*)()) F415_6031;
	R5661[37] = (char *(*)()) F416_6033;
	R5661[38] = (char *(*)()) F417_6035;
	R5661[39] = (char *(*)()) F418_6039;
	R5661[40] = (char *(*)()) F419_6041;
}

char *(*R5720[2])();
void R5720_init () {
	R5720[0] = (char *(*)()) F1643_16919;
	R5720[1] = (char *(*)()) F1644_16984;
}

char *(*R5722[2])();
void R5722_init () {
	R5722[0] = (char *(*)()) F420_6045;
	R5722[1] = (char *(*)()) F1644_16932;
}

char *(*R6012[4])();
void R6012_init () {
	R6012[0] = (char *(*)()) F434_6338;
	R6012[1] = (char *(*)()) F435_6338;
	R6012[2] = (char *(*)()) F436_6338;
	R6012[3] = (char *(*)()) F434_6338;
}

char *(*R6017[1354])();
void R6017_init () {
	R6017[0] = (char *(*)()) F445_6484;
	R6017[1] = (char *(*)()) F446_6495;
	{long i; for (i = 744; i < 746; i++) R6017[i] = (char *(*)()) F1188_10870;}
	{long i; for (i = 747; i < 749; i++) R6017[i] = (char *(*)()) F1191_10910;}
	{long i; for (i = 796; i < 798; i++) R6017[i] = (char *(*)()) F1240_11218;}
	{long i; for (i = 799; i < 801; i++) R6017[i] = (char *(*)()) F1243_11386;}
	R6017[854] = (char *(*)()) F1299_12370;
	R6017[859] = (char *(*)()) F1304_12651;
	{long i; for (i = 978; i < 981; i++) R6017[i] = (char *(*)()) F1420_13533;}
	{long i; for (i = 982; i < 985; i++) R6017[i] = (char *(*)()) F1420_13533;}
	R6017[1038] = (char *(*)()) F1483_13907_6017_2;
	R6017[1039] = (char *(*)()) F1484_13907_6017_2;
	R6017[1041] = (char *(*)()) F1486_14006_6017_2;
	R6017[1042] = (char *(*)()) F1487_14006_6017_2;
	R6017[1044] = (char *(*)()) F1489_14105_6017_2;
	R6017[1045] = (char *(*)()) F1490_14105_6017_2;
	R6017[1047] = (char *(*)()) F1492_14204_6017_2;
	R6017[1048] = (char *(*)()) F1493_14204_6017_2;
	R6017[1050] = (char *(*)()) F1495_14299_6017_2;
	R6017[1051] = (char *(*)()) F1496_14299_6017_2;
	R6017[1053] = (char *(*)()) F1498_14393_6017_2;
	R6017[1054] = (char *(*)()) F1499_14393_6017_2;
	R6017[1056] = (char *(*)()) F1501_14488_6017_2;
	R6017[1057] = (char *(*)()) F1502_14488_6017_2;
	R6017[1059] = (char *(*)()) F1504_14583_6017_2;
	R6017[1060] = (char *(*)()) F1505_14583_6017_2;
	R6017[1062] = (char *(*)()) F1507_14652_6017_2;
	R6017[1063] = (char *(*)()) F1508_14652_6017_2;
	R6017[1065] = (char *(*)()) F1510_14718_6017_2;
	R6017[1066] = (char *(*)()) F1511_14718_6017_2;
	R6017[1269] = (char *(*)()) F1714_18223;
	R6017[1353] = (char *(*)()) F1798_20799;
}
static EIF_BOOLEAN F1483_13907_6017_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1483_13907(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F1484_13907_6017_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1484_13907(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F1486_14006_6017_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1486_14006(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1487_14006_6017_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1487_14006(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1489_14105_6017_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1489_14105(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F1490_14105_6017_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1490_14105(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F1492_14204_6017_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1492_14204(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F1493_14204_6017_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1493_14204(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F1495_14299_6017_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1495_14299(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F1496_14299_6017_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1496_14299(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F1498_14393_6017_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1498_14393(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F1499_14393_6017_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1499_14393(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F1501_14488_6017_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1501_14488(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F1502_14488_6017_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1502_14488(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F1504_14583_6017_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1504_14583(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F1505_14583_6017_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1505_14583(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F1507_14652_6017_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1507_14652(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F1508_14652_6017_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1508_14652(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F1510_14718_6017_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1510_14718(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F1511_14718_6017_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1511_14718(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R6415[7])();
void R6415_init () {
	{long i; for (i = 0; i < 5; i++) R6415[i] = (char *(*)()) F463_6816;}
	R6415[5] = (char *(*)()) F469_6836;
	R6415[6] = (char *(*)()) F463_6816;
}

char *(*R6669[1284])();
void R6669_init () {
	R6669[0] = (char *(*)()) F482_7087;
	R6669[377] = (char *(*)()) F478_7087;
	R6669[378] = (char *(*)()) F479_7087;
	R6669[379] = (char *(*)()) F480_7087;
	R6669[380] = (char *(*)()) F481_7087;
	R6669[381] = (char *(*)()) F482_7087;
	R6669[382] = (char *(*)()) F483_7087;
	R6669[383] = (char *(*)()) F484_7087;
	R6669[384] = (char *(*)()) F485_7087;
	R6669[385] = (char *(*)()) F486_7087;
	R6669[386] = (char *(*)()) F487_7087;
	R6669[387] = (char *(*)()) F488_7087;
	R6669[388] = (char *(*)()) F489_7087;
	{long i; for (i = 389; i < 391; i++) R6669[i] = (char *(*)()) F478_7087;}
	R6669[391] = (char *(*)()) F481_7087;
	R6669[392] = (char *(*)()) F483_7087;
	R6669[393] = (char *(*)()) F478_7087;
	R6669[398] = (char *(*)()) F478_7087;
	R6669[399] = (char *(*)()) F481_7087;
	{long i; for (i = 400; i < 404; i++) R6669[i] = (char *(*)()) F478_7087;}
	R6669[406] = (char *(*)()) F478_7087;
	R6669[409] = (char *(*)()) F478_7087;
	{long i; for (i = 411; i < 413; i++) R6669[i] = (char *(*)()) F478_7087;}
	R6669[415] = (char *(*)()) F478_7087;
	{long i; for (i = 417; i < 424; i++) R6669[i] = (char *(*)()) F478_7087;}
	R6669[424] = (char *(*)()) F479_7087;
	R6669[425] = (char *(*)()) F480_7087;
	R6669[426] = (char *(*)()) F481_7087;
	R6669[427] = (char *(*)()) F482_7087;
	R6669[428] = (char *(*)()) F483_7087;
	R6669[429] = (char *(*)()) F484_7087;
	R6669[430] = (char *(*)()) F485_7087;
	R6669[431] = (char *(*)()) F486_7087;
	R6669[432] = (char *(*)()) F487_7087;
	R6669[433] = (char *(*)()) F488_7087;
	R6669[434] = (char *(*)()) F489_7087;
	R6669[727] = (char *(*)()) F486_7087;
	R6669[730] = (char *(*)()) F485_7087;
	R6669[880] = (char *(*)()) F478_7087;
	R6669[1283] = (char *(*)()) F485_7087;
}

char *(*R6670[1284])();
void R6670_init () {
	R6670[0] = (char *(*)()) F482_7088_6670_182;
	R6670[377] = (char *(*)()) F478_7088;
	R6670[378] = (char *(*)()) F479_7088_6670_182;
	R6670[379] = (char *(*)()) F480_7088_6670_182;
	R6670[380] = (char *(*)()) F481_7088_6670_182;
	R6670[381] = (char *(*)()) F482_7088_6670_182;
	R6670[382] = (char *(*)()) F483_7088_6670_182;
	R6670[383] = (char *(*)()) F484_7088_6670_182;
	R6670[384] = (char *(*)()) F485_7088_6670_182;
	R6670[385] = (char *(*)()) F486_7088_6670_182;
	R6670[386] = (char *(*)()) F487_7088_6670_182;
	R6670[387] = (char *(*)()) F488_7088_6670_182;
	R6670[388] = (char *(*)()) F489_7088_6670_182;
	{long i; for (i = 389; i < 391; i++) R6670[i] = (char *(*)()) F478_7088;}
	R6670[391] = (char *(*)()) F481_7088_6670_182;
	R6670[392] = (char *(*)()) F483_7088_6670_182;
	R6670[393] = (char *(*)()) F478_7088;
	R6670[398] = (char *(*)()) F478_7088;
	R6670[399] = (char *(*)()) F481_7088_6670_182;
	{long i; for (i = 400; i < 404; i++) R6670[i] = (char *(*)()) F478_7088;}
	R6670[406] = (char *(*)()) F478_7088;
	R6670[409] = (char *(*)()) F478_7088;
	{long i; for (i = 411; i < 413; i++) R6670[i] = (char *(*)()) F478_7088;}
	R6670[415] = (char *(*)()) F478_7088;
	{long i; for (i = 417; i < 424; i++) R6670[i] = (char *(*)()) F478_7088;}
	R6670[424] = (char *(*)()) F479_7088_6670_182;
	R6670[425] = (char *(*)()) F480_7088_6670_182;
	R6670[426] = (char *(*)()) F481_7088_6670_182;
	R6670[427] = (char *(*)()) F482_7088_6670_182;
	R6670[428] = (char *(*)()) F483_7088_6670_182;
	R6670[429] = (char *(*)()) F484_7088_6670_182;
	R6670[430] = (char *(*)()) F485_7088_6670_182;
	R6670[431] = (char *(*)()) F486_7088_6670_182;
	R6670[432] = (char *(*)()) F487_7088_6670_182;
	R6670[433] = (char *(*)()) F488_7088_6670_182;
	R6670[434] = (char *(*)()) F489_7088_6670_182;
	R6670[727] = (char *(*)()) F486_7088_6670_182;
	R6670[730] = (char *(*)()) F485_7088_6670_182;
	R6670[880] = (char *(*)()) F478_7088;
	R6670[1283] = (char *(*)()) F485_7088_6670_182;
}
static void F482_7088_6670_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F482_7088(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F479_7088_6670_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F479_7088(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F480_7088_6670_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F480_7088(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F481_7088_6670_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F481_7088(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F483_7088_6670_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F483_7088(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F484_7088_6670_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F484_7088(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F485_7088_6670_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F485_7088(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F486_7088_6670_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F486_7088(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F487_7088_6670_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F487_7088(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F488_7088_6670_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F488_7088(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F489_7088_6670_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F489_7088(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R6676[1284])();
void R6676_init () {
	R6676[0] = (char *(*)()) F482_7094;
	R6676[377] = (char *(*)()) F478_7094;
	R6676[378] = (char *(*)()) F479_7094;
	R6676[379] = (char *(*)()) F480_7094;
	R6676[380] = (char *(*)()) F481_7094;
	R6676[381] = (char *(*)()) F482_7094;
	R6676[382] = (char *(*)()) F483_7094;
	R6676[383] = (char *(*)()) F484_7094;
	R6676[384] = (char *(*)()) F485_7094;
	R6676[385] = (char *(*)()) F486_7094;
	R6676[386] = (char *(*)()) F487_7094;
	R6676[387] = (char *(*)()) F488_7094;
	R6676[388] = (char *(*)()) F489_7094;
	{long i; for (i = 389; i < 391; i++) R6676[i] = (char *(*)()) F478_7094;}
	R6676[391] = (char *(*)()) F481_7094;
	R6676[392] = (char *(*)()) F483_7094;
	R6676[393] = (char *(*)()) F478_7094;
	R6676[398] = (char *(*)()) F478_7094;
	R6676[399] = (char *(*)()) F481_7094;
	{long i; for (i = 400; i < 404; i++) R6676[i] = (char *(*)()) F478_7094;}
	R6676[406] = (char *(*)()) F478_7094;
	R6676[409] = (char *(*)()) F478_7094;
	{long i; for (i = 411; i < 413; i++) R6676[i] = (char *(*)()) F478_7094;}
	R6676[415] = (char *(*)()) F478_7094;
	{long i; for (i = 417; i < 424; i++) R6676[i] = (char *(*)()) F478_7094;}
	R6676[424] = (char *(*)()) F479_7094;
	R6676[425] = (char *(*)()) F480_7094;
	R6676[426] = (char *(*)()) F481_7094;
	R6676[427] = (char *(*)()) F482_7094;
	R6676[428] = (char *(*)()) F483_7094;
	R6676[429] = (char *(*)()) F484_7094;
	R6676[430] = (char *(*)()) F485_7094;
	R6676[431] = (char *(*)()) F486_7094;
	R6676[432] = (char *(*)()) F487_7094;
	R6676[433] = (char *(*)()) F488_7094;
	R6676[434] = (char *(*)()) F489_7094;
	R6676[727] = (char *(*)()) F486_7094;
	R6676[730] = (char *(*)()) F485_7094;
	R6676[880] = (char *(*)()) F478_7094;
	R6676[1283] = (char *(*)()) F485_7094;
}

static EIF_TYPE_INDEX Y6677_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype12[] = {1504,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype13[] = {1504,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype26[] = {1750,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype30[] = {907,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype37[] = {1301,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype38[] = {1230,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype39[] = {1230,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype40[] = {1230,0xFFF9,1,1186,0,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype41[] = {1230,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype42[] = {1230,0xFFF9,1,1186,1486,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype43[] = {1230,0xFFF9,1,1186,1401,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype44[] = {1230,0xFFF9,1,1186,1346,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype45[] = {1230,0xFFF9,1,1186,1154,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype46[] = {1230,0xFFF9,1,1186,1265,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype47[] = {1230,0xFFF9,1,1186,1486,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype48[] = {1230,0xFFF9,1,1186,1394,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype49[] = {1230,0xFFF9,1,1186,1393,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype50[] = {1230,0xFFF9,1,1186,1241,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype51[] = {1230,0xFFF9,1,1186,1486,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype52[] = {1230,0xFFF9,1,1186,1714,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype53[] = {1230,0xFFF9,5,1186,1498,1486,1486,1486,1486,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype54[] = {1230,0xFFF9,7,1186,1486,1486,1510,1510,1510,1486,1486,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype55[] = {1230,0xFFF9,2,1186,1486,1486,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype56[] = {1230,0xFFF9,4,1186,1486,1486,1486,1486,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype57[] = {1230,0xFFF9,3,1186,1486,1486,1154,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype58[] = {1230,0xFFF9,8,1186,1486,1486,1486,1510,1510,1510,1486,1486,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype59[] = {1230,0xFFF9,0,1186,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype77[] = {1504,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype78[] = {1189,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype79[] = {1192,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype80[] = {1192,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype81[] = {1192,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype82[] = {1241,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype83[] = {1192,0xFFFF};
static EIF_TYPE_INDEX Y6677_pgtype84[] = {1192,0xFFFF};
EIF_TYPE_INDEX *Y6677_gen_type [1322];
EIF_TYPE_INDEX Y6677 [1322];
void Y6677_init (void)
{
	egc_routines_types [6677] = Y6677;
	egc_routines_gen_types [6677] = Y6677_gen_type;
	egc_routines_offset [6677] = 477;
	Y6677_gen_type [0] = Y6677_pgtype0;
	Y6677_gen_type [1] = Y6677_pgtype1;
	Y6677_gen_type [2] = Y6677_pgtype2;
	Y6677_gen_type [3] = Y6677_pgtype3;
	Y6677_gen_type [4] = Y6677_pgtype4;
	Y6677_gen_type [5] = Y6677_pgtype5;
	Y6677_gen_type [6] = Y6677_pgtype6;
	Y6677_gen_type [7] = Y6677_pgtype7;
	Y6677_gen_type [8] = Y6677_pgtype8;
	Y6677_gen_type [9] = Y6677_pgtype9;
	Y6677_gen_type [10] = Y6677_pgtype10;
	Y6677_gen_type [11] = Y6677_pgtype11;
	Y6677_gen_type [37] = Y6677_pgtype12;
	Y6677_gen_type [38] = Y6677_pgtype13;
	Y6677_gen_type [414] = Y6677_pgtype14;
	Y6677_gen_type [415] = Y6677_pgtype15;
	Y6677_gen_type [416] = Y6677_pgtype16;
	Y6677_gen_type [417] = Y6677_pgtype17;
	Y6677_gen_type [418] = Y6677_pgtype18;
	Y6677_gen_type [419] = Y6677_pgtype19;
	Y6677_gen_type [420] = Y6677_pgtype20;
	Y6677_gen_type [421] = Y6677_pgtype21;
	Y6677_gen_type [422] = Y6677_pgtype22;
	Y6677_gen_type [423] = Y6677_pgtype23;
	Y6677_gen_type [424] = Y6677_pgtype24;
	Y6677_gen_type [425] = Y6677_pgtype25;
	Y6677_gen_type [426] = Y6677_pgtype26;
	Y6677_gen_type [427] = Y6677_pgtype27;
	Y6677_gen_type [428] = Y6677_pgtype28;
	Y6677_gen_type [429] = Y6677_pgtype29;
	Y6677_gen_type [430] = Y6677_pgtype30;
	Y6677_gen_type [431] = Y6677_pgtype31;
	Y6677_gen_type [432] = Y6677_pgtype32;
	Y6677_gen_type [433] = Y6677_pgtype33;
	Y6677_gen_type [434] = Y6677_pgtype34;
	Y6677_gen_type [435] = Y6677_pgtype35;
	Y6677_gen_type [436] = Y6677_pgtype36;
	Y6677_gen_type [437] = Y6677_pgtype37;
	Y6677_gen_type [438] = Y6677_pgtype38;
	Y6677_gen_type [439] = Y6677_pgtype39;
	Y6677_gen_type [440] = Y6677_pgtype40;
	Y6677_gen_type [441] = Y6677_pgtype41;
	Y6677_gen_type [442] = Y6677_pgtype42;
	Y6677_gen_type [443] = Y6677_pgtype43;
	Y6677_gen_type [444] = Y6677_pgtype44;
	Y6677_gen_type [445] = Y6677_pgtype45;
	Y6677_gen_type [446] = Y6677_pgtype46;
	Y6677_gen_type [447] = Y6677_pgtype47;
	Y6677_gen_type [448] = Y6677_pgtype48;
	Y6677_gen_type [449] = Y6677_pgtype49;
	Y6677_gen_type [450] = Y6677_pgtype50;
	Y6677_gen_type [451] = Y6677_pgtype51;
	Y6677_gen_type [452] = Y6677_pgtype52;
	Y6677_gen_type [453] = Y6677_pgtype53;
	Y6677_gen_type [454] = Y6677_pgtype54;
	Y6677_gen_type [455] = Y6677_pgtype55;
	Y6677_gen_type [456] = Y6677_pgtype56;
	Y6677_gen_type [457] = Y6677_pgtype57;
	Y6677_gen_type [458] = Y6677_pgtype58;
	Y6677_gen_type [459] = Y6677_pgtype59;
	Y6677_gen_type [460] = Y6677_pgtype60;
	Y6677_gen_type [461] = Y6677_pgtype61;
	Y6677_gen_type [462] = Y6677_pgtype62;
	Y6677_gen_type [463] = Y6677_pgtype63;
	Y6677_gen_type [464] = Y6677_pgtype64;
	Y6677_gen_type [465] = Y6677_pgtype65;
	Y6677_gen_type [466] = Y6677_pgtype66;
	Y6677_gen_type [467] = Y6677_pgtype67;
	Y6677_gen_type [468] = Y6677_pgtype68;
	Y6677_gen_type [469] = Y6677_pgtype69;
	Y6677_gen_type [470] = Y6677_pgtype70;
	Y6677_gen_type [471] = Y6677_pgtype71;
	Y6677_gen_type [472] = Y6677_pgtype72;
	Y6677_gen_type [473] = Y6677_pgtype73;
	Y6677_gen_type [474] = Y6677_pgtype74;
	Y6677_gen_type [475] = Y6677_pgtype75;
	Y6677_gen_type [476] = Y6677_pgtype76;
	Y6677_gen_type [477] = Y6677_pgtype77;
	Y6677_gen_type [764] = Y6677_pgtype78;
	Y6677_gen_type [767] = Y6677_pgtype79;
	Y6677_gen_type [768] = Y6677_pgtype80;
	Y6677_gen_type [769] = Y6677_pgtype81;
	Y6677_gen_type [917] = Y6677_pgtype82;
	Y6677_gen_type [1320] = Y6677_pgtype83;
	Y6677_gen_type [1321] = Y6677_pgtype84;
	{long i; for (i = 37; i < 39; i++) Y6677[i] = 1504;};
	Y6677[426] = 1750;
	Y6677[430] = 907;
	Y6677[437] = 1301;
	{long i; for (i = 438; i < 460; i++) Y6677[i] = 1230;};
	Y6677[477] = 1504;
	Y6677[764] = 1189;
	{long i; for (i = 767; i < 770; i++) Y6677[i] = 1192;};
	Y6677[917] = 1241;
	{long i; for (i = 1320; i < 1322; i++) Y6677[i] = 1192;};
}

char *(*R6701[1217])();
void R6701_init () {
	R6701[0] = (char *(*)()) F493_7125;
	R6701[1] = (char *(*)()) F494_7126;
	R6701[644] = (char *(*)()) F1137_9645;
	R6701[1216] = (char *(*)()) F1709_18112;
}


#ifdef __cplusplus
}
#endif
