#include "epoly10.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R7674[524])();
void R7674_init () {
	R7674[0] = (char *(*)()) F883_8695;
	R7674[1] = (char *(*)()) F884_8695_7674_4;
	R7674[2] = (char *(*)()) F885_8695_7674_4;
	{long i; for (i = 3; i < 5; i++) R7674[i] = (char *(*)()) F883_8695;}
	R7674[5] = (char *(*)()) F885_8695_7674_4;
	R7674[6] = (char *(*)()) F884_8695_7674_4;
	{long i; for (i = 7; i < 9; i++) R7674[i] = (char *(*)()) F883_8695;}
	R7674[9] = (char *(*)()) F892_8824;
	R7674[10] = (char *(*)()) F893_8824_7674_4;
	R7674[11] = (char *(*)()) F894_8824_7674_4;
	R7674[12] = (char *(*)()) F895_8824_7674_4;
	R7674[13] = (char *(*)()) F896_8824_7674_4;
	R7674[14] = (char *(*)()) F897_8824_7674_4;
	R7674[15] = (char *(*)()) F898_8824_7674_4;
	R7674[16] = (char *(*)()) F899_8824_7674_4;
	R7674[17] = (char *(*)()) F900_8824_7674_4;
	R7674[18] = (char *(*)()) F901_8824_7674_4;
	R7674[19] = (char *(*)()) F902_8824_7674_4;
	R7674[20] = (char *(*)()) F903_8824_7674_4;
	{long i; for (i = 21; i < 23; i++) R7674[i] = (char *(*)()) F892_8824;}
	R7674[23] = (char *(*)()) F895_8824_7674_4;
	R7674[24] = (char *(*)()) F897_8824_7674_4;
	R7674[25] = (char *(*)()) F892_8824;
	R7674[30] = (char *(*)()) F909_8880;
	R7674[31] = (char *(*)()) F910_8880_7674_4;
	{long i; for (i = 32; i < 36; i++) R7674[i] = (char *(*)()) F909_8880;}
	R7674[38] = (char *(*)()) F909_8880;
	R7674[41] = (char *(*)()) F909_8880;
	{long i; for (i = 43; i < 45; i++) R7674[i] = (char *(*)()) F909_8880;}
	R7674[47] = (char *(*)()) F909_8880;
	{long i; for (i = 49; i < 55; i++) R7674[i] = (char *(*)()) F909_8880;}
	{long i; for (i = 470; i < 472; i++) R7674[i] = (char *(*)()) F1341_12757;}
	{long i; for (i = 489; i < 491; i++) R7674[i] = (char *(*)()) F1341_12757;}
	R7674[492] = (char *(*)()) F1341_12757;
	R7674[512] = (char *(*)()) F909_8880;
	R7674[523] = (char *(*)()) F1341_12757;
}
static void F884_8695_7674_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F884_8695(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F885_8695_7674_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F885_8695(Current, *(EIF_BOOLEAN *)arg1);
}
static void F893_8824_7674_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F893_8824(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F894_8824_7674_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F894_8824(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F895_8824_7674_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F895_8824(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F896_8824_7674_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F896_8824(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F897_8824_7674_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F897_8824(Current, *(EIF_BOOLEAN *)arg1);
}
static void F898_8824_7674_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F898_8824(Current, *(EIF_POINTER *)arg1);
}
static void F899_8824_7674_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F899_8824(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F900_8824_7674_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F900_8824(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F901_8824_7674_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F901_8824(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F902_8824_7674_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F902_8824(Current, *(EIF_REAL_32 *)arg1);
}
static void F903_8824_7674_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F903_8824(Current, *(EIF_REAL_64 *)arg1);
}
static void F910_8880_7674_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F910_8880(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R7675[626])();
void R7675_init () {
	R7675[0] = (char *(*)()) F781_8416;
	R7675[102] = (char *(*)()) F883_8698;
	R7675[103] = (char *(*)()) F884_8698;
	R7675[104] = (char *(*)()) F885_8698;
	R7675[105] = (char *(*)()) F883_8698;
	R7675[106] = (char *(*)()) F887_8726;
	R7675[107] = (char *(*)()) F888_8726;
	R7675[108] = (char *(*)()) F889_8726;
	R7675[109] = (char *(*)()) F883_8699;
	R7675[110] = (char *(*)()) F891_8770;
	R7675[111] = (char *(*)()) F892_8834;
	R7675[112] = (char *(*)()) F893_8834;
	R7675[113] = (char *(*)()) F894_8834;
	R7675[114] = (char *(*)()) F895_8834;
	R7675[115] = (char *(*)()) F896_8834;
	R7675[116] = (char *(*)()) F897_8834;
	R7675[117] = (char *(*)()) F898_8834;
	R7675[118] = (char *(*)()) F899_8834;
	R7675[119] = (char *(*)()) F900_8834;
	R7675[120] = (char *(*)()) F901_8834;
	R7675[121] = (char *(*)()) F902_8834;
	R7675[122] = (char *(*)()) F903_8834;
	R7675[123] = (char *(*)()) F892_8834;
	R7675[124] = (char *(*)()) F905_8852;
	R7675[125] = (char *(*)()) F906_8852;
	R7675[126] = (char *(*)()) F907_8852;
	R7675[127] = (char *(*)()) F892_8834;
	R7675[132] = (char *(*)()) F909_8881;
	R7675[133] = (char *(*)()) F910_8881;
	{long i; for (i = 134; i < 138; i++) R7675[i] = (char *(*)()) F909_8881;}
	R7675[140] = (char *(*)()) F909_8881;
	R7675[143] = (char *(*)()) F909_8881;
	{long i; for (i = 145; i < 147; i++) R7675[i] = (char *(*)()) F909_8881;}
	R7675[149] = (char *(*)()) F909_8881;
	{long i; for (i = 151; i < 157; i++) R7675[i] = (char *(*)()) F909_8881;}
	{long i; for (i = 572; i < 574; i++) R7675[i] = (char *(*)()) F1341_12748;}
	{long i; for (i = 591; i < 593; i++) R7675[i] = (char *(*)()) F1341_12748;}
	R7675[594] = (char *(*)()) F1341_12748;
	R7675[614] = (char *(*)()) F909_8881;
	R7675[625] = (char *(*)()) F1341_12748;
}

char *(*R7676[524])();
void R7676_init () {
	R7676[0] = (char *(*)()) F883_8671;
	R7676[1] = (char *(*)()) F884_8671;
	R7676[2] = (char *(*)()) F885_8671;
	{long i; for (i = 3; i < 5; i++) R7676[i] = (char *(*)()) F883_8671;}
	R7676[5] = (char *(*)()) F885_8671;
	R7676[6] = (char *(*)()) F884_8671;
	R7676[7] = (char *(*)()) F883_8671;
	R7676[8] = (char *(*)()) F891_8757;
	R7676[9] = (char *(*)()) F892_8791;
	R7676[10] = (char *(*)()) F893_8791;
	R7676[11] = (char *(*)()) F894_8791;
	R7676[12] = (char *(*)()) F895_8791;
	R7676[13] = (char *(*)()) F896_8791;
	R7676[14] = (char *(*)()) F897_8791;
	R7676[15] = (char *(*)()) F898_8791;
	R7676[16] = (char *(*)()) F899_8791;
	R7676[17] = (char *(*)()) F900_8791;
	R7676[18] = (char *(*)()) F901_8791;
	R7676[19] = (char *(*)()) F902_8791;
	R7676[20] = (char *(*)()) F903_8791;
	{long i; for (i = 21; i < 23; i++) R7676[i] = (char *(*)()) F892_8791;}
	R7676[23] = (char *(*)()) F895_8791;
	R7676[24] = (char *(*)()) F897_8791;
	R7676[25] = (char *(*)()) F892_8791;
	R7676[30] = (char *(*)()) F892_8791;
	R7676[31] = (char *(*)()) F895_8791;
	{long i; for (i = 32; i < 36; i++) R7676[i] = (char *(*)()) F892_8791;}
	R7676[38] = (char *(*)()) F892_8791;
	R7676[41] = (char *(*)()) F892_8791;
	{long i; for (i = 43; i < 45; i++) R7676[i] = (char *(*)()) F892_8791;}
	R7676[47] = (char *(*)()) F892_8791;
	{long i; for (i = 49; i < 55; i++) R7676[i] = (char *(*)()) F892_8791;}
	{long i; for (i = 470; i < 472; i++) R7676[i] = (char *(*)()) F1341_12722;}
	{long i; for (i = 489; i < 491; i++) R7676[i] = (char *(*)()) F1341_12722;}
	R7676[492] = (char *(*)()) F1341_12722;
	R7676[512] = (char *(*)()) F892_8791;
	R7676[523] = (char *(*)()) F1341_12722;
}

static EIF_TYPE_INDEX Y7676_pgtype0[] = {433,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7676_pgtype1[] = {434,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7676_pgtype2[] = {435,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7676_pgtype3[] = {433,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7676_pgtype4[] = {433,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7676_pgtype5[] = {435,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7676_pgtype6[] = {434,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7676_pgtype7[] = {433,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7676_pgtype8[] = {436,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7676_pgtype9[] = {430,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7676_pgtype10[] = {430,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7676_pgtype11[] = {430,1395,0xFFFF};
static EIF_TYPE_INDEX Y7676_pgtype12[] = {430,1401,0xFFFF};
static EIF_TYPE_INDEX Y7676_pgtype13[] = {430,1401,0xFFFF};
static EIF_TYPE_INDEX Y7676_pgtype14[] = {430,1346,0xFFFF};
static EIF_TYPE_INDEX Y7676_pgtype15[] = {430,1346,0xFFFF};
static EIF_TYPE_INDEX Y7676_pgtype16[] = {430,1346,0xFFFF};
static EIF_TYPE_INDEX Y7676_pgtype17[] = {430,1346,0xFFFF};
static EIF_TYPE_INDEX Y7676_pgtype18[] = {430,1346,0xFFFF};
static EIF_TYPE_INDEX Y7676_pgtype19[] = {430,1346,0xFFFF};
static EIF_TYPE_INDEX Y7676_pgtype20[] = {430,1395,0xFFFF};
static EIF_TYPE_INDEX Y7676_pgtype21[] = {430,1397,0xFFFF};
static EIF_TYPE_INDEX Y7676_pgtype22[] = {430,1394,0xFFFF};
static EIF_TYPE_INDEX Y7676_pgtype23[] = {430,1393,0xFFFF};
static EIF_TYPE_INDEX Y7676_pgtype24[] = {430,1392,0xFFFF};
static EIF_TYPE_INDEX Y7676_pgtype25[] = {430,1392,0xFFFF};
static EIF_TYPE_INDEX Y7676_pgtype26[] = {430,1392,0xFFFF};
static EIF_TYPE_INDEX Y7676_pgtype27[] = {430,1395,0xFFFF};
static EIF_TYPE_INDEX Y7676_pgtype28[] = {430,1395,0xFFFF};
static EIF_TYPE_INDEX Y7676_pgtype29[] = {430,1401,0xFFFF};
EIF_TYPE_INDEX *Y7676_gen_type [715];
EIF_TYPE_INDEX Y7676 [715];
void Y7676_init (void)
{
	egc_routines_types [7676] = Y7676;
	egc_routines_gen_types [7676] = Y7676_gen_type;
	egc_routines_offset [7676] = 691;
	Y7676_gen_type [191] = Y7676_pgtype0;
	Y7676_gen_type [192] = Y7676_pgtype1;
	Y7676_gen_type [193] = Y7676_pgtype2;
	Y7676_gen_type [194] = Y7676_pgtype3;
	Y7676_gen_type [195] = Y7676_pgtype4;
	Y7676_gen_type [196] = Y7676_pgtype5;
	Y7676_gen_type [197] = Y7676_pgtype6;
	Y7676_gen_type [198] = Y7676_pgtype7;
	Y7676_gen_type [199] = Y7676_pgtype8;
	Y7676_gen_type [649] = Y7676_pgtype9;
	Y7676_gen_type [650] = Y7676_pgtype10;
	Y7676_gen_type [651] = Y7676_pgtype11;
	Y7676_gen_type [652] = Y7676_pgtype12;
	Y7676_gen_type [653] = Y7676_pgtype13;
	Y7676_gen_type [657] = Y7676_pgtype14;
	Y7676_gen_type [658] = Y7676_pgtype15;
	Y7676_gen_type [659] = Y7676_pgtype16;
	Y7676_gen_type [660] = Y7676_pgtype17;
	Y7676_gen_type [661] = Y7676_pgtype18;
	Y7676_gen_type [662] = Y7676_pgtype19;
	Y7676_gen_type [678] = Y7676_pgtype20;
	Y7676_gen_type [680] = Y7676_pgtype21;
	Y7676_gen_type [681] = Y7676_pgtype22;
	Y7676_gen_type [683] = Y7676_pgtype23;
	Y7676_gen_type [690] = Y7676_pgtype24;
	Y7676_gen_type [691] = Y7676_pgtype25;
	Y7676_gen_type [694] = Y7676_pgtype26;
	Y7676_gen_type [704] = Y7676_pgtype27;
	Y7676_gen_type [705] = Y7676_pgtype28;
	Y7676_gen_type [714] = Y7676_pgtype29;
	{long i; for (i = 0; i < 12; i++) Y7676[i] = 429;};
	{long i; for (i = 143; i < 191; i++) Y7676[i] = 429;};
	Y7676[191] = 433;
	Y7676[192] = 434;
	Y7676[193] = 435;
	{long i; for (i = 194; i < 196; i++) Y7676[i] = 433;};
	Y7676[196] = 435;
	Y7676[197] = 434;
	Y7676[198] = 433;
	Y7676[199] = 436;
	{long i; for (i = 200; i < 246; i++) Y7676[i] = 432;};
	{long i; for (i = 649; i < 654; i++) Y7676[i] = 430;};
	{long i; for (i = 657; i < 663; i++) Y7676[i] = 430;};
	Y7676[678] = 430;
	{long i; for (i = 680; i < 682; i++) Y7676[i] = 430;};
	Y7676[683] = 430;
	{long i; for (i = 690; i < 692; i++) Y7676[i] = 430;};
	Y7676[694] = 430;
	Y7676[703] = 432;
	{long i; for (i = 704; i < 706; i++) Y7676[i] = 430;};
	Y7676[714] = 430;
}

char *(*R7678[524])();
void R7678_init () {
	R7678[0] = (char *(*)()) F883_8690;
	R7678[1] = (char *(*)()) F884_8690;
	R7678[2] = (char *(*)()) F885_8690;
	{long i; for (i = 3; i < 5; i++) R7678[i] = (char *(*)()) F883_8690;}
	R7678[5] = (char *(*)()) F885_8690;
	R7678[6] = (char *(*)()) F884_8690;
	{long i; for (i = 7; i < 9; i++) R7678[i] = (char *(*)()) F883_8690;}
	R7678[9] = (char *(*)()) F892_8816;
	R7678[10] = (char *(*)()) F893_8816;
	R7678[11] = (char *(*)()) F894_8816;
	R7678[12] = (char *(*)()) F895_8816;
	R7678[13] = (char *(*)()) F896_8816;
	R7678[14] = (char *(*)()) F897_8816;
	R7678[15] = (char *(*)()) F898_8816;
	R7678[16] = (char *(*)()) F899_8816;
	R7678[17] = (char *(*)()) F900_8816;
	R7678[18] = (char *(*)()) F901_8816;
	R7678[19] = (char *(*)()) F902_8816;
	R7678[20] = (char *(*)()) F903_8816;
	{long i; for (i = 21; i < 23; i++) R7678[i] = (char *(*)()) F892_8816;}
	R7678[23] = (char *(*)()) F895_8816;
	R7678[24] = (char *(*)()) F897_8816;
	R7678[25] = (char *(*)()) F892_8816;
	R7678[30] = (char *(*)()) F892_8816;
	R7678[31] = (char *(*)()) F895_8816;
	{long i; for (i = 32; i < 36; i++) R7678[i] = (char *(*)()) F892_8816;}
	R7678[38] = (char *(*)()) F892_8816;
	R7678[41] = (char *(*)()) F892_8816;
	{long i; for (i = 43; i < 45; i++) R7678[i] = (char *(*)()) F892_8816;}
	R7678[47] = (char *(*)()) F892_8816;
	{long i; for (i = 49; i < 55; i++) R7678[i] = (char *(*)()) F892_8816;}
	{long i; for (i = 470; i < 472; i++) R7678[i] = (char *(*)()) F1341_12734;}
	{long i; for (i = 489; i < 491; i++) R7678[i] = (char *(*)()) F1341_12734;}
	R7678[492] = (char *(*)()) F1341_12734;
	R7678[512] = (char *(*)()) F892_8816;
	R7678[523] = (char *(*)()) F1341_12734;
}

char *(*R7704[8])();
void R7704_init () {
	R7704[0] = (char *(*)()) F970_9115;
	R7704[7] = (char *(*)()) F977_9179;
}

char *(*R7706[1018])();
void R7706_init () {
	R7706[0] = (char *(*)()) F781_8403;
	R7706[25] = (char *(*)()) F806_8454;
	R7706[26] = (char *(*)()) F807_8454;
	R7706[27] = (char *(*)()) F808_8454;
	R7706[28] = (char *(*)()) F809_8454;
	R7706[29] = (char *(*)()) F810_8454;
	R7706[30] = (char *(*)()) F811_8454;
	R7706[31] = (char *(*)()) F812_8454;
	R7706[32] = (char *(*)()) F813_8454;
	R7706[33] = (char *(*)()) F814_8454;
	R7706[34] = (char *(*)()) F806_8454;
	R7706[35] = (char *(*)()) F807_8454;
	R7706[36] = (char *(*)()) F809_8454;
	R7706[37] = (char *(*)()) F813_8454;
	R7706[38] = (char *(*)()) F814_8454;
	R7706[39] = (char *(*)()) F806_8454;
	{long i; for (i = 52; i < 54; i++) R7706[i] = (char *(*)()) F833_8579;}
	R7706[102] = (char *(*)()) F883_8674;
	R7706[103] = (char *(*)()) F884_8674;
	R7706[104] = (char *(*)()) F885_8674;
	{long i; for (i = 105; i < 107; i++) R7706[i] = (char *(*)()) F883_8674;}
	R7706[107] = (char *(*)()) F885_8674;
	R7706[108] = (char *(*)()) F884_8674;
	{long i; for (i = 109; i < 111; i++) R7706[i] = (char *(*)()) F883_8674;}
	R7706[111] = (char *(*)()) F892_8801;
	R7706[112] = (char *(*)()) F893_8801;
	R7706[113] = (char *(*)()) F894_8801;
	R7706[114] = (char *(*)()) F895_8801;
	R7706[115] = (char *(*)()) F896_8801;
	R7706[116] = (char *(*)()) F897_8801;
	R7706[117] = (char *(*)()) F898_8801;
	R7706[118] = (char *(*)()) F899_8801;
	R7706[119] = (char *(*)()) F900_8801;
	R7706[120] = (char *(*)()) F901_8801;
	R7706[121] = (char *(*)()) F902_8801;
	R7706[122] = (char *(*)()) F903_8801;
	{long i; for (i = 123; i < 125; i++) R7706[i] = (char *(*)()) F892_8801;}
	R7706[125] = (char *(*)()) F895_8801;
	R7706[126] = (char *(*)()) F897_8801;
	R7706[127] = (char *(*)()) F892_8801;
	R7706[132] = (char *(*)()) F892_8801;
	R7706[133] = (char *(*)()) F895_8801;
	{long i; for (i = 134; i < 138; i++) R7706[i] = (char *(*)()) F892_8801;}
	R7706[140] = (char *(*)()) F892_8801;
	R7706[143] = (char *(*)()) F892_8801;
	{long i; for (i = 145; i < 147; i++) R7706[i] = (char *(*)()) F892_8801;}
	R7706[149] = (char *(*)()) F892_8801;
	{long i; for (i = 151; i < 157; i++) R7706[i] = (char *(*)()) F892_8801;}
	R7706[157] = (char *(*)()) F938_9021;
	R7706[158] = (char *(*)()) F939_9021;
	R7706[159] = (char *(*)()) F940_9021;
	R7706[160] = (char *(*)()) F941_9021;
	R7706[161] = (char *(*)()) F942_9021;
	R7706[162] = (char *(*)()) F943_9021;
	R7706[163] = (char *(*)()) F944_9021;
	R7706[164] = (char *(*)()) F945_9021;
	R7706[165] = (char *(*)()) F946_9021;
	R7706[166] = (char *(*)()) F947_9021;
	R7706[167] = (char *(*)()) F948_9021;
	R7706[168] = (char *(*)()) F949_9021;
	{long i; for (i = 366; i < 368; i++) R7706[i] = (char *(*)()) F1146_10072;}
	R7706[461] = (char *(*)()) F1240_11210;
	R7706[464] = (char *(*)()) F1243_11378;
	{long i; for (i = 572; i < 574; i++) R7706[i] = (char *(*)()) F1341_12727;}
	{long i; for (i = 591; i < 593; i++) R7706[i] = (char *(*)()) F1341_12727;}
	R7706[594] = (char *(*)()) F1341_12727;
	R7706[614] = (char *(*)()) F892_8801;
	R7706[625] = (char *(*)()) F1341_12727;
	R7706[935] = (char *(*)()) F1716_18245;
	R7706[1017] = (char *(*)()) F1798_20788;
}

char *(*R7707[1018])();
void R7707_init () {
	R7707[0] = (char *(*)()) F781_8404;
	{long i; for (i = 52; i < 54; i++) R7707[i] = (char *(*)()) F833_8578;}
	R7707[111] = (char *(*)()) F892_8802;
	R7707[112] = (char *(*)()) F893_8802;
	R7707[113] = (char *(*)()) F894_8802;
	R7707[114] = (char *(*)()) F895_8802;
	R7707[115] = (char *(*)()) F896_8802;
	R7707[116] = (char *(*)()) F897_8802;
	R7707[117] = (char *(*)()) F898_8802;
	R7707[118] = (char *(*)()) F899_8802;
	R7707[119] = (char *(*)()) F900_8802;
	R7707[120] = (char *(*)()) F901_8802;
	R7707[121] = (char *(*)()) F902_8802;
	R7707[122] = (char *(*)()) F903_8802;
	{long i; for (i = 123; i < 125; i++) R7707[i] = (char *(*)()) F892_8802;}
	R7707[125] = (char *(*)()) F895_8802;
	R7707[126] = (char *(*)()) F897_8802;
	R7707[127] = (char *(*)()) F892_8802;
	R7707[132] = (char *(*)()) F892_8802;
	R7707[133] = (char *(*)()) F895_8802;
	{long i; for (i = 134; i < 138; i++) R7707[i] = (char *(*)()) F892_8802;}
	R7707[140] = (char *(*)()) F892_8802;
	R7707[143] = (char *(*)()) F892_8802;
	{long i; for (i = 145; i < 147; i++) R7707[i] = (char *(*)()) F892_8802;}
	R7707[149] = (char *(*)()) F892_8802;
	{long i; for (i = 151; i < 157; i++) R7707[i] = (char *(*)()) F892_8802;}
	R7707[157] = (char *(*)()) F938_9022;
	R7707[158] = (char *(*)()) F939_9022;
	R7707[159] = (char *(*)()) F940_9022;
	R7707[160] = (char *(*)()) F941_9022;
	R7707[161] = (char *(*)()) F942_9022;
	R7707[162] = (char *(*)()) F943_9022;
	R7707[163] = (char *(*)()) F944_9022;
	R7707[164] = (char *(*)()) F945_9022;
	R7707[165] = (char *(*)()) F946_9022;
	R7707[166] = (char *(*)()) F947_9022;
	R7707[167] = (char *(*)()) F948_9022;
	R7707[168] = (char *(*)()) F949_9022;
	R7707[461] = (char *(*)()) F1240_11209;
	R7707[464] = (char *(*)()) F1243_11377;
	R7707[614] = (char *(*)()) F892_8802;
	R7707[1017] = (char *(*)()) F1798_20790;
}

char *(*R7711[1018])();
void R7711_init () {
	R7711[0] = (char *(*)()) F748_8343;
	{long i; for (i = 52; i < 54; i++) R7711[i] = (char *(*)()) F751_8343;}
	R7711[111] = (char *(*)()) F748_8343;
	R7711[112] = (char *(*)()) F749_8343;
	R7711[113] = (char *(*)()) F750_8343;
	R7711[114] = (char *(*)()) F751_8343;
	R7711[115] = (char *(*)()) F752_8343;
	R7711[116] = (char *(*)()) F754_8343;
	R7711[117] = (char *(*)()) F755_8343;
	R7711[118] = (char *(*)()) F753_8343;
	R7711[119] = (char *(*)()) F756_8343;
	R7711[120] = (char *(*)()) F757_8343;
	R7711[121] = (char *(*)()) F758_8343;
	R7711[122] = (char *(*)()) F759_8343;
	{long i; for (i = 123; i < 125; i++) R7711[i] = (char *(*)()) F748_8343;}
	R7711[125] = (char *(*)()) F751_8343;
	R7711[126] = (char *(*)()) F754_8343;
	R7711[127] = (char *(*)()) F748_8343;
	R7711[132] = (char *(*)()) F748_8343;
	R7711[133] = (char *(*)()) F751_8343;
	{long i; for (i = 134; i < 138; i++) R7711[i] = (char *(*)()) F748_8343;}
	R7711[140] = (char *(*)()) F748_8343;
	R7711[143] = (char *(*)()) F748_8343;
	{long i; for (i = 145; i < 147; i++) R7711[i] = (char *(*)()) F748_8343;}
	R7711[149] = (char *(*)()) F748_8343;
	{long i; for (i = 151; i < 158; i++) R7711[i] = (char *(*)()) F748_8343;}
	R7711[158] = (char *(*)()) F749_8343;
	R7711[159] = (char *(*)()) F750_8343;
	R7711[160] = (char *(*)()) F751_8343;
	R7711[161] = (char *(*)()) F752_8343;
	R7711[162] = (char *(*)()) F754_8343;
	R7711[163] = (char *(*)()) F755_8343;
	R7711[164] = (char *(*)()) F753_8343;
	R7711[165] = (char *(*)()) F756_8343;
	R7711[166] = (char *(*)()) F757_8343;
	R7711[167] = (char *(*)()) F758_8343;
	R7711[168] = (char *(*)()) F759_8343;
	R7711[461] = (char *(*)()) F756_8343;
	R7711[464] = (char *(*)()) F753_8343;
	R7711[614] = (char *(*)()) F748_8343;
	R7711[1017] = (char *(*)()) F753_8343;
}

char *(*R7713[1018])();
void R7713_init () {
	R7713[0] = (char *(*)()) F781_8426;
	{long i; for (i = 52; i < 54; i++) R7713[i] = (char *(*)()) F833_8589;}
	R7713[111] = (char *(*)()) F892_8828;
	R7713[112] = (char *(*)()) F893_8828;
	R7713[113] = (char *(*)()) F894_8828;
	R7713[114] = (char *(*)()) F895_8828;
	R7713[115] = (char *(*)()) F896_8828;
	R7713[116] = (char *(*)()) F897_8828;
	R7713[117] = (char *(*)()) F898_8828;
	R7713[118] = (char *(*)()) F899_8828;
	R7713[119] = (char *(*)()) F900_8828;
	R7713[120] = (char *(*)()) F901_8828;
	R7713[121] = (char *(*)()) F902_8828;
	R7713[122] = (char *(*)()) F903_8828;
	{long i; for (i = 123; i < 125; i++) R7713[i] = (char *(*)()) F892_8828;}
	R7713[125] = (char *(*)()) F895_8828;
	R7713[126] = (char *(*)()) F897_8828;
	R7713[127] = (char *(*)()) F892_8828;
	R7713[132] = (char *(*)()) F892_8828;
	R7713[133] = (char *(*)()) F895_8828;
	{long i; for (i = 134; i < 138; i++) R7713[i] = (char *(*)()) F892_8828;}
	R7713[140] = (char *(*)()) F892_8828;
	R7713[143] = (char *(*)()) F892_8828;
	{long i; for (i = 145; i < 147; i++) R7713[i] = (char *(*)()) F892_8828;}
	R7713[149] = (char *(*)()) F892_8828;
	{long i; for (i = 151; i < 157; i++) R7713[i] = (char *(*)()) F892_8828;}
	R7713[157] = (char *(*)()) F938_9052;
	R7713[158] = (char *(*)()) F939_9052;
	R7713[159] = (char *(*)()) F940_9052;
	R7713[160] = (char *(*)()) F941_9052;
	R7713[161] = (char *(*)()) F942_9052;
	R7713[162] = (char *(*)()) F943_9052;
	R7713[163] = (char *(*)()) F944_9052;
	R7713[164] = (char *(*)()) F945_9052;
	R7713[165] = (char *(*)()) F946_9052;
	R7713[166] = (char *(*)()) F947_9052;
	R7713[167] = (char *(*)()) F948_9052;
	R7713[168] = (char *(*)()) F949_9052;
	R7713[461] = (char *(*)()) F1242_11337;
	R7713[464] = (char *(*)()) F1245_11502;
	R7713[614] = (char *(*)()) F892_8828;
	R7713[1017] = (char *(*)()) F1245_11502;
}

char *(*R7715[834])();
void R7715_init () {
	R7715[0] = (char *(*)()) F760_8350;
	R7715[1] = (char *(*)()) F763_8350_7715_4;
	R7715[2] = (char *(*)()) F765_8350_7715_4;
	R7715[3] = (char *(*)()) F760_8350;
	R7715[4] = (char *(*)()) F887_8723;
	R7715[5] = (char *(*)()) F888_8723_7715_4;
	R7715[6] = (char *(*)()) F889_8723_7715_4;
	R7715[7] = (char *(*)()) F890_8740;
	R7715[8] = (char *(*)()) F760_8350;
	R7715[9] = (char *(*)()) F892_8820;
	R7715[10] = (char *(*)()) F893_8820_7715_4;
	R7715[11] = (char *(*)()) F894_8820_7715_4;
	R7715[12] = (char *(*)()) F895_8820_7715_4;
	R7715[13] = (char *(*)()) F896_8820_7715_4;
	R7715[14] = (char *(*)()) F897_8820_7715_4;
	R7715[15] = (char *(*)()) F898_8820_7715_4;
	R7715[16] = (char *(*)()) F899_8820_7715_4;
	R7715[17] = (char *(*)()) F900_8820_7715_4;
	R7715[18] = (char *(*)()) F901_8820_7715_4;
	R7715[19] = (char *(*)()) F902_8820_7715_4;
	R7715[20] = (char *(*)()) F903_8820_7715_4;
	{long i; for (i = 21; i < 23; i++) R7715[i] = (char *(*)()) F892_8820;}
	R7715[23] = (char *(*)()) F895_8820_7715_4;
	R7715[24] = (char *(*)()) F897_8820_7715_4;
	R7715[25] = (char *(*)()) F892_8820;
	R7715[30] = (char *(*)()) F892_8820;
	R7715[31] = (char *(*)()) F895_8820_7715_4;
	{long i; for (i = 32; i < 36; i++) R7715[i] = (char *(*)()) F892_8820;}
	R7715[38] = (char *(*)()) F892_8820;
	R7715[41] = (char *(*)()) F892_8820;
	{long i; for (i = 43; i < 45; i++) R7715[i] = (char *(*)()) F892_8820;}
	R7715[47] = (char *(*)()) F892_8820;
	{long i; for (i = 49; i < 55; i++) R7715[i] = (char *(*)()) F892_8820;}
	{long i; for (i = 264; i < 266; i++) R7715[i] = (char *(*)()) F767_8350_7715_4;}
	{long i; for (i = 470; i < 472; i++) R7715[i] = (char *(*)()) F760_8350;}
	{long i; for (i = 489; i < 491; i++) R7715[i] = (char *(*)()) F760_8350;}
	R7715[492] = (char *(*)()) F760_8350;
	R7715[512] = (char *(*)()) F892_8820;
	R7715[523] = (char *(*)()) F760_8350;
	R7715[833] = (char *(*)()) F767_8350_7715_4;
}
static void F763_8350_7715_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F763_8350(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F765_8350_7715_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F765_8350(Current, *(EIF_BOOLEAN *)arg1);
}
static void F888_8723_7715_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F888_8723(Current, *(EIF_BOOLEAN *)arg1);
}
static void F889_8723_7715_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F889_8723(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F893_8820_7715_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F893_8820(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F894_8820_7715_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F894_8820(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F895_8820_7715_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F895_8820(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F896_8820_7715_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F896_8820(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F897_8820_7715_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F897_8820(Current, *(EIF_BOOLEAN *)arg1);
}
static void F898_8820_7715_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F898_8820(Current, *(EIF_POINTER *)arg1);
}
static void F899_8820_7715_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F899_8820(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F900_8820_7715_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F900_8820(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F901_8820_7715_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F901_8820(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F902_8820_7715_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F902_8820(Current, *(EIF_REAL_32 *)arg1);
}
static void F903_8820_7715_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F903_8820(Current, *(EIF_REAL_64 *)arg1);
}
static void F767_8350_7715_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F767_8350(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R7716[513])();
void R7716_init () {
	R7716[0] = (char *(*)()) F835_8634;
	R7716[1] = (char *(*)()) F838_8634;
	R7716[2] = (char *(*)()) F840_8634;
	R7716[3] = (char *(*)()) F835_8634;
	R7716[4] = (char *(*)()) F772_8357;
	R7716[5] = (char *(*)()) F774_8357;
	R7716[6] = (char *(*)()) F773_8357;
	R7716[7] = (char *(*)()) F772_8357;
	R7716[8] = (char *(*)()) F835_8634;
	R7716[9] = (char *(*)()) F892_8827;
	R7716[10] = (char *(*)()) F893_8827;
	R7716[11] = (char *(*)()) F894_8827;
	R7716[12] = (char *(*)()) F895_8827;
	R7716[13] = (char *(*)()) F896_8827;
	R7716[14] = (char *(*)()) F897_8827;
	R7716[15] = (char *(*)()) F898_8827;
	R7716[16] = (char *(*)()) F899_8827;
	R7716[17] = (char *(*)()) F900_8827;
	R7716[18] = (char *(*)()) F901_8827;
	R7716[19] = (char *(*)()) F902_8827;
	R7716[20] = (char *(*)()) F903_8827;
	R7716[21] = (char *(*)()) F892_8827;
	R7716[22] = (char *(*)()) F772_8357;
	R7716[23] = (char *(*)()) F773_8357;
	R7716[24] = (char *(*)()) F774_8357;
	R7716[25] = (char *(*)()) F892_8827;
	R7716[30] = (char *(*)()) F909_8876;
	R7716[31] = (char *(*)()) F910_8876;
	{long i; for (i = 32; i < 36; i++) R7716[i] = (char *(*)()) F909_8876;}
	R7716[38] = (char *(*)()) F909_8876;
	R7716[41] = (char *(*)()) F909_8876;
	{long i; for (i = 43; i < 45; i++) R7716[i] = (char *(*)()) F909_8876;}
	R7716[47] = (char *(*)()) F909_8876;
	{long i; for (i = 49; i < 55; i++) R7716[i] = (char *(*)()) F909_8876;}
	R7716[512] = (char *(*)()) F909_8876;
}

char *(*R7739[993])();
void R7739_init () {
	R7739[0] = (char *(*)()) F806_8452;
	R7739[1] = (char *(*)()) F807_8452_7739_8;
	R7739[2] = (char *(*)()) F808_8452;
	R7739[3] = (char *(*)()) F809_8452_7739_8;
	R7739[4] = (char *(*)()) F810_8452_7739_8;
	R7739[5] = (char *(*)()) F811_8452_7739_8;
	R7739[6] = (char *(*)()) F812_8452_7739_8;
	R7739[7] = (char *(*)()) F813_8452_7739_8;
	R7739[8] = (char *(*)()) F814_8452_7739_8;
	R7739[9] = (char *(*)()) F806_8452;
	R7739[10] = (char *(*)()) F807_8452_7739_8;
	R7739[11] = (char *(*)()) F809_8452_7739_8;
	R7739[12] = (char *(*)()) F813_8452_7739_8;
	R7739[13] = (char *(*)()) F814_8452_7739_8;
	R7739[14] = (char *(*)()) F806_8452;
	{long i; for (i = 27; i < 29; i++) R7739[i] = (char *(*)()) F833_8573_7739_8;}
	R7739[77] = (char *(*)()) F835_8619;
	R7739[78] = (char *(*)()) F838_8619_7739_8;
	R7739[79] = (char *(*)()) F840_8619_7739_8;
	{long i; for (i = 80; i < 82; i++) R7739[i] = (char *(*)()) F835_8619;}
	R7739[82] = (char *(*)()) F840_8619_7739_8;
	R7739[83] = (char *(*)()) F838_8619_7739_8;
	{long i; for (i = 84; i < 86; i++) R7739[i] = (char *(*)()) F835_8619;}
	R7739[86] = (char *(*)()) F892_8786;
	R7739[87] = (char *(*)()) F893_8786_7739_8;
	R7739[88] = (char *(*)()) F894_8786_7739_8;
	R7739[89] = (char *(*)()) F895_8786_7739_8;
	R7739[90] = (char *(*)()) F896_8786_7739_8;
	R7739[91] = (char *(*)()) F897_8786_7739_8;
	R7739[92] = (char *(*)()) F898_8786_7739_8;
	R7739[93] = (char *(*)()) F899_8786_7739_8;
	R7739[94] = (char *(*)()) F900_8786_7739_8;
	R7739[95] = (char *(*)()) F901_8786_7739_8;
	R7739[96] = (char *(*)()) F902_8786_7739_8;
	R7739[97] = (char *(*)()) F903_8786_7739_8;
	{long i; for (i = 98; i < 100; i++) R7739[i] = (char *(*)()) F892_8786;}
	R7739[100] = (char *(*)()) F895_8786_7739_8;
	R7739[101] = (char *(*)()) F897_8786_7739_8;
	R7739[102] = (char *(*)()) F892_8786;
	R7739[107] = (char *(*)()) F892_8786;
	R7739[108] = (char *(*)()) F895_8786_7739_8;
	{long i; for (i = 109; i < 113; i++) R7739[i] = (char *(*)()) F892_8786;}
	R7739[115] = (char *(*)()) F892_8786;
	R7739[118] = (char *(*)()) F892_8786;
	{long i; for (i = 120; i < 122; i++) R7739[i] = (char *(*)()) F892_8786;}
	R7739[124] = (char *(*)()) F892_8786;
	{long i; for (i = 126; i < 132; i++) R7739[i] = (char *(*)()) F892_8786;}
	R7739[132] = (char *(*)()) F938_9014;
	R7739[133] = (char *(*)()) F939_9014_7739_8;
	R7739[134] = (char *(*)()) F940_9014_7739_8;
	R7739[135] = (char *(*)()) F941_9014_7739_8;
	R7739[136] = (char *(*)()) F942_9014_7739_8;
	R7739[137] = (char *(*)()) F943_9014_7739_8;
	R7739[138] = (char *(*)()) F944_9014_7739_8;
	R7739[139] = (char *(*)()) F945_9014_7739_8;
	R7739[140] = (char *(*)()) F946_9014_7739_8;
	R7739[141] = (char *(*)()) F947_9014_7739_8;
	R7739[142] = (char *(*)()) F948_9014_7739_8;
	R7739[143] = (char *(*)()) F949_9014_7739_8;
	R7739[381] = (char *(*)()) F1187_10731;
	R7739[435] = (char *(*)()) F1241_11248_7739_8;
	R7739[436] = (char *(*)()) F1242_11271_7739_8;
	R7739[438] = (char *(*)()) F1244_11413_7739_8;
	R7739[439] = (char *(*)()) F1245_11435_7739_8;
	{long i; for (i = 547; i < 549; i++) R7739[i] = (char *(*)()) F1341_12723;}
	{long i; for (i = 566; i < 568; i++) R7739[i] = (char *(*)()) F1341_12723;}
	R7739[569] = (char *(*)()) F1341_12723;
	R7739[589] = (char *(*)()) F892_8786;
	R7739[600] = (char *(*)()) F1341_12723;
	R7739[602] = (char *(*)()) F1408_13449;
	R7739[603] = (char *(*)()) F1409_13449_7739_8;
	R7739[604] = (char *(*)()) F1410_13449_7739_8;
	R7739[605] = (char *(*)()) F1411_13449_7739_8;
	R7739[606] = (char *(*)()) F1412_13449_7739_8;
	R7739[607] = (char *(*)()) F1413_13449_7739_8;
	R7739[608] = (char *(*)()) F1414_13449_7739_8;
	R7739[609] = (char *(*)()) F1415_13449_7739_8;
	R7739[610] = (char *(*)()) F1416_13449_7739_8;
	R7739[611] = (char *(*)()) F1417_13449_7739_8;
	R7739[612] = (char *(*)()) F1418_13449_7739_8;
	R7739[613] = (char *(*)()) F1419_13449_7739_8;
	R7739[992] = (char *(*)()) F1798_20772_7739_8;
}
static EIF_REFERENCE F807_8452_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F807_8452(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1498, 0x00).id, 1498, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F809_8452_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F809_8452(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F810_8452_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F810_8452(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F811_8452_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F811_8452(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F812_8452_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F812_8452(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F813_8452_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F813_8452(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1504, 0x00).id, 1504, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F814_8452_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F814_8452(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1195, 0x00).id, 1195, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F833_8573_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F833_8573(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F838_8619_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F838_8619(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F840_8619_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F840_8619(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1195, 0x00).id, 1195, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F893_8786_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F893_8786(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1498, 0x00).id, 1498, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F894_8786_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F894_8786(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1495, 0x00).id, 1495, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F895_8786_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F895_8786(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F896_8786_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F896_8786(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1504, 0x00).id, 1504, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F897_8786_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F897_8786(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1195, 0x00).id, 1195, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F898_8786_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F898_8786(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F899_8786_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F899_8786(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1192, 0x00).id, 1192, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F900_8786_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F900_8786(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F901_8786_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F901_8786(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1501, 0x00).id, 1501, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F902_8786_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F902_8786(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1507, 0x00).id, 1507, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F903_8786_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F903_8786(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1510, 0x00).id, 1510, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F939_9014_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F939_9014(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1498, 0x00).id, 1498, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F940_9014_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F940_9014(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1495, 0x00).id, 1495, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F941_9014_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F941_9014(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F942_9014_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F942_9014(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1504, 0x00).id, 1504, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F943_9014_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F943_9014(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1195, 0x00).id, 1195, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F944_9014_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F944_9014(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F945_9014_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F945_9014(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1192, 0x00).id, 1192, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F946_9014_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F946_9014(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F947_9014_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F947_9014(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1501, 0x00).id, 1501, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F948_9014_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F948_9014(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1507, 0x00).id, 1507, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F949_9014_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F949_9014(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1510, 0x00).id, 1510, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1241_11248_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1241_11248(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1242_11271_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1242_11271(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1244_11413_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1244_11413(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1192, 0x00).id, 1192, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1245_11435_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1245_11435(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1192, 0x00).id, 1192, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1409_13449_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1409_13449(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1498, 0x00).id, 1498, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1410_13449_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1410_13449(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1495, 0x00).id, 1495, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1411_13449_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1411_13449(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1412_13449_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F1412_13449(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1504, 0x00).id, 1504, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1413_13449_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1413_13449(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1195, 0x00).id, 1195, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1414_13449_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1414_13449(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1415_13449_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1415_13449(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1192, 0x00).id, 1192, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1416_13449_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1416_13449(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1417_13449_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F1417_13449(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1501, 0x00).id, 1501, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1418_13449_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1418_13449(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1507, 0x00).id, 1507, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1419_13449_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1419_13449(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1510, 0x00).id, 1510, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1798_20772_7739_8 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1798_20772(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1192, 0x00).id, 1192, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R7740[993])();
void R7740_init () {
	R7740[0] = (char *(*)()) F806_8457;
	R7740[1] = (char *(*)()) F807_8457;
	R7740[2] = (char *(*)()) F808_8457;
	R7740[3] = (char *(*)()) F809_8457;
	R7740[4] = (char *(*)()) F810_8457;
	R7740[5] = (char *(*)()) F811_8457;
	R7740[6] = (char *(*)()) F812_8457;
	R7740[7] = (char *(*)()) F813_8457;
	R7740[8] = (char *(*)()) F814_8457;
	R7740[9] = (char *(*)()) F806_8457;
	R7740[10] = (char *(*)()) F807_8457;
	R7740[11] = (char *(*)()) F809_8457;
	R7740[12] = (char *(*)()) F813_8457;
	R7740[13] = (char *(*)()) F814_8457;
	R7740[14] = (char *(*)()) F806_8457;
	{long i; for (i = 27; i < 29; i++) R7740[i] = (char *(*)()) F833_8570;}
	R7740[77] = (char *(*)()) F835_8622;
	R7740[78] = (char *(*)()) F838_8622;
	R7740[79] = (char *(*)()) F840_8622;
	{long i; for (i = 80; i < 82; i++) R7740[i] = (char *(*)()) F835_8622;}
	R7740[82] = (char *(*)()) F840_8622;
	R7740[83] = (char *(*)()) F838_8622;
	{long i; for (i = 84; i < 87; i++) R7740[i] = (char *(*)()) F835_8622;}
	R7740[87] = (char *(*)()) F836_8622;
	R7740[88] = (char *(*)()) F837_8622;
	R7740[89] = (char *(*)()) F838_8622;
	R7740[90] = (char *(*)()) F839_8622;
	R7740[91] = (char *(*)()) F840_8622;
	R7740[92] = (char *(*)()) F841_8622;
	R7740[93] = (char *(*)()) F842_8622;
	R7740[94] = (char *(*)()) F843_8622;
	R7740[95] = (char *(*)()) F844_8622;
	R7740[96] = (char *(*)()) F845_8622;
	R7740[97] = (char *(*)()) F846_8622;
	{long i; for (i = 98; i < 100; i++) R7740[i] = (char *(*)()) F835_8622;}
	R7740[100] = (char *(*)()) F838_8622;
	R7740[101] = (char *(*)()) F840_8622;
	R7740[102] = (char *(*)()) F835_8622;
	R7740[107] = (char *(*)()) F835_8622;
	R7740[108] = (char *(*)()) F838_8622;
	{long i; for (i = 109; i < 113; i++) R7740[i] = (char *(*)()) F835_8622;}
	R7740[115] = (char *(*)()) F835_8622;
	R7740[118] = (char *(*)()) F835_8622;
	{long i; for (i = 120; i < 122; i++) R7740[i] = (char *(*)()) F835_8622;}
	R7740[124] = (char *(*)()) F835_8622;
	{long i; for (i = 126; i < 132; i++) R7740[i] = (char *(*)()) F835_8622;}
	R7740[132] = (char *(*)()) F938_9019;
	R7740[133] = (char *(*)()) F939_9019;
	R7740[134] = (char *(*)()) F940_9019;
	R7740[135] = (char *(*)()) F941_9019;
	R7740[136] = (char *(*)()) F942_9019;
	R7740[137] = (char *(*)()) F943_9019;
	R7740[138] = (char *(*)()) F944_9019;
	R7740[139] = (char *(*)()) F945_9019;
	R7740[140] = (char *(*)()) F946_9019;
	R7740[141] = (char *(*)()) F947_9019;
	R7740[142] = (char *(*)()) F948_9019;
	R7740[143] = (char *(*)()) F949_9019;
	R7740[381] = (char *(*)()) F1187_10761;
	{long i; for (i = 435; i < 437; i++) R7740[i] = (char *(*)()) F1240_11212;}
	{long i; for (i = 438; i < 440; i++) R7740[i] = (char *(*)()) F1243_11380;}
	{long i; for (i = 547; i < 549; i++) R7740[i] = (char *(*)()) F835_8622;}
	{long i; for (i = 566; i < 568; i++) R7740[i] = (char *(*)()) F835_8622;}
	R7740[569] = (char *(*)()) F835_8622;
	R7740[589] = (char *(*)()) F835_8622;
	R7740[600] = (char *(*)()) F835_8622;
	R7740[602] = (char *(*)()) F1408_13457;
	R7740[603] = (char *(*)()) F1409_13457;
	R7740[604] = (char *(*)()) F1410_13457;
	R7740[605] = (char *(*)()) F1411_13457;
	R7740[606] = (char *(*)()) F1412_13457;
	R7740[607] = (char *(*)()) F1413_13457;
	R7740[608] = (char *(*)()) F1414_13457;
	R7740[609] = (char *(*)()) F1415_13457;
	R7740[610] = (char *(*)()) F1416_13457;
	R7740[611] = (char *(*)()) F1417_13457;
	R7740[612] = (char *(*)()) F1418_13457;
	R7740[613] = (char *(*)()) F1419_13457;
	R7740[992] = (char *(*)()) F1243_11380;
}


#ifdef __cplusplus
}
#endif
