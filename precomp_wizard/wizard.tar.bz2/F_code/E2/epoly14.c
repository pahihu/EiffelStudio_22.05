#include "epoly14.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R8975[569])();
void R8975_init () {
	R8975[0] = (char *(*)()) F1148_10379;
	R8975[568] = (char *(*)()) F1716_18280;
}

char *(*R9226[5])();
void R9226_init () {
	R9226[0] = (char *(*)()) F1402_13425;
	R9226[4] = (char *(*)()) F1406_13440;
}

char *(*R9231[54])();
void R9231_init () {
	R9231[0] = (char *(*)()) F1353_12906;
	R9231[1] = (char *(*)()) F1354_12908;
	R9231[2] = (char *(*)()) F1355_12921;
	R9231[3] = (char *(*)()) F1356_12929;
	R9231[5] = (char *(*)()) F1358_12953;
	R9231[6] = (char *(*)()) F1359_12986;
	R9231[9] = (char *(*)()) F1361_13012;
	{long i; for (i = 10; i < 12; i++) R9231[i] = (char *(*)()) F1363_13055;}
	{long i; for (i = 13; i < 16; i++) R9231[i] = (char *(*)()) F1363_13055;}
	R9231[18] = (char *(*)()) F1371_13118;
	R9231[19] = (char *(*)()) F1372_13130;
	R9231[20] = (char *(*)()) F1373_13162;
	R9231[21] = (char *(*)()) F1374_13169;
	R9231[22] = (char *(*)()) F1375_13176;
	R9231[23] = (char *(*)()) F1376_13199;
	R9231[26] = (char *(*)()) F1379_13224;
	R9231[27] = (char *(*)()) F1380_13232;
	R9231[34] = (char *(*)()) F1387_13316;
	R9231[37] = (char *(*)()) F1390_13353;
	R9231[38] = (char *(*)()) F1391_13355;
	R9231[41] = (char *(*)()) F1394_13377;
	R9231[42] = (char *(*)()) F1395_13382;
	R9231[46] = (char *(*)()) F1399_13404;
	R9231[49] = (char *(*)()) F1402_13425;
	R9231[53] = (char *(*)()) F1406_13440;
}

char *(*R9237[20])();
void R9237_init () {
	R9237[0] = (char *(*)()) F1353_12906;
	R9237[1] = (char *(*)()) F1354_12908;
	R9237[2] = (char *(*)()) F1355_12921;
	R9237[3] = (char *(*)()) F1356_12929;
	R9237[5] = (char *(*)()) F1358_12953;
	R9237[6] = (char *(*)()) F1359_12986;
	R9237[9] = (char *(*)()) F1361_13012;
	{long i; for (i = 10; i < 12; i++) R9237[i] = (char *(*)()) F1363_13055;}
	{long i; for (i = 13; i < 16; i++) R9237[i] = (char *(*)()) F1363_13055;}
	R9237[19] = (char *(*)()) F1372_13130;
}

char *(*R9255[39])();
void R9255_init () {
	R9255[0] = (char *(*)()) F1353_12906;
	R9255[1] = (char *(*)()) F1354_12908;
	R9255[2] = (char *(*)()) F1355_12921;
	R9255[3] = (char *(*)()) F1356_12929;
	R9255[5] = (char *(*)()) F1358_12953;
	R9255[6] = (char *(*)()) F1359_12986;
	R9255[9] = (char *(*)()) F1361_13012;
	{long i; for (i = 10; i < 12; i++) R9255[i] = (char *(*)()) F1363_13055;}
	{long i; for (i = 13; i < 16; i++) R9255[i] = (char *(*)()) F1363_13055;}
	R9255[18] = (char *(*)()) F1371_13118;
	R9255[19] = (char *(*)()) F1372_13130;
	R9255[20] = (char *(*)()) F1373_13162;
	R9255[21] = (char *(*)()) F1374_13169;
	R9255[22] = (char *(*)()) F1375_13176;
	R9255[23] = (char *(*)()) F1376_13199;
	R9255[26] = (char *(*)()) F1379_13224;
	R9255[27] = (char *(*)()) F1380_13232;
	R9255[34] = (char *(*)()) F1387_13316;
	R9255[37] = (char *(*)()) F1390_13353;
	R9255[38] = (char *(*)()) F1391_13355;
}

char *(*R9271[10])();
void R9271_init () {
	R9271[0] = (char *(*)()) F1359_12986;
	R9271[3] = (char *(*)()) F1361_13012;
	{long i; for (i = 4; i < 6; i++) R9271[i] = (char *(*)()) F1363_13055;}
	{long i; for (i = 7; i < 10; i++) R9271[i] = (char *(*)()) F1363_13055;}
}

char *(*R9308[612])();
void R9308_init () {
	R9308[0] = (char *(*)()) F1187_10757;
	{long i; for (i = 2; i < 4; i++) R9308[i] = (char *(*)()) F1188_10865;}
	{long i; for (i = 5; i < 7; i++) R9308[i] = (char *(*)()) F1191_10906;}
	{long i; for (i = 8; i < 10; i++) R9308[i] = (char *(*)()) F1194_10954;}
	{long i; for (i = 10; i < 41; i++) R9308[i] = (char *(*)()) F1197_10975;}
	R9308[41] = (char *(*)()) F1228_11001;
	R9308[42] = (char *(*)()) F1229_11001;
	{long i; for (i = 44; i < 50; i++) R9308[i] = (char *(*)()) F1230_11009;}
	{long i; for (i = 54; i < 56; i++) R9308[i] = (char *(*)()) F1237_11068;}
	{long i; for (i = 57; i < 59; i++) R9308[i] = (char *(*)()) F1237_11068;}
	R9308[70] = (char *(*)()) F1257_11717;
	R9308[112] = (char *(*)()) F1299_12367;
	R9308[114] = (char *(*)()) F1301_12517;
	R9308[117] = (char *(*)()) F1304_12641;
	R9308[118] = (char *(*)()) F1305_12683;
	R9308[119] = (char *(*)()) F1306_12683;
	R9308[120] = (char *(*)()) F1307_12683;
	R9308[121] = (char *(*)()) F1308_12683;
	R9308[122] = (char *(*)()) F1309_12683;
	R9308[123] = (char *(*)()) F1310_12683;
	R9308[124] = (char *(*)()) F1311_12683;
	R9308[125] = (char *(*)()) F1312_12683;
	R9308[126] = (char *(*)()) F1313_12683;
	R9308[127] = (char *(*)()) F1314_12683;
	R9308[128] = (char *(*)()) F1315_12683;
	R9308[129] = (char *(*)()) F1316_12683;
	R9308[130] = (char *(*)()) F1317_12683;
	R9308[131] = (char *(*)()) F1318_12683;
	R9308[132] = (char *(*)()) F1319_12683;
	R9308[133] = (char *(*)()) F1320_12683;
	R9308[134] = (char *(*)()) F1321_12683;
	R9308[135] = (char *(*)()) F1322_12683;
	R9308[136] = (char *(*)()) F1323_12683;
	R9308[137] = (char *(*)()) F1324_12683;
	R9308[138] = (char *(*)()) F1325_12683;
	R9308[139] = (char *(*)()) F1326_12683;
	R9308[140] = (char *(*)()) F1327_12683;
	R9308[141] = (char *(*)()) F1328_12683;
	R9308[142] = (char *(*)()) F1329_12683;
	R9308[143] = (char *(*)()) F1330_12683;
	R9308[144] = (char *(*)()) F1331_12683;
	R9308[145] = (char *(*)()) F1332_12683;
	R9308[146] = (char *(*)()) F1333_12683;
	R9308[147] = (char *(*)()) F1334_12683;
	R9308[148] = (char *(*)()) F1335_12683;
	R9308[149] = (char *(*)()) F1336_12683;
	R9308[150] = (char *(*)()) F1337_12683;
	R9308[151] = (char *(*)()) F1338_12683;
	{long i; for (i = 236; i < 239; i++) R9308[i] = (char *(*)()) F1420_13517;}
	{long i; for (i = 240; i < 243; i++) R9308[i] = (char *(*)()) F1420_13517;}
	R9308[290] = (char *(*)()) F1477_13761;
	R9308[291] = (char *(*)()) F1478_13766;
	R9308[292] = (char *(*)()) F1479_13795;
	R9308[293] = (char *(*)()) F1480_13810;
	{long i; for (i = 296; i < 298; i++) R9308[i] = (char *(*)()) F1482_13838;}
	{long i; for (i = 299; i < 301; i++) R9308[i] = (char *(*)()) F1485_13936;}
	{long i; for (i = 302; i < 304; i++) R9308[i] = (char *(*)()) F1488_14035;}
	{long i; for (i = 305; i < 307; i++) R9308[i] = (char *(*)()) F1491_14134;}
	{long i; for (i = 308; i < 310; i++) R9308[i] = (char *(*)()) F1494_14233;}
	{long i; for (i = 311; i < 313; i++) R9308[i] = (char *(*)()) F1497_14327;}
	{long i; for (i = 314; i < 316; i++) R9308[i] = (char *(*)()) F1500_14421;}
	{long i; for (i = 317; i < 319; i++) R9308[i] = (char *(*)()) F1503_14516;}
	{long i; for (i = 320; i < 322; i++) R9308[i] = (char *(*)()) F1506_14611;}
	{long i; for (i = 323; i < 325; i++) R9308[i] = (char *(*)()) F1509_14677;}
	R9308[325] = (char *(*)()) F1512_14776;
	R9308[326] = (char *(*)()) F1513_14796;
	R9308[530] = (char *(*)()) F1717_18303;
	R9308[532] = (char *(*)()) F1719_18322;
	R9308[611] = (char *(*)()) F1798_20783;
}

char *(*R9446[2])();
void R9446_init () {
	R9446[0] = (char *(*)()) F1189_10901;
	R9446[1] = (char *(*)()) F1190_10901;
}

char *(*R9570[6])();
void R9570_init () {
	R9570[0] = (char *(*)()) F1231_11046;
	R9570[1] = (char *(*)()) F1232_11049;
	R9570[2] = (char *(*)()) F1233_11049;
	R9570[3] = (char *(*)()) F1234_11049;
	R9570[4] = (char *(*)()) F1235_11049;
	R9570[5] = (char *(*)()) F1233_11049;
}

char *(*R9594[5])();
void R9594_init () {
	R9594[0] = (char *(*)()) F1232_11048;
	R9594[1] = (char *(*)()) F1233_11048_9594_1;
	R9594[2] = (char *(*)()) F1234_11048_9594_1;
	R9594[3] = (char *(*)()) F1235_11048_9594_1;
	R9594[4] = (char *(*)()) F1233_11048_9594_1;
}
static EIF_REFERENCE F1233_11048_9594_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1233_11048(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1195, 0x00).id, 1195, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1234_11048_9594_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1234_11048(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1235_11048_9594_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1235_11048(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R9595[5])();
void R9595_init () {
	R9595[0] = (char *(*)()) F1232_11050;
	R9595[1] = (char *(*)()) F1233_11050_9595_5;
	R9595[2] = (char *(*)()) F1234_11050_9595_5;
	R9595[3] = (char *(*)()) F1235_11050_9595_5;
	R9595[4] = (char *(*)()) F1233_11050_9595_5;
}
static EIF_REFERENCE F1233_11050_9595_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1233_11050(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1195, 0x00).id, 1195, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1234_11050_9595_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1234_11050(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1235_11050_9595_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1235_11050(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R9599[5])();
void R9599_init () {
	R9599[0] = (char *(*)()) F1232_11057;
	R9599[1] = (char *(*)()) F1233_11057_9599_517;
	R9599[2] = (char *(*)()) F1234_11057_9599_517;
	R9599[3] = (char *(*)()) F1235_11057_9599_517;
	R9599[4] = (char *(*)()) F1233_11057_9599_517;
}
static EIF_REFERENCE F1233_11057_9599_517 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1233_11057(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1195, 0x00).id, 1195, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1234_11057_9599_517 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1234_11057(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1235_11057_9599_517 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1235_11057(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y9600_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y9600_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y9600_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y9600_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y9600_pgtype4[] = {1195,0xFFFF};
EIF_TYPE_INDEX *Y9600_gen_type [5];
EIF_TYPE_INDEX Y9600 [5];
void Y9600_init (void)
{
	egc_routines_types [9600] = Y9600;
	egc_routines_gen_types [9600] = Y9600_gen_type;
	egc_routines_offset [9600] = 1231;
	Y9600_gen_type [0] = Y9600_pgtype0;
	Y9600_gen_type [1] = Y9600_pgtype1;
	Y9600_gen_type [2] = Y9600_pgtype2;
	Y9600_gen_type [3] = Y9600_pgtype3;
	Y9600_gen_type [4] = Y9600_pgtype4;
	Y9600[4] = 1195;
}

char *(*R9601[558])();
void R9601_init () {
	{long i; for (i = 0; i < 2; i++) R9601[i] = (char *(*)()) F1240_11189;}
	{long i; for (i = 3; i < 5; i++) R9601[i] = (char *(*)()) F1243_11356;}
	R9601[557] = (char *(*)()) F1798_20757;
}

char *(*R9603[558])();
void R9603_init () {
	R9603[0] = (char *(*)()) F1241_11250;
	R9603[1] = (char *(*)()) F1242_11273;
	R9603[3] = (char *(*)()) F1244_11416;
	R9603[4] = (char *(*)()) F1245_11438;
	R9603[557] = (char *(*)()) F1798_20885;
}

char *(*R9604[558])();
void R9604_init () {
	R9604[0] = (char *(*)()) F1241_11248;
	R9604[1] = (char *(*)()) F1242_11271;
	R9604[3] = (char *(*)()) F1244_11415;
	R9604[4] = (char *(*)()) F1245_11437;
	R9604[557] = (char *(*)()) F1245_11437;
}

char *(*R9605[558])();
void R9605_init () {
	{long i; for (i = 0; i < 2; i++) R9605[i] = (char *(*)()) F1240_11201;}
	{long i; for (i = 3; i < 5; i++) R9605[i] = (char *(*)()) F1237_11062;}
	R9605[557] = (char *(*)()) F1237_11062;
}

char *(*R9615[558])();
void R9615_init () {
	{long i; for (i = 0; i < 2; i++) R9615[i] = (char *(*)()) F1240_11219;}
	{long i; for (i = 3; i < 5; i++) R9615[i] = (char *(*)()) F1243_11387;}
	R9615[557] = (char *(*)()) F1243_11387;
}

char *(*R9617[558])();
void R9617_init () {
	{long i; for (i = 0; i < 2; i++) R9617[i] = (char *(*)()) F1240_11221;}
	{long i; for (i = 3; i < 5; i++) R9617[i] = (char *(*)()) F1243_11389;}
	R9617[557] = (char *(*)()) F1243_11389;
}

char *(*R9618[558])();
void R9618_init () {
	R9618[0] = (char *(*)()) F1241_11260;
	R9618[1] = (char *(*)()) F730_8337;
	R9618[3] = (char *(*)()) F1244_11425;
	R9618[4] = (char *(*)()) F729_8337;
	R9618[557] = (char *(*)()) F729_8337;
}

char *(*R9620[558])();
void R9620_init () {
	{long i; for (i = 0; i < 2; i++) R9620[i] = (char *(*)()) F1240_11222;}
	{long i; for (i = 3; i < 5; i++) R9620[i] = (char *(*)()) F1243_11390;}
	R9620[557] = (char *(*)()) F1243_11390;
}

char *(*R9621[558])();
void R9621_init () {
	{long i; for (i = 0; i < 2; i++) R9621[i] = (char *(*)()) F1240_11223;}
	{long i; for (i = 3; i < 5; i++) R9621[i] = (char *(*)()) F1237_11079;}
	R9621[557] = (char *(*)()) F1237_11079;
}

char *(*R9640[558])();
void R9640_init () {
	{long i; for (i = 0; i < 2; i++) R9640[i] = (char *(*)()) F1240_11210;}
	{long i; for (i = 3; i < 5; i++) R9640[i] = (char *(*)()) F1243_11378;}
	R9640[557] = (char *(*)()) F1798_20788;
}

char *(*R9641[558])();
void R9641_init () {
	{long i; for (i = 0; i < 2; i++) R9641[i] = (char *(*)()) F1240_11209;}
	{long i; for (i = 3; i < 5; i++) R9641[i] = (char *(*)()) F1243_11377;}
	R9641[557] = (char *(*)()) F1798_20790;
}

char *(*R9645[558])();
void R9645_init () {
	{long i; for (i = 0; i < 2; i++) R9645[i] = (char *(*)()) F1237_11103;}
	{long i; for (i = 3; i < 5; i++) R9645[i] = (char *(*)()) F1237_11103;}
	R9645[557] = (char *(*)()) F1798_20795;
}

char *(*R9646[558])();
void R9646_init () {
	{long i; for (i = 0; i < 2; i++) R9646[i] = (char *(*)()) F1237_11104;}
	{long i; for (i = 3; i < 5; i++) R9646[i] = (char *(*)()) F1237_11104;}
	R9646[557] = (char *(*)()) F1798_20801;
}

char *(*R9651[558])();
void R9651_init () {
	{long i; for (i = 0; i < 2; i++) R9651[i] = (char *(*)()) F1240_11206;}
	{long i; for (i = 3; i < 5; i++) R9651[i] = (char *(*)()) F1243_11374;}
	R9651[557] = (char *(*)()) F1798_20776;
}

char *(*R9662[558])();
void R9662_init () {
	R9662[0] = (char *(*)()) F1241_11255;
	R9662[1] = (char *(*)()) F1242_11339;
	R9662[3] = (char *(*)()) F1244_11421;
	R9662[4] = (char *(*)()) F1245_11504;
	R9662[557] = (char *(*)()) F1798_20845;
}

char *(*R9663[558])();
void R9663_init () {
	R9663[0] = (char *(*)()) F1241_11256;
	R9663[1] = (char *(*)()) F1242_11340;
	R9663[3] = (char *(*)()) F1244_11422;
	R9663[4] = (char *(*)()) F1245_11505;
	R9663[557] = (char *(*)()) F1798_20846;
}


#ifdef __cplusplus
}
#endif
