#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O13029[80];
void O13029_init () {
	{long i; for (i = 0; i < 2; i++) O13029[i] =  + _REFACS_2_;}
	{long i; for (i = 34; i < 37; i++) O13029[i] =  + _REFACS_29_;}
	{long i; for (i = 37; i < 40; i++) O13029[i] =  + _REFACS_36_;}
	{long i; for (i = 40; i < 44; i++) O13029[i] =  + _REFACS_29_;}
	{long i; for (i = 44; i < 46; i++) O13029[i] =  + _REFACS_33_;}
	{long i; for (i = 46; i < 48; i++) O13029[i] =  + _REFACS_36_;}
	{long i; for (i = 48; i < 52; i++) O13029[i] =  + _REFACS_35_;}
	{long i; for (i = 52; i < 54; i++) O13029[i] =  + _REFACS_40_;}
	{long i; for (i = 54; i < 56; i++) O13029[i] =  + _REFACS_43_;}
	O13029[58] =  + _REFACS_28_;
	O13029[79] =  + _REFACS_35_;
}

long O13030[80];
void O13030_init () {
	{long i; for (i = 0; i < 2; i++) O13030[i] = + _CHROFF_3_0_;}
	{long i; for (i = 34; i < 37; i++) O13030[i] = + _CHROFF_39_5_;}
	{long i; for (i = 37; i < 40; i++) O13030[i] = + _CHROFF_49_8_;}
	{long i; for (i = 40; i < 44; i++) O13030[i] = + _CHROFF_39_5_;}
	{long i; for (i = 44; i < 46; i++) O13030[i] = + _CHROFF_47_5_;}
	O13030[46] = + _CHROFF_50_5_;
	O13030[47] = + _CHROFF_53_5_;
	O13030[48] = + _CHROFF_49_8_;
	O13030[49] = + _CHROFF_51_8_;
	{long i; for (i = 50; i < 52; i++) O13030[i] = + _CHROFF_49_8_;}
	{long i; for (i = 52; i < 54; i++) O13030[i] = + _CHROFF_59_10_;}
	O13030[54] = + _CHROFF_65_10_;
	O13030[55] = + _CHROFF_68_10_;
	O13030[58] = + _CHROFF_37_5_;
	O13030[79] = + _CHROFF_45_8_;
}

long O13044[87];
void O13044_init () {
	O13044[0] = + _LNGOFF_1_1_0_0_;
	O13044[23] = + _LNGOFF_38_9_6_2_;
	O13044[26] = + _LNGOFF_49_12_10_3_;
	O13044[51] = + _LNGOFF_37_9_6_2_;
	O13044[53] = + _LNGOFF_43_9_6_2_;
	O13044[55] = + _LNGOFF_40_9_6_2_;
	O13044[61] = + _LNGOFF_37_9_6_2_;
	O13044[62] = + _LNGOFF_37_10_6_2_;
	O13044[65] = + _LNGOFF_41_9_6_2_;
	O13044[72] = + _LNGOFF_51_13_10_3_;
	O13044[74] = + _LNGOFF_58_14_10_3_;
	O13044[76] = + _LNGOFF_51_15_10_3_;
	O13044[82] = + _LNGOFF_50_13_10_3_;
	O13044[83] = + _LNGOFF_51_14_10_3_;
	O13044[86] = + _LNGOFF_59_16_10_3_;
}

long O13045[87];
void O13045_init () {
	O13045[0] = + _LNGOFF_1_1_0_1_;
	O13045[23] = + _LNGOFF_38_9_6_3_;
	O13045[26] = + _LNGOFF_49_12_10_4_;
	O13045[51] = + _LNGOFF_37_9_6_3_;
	O13045[53] = + _LNGOFF_43_9_6_3_;
	O13045[55] = + _LNGOFF_40_9_6_3_;
	O13045[61] = + _LNGOFF_37_9_6_3_;
	O13045[62] = + _LNGOFF_37_10_6_3_;
	O13045[65] = + _LNGOFF_41_9_6_3_;
	O13045[72] = + _LNGOFF_51_13_10_4_;
	O13045[74] = + _LNGOFF_58_14_10_4_;
	O13045[76] = + _LNGOFF_51_15_10_4_;
	O13045[82] = + _LNGOFF_50_13_10_4_;
	O13045[83] = + _LNGOFF_51_14_10_4_;
	O13045[86] = + _LNGOFF_59_16_10_4_;
}

long O13058[117];
void O13058_init () {
	O13058[0] =  + _REFACS_1_;
	{long i; for (i = 77; i < 79; i++) O13058[i] =  + _REFACS_34_;}
	O13058[94] =  + _REFACS_12_;
	{long i; for (i = 99; i < 101; i++) O13058[i] =  + _REFACS_14_;}
	{long i; for (i = 106; i < 110; i++) O13058[i] =  + _REFACS_15_;}
	O13058[110] =  + _REFACS_18_;
	{long i; for (i = 115; i < 117; i++) O13058[i] =  + _REFACS_20_;}
}

long O13060[117];
void O13060_init () {
	O13060[0] = + _PTROFF_2_1_0_0_0_0_;
	{long i; for (i = 77; i < 79; i++) O13060[i] = + _PTROFF_46_14_10_6_0_1_;}
	O13060[94] = + _PTROFF_22_8_6_4_0_1_;
	{long i; for (i = 99; i < 101; i++) O13060[i] = + _PTROFF_21_7_6_1_0_1_;}
	O13060[106] = + _PTROFF_23_8_6_1_0_1_;
	{long i; for (i = 107; i < 109; i++) O13060[i] = + _PTROFF_23_9_6_1_0_1_;}
	O13060[109] = + _PTROFF_24_9_6_1_0_1_;
	O13060[110] = + _PTROFF_26_8_6_2_0_1_;
	{long i; for (i = 115; i < 117; i++) O13060[i] = + _PTROFF_29_14_8_2_0_1_;}
}

long O13069[109];
void O13069_init () {
	O13069[0] = + _PTROFF_2_1_0_0_0_0_;
	O13069[70] = + _PTROFF_44_13_10_6_1_1_;
	{long i; for (i = 75; i < 77; i++) O13069[i] = + _PTROFF_46_14_10_6_0_2_;}
	O13069[92] = + _PTROFF_22_8_6_4_0_2_;
	O13069[104] = + _PTROFF_23_8_6_1_0_2_;
	{long i; for (i = 105; i < 107; i++) O13069[i] = + _PTROFF_23_9_6_1_0_2_;}
	O13069[107] = + _PTROFF_24_9_6_1_0_2_;
	O13069[108] = + _PTROFF_26_8_6_2_0_2_;
}

long O13071[109];
void O13071_init () {
	O13071[0] =  + _REFACS_1_;
	O13071[70] =  + _REFACS_33_;
	{long i; for (i = 75; i < 77; i++) O13071[i] =  + _REFACS_35_;}
	O13071[92] =  + _REFACS_13_;
	{long i; for (i = 104; i < 108; i++) O13071[i] =  + _REFACS_16_;}
	O13071[108] =  + _REFACS_19_;
}

long O13082[81];
void O13082_init () {
	O13082[0] =  + _REFACS_1_;
	O13082[18] =  + _REFACS_36_;
	O13082[35] =  + _REFACS_36_;
	O13082[67] =  + _REFACS_34_;
	O13082[68] =  + _REFACS_39_;
	{long i; for (i = 72; i < 74; i++) O13082[i] =  + _REFACS_36_;}
	O13082[77] =  + _REFACS_35_;
	O13082[78] =  + _REFACS_40_;
	O13082[79] =  + _REFACS_34_;
	O13082[80] =  + _REFACS_37_;
}

long O13118[114];
void O13118_init () {
	O13118[0] =  + _REFACS_8_;
	O13118[1] =  + _REFACS_11_;
	O13118[2] =  + _REFACS_27_;
	O13118[3] =  + _REFACS_33_;
	O13118[4] =  + _REFACS_28_;
	O13118[5] =  + _REFACS_34_;
	O13118[6] =  + _REFACS_28_;
	O13118[7] =  + _REFACS_29_;
	O13118[8] =  + _REFACS_28_;
	O13118[9] =  + _REFACS_35_;
	O13118[10] =  + _REFACS_37_;
	O13118[11] =  + _REFACS_35_;
	{long i; for (i = 12; i < 15; i++) O13118[i] =  + _REFACS_30_;}
	{long i; for (i = 15; i < 18; i++) O13118[i] =  + _REFACS_37_;}
	{long i; for (i = 18; i < 22; i++) O13118[i] =  + _REFACS_30_;}
	{long i; for (i = 22; i < 24; i++) O13118[i] =  + _REFACS_34_;}
	{long i; for (i = 24; i < 26; i++) O13118[i] =  + _REFACS_37_;}
	O13118[26] =  + _REFACS_36_;
	O13118[27] =  + _REFACS_37_;
	{long i; for (i = 28; i < 30; i++) O13118[i] =  + _REFACS_36_;}
	{long i; for (i = 30; i < 32; i++) O13118[i] =  + _REFACS_41_;}
	{long i; for (i = 32; i < 34; i++) O13118[i] =  + _REFACS_44_;}
	O13118[34] =  + _REFACS_27_;
	{long i; for (i = 35; i < 37; i++) O13118[i] =  + _REFACS_29_;}
	O13118[37] =  + _REFACS_31_;
	O13118[38] =  + _REFACS_27_;
	O13118[39] =  + _REFACS_32_;
	{long i; for (i = 40; i < 45; i++) O13118[i] =  + _REFACS_28_;}
	{long i; for (i = 45; i < 47; i++) O13118[i] =  + _REFACS_29_;}
	O13118[47] =  + _REFACS_28_;
	O13118[48] =  + _REFACS_29_;
	O13118[49] =  + _REFACS_33_;
	O13118[50] =  + _REFACS_28_;
	O13118[51] =  + _REFACS_31_;
	{long i; for (i = 52; i < 55; i++) O13118[i] =  + _REFACS_27_;}
	O13118[55] =  + _REFACS_33_;
	{long i; for (i = 56; i < 58; i++) O13118[i] =  + _REFACS_36_;}
	O13118[58] =  + _REFACS_38_;
	O13118[59] =  + _REFACS_35_;
	O13118[60] =  + _REFACS_40_;
	{long i; for (i = 61; i < 64; i++) O13118[i] =  + _REFACS_34_;}
	{long i; for (i = 64; i < 66; i++) O13118[i] =  + _REFACS_37_;}
	{long i; for (i = 66; i < 68; i++) O13118[i] =  + _REFACS_36_;}
	O13118[68] =  + _REFACS_34_;
	O13118[69] =  + _REFACS_36_;
	O13118[70] =  + _REFACS_41_;
	O13118[71] =  + _REFACS_35_;
	O13118[72] =  + _REFACS_38_;
	{long i; for (i = 73; i < 76; i++) O13118[i] =  + _REFACS_33_;}
	O13118[76] =  + _REFACS_11_;
	{long i; for (i = 77; i < 79; i++) O13118[i] =  + _REFACS_13_;}
	{long i; for (i = 79; i < 81; i++) O13118[i] =  + _REFACS_11_;}
	O13118[81] =  + _REFACS_14_;
	{long i; for (i = 82; i < 84; i++) O13118[i] =  + _REFACS_15_;}
	{long i; for (i = 84; i < 86; i++) O13118[i] =  + _REFACS_16_;}
	{long i; for (i = 86; i < 88; i++) O13118[i] =  + _REFACS_15_;}
	{long i; for (i = 88; i < 92; i++) O13118[i] =  + _REFACS_12_;}
	O13118[92] =  + _REFACS_13_;
	{long i; for (i = 93; i < 97; i++) O13118[i] =  + _REFACS_17_;}
	O13118[97] =  + _REFACS_20_;
	{long i; for (i = 98; i < 100; i++) O13118[i] =  + _REFACS_13_;}
	{long i; for (i = 100; i < 102; i++) O13118[i] =  + _REFACS_16_;}
	{long i; for (i = 102; i < 104; i++) O13118[i] =  + _REFACS_21_;}
	O13118[105] =  + _REFACS_28_;
	O13118[108] =  + _REFACS_28_;
	O13118[110] =  + _REFACS_34_;
	O13118[113] =  + _REFACS_34_;
}

long O13119[114];
void O13119_init () {
	O13119[0] =  + _REFACS_9_;
	O13119[1] =  + _REFACS_12_;
	O13119[2] =  + _REFACS_28_;
	O13119[3] =  + _REFACS_34_;
	O13119[4] =  + _REFACS_29_;
	O13119[5] =  + _REFACS_35_;
	O13119[6] =  + _REFACS_29_;
	O13119[7] =  + _REFACS_30_;
	O13119[8] =  + _REFACS_29_;
	O13119[9] =  + _REFACS_36_;
	O13119[10] =  + _REFACS_38_;
	O13119[11] =  + _REFACS_36_;
	{long i; for (i = 12; i < 15; i++) O13119[i] =  + _REFACS_31_;}
	{long i; for (i = 15; i < 18; i++) O13119[i] =  + _REFACS_38_;}
	{long i; for (i = 18; i < 22; i++) O13119[i] =  + _REFACS_31_;}
	{long i; for (i = 22; i < 24; i++) O13119[i] =  + _REFACS_35_;}
	{long i; for (i = 24; i < 26; i++) O13119[i] =  + _REFACS_38_;}
	O13119[26] =  + _REFACS_37_;
	O13119[27] =  + _REFACS_38_;
	{long i; for (i = 28; i < 30; i++) O13119[i] =  + _REFACS_37_;}
	{long i; for (i = 30; i < 32; i++) O13119[i] =  + _REFACS_42_;}
	{long i; for (i = 32; i < 34; i++) O13119[i] =  + _REFACS_45_;}
	O13119[34] =  + _REFACS_28_;
	{long i; for (i = 35; i < 37; i++) O13119[i] =  + _REFACS_30_;}
	O13119[37] =  + _REFACS_32_;
	O13119[38] =  + _REFACS_28_;
	O13119[39] =  + _REFACS_33_;
	{long i; for (i = 40; i < 45; i++) O13119[i] =  + _REFACS_29_;}
	{long i; for (i = 45; i < 47; i++) O13119[i] =  + _REFACS_30_;}
	O13119[47] =  + _REFACS_29_;
	O13119[48] =  + _REFACS_30_;
	O13119[49] =  + _REFACS_34_;
	O13119[50] =  + _REFACS_29_;
	O13119[51] =  + _REFACS_32_;
	{long i; for (i = 52; i < 55; i++) O13119[i] =  + _REFACS_28_;}
	O13119[55] =  + _REFACS_34_;
	{long i; for (i = 56; i < 58; i++) O13119[i] =  + _REFACS_37_;}
	O13119[58] =  + _REFACS_39_;
	O13119[59] =  + _REFACS_36_;
	O13119[60] =  + _REFACS_41_;
	{long i; for (i = 61; i < 64; i++) O13119[i] =  + _REFACS_35_;}
	{long i; for (i = 64; i < 66; i++) O13119[i] =  + _REFACS_38_;}
	{long i; for (i = 66; i < 68; i++) O13119[i] =  + _REFACS_37_;}
	O13119[68] =  + _REFACS_35_;
	O13119[69] =  + _REFACS_37_;
	O13119[70] =  + _REFACS_42_;
	O13119[71] =  + _REFACS_36_;
	O13119[72] =  + _REFACS_39_;
	{long i; for (i = 73; i < 76; i++) O13119[i] =  + _REFACS_34_;}
	O13119[76] =  + _REFACS_12_;
	{long i; for (i = 77; i < 79; i++) O13119[i] =  + _REFACS_14_;}
	{long i; for (i = 79; i < 81; i++) O13119[i] =  + _REFACS_12_;}
	O13119[81] =  + _REFACS_15_;
	{long i; for (i = 82; i < 84; i++) O13119[i] =  + _REFACS_16_;}
	{long i; for (i = 84; i < 86; i++) O13119[i] =  + _REFACS_17_;}
	{long i; for (i = 86; i < 88; i++) O13119[i] =  + _REFACS_16_;}
	{long i; for (i = 88; i < 92; i++) O13119[i] =  + _REFACS_13_;}
	O13119[92] =  + _REFACS_14_;
	{long i; for (i = 93; i < 97; i++) O13119[i] =  + _REFACS_18_;}
	O13119[97] =  + _REFACS_21_;
	{long i; for (i = 98; i < 100; i++) O13119[i] =  + _REFACS_14_;}
	{long i; for (i = 100; i < 102; i++) O13119[i] =  + _REFACS_17_;}
	{long i; for (i = 102; i < 104; i++) O13119[i] =  + _REFACS_22_;}
	O13119[105] =  + _REFACS_29_;
	O13119[108] =  + _REFACS_29_;
	O13119[110] =  + _REFACS_35_;
	O13119[113] =  + _REFACS_35_;
}

long O13121[114];
void O13121_init () {
	O13121[0] =  + _REFACS_10_;
	O13121[1] =  + _REFACS_13_;
	O13121[2] =  + _REFACS_29_;
	O13121[3] =  + _REFACS_35_;
	O13121[4] =  + _REFACS_30_;
	O13121[5] =  + _REFACS_36_;
	O13121[6] =  + _REFACS_30_;
	O13121[7] =  + _REFACS_31_;
	O13121[8] =  + _REFACS_30_;
	O13121[9] =  + _REFACS_37_;
	O13121[10] =  + _REFACS_39_;
	O13121[11] =  + _REFACS_37_;
	{long i; for (i = 12; i < 15; i++) O13121[i] =  + _REFACS_32_;}
	{long i; for (i = 15; i < 18; i++) O13121[i] =  + _REFACS_39_;}
	{long i; for (i = 18; i < 22; i++) O13121[i] =  + _REFACS_32_;}
	{long i; for (i = 22; i < 24; i++) O13121[i] =  + _REFACS_36_;}
	{long i; for (i = 24; i < 26; i++) O13121[i] =  + _REFACS_39_;}
	O13121[26] =  + _REFACS_38_;
	O13121[27] =  + _REFACS_39_;
	{long i; for (i = 28; i < 30; i++) O13121[i] =  + _REFACS_38_;}
	{long i; for (i = 30; i < 32; i++) O13121[i] =  + _REFACS_43_;}
	{long i; for (i = 32; i < 34; i++) O13121[i] =  + _REFACS_46_;}
	O13121[34] =  + _REFACS_29_;
	{long i; for (i = 35; i < 37; i++) O13121[i] =  + _REFACS_31_;}
	O13121[37] =  + _REFACS_33_;
	O13121[38] =  + _REFACS_29_;
	O13121[39] =  + _REFACS_34_;
	{long i; for (i = 40; i < 45; i++) O13121[i] =  + _REFACS_30_;}
	{long i; for (i = 45; i < 47; i++) O13121[i] =  + _REFACS_31_;}
	O13121[47] =  + _REFACS_30_;
	O13121[48] =  + _REFACS_31_;
	O13121[49] =  + _REFACS_35_;
	O13121[50] =  + _REFACS_30_;
	O13121[51] =  + _REFACS_33_;
	{long i; for (i = 52; i < 55; i++) O13121[i] =  + _REFACS_29_;}
	O13121[55] =  + _REFACS_35_;
	{long i; for (i = 56; i < 58; i++) O13121[i] =  + _REFACS_38_;}
	O13121[58] =  + _REFACS_40_;
	O13121[59] =  + _REFACS_37_;
	O13121[60] =  + _REFACS_42_;
	{long i; for (i = 61; i < 64; i++) O13121[i] =  + _REFACS_36_;}
	{long i; for (i = 64; i < 66; i++) O13121[i] =  + _REFACS_39_;}
	{long i; for (i = 66; i < 68; i++) O13121[i] =  + _REFACS_38_;}
	O13121[68] =  + _REFACS_36_;
	O13121[69] =  + _REFACS_38_;
	O13121[70] =  + _REFACS_43_;
	O13121[71] =  + _REFACS_37_;
	O13121[72] =  + _REFACS_40_;
	{long i; for (i = 73; i < 76; i++) O13121[i] =  + _REFACS_35_;}
	O13121[76] =  + _REFACS_13_;
	{long i; for (i = 77; i < 79; i++) O13121[i] =  + _REFACS_15_;}
	{long i; for (i = 79; i < 81; i++) O13121[i] =  + _REFACS_13_;}
	O13121[81] =  + _REFACS_16_;
	{long i; for (i = 82; i < 84; i++) O13121[i] =  + _REFACS_17_;}
	{long i; for (i = 84; i < 86; i++) O13121[i] =  + _REFACS_18_;}
	{long i; for (i = 86; i < 88; i++) O13121[i] =  + _REFACS_17_;}
	{long i; for (i = 88; i < 92; i++) O13121[i] =  + _REFACS_14_;}
	O13121[92] =  + _REFACS_15_;
	{long i; for (i = 93; i < 97; i++) O13121[i] =  + _REFACS_19_;}
	O13121[97] =  + _REFACS_22_;
	{long i; for (i = 98; i < 100; i++) O13121[i] =  + _REFACS_15_;}
	{long i; for (i = 100; i < 102; i++) O13121[i] =  + _REFACS_18_;}
	{long i; for (i = 102; i < 104; i++) O13121[i] =  + _REFACS_23_;}
	O13121[105] =  + _REFACS_30_;
	O13121[108] =  + _REFACS_30_;
	O13121[110] =  + _REFACS_36_;
	O13121[113] =  + _REFACS_36_;
}

long O13122[114];
void O13122_init () {
	O13122[0] =  + _REFACS_11_;
	O13122[1] =  + _REFACS_14_;
	O13122[2] =  + _REFACS_30_;
	O13122[3] =  + _REFACS_36_;
	O13122[4] =  + _REFACS_31_;
	O13122[5] =  + _REFACS_37_;
	O13122[6] =  + _REFACS_31_;
	O13122[7] =  + _REFACS_32_;
	O13122[8] =  + _REFACS_31_;
	O13122[9] =  + _REFACS_38_;
	O13122[10] =  + _REFACS_40_;
	O13122[11] =  + _REFACS_38_;
	{long i; for (i = 12; i < 15; i++) O13122[i] =  + _REFACS_33_;}
	{long i; for (i = 15; i < 18; i++) O13122[i] =  + _REFACS_40_;}
	{long i; for (i = 18; i < 22; i++) O13122[i] =  + _REFACS_33_;}
	{long i; for (i = 22; i < 24; i++) O13122[i] =  + _REFACS_37_;}
	{long i; for (i = 24; i < 26; i++) O13122[i] =  + _REFACS_40_;}
	O13122[26] =  + _REFACS_39_;
	O13122[27] =  + _REFACS_40_;
	{long i; for (i = 28; i < 30; i++) O13122[i] =  + _REFACS_39_;}
	{long i; for (i = 30; i < 32; i++) O13122[i] =  + _REFACS_44_;}
	{long i; for (i = 32; i < 34; i++) O13122[i] =  + _REFACS_47_;}
	O13122[34] =  + _REFACS_30_;
	{long i; for (i = 35; i < 37; i++) O13122[i] =  + _REFACS_32_;}
	O13122[37] =  + _REFACS_34_;
	O13122[38] =  + _REFACS_30_;
	O13122[39] =  + _REFACS_35_;
	{long i; for (i = 40; i < 45; i++) O13122[i] =  + _REFACS_31_;}
	{long i; for (i = 45; i < 47; i++) O13122[i] =  + _REFACS_32_;}
	O13122[47] =  + _REFACS_31_;
	O13122[48] =  + _REFACS_32_;
	O13122[49] =  + _REFACS_36_;
	O13122[50] =  + _REFACS_31_;
	O13122[51] =  + _REFACS_34_;
	{long i; for (i = 52; i < 55; i++) O13122[i] =  + _REFACS_30_;}
	O13122[55] =  + _REFACS_36_;
	{long i; for (i = 56; i < 58; i++) O13122[i] =  + _REFACS_39_;}
	O13122[58] =  + _REFACS_41_;
	O13122[59] =  + _REFACS_38_;
	O13122[60] =  + _REFACS_43_;
	{long i; for (i = 61; i < 64; i++) O13122[i] =  + _REFACS_37_;}
	{long i; for (i = 64; i < 66; i++) O13122[i] =  + _REFACS_40_;}
	{long i; for (i = 66; i < 68; i++) O13122[i] =  + _REFACS_39_;}
	O13122[68] =  + _REFACS_37_;
	O13122[69] =  + _REFACS_39_;
	O13122[70] =  + _REFACS_44_;
	O13122[71] =  + _REFACS_38_;
	O13122[72] =  + _REFACS_41_;
	{long i; for (i = 73; i < 76; i++) O13122[i] =  + _REFACS_36_;}
	O13122[76] =  + _REFACS_14_;
	{long i; for (i = 77; i < 79; i++) O13122[i] =  + _REFACS_16_;}
	{long i; for (i = 79; i < 81; i++) O13122[i] =  + _REFACS_14_;}
	O13122[81] =  + _REFACS_17_;
	{long i; for (i = 82; i < 84; i++) O13122[i] =  + _REFACS_18_;}
	{long i; for (i = 84; i < 86; i++) O13122[i] =  + _REFACS_19_;}
	{long i; for (i = 86; i < 88; i++) O13122[i] =  + _REFACS_18_;}
	{long i; for (i = 88; i < 92; i++) O13122[i] =  + _REFACS_15_;}
	O13122[92] =  + _REFACS_16_;
	{long i; for (i = 93; i < 97; i++) O13122[i] =  + _REFACS_20_;}
	O13122[97] =  + _REFACS_23_;
	{long i; for (i = 98; i < 100; i++) O13122[i] =  + _REFACS_16_;}
	{long i; for (i = 100; i < 102; i++) O13122[i] =  + _REFACS_19_;}
	{long i; for (i = 102; i < 104; i++) O13122[i] =  + _REFACS_24_;}
	O13122[105] =  + _REFACS_31_;
	O13122[108] =  + _REFACS_31_;
	O13122[110] =  + _REFACS_37_;
	O13122[113] =  + _REFACS_37_;
}

long O13123[114];
void O13123_init () {
	O13123[0] =  + _REFACS_12_;
	O13123[1] =  + _REFACS_15_;
	O13123[2] =  + _REFACS_31_;
	O13123[3] =  + _REFACS_37_;
	O13123[4] =  + _REFACS_32_;
	O13123[5] =  + _REFACS_38_;
	O13123[6] =  + _REFACS_32_;
	O13123[7] =  + _REFACS_33_;
	O13123[8] =  + _REFACS_32_;
	O13123[9] =  + _REFACS_39_;
	O13123[10] =  + _REFACS_41_;
	O13123[11] =  + _REFACS_39_;
	{long i; for (i = 12; i < 15; i++) O13123[i] =  + _REFACS_34_;}
	{long i; for (i = 15; i < 18; i++) O13123[i] =  + _REFACS_41_;}
	{long i; for (i = 18; i < 22; i++) O13123[i] =  + _REFACS_34_;}
	{long i; for (i = 22; i < 24; i++) O13123[i] =  + _REFACS_38_;}
	{long i; for (i = 24; i < 26; i++) O13123[i] =  + _REFACS_41_;}
	O13123[26] =  + _REFACS_40_;
	O13123[27] =  + _REFACS_41_;
	{long i; for (i = 28; i < 30; i++) O13123[i] =  + _REFACS_40_;}
	{long i; for (i = 30; i < 32; i++) O13123[i] =  + _REFACS_45_;}
	{long i; for (i = 32; i < 34; i++) O13123[i] =  + _REFACS_48_;}
	O13123[34] =  + _REFACS_31_;
	{long i; for (i = 35; i < 37; i++) O13123[i] =  + _REFACS_33_;}
	O13123[37] =  + _REFACS_35_;
	O13123[38] =  + _REFACS_31_;
	O13123[39] =  + _REFACS_36_;
	{long i; for (i = 40; i < 45; i++) O13123[i] =  + _REFACS_32_;}
	{long i; for (i = 45; i < 47; i++) O13123[i] =  + _REFACS_33_;}
	O13123[47] =  + _REFACS_32_;
	O13123[48] =  + _REFACS_33_;
	O13123[49] =  + _REFACS_37_;
	O13123[50] =  + _REFACS_32_;
	O13123[51] =  + _REFACS_35_;
	{long i; for (i = 52; i < 55; i++) O13123[i] =  + _REFACS_31_;}
	O13123[55] =  + _REFACS_37_;
	{long i; for (i = 56; i < 58; i++) O13123[i] =  + _REFACS_40_;}
	O13123[58] =  + _REFACS_42_;
	O13123[59] =  + _REFACS_39_;
	O13123[60] =  + _REFACS_44_;
	{long i; for (i = 61; i < 64; i++) O13123[i] =  + _REFACS_38_;}
	{long i; for (i = 64; i < 66; i++) O13123[i] =  + _REFACS_41_;}
	{long i; for (i = 66; i < 68; i++) O13123[i] =  + _REFACS_40_;}
	O13123[68] =  + _REFACS_38_;
	O13123[69] =  + _REFACS_40_;
	O13123[70] =  + _REFACS_45_;
	O13123[71] =  + _REFACS_39_;
	O13123[72] =  + _REFACS_42_;
	{long i; for (i = 73; i < 76; i++) O13123[i] =  + _REFACS_37_;}
	O13123[76] =  + _REFACS_15_;
	{long i; for (i = 77; i < 79; i++) O13123[i] =  + _REFACS_17_;}
	{long i; for (i = 79; i < 81; i++) O13123[i] =  + _REFACS_15_;}
	O13123[81] =  + _REFACS_18_;
	{long i; for (i = 82; i < 84; i++) O13123[i] =  + _REFACS_19_;}
	{long i; for (i = 84; i < 86; i++) O13123[i] =  + _REFACS_20_;}
	{long i; for (i = 86; i < 88; i++) O13123[i] =  + _REFACS_19_;}
	{long i; for (i = 88; i < 92; i++) O13123[i] =  + _REFACS_16_;}
	O13123[92] =  + _REFACS_17_;
	{long i; for (i = 93; i < 97; i++) O13123[i] =  + _REFACS_21_;}
	O13123[97] =  + _REFACS_24_;
	{long i; for (i = 98; i < 100; i++) O13123[i] =  + _REFACS_17_;}
	{long i; for (i = 100; i < 102; i++) O13123[i] =  + _REFACS_20_;}
	{long i; for (i = 102; i < 104; i++) O13123[i] =  + _REFACS_25_;}
	O13123[105] =  + _REFACS_32_;
	O13123[108] =  + _REFACS_32_;
	O13123[110] =  + _REFACS_38_;
	O13123[113] =  + _REFACS_38_;
}

long O13143[114];
void O13143_init () {
	O13143[0] = + _CHROFF_13_1_;
	O13143[1] = + _CHROFF_16_3_;
	O13143[2] = + _CHROFF_35_5_;
	O13143[3] = + _CHROFF_42_8_;
	O13143[4] = + _CHROFF_37_5_;
	O13143[5] = + _CHROFF_46_8_;
	O13143[6] = + _CHROFF_37_5_;
	O13143[7] = + _CHROFF_38_5_;
	O13143[8] = + _CHROFF_37_5_;
	O13143[9] = + _CHROFF_47_8_;
	O13143[10] = + _CHROFF_49_8_;
	O13143[11] = + _CHROFF_47_8_;
	{long i; for (i = 12; i < 15; i++) O13143[i] = + _CHROFF_39_6_;}
	{long i; for (i = 15; i < 18; i++) O13143[i] = + _CHROFF_49_9_;}
	{long i; for (i = 18; i < 22; i++) O13143[i] = + _CHROFF_39_6_;}
	{long i; for (i = 22; i < 24; i++) O13143[i] = + _CHROFF_47_6_;}
	O13143[24] = + _CHROFF_50_6_;
	O13143[25] = + _CHROFF_53_6_;
	O13143[26] = + _CHROFF_49_9_;
	O13143[27] = + _CHROFF_51_9_;
	{long i; for (i = 28; i < 30; i++) O13143[i] = + _CHROFF_49_9_;}
	{long i; for (i = 30; i < 32; i++) O13143[i] = + _CHROFF_59_11_;}
	O13143[32] = + _CHROFF_65_11_;
	O13143[33] = + _CHROFF_68_11_;
	O13143[34] = + _CHROFF_35_5_;
	O13143[35] = + _CHROFF_37_5_;
	O13143[36] = + _CHROFF_37_6_;
	O13143[37] = + _CHROFF_43_5_;
	O13143[38] = + _CHROFF_35_5_;
	O13143[39] = + _CHROFF_40_5_;
	{long i; for (i = 40; i < 43; i++) O13143[i] = + _CHROFF_37_5_;}
	{long i; for (i = 43; i < 45; i++) O13143[i] = + _CHROFF_36_5_;}
	{long i; for (i = 45; i < 47; i++) O13143[i] = + _CHROFF_37_5_;}
	O13143[47] = + _CHROFF_36_5_;
	O13143[48] = + _CHROFF_37_5_;
	O13143[49] = + _CHROFF_41_5_;
	O13143[50] = + _CHROFF_36_5_;
	O13143[51] = + _CHROFF_40_5_;
	{long i; for (i = 52; i < 55; i++) O13143[i] = + _CHROFF_35_5_;}
	O13143[55] = + _CHROFF_42_8_;
	O13143[56] = + _CHROFF_51_8_;
	O13143[57] = + _CHROFF_45_9_;
	O13143[58] = + _CHROFF_58_8_;
	O13143[59] = + _CHROFF_44_8_;
	O13143[60] = + _CHROFF_51_8_;
	{long i; for (i = 61; i < 64; i++) O13143[i] = + _CHROFF_44_8_;}
	{long i; for (i = 64; i < 66; i++) O13143[i] = + _CHROFF_46_8_;}
	O13143[66] = + _CHROFF_50_8_;
	O13143[67] = + _CHROFF_51_8_;
	O13143[68] = + _CHROFF_43_8_;
	O13143[69] = + _CHROFF_46_8_;
	O13143[70] = + _CHROFF_59_8_;
	O13143[71] = + _CHROFF_44_8_;
	O13143[72] = + _CHROFF_51_8_;
	{long i; for (i = 73; i < 76; i++) O13143[i] = + _CHROFF_42_8_;}
	O13143[76] = + _CHROFF_16_1_;
	O13143[77] = + _CHROFF_18_1_;
	O13143[78] = + _CHROFF_23_1_;
	{long i; for (i = 79; i < 81; i++) O13143[i] = + _CHROFF_16_1_;}
	O13143[81] = + _CHROFF_22_3_;
	{long i; for (i = 82; i < 84; i++) O13143[i] = + _CHROFF_20_1_;}
	{long i; for (i = 84; i < 86; i++) O13143[i] = + _CHROFF_25_1_;}
	{long i; for (i = 86; i < 88; i++) O13143[i] = + _CHROFF_21_3_;}
	{long i; for (i = 88; i < 92; i++) O13143[i] = + _CHROFF_17_2_;}
	O13143[92] = + _CHROFF_18_2_;
	{long i; for (i = 93; i < 96; i++) O13143[i] = + _CHROFF_23_4_;}
	O13143[96] = + _CHROFF_24_4_;
	O13143[97] = + _CHROFF_26_4_;
	O13143[98] = + _CHROFF_19_1_;
	O13143[99] = + _CHROFF_22_1_;
	{long i; for (i = 100; i < 102; i++) O13143[i] = + _CHROFF_21_5_;}
	{long i; for (i = 102; i < 104; i++) O13143[i] = + _CHROFF_29_8_;}
	O13143[105] = + _CHROFF_36_5_;
	O13143[108] = + _CHROFF_36_5_;
	O13143[110] = + _CHROFF_48_8_;
	O13143[113] = + _CHROFF_48_8_;
}

long O13148[114];
void O13148_init () {
	O13148[0] = + _I16OFF_13_5_4_;
	O13148[1] = + _I16OFF_16_7_4_;
	O13148[2] = + _I16OFF_35_9_4_;
	O13148[3] = + _I16OFF_42_12_6_;
	O13148[4] = + _I16OFF_37_9_4_;
	O13148[5] = + _I16OFF_46_12_6_;
	O13148[6] = + _I16OFF_37_9_4_;
	O13148[7] = + _I16OFF_38_9_4_;
	O13148[8] = + _I16OFF_37_9_4_;
	O13148[9] = + _I16OFF_47_12_6_;
	O13148[10] = + _I16OFF_49_12_6_;
	O13148[11] = + _I16OFF_47_12_6_;
	{long i; for (i = 12; i < 15; i++) O13148[i] = + _I16OFF_39_10_4_;}
	{long i; for (i = 15; i < 18; i++) O13148[i] = + _I16OFF_49_13_6_;}
	{long i; for (i = 18; i < 22; i++) O13148[i] = + _I16OFF_39_10_4_;}
	O13148[22] = + _I16OFF_47_12_4_;
	O13148[23] = + _I16OFF_47_14_4_;
	O13148[24] = + _I16OFF_50_13_4_;
	O13148[25] = + _I16OFF_53_13_4_;
	O13148[26] = + _I16OFF_49_13_6_;
	O13148[27] = + _I16OFF_51_13_6_;
	{long i; for (i = 28; i < 30; i++) O13148[i] = + _I16OFF_49_14_6_;}
	O13148[30] = + _I16OFF_59_21_6_;
	O13148[31] = + _I16OFF_59_23_6_;
	O13148[32] = + _I16OFF_65_25_6_;
	O13148[33] = + _I16OFF_68_26_6_;
	O13148[34] = + _I16OFF_35_9_4_;
	O13148[35] = + _I16OFF_37_9_4_;
	O13148[36] = + _I16OFF_37_10_4_;
	O13148[37] = + _I16OFF_43_9_4_;
	O13148[38] = + _I16OFF_35_9_4_;
	O13148[39] = + _I16OFF_40_9_4_;
	{long i; for (i = 40; i < 43; i++) O13148[i] = + _I16OFF_37_9_4_;}
	{long i; for (i = 43; i < 45; i++) O13148[i] = + _I16OFF_36_9_4_;}
	O13148[45] = + _I16OFF_37_9_4_;
	O13148[46] = + _I16OFF_37_10_4_;
	O13148[47] = + _I16OFF_36_9_4_;
	O13148[48] = + _I16OFF_37_9_4_;
	O13148[49] = + _I16OFF_41_9_4_;
	O13148[50] = + _I16OFF_36_9_4_;
	O13148[51] = + _I16OFF_40_12_4_;
	{long i; for (i = 52; i < 55; i++) O13148[i] = + _I16OFF_35_9_4_;}
	O13148[55] = + _I16OFF_42_13_6_;
	O13148[56] = + _I16OFF_51_13_6_;
	O13148[57] = + _I16OFF_45_16_6_;
	O13148[58] = + _I16OFF_58_14_6_;
	O13148[59] = + _I16OFF_44_13_6_;
	O13148[60] = + _I16OFF_51_15_6_;
	O13148[61] = + _I16OFF_44_13_6_;
	{long i; for (i = 62; i < 64; i++) O13148[i] = + _I16OFF_44_14_6_;}
	{long i; for (i = 64; i < 66; i++) O13148[i] = + _I16OFF_46_14_6_;}
	O13148[66] = + _I16OFF_50_13_6_;
	O13148[67] = + _I16OFF_51_14_6_;
	O13148[68] = + _I16OFF_43_13_6_;
	O13148[69] = + _I16OFF_46_14_6_;
	O13148[70] = + _I16OFF_59_16_6_;
	O13148[71] = + _I16OFF_44_15_6_;
	O13148[72] = + _I16OFF_51_18_6_;
	{long i; for (i = 73; i < 76; i++) O13148[i] = + _I16OFF_42_13_6_;}
	O13148[76] = + _I16OFF_16_5_4_;
	O13148[77] = + _I16OFF_18_5_4_;
	O13148[78] = + _I16OFF_23_5_4_;
	{long i; for (i = 79; i < 81; i++) O13148[i] = + _I16OFF_16_5_4_;}
	O13148[81] = + _I16OFF_22_8_4_;
	{long i; for (i = 82; i < 84; i++) O13148[i] = + _I16OFF_20_5_4_;}
	{long i; for (i = 84; i < 86; i++) O13148[i] = + _I16OFF_25_6_4_;}
	{long i; for (i = 86; i < 88; i++) O13148[i] = + _I16OFF_21_7_4_;}
	{long i; for (i = 88; i < 92; i++) O13148[i] = + _I16OFF_17_6_4_;}
	O13148[92] = + _I16OFF_18_6_4_;
	O13148[93] = + _I16OFF_23_8_4_;
	{long i; for (i = 94; i < 96; i++) O13148[i] = + _I16OFF_23_9_4_;}
	O13148[96] = + _I16OFF_24_9_4_;
	O13148[97] = + _I16OFF_26_8_4_;
	O13148[98] = + _I16OFF_19_5_4_;
	O13148[99] = + _I16OFF_22_5_4_;
	{long i; for (i = 100; i < 102; i++) O13148[i] = + _I16OFF_21_10_4_;}
	{long i; for (i = 102; i < 104; i++) O13148[i] = + _I16OFF_29_14_6_;}
	O13148[105] = + _I16OFF_36_10_4_;
	O13148[108] = + _I16OFF_36_9_4_;
	O13148[110] = + _I16OFF_48_19_6_;
	O13148[113] = + _I16OFF_48_18_6_;
}

long O13149[114];
void O13149_init () {
	O13149[0] = + _I16OFF_13_5_5_;
	O13149[1] = + _I16OFF_16_7_5_;
	O13149[2] = + _I16OFF_35_9_5_;
	O13149[3] = + _I16OFF_42_12_7_;
	O13149[4] = + _I16OFF_37_9_5_;
	O13149[5] = + _I16OFF_46_12_7_;
	O13149[6] = + _I16OFF_37_9_5_;
	O13149[7] = + _I16OFF_38_9_5_;
	O13149[8] = + _I16OFF_37_9_5_;
	O13149[9] = + _I16OFF_47_12_7_;
	O13149[10] = + _I16OFF_49_12_7_;
	O13149[11] = + _I16OFF_47_12_7_;
	{long i; for (i = 12; i < 15; i++) O13149[i] = + _I16OFF_39_10_5_;}
	{long i; for (i = 15; i < 18; i++) O13149[i] = + _I16OFF_49_13_7_;}
	{long i; for (i = 18; i < 22; i++) O13149[i] = + _I16OFF_39_10_5_;}
	O13149[22] = + _I16OFF_47_12_5_;
	O13149[23] = + _I16OFF_47_14_5_;
	O13149[24] = + _I16OFF_50_13_5_;
	O13149[25] = + _I16OFF_53_13_5_;
	O13149[26] = + _I16OFF_49_13_7_;
	O13149[27] = + _I16OFF_51_13_7_;
	{long i; for (i = 28; i < 30; i++) O13149[i] = + _I16OFF_49_14_7_;}
	O13149[30] = + _I16OFF_59_21_7_;
	O13149[31] = + _I16OFF_59_23_7_;
	O13149[32] = + _I16OFF_65_25_7_;
	O13149[33] = + _I16OFF_68_26_7_;
	O13149[34] = + _I16OFF_35_9_5_;
	O13149[35] = + _I16OFF_37_9_5_;
	O13149[36] = + _I16OFF_37_10_5_;
	O13149[37] = + _I16OFF_43_9_5_;
	O13149[38] = + _I16OFF_35_9_5_;
	O13149[39] = + _I16OFF_40_9_5_;
	{long i; for (i = 40; i < 43; i++) O13149[i] = + _I16OFF_37_9_5_;}
	{long i; for (i = 43; i < 45; i++) O13149[i] = + _I16OFF_36_9_5_;}
	O13149[45] = + _I16OFF_37_9_5_;
	O13149[46] = + _I16OFF_37_10_5_;
	O13149[47] = + _I16OFF_36_9_5_;
	O13149[48] = + _I16OFF_37_9_5_;
	O13149[49] = + _I16OFF_41_9_5_;
	O13149[50] = + _I16OFF_36_9_5_;
	O13149[51] = + _I16OFF_40_12_5_;
	{long i; for (i = 52; i < 55; i++) O13149[i] = + _I16OFF_35_9_5_;}
	O13149[55] = + _I16OFF_42_13_7_;
	O13149[56] = + _I16OFF_51_13_7_;
	O13149[57] = + _I16OFF_45_16_7_;
	O13149[58] = + _I16OFF_58_14_7_;
	O13149[59] = + _I16OFF_44_13_7_;
	O13149[60] = + _I16OFF_51_15_7_;
	O13149[61] = + _I16OFF_44_13_7_;
	{long i; for (i = 62; i < 64; i++) O13149[i] = + _I16OFF_44_14_7_;}
	{long i; for (i = 64; i < 66; i++) O13149[i] = + _I16OFF_46_14_7_;}
	O13149[66] = + _I16OFF_50_13_7_;
	O13149[67] = + _I16OFF_51_14_7_;
	O13149[68] = + _I16OFF_43_13_7_;
	O13149[69] = + _I16OFF_46_14_7_;
	O13149[70] = + _I16OFF_59_16_7_;
	O13149[71] = + _I16OFF_44_15_7_;
	O13149[72] = + _I16OFF_51_18_7_;
	{long i; for (i = 73; i < 76; i++) O13149[i] = + _I16OFF_42_13_7_;}
	O13149[76] = + _I16OFF_16_5_5_;
	O13149[77] = + _I16OFF_18_5_5_;
	O13149[78] = + _I16OFF_23_5_5_;
	{long i; for (i = 79; i < 81; i++) O13149[i] = + _I16OFF_16_5_5_;}
	O13149[81] = + _I16OFF_22_8_5_;
	{long i; for (i = 82; i < 84; i++) O13149[i] = + _I16OFF_20_5_5_;}
	{long i; for (i = 84; i < 86; i++) O13149[i] = + _I16OFF_25_6_5_;}
	{long i; for (i = 86; i < 88; i++) O13149[i] = + _I16OFF_21_7_5_;}
	{long i; for (i = 88; i < 92; i++) O13149[i] = + _I16OFF_17_6_5_;}
	O13149[92] = + _I16OFF_18_6_5_;
	O13149[93] = + _I16OFF_23_8_5_;
	{long i; for (i = 94; i < 96; i++) O13149[i] = + _I16OFF_23_9_5_;}
	O13149[96] = + _I16OFF_24_9_5_;
	O13149[97] = + _I16OFF_26_8_5_;
	O13149[98] = + _I16OFF_19_5_5_;
	O13149[99] = + _I16OFF_22_5_5_;
	{long i; for (i = 100; i < 102; i++) O13149[i] = + _I16OFF_21_10_5_;}
	{long i; for (i = 102; i < 104; i++) O13149[i] = + _I16OFF_29_14_7_;}
	O13149[105] = + _I16OFF_36_10_5_;
	O13149[108] = + _I16OFF_36_9_5_;
	O13149[110] = + _I16OFF_48_19_7_;
	O13149[113] = + _I16OFF_48_18_7_;
}

long O13151[114];
void O13151_init () {
	O13151[0] = + _CHROFF_13_4_;
	O13151[1] = + _CHROFF_16_6_;
	O13151[2] = + _CHROFF_35_8_;
	O13151[3] = + _CHROFF_42_11_;
	O13151[4] = + _CHROFF_37_8_;
	O13151[5] = + _CHROFF_46_11_;
	O13151[6] = + _CHROFF_37_8_;
	O13151[7] = + _CHROFF_38_8_;
	O13151[8] = + _CHROFF_37_8_;
	O13151[9] = + _CHROFF_47_11_;
	O13151[10] = + _CHROFF_49_11_;
	O13151[11] = + _CHROFF_47_11_;
	{long i; for (i = 12; i < 15; i++) O13151[i] = + _CHROFF_39_9_;}
	{long i; for (i = 15; i < 18; i++) O13151[i] = + _CHROFF_49_12_;}
	{long i; for (i = 18; i < 22; i++) O13151[i] = + _CHROFF_39_9_;}
	O13151[22] = + _CHROFF_47_11_;
	O13151[23] = + _CHROFF_47_13_;
	O13151[24] = + _CHROFF_50_12_;
	O13151[25] = + _CHROFF_53_12_;
	O13151[26] = + _CHROFF_49_12_;
	O13151[27] = + _CHROFF_51_12_;
	{long i; for (i = 28; i < 30; i++) O13151[i] = + _CHROFF_49_13_;}
	O13151[30] = + _CHROFF_59_20_;
	O13151[31] = + _CHROFF_59_22_;
	O13151[32] = + _CHROFF_65_24_;
	O13151[33] = + _CHROFF_68_25_;
	O13151[34] = + _CHROFF_35_8_;
	O13151[35] = + _CHROFF_37_8_;
	O13151[36] = + _CHROFF_37_9_;
	O13151[37] = + _CHROFF_43_8_;
	O13151[38] = + _CHROFF_35_8_;
	O13151[39] = + _CHROFF_40_8_;
	{long i; for (i = 40; i < 43; i++) O13151[i] = + _CHROFF_37_8_;}
	{long i; for (i = 43; i < 45; i++) O13151[i] = + _CHROFF_36_8_;}
	O13151[45] = + _CHROFF_37_8_;
	O13151[46] = + _CHROFF_37_9_;
	O13151[47] = + _CHROFF_36_8_;
	O13151[48] = + _CHROFF_37_8_;
	O13151[49] = + _CHROFF_41_8_;
	O13151[50] = + _CHROFF_36_8_;
	O13151[51] = + _CHROFF_40_11_;
	{long i; for (i = 52; i < 55; i++) O13151[i] = + _CHROFF_35_8_;}
	O13151[55] = + _CHROFF_42_12_;
	O13151[56] = + _CHROFF_51_12_;
	O13151[57] = + _CHROFF_45_15_;
	O13151[58] = + _CHROFF_58_13_;
	O13151[59] = + _CHROFF_44_12_;
	O13151[60] = + _CHROFF_51_14_;
	O13151[61] = + _CHROFF_44_12_;
	{long i; for (i = 62; i < 64; i++) O13151[i] = + _CHROFF_44_13_;}
	{long i; for (i = 64; i < 66; i++) O13151[i] = + _CHROFF_46_13_;}
	O13151[66] = + _CHROFF_50_12_;
	O13151[67] = + _CHROFF_51_13_;
	O13151[68] = + _CHROFF_43_12_;
	O13151[69] = + _CHROFF_46_13_;
	O13151[70] = + _CHROFF_59_15_;
	O13151[71] = + _CHROFF_44_14_;
	O13151[72] = + _CHROFF_51_17_;
	{long i; for (i = 73; i < 76; i++) O13151[i] = + _CHROFF_42_12_;}
	O13151[76] = + _CHROFF_16_4_;
	O13151[77] = + _CHROFF_18_4_;
	O13151[78] = + _CHROFF_23_4_;
	{long i; for (i = 79; i < 81; i++) O13151[i] = + _CHROFF_16_4_;}
	O13151[81] = + _CHROFF_22_7_;
	{long i; for (i = 82; i < 84; i++) O13151[i] = + _CHROFF_20_4_;}
	{long i; for (i = 84; i < 86; i++) O13151[i] = + _CHROFF_25_5_;}
	{long i; for (i = 86; i < 88; i++) O13151[i] = + _CHROFF_21_6_;}
	{long i; for (i = 88; i < 92; i++) O13151[i] = + _CHROFF_17_5_;}
	O13151[92] = + _CHROFF_18_5_;
	O13151[93] = + _CHROFF_23_7_;
	{long i; for (i = 94; i < 96; i++) O13151[i] = + _CHROFF_23_8_;}
	O13151[96] = + _CHROFF_24_8_;
	O13151[97] = + _CHROFF_26_7_;
	O13151[98] = + _CHROFF_19_4_;
	O13151[99] = + _CHROFF_22_4_;
	{long i; for (i = 100; i < 102; i++) O13151[i] = + _CHROFF_21_9_;}
	{long i; for (i = 102; i < 104; i++) O13151[i] = + _CHROFF_29_13_;}
	O13151[105] = + _CHROFF_36_9_;
	O13151[108] = + _CHROFF_36_8_;
	O13151[110] = + _CHROFF_48_16_;
	O13151[113] = + _CHROFF_48_15_;
}

long O13195[112];
void O13195_init () {
	O13195[0] =  + _REFACS_32_;
	O13195[1] =  + _REFACS_38_;
	O13195[2] =  + _REFACS_33_;
	O13195[3] =  + _REFACS_39_;
	O13195[4] =  + _REFACS_33_;
	O13195[5] =  + _REFACS_34_;
	O13195[6] =  + _REFACS_33_;
	O13195[7] =  + _REFACS_40_;
	O13195[8] =  + _REFACS_42_;
	O13195[9] =  + _REFACS_40_;
	{long i; for (i = 10; i < 13; i++) O13195[i] =  + _REFACS_35_;}
	{long i; for (i = 13; i < 16; i++) O13195[i] =  + _REFACS_42_;}
	{long i; for (i = 16; i < 20; i++) O13195[i] =  + _REFACS_35_;}
	{long i; for (i = 20; i < 22; i++) O13195[i] =  + _REFACS_39_;}
	{long i; for (i = 22; i < 24; i++) O13195[i] =  + _REFACS_42_;}
	O13195[24] =  + _REFACS_41_;
	O13195[25] =  + _REFACS_42_;
	{long i; for (i = 26; i < 28; i++) O13195[i] =  + _REFACS_41_;}
	{long i; for (i = 28; i < 30; i++) O13195[i] =  + _REFACS_46_;}
	{long i; for (i = 30; i < 32; i++) O13195[i] =  + _REFACS_49_;}
	O13195[32] =  + _REFACS_32_;
	{long i; for (i = 33; i < 35; i++) O13195[i] =  + _REFACS_34_;}
	O13195[35] =  + _REFACS_36_;
	O13195[36] =  + _REFACS_32_;
	O13195[37] =  + _REFACS_37_;
	{long i; for (i = 38; i < 43; i++) O13195[i] =  + _REFACS_33_;}
	{long i; for (i = 43; i < 45; i++) O13195[i] =  + _REFACS_34_;}
	O13195[45] =  + _REFACS_33_;
	O13195[46] =  + _REFACS_34_;
	O13195[47] =  + _REFACS_38_;
	O13195[48] =  + _REFACS_33_;
	O13195[49] =  + _REFACS_36_;
	{long i; for (i = 50; i < 53; i++) O13195[i] =  + _REFACS_32_;}
	O13195[53] =  + _REFACS_38_;
	{long i; for (i = 54; i < 56; i++) O13195[i] =  + _REFACS_41_;}
	O13195[56] =  + _REFACS_43_;
	O13195[57] =  + _REFACS_40_;
	O13195[58] =  + _REFACS_45_;
	{long i; for (i = 59; i < 62; i++) O13195[i] =  + _REFACS_39_;}
	{long i; for (i = 62; i < 64; i++) O13195[i] =  + _REFACS_42_;}
	{long i; for (i = 64; i < 66; i++) O13195[i] =  + _REFACS_41_;}
	O13195[66] =  + _REFACS_39_;
	O13195[67] =  + _REFACS_41_;
	O13195[68] =  + _REFACS_46_;
	O13195[69] =  + _REFACS_40_;
	O13195[70] =  + _REFACS_43_;
	{long i; for (i = 71; i < 74; i++) O13195[i] =  + _REFACS_38_;}
	O13195[103] =  + _REFACS_33_;
	O13195[106] =  + _REFACS_33_;
	O13195[108] =  + _REFACS_39_;
	O13195[111] =  + _REFACS_39_;
}

long O13196[112];
void O13196_init () {
	O13196[0] =  + _REFACS_33_;
	O13196[1] =  + _REFACS_39_;
	O13196[2] =  + _REFACS_34_;
	O13196[3] =  + _REFACS_40_;
	O13196[4] =  + _REFACS_34_;
	O13196[5] =  + _REFACS_35_;
	O13196[6] =  + _REFACS_34_;
	O13196[7] =  + _REFACS_41_;
	O13196[8] =  + _REFACS_43_;
	O13196[9] =  + _REFACS_41_;
	{long i; for (i = 10; i < 13; i++) O13196[i] =  + _REFACS_36_;}
	{long i; for (i = 13; i < 16; i++) O13196[i] =  + _REFACS_43_;}
	{long i; for (i = 16; i < 20; i++) O13196[i] =  + _REFACS_36_;}
	{long i; for (i = 20; i < 22; i++) O13196[i] =  + _REFACS_40_;}
	{long i; for (i = 22; i < 24; i++) O13196[i] =  + _REFACS_43_;}
	O13196[24] =  + _REFACS_42_;
	O13196[25] =  + _REFACS_43_;
	{long i; for (i = 26; i < 28; i++) O13196[i] =  + _REFACS_42_;}
	{long i; for (i = 28; i < 30; i++) O13196[i] =  + _REFACS_47_;}
	{long i; for (i = 30; i < 32; i++) O13196[i] =  + _REFACS_50_;}
	O13196[32] =  + _REFACS_33_;
	{long i; for (i = 33; i < 35; i++) O13196[i] =  + _REFACS_35_;}
	O13196[35] =  + _REFACS_37_;
	O13196[36] =  + _REFACS_33_;
	O13196[37] =  + _REFACS_38_;
	{long i; for (i = 38; i < 43; i++) O13196[i] =  + _REFACS_34_;}
	{long i; for (i = 43; i < 45; i++) O13196[i] =  + _REFACS_35_;}
	O13196[45] =  + _REFACS_34_;
	O13196[46] =  + _REFACS_35_;
	O13196[47] =  + _REFACS_39_;
	O13196[48] =  + _REFACS_34_;
	O13196[49] =  + _REFACS_37_;
	{long i; for (i = 50; i < 53; i++) O13196[i] =  + _REFACS_33_;}
	O13196[53] =  + _REFACS_39_;
	{long i; for (i = 54; i < 56; i++) O13196[i] =  + _REFACS_42_;}
	O13196[56] =  + _REFACS_44_;
	O13196[57] =  + _REFACS_41_;
	O13196[58] =  + _REFACS_46_;
	{long i; for (i = 59; i < 62; i++) O13196[i] =  + _REFACS_40_;}
	{long i; for (i = 62; i < 64; i++) O13196[i] =  + _REFACS_43_;}
	{long i; for (i = 64; i < 66; i++) O13196[i] =  + _REFACS_42_;}
	O13196[66] =  + _REFACS_40_;
	O13196[67] =  + _REFACS_42_;
	O13196[68] =  + _REFACS_47_;
	O13196[69] =  + _REFACS_41_;
	O13196[70] =  + _REFACS_44_;
	{long i; for (i = 71; i < 74; i++) O13196[i] =  + _REFACS_39_;}
	O13196[103] =  + _REFACS_34_;
	O13196[106] =  + _REFACS_34_;
	O13196[108] =  + _REFACS_40_;
	O13196[111] =  + _REFACS_40_;
}

long O13197[112];
void O13197_init () {
	O13197[0] =  + _REFACS_34_;
	O13197[1] =  + _REFACS_40_;
	O13197[2] =  + _REFACS_35_;
	O13197[3] =  + _REFACS_41_;
	O13197[4] =  + _REFACS_35_;
	O13197[5] =  + _REFACS_36_;
	O13197[6] =  + _REFACS_35_;
	O13197[7] =  + _REFACS_42_;
	O13197[8] =  + _REFACS_44_;
	O13197[9] =  + _REFACS_42_;
	{long i; for (i = 10; i < 13; i++) O13197[i] =  + _REFACS_37_;}
	{long i; for (i = 13; i < 16; i++) O13197[i] =  + _REFACS_44_;}
	{long i; for (i = 16; i < 20; i++) O13197[i] =  + _REFACS_37_;}
	{long i; for (i = 20; i < 22; i++) O13197[i] =  + _REFACS_41_;}
	{long i; for (i = 22; i < 24; i++) O13197[i] =  + _REFACS_44_;}
	O13197[24] =  + _REFACS_43_;
	O13197[25] =  + _REFACS_44_;
	{long i; for (i = 26; i < 28; i++) O13197[i] =  + _REFACS_43_;}
	{long i; for (i = 28; i < 30; i++) O13197[i] =  + _REFACS_48_;}
	{long i; for (i = 30; i < 32; i++) O13197[i] =  + _REFACS_51_;}
	O13197[32] =  + _REFACS_34_;
	{long i; for (i = 33; i < 35; i++) O13197[i] =  + _REFACS_36_;}
	O13197[35] =  + _REFACS_38_;
	O13197[36] =  + _REFACS_34_;
	O13197[37] =  + _REFACS_39_;
	{long i; for (i = 38; i < 43; i++) O13197[i] =  + _REFACS_35_;}
	{long i; for (i = 43; i < 45; i++) O13197[i] =  + _REFACS_36_;}
	O13197[45] =  + _REFACS_35_;
	O13197[46] =  + _REFACS_36_;
	O13197[47] =  + _REFACS_40_;
	O13197[48] =  + _REFACS_35_;
	O13197[49] =  + _REFACS_38_;
	{long i; for (i = 50; i < 53; i++) O13197[i] =  + _REFACS_34_;}
	O13197[53] =  + _REFACS_40_;
	{long i; for (i = 54; i < 56; i++) O13197[i] =  + _REFACS_43_;}
	O13197[56] =  + _REFACS_45_;
	O13197[57] =  + _REFACS_42_;
	O13197[58] =  + _REFACS_47_;
	{long i; for (i = 59; i < 62; i++) O13197[i] =  + _REFACS_41_;}
	{long i; for (i = 62; i < 64; i++) O13197[i] =  + _REFACS_44_;}
	{long i; for (i = 64; i < 66; i++) O13197[i] =  + _REFACS_43_;}
	O13197[66] =  + _REFACS_41_;
	O13197[67] =  + _REFACS_43_;
	O13197[68] =  + _REFACS_48_;
	O13197[69] =  + _REFACS_42_;
	O13197[70] =  + _REFACS_45_;
	{long i; for (i = 71; i < 74; i++) O13197[i] =  + _REFACS_40_;}
	O13197[103] =  + _REFACS_35_;
	O13197[106] =  + _REFACS_35_;
	O13197[108] =  + _REFACS_41_;
	O13197[111] =  + _REFACS_41_;
}

long O13227[111];
void O13227_init () {
	O13227[0] = + _LNGOFF_42_12_10_2_;
	O13227[2] = + _LNGOFF_46_12_10_2_;
	O13227[6] = + _LNGOFF_47_12_10_3_;
	O13227[7] = + _LNGOFF_49_12_10_5_;
	O13227[8] = + _LNGOFF_47_12_10_3_;
	{long i; for (i = 12; i < 15; i++) O13227[i] = + _LNGOFF_49_13_10_3_;}
	O13227[23] = + _LNGOFF_49_13_10_2_;
	O13227[24] = + _LNGOFF_51_13_10_2_;
	{long i; for (i = 25; i < 27; i++) O13227[i] = + _LNGOFF_49_14_10_2_;}
	O13227[27] = + _LNGOFF_59_21_10_2_;
	O13227[28] = + _LNGOFF_59_23_10_2_;
	O13227[29] = + _LNGOFF_65_25_10_2_;
	O13227[30] = + _LNGOFF_68_26_10_2_;
	O13227[52] = + _LNGOFF_42_13_10_2_;
	O13227[53] = + _LNGOFF_51_13_10_5_;
	O13227[54] = + _LNGOFF_45_16_10_3_;
	O13227[55] = + _LNGOFF_58_14_10_5_;
	O13227[56] = + _LNGOFF_44_13_10_2_;
	O13227[57] = + _LNGOFF_51_15_10_5_;
	O13227[58] = + _LNGOFF_44_13_10_2_;
	{long i; for (i = 59; i < 61; i++) O13227[i] = + _LNGOFF_44_14_10_2_;}
	{long i; for (i = 61; i < 63; i++) O13227[i] = + _LNGOFF_46_14_10_2_;}
	O13227[63] = + _LNGOFF_50_13_10_5_;
	O13227[64] = + _LNGOFF_51_14_10_5_;
	O13227[65] = + _LNGOFF_43_13_10_2_;
	O13227[66] = + _LNGOFF_46_14_10_2_;
	O13227[67] = + _LNGOFF_59_16_10_5_;
	O13227[68] = + _LNGOFF_44_15_10_2_;
	O13227[69] = + _LNGOFF_51_18_10_2_;
	{long i; for (i = 70; i < 73; i++) O13227[i] = + _LNGOFF_42_13_10_2_;}
	O13227[107] = + _LNGOFF_48_19_10_2_;
	O13227[110] = + _LNGOFF_48_18_10_2_;
}

long O13228[111];
void O13228_init () {
	O13228[0] = + _LNGOFF_42_12_10_3_;
	O13228[2] = + _LNGOFF_46_12_10_3_;
	O13228[6] = + _LNGOFF_47_12_10_4_;
	O13228[7] = + _LNGOFF_49_12_10_6_;
	O13228[8] = + _LNGOFF_47_12_10_4_;
	{long i; for (i = 12; i < 15; i++) O13228[i] = + _LNGOFF_49_13_10_4_;}
	O13228[23] = + _LNGOFF_49_13_10_3_;
	O13228[24] = + _LNGOFF_51_13_10_3_;
	{long i; for (i = 25; i < 27; i++) O13228[i] = + _LNGOFF_49_14_10_3_;}
	O13228[27] = + _LNGOFF_59_21_10_3_;
	O13228[28] = + _LNGOFF_59_23_10_3_;
	O13228[29] = + _LNGOFF_65_25_10_3_;
	O13228[30] = + _LNGOFF_68_26_10_3_;
	O13228[52] = + _LNGOFF_42_13_10_3_;
	O13228[53] = + _LNGOFF_51_13_10_6_;
	O13228[54] = + _LNGOFF_45_16_10_4_;
	O13228[55] = + _LNGOFF_58_14_10_6_;
	O13228[56] = + _LNGOFF_44_13_10_3_;
	O13228[57] = + _LNGOFF_51_15_10_6_;
	O13228[58] = + _LNGOFF_44_13_10_3_;
	{long i; for (i = 59; i < 61; i++) O13228[i] = + _LNGOFF_44_14_10_3_;}
	{long i; for (i = 61; i < 63; i++) O13228[i] = + _LNGOFF_46_14_10_3_;}
	O13228[63] = + _LNGOFF_50_13_10_6_;
	O13228[64] = + _LNGOFF_51_14_10_6_;
	O13228[65] = + _LNGOFF_43_13_10_3_;
	O13228[66] = + _LNGOFF_46_14_10_3_;
	O13228[67] = + _LNGOFF_59_16_10_6_;
	O13228[68] = + _LNGOFF_44_15_10_3_;
	O13228[69] = + _LNGOFF_51_18_10_3_;
	{long i; for (i = 70; i < 73; i++) O13228[i] = + _LNGOFF_42_13_10_3_;}
	O13228[107] = + _LNGOFF_48_19_10_3_;
	O13228[110] = + _LNGOFF_48_18_10_3_;
}

long O13229[111];
void O13229_init () {
	O13229[0] = + _LNGOFF_42_12_10_4_;
	O13229[2] = + _LNGOFF_46_12_10_4_;
	O13229[6] = + _LNGOFF_47_12_10_5_;
	O13229[7] = + _LNGOFF_49_12_10_7_;
	O13229[8] = + _LNGOFF_47_12_10_5_;
	{long i; for (i = 12; i < 15; i++) O13229[i] = + _LNGOFF_49_13_10_5_;}
	O13229[23] = + _LNGOFF_49_13_10_4_;
	O13229[24] = + _LNGOFF_51_13_10_4_;
	{long i; for (i = 25; i < 27; i++) O13229[i] = + _LNGOFF_49_14_10_4_;}
	O13229[27] = + _LNGOFF_59_21_10_4_;
	O13229[28] = + _LNGOFF_59_23_10_4_;
	O13229[29] = + _LNGOFF_65_25_10_4_;
	O13229[30] = + _LNGOFF_68_26_10_4_;
	O13229[52] = + _LNGOFF_42_13_10_4_;
	O13229[53] = + _LNGOFF_51_13_10_7_;
	O13229[54] = + _LNGOFF_45_16_10_5_;
	O13229[55] = + _LNGOFF_58_14_10_7_;
	O13229[56] = + _LNGOFF_44_13_10_4_;
	O13229[57] = + _LNGOFF_51_15_10_7_;
	O13229[58] = + _LNGOFF_44_13_10_4_;
	{long i; for (i = 59; i < 61; i++) O13229[i] = + _LNGOFF_44_14_10_4_;}
	{long i; for (i = 61; i < 63; i++) O13229[i] = + _LNGOFF_46_14_10_4_;}
	O13229[63] = + _LNGOFF_50_13_10_7_;
	O13229[64] = + _LNGOFF_51_14_10_7_;
	O13229[65] = + _LNGOFF_43_13_10_4_;
	O13229[66] = + _LNGOFF_46_14_10_4_;
	O13229[67] = + _LNGOFF_59_16_10_7_;
	O13229[68] = + _LNGOFF_44_15_10_4_;
	O13229[69] = + _LNGOFF_51_18_10_4_;
	{long i; for (i = 70; i < 73; i++) O13229[i] = + _LNGOFF_42_13_10_4_;}
	O13229[107] = + _LNGOFF_48_19_10_4_;
	O13229[110] = + _LNGOFF_48_18_10_4_;
}

long O13230[111];
void O13230_init () {
	O13230[0] = + _LNGOFF_42_12_10_5_;
	O13230[2] = + _LNGOFF_46_12_10_5_;
	O13230[6] = + _LNGOFF_47_12_10_6_;
	O13230[7] = + _LNGOFF_49_12_10_8_;
	O13230[8] = + _LNGOFF_47_12_10_6_;
	{long i; for (i = 12; i < 15; i++) O13230[i] = + _LNGOFF_49_13_10_6_;}
	O13230[23] = + _LNGOFF_49_13_10_5_;
	O13230[24] = + _LNGOFF_51_13_10_5_;
	{long i; for (i = 25; i < 27; i++) O13230[i] = + _LNGOFF_49_14_10_5_;}
	O13230[27] = + _LNGOFF_59_21_10_5_;
	O13230[28] = + _LNGOFF_59_23_10_5_;
	O13230[29] = + _LNGOFF_65_25_10_5_;
	O13230[30] = + _LNGOFF_68_26_10_5_;
	O13230[52] = + _LNGOFF_42_13_10_5_;
	O13230[53] = + _LNGOFF_51_13_10_8_;
	O13230[54] = + _LNGOFF_45_16_10_6_;
	O13230[55] = + _LNGOFF_58_14_10_8_;
	O13230[56] = + _LNGOFF_44_13_10_5_;
	O13230[57] = + _LNGOFF_51_15_10_8_;
	O13230[58] = + _LNGOFF_44_13_10_5_;
	{long i; for (i = 59; i < 61; i++) O13230[i] = + _LNGOFF_44_14_10_5_;}
	{long i; for (i = 61; i < 63; i++) O13230[i] = + _LNGOFF_46_14_10_5_;}
	O13230[63] = + _LNGOFF_50_13_10_8_;
	O13230[64] = + _LNGOFF_51_14_10_8_;
	O13230[65] = + _LNGOFF_43_13_10_5_;
	O13230[66] = + _LNGOFF_46_14_10_5_;
	O13230[67] = + _LNGOFF_59_16_10_8_;
	O13230[68] = + _LNGOFF_44_15_10_5_;
	O13230[69] = + _LNGOFF_51_18_10_5_;
	{long i; for (i = 70; i < 73; i++) O13230[i] = + _LNGOFF_42_13_10_5_;}
	O13230[107] = + _LNGOFF_48_19_10_5_;
	O13230[110] = + _LNGOFF_48_18_10_5_;
}

long O13235[111];
void O13235_init () {
	O13235[0] =  + _REFACS_41_;
	O13235[2] =  + _REFACS_42_;
	O13235[6] =  + _REFACS_43_;
	O13235[7] =  + _REFACS_45_;
	O13235[8] =  + _REFACS_43_;
	{long i; for (i = 12; i < 15; i++) O13235[i] =  + _REFACS_45_;}
	O13235[23] =  + _REFACS_44_;
	O13235[24] =  + _REFACS_45_;
	{long i; for (i = 25; i < 27; i++) O13235[i] =  + _REFACS_44_;}
	{long i; for (i = 27; i < 29; i++) O13235[i] =  + _REFACS_49_;}
	{long i; for (i = 29; i < 31; i++) O13235[i] =  + _REFACS_52_;}
	O13235[52] =  + _REFACS_41_;
	{long i; for (i = 53; i < 55; i++) O13235[i] =  + _REFACS_44_;}
	O13235[55] =  + _REFACS_46_;
	O13235[56] =  + _REFACS_43_;
	O13235[57] =  + _REFACS_48_;
	{long i; for (i = 58; i < 61; i++) O13235[i] =  + _REFACS_42_;}
	{long i; for (i = 61; i < 63; i++) O13235[i] =  + _REFACS_45_;}
	{long i; for (i = 63; i < 65; i++) O13235[i] =  + _REFACS_44_;}
	O13235[65] =  + _REFACS_42_;
	O13235[66] =  + _REFACS_44_;
	O13235[67] =  + _REFACS_49_;
	O13235[68] =  + _REFACS_43_;
	O13235[69] =  + _REFACS_46_;
	{long i; for (i = 70; i < 73; i++) O13235[i] =  + _REFACS_41_;}
	O13235[107] =  + _REFACS_42_;
	O13235[110] =  + _REFACS_42_;
}

long O13244[111];
void O13244_init () {
	O13244[0] = + _I16OFF_42_12_8_;
	O13244[2] = + _I16OFF_46_12_8_;
	O13244[6] = + _I16OFF_47_12_8_;
	O13244[7] = + _I16OFF_49_12_8_;
	O13244[8] = + _I16OFF_47_12_8_;
	{long i; for (i = 12; i < 15; i++) O13244[i] = + _I16OFF_49_13_8_;}
	O13244[23] = + _I16OFF_49_13_8_;
	O13244[24] = + _I16OFF_51_13_8_;
	{long i; for (i = 25; i < 27; i++) O13244[i] = + _I16OFF_49_14_8_;}
	O13244[27] = + _I16OFF_59_21_8_;
	O13244[28] = + _I16OFF_59_23_8_;
	O13244[29] = + _I16OFF_65_25_8_;
	O13244[30] = + _I16OFF_68_26_8_;
	O13244[52] = + _I16OFF_42_13_8_;
	O13244[53] = + _I16OFF_51_13_8_;
	O13244[54] = + _I16OFF_45_16_8_;
	O13244[55] = + _I16OFF_58_14_8_;
	O13244[56] = + _I16OFF_44_13_8_;
	O13244[57] = + _I16OFF_51_15_8_;
	O13244[58] = + _I16OFF_44_13_8_;
	{long i; for (i = 59; i < 61; i++) O13244[i] = + _I16OFF_44_14_8_;}
	{long i; for (i = 61; i < 63; i++) O13244[i] = + _I16OFF_46_14_8_;}
	O13244[63] = + _I16OFF_50_13_8_;
	O13244[64] = + _I16OFF_51_14_8_;
	O13244[65] = + _I16OFF_43_13_8_;
	O13244[66] = + _I16OFF_46_14_8_;
	O13244[67] = + _I16OFF_59_16_8_;
	O13244[68] = + _I16OFF_44_15_8_;
	O13244[69] = + _I16OFF_51_18_8_;
	{long i; for (i = 70; i < 73; i++) O13244[i] = + _I16OFF_42_13_8_;}
	O13244[107] = + _I16OFF_48_19_8_;
	O13244[110] = + _I16OFF_48_18_8_;
}

long O13245[111];
void O13245_init () {
	O13245[0] = + _I16OFF_42_12_9_;
	O13245[2] = + _I16OFF_46_12_9_;
	O13245[6] = + _I16OFF_47_12_9_;
	O13245[7] = + _I16OFF_49_12_9_;
	O13245[8] = + _I16OFF_47_12_9_;
	{long i; for (i = 12; i < 15; i++) O13245[i] = + _I16OFF_49_13_9_;}
	O13245[23] = + _I16OFF_49_13_9_;
	O13245[24] = + _I16OFF_51_13_9_;
	{long i; for (i = 25; i < 27; i++) O13245[i] = + _I16OFF_49_14_9_;}
	O13245[27] = + _I16OFF_59_21_9_;
	O13245[28] = + _I16OFF_59_23_9_;
	O13245[29] = + _I16OFF_65_25_9_;
	O13245[30] = + _I16OFF_68_26_9_;
	O13245[52] = + _I16OFF_42_13_9_;
	O13245[53] = + _I16OFF_51_13_9_;
	O13245[54] = + _I16OFF_45_16_9_;
	O13245[55] = + _I16OFF_58_14_9_;
	O13245[56] = + _I16OFF_44_13_9_;
	O13245[57] = + _I16OFF_51_15_9_;
	O13245[58] = + _I16OFF_44_13_9_;
	{long i; for (i = 59; i < 61; i++) O13245[i] = + _I16OFF_44_14_9_;}
	{long i; for (i = 61; i < 63; i++) O13245[i] = + _I16OFF_46_14_9_;}
	O13245[63] = + _I16OFF_50_13_9_;
	O13245[64] = + _I16OFF_51_14_9_;
	O13245[65] = + _I16OFF_43_13_9_;
	O13245[66] = + _I16OFF_46_14_9_;
	O13245[67] = + _I16OFF_59_16_9_;
	O13245[68] = + _I16OFF_44_15_9_;
	O13245[69] = + _I16OFF_51_18_9_;
	{long i; for (i = 70; i < 73; i++) O13245[i] = + _I16OFF_42_13_9_;}
	O13245[107] = + _I16OFF_48_19_9_;
	O13245[110] = + _I16OFF_48_18_9_;
}

long O13273[29];
void O13273_init () {
	O13273[0] =  + _REFACS_44_;
	O13273[4] =  + _REFACS_45_;
	O13273[5] =  + _REFACS_47_;
	O13273[6] =  + _REFACS_45_;
	{long i; for (i = 10; i < 13; i++) O13273[i] =  + _REFACS_47_;}
	O13273[21] =  + _REFACS_46_;
	O13273[22] =  + _REFACS_47_;
	{long i; for (i = 23; i < 25; i++) O13273[i] =  + _REFACS_46_;}
	{long i; for (i = 25; i < 27; i++) O13273[i] =  + _REFACS_51_;}
	{long i; for (i = 27; i < 29; i++) O13273[i] =  + _REFACS_54_;}
}

long O13287[29];
void O13287_init () {
	O13287[0] =  + _REFACS_45_;
	O13287[4] =  + _REFACS_46_;
	O13287[5] =  + _REFACS_48_;
	O13287[6] =  + _REFACS_46_;
	{long i; for (i = 10; i < 13; i++) O13287[i] =  + _REFACS_48_;}
	O13287[21] =  + _REFACS_47_;
	O13287[22] =  + _REFACS_48_;
	{long i; for (i = 23; i < 25; i++) O13287[i] =  + _REFACS_47_;}
	{long i; for (i = 25; i < 27; i++) O13287[i] =  + _REFACS_52_;}
	{long i; for (i = 27; i < 29; i++) O13287[i] =  + _REFACS_55_;}
}

long O13358[12];
void O13358_init () {
	{long i; for (i = 0; i < 2; i++) O13358[i] =  + _REFACS_43_;}
	{long i; for (i = 2; i < 4; i++) O13358[i] =  + _REFACS_46_;}
	{long i; for (i = 8; i < 10; i++) O13358[i] =  + _REFACS_53_;}
	{long i; for (i = 10; i < 12; i++) O13358[i] =  + _REFACS_56_;}
}

long O13359[12];
void O13359_init () {
	{long i; for (i = 0; i < 2; i++) O13359[i] =  + _REFACS_44_;}
	{long i; for (i = 2; i < 4; i++) O13359[i] =  + _REFACS_47_;}
	{long i; for (i = 8; i < 10; i++) O13359[i] =  + _REFACS_54_;}
	{long i; for (i = 10; i < 12; i++) O13359[i] =  + _REFACS_57_;}
}

long O13365[12];
void O13365_init () {
	{long i; for (i = 0; i < 2; i++) O13365[i] = + _CHROFF_47_8_;}
	O13365[2] = + _CHROFF_50_8_;
	O13365[3] = + _CHROFF_53_8_;
	{long i; for (i = 8; i < 10; i++) O13365[i] = + _CHROFF_59_13_;}
	O13365[10] = + _CHROFF_65_13_;
	O13365[11] = + _CHROFF_68_13_;
}

long O13386[12];
void O13386_init () {
	{long i; for (i = 0; i < 2; i++) O13386[i] =  + _REFACS_45_;}
	{long i; for (i = 2; i < 4; i++) O13386[i] =  + _REFACS_48_;}
	{long i; for (i = 8; i < 10; i++) O13386[i] =  + _REFACS_55_;}
	{long i; for (i = 10; i < 12; i++) O13386[i] =  + _REFACS_58_;}
}

long O13389[12];
void O13389_init () {
	{long i; for (i = 0; i < 2; i++) O13389[i] = + _CHROFF_47_9_;}
	O13389[2] = + _CHROFF_50_9_;
	O13389[3] = + _CHROFF_53_9_;
	{long i; for (i = 8; i < 10; i++) O13389[i] = + _CHROFF_59_14_;}
	O13389[10] = + _CHROFF_65_14_;
	O13389[11] = + _CHROFF_68_14_;
}

long O13390[12];
void O13390_init () {
	{long i; for (i = 0; i < 2; i++) O13390[i] =  + _REFACS_46_;}
	{long i; for (i = 2; i < 4; i++) O13390[i] =  + _REFACS_49_;}
	{long i; for (i = 8; i < 10; i++) O13390[i] =  + _REFACS_56_;}
	{long i; for (i = 10; i < 12; i++) O13390[i] =  + _REFACS_59_;}
}

long O13406[10];
void O13406_init () {
	O13406[0] = + _CHROFF_50_10_;
	O13406[1] = + _CHROFF_53_10_;
	O13406[8] = + _CHROFF_65_15_;
	O13406[9] = + _CHROFF_68_15_;
}

long O13427[8];
void O13427_init () {
	O13427[0] =  + _REFACS_48_;
	O13427[1] =  + _REFACS_49_;
	{long i; for (i = 2; i < 4; i++) O13427[i] =  + _REFACS_48_;}
	{long i; for (i = 4; i < 6; i++) O13427[i] =  + _REFACS_57_;}
	O13427[6] =  + _REFACS_60_;
	O13427[7] =  + _REFACS_63_;
}

long O13453[4];
void O13453_init () {
	O13453[0] = + _CHROFF_59_15_;
	O13453[1] = + _CHROFF_59_17_;
	O13453[2] = + _CHROFF_65_16_;
	O13453[3] = + _CHROFF_68_16_;
}

long O13454[4];
void O13454_init () {
	O13454[0] = + _CHROFF_59_16_;
	O13454[1] = + _CHROFF_59_18_;
	O13454[2] = + _CHROFF_65_17_;
	O13454[3] = + _CHROFF_68_17_;
}

long O13455[4];
void O13455_init () {
	O13455[0] = + _CHROFF_59_17_;
	O13455[1] = + _CHROFF_59_19_;
	O13455[2] = + _CHROFF_65_18_;
	O13455[3] = + _CHROFF_68_18_;
}

long O13457[4];
void O13457_init () {
	O13457[0] = + _CHROFF_59_18_;
	O13457[1] = + _CHROFF_59_20_;
	O13457[2] = + _CHROFF_65_19_;
	O13457[3] = + _CHROFF_68_19_;
}

long O13459[4];
void O13459_init () {
	O13459[0] = + _PTROFF_59_21_10_11_0_1_;
	O13459[1] = + _PTROFF_59_23_10_11_0_1_;
	O13459[2] = + _PTROFF_65_25_10_11_0_1_;
	O13459[3] = + _PTROFF_68_26_10_11_0_1_;
}

long O13461[4];
void O13461_init () {
	O13461[0] = + _LNGOFF_59_21_10_6_;
	O13461[1] = + _LNGOFF_59_23_10_6_;
	O13461[2] = + _LNGOFF_65_25_10_6_;
	O13461[3] = + _LNGOFF_68_26_10_6_;
}

long O13462[4];
void O13462_init () {
	O13462[0] = + _LNGOFF_59_21_10_7_;
	O13462[1] = + _LNGOFF_59_23_10_7_;
	O13462[2] = + _LNGOFF_65_25_10_7_;
	O13462[3] = + _LNGOFF_68_26_10_7_;
}

long O13467[4];
void O13467_init () {
	O13467[0] = + _LNGOFF_59_21_10_8_;
	O13467[1] = + _LNGOFF_59_23_10_8_;
	O13467[2] = + _LNGOFF_65_25_10_8_;
	O13467[3] = + _LNGOFF_68_26_10_8_;
}

long O13482[4];
void O13482_init () {
	O13482[0] = + _PTROFF_59_21_10_11_0_2_;
	O13482[1] = + _PTROFF_59_23_10_11_0_2_;
	O13482[2] = + _PTROFF_65_25_10_11_0_2_;
	O13482[3] = + _PTROFF_68_26_10_11_0_2_;
}

long O13483[4];
void O13483_init () {
	O13483[0] = + _PTROFF_59_21_10_11_0_3_;
	O13483[1] = + _PTROFF_59_23_10_11_0_3_;
	O13483[2] = + _PTROFF_65_25_10_11_0_3_;
	O13483[3] = + _PTROFF_68_26_10_11_0_3_;
}

long O13485[4];
void O13485_init () {
	O13485[0] = + _LNGOFF_59_21_10_9_;
	O13485[1] = + _LNGOFF_59_23_10_9_;
	O13485[2] = + _LNGOFF_65_25_10_9_;
	O13485[3] = + _LNGOFF_68_26_10_9_;
}

long O13486[4];
void O13486_init () {
	O13486[0] = + _LNGOFF_59_21_10_10_;
	O13486[1] = + _LNGOFF_59_23_10_10_;
	O13486[2] = + _LNGOFF_65_25_10_10_;
	O13486[3] = + _LNGOFF_68_26_10_10_;
}

long O13492[2];
void O13492_init () {
	O13492[0] = + _CHROFF_65_20_;
	O13492[1] = + _CHROFF_68_20_;
}

long O13493[2];
void O13493_init () {
	O13493[0] =  + _REFACS_62_;
	O13493[1] =  + _REFACS_65_;
}

long O13496[2];
void O13496_init () {
	O13496[0] = + _CHROFF_65_21_;
	O13496[1] = + _CHROFF_68_21_;
}

long O13497[2];
void O13497_init () {
	O13497[0] = + _CHROFF_65_22_;
	O13497[1] = + _CHROFF_68_22_;
}

long O13675[59];
void O13675_init () {
	O13675[0] = + _CHROFF_42_10_;
	O13675[1] = + _CHROFF_51_10_;
	O13675[2] = + _CHROFF_45_11_;
	O13675[3] = + _CHROFF_58_10_;
	O13675[4] = + _CHROFF_44_10_;
	O13675[5] = + _CHROFF_51_10_;
	{long i; for (i = 6; i < 9; i++) O13675[i] = + _CHROFF_44_10_;}
	{long i; for (i = 9; i < 11; i++) O13675[i] = + _CHROFF_46_10_;}
	O13675[11] = + _CHROFF_50_10_;
	O13675[12] = + _CHROFF_51_11_;
	O13675[13] = + _CHROFF_43_10_;
	O13675[14] = + _CHROFF_46_10_;
	O13675[15] = + _CHROFF_59_10_;
	O13675[16] = + _CHROFF_44_10_;
	O13675[17] = + _CHROFF_51_13_;
	{long i; for (i = 18; i < 21; i++) O13675[i] = + _CHROFF_42_10_;}
	O13675[55] = + _CHROFF_48_10_;
	O13675[58] = + _CHROFF_48_10_;
}

long O13900[18];
void O13900_init () {
	{long i; for (i = 0; i < 2; i++) O13900[i] =  + _REFACS_20_;}
	{long i; for (i = 7; i < 11; i++) O13900[i] =  + _REFACS_22_;}
	O13900[11] =  + _REFACS_25_;
	{long i; for (i = 16; i < 18; i++) O13900[i] =  + _REFACS_26_;}
}

long O13906[5];
void O13906_init () {
	O13906[0] = + _PTROFF_23_8_6_1_0_3_;
	{long i; for (i = 1; i < 3; i++) O13906[i] = + _PTROFF_23_9_6_1_0_3_;}
	O13906[3] = + _PTROFF_24_9_6_1_0_3_;
	O13906[4] = + _PTROFF_26_8_6_2_0_3_;
}

long O13968[10];
void O13968_init () {
	O13968[0] = + _LNGOFF_1_1_0_0_;
	O13968[1] = + _LNGOFF_36_10_6_1_;
	{long i; for (i = 2; i < 4; i++) O13968[i] = + _LNGOFF_1_1_0_0_;}
	O13968[4] = + _LNGOFF_36_9_6_1_;
	O13968[5] = + _LNGOFF_6_5_0_0_;
	O13968[6] = + _LNGOFF_48_19_10_6_;
	O13968[7] = + _LNGOFF_6_5_0_0_;
	O13968[8] = + _LNGOFF_6_7_0_0_;
	O13968[9] = + _LNGOFF_48_18_10_6_;
}

long O14044[5];
void O14044_init () {
	O14044[0] = + _PTROFF_6_5_0_3_0_0_;
	O14044[1] = + _PTROFF_48_19_10_9_0_1_;
	O14044[2] = + _PTROFF_6_5_0_3_0_0_;
	O14044[3] = + _PTROFF_6_7_0_5_0_0_;
	O14044[4] = + _PTROFF_48_18_10_9_0_1_;
}

long O14052[5];
void O14052_init () {
	O14052[0] = + _CHROFF_6_3_;
	O14052[1] = + _CHROFF_48_17_;
	O14052[2] = + _CHROFF_6_3_;
	O14052[3] = + _CHROFF_6_5_;
	O14052[4] = + _CHROFF_48_16_;
}

long O14053[5];
void O14053_init () {
	O14053[0] = + _CHROFF_6_4_;
	O14053[1] = + _CHROFF_48_18_;
	O14053[2] = + _CHROFF_6_4_;
	O14053[3] = + _CHROFF_6_6_;
	O14053[4] = + _CHROFF_48_17_;
}

long O14057[5];
void O14057_init () {
	O14057[0] = + _CHROFF_6_0_;
	O14057[1] = + _CHROFF_48_12_;
	{long i; for (i = 2; i < 4; i++) O14057[i] = + _CHROFF_6_0_;}
	O14057[4] = + _CHROFF_48_11_;
}

long O14058[5];
void O14058_init () {
	O14058[0] = + _R64OFF_6_5_0_3_0_1_0_0_;
	O14058[1] = + _R64OFF_48_19_10_9_0_3_0_0_;
	O14058[2] = + _R64OFF_6_5_0_3_0_2_0_0_;
	O14058[3] = + _R64OFF_6_7_0_5_0_5_0_0_;
	O14058[4] = + _R64OFF_48_18_10_9_0_4_0_0_;
}

long O14077[5];
void O14077_init () {
	O14077[0] =  + _REFACS_2_;
	O14077[1] =  + _REFACS_44_;
	{long i; for (i = 2; i < 4; i++) O14077[i] =  + _REFACS_2_;}
	O14077[4] =  + _REFACS_44_;
}

long O14078[5];
void O14078_init () {
	O14078[0] =  + _REFACS_3_;
	O14078[1] =  + _REFACS_45_;
	{long i; for (i = 2; i < 4; i++) O14078[i] =  + _REFACS_3_;}
	O14078[4] =  + _REFACS_45_;
}

long O14082[5];
void O14082_init () {
	O14082[0] =  + _REFACS_4_;
	O14082[1] =  + _REFACS_46_;
	{long i; for (i = 2; i < 4; i++) O14082[i] =  + _REFACS_4_;}
	O14082[4] =  + _REFACS_46_;
}

long O14083[5];
void O14083_init () {
	O14083[0] = + _CHROFF_6_1_;
	O14083[1] = + _CHROFF_48_13_;
	{long i; for (i = 2; i < 4; i++) O14083[i] = + _CHROFF_6_1_;}
	O14083[4] = + _CHROFF_48_12_;
}

long O14084[5];
void O14084_init () {
	O14084[0] =  + _REFACS_5_;
	O14084[1] =  + _REFACS_47_;
	{long i; for (i = 2; i < 4; i++) O14084[i] =  + _REFACS_5_;}
	O14084[4] =  + _REFACS_47_;
}

long O14085[5];
void O14085_init () {
	O14085[0] = + _LNGOFF_6_5_0_1_;
	O14085[1] = + _LNGOFF_48_19_10_7_;
	O14085[2] = + _LNGOFF_6_5_0_1_;
	O14085[3] = + _LNGOFF_6_7_0_1_;
	O14085[4] = + _LNGOFF_48_18_10_7_;
}

long O14086[5];
void O14086_init () {
	O14086[0] = + _LNGOFF_6_5_0_2_;
	O14086[1] = + _LNGOFF_48_19_10_8_;
	O14086[2] = + _LNGOFF_6_5_0_2_;
	O14086[3] = + _LNGOFF_6_7_0_2_;
	O14086[4] = + _LNGOFF_48_18_10_8_;
}

long O14200[3];
void O14200_init () {
	O14200[0] = 0;
	{long i; for (i = 1; i < 3; i++) O14200[i] = + _LNGOFF_3_1_0_0_;}
}

long O14202[3];
void O14202_init () {
	O14202[0] =  + _REFACS_1_;
	{long i; for (i = 1; i < 3; i++) O14202[i] = 0;}
}

long O14214[3];
void O14214_init () {
	O14214[0] = + _LNGOFF_4_1_0_0_;
	{long i; for (i = 1; i < 3; i++) O14214[i] = + _LNGOFF_3_1_0_1_;}
}

long O14217[3];
void O14217_init () {
	O14217[0] = + _LNGOFF_4_1_0_1_;
	{long i; for (i = 1; i < 3; i++) O14217[i] = + _LNGOFF_3_1_0_2_;}
}

long O14224[3];
void O14224_init () {
	O14224[0] = + _LNGOFF_4_1_0_2_;
	{long i; for (i = 1; i < 3; i++) O14224[i] = + _LNGOFF_3_1_0_3_;}
}

long O14231[3];
void O14231_init () {
	O14231[0] = + _CHROFF_4_0_;
	{long i; for (i = 1; i < 3; i++) O14231[i] = + _CHROFF_3_0_;}
}

long O14232[3];
void O14232_init () {
	O14232[0] = + _LNGOFF_4_1_0_3_;
	{long i; for (i = 1; i < 3; i++) O14232[i] = + _LNGOFF_3_1_0_4_;}
}

long O14233[3];
void O14233_init () {
	O14233[0] =  + _REFACS_2_;
	{long i; for (i = 1; i < 3; i++) O14233[i] =  + _REFACS_1_;}
}

long O14234[3];
void O14234_init () {
	O14234[0] =  + _REFACS_3_;
	{long i; for (i = 1; i < 3; i++) O14234[i] =  + _REFACS_2_;}
}

long O14243[3];
void O14243_init () {
	O14243[0] = + _LNGOFF_4_1_0_4_;
	{long i; for (i = 1; i < 3; i++) O14243[i] = + _LNGOFF_3_1_0_5_;}
}

long O14749[3];
void O14749_init () {
	O14749[0] = + _CHROFF_2_1_;
	O14749[1] = + _CHROFF_5_1_;
	O14749[2] = + _CHROFF_16_1_;
}

long O14751[3];
void O14751_init () {
	{long i; for (i = 0; i < 2; i++) O14751[i] = 0;}
	O14751[2] =  + _REFACS_1_;
}

long O14752[3];
void O14752_init () {
	{long i; for (i = 0; i < 2; i++) O14752[i] =  + _REFACS_1_;}
	O14752[2] =  + _REFACS_2_;
}

long O14754[3];
void O14754_init () {
	O14754[0] = + _LNGOFF_2_2_0_0_;
	O14754[1] = + _LNGOFF_5_2_0_0_;
	O14754[2] = + _LNGOFF_16_4_0_1_;
}

long O16029[3];
void O16029_init () {
	{long i; for (i = 0; i < 2; i++) O16029[i] = + _CHROFF_6_0_;}
	O16029[2] = + _CHROFF_7_0_;
}

long O16030[3];
void O16030_init () {
	{long i; for (i = 0; i < 2; i++) O16030[i] = + _CHROFF_6_1_;}
	O16030[2] = + _CHROFF_7_1_;
}

long O16040[3];
void O16040_init () {
	{long i; for (i = 0; i < 2; i++) O16040[i] = + _LNGOFF_6_2_0_0_;}
	O16040[2] = + _LNGOFF_7_3_0_0_;
}


#ifdef __cplusplus
}
#endif
