#include "epoly8.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R7643[834])();
void R7643_init () {
	R7643[0] = (char *(*)()) F606_8248;
	R7643[1] = (char *(*)()) F609_8248_7643_4;
	R7643[2] = (char *(*)()) F611_8248_7643_4;
	{long i; for (i = 3; i < 5; i++) R7643[i] = (char *(*)()) F606_8248;}
	R7643[5] = (char *(*)()) F611_8248_7643_4;
	R7643[6] = (char *(*)()) F609_8248_7643_4;
	{long i; for (i = 7; i < 9; i++) R7643[i] = (char *(*)()) F606_8248;}
	R7643[9] = (char *(*)()) F892_8817;
	R7643[10] = (char *(*)()) F893_8817_7643_4;
	R7643[11] = (char *(*)()) F894_8817_7643_4;
	R7643[12] = (char *(*)()) F895_8817_7643_4;
	R7643[13] = (char *(*)()) F896_8817_7643_4;
	R7643[14] = (char *(*)()) F897_8817_7643_4;
	R7643[15] = (char *(*)()) F898_8817_7643_4;
	R7643[16] = (char *(*)()) F899_8817_7643_4;
	R7643[17] = (char *(*)()) F900_8817_7643_4;
	R7643[18] = (char *(*)()) F901_8817_7643_4;
	R7643[19] = (char *(*)()) F902_8817_7643_4;
	R7643[20] = (char *(*)()) F903_8817_7643_4;
	{long i; for (i = 21; i < 23; i++) R7643[i] = (char *(*)()) F892_8817;}
	R7643[23] = (char *(*)()) F895_8817_7643_4;
	R7643[24] = (char *(*)()) F897_8817_7643_4;
	R7643[25] = (char *(*)()) F892_8817;
	R7643[30] = (char *(*)()) F892_8817;
	R7643[31] = (char *(*)()) F895_8817_7643_4;
	{long i; for (i = 32; i < 36; i++) R7643[i] = (char *(*)()) F892_8817;}
	R7643[38] = (char *(*)()) F892_8817;
	R7643[41] = (char *(*)()) F892_8817;
	{long i; for (i = 43; i < 45; i++) R7643[i] = (char *(*)()) F892_8817;}
	R7643[47] = (char *(*)()) F892_8817;
	{long i; for (i = 49; i < 55; i++) R7643[i] = (char *(*)()) F892_8817;}
	R7643[87] = (char *(*)()) F597_8231_7643_4;
	R7643[94] = (char *(*)()) F597_8231_7643_4;
	{long i; for (i = 264; i < 266; i++) R7643[i] = (char *(*)()) F613_8248_7643_4;}
	{long i; for (i = 470; i < 472; i++) R7643[i] = (char *(*)()) F606_8248;}
	{long i; for (i = 489; i < 491; i++) R7643[i] = (char *(*)()) F606_8248;}
	R7643[492] = (char *(*)()) F606_8248;
	R7643[512] = (char *(*)()) F892_8817;
	R7643[523] = (char *(*)()) F606_8248;
	R7643[833] = (char *(*)()) F613_8248_7643_4;
}
static void F609_8248_7643_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F609_8248(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F611_8248_7643_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F611_8248(Current, *(EIF_BOOLEAN *)arg1);
}
static void F893_8817_7643_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F893_8817(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F894_8817_7643_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F894_8817(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F895_8817_7643_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F895_8817(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F896_8817_7643_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F896_8817(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F897_8817_7643_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F897_8817(Current, *(EIF_BOOLEAN *)arg1);
}
static void F898_8817_7643_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F898_8817(Current, *(EIF_POINTER *)arg1);
}
static void F899_8817_7643_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F899_8817(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F900_8817_7643_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F900_8817(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F901_8817_7643_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F901_8817(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F902_8817_7643_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F902_8817(Current, *(EIF_REAL_32 *)arg1);
}
static void F903_8817_7643_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F903_8817(Current, *(EIF_REAL_64 *)arg1);
}
static void F597_8231_7643_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F597_8231(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F613_8248_7643_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F613_8248(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R7644[834])();
void R7644_init () {
	R7644[0] = (char *(*)()) F883_8670;
	R7644[1] = (char *(*)()) F884_8670;
	R7644[2] = (char *(*)()) F885_8670;
	{long i; for (i = 3; i < 5; i++) R7644[i] = (char *(*)()) F883_8670;}
	R7644[5] = (char *(*)()) F885_8670;
	R7644[6] = (char *(*)()) F884_8670;
	{long i; for (i = 7; i < 9; i++) R7644[i] = (char *(*)()) F883_8670;}
	R7644[9] = (char *(*)()) F892_8790;
	R7644[10] = (char *(*)()) F893_8790;
	R7644[11] = (char *(*)()) F894_8790;
	R7644[12] = (char *(*)()) F895_8790;
	R7644[13] = (char *(*)()) F896_8790;
	R7644[14] = (char *(*)()) F897_8790;
	R7644[15] = (char *(*)()) F898_8790;
	R7644[16] = (char *(*)()) F899_8790;
	R7644[17] = (char *(*)()) F900_8790;
	R7644[18] = (char *(*)()) F901_8790;
	R7644[19] = (char *(*)()) F902_8790;
	R7644[20] = (char *(*)()) F903_8790;
	{long i; for (i = 21; i < 23; i++) R7644[i] = (char *(*)()) F892_8790;}
	R7644[23] = (char *(*)()) F895_8790;
	R7644[24] = (char *(*)()) F897_8790;
	R7644[25] = (char *(*)()) F892_8790;
	R7644[30] = (char *(*)()) F892_8790;
	R7644[31] = (char *(*)()) F895_8790;
	{long i; for (i = 32; i < 36; i++) R7644[i] = (char *(*)()) F892_8790;}
	R7644[38] = (char *(*)()) F892_8790;
	R7644[41] = (char *(*)()) F892_8790;
	{long i; for (i = 43; i < 45; i++) R7644[i] = (char *(*)()) F892_8790;}
	R7644[47] = (char *(*)()) F892_8790;
	{long i; for (i = 49; i < 55; i++) R7644[i] = (char *(*)()) F892_8790;}
	R7644[87] = (char *(*)()) F723_8318;
	R7644[94] = (char *(*)()) F723_8318;
	{long i; for (i = 264; i < 266; i++) R7644[i] = (char *(*)()) F1146_10055;}
	{long i; for (i = 470; i < 472; i++) R7644[i] = (char *(*)()) F1341_12721;}
	{long i; for (i = 489; i < 491; i++) R7644[i] = (char *(*)()) F1341_12721;}
	R7644[492] = (char *(*)()) F1341_12721;
	R7644[512] = (char *(*)()) F892_8790;
	R7644[523] = (char *(*)()) F1341_12721;
	R7644[833] = (char *(*)()) F1146_10055;
}

char *(*R7647[834])();
void R7647_init () {
	R7647[0] = (char *(*)()) F594_8235;
	R7647[1] = (char *(*)()) F597_8235;
	R7647[2] = (char *(*)()) F601_8235;
	{long i; for (i = 3; i < 5; i++) R7647[i] = (char *(*)()) F594_8235;}
	R7647[5] = (char *(*)()) F601_8235;
	R7647[6] = (char *(*)()) F597_8235;
	{long i; for (i = 7; i < 10; i++) R7647[i] = (char *(*)()) F594_8235;}
	R7647[10] = (char *(*)()) F595_8235;
	R7647[11] = (char *(*)()) F596_8235;
	R7647[12] = (char *(*)()) F597_8235;
	R7647[13] = (char *(*)()) F598_8235;
	R7647[14] = (char *(*)()) F601_8235;
	R7647[15] = (char *(*)()) F602_8235;
	R7647[16] = (char *(*)()) F599_8235;
	R7647[17] = (char *(*)()) F600_8235;
	R7647[18] = (char *(*)()) F603_8235;
	R7647[19] = (char *(*)()) F604_8235;
	R7647[20] = (char *(*)()) F605_8235;
	{long i; for (i = 21; i < 23; i++) R7647[i] = (char *(*)()) F594_8235;}
	R7647[23] = (char *(*)()) F597_8235;
	R7647[24] = (char *(*)()) F601_8235;
	R7647[25] = (char *(*)()) F594_8235;
	R7647[30] = (char *(*)()) F594_8235;
	R7647[31] = (char *(*)()) F597_8235;
	{long i; for (i = 32; i < 36; i++) R7647[i] = (char *(*)()) F594_8235;}
	R7647[38] = (char *(*)()) F594_8235;
	R7647[41] = (char *(*)()) F594_8235;
	{long i; for (i = 43; i < 45; i++) R7647[i] = (char *(*)()) F594_8235;}
	R7647[47] = (char *(*)()) F594_8235;
	{long i; for (i = 49; i < 55; i++) R7647[i] = (char *(*)()) F594_8235;}
	R7647[87] = (char *(*)()) F597_8235;
	R7647[94] = (char *(*)()) F597_8235;
	{long i; for (i = 264; i < 266; i++) R7647[i] = (char *(*)()) F599_8235;}
	{long i; for (i = 470; i < 472; i++) R7647[i] = (char *(*)()) F594_8235;}
	{long i; for (i = 489; i < 491; i++) R7647[i] = (char *(*)()) F594_8235;}
	R7647[492] = (char *(*)()) F594_8235;
	R7647[512] = (char *(*)()) F594_8235;
	R7647[523] = (char *(*)()) F594_8235;
	R7647[833] = (char *(*)()) F599_8235;
}

char *(*R7648[834])();
void R7648_init () {
	R7648[0] = (char *(*)()) F883_8676;
	R7648[1] = (char *(*)()) F884_8676;
	R7648[2] = (char *(*)()) F885_8676;
	{long i; for (i = 3; i < 5; i++) R7648[i] = (char *(*)()) F883_8676;}
	R7648[5] = (char *(*)()) F885_8676;
	R7648[6] = (char *(*)()) F884_8676;
	{long i; for (i = 7; i < 9; i++) R7648[i] = (char *(*)()) F883_8676;}
	R7648[9] = (char *(*)()) F859_8654;
	R7648[10] = (char *(*)()) F860_8654;
	R7648[11] = (char *(*)()) F861_8654;
	R7648[12] = (char *(*)()) F862_8654;
	R7648[13] = (char *(*)()) F863_8654;
	R7648[14] = (char *(*)()) F864_8654;
	R7648[15] = (char *(*)()) F865_8654;
	R7648[16] = (char *(*)()) F866_8654;
	R7648[17] = (char *(*)()) F867_8654;
	R7648[18] = (char *(*)()) F868_8654;
	R7648[19] = (char *(*)()) F869_8654;
	R7648[20] = (char *(*)()) F870_8654;
	{long i; for (i = 21; i < 23; i++) R7648[i] = (char *(*)()) F859_8654;}
	R7648[23] = (char *(*)()) F862_8654;
	R7648[24] = (char *(*)()) F864_8654;
	R7648[25] = (char *(*)()) F859_8654;
	R7648[30] = (char *(*)()) F859_8654;
	R7648[31] = (char *(*)()) F862_8654;
	{long i; for (i = 32; i < 36; i++) R7648[i] = (char *(*)()) F859_8654;}
	R7648[38] = (char *(*)()) F859_8654;
	R7648[41] = (char *(*)()) F859_8654;
	{long i; for (i = 43; i < 45; i++) R7648[i] = (char *(*)()) F859_8654;}
	R7648[47] = (char *(*)()) F859_8654;
	{long i; for (i = 49; i < 55; i++) R7648[i] = (char *(*)()) F859_8654;}
	R7648[87] = (char *(*)()) F723_8320;
	R7648[94] = (char *(*)()) F723_8320;
	{long i; for (i = 264; i < 266; i++) R7648[i] = (char *(*)()) F1146_10073;}
	{long i; for (i = 470; i < 472; i++) R7648[i] = (char *(*)()) F859_8654;}
	{long i; for (i = 489; i < 491; i++) R7648[i] = (char *(*)()) F859_8654;}
	R7648[492] = (char *(*)()) F859_8654;
	R7648[512] = (char *(*)()) F859_8654;
	R7648[523] = (char *(*)()) F859_8654;
	R7648[833] = (char *(*)()) F1146_10073;
}

char *(*R7649[524])();
void R7649_init () {
	R7649[0] = (char *(*)()) F883_8685;
	R7649[1] = (char *(*)()) F884_8685;
	R7649[2] = (char *(*)()) F885_8685;
	{long i; for (i = 3; i < 5; i++) R7649[i] = (char *(*)()) F883_8685;}
	R7649[5] = (char *(*)()) F885_8685;
	R7649[6] = (char *(*)()) F884_8685;
	R7649[7] = (char *(*)()) F883_8685;
	R7649[8] = (char *(*)()) F891_8762;
	R7649[9] = (char *(*)()) F892_8812;
	R7649[10] = (char *(*)()) F893_8812;
	R7649[11] = (char *(*)()) F894_8812;
	R7649[12] = (char *(*)()) F895_8812;
	R7649[13] = (char *(*)()) F896_8812;
	R7649[14] = (char *(*)()) F897_8812;
	R7649[15] = (char *(*)()) F898_8812;
	R7649[16] = (char *(*)()) F899_8812;
	R7649[17] = (char *(*)()) F900_8812;
	R7649[18] = (char *(*)()) F901_8812;
	R7649[19] = (char *(*)()) F902_8812;
	R7649[20] = (char *(*)()) F903_8812;
	{long i; for (i = 21; i < 23; i++) R7649[i] = (char *(*)()) F892_8812;}
	R7649[23] = (char *(*)()) F895_8812;
	R7649[24] = (char *(*)()) F897_8812;
	R7649[25] = (char *(*)()) F892_8812;
	R7649[30] = (char *(*)()) F892_8812;
	R7649[31] = (char *(*)()) F895_8812;
	{long i; for (i = 32; i < 36; i++) R7649[i] = (char *(*)()) F892_8812;}
	R7649[38] = (char *(*)()) F892_8812;
	R7649[41] = (char *(*)()) F892_8812;
	{long i; for (i = 43; i < 45; i++) R7649[i] = (char *(*)()) F892_8812;}
	R7649[47] = (char *(*)()) F892_8812;
	{long i; for (i = 49; i < 55; i++) R7649[i] = (char *(*)()) F892_8812;}
	{long i; for (i = 470; i < 472; i++) R7649[i] = (char *(*)()) F835_8624;}
	{long i; for (i = 489; i < 491; i++) R7649[i] = (char *(*)()) F835_8624;}
	R7649[492] = (char *(*)()) F835_8624;
	R7649[512] = (char *(*)()) F892_8812;
	R7649[523] = (char *(*)()) F835_8624;
}

char *(*R7650[834])();
void R7650_init () {
	R7650[0] = (char *(*)()) F883_8686;
	R7650[1] = (char *(*)()) F884_8686;
	R7650[2] = (char *(*)()) F885_8686;
	{long i; for (i = 3; i < 5; i++) R7650[i] = (char *(*)()) F883_8686;}
	R7650[5] = (char *(*)()) F885_8686;
	R7650[6] = (char *(*)()) F884_8686;
	R7650[7] = (char *(*)()) F883_8686;
	R7650[8] = (char *(*)()) F891_8760;
	R7650[9] = (char *(*)()) F892_8813;
	R7650[10] = (char *(*)()) F893_8813;
	R7650[11] = (char *(*)()) F894_8813;
	R7650[12] = (char *(*)()) F895_8813;
	R7650[13] = (char *(*)()) F896_8813;
	R7650[14] = (char *(*)()) F897_8813;
	R7650[15] = (char *(*)()) F898_8813;
	R7650[16] = (char *(*)()) F899_8813;
	R7650[17] = (char *(*)()) F900_8813;
	R7650[18] = (char *(*)()) F901_8813;
	R7650[19] = (char *(*)()) F902_8813;
	R7650[20] = (char *(*)()) F903_8813;
	{long i; for (i = 21; i < 23; i++) R7650[i] = (char *(*)()) F892_8813;}
	R7650[23] = (char *(*)()) F895_8813;
	R7650[24] = (char *(*)()) F897_8813;
	R7650[25] = (char *(*)()) F892_8813;
	R7650[30] = (char *(*)()) F892_8813;
	R7650[31] = (char *(*)()) F895_8813;
	{long i; for (i = 32; i < 36; i++) R7650[i] = (char *(*)()) F892_8813;}
	R7650[38] = (char *(*)()) F892_8813;
	R7650[41] = (char *(*)()) F892_8813;
	{long i; for (i = 43; i < 45; i++) R7650[i] = (char *(*)()) F892_8813;}
	R7650[47] = (char *(*)()) F892_8813;
	{long i; for (i = 49; i < 55; i++) R7650[i] = (char *(*)()) F892_8813;}
	R7650[87] = (char *(*)()) F723_8326;
	R7650[94] = (char *(*)()) F723_8326;
	{long i; for (i = 264; i < 266; i++) R7650[i] = (char *(*)()) F1146_10132;}
	{long i; for (i = 470; i < 472; i++) R7650[i] = (char *(*)()) F1341_12732;}
	{long i; for (i = 489; i < 491; i++) R7650[i] = (char *(*)()) F1341_12732;}
	R7650[492] = (char *(*)()) F1341_12732;
	R7650[512] = (char *(*)()) F892_8813;
	R7650[523] = (char *(*)()) F1341_12732;
	R7650[833] = (char *(*)()) F1146_10132;
}

char *(*R7651[834])();
void R7651_init () {
	R7651[0] = (char *(*)()) F883_8677;
	R7651[1] = (char *(*)()) F884_8677;
	R7651[2] = (char *(*)()) F885_8677;
	{long i; for (i = 3; i < 5; i++) R7651[i] = (char *(*)()) F883_8677;}
	R7651[5] = (char *(*)()) F885_8677;
	R7651[6] = (char *(*)()) F884_8677;
	{long i; for (i = 7; i < 9; i++) R7651[i] = (char *(*)()) F883_8677;}
	R7651[9] = (char *(*)()) F859_8655;
	R7651[10] = (char *(*)()) F860_8655;
	R7651[11] = (char *(*)()) F861_8655;
	R7651[12] = (char *(*)()) F862_8655;
	R7651[13] = (char *(*)()) F863_8655;
	R7651[14] = (char *(*)()) F864_8655;
	R7651[15] = (char *(*)()) F865_8655;
	R7651[16] = (char *(*)()) F866_8655;
	R7651[17] = (char *(*)()) F867_8655;
	R7651[18] = (char *(*)()) F868_8655;
	R7651[19] = (char *(*)()) F869_8655;
	R7651[20] = (char *(*)()) F870_8655;
	{long i; for (i = 21; i < 23; i++) R7651[i] = (char *(*)()) F859_8655;}
	R7651[23] = (char *(*)()) F862_8655;
	R7651[24] = (char *(*)()) F864_8655;
	R7651[25] = (char *(*)()) F859_8655;
	R7651[30] = (char *(*)()) F859_8655;
	R7651[31] = (char *(*)()) F862_8655;
	{long i; for (i = 32; i < 36; i++) R7651[i] = (char *(*)()) F859_8655;}
	R7651[38] = (char *(*)()) F859_8655;
	R7651[41] = (char *(*)()) F859_8655;
	{long i; for (i = 43; i < 45; i++) R7651[i] = (char *(*)()) F859_8655;}
	R7651[47] = (char *(*)()) F859_8655;
	{long i; for (i = 49; i < 55; i++) R7651[i] = (char *(*)()) F859_8655;}
	{long i; for (i = 264; i < 266; i++) R7651[i] = (char *(*)()) F1146_10074;}
	{long i; for (i = 470; i < 472; i++) R7651[i] = (char *(*)()) F859_8655;}
	{long i; for (i = 489; i < 491; i++) R7651[i] = (char *(*)()) F859_8655;}
	R7651[492] = (char *(*)()) F859_8655;
	R7651[512] = (char *(*)()) F859_8655;
	R7651[523] = (char *(*)()) F859_8655;
	R7651[833] = (char *(*)()) F1146_10074;
}

char *(*R7652[826])();
void R7652_init () {
	R7652[0] = (char *(*)()) F891_8761;
	R7652[1] = (char *(*)()) F892_8814;
	R7652[2] = (char *(*)()) F893_8814;
	R7652[3] = (char *(*)()) F894_8814;
	R7652[4] = (char *(*)()) F895_8814;
	R7652[5] = (char *(*)()) F896_8814;
	R7652[6] = (char *(*)()) F897_8814;
	R7652[7] = (char *(*)()) F898_8814;
	R7652[8] = (char *(*)()) F899_8814;
	R7652[9] = (char *(*)()) F900_8814;
	R7652[10] = (char *(*)()) F901_8814;
	R7652[11] = (char *(*)()) F902_8814;
	R7652[12] = (char *(*)()) F903_8814;
	{long i; for (i = 13; i < 15; i++) R7652[i] = (char *(*)()) F892_8814;}
	R7652[15] = (char *(*)()) F895_8814;
	R7652[16] = (char *(*)()) F897_8814;
	R7652[17] = (char *(*)()) F892_8814;
	R7652[22] = (char *(*)()) F892_8814;
	R7652[23] = (char *(*)()) F895_8814;
	{long i; for (i = 24; i < 28; i++) R7652[i] = (char *(*)()) F892_8814;}
	R7652[30] = (char *(*)()) F892_8814;
	R7652[33] = (char *(*)()) F892_8814;
	{long i; for (i = 35; i < 37; i++) R7652[i] = (char *(*)()) F892_8814;}
	R7652[39] = (char *(*)()) F892_8814;
	{long i; for (i = 41; i < 47; i++) R7652[i] = (char *(*)()) F892_8814;}
	{long i; for (i = 256; i < 258; i++) R7652[i] = (char *(*)()) F1146_10133;}
	{long i; for (i = 462; i < 464; i++) R7652[i] = (char *(*)()) F1341_12731;}
	{long i; for (i = 481; i < 483; i++) R7652[i] = (char *(*)()) F1341_12731;}
	R7652[484] = (char *(*)()) F1341_12731;
	R7652[504] = (char *(*)()) F892_8814;
	R7652[515] = (char *(*)()) F1341_12731;
	R7652[825] = (char *(*)()) F1716_18247;
}

char *(*R7653[1018])();
void R7653_init () {
	R7653[0] = (char *(*)()) F781_8409;
	R7653[25] = (char *(*)()) F806_8463;
	R7653[26] = (char *(*)()) F807_8463;
	R7653[27] = (char *(*)()) F808_8463;
	R7653[28] = (char *(*)()) F809_8463;
	R7653[29] = (char *(*)()) F810_8463;
	R7653[30] = (char *(*)()) F811_8463;
	R7653[31] = (char *(*)()) F812_8463;
	R7653[32] = (char *(*)()) F813_8463;
	R7653[33] = (char *(*)()) F814_8463;
	R7653[34] = (char *(*)()) F806_8463;
	R7653[35] = (char *(*)()) F807_8463;
	R7653[36] = (char *(*)()) F809_8463;
	R7653[37] = (char *(*)()) F813_8463;
	R7653[38] = (char *(*)()) F814_8463;
	R7653[39] = (char *(*)()) F806_8463;
	{long i; for (i = 52; i < 54; i++) R7653[i] = (char *(*)()) F833_8583;}
	R7653[102] = (char *(*)()) F847_8639;
	R7653[103] = (char *(*)()) F850_8639;
	R7653[104] = (char *(*)()) F852_8639;
	{long i; for (i = 105; i < 107; i++) R7653[i] = (char *(*)()) F847_8639;}
	R7653[107] = (char *(*)()) F852_8639;
	R7653[108] = (char *(*)()) F850_8639;
	{long i; for (i = 109; i < 112; i++) R7653[i] = (char *(*)()) F847_8639;}
	R7653[112] = (char *(*)()) F848_8639;
	R7653[113] = (char *(*)()) F849_8639;
	R7653[114] = (char *(*)()) F850_8639;
	R7653[115] = (char *(*)()) F851_8639;
	R7653[116] = (char *(*)()) F852_8639;
	R7653[117] = (char *(*)()) F853_8639;
	R7653[118] = (char *(*)()) F854_8639;
	R7653[119] = (char *(*)()) F855_8639;
	R7653[120] = (char *(*)()) F856_8639;
	R7653[121] = (char *(*)()) F857_8639;
	R7653[122] = (char *(*)()) F858_8639;
	{long i; for (i = 123; i < 125; i++) R7653[i] = (char *(*)()) F847_8639;}
	R7653[125] = (char *(*)()) F850_8639;
	R7653[126] = (char *(*)()) F852_8639;
	R7653[127] = (char *(*)()) F847_8639;
	R7653[132] = (char *(*)()) F847_8639;
	R7653[133] = (char *(*)()) F850_8639;
	{long i; for (i = 134; i < 138; i++) R7653[i] = (char *(*)()) F847_8639;}
	R7653[140] = (char *(*)()) F847_8639;
	R7653[143] = (char *(*)()) F847_8639;
	{long i; for (i = 145; i < 147; i++) R7653[i] = (char *(*)()) F847_8639;}
	R7653[149] = (char *(*)()) F847_8639;
	{long i; for (i = 151; i < 157; i++) R7653[i] = (char *(*)()) F847_8639;}
	R7653[157] = (char *(*)()) F938_9030;
	R7653[158] = (char *(*)()) F939_9030;
	R7653[159] = (char *(*)()) F940_9030;
	R7653[160] = (char *(*)()) F941_9030;
	R7653[161] = (char *(*)()) F942_9030;
	R7653[162] = (char *(*)()) F943_9030;
	R7653[163] = (char *(*)()) F944_9030;
	R7653[164] = (char *(*)()) F945_9030;
	R7653[165] = (char *(*)()) F946_9030;
	R7653[166] = (char *(*)()) F947_9030;
	R7653[167] = (char *(*)()) F948_9030;
	R7653[168] = (char *(*)()) F949_9030;
	R7653[189] = (char *(*)()) F723_8321;
	R7653[196] = (char *(*)()) F723_8321;
	{long i; for (i = 366; i < 368; i++) R7653[i] = (char *(*)()) F1146_10106;}
	R7653[461] = (char *(*)()) F1242_11276;
	R7653[464] = (char *(*)()) F1245_11441;
	{long i; for (i = 572; i < 574; i++) R7653[i] = (char *(*)()) F847_8639;}
	{long i; for (i = 574; i < 576; i++) R7653[i] = (char *(*)()) F1355_12912;}
	{long i; for (i = 577; i < 579; i++) R7653[i] = (char *(*)()) F1355_12912;}
	{long i; for (i = 581; i < 584; i++) R7653[i] = (char *(*)()) F1355_12912;}
	{long i; for (i = 585; i < 588; i++) R7653[i] = (char *(*)()) F1355_12912;}
	{long i; for (i = 591; i < 593; i++) R7653[i] = (char *(*)()) F847_8639;}
	R7653[594] = (char *(*)()) F847_8639;
	R7653[614] = (char *(*)()) F847_8639;
	R7653[625] = (char *(*)()) F847_8639;
	R7653[935] = (char *(*)()) F1146_10106;
	R7653[1017] = (char *(*)()) F1245_11441;
}

char *(*R7654[993])();
void R7654_init () {
	R7654[0] = (char *(*)()) F661_8266;
	R7654[1] = (char *(*)()) F663_8266;
	R7654[2] = (char *(*)()) F662_8266;
	R7654[3] = (char *(*)()) F666_8266;
	R7654[4] = (char *(*)()) F667_8266;
	R7654[5] = (char *(*)()) F679_8266;
	R7654[6] = (char *(*)()) F672_8266;
	R7654[7] = (char *(*)()) F668_8266;
	R7654[8] = (char *(*)()) F670_8266;
	R7654[9] = (char *(*)()) F661_8266;
	R7654[10] = (char *(*)()) F663_8266;
	R7654[11] = (char *(*)()) F666_8266;
	R7654[12] = (char *(*)()) F668_8266;
	R7654[13] = (char *(*)()) F670_8266;
	R7654[14] = (char *(*)()) F661_8266;
	R7654[77] = (char *(*)()) F662_8266;
	R7654[78] = (char *(*)()) F667_8266;
	R7654[79] = (char *(*)()) F671_8266;
	{long i; for (i = 80; i < 82; i++) R7654[i] = (char *(*)()) F662_8266;}
	R7654[82] = (char *(*)()) F671_8266;
	R7654[83] = (char *(*)()) F667_8266;
	{long i; for (i = 84; i < 86; i++) R7654[i] = (char *(*)()) F662_8266;}
	R7654[436] = (char *(*)()) F675_8266;
	R7654[439] = (char *(*)()) F674_8266;
	{long i; for (i = 547; i < 549; i++) R7654[i] = (char *(*)()) F662_8266;}
	{long i; for (i = 549; i < 551; i++) R7654[i] = (char *(*)()) F1355_12914;}
	{long i; for (i = 552; i < 554; i++) R7654[i] = (char *(*)()) F1355_12914;}
	{long i; for (i = 556; i < 559; i++) R7654[i] = (char *(*)()) F1355_12914;}
	{long i; for (i = 560; i < 563; i++) R7654[i] = (char *(*)()) F1355_12914;}
	{long i; for (i = 566; i < 568; i++) R7654[i] = (char *(*)()) F662_8266;}
	R7654[569] = (char *(*)()) F662_8266;
	R7654[600] = (char *(*)()) F662_8266;
	R7654[992] = (char *(*)()) F674_8266;
}

char *(*R7656[21])();
void R7656_init () {
	R7656[0] = (char *(*)()) F887_8725;
	R7656[1] = (char *(*)()) F888_8725_7656_4;
	R7656[2] = (char *(*)()) F889_8725_7656_4;
	R7656[18] = (char *(*)()) F905_8850;
	R7656[19] = (char *(*)()) F906_8850_7656_4;
	R7656[20] = (char *(*)()) F907_8850_7656_4;
}
static void F888_8725_7656_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F888_8725(Current, *(EIF_BOOLEAN *)arg1);
}
static void F889_8725_7656_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F889_8725(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F906_8850_7656_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F906_8850(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F907_8850_7656_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F907_8850(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R7657[1018])();
void R7657_init () {
	R7657[0] = (char *(*)()) F781_8411;
	R7657[25] = (char *(*)()) F806_8547;
	R7657[26] = (char *(*)()) F807_8547_7657_4;
	R7657[27] = (char *(*)()) F808_8547;
	R7657[28] = (char *(*)()) F809_8547_7657_4;
	R7657[29] = (char *(*)()) F810_8547_7657_4;
	R7657[30] = (char *(*)()) F811_8547_7657_4;
	R7657[31] = (char *(*)()) F812_8547_7657_4;
	R7657[32] = (char *(*)()) F813_8547_7657_4;
	R7657[33] = (char *(*)()) F814_8547_7657_4;
	R7657[34] = (char *(*)()) F806_8547;
	R7657[35] = (char *(*)()) F807_8547_7657_4;
	R7657[36] = (char *(*)()) F809_8547_7657_4;
	R7657[37] = (char *(*)()) F813_8547_7657_4;
	R7657[38] = (char *(*)()) F814_8547_7657_4;
	R7657[39] = (char *(*)()) F806_8547;
	R7657[52] = (char *(*)()) F833_8585_7657_4;
	R7657[53] = (char *(*)()) F834_8607_7657_4;
	R7657[102] = (char *(*)()) F883_8692;
	R7657[103] = (char *(*)()) F884_8692_7657_4;
	R7657[104] = (char *(*)()) F885_8692_7657_4;
	R7657[105] = (char *(*)()) F886_8713;
	R7657[106] = (char *(*)()) F887_8724;
	R7657[107] = (char *(*)()) F888_8724_7657_4;
	R7657[108] = (char *(*)()) F889_8724_7657_4;
	R7657[109] = (char *(*)()) F890_8739;
	R7657[110] = (char *(*)()) F891_8765;
	R7657[111] = (char *(*)()) F892_8821;
	R7657[112] = (char *(*)()) F893_8821_7657_4;
	R7657[113] = (char *(*)()) F894_8821_7657_4;
	R7657[114] = (char *(*)()) F895_8821_7657_4;
	R7657[115] = (char *(*)()) F896_8821_7657_4;
	R7657[116] = (char *(*)()) F897_8821_7657_4;
	R7657[117] = (char *(*)()) F898_8821_7657_4;
	R7657[118] = (char *(*)()) F899_8821_7657_4;
	R7657[119] = (char *(*)()) F900_8821_7657_4;
	R7657[120] = (char *(*)()) F901_8821_7657_4;
	R7657[121] = (char *(*)()) F902_8821_7657_4;
	R7657[122] = (char *(*)()) F903_8821_7657_4;
	R7657[123] = (char *(*)()) F892_8821;
	R7657[124] = (char *(*)()) F905_8849;
	R7657[125] = (char *(*)()) F906_8849_7657_4;
	R7657[126] = (char *(*)()) F907_8849_7657_4;
	R7657[127] = (char *(*)()) F892_8821;
	R7657[132] = (char *(*)()) F909_8875;
	R7657[133] = (char *(*)()) F910_8875_7657_4;
	{long i; for (i = 134; i < 138; i++) R7657[i] = (char *(*)()) F909_8875;}
	R7657[140] = (char *(*)()) F909_8875;
	R7657[143] = (char *(*)()) F909_8875;
	{long i; for (i = 145; i < 147; i++) R7657[i] = (char *(*)()) F909_8875;}
	R7657[149] = (char *(*)()) F909_8875;
	{long i; for (i = 151; i < 157; i++) R7657[i] = (char *(*)()) F909_8875;}
	R7657[157] = (char *(*)()) F938_9065;
	R7657[158] = (char *(*)()) F939_9065_7657_4;
	R7657[159] = (char *(*)()) F940_9065_7657_4;
	R7657[160] = (char *(*)()) F941_9065_7657_4;
	R7657[161] = (char *(*)()) F942_9065_7657_4;
	R7657[162] = (char *(*)()) F943_9065_7657_4;
	R7657[163] = (char *(*)()) F944_9065_7657_4;
	R7657[164] = (char *(*)()) F945_9065_7657_4;
	R7657[165] = (char *(*)()) F946_9065_7657_4;
	R7657[166] = (char *(*)()) F947_9065_7657_4;
	R7657[167] = (char *(*)()) F948_9065_7657_4;
	R7657[168] = (char *(*)()) F949_9065_7657_4;
	R7657[189] = (char *(*)()) F723_8328_7657_4;
	R7657[196] = (char *(*)()) F723_8328_7657_4;
	{long i; for (i = 366; i < 368; i++) R7657[i] = (char *(*)()) F1146_10139_7657_4;}
	R7657[461] = (char *(*)()) F1242_11318_7657_4;
	R7657[464] = (char *(*)()) F1245_11483_7657_4;
	{long i; for (i = 572; i < 576; i++) R7657[i] = (char *(*)()) F1348_12856;}
	{long i; for (i = 577; i < 579; i++) R7657[i] = (char *(*)()) F1348_12856;}
	{long i; for (i = 581; i < 584; i++) R7657[i] = (char *(*)()) F1348_12856;}
	{long i; for (i = 585; i < 588; i++) R7657[i] = (char *(*)()) F1348_12856;}
	{long i; for (i = 591; i < 593; i++) R7657[i] = (char *(*)()) F1341_12756;}
	R7657[594] = (char *(*)()) F1341_12756;
	R7657[614] = (char *(*)()) F909_8875;
	R7657[625] = (char *(*)()) F1341_12756;
	R7657[935] = (char *(*)()) F1146_10139_7657_4;
	R7657[1017] = (char *(*)()) F1245_11483_7657_4;
}
static void F807_8547_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F807_8547(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F809_8547_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F809_8547(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F810_8547_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F810_8547(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F811_8547_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F811_8547(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F812_8547_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F812_8547(Current, *(EIF_POINTER *)arg1);
}
static void F813_8547_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F813_8547(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F814_8547_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F814_8547(Current, *(EIF_BOOLEAN *)arg1);
}
static void F833_8585_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F833_8585(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F834_8607_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F834_8607(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F884_8692_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F884_8692(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F885_8692_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F885_8692(Current, *(EIF_BOOLEAN *)arg1);
}
static void F888_8724_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F888_8724(Current, *(EIF_BOOLEAN *)arg1);
}
static void F889_8724_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F889_8724(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F893_8821_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F893_8821(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F894_8821_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F894_8821(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F895_8821_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F895_8821(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F896_8821_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F896_8821(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F897_8821_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F897_8821(Current, *(EIF_BOOLEAN *)arg1);
}
static void F898_8821_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F898_8821(Current, *(EIF_POINTER *)arg1);
}
static void F899_8821_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F899_8821(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F900_8821_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F900_8821(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F901_8821_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F901_8821(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F902_8821_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F902_8821(Current, *(EIF_REAL_32 *)arg1);
}
static void F903_8821_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F903_8821(Current, *(EIF_REAL_64 *)arg1);
}
static void F906_8849_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F906_8849(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F907_8849_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F907_8849(Current, *(EIF_BOOLEAN *)arg1);
}
static void F910_8875_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F910_8875(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F939_9065_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F939_9065(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F940_9065_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F940_9065(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F941_9065_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F941_9065(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F942_9065_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F942_9065(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F943_9065_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F943_9065(Current, *(EIF_BOOLEAN *)arg1);
}
static void F944_9065_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F944_9065(Current, *(EIF_POINTER *)arg1);
}
static void F945_9065_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F945_9065(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F946_9065_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F946_9065(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F947_9065_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F947_9065(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F948_9065_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F948_9065(Current, *(EIF_REAL_32 *)arg1);
}
static void F949_9065_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F949_9065(Current, *(EIF_REAL_64 *)arg1);
}
static void F723_8328_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F723_8328(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1146_10139_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1146_10139(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1242_11318_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1242_11318(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1245_11483_7657_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1245_11483(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R7658[1018])();
void R7658_init () {
	R7658[0] = (char *(*)()) F618_8254;
	R7658[25] = (char *(*)()) F618_8254;
	R7658[26] = (char *(*)()) F619_8254;
	R7658[27] = (char *(*)()) F618_8254;
	{long i; for (i = 28; i < 31; i++) R7658[i] = (char *(*)()) F621_8254;}
	R7658[31] = (char *(*)()) F626_8254;
	R7658[32] = (char *(*)()) F622_8254;
	R7658[33] = (char *(*)()) F625_8254;
	R7658[34] = (char *(*)()) F618_8254;
	R7658[35] = (char *(*)()) F619_8254;
	R7658[36] = (char *(*)()) F621_8254;
	R7658[37] = (char *(*)()) F622_8254;
	R7658[38] = (char *(*)()) F625_8254;
	R7658[39] = (char *(*)()) F618_8254;
	{long i; for (i = 52; i < 54; i++) R7658[i] = (char *(*)()) F621_8254;}
	R7658[102] = (char *(*)()) F835_8635;
	R7658[103] = (char *(*)()) F838_8635;
	R7658[104] = (char *(*)()) F840_8635;
	R7658[105] = (char *(*)()) F835_8635;
	R7658[106] = (char *(*)()) F777_8396;
	R7658[107] = (char *(*)()) F779_8396;
	R7658[108] = (char *(*)()) F778_8396;
	R7658[109] = (char *(*)()) F618_8254;
	{long i; for (i = 110; i < 112; i++) R7658[i] = (char *(*)()) F835_8635;}
	R7658[112] = (char *(*)()) F836_8635;
	R7658[113] = (char *(*)()) F837_8635;
	R7658[114] = (char *(*)()) F838_8635;
	R7658[115] = (char *(*)()) F839_8635;
	R7658[116] = (char *(*)()) F840_8635;
	R7658[117] = (char *(*)()) F841_8635;
	R7658[118] = (char *(*)()) F842_8635;
	R7658[119] = (char *(*)()) F843_8635;
	R7658[120] = (char *(*)()) F844_8635;
	R7658[121] = (char *(*)()) F845_8635;
	R7658[122] = (char *(*)()) F846_8635;
	R7658[123] = (char *(*)()) F835_8635;
	R7658[124] = (char *(*)()) F777_8396;
	R7658[125] = (char *(*)()) F778_8396;
	R7658[126] = (char *(*)()) F779_8396;
	R7658[127] = (char *(*)()) F835_8635;
	R7658[132] = (char *(*)()) F835_8635;
	R7658[133] = (char *(*)()) F838_8635;
	{long i; for (i = 134; i < 138; i++) R7658[i] = (char *(*)()) F835_8635;}
	R7658[140] = (char *(*)()) F835_8635;
	R7658[143] = (char *(*)()) F835_8635;
	{long i; for (i = 145; i < 147; i++) R7658[i] = (char *(*)()) F835_8635;}
	R7658[149] = (char *(*)()) F835_8635;
	{long i; for (i = 151; i < 157; i++) R7658[i] = (char *(*)()) F835_8635;}
	R7658[157] = (char *(*)()) F618_8254;
	R7658[158] = (char *(*)()) F619_8254;
	R7658[159] = (char *(*)()) F620_8254;
	R7658[160] = (char *(*)()) F621_8254;
	R7658[161] = (char *(*)()) F622_8254;
	R7658[162] = (char *(*)()) F625_8254;
	R7658[163] = (char *(*)()) F626_8254;
	R7658[164] = (char *(*)()) F623_8254;
	R7658[165] = (char *(*)()) F624_8254;
	R7658[166] = (char *(*)()) F627_8254;
	R7658[167] = (char *(*)()) F628_8254;
	R7658[168] = (char *(*)()) F629_8254;
	R7658[189] = (char *(*)()) F621_8254;
	R7658[196] = (char *(*)()) F621_8254;
	{long i; for (i = 366; i < 368; i++) R7658[i] = (char *(*)()) F623_8254;}
	R7658[461] = (char *(*)()) F624_8254;
	R7658[464] = (char *(*)()) F623_8254;
	{long i; for (i = 572; i < 574; i++) R7658[i] = (char *(*)()) F835_8635;}
	{long i; for (i = 574; i < 576; i++) R7658[i] = (char *(*)()) F618_8254;}
	{long i; for (i = 577; i < 579; i++) R7658[i] = (char *(*)()) F618_8254;}
	{long i; for (i = 581; i < 584; i++) R7658[i] = (char *(*)()) F618_8254;}
	{long i; for (i = 585; i < 588; i++) R7658[i] = (char *(*)()) F618_8254;}
	{long i; for (i = 591; i < 593; i++) R7658[i] = (char *(*)()) F835_8635;}
	R7658[594] = (char *(*)()) F835_8635;
	R7658[614] = (char *(*)()) F835_8635;
	R7658[625] = (char *(*)()) F835_8635;
	R7658[935] = (char *(*)()) F623_8254;
	R7658[1017] = (char *(*)()) F623_8254;
}


#ifdef __cplusplus
}
#endif
