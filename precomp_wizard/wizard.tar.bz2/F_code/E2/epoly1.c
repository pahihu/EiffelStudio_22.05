#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O2300[1512];
void O2300_init () {
	O2300[0] = 0;
	{long i; for (i = 1502; i < 1506; i++) O2300[i] = 0;}
	O2300[1506] =  + _REFACS_1_;
	{long i; for (i = 1507; i < 1511; i++) O2300[i] = 0;}
	O2300[1511] =  + _REFACS_1_;
}

long O2303[1527];
void O2303_init () {
	O2303[0] = 0;
	{long i; for (i = 1385; i < 1387; i++) O2303[i] = 0;}
	{long i; for (i = 1415; i < 1420; i++) O2303[i] = 0;}
	O2303[1420] =  + _REFACS_1_;
	{long i; for (i = 1421; i < 1423; i++) O2303[i] = 0;}
	O2303[1423] =  + _REFACS_1_;
	{long i; for (i = 1424; i < 1448; i++) O2303[i] = 0;}
	O2303[1448] =  + _REFACS_2_;
	{long i; for (i = 1449; i < 1453; i++) O2303[i] = 0;}
	{long i; for (i = 1453; i < 1456; i++) O2303[i] =  + _REFACS_1_;}
	{long i; for (i = 1456; i < 1458; i++) O2303[i] = 0;}
	{long i; for (i = 1458; i < 1460; i++) O2303[i] =  + _REFACS_2_;}
	O2303[1460] =  + _REFACS_1_;
	O2303[1461] =  + _REFACS_2_;
	O2303[1462] =  + _REFACS_6_;
	O2303[1463] =  + _REFACS_1_;
	O2303[1464] =  + _REFACS_4_;
	{long i; for (i = 1465; i < 1469; i++) O2303[i] = 0;}
	O2303[1469] =  + _REFACS_2_;
	{long i; for (i = 1470; i < 1474; i++) O2303[i] = 0;}
	{long i; for (i = 1474; i < 1477; i++) O2303[i] =  + _REFACS_1_;}
	{long i; for (i = 1477; i < 1479; i++) O2303[i] = 0;}
	{long i; for (i = 1479; i < 1481; i++) O2303[i] =  + _REFACS_2_;}
	O2303[1481] =  + _REFACS_1_;
	O2303[1482] =  + _REFACS_2_;
	O2303[1483] =  + _REFACS_6_;
	O2303[1484] =  + _REFACS_1_;
	O2303[1485] =  + _REFACS_4_;
	{long i; for (i = 1486; i < 1489; i++) O2303[i] = 0;}
	{long i; for (i = 1513; i < 1517; i++) O2303[i] =  + _REFACS_2_;}
	O2303[1518] = 0;
	O2303[1521] = 0;
	O2303[1523] = 0;
	O2303[1526] = 0;
}

long O2304[1527];
void O2304_init () {
	O2304[0] =  + _REFACS_1_;
	{long i; for (i = 1385; i < 1387; i++) O2304[i] =  + _REFACS_1_;}
	{long i; for (i = 1415; i < 1420; i++) O2304[i] =  + _REFACS_1_;}
	O2304[1420] =  + _REFACS_2_;
	{long i; for (i = 1421; i < 1423; i++) O2304[i] =  + _REFACS_1_;}
	O2304[1423] =  + _REFACS_2_;
	{long i; for (i = 1424; i < 1448; i++) O2304[i] =  + _REFACS_1_;}
	O2304[1448] =  + _REFACS_3_;
	{long i; for (i = 1449; i < 1453; i++) O2304[i] =  + _REFACS_1_;}
	{long i; for (i = 1453; i < 1456; i++) O2304[i] =  + _REFACS_2_;}
	{long i; for (i = 1456; i < 1458; i++) O2304[i] =  + _REFACS_1_;}
	{long i; for (i = 1458; i < 1460; i++) O2304[i] =  + _REFACS_3_;}
	O2304[1460] =  + _REFACS_2_;
	O2304[1461] =  + _REFACS_3_;
	O2304[1462] =  + _REFACS_7_;
	O2304[1463] =  + _REFACS_2_;
	O2304[1464] =  + _REFACS_5_;
	{long i; for (i = 1465; i < 1469; i++) O2304[i] =  + _REFACS_1_;}
	O2304[1469] =  + _REFACS_3_;
	{long i; for (i = 1470; i < 1474; i++) O2304[i] =  + _REFACS_1_;}
	{long i; for (i = 1474; i < 1477; i++) O2304[i] =  + _REFACS_2_;}
	{long i; for (i = 1477; i < 1479; i++) O2304[i] =  + _REFACS_1_;}
	{long i; for (i = 1479; i < 1481; i++) O2304[i] =  + _REFACS_3_;}
	O2304[1481] =  + _REFACS_2_;
	O2304[1482] =  + _REFACS_3_;
	O2304[1483] =  + _REFACS_7_;
	O2304[1484] =  + _REFACS_2_;
	O2304[1485] =  + _REFACS_5_;
	{long i; for (i = 1486; i < 1489; i++) O2304[i] =  + _REFACS_1_;}
	{long i; for (i = 1513; i < 1517; i++) O2304[i] =  + _REFACS_3_;}
	O2304[1518] =  + _REFACS_1_;
	O2304[1521] =  + _REFACS_1_;
	O2304[1523] =  + _REFACS_1_;
	O2304[1526] =  + _REFACS_1_;
}

long O3412[1506];
void O3412_init () {
	O3412[0] = 0;
	O3412[1478] = 0;
	{long i; for (i = 1479; i < 1481; i++) O3412[i] =  + _REFACS_2_;}
	{long i; for (i = 1481; i < 1484; i++) O3412[i] = 0;}
	{long i; for (i = 1484; i < 1488; i++) O3412[i] =  + _REFACS_4_;}
	{long i; for (i = 1488; i < 1490; i++) O3412[i] = 0;}
	{long i; for (i = 1490; i < 1494; i++) O3412[i] =  + _REFACS_1_;}
	O3412[1494] =  + _REFACS_2_;
	{long i; for (i = 1495; i < 1499; i++) O3412[i] =  + _REFACS_1_;}
	O3412[1499] =  + _REFACS_2_;
	{long i; for (i = 1500; i < 1502; i++) O3412[i] = 0;}
	{long i; for (i = 1502; i < 1506; i++) O3412[i] =  + _REFACS_4_;}
}

long O3414[1506];
void O3414_init () {
	O3414[0] =  + _REFACS_1_;
	O3414[1478] =  + _REFACS_1_;
	{long i; for (i = 1479; i < 1481; i++) O3414[i] =  + _REFACS_3_;}
	{long i; for (i = 1481; i < 1484; i++) O3414[i] =  + _REFACS_1_;}
	{long i; for (i = 1484; i < 1488; i++) O3414[i] =  + _REFACS_5_;}
	{long i; for (i = 1488; i < 1490; i++) O3414[i] =  + _REFACS_1_;}
	{long i; for (i = 1490; i < 1494; i++) O3414[i] =  + _REFACS_2_;}
	O3414[1494] =  + _REFACS_3_;
	{long i; for (i = 1495; i < 1499; i++) O3414[i] =  + _REFACS_2_;}
	O3414[1499] =  + _REFACS_3_;
	{long i; for (i = 1500; i < 1502; i++) O3414[i] =  + _REFACS_1_;}
	{long i; for (i = 1502; i < 1506; i++) O3414[i] =  + _REFACS_5_;}
}

long O3416[1506];
void O3416_init () {
	O3416[0] =  + _REFACS_2_;
	O3416[1478] =  + _REFACS_2_;
	{long i; for (i = 1479; i < 1481; i++) O3416[i] =  + _REFACS_4_;}
	{long i; for (i = 1481; i < 1484; i++) O3416[i] =  + _REFACS_2_;}
	{long i; for (i = 1484; i < 1488; i++) O3416[i] =  + _REFACS_6_;}
	{long i; for (i = 1488; i < 1490; i++) O3416[i] =  + _REFACS_2_;}
	{long i; for (i = 1490; i < 1494; i++) O3416[i] =  + _REFACS_3_;}
	O3416[1494] =  + _REFACS_4_;
	{long i; for (i = 1495; i < 1499; i++) O3416[i] =  + _REFACS_3_;}
	O3416[1499] =  + _REFACS_4_;
	{long i; for (i = 1500; i < 1502; i++) O3416[i] =  + _REFACS_2_;}
	{long i; for (i = 1502; i < 1506; i++) O3416[i] =  + _REFACS_6_;}
}

long O3567[1505];
void O3567_init () {
	O3567[0] = 0;
	{long i; for (i = 1391; i < 1393; i++) O3567[i] = 0;}
	{long i; for (i = 1393; i < 1395; i++) O3567[i] =  + _REFACS_2_;}
	{long i; for (i = 1395; i < 1398; i++) O3567[i] =  + _REFACS_3_;}
	O3567[1398] =  + _REFACS_4_;
	{long i; for (i = 1399; i < 1401; i++) O3567[i] =  + _REFACS_3_;}
	O3567[1401] =  + _REFACS_4_;
	O3567[1402] =  + _REFACS_3_;
	{long i; for (i = 1403; i < 1425; i++) O3567[i] =  + _REFACS_4_;}
	O3567[1425] =  + _REFACS_2_;
	O3567[1426] =  + _REFACS_4_;
	O3567[1427] =  + _REFACS_3_;
	O3567[1428] =  + _REFACS_6_;
	O3567[1429] =  + _REFACS_2_;
	O3567[1430] =  + _REFACS_7_;
	{long i; for (i = 1431; i < 1434; i++) O3567[i] =  + _REFACS_3_;}
	{long i; for (i = 1434; i < 1436; i++) O3567[i] =  + _REFACS_2_;}
	{long i; for (i = 1436; i < 1438; i++) O3567[i] =  + _REFACS_4_;}
	O3567[1438] =  + _REFACS_3_;
	O3567[1439] =  + _REFACS_4_;
	O3567[1440] =  + _REFACS_8_;
	O3567[1441] =  + _REFACS_3_;
	O3567[1442] =  + _REFACS_6_;
	{long i; for (i = 1443; i < 1447; i++) O3567[i] =  + _REFACS_2_;}
	O3567[1447] =  + _REFACS_4_;
	O3567[1448] =  + _REFACS_3_;
	O3567[1449] =  + _REFACS_6_;
	O3567[1450] =  + _REFACS_2_;
	O3567[1451] =  + _REFACS_7_;
	{long i; for (i = 1452; i < 1455; i++) O3567[i] =  + _REFACS_3_;}
	{long i; for (i = 1455; i < 1457; i++) O3567[i] =  + _REFACS_2_;}
	{long i; for (i = 1457; i < 1459; i++) O3567[i] =  + _REFACS_4_;}
	O3567[1459] =  + _REFACS_3_;
	O3567[1460] =  + _REFACS_4_;
	O3567[1461] =  + _REFACS_8_;
	O3567[1462] =  + _REFACS_3_;
	O3567[1463] =  + _REFACS_6_;
	{long i; for (i = 1464; i < 1467; i++) O3567[i] =  + _REFACS_2_;}
	O3567[1467] =  + _REFACS_3_;
	{long i; for (i = 1468; i < 1470; i++) O3567[i] =  + _REFACS_5_;}
	{long i; for (i = 1470; i < 1473; i++) O3567[i] =  + _REFACS_3_;}
	{long i; for (i = 1473; i < 1477; i++) O3567[i] =  + _REFACS_7_;}
	{long i; for (i = 1477; i < 1479; i++) O3567[i] =  + _REFACS_3_;}
	{long i; for (i = 1479; i < 1483; i++) O3567[i] =  + _REFACS_4_;}
	O3567[1483] =  + _REFACS_5_;
	{long i; for (i = 1484; i < 1488; i++) O3567[i] =  + _REFACS_4_;}
	O3567[1488] =  + _REFACS_5_;
	{long i; for (i = 1489; i < 1491; i++) O3567[i] =  + _REFACS_3_;}
	{long i; for (i = 1491; i < 1495; i++) O3567[i] =  + _REFACS_7_;}
	O3567[1496] =  + _REFACS_2_;
	O3567[1499] =  + _REFACS_2_;
	O3567[1501] =  + _REFACS_2_;
	O3567[1504] =  + _REFACS_2_;
}


#ifdef __cplusplus
}
#endif
