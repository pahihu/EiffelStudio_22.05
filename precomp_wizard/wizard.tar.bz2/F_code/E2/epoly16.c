#include "epoly16.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R9829[555])();
void R9829_init () {
	R9829[0] = (char *(*)()) F1244_11418;
	R9829[1] = (char *(*)()) F1245_11488;
	R9829[554] = (char *(*)()) F1798_20778;
}

char *(*R9837[555])();
void R9837_init () {
	R9837[0] = (char *(*)()) F1244_11429;
	R9837[1] = (char *(*)()) F1243_11408;
	R9837[554] = (char *(*)()) F1243_11408;
}

char *(*R9852[554])();
void R9852_init () {
	R9852[0] = (char *(*)()) F1245_11446;
	R9852[553] = (char *(*)()) F1798_20833;
}

char *(*R9860[554])();
void R9860_init () {
	R9860[0] = (char *(*)()) F1245_11461;
	R9860[553] = (char *(*)()) F1798_20808;
}

char *(*R9863[554])();
void R9863_init () {
	R9863[0] = (char *(*)()) F1245_11469;
	R9863[553] = (char *(*)()) F1798_20816;
}

char *(*R9865[554])();
void R9865_init () {
	R9865[0] = (char *(*)()) F1245_11471;
	R9865[553] = (char *(*)()) F1798_20814;
}

char *(*R9867[554])();
void R9867_init () {
	R9867[0] = (char *(*)()) F1245_11482;
	R9867[553] = (char *(*)()) F1798_20813;
}

char *(*R9869[554])();
void R9869_init () {
	R9869[0] = (char *(*)()) F1245_11486;
	R9869[553] = (char *(*)()) F1798_20830;
}

char *(*R9879[554])();
void R9879_init () {
	R9879[0] = (char *(*)()) F1245_11510;
	R9879[553] = (char *(*)()) F1798_20847;
}

char *(*R9880[554])();
void R9880_init () {
	R9880[0] = (char *(*)()) F1245_11511;
	R9880[553] = (char *(*)()) F1798_20848;
}

char *(*R9891[156])();
void R9891_init () {
	R9891[0] = (char *(*)()) F1251_11592;
	R9891[1] = (char *(*)()) F1252_11597;
	R9891[3] = (char *(*)()) F1254_11635;
	R9891[4] = (char *(*)()) F1255_11651;
	R9891[5] = (char *(*)()) F1256_11683;
	R9891[6] = (char *(*)()) F1257_11724;
	R9891[8] = (char *(*)()) F1259_11745;
	R9891[13] = (char *(*)()) F1262_11797;
	R9891[30] = (char *(*)()) F1281_11993;
	R9891[33] = (char *(*)()) F1284_12028;
	R9891[51] = (char *(*)()) F1302_12559;
	R9891[102] = (char *(*)()) F1353_12907;
	R9891[103] = (char *(*)()) F1354_12909;
	R9891[104] = (char *(*)()) F1355_12922;
	R9891[105] = (char *(*)()) F1356_12930;
	R9891[107] = (char *(*)()) F1358_12954;
	R9891[108] = (char *(*)()) F1359_12990;
	R9891[111] = (char *(*)()) F1361_13013;
	{long i; for (i = 112; i < 114; i++) R9891[i] = (char *(*)()) F1363_13056;}
	{long i; for (i = 115; i < 118; i++) R9891[i] = (char *(*)()) F1363_13056;}
	R9891[120] = (char *(*)()) F1371_13119;
	R9891[121] = (char *(*)()) F1372_13120;
	R9891[122] = (char *(*)()) F1373_13163;
	R9891[123] = (char *(*)()) F1374_13170;
	R9891[124] = (char *(*)()) F1375_13177;
	R9891[125] = (char *(*)()) F1376_13200;
	R9891[128] = (char *(*)()) F1379_13225;
	R9891[129] = (char *(*)()) F1380_13233;
	R9891[136] = (char *(*)()) F1387_13317;
	R9891[139] = (char *(*)()) F1390_13354;
	R9891[140] = (char *(*)()) F1391_13356;
	R9891[143] = (char *(*)()) F1394_13378;
	R9891[144] = (char *(*)()) F1395_13385;
	R9891[148] = (char *(*)()) F1399_13405;
	R9891[151] = (char *(*)()) F1402_13426;
	R9891[155] = (char *(*)()) F1406_13441;
}

char *(*R9892[156])();
void R9892_init () {
	R9892[0] = (char *(*)()) F1251_11591;
	R9892[1] = (char *(*)()) F1252_11598;
	R9892[3] = (char *(*)()) F1254_11634;
	R9892[4] = (char *(*)()) F1255_11650;
	R9892[5] = (char *(*)()) F1256_11682;
	R9892[6] = (char *(*)()) F1257_11723;
	R9892[8] = (char *(*)()) F1259_11744;
	R9892[13] = (char *(*)()) F1262_11796;
	R9892[30] = (char *(*)()) F1281_11992;
	R9892[33] = (char *(*)()) F1282_12002;
	R9892[51] = (char *(*)()) F1302_12558;
	{long i; for (i = 102; i < 106; i++) R9892[i] = (char *(*)()) F1155_10572;}
	{long i; for (i = 107; i < 109; i++) R9892[i] = (char *(*)()) F1155_10572;}
	R9892[111] = (char *(*)()) F1362_13015;
	{long i; for (i = 112; i < 114; i++) R9892[i] = (char *(*)()) F1155_10572;}
	{long i; for (i = 115; i < 118; i++) R9892[i] = (char *(*)()) F1365_13065;}
	{long i; for (i = 120; i < 126; i++) R9892[i] = (char *(*)()) F1155_10572;}
	{long i; for (i = 128; i < 130; i++) R9892[i] = (char *(*)()) F1155_10572;}
	R9892[136] = (char *(*)()) F1155_10572;
	{long i; for (i = 139; i < 141; i++) R9892[i] = (char *(*)()) F1155_10572;}
	{long i; for (i = 143; i < 145; i++) R9892[i] = (char *(*)()) F1155_10572;}
	R9892[148] = (char *(*)()) F1155_10572;
	R9892[151] = (char *(*)()) F1155_10572;
	R9892[155] = (char *(*)()) F1155_10572;
}

char *(*R9893[156])();
void R9893_init () {
	{long i; for (i = 0; i < 2; i++) R9893[i] = (char *(*)()) F1248_11531;}
	{long i; for (i = 3; i < 7; i++) R9893[i] = (char *(*)()) F1248_11531;}
	R9893[8] = (char *(*)()) F1248_11531;
	R9893[13] = (char *(*)()) F1262_11758;
	R9893[30] = (char *(*)()) F1248_11531;
	R9893[33] = (char *(*)()) F1248_11531;
	R9893[51] = (char *(*)()) F1248_11531;
	{long i; for (i = 102; i < 106; i++) R9893[i] = (char *(*)()) F1248_11531;}
	R9893[107] = (char *(*)()) F1248_11531;
	R9893[108] = (char *(*)()) F1359_12956;
	R9893[111] = (char *(*)()) F1362_13016;
	{long i; for (i = 112; i < 114; i++) R9893[i] = (char *(*)()) F1363_13042;}
	R9893[115] = (char *(*)()) F1366_13097;
	R9893[116] = (char *(*)()) F1367_13098;
	R9893[117] = (char *(*)()) F1368_13099;
	{long i; for (i = 120; i < 126; i++) R9893[i] = (char *(*)()) F1248_11531;}
	{long i; for (i = 128; i < 130; i++) R9893[i] = (char *(*)()) F1248_11531;}
	R9893[136] = (char *(*)()) F1248_11531;
	{long i; for (i = 139; i < 141; i++) R9893[i] = (char *(*)()) F1248_11531;}
	{long i; for (i = 143; i < 145; i++) R9893[i] = (char *(*)()) F1248_11531;}
	R9893[148] = (char *(*)()) F1248_11531;
	R9893[151] = (char *(*)()) F1248_11531;
	R9893[155] = (char *(*)()) F1248_11531;
}

char *(*R10110[111])();
void R10110_init () {
	R10110[0] = (char *(*)()) F1265_11808;
	{long i; for (i = 72; i < 76; i++) R10110[i] = (char *(*)()) F1265_11808;}
	{long i; for (i = 77; i < 79; i++) R10110[i] = (char *(*)()) F1265_11808;}
	{long i; for (i = 81; i < 84; i++) R10110[i] = (char *(*)()) F1265_11808;}
	{long i; for (i = 85; i < 88; i++) R10110[i] = (char *(*)()) F1365_13069;}
	{long i; for (i = 90; i < 96; i++) R10110[i] = (char *(*)()) F1265_11808;}
	{long i; for (i = 98; i < 100; i++) R10110[i] = (char *(*)()) F1265_11808;}
	R10110[106] = (char *(*)()) F1265_11808;
	{long i; for (i = 109; i < 111; i++) R10110[i] = (char *(*)()) F1265_11808;}
}

char *(*R10111[111])();
void R10111_init () {
	R10111[0] = (char *(*)()) F1265_11809;
	{long i; for (i = 72; i < 76; i++) R10111[i] = (char *(*)()) F1265_11809;}
	{long i; for (i = 77; i < 79; i++) R10111[i] = (char *(*)()) F1265_11809;}
	{long i; for (i = 81; i < 84; i++) R10111[i] = (char *(*)()) F1265_11809;}
	{long i; for (i = 85; i < 88; i++) R10111[i] = (char *(*)()) F1365_13070;}
	{long i; for (i = 90; i < 96; i++) R10111[i] = (char *(*)()) F1265_11809;}
	{long i; for (i = 98; i < 100; i++) R10111[i] = (char *(*)()) F1265_11809;}
	R10111[106] = (char *(*)()) F1265_11809;
	{long i; for (i = 109; i < 111; i++) R10111[i] = (char *(*)()) F1265_11809;}
}

char *(*R10113[111])();
void R10113_init () {
	R10113[0] = (char *(*)()) F1265_11811;
	{long i; for (i = 72; i < 76; i++) R10113[i] = (char *(*)()) F1265_11811;}
	{long i; for (i = 77; i < 79; i++) R10113[i] = (char *(*)()) F1265_11811;}
	{long i; for (i = 81; i < 84; i++) R10113[i] = (char *(*)()) F1265_11811;}
	{long i; for (i = 85; i < 88; i++) R10113[i] = (char *(*)()) F1365_13072;}
	{long i; for (i = 90; i < 96; i++) R10113[i] = (char *(*)()) F1265_11811;}
	{long i; for (i = 98; i < 100; i++) R10113[i] = (char *(*)()) F1265_11811;}
	R10113[106] = (char *(*)()) F1265_11811;
	{long i; for (i = 109; i < 111; i++) R10113[i] = (char *(*)()) F1265_11811;}
}

char *(*R10867[34])();
void R10867_init () {
	R10867[0] = (char *(*)()) F1305_12679;
	R10867[1] = (char *(*)()) F1306_12679;
	R10867[2] = (char *(*)()) F1307_12679;
	R10867[3] = (char *(*)()) F1308_12679;
	R10867[4] = (char *(*)()) F1309_12679;
	R10867[5] = (char *(*)()) F1310_12679;
	R10867[6] = (char *(*)()) F1311_12679;
	R10867[7] = (char *(*)()) F1312_12679;
	R10867[8] = (char *(*)()) F1313_12679;
	R10867[9] = (char *(*)()) F1314_12679;
	R10867[10] = (char *(*)()) F1315_12679;
	R10867[11] = (char *(*)()) F1316_12679;
	R10867[12] = (char *(*)()) F1317_12679;
	R10867[13] = (char *(*)()) F1318_12679;
	R10867[14] = (char *(*)()) F1319_12679;
	R10867[15] = (char *(*)()) F1320_12679;
	R10867[16] = (char *(*)()) F1321_12679;
	R10867[17] = (char *(*)()) F1322_12679;
	R10867[18] = (char *(*)()) F1323_12679;
	R10867[19] = (char *(*)()) F1324_12679;
	R10867[20] = (char *(*)()) F1325_12679;
	R10867[21] = (char *(*)()) F1326_12679;
	R10867[22] = (char *(*)()) F1327_12679;
	R10867[23] = (char *(*)()) F1328_12679;
	R10867[24] = (char *(*)()) F1329_12679;
	R10867[25] = (char *(*)()) F1330_12679;
	R10867[26] = (char *(*)()) F1331_12679;
	R10867[27] = (char *(*)()) F1332_12679;
	R10867[28] = (char *(*)()) F1333_12679;
	R10867[29] = (char *(*)()) F1334_12679;
	R10867[30] = (char *(*)()) F1335_12679;
	R10867[31] = (char *(*)()) F1336_12679;
	R10867[32] = (char *(*)()) F1337_12679;
	R10867[33] = (char *(*)()) F1338_12679;
}

char *(*R10868[34])();
void R10868_init () {
	R10868[0] = (char *(*)()) F1305_12680;
	R10868[1] = (char *(*)()) F1306_12680;
	R10868[2] = (char *(*)()) F1307_12680;
	R10868[3] = (char *(*)()) F1308_12680;
	R10868[4] = (char *(*)()) F1309_12680;
	R10868[5] = (char *(*)()) F1310_12680;
	R10868[6] = (char *(*)()) F1311_12680;
	R10868[7] = (char *(*)()) F1312_12680;
	R10868[8] = (char *(*)()) F1313_12680;
	R10868[9] = (char *(*)()) F1314_12680;
	R10868[10] = (char *(*)()) F1315_12680;
	R10868[11] = (char *(*)()) F1316_12680;
	R10868[12] = (char *(*)()) F1317_12680;
	R10868[13] = (char *(*)()) F1318_12680;
	R10868[14] = (char *(*)()) F1319_12680;
	R10868[15] = (char *(*)()) F1320_12680;
	R10868[16] = (char *(*)()) F1321_12680;
	R10868[17] = (char *(*)()) F1322_12680;
	R10868[18] = (char *(*)()) F1323_12680;
	R10868[19] = (char *(*)()) F1324_12680;
	R10868[20] = (char *(*)()) F1325_12680;
	R10868[21] = (char *(*)()) F1326_12680;
	R10868[22] = (char *(*)()) F1327_12680;
	R10868[23] = (char *(*)()) F1328_12680;
	R10868[24] = (char *(*)()) F1329_12680;
	R10868[25] = (char *(*)()) F1330_12680;
	R10868[26] = (char *(*)()) F1331_12680;
	R10868[27] = (char *(*)()) F1332_12680;
	R10868[28] = (char *(*)()) F1333_12680;
	R10868[29] = (char *(*)()) F1334_12680;
	R10868[30] = (char *(*)()) F1335_12680;
	R10868[31] = (char *(*)()) F1336_12680;
	R10868[32] = (char *(*)()) F1337_12680;
	R10868[33] = (char *(*)()) F1338_12680;
}

char *(*R10869[34])();
void R10869_init () {
	R10869[0] = (char *(*)()) F1305_12681;
	R10869[1] = (char *(*)()) F1306_12681;
	R10869[2] = (char *(*)()) F1307_12681;
	R10869[3] = (char *(*)()) F1308_12681;
	R10869[4] = (char *(*)()) F1309_12681;
	R10869[5] = (char *(*)()) F1310_12681;
	R10869[6] = (char *(*)()) F1311_12681;
	R10869[7] = (char *(*)()) F1312_12681;
	R10869[8] = (char *(*)()) F1313_12681;
	R10869[9] = (char *(*)()) F1314_12681;
	R10869[10] = (char *(*)()) F1315_12681;
	R10869[11] = (char *(*)()) F1316_12681;
	R10869[12] = (char *(*)()) F1317_12681;
	R10869[13] = (char *(*)()) F1318_12681;
	R10869[14] = (char *(*)()) F1319_12681;
	R10869[15] = (char *(*)()) F1320_12681;
	R10869[16] = (char *(*)()) F1321_12681;
	R10869[17] = (char *(*)()) F1322_12681;
	R10869[18] = (char *(*)()) F1323_12681;
	R10869[19] = (char *(*)()) F1324_12681;
	R10869[20] = (char *(*)()) F1325_12681;
	R10869[21] = (char *(*)()) F1326_12681;
	R10869[22] = (char *(*)()) F1327_12681;
	R10869[23] = (char *(*)()) F1328_12681;
	R10869[24] = (char *(*)()) F1329_12681;
	R10869[25] = (char *(*)()) F1330_12681;
	R10869[26] = (char *(*)()) F1331_12681;
	R10869[27] = (char *(*)()) F1332_12681;
	R10869[28] = (char *(*)()) F1333_12681;
	R10869[29] = (char *(*)()) F1334_12681;
	R10869[30] = (char *(*)()) F1335_12681;
	R10869[31] = (char *(*)()) F1336_12681;
	R10869[32] = (char *(*)()) F1337_12681;
	R10869[33] = (char *(*)()) F1338_12681;
}

char *(*R10870[34])();
void R10870_init () {
	R10870[0] = (char *(*)()) F1305_12682;
	R10870[1] = (char *(*)()) F1306_12682;
	R10870[2] = (char *(*)()) F1307_12682;
	R10870[3] = (char *(*)()) F1308_12682;
	R10870[4] = (char *(*)()) F1309_12682;
	R10870[5] = (char *(*)()) F1310_12682;
	R10870[6] = (char *(*)()) F1311_12682;
	R10870[7] = (char *(*)()) F1312_12682;
	R10870[8] = (char *(*)()) F1313_12682;
	R10870[9] = (char *(*)()) F1314_12682;
	R10870[10] = (char *(*)()) F1315_12682;
	R10870[11] = (char *(*)()) F1316_12682;
	R10870[12] = (char *(*)()) F1317_12682;
	R10870[13] = (char *(*)()) F1318_12682;
	R10870[14] = (char *(*)()) F1319_12682;
	R10870[15] = (char *(*)()) F1320_12682;
	R10870[16] = (char *(*)()) F1321_12682;
	R10870[17] = (char *(*)()) F1322_12682;
	R10870[18] = (char *(*)()) F1323_12682;
	R10870[19] = (char *(*)()) F1324_12682;
	R10870[20] = (char *(*)()) F1325_12682;
	R10870[21] = (char *(*)()) F1326_12682;
	R10870[22] = (char *(*)()) F1327_12682;
	R10870[23] = (char *(*)()) F1328_12682;
	R10870[24] = (char *(*)()) F1329_12682;
	R10870[25] = (char *(*)()) F1330_12682;
	R10870[26] = (char *(*)()) F1331_12682;
	R10870[27] = (char *(*)()) F1332_12682;
	R10870[28] = (char *(*)()) F1333_12682;
	R10870[29] = (char *(*)()) F1334_12682;
	R10870[30] = (char *(*)()) F1335_12682;
	R10870[31] = (char *(*)()) F1336_12682;
	R10870[32] = (char *(*)()) F1337_12682;
	R10870[33] = (char *(*)()) F1338_12682;
}

char *(*R10875[34])();
void R10875_init () {
	R10875[0] = (char *(*)()) F1305_12688;
	R10875[1] = (char *(*)()) F1306_12688;
	R10875[2] = (char *(*)()) F1307_12688;
	R10875[3] = (char *(*)()) F1308_12688;
	R10875[4] = (char *(*)()) F1309_12688;
	R10875[5] = (char *(*)()) F1310_12688;
	R10875[6] = (char *(*)()) F1311_12688;
	R10875[7] = (char *(*)()) F1312_12688;
	R10875[8] = (char *(*)()) F1313_12688;
	R10875[9] = (char *(*)()) F1314_12688;
	R10875[10] = (char *(*)()) F1315_12688;
	R10875[11] = (char *(*)()) F1316_12688;
	R10875[12] = (char *(*)()) F1317_12688;
	R10875[13] = (char *(*)()) F1318_12688;
	R10875[14] = (char *(*)()) F1319_12688;
	R10875[15] = (char *(*)()) F1320_12688;
	R10875[16] = (char *(*)()) F1321_12688;
	R10875[17] = (char *(*)()) F1322_12688;
	R10875[18] = (char *(*)()) F1323_12688;
	R10875[19] = (char *(*)()) F1324_12688;
	R10875[20] = (char *(*)()) F1325_12688;
	R10875[21] = (char *(*)()) F1326_12688;
	R10875[22] = (char *(*)()) F1327_12688;
	R10875[23] = (char *(*)()) F1328_12688;
	R10875[24] = (char *(*)()) F1329_12688;
	R10875[25] = (char *(*)()) F1330_12688;
	R10875[26] = (char *(*)()) F1331_12688;
	R10875[27] = (char *(*)()) F1332_12688;
	R10875[28] = (char *(*)()) F1333_12688;
	R10875[29] = (char *(*)()) F1334_12688;
	R10875[30] = (char *(*)()) F1335_12688;
	R10875[31] = (char *(*)()) F1336_12688;
	R10875[32] = (char *(*)()) F1337_12688;
	R10875[33] = (char *(*)()) F1338_12688;
}

char *(*R10880[34])();
void R10880_init () {
	R10880[0] = (char *(*)()) F1305_12696;
	R10880[1] = (char *(*)()) F1306_12696_10880_1;
	R10880[2] = (char *(*)()) F1307_12696_10880_1;
	R10880[3] = (char *(*)()) F1308_12696_10880_1;
	R10880[4] = (char *(*)()) F1309_12696_10880_1;
	R10880[5] = (char *(*)()) F1310_12696_10880_1;
	R10880[6] = (char *(*)()) F1311_12696_10880_1;
	R10880[7] = (char *(*)()) F1312_12696_10880_1;
	R10880[8] = (char *(*)()) F1313_12696_10880_1;
	R10880[9] = (char *(*)()) F1314_12696_10880_1;
	R10880[10] = (char *(*)()) F1315_12696_10880_1;
	R10880[11] = (char *(*)()) F1316_12696_10880_1;
	R10880[12] = (char *(*)()) F1317_12696_10880_1;
	R10880[13] = (char *(*)()) F1318_12696_10880_1;
	R10880[14] = (char *(*)()) F1319_12696_10880_1;
	R10880[15] = (char *(*)()) F1320_12696_10880_1;
	R10880[16] = (char *(*)()) F1321_12696;
	R10880[17] = (char *(*)()) F1322_12696;
	R10880[18] = (char *(*)()) F1323_12696_10880_1;
	R10880[19] = (char *(*)()) F1324_12696_10880_1;
	R10880[20] = (char *(*)()) F1325_12696_10880_1;
	R10880[21] = (char *(*)()) F1326_12696;
	R10880[22] = (char *(*)()) F1327_12696;
	R10880[23] = (char *(*)()) F1328_12696_10880_1;
	R10880[24] = (char *(*)()) F1329_12696_10880_1;
	R10880[25] = (char *(*)()) F1330_12696_10880_1;
	R10880[26] = (char *(*)()) F1331_12696_10880_1;
	R10880[27] = (char *(*)()) F1332_12696_10880_1;
	R10880[28] = (char *(*)()) F1333_12696_10880_1;
	R10880[29] = (char *(*)()) F1334_12696_10880_1;
	R10880[30] = (char *(*)()) F1335_12696_10880_1;
	R10880[31] = (char *(*)()) F1336_12696_10880_1;
	R10880[32] = (char *(*)()) F1337_12696_10880_1;
	R10880[33] = (char *(*)()) F1338_12696_10880_1;
}
static EIF_REFERENCE F1306_12696_10880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1306_12696(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1307_12696_10880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REFERENCE* r = F1307_12696(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1198,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1198, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REFERENCE* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1308_12696_10880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1308_12696(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1510, 0x00).id, 1510, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1309_12696_10880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1309_12696(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1507, 0x00).id, 1507, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1310_12696_10880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F1310_12696(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1504, 0x00).id, 1504, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1311_12696_10880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F1311_12696(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1501, 0x00).id, 1501, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1312_12696_10880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1312_12696(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1498, 0x00).id, 1498, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1313_12696_10880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1313_12696(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1495, 0x00).id, 1495, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1314_12696_10880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F1314_12696(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(1492, 0x00).id, 1492, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1315_12696_10880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F1315_12696(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(1489, 0x00).id, 1489, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1316_12696_10880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1316_12696(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1317_12696_10880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F1317_12696(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(1483, 0x00).id, 1483, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1318_12696_10880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1318_12696(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1192, 0x00).id, 1192, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1319_12696_10880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1319_12696(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1320_12696_10880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1320_12696(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1195, 0x00).id, 1195, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1323_12696_10880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16* r = F1323_12696(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1200,1501,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1200, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1324_12696_10880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8* r = F1324_12696(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1202,1504,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1202, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1325_12696_10880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32* r = F1325_12696(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1204,1507,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1204, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1328_12696_10880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER* r = F1328_12696(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1206,1228,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1206, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_POINTER* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1329_12696_10880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64* r = F1329_12696(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1208,1510,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1208, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1330_12696_10880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN* r = F1330_12696(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1210,1195,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1210, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_BOOLEAN* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1331_12696_10880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64* r = F1331_12696(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1212,1495,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1212, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1332_12696_10880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32* r = F1332_12696(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1214,1498,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1214, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1333_12696_10880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8* r = F1333_12696(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1216,1192,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1216, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1334_12696_10880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32* r = F1334_12696(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1218,1486,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1218, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1335_12696_10880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16* r = F1335_12696(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1220,1489,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1220, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1336_12696_10880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8* r = F1336_12696(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1222,1492,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1222, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1337_12696_10880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64* r = F1337_12696(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1224,1483,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1224, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1338_12696_10880_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32* r = F1338_12696(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1226,1189,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1226, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_32* *)Result = r;
		return Result;
	}
}

char *(*R10890[34])();
void R10890_init () {
	R10890[0] = (char *(*)()) F1305_12708;
	R10890[1] = (char *(*)()) F1306_12708;
	R10890[2] = (char *(*)()) F1307_12708;
	R10890[3] = (char *(*)()) F1308_12708;
	R10890[4] = (char *(*)()) F1309_12708;
	R10890[5] = (char *(*)()) F1310_12708;
	R10890[6] = (char *(*)()) F1311_12708;
	R10890[7] = (char *(*)()) F1312_12708;
	R10890[8] = (char *(*)()) F1313_12708;
	R10890[9] = (char *(*)()) F1314_12708;
	R10890[10] = (char *(*)()) F1315_12708;
	R10890[11] = (char *(*)()) F1316_12708;
	R10890[12] = (char *(*)()) F1317_12708;
	R10890[13] = (char *(*)()) F1318_12708;
	R10890[14] = (char *(*)()) F1319_12708;
	R10890[15] = (char *(*)()) F1320_12708;
	R10890[16] = (char *(*)()) F1321_12708;
	R10890[17] = (char *(*)()) F1322_12708;
	R10890[18] = (char *(*)()) F1323_12708;
	R10890[19] = (char *(*)()) F1324_12708;
	R10890[20] = (char *(*)()) F1325_12708;
	R10890[21] = (char *(*)()) F1326_12708;
	R10890[22] = (char *(*)()) F1327_12708;
	R10890[23] = (char *(*)()) F1328_12708;
	R10890[24] = (char *(*)()) F1329_12708;
	R10890[25] = (char *(*)()) F1330_12708;
	R10890[26] = (char *(*)()) F1331_12708;
	R10890[27] = (char *(*)()) F1332_12708;
	R10890[28] = (char *(*)()) F1333_12708;
	R10890[29] = (char *(*)()) F1334_12708;
	R10890[30] = (char *(*)()) F1335_12708;
	R10890[31] = (char *(*)()) F1336_12708;
	R10890[32] = (char *(*)()) F1337_12708;
	R10890[33] = (char *(*)()) F1338_12708;
}

char *(*R10892[54])();
void R10892_init () {
	{long i; for (i = 0; i < 4; i++) R10892[i] = (char *(*)()) F1347_12792;}
	{long i; for (i = 5; i < 7; i++) R10892[i] = (char *(*)()) F1347_12792;}
	{long i; for (i = 9; i < 12; i++) R10892[i] = (char *(*)()) F1347_12792;}
	{long i; for (i = 13; i < 16; i++) R10892[i] = (char *(*)()) F1347_12792;}
	{long i; for (i = 18; i < 24; i++) R10892[i] = (char *(*)()) F1347_12792;}
	{long i; for (i = 26; i < 28; i++) R10892[i] = (char *(*)()) F1347_12792;}
	R10892[34] = (char *(*)()) F1347_12792;
	{long i; for (i = 37; i < 39; i++) R10892[i] = (char *(*)()) F1347_12792;}
	{long i; for (i = 41; i < 43; i++) R10892[i] = (char *(*)()) F1392_13357;}
	R10892[46] = (char *(*)()) F1398_13403;
	R10892[49] = (char *(*)()) F1392_13357;
	R10892[53] = (char *(*)()) F1406_13435;
}

char *(*R10894[54])();
void R10894_init () {
	{long i; for (i = 0; i < 3; i++) R10894[i] = (char *(*)()) F1339_12711;}
	R10894[3] = (char *(*)()) F1356_12924;
	{long i; for (i = 5; i < 7; i++) R10894[i] = (char *(*)()) F1339_12711;}
	{long i; for (i = 9; i < 12; i++) R10894[i] = (char *(*)()) F1339_12711;}
	{long i; for (i = 13; i < 16; i++) R10894[i] = (char *(*)()) F1365_13071;}
	{long i; for (i = 18; i < 24; i++) R10894[i] = (char *(*)()) F1339_12711;}
	R10894[26] = (char *(*)()) F1339_12711;
	R10894[27] = (char *(*)()) F1380_13227;
	R10894[34] = (char *(*)()) F1339_12711;
	{long i; for (i = 37; i < 39; i++) R10894[i] = (char *(*)()) F1339_12711;}
	{long i; for (i = 41; i < 43; i++) R10894[i] = (char *(*)()) F1339_12711;}
	R10894[46] = (char *(*)()) F1339_12711;
	R10894[49] = (char *(*)()) F1402_13420;
	R10894[53] = (char *(*)()) F1402_13420;
}

char *(*R10967[16])();
void R10967_init () {
	{long i; for (i = 0; i < 2; i++) R10967[i] = (char *(*)()) F1341_12738;}
	{long i; for (i = 2; i < 4; i++) R10967[i] = (char *(*)()) F1348_12833;}
	{long i; for (i = 5; i < 7; i++) R10967[i] = (char *(*)()) F1348_12833;}
	{long i; for (i = 9; i < 12; i++) R10967[i] = (char *(*)()) F1348_12833;}
	{long i; for (i = 13; i < 16; i++) R10967[i] = (char *(*)()) F1348_12833;}
}

char *(*R10970[16])();
void R10970_init () {
	{long i; for (i = 0; i < 2; i++) R10970[i] = (char *(*)()) F1341_12747;}
	{long i; for (i = 2; i < 4; i++) R10970[i] = (char *(*)()) F1355_12918;}
	{long i; for (i = 5; i < 7; i++) R10970[i] = (char *(*)()) F1355_12918;}
	{long i; for (i = 9; i < 12; i++) R10970[i] = (char *(*)()) F1355_12918;}
	{long i; for (i = 13; i < 16; i++) R10970[i] = (char *(*)()) F1355_12918;}
}

char *(*R11373[12])();
void R11373_init () {
	R11373[0] = (char *(*)()) F1408_13459;
	R11373[1] = (char *(*)()) F1409_13459;
	R11373[2] = (char *(*)()) F1410_13459;
	R11373[3] = (char *(*)()) F1411_13459;
	R11373[4] = (char *(*)()) F1412_13459;
	R11373[5] = (char *(*)()) F1413_13459;
	R11373[6] = (char *(*)()) F1414_13459;
	R11373[7] = (char *(*)()) F1415_13459;
	R11373[8] = (char *(*)()) F1416_13459;
	R11373[9] = (char *(*)()) F1417_13459;
	R11373[10] = (char *(*)()) F1418_13459;
	R11373[11] = (char *(*)()) F1419_13459;
}

char *(*R11374[12])();
void R11374_init () {
	R11374[0] = (char *(*)()) F1408_13460;
	R11374[1] = (char *(*)()) F1409_13460;
	R11374[2] = (char *(*)()) F1410_13460;
	R11374[3] = (char *(*)()) F1411_13460;
	R11374[4] = (char *(*)()) F1412_13460;
	R11374[5] = (char *(*)()) F1413_13460;
	R11374[6] = (char *(*)()) F1414_13460;
	R11374[7] = (char *(*)()) F1415_13460;
	R11374[8] = (char *(*)()) F1416_13460;
	R11374[9] = (char *(*)()) F1417_13460;
	R11374[10] = (char *(*)()) F1418_13460;
	R11374[11] = (char *(*)()) F1419_13460;
}

char *(*R11376[12])();
void R11376_init () {
	R11376[0] = (char *(*)()) F1408_13446;
	R11376[1] = (char *(*)()) F1409_13446;
	R11376[2] = (char *(*)()) F1410_13446;
	R11376[3] = (char *(*)()) F1411_13446;
	R11376[4] = (char *(*)()) F1412_13446;
	R11376[5] = (char *(*)()) F1413_13446;
	R11376[6] = (char *(*)()) F1414_13446;
	R11376[7] = (char *(*)()) F1415_13446;
	R11376[8] = (char *(*)()) F1416_13446;
	R11376[9] = (char *(*)()) F1417_13446;
	R11376[10] = (char *(*)()) F1418_13446;
	R11376[11] = (char *(*)()) F1419_13446;
}

char *(*R11377[12])();
void R11377_init () {
	R11377[0] = (char *(*)()) F1408_13447;
	R11377[1] = (char *(*)()) F1409_13447_11377_182;
	R11377[2] = (char *(*)()) F1410_13447_11377_182;
	R11377[3] = (char *(*)()) F1411_13447_11377_182;
	R11377[4] = (char *(*)()) F1412_13447_11377_182;
	R11377[5] = (char *(*)()) F1413_13447_11377_182;
	R11377[6] = (char *(*)()) F1414_13447_11377_182;
	R11377[7] = (char *(*)()) F1415_13447_11377_182;
	R11377[8] = (char *(*)()) F1416_13447_11377_182;
	R11377[9] = (char *(*)()) F1417_13447_11377_182;
	R11377[10] = (char *(*)()) F1418_13447_11377_182;
	R11377[11] = (char *(*)()) F1419_13447_11377_182;
}
static void F1409_13447_11377_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1409_13447(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F1410_13447_11377_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1410_13447(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F1411_13447_11377_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1411_13447(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1412_13447_11377_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1412_13447(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F1413_13447_11377_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1413_13447(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F1414_13447_11377_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1414_13447(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F1415_13447_11377_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1415_13447(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F1416_13447_11377_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1416_13447(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F1417_13447_11377_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1417_13447(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F1418_13447_11377_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1418_13447(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F1419_13447_11377_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1419_13447(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R11386[12])();
void R11386_init () {
	R11386[0] = (char *(*)()) F1408_13462;
	R11386[1] = (char *(*)()) F1409_13462;
	R11386[2] = (char *(*)()) F1410_13462;
	R11386[3] = (char *(*)()) F1411_13462;
	R11386[4] = (char *(*)()) F1412_13462;
	R11386[5] = (char *(*)()) F1413_13462;
	R11386[6] = (char *(*)()) F1414_13462;
	R11386[7] = (char *(*)()) F1415_13462;
	R11386[8] = (char *(*)()) F1416_13462;
	R11386[9] = (char *(*)()) F1417_13462;
	R11386[10] = (char *(*)()) F1418_13462;
	R11386[11] = (char *(*)()) F1419_13462;
}

char *(*R11387[12])();
void R11387_init () {
	R11387[0] = (char *(*)()) F1408_13464;
	R11387[1] = (char *(*)()) F1409_13464_11387_182;
	R11387[2] = (char *(*)()) F1410_13464_11387_182;
	R11387[3] = (char *(*)()) F1411_13464_11387_182;
	R11387[4] = (char *(*)()) F1412_13464_11387_182;
	R11387[5] = (char *(*)()) F1413_13464_11387_182;
	R11387[6] = (char *(*)()) F1414_13464_11387_182;
	R11387[7] = (char *(*)()) F1415_13464_11387_182;
	R11387[8] = (char *(*)()) F1416_13464_11387_182;
	R11387[9] = (char *(*)()) F1417_13464_11387_182;
	R11387[10] = (char *(*)()) F1418_13464_11387_182;
	R11387[11] = (char *(*)()) F1419_13464_11387_182;
}
static void F1409_13464_11387_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1409_13464(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F1410_13464_11387_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1410_13464(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F1411_13464_11387_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1411_13464(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1412_13464_11387_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1412_13464(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F1413_13464_11387_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1413_13464(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F1414_13464_11387_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1414_13464(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F1415_13464_11387_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1415_13464(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F1416_13464_11387_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1416_13464(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F1417_13464_11387_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1417_13464(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F1418_13464_11387_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1418_13464(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F1419_13464_11387_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1419_13464(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R11388[12])();
void R11388_init () {
	R11388[0] = (char *(*)()) F1408_13465;
	R11388[1] = (char *(*)()) F1409_13465_11388_182;
	R11388[2] = (char *(*)()) F1410_13465_11388_182;
	R11388[3] = (char *(*)()) F1411_13465_11388_182;
	R11388[4] = (char *(*)()) F1412_13465_11388_182;
	R11388[5] = (char *(*)()) F1413_13465_11388_182;
	R11388[6] = (char *(*)()) F1414_13465_11388_182;
	R11388[7] = (char *(*)()) F1415_13465_11388_182;
	R11388[8] = (char *(*)()) F1416_13465_11388_182;
	R11388[9] = (char *(*)()) F1417_13465_11388_182;
	R11388[10] = (char *(*)()) F1418_13465_11388_182;
	R11388[11] = (char *(*)()) F1419_13465_11388_182;
}
static void F1409_13465_11388_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1409_13465(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F1410_13465_11388_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1410_13465(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F1411_13465_11388_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1411_13465(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1412_13465_11388_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1412_13465(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F1413_13465_11388_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1413_13465(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F1414_13465_11388_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1414_13465(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F1415_13465_11388_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1415_13465(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F1416_13465_11388_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1416_13465(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F1417_13465_11388_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1417_13465(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F1418_13465_11388_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1418_13465(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F1419_13465_11388_182 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1419_13465(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R11389[12])();
void R11389_init () {
	R11389[0] = (char *(*)()) F1408_13466;
	R11389[1] = (char *(*)()) F1409_13466_11389_4;
	R11389[2] = (char *(*)()) F1410_13466_11389_4;
	R11389[3] = (char *(*)()) F1411_13466_11389_4;
	R11389[4] = (char *(*)()) F1412_13466_11389_4;
	R11389[5] = (char *(*)()) F1413_13466_11389_4;
	R11389[6] = (char *(*)()) F1414_13466_11389_4;
	R11389[7] = (char *(*)()) F1415_13466_11389_4;
	R11389[8] = (char *(*)()) F1416_13466_11389_4;
	R11389[9] = (char *(*)()) F1417_13466_11389_4;
	R11389[10] = (char *(*)()) F1418_13466_11389_4;
	R11389[11] = (char *(*)()) F1419_13466_11389_4;
}
static void F1409_13466_11389_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1409_13466(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F1410_13466_11389_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1410_13466(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F1411_13466_11389_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1411_13466(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1412_13466_11389_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1412_13466(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F1413_13466_11389_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1413_13466(Current, *(EIF_BOOLEAN *)arg1);
}
static void F1414_13466_11389_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1414_13466(Current, *(EIF_POINTER *)arg1);
}
static void F1415_13466_11389_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1415_13466(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1416_13466_11389_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1416_13466(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1417_13466_11389_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1417_13466(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F1418_13466_11389_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1418_13466(Current, *(EIF_REAL_32 *)arg1);
}
static void F1419_13466_11389_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1419_13466(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R11391[12])();
void R11391_init () {
	R11391[0] = (char *(*)()) F1408_13468;
	R11391[1] = (char *(*)()) F1409_13468_11391_20;
	R11391[2] = (char *(*)()) F1410_13468_11391_20;
	R11391[3] = (char *(*)()) F1411_13468_11391_20;
	R11391[4] = (char *(*)()) F1412_13468_11391_20;
	R11391[5] = (char *(*)()) F1413_13468_11391_20;
	R11391[6] = (char *(*)()) F1414_13468_11391_20;
	R11391[7] = (char *(*)()) F1415_13468_11391_20;
	R11391[8] = (char *(*)()) F1416_13468_11391_20;
	R11391[9] = (char *(*)()) F1417_13468_11391_20;
	R11391[10] = (char *(*)()) F1418_13468_11391_20;
	R11391[11] = (char *(*)()) F1419_13468_11391_20;
}
static void F1409_13468_11391_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1409_13468(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F1410_13468_11391_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1410_13468(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F1411_13468_11391_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1411_13468(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F1412_13468_11391_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1412_13468(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F1413_13468_11391_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1413_13468(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F1414_13468_11391_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1414_13468(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F1415_13468_11391_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1415_13468(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F1416_13468_11391_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1416_13468(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F1417_13468_11391_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1417_13468(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F1418_13468_11391_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1418_13468(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F1419_13468_11391_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F1419_13468(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R11392[12])();
void R11392_init () {
	R11392[0] = (char *(*)()) F1408_13469;
	R11392[1] = (char *(*)()) F1409_13469;
	R11392[2] = (char *(*)()) F1410_13469;
	R11392[3] = (char *(*)()) F1411_13469;
	R11392[4] = (char *(*)()) F1412_13469;
	R11392[5] = (char *(*)()) F1413_13469;
	R11392[6] = (char *(*)()) F1414_13469;
	R11392[7] = (char *(*)()) F1415_13469;
	R11392[8] = (char *(*)()) F1416_13469;
	R11392[9] = (char *(*)()) F1417_13469;
	R11392[10] = (char *(*)()) F1418_13469;
	R11392[11] = (char *(*)()) F1419_13469;
}

char *(*R11394[12])();
void R11394_init () {
	R11394[0] = (char *(*)()) F1408_13471;
	R11394[1] = (char *(*)()) F1409_13471;
	R11394[2] = (char *(*)()) F1410_13471;
	R11394[3] = (char *(*)()) F1411_13471;
	R11394[4] = (char *(*)()) F1412_13471;
	R11394[5] = (char *(*)()) F1413_13471;
	R11394[6] = (char *(*)()) F1414_13471;
	R11394[7] = (char *(*)()) F1415_13471;
	R11394[8] = (char *(*)()) F1416_13471;
	R11394[9] = (char *(*)()) F1417_13471;
	R11394[10] = (char *(*)()) F1418_13471;
	R11394[11] = (char *(*)()) F1419_13471;
}

char *(*R11395[12])();
void R11395_init () {
	R11395[0] = (char *(*)()) F1408_13472;
	R11395[1] = (char *(*)()) F1409_13472;
	R11395[2] = (char *(*)()) F1410_13472;
	R11395[3] = (char *(*)()) F1411_13472;
	R11395[4] = (char *(*)()) F1412_13472;
	R11395[5] = (char *(*)()) F1413_13472;
	R11395[6] = (char *(*)()) F1414_13472;
	R11395[7] = (char *(*)()) F1415_13472;
	R11395[8] = (char *(*)()) F1416_13472;
	R11395[9] = (char *(*)()) F1417_13472;
	R11395[10] = (char *(*)()) F1418_13472;
	R11395[11] = (char *(*)()) F1419_13472;
}

char *(*R11396[12])();
void R11396_init () {
	R11396[0] = (char *(*)()) F1408_13473;
	R11396[1] = (char *(*)()) F1409_13473;
	R11396[2] = (char *(*)()) F1410_13473;
	R11396[3] = (char *(*)()) F1411_13473;
	R11396[4] = (char *(*)()) F1412_13473;
	R11396[5] = (char *(*)()) F1413_13473;
	R11396[6] = (char *(*)()) F1414_13473;
	R11396[7] = (char *(*)()) F1415_13473;
	R11396[8] = (char *(*)()) F1416_13473;
	R11396[9] = (char *(*)()) F1417_13473;
	R11396[10] = (char *(*)()) F1418_13473;
	R11396[11] = (char *(*)()) F1419_13473;
}

char *(*R11397[12])();
void R11397_init () {
	R11397[0] = (char *(*)()) F1408_13474;
	R11397[1] = (char *(*)()) F1409_13474;
	R11397[2] = (char *(*)()) F1410_13474;
	R11397[3] = (char *(*)()) F1411_13474;
	R11397[4] = (char *(*)()) F1412_13474;
	R11397[5] = (char *(*)()) F1413_13474;
	R11397[6] = (char *(*)()) F1414_13474;
	R11397[7] = (char *(*)()) F1415_13474;
	R11397[8] = (char *(*)()) F1416_13474;
	R11397[9] = (char *(*)()) F1417_13474;
	R11397[10] = (char *(*)()) F1418_13474;
	R11397[11] = (char *(*)()) F1419_13474;
}

char *(*R11398[12])();
void R11398_init () {
	R11398[0] = (char *(*)()) F1408_13475;
	R11398[1] = (char *(*)()) F1409_13475;
	R11398[2] = (char *(*)()) F1410_13475;
	R11398[3] = (char *(*)()) F1411_13475;
	R11398[4] = (char *(*)()) F1412_13475;
	R11398[5] = (char *(*)()) F1413_13475;
	R11398[6] = (char *(*)()) F1414_13475;
	R11398[7] = (char *(*)()) F1415_13475;
	R11398[8] = (char *(*)()) F1416_13475;
	R11398[9] = (char *(*)()) F1417_13475;
	R11398[10] = (char *(*)()) F1418_13475;
	R11398[11] = (char *(*)()) F1419_13475;
}

char *(*R11401[12])();
void R11401_init () {
	R11401[0] = (char *(*)()) F1408_13478;
	R11401[1] = (char *(*)()) F1409_13478;
	R11401[2] = (char *(*)()) F1410_13478;
	R11401[3] = (char *(*)()) F1411_13478;
	R11401[4] = (char *(*)()) F1412_13478;
	R11401[5] = (char *(*)()) F1413_13478;
	R11401[6] = (char *(*)()) F1414_13478;
	R11401[7] = (char *(*)()) F1415_13478;
	R11401[8] = (char *(*)()) F1416_13478;
	R11401[9] = (char *(*)()) F1417_13478;
	R11401[10] = (char *(*)()) F1418_13478;
	R11401[11] = (char *(*)()) F1419_13478;
}

char *(*R11404[12])();
void R11404_init () {
	R11404[0] = (char *(*)()) F1408_13481;
	R11404[1] = (char *(*)()) F1409_13481;
	R11404[2] = (char *(*)()) F1410_13481;
	R11404[3] = (char *(*)()) F1411_13481;
	R11404[4] = (char *(*)()) F1412_13481;
	R11404[5] = (char *(*)()) F1413_13481;
	R11404[6] = (char *(*)()) F1414_13481;
	R11404[7] = (char *(*)()) F1415_13481;
	R11404[8] = (char *(*)()) F1416_13481;
	R11404[9] = (char *(*)()) F1417_13481;
	R11404[10] = (char *(*)()) F1418_13481;
	R11404[11] = (char *(*)()) F1419_13481;
}

char *(*R11405[12])();
void R11405_init () {
	R11405[0] = (char *(*)()) F1408_13482;
	R11405[1] = (char *(*)()) F1409_13482_11405_12;
	R11405[2] = (char *(*)()) F1410_13482_11405_12;
	R11405[3] = (char *(*)()) F1411_13482_11405_12;
	R11405[4] = (char *(*)()) F1412_13482_11405_12;
	R11405[5] = (char *(*)()) F1413_13482_11405_12;
	R11405[6] = (char *(*)()) F1414_13482_11405_12;
	R11405[7] = (char *(*)()) F1415_13482_11405_12;
	R11405[8] = (char *(*)()) F1416_13482_11405_12;
	R11405[9] = (char *(*)()) F1417_13482_11405_12;
	R11405[10] = (char *(*)()) F1418_13482_11405_12;
	R11405[11] = (char *(*)()) F1419_13482_11405_12;
}
static EIF_REFERENCE F1409_13482_11405_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1409_13482(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F1410_13482_11405_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1410_13482(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static EIF_REFERENCE F1411_13482_11405_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1411_13482(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static EIF_REFERENCE F1412_13482_11405_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1412_13482(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static EIF_REFERENCE F1413_13482_11405_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1413_13482(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static EIF_REFERENCE F1414_13482_11405_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1414_13482(Current, *(EIF_POINTER *)arg1, arg2);
}
static EIF_REFERENCE F1415_13482_11405_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1415_13482(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static EIF_REFERENCE F1416_13482_11405_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1416_13482(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static EIF_REFERENCE F1417_13482_11405_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1417_13482(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static EIF_REFERENCE F1418_13482_11405_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1418_13482(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F1419_13482_11405_12 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F1419_13482(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R11407[12])();
void R11407_init () {
	R11407[0] = (char *(*)()) F1408_13484;
	R11407[1] = (char *(*)()) F1409_13484;
	R11407[2] = (char *(*)()) F1410_13484;
	R11407[3] = (char *(*)()) F1411_13484;
	R11407[4] = (char *(*)()) F1412_13484;
	R11407[5] = (char *(*)()) F1413_13484;
	R11407[6] = (char *(*)()) F1414_13484;
	R11407[7] = (char *(*)()) F1415_13484;
	R11407[8] = (char *(*)()) F1416_13484;
	R11407[9] = (char *(*)()) F1417_13484;
	R11407[10] = (char *(*)()) F1418_13484;
	R11407[11] = (char *(*)()) F1419_13484;
}

char *(*R11409[12])();
void R11409_init () {
	R11409[0] = (char *(*)()) F1408_13486;
	R11409[1] = (char *(*)()) F1409_13486;
	R11409[2] = (char *(*)()) F1410_13486;
	R11409[3] = (char *(*)()) F1411_13486;
	R11409[4] = (char *(*)()) F1412_13486;
	R11409[5] = (char *(*)()) F1413_13486;
	R11409[6] = (char *(*)()) F1414_13486;
	R11409[7] = (char *(*)()) F1415_13486;
	R11409[8] = (char *(*)()) F1416_13486;
	R11409[9] = (char *(*)()) F1417_13486;
	R11409[10] = (char *(*)()) F1418_13486;
	R11409[11] = (char *(*)()) F1419_13486;
}

char *(*R11416[12])();
void R11416_init () {
	R11416[0] = (char *(*)()) F1408_13494;
	R11416[1] = (char *(*)()) F1409_13494;
	R11416[2] = (char *(*)()) F1410_13494;
	R11416[3] = (char *(*)()) F1411_13494;
	R11416[4] = (char *(*)()) F1412_13494;
	R11416[5] = (char *(*)()) F1413_13494;
	R11416[6] = (char *(*)()) F1414_13494;
	R11416[7] = (char *(*)()) F1415_13494;
	R11416[8] = (char *(*)()) F1416_13494;
	R11416[9] = (char *(*)()) F1417_13494;
	R11416[10] = (char *(*)()) F1418_13494;
	R11416[11] = (char *(*)()) F1419_13494;
}

char *(*R11420[7])();
void R11420_init () {
	{long i; for (i = 0; i < 3; i++) R11420[i] = (char *(*)()) F1420_13498;}
	R11420[4] = (char *(*)()) F1427_13634;
	{long i; for (i = 5; i < 7; i++) R11420[i] = (char *(*)()) F1420_13498;}
}

char *(*R11447[7])();
void R11447_init () {
	{long i; for (i = 0; i < 3; i++) R11447[i] = (char *(*)()) F1423_13588;}
	R11447[4] = (char *(*)()) F1427_13647;
	{long i; for (i = 5; i < 7; i++) R11447[i] = (char *(*)()) F1428_13668;}
}

char *(*R11448[7])();
void R11448_init () {
	{long i; for (i = 0; i < 3; i++) R11448[i] = (char *(*)()) F1423_13589;}
	R11448[4] = (char *(*)()) F1427_13648;
	{long i; for (i = 5; i < 7; i++) R11448[i] = (char *(*)()) F1420_13527;}
}

char *(*R11594[37])();
void R11594_init () {
	R11594[0] = (char *(*)()) F1477_13762;
	R11594[1] = (char *(*)()) F1478_13767;
	R11594[2] = (char *(*)()) F1479_13785;
	R11594[3] = (char *(*)()) F1480_13811;
	R11594[35] = (char *(*)()) F1512_14770;
	R11594[36] = (char *(*)()) F1513_14785;
}

char *(*R11653[29])();
void R11653_init () {
	R11653[0] = (char *(*)()) F1483_13913_11653_1;
	R11653[1] = (char *(*)()) F1484_13913_11653_1;
	R11653[3] = (char *(*)()) F1486_14012_11653_1;
	R11653[4] = (char *(*)()) F1487_14012_11653_1;
	R11653[6] = (char *(*)()) F1489_14111_11653_1;
	R11653[7] = (char *(*)()) F1490_14111_11653_1;
	R11653[9] = (char *(*)()) F1492_14210_11653_1;
	R11653[10] = (char *(*)()) F1493_14210_11653_1;
	R11653[24] = (char *(*)()) F1507_14667_11653_1;
	R11653[25] = (char *(*)()) F1508_14667_11653_1;
	R11653[27] = (char *(*)()) F1510_14733_11653_1;
	R11653[28] = (char *(*)()) F1511_14733_11653_1;
}
static EIF_REFERENCE F1483_13913_11653_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F1483_13913(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(1483, 0x00).id, 1483, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1484_13913_11653_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F1484_13913(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(1483, 0x00).id, 1483, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1486_14012_11653_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1486_14012(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1487_14012_11653_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1487_14012(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1489_14111_11653_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F1489_14111(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(1489, 0x00).id, 1489, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1490_14111_11653_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F1490_14111(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(1489, 0x00).id, 1489, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1492_14210_11653_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F1492_14210(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(1492, 0x00).id, 1492, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1493_14210_11653_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F1493_14210(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(1492, 0x00).id, 1492, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1507_14667_11653_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1507_14667(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1507, 0x00).id, 1507, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1508_14667_11653_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1508_14667(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1507, 0x00).id, 1507, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1510_14733_11653_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1510_14733(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1510, 0x00).id, 1510, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1511_14733_11653_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1511_14733(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1510, 0x00).id, 1510, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R11672[2])();
void R11672_init () {
	R11672[0] = (char *(*)()) F1483_13919;
	R11672[1] = (char *(*)()) F1484_13919;
}

char *(*R11673[2])();
void R11673_init () {
	R11673[0] = (char *(*)()) F1483_13920;
	R11673[1] = (char *(*)()) F1484_13920;
}

char *(*R11676[2])();
void R11676_init () {
	R11676[0] = (char *(*)()) F1483_13923;
	R11676[1] = (char *(*)()) F1484_13923;
}

char *(*R11726[2])();
void R11726_init () {
	R11726[0] = (char *(*)()) F1486_14016;
	R11726[1] = (char *(*)()) F1487_14016;
}

char *(*R11728[2])();
void R11728_init () {
	R11728[0] = (char *(*)()) F1486_14018;
	R11728[1] = (char *(*)()) F1487_14018;
}

char *(*R11729[2])();
void R11729_init () {
	R11729[0] = (char *(*)()) F1486_14019;
	R11729[1] = (char *(*)()) F1487_14019;
}

char *(*R11731[2])();
void R11731_init () {
	R11731[0] = (char *(*)()) F1486_14021;
	R11731[1] = (char *(*)()) F1487_14021;
}

char *(*R11733[2])();
void R11733_init () {
	R11733[0] = (char *(*)()) F1486_14023;
	R11733[1] = (char *(*)()) F1487_14023;
}

char *(*R11785[2])();
void R11785_init () {
	R11785[0] = (char *(*)()) F1489_14118;
	R11785[1] = (char *(*)()) F1490_14118;
}

char *(*R11788[2])();
void R11788_init () {
	R11788[0] = (char *(*)()) F1489_14121;
	R11788[1] = (char *(*)()) F1490_14121;
}

char *(*R11838[2])();
void R11838_init () {
	R11838[0] = (char *(*)()) F1492_14214;
	R11838[1] = (char *(*)()) F1493_14214;
}

char *(*R11841[2])();
void R11841_init () {
	R11841[0] = (char *(*)()) F1492_14217;
	R11841[1] = (char *(*)()) F1493_14217;
}

char *(*R11844[2])();
void R11844_init () {
	R11844[0] = (char *(*)()) F1492_14220;
	R11844[1] = (char *(*)()) F1493_14220;
}

char *(*R11898[2])();
void R11898_init () {
	R11898[0] = (char *(*)()) F1495_14314;
	R11898[1] = (char *(*)()) F1496_14314;
}

char *(*R11944[2])();
void R11944_init () {
	R11944[0] = (char *(*)()) F1498_14402;
	R11944[1] = (char *(*)()) F1499_14402;
}

char *(*R11945[2])();
void R11945_init () {
	R11945[0] = (char *(*)()) F1498_14403;
	R11945[1] = (char *(*)()) F1499_14403;
}

char *(*R11947[2])();
void R11947_init () {
	R11947[0] = (char *(*)()) F1498_14405;
	R11947[1] = (char *(*)()) F1499_14405;
}

char *(*R11950[2])();
void R11950_init () {
	R11950[0] = (char *(*)()) F1498_14408;
	R11950[1] = (char *(*)()) F1499_14408;
}

char *(*R11951[2])();
void R11951_init () {
	R11951[0] = (char *(*)()) F1498_14409;
	R11951[1] = (char *(*)()) F1499_14409;
}

char *(*R11999[2])();
void R11999_init () {
	R11999[0] = (char *(*)()) F1501_14499;
	R11999[1] = (char *(*)()) F1502_14499;
}

char *(*R12000[2])();
void R12000_init () {
	R12000[0] = (char *(*)()) F1501_14500;
	R12000[1] = (char *(*)()) F1502_14500;
}

char *(*R12003[2])();
void R12003_init () {
	R12003[0] = (char *(*)()) F1501_14503;
	R12003[1] = (char *(*)()) F1502_14503;
}

char *(*R12051[2])();
void R12051_init () {
	R12051[0] = (char *(*)()) F1504_14593;
	R12051[1] = (char *(*)()) F1505_14593;
}

char *(*R12052[2])();
void R12052_init () {
	R12052[0] = (char *(*)()) F1504_14594;
	R12052[1] = (char *(*)()) F1505_14594;
}

char *(*R12053[2])();
void R12053_init () {
	R12053[0] = (char *(*)()) F1504_14595;
	R12053[1] = (char *(*)()) F1505_14595;
}

char *(*R12054[2])();
void R12054_init () {
	R12054[0] = (char *(*)()) F1504_14596;
	R12054[1] = (char *(*)()) F1505_14596;
}

char *(*R12056[2])();
void R12056_init () {
	R12056[0] = (char *(*)()) F1504_14598;
	R12056[1] = (char *(*)()) F1505_14598;
}

char *(*R12102[2])();
void R12102_init () {
	R12102[0] = (char *(*)()) F1507_14656;
	R12102[1] = (char *(*)()) F1508_14656;
}

char *(*R12109[2])();
void R12109_init () {
	R12109[0] = (char *(*)()) F1507_14660;
	R12109[1] = (char *(*)()) F1508_14660;
}

char *(*R12136[2])();
void R12136_init () {
	R12136[0] = (char *(*)()) F1510_14722;
	R12136[1] = (char *(*)()) F1511_14722;
}

char *(*R12143[2])();
void R12143_init () {
	R12143[0] = (char *(*)()) F1510_14726;
	R12143[1] = (char *(*)()) F1511_14726;
}

char *(*R12202[180])();
void R12202_init () {
	R12202[0] = (char *(*)()) F1520_14933;
	R12202[5] = (char *(*)()) F1525_15009;
	R12202[8] = (char *(*)()) F1528_15037;
	R12202[10] = (char *(*)()) F1530_15132;
	R12202[12] = (char *(*)()) F1532_15187;
	R12202[15] = (char *(*)()) F1535_15226;
	R12202[17] = (char *(*)()) F1536_15243;
	R12202[19] = (char *(*)()) F1539_15457;
	R12202[31] = (char *(*)()) F1548_15580;
	R12202[65] = (char *(*)()) F1548_15580;
	{long i; for (i = 82; i < 84; i++) R12202[i] = (char *(*)()) F1591_16232;}
	{long i; for (i = 92; i < 94; i++) R12202[i] = (char *(*)()) F1591_16232;}
	R12202[95] = (char *(*)()) F1591_16232;
	R12202[96] = (char *(*)()) F1616_16565;
	{long i; for (i = 98; i < 100; i++) R12202[i] = (char *(*)()) F1616_16565;}
	R12202[123] = (char *(*)()) F1589_16173;
	R12202[124] = (char *(*)()) F1644_16953;
	{long i; for (i = 125; i < 127; i++) R12202[i] = (char *(*)()) F1589_16173;}
	{long i; for (i = 129; i < 131; i++) R12202[i] = (char *(*)()) F1589_16173;}
	R12202[137] = (char *(*)()) F1589_16173;
	{long i; for (i = 140; i < 142; i++) R12202[i] = (char *(*)()) F1589_16173;}
	R12202[147] = (char *(*)()) F1548_15580;
	R12202[153] = (char *(*)()) F1672_17536;
	R12202[159] = (char *(*)()) F1672_17536;
	R12202[163] = (char *(*)()) F1683_17609;
	R12202[165] = (char *(*)()) F1685_17624;
	R12202[176] = (char *(*)()) F1696_17894;
	R12202[178] = (char *(*)()) F1698_18024;
	R12202[179] = (char *(*)()) F1699_18061;
}

char *(*R12742[82])();
void R12742_init () {
	{long i; for (i = 0; i < 2; i++) R12742[i] = (char *(*)()) F1542_15548;}
	R12742[41] = (char *(*)()) F1542_15548;
	R12742[42] = (char *(*)()) F1644_16947;
	R12742[44] = (char *(*)()) F1542_15548;
	R12742[81] = (char *(*)()) F1542_15548;
}

char *(*R12747[82])();
void R12747_init () {
	{long i; for (i = 0; i < 2; i++) R12747[i] = (char *(*)()) F1542_15549;}
	R12747[41] = (char *(*)()) F1542_15549;
	R12747[42] = (char *(*)()) F1644_16946;
	R12747[44] = (char *(*)()) F1542_15549;
	R12747[81] = (char *(*)()) F1542_15549;
}

char *(*R12769[82])();
void R12769_init () {
	{long i; for (i = 0; i < 2; i++) R12769[i] = (char *(*)()) F1541_15543;}
	R12769[41] = (char *(*)()) F1541_15543;
	R12769[42] = (char *(*)()) F1644_16966;
	R12769[44] = (char *(*)()) F1541_15543;
	R12769[81] = (char *(*)()) F1541_15543;
}

char *(*R12770[82])();
void R12770_init () {
	{long i; for (i = 0; i < 2; i++) R12770[i] = (char *(*)()) F1595_16265;}
	R12770[41] = (char *(*)()) F1643_16922;
	R12770[42] = (char *(*)()) F1644_16991;
	R12770[44] = (char *(*)()) F1646_17015;
	R12770[81] = (char *(*)()) F1547_15563;
}

char *(*R12771[82])();
void R12771_init () {
	{long i; for (i = 0; i < 2; i++) R12771[i] = (char *(*)()) F1595_16266;}
	R12771[41] = (char *(*)()) F1643_16923;
	R12771[42] = (char *(*)()) F1644_16992;
	R12771[44] = (char *(*)()) F1646_17016;
	R12771[81] = (char *(*)()) F1547_15567;
}

static EIF_TYPE_INDEX Y12772_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype3[] = {1395,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype4[] = {1401,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype6[] = {1401,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype7[] = {1401,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype8[] = {1401,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype9[] = {1346,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype10[] = {1346,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype11[] = {1346,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype12[] = {1346,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype13[] = {1346,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype14[] = {1346,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype15[] = {1346,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype16[] = {1346,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype17[] = {1346,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype18[] = {1346,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype19[] = {1346,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype20[] = {1346,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype21[] = {1395,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype22[] = {1397,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype23[] = {1394,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype24[] = {1393,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype25[] = {1392,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype26[] = {1392,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype27[] = {1392,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype28[] = {1395,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype29[] = {1397,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype30[] = {1394,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype31[] = {1393,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype32[] = {1392,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype33[] = {1392,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype34[] = {1392,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype35[] = {1395,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype36[] = {1395,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype37[] = {1395,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype38[] = {1395,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype39[] = {1401,0xFFFF};
static EIF_TYPE_INDEX Y12772_pgtype40[] = {1401,0xFFFF};
EIF_TYPE_INDEX *Y12772_gen_type [143];
EIF_TYPE_INDEX Y12772 [143];
void Y12772_init (void)
{
	egc_routines_types [12772] = Y12772;
	egc_routines_gen_types [12772] = Y12772_gen_type;
	egc_routines_offset [12772] = 1540;
	Y12772_gen_type [0] = Y12772_pgtype0;
	Y12772_gen_type [1] = Y12772_pgtype1;
	Y12772_gen_type [2] = Y12772_pgtype2;
	Y12772_gen_type [3] = Y12772_pgtype3;
	Y12772_gen_type [4] = Y12772_pgtype4;
	Y12772_gen_type [5] = Y12772_pgtype5;
	Y12772_gen_type [6] = Y12772_pgtype6;
	Y12772_gen_type [12] = Y12772_pgtype7;
	Y12772_gen_type [13] = Y12772_pgtype8;
	Y12772_gen_type [51] = Y12772_pgtype9;
	Y12772_gen_type [52] = Y12772_pgtype10;
	Y12772_gen_type [53] = Y12772_pgtype11;
	Y12772_gen_type [54] = Y12772_pgtype12;
	Y12772_gen_type [55] = Y12772_pgtype13;
	Y12772_gen_type [56] = Y12772_pgtype14;
	Y12772_gen_type [57] = Y12772_pgtype15;
	Y12772_gen_type [58] = Y12772_pgtype16;
	Y12772_gen_type [59] = Y12772_pgtype17;
	Y12772_gen_type [60] = Y12772_pgtype18;
	Y12772_gen_type [61] = Y12772_pgtype19;
	Y12772_gen_type [62] = Y12772_pgtype20;
	Y12772_gen_type [80] = Y12772_pgtype21;
	Y12772_gen_type [81] = Y12772_pgtype22;
	Y12772_gen_type [82] = Y12772_pgtype23;
	Y12772_gen_type [84] = Y12772_pgtype24;
	Y12772_gen_type [90] = Y12772_pgtype25;
	Y12772_gen_type [91] = Y12772_pgtype26;
	Y12772_gen_type [94] = Y12772_pgtype27;
	Y12772_gen_type [101] = Y12772_pgtype28;
	Y12772_gen_type [102] = Y12772_pgtype29;
	Y12772_gen_type [103] = Y12772_pgtype30;
	Y12772_gen_type [105] = Y12772_pgtype31;
	Y12772_gen_type [111] = Y12772_pgtype32;
	Y12772_gen_type [112] = Y12772_pgtype33;
	Y12772_gen_type [115] = Y12772_pgtype34;
	Y12772_gen_type [127] = Y12772_pgtype35;
	Y12772_gen_type [128] = Y12772_pgtype36;
	Y12772_gen_type [129] = Y12772_pgtype37;
	Y12772_gen_type [130] = Y12772_pgtype38;
	Y12772_gen_type [137] = Y12772_pgtype39;
	Y12772_gen_type [142] = Y12772_pgtype40;
	Y12772[3] = 1395;
	Y12772[4] = 1401;
	Y12772[6] = 1401;
	{long i; for (i = 12; i < 14; i++) Y12772[i] = 1401;};
	{long i; for (i = 51; i < 63; i++) Y12772[i] = 1346;};
	Y12772[80] = 1395;
	Y12772[81] = 1397;
	Y12772[82] = 1394;
	Y12772[84] = 1393;
	{long i; for (i = 90; i < 92; i++) Y12772[i] = 1392;};
	Y12772[94] = 1392;
	Y12772[101] = 1395;
	Y12772[102] = 1397;
	Y12772[103] = 1394;
	Y12772[105] = 1393;
	{long i; for (i = 111; i < 113; i++) Y12772[i] = 1392;};
	Y12772[115] = 1392;
	{long i; for (i = 127; i < 131; i++) Y12772[i] = 1395;};
	Y12772[137] = 1401;
	Y12772[142] = 1401;
}

char *(*R12803[149])();
void R12803_init () {
	R12803[0] = (char *(*)()) F1548_15589;
	R12803[34] = (char *(*)()) F1548_15589;
	{long i; for (i = 51; i < 53; i++) R12803[i] = (char *(*)()) F1601_16344;}
	R12803[61] = (char *(*)()) F1548_15589;
	R12803[62] = (char *(*)()) F1613_16464;
	R12803[64] = (char *(*)()) F1615_16508;
	R12803[65] = (char *(*)()) F1548_15589;
	{long i; for (i = 67; i < 69; i++) R12803[i] = (char *(*)()) F1548_15589;}
	R12803[92] = (char *(*)()) F1643_16907;
	R12803[93] = (char *(*)()) F1644_16928;
	R12803[94] = (char *(*)()) F1645_17007;
	R12803[95] = (char *(*)()) F1646_17009;
	R12803[98] = (char *(*)()) F1648_17053;
	R12803[99] = (char *(*)()) F1650_17078;
	R12803[106] = (char *(*)()) F1548_15589;
	{long i; for (i = 109; i < 111; i++) R12803[i] = (char *(*)()) F1548_15589;}
	R12803[116] = (char *(*)()) F1667_17417;
	R12803[122] = (char *(*)()) F1673_17541;
	R12803[128] = (char *(*)()) F1679_17557;
	R12803[132] = (char *(*)()) F1679_17557;
	R12803[145] = (char *(*)()) F1548_15589;
	R12803[148] = (char *(*)()) F1548_15589;
}

char *(*R12805[149])();
void R12805_init () {
	R12805[0] = (char *(*)()) F1548_15592;
	R12805[34] = (char *(*)()) F1548_15592;
	{long i; for (i = 51; i < 53; i++) R12805[i] = (char *(*)()) F1548_15592;}
	{long i; for (i = 61; i < 63; i++) R12805[i] = (char *(*)()) F1548_15592;}
	{long i; for (i = 64; i < 66; i++) R12805[i] = (char *(*)()) F1548_15592;}
	{long i; for (i = 67; i < 69; i++) R12805[i] = (char *(*)()) F1548_15592;}
	{long i; for (i = 92; i < 96; i++) R12805[i] = (char *(*)()) F1548_15592;}
	{long i; for (i = 98; i < 100; i++) R12805[i] = (char *(*)()) F1548_15592;}
	R12805[106] = (char *(*)()) F1657_17269;
	{long i; for (i = 109; i < 111; i++) R12805[i] = (char *(*)()) F1548_15592;}
	R12805[116] = (char *(*)()) F1667_17460;
	R12805[122] = (char *(*)()) F1548_15592;
	R12805[128] = (char *(*)()) F1548_15592;
	R12805[132] = (char *(*)()) F1548_15592;
	R12805[145] = (char *(*)()) F1696_17895;
	R12805[148] = (char *(*)()) F1699_18062;
}

char *(*R12806[149])();
void R12806_init () {
	R12806[0] = (char *(*)()) F1548_15593;
	R12806[34] = (char *(*)()) F1548_15593;
	{long i; for (i = 51; i < 53; i++) R12806[i] = (char *(*)()) F1548_15593;}
	{long i; for (i = 61; i < 63; i++) R12806[i] = (char *(*)()) F1548_15593;}
	{long i; for (i = 64; i < 66; i++) R12806[i] = (char *(*)()) F1548_15593;}
	{long i; for (i = 67; i < 69; i++) R12806[i] = (char *(*)()) F1548_15593;}
	{long i; for (i = 92; i < 96; i++) R12806[i] = (char *(*)()) F1548_15593;}
	{long i; for (i = 98; i < 100; i++) R12806[i] = (char *(*)()) F1548_15593;}
	R12806[106] = (char *(*)()) F1548_15593;
	{long i; for (i = 109; i < 111; i++) R12806[i] = (char *(*)()) F1548_15593;}
	R12806[116] = (char *(*)()) F1667_17451;
	R12806[122] = (char *(*)()) F1548_15593;
	R12806[128] = (char *(*)()) F1548_15593;
	R12806[132] = (char *(*)()) F1548_15593;
	R12806[145] = (char *(*)()) F1696_17908;
	R12806[148] = (char *(*)()) F1699_18046;
}

char *(*R12807[149])();
void R12807_init () {
	R12807[0] = (char *(*)()) F1548_15594;
	R12807[34] = (char *(*)()) F1548_15594;
	{long i; for (i = 51; i < 53; i++) R12807[i] = (char *(*)()) F1548_15594;}
	{long i; for (i = 61; i < 63; i++) R12807[i] = (char *(*)()) F1548_15594;}
	{long i; for (i = 64; i < 66; i++) R12807[i] = (char *(*)()) F1548_15594;}
	{long i; for (i = 67; i < 69; i++) R12807[i] = (char *(*)()) F1548_15594;}
	{long i; for (i = 92; i < 96; i++) R12807[i] = (char *(*)()) F1548_15594;}
	{long i; for (i = 98; i < 100; i++) R12807[i] = (char *(*)()) F1548_15594;}
	R12807[106] = (char *(*)()) F1548_15594;
	{long i; for (i = 109; i < 111; i++) R12807[i] = (char *(*)()) F1548_15594;}
	R12807[116] = (char *(*)()) F1667_17452;
	R12807[122] = (char *(*)()) F1548_15594;
	R12807[128] = (char *(*)()) F1548_15594;
	R12807[132] = (char *(*)()) F1548_15594;
	R12807[145] = (char *(*)()) F1548_15594;
	R12807[148] = (char *(*)()) F1548_15594;
}

char *(*R12808[149])();
void R12808_init () {
	R12808[0] = (char *(*)()) F1548_15595;
	R12808[34] = (char *(*)()) F1548_15595;
	{long i; for (i = 51; i < 53; i++) R12808[i] = (char *(*)()) F1548_15595;}
	{long i; for (i = 61; i < 63; i++) R12808[i] = (char *(*)()) F1548_15595;}
	{long i; for (i = 64; i < 66; i++) R12808[i] = (char *(*)()) F1548_15595;}
	{long i; for (i = 67; i < 69; i++) R12808[i] = (char *(*)()) F1548_15595;}
	{long i; for (i = 92; i < 96; i++) R12808[i] = (char *(*)()) F1548_15595;}
	{long i; for (i = 98; i < 100; i++) R12808[i] = (char *(*)()) F1548_15595;}
	R12808[106] = (char *(*)()) F1548_15595;
	{long i; for (i = 109; i < 111; i++) R12808[i] = (char *(*)()) F1548_15595;}
	R12808[116] = (char *(*)()) F1548_15595;
	R12808[122] = (char *(*)()) F1548_15595;
	R12808[128] = (char *(*)()) F1548_15595;
	R12808[132] = (char *(*)()) F1548_15595;
	R12808[145] = (char *(*)()) F1696_17909;
	R12808[148] = (char *(*)()) F1548_15595;
}

char *(*R12811[149])();
void R12811_init () {
	R12811[0] = (char *(*)()) F1548_15598;
	R12811[34] = (char *(*)()) F1548_15598;
	{long i; for (i = 51; i < 53; i++) R12811[i] = (char *(*)()) F1548_15598;}
	{long i; for (i = 61; i < 63; i++) R12811[i] = (char *(*)()) F1548_15598;}
	{long i; for (i = 64; i < 66; i++) R12811[i] = (char *(*)()) F1548_15598;}
	{long i; for (i = 67; i < 69; i++) R12811[i] = (char *(*)()) F1548_15598;}
	{long i; for (i = 92; i < 96; i++) R12811[i] = (char *(*)()) F1548_15598;}
	{long i; for (i = 98; i < 100; i++) R12811[i] = (char *(*)()) F1548_15598;}
	R12811[106] = (char *(*)()) F1548_15598;
	{long i; for (i = 109; i < 111; i++) R12811[i] = (char *(*)()) F1548_15598;}
	R12811[116] = (char *(*)()) F1548_15598;
	R12811[122] = (char *(*)()) F1548_15598;
	R12811[128] = (char *(*)()) F1548_15598;
	R12811[132] = (char *(*)()) F1548_15598;
	R12811[145] = (char *(*)()) F1696_17910;
	R12811[148] = (char *(*)()) F1548_15598;
}

char *(*R12813[149])();
void R12813_init () {
	R12813[0] = (char *(*)()) F1548_15600;
	R12813[34] = (char *(*)()) F1548_15600;
	{long i; for (i = 51; i < 53; i++) R12813[i] = (char *(*)()) F1548_15600;}
	{long i; for (i = 61; i < 63; i++) R12813[i] = (char *(*)()) F1548_15600;}
	{long i; for (i = 64; i < 66; i++) R12813[i] = (char *(*)()) F1548_15600;}
	{long i; for (i = 67; i < 69; i++) R12813[i] = (char *(*)()) F1548_15600;}
	{long i; for (i = 92; i < 96; i++) R12813[i] = (char *(*)()) F1548_15600;}
	{long i; for (i = 98; i < 100; i++) R12813[i] = (char *(*)()) F1548_15600;}
	R12813[106] = (char *(*)()) F1548_15600;
	{long i; for (i = 109; i < 111; i++) R12813[i] = (char *(*)()) F1548_15600;}
	R12813[116] = (char *(*)()) F1548_15600;
	R12813[122] = (char *(*)()) F1548_15600;
	R12813[128] = (char *(*)()) F1548_15600;
	R12813[132] = (char *(*)()) F1548_15600;
	R12813[145] = (char *(*)()) F1696_17911;
	R12813[148] = (char *(*)()) F1548_15600;
}

char *(*R12814[149])();
void R12814_init () {
	R12814[0] = (char *(*)()) F1548_15601;
	R12814[34] = (char *(*)()) F1548_15601;
	{long i; for (i = 51; i < 53; i++) R12814[i] = (char *(*)()) F1548_15601;}
	{long i; for (i = 61; i < 63; i++) R12814[i] = (char *(*)()) F1548_15601;}
	R12814[64] = (char *(*)()) F1614_16499;
	R12814[65] = (char *(*)()) F1548_15601;
	{long i; for (i = 67; i < 69; i++) R12814[i] = (char *(*)()) F1548_15601;}
	R12814[92] = (char *(*)()) F1548_15601;
	R12814[93] = (char *(*)()) F1644_16996;
	{long i; for (i = 94; i < 96; i++) R12814[i] = (char *(*)()) F1548_15601;}
	{long i; for (i = 98; i < 100; i++) R12814[i] = (char *(*)()) F1548_15601;}
	R12814[106] = (char *(*)()) F1657_17268;
	{long i; for (i = 109; i < 111; i++) R12814[i] = (char *(*)()) F1548_15601;}
	R12814[116] = (char *(*)()) F1548_15601;
	R12814[122] = (char *(*)()) F1548_15601;
	R12814[128] = (char *(*)()) F1548_15601;
	R12814[132] = (char *(*)()) F1548_15601;
	R12814[145] = (char *(*)()) F1548_15601;
	R12814[148] = (char *(*)()) F1548_15601;
}

char *(*R12824[149])();
void R12824_init () {
	R12824[0] = (char *(*)()) F1549_15612;
	R12824[34] = (char *(*)()) F1549_15612;
	{long i; for (i = 51; i < 53; i++) R12824[i] = (char *(*)()) F1589_16158;}
	{long i; for (i = 61; i < 63; i++) R12824[i] = (char *(*)()) F1589_16158;}
	R12824[64] = (char *(*)()) F1589_16158;
	R12824[65] = (char *(*)()) F1549_15612;
	{long i; for (i = 67; i < 69; i++) R12824[i] = (char *(*)()) F1549_15612;}
	{long i; for (i = 92; i < 96; i++) R12824[i] = (char *(*)()) F1589_16158;}
	{long i; for (i = 98; i < 100; i++) R12824[i] = (char *(*)()) F1589_16158;}
	R12824[106] = (char *(*)()) F1589_16158;
	{long i; for (i = 109; i < 111; i++) R12824[i] = (char *(*)()) F1589_16158;}
	R12824[122] = (char *(*)()) F1549_15612;
	R12824[128] = (char *(*)()) F1549_15612;
	R12824[132] = (char *(*)()) F1549_15612;
	R12824[145] = (char *(*)()) F1589_16158;
	R12824[148] = (char *(*)()) F1589_16158;
}

char *(*R12825[149])();
void R12825_init () {
	R12825[0] = (char *(*)()) F1549_15613;
	R12825[34] = (char *(*)()) F1549_15613;
	{long i; for (i = 51; i < 53; i++) R12825[i] = (char *(*)()) F1589_16159;}
	{long i; for (i = 61; i < 63; i++) R12825[i] = (char *(*)()) F1589_16159;}
	R12825[64] = (char *(*)()) F1589_16159;
	R12825[65] = (char *(*)()) F1549_15613;
	{long i; for (i = 67; i < 69; i++) R12825[i] = (char *(*)()) F1549_15613;}
	{long i; for (i = 92; i < 96; i++) R12825[i] = (char *(*)()) F1589_16159;}
	{long i; for (i = 98; i < 100; i++) R12825[i] = (char *(*)()) F1589_16159;}
	R12825[106] = (char *(*)()) F1589_16159;
	{long i; for (i = 109; i < 111; i++) R12825[i] = (char *(*)()) F1589_16159;}
	R12825[122] = (char *(*)()) F1549_15613;
	R12825[128] = (char *(*)()) F1549_15613;
	R12825[132] = (char *(*)()) F1549_15613;
	R12825[145] = (char *(*)()) F1589_16159;
	R12825[148] = (char *(*)()) F1589_16159;
}

char *(*R12833[149])();
void R12833_init () {
	R12833[0] = (char *(*)()) F1549_15621;
	R12833[34] = (char *(*)()) F1549_15621;
	{long i; for (i = 51; i < 53; i++) R12833[i] = (char *(*)()) F1549_15621;}
	{long i; for (i = 61; i < 63; i++) R12833[i] = (char *(*)()) F1549_15621;}
	{long i; for (i = 64; i < 66; i++) R12833[i] = (char *(*)()) F1549_15621;}
	{long i; for (i = 67; i < 69; i++) R12833[i] = (char *(*)()) F1549_15621;}
	{long i; for (i = 92; i < 96; i++) R12833[i] = (char *(*)()) F1549_15621;}
	R12833[98] = (char *(*)()) F1648_17054;
	R12833[99] = (char *(*)()) F1650_17077;
	R12833[106] = (char *(*)()) F1549_15621;
	{long i; for (i = 109; i < 111; i++) R12833[i] = (char *(*)()) F1549_15621;}
	R12833[122] = (char *(*)()) F1549_15621;
	R12833[128] = (char *(*)()) F1549_15621;
	R12833[132] = (char *(*)()) F1549_15621;
	R12833[145] = (char *(*)()) F1549_15621;
	R12833[148] = (char *(*)()) F1549_15621;
}

char *(*R12839[149])();
void R12839_init () {
	R12839[0] = (char *(*)()) F1549_15627;
	R12839[34] = (char *(*)()) F1549_15627;
	{long i; for (i = 51; i < 53; i++) R12839[i] = (char *(*)()) F1549_15627;}
	{long i; for (i = 61; i < 63; i++) R12839[i] = (char *(*)()) F1549_15627;}
	{long i; for (i = 64; i < 66; i++) R12839[i] = (char *(*)()) F1549_15627;}
	{long i; for (i = 67; i < 69; i++) R12839[i] = (char *(*)()) F1549_15627;}
	{long i; for (i = 92; i < 96; i++) R12839[i] = (char *(*)()) F1549_15627;}
	{long i; for (i = 98; i < 100; i++) R12839[i] = (char *(*)()) F1549_15627;}
	R12839[106] = (char *(*)()) F1549_15627;
	{long i; for (i = 109; i < 111; i++) R12839[i] = (char *(*)()) F1549_15627;}
	R12839[122] = (char *(*)()) F1549_15627;
	R12839[128] = (char *(*)()) F1549_15627;
	R12839[132] = (char *(*)()) F1549_15627;
	R12839[145] = (char *(*)()) F1696_17920;
	R12839[148] = (char *(*)()) F1549_15627;
}

char *(*R12840[149])();
void R12840_init () {
	R12840[0] = (char *(*)()) F1549_15628;
	R12840[34] = (char *(*)()) F1549_15628;
	{long i; for (i = 51; i < 53; i++) R12840[i] = (char *(*)()) F1549_15628;}
	{long i; for (i = 61; i < 63; i++) R12840[i] = (char *(*)()) F1549_15628;}
	R12840[64] = (char *(*)()) F1549_15628;
	R12840[65] = (char *(*)()) F1616_16541;
	{long i; for (i = 67; i < 69; i++) R12840[i] = (char *(*)()) F1616_16541;}
	{long i; for (i = 92; i < 96; i++) R12840[i] = (char *(*)()) F1549_15628;}
	{long i; for (i = 98; i < 100; i++) R12840[i] = (char *(*)()) F1549_15628;}
	R12840[106] = (char *(*)()) F1549_15628;
	{long i; for (i = 109; i < 111; i++) R12840[i] = (char *(*)()) F1549_15628;}
	R12840[122] = (char *(*)()) F1549_15628;
	R12840[128] = (char *(*)()) F1549_15628;
	R12840[132] = (char *(*)()) F1549_15628;
	R12840[145] = (char *(*)()) F1549_15628;
	R12840[148] = (char *(*)()) F1549_15628;
}

char *(*R12844[149])();
void R12844_init () {
	R12844[0] = (char *(*)()) F1550_15662;
	R12844[34] = (char *(*)()) F1550_15662;
	{long i; for (i = 51; i < 53; i++) R12844[i] = (char *(*)()) F1549_15632;}
	{long i; for (i = 61; i < 63; i++) R12844[i] = (char *(*)()) F1549_15632;}
	R12844[64] = (char *(*)()) F1549_15632;
	R12844[65] = (char *(*)()) F1616_16554;
	{long i; for (i = 67; i < 69; i++) R12844[i] = (char *(*)()) F1616_16554;}
	{long i; for (i = 92; i < 96; i++) R12844[i] = (char *(*)()) F1549_15632;}
	{long i; for (i = 98; i < 100; i++) R12844[i] = (char *(*)()) F1549_15632;}
	R12844[106] = (char *(*)()) F1549_15632;
	{long i; for (i = 109; i < 111; i++) R12844[i] = (char *(*)()) F1549_15632;}
	R12844[122] = (char *(*)()) F1549_15632;
	R12844[128] = (char *(*)()) F1549_15632;
	R12844[145] = (char *(*)()) F1549_15632;
	R12844[148] = (char *(*)()) F1549_15632;
}

char *(*R12846[149])();
void R12846_init () {
	R12846[0] = (char *(*)()) F1549_15634;
	R12846[34] = (char *(*)()) F1549_15634;
	{long i; for (i = 51; i < 53; i++) R12846[i] = (char *(*)()) F1549_15634;}
	{long i; for (i = 61; i < 63; i++) R12846[i] = (char *(*)()) F1549_15634;}
	{long i; for (i = 64; i < 66; i++) R12846[i] = (char *(*)()) F1549_15634;}
	{long i; for (i = 67; i < 69; i++) R12846[i] = (char *(*)()) F1618_16629;}
	{long i; for (i = 92; i < 96; i++) R12846[i] = (char *(*)()) F1549_15634;}
	{long i; for (i = 98; i < 100; i++) R12846[i] = (char *(*)()) F1549_15634;}
	R12846[106] = (char *(*)()) F1549_15634;
	{long i; for (i = 109; i < 111; i++) R12846[i] = (char *(*)()) F1549_15634;}
	R12846[122] = (char *(*)()) F1549_15634;
	R12846[128] = (char *(*)()) F1549_15634;
	R12846[132] = (char *(*)()) F1549_15634;
	R12846[145] = (char *(*)()) F1549_15634;
	R12846[148] = (char *(*)()) F1549_15634;
}


#ifdef __cplusplus
}
#endif
