#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O8685[621];
void O8685_init () {
	O8685[0] = + _LNGOFF_1_3_2_1_;
	O8685[1] = + _LNGOFF_2_7_2_3_;
	O8685[2] = + _LNGOFF_3_6_2_1_;
	O8685[3] = + _LNGOFF_4_6_2_1_;
	O8685[4] = + _LNGOFF_5_7_2_1_;
	O8685[572] = + _LNGOFF_5_7_2_1_;
	{long i; for (i = 612; i < 615; i++) O8685[i] = + _LNGOFF_5_6_2_1_;}
	O8685[616] = + _LNGOFF_7_8_2_1_;
	{long i; for (i = 617; i < 621; i++) O8685[i] = + _LNGOFF_6_7_2_1_;}
}

long O8694[621];
void O8694_init () {
	O8694[0] = + _CHROFF_1_1_;
	O8694[1] = + _CHROFF_2_5_;
	O8694[2] = + _CHROFF_3_4_;
	O8694[3] = + _CHROFF_4_4_;
	O8694[4] = + _CHROFF_5_5_;
	O8694[572] = + _CHROFF_5_5_;
	{long i; for (i = 612; i < 615; i++) O8694[i] = + _CHROFF_5_4_;}
	O8694[616] = + _CHROFF_7_6_;
	{long i; for (i = 617; i < 621; i++) O8694[i] = + _CHROFF_6_5_;}
}

long O8800[619];
void O8800_init () {
	O8800[0] = + _PTROFF_3_6_2_4_1_0_;
	O8800[1] = + _PTROFF_4_6_2_4_1_0_;
	O8800[2] = + _PTROFF_5_7_2_4_1_0_;
	O8800[570] = + _PTROFF_5_7_2_4_1_0_;
	{long i; for (i = 610; i < 613; i++) O8800[i] = + _PTROFF_5_6_2_4_1_0_;}
	O8800[614] = + _PTROFF_7_8_2_4_1_0_;
	{long i; for (i = 615; i < 619; i++) O8800[i] = + _PTROFF_6_7_2_4_1_0_;}
}

long O8939[619];
void O8939_init () {
	O8939[0] = + _LNGOFF_3_6_2_3_;
	O8939[1] = + _LNGOFF_4_6_2_3_;
	O8939[2] = + _LNGOFF_5_7_2_3_;
	O8939[570] = + _LNGOFF_5_7_2_3_;
	{long i; for (i = 610; i < 613; i++) O8939[i] = + _LNGOFF_5_6_2_3_;}
	O8939[614] = + _LNGOFF_7_8_2_3_;
	{long i; for (i = 615; i < 619; i++) O8939[i] = + _LNGOFF_6_7_2_3_;}
}

long O8948[619];
void O8948_init () {
	O8948[0] = + _CHROFF_3_3_;
	O8948[1] = + _CHROFF_4_3_;
	O8948[2] = + _CHROFF_5_3_;
	O8948[570] = + _CHROFF_5_3_;
	{long i; for (i = 610; i < 613; i++) O8948[i] = + _CHROFF_5_3_;}
	O8948[614] = + _CHROFF_7_3_;
	{long i; for (i = 615; i < 619; i++) O8948[i] = + _CHROFF_6_3_;}
}

long O9088[549];
void O9088_init () {
	O9088[0] = + _LNGOFF_0_0_0_0_;
	O9088[1] = + _LNGOFF_1_0_0_1_;
	{long i; for (i = 2; i < 4; i++) O9088[i] = + _LNGOFF_0_0_0_0_;}
	O9088[4] = + _LNGOFF_2_0_0_0_;
	O9088[5] = + _LNGOFF_0_1_0_0_;
	O9088[119] = + _LNGOFF_2_0_0_0_;
	O9088[134] = + _LNGOFF_4_0_0_0_;
	O9088[196] = + _LNGOFF_5_2_0_0_;
	{long i; for (i = 197; i < 209; i++) O9088[i] = + _LNGOFF_6_3_0_0_;}
	O9088[209] = + _LNGOFF_6_4_0_0_;
	O9088[210] = + _LNGOFF_6_3_0_0_;
	O9088[211] = + _LNGOFF_13_5_0_0_;
	O9088[212] = + _LNGOFF_6_3_0_0_;
	O9088[213] = + _LNGOFF_7_4_0_0_;
	{long i; for (i = 214; i < 218; i++) O9088[i] = + _LNGOFF_14_3_0_0_;}
	O9088[218] = + _LNGOFF_5_2_0_0_;
	O9088[219] = + _LNGOFF_5_3_0_0_;
	O9088[220] = + _LNGOFF_5_2_0_0_;
	{long i; for (i = 221; i < 223; i++) O9088[i] = + _LNGOFF_5_3_0_0_;}
	O9088[223] = + _LNGOFF_5_2_0_0_;
	O9088[224] = + _LNGOFF_5_3_0_0_;
	O9088[225] = + _LNGOFF_6_3_0_0_;
	{long i; for (i = 226; i < 229; i++) O9088[i] = + _LNGOFF_5_2_0_0_;}
	{long i; for (i = 229; i < 231; i++) O9088[i] = + _LNGOFF_6_2_0_0_;}
	{long i; for (i = 231; i < 233; i++) O9088[i] = + _LNGOFF_5_3_0_0_;}
	{long i; for (i = 233; i < 235; i++) O9088[i] = + _LNGOFF_5_2_0_0_;}
	O9088[235] = + _LNGOFF_5_3_0_0_;
	{long i; for (i = 236; i < 241; i++) O9088[i] = + _LNGOFF_5_2_0_0_;}
	{long i; for (i = 241; i < 244; i++) O9088[i] = + _LNGOFF_6_0_0_0_;}
	O9088[244] = + _LNGOFF_7_2_0_1_;
	{long i; for (i = 245; i < 247; i++) O9088[i] = + _LNGOFF_6_1_0_0_;}
	{long i; for (i = 247; i < 255; i++) O9088[i] = + _LNGOFF_6_0_0_0_;}
	O9088[255] = + _LNGOFF_6_1_0_0_;
	O9088[365] = + _LNGOFF_2_4_0_0_;
	O9088[369] = + _LNGOFF_2_2_0_1_;
	O9088[388] = + _LNGOFF_49_16_0_3_;
	O9088[397] = + _LNGOFF_2_3_0_0_;
	O9088[398] = + _LNGOFF_4_3_0_0_;
	O9088[399] = + _LNGOFF_5_5_0_0_;
	O9088[400] = + _LNGOFF_10_10_0_0_;
	O9088[403] = + _LNGOFF_6_3_0_0_;
	O9088[430] = + _LNGOFF_8_5_0_0_;
	O9088[432] = + _LNGOFF_11_5_0_0_;
	O9088[434] = + _LNGOFF_11_6_0_0_;
	O9088[436] = + _LNGOFF_16_7_6_0_;
	O9088[438] = + _LNGOFF_42_12_10_0_;
	O9088[440] = + _LNGOFF_46_12_10_0_;
	O9088[444] = + _LNGOFF_47_12_10_0_;
	O9088[445] = + _LNGOFF_49_12_10_0_;
	O9088[446] = + _LNGOFF_47_12_10_0_;
	{long i; for (i = 450; i < 453; i++) O9088[i] = + _LNGOFF_49_13_10_0_;}
	O9088[461] = + _LNGOFF_49_13_10_0_;
	O9088[462] = + _LNGOFF_51_13_10_0_;
	{long i; for (i = 463; i < 465; i++) O9088[i] = + _LNGOFF_49_14_10_0_;}
	O9088[465] = + _LNGOFF_59_21_10_0_;
	O9088[466] = + _LNGOFF_59_23_10_0_;
	O9088[467] = + _LNGOFF_65_25_10_0_;
	O9088[468] = + _LNGOFF_68_26_10_0_;
	O9088[490] = + _LNGOFF_42_13_10_0_;
	O9088[491] = + _LNGOFF_51_13_10_0_;
	O9088[492] = + _LNGOFF_45_16_10_0_;
	O9088[493] = + _LNGOFF_58_14_10_0_;
	O9088[494] = + _LNGOFF_44_13_10_0_;
	O9088[495] = + _LNGOFF_51_15_10_0_;
	O9088[496] = + _LNGOFF_44_13_10_0_;
	{long i; for (i = 497; i < 499; i++) O9088[i] = + _LNGOFF_44_14_10_0_;}
	{long i; for (i = 499; i < 501; i++) O9088[i] = + _LNGOFF_46_14_10_0_;}
	O9088[501] = + _LNGOFF_50_13_10_0_;
	O9088[502] = + _LNGOFF_51_14_10_0_;
	O9088[503] = + _LNGOFF_43_13_10_0_;
	O9088[504] = + _LNGOFF_46_14_10_0_;
	O9088[505] = + _LNGOFF_59_16_10_0_;
	O9088[506] = + _LNGOFF_44_15_10_0_;
	O9088[507] = + _LNGOFF_51_18_10_0_;
	{long i; for (i = 508; i < 511; i++) O9088[i] = + _LNGOFF_42_13_10_0_;}
	O9088[516] = + _LNGOFF_22_8_6_0_;
	{long i; for (i = 521; i < 523; i++) O9088[i] = + _LNGOFF_21_7_6_0_;}
	O9088[528] = + _LNGOFF_23_8_6_0_;
	{long i; for (i = 529; i < 531; i++) O9088[i] = + _LNGOFF_23_9_6_0_;}
	O9088[531] = + _LNGOFF_24_9_6_0_;
	O9088[532] = + _LNGOFF_26_8_6_0_;
	{long i; for (i = 537; i < 539; i++) O9088[i] = + _LNGOFF_29_14_8_0_;}
	O9088[545] = + _LNGOFF_48_19_10_0_;
	O9088[548] = + _LNGOFF_48_18_10_0_;
}

long O9148[252];
void O9148_init () {
	O9148[0] =  + _REFACS_1_;
	O9148[130] =  + _REFACS_1_;
	{long i; for (i = 192; i < 207; i++) O9148[i] =  + _REFACS_1_;}
	O9148[207] =  + _REFACS_2_;
	{long i; for (i = 208; i < 240; i++) O9148[i] =  + _REFACS_1_;}
	O9148[240] =  + _REFACS_2_;
	{long i; for (i = 241; i < 252; i++) O9148[i] =  + _REFACS_1_;}
}

long O9566[7];
void O9566_init () {
	{long i; for (i = 0; i < 2; i++) O9566[i] = + _CHROFF_4_0_;}
	O9566[2] = + _CHROFF_5_0_;
	{long i; for (i = 3; i < 7; i++) O9566[i] = + _CHROFF_4_0_;}
}

long O9567[7];
void O9567_init () {
	{long i; for (i = 0; i < 2; i++) O9567[i] = + _LNGOFF_4_2_0_0_;}
	O9567[2] = + _LNGOFF_5_2_0_0_;
	O9567[3] = + _LNGOFF_4_3_0_0_;
	{long i; for (i = 4; i < 6; i++) O9567[i] = + _LNGOFF_4_2_0_0_;}
	O9567[6] = + _LNGOFF_4_3_0_0_;
}

long O9575[7];
void O9575_init () {
	{long i; for (i = 0; i < 2; i++) O9575[i] = + _PTROFF_4_2_0_3_0_0_;}
	O9575[2] = + _PTROFF_5_2_0_3_0_0_;
	O9575[3] = + _PTROFF_4_3_0_3_0_0_;
	O9575[4] = + _PTROFF_4_2_0_3_0_0_;
	O9575[5] = + _PTROFF_4_2_0_4_0_0_;
	O9575[6] = + _PTROFF_4_3_0_3_0_0_;
}

long O9576[7];
void O9576_init () {
	{long i; for (i = 0; i < 2; i++) O9576[i] = + _PTROFF_4_2_0_3_0_1_;}
	O9576[2] = + _PTROFF_5_2_0_3_0_1_;
	O9576[3] = + _PTROFF_4_3_0_3_0_1_;
	O9576[4] = + _PTROFF_4_2_0_3_0_1_;
	O9576[5] = + _PTROFF_4_2_0_4_0_1_;
	O9576[6] = + _PTROFF_4_3_0_3_0_1_;
}

long O9578[7];
void O9578_init () {
	{long i; for (i = 0; i < 2; i++) O9578[i] = + _PTROFF_4_2_0_3_0_2_;}
	O9578[2] = + _PTROFF_5_2_0_3_0_2_;
	O9578[3] = + _PTROFF_4_3_0_3_0_2_;
	O9578[4] = + _PTROFF_4_2_0_3_0_2_;
	O9578[5] = + _PTROFF_4_2_0_4_0_2_;
	O9578[6] = + _PTROFF_4_3_0_3_0_2_;
}

long O9579[7];
void O9579_init () {
	{long i; for (i = 0; i < 2; i++) O9579[i] = + _LNGOFF_4_2_0_1_;}
	O9579[2] = + _LNGOFF_5_2_0_1_;
	O9579[3] = + _LNGOFF_4_3_0_1_;
	{long i; for (i = 4; i < 6; i++) O9579[i] = + _LNGOFF_4_2_0_1_;}
	O9579[6] = + _LNGOFF_4_3_0_1_;
}

long O9580[7];
void O9580_init () {
	{long i; for (i = 0; i < 2; i++) O9580[i] = + _CHROFF_4_1_;}
	O9580[2] = + _CHROFF_5_1_;
	{long i; for (i = 3; i < 7; i++) O9580[i] = + _CHROFF_4_1_;}
}

long O9581[7];
void O9581_init () {
	{long i; for (i = 0; i < 2; i++) O9581[i] = + _LNGOFF_4_2_0_2_;}
	O9581[2] = + _LNGOFF_5_2_0_2_;
	O9581[3] = + _LNGOFF_4_3_0_2_;
	{long i; for (i = 4; i < 6; i++) O9581[i] = + _LNGOFF_4_2_0_2_;}
	O9581[6] = + _LNGOFF_4_3_0_2_;
}

long O9594[5];
void O9594_init () {
	O9594[0] =  + _REFACS_4_;
	O9594[1] = + _CHROFF_4_2_;
	O9594[2] = + _PTROFF_4_2_0_3_0_3_;
	O9594[3] = + _LNGOFF_4_2_0_3_;
	O9594[4] = + _CHROFF_4_2_;
}

long O9693[563];
void O9693_init () {
	{long i; for (i = 0; i < 3; i++) O9693[i] = + _LNGOFF_0_0_0_0_;}
	{long i; for (i = 3; i < 5; i++) O9693[i] = + _LNGOFF_1_0_0_0_;}
	O9693[5] = + _LNGOFF_1_1_0_0_;
	{long i; for (i = 6; i < 8; i++) O9693[i] = + _LNGOFF_1_0_0_0_;}
	{long i; for (i = 8; i < 11; i++) O9693[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 561; i < 563; i++) O9693[i] = + _LNGOFF_1_1_0_0_;}
}

long O9694[563];
void O9694_init () {
	{long i; for (i = 0; i < 3; i++) O9694[i] = + _LNGOFF_0_0_0_1_;}
	{long i; for (i = 3; i < 5; i++) O9694[i] = + _LNGOFF_1_0_0_1_;}
	O9694[5] = + _LNGOFF_1_1_0_1_;
	{long i; for (i = 6; i < 8; i++) O9694[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 8; i < 11; i++) O9694[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 561; i < 563; i++) O9694[i] = + _LNGOFF_1_1_0_1_;}
}

long O9759[3];
void O9759_init () {
	{long i; for (i = 0; i < 2; i++) O9759[i] = + _LNGOFF_1_0_0_2_;}
	O9759[2] = + _LNGOFF_1_1_0_2_;
}

long O9839[557];
void O9839_init () {
	{long i; for (i = 0; i < 2; i++) O9839[i] = + _LNGOFF_1_0_0_2_;}
	{long i; for (i = 2; i < 5; i++) O9839[i] = + _LNGOFF_1_1_0_2_;}
	{long i; for (i = 555; i < 557; i++) O9839[i] = + _LNGOFF_1_1_0_2_;}
}

long O9885[159];
void O9885_init () {
	{long i; for (i = 0; i < 37; i++) O9885[i] = 0;}
	O9885[37] =  + _REFACS_2_;
	O9885[38] = 0;
	O9885[54] = 0;
	{long i; for (i = 91; i < 99; i++) O9885[i] = 0;}
	{long i; for (i = 99; i < 114; i++) O9885[i] =  + _REFACS_2_;}
	O9885[114] =  + _REFACS_3_;
	{long i; for (i = 115; i < 147; i++) O9885[i] =  + _REFACS_2_;}
	O9885[147] =  + _REFACS_3_;
	{long i; for (i = 148; i < 159; i++) O9885[i] =  + _REFACS_2_;}
}

long O9889[159];
void O9889_init () {
	{long i; for (i = 0; i < 37; i++) O9889[i] =  + _REFACS_1_;}
	O9889[37] =  + _REFACS_3_;
	O9889[38] =  + _REFACS_1_;
	O9889[54] =  + _REFACS_1_;
	{long i; for (i = 91; i < 99; i++) O9889[i] =  + _REFACS_1_;}
	{long i; for (i = 99; i < 114; i++) O9889[i] =  + _REFACS_3_;}
	O9889[114] =  + _REFACS_4_;
	{long i; for (i = 115; i < 147; i++) O9889[i] =  + _REFACS_3_;}
	O9889[147] =  + _REFACS_4_;
	{long i; for (i = 148; i < 159; i++) O9889[i] =  + _REFACS_3_;}
}

long O10900[68];
void O10900_init () {
	{long i; for (i = 0; i < 8; i++) O10900[i] =  + _REFACS_2_;}
	O10900[8] =  + _REFACS_4_;
	{long i; for (i = 9; i < 23; i++) O10900[i] =  + _REFACS_5_;}
	O10900[23] =  + _REFACS_6_;
	{long i; for (i = 24; i < 30; i++) O10900[i] =  + _REFACS_5_;}
	{long i; for (i = 30; i < 41; i++) O10900[i] =  + _REFACS_4_;}
	{long i; for (i = 41; i < 43; i++) O10900[i] =  + _REFACS_5_;}
	{long i; for (i = 43; i < 53; i++) O10900[i] =  + _REFACS_4_;}
	{long i; for (i = 53; i < 56; i++) O10900[i] =  + _REFACS_5_;}
	O10900[56] =  + _REFACS_6_;
	{long i; for (i = 57; i < 68; i++) O10900[i] =  + _REFACS_5_;}
}

long O10935[45];
void O10935_init () {
	O10935[0] = + _CHROFF_5_0_;
	{long i; for (i = 1; i < 15; i++) O10935[i] = + _CHROFF_6_1_;}
	O10935[15] = + _CHROFF_13_2_;
	O10935[16] = + _CHROFF_6_1_;
	O10935[17] = + _CHROFF_7_1_;
	{long i; for (i = 18; i < 22; i++) O10935[i] = + _CHROFF_14_1_;}
	O10935[22] = + _CHROFF_5_0_;
	O10935[23] = + _CHROFF_5_1_;
	O10935[24] = + _CHROFF_5_0_;
	{long i; for (i = 25; i < 27; i++) O10935[i] = + _CHROFF_5_1_;}
	O10935[27] = + _CHROFF_5_0_;
	O10935[28] = + _CHROFF_5_1_;
	O10935[29] = + _CHROFF_6_0_;
	{long i; for (i = 30; i < 33; i++) O10935[i] = + _CHROFF_5_0_;}
	{long i; for (i = 33; i < 35; i++) O10935[i] = + _CHROFF_6_0_;}
	{long i; for (i = 35; i < 37; i++) O10935[i] = + _CHROFF_5_1_;}
	{long i; for (i = 37; i < 39; i++) O10935[i] = + _CHROFF_5_0_;}
	O10935[39] = + _CHROFF_5_1_;
	{long i; for (i = 40; i < 45; i++) O10935[i] = + _CHROFF_5_0_;}
}

long O10936[45];
void O10936_init () {
	O10936[0] = + _CHROFF_5_1_;
	{long i; for (i = 1; i < 15; i++) O10936[i] = + _CHROFF_6_2_;}
	O10936[15] = + _CHROFF_13_3_;
	O10936[16] = + _CHROFF_6_2_;
	O10936[17] = + _CHROFF_7_2_;
	{long i; for (i = 18; i < 22; i++) O10936[i] = + _CHROFF_14_2_;}
	O10936[22] = + _CHROFF_5_1_;
	O10936[23] = + _CHROFF_5_2_;
	O10936[24] = + _CHROFF_5_1_;
	{long i; for (i = 25; i < 27; i++) O10936[i] = + _CHROFF_5_2_;}
	O10936[27] = + _CHROFF_5_1_;
	O10936[28] = + _CHROFF_5_2_;
	O10936[29] = + _CHROFF_6_1_;
	{long i; for (i = 30; i < 33; i++) O10936[i] = + _CHROFF_5_1_;}
	{long i; for (i = 33; i < 35; i++) O10936[i] = + _CHROFF_6_1_;}
	{long i; for (i = 35; i < 37; i++) O10936[i] = + _CHROFF_5_2_;}
	{long i; for (i = 37; i < 39; i++) O10936[i] = + _CHROFF_5_1_;}
	O10936[39] = + _CHROFF_5_2_;
	{long i; for (i = 40; i < 45; i++) O10936[i] = + _CHROFF_5_1_;}
}

long O11421[10];
void O11421_init () {
	{long i; for (i = 0; i < 2; i++) O11421[i] = + _CHROFF_16_0_;}
	O11421[2] = + _CHROFF_18_0_;
	{long i; for (i = 3; i < 5; i++) O11421[i] = + _CHROFF_27_0_;}
	O11421[5] = + _CHROFF_29_0_;
	O11421[6] = + _CHROFF_18_0_;
	O11421[7] = + _CHROFF_23_0_;
	O11421[8] = + _CHROFF_21_0_;
	O11421[9] = + _CHROFF_22_0_;
}

long O11432[10];
void O11432_init () {
	{long i; for (i = 0; i < 3; i++) O11432[i] =  + _REFACS_3_;}
	{long i; for (i = 3; i < 6; i++) O11432[i] =  + _REFACS_5_;}
	{long i; for (i = 6; i < 8; i++) O11432[i] =  + _REFACS_3_;}
	{long i; for (i = 8; i < 10; i++) O11432[i] =  + _REFACS_5_;}
}

EIF_TYPE_INDEX *Y11432_gen_type [10];
EIF_TYPE_INDEX Y11432 [10];
void Y11432_init (void)
{
	egc_routines_types [11432] = Y11432;
	egc_routines_gen_types [11432] = Y11432_gen_type;
	egc_routines_offset [11432] = 1419;
	{long i; for (i = 0; i < 10; i++) Y11432[i] = 1239;};
}

long O11433[10];
void O11433_init () {
	{long i; for (i = 0; i < 3; i++) O11433[i] =  + _REFACS_4_;}
	{long i; for (i = 3; i < 6; i++) O11433[i] =  + _REFACS_6_;}
	{long i; for (i = 6; i < 8; i++) O11433[i] =  + _REFACS_4_;}
	{long i; for (i = 8; i < 10; i++) O11433[i] =  + _REFACS_6_;}
}

long O11434[10];
void O11434_init () {
	{long i; for (i = 0; i < 3; i++) O11434[i] =  + _REFACS_5_;}
	{long i; for (i = 3; i < 6; i++) O11434[i] =  + _REFACS_7_;}
	{long i; for (i = 6; i < 8; i++) O11434[i] =  + _REFACS_5_;}
	{long i; for (i = 8; i < 10; i++) O11434[i] =  + _REFACS_7_;}
}

EIF_TYPE_INDEX *Y11434_gen_type [10];
EIF_TYPE_INDEX Y11434 [10];
void Y11434_init (void)
{
	egc_routines_types [11434] = Y11434;
	egc_routines_gen_types [11434] = Y11434_gen_type;
	egc_routines_offset [11434] = 1419;
	{long i; for (i = 0; i < 3; i++) Y11434[i] = 1764;};
	{long i; for (i = 3; i < 6; i++) Y11434[i] = 1766;};
	Y11434[6] = 1764;
	Y11434[7] = 1765;
	{long i; for (i = 8; i < 10; i++) Y11434[i] = 1764;};
}

long O11436[10];
void O11436_init () {
	{long i; for (i = 0; i < 3; i++) O11436[i] =  + _REFACS_6_;}
	{long i; for (i = 3; i < 6; i++) O11436[i] =  + _REFACS_8_;}
	{long i; for (i = 6; i < 8; i++) O11436[i] =  + _REFACS_6_;}
	{long i; for (i = 8; i < 10; i++) O11436[i] =  + _REFACS_8_;}
}

long O11438[10];
void O11438_init () {
	{long i; for (i = 0; i < 3; i++) O11438[i] =  + _REFACS_8_;}
	{long i; for (i = 3; i < 6; i++) O11438[i] =  + _REFACS_10_;}
	{long i; for (i = 6; i < 8; i++) O11438[i] =  + _REFACS_8_;}
	{long i; for (i = 8; i < 10; i++) O11438[i] =  + _REFACS_10_;}
}

long O11469[10];
void O11469_init () {
	{long i; for (i = 0; i < 2; i++) O11469[i] = + _CHROFF_16_1_;}
	O11469[2] = + _CHROFF_18_1_;
	{long i; for (i = 3; i < 5; i++) O11469[i] = + _CHROFF_27_1_;}
	O11469[5] = + _CHROFF_29_1_;
	O11469[6] = + _CHROFF_18_1_;
	O11469[7] = + _CHROFF_23_1_;
	O11469[8] = + _CHROFF_21_1_;
	O11469[9] = + _CHROFF_22_1_;
}

long O11470[10];
void O11470_init () {
	{long i; for (i = 0; i < 3; i++) O11470[i] =  + _REFACS_9_;}
	{long i; for (i = 3; i < 6; i++) O11470[i] =  + _REFACS_11_;}
	{long i; for (i = 6; i < 8; i++) O11470[i] =  + _REFACS_9_;}
	{long i; for (i = 8; i < 10; i++) O11470[i] =  + _REFACS_11_;}
}

long O11472[10];
void O11472_init () {
	{long i; for (i = 0; i < 3; i++) O11472[i] =  + _REFACS_11_;}
	{long i; for (i = 3; i < 6; i++) O11472[i] =  + _REFACS_13_;}
	{long i; for (i = 6; i < 8; i++) O11472[i] =  + _REFACS_11_;}
	{long i; for (i = 8; i < 10; i++) O11472[i] =  + _REFACS_13_;}
}

long O11480[10];
void O11480_init () {
	{long i; for (i = 0; i < 2; i++) O11480[i] = + _LNGOFF_16_3_0_0_;}
	O11480[2] = + _LNGOFF_18_3_0_0_;
	{long i; for (i = 3; i < 5; i++) O11480[i] = + _LNGOFF_27_5_0_0_;}
	O11480[5] = + _LNGOFF_29_5_0_0_;
	O11480[6] = + _LNGOFF_18_3_0_0_;
	O11480[7] = + _LNGOFF_23_4_0_0_;
	O11480[8] = + _LNGOFF_21_4_0_0_;
	O11480[9] = + _LNGOFF_22_4_0_0_;
}

long O11481[10];
void O11481_init () {
	{long i; for (i = 0; i < 3; i++) O11481[i] =  + _REFACS_14_;}
	{long i; for (i = 3; i < 6; i++) O11481[i] =  + _REFACS_16_;}
	{long i; for (i = 6; i < 8; i++) O11481[i] =  + _REFACS_14_;}
	{long i; for (i = 8; i < 10; i++) O11481[i] =  + _REFACS_16_;}
}

long O11483[10];
void O11483_init () {
	{long i; for (i = 0; i < 2; i++) O11483[i] = + _CHROFF_16_2_;}
	O11483[2] = + _CHROFF_18_2_;
	{long i; for (i = 3; i < 5; i++) O11483[i] = + _CHROFF_27_2_;}
	O11483[5] = + _CHROFF_29_2_;
	O11483[6] = + _CHROFF_18_2_;
	O11483[7] = + _CHROFF_23_2_;
	O11483[8] = + _CHROFF_21_2_;
	O11483[9] = + _CHROFF_22_2_;
}

long O11488[3];
void O11488_init () {
	{long i; for (i = 0; i < 2; i++) O11488[i] = + _CHROFF_27_3_;}
	O11488[2] = + _CHROFF_29_3_;
}

long O11489[3];
void O11489_init () {
	{long i; for (i = 0; i < 2; i++) O11489[i] = + _CHROFF_27_4_;}
	O11489[2] = + _CHROFF_29_4_;
}

static EIF_TYPE_INDEX Y11491_pgtype0[] = {891,1422,0xFFFF};
static EIF_TYPE_INDEX Y11491_pgtype1[] = {891,1423,0xFFFF};
static EIF_TYPE_INDEX Y11491_pgtype2[] = {891,1424,0xFFFF};
EIF_TYPE_INDEX *Y11491_gen_type [3];
EIF_TYPE_INDEX Y11491 [3];
void Y11491_init (void)
{
	egc_routines_types [11491] = Y11491;
	egc_routines_gen_types [11491] = Y11491_gen_type;
	egc_routines_offset [11491] = 1422;
	Y11491_gen_type [0] = Y11491_pgtype0;
	Y11491_gen_type [1] = Y11491_pgtype1;
	Y11491_gen_type [2] = Y11491_pgtype2;
	{long i; for (i = 0; i < 3; i++) Y11491[i] = 891;};
}

long O11523[4];
void O11523_init () {
	{long i; for (i = 0; i < 2; i++) O11523[i] =  + _REFACS_16_;}
	{long i; for (i = 2; i < 4; i++) O11523[i] =  + _REFACS_18_;}
}

long O11524[4];
void O11524_init () {
	{long i; for (i = 0; i < 2; i++) O11524[i] =  + _REFACS_17_;}
	{long i; for (i = 2; i < 4; i++) O11524[i] =  + _REFACS_19_;}
}

long O11540[2];
void O11540_init () {
	O11540[0] = + _CHROFF_21_3_;
	O11540[1] = + _CHROFF_22_3_;
}

long O12205[188];
void O12205_init () {
	{long i; for (i = 0; i < 24; i++) O12205[i] = 0;}
	O12205[24] =  + _REFACS_22_;
	O12205[25] =  + _REFACS_23_;
	{long i; for (i = 26; i < 31; i++) O12205[i] = 0;}
	O12205[31] =  + _REFACS_1_;
	O12205[32] = 0;
	O12205[33] =  + _REFACS_1_;
	{long i; for (i = 34; i < 39; i++) O12205[i] = 0;}
	{long i; for (i = 39; i < 41; i++) O12205[i] =  + _REFACS_1_;}
	{long i; for (i = 41; i < 44; i++) O12205[i] = 0;}
	{long i; for (i = 44; i < 46; i++) O12205[i] =  + _REFACS_5_;}
	{long i; for (i = 46; i < 50; i++) O12205[i] = 0;}
	{long i; for (i = 50; i < 52; i++) O12205[i] =  + _REFACS_1_;}
	{long i; for (i = 52; i < 66; i++) O12205[i] = 0;}
	{long i; for (i = 66; i < 72; i++) O12205[i] =  + _REFACS_2_;}
	{long i; for (i = 72; i < 74; i++) O12205[i] =  + _REFACS_7_;}
	{long i; for (i = 74; i < 76; i++) O12205[i] =  + _REFACS_24_;}
	{long i; for (i = 76; i < 79; i++) O12205[i] =  + _REFACS_25_;}
	O12205[79] =  + _REFACS_26_;
	{long i; for (i = 80; i < 82; i++) O12205[i] =  + _REFACS_25_;}
	O12205[82] =  + _REFACS_26_;
	O12205[83] =  + _REFACS_25_;
	{long i; for (i = 84; i < 94; i++) O12205[i] =  + _REFACS_26_;}
	{long i; for (i = 94; i < 96; i++) O12205[i] =  + _REFACS_30_;}
	{long i; for (i = 96; i < 98; i++) O12205[i] =  + _REFACS_33_;}
	{long i; for (i = 98; i < 102; i++) O12205[i] =  + _REFACS_26_;}
	{long i; for (i = 102; i < 104; i++) O12205[i] =  + _REFACS_30_;}
	{long i; for (i = 104; i < 106; i++) O12205[i] =  + _REFACS_33_;}
	O12205[106] =  + _REFACS_24_;
	O12205[107] =  + _REFACS_26_;
	O12205[108] =  + _REFACS_25_;
	O12205[109] =  + _REFACS_28_;
	O12205[110] =  + _REFACS_24_;
	O12205[111] =  + _REFACS_29_;
	{long i; for (i = 112; i < 117; i++) O12205[i] =  + _REFACS_25_;}
	{long i; for (i = 117; i < 119; i++) O12205[i] =  + _REFACS_26_;}
	O12205[119] =  + _REFACS_25_;
	O12205[120] =  + _REFACS_26_;
	O12205[121] =  + _REFACS_30_;
	O12205[122] =  + _REFACS_25_;
	O12205[123] =  + _REFACS_28_;
	{long i; for (i = 124; i < 128; i++) O12205[i] =  + _REFACS_24_;}
	O12205[128] =  + _REFACS_26_;
	O12205[129] =  + _REFACS_25_;
	O12205[130] =  + _REFACS_28_;
	O12205[131] =  + _REFACS_24_;
	O12205[132] =  + _REFACS_29_;
	{long i; for (i = 133; i < 138; i++) O12205[i] =  + _REFACS_25_;}
	{long i; for (i = 138; i < 140; i++) O12205[i] =  + _REFACS_26_;}
	O12205[140] =  + _REFACS_25_;
	O12205[141] =  + _REFACS_26_;
	O12205[142] =  + _REFACS_30_;
	O12205[143] =  + _REFACS_25_;
	O12205[144] =  + _REFACS_28_;
	{long i; for (i = 145; i < 148; i++) O12205[i] =  + _REFACS_24_;}
	O12205[148] =  + _REFACS_10_;
	{long i; for (i = 149; i < 151; i++) O12205[i] =  + _REFACS_12_;}
	{long i; for (i = 151; i < 154; i++) O12205[i] =  + _REFACS_10_;}
	{long i; for (i = 154; i < 158; i++) O12205[i] =  + _REFACS_14_;}
	{long i; for (i = 158; i < 160; i++) O12205[i] =  + _REFACS_10_;}
	{long i; for (i = 160; i < 164; i++) O12205[i] =  + _REFACS_11_;}
	O12205[164] =  + _REFACS_12_;
	{long i; for (i = 165; i < 169; i++) O12205[i] =  + _REFACS_11_;}
	{long i; for (i = 169; i < 172; i++) O12205[i] =  + _REFACS_12_;}
	{long i; for (i = 172; i < 176; i++) O12205[i] =  + _REFACS_14_;}
	O12205[176] = 0;
	O12205[177] =  + _REFACS_25_;
	{long i; for (i = 178; i < 180; i++) O12205[i] = 0;}
	O12205[180] =  + _REFACS_25_;
	O12205[181] = 0;
	O12205[182] =  + _REFACS_25_;
	{long i; for (i = 183; i < 185; i++) O12205[i] = 0;}
	O12205[185] =  + _REFACS_25_;
	{long i; for (i = 186; i < 188; i++) O12205[i] = 0;}
}

static EIF_TYPE_INDEX Y12205_pgtype0[] = {1340,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y12205_pgtype1[] = {1340,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y12205_pgtype2[] = {1341,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y12205_pgtype3[] = {1341,1395,0xFFFF};
static EIF_TYPE_INDEX Y12205_pgtype4[] = {1341,1401,0xFFFF};
static EIF_TYPE_INDEX Y12205_pgtype5[] = {1341,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y12205_gen_type [188];
EIF_TYPE_INDEX Y12205 [188];
void Y12205_init (void)
{
	egc_routines_types [12205] = Y12205;
	egc_routines_gen_types [12205] = Y12205_gen_type;
	egc_routines_offset [12205] = 1513;
	Y12205_gen_type [27] = Y12205_pgtype0;
	Y12205_gen_type [28] = Y12205_pgtype1;
	Y12205_gen_type [29] = Y12205_pgtype2;
	Y12205_gen_type [30] = Y12205_pgtype3;
	Y12205_gen_type [31] = Y12205_pgtype4;
	Y12205_gen_type [32] = Y12205_pgtype5;
	Y12205[0] = 1247;
	{long i; for (i = 1; i < 3; i++) Y12205[i] = 1248;};
	{long i; for (i = 3; i < 5; i++) Y12205[i] = 1249;};
	{long i; for (i = 5; i < 7; i++) Y12205[i] = 1250;};
	Y12205[7] = 1251;
	{long i; for (i = 8; i < 10; i++) Y12205[i] = 1252;};
	{long i; for (i = 10; i < 12; i++) Y12205[i] = 1253;};
	Y12205[12] = 1260;
	{long i; for (i = 13; i < 15; i++) Y12205[i] = 1254;};
	{long i; for (i = 15; i < 17; i++) Y12205[i] = 1255;};
	{long i; for (i = 17; i < 19; i++) Y12205[i] = 1256;};
	Y12205[19] = 1257;
	{long i; for (i = 20; i < 22; i++) Y12205[i] = 1301;};
	{long i; for (i = 22; i < 24; i++) Y12205[i] = 1258;};
	{long i; for (i = 24; i < 26; i++) Y12205[i] = 1261;};
	Y12205[26] = 1259;
	{long i; for (i = 27; i < 29; i++) Y12205[i] = 1340;};
	{long i; for (i = 29; i < 33; i++) Y12205[i] = 1341;};
	Y12205[33] = 1343;
	{long i; for (i = 34; i < 37; i++) Y12205[i] = 1247;};
	Y12205[37] = 1251;
	Y12205[38] = 1267;
	{long i; for (i = 39; i < 41; i++) Y12205[i] = 1344;};
	Y12205[41] = 1268;
	{long i; for (i = 42; i < 44; i++) Y12205[i] = 1264;};
	{long i; for (i = 44; i < 46; i++) Y12205[i] = 1265;};
	{long i; for (i = 46; i < 48; i++) Y12205[i] = 1266;};
	{long i; for (i = 48; i < 50; i++) Y12205[i] = 1345;};
	{long i; for (i = 50; i < 52; i++) Y12205[i] = 1269;};
	{long i; for (i = 52; i < 54; i++) Y12205[i] = 1270;};
	Y12205[54] = 1272;
	Y12205[55] = 1273;
	Y12205[56] = 1274;
	Y12205[57] = 1284;
	{long i; for (i = 58; i < 60; i++) Y12205[i] = 1271;};
	{long i; for (i = 60; i < 63; i++) Y12205[i] = 1275;};
	{long i; for (i = 63; i < 65; i++) Y12205[i] = 1277;};
	Y12205[65] = 1257;
	{long i; for (i = 66; i < 69; i++) Y12205[i] = 1281;};
	Y12205[69] = 1282;
	Y12205[70] = 1281;
	Y12205[71] = 1283;
	{long i; for (i = 72; i < 74; i++) Y12205[i] = 1284;};
	{long i; for (i = 74; i < 76; i++) Y12205[i] = 1346;};
	{long i; for (i = 76; i < 78; i++) Y12205[i] = 1347;};
	Y12205[78] = 1348;
	Y12205[79] = 1349;
	Y12205[80] = 1350;
	Y12205[81] = 1348;
	Y12205[82] = 1349;
	Y12205[83] = 1350;
	Y12205[84] = 1351;
	Y12205[85] = 1352;
	Y12205[86] = 1353;
	Y12205[87] = 1351;
	Y12205[88] = 1352;
	Y12205[89] = 1353;
	Y12205[90] = 1354;
	Y12205[91] = 1355;
	{long i; for (i = 92; i < 94; i++) Y12205[i] = 1354;};
	Y12205[94] = 1358;
	Y12205[95] = 1359;
	Y12205[96] = 1360;
	Y12205[97] = 1362;
	Y12205[98] = 1354;
	Y12205[99] = 1355;
	Y12205[100] = 1356;
	Y12205[101] = 1357;
	Y12205[102] = 1358;
	Y12205[103] = 1359;
	Y12205[104] = 1360;
	Y12205[105] = 1362;
	Y12205[106] = 1368;
	Y12205[107] = 1369;
	Y12205[108] = 1371;
	Y12205[109] = 1372;
	Y12205[110] = 1373;
	Y12205[111] = 1374;
	{long i; for (i = 112; i < 114; i++) Y12205[i] = 1376;};
	Y12205[114] = 1378;
	Y12205[115] = 1379;
	Y12205[116] = 1380;
	Y12205[117] = 1381;
	Y12205[118] = 1382;
	Y12205[119] = 1383;
	Y12205[120] = 1384;
	Y12205[121] = 1385;
	Y12205[122] = 1386;
	Y12205[123] = 1387;
	Y12205[124] = 1388;
	Y12205[125] = 1389;
	Y12205[126] = 1390;
	Y12205[127] = 1368;
	Y12205[128] = 1369;
	Y12205[129] = 1371;
	Y12205[130] = 1372;
	Y12205[131] = 1373;
	Y12205[132] = 1374;
	Y12205[133] = 1376;
	Y12205[134] = 1377;
	Y12205[135] = 1378;
	Y12205[136] = 1379;
	Y12205[137] = 1380;
	Y12205[138] = 1381;
	Y12205[139] = 1382;
	Y12205[140] = 1383;
	Y12205[141] = 1384;
	Y12205[142] = 1385;
	Y12205[143] = 1386;
	Y12205[144] = 1387;
	Y12205[145] = 1388;
	Y12205[146] = 1389;
	Y12205[147] = 1390;
	Y12205[148] = 1391;
	{long i; for (i = 149; i < 151; i++) Y12205[i] = 1392;};
	Y12205[151] = 1391;
	{long i; for (i = 152; i < 154; i++) Y12205[i] = 1393;};
	Y12205[154] = 1395;
	Y12205[155] = 1396;
	Y12205[156] = 1395;
	Y12205[157] = 1396;
	Y12205[158] = 1391;
	Y12205[159] = 1398;
	Y12205[160] = 1401;
	Y12205[161] = 1402;
	Y12205[162] = 1403;
	Y12205[163] = 1401;
	Y12205[164] = 1405;
	Y12205[165] = 1401;
	Y12205[166] = 1402;
	Y12205[167] = 1403;
	Y12205[168] = 1404;
	Y12205[169] = 1405;
	{long i; for (i = 170; i < 172; i++) Y12205[i] = 1394;};
	Y12205[172] = 1399;
	Y12205[173] = 1400;
	Y12205[174] = 1399;
	Y12205[175] = 1400;
	Y12205[176] = 1278;
	Y12205[177] = 1370;
	Y12205[178] = 1279;
	Y12205[179] = 1280;
	Y12205[180] = 1375;
	Y12205[181] = 1278;
	Y12205[182] = 1370;
	Y12205[183] = 1279;
	Y12205[184] = 1280;
	Y12205[185] = 1375;
	{long i; for (i = 186; i < 188; i++) Y12205[i] = 1285;};
}

long O12206[188];
void O12206_init () {
	{long i; for (i = 0; i < 2; i++) O12206[i] = + _CHROFF_1_0_;}
	O12206[2] = + _CHROFF_2_3_;
	{long i; for (i = 3; i < 5; i++) O12206[i] = + _CHROFF_1_0_;}
	O12206[5] = + _CHROFF_1_1_;
	O12206[6] = + _CHROFF_2_1_;
	{long i; for (i = 7; i < 10; i++) O12206[i] = + _CHROFF_1_0_;}
	O12206[10] = + _CHROFF_2_1_;
	O12206[11] = + _CHROFF_4_1_;
	O12206[12] = + _CHROFF_2_0_;
	{long i; for (i = 13; i < 15; i++) O12206[i] = + _CHROFF_1_0_;}
	O12206[15] = + _CHROFF_2_0_;
	O12206[16] = + _CHROFF_3_1_;
	O12206[17] = + _CHROFF_1_0_;
	O12206[18] = + _CHROFF_2_0_;
	O12206[19] = + _CHROFF_1_0_;
	O12206[20] = + _CHROFF_2_1_;
	O12206[21] = + _CHROFF_3_4_;
	{long i; for (i = 22; i < 24; i++) O12206[i] = + _CHROFF_1_0_;}
	O12206[24] = + _CHROFF_40_8_;
	O12206[25] = + _CHROFF_49_15_;
	{long i; for (i = 26; i < 28; i++) O12206[i] = + _CHROFF_1_0_;}
	O12206[28] = + _CHROFF_2_0_;
	{long i; for (i = 29; i < 31; i++) O12206[i] = + _CHROFF_1_0_;}
	{long i; for (i = 31; i < 33; i++) O12206[i] = + _CHROFF_2_0_;}
	O12206[33] = + _CHROFF_4_0_;
	O12206[34] = + _CHROFF_2_2_;
	O12206[35] = + _CHROFF_4_2_;
	O12206[36] = + _CHROFF_5_4_;
	O12206[37] = + _CHROFF_10_9_;
	O12206[38] = + _CHROFF_1_0_;
	O12206[39] = + _CHROFF_2_0_;
	O12206[40] = + _CHROFF_6_2_;
	{long i; for (i = 41; i < 43; i++) O12206[i] = + _CHROFF_1_0_;}
	O12206[43] = + _CHROFF_3_0_;
	O12206[44] = + _CHROFF_7_4_;
	O12206[45] = + _CHROFF_8_5_;
	{long i; for (i = 46; i < 48; i++) O12206[i] = + _CHROFF_1_0_;}
	{long i; for (i = 48; i < 50; i++) O12206[i] = + _CHROFF_1_1_;}
	{long i; for (i = 50; i < 52; i++) O12206[i] = + _CHROFF_3_1_;}
	{long i; for (i = 52; i < 59; i++) O12206[i] = + _CHROFF_1_0_;}
	O12206[59] = + _CHROFF_2_0_;
	O12206[60] = + _CHROFF_1_0_;
	O12206[61] = + _CHROFF_2_0_;
	{long i; for (i = 62; i < 64; i++) O12206[i] = + _CHROFF_1_0_;}
	O12206[64] = + _CHROFF_2_0_;
	O12206[65] = + _CHROFF_1_0_;
	O12206[66] = + _CHROFF_3_0_;
	O12206[67] = + _CHROFF_8_4_;
	O12206[68] = + _CHROFF_4_0_;
	O12206[69] = + _CHROFF_11_4_;
	O12206[70] = + _CHROFF_4_0_;
	O12206[71] = + _CHROFF_11_5_;
	O12206[72] = + _CHROFF_13_3_;
	O12206[73] = + _CHROFF_16_5_;
	O12206[74] = + _CHROFF_35_7_;
	O12206[75] = + _CHROFF_42_10_;
	O12206[76] = + _CHROFF_37_7_;
	O12206[77] = + _CHROFF_46_10_;
	O12206[78] = + _CHROFF_37_7_;
	O12206[79] = + _CHROFF_38_7_;
	O12206[80] = + _CHROFF_37_7_;
	O12206[81] = + _CHROFF_47_10_;
	O12206[82] = + _CHROFF_49_10_;
	O12206[83] = + _CHROFF_47_10_;
	{long i; for (i = 84; i < 87; i++) O12206[i] = + _CHROFF_39_8_;}
	{long i; for (i = 87; i < 90; i++) O12206[i] = + _CHROFF_49_11_;}
	{long i; for (i = 90; i < 94; i++) O12206[i] = + _CHROFF_39_8_;}
	O12206[94] = + _CHROFF_47_10_;
	O12206[95] = + _CHROFF_47_12_;
	O12206[96] = + _CHROFF_50_11_;
	O12206[97] = + _CHROFF_53_11_;
	O12206[98] = + _CHROFF_49_11_;
	O12206[99] = + _CHROFF_51_11_;
	{long i; for (i = 100; i < 102; i++) O12206[i] = + _CHROFF_49_12_;}
	O12206[102] = + _CHROFF_59_19_;
	O12206[103] = + _CHROFF_59_21_;
	O12206[104] = + _CHROFF_65_23_;
	O12206[105] = + _CHROFF_68_24_;
	O12206[106] = + _CHROFF_35_7_;
	O12206[107] = + _CHROFF_37_7_;
	O12206[108] = + _CHROFF_37_8_;
	O12206[109] = + _CHROFF_43_7_;
	O12206[110] = + _CHROFF_35_7_;
	O12206[111] = + _CHROFF_40_7_;
	{long i; for (i = 112; i < 115; i++) O12206[i] = + _CHROFF_37_7_;}
	{long i; for (i = 115; i < 117; i++) O12206[i] = + _CHROFF_36_7_;}
	O12206[117] = + _CHROFF_37_7_;
	O12206[118] = + _CHROFF_37_8_;
	O12206[119] = + _CHROFF_36_7_;
	O12206[120] = + _CHROFF_37_7_;
	O12206[121] = + _CHROFF_41_7_;
	O12206[122] = + _CHROFF_36_7_;
	O12206[123] = + _CHROFF_40_10_;
	{long i; for (i = 124; i < 127; i++) O12206[i] = + _CHROFF_35_7_;}
	O12206[127] = + _CHROFF_42_11_;
	O12206[128] = + _CHROFF_51_11_;
	O12206[129] = + _CHROFF_45_14_;
	O12206[130] = + _CHROFF_58_12_;
	O12206[131] = + _CHROFF_44_11_;
	O12206[132] = + _CHROFF_51_13_;
	O12206[133] = + _CHROFF_44_11_;
	{long i; for (i = 134; i < 136; i++) O12206[i] = + _CHROFF_44_12_;}
	{long i; for (i = 136; i < 138; i++) O12206[i] = + _CHROFF_46_12_;}
	O12206[138] = + _CHROFF_50_11_;
	O12206[139] = + _CHROFF_51_12_;
	O12206[140] = + _CHROFF_43_11_;
	O12206[141] = + _CHROFF_46_12_;
	O12206[142] = + _CHROFF_59_14_;
	O12206[143] = + _CHROFF_44_13_;
	O12206[144] = + _CHROFF_51_16_;
	{long i; for (i = 145; i < 148; i++) O12206[i] = + _CHROFF_42_11_;}
	O12206[148] = + _CHROFF_16_3_;
	O12206[149] = + _CHROFF_18_3_;
	O12206[150] = + _CHROFF_23_3_;
	{long i; for (i = 151; i < 153; i++) O12206[i] = + _CHROFF_16_3_;}
	O12206[153] = + _CHROFF_22_6_;
	{long i; for (i = 154; i < 156; i++) O12206[i] = + _CHROFF_20_3_;}
	{long i; for (i = 156; i < 158; i++) O12206[i] = + _CHROFF_25_4_;}
	{long i; for (i = 158; i < 160; i++) O12206[i] = + _CHROFF_21_5_;}
	{long i; for (i = 160; i < 164; i++) O12206[i] = + _CHROFF_17_4_;}
	O12206[164] = + _CHROFF_18_4_;
	O12206[165] = + _CHROFF_23_6_;
	{long i; for (i = 166; i < 168; i++) O12206[i] = + _CHROFF_23_7_;}
	O12206[168] = + _CHROFF_24_7_;
	O12206[169] = + _CHROFF_26_6_;
	O12206[170] = + _CHROFF_19_3_;
	O12206[171] = + _CHROFF_22_3_;
	{long i; for (i = 172; i < 174; i++) O12206[i] = + _CHROFF_21_8_;}
	{long i; for (i = 174; i < 176; i++) O12206[i] = + _CHROFF_29_12_;}
	O12206[176] = + _CHROFF_1_0_;
	O12206[177] = + _CHROFF_36_8_;
	{long i; for (i = 178; i < 180; i++) O12206[i] = + _CHROFF_1_0_;}
	O12206[180] = + _CHROFF_36_7_;
	O12206[181] = + _CHROFF_6_2_;
	O12206[182] = + _CHROFF_48_15_;
	O12206[183] = + _CHROFF_6_2_;
	O12206[184] = + _CHROFF_6_4_;
	O12206[185] = + _CHROFF_48_14_;
	{long i; for (i = 186; i < 188; i++) O12206[i] = + _CHROFF_3_0_;}
}

long O12347[174];
void O12347_init () {
	O12347[0] =  + _REFACS_1_;
	{long i; for (i = 62; i < 64; i++) O12347[i] =  + _REFACS_25_;}
	{long i; for (i = 64; i < 67; i++) O12347[i] =  + _REFACS_26_;}
	O12347[67] =  + _REFACS_27_;
	{long i; for (i = 68; i < 70; i++) O12347[i] =  + _REFACS_26_;}
	O12347[70] =  + _REFACS_27_;
	O12347[71] =  + _REFACS_26_;
	{long i; for (i = 72; i < 82; i++) O12347[i] =  + _REFACS_27_;}
	{long i; for (i = 82; i < 84; i++) O12347[i] =  + _REFACS_31_;}
	{long i; for (i = 84; i < 86; i++) O12347[i] =  + _REFACS_34_;}
	{long i; for (i = 86; i < 90; i++) O12347[i] =  + _REFACS_27_;}
	{long i; for (i = 90; i < 92; i++) O12347[i] =  + _REFACS_31_;}
	{long i; for (i = 92; i < 94; i++) O12347[i] =  + _REFACS_34_;}
	O12347[94] =  + _REFACS_25_;
	O12347[95] =  + _REFACS_27_;
	O12347[96] =  + _REFACS_26_;
	O12347[97] =  + _REFACS_29_;
	O12347[98] =  + _REFACS_25_;
	O12347[99] =  + _REFACS_30_;
	{long i; for (i = 100; i < 105; i++) O12347[i] =  + _REFACS_26_;}
	{long i; for (i = 105; i < 107; i++) O12347[i] =  + _REFACS_27_;}
	O12347[107] =  + _REFACS_26_;
	O12347[108] =  + _REFACS_27_;
	O12347[109] =  + _REFACS_31_;
	O12347[110] =  + _REFACS_26_;
	O12347[111] =  + _REFACS_29_;
	{long i; for (i = 112; i < 116; i++) O12347[i] =  + _REFACS_25_;}
	O12347[116] =  + _REFACS_27_;
	O12347[117] =  + _REFACS_26_;
	O12347[118] =  + _REFACS_29_;
	O12347[119] =  + _REFACS_25_;
	O12347[120] =  + _REFACS_30_;
	{long i; for (i = 121; i < 126; i++) O12347[i] =  + _REFACS_26_;}
	{long i; for (i = 126; i < 128; i++) O12347[i] =  + _REFACS_27_;}
	O12347[128] =  + _REFACS_26_;
	O12347[129] =  + _REFACS_27_;
	O12347[130] =  + _REFACS_31_;
	O12347[131] =  + _REFACS_26_;
	O12347[132] =  + _REFACS_29_;
	{long i; for (i = 133; i < 136; i++) O12347[i] =  + _REFACS_25_;}
	O12347[165] =  + _REFACS_26_;
	O12347[168] =  + _REFACS_26_;
	O12347[170] =  + _REFACS_26_;
	O12347[173] =  + _REFACS_26_;
}

long O12739[143];
void O12739_init () {
	O12739[0] = + _LNGOFF_1_1_0_0_;
	O12739[1] = + _LNGOFF_2_1_0_0_;
	{long i; for (i = 2; i < 4; i++) O12739[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 4; i < 6; i++) O12739[i] = + _LNGOFF_2_1_0_0_;}
	O12739[6] = + _LNGOFF_4_1_0_0_;
	O12739[12] = + _LNGOFF_2_1_0_0_;
	O12739[13] = + _LNGOFF_6_3_0_1_;
	O12739[51] = + _LNGOFF_37_9_6_0_;
	O12739[52] = + _LNGOFF_38_9_6_0_;
	O12739[53] = + _LNGOFF_37_9_6_0_;
	O12739[54] = + _LNGOFF_47_12_10_1_;
	O12739[55] = + _LNGOFF_49_12_10_1_;
	O12739[56] = + _LNGOFF_47_12_10_1_;
	{long i; for (i = 57; i < 60; i++) O12739[i] = + _LNGOFF_39_10_6_0_;}
	{long i; for (i = 60; i < 63; i++) O12739[i] = + _LNGOFF_49_13_10_1_;}
	O12739[80] = + _LNGOFF_37_9_6_0_;
	O12739[81] = + _LNGOFF_37_10_6_0_;
	O12739[82] = + _LNGOFF_43_9_6_0_;
	O12739[84] = + _LNGOFF_40_9_6_0_;
	O12739[90] = + _LNGOFF_37_9_6_0_;
	O12739[91] = + _LNGOFF_37_10_6_0_;
	O12739[94] = + _LNGOFF_41_9_6_0_;
	O12739[101] = + _LNGOFF_51_13_10_1_;
	O12739[102] = + _LNGOFF_45_16_10_1_;
	O12739[103] = + _LNGOFF_58_14_10_1_;
	O12739[105] = + _LNGOFF_51_15_10_1_;
	O12739[111] = + _LNGOFF_50_13_10_1_;
	O12739[112] = + _LNGOFF_51_14_10_1_;
	O12739[115] = + _LNGOFF_59_16_10_1_;
	{long i; for (i = 127; i < 129; i++) O12739[i] = + _LNGOFF_20_5_6_0_;}
	{long i; for (i = 129; i < 131; i++) O12739[i] = + _LNGOFF_25_6_6_0_;}
	O12739[137] = + _LNGOFF_18_6_6_0_;
	O12739[142] = + _LNGOFF_26_8_6_1_;
}

long O12773[142];
void O12773_init () {
	O12773[0] =  + _REFACS_1_;
	O12773[4] =  + _REFACS_1_;
	O12773[5] =  + _REFACS_2_;
	O12773[12] =  + _REFACS_2_;
	O12773[53] =  + _REFACS_27_;
	O12773[54] =  + _REFACS_28_;
	O12773[55] =  + _REFACS_27_;
	{long i; for (i = 59; i < 62; i++) O12773[i] =  + _REFACS_28_;}
	O12773[100] =  + _REFACS_28_;
	O12773[101] =  + _REFACS_27_;
	O12773[102] =  + _REFACS_30_;
	O12773[104] =  + _REFACS_31_;
	{long i; for (i = 110; i < 112; i++) O12773[i] =  + _REFACS_28_;}
	O12773[114] =  + _REFACS_32_;
	{long i; for (i = 128; i < 130; i++) O12773[i] =  + _REFACS_15_;}
	O12773[141] =  + _REFACS_13_;
}

static EIF_TYPE_INDEX Y12773_pgtype0[] = {891,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y12773_pgtype1[] = {891,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y12773_pgtype2[] = {891,1401,0xFFFF};
static EIF_TYPE_INDEX Y12773_pgtype3[] = {891,1401,0xFFFF};
static EIF_TYPE_INDEX Y12773_pgtype4[] = {891,1346,0xFFFF};
static EIF_TYPE_INDEX Y12773_pgtype5[] = {891,1346,0xFFFF};
static EIF_TYPE_INDEX Y12773_pgtype6[] = {891,1346,0xFFFF};
static EIF_TYPE_INDEX Y12773_pgtype7[] = {891,1346,0xFFFF};
static EIF_TYPE_INDEX Y12773_pgtype8[] = {891,1346,0xFFFF};
static EIF_TYPE_INDEX Y12773_pgtype9[] = {891,1346,0xFFFF};
static EIF_TYPE_INDEX Y12773_pgtype10[] = {891,1395,0xFFFF};
static EIF_TYPE_INDEX Y12773_pgtype11[] = {891,1397,0xFFFF};
static EIF_TYPE_INDEX Y12773_pgtype12[] = {891,1394,0xFFFF};
static EIF_TYPE_INDEX Y12773_pgtype13[] = {891,1393,0xFFFF};
static EIF_TYPE_INDEX Y12773_pgtype14[] = {891,1392,0xFFFF};
static EIF_TYPE_INDEX Y12773_pgtype15[] = {891,1392,0xFFFF};
static EIF_TYPE_INDEX Y12773_pgtype16[] = {891,1392,0xFFFF};
static EIF_TYPE_INDEX Y12773_pgtype17[] = {891,1395,0xFFFF};
static EIF_TYPE_INDEX Y12773_pgtype18[] = {891,1395,0xFFFF};
static EIF_TYPE_INDEX Y12773_pgtype19[] = {891,1401,0xFFFF};
EIF_TYPE_INDEX *Y12773_gen_type [142];
EIF_TYPE_INDEX Y12773 [142];
void Y12773_init (void)
{
	egc_routines_types [12773] = Y12773;
	egc_routines_gen_types [12773] = Y12773_gen_type;
	egc_routines_offset [12773] = 1541;
	Y12773_gen_type [0] = Y12773_pgtype0;
	Y12773_gen_type [4] = Y12773_pgtype1;
	Y12773_gen_type [5] = Y12773_pgtype2;
	Y12773_gen_type [12] = Y12773_pgtype3;
	Y12773_gen_type [53] = Y12773_pgtype4;
	Y12773_gen_type [54] = Y12773_pgtype5;
	Y12773_gen_type [55] = Y12773_pgtype6;
	Y12773_gen_type [59] = Y12773_pgtype7;
	Y12773_gen_type [60] = Y12773_pgtype8;
	Y12773_gen_type [61] = Y12773_pgtype9;
	Y12773_gen_type [100] = Y12773_pgtype10;
	Y12773_gen_type [101] = Y12773_pgtype11;
	Y12773_gen_type [102] = Y12773_pgtype12;
	Y12773_gen_type [104] = Y12773_pgtype13;
	Y12773_gen_type [110] = Y12773_pgtype14;
	Y12773_gen_type [111] = Y12773_pgtype15;
	Y12773_gen_type [114] = Y12773_pgtype16;
	Y12773_gen_type [128] = Y12773_pgtype17;
	Y12773_gen_type [129] = Y12773_pgtype18;
	Y12773_gen_type [141] = Y12773_pgtype19;
	Y12773[0] = 891;
	{long i; for (i = 4; i < 6; i++) Y12773[i] = 891;};
	Y12773[12] = 891;
	{long i; for (i = 53; i < 56; i++) Y12773[i] = 891;};
	{long i; for (i = 59; i < 62; i++) Y12773[i] = 891;};
	{long i; for (i = 100; i < 103; i++) Y12773[i] = 891;};
	Y12773[104] = 891;
	{long i; for (i = 110; i < 112; i++) Y12773[i] = 891;};
	Y12773[114] = 891;
	{long i; for (i = 128; i < 130; i++) Y12773[i] = 891;};
	Y12773[141] = 891;
}

long O12790[152];
void O12790_init () {
	O12790[0] = + _PTROFF_2_3_0_1_0_0_;
	O12790[1] = + _PTROFF_4_3_0_1_0_0_;
	O12790[2] = + _PTROFF_5_5_0_1_0_0_;
	O12790[3] = + _PTROFF_10_10_0_9_0_0_;
	O12790[6] = + _PTROFF_6_3_0_2_0_0_;
	O12790[33] = + _PTROFF_8_5_0_1_0_0_;
	O12790[35] = + _PTROFF_11_5_0_1_0_0_;
	O12790[37] = + _PTROFF_11_6_0_1_0_0_;
	O12790[39] = + _PTROFF_16_7_6_1_0_0_;
	O12790[41] = + _PTROFF_42_12_10_6_0_0_;
	O12790[43] = + _PTROFF_46_12_10_6_0_0_;
	O12790[47] = + _PTROFF_47_12_10_7_0_0_;
	O12790[48] = + _PTROFF_49_12_10_10_0_0_;
	O12790[49] = + _PTROFF_47_12_10_7_0_0_;
	{long i; for (i = 53; i < 56; i++) O12790[i] = + _PTROFF_49_13_10_7_0_0_;}
	O12790[64] = + _PTROFF_49_13_10_6_0_0_;
	O12790[65] = + _PTROFF_51_13_10_8_0_0_;
	O12790[66] = + _PTROFF_49_14_10_8_0_0_;
	O12790[67] = + _PTROFF_49_14_10_10_0_0_;
	O12790[68] = + _PTROFF_59_21_10_11_0_0_;
	O12790[69] = + _PTROFF_59_23_10_11_0_0_;
	O12790[70] = + _PTROFF_65_25_10_11_0_0_;
	O12790[71] = + _PTROFF_68_26_10_11_0_0_;
	O12790[93] = + _PTROFF_42_13_10_6_0_0_;
	O12790[94] = + _PTROFF_51_13_10_9_0_0_;
	O12790[95] = + _PTROFF_45_16_10_7_0_0_;
	O12790[96] = + _PTROFF_58_14_10_9_0_0_;
	O12790[97] = + _PTROFF_44_13_10_6_1_0_;
	O12790[98] = + _PTROFF_51_15_10_10_0_0_;
	O12790[99] = + _PTROFF_44_13_10_7_0_0_;
	{long i; for (i = 100; i < 102; i++) O12790[i] = + _PTROFF_44_14_10_7_0_0_;}
	{long i; for (i = 102; i < 104; i++) O12790[i] = + _PTROFF_46_14_10_6_0_0_;}
	O12790[104] = + _PTROFF_50_13_10_9_0_0_;
	O12790[105] = + _PTROFF_51_14_10_9_0_0_;
	O12790[106] = + _PTROFF_43_13_10_6_0_0_;
	O12790[107] = + _PTROFF_46_14_10_7_0_0_;
	O12790[108] = + _PTROFF_59_16_10_12_0_0_;
	O12790[109] = + _PTROFF_44_15_10_6_0_0_;
	O12790[110] = + _PTROFF_51_18_10_10_0_0_;
	{long i; for (i = 111; i < 114; i++) O12790[i] = + _PTROFF_42_13_10_6_0_0_;}
	O12790[119] = + _PTROFF_22_8_6_4_0_0_;
	{long i; for (i = 124; i < 126; i++) O12790[i] = + _PTROFF_21_7_6_1_0_0_;}
	O12790[131] = + _PTROFF_23_8_6_1_0_0_;
	{long i; for (i = 132; i < 134; i++) O12790[i] = + _PTROFF_23_9_6_1_0_0_;}
	O12790[134] = + _PTROFF_24_9_6_1_0_0_;
	O12790[135] = + _PTROFF_26_8_6_2_0_0_;
	{long i; for (i = 140; i < 142; i++) O12790[i] = + _PTROFF_29_14_8_2_0_0_;}
	O12790[148] = + _PTROFF_48_19_10_9_0_0_;
	O12790[151] = + _PTROFF_48_18_10_9_0_0_;
}

long O12791[152];
void O12791_init () {
	O12791[0] = + _CHROFF_2_0_;
	O12791[1] = + _CHROFF_4_0_;
	O12791[2] = + _CHROFF_5_0_;
	O12791[3] = + _CHROFF_10_0_;
	O12791[6] = + _CHROFF_6_0_;
	O12791[33] = + _CHROFF_8_0_;
	O12791[35] = + _CHROFF_11_0_;
	O12791[37] = + _CHROFF_11_0_;
	O12791[39] = + _CHROFF_16_1_;
	O12791[41] = + _CHROFF_42_1_;
	O12791[43] = + _CHROFF_46_1_;
	O12791[47] = + _CHROFF_47_1_;
	O12791[48] = + _CHROFF_49_1_;
	O12791[49] = + _CHROFF_47_1_;
	{long i; for (i = 53; i < 56; i++) O12791[i] = + _CHROFF_49_1_;}
	O12791[64] = + _CHROFF_49_1_;
	O12791[65] = + _CHROFF_51_1_;
	{long i; for (i = 66; i < 68; i++) O12791[i] = + _CHROFF_49_1_;}
	{long i; for (i = 68; i < 70; i++) O12791[i] = + _CHROFF_59_1_;}
	O12791[70] = + _CHROFF_65_1_;
	O12791[71] = + _CHROFF_68_1_;
	O12791[93] = + _CHROFF_42_1_;
	O12791[94] = + _CHROFF_51_1_;
	O12791[95] = + _CHROFF_45_1_;
	O12791[96] = + _CHROFF_58_1_;
	O12791[97] = + _CHROFF_44_1_;
	O12791[98] = + _CHROFF_51_1_;
	{long i; for (i = 99; i < 102; i++) O12791[i] = + _CHROFF_44_1_;}
	{long i; for (i = 102; i < 104; i++) O12791[i] = + _CHROFF_46_1_;}
	O12791[104] = + _CHROFF_50_1_;
	O12791[105] = + _CHROFF_51_1_;
	O12791[106] = + _CHROFF_43_1_;
	O12791[107] = + _CHROFF_46_1_;
	O12791[108] = + _CHROFF_59_1_;
	O12791[109] = + _CHROFF_44_1_;
	O12791[110] = + _CHROFF_51_1_;
	{long i; for (i = 111; i < 114; i++) O12791[i] = + _CHROFF_42_1_;}
	O12791[119] = + _CHROFF_22_1_;
	{long i; for (i = 124; i < 126; i++) O12791[i] = + _CHROFF_21_1_;}
	{long i; for (i = 131; i < 134; i++) O12791[i] = + _CHROFF_23_1_;}
	O12791[134] = + _CHROFF_24_1_;
	O12791[135] = + _CHROFF_26_1_;
	{long i; for (i = 140; i < 142; i++) O12791[i] = + _CHROFF_29_1_;}
	O12791[148] = + _CHROFF_48_1_;
	O12791[151] = + _CHROFF_48_1_;
}

long O12802[152];
void O12802_init () {
	{long i; for (i = 0; i < 4; i++) O12802[i] =  + _REFACS_1_;}
	O12802[6] =  + _REFACS_4_;
	O12802[33] =  + _REFACS_3_;
	O12802[35] =  + _REFACS_3_;
	O12802[37] =  + _REFACS_3_;
	O12802[39] =  + _REFACS_8_;
	O12802[41] =  + _REFACS_26_;
	O12802[43] =  + _REFACS_27_;
	O12802[47] =  + _REFACS_28_;
	O12802[48] =  + _REFACS_29_;
	O12802[49] =  + _REFACS_28_;
	{long i; for (i = 53; i < 56; i++) O12802[i] =  + _REFACS_29_;}
	{long i; for (i = 64; i < 68; i++) O12802[i] =  + _REFACS_28_;}
	{long i; for (i = 68; i < 70; i++) O12802[i] =  + _REFACS_32_;}
	{long i; for (i = 70; i < 72; i++) O12802[i] =  + _REFACS_35_;}
	O12802[93] =  + _REFACS_26_;
	O12802[94] =  + _REFACS_29_;
	O12802[95] =  + _REFACS_28_;
	O12802[96] =  + _REFACS_31_;
	O12802[97] =  + _REFACS_26_;
	O12802[98] =  + _REFACS_32_;
	{long i; for (i = 99; i < 104; i++) O12802[i] =  + _REFACS_27_;}
	{long i; for (i = 104; i < 106; i++) O12802[i] =  + _REFACS_29_;}
	O12802[106] =  + _REFACS_27_;
	O12802[107] =  + _REFACS_28_;
	O12802[108] =  + _REFACS_33_;
	O12802[109] =  + _REFACS_27_;
	O12802[110] =  + _REFACS_30_;
	{long i; for (i = 111; i < 114; i++) O12802[i] =  + _REFACS_26_;}
	O12802[119] =  + _REFACS_11_;
	{long i; for (i = 124; i < 126; i++) O12802[i] =  + _REFACS_11_;}
	{long i; for (i = 131; i < 135; i++) O12802[i] =  + _REFACS_12_;}
	O12802[135] =  + _REFACS_15_;
	{long i; for (i = 140; i < 142; i++) O12802[i] =  + _REFACS_15_;}
	O12802[148] =  + _REFACS_27_;
	O12802[151] =  + _REFACS_27_;
}

long O12804[152];
void O12804_init () {
	O12804[0] = + _CHROFF_2_1_;
	O12804[1] = + _CHROFF_4_1_;
	O12804[2] = + _CHROFF_5_1_;
	O12804[3] = + _CHROFF_10_1_;
	O12804[6] = + _CHROFF_6_1_;
	O12804[33] = + _CHROFF_8_1_;
	O12804[35] = + _CHROFF_11_1_;
	O12804[37] = + _CHROFF_11_1_;
	O12804[39] = + _CHROFF_16_2_;
	O12804[41] = + _CHROFF_42_2_;
	O12804[43] = + _CHROFF_46_2_;
	O12804[47] = + _CHROFF_47_2_;
	O12804[48] = + _CHROFF_49_2_;
	O12804[49] = + _CHROFF_47_2_;
	{long i; for (i = 53; i < 56; i++) O12804[i] = + _CHROFF_49_2_;}
	O12804[64] = + _CHROFF_49_2_;
	O12804[65] = + _CHROFF_51_2_;
	{long i; for (i = 66; i < 68; i++) O12804[i] = + _CHROFF_49_2_;}
	{long i; for (i = 68; i < 70; i++) O12804[i] = + _CHROFF_59_2_;}
	O12804[70] = + _CHROFF_65_2_;
	O12804[71] = + _CHROFF_68_2_;
	O12804[93] = + _CHROFF_42_2_;
	O12804[94] = + _CHROFF_51_2_;
	O12804[95] = + _CHROFF_45_2_;
	O12804[96] = + _CHROFF_58_2_;
	O12804[97] = + _CHROFF_44_2_;
	O12804[98] = + _CHROFF_51_2_;
	{long i; for (i = 99; i < 102; i++) O12804[i] = + _CHROFF_44_2_;}
	{long i; for (i = 102; i < 104; i++) O12804[i] = + _CHROFF_46_2_;}
	O12804[104] = + _CHROFF_50_2_;
	O12804[105] = + _CHROFF_51_2_;
	O12804[106] = + _CHROFF_43_2_;
	O12804[107] = + _CHROFF_46_2_;
	O12804[108] = + _CHROFF_59_2_;
	O12804[109] = + _CHROFF_44_2_;
	O12804[110] = + _CHROFF_51_2_;
	{long i; for (i = 111; i < 114; i++) O12804[i] = + _CHROFF_42_2_;}
	O12804[119] = + _CHROFF_22_2_;
	{long i; for (i = 124; i < 126; i++) O12804[i] = + _CHROFF_21_2_;}
	{long i; for (i = 131; i < 134; i++) O12804[i] = + _CHROFF_23_2_;}
	O12804[134] = + _CHROFF_24_2_;
	O12804[135] = + _CHROFF_26_2_;
	{long i; for (i = 140; i < 142; i++) O12804[i] = + _CHROFF_29_2_;}
	O12804[148] = + _CHROFF_48_2_;
	O12804[151] = + _CHROFF_48_2_;
}

long O12836[151];
void O12836_init () {
	{long i; for (i = 0; i < 3; i++) O12836[i] =  + _REFACS_2_;}
	O12836[32] =  + _REFACS_4_;
	O12836[34] =  + _REFACS_4_;
	O12836[36] =  + _REFACS_4_;
	O12836[38] =  + _REFACS_9_;
	O12836[40] =  + _REFACS_27_;
	O12836[42] =  + _REFACS_28_;
	O12836[46] =  + _REFACS_29_;
	O12836[47] =  + _REFACS_30_;
	O12836[48] =  + _REFACS_29_;
	{long i; for (i = 52; i < 55; i++) O12836[i] =  + _REFACS_30_;}
	{long i; for (i = 63; i < 67; i++) O12836[i] =  + _REFACS_29_;}
	{long i; for (i = 67; i < 69; i++) O12836[i] =  + _REFACS_33_;}
	{long i; for (i = 69; i < 71; i++) O12836[i] =  + _REFACS_36_;}
	O12836[92] =  + _REFACS_27_;
	O12836[93] =  + _REFACS_30_;
	O12836[94] =  + _REFACS_29_;
	O12836[95] =  + _REFACS_32_;
	O12836[96] =  + _REFACS_27_;
	O12836[97] =  + _REFACS_33_;
	{long i; for (i = 98; i < 103; i++) O12836[i] =  + _REFACS_28_;}
	{long i; for (i = 103; i < 105; i++) O12836[i] =  + _REFACS_30_;}
	O12836[105] =  + _REFACS_28_;
	O12836[106] =  + _REFACS_29_;
	O12836[107] =  + _REFACS_34_;
	O12836[108] =  + _REFACS_28_;
	O12836[109] =  + _REFACS_31_;
	{long i; for (i = 110; i < 113; i++) O12836[i] =  + _REFACS_27_;}
	{long i; for (i = 123; i < 125; i++) O12836[i] =  + _REFACS_12_;}
	{long i; for (i = 130; i < 134; i++) O12836[i] =  + _REFACS_13_;}
	O12836[134] =  + _REFACS_16_;
	{long i; for (i = 139; i < 141; i++) O12836[i] =  + _REFACS_16_;}
	O12836[147] =  + _REFACS_28_;
	O12836[150] =  + _REFACS_28_;
}

long O12837[151];
void O12837_init () {
	{long i; for (i = 0; i < 3; i++) O12837[i] =  + _REFACS_3_;}
	O12837[32] =  + _REFACS_5_;
	O12837[34] =  + _REFACS_5_;
	O12837[36] =  + _REFACS_5_;
	O12837[38] =  + _REFACS_10_;
	O12837[40] =  + _REFACS_28_;
	O12837[42] =  + _REFACS_29_;
	O12837[46] =  + _REFACS_30_;
	O12837[47] =  + _REFACS_31_;
	O12837[48] =  + _REFACS_30_;
	{long i; for (i = 52; i < 55; i++) O12837[i] =  + _REFACS_31_;}
	{long i; for (i = 63; i < 67; i++) O12837[i] =  + _REFACS_30_;}
	{long i; for (i = 67; i < 69; i++) O12837[i] =  + _REFACS_34_;}
	{long i; for (i = 69; i < 71; i++) O12837[i] =  + _REFACS_37_;}
	O12837[92] =  + _REFACS_28_;
	O12837[93] =  + _REFACS_31_;
	O12837[94] =  + _REFACS_30_;
	O12837[95] =  + _REFACS_33_;
	O12837[96] =  + _REFACS_28_;
	O12837[97] =  + _REFACS_34_;
	{long i; for (i = 98; i < 103; i++) O12837[i] =  + _REFACS_29_;}
	{long i; for (i = 103; i < 105; i++) O12837[i] =  + _REFACS_31_;}
	O12837[105] =  + _REFACS_29_;
	O12837[106] =  + _REFACS_30_;
	O12837[107] =  + _REFACS_35_;
	O12837[108] =  + _REFACS_29_;
	O12837[109] =  + _REFACS_32_;
	{long i; for (i = 110; i < 113; i++) O12837[i] =  + _REFACS_28_;}
	{long i; for (i = 123; i < 125; i++) O12837[i] =  + _REFACS_13_;}
	{long i; for (i = 130; i < 134; i++) O12837[i] =  + _REFACS_14_;}
	O12837[134] =  + _REFACS_17_;
	{long i; for (i = 139; i < 141; i++) O12837[i] =  + _REFACS_17_;}
	O12837[147] =  + _REFACS_29_;
	O12837[150] =  + _REFACS_29_;
}

long O12857[70];
void O12857_init () {
	{long i; for (i = 0; i < 2; i++) O12857[i] =  + _REFACS_4_;}
	O12857[31] =  + _REFACS_6_;
	O12857[33] =  + _REFACS_6_;
	O12857[35] =  + _REFACS_6_;
	{long i; for (i = 66; i < 68; i++) O12857[i] =  + _REFACS_35_;}
	{long i; for (i = 68; i < 70; i++) O12857[i] =  + _REFACS_38_;}
}

long O12864[70];
void O12864_init () {
	O12864[0] = + _CHROFF_5_2_;
	O12864[1] = + _CHROFF_10_2_;
	O12864[31] = + _CHROFF_8_2_;
	O12864[33] = + _CHROFF_11_2_;
	O12864[35] = + _CHROFF_11_2_;
	{long i; for (i = 66; i < 68; i++) O12864[i] = + _CHROFF_59_3_;}
	O12864[68] = + _CHROFF_65_3_;
	O12864[69] = + _CHROFF_68_3_;
}

long O12870[70];
void O12870_init () {
	O12870[0] = + _CHROFF_5_3_;
	O12870[1] = + _CHROFF_10_3_;
	O12870[31] = + _CHROFF_8_3_;
	O12870[33] = + _CHROFF_11_3_;
	O12870[35] = + _CHROFF_11_3_;
	{long i; for (i = 66; i < 68; i++) O12870[i] = + _CHROFF_59_4_;}
	O12870[68] = + _CHROFF_65_4_;
	O12870[69] = + _CHROFF_68_4_;
}

long O12951[143];
void O12951_init () {
	O12951[0] =  + _REFACS_1_;
	O12951[32] =  + _REFACS_29_;
	O12951[34] =  + _REFACS_30_;
	O12951[38] =  + _REFACS_31_;
	O12951[39] =  + _REFACS_32_;
	O12951[40] =  + _REFACS_31_;
	{long i; for (i = 44; i < 47; i++) O12951[i] =  + _REFACS_32_;}
	{long i; for (i = 55; i < 59; i++) O12951[i] =  + _REFACS_31_;}
	{long i; for (i = 59; i < 61; i++) O12951[i] =  + _REFACS_36_;}
	{long i; for (i = 61; i < 63; i++) O12951[i] =  + _REFACS_39_;}
	O12951[84] =  + _REFACS_29_;
	O12951[85] =  + _REFACS_32_;
	O12951[86] =  + _REFACS_31_;
	O12951[87] =  + _REFACS_34_;
	O12951[88] =  + _REFACS_29_;
	O12951[89] =  + _REFACS_35_;
	{long i; for (i = 90; i < 95; i++) O12951[i] =  + _REFACS_30_;}
	{long i; for (i = 95; i < 97; i++) O12951[i] =  + _REFACS_32_;}
	O12951[97] =  + _REFACS_30_;
	O12951[98] =  + _REFACS_31_;
	O12951[99] =  + _REFACS_36_;
	O12951[100] =  + _REFACS_30_;
	O12951[101] =  + _REFACS_33_;
	{long i; for (i = 102; i < 105; i++) O12951[i] =  + _REFACS_29_;}
	O12951[139] =  + _REFACS_30_;
	O12951[142] =  + _REFACS_30_;
}

long O12952[143];
void O12952_init () {
	O12952[0] =  + _REFACS_2_;
	O12952[32] =  + _REFACS_30_;
	O12952[34] =  + _REFACS_31_;
	O12952[38] =  + _REFACS_32_;
	O12952[39] =  + _REFACS_33_;
	O12952[40] =  + _REFACS_32_;
	{long i; for (i = 44; i < 47; i++) O12952[i] =  + _REFACS_33_;}
	{long i; for (i = 55; i < 59; i++) O12952[i] =  + _REFACS_32_;}
	{long i; for (i = 59; i < 61; i++) O12952[i] =  + _REFACS_37_;}
	{long i; for (i = 61; i < 63; i++) O12952[i] =  + _REFACS_40_;}
	O12952[84] =  + _REFACS_30_;
	O12952[85] =  + _REFACS_33_;
	O12952[86] =  + _REFACS_32_;
	O12952[87] =  + _REFACS_35_;
	O12952[88] =  + _REFACS_30_;
	O12952[89] =  + _REFACS_36_;
	{long i; for (i = 90; i < 95; i++) O12952[i] =  + _REFACS_31_;}
	{long i; for (i = 95; i < 97; i++) O12952[i] =  + _REFACS_33_;}
	O12952[97] =  + _REFACS_31_;
	O12952[98] =  + _REFACS_32_;
	O12952[99] =  + _REFACS_37_;
	O12952[100] =  + _REFACS_31_;
	O12952[101] =  + _REFACS_34_;
	{long i; for (i = 102; i < 105; i++) O12952[i] =  + _REFACS_30_;}
	O12952[139] =  + _REFACS_31_;
	O12952[142] =  + _REFACS_31_;
}

long O12960[142];
void O12960_init () {
	{long i; for (i = 0; i < 2; i++) O12960[i] =  + _REFACS_6_;}
	O12960[30] =  + _REFACS_26_;
	O12960[31] =  + _REFACS_31_;
	O12960[32] =  + _REFACS_27_;
	O12960[33] =  + _REFACS_32_;
	O12960[34] =  + _REFACS_27_;
	O12960[35] =  + _REFACS_28_;
	O12960[36] =  + _REFACS_27_;
	O12960[37] =  + _REFACS_33_;
	O12960[38] =  + _REFACS_34_;
	O12960[39] =  + _REFACS_33_;
	{long i; for (i = 40; i < 43; i++) O12960[i] =  + _REFACS_28_;}
	{long i; for (i = 43; i < 46; i++) O12960[i] =  + _REFACS_34_;}
	{long i; for (i = 46; i < 50; i++) O12960[i] =  + _REFACS_28_;}
	{long i; for (i = 50; i < 52; i++) O12960[i] =  + _REFACS_32_;}
	{long i; for (i = 52; i < 54; i++) O12960[i] =  + _REFACS_35_;}
	{long i; for (i = 54; i < 58; i++) O12960[i] =  + _REFACS_33_;}
	{long i; for (i = 58; i < 60; i++) O12960[i] =  + _REFACS_38_;}
	{long i; for (i = 60; i < 62; i++) O12960[i] =  + _REFACS_41_;}
	O12960[62] =  + _REFACS_26_;
	O12960[63] =  + _REFACS_28_;
	O12960[64] =  + _REFACS_27_;
	O12960[65] =  + _REFACS_30_;
	O12960[66] =  + _REFACS_26_;
	O12960[67] =  + _REFACS_31_;
	{long i; for (i = 68; i < 73; i++) O12960[i] =  + _REFACS_27_;}
	{long i; for (i = 73; i < 75; i++) O12960[i] =  + _REFACS_28_;}
	O12960[75] =  + _REFACS_27_;
	O12960[76] =  + _REFACS_28_;
	O12960[77] =  + _REFACS_32_;
	O12960[78] =  + _REFACS_27_;
	O12960[79] =  + _REFACS_30_;
	{long i; for (i = 80; i < 83; i++) O12960[i] =  + _REFACS_26_;}
	O12960[83] =  + _REFACS_31_;
	O12960[84] =  + _REFACS_34_;
	O12960[85] =  + _REFACS_33_;
	O12960[86] =  + _REFACS_36_;
	O12960[87] =  + _REFACS_31_;
	O12960[88] =  + _REFACS_37_;
	{long i; for (i = 89; i < 94; i++) O12960[i] =  + _REFACS_32_;}
	{long i; for (i = 94; i < 96; i++) O12960[i] =  + _REFACS_34_;}
	O12960[96] =  + _REFACS_32_;
	O12960[97] =  + _REFACS_33_;
	O12960[98] =  + _REFACS_38_;
	O12960[99] =  + _REFACS_32_;
	O12960[100] =  + _REFACS_35_;
	{long i; for (i = 101; i < 104; i++) O12960[i] =  + _REFACS_31_;}
	{long i; for (i = 128; i < 130; i++) O12960[i] =  + _REFACS_15_;}
	{long i; for (i = 130; i < 132; i++) O12960[i] =  + _REFACS_18_;}
	O12960[133] =  + _REFACS_27_;
	O12960[136] =  + _REFACS_27_;
	O12960[138] =  + _REFACS_32_;
	O12960[141] =  + _REFACS_32_;
}

long O12961[142];
void O12961_init () {
	O12961[0] = + _CHROFF_7_1_;
	O12961[1] = + _CHROFF_8_1_;
	O12961[30] = + _CHROFF_35_1_;
	O12961[31] = + _CHROFF_42_3_;
	O12961[32] = + _CHROFF_37_1_;
	O12961[33] = + _CHROFF_46_3_;
	O12961[34] = + _CHROFF_37_1_;
	O12961[35] = + _CHROFF_38_1_;
	O12961[36] = + _CHROFF_37_1_;
	O12961[37] = + _CHROFF_47_3_;
	O12961[38] = + _CHROFF_49_3_;
	O12961[39] = + _CHROFF_47_3_;
	{long i; for (i = 40; i < 43; i++) O12961[i] = + _CHROFF_39_1_;}
	{long i; for (i = 43; i < 46; i++) O12961[i] = + _CHROFF_49_3_;}
	{long i; for (i = 46; i < 50; i++) O12961[i] = + _CHROFF_39_1_;}
	{long i; for (i = 50; i < 52; i++) O12961[i] = + _CHROFF_47_1_;}
	O12961[52] = + _CHROFF_50_1_;
	O12961[53] = + _CHROFF_53_1_;
	O12961[54] = + _CHROFF_49_3_;
	O12961[55] = + _CHROFF_51_3_;
	{long i; for (i = 56; i < 58; i++) O12961[i] = + _CHROFF_49_3_;}
	{long i; for (i = 58; i < 60; i++) O12961[i] = + _CHROFF_59_5_;}
	O12961[60] = + _CHROFF_65_5_;
	O12961[61] = + _CHROFF_68_5_;
	O12961[62] = + _CHROFF_35_1_;
	{long i; for (i = 63; i < 65; i++) O12961[i] = + _CHROFF_37_1_;}
	O12961[65] = + _CHROFF_43_1_;
	O12961[66] = + _CHROFF_35_1_;
	O12961[67] = + _CHROFF_40_1_;
	{long i; for (i = 68; i < 71; i++) O12961[i] = + _CHROFF_37_1_;}
	{long i; for (i = 71; i < 73; i++) O12961[i] = + _CHROFF_36_1_;}
	{long i; for (i = 73; i < 75; i++) O12961[i] = + _CHROFF_37_1_;}
	O12961[75] = + _CHROFF_36_1_;
	O12961[76] = + _CHROFF_37_1_;
	O12961[77] = + _CHROFF_41_1_;
	O12961[78] = + _CHROFF_36_1_;
	O12961[79] = + _CHROFF_40_1_;
	{long i; for (i = 80; i < 83; i++) O12961[i] = + _CHROFF_35_1_;}
	O12961[83] = + _CHROFF_42_3_;
	O12961[84] = + _CHROFF_51_3_;
	O12961[85] = + _CHROFF_45_3_;
	O12961[86] = + _CHROFF_58_3_;
	O12961[87] = + _CHROFF_44_3_;
	O12961[88] = + _CHROFF_51_3_;
	{long i; for (i = 89; i < 92; i++) O12961[i] = + _CHROFF_44_3_;}
	{long i; for (i = 92; i < 94; i++) O12961[i] = + _CHROFF_46_3_;}
	O12961[94] = + _CHROFF_50_3_;
	O12961[95] = + _CHROFF_51_3_;
	O12961[96] = + _CHROFF_43_3_;
	O12961[97] = + _CHROFF_46_3_;
	O12961[98] = + _CHROFF_59_3_;
	O12961[99] = + _CHROFF_44_3_;
	O12961[100] = + _CHROFF_51_3_;
	{long i; for (i = 101; i < 104; i++) O12961[i] = + _CHROFF_42_3_;}
	{long i; for (i = 128; i < 130; i++) O12961[i] = + _CHROFF_21_1_;}
	{long i; for (i = 130; i < 132; i++) O12961[i] = + _CHROFF_29_3_;}
	O12961[133] = + _CHROFF_36_1_;
	O12961[136] = + _CHROFF_36_1_;
	O12961[138] = + _CHROFF_48_3_;
	O12961[141] = + _CHROFF_48_3_;
}

long O12962[142];
void O12962_init () {
	O12962[0] = + _CHROFF_7_2_;
	O12962[1] = + _CHROFF_8_2_;
	O12962[30] = + _CHROFF_35_2_;
	O12962[31] = + _CHROFF_42_4_;
	O12962[32] = + _CHROFF_37_2_;
	O12962[33] = + _CHROFF_46_4_;
	O12962[34] = + _CHROFF_37_2_;
	O12962[35] = + _CHROFF_38_2_;
	O12962[36] = + _CHROFF_37_2_;
	O12962[37] = + _CHROFF_47_4_;
	O12962[38] = + _CHROFF_49_4_;
	O12962[39] = + _CHROFF_47_4_;
	{long i; for (i = 40; i < 43; i++) O12962[i] = + _CHROFF_39_2_;}
	{long i; for (i = 43; i < 46; i++) O12962[i] = + _CHROFF_49_4_;}
	{long i; for (i = 46; i < 50; i++) O12962[i] = + _CHROFF_39_2_;}
	{long i; for (i = 50; i < 52; i++) O12962[i] = + _CHROFF_47_2_;}
	O12962[52] = + _CHROFF_50_2_;
	O12962[53] = + _CHROFF_53_2_;
	O12962[54] = + _CHROFF_49_4_;
	O12962[55] = + _CHROFF_51_4_;
	{long i; for (i = 56; i < 58; i++) O12962[i] = + _CHROFF_49_4_;}
	{long i; for (i = 58; i < 60; i++) O12962[i] = + _CHROFF_59_6_;}
	O12962[60] = + _CHROFF_65_6_;
	O12962[61] = + _CHROFF_68_6_;
	O12962[62] = + _CHROFF_35_2_;
	{long i; for (i = 63; i < 65; i++) O12962[i] = + _CHROFF_37_2_;}
	O12962[65] = + _CHROFF_43_2_;
	O12962[66] = + _CHROFF_35_2_;
	O12962[67] = + _CHROFF_40_2_;
	{long i; for (i = 68; i < 71; i++) O12962[i] = + _CHROFF_37_2_;}
	{long i; for (i = 71; i < 73; i++) O12962[i] = + _CHROFF_36_2_;}
	{long i; for (i = 73; i < 75; i++) O12962[i] = + _CHROFF_37_2_;}
	O12962[75] = + _CHROFF_36_2_;
	O12962[76] = + _CHROFF_37_2_;
	O12962[77] = + _CHROFF_41_2_;
	O12962[78] = + _CHROFF_36_2_;
	O12962[79] = + _CHROFF_40_2_;
	{long i; for (i = 80; i < 83; i++) O12962[i] = + _CHROFF_35_2_;}
	O12962[83] = + _CHROFF_42_4_;
	O12962[84] = + _CHROFF_51_4_;
	O12962[85] = + _CHROFF_45_4_;
	O12962[86] = + _CHROFF_58_4_;
	O12962[87] = + _CHROFF_44_4_;
	O12962[88] = + _CHROFF_51_4_;
	{long i; for (i = 89; i < 92; i++) O12962[i] = + _CHROFF_44_4_;}
	{long i; for (i = 92; i < 94; i++) O12962[i] = + _CHROFF_46_4_;}
	O12962[94] = + _CHROFF_50_4_;
	O12962[95] = + _CHROFF_51_4_;
	O12962[96] = + _CHROFF_43_4_;
	O12962[97] = + _CHROFF_46_4_;
	O12962[98] = + _CHROFF_59_4_;
	O12962[99] = + _CHROFF_44_4_;
	O12962[100] = + _CHROFF_51_4_;
	{long i; for (i = 101; i < 104; i++) O12962[i] = + _CHROFF_42_4_;}
	{long i; for (i = 128; i < 130; i++) O12962[i] = + _CHROFF_21_2_;}
	{long i; for (i = 130; i < 132; i++) O12962[i] = + _CHROFF_29_4_;}
	O12962[133] = + _CHROFF_36_2_;
	O12962[136] = + _CHROFF_36_2_;
	O12962[138] = + _CHROFF_48_4_;
	O12962[141] = + _CHROFF_48_4_;
}

long O12964[142];
void O12964_init () {
	O12964[0] = + _CHROFF_7_3_;
	O12964[1] = + _CHROFF_8_3_;
	O12964[30] = + _CHROFF_35_3_;
	O12964[31] = + _CHROFF_42_5_;
	O12964[32] = + _CHROFF_37_3_;
	O12964[33] = + _CHROFF_46_5_;
	O12964[34] = + _CHROFF_37_3_;
	O12964[35] = + _CHROFF_38_3_;
	O12964[36] = + _CHROFF_37_3_;
	O12964[37] = + _CHROFF_47_5_;
	O12964[38] = + _CHROFF_49_5_;
	O12964[39] = + _CHROFF_47_5_;
	{long i; for (i = 40; i < 43; i++) O12964[i] = + _CHROFF_39_3_;}
	{long i; for (i = 43; i < 46; i++) O12964[i] = + _CHROFF_49_5_;}
	{long i; for (i = 46; i < 50; i++) O12964[i] = + _CHROFF_39_3_;}
	{long i; for (i = 50; i < 52; i++) O12964[i] = + _CHROFF_47_3_;}
	O12964[52] = + _CHROFF_50_3_;
	O12964[53] = + _CHROFF_53_3_;
	O12964[54] = + _CHROFF_49_5_;
	O12964[55] = + _CHROFF_51_5_;
	{long i; for (i = 56; i < 58; i++) O12964[i] = + _CHROFF_49_5_;}
	{long i; for (i = 58; i < 60; i++) O12964[i] = + _CHROFF_59_7_;}
	O12964[60] = + _CHROFF_65_7_;
	O12964[61] = + _CHROFF_68_7_;
	O12964[62] = + _CHROFF_35_3_;
	{long i; for (i = 63; i < 65; i++) O12964[i] = + _CHROFF_37_3_;}
	O12964[65] = + _CHROFF_43_3_;
	O12964[66] = + _CHROFF_35_3_;
	O12964[67] = + _CHROFF_40_3_;
	{long i; for (i = 68; i < 71; i++) O12964[i] = + _CHROFF_37_3_;}
	{long i; for (i = 71; i < 73; i++) O12964[i] = + _CHROFF_36_3_;}
	{long i; for (i = 73; i < 75; i++) O12964[i] = + _CHROFF_37_3_;}
	O12964[75] = + _CHROFF_36_3_;
	O12964[76] = + _CHROFF_37_3_;
	O12964[77] = + _CHROFF_41_3_;
	O12964[78] = + _CHROFF_36_3_;
	O12964[79] = + _CHROFF_40_3_;
	{long i; for (i = 80; i < 83; i++) O12964[i] = + _CHROFF_35_3_;}
	O12964[83] = + _CHROFF_42_5_;
	O12964[84] = + _CHROFF_51_5_;
	O12964[85] = + _CHROFF_45_5_;
	O12964[86] = + _CHROFF_58_5_;
	O12964[87] = + _CHROFF_44_5_;
	O12964[88] = + _CHROFF_51_5_;
	{long i; for (i = 89; i < 92; i++) O12964[i] = + _CHROFF_44_5_;}
	{long i; for (i = 92; i < 94; i++) O12964[i] = + _CHROFF_46_5_;}
	O12964[94] = + _CHROFF_50_5_;
	O12964[95] = + _CHROFF_51_5_;
	O12964[96] = + _CHROFF_43_5_;
	O12964[97] = + _CHROFF_46_5_;
	O12964[98] = + _CHROFF_59_5_;
	O12964[99] = + _CHROFF_44_5_;
	O12964[100] = + _CHROFF_51_5_;
	{long i; for (i = 101; i < 104; i++) O12964[i] = + _CHROFF_42_5_;}
	{long i; for (i = 128; i < 130; i++) O12964[i] = + _CHROFF_21_3_;}
	{long i; for (i = 130; i < 132; i++) O12964[i] = + _CHROFF_29_5_;}
	O12964[133] = + _CHROFF_36_3_;
	O12964[136] = + _CHROFF_36_3_;
	O12964[138] = + _CHROFF_48_5_;
	O12964[141] = + _CHROFF_48_5_;
}

long O12993[141];
void O12993_init () {
	O12993[0] = + _CHROFF_8_4_;
	O12993[30] = + _CHROFF_42_6_;
	O12993[32] = + _CHROFF_46_6_;
	O12993[36] = + _CHROFF_47_6_;
	O12993[37] = + _CHROFF_49_6_;
	O12993[38] = + _CHROFF_47_6_;
	{long i; for (i = 42; i < 45; i++) O12993[i] = + _CHROFF_49_6_;}
	O12993[53] = + _CHROFF_49_6_;
	O12993[54] = + _CHROFF_51_6_;
	{long i; for (i = 55; i < 57; i++) O12993[i] = + _CHROFF_49_6_;}
	{long i; for (i = 57; i < 59; i++) O12993[i] = + _CHROFF_59_8_;}
	O12993[59] = + _CHROFF_65_8_;
	O12993[60] = + _CHROFF_68_8_;
	O12993[82] = + _CHROFF_42_6_;
	O12993[83] = + _CHROFF_51_6_;
	O12993[84] = + _CHROFF_45_6_;
	O12993[85] = + _CHROFF_58_6_;
	O12993[86] = + _CHROFF_44_6_;
	O12993[87] = + _CHROFF_51_6_;
	{long i; for (i = 88; i < 91; i++) O12993[i] = + _CHROFF_44_6_;}
	{long i; for (i = 91; i < 93; i++) O12993[i] = + _CHROFF_46_6_;}
	O12993[93] = + _CHROFF_50_6_;
	O12993[94] = + _CHROFF_51_6_;
	O12993[95] = + _CHROFF_43_6_;
	O12993[96] = + _CHROFF_46_6_;
	O12993[97] = + _CHROFF_59_6_;
	O12993[98] = + _CHROFF_44_6_;
	O12993[99] = + _CHROFF_51_6_;
	{long i; for (i = 100; i < 103; i++) O12993[i] = + _CHROFF_42_6_;}
	{long i; for (i = 129; i < 131; i++) O12993[i] = + _CHROFF_29_6_;}
	O12993[137] = + _CHROFF_48_6_;
	O12993[140] = + _CHROFF_48_6_;
}

long O12994[141];
void O12994_init () {
	O12994[0] = + _I16OFF_8_6_4_;
	O12994[30] = + _I16OFF_42_12_4_;
	O12994[32] = + _I16OFF_46_12_4_;
	O12994[36] = + _I16OFF_47_12_4_;
	O12994[37] = + _I16OFF_49_12_4_;
	O12994[38] = + _I16OFF_47_12_4_;
	{long i; for (i = 42; i < 45; i++) O12994[i] = + _I16OFF_49_13_4_;}
	O12994[53] = + _I16OFF_49_13_4_;
	O12994[54] = + _I16OFF_51_13_4_;
	{long i; for (i = 55; i < 57; i++) O12994[i] = + _I16OFF_49_14_4_;}
	O12994[57] = + _I16OFF_59_21_4_;
	O12994[58] = + _I16OFF_59_23_4_;
	O12994[59] = + _I16OFF_65_25_4_;
	O12994[60] = + _I16OFF_68_26_4_;
	O12994[82] = + _I16OFF_42_13_4_;
	O12994[83] = + _I16OFF_51_13_4_;
	O12994[84] = + _I16OFF_45_16_4_;
	O12994[85] = + _I16OFF_58_14_4_;
	O12994[86] = + _I16OFF_44_13_4_;
	O12994[87] = + _I16OFF_51_15_4_;
	O12994[88] = + _I16OFF_44_13_4_;
	{long i; for (i = 89; i < 91; i++) O12994[i] = + _I16OFF_44_14_4_;}
	{long i; for (i = 91; i < 93; i++) O12994[i] = + _I16OFF_46_14_4_;}
	O12994[93] = + _I16OFF_50_13_4_;
	O12994[94] = + _I16OFF_51_14_4_;
	O12994[95] = + _I16OFF_43_13_4_;
	O12994[96] = + _I16OFF_46_14_4_;
	O12994[97] = + _I16OFF_59_16_4_;
	O12994[98] = + _I16OFF_44_15_4_;
	O12994[99] = + _I16OFF_51_18_4_;
	{long i; for (i = 100; i < 103; i++) O12994[i] = + _I16OFF_42_13_4_;}
	{long i; for (i = 129; i < 131; i++) O12994[i] = + _I16OFF_29_14_4_;}
	O12994[137] = + _I16OFF_48_19_4_;
	O12994[140] = + _I16OFF_48_18_4_;
}

long O12995[141];
void O12995_init () {
	O12995[0] = + _I16OFF_8_6_5_;
	O12995[30] = + _I16OFF_42_12_5_;
	O12995[32] = + _I16OFF_46_12_5_;
	O12995[36] = + _I16OFF_47_12_5_;
	O12995[37] = + _I16OFF_49_12_5_;
	O12995[38] = + _I16OFF_47_12_5_;
	{long i; for (i = 42; i < 45; i++) O12995[i] = + _I16OFF_49_13_5_;}
	O12995[53] = + _I16OFF_49_13_5_;
	O12995[54] = + _I16OFF_51_13_5_;
	{long i; for (i = 55; i < 57; i++) O12995[i] = + _I16OFF_49_14_5_;}
	O12995[57] = + _I16OFF_59_21_5_;
	O12995[58] = + _I16OFF_59_23_5_;
	O12995[59] = + _I16OFF_65_25_5_;
	O12995[60] = + _I16OFF_68_26_5_;
	O12995[82] = + _I16OFF_42_13_5_;
	O12995[83] = + _I16OFF_51_13_5_;
	O12995[84] = + _I16OFF_45_16_5_;
	O12995[85] = + _I16OFF_58_14_5_;
	O12995[86] = + _I16OFF_44_13_5_;
	O12995[87] = + _I16OFF_51_15_5_;
	O12995[88] = + _I16OFF_44_13_5_;
	{long i; for (i = 89; i < 91; i++) O12995[i] = + _I16OFF_44_14_5_;}
	{long i; for (i = 91; i < 93; i++) O12995[i] = + _I16OFF_46_14_5_;}
	O12995[93] = + _I16OFF_50_13_5_;
	O12995[94] = + _I16OFF_51_14_5_;
	O12995[95] = + _I16OFF_43_13_5_;
	O12995[96] = + _I16OFF_46_14_5_;
	O12995[97] = + _I16OFF_59_16_5_;
	O12995[98] = + _I16OFF_44_15_5_;
	O12995[99] = + _I16OFF_51_18_5_;
	{long i; for (i = 100; i < 103; i++) O12995[i] = + _I16OFF_42_13_5_;}
	{long i; for (i = 129; i < 131; i++) O12995[i] = + _I16OFF_29_14_5_;}
	O12995[137] = + _I16OFF_48_19_5_;
	O12995[140] = + _I16OFF_48_18_5_;
}

long O13000[141];
void O13000_init () {
	O13000[0] =  + _REFACS_7_;
	O13000[30] =  + _REFACS_32_;
	O13000[32] =  + _REFACS_33_;
	O13000[36] =  + _REFACS_34_;
	O13000[37] =  + _REFACS_35_;
	O13000[38] =  + _REFACS_34_;
	{long i; for (i = 42; i < 45; i++) O13000[i] =  + _REFACS_35_;}
	{long i; for (i = 53; i < 57; i++) O13000[i] =  + _REFACS_34_;}
	{long i; for (i = 57; i < 59; i++) O13000[i] =  + _REFACS_39_;}
	{long i; for (i = 59; i < 61; i++) O13000[i] =  + _REFACS_42_;}
	O13000[82] =  + _REFACS_32_;
	O13000[83] =  + _REFACS_35_;
	O13000[84] =  + _REFACS_34_;
	O13000[85] =  + _REFACS_37_;
	O13000[86] =  + _REFACS_32_;
	O13000[87] =  + _REFACS_38_;
	{long i; for (i = 88; i < 93; i++) O13000[i] =  + _REFACS_33_;}
	{long i; for (i = 93; i < 95; i++) O13000[i] =  + _REFACS_35_;}
	O13000[95] =  + _REFACS_33_;
	O13000[96] =  + _REFACS_34_;
	O13000[97] =  + _REFACS_39_;
	O13000[98] =  + _REFACS_33_;
	O13000[99] =  + _REFACS_36_;
	{long i; for (i = 100; i < 103; i++) O13000[i] =  + _REFACS_32_;}
	{long i; for (i = 129; i < 131; i++) O13000[i] =  + _REFACS_19_;}
	O13000[137] =  + _REFACS_33_;
	O13000[140] =  + _REFACS_33_;
}

long O13019[138];
void O13019_init () {
	{long i; for (i = 0; i < 2; i++) O13019[i] = + _CHROFF_1_0_;}
	O13019[26] = + _CHROFF_35_4_;
	O13019[27] = + _CHROFF_42_7_;
	O13019[28] = + _CHROFF_37_4_;
	O13019[29] = + _CHROFF_46_7_;
	O13019[30] = + _CHROFF_37_4_;
	O13019[31] = + _CHROFF_38_4_;
	O13019[32] = + _CHROFF_37_4_;
	O13019[33] = + _CHROFF_47_7_;
	O13019[34] = + _CHROFF_49_7_;
	O13019[35] = + _CHROFF_47_7_;
	{long i; for (i = 36; i < 39; i++) O13019[i] = + _CHROFF_39_4_;}
	{long i; for (i = 39; i < 42; i++) O13019[i] = + _CHROFF_49_7_;}
	{long i; for (i = 42; i < 46; i++) O13019[i] = + _CHROFF_39_4_;}
	{long i; for (i = 46; i < 48; i++) O13019[i] = + _CHROFF_47_4_;}
	O13019[48] = + _CHROFF_50_4_;
	O13019[49] = + _CHROFF_53_4_;
	O13019[50] = + _CHROFF_49_7_;
	O13019[51] = + _CHROFF_51_7_;
	{long i; for (i = 52; i < 54; i++) O13019[i] = + _CHROFF_49_7_;}
	{long i; for (i = 54; i < 56; i++) O13019[i] = + _CHROFF_59_9_;}
	O13019[56] = + _CHROFF_65_9_;
	O13019[57] = + _CHROFF_68_9_;
	O13019[58] = + _CHROFF_35_4_;
	{long i; for (i = 59; i < 61; i++) O13019[i] = + _CHROFF_37_4_;}
	O13019[61] = + _CHROFF_43_4_;
	O13019[62] = + _CHROFF_35_4_;
	O13019[63] = + _CHROFF_40_4_;
	{long i; for (i = 64; i < 67; i++) O13019[i] = + _CHROFF_37_4_;}
	{long i; for (i = 67; i < 69; i++) O13019[i] = + _CHROFF_36_4_;}
	{long i; for (i = 69; i < 71; i++) O13019[i] = + _CHROFF_37_4_;}
	O13019[71] = + _CHROFF_36_4_;
	O13019[72] = + _CHROFF_37_4_;
	O13019[73] = + _CHROFF_41_4_;
	O13019[74] = + _CHROFF_36_4_;
	O13019[75] = + _CHROFF_40_4_;
	{long i; for (i = 76; i < 79; i++) O13019[i] = + _CHROFF_35_4_;}
	O13019[79] = + _CHROFF_42_7_;
	O13019[80] = + _CHROFF_51_7_;
	O13019[81] = + _CHROFF_45_7_;
	O13019[82] = + _CHROFF_58_7_;
	O13019[83] = + _CHROFF_44_7_;
	O13019[84] = + _CHROFF_51_7_;
	{long i; for (i = 85; i < 88; i++) O13019[i] = + _CHROFF_44_7_;}
	{long i; for (i = 88; i < 90; i++) O13019[i] = + _CHROFF_46_7_;}
	O13019[90] = + _CHROFF_50_7_;
	O13019[91] = + _CHROFF_51_7_;
	O13019[92] = + _CHROFF_43_7_;
	O13019[93] = + _CHROFF_46_7_;
	O13019[94] = + _CHROFF_59_7_;
	O13019[95] = + _CHROFF_44_7_;
	O13019[96] = + _CHROFF_51_7_;
	{long i; for (i = 97; i < 100; i++) O13019[i] = + _CHROFF_42_7_;}
	{long i; for (i = 112; i < 116; i++) O13019[i] = + _CHROFF_17_1_;}
	O13019[116] = + _CHROFF_18_1_;
	{long i; for (i = 117; i < 120; i++) O13019[i] = + _CHROFF_23_3_;}
	O13019[120] = + _CHROFF_24_3_;
	O13019[121] = + _CHROFF_26_3_;
	{long i; for (i = 124; i < 126; i++) O13019[i] = + _CHROFF_21_4_;}
	{long i; for (i = 126; i < 128; i++) O13019[i] = + _CHROFF_29_7_;}
	O13019[129] = + _CHROFF_36_4_;
	O13019[132] = + _CHROFF_36_4_;
	O13019[134] = + _CHROFF_48_7_;
	O13019[137] = + _CHROFF_48_7_;
}


#ifdef __cplusplus
}
#endif
