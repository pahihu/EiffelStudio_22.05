#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O4793[1407];
void O4793_init () {
	O4793[0] =  + _REFACS_12_;
	{long i; for (i = 1295; i < 1297; i++) O4793[i] =  + _REFACS_21_;}
	{long i; for (i = 1297; i < 1300; i++) O4793[i] =  + _REFACS_22_;}
	O4793[1300] =  + _REFACS_23_;
	{long i; for (i = 1301; i < 1303; i++) O4793[i] =  + _REFACS_22_;}
	O4793[1303] =  + _REFACS_23_;
	O4793[1304] =  + _REFACS_22_;
	{long i; for (i = 1305; i < 1315; i++) O4793[i] =  + _REFACS_23_;}
	{long i; for (i = 1315; i < 1317; i++) O4793[i] =  + _REFACS_27_;}
	{long i; for (i = 1317; i < 1319; i++) O4793[i] =  + _REFACS_30_;}
	{long i; for (i = 1319; i < 1323; i++) O4793[i] =  + _REFACS_23_;}
	{long i; for (i = 1323; i < 1325; i++) O4793[i] =  + _REFACS_27_;}
	{long i; for (i = 1325; i < 1327; i++) O4793[i] =  + _REFACS_30_;}
	O4793[1327] =  + _REFACS_21_;
	O4793[1328] =  + _REFACS_23_;
	O4793[1329] =  + _REFACS_22_;
	O4793[1330] =  + _REFACS_25_;
	O4793[1331] =  + _REFACS_21_;
	O4793[1332] =  + _REFACS_26_;
	{long i; for (i = 1333; i < 1338; i++) O4793[i] =  + _REFACS_22_;}
	{long i; for (i = 1338; i < 1340; i++) O4793[i] =  + _REFACS_23_;}
	O4793[1340] =  + _REFACS_22_;
	O4793[1341] =  + _REFACS_23_;
	O4793[1342] =  + _REFACS_27_;
	O4793[1343] =  + _REFACS_22_;
	O4793[1344] =  + _REFACS_25_;
	{long i; for (i = 1345; i < 1349; i++) O4793[i] =  + _REFACS_21_;}
	O4793[1349] =  + _REFACS_23_;
	O4793[1350] =  + _REFACS_22_;
	O4793[1351] =  + _REFACS_25_;
	O4793[1352] =  + _REFACS_21_;
	O4793[1353] =  + _REFACS_26_;
	{long i; for (i = 1354; i < 1359; i++) O4793[i] =  + _REFACS_22_;}
	{long i; for (i = 1359; i < 1361; i++) O4793[i] =  + _REFACS_23_;}
	O4793[1361] =  + _REFACS_22_;
	O4793[1362] =  + _REFACS_23_;
	O4793[1363] =  + _REFACS_27_;
	O4793[1364] =  + _REFACS_22_;
	O4793[1365] =  + _REFACS_25_;
	{long i; for (i = 1366; i < 1369; i++) O4793[i] =  + _REFACS_21_;}
	O4793[1398] =  + _REFACS_22_;
	O4793[1401] =  + _REFACS_22_;
	O4793[1403] =  + _REFACS_22_;
	O4793[1406] =  + _REFACS_22_;
}

long O4796[1407];
void O4796_init () {
	O4796[0] =  + _REFACS_13_;
	{long i; for (i = 1295; i < 1297; i++) O4796[i] =  + _REFACS_22_;}
	{long i; for (i = 1297; i < 1300; i++) O4796[i] =  + _REFACS_23_;}
	O4796[1300] =  + _REFACS_24_;
	{long i; for (i = 1301; i < 1303; i++) O4796[i] =  + _REFACS_23_;}
	O4796[1303] =  + _REFACS_24_;
	O4796[1304] =  + _REFACS_23_;
	{long i; for (i = 1305; i < 1315; i++) O4796[i] =  + _REFACS_24_;}
	{long i; for (i = 1315; i < 1317; i++) O4796[i] =  + _REFACS_28_;}
	{long i; for (i = 1317; i < 1319; i++) O4796[i] =  + _REFACS_31_;}
	{long i; for (i = 1319; i < 1323; i++) O4796[i] =  + _REFACS_24_;}
	{long i; for (i = 1323; i < 1325; i++) O4796[i] =  + _REFACS_28_;}
	{long i; for (i = 1325; i < 1327; i++) O4796[i] =  + _REFACS_31_;}
	O4796[1327] =  + _REFACS_22_;
	O4796[1328] =  + _REFACS_24_;
	O4796[1329] =  + _REFACS_23_;
	O4796[1330] =  + _REFACS_26_;
	O4796[1331] =  + _REFACS_22_;
	O4796[1332] =  + _REFACS_27_;
	{long i; for (i = 1333; i < 1338; i++) O4796[i] =  + _REFACS_23_;}
	{long i; for (i = 1338; i < 1340; i++) O4796[i] =  + _REFACS_24_;}
	O4796[1340] =  + _REFACS_23_;
	O4796[1341] =  + _REFACS_24_;
	O4796[1342] =  + _REFACS_28_;
	O4796[1343] =  + _REFACS_23_;
	O4796[1344] =  + _REFACS_26_;
	{long i; for (i = 1345; i < 1349; i++) O4796[i] =  + _REFACS_22_;}
	O4796[1349] =  + _REFACS_24_;
	O4796[1350] =  + _REFACS_23_;
	O4796[1351] =  + _REFACS_26_;
	O4796[1352] =  + _REFACS_22_;
	O4796[1353] =  + _REFACS_27_;
	{long i; for (i = 1354; i < 1359; i++) O4796[i] =  + _REFACS_23_;}
	{long i; for (i = 1359; i < 1361; i++) O4796[i] =  + _REFACS_24_;}
	O4796[1361] =  + _REFACS_23_;
	O4796[1362] =  + _REFACS_24_;
	O4796[1363] =  + _REFACS_28_;
	O4796[1364] =  + _REFACS_23_;
	O4796[1365] =  + _REFACS_26_;
	{long i; for (i = 1366; i < 1369; i++) O4796[i] =  + _REFACS_22_;}
	O4796[1398] =  + _REFACS_23_;
	O4796[1401] =  + _REFACS_23_;
	O4796[1403] =  + _REFACS_23_;
	O4796[1406] =  + _REFACS_23_;
}

long O4986[3];
void O4986_init () {
	O4986[0] = + _LNGOFF_1_0_0_0_;
	O4986[1] = + _LNGOFF_2_0_0_0_;
	O4986[2] = + _LNGOFF_1_0_0_0_;
}

long O4990[3];
void O4990_init () {
	O4990[0] = + _LNGOFF_1_0_0_1_;
	O4990[1] = + _LNGOFF_2_0_0_1_;
	O4990[2] = + _LNGOFF_1_0_0_1_;
}

long O5078[4];
void O5078_init () {
	O5078[0] = + _CHROFF_2_0_;
	O5078[1] = + _CHROFF_2_1_;
	{long i; for (i = 2; i < 4; i++) O5078[i] = + _CHROFF_2_0_;}
}

long O5079[4];
void O5079_init () {
	O5079[0] = + _CHROFF_2_1_;
	O5079[1] = + _CHROFF_2_2_;
	{long i; for (i = 2; i < 4; i++) O5079[i] = + _CHROFF_2_1_;}
}

long O5147[246];
void O5147_init () {
	O5147[0] = 0;
	O5147[1] = + _LNGOFF_0_0_0_0_;
	O5147[2] = + _I64OFF_0_0_0_0_0_0_0_;
	O5147[3] = + _CHROFF_0_0_;
	O5147[4] = + _LNGOFF_0_0_0_0_;
	O5147[5] = 0;
	O5147[6] = + _LNGOFF_1_0_0_0_;
	O5147[7] = + _CHROFF_1_0_;
	O5147[8] = 0;
	{long i; for (i = 244; i < 246; i++) O5147[i] = 0;}
}

long O5151[4];
void O5151_init () {
	O5151[0] =  + _REFACS_1_;
	{long i; for (i = 1; i < 3; i++) O5151[i] = 0;}
	O5151[3] =  + _REFACS_1_;
}

long O6382[970];
void O6382_init () {
	{long i; for (i = 0; i < 11; i++) O6382[i] = 0;}
	{long i; for (i = 960; i < 970; i++) O6382[i] =  + _REFACS_1_;}
}

static EIF_TYPE_INDEX Y6671_pgtype0[] = {1407,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype1[] = {1408,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype2[] = {1409,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype3[] = {1410,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype4[] = {1411,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype5[] = {1412,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype6[] = {1413,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype7[] = {1414,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype8[] = {1415,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype9[] = {1416,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype10[] = {1417,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype11[] = {1418,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype12[] = {1411,1504,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype13[] = {1411,1504,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype14[] = {1407,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype15[] = {1408,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype16[] = {1409,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype17[] = {1410,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype18[] = {1411,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype19[] = {1412,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype20[] = {1413,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype21[] = {1414,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype22[] = {1415,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype23[] = {1416,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype24[] = {1417,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype25[] = {1418,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype26[] = {1407,1750,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype27[] = {1407,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype28[] = {1410,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype29[] = {1412,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype30[] = {1407,907,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype31[] = {1407,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype32[] = {1410,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype33[] = {1407,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype34[] = {1410,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype35[] = {1407,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype36[] = {1410,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype37[] = {1407,1301,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype38[] = {1407,1230,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype39[] = {1407,1230,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype40[] = {1407,1230,0xFFF9,1,1186,0,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype41[] = {1407,1230,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype42[] = {1407,1230,0xFFF9,1,1186,1486,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype43[] = {1407,1230,0xFFF9,1,1186,1401,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype44[] = {1407,1230,0xFFF9,1,1186,1346,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype45[] = {1407,1230,0xFFF9,1,1186,1154,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype46[] = {1407,1230,0xFFF9,1,1186,1265,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype47[] = {1407,1230,0xFFF9,1,1186,1486,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype48[] = {1407,1230,0xFFF9,1,1186,1394,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype49[] = {1407,1230,0xFFF9,1,1186,1393,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype50[] = {1407,1230,0xFFF9,1,1186,1241,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype51[] = {1407,1230,0xFFF9,1,1186,1486,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype52[] = {1407,1230,0xFFF9,1,1186,1714,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype53[] = {1407,1230,0xFFF9,5,1186,1498,1486,1486,1486,1486,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype54[] = {1407,1230,0xFFF9,7,1186,1486,1486,1510,1510,1510,1486,1486,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype55[] = {1407,1230,0xFFF9,2,1186,1486,1486,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype56[] = {1407,1230,0xFFF9,4,1186,1486,1486,1486,1486,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype57[] = {1407,1230,0xFFF9,3,1186,1486,1486,1154,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype58[] = {1407,1230,0xFFF9,8,1186,1486,1486,1486,1510,1510,1510,1486,1486,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype59[] = {1407,1230,0xFFF9,0,1186,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype60[] = {1407,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype61[] = {1408,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype62[] = {1409,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype63[] = {1410,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype64[] = {1411,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype65[] = {1412,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype66[] = {1413,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype67[] = {1414,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype68[] = {1415,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype69[] = {1416,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype70[] = {1417,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype71[] = {1418,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype72[] = {1407,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype73[] = {1412,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype74[] = {1414,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype75[] = {1410,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype76[] = {1408,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype77[] = {1411,1504,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype78[] = {1415,1189,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype79[] = {1414,1192,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype80[] = {1414,1192,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype81[] = {1414,1192,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype82[] = {1407,1241,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype83[] = {1414,1192,0xFFFF};
static EIF_TYPE_INDEX Y6671_pgtype84[] = {1414,1192,0xFFFF};
EIF_TYPE_INDEX *Y6671_gen_type [1322];
EIF_TYPE_INDEX Y6671 [1322];
void Y6671_init (void)
{
	egc_routines_types [6671] = Y6671;
	egc_routines_gen_types [6671] = Y6671_gen_type;
	egc_routines_offset [6671] = 477;
	Y6671_gen_type [0] = Y6671_pgtype0;
	Y6671_gen_type [1] = Y6671_pgtype1;
	Y6671_gen_type [2] = Y6671_pgtype2;
	Y6671_gen_type [3] = Y6671_pgtype3;
	Y6671_gen_type [4] = Y6671_pgtype4;
	Y6671_gen_type [5] = Y6671_pgtype5;
	Y6671_gen_type [6] = Y6671_pgtype6;
	Y6671_gen_type [7] = Y6671_pgtype7;
	Y6671_gen_type [8] = Y6671_pgtype8;
	Y6671_gen_type [9] = Y6671_pgtype9;
	Y6671_gen_type [10] = Y6671_pgtype10;
	Y6671_gen_type [11] = Y6671_pgtype11;
	Y6671_gen_type [37] = Y6671_pgtype12;
	Y6671_gen_type [38] = Y6671_pgtype13;
	Y6671_gen_type [414] = Y6671_pgtype14;
	Y6671_gen_type [415] = Y6671_pgtype15;
	Y6671_gen_type [416] = Y6671_pgtype16;
	Y6671_gen_type [417] = Y6671_pgtype17;
	Y6671_gen_type [418] = Y6671_pgtype18;
	Y6671_gen_type [419] = Y6671_pgtype19;
	Y6671_gen_type [420] = Y6671_pgtype20;
	Y6671_gen_type [421] = Y6671_pgtype21;
	Y6671_gen_type [422] = Y6671_pgtype22;
	Y6671_gen_type [423] = Y6671_pgtype23;
	Y6671_gen_type [424] = Y6671_pgtype24;
	Y6671_gen_type [425] = Y6671_pgtype25;
	Y6671_gen_type [426] = Y6671_pgtype26;
	Y6671_gen_type [427] = Y6671_pgtype27;
	Y6671_gen_type [428] = Y6671_pgtype28;
	Y6671_gen_type [429] = Y6671_pgtype29;
	Y6671_gen_type [430] = Y6671_pgtype30;
	Y6671_gen_type [431] = Y6671_pgtype31;
	Y6671_gen_type [432] = Y6671_pgtype32;
	Y6671_gen_type [433] = Y6671_pgtype33;
	Y6671_gen_type [434] = Y6671_pgtype34;
	Y6671_gen_type [435] = Y6671_pgtype35;
	Y6671_gen_type [436] = Y6671_pgtype36;
	Y6671_gen_type [437] = Y6671_pgtype37;
	Y6671_gen_type [438] = Y6671_pgtype38;
	Y6671_gen_type [439] = Y6671_pgtype39;
	Y6671_gen_type [440] = Y6671_pgtype40;
	Y6671_gen_type [441] = Y6671_pgtype41;
	Y6671_gen_type [442] = Y6671_pgtype42;
	Y6671_gen_type [443] = Y6671_pgtype43;
	Y6671_gen_type [444] = Y6671_pgtype44;
	Y6671_gen_type [445] = Y6671_pgtype45;
	Y6671_gen_type [446] = Y6671_pgtype46;
	Y6671_gen_type [447] = Y6671_pgtype47;
	Y6671_gen_type [448] = Y6671_pgtype48;
	Y6671_gen_type [449] = Y6671_pgtype49;
	Y6671_gen_type [450] = Y6671_pgtype50;
	Y6671_gen_type [451] = Y6671_pgtype51;
	Y6671_gen_type [452] = Y6671_pgtype52;
	Y6671_gen_type [453] = Y6671_pgtype53;
	Y6671_gen_type [454] = Y6671_pgtype54;
	Y6671_gen_type [455] = Y6671_pgtype55;
	Y6671_gen_type [456] = Y6671_pgtype56;
	Y6671_gen_type [457] = Y6671_pgtype57;
	Y6671_gen_type [458] = Y6671_pgtype58;
	Y6671_gen_type [459] = Y6671_pgtype59;
	Y6671_gen_type [460] = Y6671_pgtype60;
	Y6671_gen_type [461] = Y6671_pgtype61;
	Y6671_gen_type [462] = Y6671_pgtype62;
	Y6671_gen_type [463] = Y6671_pgtype63;
	Y6671_gen_type [464] = Y6671_pgtype64;
	Y6671_gen_type [465] = Y6671_pgtype65;
	Y6671_gen_type [466] = Y6671_pgtype66;
	Y6671_gen_type [467] = Y6671_pgtype67;
	Y6671_gen_type [468] = Y6671_pgtype68;
	Y6671_gen_type [469] = Y6671_pgtype69;
	Y6671_gen_type [470] = Y6671_pgtype70;
	Y6671_gen_type [471] = Y6671_pgtype71;
	Y6671_gen_type [472] = Y6671_pgtype72;
	Y6671_gen_type [473] = Y6671_pgtype73;
	Y6671_gen_type [474] = Y6671_pgtype74;
	Y6671_gen_type [475] = Y6671_pgtype75;
	Y6671_gen_type [476] = Y6671_pgtype76;
	Y6671_gen_type [477] = Y6671_pgtype77;
	Y6671_gen_type [764] = Y6671_pgtype78;
	Y6671_gen_type [767] = Y6671_pgtype79;
	Y6671_gen_type [768] = Y6671_pgtype80;
	Y6671_gen_type [769] = Y6671_pgtype81;
	Y6671_gen_type [917] = Y6671_pgtype82;
	Y6671_gen_type [1320] = Y6671_pgtype83;
	Y6671_gen_type [1321] = Y6671_pgtype84;
	Y6671[0] = 1407;
	Y6671[1] = 1408;
	Y6671[2] = 1409;
	Y6671[3] = 1410;
	Y6671[4] = 1411;
	Y6671[5] = 1412;
	Y6671[6] = 1413;
	Y6671[7] = 1414;
	Y6671[8] = 1415;
	Y6671[9] = 1416;
	Y6671[10] = 1417;
	Y6671[11] = 1418;
	{long i; for (i = 37; i < 39; i++) Y6671[i] = 1411;};
	Y6671[414] = 1407;
	Y6671[415] = 1408;
	Y6671[416] = 1409;
	Y6671[417] = 1410;
	Y6671[418] = 1411;
	Y6671[419] = 1412;
	Y6671[420] = 1413;
	Y6671[421] = 1414;
	Y6671[422] = 1415;
	Y6671[423] = 1416;
	Y6671[424] = 1417;
	Y6671[425] = 1418;
	{long i; for (i = 426; i < 428; i++) Y6671[i] = 1407;};
	Y6671[428] = 1410;
	Y6671[429] = 1412;
	{long i; for (i = 430; i < 432; i++) Y6671[i] = 1407;};
	Y6671[432] = 1410;
	Y6671[433] = 1407;
	Y6671[434] = 1410;
	Y6671[435] = 1407;
	Y6671[436] = 1410;
	{long i; for (i = 437; i < 461; i++) Y6671[i] = 1407;};
	Y6671[461] = 1408;
	Y6671[462] = 1409;
	Y6671[463] = 1410;
	Y6671[464] = 1411;
	Y6671[465] = 1412;
	Y6671[466] = 1413;
	Y6671[467] = 1414;
	Y6671[468] = 1415;
	Y6671[469] = 1416;
	Y6671[470] = 1417;
	Y6671[471] = 1418;
	Y6671[472] = 1407;
	Y6671[473] = 1412;
	Y6671[474] = 1414;
	Y6671[475] = 1410;
	Y6671[476] = 1408;
	Y6671[477] = 1411;
	Y6671[764] = 1415;
	{long i; for (i = 767; i < 770; i++) Y6671[i] = 1414;};
	Y6671[917] = 1407;
	{long i; for (i = 1320; i < 1322; i++) Y6671[i] = 1414;};
}

long O7054[1023];
void O7054_init () {
	O7054[0] = + _LNGOFF_0_0_0_0_;
	{long i; for (i = 1; i < 4; i++) O7054[i] = + _LNGOFF_3_2_0_1_;}
	O7054[4] = + _LNGOFF_3_3_0_1_;
	O7054[5] = + _LNGOFF_10_3_0_2_;
	{long i; for (i = 6; i < 9; i++) O7054[i] = + _LNGOFF_0_0_0_0_;}
	O7054[9] = + _LNGOFF_13_16_0_4_;
	O7054[10] = + _LNGOFF_21_18_0_5_;
	O7054[633] = + _LNGOFF_15_11_0_0_;
	O7054[635] = + _LNGOFF_1_0_0_0_;
	O7054[1020] = + _LNGOFF_1_1_0_0_;
	O7054[1022] = + _LNGOFF_49_16_0_2_;
}

long O7326[2];
void O7326_init () {
	O7326[0] = + _CHROFF_12_0_;
	O7326[1] = + _CHROFF_18_0_;
}

long O7327[2];
void O7327_init () {
	O7327[0] = + _CHROFF_12_1_;
	O7327[1] = + _CHROFF_18_1_;
}

long O7328[2];
void O7328_init () {
	O7328[0] = + _CHROFF_12_2_;
	O7328[1] = + _CHROFF_18_2_;
}

long O7329[2];
void O7329_init () {
	O7329[0] = + _CHROFF_12_3_;
	O7329[1] = + _CHROFF_18_3_;
}

long O7330[2];
void O7330_init () {
	O7330[0] = + _CHROFF_12_4_;
	O7330[1] = + _CHROFF_18_4_;
}

long O7331[2];
void O7331_init () {
	O7331[0] = + _CHROFF_12_5_;
	O7331[1] = + _CHROFF_18_5_;
}

long O7332[2];
void O7332_init () {
	O7332[0] = + _CHROFF_12_6_;
	O7332[1] = + _CHROFF_18_6_;
}

long O7333[2];
void O7333_init () {
	O7333[0] = + _CHROFF_12_7_;
	O7333[1] = + _CHROFF_18_7_;
}

long O7334[2];
void O7334_init () {
	O7334[0] = + _CHROFF_12_8_;
	O7334[1] = + _CHROFF_18_8_;
}

long O7349[2];
void O7349_init () {
	O7349[0] = + _CHROFF_12_9_;
	O7349[1] = + _CHROFF_18_9_;
}

long O7350[2];
void O7350_init () {
	O7350[0] = + _CHROFF_12_10_;
	O7350[1] = + _CHROFF_18_10_;
}

long O7351[2];
void O7351_init () {
	O7351[0] = + _CHROFF_12_11_;
	O7351[1] = + _CHROFF_18_11_;
}

long O7352[2];
void O7352_init () {
	O7352[0] = + _CHROFF_12_12_;
	O7352[1] = + _CHROFF_18_12_;
}

long O7353[2];
void O7353_init () {
	O7353[0] = + _CHROFF_12_13_;
	O7353[1] = + _CHROFF_18_13_;
}

long O7354[2];
void O7354_init () {
	O7354[0] = + _CHROFF_12_14_;
	O7354[1] = + _CHROFF_18_14_;
}

long O7355[2];
void O7355_init () {
	O7355[0] = + _CHROFF_12_15_;
	O7355[1] = + _CHROFF_18_15_;
}

long O7356[2];
void O7356_init () {
	O7356[0] = + _CHROFF_12_16_;
	O7356[1] = + _CHROFF_18_16_;
}

long O7357[2];
void O7357_init () {
	O7357[0] = + _CHROFF_12_17_;
	O7357[1] = + _CHROFF_18_17_;
}

static EIF_TYPE_INDEX Y7500_pgtype0[] = {541,1289,0xFFFF};
static EIF_TYPE_INDEX Y7500_pgtype1[] = {891,1289,0xFFFF};
static EIF_TYPE_INDEX Y7500_pgtype2[] = {891,1289,0xFFFF};
EIF_TYPE_INDEX *Y7500_gen_type [734];
EIF_TYPE_INDEX Y7500 [734];
void Y7500_init (void)
{
	egc_routines_types [7500] = Y7500;
	egc_routines_gen_types [7500] = Y7500_gen_type;
	egc_routines_offset [7500] = 555;
	Y7500_gen_type [0] = Y7500_pgtype0;
	Y7500_gen_type [732] = Y7500_pgtype1;
	Y7500_gen_type [733] = Y7500_pgtype2;
	Y7500[0] = 541;
	{long i; for (i = 732; i < 734; i++) Y7500[i] = 891;};
}

long O7528[1233];
void O7528_init () {
	{long i; for (i = 0; i < 12; i++) O7528[i] = + _CHROFF_0_0_;}
	O7528[12] = + _CHROFF_1_0_;
	{long i; for (i = 13; i < 15; i++) O7528[i] = + _CHROFF_4_0_;}
	{long i; for (i = 15; i < 209; i++) O7528[i] = + _CHROFF_0_0_;}
	O7528[209] = + _CHROFF_1_0_;
	{long i; for (i = 210; i < 214; i++) O7528[i] = + _CHROFF_0_0_;}
	O7528[214] = + _CHROFF_1_0_;
	{long i; for (i = 215; i < 227; i++) O7528[i] = + _CHROFF_0_0_;}
	O7528[239] = + _CHROFF_7_0_;
	O7528[240] = + _CHROFF_5_0_;
	O7528[241] = + _CHROFF_6_0_;
	O7528[242] = + _CHROFF_5_0_;
	{long i; for (i = 243; i < 245; i++) O7528[i] = + _CHROFF_4_0_;}
	{long i; for (i = 245; i < 248; i++) O7528[i] = + _CHROFF_5_0_;}
	O7528[248] = + _CHROFF_7_0_;
	{long i; for (i = 249; i < 253; i++) O7528[i] = + _CHROFF_5_0_;}
	O7528[253] = + _CHROFF_9_0_;
	{long i; for (i = 254; i < 267; i++) O7528[i] = + _CHROFF_0_0_;}
	O7528[267] = + _CHROFF_1_0_;
	{long i; for (i = 268; i < 316; i++) O7528[i] = + _CHROFF_0_0_;}
	{long i; for (i = 316; i < 324; i++) O7528[i] = + _CHROFF_2_0_;}
	O7528[324] = + _CHROFF_4_0_;
	{long i; for (i = 325; i < 341; i++) O7528[i] = + _CHROFF_1_0_;}
	O7528[341] = + _CHROFF_5_0_;
	{long i; for (i = 342; i < 344; i++) O7528[i] = + _CHROFF_1_0_;}
	{long i; for (i = 344; i < 346; i++) O7528[i] = + _CHROFF_3_0_;}
	{long i; for (i = 346; i < 349; i++) O7528[i] = + _CHROFF_5_0_;}
	{long i; for (i = 349; i < 351; i++) O7528[i] = + _CHROFF_9_0_;}
	O7528[351] = + _CHROFF_10_0_;
	{long i; for (i = 352; i < 371; i++) O7528[i] = + _CHROFF_9_0_;}
	{long i; for (i = 371; i < 388; i++) O7528[i] = + _CHROFF_1_0_;}
	O7528[388] = + _CHROFF_2_0_;
	O7528[403] = + _CHROFF_0_0_;
	O7528[408] = + _CHROFF_2_0_;
	O7528[410] = + _CHROFF_0_0_;
	O7528[579] = + _CHROFF_3_2_;
	O7528[580] = + _CHROFF_4_2_;
	O7528[581] = + _CHROFF_5_2_;
	O7528[675] = + _CHROFF_1_0_;
	{long i; for (i = 678; i < 681; i++) O7528[i] = + _CHROFF_1_0_;}
	{long i; for (i = 774; i < 779; i++) O7528[i] = + _CHROFF_3_0_;}
	{long i; for (i = 781; i < 795; i++) O7528[i] = + _CHROFF_6_0_;}
	O7528[795] = + _CHROFF_13_1_;
	O7528[796] = + _CHROFF_6_0_;
	O7528[797] = + _CHROFF_7_0_;
	{long i; for (i = 798; i < 802; i++) O7528[i] = + _CHROFF_14_0_;}
	O7528[803] = + _CHROFF_5_0_;
	{long i; for (i = 805; i < 807; i++) O7528[i] = + _CHROFF_5_0_;}
	O7528[808] = + _CHROFF_5_0_;
	{long i; for (i = 815; i < 817; i++) O7528[i] = + _CHROFF_5_0_;}
	O7528[819] = + _CHROFF_5_0_;
	O7528[828] = + _CHROFF_7_0_;
	{long i; for (i = 829; i < 831; i++) O7528[i] = + _CHROFF_6_0_;}
	O7528[839] = + _CHROFF_6_0_;
	O7528[1149] = + _CHROFF_5_2_;
	{long i; for (i = 1189; i < 1192; i++) O7528[i] = + _CHROFF_5_2_;}
	O7528[1193] = + _CHROFF_7_2_;
	{long i; for (i = 1194; i < 1198; i++) O7528[i] = + _CHROFF_6_2_;}
	{long i; for (i = 1231; i < 1233; i++) O7528[i] = + _CHROFF_1_0_;}
}

static EIF_TYPE_INDEX Y7596_pgtype0[] = {579,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7596_pgtype1[] = {580,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y7596_gen_type [2];
EIF_TYPE_INDEX Y7596 [2];
void Y7596_init (void)
{
	egc_routines_types [7596] = Y7596;
	egc_routines_gen_types [7596] = Y7596_gen_type;
	egc_routines_offset [7596] = 579;
	Y7596_gen_type [0] = Y7596_pgtype0;
	Y7596_gen_type [1] = Y7596_pgtype1;
	Y7596[0] = 579;
	Y7596[1] = 580;
}

EIF_TYPE_INDEX *Y7738_gen_type [1];
EIF_TYPE_INDEX Y7738 [1];
void Y7738_init (void)
{
	egc_routines_types [7738] = Y7738;
	egc_routines_gen_types [7738] = Y7738_gen_type;
	egc_routines_offset [7738] = 780;
	Y7738[0] = 1486;
}

long O7748[15];
void O7748_init () {
	O7748[0] = 0;
	O7748[1] = + _LNGOFF_5_3_0_0_;
	O7748[2] = 0;
	O7748[3] = + _LNGOFF_5_3_0_0_;
	O7748[4] = + _LNGOFF_4_3_0_0_;
	O7748[5] = + _LNGOFF_4_3_0_1_;
	O7748[6] = + _PTROFF_5_3_0_7_0_0_;
	O7748[7] = + _CHROFF_5_3_;
	O7748[8] = + _CHROFF_5_1_;
	O7748[9] = 0;
	{long i; for (i = 10; i < 12; i++) O7748[i] = + _LNGOFF_5_4_0_0_;}
	O7748[12] = + _CHROFF_5_4_;
	O7748[13] = + _CHROFF_5_1_;
	O7748[14] = 0;
}

long O7757[15];
void O7757_init () {
	O7757[0] = + _LNGOFF_7_3_0_0_;
	O7757[1] = + _LNGOFF_5_3_0_2_;
	O7757[2] = + _LNGOFF_6_3_0_0_;
	O7757[3] = + _LNGOFF_5_3_0_1_;
	O7757[4] = + _LNGOFF_4_3_0_1_;
	O7757[5] = + _LNGOFF_4_3_0_2_;
	O7757[6] = + _LNGOFF_5_3_0_0_;
	{long i; for (i = 7; i < 9; i++) O7757[i] = + _LNGOFF_5_5_0_0_;}
	O7757[9] = + _LNGOFF_7_4_0_0_;
	O7757[10] = + _LNGOFF_5_4_0_2_;
	O7757[11] = + _LNGOFF_5_4_0_1_;
	{long i; for (i = 12; i < 14; i++) O7757[i] = + _LNGOFF_5_6_0_0_;}
	O7757[14] = + _LNGOFF_9_3_0_0_;
}

long O7784[15];
void O7784_init () {
	O7784[0] =  + _REFACS_1_;
	O7784[1] = 0;
	O7784[2] =  + _REFACS_1_;
	{long i; for (i = 3; i < 9; i++) O7784[i] = 0;}
	O7784[9] =  + _REFACS_1_;
	{long i; for (i = 10; i < 14; i++) O7784[i] = 0;}
	O7784[14] =  + _REFACS_1_;
}

static EIF_TYPE_INDEX Y7784_pgtype0[] = {1407,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7784_pgtype1[] = {1408,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7784_pgtype2[] = {1407,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7784_pgtype3[] = {1410,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7784_pgtype4[] = {1410,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7784_pgtype5[] = {1410,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7784_pgtype6[] = {1413,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7784_pgtype7[] = {1411,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7784_pgtype8[] = {1412,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7784_pgtype9[] = {1407,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7784_pgtype10[] = {1408,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7784_pgtype11[] = {1410,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7784_pgtype12[] = {1411,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7784_pgtype13[] = {1412,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7784_pgtype14[] = {1407,0,0xFFFF};
EIF_TYPE_INDEX *Y7784_gen_type [15];
EIF_TYPE_INDEX Y7784 [15];
void Y7784_init (void)
{
	egc_routines_types [7784] = Y7784;
	egc_routines_gen_types [7784] = Y7784_gen_type;
	egc_routines_offset [7784] = 805;
	Y7784_gen_type [0] = Y7784_pgtype0;
	Y7784_gen_type [1] = Y7784_pgtype1;
	Y7784_gen_type [2] = Y7784_pgtype2;
	Y7784_gen_type [3] = Y7784_pgtype3;
	Y7784_gen_type [4] = Y7784_pgtype4;
	Y7784_gen_type [5] = Y7784_pgtype5;
	Y7784_gen_type [6] = Y7784_pgtype6;
	Y7784_gen_type [7] = Y7784_pgtype7;
	Y7784_gen_type [8] = Y7784_pgtype8;
	Y7784_gen_type [9] = Y7784_pgtype9;
	Y7784_gen_type [10] = Y7784_pgtype10;
	Y7784_gen_type [11] = Y7784_pgtype11;
	Y7784_gen_type [12] = Y7784_pgtype12;
	Y7784_gen_type [13] = Y7784_pgtype13;
	Y7784_gen_type [14] = Y7784_pgtype14;
	Y7784[0] = 1407;
	Y7784[1] = 1408;
	Y7784[2] = 1407;
	{long i; for (i = 3; i < 6; i++) Y7784[i] = 1410;};
	Y7784[6] = 1413;
	Y7784[7] = 1411;
	Y7784[8] = 1412;
	Y7784[9] = 1407;
	Y7784[10] = 1408;
	Y7784[11] = 1410;
	Y7784[12] = 1411;
	Y7784[13] = 1412;
	Y7784[14] = 1407;
}

long O7785[15];
void O7785_init () {
	O7785[0] =  + _REFACS_2_;
	O7785[1] =  + _REFACS_1_;
	O7785[2] =  + _REFACS_2_;
	{long i; for (i = 3; i < 9; i++) O7785[i] =  + _REFACS_1_;}
	O7785[9] =  + _REFACS_2_;
	{long i; for (i = 10; i < 14; i++) O7785[i] =  + _REFACS_1_;}
	O7785[14] =  + _REFACS_2_;
}

static EIF_TYPE_INDEX Y7785_pgtype0[] = {1407,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7785_pgtype1[] = {1407,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7785_pgtype2[] = {1410,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7785_pgtype3[] = {1407,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7785_pgtype4[] = {1410,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7785_pgtype5[] = {1408,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7785_pgtype6[] = {1407,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7785_pgtype7[] = {1407,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7785_pgtype8[] = {1407,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7785_pgtype9[] = {1407,1236,0xFFFF};
static EIF_TYPE_INDEX Y7785_pgtype10[] = {1407,1236,0xFFFF};
static EIF_TYPE_INDEX Y7785_pgtype11[] = {1407,1236,0xFFFF};
static EIF_TYPE_INDEX Y7785_pgtype12[] = {1407,1236,0xFFFF};
static EIF_TYPE_INDEX Y7785_pgtype13[] = {1407,1236,0xFFFF};
static EIF_TYPE_INDEX Y7785_pgtype14[] = {1407,1244,0xFFFF};
EIF_TYPE_INDEX *Y7785_gen_type [15];
EIF_TYPE_INDEX Y7785 [15];
void Y7785_init (void)
{
	egc_routines_types [7785] = Y7785;
	egc_routines_gen_types [7785] = Y7785_gen_type;
	egc_routines_offset [7785] = 805;
	Y7785_gen_type [0] = Y7785_pgtype0;
	Y7785_gen_type [1] = Y7785_pgtype1;
	Y7785_gen_type [2] = Y7785_pgtype2;
	Y7785_gen_type [3] = Y7785_pgtype3;
	Y7785_gen_type [4] = Y7785_pgtype4;
	Y7785_gen_type [5] = Y7785_pgtype5;
	Y7785_gen_type [6] = Y7785_pgtype6;
	Y7785_gen_type [7] = Y7785_pgtype7;
	Y7785_gen_type [8] = Y7785_pgtype8;
	Y7785_gen_type [9] = Y7785_pgtype9;
	Y7785_gen_type [10] = Y7785_pgtype10;
	Y7785_gen_type [11] = Y7785_pgtype11;
	Y7785_gen_type [12] = Y7785_pgtype12;
	Y7785_gen_type [13] = Y7785_pgtype13;
	Y7785_gen_type [14] = Y7785_pgtype14;
	{long i; for (i = 0; i < 2; i++) Y7785[i] = 1407;};
	Y7785[2] = 1410;
	Y7785[3] = 1407;
	Y7785[4] = 1410;
	Y7785[5] = 1408;
	{long i; for (i = 6; i < 15; i++) Y7785[i] = 1407;};
}

long O7786[15];
void O7786_init () {
	O7786[0] =  + _REFACS_3_;
	O7786[1] =  + _REFACS_2_;
	O7786[2] =  + _REFACS_3_;
	{long i; for (i = 3; i < 9; i++) O7786[i] =  + _REFACS_2_;}
	O7786[9] =  + _REFACS_3_;
	{long i; for (i = 10; i < 14; i++) O7786[i] =  + _REFACS_2_;}
	O7786[14] =  + _REFACS_3_;
}

long O7787[15];
void O7787_init () {
	O7787[0] =  + _REFACS_4_;
	O7787[1] =  + _REFACS_3_;
	O7787[2] =  + _REFACS_4_;
	{long i; for (i = 3; i < 9; i++) O7787[i] =  + _REFACS_3_;}
	O7787[9] =  + _REFACS_4_;
	{long i; for (i = 10; i < 14; i++) O7787[i] =  + _REFACS_3_;}
	O7787[14] =  + _REFACS_4_;
}

long O7788[15];
void O7788_init () {
	O7788[0] = + _LNGOFF_7_3_0_1_;
	O7788[1] = + _LNGOFF_5_3_0_3_;
	O7788[2] = + _LNGOFF_6_3_0_1_;
	O7788[3] = + _LNGOFF_5_3_0_2_;
	O7788[4] = + _LNGOFF_4_3_0_2_;
	O7788[5] = + _LNGOFF_4_3_0_3_;
	O7788[6] = + _LNGOFF_5_3_0_1_;
	{long i; for (i = 7; i < 9; i++) O7788[i] = + _LNGOFF_5_5_0_1_;}
	O7788[9] = + _LNGOFF_7_4_0_1_;
	O7788[10] = + _LNGOFF_5_4_0_3_;
	O7788[11] = + _LNGOFF_5_4_0_2_;
	{long i; for (i = 12; i < 14; i++) O7788[i] = + _LNGOFF_5_6_0_1_;}
	O7788[14] = + _LNGOFF_9_3_0_1_;
}

long O7789[15];
void O7789_init () {
	O7789[0] = + _CHROFF_7_2_;
	O7789[1] = + _CHROFF_5_2_;
	O7789[2] = + _CHROFF_6_2_;
	O7789[3] = + _CHROFF_5_2_;
	{long i; for (i = 4; i < 6; i++) O7789[i] = + _CHROFF_4_2_;}
	{long i; for (i = 6; i < 8; i++) O7789[i] = + _CHROFF_5_2_;}
	O7789[8] = + _CHROFF_5_3_;
	O7789[9] = + _CHROFF_7_2_;
	{long i; for (i = 10; i < 13; i++) O7789[i] = + _CHROFF_5_2_;}
	O7789[13] = + _CHROFF_5_3_;
	O7789[14] = + _CHROFF_9_2_;
}

long O7790[15];
void O7790_init () {
	O7790[0] = + _LNGOFF_7_3_0_2_;
	O7790[1] = + _LNGOFF_5_3_0_4_;
	O7790[2] = + _LNGOFF_6_3_0_2_;
	O7790[3] = + _LNGOFF_5_3_0_3_;
	O7790[4] = + _LNGOFF_4_3_0_3_;
	O7790[5] = + _LNGOFF_4_3_0_4_;
	O7790[6] = + _LNGOFF_5_3_0_2_;
	{long i; for (i = 7; i < 9; i++) O7790[i] = + _LNGOFF_5_5_0_2_;}
	O7790[9] = + _LNGOFF_7_4_0_2_;
	O7790[10] = + _LNGOFF_5_4_0_4_;
	O7790[11] = + _LNGOFF_5_4_0_3_;
	{long i; for (i = 12; i < 14; i++) O7790[i] = + _LNGOFF_5_6_0_2_;}
	O7790[14] = + _LNGOFF_9_3_0_2_;
}

long O7793[15];
void O7793_init () {
	O7793[0] = + _LNGOFF_7_3_0_3_;
	O7793[1] = + _LNGOFF_5_3_0_5_;
	O7793[2] = + _LNGOFF_6_3_0_3_;
	O7793[3] = + _LNGOFF_5_3_0_4_;
	O7793[4] = + _LNGOFF_4_3_0_4_;
	O7793[5] = + _LNGOFF_4_3_0_5_;
	O7793[6] = + _LNGOFF_5_3_0_3_;
	{long i; for (i = 7; i < 9; i++) O7793[i] = + _LNGOFF_5_5_0_3_;}
	O7793[9] = + _LNGOFF_7_4_0_3_;
	O7793[10] = + _LNGOFF_5_4_0_5_;
	O7793[11] = + _LNGOFF_5_4_0_4_;
	{long i; for (i = 12; i < 14; i++) O7793[i] = + _LNGOFF_5_6_0_3_;}
	O7793[14] = + _LNGOFF_9_3_0_3_;
}

long O7794[15];
void O7794_init () {
	O7794[0] = + _LNGOFF_7_3_0_4_;
	O7794[1] = + _LNGOFF_5_3_0_6_;
	O7794[2] = + _LNGOFF_6_3_0_4_;
	O7794[3] = + _LNGOFF_5_3_0_5_;
	O7794[4] = + _LNGOFF_4_3_0_5_;
	O7794[5] = + _LNGOFF_4_3_0_6_;
	O7794[6] = + _LNGOFF_5_3_0_4_;
	{long i; for (i = 7; i < 9; i++) O7794[i] = + _LNGOFF_5_5_0_4_;}
	O7794[9] = + _LNGOFF_7_4_0_4_;
	O7794[10] = + _LNGOFF_5_4_0_6_;
	O7794[11] = + _LNGOFF_5_4_0_5_;
	{long i; for (i = 12; i < 14; i++) O7794[i] = + _LNGOFF_5_6_0_4_;}
	O7794[14] = + _LNGOFF_9_3_0_4_;
}

long O7798[15];
void O7798_init () {
	O7798[0] = + _LNGOFF_7_3_0_5_;
	O7798[1] = + _LNGOFF_5_3_0_7_;
	O7798[2] = + _LNGOFF_6_3_0_5_;
	O7798[3] = + _LNGOFF_5_3_0_6_;
	O7798[4] = + _LNGOFF_4_3_0_6_;
	O7798[5] = + _LNGOFF_4_3_0_7_;
	O7798[6] = + _LNGOFF_5_3_0_5_;
	{long i; for (i = 7; i < 9; i++) O7798[i] = + _LNGOFF_5_5_0_5_;}
	O7798[9] = + _LNGOFF_7_4_0_5_;
	O7798[10] = + _LNGOFF_5_4_0_7_;
	O7798[11] = + _LNGOFF_5_4_0_6_;
	{long i; for (i = 12; i < 14; i++) O7798[i] = + _LNGOFF_5_6_0_5_;}
	O7798[14] = + _LNGOFF_9_3_0_5_;
}

long O7799[15];
void O7799_init () {
	O7799[0] =  + _REFACS_5_;
	O7799[1] = + _LNGOFF_5_3_0_1_;
	O7799[2] =  + _REFACS_5_;
	O7799[3] = + _LNGOFF_5_3_0_7_;
	O7799[4] = + _LNGOFF_4_3_0_7_;
	O7799[5] = + _LNGOFF_4_3_0_8_;
	O7799[6] = + _PTROFF_5_3_0_7_0_1_;
	{long i; for (i = 7; i < 9; i++) O7799[i] = + _CHROFF_5_4_;}
	O7799[9] =  + _REFACS_5_;
	O7799[10] = + _LNGOFF_5_4_0_1_;
	O7799[11] = + _LNGOFF_5_4_0_7_;
	O7799[12] = + _CHROFF_5_5_;
	O7799[13] = + _CHROFF_5_4_;
	O7799[14] =  + _REFACS_5_;
}

long O7800[15];
void O7800_init () {
	O7800[0] =  + _REFACS_6_;
	O7800[1] =  + _REFACS_4_;
	O7800[2] = + _LNGOFF_6_3_0_6_;
	O7800[3] =  + _REFACS_4_;
	O7800[4] = + _LNGOFF_4_3_0_8_;
	O7800[5] = + _LNGOFF_4_3_0_0_;
	{long i; for (i = 6; i < 9; i++) O7800[i] =  + _REFACS_4_;}
	O7800[9] =  + _REFACS_6_;
	{long i; for (i = 10; i < 14; i++) O7800[i] =  + _REFACS_4_;}
	O7800[14] =  + _REFACS_6_;
}

long O7834[15];
void O7834_init () {
	O7834[0] = + _LNGOFF_7_3_0_6_;
	O7834[1] = + _LNGOFF_5_3_0_8_;
	O7834[2] = + _LNGOFF_6_3_0_7_;
	O7834[3] = + _LNGOFF_5_3_0_8_;
	{long i; for (i = 4; i < 6; i++) O7834[i] = + _LNGOFF_4_3_0_9_;}
	O7834[6] = + _LNGOFF_5_3_0_6_;
	{long i; for (i = 7; i < 9; i++) O7834[i] = + _LNGOFF_5_5_0_6_;}
	O7834[9] = + _LNGOFF_7_4_0_6_;
	{long i; for (i = 10; i < 12; i++) O7834[i] = + _LNGOFF_5_4_0_8_;}
	{long i; for (i = 12; i < 14; i++) O7834[i] = + _LNGOFF_5_6_0_6_;}
	O7834[14] = + _LNGOFF_9_3_0_6_;
}

long O7837[5];
void O7837_init () {
	O7837[0] = + _CHROFF_7_3_;
	{long i; for (i = 1; i < 4; i++) O7837[i] = + _CHROFF_5_3_;}
	O7837[4] = + _CHROFF_5_5_;
}

long O7864[2];
void O7864_init () {
	O7864[0] = + _LNGOFF_0_1_0_0_;
	O7864[1] = + _LNGOFF_1_1_0_0_;
}

long O7865[2];
void O7865_init () {
	O7865[0] = + _LNGOFF_0_1_0_1_;
	O7865[1] = + _LNGOFF_1_1_0_1_;
}

long O7898[9];
void O7898_init () {
	{long i; for (i = 0; i < 8; i++) O7898[i] = + _CHROFF_2_1_;}
	O7898[8] = + _CHROFF_4_1_;
}

long O7899[9];
void O7899_init () {
	{long i; for (i = 0; i < 8; i++) O7899[i] = + _CHROFF_2_2_;}
	O7899[8] = + _CHROFF_4_2_;
}

long O7900[9];
void O7900_init () {
	{long i; for (i = 0; i < 8; i++) O7900[i] = + _LNGOFF_2_3_0_0_;}
	O7900[8] = + _LNGOFF_4_3_0_0_;
}

long O7931[504];
void O7931_init () {
	{long i; for (i = 0; i < 16; i++) O7931[i] = + _LNGOFF_1_1_0_0_;}
	O7931[16] = + _LNGOFF_5_1_0_0_;
	{long i; for (i = 17; i < 19; i++) O7931[i] = + _LNGOFF_1_2_0_0_;}
	{long i; for (i = 19; i < 21; i++) O7931[i] = + _LNGOFF_3_2_0_0_;}
	{long i; for (i = 21; i < 24; i++) O7931[i] = + _LNGOFF_5_2_0_0_;}
	{long i; for (i = 24; i < 26; i++) O7931[i] = + _LNGOFF_9_2_0_0_;}
	O7931[26] = + _LNGOFF_10_2_0_0_;
	{long i; for (i = 27; i < 46; i++) O7931[i] = + _LNGOFF_9_2_0_0_;}
	O7931[503] = + _LNGOFF_7_2_0_0_;
}

long O7949[487];
void O7949_init () {
	{long i; for (i = 0; i < 2; i++) O7949[i] = + _CHROFF_1_1_;}
	{long i; for (i = 2; i < 4; i++) O7949[i] = + _CHROFF_3_1_;}
	{long i; for (i = 4; i < 7; i++) O7949[i] = + _CHROFF_5_1_;}
	{long i; for (i = 7; i < 9; i++) O7949[i] = + _CHROFF_9_1_;}
	O7949[9] = + _CHROFF_10_1_;
	{long i; for (i = 10; i < 29; i++) O7949[i] = + _CHROFF_9_1_;}
	O7949[486] = + _CHROFF_7_1_;
}

static EIF_TYPE_INDEX Y7952_pgtype0[] = {915,0xFFF9,1,1186,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7952_pgtype1[] = {915,0xFFF9,1,1186,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7952_pgtype2[] = {915,0xFFF9,1,1186,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7952_pgtype3[] = {915,0xFFF9,1,1186,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7952_pgtype4[] = {915,0xFFF9,1,1186,1301,0xFFFF};
EIF_TYPE_INDEX *Y7952_gen_type [5];
EIF_TYPE_INDEX Y7952 [5];
void Y7952_init (void)
{
	egc_routines_types [7952] = Y7952;
	egc_routines_gen_types [7952] = Y7952_gen_type;
	egc_routines_offset [7952] = 910;
	Y7952_gen_type [0] = Y7952_pgtype0;
	Y7952_gen_type [1] = Y7952_pgtype1;
	Y7952_gen_type [2] = Y7952_pgtype2;
	Y7952_gen_type [3] = Y7952_pgtype3;
	Y7952_gen_type [4] = Y7952_pgtype4;
	{long i; for (i = 0; i < 5; i++) Y7952[i] = 915;};
}

static EIF_TYPE_INDEX Y7953_pgtype0[] = {915,0xFFF9,1,1186,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7953_pgtype1[] = {915,0xFFF9,1,1186,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7953_pgtype2[] = {915,0xFFF9,1,1186,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7953_pgtype3[] = {915,0xFFF9,1,1186,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7953_pgtype4[] = {915,0xFFF9,1,1186,1301,0xFFFF};
EIF_TYPE_INDEX *Y7953_gen_type [5];
EIF_TYPE_INDEX Y7953 [5];
void Y7953_init (void)
{
	egc_routines_types [7953] = Y7953;
	egc_routines_gen_types [7953] = Y7953_gen_type;
	egc_routines_offset [7953] = 910;
	Y7953_gen_type [0] = Y7953_pgtype0;
	Y7953_gen_type [1] = Y7953_pgtype1;
	Y7953_gen_type [2] = Y7953_pgtype2;
	Y7953_gen_type [3] = Y7953_pgtype3;
	Y7953_gen_type [4] = Y7953_pgtype4;
	{long i; for (i = 0; i < 5; i++) Y7953[i] = 915;};
}

static EIF_TYPE_INDEX Y7954_pgtype0[] = {916,0xFFF9,1,1186,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7954_pgtype1[] = {916,0xFFF9,1,1186,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7954_pgtype2[] = {916,0xFFF9,1,1186,1301,0xFFFF};
EIF_TYPE_INDEX *Y7954_gen_type [3];
EIF_TYPE_INDEX Y7954 [3];
void Y7954_init (void)
{
	egc_routines_types [7954] = Y7954;
	egc_routines_gen_types [7954] = Y7954_gen_type;
	egc_routines_offset [7954] = 912;
	Y7954_gen_type [0] = Y7954_pgtype0;
	Y7954_gen_type [1] = Y7954_pgtype1;
	Y7954_gen_type [2] = Y7954_pgtype2;
	{long i; for (i = 0; i < 3; i++) Y7954[i] = 916;};
}

static EIF_TYPE_INDEX Y7955_pgtype0[] = {916,0xFFF9,1,1186,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7955_pgtype1[] = {916,0xFFF9,1,1186,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7955_pgtype2[] = {916,0xFFF9,1,1186,1301,0xFFFF};
EIF_TYPE_INDEX *Y7955_gen_type [3];
EIF_TYPE_INDEX Y7955 [3];
void Y7955_init (void)
{
	egc_routines_types [7955] = Y7955;
	egc_routines_gen_types [7955] = Y7955_gen_type;
	egc_routines_offset [7955] = 912;
	Y7955_gen_type [0] = Y7955_pgtype0;
	Y7955_gen_type [1] = Y7955_pgtype1;
	Y7955_gen_type [2] = Y7955_pgtype2;
	{long i; for (i = 0; i < 3; i++) Y7955[i] = 916;};
}

long O7968[22];
void O7968_init () {
	{long i; for (i = 0; i < 2; i++) O7968[i] = + _LNGOFF_9_2_0_1_;}
	O7968[2] = + _LNGOFF_10_2_0_1_;
	{long i; for (i = 3; i < 22; i++) O7968[i] = + _LNGOFF_9_2_0_1_;}
}

long O8159[25];
void O8159_init () {
	{long i; for (i = 0; i < 21; i++) O8159[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 21; i < 25; i++) O8159[i] = + _LNGOFF_2_1_0_0_;}
}

long O8163[25];
void O8163_init () {
	{long i; for (i = 0; i < 21; i++) O8163[i] = + _CHROFF_1_0_;}
	{long i; for (i = 21; i < 25; i++) O8163[i] = + _CHROFF_2_0_;}
}

long O8164[25];
void O8164_init () {
	{long i; for (i = 0; i < 21; i++) O8164[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 21; i < 25; i++) O8164[i] = + _LNGOFF_2_1_0_1_;}
}

long O8165[25];
void O8165_init () {
	{long i; for (i = 0; i < 21; i++) O8165[i] = + _LNGOFF_1_1_0_2_;}
	{long i; for (i = 21; i < 25; i++) O8165[i] = + _LNGOFF_2_1_0_2_;}
}

long O8166[25];
void O8166_init () {
	{long i; for (i = 0; i < 21; i++) O8166[i] = + _LNGOFF_1_1_0_3_;}
	{long i; for (i = 21; i < 25; i++) O8166[i] = + _LNGOFF_2_1_0_3_;}
}

long O8167[25];
void O8167_init () {
	{long i; for (i = 0; i < 21; i++) O8167[i] = + _LNGOFF_1_1_0_4_;}
	{long i; for (i = 21; i < 25; i++) O8167[i] = + _LNGOFF_2_1_0_4_;}
}

long O8170[50];
void O8170_init () {
	{long i; for (i = 0; i < 12; i++) O8170[i] = + _LNGOFF_1_0_0_0_;}
	{long i; for (i = 12; i < 38; i++) O8170[i] = + _LNGOFF_2_0_0_0_;}
	{long i; for (i = 38; i < 50; i++) O8170[i] = + _LNGOFF_1_0_0_0_;}
}

long O8172[50];
void O8172_init () {
	{long i; for (i = 0; i < 12; i++) O8172[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 12; i < 38; i++) O8172[i] = + _LNGOFF_2_0_0_1_;}
	{long i; for (i = 38; i < 50; i++) O8172[i] = + _LNGOFF_1_0_0_1_;}
}

long O8251[8];
void O8251_init () {
	O8251[0] = + _LNGOFF_2_0_0_0_;
	O8251[1] = + _LNGOFF_3_0_0_0_;
	{long i; for (i = 2; i < 5; i++) O8251[i] = + _LNGOFF_2_0_0_0_;}
	{long i; for (i = 5; i < 7; i++) O8251[i] = + _LNGOFF_3_0_0_0_;}
	O8251[7] = + _LNGOFF_2_0_0_0_;
}

long O8252[8];
void O8252_init () {
	O8252[0] = + _LNGOFF_2_0_0_1_;
	O8252[1] = + _LNGOFF_3_0_0_1_;
	{long i; for (i = 2; i < 5; i++) O8252[i] = + _LNGOFF_2_0_0_1_;}
	{long i; for (i = 5; i < 7; i++) O8252[i] = + _LNGOFF_3_0_0_1_;}
	O8252[7] = + _LNGOFF_2_0_0_1_;
}

long O8253[8];
void O8253_init () {
	O8253[0] = + _LNGOFF_2_0_0_2_;
	O8253[1] = + _LNGOFF_3_0_0_2_;
	{long i; for (i = 2; i < 5; i++) O8253[i] = + _LNGOFF_2_0_0_2_;}
	{long i; for (i = 5; i < 7; i++) O8253[i] = + _LNGOFF_3_0_0_2_;}
	O8253[7] = + _LNGOFF_2_0_0_2_;
}

long O8683[621];
void O8683_init () {
	O8683[0] = + _CHROFF_1_0_;
	O8683[1] = + _CHROFF_2_0_;
	O8683[2] = + _CHROFF_3_0_;
	O8683[3] = + _CHROFF_4_0_;
	O8683[4] = + _CHROFF_5_0_;
	O8683[572] = + _CHROFF_5_0_;
	{long i; for (i = 612; i < 615; i++) O8683[i] = + _CHROFF_5_0_;}
	O8683[616] = + _CHROFF_7_1_;
	{long i; for (i = 617; i < 621; i++) O8683[i] = + _CHROFF_6_1_;}
}


#ifdef __cplusplus
}
#endif
