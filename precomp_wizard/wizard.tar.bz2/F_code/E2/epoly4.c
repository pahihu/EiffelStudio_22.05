#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O4777[1407];
void O4777_init () {
	O4777[0] =  + _REFACS_4_;
	{long i; for (i = 1295; i < 1297; i++) O4777[i] =  + _REFACS_13_;}
	{long i; for (i = 1297; i < 1300; i++) O4777[i] =  + _REFACS_14_;}
	O4777[1300] =  + _REFACS_15_;
	{long i; for (i = 1301; i < 1303; i++) O4777[i] =  + _REFACS_14_;}
	O4777[1303] =  + _REFACS_15_;
	O4777[1304] =  + _REFACS_14_;
	{long i; for (i = 1305; i < 1315; i++) O4777[i] =  + _REFACS_15_;}
	{long i; for (i = 1315; i < 1317; i++) O4777[i] =  + _REFACS_19_;}
	{long i; for (i = 1317; i < 1319; i++) O4777[i] =  + _REFACS_22_;}
	{long i; for (i = 1319; i < 1323; i++) O4777[i] =  + _REFACS_15_;}
	{long i; for (i = 1323; i < 1325; i++) O4777[i] =  + _REFACS_19_;}
	{long i; for (i = 1325; i < 1327; i++) O4777[i] =  + _REFACS_22_;}
	O4777[1327] =  + _REFACS_13_;
	O4777[1328] =  + _REFACS_15_;
	O4777[1329] =  + _REFACS_14_;
	O4777[1330] =  + _REFACS_17_;
	O4777[1331] =  + _REFACS_13_;
	O4777[1332] =  + _REFACS_18_;
	{long i; for (i = 1333; i < 1338; i++) O4777[i] =  + _REFACS_14_;}
	{long i; for (i = 1338; i < 1340; i++) O4777[i] =  + _REFACS_15_;}
	O4777[1340] =  + _REFACS_14_;
	O4777[1341] =  + _REFACS_15_;
	O4777[1342] =  + _REFACS_19_;
	O4777[1343] =  + _REFACS_14_;
	O4777[1344] =  + _REFACS_17_;
	{long i; for (i = 1345; i < 1349; i++) O4777[i] =  + _REFACS_13_;}
	O4777[1349] =  + _REFACS_15_;
	O4777[1350] =  + _REFACS_14_;
	O4777[1351] =  + _REFACS_17_;
	O4777[1352] =  + _REFACS_13_;
	O4777[1353] =  + _REFACS_18_;
	{long i; for (i = 1354; i < 1359; i++) O4777[i] =  + _REFACS_14_;}
	{long i; for (i = 1359; i < 1361; i++) O4777[i] =  + _REFACS_15_;}
	O4777[1361] =  + _REFACS_14_;
	O4777[1362] =  + _REFACS_15_;
	O4777[1363] =  + _REFACS_19_;
	O4777[1364] =  + _REFACS_14_;
	O4777[1365] =  + _REFACS_17_;
	{long i; for (i = 1366; i < 1369; i++) O4777[i] =  + _REFACS_13_;}
	O4777[1398] =  + _REFACS_14_;
	O4777[1401] =  + _REFACS_14_;
	O4777[1403] =  + _REFACS_14_;
	O4777[1406] =  + _REFACS_14_;
}

long O4779[1407];
void O4779_init () {
	O4779[0] =  + _REFACS_5_;
	{long i; for (i = 1295; i < 1297; i++) O4779[i] =  + _REFACS_14_;}
	{long i; for (i = 1297; i < 1300; i++) O4779[i] =  + _REFACS_15_;}
	O4779[1300] =  + _REFACS_16_;
	{long i; for (i = 1301; i < 1303; i++) O4779[i] =  + _REFACS_15_;}
	O4779[1303] =  + _REFACS_16_;
	O4779[1304] =  + _REFACS_15_;
	{long i; for (i = 1305; i < 1315; i++) O4779[i] =  + _REFACS_16_;}
	{long i; for (i = 1315; i < 1317; i++) O4779[i] =  + _REFACS_20_;}
	{long i; for (i = 1317; i < 1319; i++) O4779[i] =  + _REFACS_23_;}
	{long i; for (i = 1319; i < 1323; i++) O4779[i] =  + _REFACS_16_;}
	{long i; for (i = 1323; i < 1325; i++) O4779[i] =  + _REFACS_20_;}
	{long i; for (i = 1325; i < 1327; i++) O4779[i] =  + _REFACS_23_;}
	O4779[1327] =  + _REFACS_14_;
	O4779[1328] =  + _REFACS_16_;
	O4779[1329] =  + _REFACS_15_;
	O4779[1330] =  + _REFACS_18_;
	O4779[1331] =  + _REFACS_14_;
	O4779[1332] =  + _REFACS_19_;
	{long i; for (i = 1333; i < 1338; i++) O4779[i] =  + _REFACS_15_;}
	{long i; for (i = 1338; i < 1340; i++) O4779[i] =  + _REFACS_16_;}
	O4779[1340] =  + _REFACS_15_;
	O4779[1341] =  + _REFACS_16_;
	O4779[1342] =  + _REFACS_20_;
	O4779[1343] =  + _REFACS_15_;
	O4779[1344] =  + _REFACS_18_;
	{long i; for (i = 1345; i < 1349; i++) O4779[i] =  + _REFACS_14_;}
	O4779[1349] =  + _REFACS_16_;
	O4779[1350] =  + _REFACS_15_;
	O4779[1351] =  + _REFACS_18_;
	O4779[1352] =  + _REFACS_14_;
	O4779[1353] =  + _REFACS_19_;
	{long i; for (i = 1354; i < 1359; i++) O4779[i] =  + _REFACS_15_;}
	{long i; for (i = 1359; i < 1361; i++) O4779[i] =  + _REFACS_16_;}
	O4779[1361] =  + _REFACS_15_;
	O4779[1362] =  + _REFACS_16_;
	O4779[1363] =  + _REFACS_20_;
	O4779[1364] =  + _REFACS_15_;
	O4779[1365] =  + _REFACS_18_;
	{long i; for (i = 1366; i < 1369; i++) O4779[i] =  + _REFACS_14_;}
	O4779[1398] =  + _REFACS_15_;
	O4779[1401] =  + _REFACS_15_;
	O4779[1403] =  + _REFACS_15_;
	O4779[1406] =  + _REFACS_15_;
}

long O4781[1407];
void O4781_init () {
	O4781[0] =  + _REFACS_6_;
	{long i; for (i = 1295; i < 1297; i++) O4781[i] =  + _REFACS_15_;}
	{long i; for (i = 1297; i < 1300; i++) O4781[i] =  + _REFACS_16_;}
	O4781[1300] =  + _REFACS_17_;
	{long i; for (i = 1301; i < 1303; i++) O4781[i] =  + _REFACS_16_;}
	O4781[1303] =  + _REFACS_17_;
	O4781[1304] =  + _REFACS_16_;
	{long i; for (i = 1305; i < 1315; i++) O4781[i] =  + _REFACS_17_;}
	{long i; for (i = 1315; i < 1317; i++) O4781[i] =  + _REFACS_21_;}
	{long i; for (i = 1317; i < 1319; i++) O4781[i] =  + _REFACS_24_;}
	{long i; for (i = 1319; i < 1323; i++) O4781[i] =  + _REFACS_17_;}
	{long i; for (i = 1323; i < 1325; i++) O4781[i] =  + _REFACS_21_;}
	{long i; for (i = 1325; i < 1327; i++) O4781[i] =  + _REFACS_24_;}
	O4781[1327] =  + _REFACS_15_;
	O4781[1328] =  + _REFACS_17_;
	O4781[1329] =  + _REFACS_16_;
	O4781[1330] =  + _REFACS_19_;
	O4781[1331] =  + _REFACS_15_;
	O4781[1332] =  + _REFACS_20_;
	{long i; for (i = 1333; i < 1338; i++) O4781[i] =  + _REFACS_16_;}
	{long i; for (i = 1338; i < 1340; i++) O4781[i] =  + _REFACS_17_;}
	O4781[1340] =  + _REFACS_16_;
	O4781[1341] =  + _REFACS_17_;
	O4781[1342] =  + _REFACS_21_;
	O4781[1343] =  + _REFACS_16_;
	O4781[1344] =  + _REFACS_19_;
	{long i; for (i = 1345; i < 1349; i++) O4781[i] =  + _REFACS_15_;}
	O4781[1349] =  + _REFACS_17_;
	O4781[1350] =  + _REFACS_16_;
	O4781[1351] =  + _REFACS_19_;
	O4781[1352] =  + _REFACS_15_;
	O4781[1353] =  + _REFACS_20_;
	{long i; for (i = 1354; i < 1359; i++) O4781[i] =  + _REFACS_16_;}
	{long i; for (i = 1359; i < 1361; i++) O4781[i] =  + _REFACS_17_;}
	O4781[1361] =  + _REFACS_16_;
	O4781[1362] =  + _REFACS_17_;
	O4781[1363] =  + _REFACS_21_;
	O4781[1364] =  + _REFACS_16_;
	O4781[1365] =  + _REFACS_19_;
	{long i; for (i = 1366; i < 1369; i++) O4781[i] =  + _REFACS_15_;}
	O4781[1398] =  + _REFACS_16_;
	O4781[1401] =  + _REFACS_16_;
	O4781[1403] =  + _REFACS_16_;
	O4781[1406] =  + _REFACS_16_;
}

long O4783[1407];
void O4783_init () {
	O4783[0] =  + _REFACS_7_;
	{long i; for (i = 1295; i < 1297; i++) O4783[i] =  + _REFACS_16_;}
	{long i; for (i = 1297; i < 1300; i++) O4783[i] =  + _REFACS_17_;}
	O4783[1300] =  + _REFACS_18_;
	{long i; for (i = 1301; i < 1303; i++) O4783[i] =  + _REFACS_17_;}
	O4783[1303] =  + _REFACS_18_;
	O4783[1304] =  + _REFACS_17_;
	{long i; for (i = 1305; i < 1315; i++) O4783[i] =  + _REFACS_18_;}
	{long i; for (i = 1315; i < 1317; i++) O4783[i] =  + _REFACS_22_;}
	{long i; for (i = 1317; i < 1319; i++) O4783[i] =  + _REFACS_25_;}
	{long i; for (i = 1319; i < 1323; i++) O4783[i] =  + _REFACS_18_;}
	{long i; for (i = 1323; i < 1325; i++) O4783[i] =  + _REFACS_22_;}
	{long i; for (i = 1325; i < 1327; i++) O4783[i] =  + _REFACS_25_;}
	O4783[1327] =  + _REFACS_16_;
	O4783[1328] =  + _REFACS_18_;
	O4783[1329] =  + _REFACS_17_;
	O4783[1330] =  + _REFACS_20_;
	O4783[1331] =  + _REFACS_16_;
	O4783[1332] =  + _REFACS_21_;
	{long i; for (i = 1333; i < 1338; i++) O4783[i] =  + _REFACS_17_;}
	{long i; for (i = 1338; i < 1340; i++) O4783[i] =  + _REFACS_18_;}
	O4783[1340] =  + _REFACS_17_;
	O4783[1341] =  + _REFACS_18_;
	O4783[1342] =  + _REFACS_22_;
	O4783[1343] =  + _REFACS_17_;
	O4783[1344] =  + _REFACS_20_;
	{long i; for (i = 1345; i < 1349; i++) O4783[i] =  + _REFACS_16_;}
	O4783[1349] =  + _REFACS_18_;
	O4783[1350] =  + _REFACS_17_;
	O4783[1351] =  + _REFACS_20_;
	O4783[1352] =  + _REFACS_16_;
	O4783[1353] =  + _REFACS_21_;
	{long i; for (i = 1354; i < 1359; i++) O4783[i] =  + _REFACS_17_;}
	{long i; for (i = 1359; i < 1361; i++) O4783[i] =  + _REFACS_18_;}
	O4783[1361] =  + _REFACS_17_;
	O4783[1362] =  + _REFACS_18_;
	O4783[1363] =  + _REFACS_22_;
	O4783[1364] =  + _REFACS_17_;
	O4783[1365] =  + _REFACS_20_;
	{long i; for (i = 1366; i < 1369; i++) O4783[i] =  + _REFACS_16_;}
	O4783[1398] =  + _REFACS_17_;
	O4783[1401] =  + _REFACS_17_;
	O4783[1403] =  + _REFACS_17_;
	O4783[1406] =  + _REFACS_17_;
}

long O4785[1407];
void O4785_init () {
	O4785[0] =  + _REFACS_8_;
	{long i; for (i = 1295; i < 1297; i++) O4785[i] =  + _REFACS_17_;}
	{long i; for (i = 1297; i < 1300; i++) O4785[i] =  + _REFACS_18_;}
	O4785[1300] =  + _REFACS_19_;
	{long i; for (i = 1301; i < 1303; i++) O4785[i] =  + _REFACS_18_;}
	O4785[1303] =  + _REFACS_19_;
	O4785[1304] =  + _REFACS_18_;
	{long i; for (i = 1305; i < 1315; i++) O4785[i] =  + _REFACS_19_;}
	{long i; for (i = 1315; i < 1317; i++) O4785[i] =  + _REFACS_23_;}
	{long i; for (i = 1317; i < 1319; i++) O4785[i] =  + _REFACS_26_;}
	{long i; for (i = 1319; i < 1323; i++) O4785[i] =  + _REFACS_19_;}
	{long i; for (i = 1323; i < 1325; i++) O4785[i] =  + _REFACS_23_;}
	{long i; for (i = 1325; i < 1327; i++) O4785[i] =  + _REFACS_26_;}
	O4785[1327] =  + _REFACS_17_;
	O4785[1328] =  + _REFACS_19_;
	O4785[1329] =  + _REFACS_18_;
	O4785[1330] =  + _REFACS_21_;
	O4785[1331] =  + _REFACS_17_;
	O4785[1332] =  + _REFACS_22_;
	{long i; for (i = 1333; i < 1338; i++) O4785[i] =  + _REFACS_18_;}
	{long i; for (i = 1338; i < 1340; i++) O4785[i] =  + _REFACS_19_;}
	O4785[1340] =  + _REFACS_18_;
	O4785[1341] =  + _REFACS_19_;
	O4785[1342] =  + _REFACS_23_;
	O4785[1343] =  + _REFACS_18_;
	O4785[1344] =  + _REFACS_21_;
	{long i; for (i = 1345; i < 1349; i++) O4785[i] =  + _REFACS_17_;}
	O4785[1349] =  + _REFACS_19_;
	O4785[1350] =  + _REFACS_18_;
	O4785[1351] =  + _REFACS_21_;
	O4785[1352] =  + _REFACS_17_;
	O4785[1353] =  + _REFACS_22_;
	{long i; for (i = 1354; i < 1359; i++) O4785[i] =  + _REFACS_18_;}
	{long i; for (i = 1359; i < 1361; i++) O4785[i] =  + _REFACS_19_;}
	O4785[1361] =  + _REFACS_18_;
	O4785[1362] =  + _REFACS_19_;
	O4785[1363] =  + _REFACS_23_;
	O4785[1364] =  + _REFACS_18_;
	O4785[1365] =  + _REFACS_21_;
	{long i; for (i = 1366; i < 1369; i++) O4785[i] =  + _REFACS_17_;}
	O4785[1398] =  + _REFACS_18_;
	O4785[1401] =  + _REFACS_18_;
	O4785[1403] =  + _REFACS_18_;
	O4785[1406] =  + _REFACS_18_;
}

long O4787[1407];
void O4787_init () {
	O4787[0] =  + _REFACS_9_;
	{long i; for (i = 1295; i < 1297; i++) O4787[i] =  + _REFACS_18_;}
	{long i; for (i = 1297; i < 1300; i++) O4787[i] =  + _REFACS_19_;}
	O4787[1300] =  + _REFACS_20_;
	{long i; for (i = 1301; i < 1303; i++) O4787[i] =  + _REFACS_19_;}
	O4787[1303] =  + _REFACS_20_;
	O4787[1304] =  + _REFACS_19_;
	{long i; for (i = 1305; i < 1315; i++) O4787[i] =  + _REFACS_20_;}
	{long i; for (i = 1315; i < 1317; i++) O4787[i] =  + _REFACS_24_;}
	{long i; for (i = 1317; i < 1319; i++) O4787[i] =  + _REFACS_27_;}
	{long i; for (i = 1319; i < 1323; i++) O4787[i] =  + _REFACS_20_;}
	{long i; for (i = 1323; i < 1325; i++) O4787[i] =  + _REFACS_24_;}
	{long i; for (i = 1325; i < 1327; i++) O4787[i] =  + _REFACS_27_;}
	O4787[1327] =  + _REFACS_18_;
	O4787[1328] =  + _REFACS_20_;
	O4787[1329] =  + _REFACS_19_;
	O4787[1330] =  + _REFACS_22_;
	O4787[1331] =  + _REFACS_18_;
	O4787[1332] =  + _REFACS_23_;
	{long i; for (i = 1333; i < 1338; i++) O4787[i] =  + _REFACS_19_;}
	{long i; for (i = 1338; i < 1340; i++) O4787[i] =  + _REFACS_20_;}
	O4787[1340] =  + _REFACS_19_;
	O4787[1341] =  + _REFACS_20_;
	O4787[1342] =  + _REFACS_24_;
	O4787[1343] =  + _REFACS_19_;
	O4787[1344] =  + _REFACS_22_;
	{long i; for (i = 1345; i < 1349; i++) O4787[i] =  + _REFACS_18_;}
	O4787[1349] =  + _REFACS_20_;
	O4787[1350] =  + _REFACS_19_;
	O4787[1351] =  + _REFACS_22_;
	O4787[1352] =  + _REFACS_18_;
	O4787[1353] =  + _REFACS_23_;
	{long i; for (i = 1354; i < 1359; i++) O4787[i] =  + _REFACS_19_;}
	{long i; for (i = 1359; i < 1361; i++) O4787[i] =  + _REFACS_20_;}
	O4787[1361] =  + _REFACS_19_;
	O4787[1362] =  + _REFACS_20_;
	O4787[1363] =  + _REFACS_24_;
	O4787[1364] =  + _REFACS_19_;
	O4787[1365] =  + _REFACS_22_;
	{long i; for (i = 1366; i < 1369; i++) O4787[i] =  + _REFACS_18_;}
	O4787[1398] =  + _REFACS_19_;
	O4787[1401] =  + _REFACS_19_;
	O4787[1403] =  + _REFACS_19_;
	O4787[1406] =  + _REFACS_19_;
}

long O4789[1407];
void O4789_init () {
	O4789[0] =  + _REFACS_10_;
	{long i; for (i = 1295; i < 1297; i++) O4789[i] =  + _REFACS_19_;}
	{long i; for (i = 1297; i < 1300; i++) O4789[i] =  + _REFACS_20_;}
	O4789[1300] =  + _REFACS_21_;
	{long i; for (i = 1301; i < 1303; i++) O4789[i] =  + _REFACS_20_;}
	O4789[1303] =  + _REFACS_21_;
	O4789[1304] =  + _REFACS_20_;
	{long i; for (i = 1305; i < 1315; i++) O4789[i] =  + _REFACS_21_;}
	{long i; for (i = 1315; i < 1317; i++) O4789[i] =  + _REFACS_25_;}
	{long i; for (i = 1317; i < 1319; i++) O4789[i] =  + _REFACS_28_;}
	{long i; for (i = 1319; i < 1323; i++) O4789[i] =  + _REFACS_21_;}
	{long i; for (i = 1323; i < 1325; i++) O4789[i] =  + _REFACS_25_;}
	{long i; for (i = 1325; i < 1327; i++) O4789[i] =  + _REFACS_28_;}
	O4789[1327] =  + _REFACS_19_;
	O4789[1328] =  + _REFACS_21_;
	O4789[1329] =  + _REFACS_20_;
	O4789[1330] =  + _REFACS_23_;
	O4789[1331] =  + _REFACS_19_;
	O4789[1332] =  + _REFACS_24_;
	{long i; for (i = 1333; i < 1338; i++) O4789[i] =  + _REFACS_20_;}
	{long i; for (i = 1338; i < 1340; i++) O4789[i] =  + _REFACS_21_;}
	O4789[1340] =  + _REFACS_20_;
	O4789[1341] =  + _REFACS_21_;
	O4789[1342] =  + _REFACS_25_;
	O4789[1343] =  + _REFACS_20_;
	O4789[1344] =  + _REFACS_23_;
	{long i; for (i = 1345; i < 1349; i++) O4789[i] =  + _REFACS_19_;}
	O4789[1349] =  + _REFACS_21_;
	O4789[1350] =  + _REFACS_20_;
	O4789[1351] =  + _REFACS_23_;
	O4789[1352] =  + _REFACS_19_;
	O4789[1353] =  + _REFACS_24_;
	{long i; for (i = 1354; i < 1359; i++) O4789[i] =  + _REFACS_20_;}
	{long i; for (i = 1359; i < 1361; i++) O4789[i] =  + _REFACS_21_;}
	O4789[1361] =  + _REFACS_20_;
	O4789[1362] =  + _REFACS_21_;
	O4789[1363] =  + _REFACS_25_;
	O4789[1364] =  + _REFACS_20_;
	O4789[1365] =  + _REFACS_23_;
	{long i; for (i = 1366; i < 1369; i++) O4789[i] =  + _REFACS_19_;}
	O4789[1398] =  + _REFACS_20_;
	O4789[1401] =  + _REFACS_20_;
	O4789[1403] =  + _REFACS_20_;
	O4789[1406] =  + _REFACS_20_;
}

long O4791[1407];
void O4791_init () {
	O4791[0] =  + _REFACS_11_;
	{long i; for (i = 1295; i < 1297; i++) O4791[i] =  + _REFACS_20_;}
	{long i; for (i = 1297; i < 1300; i++) O4791[i] =  + _REFACS_21_;}
	O4791[1300] =  + _REFACS_22_;
	{long i; for (i = 1301; i < 1303; i++) O4791[i] =  + _REFACS_21_;}
	O4791[1303] =  + _REFACS_22_;
	O4791[1304] =  + _REFACS_21_;
	{long i; for (i = 1305; i < 1315; i++) O4791[i] =  + _REFACS_22_;}
	{long i; for (i = 1315; i < 1317; i++) O4791[i] =  + _REFACS_26_;}
	{long i; for (i = 1317; i < 1319; i++) O4791[i] =  + _REFACS_29_;}
	{long i; for (i = 1319; i < 1323; i++) O4791[i] =  + _REFACS_22_;}
	{long i; for (i = 1323; i < 1325; i++) O4791[i] =  + _REFACS_26_;}
	{long i; for (i = 1325; i < 1327; i++) O4791[i] =  + _REFACS_29_;}
	O4791[1327] =  + _REFACS_20_;
	O4791[1328] =  + _REFACS_22_;
	O4791[1329] =  + _REFACS_21_;
	O4791[1330] =  + _REFACS_24_;
	O4791[1331] =  + _REFACS_20_;
	O4791[1332] =  + _REFACS_25_;
	{long i; for (i = 1333; i < 1338; i++) O4791[i] =  + _REFACS_21_;}
	{long i; for (i = 1338; i < 1340; i++) O4791[i] =  + _REFACS_22_;}
	O4791[1340] =  + _REFACS_21_;
	O4791[1341] =  + _REFACS_22_;
	O4791[1342] =  + _REFACS_26_;
	O4791[1343] =  + _REFACS_21_;
	O4791[1344] =  + _REFACS_24_;
	{long i; for (i = 1345; i < 1349; i++) O4791[i] =  + _REFACS_20_;}
	O4791[1349] =  + _REFACS_22_;
	O4791[1350] =  + _REFACS_21_;
	O4791[1351] =  + _REFACS_24_;
	O4791[1352] =  + _REFACS_20_;
	O4791[1353] =  + _REFACS_25_;
	{long i; for (i = 1354; i < 1359; i++) O4791[i] =  + _REFACS_21_;}
	{long i; for (i = 1359; i < 1361; i++) O4791[i] =  + _REFACS_22_;}
	O4791[1361] =  + _REFACS_21_;
	O4791[1362] =  + _REFACS_22_;
	O4791[1363] =  + _REFACS_26_;
	O4791[1364] =  + _REFACS_21_;
	O4791[1365] =  + _REFACS_24_;
	{long i; for (i = 1366; i < 1369; i++) O4791[i] =  + _REFACS_20_;}
	O4791[1398] =  + _REFACS_21_;
	O4791[1401] =  + _REFACS_21_;
	O4791[1403] =  + _REFACS_21_;
	O4791[1406] =  + _REFACS_21_;
}


#ifdef __cplusplus
}
#endif
