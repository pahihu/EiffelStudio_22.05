#include "epoly13.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R7959[22])();
void R7959_init () {
	R7959[0] = (char *(*)()) F916_8912;
	R7959[1] = (char *(*)()) F917_8946;
	R7959[2] = (char *(*)()) F918_8947;
	R7959[5] = (char *(*)()) F917_8946;
	R7959[8] = (char *(*)()) F917_8946;
	{long i; for (i = 10; i < 12; i++) R7959[i] = (char *(*)()) F917_8946;}
	R7959[14] = (char *(*)()) F917_8946;
	{long i; for (i = 16; i < 22; i++) R7959[i] = (char *(*)()) F917_8946;}
}

static EIF_TYPE_INDEX Y7991_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7991_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7991_pgtype2[] = {0xFFF9,1,1186,0,0xFFFF};
static EIF_TYPE_INDEX Y7991_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7991_pgtype4[] = {0xFFF9,1,1186,1486,0xFFFF};
static EIF_TYPE_INDEX Y7991_pgtype5[] = {0xFFF9,1,1186,1401,0xFFFF};
static EIF_TYPE_INDEX Y7991_pgtype6[] = {0xFFF9,1,1186,1346,0xFFFF};
static EIF_TYPE_INDEX Y7991_pgtype7[] = {0xFFF9,1,1186,1154,0xFFFF};
static EIF_TYPE_INDEX Y7991_pgtype8[] = {0xFFF9,1,1186,1265,0xFFFF};
static EIF_TYPE_INDEX Y7991_pgtype9[] = {0xFFF9,1,1186,1486,0xFFFF};
static EIF_TYPE_INDEX Y7991_pgtype10[] = {0xFFF9,1,1186,1394,0xFFFF};
static EIF_TYPE_INDEX Y7991_pgtype11[] = {0xFFF9,1,1186,1393,0xFFFF};
static EIF_TYPE_INDEX Y7991_pgtype12[] = {0xFFF9,1,1186,1241,0xFFFF};
static EIF_TYPE_INDEX Y7991_pgtype13[] = {0xFFF9,1,1186,1486,0xFFFF};
static EIF_TYPE_INDEX Y7991_pgtype14[] = {0xFFF9,1,1186,1714,0xFFFF};
static EIF_TYPE_INDEX Y7991_pgtype15[] = {0xFFF9,5,1186,1498,1486,1486,1486,1486,0xFFFF};
static EIF_TYPE_INDEX Y7991_pgtype16[] = {0xFFF9,7,1186,1486,1486,1510,1510,1510,1486,1486,0xFFFF};
static EIF_TYPE_INDEX Y7991_pgtype17[] = {0xFFF9,2,1186,1486,1486,0xFFFF};
static EIF_TYPE_INDEX Y7991_pgtype18[] = {0xFFF9,4,1186,1486,1486,1486,1486,0xFFFF};
static EIF_TYPE_INDEX Y7991_pgtype19[] = {0xFFF9,3,1186,1486,1486,1154,0xFFFF};
static EIF_TYPE_INDEX Y7991_pgtype20[] = {0xFFF9,8,1186,1486,1486,1486,1510,1510,1510,1486,1486,0xFFFF};
static EIF_TYPE_INDEX Y7991_pgtype21[] = {0xFFF9,0,1186,0xFFFF};
EIF_TYPE_INDEX *Y7991_gen_type [22];
EIF_TYPE_INDEX Y7991 [22];
void Y7991_init (void)
{
	egc_routines_types [7991] = Y7991;
	egc_routines_gen_types [7991] = Y7991_gen_type;
	egc_routines_offset [7991] = 915;
	Y7991_gen_type [0] = Y7991_pgtype0;
	Y7991_gen_type [1] = Y7991_pgtype1;
	Y7991_gen_type [2] = Y7991_pgtype2;
	Y7991_gen_type [3] = Y7991_pgtype3;
	Y7991_gen_type [4] = Y7991_pgtype4;
	Y7991_gen_type [5] = Y7991_pgtype5;
	Y7991_gen_type [6] = Y7991_pgtype6;
	Y7991_gen_type [7] = Y7991_pgtype7;
	Y7991_gen_type [8] = Y7991_pgtype8;
	Y7991_gen_type [9] = Y7991_pgtype9;
	Y7991_gen_type [10] = Y7991_pgtype10;
	Y7991_gen_type [11] = Y7991_pgtype11;
	Y7991_gen_type [12] = Y7991_pgtype12;
	Y7991_gen_type [13] = Y7991_pgtype13;
	Y7991_gen_type [14] = Y7991_pgtype14;
	Y7991_gen_type [15] = Y7991_pgtype15;
	Y7991_gen_type [16] = Y7991_pgtype16;
	Y7991_gen_type [17] = Y7991_pgtype17;
	Y7991_gen_type [18] = Y7991_pgtype18;
	Y7991_gen_type [19] = Y7991_pgtype19;
	Y7991_gen_type [20] = Y7991_pgtype20;
	Y7991_gen_type [21] = Y7991_pgtype21;
	Y7991[2] = 1186;
	{long i; for (i = 4; i < 22; i++) Y7991[i] = 1186;};
}

char *(*R8020[12])();
void R8020_init () {
	R8020[0] = (char *(*)()) F938_9012;
	R8020[1] = (char *(*)()) F939_9012;
	R8020[2] = (char *(*)()) F940_9012;
	R8020[3] = (char *(*)()) F941_9012;
	R8020[4] = (char *(*)()) F942_9012;
	R8020[5] = (char *(*)()) F943_9012;
	R8020[6] = (char *(*)()) F944_9012;
	R8020[7] = (char *(*)()) F945_9012;
	R8020[8] = (char *(*)()) F946_9012;
	R8020[9] = (char *(*)()) F947_9012;
	R8020[10] = (char *(*)()) F948_9012;
	R8020[11] = (char *(*)()) F949_9012;
}

char *(*R8044[12])();
void R8044_init () {
	R8044[0] = (char *(*)()) F938_9054;
	R8044[1] = (char *(*)()) F939_9054_8044_20;
	R8044[2] = (char *(*)()) F940_9054_8044_20;
	R8044[3] = (char *(*)()) F941_9054_8044_20;
	R8044[4] = (char *(*)()) F942_9054_8044_20;
	R8044[5] = (char *(*)()) F943_9054_8044_20;
	R8044[6] = (char *(*)()) F944_9054_8044_20;
	R8044[7] = (char *(*)()) F945_9054_8044_20;
	R8044[8] = (char *(*)()) F946_9054_8044_20;
	R8044[9] = (char *(*)()) F947_9054_8044_20;
	R8044[10] = (char *(*)()) F948_9054_8044_20;
	R8044[11] = (char *(*)()) F949_9054_8044_20;
}
static void F939_9054_8044_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F939_9054(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F940_9054_8044_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F940_9054(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F941_9054_8044_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F941_9054(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F942_9054_8044_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F942_9054(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F943_9054_8044_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F943_9054(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F944_9054_8044_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F944_9054(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F945_9054_8044_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F945_9054(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F946_9054_8044_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F946_9054(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F947_9054_8044_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F947_9054(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F948_9054_8044_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F948_9054(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F949_9054_8044_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F949_9054(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R8051[12])();
void R8051_init () {
	R8051[0] = (char *(*)()) F938_9066;
	R8051[1] = (char *(*)()) F939_9066;
	R8051[2] = (char *(*)()) F940_9066;
	R8051[3] = (char *(*)()) F941_9066;
	R8051[4] = (char *(*)()) F942_9066;
	R8051[5] = (char *(*)()) F943_9066;
	R8051[6] = (char *(*)()) F944_9066;
	R8051[7] = (char *(*)()) F945_9066;
	R8051[8] = (char *(*)()) F946_9066;
	R8051[9] = (char *(*)()) F947_9066;
	R8051[10] = (char *(*)()) F948_9066;
	R8051[11] = (char *(*)()) F949_9066;
}

char *(*R8077[173])();
void R8077_init () {
	R8077[0] = (char *(*)()) F968_9094;
	R8077[2] = (char *(*)()) F723_8319_8077_1;
	R8077[3] = (char *(*)()) F971_9129;
	R8077[4] = (char *(*)()) F972_9129_8077_1;
	R8077[5] = (char *(*)()) F973_9129_8077_1;
	R8077[6] = (char *(*)()) F974_9135;
	R8077[9] = (char *(*)()) F723_8319_8077_1;
	R8077[43] = (char *(*)()) F999_9201;
	R8077[44] = (char *(*)()) F1000_9201_8077_1;
	R8077[45] = (char *(*)()) F1001_9201_8077_1;
	R8077[46] = (char *(*)()) F1002_9201_8077_1;
	R8077[47] = (char *(*)()) F1003_9201_8077_1;
	R8077[48] = (char *(*)()) F1004_9201_8077_1;
	R8077[49] = (char *(*)()) F1005_9201_8077_1;
	R8077[50] = (char *(*)()) F1006_9201_8077_1;
	R8077[51] = (char *(*)()) F1007_9201_8077_1;
	R8077[52] = (char *(*)()) F1008_9201_8077_1;
	R8077[53] = (char *(*)()) F1009_9201_8077_1;
	R8077[54] = (char *(*)()) F1010_9201_8077_1;
	R8077[55] = (char *(*)()) F1023_9229;
	R8077[56] = (char *(*)()) F1024_9229_8077_1;
	R8077[57] = (char *(*)()) F1025_9229;
	R8077[58] = (char *(*)()) F1026_9229_8077_1;
	R8077[59] = (char *(*)()) F1027_9229_8077_1;
	R8077[60] = (char *(*)()) F1028_9229_8077_1;
	R8077[61] = (char *(*)()) F1029_9229_8077_1;
	R8077[62] = (char *(*)()) F1030_9229_8077_1;
	R8077[63] = (char *(*)()) F1031_9229_8077_1;
	R8077[64] = (char *(*)()) F1032_9235;
	R8077[65] = (char *(*)()) F1033_9235_8077_1;
	R8077[66] = (char *(*)()) F1034_9235_8077_1;
	R8077[67] = (char *(*)()) F1035_9241;
	R8077[80] = (char *(*)()) F1036_9247;
	R8077[81] = (char *(*)()) F1037_9247_8077_1;
	R8077[82] = (char *(*)()) F1038_9247_8077_1;
	R8077[83] = (char *(*)()) F1039_9247_8077_1;
	R8077[84] = (char *(*)()) F1040_9247_8077_1;
	R8077[85] = (char *(*)()) F1041_9247_8077_1;
	R8077[86] = (char *(*)()) F1042_9247_8077_1;
	R8077[87] = (char *(*)()) F1043_9247_8077_1;
	R8077[88] = (char *(*)()) F1044_9247_8077_1;
	R8077[89] = (char *(*)()) F1045_9247_8077_1;
	R8077[90] = (char *(*)()) F1046_9247_8077_1;
	R8077[91] = (char *(*)()) F1047_9247_8077_1;
	R8077[92] = (char *(*)()) F1044_9247_8077_1;
	R8077[93] = (char *(*)()) F1043_9247_8077_1;
	R8077[94] = (char *(*)()) F1036_9247;
	R8077[95] = (char *(*)()) F1037_9247_8077_1;
	R8077[96] = (char *(*)()) F1038_9247_8077_1;
	R8077[97] = (char *(*)()) F1039_9247_8077_1;
	R8077[98] = (char *(*)()) F1040_9247_8077_1;
	R8077[99] = (char *(*)()) F1041_9247_8077_1;
	R8077[100] = (char *(*)()) F1042_9247_8077_1;
	R8077[101] = (char *(*)()) F1043_9247_8077_1;
	R8077[102] = (char *(*)()) F1044_9247_8077_1;
	R8077[103] = (char *(*)()) F1045_9247_8077_1;
	R8077[104] = (char *(*)()) F1046_9247_8077_1;
	R8077[105] = (char *(*)()) F1047_9247_8077_1;
	R8077[106] = (char *(*)()) F1036_9247;
	R8077[107] = (char *(*)()) F1037_9247_8077_1;
	R8077[108] = (char *(*)()) F1038_9247_8077_1;
	R8077[109] = (char *(*)()) F1039_9247_8077_1;
	R8077[110] = (char *(*)()) F1040_9247_8077_1;
	R8077[111] = (char *(*)()) F1041_9247_8077_1;
	R8077[112] = (char *(*)()) F1042_9247_8077_1;
	R8077[113] = (char *(*)()) F1043_9247_8077_1;
	R8077[114] = (char *(*)()) F1044_9247_8077_1;
	R8077[115] = (char *(*)()) F1045_9247_8077_1;
	R8077[116] = (char *(*)()) F1046_9247_8077_1;
	R8077[117] = (char *(*)()) F1047_9247_8077_1;
	R8077[172] = (char *(*)()) F1140_9688_8077_1;
}
static EIF_REFERENCE F723_8319_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F723_8319(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F972_9129_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F972_9129(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F973_9129_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F973_9129(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1000_9201_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1000_9201(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1192, 0x00).id, 1192, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1001_9201_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1001_9201(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1498, 0x00).id, 1498, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1002_9201_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1002_9201(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1495, 0x00).id, 1495, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1003_9201_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1003_9201(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1004_9201_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F1004_9201(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1504, 0x00).id, 1504, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1005_9201_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1005_9201(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1006_9201_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1006_9201(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1195, 0x00).id, 1195, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1007_9201_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1007_9201(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1008_9201_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F1008_9201(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1501, 0x00).id, 1501, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1009_9201_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1009_9201(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1507, 0x00).id, 1507, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1010_9201_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1010_9201(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1510, 0x00).id, 1510, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1024_9229_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1024_9229(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1498, 0x00).id, 1498, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1026_9229_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1026_9229(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1027_9229_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1027_9229(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1028_9229_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1028_9229(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1029_9229_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1029_9229(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1030_9229_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F1030_9229(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1504, 0x00).id, 1504, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1031_9229_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1031_9229(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1195, 0x00).id, 1195, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1033_9235_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1033_9235(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1034_9235_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1034_9235(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1195, 0x00).id, 1195, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1037_9247_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1037_9247(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1498, 0x00).id, 1498, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1038_9247_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1038_9247(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1495, 0x00).id, 1495, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1039_9247_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1039_9247(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1040_9247_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F1040_9247(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1504, 0x00).id, 1504, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1041_9247_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1041_9247(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1195, 0x00).id, 1195, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1042_9247_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1042_9247(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1228, 0x00).id, 1228, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1043_9247_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1043_9247(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1192, 0x00).id, 1192, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1044_9247_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1044_9247(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1045_9247_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F1045_9247(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(1501, 0x00).id, 1501, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1046_9247_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1046_9247(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1507, 0x00).id, 1507, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1047_9247_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F1047_9247(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(1510, 0x00).id, 1510, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1140_9688_8077_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1140_9688(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1192, 0x00).id, 1192, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R8078[173])();
void R8078_init () {
	R8078[0] = (char *(*)()) F968_9095;
	R8078[2] = (char *(*)()) F723_8320;
	R8078[3] = (char *(*)()) F971_9130;
	R8078[4] = (char *(*)()) F972_9130;
	R8078[5] = (char *(*)()) F973_9130;
	R8078[6] = (char *(*)()) F974_9136;
	R8078[9] = (char *(*)()) F723_8320;
	R8078[43] = (char *(*)()) F1011_9219;
	R8078[44] = (char *(*)()) F1012_9219;
	R8078[45] = (char *(*)()) F1013_9219;
	R8078[46] = (char *(*)()) F1014_9219;
	R8078[47] = (char *(*)()) F1015_9219;
	R8078[48] = (char *(*)()) F1016_9219;
	R8078[49] = (char *(*)()) F1017_9219;
	R8078[50] = (char *(*)()) F1018_9219;
	R8078[51] = (char *(*)()) F1019_9219;
	R8078[52] = (char *(*)()) F1020_9219;
	R8078[53] = (char *(*)()) F1021_9219;
	R8078[54] = (char *(*)()) F1022_9219;
	R8078[55] = (char *(*)()) F1023_9232;
	R8078[56] = (char *(*)()) F1024_9232;
	R8078[57] = (char *(*)()) F1025_9232;
	R8078[58] = (char *(*)()) F1026_9232;
	R8078[59] = (char *(*)()) F1027_9232;
	R8078[60] = (char *(*)()) F1028_9232;
	R8078[61] = (char *(*)()) F1029_9232;
	R8078[62] = (char *(*)()) F1030_9232;
	R8078[63] = (char *(*)()) F1031_9232;
	R8078[64] = (char *(*)()) F1032_9236;
	R8078[65] = (char *(*)()) F1033_9236;
	R8078[66] = (char *(*)()) F1034_9236;
	R8078[67] = (char *(*)()) F1035_9242;
	R8078[80] = (char *(*)()) F1036_9256;
	R8078[81] = (char *(*)()) F1037_9256;
	R8078[82] = (char *(*)()) F1038_9256;
	R8078[83] = (char *(*)()) F1039_9256;
	R8078[84] = (char *(*)()) F1040_9256;
	R8078[85] = (char *(*)()) F1041_9256;
	R8078[86] = (char *(*)()) F1042_9256;
	R8078[87] = (char *(*)()) F1043_9256;
	R8078[88] = (char *(*)()) F1044_9256;
	R8078[89] = (char *(*)()) F1045_9256;
	R8078[90] = (char *(*)()) F1046_9256;
	R8078[91] = (char *(*)()) F1047_9256;
	R8078[92] = (char *(*)()) F1044_9256;
	R8078[93] = (char *(*)()) F1043_9256;
	R8078[94] = (char *(*)()) F1036_9256;
	R8078[95] = (char *(*)()) F1037_9256;
	R8078[96] = (char *(*)()) F1038_9256;
	R8078[97] = (char *(*)()) F1039_9256;
	R8078[98] = (char *(*)()) F1040_9256;
	R8078[99] = (char *(*)()) F1041_9256;
	R8078[100] = (char *(*)()) F1042_9256;
	R8078[101] = (char *(*)()) F1043_9256;
	R8078[102] = (char *(*)()) F1044_9256;
	R8078[103] = (char *(*)()) F1045_9256;
	R8078[104] = (char *(*)()) F1046_9256;
	R8078[105] = (char *(*)()) F1047_9256;
	R8078[106] = (char *(*)()) F1036_9256;
	R8078[107] = (char *(*)()) F1037_9256;
	R8078[108] = (char *(*)()) F1038_9256;
	R8078[109] = (char *(*)()) F1039_9256;
	R8078[110] = (char *(*)()) F1040_9256;
	R8078[111] = (char *(*)()) F1041_9256;
	R8078[112] = (char *(*)()) F1042_9256;
	R8078[113] = (char *(*)()) F1043_9256;
	R8078[114] = (char *(*)()) F1044_9256;
	R8078[115] = (char *(*)()) F1045_9256;
	R8078[116] = (char *(*)()) F1046_9256;
	R8078[117] = (char *(*)()) F1047_9256;
	R8078[172] = (char *(*)()) F1140_9690;
}

char *(*R8079[173])();
void R8079_init () {
	R8079[0] = (char *(*)()) F968_9096;
	R8079[2] = (char *(*)()) F723_8326;
	R8079[3] = (char *(*)()) F971_9131;
	R8079[4] = (char *(*)()) F972_9131;
	R8079[5] = (char *(*)()) F973_9131;
	R8079[6] = (char *(*)()) F974_9137;
	R8079[9] = (char *(*)()) F723_8326;
	R8079[43] = (char *(*)()) F1011_9227;
	R8079[44] = (char *(*)()) F1012_9227;
	R8079[45] = (char *(*)()) F1013_9227;
	R8079[46] = (char *(*)()) F1014_9227;
	R8079[47] = (char *(*)()) F1015_9227;
	R8079[48] = (char *(*)()) F1016_9227;
	R8079[49] = (char *(*)()) F1017_9227;
	R8079[50] = (char *(*)()) F1018_9227;
	R8079[51] = (char *(*)()) F1019_9227;
	R8079[52] = (char *(*)()) F1020_9227;
	R8079[53] = (char *(*)()) F1021_9227;
	R8079[54] = (char *(*)()) F1022_9227;
	R8079[55] = (char *(*)()) F1023_9233;
	R8079[56] = (char *(*)()) F1024_9233;
	R8079[57] = (char *(*)()) F1025_9233;
	R8079[58] = (char *(*)()) F1026_9233;
	R8079[59] = (char *(*)()) F1027_9233;
	R8079[60] = (char *(*)()) F1028_9233;
	R8079[61] = (char *(*)()) F1029_9233;
	R8079[62] = (char *(*)()) F1030_9233;
	R8079[63] = (char *(*)()) F1031_9233;
	R8079[64] = (char *(*)()) F1032_9238;
	R8079[65] = (char *(*)()) F1033_9238;
	R8079[66] = (char *(*)()) F1034_9238;
	R8079[67] = (char *(*)()) F1035_9244;
	R8079[80] = (char *(*)()) F1036_9262;
	R8079[81] = (char *(*)()) F1037_9262;
	R8079[82] = (char *(*)()) F1038_9262;
	R8079[83] = (char *(*)()) F1039_9262;
	R8079[84] = (char *(*)()) F1040_9262;
	R8079[85] = (char *(*)()) F1041_9262;
	R8079[86] = (char *(*)()) F1042_9262;
	R8079[87] = (char *(*)()) F1043_9262;
	R8079[88] = (char *(*)()) F1044_9262;
	R8079[89] = (char *(*)()) F1045_9262;
	R8079[90] = (char *(*)()) F1046_9262;
	R8079[91] = (char *(*)()) F1047_9262;
	R8079[92] = (char *(*)()) F1044_9262;
	R8079[93] = (char *(*)()) F1043_9262;
	R8079[94] = (char *(*)()) F1036_9262;
	R8079[95] = (char *(*)()) F1037_9262;
	R8079[96] = (char *(*)()) F1038_9262;
	R8079[97] = (char *(*)()) F1039_9262;
	R8079[98] = (char *(*)()) F1040_9262;
	R8079[99] = (char *(*)()) F1041_9262;
	R8079[100] = (char *(*)()) F1042_9262;
	R8079[101] = (char *(*)()) F1043_9262;
	R8079[102] = (char *(*)()) F1044_9262;
	R8079[103] = (char *(*)()) F1045_9262;
	R8079[104] = (char *(*)()) F1046_9262;
	R8079[105] = (char *(*)()) F1047_9262;
	R8079[106] = (char *(*)()) F1036_9262;
	R8079[107] = (char *(*)()) F1037_9262;
	R8079[108] = (char *(*)()) F1038_9262;
	R8079[109] = (char *(*)()) F1039_9262;
	R8079[110] = (char *(*)()) F1040_9262;
	R8079[111] = (char *(*)()) F1041_9262;
	R8079[112] = (char *(*)()) F1042_9262;
	R8079[113] = (char *(*)()) F1043_9262;
	R8079[114] = (char *(*)()) F1044_9262;
	R8079[115] = (char *(*)()) F1045_9262;
	R8079[116] = (char *(*)()) F1046_9262;
	R8079[117] = (char *(*)()) F1047_9262;
	R8079[172] = (char *(*)()) F1140_9691;
}

static EIF_TYPE_INDEX Y8080_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype14[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype19[] = {50,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype20[] = {1189,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype21[] = {1486,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype104[] = {1189,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype105[] = {1192,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype123[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype124[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype125[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype126[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype127[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype128[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype129[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8080_pgtype130[] = {1192,0xFFFF};
EIF_TYPE_INDEX *Y8080_gen_type [185];
EIF_TYPE_INDEX Y8080 [185];
void Y8080_init (void)
{
	egc_routines_types [8080] = Y8080;
	egc_routines_gen_types [8080] = Y8080_gen_type;
	egc_routines_offset [8080] = 955;
	Y8080_gen_type [0] = Y8080_pgtype0;
	Y8080_gen_type [1] = Y8080_pgtype1;
	Y8080_gen_type [2] = Y8080_pgtype2;
	Y8080_gen_type [3] = Y8080_pgtype3;
	Y8080_gen_type [4] = Y8080_pgtype4;
	Y8080_gen_type [5] = Y8080_pgtype5;
	Y8080_gen_type [6] = Y8080_pgtype6;
	Y8080_gen_type [7] = Y8080_pgtype7;
	Y8080_gen_type [8] = Y8080_pgtype8;
	Y8080_gen_type [9] = Y8080_pgtype9;
	Y8080_gen_type [10] = Y8080_pgtype10;
	Y8080_gen_type [11] = Y8080_pgtype11;
	Y8080_gen_type [12] = Y8080_pgtype12;
	Y8080_gen_type [13] = Y8080_pgtype13;
	Y8080_gen_type [14] = Y8080_pgtype14;
	Y8080_gen_type [15] = Y8080_pgtype15;
	Y8080_gen_type [16] = Y8080_pgtype16;
	Y8080_gen_type [17] = Y8080_pgtype17;
	Y8080_gen_type [18] = Y8080_pgtype18;
	Y8080_gen_type [19] = Y8080_pgtype19;
	Y8080_gen_type [20] = Y8080_pgtype20;
	Y8080_gen_type [21] = Y8080_pgtype21;
	Y8080_gen_type [22] = Y8080_pgtype22;
	Y8080_gen_type [23] = Y8080_pgtype23;
	Y8080_gen_type [24] = Y8080_pgtype24;
	Y8080_gen_type [25] = Y8080_pgtype25;
	Y8080_gen_type [26] = Y8080_pgtype26;
	Y8080_gen_type [27] = Y8080_pgtype27;
	Y8080_gen_type [28] = Y8080_pgtype28;
	Y8080_gen_type [29] = Y8080_pgtype29;
	Y8080_gen_type [30] = Y8080_pgtype30;
	Y8080_gen_type [31] = Y8080_pgtype31;
	Y8080_gen_type [32] = Y8080_pgtype32;
	Y8080_gen_type [33] = Y8080_pgtype33;
	Y8080_gen_type [34] = Y8080_pgtype34;
	Y8080_gen_type [35] = Y8080_pgtype35;
	Y8080_gen_type [36] = Y8080_pgtype36;
	Y8080_gen_type [37] = Y8080_pgtype37;
	Y8080_gen_type [38] = Y8080_pgtype38;
	Y8080_gen_type [39] = Y8080_pgtype39;
	Y8080_gen_type [40] = Y8080_pgtype40;
	Y8080_gen_type [41] = Y8080_pgtype41;
	Y8080_gen_type [42] = Y8080_pgtype42;
	Y8080_gen_type [43] = Y8080_pgtype43;
	Y8080_gen_type [44] = Y8080_pgtype44;
	Y8080_gen_type [45] = Y8080_pgtype45;
	Y8080_gen_type [46] = Y8080_pgtype46;
	Y8080_gen_type [47] = Y8080_pgtype47;
	Y8080_gen_type [48] = Y8080_pgtype48;
	Y8080_gen_type [49] = Y8080_pgtype49;
	Y8080_gen_type [50] = Y8080_pgtype50;
	Y8080_gen_type [51] = Y8080_pgtype51;
	Y8080_gen_type [52] = Y8080_pgtype52;
	Y8080_gen_type [53] = Y8080_pgtype53;
	Y8080_gen_type [54] = Y8080_pgtype54;
	Y8080_gen_type [55] = Y8080_pgtype55;
	Y8080_gen_type [56] = Y8080_pgtype56;
	Y8080_gen_type [57] = Y8080_pgtype57;
	Y8080_gen_type [58] = Y8080_pgtype58;
	Y8080_gen_type [59] = Y8080_pgtype59;
	Y8080_gen_type [60] = Y8080_pgtype60;
	Y8080_gen_type [61] = Y8080_pgtype61;
	Y8080_gen_type [62] = Y8080_pgtype62;
	Y8080_gen_type [63] = Y8080_pgtype63;
	Y8080_gen_type [64] = Y8080_pgtype64;
	Y8080_gen_type [65] = Y8080_pgtype65;
	Y8080_gen_type [66] = Y8080_pgtype66;
	Y8080_gen_type [67] = Y8080_pgtype67;
	Y8080_gen_type [68] = Y8080_pgtype68;
	Y8080_gen_type [69] = Y8080_pgtype69;
	Y8080_gen_type [70] = Y8080_pgtype70;
	Y8080_gen_type [71] = Y8080_pgtype71;
	Y8080_gen_type [72] = Y8080_pgtype72;
	Y8080_gen_type [73] = Y8080_pgtype73;
	Y8080_gen_type [74] = Y8080_pgtype74;
	Y8080_gen_type [75] = Y8080_pgtype75;
	Y8080_gen_type [76] = Y8080_pgtype76;
	Y8080_gen_type [77] = Y8080_pgtype77;
	Y8080_gen_type [78] = Y8080_pgtype78;
	Y8080_gen_type [79] = Y8080_pgtype79;
	Y8080_gen_type [80] = Y8080_pgtype80;
	Y8080_gen_type [81] = Y8080_pgtype81;
	Y8080_gen_type [82] = Y8080_pgtype82;
	Y8080_gen_type [83] = Y8080_pgtype83;
	Y8080_gen_type [84] = Y8080_pgtype84;
	Y8080_gen_type [85] = Y8080_pgtype85;
	Y8080_gen_type [86] = Y8080_pgtype86;
	Y8080_gen_type [87] = Y8080_pgtype87;
	Y8080_gen_type [88] = Y8080_pgtype88;
	Y8080_gen_type [89] = Y8080_pgtype89;
	Y8080_gen_type [90] = Y8080_pgtype90;
	Y8080_gen_type [91] = Y8080_pgtype91;
	Y8080_gen_type [92] = Y8080_pgtype92;
	Y8080_gen_type [93] = Y8080_pgtype93;
	Y8080_gen_type [94] = Y8080_pgtype94;
	Y8080_gen_type [95] = Y8080_pgtype95;
	Y8080_gen_type [96] = Y8080_pgtype96;
	Y8080_gen_type [97] = Y8080_pgtype97;
	Y8080_gen_type [98] = Y8080_pgtype98;
	Y8080_gen_type [99] = Y8080_pgtype99;
	Y8080_gen_type [100] = Y8080_pgtype100;
	Y8080_gen_type [101] = Y8080_pgtype101;
	Y8080_gen_type [102] = Y8080_pgtype102;
	Y8080_gen_type [103] = Y8080_pgtype103;
	Y8080_gen_type [104] = Y8080_pgtype104;
	Y8080_gen_type [105] = Y8080_pgtype105;
	Y8080_gen_type [106] = Y8080_pgtype106;
	Y8080_gen_type [107] = Y8080_pgtype107;
	Y8080_gen_type [108] = Y8080_pgtype108;
	Y8080_gen_type [109] = Y8080_pgtype109;
	Y8080_gen_type [110] = Y8080_pgtype110;
	Y8080_gen_type [111] = Y8080_pgtype111;
	Y8080_gen_type [112] = Y8080_pgtype112;
	Y8080_gen_type [113] = Y8080_pgtype113;
	Y8080_gen_type [114] = Y8080_pgtype114;
	Y8080_gen_type [115] = Y8080_pgtype115;
	Y8080_gen_type [116] = Y8080_pgtype116;
	Y8080_gen_type [117] = Y8080_pgtype117;
	Y8080_gen_type [118] = Y8080_pgtype118;
	Y8080_gen_type [119] = Y8080_pgtype119;
	Y8080_gen_type [120] = Y8080_pgtype120;
	Y8080_gen_type [121] = Y8080_pgtype121;
	Y8080_gen_type [122] = Y8080_pgtype122;
	Y8080_gen_type [123] = Y8080_pgtype123;
	Y8080_gen_type [124] = Y8080_pgtype124;
	Y8080_gen_type [125] = Y8080_pgtype125;
	Y8080_gen_type [126] = Y8080_pgtype126;
	Y8080_gen_type [127] = Y8080_pgtype127;
	Y8080_gen_type [128] = Y8080_pgtype128;
	Y8080_gen_type [129] = Y8080_pgtype129;
	Y8080_gen_type [184] = Y8080_pgtype130;
	Y8080[14] = 1486;
	Y8080[19] = 50;
	Y8080[20] = 1189;
	Y8080[21] = 1486;
	Y8080[104] = 1189;
	Y8080[105] = 1192;
	Y8080[184] = 1192;
}

char *(*R8107[3])();
void R8107_init () {
	R8107[0] = (char *(*)()) F971_9128;
	R8107[1] = (char *(*)()) F972_9128;
	R8107[2] = (char *(*)()) F973_9128;
}

char *(*R8140[9])();
void R8140_init () {
	R8140[0] = (char *(*)()) F1023_9230;
	R8140[1] = (char *(*)()) F1024_9230;
	R8140[2] = (char *(*)()) F1025_9230_8140_1;
	R8140[3] = (char *(*)()) F1026_9230;
	R8140[4] = (char *(*)()) F1027_9230_8140_1;
	R8140[5] = (char *(*)()) F1028_9230_8140_1;
	R8140[6] = (char *(*)()) F1029_9230;
	R8140[7] = (char *(*)()) F1030_9230;
	R8140[8] = (char *(*)()) F1031_9230;
}
static EIF_REFERENCE F1025_9230_8140_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1025_9230(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1027_9230_8140_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1027_9230(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1028_9230_8140_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1028_9230(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(1498, 0x00).id, 1498, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}

char *(*R8143[75])();
void R8143_init () {
	R8143[0] = (char *(*)()) F1011_9209;
	R8143[1] = (char *(*)()) F1012_9209;
	R8143[2] = (char *(*)()) F1013_9209;
	R8143[3] = (char *(*)()) F1014_9209;
	R8143[4] = (char *(*)()) F1015_9209;
	R8143[5] = (char *(*)()) F1016_9209;
	R8143[6] = (char *(*)()) F1017_9209;
	R8143[7] = (char *(*)()) F1018_9209;
	R8143[8] = (char *(*)()) F1019_9209;
	R8143[9] = (char *(*)()) F1020_9209;
	R8143[10] = (char *(*)()) F1021_9209;
	R8143[11] = (char *(*)()) F1022_9209;
	R8143[12] = (char *(*)()) F1011_9209;
	R8143[13] = (char *(*)()) F1013_9209;
	R8143[14] = (char *(*)()) F1011_9209;
	{long i; for (i = 15; i < 18; i++) R8143[i] = (char *(*)()) F1015_9209;}
	R8143[18] = (char *(*)()) F1019_9209;
	R8143[19] = (char *(*)()) F1016_9209;
	R8143[20] = (char *(*)()) F1018_9209;
	R8143[21] = (char *(*)()) F1011_9209;
	R8143[22] = (char *(*)()) F1015_9209;
	R8143[23] = (char *(*)()) F1018_9209;
	R8143[24] = (char *(*)()) F1011_9209;
	R8143[37] = (char *(*)()) F1036_9249;
	R8143[38] = (char *(*)()) F1037_9249;
	R8143[39] = (char *(*)()) F1038_9249;
	R8143[40] = (char *(*)()) F1039_9249;
	R8143[41] = (char *(*)()) F1040_9249;
	R8143[42] = (char *(*)()) F1041_9249;
	R8143[43] = (char *(*)()) F1042_9249;
	R8143[44] = (char *(*)()) F1043_9249;
	R8143[45] = (char *(*)()) F1044_9249;
	R8143[46] = (char *(*)()) F1045_9249;
	R8143[47] = (char *(*)()) F1046_9249;
	R8143[48] = (char *(*)()) F1047_9249;
	R8143[49] = (char *(*)()) F1044_9249;
	R8143[50] = (char *(*)()) F1043_9249;
	R8143[51] = (char *(*)()) F1036_9249;
	R8143[52] = (char *(*)()) F1037_9249;
	R8143[53] = (char *(*)()) F1038_9249;
	R8143[54] = (char *(*)()) F1039_9249;
	R8143[55] = (char *(*)()) F1040_9249;
	R8143[56] = (char *(*)()) F1041_9249;
	R8143[57] = (char *(*)()) F1042_9249;
	R8143[58] = (char *(*)()) F1043_9249;
	R8143[59] = (char *(*)()) F1044_9249;
	R8143[60] = (char *(*)()) F1045_9249;
	R8143[61] = (char *(*)()) F1046_9249;
	R8143[62] = (char *(*)()) F1047_9249;
	R8143[63] = (char *(*)()) F1036_9249;
	R8143[64] = (char *(*)()) F1037_9249;
	R8143[65] = (char *(*)()) F1038_9249;
	R8143[66] = (char *(*)()) F1039_9249;
	R8143[67] = (char *(*)()) F1040_9249;
	R8143[68] = (char *(*)()) F1041_9249;
	R8143[69] = (char *(*)()) F1042_9249;
	R8143[70] = (char *(*)()) F1043_9249;
	R8143[71] = (char *(*)()) F1044_9249;
	R8143[72] = (char *(*)()) F1045_9249;
	R8143[73] = (char *(*)()) F1046_9249;
	R8143[74] = (char *(*)()) F1047_9249;
}

char *(*R8144[75])();
void R8144_init () {
	R8144[0] = (char *(*)()) F1011_9210;
	R8144[1] = (char *(*)()) F1012_9210;
	R8144[2] = (char *(*)()) F1013_9210;
	R8144[3] = (char *(*)()) F1014_9210;
	R8144[4] = (char *(*)()) F1015_9210;
	R8144[5] = (char *(*)()) F1016_9210;
	R8144[6] = (char *(*)()) F1017_9210;
	R8144[7] = (char *(*)()) F1018_9210;
	R8144[8] = (char *(*)()) F1019_9210;
	R8144[9] = (char *(*)()) F1020_9210;
	R8144[10] = (char *(*)()) F1021_9210;
	R8144[11] = (char *(*)()) F1022_9210;
	R8144[12] = (char *(*)()) F1011_9210;
	R8144[13] = (char *(*)()) F1013_9210;
	R8144[14] = (char *(*)()) F1011_9210;
	{long i; for (i = 15; i < 18; i++) R8144[i] = (char *(*)()) F1015_9210;}
	R8144[18] = (char *(*)()) F1019_9210;
	R8144[19] = (char *(*)()) F1016_9210;
	R8144[20] = (char *(*)()) F1018_9210;
	R8144[21] = (char *(*)()) F1011_9210;
	R8144[22] = (char *(*)()) F1015_9210;
	R8144[23] = (char *(*)()) F1018_9210;
	R8144[24] = (char *(*)()) F1011_9210;
	R8144[37] = (char *(*)()) F1048_9268;
	R8144[38] = (char *(*)()) F1049_9268;
	R8144[39] = (char *(*)()) F1050_9268;
	R8144[40] = (char *(*)()) F1051_9268;
	R8144[41] = (char *(*)()) F1052_9268;
	R8144[42] = (char *(*)()) F1053_9268;
	R8144[43] = (char *(*)()) F1054_9268;
	R8144[44] = (char *(*)()) F1055_9268;
	R8144[45] = (char *(*)()) F1056_9268;
	R8144[46] = (char *(*)()) F1057_9268;
	R8144[47] = (char *(*)()) F1058_9268;
	R8144[48] = (char *(*)()) F1059_9268;
	R8144[49] = (char *(*)()) F1060_9274;
	R8144[50] = (char *(*)()) F1061_9280;
	R8144[51] = (char *(*)()) F1062_9286;
	R8144[52] = (char *(*)()) F1063_9286;
	R8144[53] = (char *(*)()) F1064_9286;
	R8144[54] = (char *(*)()) F1065_9286;
	R8144[55] = (char *(*)()) F1066_9286;
	R8144[56] = (char *(*)()) F1067_9286;
	R8144[57] = (char *(*)()) F1068_9286;
	R8144[58] = (char *(*)()) F1069_9286;
	R8144[59] = (char *(*)()) F1070_9286;
	R8144[60] = (char *(*)()) F1071_9286;
	R8144[61] = (char *(*)()) F1072_9286;
	R8144[62] = (char *(*)()) F1073_9286;
	R8144[63] = (char *(*)()) F1074_9292;
	R8144[64] = (char *(*)()) F1075_9292;
	R8144[65] = (char *(*)()) F1076_9292;
	R8144[66] = (char *(*)()) F1077_9292;
	R8144[67] = (char *(*)()) F1078_9292;
	R8144[68] = (char *(*)()) F1079_9292;
	R8144[69] = (char *(*)()) F1080_9292;
	R8144[70] = (char *(*)()) F1081_9292;
	R8144[71] = (char *(*)()) F1082_9292;
	R8144[72] = (char *(*)()) F1083_9292;
	R8144[73] = (char *(*)()) F1084_9292;
	R8144[74] = (char *(*)()) F1085_9292;
}

char *(*R8152[25])();
void R8152_init () {
	R8152[0] = (char *(*)()) F1011_9221;
	R8152[1] = (char *(*)()) F1012_9221;
	R8152[2] = (char *(*)()) F1013_9221;
	R8152[3] = (char *(*)()) F1014_9221;
	R8152[4] = (char *(*)()) F1015_9221;
	R8152[5] = (char *(*)()) F1016_9221;
	R8152[6] = (char *(*)()) F1017_9221;
	R8152[7] = (char *(*)()) F1018_9221;
	R8152[8] = (char *(*)()) F1019_9221;
	R8152[9] = (char *(*)()) F1020_9221;
	R8152[10] = (char *(*)()) F1021_9221;
	R8152[11] = (char *(*)()) F1022_9221;
	R8152[12] = (char *(*)()) F1011_9221;
	R8152[13] = (char *(*)()) F1013_9221;
	R8152[14] = (char *(*)()) F1011_9221;
	{long i; for (i = 15; i < 18; i++) R8152[i] = (char *(*)()) F1015_9221;}
	R8152[18] = (char *(*)()) F1019_9221;
	R8152[19] = (char *(*)()) F1016_9221;
	R8152[20] = (char *(*)()) F1018_9221;
	R8152[21] = (char *(*)()) F1011_9221;
	R8152[22] = (char *(*)()) F1015_9221;
	R8152[23] = (char *(*)()) F1018_9221;
	R8152[24] = (char *(*)()) F1011_9221;
}

char *(*R8155[75])();
void R8155_init () {
	R8155[0] = (char *(*)()) F1011_9226;
	R8155[1] = (char *(*)()) F1012_9226;
	R8155[2] = (char *(*)()) F1013_9226;
	R8155[3] = (char *(*)()) F1014_9226;
	R8155[4] = (char *(*)()) F1015_9226;
	R8155[5] = (char *(*)()) F1016_9226;
	R8155[6] = (char *(*)()) F1017_9226;
	R8155[7] = (char *(*)()) F1018_9226;
	R8155[8] = (char *(*)()) F1019_9226;
	R8155[9] = (char *(*)()) F1020_9226;
	R8155[10] = (char *(*)()) F1021_9226;
	R8155[11] = (char *(*)()) F1022_9226;
	R8155[12] = (char *(*)()) F1011_9226;
	R8155[13] = (char *(*)()) F1013_9226;
	R8155[14] = (char *(*)()) F1011_9226;
	{long i; for (i = 15; i < 18; i++) R8155[i] = (char *(*)()) F1015_9226;}
	R8155[18] = (char *(*)()) F1019_9226;
	R8155[19] = (char *(*)()) F1016_9226;
	R8155[20] = (char *(*)()) F1018_9226;
	R8155[21] = (char *(*)()) F1032_9237;
	R8155[22] = (char *(*)()) F1033_9237;
	R8155[23] = (char *(*)()) F1034_9237;
	R8155[24] = (char *(*)()) F1035_9243;
	R8155[37] = (char *(*)()) F1036_9261;
	R8155[38] = (char *(*)()) F1037_9261;
	R8155[39] = (char *(*)()) F1038_9261;
	R8155[40] = (char *(*)()) F1039_9261;
	R8155[41] = (char *(*)()) F1040_9261;
	R8155[42] = (char *(*)()) F1041_9261;
	R8155[43] = (char *(*)()) F1042_9261;
	R8155[44] = (char *(*)()) F1043_9261;
	R8155[45] = (char *(*)()) F1044_9261;
	R8155[46] = (char *(*)()) F1045_9261;
	R8155[47] = (char *(*)()) F1046_9261;
	R8155[48] = (char *(*)()) F1047_9261;
	R8155[49] = (char *(*)()) F1044_9261;
	R8155[50] = (char *(*)()) F1043_9261;
	R8155[51] = (char *(*)()) F1036_9261;
	R8155[52] = (char *(*)()) F1037_9261;
	R8155[53] = (char *(*)()) F1038_9261;
	R8155[54] = (char *(*)()) F1039_9261;
	R8155[55] = (char *(*)()) F1040_9261;
	R8155[56] = (char *(*)()) F1041_9261;
	R8155[57] = (char *(*)()) F1042_9261;
	R8155[58] = (char *(*)()) F1043_9261;
	R8155[59] = (char *(*)()) F1044_9261;
	R8155[60] = (char *(*)()) F1045_9261;
	R8155[61] = (char *(*)()) F1046_9261;
	R8155[62] = (char *(*)()) F1047_9261;
	R8155[63] = (char *(*)()) F1036_9261;
	R8155[64] = (char *(*)()) F1037_9261;
	R8155[65] = (char *(*)()) F1038_9261;
	R8155[66] = (char *(*)()) F1039_9261;
	R8155[67] = (char *(*)()) F1040_9261;
	R8155[68] = (char *(*)()) F1041_9261;
	R8155[69] = (char *(*)()) F1042_9261;
	R8155[70] = (char *(*)()) F1043_9261;
	R8155[71] = (char *(*)()) F1044_9261;
	R8155[72] = (char *(*)()) F1045_9261;
	R8155[73] = (char *(*)()) F1046_9261;
	R8155[74] = (char *(*)()) F1047_9261;
}

char *(*R8156[75])();
void R8156_init () {
	R8156[0] = (char *(*)()) F1011_9228;
	R8156[1] = (char *(*)()) F1012_9228;
	R8156[2] = (char *(*)()) F1013_9228;
	R8156[3] = (char *(*)()) F1014_9228;
	R8156[4] = (char *(*)()) F1015_9228;
	R8156[5] = (char *(*)()) F1016_9228;
	R8156[6] = (char *(*)()) F1017_9228;
	R8156[7] = (char *(*)()) F1018_9228;
	R8156[8] = (char *(*)()) F1019_9228;
	R8156[9] = (char *(*)()) F1020_9228;
	R8156[10] = (char *(*)()) F1021_9228;
	R8156[11] = (char *(*)()) F1022_9228;
	R8156[12] = (char *(*)()) F1023_9234;
	R8156[13] = (char *(*)()) F1024_9234;
	R8156[14] = (char *(*)()) F1025_9234;
	R8156[15] = (char *(*)()) F1026_9234;
	R8156[16] = (char *(*)()) F1027_9234;
	R8156[17] = (char *(*)()) F1028_9234;
	R8156[18] = (char *(*)()) F1029_9234;
	R8156[19] = (char *(*)()) F1030_9234;
	R8156[20] = (char *(*)()) F1031_9234;
	R8156[21] = (char *(*)()) F1032_9239;
	R8156[22] = (char *(*)()) F1033_9239;
	R8156[23] = (char *(*)()) F1034_9239;
	R8156[24] = (char *(*)()) F1035_9245;
	R8156[37] = (char *(*)()) F1048_9271;
	R8156[38] = (char *(*)()) F1049_9271;
	R8156[39] = (char *(*)()) F1050_9271;
	R8156[40] = (char *(*)()) F1051_9271;
	R8156[41] = (char *(*)()) F1052_9271;
	R8156[42] = (char *(*)()) F1053_9271;
	R8156[43] = (char *(*)()) F1054_9271;
	R8156[44] = (char *(*)()) F1055_9271;
	R8156[45] = (char *(*)()) F1056_9271;
	R8156[46] = (char *(*)()) F1057_9271;
	R8156[47] = (char *(*)()) F1058_9271;
	R8156[48] = (char *(*)()) F1059_9271;
	R8156[49] = (char *(*)()) F1060_9277;
	R8156[50] = (char *(*)()) F1061_9283;
	R8156[51] = (char *(*)()) F1062_9289;
	R8156[52] = (char *(*)()) F1063_9289;
	R8156[53] = (char *(*)()) F1064_9289;
	R8156[54] = (char *(*)()) F1065_9289;
	R8156[55] = (char *(*)()) F1066_9289;
	R8156[56] = (char *(*)()) F1067_9289;
	R8156[57] = (char *(*)()) F1068_9289;
	R8156[58] = (char *(*)()) F1069_9289;
	R8156[59] = (char *(*)()) F1070_9289;
	R8156[60] = (char *(*)()) F1071_9289;
	R8156[61] = (char *(*)()) F1072_9289;
	R8156[62] = (char *(*)()) F1073_9289;
	R8156[63] = (char *(*)()) F1036_9263;
	R8156[64] = (char *(*)()) F1037_9263;
	R8156[65] = (char *(*)()) F1038_9263;
	R8156[66] = (char *(*)()) F1039_9263;
	R8156[67] = (char *(*)()) F1040_9263;
	R8156[68] = (char *(*)()) F1041_9263;
	R8156[69] = (char *(*)()) F1042_9263;
	R8156[70] = (char *(*)()) F1043_9263;
	R8156[71] = (char *(*)()) F1044_9263;
	R8156[72] = (char *(*)()) F1045_9263;
	R8156[73] = (char *(*)()) F1046_9263;
	R8156[74] = (char *(*)()) F1047_9263;
}

char *(*R8158[25])();
void R8158_init () {
	R8158[0] = (char *(*)()) F1011_9207;
	R8158[1] = (char *(*)()) F1012_9207;
	R8158[2] = (char *(*)()) F1013_9207;
	R8158[3] = (char *(*)()) F1014_9207;
	R8158[4] = (char *(*)()) F1015_9207;
	R8158[5] = (char *(*)()) F1016_9207;
	R8158[6] = (char *(*)()) F1017_9207;
	R8158[7] = (char *(*)()) F1018_9207;
	R8158[8] = (char *(*)()) F1019_9207;
	R8158[9] = (char *(*)()) F1020_9207;
	R8158[10] = (char *(*)()) F1021_9207;
	R8158[11] = (char *(*)()) F1022_9207;
	R8158[12] = (char *(*)()) F1011_9207;
	R8158[13] = (char *(*)()) F1013_9207;
	R8158[14] = (char *(*)()) F1011_9207;
	{long i; for (i = 15; i < 18; i++) R8158[i] = (char *(*)()) F1015_9207;}
	R8158[18] = (char *(*)()) F1019_9207;
	R8158[19] = (char *(*)()) F1016_9207;
	R8158[20] = (char *(*)()) F1018_9207;
	R8158[21] = (char *(*)()) F1011_9207;
	R8158[22] = (char *(*)()) F1015_9207;
	R8158[23] = (char *(*)()) F1018_9207;
	R8158[24] = (char *(*)()) F1011_9207;
}

char *(*R8171[38])();
void R8171_init () {
	R8171[0] = (char *(*)()) F1048_9272;
	R8171[1] = (char *(*)()) F1049_9272;
	R8171[2] = (char *(*)()) F1050_9272;
	R8171[3] = (char *(*)()) F1051_9272;
	R8171[4] = (char *(*)()) F1052_9272;
	R8171[5] = (char *(*)()) F1053_9272;
	R8171[6] = (char *(*)()) F1054_9272;
	R8171[7] = (char *(*)()) F1055_9272;
	R8171[8] = (char *(*)()) F1056_9272;
	R8171[9] = (char *(*)()) F1057_9272;
	R8171[10] = (char *(*)()) F1058_9272;
	R8171[11] = (char *(*)()) F1059_9272;
	R8171[12] = (char *(*)()) F1060_9278;
	R8171[13] = (char *(*)()) F1061_9284;
	R8171[14] = (char *(*)()) F1062_9290;
	R8171[15] = (char *(*)()) F1063_9290;
	R8171[16] = (char *(*)()) F1064_9290;
	R8171[17] = (char *(*)()) F1065_9290;
	R8171[18] = (char *(*)()) F1066_9290;
	R8171[19] = (char *(*)()) F1067_9290;
	R8171[20] = (char *(*)()) F1068_9290;
	R8171[21] = (char *(*)()) F1069_9290;
	R8171[22] = (char *(*)()) F1070_9290;
	R8171[23] = (char *(*)()) F1071_9290;
	R8171[24] = (char *(*)()) F1072_9290;
	R8171[25] = (char *(*)()) F1073_9290;
	R8171[26] = (char *(*)()) F1074_9294;
	R8171[27] = (char *(*)()) F1075_9294;
	R8171[28] = (char *(*)()) F1076_9294;
	R8171[29] = (char *(*)()) F1077_9294;
	R8171[30] = (char *(*)()) F1078_9294;
	R8171[31] = (char *(*)()) F1079_9294;
	R8171[32] = (char *(*)()) F1080_9294;
	R8171[33] = (char *(*)()) F1081_9294;
	R8171[34] = (char *(*)()) F1082_9294;
	R8171[35] = (char *(*)()) F1083_9294;
	R8171[36] = (char *(*)()) F1084_9294;
	R8171[37] = (char *(*)()) F1085_9294;
}

char *(*R8173[12])();
void R8173_init () {
	R8173[0] = (char *(*)()) F1048_9267;
	R8173[1] = (char *(*)()) F1049_9267;
	R8173[2] = (char *(*)()) F1050_9267;
	R8173[3] = (char *(*)()) F1051_9267;
	R8173[4] = (char *(*)()) F1052_9267;
	R8173[5] = (char *(*)()) F1053_9267;
	R8173[6] = (char *(*)()) F1054_9267;
	R8173[7] = (char *(*)()) F1055_9267;
	R8173[8] = (char *(*)()) F1056_9267;
	R8173[9] = (char *(*)()) F1057_9267;
	R8173[10] = (char *(*)()) F1058_9267;
	R8173[11] = (char *(*)()) F1059_9267;
}

char *(*R8181[12])();
void R8181_init () {
	R8181[0] = (char *(*)()) F1062_9285;
	R8181[1] = (char *(*)()) F1063_9285;
	R8181[2] = (char *(*)()) F1064_9285;
	R8181[3] = (char *(*)()) F1065_9285;
	R8181[4] = (char *(*)()) F1066_9285;
	R8181[5] = (char *(*)()) F1067_9285;
	R8181[6] = (char *(*)()) F1068_9285;
	R8181[7] = (char *(*)()) F1069_9285;
	R8181[8] = (char *(*)()) F1070_9285;
	R8181[9] = (char *(*)()) F1071_9285;
	R8181[10] = (char *(*)()) F1072_9285;
	R8181[11] = (char *(*)()) F1073_9285;
}

char *(*R8184[12])();
void R8184_init () {
	R8184[0] = (char *(*)()) F1074_9291;
	R8184[1] = (char *(*)()) F1075_9291;
	R8184[2] = (char *(*)()) F1076_9291;
	R8184[3] = (char *(*)()) F1077_9291;
	R8184[4] = (char *(*)()) F1078_9291;
	R8184[5] = (char *(*)()) F1079_9291;
	R8184[6] = (char *(*)()) F1080_9291;
	R8184[7] = (char *(*)()) F1081_9291;
	R8184[8] = (char *(*)()) F1082_9291;
	R8184[9] = (char *(*)()) F1083_9291;
	R8184[10] = (char *(*)()) F1084_9291;
	R8184[11] = (char *(*)()) F1085_9291;
}

char *(*R8213[12])();
void R8213_init () {
	R8213[0] = (char *(*)()) F1104_9366;
	R8213[1] = (char *(*)()) F1105_9372;
	R8213[2] = (char *(*)()) F1106_9376;
	R8213[3] = (char *(*)()) F1107_9381;
	R8213[4] = (char *(*)()) F1108_9390;
	{long i; for (i = 6; i < 9; i++) R8213[i] = (char *(*)()) F1108_9390;}
	R8213[10] = (char *(*)()) F1114_9409;
	R8213[11] = (char *(*)()) F1108_9390;
}

char *(*R8700[570])();
void R8700_init () {
	{long i; for (i = 0; i < 2; i++) R8700[i] = (char *(*)()) F1146_10077;}
	R8700[569] = (char *(*)()) F1716_18244;
}

char *(*R8708[572])();
void R8708_init () {
	R8708[0] = (char *(*)()) F1145_9958;
	{long i; for (i = 2; i < 4; i++) R8708[i] = (char *(*)()) F1146_10101;}
	R8708[571] = (char *(*)()) F1146_10101;
}

char *(*R8710[572])();
void R8710_init () {
	R8710[0] = (char *(*)()) F1145_9957;
	{long i; for (i = 2; i < 4; i++) R8710[i] = (char *(*)()) F1146_10129;}
	R8710[571] = (char *(*)()) F1146_10129;
}

char *(*R8713[572])();
void R8713_init () {
	R8713[0] = (char *(*)()) F1145_10003;
	{long i; for (i = 2; i < 4; i++) R8713[i] = (char *(*)()) F1146_10151;}
	R8713[571] = (char *(*)()) F1716_18267;
}

char *(*R8715[570])();
void R8715_init () {
	{long i; for (i = 0; i < 2; i++) R8715[i] = (char *(*)()) F1146_10154;}
	R8715[569] = (char *(*)()) F1716_18265;
}

char *(*R8743[570])();
void R8743_init () {
	{long i; for (i = 0; i < 2; i++) R8743[i] = (char *(*)()) F1146_10184;}
	R8743[569] = (char *(*)()) F1716_18262;
}

char *(*R8745[570])();
void R8745_init () {
	R8745[0] = (char *(*)()) F1147_10291;
	R8745[1] = (char *(*)()) F1148_10349;
	R8745[569] = (char *(*)()) F1148_10349;
}

char *(*R8751[570])();
void R8751_init () {
	R8751[0] = (char *(*)()) F1147_10297;
	R8751[1] = (char *(*)()) F1148_10358;
	R8751[569] = (char *(*)()) F1148_10358;
}

char *(*R8756[570])();
void R8756_init () {
	{long i; for (i = 0; i < 2; i++) R8756[i] = (char *(*)()) F1146_10191;}
	R8756[569] = (char *(*)()) F1716_18256;
}

char *(*R8759[570])();
void R8759_init () {
	{long i; for (i = 0; i < 2; i++) R8759[i] = (char *(*)()) F1146_10188;}
	R8759[569] = (char *(*)()) F1716_18253;
}

char *(*R8787[570])();
void R8787_init () {
	R8787[0] = (char *(*)()) F1146_10042;
	R8787[1] = (char *(*)()) F1148_10323;
	R8787[569] = (char *(*)()) F1148_10323;
}

char *(*R8812[570])();
void R8812_init () {
	{long i; for (i = 0; i < 2; i++) R8812[i] = (char *(*)()) F1146_10076;}
	R8812[569] = (char *(*)()) F1716_18243;
}

char *(*R8881[570])();
void R8881_init () {
	R8881[0] = (char *(*)()) F1147_10317;
	R8881[1] = (char *(*)()) F1146_10200;
	R8881[569] = (char *(*)()) F1146_10200;
}

char *(*R8882[570])();
void R8882_init () {
	{long i; for (i = 0; i < 2; i++) R8882[i] = (char *(*)()) F1146_10201;}
	R8882[569] = (char *(*)()) F1716_18299;
}

char *(*R8965[569])();
void R8965_init () {
	R8965[0] = (char *(*)()) F1148_10369;
	R8965[568] = (char *(*)()) F1716_18241;
}

char *(*R8971[569])();
void R8971_init () {
	R8971[0] = (char *(*)()) F1148_10375;
	R8971[568] = (char *(*)()) F1716_18279;
}


#ifdef __cplusplus
}
#endif
