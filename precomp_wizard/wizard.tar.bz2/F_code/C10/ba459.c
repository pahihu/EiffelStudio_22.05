/*
 * Code for class BASE_PROCESS_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ba459.h"
#include <unistd.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F260_4481
static void inline_F260_4481 (EIF_INTEGER_32 arg1)
{
	{
	pid_t pgid = getpgid (arg1);
	tcsetpgrp (1, pgid);
	tcsetpgrp (2, pgid);
}
	;
}
#define INLINE_F260_4481
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BASE_PROCESS_IMP}.make */
void F526_7565 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLR(5,arg1);
	RTLR(6,arg3);
	RTLIU(7);
	
	RTEAA("make", 525, Current, 2, 3, 7698);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {891,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 891, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F892_8780(RTCW(loc1), ((EIF_INTEGER_32) 0L));
	RTHOOK(2);
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		RTHOOK(3);
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7452[Dtype(RTCW(arg2))-554])(arg2);
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8078[Dtype(loc2)-967])(loc2);
			if (tb1) break;
			RTHOOK(4);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8077[Dtype(loc2)-967])(loc2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7657[Dtype(RTCW(loc1))-780])(loc1, tr1);
			RTHOOK(5);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R8079[Dtype(loc2)-967])(loc2);
		}
	}
	RTHOOK(6);
	F526_7580(Current, arg1, loc1, arg3);
	RTHOOK(7);
	F526_7581(Current, arg1, loc1, *(EIF_REFERENCE *)(Current + _REFACS_1_));
	RTHOOK(8);
	F512_7407(Current);
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {BASE_PROCESS_IMP}.make_with_command_line */
void F526_7566 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc1);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTEAA("make_with_command_line", 525, Current, 2, 2, 7699);
	RTGC;
	RTHOOK(1);
	loc2 = F511_7387(Current, arg1);
	RTHOOK(2);
	tb1 = F724_8337(RTCW(loc2));
	if (tb1) {
		RTHOOK(3);
		loc1 = F1237_11118(RTMS_EX_H(" ",1,32));
		RTHOOK(4);
		loc2 = (EIF_REFERENCE) NULL;
	} else {
		RTHOOK(5);
		ti4_1 = F892_8801(RTCW(loc2));
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
			RTHOOK(6);
			loc1 = F892_8788(RTCW(loc2));
			RTHOOK(7);
			loc2 = (EIF_REFERENCE) NULL;
		} else {
			RTHOOK(8);
			loc1 = F892_8788(RTCW(loc2));
			RTHOOK(9);
			F892_8811(RTCW(loc2));
			RTHOOK(10);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R7675[Dtype(RTCW(loc2))-780])(loc2);
		}
	}
	RTHOOK(11);
	F527_7584(Current, loc1, loc2, arg2);
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {BASE_PROCESS_IMP}.close */
void F526_7570 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("close", 525, Current, 0, 0, 7703);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_21_15_) && *(EIF_BOOLEAN *)(Current+ _CHROFF_21_14_))) {
		RTHOOK(2);
		ti4_1 = F525_7563(Current);
		inline_F260_4481(ti4_1);
	}
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F1150_10445(RTCW(tr1));
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {BASE_PROCESS_IMP}.platform_launch */
void F526_7571 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("platform_launch", 525, Current, 1, 0, 7704);
	RTGC;
	RTHOOK(1);
	F527_7598(Current);
	RTHOOK(2);
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_21_15_) && *(EIF_BOOLEAN *)(Current+ _CHROFF_21_14_))) {
		RTHOOK(3);
		ti4_1 = F525_7563(Current);
		inline_F260_4481(ti4_1);
	}
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F1150_10446(RTCW(tr1), *(EIF_BOOLEAN *)(Current+ _CHROFF_21_14_), *(EIF_REFERENCE *)(Current + _REFACS_5_), *(EIF_BOOLEAN *)(Current+ _CHROFF_21_15_));
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_15_11_0_1_);
	RTHOOK(6);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_21_18_0_0_) = (EIF_INTEGER_32) loc1;
	RTHOOK(7);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_21_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) -1L));
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {BASE_PROCESS_IMP}.initialize_after_launch */
void F526_7572 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("initialize_after_launch", 525, Current, 0, 0, 7705);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {BASE_PROCESS_IMP}.update_process_state */
void F526_7577 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("update_process_state", 525, Current, 0, 0, 7710);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F1150_10444(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_21_18_0_0_), (EIF_BOOLEAN) 0);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_15_1_);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_21_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) !tb1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {BASE_PROCESS_IMP}.close_process */
void F526_7578 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("close_process", 525, Current, 0, 0, 7711);
	RTHOOK(1);
	F526_7570(Current);
	RTHOOK(2);
	RTEE;
}

/* {BASE_PROCESS_IMP}.initialize_child_process */
void F526_7579 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	struct eif_ex_79 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(85, 0x00).id);
	RTLI(7);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLIU(7);
	
	RTEAA("initialize_child_process", 525, Current, 4, 0, 7712);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
		tr2 = F86_1484(RTCW(loc1), loc2);
		F1150_10440(RTCW(tr1), tr2);
	} else {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
		F1150_10440(RTCW(tr1), NULL);
	}
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
		tr2 = F86_1484(RTCW(loc1), loc3);
		F1150_10441(RTCW(tr1), tr2);
	} else {
		RTHOOK(6);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
		F1150_10441(RTCW(tr1), NULL);
	}
	RTHOOK(7);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_21_18_0_3_) == ((EIF_INTEGER_32) 3L))) {
		RTHOOK(8);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
		F1150_10443(RTCW(tr1));
	} else {
		RTHOOK(9);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			RTHOOK(10);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
			tr2 = F86_1484(RTCW(loc1), loc4);
			F1150_10442(RTCW(tr1), tr2);
		} else {
			RTHOOK(11);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
			F1150_10442(RTCW(tr1), NULL);
		}
	}
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {BASE_PROCESS_IMP}.setup_command */
void F526_7580 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,arg3);
	RTLR(3,Current);
	RTLR(4,arg2);
	RTLR(5,loc2);
	RTLR(6,tr1);
	RTLIU(7);
	
	RTEAA("setup_command", 525, Current, 3, 3, 7713);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9640[Dtype(RTCW(arg1))-1240])(arg1);
	F1240_11189(RTCW(loc1), ti4_1);
	RTHOOK(2);
	F1242_11303(RTCW(loc1), arg1);
	RTHOOK(3);
	F511_7383(Current, arg3);
	RTHOOK(4);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) arg2;
	RTHOOK(5);
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		RTHOOK(6);
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7452[Dtype(RTCW(arg2))-554])(arg2);
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8078[Dtype(loc2)-967])(loc2);
			if (tb1) break;
			RTHOOK(7);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
			F1242_11317(RTCW(loc1), tw1);
			RTHOOK(8);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8077[Dtype(loc2)-967])(loc2);
			F1242_11303(RTCW(loc1), tr1);
			RTHOOK(9);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R8079[Dtype(loc2)-967])(loc2);
		}
	}
	RTHOOK(10);
	tr1 = RTLNS(eif_new_type(1240, 0x00).id, 1240, _OBJSIZ_1_0_0_4_0_0_0_0_);
	F1241_11244(RTCW(tr1), loc1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(14);
	RTLE;
	RTEE;
}

/* {BASE_PROCESS_IMP}.create_child_process_manager */
void F526_7581 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTEAA("create_child_process_manager", 525, Current, 0, 3, 7714);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_new_type(1149, 0).id);
	F1150_10426(RTCW(tr1), arg1, arg2, arg3);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_15_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F1150_10439(RTCW(tr1), (EIF_BOOLEAN) 1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit459 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
