/*
 * Code for class PROCESS_THREAD_TIMER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pr454.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PROCESS_THREAD_TIMER}.make */
void F521_7534 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 520, Current, 0, 1, 7667);
	RTGC;
	RTHOOK(1);
	F291_4839(Current);
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_0_) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	tr1 = RTLNSMART(eif_new_type(1138, 0).id);
	F1139_9669(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {PROCESS_THREAD_TIMER}.start */
void F521_7535 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("start", 520, Current, 0, 0, 7668);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1139_9672(RTCW(tr1));
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(3);
	F291_4843(Current);
	RTHOOK(4);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1139_9674(RTCW(tr1));
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {PROCESS_THREAD_TIMER}.destroy */
void F521_7536 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("destroy", 520, Current, 0, 0, 7669);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1139_9672(RTCW(tr1));
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1139_9674(RTCW(tr1));
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {PROCESS_THREAD_TIMER}.wait */
EIF_BOOLEAN F521_7537 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_64 tu8_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("wait", 520, Current, 0, 1, 7670);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		F291_4851(Current);
		RTHOOK(3);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		RTHOOK(5);
		tu8_1 = (EIF_NATURAL_64) arg1;
		Result = F291_4852(Current, tu8_1);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {PROCESS_THREAD_TIMER}.execute */
void F521_7539 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_64 loc1 = (EIF_INTEGER_64) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_64 ti8_1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("execute", 520, Current, 2, 0, 7672);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = tr1;
	loc2 = RTRV(eif_new_type(526, 0x00),loc2);
	if (EIF_TEST(loc2)) {
		RTHOOK(2);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_3_0_0_);
		loc1 = (EIF_INTEGER_64) ti4_1;
		ti8_1 = (EIF_INTEGER_64) ((EIF_INTEGER_32) 1000000L);
		loc1 = (EIF_INTEGER_64) (EIF_INTEGER_64) (loc1 * ti8_1);
		for (;;) {
			RTHOOK(3);
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_3_2_)) break;
			RTHOOK(4);
			F527_7590(loc2);
			RTHOOK(5);
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_3_2_)) {
				RTHOOK(6);
				F517_7513(Current, loc1);
			}
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

void EIF_Minit454 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
