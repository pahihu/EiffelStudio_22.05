
#ifndef _C10_pr453_
#define _C10_pr453_

#ifdef __cplusplus
extern "C" {
#endif

extern void F520_7532(EIF_REFERENCE, EIF_REFERENCE);
extern void F520_7533(EIF_REFERENCE);
extern void EIF_Minit453(void);
extern void F527_7596(EIF_REFERENCE);
extern void F517_7513(EIF_REFERENCE, EIF_INTEGER_64);
extern void F291_4839(EIF_REFERENCE);
extern void F1139_9669(EIF_REFERENCE);
extern EIF_BOOLEAN F292_4864(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
