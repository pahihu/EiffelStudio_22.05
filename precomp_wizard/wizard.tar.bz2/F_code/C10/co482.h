
#ifndef _C10_co482_
#define _C10_co482_

#ifdef __cplusplus
extern "C" {
#endif

extern void F904_8846(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit482(void);
extern void F567_8076(EIF_REFERENCE);
extern void F892_8780(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
