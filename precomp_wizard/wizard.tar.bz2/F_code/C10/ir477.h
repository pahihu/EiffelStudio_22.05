
#ifndef _C10_ir477_
#define _C10_ir477_

#ifdef __cplusplus
extern "C" {
#endif

extern void F556_8041(EIF_REFERENCE);
extern EIF_REFERENCE F556_8045(EIF_REFERENCE);
extern EIF_REFERENCE F556_8047(EIF_REFERENCE);
extern void EIF_Minit477(void);
extern EIF_REFERENCE F1782_20320(EIF_REFERENCE);
extern char *(*R7502[])();
extern char *(*R7452[])();
extern char *(*R7498[])();

#ifdef __cplusplus
}
#endif

#endif
