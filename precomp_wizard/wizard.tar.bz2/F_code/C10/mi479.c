/*
 * Code for class MISMATCH_INFORMATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "mi479.h"
#include <eif_retrieve.h>
#include "../C24/ha1193.h"
#include "../C10/mi479.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {MISMATCH_INFORMATION}.default_create */
void F820_8555 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_create", 819, Current, 0, 0, 10160);
	RTGC;
	RTHOOK(1);
	F806_8436(Current, ((EIF_INTEGER_32) 5L));
	RTHOOK(2);
	RTOUCP(128,F820_8565, (Current));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {MISMATCH_INFORMATION}.class_name */
EIF_REFERENCE F820_8556 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("class_name", 819, Current, 1, 0, 10149);
	RTGC;
	
	RTHOOK(2);
	RTCT0("attached {STRING_8} item (type_name_key) as r", EX_CHECK);
	tr1 = RTOUCR(129,F820_8559, (Current));
	tr1 = F806_8442(Current, tr1);
	loc1 = RTCCL(tr1);
	loc1 = RTRV(eif_new_type(1244, 0x00),loc1);
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(3);
	Result = (EIF_REFERENCE) loc1;
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {MISMATCH_INFORMATION}.type_name_key */

EIF_REFERENCE F820_8559 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (129,RTMS_EX_H("_type_name",10,803527013));
}

/* {MISMATCH_INFORMATION}.out */
EIF_REFERENCE F820_8562 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTEAA("out", 819, Current, 2, 0, 10155);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1244, 0x00).id, 1244, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(F820_8556(Current))+ _LNGOFF_1_1_0_2_);
	ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_3_0_6_);
	F1243_11356(RTCW(Result), (EIF_INTEGER_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 20L) + ti4_1) + (EIF_INTEGER_32) (((EIF_INTEGER_32) 40L) * ti4_2)));
	RTHOOK(2);
	tr1 = RTMS_EX_H("Attributes of original class ",29,488257824);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9863[Dtype(RTCW(Result))-1244])(Result, tr1);
	RTHOOK(3);
	tr1 = F820_8556(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9863[Dtype(RTCW(Result))-1244])(Result, tr1);
	RTHOOK(4);
	tr1 = RTMS_EX_H(": ",2,14880);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9863[Dtype(RTCW(Result))-1244])(Result, tr1);
	RTHOOK(5);
	F1245_11472(RTCW(Result), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_3_0_6_) - ((EIF_INTEGER_32) 1L)));
	RTHOOK(6);
	tr1 = RTMS_EX_H(" item",5,1769481581);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9863[Dtype(RTCW(Result))-1244])(Result, tr1);
	RTHOOK(7);
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_3_0_6_) - ((EIF_INTEGER_32) 1L)) != ((EIF_INTEGER_32) 1L))) {
		RTHOOK(8);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R9867[Dtype(RTCW(Result))-1244])(Result, (EIF_CHARACTER_8) 's');
	}
	RTHOOK(9);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R9867[Dtype(RTCW(Result))-1244])(Result, (EIF_CHARACTER_8) '\012');
	RTHOOK(10);
	F806_8475(Current);
	for (;;) {
		RTHOOK(11);
		if (F806_8470(Current)) break;
		RTHOOK(12);
		loc2 = F806_8449(Current);
		RTHOOK(13);
		if (!RTEQ(loc2, RTOUCR(129,F820_8559, (Current)))) {
			RTHOOK(14);
			tr1 = RTMS_EX_H("  ",2,8224);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9863[Dtype(RTCW(Result))-1244])(Result, tr1);
			RTHOOK(15);
			if ((EIF_BOOLEAN)(loc2 == NULL)) {
				RTHOOK(16);
				tr1 = RTMS_EX_H("Void",4,1450142052);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9863[Dtype(RTCW(Result))-1244])(Result, tr1);
			} else {
				RTHOOK(17);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9863[Dtype(RTCW(Result))-1244])(Result, loc2);
			}
			RTHOOK(18);
			tr1 = RTMS_EX_H(": ",2,14880);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9863[Dtype(RTCW(Result))-1244])(Result, tr1);
			RTHOOK(19);
			loc1 = F806_8448(Current);
			RTHOOK(20);
			if ((EIF_BOOLEAN)(loc1 == NULL)) {
				RTHOOK(21);
				tr1 = RTMS_EX_H("Void",4,1450142052);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9863[Dtype(RTCW(Result))-1244])(Result, tr1);
			} else {
				RTHOOK(22);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R28[Dtype(RTCW(loc1))-7])(loc1);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9863[Dtype(RTCW(Result))-1244])(Result, tr1);
			}
			RTHOOK(23);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R9867[Dtype(RTCW(Result))-1244])(Result, (EIF_CHARACTER_8) '\012');
		}
		RTHOOK(24);
		F806_8476(Current);
	}
	RTHOOK(25);
	RTLE;
	RTEE;
	return Result;
}

/* {MISMATCH_INFORMATION}.internal_put */
void F820_8563 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("internal_put", 819, Current, 0, 2, 10156);
	RTGC;
	RTHOOK(1);
	tr1 = RTCCL(arg1);
	tr2 = RTLNS(eif_new_type(1244, 0x00).id, 1244, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1243_11359(RTCW(tr2), arg2);
	F806_8482(Current, tr1, tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {MISMATCH_INFORMATION}.set_string_versions */
void F820_8564 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLIU(2);
	
	RTEAA("set_string_versions", 819, Current, 1, 2, 10157);
	RTGC;
	RTHOOK(1);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(arg1 == tp1)) {
		RTHOOK(2);
		*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) NULL;
	} else {
		RTHOOK(3);
		loc1 = RTLNS(eif_new_type(1243, 0x00).id, 1243, _OBJSIZ_1_0_0_4_0_0_0_0_);
		F1243_11359(RTCW(loc1), arg1);
		RTHOOK(4);
		tb1 = F1244_11425(RTCW(loc1));
		if (tb1) {
			RTHOOK(5);
			*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) NULL;
		} else {
			RTHOOK(6);
			RTAR(Current, loc1);
			*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) loc1;
		}
	}
	RTHOOK(7);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(arg2 == tp1)) {
		RTHOOK(8);
		*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) NULL;
	} else {
		RTHOOK(9);
		loc1 = RTLNS(eif_new_type(1243, 0x00).id, 1243, _OBJSIZ_1_0_0_4_0_0_0_0_);
		F1243_11359(RTCW(loc1), arg2);
		RTHOOK(10);
		tb1 = F1244_11425(RTCW(loc1));
		if (tb1) {
			RTHOOK(11);
			*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) NULL;
		} else {
			RTHOOK(12);
			RTAR(Current, loc1);
			*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) loc1;
		}
	}
	RTHOOK(13);
	RTLE;
	RTEE;
}

/* {MISMATCH_INFORMATION}.set_callback_pointers */
static void F820_8565_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	RTOUDV(128)

	
	RTEAA("set_callback_pointers", 819, Current, 0, 0, 10158);
	RTOTP;
	RTHOOK(1);
	F820_8566(Current, Current, (EIF_POINTER) F806_8490, (EIF_POINTER) F820_8563, (EIF_POINTER) F820_8564);
	RTOTE;
	RTHOOK(2);
	RTEE;
#undef Result
}

void F820_8565 (EIF_REFERENCE Current)
{
	GTCX
	RTOUCP(128,F820_8565_body,(Current));
}

/* {MISMATCH_INFORMATION}.set_mismatch_information_access */
void F820_8566 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("set_mismatch_information_access", 819, Current, 0, 4, 10159);
	{
		EIF_OBJECT larg1 = &arg1;
		EIF_POINTER larg2 = arg2;
		EIF_POINTER larg3 = arg3;
		EIF_POINTER larg4 = arg4;set_mismatch_information_access((EIF_OBJECT) larg1, (EIF_PROCEDURE) larg2, (EIF_PROCEDURE) larg3, (EIF_PROCEDURE) larg4);
		
	}
	RTHOOK(1);
	RTLE;
	RTEE;
}

void EIF_Minit479 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
