/*
 * Code for class CONF_LOAD
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co471.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_LOAD}.make */
void F538_7818 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("make", 537, Current, 0, 1, 7956);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_8_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	F296_4922(Current);
	RTHOOK(4);
	F38_592(RTCV(F296_4924(Current)));
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {CONF_LOAD}.report_error */
void F538_7826 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("report_error", 537, Current, 0, 1, 7964);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_8_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_LOAD}.reset_error */
void F538_7827 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("reset_error", 537, Current, 0, 0, 7965);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_8_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(2);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) NULL;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_LOAD}.retrieve_configuration */
void F538_7835 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("retrieve_configuration", 537, Current, 0, 1, 7973);
	RTGC;
	RTHOOK(1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) NULL;
	RTHOOK(2);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) NULL;
	RTHOOK(3);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) NULL;
	RTHOOK(4);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
	RTHOOK(5);
	F538_7827(Current);
	RTHOOK(6);
	F538_7839(Current, arg1, NULL, NULL);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {CONF_LOAD}.add_warning */
void F538_7838 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_warning", 537, Current, 1, 1, 7976);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {891,1096,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNSMART(typres0.id);
		}
		F892_8780(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		RTHOOK(4);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(5);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7657[Dtype(RTCW(loc1))-780])(loc1, arg1);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {CONF_LOAD}.recursive_retrieve_configuration */
void F538_7839 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(16);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,tr2);
	RTLR(5,loc2);
	RTLR(6,arg2);
	RTLR(7,loc4);
	RTLR(8,loc5);
	RTLR(9,arg3);
	RTLR(10,tr3);
	RTLR(11,loc3);
	RTLR(12,loc6);
	RTLR(13,loc7);
	RTLR(14,tr4);
	RTLR(15,loc8);
	RTLIU(16);
	
	RTEAA("recursive_retrieve_configuration", 537, Current, 8, 3, 7977);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(536, 0x00).id, 536, _OBJSIZ_26_3_0_1_0_0_0_0_);
	tr1 = F1237_11118(RTCW(arg1));
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F537_7732(RTCW(loc1), tr1, tr2);
	RTHOOK(2);
	F538_7846(Current, arg1, loc1);
	RTHOOK(3);
	tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_26_0_);
	if (tb1) {
		RTHOOK(4);
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_26_2_);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_8_2_) = (EIF_BOOLEAN) tb1;
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_2_);
		F538_7826(Current, tr1);
	} else {
		RTHOOK(6);
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_8_0_)) {
			RTHOOK(7);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_5_);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
			RTHOOK(8);
			loc2 = (EIF_REFERENCE) arg2;
			RTHOOK(9);
			if ((EIF_BOOLEAN)(loc2 == NULL)) {
				RTHOOK(10);
				loc2 = RTLNS(eif_new_type(61, 0x00).id, 61, _OBJSIZ_1_0_0_0_0_0_0_0_);
				F62_1077(RTCW(loc2));
			}
			RTHOOK(11);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_6_);
			loc4 = tr1;
			if (EIF_TEST(loc4)) {
				RTHOOK(12);
				if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_3_) == NULL)) {
					RTHOOK(13);
					RTAR(Current, loc4);
					*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) loc4;
					RTHOOK(14);
					tr1 = F1740_18828(loc4);
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
				}
				RTHOOK(15);
				tr1 = *(EIF_REFERENCE *)(loc4 + _REFACS_3_);
				loc5 = tr1;
				if (EIF_TEST(loc5)) {
					RTHOOK(16);
					tb1 = '\0';
					if ((EIF_BOOLEAN)(arg3 != NULL)) {
						tr1 = eif_boxed_item(arg3,2);
						tb1 = !RTEQ(tr1, loc5);
					}
					if (tb1) {
						RTHOOK(17);
						tr1 = RTLNS(eif_new_type(1106, 0x00).id, 1106, _OBJSIZ_4_0_0_0_0_0_0_0_);
						tr2 = eif_boxed_item(arg3,1);
						tr3 = eif_boxed_item(arg3,2);
						F1107_9378(RTCW(tr1), tr2, arg1, tr3, loc5);
						F538_7826(Current, tr1);
					} else {
						RTHOOK(18);
						if ((EIF_BOOLEAN)(arg3 != NULL)) {
							
							RTHOOK(20);
							
							eif_put_reference_item(RTCW(arg3),1,arg1);
							RTHOOK(21);
							loc3 = (EIF_REFERENCE) arg3;
						} else {
							RTHOOK(22);
							{
								static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1186,1239,1298,0xFFFF};
								EIF_TYPE typres0;
								static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
								
								typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
								tr1 = RTLNTS(typres0.id, 3, 0);
							}
							((EIF_TYPED_VALUE *)tr1+1)->it_r = arg1;
							RTAR(tr1,arg1);
							((EIF_TYPED_VALUE *)tr1+2)->it_r = loc5;
							RTAR(tr1,loc5);
							loc3 = (EIF_REFERENCE) tr1;
						}
					}
				} else {
					RTHOOK(23);
					if ((EIF_BOOLEAN)(arg3 != NULL)) {
						RTHOOK(24);
						loc3 = (EIF_REFERENCE) arg3;
					} else {
						RTHOOK(25);
						loc3 = (EIF_REFERENCE) NULL;
					}
				}
				RTHOOK(26);
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_8_0_) && *(EIF_BOOLEAN *)(Current+ _CHROFF_8_3_))) {
					RTHOOK(27);
					tr1 = *(EIF_REFERENCE *)(loc4 + _REFACS_4_);
					loc6 = tr1;
					if (EIF_TEST(loc6)) {
						RTHOOK(28);
						tr1 = F1741_18837(loc4);
						F538_7841(Current, arg1, tr1, loc3, loc2);
						RTHOOK(29);
						*(EIF_BOOLEAN *)(Current+ _CHROFF_8_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						RTHOOK(30);
						tr1 = RTLNS(eif_new_type(1105, 0x00).id, 1105, _OBJSIZ_3_0_0_0_0_0_0_0_);
						tr2 = *(EIF_REFERENCE *)(loc4 + _REFACS_2_);
						F1106_9373(RTCW(tr1), arg1, tr2, loc6);
						F538_7838(Current, tr1);
					} else {
						RTHOOK(31);
						tr1 = F1741_18837(loc4);
						F538_7841(Current, arg1, tr1, loc3, loc2);
					}
				}
			} else {
				RTHOOK(32);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				loc7 = tr1;
				if (EIF_TEST(loc7)) {
					RTHOOK(33);
					F1740_18830(loc7, arg1);
					RTHOOK(34);
					F1740_18831(loc7);
					RTHOOK(35);
					tb1 = '\0';
					if ((EIF_BOOLEAN)(arg3 != NULL)) {
						tr1 = eif_boxed_item(arg3,2);
						tr2 = *(EIF_REFERENCE *)(loc7 + _REFACS_5_);
						tb1 = !RTEQ(tr1, tr2);
					}
					if (tb1) {
						RTHOOK(36);
						tb1 = *(EIF_BOOLEAN *)(loc7+ _CHROFF_16_2_);
						if (tb1) {
							RTHOOK(37);
							tr1 = RTLNS(eif_new_type(1106, 0x00).id, 1106, _OBJSIZ_4_0_0_0_0_0_0_0_);
							tr2 = eif_boxed_item(arg3,1);
							tr3 = eif_boxed_item(arg3,2);
							F1107_9378(RTCW(tr1), tr2, arg1, tr3, NULL);
							F538_7826(Current, tr1);
						} else {
							RTHOOK(38);
							tr1 = RTLNS(eif_new_type(1106, 0x00).id, 1106, _OBJSIZ_4_0_0_0_0_0_0_0_);
							tr2 = eif_boxed_item(arg3,1);
							tr3 = eif_boxed_item(arg3,2);
							tr4 = *(EIF_REFERENCE *)(loc7 + _REFACS_5_);
							F1107_9378(RTCW(tr1), tr2, arg1, tr3, tr4);
							F538_7826(Current, tr1);
						}
					}
				} else {
					RTHOOK(39);
					F455_6666(RTCW(loc1));
					RTHOOK(40);
					tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_26_2_);
					*(EIF_BOOLEAN *)(Current+ _CHROFF_8_2_) = (EIF_BOOLEAN) tb1;
					RTHOOK(41);
					tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_2_);
					loc8 = tr1;
					if (EIF_TEST(loc8)) {
						RTHOOK(42);
						F538_7826(Current, loc8);
						RTHOOK(43);
						tr1 = RTMS_EX_H("Tag \"system\" not found",22,1606008420);
						F1108_9395(loc8, tr1);
					} else {
						RTHOOK(44);
						F538_7827(Current);
					}
				}
			}
		}
	}
	RTHOOK(46);
	RTLE;
	RTEE;
}

/* {CONF_LOAD}.retrieve_redirected_configuration */
void F538_7841 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,arg1);
	RTLR(3,Current);
	RTLR(4,loc2);
	RTLR(5,arg4);
	RTLR(6,tr1);
	RTLR(7,tr2);
	RTLR(8,tr3);
	RTLR(9,arg3);
	RTLIU(10);
	
	RTEAA("retrieve_redirected_configuration", 537, Current, 2, 4, 7979);
	RTGC;
	RTHOOK(1);
	loc1 = F538_7844(Current, arg2, arg1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg4));
	loc2 = F892_8794(RTCW(tr1));
	tb1 = EIF_FALSE;
	for (;;) {
		if (tb1) break;
		tb2 = F1036_9256(loc2);
		if (tb2) break;
		RTHOOK(3);
		tr1 = F1036_9247(loc2);
		tb3 = F1304_12631(RTCW(loc1), tr1);
		tb1 = tb3;
		F1036_9262(loc2);
	}
	if (tb1) {
		RTHOOK(4);
		tr1 = RTLNS(eif_new_type(1104, 0x00).id, 1104, _OBJSIZ_2_0_0_0_0_0_0_0_);
		tr2 = F1304_12658(RTCW(loc1));
		tr3 = *(EIF_REFERENCE *)(RTCW(arg4));
		F1105_9369(RTCW(tr1), tr2, tr3);
		F538_7826(Current, tr1);
	} else {
		RTHOOK(5);
		F62_1079(RTCW(arg4), loc1);
		RTHOOK(6);
		tr1 = F1304_12658(RTCW(loc1));
		F538_7839(Current, tr1, arg4, arg3);
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {CONF_LOAD}.conf_location_value_to_path */
EIF_REFERENCE F538_7843 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("conf_location_value_to_path", 537, Current, 1, 1, 7981);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(1303, 0x00).id, 1303, _OBJSIZ_2_1_0_0_0_0_0_0_);
		F1304_12619(RTCW(tr1), arg1);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(4);
		loc1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1242_11265(RTCW(loc1), arg1);
		RTHOOK(5);
		tr1 = RTMS32_EX_H("\\\000\000\000",1,92);
		tr2 = RTMS32_EX_H("/\000\000\000",1,47);
		F1242_11281(RTCW(loc1), tr1, tr2);
		RTHOOK(6);
		tr1 = RTLNS(eif_new_type(1303, 0x00).id, 1303, _OBJSIZ_2_1_0_0_0_0_0_0_);
		F1304_12619(RTCW(tr1), loc1);
		RTHOOK(7);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {CONF_LOAD}.conf_redirection_location_for_file */
EIF_REFERENCE F538_7844 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTEAA("conf_redirection_location_for_file", 537, Current, 0, 2, 7982);
	RTGC;
	RTHOOK(1);
	Result = F538_7843(Current, arg1);
	RTHOOK(2);
	tr1 = RTLNS(eif_new_type(1303, 0x00).id, 1303, _OBJSIZ_2_1_0_0_0_0_0_0_);
	F1304_12619(RTCW(tr1), arg2);
	tr1 = F1304_12634(RTCW(tr1));
	tr1 = F1304_12639(RTCW(Result), tr1);
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_LOAD}.parse_file */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F538_7846 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_REFERENCE  EIF_VOLATILE tr2 = NULL;
	EIF_INTEGER_32  EIF_VOLATILE ti4_1;
	EIF_INTEGER_32  EIF_VOLATILE ti4_2;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_BOOLEAN  EIF_VOLATILE tb2;
	RTCFDT;
	RTLD;
	RTXD;
	
	RTLI(16);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc2);
	RTLR(5,arg2);
	RTLR(6,loc4);
	RTLR(7,loc3);
	RTLR(8,loc1);
	RTLR(9,loc7);
	RTLR(10,loc8);
	RTLR(11,loc5);
	RTLR(12,loc9);
	RTLR(13,loc10);
	RTLR(14,loc11);
	RTLR(15,saved_except);
	RTLIU(16);
	RTXSLS;
	
	RTEAA("parse_file", 537, Current, 11, 2, 7984);
	RTGC;
	RTE_T
	RTHOOK(1);
	if ((EIF_BOOLEAN) !loc6) {
		RTHOOK(2);
		F538_7827(Current);
		RTHOOK(3);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R9618[Dtype(RTCW(arg1))-1240])(arg1);
		if (tb1) {
			RTHOOK(4);
			tr1 = RTLNS(eif_new_type(1103, 0x00).id, 1103, _OBJSIZ_3_0_0_0_0_0_0_0_);
			tr2 = F1237_11118(RTCW(arg1));
			F1104_9361(RTCW(tr1), tr2);
			F538_7826(Current, tr1);
		} else {
			RTHOOK(5);
			tr1 = RTLNS(eif_new_type(361, 0x00).id, 361, _OBJSIZ_5_5_0_5_0_0_0_0_);
			F361_5502(RTCW(tr1));
			loc2 = (EIF_REFERENCE) tr1;
			RTHOOK(6);
			F355_5455(RTCW(arg2), loc2);
			RTHOOK(7);
			tr1 = RTLNS(eif_new_type(364, 0x00).id, 364, _OBJSIZ_4_0_0_0_0_0_0_0_);
			F365_5642(RTCW(tr1), arg2);
			loc4 = (EIF_REFERENCE) tr1;
			RTHOOK(8);
			F355_5455(RTCW(loc4), loc2);
			RTHOOK(9);
			tr1 = RTLNS(eif_new_type(363, 0x00).id, 363, _OBJSIZ_8_1_0_0_0_0_0_0_);
			F364_5607(RTCW(tr1), loc4);
			loc3 = (EIF_REFERENCE) tr1;
			RTHOOK(10);
			F355_5455(RTCW(loc3), loc2);
			RTHOOK(11);
			F361_5509(RTCW(loc2), loc3);
			RTHOOK(12);
			tr1 = RTLNS(eif_new_type(1147, 0x00).id, 1147, _OBJSIZ_5_7_2_4_1_1_2_1_);
			F1148_10323(RTCW(tr1), arg1);
			loc1 = (EIF_REFERENCE) tr1;
			RTHOOK(13);
			tb1 = '\0';
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8700[Dtype(RTCW(loc1))-1146])(loc1);
			if (tb2) {
				tb2 = F1146_10084(RTCW(loc1));
				tb1 = tb2;
			}
			if (tb1) {
				RTHOOK(14);
				F1146_10112(RTCW(loc1));
			}
			RTHOOK(15);
			tb1 = F1146_10102(RTCW(loc1));
			if (tb1) {
				RTHOOK(16);
				F361_5506(RTCW(loc2), loc1);
				RTHOOK(17);
				F1146_10129(RTCW(loc1));
			} else {
				RTHOOK(18);
				tr1 = RTLNS(eif_new_type(1103, 0x00).id, 1103, _OBJSIZ_3_0_0_0_0_0_0_0_);
				tr2 = F1237_11118(RTCW(arg1));
				F1104_9361(RTCW(tr1), tr2);
				F538_7826(Current, tr1);
			}
		}
	} else {
		RTHOOK(19);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			RTHOOK(20);
			tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_2_);
			loc7 = tr1;
			if (EIF_TEST(loc7)) {
				RTHOOK(21);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_3_);
				loc8 = tr1;
				if (EIF_TEST(loc8)) {
					RTHOOK(22);
					loc5 = (EIF_REFERENCE) loc8;
				} else {
					RTHOOK(23);
					loc5 = F361_5518(RTCW(loc2));
				}
				RTHOOK(24);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc5));
				ti4_1 = F1298_12356(RTCW(loc5));
				ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_0_0_1_);
				F1108_9394(loc7, tr1, ti4_1, ti4_2);
				RTHOOK(25);
				F1108_9392(loc7);
			} else {
				RTHOOK(26);
				F455_6666(RTCW(arg2));
			}
		} else {
			RTHOOK(27);
			F455_6666(RTCW(arg2));
		}
		RTHOOK(28);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_2_);
		loc9 = tr1;
		if (EIF_TEST(loc9)) {
			RTHOOK(29);
			F538_7826(Current, loc9);
		} else {
			
		}
	}
	RTHOOK(31);
	tb1 = '\01';
	if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_8_1_)) {
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg2)+ _CHROFF_26_1_);
		tb1 = tb2;
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_8_1_) = (EIF_BOOLEAN) tb1;
	RTHOOK(32);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc10 = tr1;
	if (EIF_TEST(loc10)) {
		RTHOOK(33);
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_3_);
		loc11 = tr1;
		if (EIF_TEST(loc11)) {
			tb2 = F724_8337(loc11);
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			RTHOOK(34);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7716[Dtype(loc10)-882])(loc10, loc11);
		}
	} else {
		RTHOOK(35);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_3_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	}
	RTE_E
	RTXSC;
	RTHOOK(36);
	loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(37);
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTHOOK(38);
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

void EIF_Minit471 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
