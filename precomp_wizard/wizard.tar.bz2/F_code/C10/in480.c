/*
 * Code for class INTEGER_INTERVAL
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "in480.h"
#include "eif_built_in.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {INTEGER_INTERVAL}.make */
void F833_8567 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make", 832, Current, 0, 2, 10175);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg1 <= arg2)) {
		RTHOOK(2);
		*(EIF_INTEGER_32 *)(Current + O7865[dtype-832]) = (EIF_INTEGER_32) arg1;
		RTHOOK(3);
		*(EIF_INTEGER_32 *)(Current + O7864[dtype-832]) = (EIF_INTEGER_32) arg2;
	} else {
		RTHOOK(4);
		*(EIF_INTEGER_32 *)(Current + O7865[dtype-832]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		RTHOOK(5);
		*(EIF_INTEGER_32 *)(Current + O7864[dtype-832]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	}
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {INTEGER_INTERVAL}.lower */
EIF_INTEGER_32 F833_8570 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O7865[Dtype(Current)-832]);
}


/* {INTEGER_INTERVAL}.upper */
EIF_INTEGER_32 F833_8572 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O7864[Dtype(Current)-832]);
}


/* {INTEGER_INTERVAL}.item */
EIF_INTEGER_32 F833_8573 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("item", 832, Current, 0, 1, 10181);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) arg1;
}

/* {INTEGER_INTERVAL}.has */
EIF_BOOLEAN F833_8575 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTCDT;
	
	
	RTEAA("has", 832, Current, 0, 1, 10183);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) (arg1 <= *(EIF_INTEGER_32 *)(Current + O7864[dtype-832])) && (EIF_BOOLEAN) (arg1 >= *(EIF_INTEGER_32 *)(Current + O7865[dtype-832])));
}

/* {INTEGER_INTERVAL}.valid_index */
EIF_BOOLEAN F833_8576 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTCDT;
	
	
	RTEAA("valid_index", 832, Current, 0, 1, 10184);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) (arg1 <= *(EIF_INTEGER_32 *)(Current + O7864[dtype-832])) && (EIF_BOOLEAN) (arg1 >= *(EIF_INTEGER_32 *)(Current + O7865[dtype-832])));
}

/* {INTEGER_INTERVAL}.capacity */
EIF_INTEGER_32 F833_8578 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("capacity", 832, Current, 0, 0, 10186);
	RTGC;
	
	RTHOOK(2);
	RTHOOK(3);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) F833_8579(Current);
}

/* {INTEGER_INTERVAL}.count */
EIF_INTEGER_32 F833_8579 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("count", 832, Current, 0, 0, 10187);
	RTGC;
	
	RTHOOK(2);
	Result = *(EIF_INTEGER_32 *)(Current + O7864[dtype-832]);
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O7865[dtype-832]);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (Result - ti4_1) + ((EIF_INTEGER_32) 1L));
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_INTERVAL}.is_equal */
EIF_BOOLEAN F833_8581 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_equal", 832, Current, 0, 1, 10189);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	tb1 = '\0';
	tb2 = EIF_TRUE;
	if (tb2) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O7865[Dtype(arg1)-832]);
		tb1 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O7865[dtype-832]) == ti4_1);
	}
	if (tb1) {
		tb1 = '\0';
		tb2 = EIF_TRUE;
		if (tb2) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O7864[Dtype(arg1)-832]);
			tb1 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O7864[dtype-832]) == ti4_1);
		}
		Result = tb1;
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_INTERVAL}.extendible */
EIF_BOOLEAN F833_8583 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("extendible", 832, Current, 0, 0, 10191);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {INTEGER_INTERVAL}.extend */
void F833_8585 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("extend", 832, Current, 0, 1, 10193);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg1 < *(EIF_INTEGER_32 *)(Current + O7865[dtype-832]))) {
		RTHOOK(2);
		*(EIF_INTEGER_32 *)(Current + O7865[dtype-832]) = (EIF_INTEGER_32) arg1;
	} else {
		RTHOOK(3);
		if ((EIF_BOOLEAN) (arg1 > *(EIF_INTEGER_32 *)(Current + O7864[dtype-832]))) {
			RTHOOK(4);
			*(EIF_INTEGER_32 *)(Current + O7864[dtype-832]) = (EIF_INTEGER_32) arg1;
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {INTEGER_INTERVAL}.put */
void F833_8586 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("put", 832, Current, 0, 1, 10194);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg1 < *(EIF_INTEGER_32 *)(Current + O7865[dtype-832]))) {
		RTHOOK(2);
		*(EIF_INTEGER_32 *)(Current + O7865[dtype-832]) = (EIF_INTEGER_32) arg1;
	} else {
		RTHOOK(3);
		if ((EIF_BOOLEAN) (arg1 > *(EIF_INTEGER_32 *)(Current + O7864[dtype-832]))) {
			RTHOOK(4);
			*(EIF_INTEGER_32 *)(Current + O7864[dtype-832]) = (EIF_INTEGER_32) arg1;
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {INTEGER_INTERVAL}.resize */
void F833_8587 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("resize", 832, Current, 0, 2, 10195);
	RTGC;
	RTHOOK(1);
	ti4_1 = eif_min_int32 (arg1,*(EIF_INTEGER_32 *)(Current + O7865[dtype-832]));
	*(EIF_INTEGER_32 *)(Current + O7865[dtype-832]) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(2);
	ti4_1 = eif_max_int32 (arg2,*(EIF_INTEGER_32 *)(Current + O7864[dtype-832]));
	*(EIF_INTEGER_32 *)(Current + O7864[dtype-832]) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {INTEGER_INTERVAL}.grow */
void F833_8589 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("grow", 832, Current, 0, 1, 10197);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (F833_8578(Current) < arg1)) {
		RTHOOK(2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R7854[dtype-832])(Current, *(EIF_INTEGER_32 *)(Current + O7865[dtype-832]), (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O7865[dtype-832]) + arg1) - ((EIF_INTEGER_32) 1L)));
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {INTEGER_INTERVAL}.as_array */
EIF_REFERENCE F833_8592 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("as_array", 832, Current, 2, 0, 10162);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_INTEGER_32 *)(Current + O7865[dtype-832]);
	RTHOOK(2);
	loc2 = *(EIF_INTEGER_32 *)(Current + O7864[dtype-832]);
	RTHOOK(3);
	{
		static EIF_TYPE_INDEX typarr0[] = {940,1486,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 940, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F941_9009(RTCW(Result), ((EIF_INTEGER_32) 0L), loc1, loc2);
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		RTHOOK(5);
		F941_9033(RTCW(Result), loc1, loc1);
		RTHOOK(6);
		loc1++;
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_INTERVAL}.linear_representation */
EIF_REFERENCE F833_8594 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("linear_representation", 832, Current, 0, 0, 10164);
	RTGC;
	
	RTHOOK(2);
	Result = F941_9061(RTCV(F833_8592(Current)));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {INTEGER_INTERVAL}.copy */
void F833_8595 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("copy", 832, Current, 0, 1, 10165);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		RTHOOK(2);
		eif_builtin_ANY_standard_copy__o_ (Current, arg1);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {INTEGER_INTERVAL}.prune */
void F833_8602 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("prune", 832, Current, 0, 1, 10172);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

void EIF_Minit480 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
