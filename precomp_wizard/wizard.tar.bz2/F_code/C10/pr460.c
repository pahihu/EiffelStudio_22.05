/*
 * Code for class PROCESS_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pr460.h"
#include <unistd.h>
#include "eif_helpers.h"
#include "eif_sig.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F260_4481
static void inline_F260_4481 (EIF_INTEGER_32 arg1)
{
	{
	pid_t pgid = getpgid (arg1);
	tcsetpgrp (1, pgid);
	tcsetpgrp (2, pgid);
}
	;
}
#define INLINE_F260_4481
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PROCESS_IMP}.make */
void F527_7584 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTEAA("make", 526, Current, 0, 3, 7728);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_new_type(1244, 0).id);
	F1237_11059(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTLNSMART(eif_new_type(1138, 0).id);
	F1139_9669(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	F526_7565(Current, arg1, arg2, arg3);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {PROCESS_IMP}.launch */
void F527_7585 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("launch", 526, Current, 0, 0, 7729);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_0_);
	if (tb1) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
		tb1 = F521_7537(RTCW(tr1), ((EIF_INTEGER_32) 0L));
		eif_do_nothing_value.it_b = tb1;
	}
	RTHOOK(3);
	F511_7311(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {PROCESS_IMP}.check_exit */
void F527_7590 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,loc2);
	RTLR(3,loc3);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTEAA("check_exit", 526, Current, 3, 0, 7734);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_21_7_)) {
		RTHOOK(2);
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
		RTHOOK(3);
		loc2 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
		RTHOOK(4);
		loc3 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
		RTHOOK(5);
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_21_5_)) {
			RTHOOK(6);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
			F1150_10444(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_21_18_0_0_), (EIF_BOOLEAN) 0);
			RTHOOK(7);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_15_1_);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_21_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) !tb1;
			RTHOOK(8);
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_21_5_)) {
				RTHOOK(9);
				if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_21_15_) && *(EIF_BOOLEAN *)(Current+ _CHROFF_21_14_))) {
					RTHOOK(10);
					ti4_1 = F525_7563(Current);
					inline_F260_4481(ti4_1);
				}
				RTHOOK(11);
				if ((EIF_BOOLEAN)(loc1 != NULL)) {
					RTHOOK(12);
					F292_4862(RTCW(loc1));
				}
				RTHOOK(13);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					RTHOOK(14);
					F292_4862(RTCW(loc2));
				}
				RTHOOK(15);
				if ((EIF_BOOLEAN)(loc3 != NULL)) {
					RTHOOK(16);
					F292_4862(RTCW(loc3));
				}
			}
		} else {
			RTHOOK(17);
			tb1 = '\0';
			tb2 = '\0';
			tb3 = '\01';
			if ((EIF_BOOLEAN)(loc1 != NULL)) {
				tb4 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_3_0_);
				tb3 = tb4;
			}
			if (tb3) {
				tb3 = '\01';
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					tb4 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_3_0_);
					tb3 = tb4;
				}
				tb2 = tb3;
			}
			if (tb2) {
				tb2 = '\01';
				if ((EIF_BOOLEAN)(loc3 != NULL)) {
					tb3 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_3_0_);
					tb2 = tb3;
				}
				tb1 = tb2;
			}
			if (tb1) {
				RTHOOK(18);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
				F521_7536(RTCW(tr1));
				RTHOOK(19);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R9728[Dtype(RTCW(tr1))-1241])(tr1);
				RTHOOK(20);
				F511_7327(Current);
			}
		}
	}
	RTHOOK(21);
	RTLE;
	RTEE;
}

/* {PROCESS_IMP}.write_input_stream */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F527_7595 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_INTEGER_32 EIF_VOLATILE loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE EIF_VOLATILE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_INTEGER_32  EIF_VOLATILE ti4_1;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	RTLD;
	RTXD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc3);
	RTLR(3,saved_except);
	RTLIU(4);
	RTXSLS;
	
	RTEAA("write_input_stream", 526, Current, 4, 0, 7717);
	RTGC;
	RTE_T
	RTHOOK(1);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc4 && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_21_16_))) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
		F1139_9672(RTCW(tr1));
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
		loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
		RTHOOK(4);
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
			RTHOOK(5);
			ti4_1 = eif_min_int32 (loc1,*(EIF_INTEGER_32 *)(Current+ _LNGOFF_21_18_0_4_));
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_21_18_0_8_) = (EIF_INTEGER_32) ti4_1;
			RTHOOK(6);
			tr1 = RTLNS(eif_new_type(1244, 0x00).id, 1244, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F1243_11356(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_21_18_0_8_));
			loc3 = (EIF_REFERENCE) tr1;
			RTHOOK(7);
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_21_18_0_8_);
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - loc2);
			RTHOOK(8);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R9681[Dtype(RTCW(tr1))-1240])(tr1, ((EIF_INTEGER_32) 1L), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_21_18_0_8_));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9863[Dtype(RTCW(loc3))-1244])(loc3, tr1);
			RTHOOK(9);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R9720[Dtype(RTCW(tr1))-1241])(tr1, loc2);
		} else {
			RTHOOK(10);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_21_18_0_8_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		}
		RTHOOK(11);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
		F1139_9674(RTCW(tr1));
		RTHOOK(12);
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			RTHOOK(13);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
			F1150_10452(RTCW(tr1), loc3);
		}
	}
	RTE_E
	RTXSC;
	RTHOOK(14);
	loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(15);
	tb1 = '\0';
	if (F378_5900(Current)) {
		tb1 = (EIF_BOOLEAN)((EIF_INTEGER_32) esignum() == RTOUCB(EIF_INTEGER_32,604,F259_4429, (Current)));
	}
	if (tb1) {
		RTHOOK(16);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_21_16_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(17);
		RTER;
	}
	/* NOTREACHED */
	RTE_EE
	RTHOOK(18);
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {PROCESS_IMP}.read_output_stream */
void F527_7596 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("read_output_stream", 526, Current, 2, 0, 7718);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_21_18_0_6_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
		F1150_10448(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_21_18_0_4_));
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTHOOK(5);
			ti4_1 = *(EIF_INTEGER_32 *)(loc2+ _LNGOFF_1_1_0_2_);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_21_18_0_6_) = (EIF_INTEGER_32) ti4_1;
			RTHOOK(6);
			(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(loc1+ _PTROFF_4_2_0_3_0_0_))(
				*(EIF_POINTER *)(loc1+ _PTROFF_4_2_0_3_0_1_),
				*(EIF_REFERENCE *)(loc1 + _REFACS_1_), loc2);
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {PROCESS_IMP}.read_error_stream */
void F527_7597 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("read_error_stream", 526, Current, 2, 0, 7719);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_21_18_0_7_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
		F1150_10450(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_21_18_0_4_));
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTHOOK(5);
			ti4_1 = *(EIF_INTEGER_32 *)(loc2+ _LNGOFF_1_1_0_2_);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_21_18_0_7_) = (EIF_INTEGER_32) ti4_1;
			RTHOOK(6);
			(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(loc1+ _PTROFF_4_2_0_3_0_0_))(
				*(EIF_POINTER *)(loc1+ _PTROFF_4_2_0_3_0_1_),
				*(EIF_REFERENCE *)(loc1 + _REFACS_1_), loc2);
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {PROCESS_IMP}.initialize_child_process */
void F527_7598 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("initialize_child_process", 526, Current, 0, 0, 7720);
	RTGC;
	RTHOOK(1);
	F526_7579(Current);
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_21_16_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {PROCESS_IMP}.initialize_after_launch */
void F527_7599 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("initialize_after_launch", 526, Current, 0, 0, 7721);
	RTGC;
	RTHOOK(1);
	{
		/* INLINED CODE (BASE_PROCESS_IMP.initialize_after_launch) */
		/* END INLINED CODE */
	}
	;
	RTHOOK(2);
	F527_7600(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {PROCESS_IMP}.start_listening_threads */
void F527_7600 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTEAA("start_listening_threads", 526, Current, 3, 0, 7722);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_21_18_0_1_) == ((EIF_INTEGER_32) 2L))) {
		RTHOOK(2);
		tr1 = RTLNSMART(eif_new_type(1244, 0).id);
		F1243_11356(RTCW(tr1), ((EIF_INTEGER_32) 4096L));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) tr1;
		RTHOOK(3);
		tr1 = RTLNSMART(eif_new_type(1138, 0).id);
		F1139_9669(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) tr1;
		RTHOOK(4);
		loc1 = RTLNSMART(eif_new_type(518, 0).id);
		F519_7530(RTCW(loc1), Current);
		RTHOOK(5);
		F291_4843(RTCW(loc1));
		RTHOOK(6);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(7);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_21_18_0_2_) == ((EIF_INTEGER_32) 2L))) {
		RTHOOK(8);
		loc2 = RTLNSMART(eif_new_type(519, 0).id);
		F520_7532(RTCW(loc2), Current);
		RTHOOK(9);
		F291_4843(RTCW(loc2));
		RTHOOK(10);
		RTAR(Current, loc2);
		*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) loc2;
	}
	RTHOOK(11);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_21_18_0_3_) == ((EIF_INTEGER_32) 2L))) {
		RTHOOK(12);
		loc3 = RTLNSMART(eif_new_type(517, 0).id);
		F518_7528(RTCW(loc3), Current);
		RTHOOK(13);
		F291_4843(RTCW(loc3));
		RTHOOK(14);
		RTAR(Current, loc3);
		*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) loc3;
	}
	RTHOOK(15);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	F521_7535(RTCW(tr1));
	RTHOOK(16);
	RTLE;
	RTEE;
}

void EIF_Minit460 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
