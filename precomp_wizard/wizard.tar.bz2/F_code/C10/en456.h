
#ifndef _C10_en456_
#define _C10_en456_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F523_7560(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit456(void);
extern EIF_REFERENCE F517_7497(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
