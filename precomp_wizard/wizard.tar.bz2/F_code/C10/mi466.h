
#ifndef _C10_mi466_
#define _C10_mi466_

#ifdef __cplusplus
extern "C" {
#endif

extern void F533_7691(EIF_REFERENCE);
static EIF_REFERENCE F533_7692_body(EIF_REFERENCE);
extern EIF_REFERENCE F533_7692(EIF_REFERENCE);
extern void EIF_Minit466(void);
extern void F378_5914(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1305_12679(EIF_REFERENCE);
extern void F820_8555(EIF_REFERENCE);
extern void F1242_11265(EIF_REFERENCE, EIF_REFERENCE);
extern void F1242_11304(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
