/*
 * Code for class CONF_OPTION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co472.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_OPTION}.create_from_namespace */
EIF_REFERENCE F539_7847 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("create_from_namespace", 538, Current, 0, 1, 7986);
	RTGC;
	RTHOOK(1);
	if (F452_6619(Current, arg1)) {
		RTHOOK(2);
		tr1 = RTLNSMART(Dftype(Current));
		F539_7849(RTCW(tr1), arg1);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {CONF_OPTION}.create_from_namespace_or_latest */
EIF_REFERENCE F539_7848 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("create_from_namespace_or_latest", 538, Current, 0, 1, 7987);
	RTGC;
	RTHOOK(1);
	Result = RTLNSMART(Dftype(Current));
	if (F452_6619(Current, arg1)) {
		RTHOOK(2);
		tr1 = arg1;
	} else {
		RTHOOK(3);
		tr1 = RTOUCR(480,F452_6617, (Current));
	}
	F539_7849(RTCW(Result), tr1);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_OPTION}.make_from_namespace */
void F539_7849 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("make_from_namespace", 538, Current, 0, 1, 7988);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(489,F452_6615, (Current));
	tb1 = F1240_11216(RTCW(arg1), tr1);
	if (tb1) {
		RTHOOK(2);
		F539_7860(Current);
	} else {
		RTHOOK(3);
		tr1 = RTOUCR(487,F452_6613, (Current));
		tb1 = F1240_11216(RTCW(arg1), tr1);
		if (tb1) {
			RTHOOK(4);
			F539_7859(Current);
		} else {
			RTHOOK(5);
			tr1 = RTOUCR(514,F452_6611, (Current));
			tb1 = F1240_11216(RTCW(arg1), tr1);
			if (tb1) {
				RTHOOK(6);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R7323[dtype-538])(Current);
			} else {
				RTHOOK(7);
				tb1 = '\01';
				tr1 = RTOUCR(485,F452_6609, (Current));
				tb2 = F1240_11216(RTCW(arg1), tr1);
				if (!tb2) {
					tr1 = RTOUCR(481,F452_6607, (Current));
					tb2 = F1240_11216(RTCW(arg1), tr1);
					tb1 = tb2;
				}
				if (tb1) {
					RTHOOK(8);
					F539_7857(Current);
				} else {
					RTHOOK(9);
					tb1 = '\01';
					tr1 = RTOUCR(515,F452_6605, (Current));
					tb2 = F1240_11216(RTCW(arg1), tr1);
					if (!tb2) {
						tr1 = RTOUCR(479,F452_6603, (Current));
						tb2 = F1240_11216(RTCW(arg1), tr1);
						tb1 = tb2;
					}
					if (tb1) {
						RTHOOK(10);
						(FUNCTION_CAST(void, (EIF_REFERENCE)) R7321[dtype-538])(Current);
					} else {
						RTHOOK(11);
						tr1 = RTOUCR(484,F452_6601, (Current));
						tb1 = F1240_11216(RTCW(arg1), tr1);
						if (tb1) {
							RTHOOK(12);
							F539_7855(Current);
						} else {
							RTHOOK(13);
							tb1 = '\01';
							tr1 = RTOUCR(488,F452_6599, (Current));
							tb2 = F1240_11216(RTCW(arg1), tr1);
							if (!tb2) {
								tr1 = RTOUCR(516,F452_6597, (Current));
								tb2 = F1240_11216(RTCW(arg1), tr1);
								tb1 = tb2;
							}
							if (tb1) {
								RTHOOK(14);
								F539_7854(Current);
							} else {
								RTHOOK(15);
								tb1 = '\01';
								tr1 = RTOUCR(478,F452_6595, (Current));
								tb2 = F1240_11216(RTCW(arg1), tr1);
								if (!tb2) {
									tr1 = RTOUCR(517,F452_6593, (Current));
									tb2 = F1240_11216(RTCW(arg1), tr1);
									tb1 = tb2;
								}
								if (tb1) {
									RTHOOK(16);
									F539_7853(Current);
								} else {
									RTHOOK(17);
									tb1 = '\01';
									tr1 = RTOUCR(491,F452_6591, (Current));
									tb2 = F1240_11216(RTCW(arg1), tr1);
									if (!tb2) {
										tr1 = RTOUCR(477,F452_6589, (Current));
										tb2 = F1240_11216(RTCW(arg1), tr1);
										tb1 = tb2;
									}
									if (tb1) {
										RTHOOK(18);
										F539_7852(Current);
									} else {
										RTHOOK(19);
										tb1 = '\01';
										tb2 = '\01';
										tb3 = '\01';
										tr1 = RTOUCR(493,F452_6587, (Current));
										tb4 = F1240_11216(RTCW(arg1), tr1);
										if (!tb4) {
											tr1 = RTOUCR(483,F452_6585, (Current));
											tb4 = F1240_11216(RTCW(arg1), tr1);
											tb3 = tb4;
										}
										if (!tb3) {
											tr1 = RTOUCR(482,F452_6583, (Current));
											tb3 = F1240_11216(RTCW(arg1), tr1);
											tb2 = tb3;
										}
										if (!tb2) {
											tr1 = RTOUCR(490,F452_6581, (Current));
											tb2 = F1240_11216(RTCW(arg1), tr1);
											tb1 = tb2;
										}
										if (tb1) {
											RTHOOK(20);
											F539_7851(Current);
										} else {
											RTHOOK(21);
											tb1 = '\01';
											tb2 = '\01';
											tb3 = '\01';
											tr1 = RTOUCR(492,F452_6579, (Current));
											tb4 = F1240_11216(RTCW(arg1), tr1);
											if (!tb4) {
												tr1 = RTOUCR(518,F452_6577, (Current));
												tb4 = F1240_11216(RTCW(arg1), tr1);
												tb3 = tb4;
											}
											if (!tb3) {
												tr1 = RTOUCR(519,F452_6575, (Current));
												tb3 = F1240_11216(RTCW(arg1), tr1);
												tb2 = tb3;
											}
											if (!tb2) {
												tr1 = RTOUCR(520,F452_6573, (Current));
												tb2 = F1240_11216(RTCW(arg1), tr1);
												tb1 = tb2;
											}
											if (tb1) {
												RTHOOK(22);
												(FUNCTION_CAST(void, (EIF_REFERENCE)) R7315[dtype-538])(Current);
											} else {
												RTHOOK(23);
												RTCT0("from_precondition", EX_CHECK);
													RTCF0;
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	RTHOOK(24);
	RTLE;
	RTEE;
}

/* {CONF_OPTION}.make_6_3 */
void F539_7850 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("make_6_3", 538, Current, 0, 0, 7989);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_new_type(1293, 0).id);
	tr2 = RTOUCR(521,F539_7899, (Current));
	F1294_12223(RTCW(tr1), tr2, ((EIF_NATURAL_8) 1U));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTLNSMART(eif_new_type(1293, 0).id);
	tr2 = RTOUCR(522,F539_7904, (Current));
	F1294_12223(RTCW(tr1), tr2, ((EIF_NATURAL_8) 2U));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	tr1 = RTLNSMART(eif_new_type(1293, 0).id);
	tr2 = RTOUCR(523,F539_7931, (Current));
	F1294_12223(RTCW(tr1), tr2, ((EIF_NATURAL_8) 1U));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	tr1 = RTLNSMART(eif_new_type(1293, 0).id);
	tr2 = RTOUCR(524,F539_7924, (Current));
	F1294_12223(RTCW(tr1), tr2, ((EIF_NATURAL_8) 1U));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	RTHOOK(5);
	*(EIF_BOOLEAN *)(Current + O7357[dtype-538]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(6);
	*(EIF_BOOLEAN *)(Current + O7356[dtype-538]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(7);
	tr1 = RTLNSMART(eif_new_type(1293, 0).id);
	tr2 = RTOUCR(525,F539_7917, (Current));
	F1294_12223(RTCW(tr1), tr2, ((EIF_NATURAL_8) 1U));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	RTHOOK(8);
	tr1 = RTLNSMART(eif_new_type(1293, 0).id);
	tr2 = RTOUCR(526,F539_7918, (Current));
	F1294_12223(RTCW(tr1), tr2, ((EIF_NATURAL_8) 2U));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {CONF_OPTION}.make_6_4 */
void F539_7851 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make_6_4", 538, Current, 0, 0, 7990);
	RTGC;
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R7315[Dtype(Current)-538])(Current);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1294_12235(RTCW(tr1), ((EIF_NATURAL_8) 2U));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_OPTION}.make_7_0 */
void F539_7852 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make_7_0", 538, Current, 0, 0, 7991);
	RTGC;
	RTHOOK(1);
	F539_7851(Current);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1294_12235(RTCW(tr1), ((EIF_NATURAL_8) 3U));
	RTHOOK(3);
	*(EIF_BOOLEAN *)(Current + O7355[Dtype(Current)-538]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {CONF_OPTION}.make_7_3 */
void F539_7853 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make_7_3", 538, Current, 0, 0, 7992);
	RTGC;
	RTHOOK(1);
	F539_7852(Current);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	F1294_12235(RTCW(tr1), ((EIF_NATURAL_8) 4U));
	RTHOOK(3);
	*(EIF_BOOLEAN *)(Current + O7354[Dtype(Current)-538]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {CONF_OPTION}.make_14_05 */
void F539_7854 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make_14_05", 538, Current, 0, 0, 7993);
	RTGC;
	RTHOOK(1);
	F539_7853(Current);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	F1294_12235(RTCW(tr1), ((EIF_NATURAL_8) 5U));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_OPTION}.make_15_11 */
void F539_7855 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make_15_11", 538, Current, 0, 0, 7994);
	RTGC;
	RTHOOK(1);
	F539_7854(Current);
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current + O7357[Dtype(Current)-538]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_OPTION}.make_16_11 */
void F539_7856 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("make_16_11", 538, Current, 0, 0, 7995);
	RTHOOK(1);
	F539_7855(Current);
	RTHOOK(2);
	RTEE;
}

/* {CONF_OPTION}.make_18_01 */
void F539_7857 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make_18_01", 538, Current, 0, 0, 7996);
	RTGC;
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R7321[Dtype(Current)-538])(Current);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F1294_12235(RTCW(tr1), ((EIF_NATURAL_8) 3U));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_OPTION}.make_19_05 */
void F539_7858 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("make_19_05", 538, Current, 0, 0, 7997);
	RTHOOK(1);
	F539_7857(Current);
	RTHOOK(2);
	RTEE;
}

/* {CONF_OPTION}.make_19_11 */
void F539_7859 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make_19_11", 538, Current, 0, 0, 7998);
	RTGC;
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R7323[Dtype(Current)-538])(Current);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1294_12235(RTCW(tr1), ((EIF_NATURAL_8) 2U));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_OPTION}.make_21_05 */
void F539_7860 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make_21_05", 538, Current, 0, 0, 7999);
	RTGC;
	RTHOOK(1);
	F539_7859(Current);
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current + O7356[Dtype(Current)-538]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_OPTION}.syntax_name */
static EIF_REFERENCE F539_7899_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(521)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("syntax_name", 538, Current, 0, 0, 8038);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1407,1241,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 4L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = RTMS32_EX_H("o\000\000\000b\000\000\000s\000\000\000o\000\000\000l\000\000\000e\000\000\000t\000\000\000e\000\000\000",8,2004093797);
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS32_EX_H("t\000\000\000r\000\000\000a\000\000\000n\000\000\000s\000\000\000i\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000a\000\000\000l\000\000\000",12,1290118508);
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS32_EX_H("s\000\000\000t\000\000\000a\000\000\000n\000\000\000d\000\000\000a\000\000\000r\000\000\000d\000\000\000",8,157435492);
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS32_EX_H("p\000\000\000r\000\000\000o\000\000\000v\000\000\000i\000\000\000s\000\000\000i\000\000\000o\000\000\000n\000\000\000a\000\000\000l\000\000\000",11,1227139436);
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1408_13455)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F539_7899 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(521,F539_7899_body,(Current));
}

/* {CONF_OPTION}.array_name */
static EIF_REFERENCE F539_7904_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(522)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("array_name", 538, Current, 0, 0, 8043);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1407,1241,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 3L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = RTMS32_EX_H("m\000\000\000i\000\000\000s\000\000\000m\000\000\000a\000\000\000t\000\000\000c\000\000\000h\000\000\000_\000\000\000e\000\000\000r\000\000\000r\000\000\000o\000\000\000r\000\000\000",14,1494271346);
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS32_EX_H("m\000\000\000i\000\000\000s\000\000\000m\000\000\000a\000\000\000t\000\000\000c\000\000\000h\000\000\000_\000\000\000w\000\000\000a\000\000\000r\000\000\000n\000\000\000i\000\000\000n\000\000\000g\000\000\000",16,1759222119);
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS32_EX_H("s\000\000\000t\000\000\000a\000\000\000n\000\000\000d\000\000\000a\000\000\000r\000\000\000d\000\000\000",8,157435492);
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1408_13455)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F539_7904 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(522,F539_7904_body,(Current));
}

/* {CONF_OPTION}.warning_name */
static EIF_REFERENCE F539_7917_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(525)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("warning_name", 538, Current, 0, 0, 8056);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1407,1241,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 3L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = RTMS32_EX_H("n\000\000\000o\000\000\000n\000\000\000e\000\000\000",4,1852796517);
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS32_EX_H("w\000\000\000a\000\000\000r\000\000\000n\000\000\000i\000\000\000n\000\000\000g\000\000\000",7,1809215079);
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS32_EX_H("e\000\000\000r\000\000\000r\000\000\000o\000\000\000r\000\000\000",5,1920877938);
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1408_13455)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F539_7917 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(525,F539_7917_body,(Current));
}

/* {CONF_OPTION}.warning_term_name */
static EIF_REFERENCE F539_7918_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(526)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("warning_term_name", 538, Current, 0, 0, 8057);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1407,1241,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 3L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = RTMS32_EX_H("n\000\000\000o\000\000\000n\000\000\000e\000\000\000",4,1852796517);
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS32_EX_H("c\000\000\000u\000\000\000r\000\000\000r\000\000\000e\000\000\000n\000\000\000t\000\000\000",7,438973044);
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS32_EX_H("a\000\000\000l\000\000\000l\000\000\000",3,6384748);
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1408_13455)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F539_7918 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(526,F539_7918_body,(Current));
}

/* {CONF_OPTION}.add_warning */
void F539_7919 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_warning", 538, Current, 2, 2, 8058);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {818,1195,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNSMART(typres0.id);
		}
		F814_8437(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		RTHOOK(4);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(5);
	F814_8483(RTCW(loc1), arg2, arg1);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {CONF_OPTION}.catcall_detection_values */
static EIF_REFERENCE F539_7924_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(524)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("catcall_detection_values", 538, Current, 0, 0, 8063);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1407,1241,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 3L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = RTMS32_EX_H("n\000\000\000o\000\000\000n\000\000\000e\000\000\000",4,1852796517);
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS32_EX_H("c\000\000\000o\000\000\000n\000\000\000f\000\000\000o\000\000\000r\000\000\000m\000\000\000a\000\000\000n\000\000\000c\000\000\000e\000\000\000",11,1508810597);
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS32_EX_H("a\000\000\000l\000\000\000l\000\000\000",3,6384748);
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1408_13455)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F539_7924 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(524,F539_7924_body,(Current));
}

/* {CONF_OPTION}.void_safety_name */
static EIF_REFERENCE F539_7931_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(523)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("void_safety_name", 538, Current, 0, 0, 8070);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1407,1241,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 5L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 5L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F1237_11118(RTCV(RTOUCR(373,F373_5739, (Current))));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1237_11118(RTCV(RTOUCR(374,F373_5740, (Current))));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1237_11118(RTCV(RTOUCR(375,F373_5741, (Current))));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1237_11118(RTCV(RTOUCR(376,F373_5742, (Current))));
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1237_11118(RTCV(RTOUCR(377,F373_5743, (Current))));
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1408_13455)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F539_7931 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(523,F539_7931_body,(Current));
}

/* {CONF_OPTION}.set_assertions */
void F539_7934 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_assertions", 538, Current, 0, 1, 8073);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_OPTION}.add_debug */
void F539_7935 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add_debug", 538, Current, 2, 2, 8074);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {818,1195,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNSMART(typres0.id);
		}
		F814_8437(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		RTHOOK(4);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(5);
	F814_8483(RTCW(loc1), arg2, arg1);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {CONF_OPTION}.set_local_namespace */
void F539_7936 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("set_local_namespace", 538, Current, 0, 1, 8075);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R9618[Dtype(RTCW(arg1))-1240])(arg1);
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(2);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) NULL;
	} else {
		RTHOOK(3);
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	}
	RTHOOK(4);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {CONF_OPTION}.set_profile */
void F539_7937 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_profile", 538, Current, 0, 1, 8076);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O7326[dtype-538]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current + O7349[dtype-538]) = (EIF_BOOLEAN) arg1;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_OPTION}.set_trace */
void F539_7938 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_trace", 538, Current, 0, 1, 8077);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O7327[dtype-538]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current + O7350[dtype-538]) = (EIF_BOOLEAN) arg1;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_OPTION}.set_optimize */
void F539_7939 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_optimize", 538, Current, 0, 1, 8078);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O7328[dtype-538]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current + O7351[dtype-538]) = (EIF_BOOLEAN) arg1;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_OPTION}.set_debug */
void F539_7940 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_debug", 538, Current, 0, 1, 8079);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O7329[dtype-538]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current + O7352[dtype-538]) = (EIF_BOOLEAN) arg1;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_OPTION}.set_msil_application_optimize */
void F539_7941 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_msil_application_optimize", 538, Current, 0, 1, 8080);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O7330[dtype-538]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current + O7353[dtype-538]) = (EIF_BOOLEAN) arg1;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_OPTION}.set_full_class_checking */
void F539_7942 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_full_class_checking", 538, Current, 0, 1, 8081);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O7331[dtype-538]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current + O7354[dtype-538]) = (EIF_BOOLEAN) arg1;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_OPTION}.set_is_attached_by_default */
void F539_7943 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_is_attached_by_default", 538, Current, 0, 1, 8082);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O7332[dtype-538]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current + O7355[dtype-538]) = (EIF_BOOLEAN) arg1;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_OPTION}.set_is_obsolete_iteration */
void F539_7944 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_is_obsolete_iteration", 538, Current, 0, 1, 8083);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O7334[dtype-538]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current + O7356[dtype-538]) = (EIF_BOOLEAN) arg1;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_OPTION}.set_is_obsolete_routine_type */
void F539_7945 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_is_obsolete_routine_type", 538, Current, 0, 1, 8084);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O7333[dtype-538]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current + O7357[dtype-538]) = (EIF_BOOLEAN) arg1;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_OPTION}.set_description */
void F539_7946 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_description", 538, Current, 0, 1, 8085);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_OPTION}.copy */
void F539_7947 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,loc5);
	RTLR(8,loc6);
	RTLIU(9);
	
	RTEAA("copy", 538, Current, 6, 1, 8086);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		RTHOOK(2);
		eif_builtin_ANY_standard_copy__o_ (Current, arg1);
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			RTHOOK(4);
			tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc1);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		}
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_11_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTHOOK(6);
			tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc2);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
		}
		RTHOOK(7);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			RTHOOK(8);
			tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc3);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
		}
		RTHOOK(9);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			RTHOOK(10);
			tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc4);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
		}
		RTHOOK(11);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			RTHOOK(12);
			tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc5);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		}
		RTHOOK(13);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_10_);
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
		RTHOOK(14);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_9_);
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
		RTHOOK(15);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
		RTHOOK(16);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
		RTHOOK(17);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
		RTHOOK(18);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_7_);
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			RTHOOK(19);
			tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc6);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
		}
	}
	RTHOOK(20);
	RTLE;
	RTEE;
}

/* {CONF_OPTION}.is_equal */
EIF_BOOLEAN F539_7948 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN tb6;
	EIF_BOOLEAN tb7;
	EIF_BOOLEAN tb8;
	EIF_BOOLEAN tb9;
	EIF_BOOLEAN tb10;
	EIF_BOOLEAN tb11;
	EIF_BOOLEAN tb12;
	EIF_BOOLEAN tb13;
	EIF_BOOLEAN tb14;
	EIF_BOOLEAN tb15;
	EIF_BOOLEAN tb16;
	EIF_BOOLEAN tb17;
	EIF_BOOLEAN tb18;
	EIF_BOOLEAN tb19;
	EIF_BOOLEAN tb20;
	EIF_BOOLEAN tb21;
	EIF_BOOLEAN tb22;
	EIF_BOOLEAN tb23;
	EIF_BOOLEAN tb24;
	EIF_BOOLEAN tb25;
	EIF_BOOLEAN tb26;
	EIF_BOOLEAN tb27;
	EIF_BOOLEAN tb28;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("is_equal", 538, Current, 0, 1, 8087);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	tb1 = '\0';
	tb2 = '\0';
	tb3 = '\0';
	tb4 = '\0';
	tb5 = '\0';
	tb6 = '\0';
	tb7 = '\0';
	tb8 = '\0';
	tb9 = '\0';
	tb10 = '\0';
	tb11 = '\0';
	tb12 = '\0';
	tb13 = '\0';
	tb14 = '\0';
	tb15 = '\0';
	tb16 = '\0';
	tb17 = '\0';
	tb18 = '\0';
	tb19 = '\0';
	tb20 = '\0';
	tb21 = '\0';
	tb22 = '\0';
	tb23 = '\0';
	tb24 = '\0';
	tb25 = '\0';
	tb26 = '\0';
	tb27 = '\0';
	tb28 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if (RTEQ(*(EIF_REFERENCE *)(Current), tr1)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_11_);
		tb28 = RTEQ(*(EIF_REFERENCE *)(Current + _REFACS_11_), tr1);
	}
	if (tb28) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
		tb27 = RTEQ(*(EIF_REFERENCE *)(Current + _REFACS_3_), tr1);
	}
	if (tb27) {
		tb27 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7355[Dtype(arg1)-538]);
		tb26 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O7355[dtype-538]) == tb27);
	}
	if (tb26) {
		tb26 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7332[Dtype(arg1)-538]);
		tb25 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O7332[dtype-538]) == tb26);
	}
	if (tb25) {
		tb25 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7356[Dtype(arg1)-538]);
		tb24 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O7356[dtype-538]) == tb25);
	}
	if (tb24) {
		tb24 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7334[Dtype(arg1)-538]);
		tb23 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O7334[dtype-538]) == tb24);
	}
	if (tb23) {
		tb23 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7357[Dtype(arg1)-538]);
		tb22 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O7357[dtype-538]) == tb23);
	}
	if (tb22) {
		tb22 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7333[Dtype(arg1)-538]);
		tb21 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O7333[dtype-538]) == tb22);
	}
	if (tb21) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_9_);
		tb20 = RTEQ(*(EIF_REFERENCE *)(Current + _REFACS_9_), tr1);
	}
	if (tb20) {
		tb20 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7352[Dtype(arg1)-538]);
		tb19 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O7352[dtype-538]) == tb20);
	}
	if (tb19) {
		tb19 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7329[Dtype(arg1)-538]);
		tb18 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O7329[dtype-538]) == tb19);
	}
	if (tb18) {
		tb18 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7354[Dtype(arg1)-538]);
		tb17 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O7354[dtype-538]) == tb18);
	}
	if (tb17) {
		tb17 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7331[Dtype(arg1)-538]);
		tb16 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O7331[dtype-538]) == tb17);
	}
	if (tb16) {
		tb16 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7353[Dtype(arg1)-538]);
		tb15 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O7353[dtype-538]) == tb16);
	}
	if (tb15) {
		tb15 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7330[Dtype(arg1)-538]);
		tb14 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O7330[dtype-538]) == tb15);
	}
	if (tb14) {
		tb14 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7351[Dtype(arg1)-538]);
		tb13 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O7351[dtype-538]) == tb14);
	}
	if (tb13) {
		tb13 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7328[Dtype(arg1)-538]);
		tb12 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O7328[dtype-538]) == tb13);
	}
	if (tb12) {
		tb12 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7349[Dtype(arg1)-538]);
		tb11 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O7349[dtype-538]) == tb12);
	}
	if (tb11) {
		tb11 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7326[Dtype(arg1)-538]);
		tb10 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O7326[dtype-538]) == tb11);
	}
	if (tb10) {
		tb10 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7350[Dtype(arg1)-538]);
		tb9 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O7350[dtype-538]) == tb10);
	}
	if (tb9) {
		tb9 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7327[Dtype(arg1)-538]);
		tb8 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current + O7327[dtype-538]) == tb9);
	}
	if (tb8) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
		tb7 = RTEQ(*(EIF_REFERENCE *)(Current + _REFACS_2_), tr1);
	}
	if (tb7) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		tb6 = RTEQ(*(EIF_REFERENCE *)(Current + _REFACS_1_), tr1);
	}
	if (tb6) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_10_);
		tb5 = RTEQ(*(EIF_REFERENCE *)(Current + _REFACS_10_), tr1);
	}
	if (tb5) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
		tb4 = RTEQ(*(EIF_REFERENCE *)(Current + _REFACS_4_), tr1);
	}
	if (tb4) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
		tb3 = RTEQ(*(EIF_REFERENCE *)(Current + _REFACS_5_), tr1);
	}
	if (tb3) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
		tb2 = RTEQ(*(EIF_REFERENCE *)(Current + _REFACS_6_), tr1);
	}
	if (tb2) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
		tb1 = RTEQ(*(EIF_REFERENCE *)(Current + _REFACS_8_), tr1);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_7_);
		Result = RTEQ(*(EIF_REFERENCE *)(Current + _REFACS_7_), tr1);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_OPTION}.merge_client */
void F539_7952 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,loc4);
	RTLR(5,loc1);
	RTLR(6,loc2);
	RTLR(7,loc5);
	RTLR(8,tr2);
	RTLIU(9);
	
	RTEAA("merge_client", 538, Current, 5, 1, 8091);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) == NULL)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(3);
	loc3 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	RTHOOK(4);
	if ((EIF_BOOLEAN)(loc3 == NULL)) {
		RTHOOK(5);
		loc3 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_11_);
		RTHOOK(6);
		RTAR(Current, loc3);
		*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) loc3;
	} else {
		RTHOOK(7);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_11_);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			RTHOOK(8);
			loc1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc4);
			RTHOOK(9);
			F814_8487(RTCW(loc1), loc3);
			RTHOOK(10);
			RTAR(Current, loc1);
			*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) loc1;
		}
	}
	RTHOOK(11);
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	RTHOOK(12);
	if ((EIF_BOOLEAN)(loc2 == NULL)) {
		RTHOOK(13);
		loc2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_7_);
		RTHOOK(14);
		RTAR(Current, loc2);
		*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) loc2;
	} else {
		RTHOOK(15);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_7_);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			RTHOOK(16);
			loc2 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc5);
			RTHOOK(17);
			F814_8487(RTCW(loc2), loc2);
			RTHOOK(18);
			RTAR(Current, loc2);
			*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) loc2;
		}
	}
	RTHOOK(19);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7326[dtype-538])) {
		RTHOOK(20);
		tb1 = '\01';
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7326[Dtype(arg1)-538]);
		if (!tb2) {
			tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7349[Dtype(arg1)-538]);
			tb1 = (*(EIF_BOOLEAN *)(Current + O7349[dtype-538]) != tb2);
		}
		*(EIF_BOOLEAN *)(Current + O7326[dtype-538]) = (EIF_BOOLEAN) tb1;
		RTHOOK(21);
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7349[Dtype(arg1)-538]);
		*(EIF_BOOLEAN *)(Current + O7349[dtype-538]) = (EIF_BOOLEAN) tb1;
	}
	RTHOOK(22);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7327[dtype-538])) {
		RTHOOK(23);
		tb1 = '\01';
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7327[Dtype(arg1)-538]);
		if (!tb2) {
			tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7350[Dtype(arg1)-538]);
			tb1 = (*(EIF_BOOLEAN *)(Current + O7350[dtype-538]) != tb2);
		}
		*(EIF_BOOLEAN *)(Current + O7327[dtype-538]) = (EIF_BOOLEAN) tb1;
		RTHOOK(24);
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7350[Dtype(arg1)-538]);
		*(EIF_BOOLEAN *)(Current + O7350[dtype-538]) = (EIF_BOOLEAN) tb1;
	}
	RTHOOK(25);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7328[dtype-538])) {
		RTHOOK(26);
		tb1 = '\01';
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7328[Dtype(arg1)-538]);
		if (!tb2) {
			tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7351[Dtype(arg1)-538]);
			tb1 = (*(EIF_BOOLEAN *)(Current + O7351[dtype-538]) != tb2);
		}
		*(EIF_BOOLEAN *)(Current + O7328[dtype-538]) = (EIF_BOOLEAN) tb1;
		RTHOOK(27);
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7351[Dtype(arg1)-538]);
		*(EIF_BOOLEAN *)(Current + O7351[dtype-538]) = (EIF_BOOLEAN) tb1;
	}
	RTHOOK(28);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7329[dtype-538])) {
		RTHOOK(29);
		tb1 = '\01';
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7329[Dtype(arg1)-538]);
		if (!tb2) {
			tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7352[Dtype(arg1)-538]);
			tb1 = (*(EIF_BOOLEAN *)(Current + O7352[dtype-538]) != tb2);
		}
		*(EIF_BOOLEAN *)(Current + O7329[dtype-538]) = (EIF_BOOLEAN) tb1;
		RTHOOK(30);
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7352[Dtype(arg1)-538]);
		*(EIF_BOOLEAN *)(Current + O7352[dtype-538]) = (EIF_BOOLEAN) tb1;
	}
	RTHOOK(31);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
	F1294_12234(RTCW(tr1), tr2);
	RTHOOK(32);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
	F1294_12234(RTCW(tr1), tr2);
	RTHOOK(33);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7330[dtype-538])) {
		RTHOOK(34);
		tb1 = '\01';
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7330[Dtype(arg1)-538]);
		if (!tb2) {
			tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7353[Dtype(arg1)-538]);
			tb1 = (*(EIF_BOOLEAN *)(Current + O7353[dtype-538]) != tb2);
		}
		*(EIF_BOOLEAN *)(Current + O7330[dtype-538]) = (EIF_BOOLEAN) tb1;
		RTHOOK(35);
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7353[Dtype(arg1)-538]);
		*(EIF_BOOLEAN *)(Current + O7353[dtype-538]) = (EIF_BOOLEAN) tb1;
	}
	RTHOOK(36);
	RTLE;
	RTEE;
}

/* {CONF_OPTION}.merge */
void F539_7953 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc1);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,loc3);
	RTLR(7,loc4);
	RTLIU(8);
	
	RTEAA("merge", 538, Current, 4, 1, 8092);
	RTGC;
	RTHOOK(1);
	F539_7952(Current, arg1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		tr1 = loc1;
	} else {
		RTHOOK(4);
		tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
		tr1 = tr2;
	}
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			RTHOOK(6);
			tr1 = F1237_11118(RTMS_EX_H(".",1,46));
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9749[Dtype(loc2)-1240])(loc2, tr1);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9749[Dtype(RTCW(tr1))-1240])(tr1, loc3);
		} else {
			RTHOOK(7);
			tr2 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc2);
			tr1 = tr2;
		}
	} else {
		RTHOOK(8);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc4 = tr2;
		if (EIF_TEST(loc4)) {
			RTHOOK(9);
			tr2 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc4);
			tr1 = tr2;
		} else {
			RTHOOK(10);
			tr1 = NULL;
		}
	}
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(11);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7331[dtype-538])) {
		RTHOOK(12);
		tb1 = '\01';
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7331[Dtype(arg1)-538]);
		if (!tb2) {
			tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7354[Dtype(arg1)-538]);
			tb1 = (*(EIF_BOOLEAN *)(Current + O7354[dtype-538]) != tb2);
		}
		*(EIF_BOOLEAN *)(Current + O7331[dtype-538]) = (EIF_BOOLEAN) tb1;
		RTHOOK(13);
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7354[Dtype(arg1)-538]);
		*(EIF_BOOLEAN *)(Current + O7354[dtype-538]) = (EIF_BOOLEAN) tb1;
	}
	RTHOOK(14);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_9_);
	F1294_12234(RTCW(tr1), tr2);
	RTHOOK(15);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7334[dtype-538])) {
		RTHOOK(16);
		tb1 = '\01';
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7334[Dtype(arg1)-538]);
		if (!tb2) {
			tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7356[Dtype(arg1)-538]);
			tb1 = (*(EIF_BOOLEAN *)(Current + O7356[dtype-538]) != tb2);
		}
		*(EIF_BOOLEAN *)(Current + O7334[dtype-538]) = (EIF_BOOLEAN) tb1;
		RTHOOK(17);
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7356[Dtype(arg1)-538]);
		*(EIF_BOOLEAN *)(Current + O7356[dtype-538]) = (EIF_BOOLEAN) tb1;
	}
	RTHOOK(18);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7333[dtype-538])) {
		RTHOOK(19);
		tb1 = '\01';
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7333[Dtype(arg1)-538]);
		if (!tb2) {
			tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7357[Dtype(arg1)-538]);
			tb1 = (*(EIF_BOOLEAN *)(Current + O7357[dtype-538]) != tb2);
		}
		*(EIF_BOOLEAN *)(Current + O7333[dtype-538]) = (EIF_BOOLEAN) tb1;
		RTHOOK(20);
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7357[Dtype(arg1)-538]);
		*(EIF_BOOLEAN *)(Current + O7357[dtype-538]) = (EIF_BOOLEAN) tb1;
	}
	RTHOOK(21);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
	F1294_12234(RTCW(tr1), tr2);
	RTHOOK(22);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	F1294_12234(RTCW(tr1), tr2);
	RTHOOK(23);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
	F1294_12234(RTCW(tr1), tr2);
	RTHOOK(24);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_10_);
	F1294_12234(RTCW(tr1), tr2);
	RTHOOK(25);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7332[dtype-538])) {
		RTHOOK(26);
		tb1 = '\0';
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7332[Dtype(arg1)-538]);
		if ((EIF_BOOLEAN) !tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
			tu1_1 = *(EIF_NATURAL_8 *)(RTCW(tr1)+ _CHROFF_1_2_);
			tb1 = (EIF_BOOLEAN)(tu1_1 == ((EIF_NATURAL_8) 1U));
		}
		if (tb1) {
			RTHOOK(27);
			tb1 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7355[Dtype(arg1)-538]);
			*(EIF_BOOLEAN *)(Current + O7332[dtype-538]) = (EIF_BOOLEAN) (EIF_BOOLEAN) !tb1;
			RTHOOK(28);
			*(EIF_BOOLEAN *)(Current + O7355[dtype-538]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			RTHOOK(29);
			tb1 = '\01';
			tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7332[Dtype(arg1)-538]);
			if (!tb2) {
				tb2 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7355[Dtype(arg1)-538]);
				tb1 = (*(EIF_BOOLEAN *)(Current + O7355[dtype-538]) != tb2);
			}
			*(EIF_BOOLEAN *)(Current + O7332[dtype-538]) = (EIF_BOOLEAN) tb1;
			RTHOOK(30);
			tb1 = *(EIF_BOOLEAN *)(RTCW(arg1) + O7355[Dtype(arg1)-538]);
			*(EIF_BOOLEAN *)(Current + O7355[dtype-538]) = (EIF_BOOLEAN) tb1;
		}
	}
	RTHOOK(31);
	RTLE;
	RTEE;
}

void EIF_Minit472 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
