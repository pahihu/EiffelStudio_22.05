
#ifndef _C10_ev484_
#define _C10_ev484_

#ifdef __cplusplus
extern "C" {
#endif

extern void F915_8905(EIF_REFERENCE);
extern void F915_8906(EIF_REFERENCE, EIF_REFERENCE);
extern void F915_8907(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit484(void);
extern EIF_REFERENCE _A484_166_2();
extern EIF_REFERENCE __A484_166_2();
extern void F909_8875(EIF_REFERENCE, EIF_REFERENCE);
extern void F915_8907(EIF_REFERENCE, EIF_REFERENCE);
extern void F1534_15195(EIF_REFERENCE);
extern void F1534_15194(EIF_REFERENCE);
extern EIF_REFERENCE _A484_167_2();
extern EIF_REFERENCE __A484_167_2();
extern void F913_8899(EIF_REFERENCE);
extern void F915_8906(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_TYPE_INDEX Y7670[];
extern EIF_TYPE_INDEX *Y7670_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
