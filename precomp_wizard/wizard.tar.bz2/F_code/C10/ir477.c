/*
 * Code for class IRON_REPOSITORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir477.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_REPOSITORY}.initialize */
void F556_8041 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("initialize", 555, Current, 0, 0, 8179);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R7498[Dtype(Current)-1287])(Current);
	RTHOOK(2);
	RTEE;
}

/* {IRON_REPOSITORY}.location_string */
EIF_REFERENCE F556_8045 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("location_string", 555, Current, 0, 0, 8181);
	RTGC;
	RTHOOK(1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7502[Dtype(Current)-1287])(Current);
	Result = F1782_20320(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_REPOSITORY}.new_cursor */
EIF_REFERENCE F556_8047 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("new_cursor", 555, Current, 0, 0, 8182);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7452[Dtype(RTCW(tr1))-554])(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit477 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
