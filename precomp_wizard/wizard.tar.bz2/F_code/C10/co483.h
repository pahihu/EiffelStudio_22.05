
#ifndef _C10_co483_
#define _C10_co483_

#ifdef __cplusplus
extern "C" {
#endif

extern void F908_8860(EIF_REFERENCE, EIF_REFERENCE);
extern void F908_8861(EIF_REFERENCE, EIF_INTEGER_32);
extern void F908_8862(EIF_REFERENCE, EIF_REFERENCE);
extern void F908_8863(EIF_REFERENCE, EIF_REFERENCE);
extern void F908_8864(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit483(void);
extern void F892_8780(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1237_11059(EIF_REFERENCE);
extern void F806_8436(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F1237_11119(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
