/*
 * Code for class CONF_CONDITION_LIST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co482.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_CONDITION_LIST}.make */
void F904_8846 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make", 903, Current, 0, 1, 11676);
	RTGC;
	RTHOOK(1);
	F892_8780(Current, arg1);
	RTHOOK(2);
	F567_8076(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit482 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
