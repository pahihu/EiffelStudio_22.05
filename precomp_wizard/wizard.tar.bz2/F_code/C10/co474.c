/*
 * Code for class CONF_VISIBLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co474.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_VISIBLE}.add_visible */
void F541_7991 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(13);
	RTLR(0,loc7);
	RTLR(1,Current);
	RTLR(2,loc5);
	RTLR(3,arg1);
	RTLR(4,arg3);
	RTLR(5,loc3);
	RTLR(6,loc2);
	RTLR(7,loc1);
	RTLR(8,arg2);
	RTLR(9,loc6);
	RTLR(10,arg4);
	RTLR(11,loc4);
	RTLR(12,tr1);
	RTLIU(13);
	
	RTEAA("add_visible", 540, Current, 7, 4, 8132);
	RTGC;
	RTHOOK(1);
	loc7 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc7 == NULL)) {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {814,0xFFF9,2,1186,1239,814,1239,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc7 = RTLNSMART(typres0.id);
		}
		F806_8437(RTCW(loc7), ((EIF_INTEGER_32) 1L));
		RTHOOK(4);
		RTAR(Current, loc7);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) loc7;
	}
	RTHOOK(5);
	loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9663[Dtype(RTCW(arg1))-1240])(arg1);
	RTHOOK(6);
	if ((EIF_BOOLEAN)(arg3 != NULL)) {
		RTHOOK(7);
		loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9663[Dtype(RTCW(arg3))-1240])(arg3);
	} else {
		RTHOOK(8);
		loc3 = (EIF_REFERENCE) loc5;
	}
	RTHOOK(9);
	loc2 = F806_8442(RTCW(loc7), loc5);
	RTHOOK(10);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTHOOK(11);
		loc1 = eif_boxed_item(loc2,2);
	}
	RTHOOK(12);
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		RTHOOK(13);
		loc6 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9662[Dtype(RTCW(arg2))-1240])(arg2);
		RTHOOK(14);
		if ((EIF_BOOLEAN)(arg4 != NULL)) {
			RTHOOK(15);
			loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9662[Dtype(RTCW(arg4))-1240])(arg4);
		} else {
			RTHOOK(16);
			loc4 = (EIF_REFERENCE) loc6;
		}
		RTHOOK(17);
		if ((EIF_BOOLEAN)(loc1 == NULL)) {
			RTHOOK(18);
			{
				static EIF_TYPE_INDEX typarr0[] = {814,1239,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				loc1 = RTLNS(typres0.id, 814, _OBJSIZ_7_4_0_7_0_0_0_0_);
			}
			F806_8437(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		}
		RTHOOK(19);
		F806_8483(RTCW(loc1), loc4, loc6);
	}
	RTHOOK(20);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTHOOK(21);
		
		eif_put_reference_item(RTCW(loc2),1,loc3);
		RTHOOK(22);
		
		eif_put_reference_item(RTCW(loc2),2,loc1);
	} else {
		RTHOOK(23);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1186,1239,814,1239,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		((EIF_TYPED_VALUE *)tr1+1)->it_r = loc3;
		RTAR(tr1,loc3);
		((EIF_TYPED_VALUE *)tr1+2)->it_r = loc1;
		RTAR(tr1,loc1);
		loc2 = (EIF_REFERENCE) tr1;
		RTHOOK(24);
		F1187_10755(RTCW(loc2));
	}
	RTHOOK(25);
	F806_8483(RTCW(loc7), loc2, loc5);
	RTHOOK(26);
	RTLE;
	RTEE;
}

void EIF_Minit474 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
