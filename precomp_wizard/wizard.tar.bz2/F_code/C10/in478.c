/*
 * Code for class INI_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "in478.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {INI_FILE}.make_empty */
void F566_8057 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make_empty", 565, Current, 0, 0, 8199);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {814,1239,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F815_8549(RTCW(tr1), ((EIF_INTEGER_32) 3L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {INI_FILE}.make_with_path */
void F566_8058 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("make_with_path", 565, Current, 0, 1, 8200);
	RTGC;
	RTHOOK(1);
	F566_8057(Current);
	RTHOOK(2);
	F566_8069(Current, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {INI_FILE}.item */
EIF_REFERENCE F566_8060 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("item", 565, Current, 0, 1, 8188);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F806_8442(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INI_FILE}.adjusted_item */
EIF_REFERENCE F566_8061 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTEAA("adjusted_item", 565, Current, 1, 1, 8189);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = F806_8442(RTCW(tr1), arg1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1240_11191(RTCW(Result), loc1);
		RTHOOK(3);
		F1242_11288(RTCW(Result));
		RTHOOK(4);
		F1242_11289(RTCW(Result));
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {INI_FILE}.new_cursor */
EIF_REFERENCE F566_8063 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("new_cursor", 565, Current, 0, 0, 8191);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F806_8451(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {INI_FILE}.import */
void F566_8069 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	struct eif_ex_79 sloc8;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) sloc8.data;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	memset (&sloc8.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc8.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc8.overhead, eif_new_type(85, 0x00).id);
	RTLI(12);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,loc3);
	RTLR(4,loc9);
	RTLR(5,Current);
	RTLR(6,tr1);
	RTLR(7,loc10);
	RTLR(8,loc7);
	RTLR(9,loc8);
	RTLR(10,loc6);
	RTLR(11,tr2);
	RTLIU(12);
	
	RTEAA("import", 565, Current, 10, 1, 8197);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1147, 0x00).id, 1147, _OBJSIZ_5_7_2_4_1_1_2_1_);
	F1148_10324(RTCW(loc1), arg1);
	RTHOOK(2);
	tb1 = '\0';
	tb2 = '\0';
	tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8700[Dtype(RTCW(loc1))-1146])(loc1);
	if (tb3) {
		tb3 = F1146_10086(RTCW(loc1));
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tb2 = F1146_10096(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(3);
		F1146_10112(RTCW(loc1));
		for (;;) {
			RTHOOK(4);
			tb1 = F599_8235(RTCW(loc1));
			if (tb1) break;
			RTHOOK(5);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R8759[Dtype(RTCW(loc1))-1146])(loc1);
			RTHOOK(6);
			loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
			RTHOOK(7);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R9721[Dtype(RTCW(loc2))-1241])(loc2);
			RTHOOK(8);
			tb2 = F729_8337(RTCW(loc2));
			if (tb2) {
			} else {
				RTHOOK(9);
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7739[Dtype(RTCW(loc2))-805])(loc2, ((EIF_INTEGER_32) 1L)));
				if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '#')) {
				} else {
					RTHOOK(10);
					tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7739[Dtype(RTCW(loc2))-805])(loc2, ((EIF_INTEGER_32) 1L)));
					if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '+')) {
						RTHOOK(11);
						if ((EIF_BOOLEAN)(loc3 != NULL)) {
							RTHOOK(12);
							tr1 = *(EIF_REFERENCE *)(Current);
							tr1 = F806_8442(RTCW(tr1), loc3);
							loc9 = tr1;
							if (EIF_TEST(loc9)) {
								RTHOOK(13);
								loc10 = loc9;
								loc10 = RTRV(eif_new_type(1241, 0x00),loc10);
								if (EIF_TEST(loc10)) {
									RTHOOK(14);
									loc7 = (EIF_REFERENCE) loc10;
								} else {
									RTHOOK(15);
									loc7 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
									F1240_11191(RTCW(loc7), loc9);
								}
								RTHOOK(16);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
								F1242_11317(RTCW(loc7), tw1);
								RTHOOK(17);
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
								if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L))) {
									RTHOOK(18);
									ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
									tr1 = F1237_11141(RTCW(loc2), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
									tr1 = F86_1494(RTCW(loc8), tr1);
									F1242_11304(RTCW(loc7), tr1);
								}
								RTHOOK(19);
								tr1 = *(EIF_REFERENCE *)(Current);
								F806_8483(RTCW(tr1), loc7, loc3);
							}
						} else {
							RTHOOK(20);
							*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						}
					} else {
						RTHOOK(21);
						loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R9817[Dtype(RTCW(loc2))-1243])(loc2, (EIF_CHARACTER_8) ':', ((EIF_INTEGER_32) 1L));
						RTHOOK(22);
						loc5 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R9817[Dtype(RTCW(loc2))-1243])(loc2, (EIF_CHARACTER_8) '=', ((EIF_INTEGER_32) 1L));
						RTHOOK(23);
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L)) || (EIF_BOOLEAN) ((EIF_BOOLEAN) (((EIF_INTEGER_32) 0L) < loc5) && (EIF_BOOLEAN) (loc5 < loc4)))) {
							RTHOOK(24);
							loc4 = (EIF_INTEGER_32) loc5;
						}
						RTHOOK(25);
						if ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 0L))) {
							RTHOOK(26);
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
							loc6 = F1237_11141(RTCW(loc2), (EIF_INTEGER_32) (ti4_1 - loc4));
							RTHOOK(27);
							tr1 = F1237_11140(RTCW(loc2), (EIF_INTEGER_32) (loc4 - ((EIF_INTEGER_32) 1L)));
							loc2 = (EIF_REFERENCE) tr1;
							RTHOOK(28);
							loc3 = F86_1494(RTCW(loc8), loc2);
							RTHOOK(29);
							tr1 = *(EIF_REFERENCE *)(Current);
							tr2 = F86_1494(RTCW(loc8), loc6);
							F806_8483(RTCW(tr1), tr2, loc3);
						} else {
							RTHOOK(30);
							*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						}
					}
				}
			}
		}
		RTHOOK(31);
		F1146_10129(RTCW(loc1));
	} else {
		RTHOOK(32);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTHOOK(33);
	RTLE;
	RTEE;
}

void EIF_Minit478 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
