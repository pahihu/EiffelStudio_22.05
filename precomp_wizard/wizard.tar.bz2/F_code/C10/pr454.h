
#ifndef _C10_pr454_
#define _C10_pr454_

#ifdef __cplusplus
extern "C" {
#endif

extern void F521_7534(EIF_REFERENCE, EIF_INTEGER_32);
extern void F521_7535(EIF_REFERENCE);
extern void F521_7536(EIF_REFERENCE);
extern EIF_BOOLEAN F521_7537(EIF_REFERENCE, EIF_INTEGER_32);
extern void F521_7539(EIF_REFERENCE);
extern void EIF_Minit454(void);
extern void F1139_9672(EIF_REFERENCE);
extern void F517_7513(EIF_REFERENCE, EIF_INTEGER_64);
extern void F291_4843(EIF_REFERENCE);
extern void F527_7590(EIF_REFERENCE);
extern EIF_BOOLEAN F291_4852(EIF_REFERENCE, EIF_NATURAL_64);
extern void F291_4851(EIF_REFERENCE);
extern void F291_4839(EIF_REFERENCE);
extern void F1139_9669(EIF_REFERENCE);
extern void F1139_9674(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
