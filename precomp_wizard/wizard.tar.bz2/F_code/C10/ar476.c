/*
 * Code for class ARGUMENTS_32
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ar476.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ARGUMENTS_32}.argument */
EIF_REFERENCE F555_8020 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("argument", 554, Current, 0, 1, 8170);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(105,F555_8038, (Current));
	Result = F938_9014(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {ARGUMENTS_32}.command_name */
static EIF_REFERENCE F555_8023_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRR
	RTOUDR(100)

	
	RTEAA("command_name", 554, Current, 0, 0, 8173);
	RTOTP;
	RTHOOK(1);
	Result = F555_8020(Current, ((EIF_INTEGER_32) 0L));
	RTOTE;
	RTHOOK(3);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F555_8023 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(100,F555_8023_body,(Current));
}

/* {ARGUMENTS_32}.new_cursor */
EIF_REFERENCE F555_8024 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("new_cursor", 554, Current, 0, 0, 8174);
	RTGC;
	RTHOOK(1);
	Result = F938_9018(RTCV(RTOUCR(105,F555_8038, (Current))));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {ARGUMENTS_32}.index_of_word_option */
EIF_INTEGER_32 F555_8025 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("index_of_word_option", 554, Current, 1, 1, 8175);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(2);
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (loc1 > (EIF_INTEGER_32) eif_builtin_ARGUMENTS_32_argument_count__i4)) {
			tr1 = RTOUCR(105,F555_8038, (Current));
			tr1 = F938_9014(RTCW(tr1), loc1);
			tb1 = F555_8035(Current, tr1, arg1);
		}
		if (tb1) break;
		RTHOOK(3);
		loc1++;
	}
	RTHOOK(4);
	if ((EIF_BOOLEAN) (loc1 <= (EIF_INTEGER_32) eif_builtin_ARGUMENTS_32_argument_count__i4)) {
		RTHOOK(5);
		RTHOOK(6);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) loc1;
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) 0;
}

/* {ARGUMENTS_32}.option_sign */
static EIF_REFERENCE F555_8032_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(106)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("option_sign", 554, Current, 0, 0, 8161);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {339,1189,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 339, _OBJSIZ_0_0_0_1_0_0_0_0_);
	}
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
	F340_5326(RTCW(tr1), tw1);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F555_8032 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(106,F555_8032_body,(Current));
}

/* {ARGUMENTS_32}.argument_count */
EIF_INTEGER_32 F555_8034 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("argument_count", 554, Current, 0, 0, 8163);
	Result = (EIF_INTEGER_32) eif_builtin_ARGUMENTS_32_argument_count__i4;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {ARGUMENTS_32}.option_word_equal */
EIF_BOOLEAN F555_8035 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("option_word_equal", 554, Current, 0, 2, 8164);
	RTGC;
	RTHOOK(1);
	tw1 = *(EIF_CHARACTER_32 *)(RTCV(RTOUCR(106,F555_8032, (Current)))+ _LNGOFF_0_0_0_0_);
	tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(tw1 == tw2)) {
		RTHOOK(2);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R9646[Dtype(RTCW(arg1))-1240])(arg1, arg2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) tb1;
	} else {
		RTHOOK(4);
		tb1 = '\0';
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R9618[Dtype(RTCW(arg1))-1240])(arg1);
		if ((EIF_BOOLEAN) !tb2) {
			tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R9604[Dtype(RTCW(arg1))-1240])(arg1, ((EIF_INTEGER_32) 1L));
			tw2 = *(EIF_CHARACTER_32 *)(RTCV(RTOUCR(106,F555_8032, (Current)))+ _LNGOFF_0_0_0_0_);
			tb1 = (EIF_BOOLEAN)(tw1 == tw2);
		}
		if (tb1) {
			RTHOOK(5);
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9640[Dtype(RTCW(arg1))-1240])(arg1);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R9681[Dtype(RTCW(arg1))-1240])(arg1, ((EIF_INTEGER_32) 2L), ti4_1);
			Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R9646[Dtype(RTCW(tr1))-1240])(tr1, arg2);
		}
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {ARGUMENTS_32}.internal_argument_array */
static EIF_REFERENCE F555_8038_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(105)

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("internal_argument_array", 554, Current, 1, 0, 8167);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {937,1240,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 937, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	tr2 = RTLNS(eif_new_type(1240, 0x00).id, 1240, _OBJSIZ_1_0_0_4_0_0_0_0_);
	F1237_11059(RTCW(tr2));
	ti4_1 = (EIF_INTEGER_32) eif_builtin_ARGUMENTS_32_argument_count__i4;
	F938_9009(RTCW(tr1), tr2, ((EIF_INTEGER_32) 0L), ti4_1);
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	F567_8076(RTCW(Result));
	for (;;) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) (loc1 > (EIF_INTEGER_32) eif_builtin_ARGUMENTS_32_argument_count__i4)) break;
		RTHOOK(4);
		tr1 = F555_8039(Current, loc1);
		F938_9033(RTCW(Result), tr1, loc1);
		RTHOOK(5);
		loc1++;
	}
	RTOTE;
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F555_8038 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(105,F555_8038_body,(Current));
}

/* {ARGUMENTS_32}.i_th_argument_string */
EIF_REFERENCE F555_8039 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("i_th_argument_string", 554, Current, 2, 1, 8168);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(513, 0x00).id, 513, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F514_7412(RTCW(loc1), ((EIF_INTEGER_32) 0L));
	RTHOOK(2);
	loc2 = (EIF_POINTER) eif_builtin_ARGUMENTS_32_i_th_argument_pointer__i4_p (arg1);
	RTHOOK(3);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc2 != tp1)) {
		RTHOOK(4);
		F514_7428(RTCW(loc1), loc2);
		RTHOOK(5);
		Result = RTLNS(eif_new_type(1240, 0x00).id, 1240, _OBJSIZ_1_0_0_4_0_0_0_0_);
		tr1 = F514_7416(RTCW(loc1));
		F1240_11191(RTCW(Result), tr1);
	} else {
		RTHOOK(6);
		Result = RTLNS(eif_new_type(1240, 0x00).id, 1240, _OBJSIZ_1_0_0_4_0_0_0_0_);
		F1237_11059(RTCW(Result));
		RTHOOK(7);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) Result;
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {ARGUMENTS_32}.i_th_argument_pointer */
EIF_POINTER F555_8040 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("i_th_argument_pointer", 554, Current, 0, 1, 8169);
	Result = (EIF_POINTER) eif_builtin_ARGUMENTS_32_i_th_argument_pointer__i4_p (arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit476 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
