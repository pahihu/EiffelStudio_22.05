
#ifndef _C10_pr458_
#define _C10_pr458_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F525_7563(EIF_REFERENCE);
extern EIF_INTEGER_32 F525_7564(EIF_REFERENCE);
extern void EIF_Minit458(void);

#ifdef __cplusplus
}
#endif

#endif
