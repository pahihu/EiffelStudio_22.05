/*
 * Code for class CONF_LOAD_PARSE_CALLBACKS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co470.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_LOAD_PARSE_CALLBACKS}.make_with_factory */
void F537_7732 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTEAA("make_with_factory", 536, Current, 0, 2, 7870);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	{
		/* INLINED CODE (XML_CALLBACKS_NULL.make) */
		/* END INLINED CODE */
	}
	;
	RTHOOK(3);
	{
		static EIF_TYPE_INDEX typarr0[] = {888,1486,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F884_8665(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	{
		static EIF_TYPE_INDEX typarr0[] = {807,1241,1486,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F808_8436(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_22_) = (EIF_REFERENCE) tr1;
	RTHOOK(5);
	tr1 = RTLNSMART(eif_new_type(1241, 0).id);
	F1237_11059(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) tr1;
	RTHOOK(6);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) arg2;
	RTHOOK(7);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_26_3_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 100000L);
	RTHOOK(8);
	{
		static EIF_TYPE_INDEX typarr0[] = {886,907,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F883_8665(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_24_) = (EIF_REFERENCE) tr1;
	RTHOOK(9);
	{
		static EIF_TYPE_INDEX typarr0[] = {814,1239,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F806_8436(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.on_start_tag */
void F537_7736 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc4);
	RTLR(2,arg3);
	RTLR(3,arg1);
	RTLR(4,tr1);
	RTLR(5,loc2);
	RTLR(6,loc3);
	RTLIU(7);
	
	RTEAA("on_start_tag", 536, Current, 4, 3, 7874);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_)) {
		RTHOOK(2);
		loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9662[Dtype(RTCW(arg3))-1240])(arg3);
		RTHOOK(3);
		F455_6668(Current, arg1);
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
		tb1 = F727_8337(RTCW(tr1));
		if (tb1) {
			RTHOOK(5);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
			F889_8724(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		}
		RTHOOK(6);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
		ti4_1 = F889_8722(RTCW(tr1));
		loc1 = F537_7805(Current, ti4_1, loc4);
		RTHOOK(7);
		tr1 = RTLNSMART(eif_new_type(1241, 0).id);
		F1237_11059(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) tr1;
		RTHOOK(8);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(F537_7804(Current) == ((EIF_INTEGER_32) 0L))) {
			tb1 = (EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 44L));
		}
		if (tb1) {
			RTHOOK(9);
			loc2 = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_5_1_0_1_0_0_0_0_);
			F908_8860(RTCW(loc2), loc4);
			RTHOOK(10);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
			F887_8724(RTCW(tr1), loc2);
		} else {
			RTHOOK(11);
			if ((EIF_BOOLEAN) (F537_7804(Current) > ((EIF_INTEGER_32) 0L))) {
				RTHOOK(12);
				loc2 = RTLNS(eif_new_type(907, 0x00).id, 907, _OBJSIZ_5_1_0_1_0_0_0_0_);
				F908_8860(RTCW(loc2), loc4);
				RTHOOK(13);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				loc3 = F887_8722(RTCW(tr1));
				RTHOOK(14);
				F892_8821(RTCW(loc3), loc2);
				RTHOOK(15);
				F908_8864(RTCW(loc2), loc3);
				RTHOOK(16);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				F887_8724(RTCW(tr1), loc2);
			}
		}
		RTHOOK(17);
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
			RTHOOK(18);
			tr1 = RTOUCR(474,F421_6046, (Current));
			tr1 = F1749_19457(RTCW(tr1), arg3);
			F455_6671(Current, tr1);
			RTHOOK(19);
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		}
		RTHOOK(20);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
		F889_8724(RTCW(tr1), loc1);
	}
	RTHOOK(21);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.on_attribute */
void F537_7737 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,arg3);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,tr2);
	RTLR(6,arg4);
	RTLIU(7);
	
	RTEAA("on_attribute", 536, Current, 3, 4, 7875);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tb2 = '\0';
	tb3 = '\0';
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_)) {
		tr1 = RTMS_EX_H("xmlns",5,1836744307);
		tb4 = F1237_11101(RTCW(arg3), tr1);
		tb3 = (EIF_BOOLEAN) !tb4;
	}
	if (tb3) {
		tr1 = RTMS_EX_H("xsi",3,7893865);
		tb3 = F1237_11101(RTCW(arg3), tr1);
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tr1 = RTMS_EX_H("schemaLocation",14,147944814);
		tb2 = F1237_11101(RTCW(arg3), tr1);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(2);
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9662[Dtype(RTCW(arg3))-1240])(arg3);
		RTHOOK(3);
		if ((EIF_BOOLEAN)(F537_7804(Current) == ((EIF_INTEGER_32) 0L))) {
			RTHOOK(4);
			tr1 = RTOUCR(475,F537_7814, (Current));
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
			ti4_1 = F889_8722(RTCW(tr2));
			tr1 = F808_8442(RTCW(tr1), ti4_1);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				RTHOOK(5);
				loc1 = F809_8442(loc3, loc2);
			}
			RTHOOK(6);
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_22_) == NULL)) {
				RTHOOK(7);
				{
					static EIF_TYPE_INDEX typarr0[] = {807,1241,1486,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr1 = RTLNSMART(typres0.id);
				}
				F808_8436(RTCW(tr1), ((EIF_INTEGER_32) 1L));
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_22_) = (EIF_REFERENCE) tr1;
			}
			RTHOOK(8);
			tb1 = '\0';
			if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
				tb2 = F808_8444(RTCW(tr1), loc1);
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				RTHOOK(9);
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R9618[Dtype(RTCW(arg4))-1240])(arg4);
				if ((EIF_BOOLEAN) !tb1) {
					RTHOOK(10);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
					tr2 = F537_7811(Current, arg4);
					F808_8483(RTCW(tr1), tr2, loc1);
				} else {
					RTHOOK(11);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr1 = F1749_19458(RTCW(tr1), arg3);
					F455_6671(Current, tr1);
				}
			} else {
				RTHOOK(12);
				F537_7816(Current, arg3);
			}
		} else {
			RTHOOK(13);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
			tr2 = F537_7811(Current, arg4);
			F806_8483(RTCW(tr1), tr2, loc2);
		}
	}
	RTHOOK(14);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.on_start_tag_finish */
void F537_7738 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,tr5);
	RTLR(6,loc1);
	RTLR(7,loc2);
	RTLIU(8);
	
	RTEAA("on_start_tag_finish", 536, Current, 2, 0, 7876);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
		ti4_1 = F889_8722(RTCW(tr1));
		switch (ti4_1) {
			case 47L:
				RTHOOK(3);
				F537_7744(Current);
				break;
			case 2L:
				RTHOOK(4);
				F537_7745(Current);
				break;
			case 4L:
				RTHOOK(5);
				F537_7746(Current);
				break;
			case 5L:
				RTHOOK(6);
				F537_7747(Current);
				break;
			case 6L:
				RTHOOK(7);
				F537_7748(Current);
				break;
			case 8L:
				RTHOOK(8);
				F537_7764(Current, (EIF_BOOLEAN) 0);
				break;
			case 9L:
				RTHOOK(9);
				F537_7749(Current);
				break;
			case 50L:
				RTHOOK(10);
				{
					EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,0,0xFFFF};
					EIF_TYPE typres0;
					typarr0[3] = dftype;
					
					typres0 = eif_compound_id(dftype, typarr0);
					tr1 = RTLNTS(typres0.id, 2, 0);
				}
				((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
				RTAR(tr1,Current);
				
				{
					static EIF_TYPE_INDEX typarr0[] = {1231,0xFFF9,1,1186,539,1294,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr4= RTLNRF(typres0.id, (EIF_POINTER) __A470_639_2, (EIF_POINTER) _A470_639_2, 0, tr1, 0, 1);
				}
				tr5 = RTOUCR(455,F373_5841, (Current));
				F537_7750(Current, tr4, tr5);
				break;
			case 51L:
				break;
			case 52L:
				RTHOOK(11);
				{
					EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,0,0xFFFF};
					EIF_TYPE typres0;
					typarr0[3] = dftype;
					
					typres0 = eif_compound_id(dftype, typarr0);
					tr1 = RTLNTS(typres0.id, 2, 0);
				}
				((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
				RTAR(tr1,Current);
				
				{
					static EIF_TYPE_INDEX typarr0[] = {1231,0xFFF9,1,1186,539,1294,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr4= RTLNRF(typres0.id, (EIF_POINTER) __A470_640_2, (EIF_POINTER) _A470_640_2, 0, tr1, 0, 1);
				}
				tr5 = RTOUCR(456,F373_5843, (Current));
				F537_7750(Current, tr4, tr5);
				break;
			case 53L:
				break;
			case 54L:
				RTHOOK(12);
				{
					EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,0,0xFFFF};
					EIF_TYPE typres0;
					typarr0[3] = dftype;
					
					typres0 = eif_compound_id(dftype, typarr0);
					tr1 = RTLNTS(typres0.id, 2, 0);
				}
				((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
				RTAR(tr1,Current);
				
				{
					static EIF_TYPE_INDEX typarr0[] = {1231,0xFFF9,1,1186,539,1294,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr4= RTLNRF(typres0.id, (EIF_POINTER) __A470_641_2, (EIF_POINTER) _A470_641_2, 0, tr1, 0, 1);
				}
				tr5 = RTOUCR(457,F373_5845, (Current));
				F537_7750(Current, tr4, tr5);
				break;
			case 28L:
				RTHOOK(13);
				loc1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
				RTHOOK(14);
				if ((EIF_BOOLEAN)(loc1 != NULL)) {
					RTHOOK(15);
					F537_7762(Current, loc1);
				} else {
					
				}
				break;
			case 27L:
				RTHOOK(17);
				loc1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
				RTHOOK(18);
				if ((EIF_BOOLEAN)(loc1 != NULL)) {
					RTHOOK(19);
					F537_7760(Current, loc1);
				} else {
					
				}
				break;
			case 29L:
				RTHOOK(21);
				loc1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
				RTHOOK(22);
				if ((EIF_BOOLEAN)(loc1 != NULL)) {
					RTHOOK(23);
					F537_7761(Current, loc1);
				} else {
					
				}
				break;
			case 10L:
			case 11L:
			case 12L:
			case 13L:
			case 14L:
			case 15L:
			case 16L:
				RTHOOK(25);
				F537_7752(Current);
				break;
			case 7L:
				RTHOOK(26);
				F537_7751(Current);
				break;
			case 17L:
				RTHOOK(27);
				F537_7753(Current);
				break;
			case 18L:
				RTHOOK(28);
				F537_7753(Current);
				break;
			case 19L:
				RTHOOK(29);
				F537_7754(Current);
				break;
			case 20L:
				RTHOOK(30);
				F537_7756(Current);
				break;
			case 21L:
				RTHOOK(31);
				F537_7755(Current);
				break;
			case 22L:
				RTHOOK(32);
				F537_7757(Current);
				break;
			case 23L:
				RTHOOK(33);
				F537_7758(Current, (EIF_BOOLEAN) 0);
				break;
			case 45L:
				RTHOOK(34);
				F537_7758(Current, (EIF_BOOLEAN) 1);
				break;
			case 24L:
				RTHOOK(35);
				F537_7759(Current);
				break;
			case 38L:
				RTHOOK(36);
				F537_7763(Current);
				break;
			case 39L:
				RTHOOK(37);
				F537_7764(Current, (EIF_BOOLEAN) 1);
				break;
			case 41L:
				RTHOOK(38);
				F537_7765(Current);
				break;
			case 40L:
				RTHOOK(39);
				F537_7766(Current);
				break;
			case 42L:
				RTHOOK(40);
				F537_7767(Current);
				break;
			case 30L:
				RTHOOK(41);
				F537_7768(Current);
				break;
			case 31L:
				RTHOOK(42);
				loc2 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
				RTHOOK(43);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					RTHOOK(44);
					F537_7769(Current, loc2);
				} else {
					
				}
				break;
			case 32L:
				RTHOOK(46);
				loc2 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
				RTHOOK(47);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					RTHOOK(48);
					F537_7770(Current, loc2);
				} else {
					
				}
				break;
			case 33L:
				RTHOOK(50);
				loc2 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
				RTHOOK(51);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					RTHOOK(52);
					F537_7771(Current, loc2);
				} else {
					
				}
				break;
			case 46L:
				RTHOOK(54);
				loc2 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
				RTHOOK(55);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					RTHOOK(56);
					F537_7772(Current, loc2);
				} else {
					
				}
				break;
			case 48L:
				RTHOOK(58);
				loc2 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
				RTHOOK(59);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					RTHOOK(60);
					F537_7773(Current, loc2);
				} else {
					
				}
				break;
			case 34L:
				RTHOOK(62);
				loc2 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
				RTHOOK(63);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					RTHOOK(64);
					F537_7774(Current, loc2);
				} else {
					
				}
				break;
			case 35L:
				RTHOOK(66);
				loc2 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
				RTHOOK(67);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					RTHOOK(68);
					F537_7775(Current, loc2);
				} else {
					
				}
				break;
			case 36L:
				RTHOOK(70);
				loc2 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
				RTHOOK(71);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					RTHOOK(72);
					F537_7776(Current, loc2);
				} else {
					
				}
				break;
			case 37L:
				RTHOOK(74);
				loc2 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
				RTHOOK(75);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					RTHOOK(76);
					F537_7777(Current, loc2);
				} else {
					
				}
				break;
			case 43L:
				RTHOOK(78);
				F537_7778(Current);
				break;
			case 44L:
				RTHOOK(79);
				F537_7802(Current);
				break;
			default:
				RTHOOK(80);
				if ((EIF_BOOLEAN) (F537_7804(Current) > ((EIF_INTEGER_32) 0L))) {
					RTHOOK(81);
					F537_7802(Current);
				}
				break;
		}
		RTHOOK(82);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		F808_8490(RTCW(tr1));
		RTHOOK(83);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
		F806_8490(RTCW(tr1));
	}
	RTHOOK(84);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.on_end_tag */
void F537_7739 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTLD;
	
	RTLI(16);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc3);
	RTLR(4,loc4);
	RTLR(5,loc2);
	RTLR(6,loc5);
	RTLR(7,loc6);
	RTLR(8,loc7);
	RTLR(9,loc8);
	RTLR(10,tr2);
	RTLR(11,tr3);
	RTLR(12,loc9);
	RTLR(13,loc10);
	RTLR(14,arg1);
	RTLR(15,tr4);
	RTLIU(16);
	
	RTEAA("on_end_tag", 536, Current, 10, 3, 7877);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
		tb1 = F1237_11077(RTCW(tr1));
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(3);
			F537_7812(Current, *(EIF_REFERENCE *)(Current + _REFACS_19_));
			RTHOOK(4);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
			ti4_1 = F889_8722(RTCW(tr1));
			switch (ti4_1) {
				case 3L:
					RTHOOK(5);
					F537_7780(Current);
					break;
				case 25L:
					RTHOOK(6);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
					F1239_11182(RTCW(tr1));
					RTHOOK(7);
					F537_7781(Current);
					break;
				case 26L:
					RTHOOK(8);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
					F1239_11182(RTCW(tr1));
					RTHOOK(9);
					F537_7782(Current);
					break;
				default:
					RTHOOK(10);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
					F1239_11182(RTCW(tr1));
					RTHOOK(11);
					if ((EIF_BOOLEAN) (F537_7804(Current) > ((EIF_INTEGER_32) 0L))) {
						RTHOOK(12);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
						tr1 = F887_8722(RTCW(tr1));
						F908_8863(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_19_));
					} else {
						RTHOOK(13);
						tr1 = RTOUCR(474,F421_6046, (Current));
						tr1 = F1749_19462(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_19_));
						F455_6671(Current, tr1);
					}
					break;
			}
		}
		RTHOOK(14);
		tr1 = RTLNSMART(eif_new_type(1241, 0).id);
		F1237_11059(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) tr1;
		RTHOOK(15);
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
		RTHOOK(16);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
		ti4_1 = F889_8722(RTCW(tr1));
		switch (ti4_1) {
			case 2L:
				RTHOOK(17);
				if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_8_) != NULL)) {
					RTHOOK(18);
					tr1 = RTLNS(eif_new_type(1111, 0x00).id, 1111, _OBJSIZ_2_0_0_3_0_0_0_0_);
					F1112_9404(RTCW(tr1));
					F455_6669(Current, tr1);
				}
				RTHOOK(19);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
				loc3 = tr1;
				if (EIF_TEST(loc3)) {
					RTHOOK(20);
					tr1 = *(EIF_REFERENCE *)(loc3 + _REFACS_7_);
					loc4 = F806_8451(RTCW(tr1));
					for (;;) {
						tb1 = F1023_9232(loc4);
						if (tb1) break;
						RTHOOK(21);
						loc2 = F1023_9229(loc4);
						RTHOOK(22);
						tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_7_);
						loc5 = tr1;
						if (EIF_TEST(loc5)) {
							RTHOOK(23);
							tb2 = '\01';
							loc6 = loc5;
							loc6 = RTRV(eif_new_type(297, 0x00),loc6);
							if (!((EIF_BOOLEAN) !EIF_TEST(loc6))) {
								tr1 = *(EIF_REFERENCE *)(loc6);
								loc7 = tr1;
								tb2 = (EIF_BOOLEAN) !EIF_TEST(loc7);
							}
							if (tb2) {
							} else {
								RTHOOK(24);
								tr1 = F1742_18855(loc3, loc7);
								loc8 = tr1;
								if ((EIF_BOOLEAN) !EIF_TEST(loc8)) {
									RTHOOK(25);
									tr1 = RTOUCR(474,F421_6046, (Current));
									tr2 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_4_);
									tr1 = F1749_19467(RTCW(tr1), loc7, tr2);
									F455_6671(Current, tr1);
								} else {
									RTHOOK(26);
									tb2 = '\01';
									if (!(EIF_BOOLEAN)(loc2 == loc8)) {
										tb3 = F1301_12514(RTCW(loc2), loc8);
										tb2 = tb3;
									}
									if (tb2) {
										RTHOOK(27);
										tr1 = RTOUCR(474,F421_6046, (Current));
										tr2 = *(EIF_REFERENCE *)(loc8 + _REFACS_4_);
										tr3 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_4_);
										tr1 = F1749_19467(RTCW(tr1), tr2, tr3);
										F455_6671(Current, tr1);
									} else {
										RTHOOK(28);
										F1301_12463(RTCW(loc2), loc8);
									}
								}
							}
						}
						RTHOOK(29);
						F1023_9233(loc4);
					}
				}
				break;
			case 4L:
				RTHOOK(30);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
				loc9 = tr1;
				if (EIF_TEST(loc9)) {
					RTHOOK(31);
					tb2 = '\0';
					tb3 = '\0';
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
					loc10 = tr1;
					if (EIF_TEST(loc10)) {
						tr1 = *(EIF_REFERENCE *)(loc10 + _REFACS_8_);
						tb3 = (EIF_BOOLEAN)(loc9 == tr1);
					}
					if (tb3) {
						tr1 = F1301_12442(loc9);
						tb3 = F724_8337(RTCW(tr1));
						tb2 = (EIF_BOOLEAN) !tb3;
					}
					if (tb2) {
						RTHOOK(32);
						tr1 = RTLNS(eif_new_type(1110, 0x00).id, 1110, _OBJSIZ_2_0_0_3_0_0_0_0_);
						F1111_9403(RTCW(tr1));
						F455_6669(Current, tr1);
					}
					RTHOOK(33);
					tr1 = *(EIF_REFERENCE *)(loc9 + _REFACS_6_);
					if ((EIF_BOOLEAN)(tr1 == NULL)) {
						RTHOOK(34);
						if ((EIF_BOOLEAN)(arg1 != NULL)) {
							RTHOOK(35);
							F537_7783(Current, loc9, arg1);
						} else {
							RTHOOK(36);
							tr1 = RTOUCR(476,F189_3474, (Current));
							F537_7783(Current, loc9, tr1);
						}
					}
					RTHOOK(37);
					*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) NULL;
				}
				break;
			case 7L:
				RTHOOK(38);
				*(EIF_REFERENCE *)(Current + _REFACS_15_) = (EIF_REFERENCE) NULL;
				break;
			case 8L:
				RTHOOK(39);
				*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) NULL;
				break;
			case 10L:
				RTHOOK(40);
				{
					EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,0,0xFFFF};
					EIF_TYPE typres0;
					typarr0[3] = dftype;
					
					typres0 = eif_compound_id(dftype, typarr0);
					tr1 = RTLNTS(typres0.id, 2, 0);
				}
				((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
				RTAR(tr1,Current);
				
				{
					static EIF_TYPE_INDEX typarr0[] = {1230,0xFFF9,1,1186,1239,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr4= RTLNRF(typres0.id, (EIF_POINTER) __A470_562_2, (EIF_POINTER) _A470_562_2, (EIF_POINTER)(F537_7741),tr1, 1, 1);
				}
				F537_7743(Current, tr4);
				RTHOOK(41);
				*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) NULL;
				break;
			case 12L:
			case 13L:
				RTHOOK(42);
				{
					EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,0,0xFFFF};
					EIF_TYPE typres0;
					typarr0[3] = dftype;
					
					typres0 = eif_compound_id(dftype, typarr0);
					tr1 = RTLNTS(typres0.id, 2, 0);
				}
				((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
				RTAR(tr1,Current);
				
				{
					static EIF_TYPE_INDEX typarr0[] = {1230,0xFFF9,1,1186,1239,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr4= RTLNRF(typres0.id, (EIF_POINTER) __A470_563_2, (EIF_POINTER) _A470_563_2, (EIF_POINTER)(F537_7742),tr1, 1, 1);
				}
				F537_7743(Current, tr4);
				RTHOOK(43);
				*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) NULL;
				break;
			case 11L:
			case 14L:
			case 15L:
			case 16L:
				RTHOOK(44);
				*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) NULL;
				break;
			case 17L:
				RTHOOK(45);
				*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) NULL;
				break;
			case 18L:
				RTHOOK(46);
				*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) NULL;
				break;
			case 20L:
				RTHOOK(47);
				*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) NULL;
				RTHOOK(48);
				*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) NULL;
				break;
			case 21L:
				RTHOOK(49);
				*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) NULL;
				RTHOOK(50);
				*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) NULL;
				break;
			case 22L:
				RTHOOK(51);
				*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) NULL;
				RTHOOK(52);
				*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) NULL;
				break;
			case 23L:
				RTHOOK(53);
				if ((EIF_BOOLEAN)(loc1 != NULL)) {
					RTHOOK(54);
					tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_18_);
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) tr1;
					RTHOOK(55);
					tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_18_);
					loc1 = (EIF_REFERENCE) tr1;
					RTHOOK(56);
					RTAR(Current, loc1);
					*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) loc1;
				} else {
					
				}
				break;
			case 45L:
				RTHOOK(58);
				if ((EIF_BOOLEAN)(loc1 != NULL)) {
					RTHOOK(59);
					tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_18_);
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) tr1;
					RTHOOK(60);
					tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_18_);
					loc1 = (EIF_REFERENCE) tr1;
					RTHOOK(61);
					RTAR(Current, loc1);
					*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) loc1;
				} else {
					
				}
				break;
			case 24L:
				RTHOOK(63);
				if ((EIF_BOOLEAN)(loc1 != NULL)) {
					RTHOOK(64);
					tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_18_);
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) tr1;
					RTHOOK(65);
					tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_18_);
					loc1 = (EIF_REFERENCE) tr1;
					RTHOOK(66);
					RTAR(Current, loc1);
					*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) loc1;
				} else {
					
				}
				RTHOOK(68);
				*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) NULL;
				break;
			case 39L:
				RTHOOK(69);
				*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) NULL;
				break;
			default:
				RTHOOK(70);
				if ((EIF_BOOLEAN) (F537_7804(Current) > ((EIF_INTEGER_32) 0L))) {
					RTHOOK(71);
					if ((EIF_BOOLEAN)(F537_7804(Current) == ((EIF_INTEGER_32) 1L))) {
						RTHOOK(72);
						F537_7803(Current);
					}
					RTHOOK(73);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					F887_8726(RTCW(tr1));
				}
				break;
		}
		RTHOOK(74);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
		F889_8726(RTCW(tr1));
	}
	RTHOOK(75);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.on_content */
void F537_7740 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("on_content", 536, Current, 0, 1, 7878);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
		F1242_11306(RTCW(tr1), arg1);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.create_external_cflag */
void F537_7741 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTEAA("create_external_cflag", 536, Current, 2, 1, 7879);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		loc1 = F453_6638(RTCW(tr1), arg1, loc2);
		RTHOOK(3);
		F1301_12490(loc2, loc1);
		RTHOOK(4);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) loc1;
	} else {
		RTHOOK(5);
		tr1 = F1749_19547(RTCV(RTOUCR(474,F421_6046, (Current))));
		F455_6671(Current, tr1);
		RTHOOK(6);
		*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) NULL;
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.create_external_linker_flag */
void F537_7742 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTEAA("create_external_linker_flag", 536, Current, 2, 1, 7880);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		loc1 = F453_6642(RTCW(tr1), arg1, loc2);
		RTHOOK(3);
		F1301_12494(loc2, loc1);
		RTHOOK(4);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) loc1;
	} else {
		RTHOOK(5);
		tr1 = F1749_19547(RTCV(RTOUCR(474,F421_6046, (Current))));
		F455_6671(Current, tr1);
		RTHOOK(6);
		*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) NULL;
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.split_external */
void F537_7743 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc5);
	RTLR(4,loc3);
	RTLR(5,loc7);
	RTLR(6,loc8);
	RTLR(7,loc9);
	RTLR(8,arg1);
	RTLR(9,loc10);
	RTLIU(10);
	
	RTEAA("split_external", 536, Current, 10, 1, 7881);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tb2 = '\0';
	tb3 = '\0';
	tb4 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		tr1 = RTOUCR(477,F452_6589, (Current));
		tb4 = F454_6655(Current, tr1);
	}
	if (tb4) {
		tr1 = *(EIF_REFERENCE *)(loc4 + _REFACS_3_);
		loc5 = tr1;
		tb3 = EIF_TEST(loc5);
	}
	if (tb3) {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
		tb3 = F1240_11223(loc5, tw1);
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tb2 = '\01';
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
		tb3 = F1240_11223(loc5, tw1);
		if (!tb3) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\011';
			tb3 = F1240_11223(loc5, tw1);
			tb2 = tb3;
		}
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(2);
		loc3 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1240_11191(RTCW(loc3), loc5);
		RTHOOK(3);
		F1242_11288(RTCW(loc3));
		RTHOOK(4);
		F1242_11289(RTCW(loc3));
		RTHOOK(5);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6415[Dtype(loc4)-463])(loc4);
		if (tb1) {
			RTHOOK(6);
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			RTHOOK(7);
			loc2 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_1_1_0_2_);
			for (;;) {
				RTHOOK(12);
				tb1 = '\01';
				if (!(EIF_BOOLEAN) (loc1 > loc2)) {
					tw1 = F1242_11271(RTCW(loc3), loc1);
					tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
					*(EIF_CHARACTER_32 *)tr1 = tw1;
					tb2 = F1188_10895(RTCW(tr1));
					tb1 = tb2;
				}
				if (tb1) break;
				RTHOOK(13);
				loc1++;
			}
			RTHOOK(14);
			tr1 = F1242_11351(RTCW(loc3), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
			F463_6826(loc4, tr1);
			RTHOOK(15);
			F1242_11326(RTCW(loc3), loc1);
			RTHOOK(16);
			F1242_11288(RTCW(loc3));
		} else {
			RTHOOK(17);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
			loc7 = tr1;
			if (EIF_TEST(loc7)) {
				RTHOOK(18);
				loc8 = loc4;
				loc8 = RTRV(eif_new_type(466, 0x00),loc8);
				if (EIF_TEST(loc8)) {
					RTHOOK(19);
					F1301_12498(loc7, loc8);
				} else {
					RTHOOK(20);
					loc9 = loc4;
					loc9 = RTRV(eif_new_type(465, 0x00),loc9);
					if (EIF_TEST(loc9)) {
						RTHOOK(21);
						F1301_12499(loc7, loc9);
					}
				}
			} else {
				
			}
		}
		RTHOOK(23);
		(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_0_))(
			*(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_1_),
			*(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_), loc3);
		RTHOOK(24);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
		loc10 = tr1;
		if (EIF_TEST(loc10)) {
			RTHOOK(25);
			tr1 = *(EIF_REFERENCE *)(loc4 + _REFACS_1_);
			F463_6827(loc10, tr1);
			RTHOOK(26);
			tr1 = *(EIF_REFERENCE *)(loc4);
			F463_6829(loc10, tr1);
		}
	}
	RTHOOK(27);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_redirection_attributes */
void F537_7744 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc4);
	RTLR(5,tr2);
	RTLR(6,loc3);
	RTLR(7,loc5);
	RTLIU(8);
	
	RTEAA("process_redirection_attributes", 536, Current, 5, 0, 7882);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1002L));
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTHOOK(3);
		if (F455_6667(Current, loc1)) {
			RTHOOK(4);
			loc2 = RTLNS(eif_new_type(1298, 0x00).id, 1298, _OBJSIZ_0_0_3_1_0_0_1_0_);
			F1299_12360(RTCW(loc2), loc1);
		} else {
			RTHOOK(5);
			tr1 = RTLNS(eif_new_type(1114, 0x00).id, 1114, _OBJSIZ_2_0_0_3_0_0_0_0_);
			F1115_9412(RTCW(tr1));
			F455_6669(Current, tr1);
		}
	}
	RTHOOK(6);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_)) {
		RTHOOK(7);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1025L));
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			RTHOOK(8);
			tr1 = RTOUCR(478,F452_6595, (Current));
			if (F454_6656(Current, tr1)) {
				RTHOOK(9);
				tb1 = F730_8337(loc4);
				if (tb1) {
					RTHOOK(10);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr2 = RTMS_EX_H("location",8,59511406);
					tr1 = F1749_19459(RTCW(tr1), tr2);
					F455_6671(Current, tr1);
				} else {
					RTHOOK(11);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
					loc3 = F453_6625(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_4_), loc4, loc2);
					RTHOOK(12);
					tb1 = '\0';
					tr1 = RTOUCR(479,F452_6603, (Current));
					if (F454_6656(Current, tr1)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
						tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1066L));
						loc5 = tr1;
						tb1 = EIF_TEST(loc5);
					}
					if (tb1) {
						RTHOOK(13);
						F1741_18840(RTCW(loc3), loc5);
					}
					RTHOOK(14);
					RTAR(Current, loc3);
					*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) loc3;
				}
			} else {
				RTHOOK(15);
				tr1 = RTMS_EX_H("location",8,59511406);
				F537_7816(Current, tr1);
			}
		} else {
			RTHOOK(16);
			tr1 = RTOUCR(478,F452_6595, (Current));
			if (F454_6656(Current, tr1)) {
				RTHOOK(17);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr2 = RTMS_EX_H("location",8,59511406);
				tr1 = F1749_19461(RTCW(tr1), tr2);
				F455_6671(Current, tr1);
			}
		}
	}
	RTHOOK(19);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_system_attributes */
void F537_7745 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(13);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc6);
	RTLR(6,loc4);
	RTLR(7,loc5);
	RTLR(8,tr2);
	RTLR(9,loc7);
	RTLR(10,tr3);
	RTLR(11,loc8);
	RTLR(12,loc9);
	RTLIU(13);
	
	RTEAA("process_system_attributes", 536, Current, 9, 0, 7883);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1001L));
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTHOOK(3);
		loc2 = F1242_11339(RTCW(loc1));
	}
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc3 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1002L));
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1003L));
	loc6 = tr1;
	if (EIF_TEST(loc6)) {
		RTHOOK(6);
		tr1 = F1242_11339(loc6);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(7);
		*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) NULL;
	}
	RTHOOK(8);
	if ((EIF_BOOLEAN)(loc2 == NULL)) {
		RTHOOK(9);
		tr1 = F1749_19463(RTCV(RTOUCR(474,F421_6046, (Current))));
		F455_6671(Current, tr1);
	} else {
		RTHOOK(10);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTHOOK(11);
			if ((EIF_BOOLEAN) !F270_4605(Current, loc2)) {
				RTHOOK(12);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr1 = F1749_19464(RTCW(tr1), loc1);
				F455_6671(Current, tr1);
			} else {
				RTHOOK(13);
				if ((EIF_BOOLEAN)(loc3 != NULL)) {
					RTHOOK(14);
					if (F455_6667(Current, loc3)) {
						RTHOOK(15);
						loc4 = RTLNS(eif_new_type(1298, 0x00).id, 1298, _OBJSIZ_0_0_3_1_0_0_1_0_);
						F1299_12360(RTCW(loc4), loc3);
					} else {
						RTHOOK(16);
						tr1 = RTLNS(eif_new_type(1114, 0x00).id, 1114, _OBJSIZ_2_0_0_3_0_0_0_0_);
						F1115_9412(RTCW(tr1));
						F455_6669(Current, tr1);
					}
				}
				RTHOOK(17);
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_)) {
					RTHOOK(18);
					if ((EIF_BOOLEAN)(loc4 == NULL)) {
						RTHOOK(19);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
						tr2 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
						tr3 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						loc7 = tr3;
						if (EIF_TEST(loc7)) {
							RTHOOK(20);
							tr3 = loc7;
						} else {
							RTHOOK(21);
							tr3 = RTOUCR(480,F452_6617, (Current));
						}
						loc5 = F453_6626(RTCW(tr1), tr2, loc2, tr3);
					} else {
						RTHOOK(22);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
						tr2 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
						tr3 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						loc8 = tr3;
						if (EIF_TEST(loc8)) {
							RTHOOK(23);
							tr3 = loc8;
						} else {
							RTHOOK(24);
							tr3 = RTOUCR(480,F452_6617, (Current));
						}
						loc5 = F453_6627(RTCW(tr1), tr2, loc2, loc4, tr3);
					}
					RTHOOK(25);
					RTAR(Current, loc5);
					*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) loc5;
					RTHOOK(26);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
					tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1029L));
					loc9 = tr1;
					if (EIF_TEST(loc9)) {
						RTHOOK(27);
						tb1 = F1240_11227(loc9);
						if (tb1) {
							RTHOOK(28);
							tb1 = F1237_11136(loc9);
							F1742_18881(RTCW(loc5), tb1);
						} else {
							RTHOOK(29);
							tr1 = RTOUCR(474,F421_6046, (Current));
							tr2 = RTMS_EX_H("readonly",8,1382700153);
							tr1 = F1749_19458(RTCW(tr1), tr2);
							F455_6671(Current, tr1);
						}
					}
				} else {
					RTHOOK(30);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr1 = F1749_19465(RTCW(tr1), loc1);
					F455_6671(Current, tr1);
				}
			}
		}
	}
	RTHOOK(32);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_target_attributes */
void F537_7746 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(12);
	RTLR(0,loc6);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc7);
	RTLR(4,loc2);
	RTLR(5,loc8);
	RTLR(6,tr2);
	RTLR(7,loc9);
	RTLR(8,loc4);
	RTLR(9,loc3);
	RTLR(10,loc5);
	RTLR(11,loc1);
	RTLIU(12);
	
	RTEAA("process_target_attributes", 536, Current, 9, 0, 7884);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc6 = tr1;
	if (EIF_TEST(loc6)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1001L));
		loc7 = tr1;
		if (EIF_TEST(loc7)) {
			RTHOOK(3);
			if ((EIF_BOOLEAN) !F270_4604(Current, loc7)) {
				RTHOOK(4);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr1 = F1749_19470(RTCW(tr1), loc7);
				F455_6671(Current, tr1);
			}
			RTHOOK(5);
			tr1 = *(EIF_REFERENCE *)(loc6 + _REFACS_7_);
			tb1 = F806_8444(RTCW(tr1), loc7);
			if (tb1) {
				RTHOOK(6);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr1 = F1749_19466(RTCW(tr1), loc7);
				F455_6671(Current, tr1);
			}
			RTHOOK(7);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			loc2 = F453_6628(RTCW(tr1), loc7, loc6);
			RTHOOK(8);
			RTAR(Current, loc2);
			*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) loc2;
			RTHOOK(9);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1000L));
			loc8 = tr1;
			if (EIF_TEST(loc8)) {
				RTHOOK(10);
				tb1 = F1240_11227(loc8);
				if (tb1) {
					RTHOOK(11);
					tb1 = F1237_11136(loc8);
					F1301_12512(RTCW(loc2), tb1);
				} else {
					RTHOOK(12);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr2 = RTOUCR(460,F373_5848, (Current));
					tr1 = F1749_19458(RTCW(tr1), tr2);
					F455_6671(Current, tr1);
				}
			}
			RTHOOK(13);
			tb1 = '\0';
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			loc9 = tr1;
			if (EIF_TEST(loc9)) {
				tb2 = F1237_11101(loc7, loc9);
				tb1 = tb2;
			}
			if (tb1) {
				RTHOOK(14);
				F1742_18886(loc6, loc2);
				RTHOOK(15);
				*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) NULL;
			}
			RTHOOK(16);
			F1742_18884(loc6, loc2);
			RTHOOK(17);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			loc4 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1004L));
			RTHOOK(18);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			loc3 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1005L));
			RTHOOK(19);
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				RTHOOK(20);
				tr1 = RTOUCR(481,F452_6607, (Current));
				if (F454_6656(Current, tr1)) {
					RTHOOK(21);
					tr1 = F1740_18828(loc6);
					tr2 = RTLNS(eif_new_type(1765, 0x00).id, 1765, _OBJSIZ_3_0_0_0_0_0_0_0_);
					F1766_19742(RTCW(tr2), loc4, loc2);
					tr2 = F1765_19729(RTCW(tr2));
					tb1 = F1304_12650(RTCW(tr1), tr2);
					if (tb1) {
						RTHOOK(22);
						loc4 = (EIF_REFERENCE) NULL;
					} else {
						RTHOOK(23);
						tr1 = RTLNS(eif_new_type(298, 0x00).id, 298, _OBJSIZ_3_1_0_0_0_0_0_0_);
						F299_4937(RTCW(tr1), loc3, loc4);
						F1301_12465(RTCW(loc2), tr1);
					}
				} else {
					RTHOOK(24);
					tr1 = RTOUCR(462,F373_5850, (Current));
					F537_7816(Current, tr1);
				}
			}
			RTHOOK(25);
			tb1 = '\0';
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_7_);
			if ((EIF_BOOLEAN)(tr1 == NULL)) {
				tb1 = (EIF_BOOLEAN)(loc3 != NULL);
			}
			if (tb1) {
				RTHOOK(26);
				if ((EIF_BOOLEAN)(loc5 == NULL)) {
					RTHOOK(27);
					loc5 = (EIF_REFERENCE) loc6;
				}
				RTHOOK(28);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_4_);
				tb1 = F1237_11101(RTCW(loc3), tr1);
				if (tb1) {
					RTHOOK(29);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr1 = F1749_19467(RTCW(tr1), loc3, loc7);
					F455_6671(Current, tr1);
				} else {
					RTHOOK(30);
					loc1 = F1742_18855(RTCW(loc5), loc3);
					RTHOOK(31);
					if ((EIF_BOOLEAN)(loc1 == NULL)) {
						RTHOOK(32);
						tr1 = RTLNS(eif_new_type(297, 0x00).id, 297, _OBJSIZ_2_0_0_0_0_0_0_0_);
						F298_4930(RTCW(tr1), loc3);
						F1301_12465(RTCW(loc2), tr1);
					} else {
						RTHOOK(33);
						F1301_12463(RTCW(loc2), loc1);
						
					}
				}
			}
		} else {
			RTHOOK(35);
			tr1 = F1749_19469(RTCV(RTOUCR(474,F421_6046, (Current))));
			F455_6671(Current, tr1);
		}
	} else {
		
		RTHOOK(37);
		F455_6666(Current);
	}
	RTHOOK(39);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_root_attributes */
void F537_7747 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc6);
	RTLR(4,loc1);
	RTLR(5,loc7);
	RTLR(6,loc2);
	RTLR(7,loc8);
	RTLR(8,loc3);
	RTLR(9,loc9);
	RTLIU(10);
	
	RTEAA("process_root_attributes", 536, Current, 9, 0, 7885);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1008L));
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		RTHOOK(2);
		tb1 = F1240_11227(loc5);
		if (tb1) {
			RTHOOK(3);
			loc4 = F1237_11136(loc5);
		} else {
			RTHOOK(4);
			tr1 = F1749_19471(RTCV(RTOUCR(474,F421_6046, (Current))));
			F455_6671(Current, tr1);
		}
	}
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1006L));
	loc6 = tr1;
	if (EIF_TEST(loc6)) {
		RTHOOK(6);
		loc1 = F1242_11339(loc6);
		RTHOOK(7);
		if ((EIF_BOOLEAN) !F270_4602(Current, loc1)) {
			RTHOOK(8);
			tr1 = F1749_19473(RTCV(RTOUCR(474,F421_6046, (Current))));
			F455_6671(Current, tr1);
		}
	}
	RTHOOK(9);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1007L));
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		RTHOOK(10);
		loc2 = F1242_11339(loc7);
		RTHOOK(11);
		if ((EIF_BOOLEAN) !F270_4600(Current, loc2)) {
			RTHOOK(12);
			tr1 = F1749_19474(RTCV(RTOUCR(474,F421_6046, (Current))));
			F455_6671(Current, tr1);
		}
	}
	RTHOOK(13);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1009L));
	loc8 = tr1;
	if (EIF_TEST(loc8)) {
		RTHOOK(14);
		loc3 = F1242_11339(loc8);
		RTHOOK(15);
		if ((EIF_BOOLEAN) !F270_4619(Current, loc3)) {
			RTHOOK(16);
			tr1 = F1749_19475(RTCV(RTOUCR(474,F421_6046, (Current))));
			F455_6671(Current, tr1);
		}
	}
	RTHOOK(17);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc9 = tr1;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc4 && (EIF_BOOLEAN)(loc1 == NULL)) && (EIF_BOOLEAN)(loc2 == NULL)) && (EIF_BOOLEAN)(loc3 == NULL)) || (EIF_BOOLEAN)(loc2 != NULL)) && EIF_TEST(loc9))) {
		RTHOOK(18);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr1 = F453_6632(RTCW(tr1), loc1, loc2, loc3, loc4);
		F1301_12478(loc9, tr1);
	} else {
		RTHOOK(19);
		tr1 = F1749_19472(RTCV(RTOUCR(474,F421_6046, (Current))));
		F455_6671(Current, tr1);
	}
	RTHOOK(20);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_version_attributes */
void F537_7748 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_16 loc1 = (EIF_NATURAL_16) 0;
	EIF_NATURAL_16 loc2 = (EIF_NATURAL_16) 0;
	EIF_NATURAL_16 loc3 = (EIF_NATURAL_16) 0;
	EIF_NATURAL_16 loc4 = (EIF_NATURAL_16) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(12);
	RTLR(0,loc6);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc7);
	RTLR(4,loc8);
	RTLR(5,loc9);
	RTLR(6,loc5);
	RTLR(7,loc10);
	RTLR(8,loc11);
	RTLR(9,loc12);
	RTLR(10,loc13);
	RTLR(11,loc14);
	RTLIU(12);
	
	RTEAA("process_version_attributes", 536, Current, 14, 0, 7886);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1012L));
	loc6 = tr1;
	if (EIF_TEST(loc6)) {
		tb2 = F1237_11094(loc6);
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(2);
		loc1 = F1237_11128(loc6);
	}
	RTHOOK(3);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1013L));
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		tb2 = F1237_11094(loc7);
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(4);
		loc2 = F1237_11128(loc7);
	}
	RTHOOK(5);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1014L));
	loc8 = tr1;
	if (EIF_TEST(loc8)) {
		tb2 = F1237_11094(loc8);
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(6);
		loc3 = F1237_11128(loc8);
	}
	RTHOOK(7);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1015L));
	loc9 = tr1;
	if (EIF_TEST(loc9)) {
		tb2 = F1237_11094(loc9);
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(8);
		loc4 = F1237_11128(loc9);
	}
	RTHOOK(9);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	loc5 = F453_6633(RTCW(tr1), loc1, loc2, loc3, loc4);
	RTHOOK(10);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1016L));
	loc10 = tr1;
	if (EIF_TEST(loc10)) {
		RTHOOK(11);
		F1714_18220(RTCW(loc5), loc10);
	}
	RTHOOK(12);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1017L));
	loc11 = tr1;
	if (EIF_TEST(loc11)) {
		RTHOOK(13);
		F1714_18219(RTCW(loc5), loc11);
	}
	RTHOOK(14);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1018L));
	loc12 = tr1;
	if (EIF_TEST(loc12)) {
		RTHOOK(15);
		F1714_18222(RTCW(loc5), loc12);
	}
	RTHOOK(16);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1019L));
	loc13 = tr1;
	if (EIF_TEST(loc13)) {
		RTHOOK(17);
		F1714_18221(RTCW(loc5), loc13);
	}
	RTHOOK(18);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc14 = tr1;
	if (EIF_TEST(loc14)) {
		RTHOOK(19);
		F1301_12468(loc14, loc5);
	} else {
		
	}
	RTHOOK(21);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_setting_attributes */
void F537_7749 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTEAA("process_setting_attributes", 536, Current, 3, 0, 7887);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1001L));
	loc1 = tr1;
	if ((EIF_BOOLEAN) !EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = F1749_19476(RTCV(RTOUCR(474,F421_6046, (Current))));
		F455_6671(Current, tr1);
	} else {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1027L));
		loc2 = tr1;
		if ((EIF_BOOLEAN) !EIF_TEST(loc2)) {
			RTHOOK(4);
			tr1 = RTOUCR(474,F421_6046, (Current));
			tr1 = F1749_19478(RTCW(tr1), loc1);
			F455_6671(Current, tr1);
		} else {
			RTHOOK(5);
			if ((EIF_BOOLEAN) !F457_6693(Current, loc1, *(EIF_REFERENCE *)(Current + _REFACS_1_))) {
				RTHOOK(6);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr1 = F1749_19477(RTCW(tr1), loc1);
				F455_6671(Current, tr1);
			} else {
				RTHOOK(7);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
				loc3 = tr1;
				if ((EIF_BOOLEAN) !EIF_TEST(loc3)) {
					
				} else {
					RTHOOK(9);
					tr1 = F1237_11118(RTCV(RTOUCR(431,F373_5803, (Current))));
					tb1 = F1240_11216(loc1, tr1);
					if (tb1) {
						RTHOOK(10);
						tr1 = RTOUCR(482,F452_6583, (Current));
						if (F454_6655(Current, tr1)) {
							RTHOOK(11);
							tb1 = F1240_11227(loc2);
							if (tb1) {
								RTHOOK(12);
								tb1 = F1237_11136(loc2);
								if (tb1) {
									RTHOOK(13);
									tr1 = F459_6774(loc3);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_14_);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
									F1294_12236(RTCW(tr1), ((EIF_NATURAL_8) 1U));
									RTHOOK(14);
									tr1 = F459_6774(loc3);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_14_);
									F1295_12256(RTCW(tr1), ((EIF_NATURAL_8) 1U));
								} else {
									RTHOOK(15);
									tr1 = F459_6774(loc3);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_14_);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
									F1294_12236(RTCW(tr1), ((EIF_NATURAL_8) 2U));
									RTHOOK(16);
									tr1 = F459_6774(loc3);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_14_);
									F1295_12256(RTCW(tr1), ((EIF_NATURAL_8) 2U));
								}
							} else {
								RTHOOK(17);
								tr1 = RTOUCR(474,F421_6046, (Current));
								tr1 = F1749_19478(RTCW(tr1), loc1);
								F455_6671(Current, tr1);
							}
						} else {
							RTHOOK(18);
							tr1 = RTOUCR(474,F421_6046, (Current));
							tr1 = F1749_19477(RTCW(tr1), loc1);
							F455_6671(Current, tr1);
						}
					} else {
						RTHOOK(19);
						tr1 = F1237_11118(RTCV(RTOUCR(406,F373_5776, (Current))));
						tb1 = F1240_11216(loc1, tr1);
						if (tb1) {
							RTHOOK(20);
							tb1 = '\0';
							tr1 = RTOUCR(483,F452_6585, (Current));
							if (F454_6656(Current, tr1)) {
								tr1 = RTOUCR(484,F452_6601, (Current));
								tb1 = F454_6655(Current, tr1);
							}
							if (tb1) {
								RTHOOK(21);
								tr1 = F459_6774(loc3);
								tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_14_);
								tb1 = F1295_12243(RTCW(tr1), loc2);
								if (tb1) {
									RTHOOK(22);
									tr1 = F459_6774(loc3);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_14_);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
									F1294_12237(RTCW(tr1), loc2);
									RTHOOK(23);
									tr1 = F459_6774(loc3);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_14_);
									F1295_12255(RTCW(tr1), loc2);
								} else {
									RTHOOK(24);
									tr1 = RTOUCR(474,F421_6046, (Current));
									tr1 = F1749_19478(RTCW(tr1), loc1);
									F455_6671(Current, tr1);
								}
							} else {
								RTHOOK(25);
								tr1 = RTOUCR(474,F421_6046, (Current));
								tr1 = F1749_19477(RTCW(tr1), loc1);
								F455_6671(Current, tr1);
							}
						} else {
							RTHOOK(26);
							tr1 = F1237_11118(RTCV(RTOUCR(421,F373_5793, (Current))));
							tb1 = F1240_11216(loc1, tr1);
							if (tb1) {
								RTHOOK(27);
								tr1 = F459_6774(loc3);
								tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_16_);
								tb1 = F1294_12224(RTCW(tr1), loc2);
								if (tb1) {
									RTHOOK(28);
									tr1 = F459_6774(loc3);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_16_);
									F1294_12237(RTCW(tr1), loc2);
								} else {
									RTHOOK(29);
									tr1 = RTOUCR(474,F421_6046, (Current));
									tr1 = F1749_19478(RTCW(tr1), loc1);
									F455_6671(Current, tr1);
								}
							} else {
								RTHOOK(30);
								tr1 = F1237_11118(RTCV(RTOUCR(408,F373_5779, (Current))));
								tb1 = F1240_11216(loc1, tr1);
								if (tb1) {
									RTHOOK(31);
									tr1 = RTOUCR(485,F452_6609, (Current));
									if (F454_6655(Current, tr1)) {
										RTHOOK(32);
										tb1 = F1240_11227(loc2);
										if (tb1) {
											RTHOOK(33);
											tr1 = F459_6774(loc3);
											tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_17_);
											tb1 = F1237_11136(loc2);
											if (tb1) {
												RTHOOK(34);
												tu1_1 = ((EIF_NATURAL_8) 2U);
											} else {
												RTHOOK(35);
												tu1_1 = ((EIF_NATURAL_8) 1U);
											}
											F1294_12236(RTCW(tr1), tu1_1);
										} else {
											RTHOOK(36);
											tr1 = RTOUCR(474,F421_6046, (Current));
											tr1 = F1749_19478(RTCW(tr1), loc1);
											F455_6671(Current, tr1);
										}
									} else {
										RTHOOK(37);
										tr1 = F459_6774(loc3);
										tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_17_);
										tb1 = F1294_12224(RTCW(tr1), loc2);
										if (tb1) {
											RTHOOK(38);
											tr1 = F459_6774(loc3);
											tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_17_);
											F1294_12237(RTCW(tr1), loc2);
										} else {
											RTHOOK(39);
											tr1 = RTOUCR(474,F421_6046, (Current));
											tr1 = F1749_19478(RTCW(tr1), loc1);
											F455_6671(Current, tr1);
										}
									}
								} else {
									RTHOOK(40);
									F459_6770(loc3, loc1, loc2);
								}
							}
						}
					}
				}
			}
		}
	}
	RTHOOK(41);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_ordered_capability */
void F537_7750 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLR(5,tr2);
	RTLR(6,loc3);
	RTLR(7,loc4);
	RTLR(8,arg2);
	RTLIU(9);
	
	RTEAA("process_ordered_capability", 536, Current, 4, 2, 7888);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tr1 = RTOUCR(479,F452_6603, (Current));
	if (F454_6656(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		loc2 = tr1;
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		RTHOOK(2);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,539,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr1 = RTLNTS(typres0.id, 2, 0);
		}
		tr2 = F459_6774(loc2);
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		loc1 = F1232_11050(RTCW(arg1), tr1);
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1067L));
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			RTHOOK(4);
			tb1 = F1295_12243(RTCW(loc1), loc3);
			if (tb1) {
				RTHOOK(5);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
				F1294_12237(RTCW(tr1), loc3);
			} else {
				RTHOOK(6);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr2 = RTOUCR(458,F373_5846, (Current));
				tr1 = F1749_19458(RTCW(tr1), tr2);
				F455_6671(Current, tr1);
			}
		}
		RTHOOK(7);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1068L));
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			RTHOOK(8);
			tb1 = F1295_12243(RTCW(loc1), loc4);
			if (tb1) {
				RTHOOK(9);
				F1295_12255(RTCW(loc1), loc4);
			} else {
				RTHOOK(10);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr2 = RTOUCR(459,F373_5847, (Current));
				tr1 = F1749_19458(RTCW(tr1), tr2);
				F455_6671(Current, tr1);
			}
		}
	} else {
		RTHOOK(11);
		tr1 = RTOUCR(474,F421_6046, (Current));
		tr1 = F1749_19457(RTCW(tr1), arg2);
		F455_6671(Current, tr1);
	}
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_file_rule_attributes */
void F537_7751 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTEAA("process_file_rule_attributes", 536, Current, 3, 0, 7889);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	loc1 = F453_6636(RTCW(tr1));
	RTHOOK(2);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_15_) = (EIF_REFERENCE) loc1;
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTHOOK(4);
		F1423_13602(loc2, loc1);
	} else {
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			RTHOOK(6);
			F1301_12481(loc3, loc1);
		} else {
			RTHOOK(7);
			tr1 = F1749_19479(RTCV(RTOUCR(474,F421_6046, (Current))));
			F455_6671(Current, tr1);
		}
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_external_attributes */
void F537_7752 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc7);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,loc5);
	RTLR(8,loc6);
	RTLIU(9);
	
	RTEAA("process_external_attributes", 536, Current, 7, 0, 7890);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1025L));
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		loc1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1027L));
	}
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc7 = tr1;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 != NULL) && EIF_TEST(loc7))) {
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
		ti4_1 = F889_8722(RTCW(tr1));
		switch (ti4_1) {
			case 10L:
				RTHOOK(6);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				loc2 = F453_6637(RTCW(tr1), loc1, loc7);
				RTHOOK(7);
				F1301_12489(loc7, loc2);
				RTHOOK(8);
				RTAR(Current, loc2);
				*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) loc2;
				break;
			case 11L:
				RTHOOK(9);
				F537_7741(Current, loc1);
				break;
			case 12L:
				RTHOOK(10);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				loc3 = F453_6639(RTCW(tr1), loc1, loc7);
				RTHOOK(11);
				F1301_12491(loc7, loc3);
				RTHOOK(12);
				RTAR(Current, loc3);
				*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) loc3;
				break;
			case 13L:
				RTHOOK(13);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				loc4 = F453_6640(RTCW(tr1), loc1, loc7);
				RTHOOK(14);
				F1301_12492(loc7, loc4);
				RTHOOK(15);
				RTAR(Current, loc4);
				*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) loc4;
				break;
			case 14L:
				RTHOOK(16);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				loc5 = F453_6641(RTCW(tr1), loc1, loc7);
				RTHOOK(17);
				F1301_12493(loc7, loc5);
				RTHOOK(18);
				RTAR(Current, loc5);
				*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) loc5;
				break;
			case 15L:
				RTHOOK(19);
				F537_7742(Current, loc1);
				break;
			case 16L:
				RTHOOK(20);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				loc6 = F453_6643(RTCW(tr1), loc1, loc7);
				RTHOOK(21);
				F1301_12495(loc7, loc6);
				RTHOOK(22);
				RTAR(Current, loc6);
				*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) loc6;
				break;
			default:
				RTHOOK(23);
				tr1 = F1749_19480(RTCV(RTOUCR(474,F421_6046, (Current))));
				F455_6671(Current, tr1);
				break;
		}
	} else {
		RTHOOK(24);
		tr1 = F1749_19480(RTCV(RTOUCR(474,F421_6046, (Current))));
		F455_6671(Current, tr1);
	}
	RTHOOK(26);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_action_attributes */
void F537_7753 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,loc4);
	RTLR(5,loc5);
	RTLR(6,loc2);
	RTLR(7,tr2);
	RTLIU(8);
	
	RTEAA("process_action_attributes", 536, Current, 5, 0, 7891);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1050L));
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		loc1 = RTMS32_EX_H("f\000\000\000a\000\000\000l\000\000\000s\000\000\000e\000\000\000",5,1635280741);
	}
	RTHOOK(4);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1026L));
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		loc4 = tr1;
		tb1 = EIF_TEST(loc4);
	}
	if (tb1) {
		RTHOOK(5);
		tb1 = F1240_11227(RTCW(loc1));
		if (tb1) {
			RTHOOK(6);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1051L));
			loc5 = tr1;
			if (EIF_TEST(loc5)) {
				RTHOOK(7);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				tb1 = F1237_11136(RTCW(loc1));
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				tr2 = F453_6629(RTCW(tr2), loc5, loc4);
				loc2 = F453_6644(RTCW(tr1), loc3, tb1, tr2);
			} else {
				RTHOOK(8);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				tb1 = F1237_11136(RTCW(loc1));
				loc2 = F453_6644(RTCW(tr1), loc3, tb1, NULL);
			}
			RTHOOK(9);
			RTAR(Current, loc2);
			*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) loc2;
			RTHOOK(10);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
			ti4_1 = F889_8722(RTCW(tr1));
			switch (ti4_1) {
				case 17L:
					RTHOOK(11);
					F1301_12505(loc4, loc2);
					break;
				case 18L:
					RTHOOK(12);
					F1301_12506(loc4, loc2);
					break;
				default:
					RTHOOK(13);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr1 = F1749_19481(RTCW(tr1), loc3);
					F455_6671(Current, tr1);
					break;
			}
		} else {
			RTHOOK(14);
			tr1 = RTOUCR(474,F421_6046, (Current));
			tr1 = F1749_19482(RTCW(tr1), loc3);
			F455_6671(Current, tr1);
		}
	} else {
		RTHOOK(15);
		tr1 = F1749_19483(RTCV(RTOUCR(474,F421_6046, (Current))));
		F455_6671(Current, tr1);
	}
	RTHOOK(17);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_variable_attributes */
void F537_7754 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTEAA("process_variable_attributes", 536, Current, 3, 0, 7892);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1027L));
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		loc1 = RTMS32_EX_H("",0,0);
	}
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1001L));
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			RTHOOK(6);
			F1301_12508(loc3, loc2, loc1);
		} else {
			
		}
	} else {
		RTHOOK(8);
		tr1 = F1749_19484(RTCV(RTOUCR(474,F421_6046, (Current))));
		F455_6671(Current, tr1);
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_library_attributes */
void F537_7755 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(12);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc5);
	RTLR(5,loc6);
	RTLR(6,loc2);
	RTLR(7,loc3);
	RTLR(8,loc7);
	RTLR(9,tr2);
	RTLR(10,loc8);
	RTLR(11,loc9);
	RTLIU(12);
	
	RTEAA("process_library_attributes", 536, Current, 9, 0, 7893);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1001L));
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		RTHOOK(2);
		loc1 = F1242_11339(loc4);
		RTHOOK(3);
		tb1 = '\0';
		tb2 = '\0';
		if (F270_4602(Current, loc1)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1025L));
			loc5 = tr1;
			tb2 = EIF_TEST(loc5);
		}
		if (tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
			loc6 = tr1;
			tb1 = EIF_TEST(loc6);
		}
		if (tb1) {
			RTHOOK(4);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			loc2 = F453_6648(RTCW(tr1), loc1, loc5, loc6);
			RTHOOK(5);
			loc3 = (EIF_REFERENCE) loc2;
			RTHOOK(6);
			RTAR(Current, loc2);
			*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) loc2;
			RTHOOK(7);
			RTAR(Current, loc3);
			*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) loc3;
			RTHOOK(8);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1029L));
			loc7 = tr1;
			if (EIF_TEST(loc7)) {
				RTHOOK(9);
				tb1 = F1240_11227(loc7);
				if (tb1) {
					RTHOOK(10);
					tb1 = F1237_11136(loc7);
					F1420_13539(RTCW(loc2), tb1);
				} else {
					RTHOOK(11);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr2 = RTMS_EX_H("readonly",8,1382700153);
					tr1 = F1749_19458(RTCW(tr1), tr2);
					F455_6671(Current, tr1);
				}
			}
			RTHOOK(12);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1057L));
			loc8 = tr1;
			if (EIF_TEST(loc8)) {
				RTHOOK(13);
				tb1 = F1240_11227(loc8);
				if (tb1) {
					RTHOOK(14);
					tb1 = F1237_11136(loc8);
					F1428_13674(RTCW(loc2), tb1);
				} else {
					RTHOOK(15);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr2 = RTMS_EX_H("use_application_options",23,923843187);
					tr1 = F1749_19458(RTCW(tr1), tr2);
					F455_6671(Current, tr1);
				}
			}
			RTHOOK(16);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1030L));
			loc9 = tr1;
			if (EIF_TEST(loc9)) {
				RTHOOK(17);
				F1426_13630(RTCW(loc2), loc9);
			}
			RTHOOK(18);
			F1301_12470(loc6, loc2);
		} else {
			RTHOOK(19);
			if ((EIF_BOOLEAN) !F270_4602(Current, loc1)) {
				RTHOOK(20);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr1 = F1749_19487(RTCW(tr1), loc4);
				F455_6671(Current, tr1);
			} else {
				RTHOOK(21);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr1 = F1749_19488(RTCW(tr1), loc4);
				F455_6671(Current, tr1);
			}
		}
	} else {
		RTHOOK(22);
		tr1 = F1749_19486(RTCV(RTOUCR(474,F421_6046, (Current))));
		F455_6671(Current, tr1);
	}
	RTHOOK(24);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_precompile_attributes */
void F537_7756 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(13);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc5);
	RTLR(4,loc1);
	RTLR(5,loc6);
	RTLR(6,loc2);
	RTLR(7,loc3);
	RTLR(8,loc7);
	RTLR(9,tr2);
	RTLR(10,loc8);
	RTLR(11,loc9);
	RTLR(12,loc10);
	RTLIU(13);
	
	RTEAA("process_precompile_attributes", 536, Current, 10, 0, 7894);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1001L));
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		loc5 = tr1;
		tb1 = EIF_TEST(loc5);
	}
	if (tb1) {
		RTHOOK(2);
		loc1 = F1242_11339(loc4);
		RTHOOK(3);
		tb1 = '\0';
		tb2 = '\0';
		if (F270_4602(Current, loc1)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1025L));
			loc6 = tr1;
			tb2 = EIF_TEST(loc6);
		}
		if (tb2) {
			tr1 = F1301_12438(loc5);
			tb1 = (EIF_BOOLEAN)(tr1 == NULL);
		}
		if (tb1) {
			RTHOOK(4);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			loc2 = F453_6649(RTCW(tr1), loc1, loc6, loc5);
			RTHOOK(5);
			loc3 = (EIF_REFERENCE) loc2;
			RTHOOK(6);
			RTAR(Current, loc2);
			*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) loc2;
			RTHOOK(7);
			RTAR(Current, loc3);
			*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) loc3;
			RTHOOK(8);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1029L));
			loc7 = tr1;
			if (EIF_TEST(loc7)) {
				RTHOOK(9);
				tb1 = F1240_11227(loc7);
				if (tb1) {
					RTHOOK(10);
					tb1 = F1237_11136(loc7);
					F1420_13539(RTCW(loc2), tb1);
				} else {
					RTHOOK(11);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr2 = RTMS_EX_H("readonly",8,1382700153);
					tr1 = F1749_19458(RTCW(tr1), tr2);
					F455_6671(Current, tr1);
				}
			}
			RTHOOK(12);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1030L));
			loc8 = tr1;
			if (EIF_TEST(loc8)) {
				RTHOOK(13);
				F1426_13630(RTCW(loc2), loc8);
			}
			RTHOOK(14);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1053L));
			loc9 = tr1;
			if (EIF_TEST(loc9)) {
				RTHOOK(15);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				tr1 = F453_6629(RTCW(tr1), loc9, loc5);
				F1429_13682(RTCW(loc2), tr1);
			}
			RTHOOK(16);
			F1301_12469(loc5, loc2);
		} else {
			RTHOOK(17);
			if ((EIF_BOOLEAN) !F270_4602(Current, loc1)) {
				RTHOOK(18);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr1 = F1749_19491(RTCW(tr1), loc4);
				F455_6671(Current, tr1);
			} else {
				RTHOOK(19);
				tr1 = F1301_12438(loc5);
				loc10 = tr1;
				if (EIF_TEST(loc10)) {
					RTHOOK(20);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr2 = *(EIF_REFERENCE *)(loc10 + _REFACS_5_);
					tr1 = F1749_19494(RTCW(tr1), loc4, tr2);
					F455_6671(Current, tr1);
				} else {
					RTHOOK(21);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr1 = F1749_19492(RTCW(tr1), loc4);
					F455_6671(Current, tr1);
				}
			}
		}
	} else {
		RTHOOK(22);
		tr1 = F1749_19490(RTCV(RTOUCR(474,F421_6046, (Current))));
		F455_6671(Current, tr1);
	}
	RTHOOK(24);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_assembly_attributes */
void F537_7757 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(15);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,loc6);
	RTLR(6,loc7);
	RTLR(7,loc8);
	RTLR(8,loc9);
	RTLR(9,loc10);
	RTLR(10,loc3);
	RTLR(11,loc4);
	RTLR(12,loc11);
	RTLR(13,tr2);
	RTLR(14,loc12);
	RTLIU(15);
	
	RTEAA("process_assembly_attributes", 536, Current, 12, 0, 7895);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1001L));
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		RTHOOK(2);
		loc1 = F1242_11339(loc5);
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		loc2 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1025L));
		RTHOOK(4);
		tb1 = '\0';
		tb2 = '\0';
		if (F270_4602(Current, loc1)) {
			tb2 = (EIF_BOOLEAN)(loc2 != NULL);
		}
		if (tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
			loc6 = tr1;
			tb1 = EIF_TEST(loc6);
		}
		if (tb1) {
			RTHOOK(5);
			tb1 = '\0';
			tr1 = RTMS_EX_H("none",4,1852796517);
			tb2 = F1237_11104(RTCW(loc2), tr1);
			if (tb2) {
				tb2 = '\0';
				tb3 = '\0';
				tb4 = '\0';
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
				tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1032L));
				loc7 = tr1;
				if (EIF_TEST(loc7)) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
					tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1033L));
					loc8 = tr1;
					tb4 = EIF_TEST(loc8);
				}
				if (tb4) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
					tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1034L));
					loc9 = tr1;
					tb3 = EIF_TEST(loc9);
				}
				if (tb3) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
					tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1035L));
					loc10 = tr1;
					tb2 = EIF_TEST(loc10);
				}
				tb1 = tb2;
			}
			if (tb1) {
				RTHOOK(6);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				loc3 = F453_6647(RTCW(tr1), loc1, loc7, loc8, loc9, loc10, loc6);
			} else {
				RTHOOK(7);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				loc3 = F453_6646(RTCW(tr1), loc1, loc2, loc6);
			}
			RTHOOK(8);
			loc4 = (EIF_REFERENCE) loc3;
			RTHOOK(9);
			RTAR(Current, loc3);
			*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) loc3;
			RTHOOK(10);
			RTAR(Current, loc4);
			*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) loc4;
			RTHOOK(11);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1029L));
			loc11 = tr1;
			if (EIF_TEST(loc11)) {
				RTHOOK(12);
				tb1 = F1240_11227(loc11);
				if (tb1) {
					RTHOOK(13);
					tb1 = F1237_11136(loc11);
					F1420_13539(RTCW(loc3), tb1);
				} else {
					RTHOOK(14);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr2 = RTMS_EX_H("readonly",8,1382700153);
					tr1 = F1749_19458(RTCW(tr1), tr2);
					F455_6671(Current, tr1);
				}
			}
			RTHOOK(15);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1030L));
			loc12 = tr1;
			if (EIF_TEST(loc12)) {
				RTHOOK(16);
				F1426_13630(RTCW(loc3), loc12);
			}
			RTHOOK(17);
			F1301_12471(loc6, loc3);
		} else {
			RTHOOK(18);
			if ((EIF_BOOLEAN) !F270_4602(Current, loc1)) {
				RTHOOK(19);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr1 = F1749_19496(RTCW(tr1), loc5);
				F455_6671(Current, tr1);
			} else {
				RTHOOK(20);
				if ((EIF_BOOLEAN)(loc2 == NULL)) {
					RTHOOK(21);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr1 = F1749_19497(RTCW(tr1), loc5);
					F455_6671(Current, tr1);
				} else {
					
				}
			}
		}
	} else {
		RTHOOK(23);
		tr1 = F1749_19495(RTCV(RTOUCR(474,F421_6046, (Current))));
		F455_6671(Current, tr1);
	}
	RTHOOK(25);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_cluster_attributes */
void F537_7758 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(14);
	RTLR(0,loc7);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,loc8);
	RTLR(6,loc3);
	RTLR(7,loc6);
	RTLR(8,loc4);
	RTLR(9,loc5);
	RTLR(10,loc9);
	RTLR(11,tr2);
	RTLR(12,loc10);
	RTLR(13,loc11);
	RTLIU(14);
	
	RTEAA("process_cluster_attributes", 536, Current, 11, 1, 7896);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1001L));
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		RTHOOK(2);
		loc1 = F1242_11339(loc7);
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		loc2 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1025L));
		RTHOOK(4);
		tb1 = '\0';
		tb2 = '\0';
		if (F270_4602(Current, loc1)) {
			tb2 = (EIF_BOOLEAN)(loc2 != NULL);
		}
		if (tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
			loc8 = tr1;
			tb1 = EIF_TEST(loc8);
		}
		if (tb1) {
			RTHOOK(5);
			loc3 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
			RTHOOK(6);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			loc6 = F453_6629(RTCW(tr1), loc2, loc8);
			RTHOOK(7);
			if (arg1) {
				RTHOOK(8);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				loc4 = F453_6651(RTCW(tr1), loc1, loc6, loc8);
			} else {
				RTHOOK(9);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				loc4 = F453_6650(RTCW(tr1), loc1, loc6, loc8);
			}
			RTHOOK(10);
			loc5 = (EIF_REFERENCE) loc4;
			RTHOOK(11);
			RTAR(Current, loc4);
			*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) loc4;
			RTHOOK(12);
			RTAR(Current, loc5);
			*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) loc5;
			RTHOOK(13);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1029L));
			loc9 = tr1;
			if (EIF_TEST(loc9)) {
				RTHOOK(14);
				tb1 = F1240_11227(loc9);
				if (tb1) {
					RTHOOK(15);
					tb1 = F1237_11136(loc9);
					F1420_13539(RTCW(loc4), tb1);
				} else {
					RTHOOK(16);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr2 = RTMS_EX_H("readonly",8,1382700153);
					tr1 = F1749_19458(RTCW(tr1), tr2);
					F455_6671(Current, tr1);
				}
			}
			RTHOOK(17);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1055L));
			loc10 = tr1;
			if (EIF_TEST(loc10)) {
				RTHOOK(18);
				tb1 = F1240_11227(loc10);
				if (tb1) {
					RTHOOK(19);
					tb1 = F1237_11136(loc10);
					F1423_13597(RTCW(loc4), tb1);
				} else {
					RTHOOK(20);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr2 = RTMS_EX_H("hidden",6,1889579886);
					tr1 = F1749_19458(RTCW(tr1), tr2);
					F455_6671(Current, tr1);
				}
			}
			RTHOOK(21);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1036L));
			loc11 = tr1;
			if (EIF_TEST(loc11)) {
				RTHOOK(22);
				tb1 = F1240_11227(loc11);
				if (tb1) {
					RTHOOK(23);
					tb1 = F1237_11136(loc11);
					F1423_13596(RTCW(loc4), tb1);
				} else {
					RTHOOK(24);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr2 = RTMS_EX_H("recursive",9,760839013);
					tr1 = F1749_19458(RTCW(tr1), tr2);
					F455_6671(Current, tr1);
				}
			}
			RTHOOK(25);
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				RTHOOK(26);
				F1423_13594(RTCW(loc3), loc4);
				RTHOOK(27);
				F1423_13593(RTCW(loc4), loc3);
				RTHOOK(28);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_7_);
				F1765_19735(RTCW(loc6), tr1);
			}
			RTHOOK(29);
			F1301_12472(loc8, loc4);
		} else {
			RTHOOK(30);
			if ((EIF_BOOLEAN) !F270_4602(Current, loc1)) {
				RTHOOK(31);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr1 = F1749_19500(RTCW(tr1), loc7);
				F455_6671(Current, tr1);
			} else {
				RTHOOK(32);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					RTHOOK(33);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr1 = F1749_19502(RTCW(tr1), loc7);
					F455_6671(Current, tr1);
				} else {
					RTHOOK(34);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr1 = F1749_19501(RTCW(tr1), loc7);
					F455_6671(Current, tr1);
				}
			}
		}
	} else {
		RTHOOK(35);
		tr1 = F1749_19499(RTCV(RTOUCR(474,F421_6046, (Current))));
		F455_6671(Current, tr1);
	}
	RTHOOK(37);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_override_attributes */
void F537_7759 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(14);
	RTLR(0,loc7);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,loc8);
	RTLR(6,loc3);
	RTLR(7,loc4);
	RTLR(8,tr2);
	RTLR(9,loc5);
	RTLR(10,loc6);
	RTLR(11,loc9);
	RTLR(12,loc10);
	RTLR(13,loc11);
	RTLIU(14);
	
	RTEAA("process_override_attributes", 536, Current, 11, 0, 7897);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1001L));
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		RTHOOK(2);
		loc1 = F1242_11339(loc7);
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		loc2 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1025L));
		RTHOOK(4);
		tb1 = '\0';
		tb2 = '\0';
		if (F270_4602(Current, loc1)) {
			tb2 = (EIF_BOOLEAN)(loc2 != NULL);
		}
		if (tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
			loc8 = tr1;
			tb1 = EIF_TEST(loc8);
		}
		if (tb1) {
			RTHOOK(5);
			loc3 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
			RTHOOK(6);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			tr2 = F453_6629(RTCW(tr2), loc2, loc8);
			loc4 = F453_6652(RTCW(tr1), loc1, tr2, loc8);
			RTHOOK(7);
			loc5 = (EIF_REFERENCE) loc4;
			RTHOOK(8);
			loc6 = (EIF_REFERENCE) loc4;
			RTHOOK(9);
			RTAR(Current, loc4);
			*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) loc4;
			RTHOOK(10);
			RTAR(Current, loc5);
			*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) loc5;
			RTHOOK(11);
			RTAR(Current, loc6);
			*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) loc6;
			RTHOOK(12);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1029L));
			loc9 = tr1;
			if (EIF_TEST(loc9)) {
				RTHOOK(13);
				tb1 = F1240_11227(loc9);
				if (tb1) {
					RTHOOK(14);
					tb1 = F1237_11136(loc9);
					F1420_13539(RTCW(loc5), tb1);
				} else {
					RTHOOK(15);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr2 = RTMS_EX_H("readonly",8,1382700153);
					tr1 = F1749_19458(RTCW(tr1), tr2);
					F455_6671(Current, tr1);
				}
			}
			RTHOOK(16);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1055L));
			loc10 = tr1;
			if (EIF_TEST(loc10)) {
				RTHOOK(17);
				tb1 = F1240_11227(loc10);
				if (tb1) {
					RTHOOK(18);
					tb1 = F1237_11136(loc10);
					F1423_13597(RTCW(loc5), tb1);
				} else {
					RTHOOK(19);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr2 = RTMS_EX_H("hidden",6,1889579886);
					tr1 = F1749_19458(RTCW(tr1), tr2);
					F455_6671(Current, tr1);
				}
			}
			RTHOOK(20);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1036L));
			loc11 = tr1;
			if (EIF_TEST(loc11)) {
				RTHOOK(21);
				tb1 = F1240_11227(loc11);
				if (tb1) {
					RTHOOK(22);
					tb1 = F1237_11136(loc11);
					F1423_13596(RTCW(loc5), tb1);
				} else {
					RTHOOK(23);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr2 = RTMS_EX_H("recursive",9,760839013);
					tr1 = F1749_19458(RTCW(tr1), tr2);
					F455_6671(Current, tr1);
				}
			}
			RTHOOK(24);
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				RTHOOK(25);
				F1423_13594(RTCW(loc3), loc5);
				RTHOOK(26);
				F1423_13593(RTCW(loc5), loc3);
			}
			RTHOOK(27);
			F1301_12473(loc8, loc4);
		} else {
			RTHOOK(28);
			if ((EIF_BOOLEAN) !F270_4602(Current, loc1)) {
				RTHOOK(29);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr1 = F1749_19504(RTCW(tr1), loc7);
				F455_6671(Current, tr1);
			} else {
				RTHOOK(30);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr1 = F1749_19505(RTCW(tr1), loc7);
				F455_6671(Current, tr1);
			}
		}
	} else {
		RTHOOK(31);
		tr1 = F1749_19503(RTCV(RTOUCR(474,F421_6046, (Current))));
		F455_6671(Current, tr1);
	}
	RTHOOK(33);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_debug_attributes */
void F537_7760 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc3);
	RTLR(5,arg1);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTEAA("process_debug_attributes", 536, Current, 3, 1, 7898);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1001L));
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTHOOK(2);
		loc1 = F1242_11339(loc2);
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1037L));
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			RTHOOK(4);
			tb1 = F1240_11227(loc3);
			if (tb1) {
				RTHOOK(5);
				tb1 = F1237_11136(loc3);
				F539_7935(RTCW(arg1), loc1, tb1);
			} else {
				RTHOOK(6);
				tb1 = F1240_11227(loc3);
				if ((EIF_BOOLEAN) !tb1) {
					RTHOOK(7);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr2 = RTOUCR(486,F276_4771, (Current));
					tr1 = F1749_19458(RTCW(tr1), tr2);
					F455_6671(Current, tr1);
				}
			}
		} else {
			RTHOOK(8);
			tr1 = RTOUCR(474,F421_6046, (Current));
			tr1 = F1749_19508(RTCW(tr1), loc2);
			F455_6671(Current, tr1);
		}
	} else {
		RTHOOK(9);
		tr1 = F1749_19507(RTCV(RTOUCR(474,F421_6046, (Current))));
		F455_6671(Current, tr1);
	}
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_warning_attributes */
void F537_7761 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,arg1);
	RTLR(5,loc1);
	RTLR(6,loc4);
	RTLR(7,tr2);
	RTLIU(8);
	
	RTEAA("process_warning_attributes", 536, Current, 4, 1, 7899);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1001L));
	loc2 = tr1;
	if ((EIF_BOOLEAN) !EIF_TEST(loc2)) {
		RTHOOK(2);
		tr1 = F1749_19509(RTCV(RTOUCR(474,F421_6046, (Current))));
		F455_6671(Current, tr1);
	} else {
		RTHOOK(3);
		tb1 = '\0';
		tr1 = RTOUCR(487,F452_6613, (Current));
		if (F454_6656(Current, tr1)) {
			tr1 = RTOUCR(385,F373_5755, (Current));
			tb2 = F1237_11101(loc2, tr1);
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(4);
			tb1 = '\0';
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1027L));
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
				tb2 = F1294_12224(RTCW(tr1), loc3);
				tb1 = tb2;
			}
			if (tb1) {
				RTHOOK(5);
				tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
				F1294_12237(RTCW(tr1), loc3);
			} else {
				RTHOOK(6);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr1 = F1749_19510(RTCW(tr1), loc2);
				F455_6671(Current, tr1);
			}
		} else {
			RTHOOK(7);
			loc1 = F1242_11339(loc2);
			RTHOOK(8);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1037L));
			loc4 = tr1;
			if ((EIF_BOOLEAN) !EIF_TEST(loc4)) {
				RTHOOK(9);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr1 = F1749_19510(RTCW(tr1), loc2);
				F455_6671(Current, tr1);
			} else {
				RTHOOK(10);
				tb1 = F1240_11227(loc4);
				if ((EIF_BOOLEAN) !tb1) {
					RTHOOK(11);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr2 = RTOUCR(486,F276_4771, (Current));
					tr1 = F1749_19458(RTCW(tr1), tr2);
					F455_6671(Current, tr1);
				} else {
					RTHOOK(12);
					if (F457_6688(Current, loc1, *(EIF_REFERENCE *)(Current + _REFACS_1_))) {
						RTHOOK(13);
						tr1 = RTOUCR(385,F373_5755, (Current));
						tb1 = F1237_11101(loc2, tr1);
						if (tb1) {
							RTHOOK(14);
							tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
							tb1 = F1237_11136(loc4);
							if (tb1) {
								RTHOOK(15);
								tu1_1 = ((EIF_NATURAL_8) 2U);
							} else {
								RTHOOK(16);
								tu1_1 = ((EIF_NATURAL_8) 1U);
							}
							F1294_12236(RTCW(tr1), tu1_1);
						} else {
							RTHOOK(17);
							tb1 = F1237_11136(loc4);
							F539_7919(RTCW(arg1), loc1, tb1);
						}
					} else {
						RTHOOK(18);
						tr1 = RTOUCR(474,F421_6046, (Current));
						tr1 = F1749_19510(RTCW(tr1), loc2);
						F455_6671(Current, tr1);
					}
				}
			}
		}
	}
	RTHOOK(19);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_assertions_attributes */
void F537_7762 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(11);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,loc5);
	RTLR(8,loc6);
	RTLR(9,loc7);
	RTLR(10,arg1);
	RTLIU(11);
	
	RTEAA("process_assertions_attributes", 536, Current, 7, 1, 7900);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	loc1 = F453_6645(RTCW(tr1));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1038L));
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTHOOK(3);
		tb1 = F1240_11227(loc2);
		if (tb1) {
			RTHOOK(4);
			tb1 = F1237_11136(loc2);
			if (tb1) {
				RTHOOK(5);
				F61_1058(RTCW(loc1));
			}
		} else {
			RTHOOK(6);
			tr1 = RTOUCR(474,F421_6046, (Current));
			tr2 = RTMS_EX_H("precondition",12,694692206);
			tr1 = F1749_19458(RTCW(tr1), tr2);
			F455_6671(Current, tr1);
		}
	}
	RTHOOK(7);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1039L));
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTHOOK(8);
		tb1 = F1240_11227(loc3);
		if (tb1) {
			RTHOOK(9);
			tb1 = F1237_11136(loc3);
			if (tb1) {
				RTHOOK(10);
				F61_1060(RTCW(loc1));
			}
		} else {
			RTHOOK(11);
			tr1 = RTOUCR(474,F421_6046, (Current));
			tr2 = RTMS_EX_H("postcondition",13,29888366);
			tr1 = F1749_19458(RTCW(tr1), tr2);
			F455_6671(Current, tr1);
		}
	}
	RTHOOK(12);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1040L));
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		RTHOOK(13);
		tb1 = F1240_11227(loc4);
		if (tb1) {
			RTHOOK(14);
			tb1 = F1237_11136(loc4);
			if (tb1) {
				RTHOOK(15);
				F61_1061(RTCW(loc1));
			}
		} else {
			RTHOOK(16);
			tr1 = RTOUCR(474,F421_6046, (Current));
			tr2 = RTMS_EX_H("check",5,1752235371);
			tr1 = F1749_19458(RTCW(tr1), tr2);
			F455_6671(Current, tr1);
		}
	}
	RTHOOK(17);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1041L));
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		RTHOOK(18);
		tb1 = F1240_11227(loc5);
		if (tb1) {
			RTHOOK(19);
			tb1 = F1237_11136(loc5);
			if (tb1) {
				RTHOOK(20);
				F61_1062(RTCW(loc1));
			}
		} else {
			RTHOOK(21);
			tr1 = RTOUCR(474,F421_6046, (Current));
			tr2 = RTMS_EX_H("invariant",9,997544820);
			tr1 = F1749_19458(RTCW(tr1), tr2);
			F455_6671(Current, tr1);
		}
	}
	RTHOOK(22);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1042L));
	loc6 = tr1;
	if (EIF_TEST(loc6)) {
		RTHOOK(23);
		tb1 = F1240_11227(loc6);
		if (tb1) {
			RTHOOK(24);
			tb1 = F1237_11136(loc6);
			if (tb1) {
				RTHOOK(25);
				F61_1063(RTCW(loc1));
			}
		} else {
			RTHOOK(26);
			tr1 = RTOUCR(474,F421_6046, (Current));
			tr2 = RTMS_EX_H("loop",4,1819242352);
			tr1 = F1749_19458(RTCW(tr1), tr2);
			F455_6671(Current, tr1);
		}
	}
	RTHOOK(27);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1043L));
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		RTHOOK(28);
		tb1 = F1240_11227(loc7);
		if (tb1) {
			RTHOOK(29);
			tb1 = F1237_11136(loc7);
			if (tb1) {
				RTHOOK(30);
				F61_1059(RTCW(loc1));
			}
		} else {
			RTHOOK(31);
			tr1 = RTOUCR(474,F421_6046, (Current));
			tr2 = RTMS_EX_H("supplier_precondition",21,1130264430);
			tr1 = F1749_19458(RTCW(tr1), tr2);
			F455_6671(Current, tr1);
		}
	}
	RTHOOK(32);
	F539_7934(RTCW(arg1), loc1);
	RTHOOK(33);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_renaming_attributes */
void F537_7763 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTEAA("process_renaming_attributes", 536, Current, 3, 0, 7901);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1047L));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc2 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1048L));
	RTHOOK(3);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 != NULL) && (EIF_BOOLEAN)(loc2 != NULL))) {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
		loc3 = tr1;
		loc3 = RTRV(eif_new_type(1425, 0x00),loc3);
		if (EIF_TEST(loc3)) {
			RTHOOK(5);
			tr1 = F1242_11340(RTCW(loc1));
			tr2 = F1242_11340(RTCW(loc2));
			F1426_13632(loc3, tr1, tr2);
		} else {
			
		}
	} else {
		RTHOOK(7);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTHOOK(8);
			tr1 = RTOUCR(474,F421_6046, (Current));
			tr1 = F1749_19512(RTCW(tr1), loc1);
			F455_6671(Current, tr1);
		} else {
			RTHOOK(9);
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				RTHOOK(10);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr1 = F1749_19513(RTCW(tr1), loc2);
				F455_6671(Current, tr1);
			} else {
				RTHOOK(11);
				tr1 = F1749_19511(RTCV(RTOUCR(474,F421_6046, (Current))));
				F455_6671(Current, tr1);
			}
		}
	}
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_option_attributes */
void F537_7764 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc22 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc23 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc24 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc25 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc26 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc27 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(30);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc4);
	RTLR(5,tr2);
	RTLR(6,loc1);
	RTLR(7,loc5);
	RTLR(8,loc6);
	RTLR(9,loc7);
	RTLR(10,loc8);
	RTLR(11,loc9);
	RTLR(12,loc10);
	RTLR(13,loc11);
	RTLR(14,loc12);
	RTLR(15,loc13);
	RTLR(16,loc14);
	RTLR(17,loc15);
	RTLR(18,loc16);
	RTLR(19,loc17);
	RTLR(20,loc18);
	RTLR(21,loc19);
	RTLR(22,loc20);
	RTLR(23,loc21);
	RTLR(24,loc22);
	RTLR(25,loc23);
	RTLR(26,loc24);
	RTLR(27,loc25);
	RTLR(28,loc26);
	RTLR(29,loc27);
	RTLIU(30);
	
	RTEAA("process_option_attributes", 536, Current, 27, 1, 7902);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	loc3 = tr1;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) !arg1 && (EIF_BOOLEAN) !EIF_TEST(loc3)) && (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_9_) != NULL))) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc4 = tr2;
		if (EIF_TEST(loc4)) {
			RTHOOK(3);
			tr2 = loc4;
		} else {
			RTHOOK(4);
			tr2 = RTOUCR(480,F452_6617, (Current));
		}
		tr2 = F1237_11118(RTCV(tr2));
		loc2 = F453_6635(RTCW(tr1), tr2);
		RTHOOK(5);
		loc1 = (EIF_REFERENCE) loc2;
	} else {
		RTHOOK(6);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc5 = tr2;
		if (EIF_TEST(loc5)) {
			RTHOOK(7);
			tr2 = loc5;
		} else {
			RTHOOK(8);
			tr2 = RTOUCR(480,F452_6617, (Current));
		}
		tr2 = F1237_11118(RTCV(tr2));
		loc1 = F453_6634(RTCW(tr1), tr2);
	}
	RTHOOK(9);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) loc1;
	RTHOOK(10);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1020L));
	loc6 = tr1;
	if (EIF_TEST(loc6)) {
		RTHOOK(11);
		tb1 = F1240_11227(loc6);
		if (tb1) {
			RTHOOK(12);
			tb1 = F1237_11136(loc6);
			F539_7938(RTCW(loc1), tb1);
		} else {
			RTHOOK(13);
			tr1 = RTOUCR(474,F421_6046, (Current));
			tr2 = RTOUCR(448,F373_5833, (Current));
			tr1 = F1749_19458(RTCW(tr1), tr2);
			F455_6671(Current, tr1);
		}
	}
	RTHOOK(14);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1021L));
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		RTHOOK(15);
		tb1 = F1240_11227(loc7);
		if (tb1) {
			RTHOOK(16);
			tb1 = F1237_11136(loc7);
			F539_7937(RTCW(loc1), tb1);
		} else {
			RTHOOK(17);
			tr1 = RTOUCR(474,F421_6046, (Current));
			tr2 = RTOUCR(447,F373_5832, (Current));
			tr1 = F1749_19458(RTCW(tr1), tr2);
			F455_6671(Current, tr1);
		}
	}
	RTHOOK(18);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1022L));
	loc8 = tr1;
	if (EIF_TEST(loc8)) {
		RTHOOK(19);
		tb1 = F1240_11227(loc8);
		if (tb1) {
			RTHOOK(20);
			tb1 = F1237_11136(loc8);
			F539_7939(RTCW(loc1), tb1);
		} else {
			RTHOOK(21);
			tr1 = RTOUCR(474,F421_6046, (Current));
			tr2 = RTOUCR(446,F373_5831, (Current));
			tr1 = F1749_19458(RTCW(tr1), tr2);
			F455_6671(Current, tr1);
		}
	}
	RTHOOK(22);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1023L));
	loc9 = tr1;
	if (EIF_TEST(loc9)) {
		RTHOOK(23);
		tb1 = F1240_11227(loc9);
		if (tb1) {
			RTHOOK(24);
			tb1 = F1237_11136(loc9);
			F539_7940(RTCW(loc1), tb1);
		} else {
			RTHOOK(25);
			tr1 = RTOUCR(474,F421_6046, (Current));
			tr2 = RTOUCR(441,F373_5826, (Current));
			tr1 = F1749_19458(RTCW(tr1), tr2);
			F455_6671(Current, tr1);
		}
	}
	RTHOOK(26);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1054L));
	loc10 = tr1;
	if (EIF_TEST(loc10)) {
		RTHOOK(27);
		tr1 = RTOUCR(487,F452_6613, (Current));
		if (F454_6656(Current, tr1)) {
			RTHOOK(28);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_6_);
			tb1 = F1294_12224(RTCW(tr1), loc10);
			if (tb1) {
				RTHOOK(29);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_6_);
				F1294_12237(RTCW(tr1), loc10);
			} else {
				RTHOOK(30);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr2 = RTOUCR(449,F373_5834, (Current));
				tr1 = F1749_19458(RTCW(tr1), tr2);
				F455_6671(Current, tr1);
			}
		} else {
			RTHOOK(31);
			tb1 = F1240_11227(loc10);
			if (tb1) {
				RTHOOK(32);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_6_);
				tb1 = F1237_11136(loc10);
				if (tb1) {
					RTHOOK(33);
					tu1_1 = ((EIF_NATURAL_8) 2U);
				} else {
					RTHOOK(34);
					tu1_1 = ((EIF_NATURAL_8) 1U);
				}
				F1294_12236(RTCW(tr1), tu1_1);
			} else {
				RTHOOK(35);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr2 = RTOUCR(449,F373_5834, (Current));
				tr1 = F1749_19458(RTCW(tr1), tr2);
				F455_6671(Current, tr1);
			}
		}
	}
	RTHOOK(36);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1056L));
	loc11 = tr1;
	if (EIF_TEST(loc11)) {
		tb2 = F1240_11227(loc11);
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(37);
		tb1 = F1237_11136(loc11);
		F539_7941(RTCW(loc1), tb1);
	}
	RTHOOK(38);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1024L));
	loc12 = tr1;
	if (EIF_TEST(loc12)) {
		RTHOOK(39);
		F539_7936(RTCW(loc1), loc12);
	}
	RTHOOK(40);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1058L));
	loc13 = tr1;
	if (EIF_TEST(loc13)) {
		RTHOOK(41);
		tb1 = F1240_11227(loc13);
		if (tb1) {
			RTHOOK(42);
			tb1 = F1237_11136(loc13);
			F539_7942(RTCW(loc1), tb1);
		} else {
			RTHOOK(43);
			tr1 = RTOUCR(474,F421_6046, (Current));
			tr2 = RTOUCR(442,F373_5827, (Current));
			tr1 = F1749_19458(RTCW(tr1), tr2);
			F455_6671(Current, tr1);
		}
	}
	RTHOOK(44);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1059L));
	loc14 = tr1;
	if (EIF_TEST(loc14)) {
		RTHOOK(45);
		tr1 = RTOUCR(488,F452_6599, (Current));
		if (F454_6656(Current, tr1)) {
			RTHOOK(46);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_9_);
			tb1 = F1294_12224(RTCW(tr1), loc14);
			if (tb1) {
				RTHOOK(47);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					RTHOOK(48);
					tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_13_);
					tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
					F1294_12237(RTCW(tr1), loc14);
					RTHOOK(49);
					tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_13_);
					F1295_12255(RTCW(tr1), loc14);
				} else {
					RTHOOK(50);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr2 = RTOUCR(439,F373_5822, (Current));
					tr1 = F1749_19460(RTCW(tr1), tr2);
					F455_6672(Current, tr1);
				}
			} else {
				RTHOOK(51);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr2 = RTOUCR(439,F373_5822, (Current));
				tr1 = F1749_19458(RTCW(tr1), tr2);
				F455_6671(Current, tr1);
			}
		} else {
			RTHOOK(52);
			tb1 = F1240_11227(loc14);
			if (tb1) {
				RTHOOK(53);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					RTHOOK(54);
					tb1 = F1237_11136(loc14);
					if (tb1) {
						RTHOOK(55);
						tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_13_);
						tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
						F1294_12236(RTCW(tr1), ((EIF_NATURAL_8) 3U));
						RTHOOK(56);
						tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_13_);
						F1295_12256(RTCW(tr1), ((EIF_NATURAL_8) 3U));
					} else {
						RTHOOK(57);
						tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_13_);
						tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
						F1294_12236(RTCW(tr1), ((EIF_NATURAL_8) 1U));
						RTHOOK(58);
						tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_13_);
						F1295_12256(RTCW(tr1), ((EIF_NATURAL_8) 1U));
					}
				} else {
					RTHOOK(59);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr2 = RTOUCR(439,F373_5822, (Current));
					tr1 = F1749_19460(RTCW(tr1), tr2);
					F455_6672(Current, tr1);
				}
			} else {
				RTHOOK(60);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr2 = RTOUCR(439,F373_5822, (Current));
				tr1 = F1749_19458(RTCW(tr1), tr2);
				F455_6671(Current, tr1);
			}
		}
	}
	RTHOOK(61);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1060L));
	loc15 = tr1;
	if (EIF_TEST(loc15)) {
		RTHOOK(62);
		tb1 = F1240_11227(loc15);
		if (tb1) {
			RTHOOK(63);
			tb1 = F1237_11136(loc15);
			F539_7943(RTCW(loc1), tb1);
		} else {
			RTHOOK(64);
			tr1 = RTOUCR(474,F421_6046, (Current));
			tr2 = RTOUCR(440,F373_5825, (Current));
			tr1 = F1749_19458(RTCW(tr1), tr2);
			F455_6671(Current, tr1);
		}
	}
	RTHOOK(65);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1071L));
	loc16 = tr1;
	if (EIF_TEST(loc16)) {
		RTHOOK(66);
		tr1 = RTOUCR(489,F452_6615, (Current));
		if ((EIF_BOOLEAN) !F454_6656(Current, tr1)) {
			RTHOOK(67);
			tr1 = RTOUCR(444,F373_5829, (Current));
			F537_7816(Current, tr1);
		} else {
			RTHOOK(68);
			tb1 = F1240_11227(loc16);
			if (tb1) {
				RTHOOK(69);
				tb1 = F1237_11136(loc16);
				F539_7944(RTCW(loc1), tb1);
			} else {
				RTHOOK(70);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr1 = F1749_19458(RTCW(tr1), loc16);
				F455_6671(Current, tr1);
			}
		}
	}
	RTHOOK(71);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1061L));
	loc17 = tr1;
	if (EIF_TEST(loc17)) {
		RTHOOK(72);
		tr1 = RTOUCR(484,F452_6601, (Current));
		if ((EIF_BOOLEAN) !F454_6656(Current, tr1)) {
			RTHOOK(73);
			tr1 = RTOUCR(445,F373_5830, (Current));
			F537_7816(Current, tr1);
		} else {
			RTHOOK(74);
			tb1 = F1240_11227(loc17);
			if (tb1) {
				RTHOOK(75);
				tb1 = F1237_11136(loc17);
				F539_7945(RTCW(loc1), tb1);
			} else {
				RTHOOK(76);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr2 = RTOUCR(445,F373_5830, (Current));
				tr1 = F1749_19458(RTCW(tr1), tr2);
				F455_6671(Current, tr1);
			}
		}
	}
	RTHOOK(77);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1063L));
	loc18 = tr1;
	if (EIF_TEST(loc18)) {
		RTHOOK(78);
		tr1 = RTOUCR(490,F452_6581, (Current));
		if (F454_6656(Current, tr1)) {
			RTHOOK(79);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_10_);
			tb1 = F1294_12224(RTCW(tr1), loc18);
			if (tb1) {
				RTHOOK(80);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					RTHOOK(81);
					tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_12_);
					tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
					F1294_12237(RTCW(tr1), loc18);
					RTHOOK(82);
					tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_12_);
					F1295_12255(RTCW(tr1), loc18);
					RTHOOK(83);
					tr1 = RTOUCR(491,F452_6591, (Current));
					if (F454_6655(Current, tr1)) {
						RTHOOK(84);
						tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_10_);
						tu1_1 = *(EIF_NATURAL_8 *)(RTCW(tr1)+ _CHROFF_1_2_);
						switch (tu1_1) {
							case 1U:
							case 3U:
								break;
							case 5U:
								RTHOOK(85);
								if ((EIF_BOOLEAN)(loc2 != NULL)) {
									RTHOOK(86);
									tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_12_);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
									F1294_12236(RTCW(tr1), ((EIF_NATURAL_8) 4U));
									RTHOOK(87);
									tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_12_);
									F1295_12256(RTCW(tr1), ((EIF_NATURAL_8) 4U));
								}
								break;
							default:
								RTHOOK(88);
								tr1 = RTOUCR(474,F421_6046, (Current));
								tr2 = RTOUCR(453,F373_5838, (Current));
								tr1 = F1749_19458(RTCW(tr1), tr2);
								F455_6671(Current, tr1);
								break;
						}
					}
				} else {
					RTHOOK(89);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr2 = RTOUCR(453,F373_5838, (Current));
					tr1 = F1749_19460(RTCW(tr1), tr2);
					F455_6672(Current, tr1);
				}
			} else {
				RTHOOK(90);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr2 = RTOUCR(453,F373_5838, (Current));
				tr1 = F1749_19458(RTCW(tr1), tr2);
				F455_6671(Current, tr1);
			}
		} else {
			RTHOOK(91);
			tr1 = RTOUCR(453,F373_5838, (Current));
			F537_7816(Current, tr1);
		}
	}
	RTHOOK(92);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1062L));
	loc19 = tr1;
	if (EIF_TEST(loc19)) {
		RTHOOK(93);
		tb1 = '\01';
		tr1 = RTOUCR(492,F452_6579, (Current));
		if (!F454_6655(Current, tr1)) {
			tb2 = '\0';
			tr1 = RTOUCR(477,F452_6589, (Current));
			if (F454_6656(Current, tr1)) {
				tr1 = RTOUCR(491,F452_6591, (Current));
				tb2 = F454_6655(Current, tr1);
			}
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(94);
			tb1 = F1240_11227(loc19);
			if (tb1) {
				RTHOOK(95);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					RTHOOK(96);
					tr1 = RTOUCR(492,F452_6579, (Current));
					if (F454_6655(Current, tr1)) {
						RTHOOK(97);
						tb1 = F1237_11136(loc19);
						if (tb1) {
							RTHOOK(98);
							tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_12_);
							tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
							F1294_12236(RTCW(tr1), ((EIF_NATURAL_8) 4U));
							RTHOOK(99);
							tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_12_);
							F1295_12256(RTCW(tr1), ((EIF_NATURAL_8) 4U));
						} else {
							RTHOOK(100);
							tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_12_);
							tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
							F1294_12236(RTCW(tr1), ((EIF_NATURAL_8) 1U));
							RTHOOK(101);
							tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_12_);
							F1295_12256(RTCW(tr1), ((EIF_NATURAL_8) 1U));
						}
					} else {
						RTHOOK(102);
						tb1 = F1237_11136(loc19);
						if (tb1) {
							RTHOOK(103);
							tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_12_);
							tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
							F1294_12236(RTCW(tr1), ((EIF_NATURAL_8) 5U));
							RTHOOK(104);
							tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_12_);
							F1295_12256(RTCW(tr1), ((EIF_NATURAL_8) 5U));
						}
					}
				} else {
					RTHOOK(105);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr2 = RTMS_EX_H("is_void_safe",12,1531546981);
					tr1 = F1749_19460(RTCW(tr1), tr2);
					F455_6672(Current, tr1);
				}
			} else {
				RTHOOK(106);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr2 = RTMS_EX_H("is_void_safe",12,1531546981);
				tr1 = F1749_19458(RTCW(tr1), tr2);
				F455_6671(Current, tr1);
			}
		} else {
			RTHOOK(107);
			tr1 = RTMS_EX_H("is_void_safe",12,1531546981);
			F537_7816(Current, tr1);
		}
	}
	RTHOOK(108);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1064L));
	loc20 = tr1;
	if (EIF_TEST(loc20)) {
		RTHOOK(109);
		tr1 = RTOUCR(492,F452_6579, (Current));
		if (F454_6655(Current, tr1)) {
			RTHOOK(110);
			tb1 = F1237_11093(loc20);
			if (tb1) {
				RTHOOK(111);
				tu1_1 = F1237_11127(loc20);
				switch (tu1_1) {
					case 0U:
						RTHOOK(112);
						tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_4_);
						F1294_12236(RTCW(tr1), ((EIF_NATURAL_8) 1U));
						break;
					case 1U:
						RTHOOK(113);
						tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_4_);
						F1294_12236(RTCW(tr1), ((EIF_NATURAL_8) 2U));
						break;
					case 2U:
						RTHOOK(114);
						tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_4_);
						F1294_12236(RTCW(tr1), ((EIF_NATURAL_8) 3U));
						break;
					default:
						RTHOOK(115);
						tr1 = RTOUCR(474,F421_6046, (Current));
						tr2 = RTMS_EX_H("syntax_level",12,1690338668);
						tr1 = F1749_19458(RTCW(tr1), tr2);
						F455_6671(Current, tr1);
						break;
				}
			} else {
				RTHOOK(116);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr2 = RTMS_EX_H("syntax_level",12,1690338668);
				tr1 = F1749_19458(RTCW(tr1), tr2);
				F455_6671(Current, tr1);
			}
		} else {
			RTHOOK(117);
			tr1 = RTMS_EX_H("syntax_level",12,1690338668);
			F537_7816(Current, tr1);
		}
	}
	RTHOOK(118);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1065L));
	loc21 = tr1;
	if (EIF_TEST(loc21)) {
		RTHOOK(119);
		tr1 = RTOUCR(490,F452_6581, (Current));
		if (F454_6656(Current, tr1)) {
			RTHOOK(120);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_4_);
			tb1 = F1294_12224(RTCW(tr1), loc21);
			if (tb1) {
				RTHOOK(121);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_4_);
				F1294_12237(RTCW(tr1), loc21);
			} else {
				RTHOOK(122);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr2 = RTOUCR(452,F373_5837, (Current));
				tr1 = F1749_19458(RTCW(tr1), tr2);
				F455_6671(Current, tr1);
			}
		} else {
			RTHOOK(123);
			tr1 = RTOUCR(452,F373_5837, (Current));
			F537_7816(Current, tr1);
		}
	}
	RTHOOK(124);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1070L));
	loc22 = tr1;
	if (EIF_TEST(loc22)) {
		RTHOOK(125);
		tr1 = RTOUCR(481,F452_6607, (Current));
		if ((EIF_BOOLEAN) !F454_6656(Current, tr1)) {
			RTHOOK(126);
			tr1 = RTOUCR(450,F373_5835, (Current));
			F537_7816(Current, tr1);
		} else {
			RTHOOK(127);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_5_);
			tb1 = F1294_12224(RTCW(tr1), loc22);
			if (tb1) {
				RTHOOK(128);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_5_);
				F1294_12237(RTCW(tr1), loc22);
			} else {
				RTHOOK(129);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr2 = RTOUCR(450,F373_5835, (Current));
				tr1 = F1749_19458(RTCW(tr1), tr2);
				F455_6671(Current, tr1);
			}
		}
	}
	RTHOOK(130);
	if (arg1) {
		RTHOOK(131);
		tb1 = '\0';
		tb2 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1007L));
		loc23 = tr1;
		if (EIF_TEST(loc23)) {
			tb2 = F270_4601(Current, loc23);
		}
		if (tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
			loc24 = tr1;
			tb1 = EIF_TEST(loc24);
		}
		if (tb1) {
			RTHOOK(132);
			tr1 = F1242_11340(loc23);
			F1420_13544(loc24, loc1, tr1);
		} else {
			RTHOOK(133);
			tr1 = F1749_19514(RTCV(RTOUCR(474,F421_6046, (Current))));
			F455_6671(Current, tr1);
		}
	} else {
		RTHOOK(134);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
		loc25 = tr1;
		if (EIF_TEST(loc25)) {
			RTHOOK(135);
			F1420_13542(loc25, loc1);
		} else {
			RTHOOK(136);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
			loc26 = tr1;
			if (EIF_TEST(loc26)) {
				RTHOOK(137);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					RTHOOK(138);
					F459_6768(loc26, loc2);
				} else {
					
				}
			} else {
				
			}
		}
	}
	RTHOOK(141);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	loc27 = tr1;
	loc27 = RTRV(eif_new_type(1427, 0x00),loc27);
	if (EIF_TEST(loc27)) {
		RTHOOK(142);
		F537_7785(Current);
	}
	
	RTHOOK(145);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_visible_attributes */
void F537_7765 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(12);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,loc7);
	RTLR(6,loc4);
	RTLR(7,loc8);
	RTLR(8,loc5);
	RTLR(9,loc9);
	RTLR(10,loc6);
	RTLR(11,tr2);
	RTLIU(12);
	
	RTEAA("process_visible_attributes", 536, Current, 9, 0, 7903);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc3 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1007L));
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		RTHOOK(3);
		tr1 = F1242_11339(RTCW(loc3));
		loc3 = (EIF_REFERENCE) tr1;
	}
	RTHOOK(4);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	RTHOOK(5);
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	RTHOOK(6);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		tb1 = F270_4601(Current, loc3);
	}
	if (tb1) {
		RTHOOK(7);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1009L));
		loc7 = tr1;
		if (EIF_TEST(loc7)) {
			RTHOOK(8);
			loc4 = F1242_11339(loc7);
			RTHOOK(9);
			if ((EIF_BOOLEAN) !F270_4619(Current, loc4)) {
				RTHOOK(10);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr1 = F1749_19517(RTCW(tr1), loc4);
				F455_6671(Current, tr1);
			}
		}
		RTHOOK(11);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1010L));
		loc8 = tr1;
		if (EIF_TEST(loc8)) {
			RTHOOK(12);
			loc5 = F1242_11339(loc8);
			RTHOOK(13);
			if ((EIF_BOOLEAN) !F270_4601(Current, loc5)) {
				RTHOOK(14);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr1 = F1749_19518(RTCW(tr1), loc5);
				F455_6671(Current, tr1);
			}
		}
		RTHOOK(15);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1011L));
		loc9 = tr1;
		if (EIF_TEST(loc9)) {
			RTHOOK(16);
			loc6 = F1242_11339(loc9);
			RTHOOK(17);
			if ((EIF_BOOLEAN) !F270_4619(Current, loc6)) {
				RTHOOK(18);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr1 = F1749_19517(RTCW(tr1), loc6);
				F455_6671(Current, tr1);
			}
		}
		RTHOOK(19);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTHOOK(20);
			F541_7991(RTCW(loc1), loc3, loc4, loc5, loc6);
		} else {
			RTHOOK(21);
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				RTHOOK(22);
				F541_7991(RTCW(loc2), loc3, loc4, loc5, loc6);
			} else {
				
			}
		}
	} else {
		RTHOOK(24);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTHOOK(25);
			tr1 = RTOUCR(474,F421_6046, (Current));
			tr2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_5_);
			tr1 = F1749_19516(RTCW(tr1), tr2);
			F455_6671(Current, tr1);
		} else {
			RTHOOK(26);
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				RTHOOK(27);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr2 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_5_);
				tr1 = F1749_19516(RTCW(tr1), tr2);
				F455_6671(Current, tr1);
			} else {
				
			}
		}
	}
	RTHOOK(29);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_uses_attributes */
void F537_7766 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("process_uses_attributes", 536, Current, 2, 0, 7904);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1049L));
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tb1 = F270_4602(Current, loc2);
		}
		if (tb1) {
			RTHOOK(3);
			tr1 = RTMS_EX_H("none",4,1852796517);
			tb1 = F1237_11104(loc2, tr1);
			if (tb1) {
				RTHOOK(4);
				{
					static EIF_TYPE_INDEX typarr0[] = {1710,1419,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
					tr1 = RTLNS(typres0.id, 1710, _OBJSIZ_4_1_0_5_0_0_0_0_);
				}
				F1711_18130(RTCW(tr1), ((EIF_INTEGER_32) 0L));
				F1423_13598(loc1, tr1);
			} else {
				RTHOOK(5);
				F1423_13600(loc1, loc2);
			}
		} else {
			RTHOOK(6);
			tr1 = RTOUCR(474,F421_6046, (Current));
			tr2 = *(EIF_REFERENCE *)(loc1 + _REFACS_5_);
			tr1 = F1749_19519(RTCW(tr1), tr2);
			F455_6671(Current, tr1);
		}
	} else {
		
		RTHOOK(8);
		F455_6666(Current);
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_overrides_attributes */
void F537_7767 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("process_overrides_attributes", 536, Current, 2, 0, 7905);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1049L));
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tb1 = F270_4602(Current, loc2);
		}
		if (tb1) {
			RTHOOK(3);
			tr1 = RTMS_EX_H("none",4,1852796517);
			tb1 = F1237_11104(loc2, tr1);
			if (tb1) {
				RTHOOK(4);
				{
					static EIF_TYPE_INDEX typarr0[] = {891,1419,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
					tr1 = RTLNS(typres0.id, 891, _OBJSIZ_1_1_0_1_0_0_0_0_);
				}
				F892_8780(RTCW(tr1), ((EIF_INTEGER_32) 0L));
				F1425_13621(loc1, tr1);
			} else {
				RTHOOK(5);
				F1425_13623(loc1, loc2);
			}
		} else {
			RTHOOK(6);
			tr1 = RTOUCR(474,F421_6046, (Current));
			tr2 = *(EIF_REFERENCE *)(loc1 + _REFACS_5_);
			tr1 = F1749_19520(RTCW(tr1), tr2);
			F455_6671(Current, tr1);
		}
	} else {
		
		RTHOOK(8);
		F455_6666(Current);
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_condition_attributes */
void F537_7768 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLR(6,loc5);
	RTLR(7,loc6);
	RTLIU(8);
	
	RTEAA("process_condition_attributes", 536, Current, 6, 0, 7906);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTHOOK(2);
		loc1 = RTLNSMART(eif_new_type(1750, 0).id);
		F1751_19564(RTCW(loc1), loc2);
	} else {
		RTHOOK(3);
		loc1 = RTLNSMART(eif_new_type(1750, 0).id);
		F1751_19563(RTCW(loc1));
	}
	RTHOOK(4);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) loc1;
	RTHOOK(5);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_)) {
		RTHOOK(6);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			RTHOOK(7);
			F460_6780(loc3, loc1);
		} else {
			RTHOOK(8);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
			loc4 = tr1;
			if (EIF_TEST(loc4)) {
				RTHOOK(9);
				F463_6828(loc4, loc1);
			} else {
				RTHOOK(10);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
				loc5 = tr1;
				if (EIF_TEST(loc5)) {
					RTHOOK(11);
					F460_6780(loc5, loc1);
				} else {
					RTHOOK(12);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
					loc6 = tr1;
					if (EIF_TEST(loc6)) {
						RTHOOK(13);
						F1420_13545(loc6, loc1);
					} else {
						RTHOOK(14);
						tr1 = F1749_19521(RTCV(RTOUCR(474,F421_6046, (Current))));
						F455_6671(Current, tr1);
					}
				}
			}
		}
	}
	RTHOOK(16);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_platform_attributes */
void F537_7769 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,arg1);
	RTLR(5,loc4);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTEAA("process_platform_attributes", 536, Current, 5, 1, 7907);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1027L));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc2 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1028L));
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		RTHOOK(4);
		tr1 = F1749_19522(RTCV(RTOUCR(474,F421_6046, (Current))));
		F455_6671(Current, tr1);
	} else {
		RTHOOK(5);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 != NULL) && (EIF_BOOLEAN)(loc2 != NULL))) {
			RTHOOK(6);
			tr1 = F1749_19523(RTCV(RTOUCR(474,F421_6046, (Current))));
			F455_6671(Current, tr1);
		} else {
			RTHOOK(7);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == NULL) && (EIF_BOOLEAN)(loc2 == NULL))) {
				RTHOOK(8);
				tr1 = F1749_19524(RTCV(RTOUCR(474,F421_6046, (Current))));
				F455_6671(Current, tr1);
			} else {
				RTHOOK(9);
				if ((EIF_BOOLEAN)(loc1 != NULL)) {
					RTHOOK(10);
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
					loc4 = F1237_11137(RTCW(loc1), tw1);
				} else {
					RTHOOK(11);
					if ((EIF_BOOLEAN)(loc2 != NULL)) {
						RTHOOK(12);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
						loc4 = F1237_11137(RTCW(loc2), tw1);
						RTHOOK(13);
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						
					}
				}
			}
		}
	}
	RTHOOK(15);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_) && (EIF_BOOLEAN)(loc4 != NULL))) {
		RTHOOK(16);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R7637[Dtype(RTCW(loc4))-882])(loc4);
		for (;;) {
			RTHOOK(17);
			tb1 = '\01';
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7648[Dtype(RTCW(loc4))-882])(loc4);
			if (!tb2) {
				tb1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_);
			}
			if (tb1) break;
			RTHOOK(18);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7670[Dtype(RTCW(loc4))-780])(loc4);
			loc3 = F457_6701(Current, tr1);
			RTHOOK(19);
			if ((EIF_BOOLEAN) !F457_6683(Current, loc3)) {
				RTHOOK(20);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7670[Dtype(RTCW(loc4))-780])(loc4);
				tr1 = F1749_19525(RTCW(tr1), tr2);
				F455_6671(Current, tr1);
			} else {
				RTHOOK(21);
				if (loc5) {
					RTHOOK(22);
					F1751_19579(RTCW(arg1), loc3);
				} else {
					RTHOOK(23);
					F1751_19578(RTCW(arg1), loc3);
				}
			}
			RTHOOK(24);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R7650[Dtype(RTCW(loc4))-882])(loc4);
		}
	}
	RTHOOK(25);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_build_attributes */
void F537_7770 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,arg1);
	RTLR(5,loc4);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTEAA("process_build_attributes", 536, Current, 5, 1, 7908);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1027L));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc2 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1028L));
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		RTHOOK(4);
		tr1 = F1749_19526(RTCV(RTOUCR(474,F421_6046, (Current))));
		F455_6671(Current, tr1);
	} else {
		RTHOOK(5);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 != NULL) && (EIF_BOOLEAN)(loc2 != NULL))) {
			RTHOOK(6);
			tr1 = F1749_19527(RTCV(RTOUCR(474,F421_6046, (Current))));
			F455_6671(Current, tr1);
		} else {
			RTHOOK(7);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == NULL) && (EIF_BOOLEAN)(loc2 == NULL))) {
				RTHOOK(8);
				tr1 = F1749_19528(RTCV(RTOUCR(474,F421_6046, (Current))));
				F455_6671(Current, tr1);
			} else {
				RTHOOK(9);
				if ((EIF_BOOLEAN)(loc1 != NULL)) {
					RTHOOK(10);
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
					loc4 = F1237_11137(RTCW(loc1), tw1);
				} else {
					RTHOOK(11);
					if ((EIF_BOOLEAN)(loc2 != NULL)) {
						RTHOOK(12);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
						loc4 = F1237_11137(RTCW(loc2), tw1);
						RTHOOK(13);
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						
					}
				}
			}
		}
	}
	RTHOOK(15);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_) && (EIF_BOOLEAN)(loc4 != NULL))) {
		RTHOOK(16);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R7637[Dtype(RTCW(loc4))-882])(loc4);
		for (;;) {
			RTHOOK(17);
			tb1 = '\01';
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7648[Dtype(RTCW(loc4))-882])(loc4);
			if (!tb2) {
				tb1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_);
			}
			if (tb1) break;
			RTHOOK(18);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7670[Dtype(RTCW(loc4))-780])(loc4);
			loc3 = F457_6702(Current, tr1);
			RTHOOK(19);
			if ((EIF_BOOLEAN) !F457_6684(Current, loc3)) {
				RTHOOK(20);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7670[Dtype(RTCW(loc4))-780])(loc4);
				tr1 = F1749_19529(RTCW(tr1), tr2);
				F455_6671(Current, tr1);
			} else {
				RTHOOK(21);
				if (loc5) {
					RTHOOK(22);
					F1751_19582(RTCW(arg1), loc3);
				} else {
					RTHOOK(23);
					F1751_19581(RTCW(arg1), loc3);
				}
			}
			RTHOOK(24);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R7650[Dtype(RTCW(loc4))-882])(loc4);
		}
	}
	RTHOOK(25);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_multithreaded_attributes */
void F537_7771 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("process_multithreaded_attributes", 536, Current, 1, 1, 7909);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(483,F452_6585, (Current));
	if (F454_6655(Current, tr1)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		loc1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1027L));
		RTHOOK(3);
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(loc1 == NULL)) {
			tb2 = F1240_11227(RTCW(loc1));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			RTHOOK(4);
			tr1 = F1749_19530(RTCV(RTOUCR(474,F421_6046, (Current))));
			F455_6671(Current, tr1);
		} else {
			RTHOOK(5);
			tb1 = F1237_11136(RTCW(loc1));
			if (tb1) {
				RTHOOK(6);
				F1751_19585(RTCW(arg1), ((EIF_INTEGER_32) 2048L));
			} else {
				RTHOOK(7);
				F1751_19584(RTCW(arg1), ((EIF_INTEGER_32) 2048L));
			}
		}
	} else {
		RTHOOK(8);
		tr1 = F1749_19521(RTCV(RTOUCR(474,F421_6046, (Current))));
		F455_6671(Current, tr1);
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_concurrency_attributes */
void F537_7772 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,tr2);
	RTLR(6,loc4);
	RTLR(7,arg1);
	RTLIU(8);
	
	RTEAA("process_concurrency_attributes", 536, Current, 6, 1, 7910);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(493,F452_6587, (Current));
	if (F454_6656(Current, tr1)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		loc1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1001L));
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		loc2 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1027L));
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		loc3 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1028L));
		RTHOOK(5);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 == NULL) && (EIF_BOOLEAN)(loc3 == NULL))) {
			RTHOOK(6);
			tr1 = RTOUCR(474,F421_6046, (Current));
			tr2 = RTMS_EX_H("(undefined)",11,959041577);
			tr1 = F1749_19531(RTCW(tr1), tr2);
			F455_6671(Current, tr1);
		} else {
			RTHOOK(7);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 != NULL) && (EIF_BOOLEAN)(loc3 != NULL))) {
				RTHOOK(8);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr2 = RTMS_EX_H("(Cannot include and exclude at the same time)",45,1282171433);
				tr1 = F1749_19531(RTCW(tr1), tr2);
				F455_6671(Current, tr1);
			} else {
				RTHOOK(9);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					RTHOOK(10);
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
					loc4 = F1237_11137(RTCW(loc2), tw1);
				} else {
					RTHOOK(11);
					if ((EIF_BOOLEAN)(loc3 != NULL)) {
						RTHOOK(12);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
						loc4 = F1237_11137(RTCW(loc3), tw1);
						RTHOOK(13);
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						
					}
				}
			}
		}
		RTHOOK(15);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_) && (EIF_BOOLEAN)(loc4 != NULL))) {
			RTHOOK(16);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R7637[Dtype(RTCW(loc4))-882])(loc4);
			for (;;) {
				RTHOOK(17);
				tb1 = '\01';
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7648[Dtype(RTCW(loc4))-882])(loc4);
				if (!tb2) {
					tb1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_);
				}
				if (tb1) break;
				RTHOOK(18);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7670[Dtype(RTCW(loc4))-780])(loc4);
				loc6 = F457_6703(Current, tr1);
				RTHOOK(19);
				if ((EIF_BOOLEAN) !F457_6685(Current, loc6)) {
					RTHOOK(20);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7670[Dtype(RTCW(loc4))-780])(loc4);
					tr1 = F1749_19531(RTCW(tr1), tr2);
					F455_6671(Current, tr1);
				} else {
					RTHOOK(21);
					if (loc5) {
						RTHOOK(22);
						F1751_19585(RTCW(arg1), loc6);
					} else {
						RTHOOK(23);
						F1751_19584(RTCW(arg1), loc6);
					}
				}
				RTHOOK(24);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R7650[Dtype(RTCW(loc4))-882])(loc4);
			}
		}
	} else {
		RTHOOK(25);
		tr1 = F1749_19521(RTCV(RTOUCR(474,F421_6046, (Current))));
		F455_6671(Current, tr1);
	}
	RTHOOK(26);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_void_safety_attributes */
void F537_7773 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,tr2);
	RTLR(6,loc4);
	RTLR(7,arg1);
	RTLIU(8);
	
	RTEAA("process_void_safety_attributes", 536, Current, 6, 1, 7911);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(485,F452_6609, (Current));
	if (F454_6656(Current, tr1)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		loc1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1001L));
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		loc2 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1027L));
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		loc3 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1028L));
		RTHOOK(5);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 == NULL) && (EIF_BOOLEAN)(loc3 == NULL))) {
			RTHOOK(6);
			tr1 = RTOUCR(474,F421_6046, (Current));
			tr2 = RTMS_EX_H("(undefined)",11,959041577);
			tr1 = F1749_19532(RTCW(tr1), tr2);
			F455_6671(Current, tr1);
		} else {
			RTHOOK(7);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 != NULL) && (EIF_BOOLEAN)(loc3 != NULL))) {
				RTHOOK(8);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr2 = RTMS_EX_H("(Cannot include and exclude at the same time)",45,1282171433);
				tr1 = F1749_19532(RTCW(tr1), tr2);
				F455_6671(Current, tr1);
			} else {
				RTHOOK(9);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					RTHOOK(10);
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
					loc4 = F1237_11137(RTCW(loc2), tw1);
				} else {
					RTHOOK(11);
					if ((EIF_BOOLEAN)(loc3 != NULL)) {
						RTHOOK(12);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
						loc4 = F1237_11137(RTCW(loc3), tw1);
						RTHOOK(13);
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						
					}
				}
			}
		}
		RTHOOK(15);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_) && (EIF_BOOLEAN)(loc4 != NULL))) {
			RTHOOK(16);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R7637[Dtype(RTCW(loc4))-882])(loc4);
			for (;;) {
				RTHOOK(17);
				tb1 = '\01';
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7648[Dtype(RTCW(loc4))-882])(loc4);
				if (!tb2) {
					tb1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_);
				}
				if (tb1) break;
				RTHOOK(18);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7670[Dtype(RTCW(loc4))-780])(loc4);
				loc6 = F457_6704(Current, tr1);
				RTHOOK(19);
				if ((EIF_BOOLEAN) !F457_6686(Current, loc6)) {
					RTHOOK(20);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7670[Dtype(RTCW(loc4))-780])(loc4);
					tr1 = F1749_19532(RTCW(tr1), tr2);
					F455_6671(Current, tr1);
				} else {
					RTHOOK(21);
					if (loc5) {
						RTHOOK(22);
						F1751_19588(RTCW(arg1), loc6);
					} else {
						RTHOOK(23);
						F1751_19587(RTCW(arg1), loc6);
					}
				}
				RTHOOK(24);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R7650[Dtype(RTCW(loc4))-882])(loc4);
			}
		}
	} else {
		RTHOOK(25);
		tr1 = F1749_19521(RTCV(RTOUCR(474,F421_6046, (Current))));
		F455_6671(Current, tr1);
	}
	RTHOOK(26);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_dotnet_attributes */
void F537_7774 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("process_dotnet_attributes", 536, Current, 1, 1, 7912);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1027L));
	RTHOOK(2);
	tb1 = '\01';
	if (!(EIF_BOOLEAN)(loc1 == NULL)) {
		tb2 = F1240_11227(RTCW(loc1));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(3);
		tr1 = F1749_19533(RTCV(RTOUCR(474,F421_6046, (Current))));
		F455_6671(Current, tr1);
	} else {
		RTHOOK(4);
		tb1 = F1237_11136(RTCW(loc1));
		F1751_19590(RTCW(arg1), tb1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_dynamic_runtime_attributes */
void F537_7775 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("process_dynamic_runtime_attributes", 536, Current, 1, 1, 7913);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1027L));
	RTHOOK(2);
	tb1 = '\01';
	if (!(EIF_BOOLEAN)(loc1 == NULL)) {
		tb2 = F1240_11227(RTCW(loc1));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(3);
		tr1 = F1749_19534(RTCV(RTOUCR(474,F421_6046, (Current))));
		F455_6671(Current, tr1);
	} else {
		RTHOOK(4);
		tb1 = F1237_11136(RTCW(loc1));
		F1751_19591(RTCW(arg1), tb1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_version_condition_attributes */
void F537_7776 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLR(6,loc5);
	RTLR(7,arg1);
	RTLIU(8);
	
	RTEAA("process_version_condition_attributes", 536, Current, 5, 1, 7914);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1045L));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc2 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1046L));
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc3 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1052L));
	RTHOOK(4);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTHOOK(5);
		loc4 = RTLNS(eif_new_type(1713, 0x00).id, 1713, _OBJSIZ_4_5_4_0_0_0_0_0_);
		F1714_18188(RTCW(loc4), loc1);
		RTHOOK(6);
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc4)+ _CHROFF_4_0_);
		if (tb1) {
			RTHOOK(7);
			tr1 = RTOUCR(474,F421_6046, (Current));
			tr1 = F1749_19535(RTCW(tr1), loc1);
			F455_6671(Current, tr1);
		}
	}
	RTHOOK(8);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTHOOK(9);
		loc5 = RTLNS(eif_new_type(1713, 0x00).id, 1713, _OBJSIZ_4_5_4_0_0_0_0_0_);
		F1714_18188(RTCW(loc5), loc2);
		RTHOOK(10);
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc5)+ _CHROFF_4_0_);
		if (tb1) {
			RTHOOK(11);
			tr1 = RTOUCR(474,F421_6046, (Current));
			tr1 = F1749_19536(RTCW(tr1), loc2);
			F455_6671(Current, tr1);
		}
	}
	RTHOOK(12);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_26_0_)) {
		RTHOOK(13);
		if ((EIF_BOOLEAN)(loc3 == NULL)) {
			RTHOOK(14);
			tr1 = F1749_19537(RTCV(RTOUCR(474,F421_6046, (Current))));
			F455_6671(Current, tr1);
		} else {
			RTHOOK(15);
			if ((EIF_BOOLEAN) !F457_6694(Current, loc3)) {
				RTHOOK(16);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr1 = F1749_19539(RTCW(tr1), loc3);
				F455_6671(Current, tr1);
			} else {
				RTHOOK(17);
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == NULL) && (EIF_BOOLEAN)(loc2 == NULL))) {
					RTHOOK(18);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr1 = F1749_19538(RTCW(tr1), loc3);
					F455_6671(Current, tr1);
				} else {
					RTHOOK(19);
					tb1 = '\0';
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 != NULL) && (EIF_BOOLEAN)(loc2 != NULL))) {
						tb2 = F444_6475(RTCW(loc1), loc2);
						tb1 = tb2;
					}
					if (tb1) {
						RTHOOK(20);
						tr1 = RTOUCR(474,F421_6046, (Current));
						tr1 = F1749_19540(RTCW(tr1), loc3);
						F455_6671(Current, tr1);
					} else {
						RTHOOK(21);
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc4 != NULL) || (EIF_BOOLEAN)(loc5 != NULL))) {
							RTHOOK(22);
							F1751_19598(RTCW(arg1), loc4, loc5, loc3);
						} else {
							
						}
					}
				}
			}
		}
	}
	RTHOOK(24);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_custom_attributes */
void F537_7777 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLR(6,loc5);
	RTLR(7,arg1);
	RTLIU(8);
	
	RTEAA("process_custom_attributes", 536, Current, 5, 1, 7915);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1001L));
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		tr1 = F1749_19541(RTCV(RTOUCR(474,F421_6046, (Current))));
		F455_6671(Current, tr1);
	} else {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		loc2 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1027L));
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		loc3 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1028L));
		RTHOOK(6);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 == NULL) && (EIF_BOOLEAN)(loc3 == NULL)) || (EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 != NULL) && (EIF_BOOLEAN)(loc3 != NULL)))) {
			RTHOOK(7);
			tr1 = RTOUCR(474,F421_6046, (Current));
			tr1 = F1749_19543(RTCW(tr1), loc1);
			F455_6671(Current, tr1);
		} else {
			RTHOOK(8);
			loc4 = RTLNS(eif_new_type(41, 0x00).id, 41, _OBJSIZ_0_2_0_0_0_0_0_0_);
			RTHOOK(9);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
			tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1069L));
			loc5 = tr1;
			if (EIF_TEST(loc5)) {
				RTHOOK(10);
				tr1 = RTOUCR(481,F452_6607, (Current));
				if (F454_6656(Current, tr1)) {
					RTHOOK(11);
					tr1 = RTOUCR(494,F537_7779, (Current));
					F813_8478(RTCW(tr1), loc5);
					RTHOOK(12);
					tb1 = F813_8468(RTCV(RTOUCR(494,F537_7779, (Current))));
					if (tb1) {
						RTHOOK(13);
						tu1_1 = *(EIF_NATURAL_8 *)(RTCV(RTOUCR(494,F537_7779, (Current)))+ _CHROFF_5_4_);
						F42_629(RTCW(loc4), tu1_1);
					}
				} else {
					RTHOOK(14);
					tr1 = RTOUCR(467,F373_5856, (Current));
					F537_7816(Current, tr1);
				}
			}
			RTHOOK(15);
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				RTHOOK(16);
				F1751_19594(RTCW(arg1), loc1, loc2, loc4);
			} else {
				RTHOOK(17);
				if ((EIF_BOOLEAN)(loc3 != NULL)) {
					RTHOOK(18);
					F42_628(RTCW(loc4), (EIF_BOOLEAN) 1);
					RTHOOK(19);
					F1751_19594(RTCW(arg1), loc1, loc3, loc4);
				} else {
					
				}
			}
		}
	}
	RTHOOK(21);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_mapping_attributes */
void F537_7778 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLIU(6);
	
	RTEAA("process_mapping_attributes", 536, Current, 4, 0, 7916);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1047L));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
	loc2 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 1048L));
	RTHOOK(3);
	tb1 = '\01';
	if (!(EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == NULL) || (EIF_BOOLEAN)(loc2 == NULL))) {
		tb2 = '\01';
		if (!(EIF_BOOLEAN) !F270_4601(Current, loc1)) {
			tb2 = (EIF_BOOLEAN) !F270_4601(Current, loc2);
		}
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(4);
		tr1 = F1749_19544(RTCV(RTOUCR(474,F421_6046, (Current))));
		F455_6671(Current, tr1);
	} else {
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			RTHOOK(6);
			F1423_13604(loc3, loc1, loc2);
		} else {
			RTHOOK(7);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
			loc4 = tr1;
			if (EIF_TEST(loc4)) {
				RTHOOK(8);
				F1301_12510(loc4, loc1, loc2);
			} else {
				
			}
		}
	}
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.match_kind */
static EIF_REFERENCE F537_7779_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(494)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("match_kind", 536, Current, 1, 0, 7917);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {817,1504,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 817, _OBJSIZ_5_6_0_7_0_0_0_0_);
	}
	F818_8548(RTCW(tr1), ((EIF_INTEGER_32) 4L));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTOUCR(468,F373_5857, (Current));
	F813_8484(RTCW(Result), ((EIF_NATURAL_8) 1U), tr1);
	RTHOOK(3);
	tr1 = RTOUCR(469,F373_5858, (Current));
	F813_8484(RTCW(Result), ((EIF_NATURAL_8) 2U), tr1);
	RTHOOK(4);
	tr1 = RTOUCR(470,F373_5859, (Current));
	F813_8484(RTCW(Result), ((EIF_NATURAL_8) 3U), tr1);
	RTHOOK(5);
	tr1 = RTOUCR(471,F373_5860, (Current));
	F813_8484(RTCW(Result), ((EIF_NATURAL_8) 4U), tr1);
	RTOTE;
	RTHOOK(13);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F537_7779 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(494,F537_7779_body,(Current));
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_description_content */
void F537_7780 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLR(6,loc5);
	RTLR(7,loc6);
	RTLR(8,loc7);
	RTLIU(9);
	
	RTEAA("process_description_content", 536, Current, 7, 0, 7918);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		F461_6793(loc1, *(EIF_REFERENCE *)(Current + _REFACS_19_));
	} else {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTHOOK(4);
			F539_7946(loc2, *(EIF_REFERENCE *)(Current + _REFACS_19_));
		} else {
			RTHOOK(5);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				RTHOOK(6);
				F462_6814(loc3, *(EIF_REFERENCE *)(Current + _REFACS_19_));
			} else {
				RTHOOK(7);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
				loc4 = tr1;
				if (EIF_TEST(loc4)) {
					RTHOOK(8);
					F463_6827(loc4, *(EIF_REFERENCE *)(Current + _REFACS_19_));
				} else {
					RTHOOK(9);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
					loc5 = tr1;
					if (EIF_TEST(loc5)) {
						RTHOOK(10);
						F1420_13537(loc5, *(EIF_REFERENCE *)(Current + _REFACS_19_));
					} else {
						RTHOOK(11);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
						loc6 = tr1;
						if (EIF_TEST(loc6)) {
							RTHOOK(12);
							F1301_12462(loc6, *(EIF_REFERENCE *)(Current + _REFACS_19_));
						} else {
							RTHOOK(13);
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
							loc7 = tr1;
							if (EIF_TEST(loc7)) {
								RTHOOK(14);
								F1742_18882(loc7, *(EIF_REFERENCE *)(Current + _REFACS_19_));
							} else {
								RTHOOK(15);
								tr1 = F1749_19545(RTCV(RTOUCR(474,F421_6046, (Current))));
								F455_6671(Current, tr1);
							}
						}
					}
				}
			}
		}
	}
	RTHOOK(16);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_exclude_content */
void F537_7781 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTEAA("process_exclude_content", 536, Current, 3, 0, 7919);
	RTGC;
	RTHOOK(1);
	tr1 = F457_6690(Current, *(EIF_REFERENCE *)(Current + _REFACS_19_));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(1113, 0x00).id, 1113, _OBJSIZ_3_0_0_4_0_0_0_0_);
		tr2 = eif_boxed_item(loc1,1);
		ti4_1 = eif_integer_32_item(loc1,2);
		F1114_9408(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_19_), tr2, ti4_1);
		F455_6669(Current, tr1);
	} else {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTHOOK(4);
			F461_6789(loc2, *(EIF_REFERENCE *)(Current + _REFACS_19_));
			RTHOOK(5);
			tr1 = *(EIF_REFERENCE *)(loc2 + _REFACS_4_);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				RTHOOK(6);
				tr1 = RTLNS(eif_new_type(1113, 0x00).id, 1113, _OBJSIZ_3_0_0_4_0_0_0_0_);
				F1114_9408(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_19_), loc3, ((EIF_INTEGER_32) 0L));
				F455_6669(Current, tr1);
			}
		} else {
			
			RTHOOK(8);
			F455_6666(Current);
		}
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_include_content */
void F537_7782 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTEAA("process_include_content", 536, Current, 3, 0, 7920);
	RTGC;
	RTHOOK(1);
	tr1 = F457_6690(Current, *(EIF_REFERENCE *)(Current + _REFACS_19_));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(1113, 0x00).id, 1113, _OBJSIZ_3_0_0_4_0_0_0_0_);
		tr2 = eif_boxed_item(loc1,1);
		ti4_1 = eif_integer_32_item(loc1,2);
		F1114_9408(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_19_), tr2, ti4_1);
		F455_6669(Current, tr1);
	} else {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTHOOK(4);
			F461_6790(loc2, *(EIF_REFERENCE *)(Current + _REFACS_19_));
			RTHOOK(5);
			tr1 = *(EIF_REFERENCE *)(loc2 + _REFACS_4_);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				RTHOOK(6);
				tr1 = RTLNS(eif_new_type(1113, 0x00).id, 1113, _OBJSIZ_3_0_0_4_0_0_0_0_);
				F1114_9408(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_19_), loc3, ((EIF_INTEGER_32) 0L));
				F455_6669(Current, tr1);
			}
		} else {
			
			RTHOOK(8);
			F455_6666(Current);
		}
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.set_default_options */
void F537_7783 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc2);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,tr2);
	RTLR(4,loc1);
	RTLR(5,arg1);
	RTLR(6,Current);
	RTLIU(7);
	
	RTEAA("set_default_options", 536, Current, 2, 2, 7921);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(539, 0x00).id, 539, _OBJSIZ_18_18_0_0_0_0_0_0_);
	tr2 = F539_7847(RTCW(tr1), arg2);
	loc2 = tr2;
	if (EIF_TEST(loc2)) {
		RTHOOK(2);
		loc1 = F1301_12446(RTCW(arg1));
		RTHOOK(3);
		F540_7982(RTCW(loc1), loc2);
		RTHOOK(4);
		F459_6767(RTCW(arg1), loc1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.non_client_options */
static EIF_REFERENCE F537_7784_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTCFDD;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(495)
	dftype = Dftype(Current);

	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc4);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("non_client_options", 536, Current, 4, 0, 7922);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {937,0xFFF9,2,1186,1236,1486,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNS(typres0.id, 937, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F938_9008(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTOUCR(475,F537_7814, (Current));
	tr1 = F808_8442(RTCW(tr1), ((EIF_INTEGER_32) 8L));
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		RTHOOK(3);
		loc1 = RTOUCR(496,F276_4641, (Current));
		RTHOOK(4);
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			RTHOOK(5);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_0_);
			if ((EIF_BOOLEAN) (loc2 > ti4_1)) break;
			RTHOOK(6);
			loc3 = F941_9014(RTCW(loc1), loc2);
			
			RTHOOK(8);
			F809_8475(loc4);
			for (;;) {
				RTHOOK(9);
				ti4_2 = F809_8448(loc4);
				if ((EIF_BOOLEAN)(ti4_2 == loc3)) break;
				RTHOOK(10);
				F809_8476(loc4);
			}
			RTHOOK(11);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1186,1236,1486,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr1 = RTLNTS(typres0.id, 3, 0);
			}
			tr2 = F809_8449(loc4);
			((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
			RTAR(tr1,tr2);
			((EIF_TYPED_VALUE *)tr1+2)->it_i4 = loc3;
			F938_9035(RTCW(Result), tr1, loc2);
			RTHOOK(12);
			loc2++;
		}
	}
	RTOTE;
	RTHOOK(14);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F537_7784 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(495,F537_7784_body,(Current));
}

/* {CONF_LOAD_PARSE_CALLBACKS}.report_non_client_options */
void F537_7785 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("report_non_client_options", 536, Current, 2, 0, 7923);
	RTGC;
	RTHOOK(1);
	loc1 = RTOUCR(495,F537_7784, (Current));
	RTHOOK(2);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_1_);
	for (;;) {
		RTHOOK(3);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_0_);
		if ((EIF_BOOLEAN) (loc2 > ti4_1)) break;
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
		tr2 = F938_9014(RTCW(loc1), loc2);
		ti4_2 = eif_integer_32_item(RTCW(tr2),2);
		tb1 = F808_8444(RTCW(tr1), ti4_2);
		if (tb1) {
			RTHOOK(5);
			tr1 = RTOUCR(474,F421_6046, (Current));
			tr2 = F938_9014(RTCW(loc1), loc2);
			tr2 = eif_boxed_item(tr2,1);
			tr1 = F1749_19515(RTCW(tr1), tr2);
			F455_6672(Current, tr1);
		}
		RTHOOK(6);
		loc2++;
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_element_under_note */
void F537_7802 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("process_element_under_note", 536, Current, 2, 0, 7940);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
	loc1 = F887_8722(RTCW(tr1));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTHOOK(3);
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc2);
		F908_8862(RTCW(loc1), tr1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.process_note */
void F537_7803 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLIU(7);
	
	RTEAA("process_note", 536, Current, 4, 0, 7941);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
	loc1 = F887_8722(RTCW(tr1));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(loc2);
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			RTHOOK(4);
			F372_5708(loc2, loc1);
		} else {
			RTHOOK(5);
			tr1 = RTOUCR(474,F421_6046, (Current));
			tr2 = *(EIF_REFERENCE *)(loc2 + O11432[Dtype(loc2)-1419]);
			tr1 = F1749_19546(RTCW(tr1), tr2);
			F455_6672(Current, tr1);
		}
	} else {
		RTHOOK(6);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			RTHOOK(7);
			tr1 = *(EIF_REFERENCE *)(loc3);
			if ((EIF_BOOLEAN)(tr1 == NULL)) {
				RTHOOK(8);
				F372_5708(loc3, loc1);
			} else {
				RTHOOK(9);
				tr1 = RTOUCR(474,F421_6046, (Current));
				tr2 = *(EIF_REFERENCE *)(loc3 + _REFACS_4_);
				tr1 = F1749_19546(RTCW(tr1), tr2);
				F455_6672(Current, tr1);
			}
		} else {
			RTHOOK(10);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			loc4 = tr1;
			if (EIF_TEST(loc4)) {
				RTHOOK(11);
				tr1 = *(EIF_REFERENCE *)(loc4);
				if ((EIF_BOOLEAN)(tr1 == NULL)) {
					RTHOOK(12);
					F372_5708(loc4, loc1);
				} else {
					RTHOOK(13);
					tr1 = RTOUCR(474,F421_6046, (Current));
					tr2 = *(EIF_REFERENCE *)(loc4 + _REFACS_3_);
					tr1 = F1749_19546(RTCW(tr1), tr2);
					F455_6672(Current, tr1);
				}
			}
		}
	}
	RTHOOK(14);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.note_level */
EIF_INTEGER_32 F537_7804 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("note_level", 536, Current, 0, 0, 7942);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_3_0_0_);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.tag_from_state_transitions */
EIF_INTEGER_32 F537_7805 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTEAA("tag_from_state_transitions", 536, Current, 3, 2, 7943);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(F537_7804(Current) == ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		tr1 = RTOUCR(497,F537_7813, (Current));
		tr1 = F808_8442(RTCW(tr1), arg1);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			RTHOOK(3);
			ti4_1 = F809_8442(loc3, arg2);
			RTHOOK(4);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ti4_1;
		}
	} else {
		RTHOOK(5);
		loc2 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
		RTHOOK(6);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			RTHOOK(7);
			tr1 = F1237_11119(RTCW(arg2));
			loc1 = F809_8442(RTCW(loc2), tr1);
		} else {
			RTHOOK(8);
			{
				static EIF_TYPE_INDEX typarr0[] = {808,1486,1241,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				loc2 = RTLNSMART(typres0.id);
			}
			F809_8436(RTCW(loc2), ((EIF_INTEGER_32) 2L));
			RTHOOK(9);
			RTAR(Current, loc2);
			*(EIF_REFERENCE *)(Current + _REFACS_25_) = (EIF_REFERENCE) loc2;
		}
		RTHOOK(10);
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
			RTHOOK(11);
			loc1 = F537_7806(Current);
			RTHOOK(12);
			tr1 = F1237_11119(RTCW(arg2));
			F809_8483(RTCW(loc2), loc1, tr1);
		}
		RTHOOK(13);
		RTHOOK(14);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) loc1;
	}
	RTHOOK(15);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) 0;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.new_undefined_tag_number */
EIF_INTEGER_32 F537_7806 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("new_undefined_tag_number", 536, Current, 0, 0, 7944);
	RTGC;
	RTHOOK(1);
	Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_26_3_0_0_);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 1L));
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_26_3_0_0_) = (EIF_INTEGER_32) Result;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.lt_gt_escaped_string */
EIF_REFERENCE F537_7811 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("lt_gt_escaped_string", 536, Current, 0, 1, 7949);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9759[Dtype(arg1)-1239]);
	F1240_11189(RTCW(Result), ti4_1);
	RTHOOK(2);
	F1242_11304(RTCW(Result), arg1);
	RTHOOK(3);
	F537_7812(Current, Result);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.lt_gt_escape_string */
void F537_7812 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("lt_gt_escape_string", 536, Current, 0, 1, 7950);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(498,F190_3496, (Current));
	tr2 = RTOUCR(472,F373_5864, (Current));
	F1242_11281(RTCW(arg1), tr1, tr2);
	RTHOOK(2);
	tr1 = RTOUCR(499,F190_3497, (Current));
	tr2 = RTOUCR(473,F373_5865, (Current));
	F1242_11281(RTCW(arg1), tr1, tr2);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.state_transitions_tag */
static EIF_REFERENCE F537_7813_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDD;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(497)
	dftype = Dftype(Current);

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTEAA("state_transitions_tag", 536, Current, 1, 0, 7951);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNS(typres0.id, 807, _OBJSIZ_6_3_0_8_0_0_0_0_);
	}
	F808_8436(RTCW(tr1), ((EIF_INTEGER_32) 14L));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 2L));
	RTHOOK(3);
	tr1 = RTMS_EX_H("system",6,16556653);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 2L), tr1);
	RTHOOK(4);
	tr1 = RTMS_EX_H("redirection",11,7276654);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 47L), tr1);
	RTHOOK(5);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 1L));
	RTHOOK(6);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 3L));
	RTHOOK(7);
	tr1 = RTMS_EX_H("note",4,1852798053);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 44L), tr1);
	RTHOOK(8);
	tr1 = RTMS_EX_H("description",11,801826414);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 3L), tr1);
	RTHOOK(9);
	tr1 = RTMS_EX_H("target",6,709236);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 4L), tr1);
	RTHOOK(10);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 2L));
	RTHOOK(11);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 25L));
	RTHOOK(12);
	tr1 = RTMS_EX_H("note",4,1852798053);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 44L), tr1);
	RTHOOK(13);
	tr1 = RTMS_EX_H("description",11,801826414);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 3L), tr1);
	RTHOOK(14);
	tr1 = RTMS_EX_H("root",4,1919905652);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 5L), tr1);
	RTHOOK(15);
	tr1 = RTMS_EX_H("version",7,1397649262);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 6L), tr1);
	RTHOOK(16);
	tr1 = RTMS_EX_H("file_rule",9,241263973);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 7L), tr1);
	RTHOOK(17);
	tr1 = RTMS_EX_H("option",6,24682094);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 8L), tr1);
	RTHOOK(18);
	tr1 = RTMS_EX_H("setting",7,2051971943);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 9L), tr1);
	RTHOOK(19);
	tr1 = RTOUCR(454,F373_5840, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 49L), tr1);
	RTHOOK(20);
	tr1 = RTMS_EX_H("mapping",7,1104548967);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 43L), tr1);
	RTHOOK(21);
	tr1 = RTMS_EX_H("external_include",16,1852008037);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 10L), tr1);
	RTHOOK(22);
	tr1 = RTMS_EX_H("external_cflag",14,2146934631);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 11L), tr1);
	RTHOOK(23);
	tr1 = RTMS_EX_H("external_object",15,1998183540);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 12L), tr1);
	RTHOOK(24);
	tr1 = RTMS_EX_H("external_library",16,1303995769);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 13L), tr1);
	RTHOOK(25);
	tr1 = RTMS_EX_H("external_resource",17,1468082021);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 14L), tr1);
	RTHOOK(26);
	tr1 = RTMS_EX_H("external_linker_flag",20,1131822695);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 15L), tr1);
	RTHOOK(27);
	tr1 = RTMS_EX_H("external_make",13,2071652709);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 16L), tr1);
	RTHOOK(28);
	tr1 = RTMS_EX_H("pre_compile_action",18,1040865902);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 17L), tr1);
	RTHOOK(29);
	tr1 = RTMS_EX_H("post_compile_action",19,1864276334);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 18L), tr1);
	RTHOOK(30);
	tr1 = RTMS_EX_H("variable",8,1315629925);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 19L), tr1);
	RTHOOK(31);
	tr1 = RTMS_EX_H("precompile",10,1775433829);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 20L), tr1);
	RTHOOK(32);
	tr1 = RTMS_EX_H("library",7,649884793);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 21L), tr1);
	RTHOOK(33);
	tr1 = RTMS_EX_H("assembly",8,1983830905);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 22L), tr1);
	RTHOOK(34);
	tr1 = RTMS_EX_H("cluster",7,439059314);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 23L), tr1);
	RTHOOK(35);
	tr1 = RTMS_EX_H("tests",5,1702956147);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 45L), tr1);
	RTHOOK(36);
	tr1 = RTMS_EX_H("override",8,1406443621);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 24L), tr1);
	RTHOOK(37);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 4L));
	RTHOOK(38);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 4L));
	RTHOOK(39);
	tr1 = RTMS_EX_H("description",11,801826414);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 3L), tr1);
	RTHOOK(40);
	tr1 = RTMS_EX_H("exclude",7,1351771749);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 25L), tr1);
	RTHOOK(41);
	tr1 = RTMS_EX_H("include",7,1197897061);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 26L), tr1);
	RTHOOK(42);
	tr1 = RTMS_EX_H("condition",9,1103211630);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 30L), tr1);
	RTHOOK(43);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 7L));
	RTHOOK(44);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 4L));
	RTHOOK(45);
	tr1 = RTMS_EX_H("description",11,801826414);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 3L), tr1);
	RTHOOK(46);
	tr1 = RTMS_EX_H("debug",5,1701719399);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 27L), tr1);
	RTHOOK(47);
	tr1 = RTMS_EX_H("assertions",10,1726143859);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 28L), tr1);
	RTHOOK(48);
	tr1 = RTMS_EX_H("warning",7,1809215079);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 29L), tr1);
	RTHOOK(49);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 8L));
	RTHOOK(50);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 39L));
	RTHOOK(51);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 5L));
	RTHOOK(52);
	tr1 = RTOUCR(455,F373_5841, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 50L), tr1);
	RTHOOK(53);
	tr1 = RTOUCR(456,F373_5843, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 52L), tr1);
	RTHOOK(54);
	tr1 = RTOUCR(457,F373_5845, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 54L), tr1);
	RTHOOK(55);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 49L));
	RTHOOK(56);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 2L));
	RTHOOK(57);
	tr1 = RTMS_EX_H("description",11,801826414);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 3L), tr1);
	RTHOOK(58);
	tr1 = RTMS_EX_H("condition",9,1103211630);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 30L), tr1);
	RTHOOK(59);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 17L));
	RTHOOK(60);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 18L));
	RTHOOK(61);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 2L));
	RTHOOK(62);
	tr1 = RTMS_EX_H("description",11,801826414);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 3L), tr1);
	RTHOOK(63);
	tr1 = RTMS_EX_H("condition",9,1103211630);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 30L), tr1);
	RTHOOK(64);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 10L));
	RTHOOK(65);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 11L));
	RTHOOK(66);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 12L));
	RTHOOK(67);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 13L));
	RTHOOK(68);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 14L));
	RTHOOK(69);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 15L));
	RTHOOK(70);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 16L));
	RTHOOK(71);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 5L));
	RTHOOK(72);
	tr1 = RTMS_EX_H("description",11,801826414);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 3L), tr1);
	RTHOOK(73);
	tr1 = RTMS_EX_H("option",6,24682094);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 8L), tr1);
	RTHOOK(74);
	tr1 = RTMS_EX_H("renaming",8,1374354535);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 38L), tr1);
	RTHOOK(75);
	tr1 = RTMS_EX_H("class_option",12,862831982);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 39L), tr1);
	RTHOOK(76);
	tr1 = RTMS_EX_H("condition",9,1103211630);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 30L), tr1);
	RTHOOK(77);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 22L));
	RTHOOK(78);
	tr1 = RTMS_EX_H("visible",7,1237289573);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 41L), tr1);
	RTHOOK(79);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 21L));
	RTHOOK(80);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 20L));
	RTHOOK(81);
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc1);
	loc1 = (EIF_REFERENCE) tr1;
	RTHOOK(82);
	tr1 = RTMS_EX_H("renaming",8,1374354535);
	F809_8488(RTCW(loc1), tr1);
	RTHOOK(83);
	tr1 = RTMS_EX_H("note",4,1852798053);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 44L), tr1);
	RTHOOK(84);
	tr1 = RTMS_EX_H("file_rule",9,241263973);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 7L), tr1);
	RTHOOK(85);
	tr1 = RTMS_EX_H("mapping",7,1104548967);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 43L), tr1);
	RTHOOK(86);
	tr1 = RTMS_EX_H("uses",4,1970496883);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 40L), tr1);
	RTHOOK(87);
	tr1 = RTMS_EX_H("tests",5,1702956147);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 45L), tr1);
	RTHOOK(88);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 45L));
	RTHOOK(89);
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc1);
	loc1 = (EIF_REFERENCE) tr1;
	RTHOOK(90);
	tr1 = RTMS_EX_H("cluster",7,439059314);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 23L), tr1);
	RTHOOK(91);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 23L));
	RTHOOK(92);
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc1);
	loc1 = (EIF_REFERENCE) tr1;
	RTHOOK(93);
	tr1 = RTMS_EX_H("cluster",7,439059314);
	F809_8488(RTCW(loc1), tr1);
	RTHOOK(94);
	tr1 = RTMS_EX_H("override",8,1406443621);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 24L), tr1);
	RTHOOK(95);
	tr1 = RTMS_EX_H("overrides",9,1420439155);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 42L), tr1);
	RTHOOK(96);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 24L));
	RTHOOK(97);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 9L));
	RTHOOK(98);
	tr1 = RTMS_EX_H("platform",8,459690093);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 31L), tr1);
	RTHOOK(99);
	tr1 = RTMS_EX_H("build",5,1970595940);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 32L), tr1);
	RTHOOK(100);
	tr1 = RTMS_EX_H("multithreaded",13,1599663972);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 33L), tr1);
	RTHOOK(101);
	tr1 = RTMS_EX_H("concurrency",11,300205945);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 46L), tr1);
	RTHOOK(102);
	tr1 = RTMS_EX_H("void_safety",11,1966795897);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 48L), tr1);
	RTHOOK(103);
	tr1 = RTMS_EX_H("dotnet",6,3372660);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 34L), tr1);
	RTHOOK(104);
	tr1 = RTMS_EX_H("dynamic_runtime",15,1723645541);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 35L), tr1);
	RTHOOK(105);
	tr1 = RTMS_EX_H("version",7,1397649262);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 36L), tr1);
	RTHOOK(106);
	tr1 = RTMS_EX_H("custom",6,2132551021);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 37L), tr1);
	RTHOOK(107);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 30L));
	RTOTE;
	RTHOOK(109);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F537_7813 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(497,F537_7813_body,(Current));
}

/* {CONF_LOAD_PARSE_CALLBACKS}.tag_attributes */
static EIF_REFERENCE F537_7814_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDD;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(475)
	dftype = Dftype(Current);

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTEAA("tag_attributes", 536, Current, 1, 0, 7952);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNS(typres0.id, 807, _OBJSIZ_6_3_0_8_0_0_0_0_);
	}
	F808_8436(RTCW(tr1), ((EIF_INTEGER_32) 25L));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 2L));
	RTHOOK(3);
	tr1 = RTMS_EX_H("uuid",4,1970628964);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1002L), tr1);
	RTHOOK(4);
	tr1 = RTMS_EX_H("location",8,59511406);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1025L), tr1);
	RTHOOK(5);
	tr1 = RTMS_EX_H("message",7,1162241893);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1066L), tr1);
	RTHOOK(6);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 47L));
	RTHOOK(7);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 4L));
	RTHOOK(8);
	tr1 = RTMS_EX_H("name",4,1851878757);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1001L), tr1);
	RTHOOK(9);
	tr1 = RTMS_EX_H("uuid",4,1970628964);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1002L), tr1);
	RTHOOK(10);
	tr1 = RTMS_EX_H("readonly",8,1382700153);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1029L), tr1);
	RTHOOK(11);
	tr1 = RTMS_EX_H("library_target",14,997913460);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1003L), tr1);
	RTHOOK(12);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 2L));
	RTHOOK(13);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 4L));
	RTHOOK(14);
	tr1 = RTOUCR(463,F373_5851, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1001L), tr1);
	RTHOOK(15);
	tr1 = RTOUCR(461,F373_5849, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1005L), tr1);
	RTHOOK(16);
	tr1 = RTOUCR(462,F373_5850, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1004L), tr1);
	RTHOOK(17);
	tr1 = RTOUCR(460,F373_5848, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1000L), tr1);
	RTHOOK(18);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 4L));
	RTHOOK(19);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 0L));
	RTHOOK(20);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 44L));
	RTHOOK(21);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 4L));
	RTHOOK(22);
	tr1 = RTMS_EX_H("cluster",7,439059314);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1006L), tr1);
	RTHOOK(23);
	tr1 = RTMS_EX_H("class",5,1819086195);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1007L), tr1);
	RTHOOK(24);
	tr1 = RTMS_EX_H("feature",7,1951938661);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1009L), tr1);
	RTHOOK(25);
	tr1 = RTMS_EX_H("all_classes",11,1867072883);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1008L), tr1);
	RTHOOK(26);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 5L));
	RTHOOK(27);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 8L));
	RTHOOK(28);
	tr1 = RTMS_EX_H("major",5,1635202418);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1012L), tr1);
	RTHOOK(29);
	tr1 = RTMS_EX_H("minor",5,1769682290);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1013L), tr1);
	RTHOOK(30);
	tr1 = RTMS_EX_H("release",7,1296412773);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1014L), tr1);
	RTHOOK(31);
	tr1 = RTMS_EX_H("build",5,1970595940);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1015L), tr1);
	RTHOOK(32);
	tr1 = RTMS_EX_H("product",7,299891316);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1016L), tr1);
	RTHOOK(33);
	tr1 = RTMS_EX_H("company",7,393321593);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1017L), tr1);
	RTHOOK(34);
	tr1 = RTMS_EX_H("copyright",9,1966519156);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1018L), tr1);
	RTHOOK(35);
	tr1 = RTMS_EX_H("trademark",9,1887934059);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1019L), tr1);
	RTHOOK(36);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 6L));
	RTHOOK(37);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 17L));
	RTHOOK(38);
	tr1 = RTOUCR(448,F373_5833, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1020L), tr1);
	RTHOOK(39);
	tr1 = RTOUCR(447,F373_5832, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1021L), tr1);
	RTHOOK(40);
	tr1 = RTOUCR(446,F373_5831, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1022L), tr1);
	RTHOOK(41);
	tr1 = RTOUCR(441,F373_5826, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1023L), tr1);
	RTHOOK(42);
	tr1 = RTOUCR(449,F373_5834, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1054L), tr1);
	RTHOOK(43);
	tr1 = RTOUCR(450,F373_5835, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1070L), tr1);
	RTHOOK(44);
	tr1 = RTOUCR(443,F373_5828, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1056L), tr1);
	RTHOOK(45);
	tr1 = RTOUCR(451,F373_5836, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1024L), tr1);
	RTHOOK(46);
	tr1 = RTOUCR(442,F373_5827, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1058L), tr1);
	RTHOOK(47);
	tr1 = RTOUCR(440,F373_5825, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1060L), tr1);
	RTHOOK(48);
	tr1 = RTOUCR(444,F373_5829, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1071L), tr1);
	RTHOOK(49);
	tr1 = RTOUCR(445,F373_5830, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1061L), tr1);
	RTHOOK(50);
	tr1 = RTMS_EX_H("syntax_level",12,1690338668);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1064L), tr1);
	RTHOOK(51);
	tr1 = RTOUCR(452,F373_5837, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1065L), tr1);
	RTHOOK(52);
	tr1 = RTOUCR(439,F373_5822, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1059L), tr1);
	RTHOOK(53);
	tr1 = RTOUCR(453,F373_5838, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1063L), tr1);
	RTHOOK(54);
	tr1 = RTMS_EX_H("is_void_safe",12,1531546981);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1062L), tr1);
	RTHOOK(55);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 8L));
	RTHOOK(56);
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc1);
	loc1 = (EIF_REFERENCE) tr1;
	RTHOOK(57);
	tr1 = RTMS_EX_H("class",5,1819086195);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1007L), tr1);
	RTHOOK(58);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 39L));
	RTHOOK(59);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 2L));
	RTHOOK(60);
	tr1 = RTMS_EX_H("name",4,1851878757);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1001L), tr1);
	RTHOOK(61);
	tr1 = RTMS_EX_H("value",5,1635404133);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1027L), tr1);
	RTHOOK(62);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 9L));
	RTHOOK(63);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 2L));
	RTHOOK(64);
	tr1 = RTOUCR(458,F373_5846, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1067L), tr1);
	RTHOOK(65);
	tr1 = RTOUCR(459,F373_5847, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1068L), tr1);
	RTHOOK(66);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 50L));
	RTHOOK(67);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 51L));
	RTHOOK(68);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 52L));
	RTHOOK(69);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 53L));
	RTHOOK(70);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 54L));
	RTHOOK(71);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 1L));
	RTHOOK(72);
	tr1 = RTMS_EX_H("location",8,59511406);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1025L), tr1);
	RTHOOK(73);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 10L));
	RTHOOK(74);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 12L));
	RTHOOK(75);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 13L));
	RTHOOK(76);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 14L));
	RTHOOK(77);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 16L));
	RTHOOK(78);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 2L));
	RTHOOK(79);
	tr1 = RTMS_EX_H("command",7,342989924);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1026L), tr1);
	RTHOOK(80);
	tr1 = RTMS_EX_H("working_directory",17,159568505);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1051L), tr1);
	RTHOOK(81);
	tr1 = RTMS_EX_H("succeed",7,1797821540);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1050L), tr1);
	RTHOOK(82);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 17L));
	RTHOOK(83);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 18L));
	RTHOOK(84);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 2L));
	RTHOOK(85);
	tr1 = RTMS_EX_H("name",4,1851878757);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1001L), tr1);
	RTHOOK(86);
	tr1 = RTMS_EX_H("value",5,1635404133);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1027L), tr1);
	RTHOOK(87);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 19L));
	RTHOOK(88);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 4L));
	RTHOOK(89);
	tr1 = RTMS_EX_H("name",4,1851878757);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1001L), tr1);
	RTHOOK(90);
	tr1 = RTMS_EX_H("location",8,59511406);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1025L), tr1);
	RTHOOK(91);
	tr1 = RTMS_EX_H("readonly",8,1382700153);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1029L), tr1);
	RTHOOK(92);
	tr1 = RTMS_EX_H("prefix",6,1922286968);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1030L), tr1);
	RTHOOK(93);
	tr1 = RTMS_EX_H("use_application_options",23,923843187);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1057L), tr1);
	RTHOOK(94);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 21L));
	RTHOOK(95);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 5L));
	RTHOOK(96);
	tr1 = RTMS_EX_H("name",4,1851878757);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1001L), tr1);
	RTHOOK(97);
	tr1 = RTMS_EX_H("location",8,59511406);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1025L), tr1);
	RTHOOK(98);
	tr1 = RTMS_EX_H("readonly",8,1382700153);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1029L), tr1);
	RTHOOK(99);
	tr1 = RTMS_EX_H("prefix",6,1922286968);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1030L), tr1);
	RTHOOK(100);
	tr1 = RTMS_EX_H("eifgens_location",16,1182782062);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1053L), tr1);
	RTHOOK(101);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 20L));
	RTHOOK(102);
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc1);
	loc1 = (EIF_REFERENCE) tr1;
	RTHOOK(103);
	tr1 = RTMS_EX_H("assembly_name",13,1179631717);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1032L), tr1);
	RTHOOK(104);
	tr1 = RTMS_EX_H("assembly_version",16,557556334);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1033L), tr1);
	RTHOOK(105);
	tr1 = RTMS_EX_H("assembly_culture",16,1780917861);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1034L), tr1);
	RTHOOK(106);
	tr1 = RTMS_EX_H("assembly_key",12,1052986489);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1035L), tr1);
	RTHOOK(107);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 22L));
	RTHOOK(108);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 6L));
	RTHOOK(109);
	tr1 = RTMS_EX_H("name",4,1851878757);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1001L), tr1);
	RTHOOK(110);
	tr1 = RTMS_EX_H("location",8,59511406);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1025L), tr1);
	RTHOOK(111);
	tr1 = RTMS_EX_H("readonly",8,1382700153);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1029L), tr1);
	RTHOOK(112);
	tr1 = RTMS_EX_H("recursive",9,760839013);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1036L), tr1);
	RTHOOK(113);
	tr1 = RTMS_EX_H("hidden",6,1889579886);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1055L), tr1);
	RTHOOK(114);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 23L));
	RTHOOK(115);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 45L));
	RTHOOK(116);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 24L));
	RTHOOK(117);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 2L));
	RTHOOK(118);
	tr1 = RTMS_EX_H("name",4,1851878757);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1001L), tr1);
	RTHOOK(119);
	tr1 = RTOUCR(486,F276_4771, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1037L), tr1);
	RTHOOK(120);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 27L));
	RTHOOK(121);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 3L));
	RTHOOK(122);
	tr1 = RTOUCR(380,F373_5749, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1001L), tr1);
	RTHOOK(123);
	tr1 = RTOUCR(486,F276_4771, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1037L), tr1);
	RTHOOK(124);
	tr1 = RTOUCR(381,F373_5751, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1027L), tr1);
	RTHOOK(125);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 29L));
	RTHOOK(126);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 6L));
	RTHOOK(127);
	tr1 = RTMS_EX_H("precondition",12,694692206);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1038L), tr1);
	RTHOOK(128);
	tr1 = RTMS_EX_H("postcondition",13,29888366);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1039L), tr1);
	RTHOOK(129);
	tr1 = RTMS_EX_H("check",5,1752235371);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1040L), tr1);
	RTHOOK(130);
	tr1 = RTMS_EX_H("invariant",9,997544820);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1041L), tr1);
	RTHOOK(131);
	tr1 = RTMS_EX_H("loop",4,1819242352);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1042L), tr1);
	RTHOOK(132);
	tr1 = RTMS_EX_H("supplier_precondition",21,1130264430);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1043L), tr1);
	RTHOOK(133);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 28L));
	RTHOOK(134);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 2L));
	RTHOOK(135);
	tr1 = RTMS_EX_H("value",5,1635404133);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1027L), tr1);
	RTHOOK(136);
	tr1 = RTMS_EX_H("excluded_value",14,1976209509);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1028L), tr1);
	RTHOOK(137);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 31L));
	RTHOOK(138);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 32L));
	RTHOOK(139);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 1L));
	RTHOOK(140);
	tr1 = RTMS_EX_H("value",5,1635404133);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1027L), tr1);
	RTHOOK(141);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 34L));
	RTHOOK(142);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 35L));
	RTHOOK(143);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 11L));
	RTHOOK(144);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 15L));
	RTHOOK(145);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 33L));
	RTHOOK(146);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 2L));
	RTHOOK(147);
	tr1 = RTMS_EX_H("value",5,1635404133);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1027L), tr1);
	RTHOOK(148);
	tr1 = RTMS_EX_H("excluded_value",14,1976209509);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1028L), tr1);
	RTHOOK(149);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 46L));
	RTHOOK(150);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 2L));
	RTHOOK(151);
	tr1 = RTMS_EX_H("value",5,1635404133);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1027L), tr1);
	RTHOOK(152);
	tr1 = RTMS_EX_H("excluded_value",14,1976209509);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1028L), tr1);
	RTHOOK(153);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 48L));
	RTHOOK(154);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 3L));
	RTHOOK(155);
	tr1 = RTMS_EX_H("min",3,7170414);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1045L), tr1);
	RTHOOK(156);
	tr1 = RTMS_EX_H("max",3,7168376);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1046L), tr1);
	RTHOOK(157);
	tr1 = RTMS_EX_H("type",4,1954115685);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1052L), tr1);
	RTHOOK(158);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 36L));
	RTHOOK(159);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 4L));
	RTHOOK(160);
	tr1 = RTOUCR(464,F373_5853, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1001L), tr1);
	RTHOOK(161);
	tr1 = RTOUCR(465,F373_5854, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1027L), tr1);
	RTHOOK(162);
	tr1 = RTOUCR(466,F373_5855, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1028L), tr1);
	RTHOOK(163);
	tr1 = RTOUCR(467,F373_5856, (Current));
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1069L), tr1);
	RTHOOK(164);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 37L));
	RTHOOK(165);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 1L));
	RTHOOK(166);
	tr1 = RTMS_EX_H("group",5,1920698224);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1049L), tr1);
	RTHOOK(167);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 40L));
	RTHOOK(168);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 42L));
	RTHOOK(169);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 4L));
	RTHOOK(170);
	tr1 = RTMS_EX_H("class",5,1819086195);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1007L), tr1);
	RTHOOK(171);
	tr1 = RTMS_EX_H("feature",7,1951938661);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1009L), tr1);
	RTHOOK(172);
	tr1 = RTMS_EX_H("class_rename",12,767457637);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1010L), tr1);
	RTHOOK(173);
	tr1 = RTMS_EX_H("feature_rename",14,1945920613);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1011L), tr1);
	RTHOOK(174);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 41L));
	RTHOOK(175);
	{
		static EIF_TYPE_INDEX typarr1[] = {807,816,1486,1486,0xFFFF};
		EIF_TYPE typres1;
		static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
		
		typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
		loc1 = RTLNSMART(eif_final_id(Y7749,Y7749_gen_type,typres1.id,805).id);
	}
	F809_8436(RTCW(loc1), ((EIF_INTEGER_32) 2L));
	RTHOOK(176);
	tr1 = RTMS_EX_H("old_name",8,598495589);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1047L), tr1);
	RTHOOK(177);
	tr1 = RTMS_EX_H("new_name",8,1407364965);
	F809_8483(RTCW(loc1), ((EIF_INTEGER_32) 1048L), tr1);
	RTHOOK(178);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 43L));
	RTHOOK(179);
	F808_8483(RTCW(Result), loc1, ((EIF_INTEGER_32) 38L));
	RTOTE;
	RTHOOK(180);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F537_7814 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(475,F537_7814_body,(Current));
}

/* {CONF_LOAD_PARSE_CALLBACKS}.report_unknown_attribute */
void F537_7816 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("report_unknown_attribute", 536, Current, 0, 1, 7954);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(474,F421_6046, (Current));
	tr1 = F1749_19459(RTCW(tr1), arg1);
	F455_6671(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.fake inline-agent#20986#448#406# of on_start_tag_finish */
EIF_REFERENCE F537_20986 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	
	
	RTEAA("fake inline-agent#20986#448#406# of on_start_tag_finish", 536, Current, 0, 1, 7866);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_13_);
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.fake inline-agent#20987#448#407# of on_start_tag_finish */
EIF_REFERENCE F537_20987 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	
	
	RTEAA("fake inline-agent#20987#448#407# of on_start_tag_finish", 536, Current, 0, 1, 7867);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_14_);
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_LOAD_PARSE_CALLBACKS}.fake inline-agent#20988#448#405# of on_start_tag_finish */
EIF_REFERENCE F537_20988 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	
	
	RTEAA("fake inline-agent#20988#448#405# of on_start_tag_finish", 536, Current, 0, 1, 7868);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_12_);
	RTEE;
	return (EIF_REFERENCE) tr1;
}

void EIF_Minit470 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
