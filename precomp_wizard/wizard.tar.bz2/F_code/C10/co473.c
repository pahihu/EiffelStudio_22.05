/*
 * Code for class CONF_TARGET_OPTION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co473.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_TARGET_OPTION}.make_6_3 */
void F540_7955 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("make_6_3", 539, Current, 0, 0, 8095);
	RTGC;
	RTHOOK(1);
	F539_7850(Current);
	RTHOOK(2);
	tr1 = RTLNSMART(eif_new_type(1293, 0).id);
	tr2 = RTOUCR(353,F540_7984, (Current));
	F1294_12223(RTCW(tr1), tr2, ((EIF_NATURAL_8) 2U));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_15_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	tr1 = RTLNSMART(eif_new_type(1293, 0).id);
	tr2 = RTOUCR(354,F540_7985, (Current));
	F1294_12223(RTCW(tr1), tr2, ((EIF_NATURAL_8) 1U));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	tr1 = RTLNSMART(eif_new_type(1293, 0).id);
	tr2 = RTOUCR(355,F540_7986, (Current));
	F1294_12223(RTCW(tr1), tr2, ((EIF_NATURAL_8) 2U));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) tr1;
	RTHOOK(5);
	tr1 = RTLNSMART(eif_new_type(1294, 0).id);
	F1295_12242(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_10_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
	RTHOOK(6);
	tr1 = RTLNSMART(eif_new_type(1294, 0).id);
	F1295_12242(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_9_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) tr1;
	RTHOOK(7);
	tr1 = RTLNSMART(eif_new_type(1294, 0).id);
	F1295_12242(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_15_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) tr1;
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {CONF_TARGET_OPTION}.make_16_11 */
void F540_7956 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make_16_11", 539, Current, 0, 0, 8096);
	RTGC;
	RTHOOK(1);
	F539_7856(Current);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F1294_12235(RTCW(tr1), ((EIF_NATURAL_8) 3U));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_TARGET_OPTION}.make_19_05 */
void F540_7957 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make_19_05", 539, Current, 0, 0, 8097);
	RTGC;
	RTHOOK(1);
	F539_7858(Current);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1294_12235(RTCW(tr1), ((EIF_NATURAL_8) 3U));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_TARGET_OPTION}.merge */
void F540_7982 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("merge", 539, Current, 0, 1, 8122);
	RTGC;
	RTHOOK(1);
	F539_7953(Current, arg1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_14_);
	F1295_12259(RTCW(tr1), tr2);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_13_);
	F1295_12258(RTCW(tr1), tr2);
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_12_);
	F1295_12258(RTCW(tr1), tr2);
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_16_);
	F1294_12234(RTCW(tr1), tr2);
	RTHOOK(6);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_17_);
	F1294_12234(RTCW(tr1), tr2);
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {CONF_TARGET_OPTION}.copy */
void F540_7983 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("copy", 539, Current, 0, 1, 8123);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		RTHOOK(2);
		F539_7947(Current, arg1);
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) tr1;
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_15_) = (EIF_REFERENCE) tr1;
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) tr1;
		RTHOOK(6);
		tr1 = RTLNSMART(eif_new_type(1294, 0).id);
		F1295_12242(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_9_));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) tr1;
		RTHOOK(7);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
		tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_13_);
		tu1_1 = *(EIF_NATURAL_8 *)(RTCW(tr2)+ _CHROFF_1_0_);
		F1295_12256(RTCW(tr1), tu1_1);
		RTHOOK(8);
		tr1 = RTLNSMART(eif_new_type(1294, 0).id);
		F1295_12242(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_15_));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) tr1;
		RTHOOK(9);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
		tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_14_);
		tu1_1 = *(EIF_NATURAL_8 *)(RTCW(tr2)+ _CHROFF_1_0_);
		F1295_12256(RTCW(tr1), tu1_1);
		RTHOOK(10);
		tr1 = RTLNSMART(eif_new_type(1294, 0).id);
		F1295_12242(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_10_));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
		RTHOOK(11);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
		tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_12_);
		tu1_1 = *(EIF_NATURAL_8 *)(RTCW(tr2)+ _CHROFF_1_0_);
		F1295_12256(RTCW(tr1), tu1_1);
	}
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {CONF_TARGET_OPTION}.concurrency_name */
static EIF_REFERENCE F540_7984_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(353)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("concurrency_name", 539, Current, 0, 0, 8124);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1407,1241,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 3L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F1237_11118(RTCV(RTOUCR(356,F373_5732, (Current))));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1237_11118(RTCV(RTOUCR(357,F373_5731, (Current))));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1237_11118(RTCV(RTOUCR(358,F373_5733, (Current))));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1408_13455)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F540_7984 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(353,F540_7984_body,(Current));
}

/* {CONF_TARGET_OPTION}.array_override_name */
static EIF_REFERENCE F540_7985_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(354)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("array_override_name", 539, Current, 0, 0, 8125);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1407,1241,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 4L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = RTOUCR(359,F373_5811, (Current));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOUCR(360,F373_5812, (Current));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOUCR(361,F373_5813, (Current));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOUCR(362,F373_5814, (Current));
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1408_13455)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F540_7985 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(354,F540_7985_body,(Current));
}

/* {CONF_TARGET_OPTION}.dead_code_name */
static EIF_REFERENCE F540_7986_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(355)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("dead_code_name", 539, Current, 0, 0, 8126);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1407,1241,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 3L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = RTOUCR(363,F373_5744, (Current));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOUCR(364,F373_5745, (Current));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOUCR(365,F373_5746, (Current));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1408_13455)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F540_7986 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(355,F540_7986_body,(Current));
}

void EIF_Minit473 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
