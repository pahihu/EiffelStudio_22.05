
#ifndef _C10_kl461_
#define _C10_kl461_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F528_7608_body(EIF_REFERENCE);
extern EIF_REFERENCE F528_7608(EIF_REFERENCE);
extern void EIF_Minit461(void);

#ifdef __cplusplus
}
#endif

#endif
