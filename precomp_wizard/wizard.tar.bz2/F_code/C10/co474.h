
#ifndef _C10_co474_
#define _C10_co474_

#ifdef __cplusplus
extern "C" {
#endif

extern void F541_7991(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit474(void);
extern void F806_8483(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1187_10755(EIF_REFERENCE);
extern EIF_REFERENCE F806_8442(EIF_REFERENCE, EIF_REFERENCE);
extern void F806_8437(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R9662[])();
extern char *(*R9663[])();

#ifdef __cplusplus
}
#endif

#endif
