
#ifndef _C10_ac481_
#define _C10_ac481_

#ifdef __cplusplus
extern "C" {
#endif

extern void F834_8607(EIF_REFERENCE, EIF_INTEGER_32);
extern void F834_8608(EIF_REFERENCE, EIF_INTEGER_32);
extern void F834_8609(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F834_8611(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F834_8612(EIF_REFERENCE);
extern void F834_8613(EIF_REFERENCE);
extern void EIF_Minit481(void);
extern void F833_8595(EIF_REFERENCE, EIF_REFERENCE);
extern void F916_8909(EIF_REFERENCE);
extern void F833_8586(EIF_REFERENCE, EIF_INTEGER_32);
extern void F833_8587(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern char *(*R7959[])();

#ifdef __cplusplus
}
#endif

#endif
