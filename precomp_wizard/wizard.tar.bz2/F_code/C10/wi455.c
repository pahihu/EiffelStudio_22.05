/*
 * Code for class WIZARD_FINAL_STATE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "wi455.h"
#include "eif_helpers.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WIZARD_FINAL_STATE}.build_finish */
void F522_7543 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("build_finish", 521, Current, 1, 0, 7677);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F1341_12751(RTCW(tr1));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	ti4_1 = RTOUCB(EIF_INTEGER_32,237,F213_3817, (Current));
	F1352_12899(RTCW(tr1), ti4_1);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	ti4_1 = RTOUCB(EIF_INTEGER_32,235,F213_3814, (Current));
	F1352_12901(RTCW(tr1), ti4_1);
	RTHOOK(4);
	tr1 = RTLNSMART(eif_new_type(1378, 0).id);
	F1248_11522(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	ti4_1 = F213_3821(Current, ((EIF_INTEGER_32) 20L));
	F1347_12817(RTCW(tr1), ti4_1);
	RTHOOK(6);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	ti4_1 = F213_3821(Current, ((EIF_INTEGER_32) 100L));
	F1347_12816(RTCW(tr1), ti4_1);
	RTHOOK(7);
	tr1 = RTLNSMART(eif_new_type(1373, 0).id);
	F1248_11522(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	RTHOOK(8);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1277_11901(RTCW(tr1));
	RTHOOK(9);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = RTOUCR(119,F214_3840, (Current));
	F1265_11811(RTCW(tr1), tr2);
	RTHOOK(10);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = RTOUCR(119,F214_3840, (Current));
	F1265_11810(RTCW(tr1), tr2);
	RTHOOK(11);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	tr2 = RTOUCR(119,F214_3840, (Current));
	F1265_11811(RTCW(tr1), tr2);
	RTHOOK(12);
	tr1 = RTLNSMART(eif_new_type(1378, 0).id);
	F1248_11522(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	RTHOOK(13);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	ti4_1 = F213_3821(Current, ((EIF_INTEGER_32) 20L));
	F1347_12817(RTCW(tr1), ti4_1);
	RTHOOK(14);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	ti4_1 = F213_3821(Current, ((EIF_INTEGER_32) 100L));
	F1347_12816(RTCW(tr1), ti4_1);
	RTHOOK(15);
	tr1 = RTLNSMART(eif_new_type(1373, 0).id);
	F1248_11522(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	RTHOOK(16);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	F1277_11901(RTCW(tr1));
	RTHOOK(17);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	tr2 = RTOUCR(119,F214_3840, (Current));
	F1265_11811(RTCW(tr1), tr2);
	RTHOOK(18);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	tr2 = RTOUCR(119,F214_3840, (Current));
	F1265_11810(RTCW(tr1), tr2);
	RTHOOK(19);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr2 = RTOUCR(119,F214_3840, (Current));
	F1265_11811(RTCW(tr1), tr2);
	RTHOOK(20);
	loc1 = RTLNS(eif_new_type(1354, 0x00).id, 1354, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1248_11522(RTCW(loc1));
	RTHOOK(21);
	tr1 = RTOUCR(119,F214_3840, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R10113[Dtype(RTCW(loc1))-1280])(loc1, tr1);
	RTHOOK(22);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F1341_12738(RTCW(tr1), loc1);
	RTHOOK(23);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F1341_12738(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_9_));
	RTHOOK(24);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F1352_12903(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_9_));
	RTHOOK(25);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F1341_12738(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_8_));
	RTHOOK(26);
	loc1 = RTLNS(eif_new_type(1354, 0x00).id, 1354, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1248_11522(RTCW(loc1));
	RTHOOK(27);
	tr1 = RTOUCR(119,F214_3840, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R10113[Dtype(RTCW(loc1))-1280])(loc1, tr1);
	RTHOOK(28);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F1341_12738(RTCW(tr1), loc1);
	RTHOOK(29);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F1341_12738(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_7_));
	RTHOOK(30);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F1352_12903(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_7_));
	RTHOOK(31);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F1341_12738(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_6_));
	RTHOOK(32);
	loc1 = RTLNS(eif_new_type(1354, 0x00).id, 1354, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1248_11522(RTCW(loc1));
	RTHOOK(33);
	tr1 = RTOUCR(119,F214_3840, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R10113[Dtype(RTCW(loc1))-1280])(loc1, tr1);
	RTHOOK(34);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F1341_12738(RTCW(tr1), loc1);
	RTHOOK(35);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr2 = RTOUCR(119,F214_3840, (Current));
	F1265_11811(RTCW(tr1), tr2);
	RTHOOK(36);
	RTLE;
	RTEE;
}

/* {WIZARD_FINAL_STATE}.proceed_with_current_info */
void F522_7544 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("proceed_with_current_info", 521, Current, 0, 0, 7678);
	RTGC;
	RTHOOK(1);
	F522_7543(Current);
	RTHOOK(2);
	F1362_13030(RTCV(F214_3823(Current)));
	RTHOOK(3);
	F1362_13031(RTCV(F214_3823(Current)));
	RTHOOK(4);
	tb1 = F1248_11526(RTCV(F214_3823(Current)));
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(5);
		F1359_12982(RTCV(F214_3823(Current)));
	}
	RTHOOK(6);
	F522_7547(Current);
	RTHOOK(7);
	tr1 = RTLNS(eif_new_type(1366, 0x00).id, 1366, _OBJSIZ_14_3_0_3_0_0_0_0_);
	tr2 = F522_7546(Current);
	F1365_13063(RTCW(tr1), tr2);
	tr2 = F214_3823(Current);
	F1363_13052(RTCW(tr1), tr2);
	RTHOOK(8);
	F220_3942(Current);
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {WIZARD_FINAL_STATE}.display_state_text */
void F522_7545 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("display_state_text", 521, Current, 0, 0, 7679);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr2 = F215_3879(RTCV(RTOUCR(1,F499_7172, (Current))));
	F1276_11891(RTCW(tr1), tr2);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = F215_3887(RTCV(RTOUCR(1,F499_7172, (Current))));
	F1276_11891(RTCW(tr1), tr2);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {WIZARD_FINAL_STATE}.final_message */
EIF_REFERENCE F522_7546 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("final_message", 521, Current, 0, 0, 7680);
	RTGC;
	RTHOOK(1);
	Result = F215_3888(RTCV(RTOUCR(1,F499_7172, (Current))));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {WIZARD_FINAL_STATE}.launch_precompilations */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F522_7547 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_REFERENCE  EIF_VOLATILE tr2 = NULL;
	EIF_REAL_32  EIF_VOLATILE tr4_1;
	EIF_INTEGER_32  EIF_VOLATILE ti4_1;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_BOOLEAN  EIF_VOLATILE tb2;
	RTCFDT;
	RTLD;
	RTXD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,loc6);
	RTLR(6,loc3);
	RTLR(7,loc5);
	RTLR(8,saved_except);
	RTLIU(9);
	RTXSLS;
	
	RTEAA("launch_precompilations", 521, Current, 6, 0, 7681);
	RTGC;
	RTE_T
	RTHOOK(1);
	if ((EIF_BOOLEAN) !loc4) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 0L));
		F1377_13211(RTCW(tr1), tr4_1);
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 0L));
		F1377_13211(RTCW(tr1), tr4_1);
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tr2 = F215_3867(RTCV(RTOUCR(1,F499_7172, (Current))));
		F1276_11891(RTCW(tr1), tr2);
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		tr2 = F215_3868(RTCV(RTOUCR(1,F499_7172, (Current))));
		F1276_11891(RTCW(tr1), tr2);
		RTHOOK(6);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R7637[Dtype(RTCW(tr1))-882])(tr1);
		RTHOOK(7);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7706[Dtype(RTCW(tr1))-780])(tr1);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_3_0_3_) = (EIF_INTEGER_32) ti4_1;
		RTHOOK(8);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_3_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		for (;;) {
			RTHOOK(9);
			tr1 = *(EIF_REFERENCE *)(Current);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7648[Dtype(RTCW(tr1))-882])(tr1);
			if (tb1) break;
			RTHOOK(10);
			tr1 = *(EIF_REFERENCE *)(Current);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7670[Dtype(RTCW(tr1))-780])(tr1);
			RTHOOK(11);
			loc2 = F892_8786(RTCW(loc1), ((EIF_INTEGER_32) 1L));
			RTHOOK(12);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_3_);
			loc6 = RTCCL(tr1);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1186,1236,1195,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				loc6 = RTRV(typres0,loc6);
			}
			if (EIF_TEST(loc6)) {
				RTHOOK(13);
				loc3 = eif_boxed_item(loc6,1);
				RTHOOK(14);
				tr1 = F1237_11118(RTCW(loc2));
				tr2 = F1237_11118(RTCW(loc3));
				tb2 = eif_boolean_item(loc6,2);
				F522_7548(Current, tr1, tr2, tb2);
			}
			RTHOOK(15);
			tr1 = *(EIF_REFERENCE *)(Current);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R7650[Dtype(RTCW(tr1))-882])(tr1);
		}
	}
	RTE_E
	RTXSC;
	RTHOOK(16);
	loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(17);
	tr1 = RTLNS(eif_new_type(1365, 0x00).id, 1365, _OBJSIZ_14_3_0_3_0_0_0_0_);
	tr2 = F215_3889(RTCV(RTOUCR(1,F499_7172, (Current))));
	F1365_13063(RTCW(tr1), tr2);
	loc5 = (EIF_REFERENCE) tr1;
	RTHOOK(18);
	tr1 = F214_3823(Current);
	F1363_13052(RTCW(loc5), tr1);
	RTHOOK(19);
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTHOOK(20);
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {WIZARD_FINAL_STATE}.precompile */
void F522_7548 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(11);
	RTLR(0,loc6);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,loc5);
	RTLR(4,Current);
	RTLR(5,tr2);
	RTLR(6,arg1);
	RTLR(7,loc3);
	RTLR(8,loc7);
	RTLR(9,loc8);
	RTLR(10,tr3);
	RTLIU(11);
	
	RTEAA("precompile", 521, Current, 8, 3, 7682);
	RTGC;
	RTHOOK(1);
	loc6 = RTLNS(eif_new_type(1303, 0x00).id, 1303, _OBJSIZ_2_1_0_0_0_0_0_0_);
	F1304_12619(RTCW(loc6), arg2);
	RTHOOK(2);
	tr1 = F1304_12634(RTCW(loc6));
	loc6 = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	tr1 = RTMS_EX_H("EIFGENs",7,1708946035);
	tr1 = F1304_12646(RTCW(loc6), tr1);
	tr2 = RTOUCR(305,F522_7553, (Current));
	loc5 = F1304_12646(RTCW(tr1), tr2);
	RTHOOK(4);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_3_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(5);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(6);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr2 = RTOUCR(1,F499_7172, (Current));
	tr2 = F215_3870(RTCW(tr2), arg1);
	F1276_11891(RTCW(tr1), tr2);
	RTHOOK(7);
	loc3 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1240_11189(RTCW(loc3), ((EIF_INTEGER_32) 50L));
	RTHOOK(8);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
	F1242_11317(RTCW(loc3), tw1);
	RTHOOK(9);
	tr1 = RTOUCR(99,F1793_20628, (RTCV(F498_7170(Current))));
	tr1 = F1304_12658(RTCW(tr1));
	F1242_11304(RTCW(loc3), tr1);
	RTHOOK(10);
	tr1 = F1237_11118(RTMS_EX_H("\" ",2,8736));
	F1242_11304(RTCW(loc3), tr1);
	RTHOOK(11);
	tr1 = F1237_11118(RTMS_EX_H(" -precompile -config \"",22,1676868386));
	F1242_11304(RTCW(loc3), tr1);
	RTHOOK(12);
	F1242_11304(RTCW(loc3), arg2);
	RTHOOK(13);
	tr1 = F1237_11118(RTMS_EX_H("\" -project_path \"",17,1982073378));
	F1242_11304(RTCW(loc3), tr1);
	RTHOOK(14);
	tr1 = F1304_12658(RTCW(loc6));
	F1242_11304(RTCW(loc3), tr1);
	RTHOOK(15);
	tr1 = F1237_11118(RTMS_EX_H("\" -output_file \"",16,1746999842));
	F1242_11304(RTCW(loc3), tr1);
	RTHOOK(16);
	tr1 = F1304_12658(RTCW(loc5));
	F1242_11304(RTCW(loc3), tr1);
	RTHOOK(17);
	tr1 = F1237_11118(RTMS_EX_H("\" -c_compile -clean",19,475768430));
	F1242_11304(RTCW(loc3), tr1);
	RTHOOK(18);
	loc7 = RTLNS(eif_new_type(187, 0x00).id, 187, _OBJSIZ_0_0_0_0_0_0_0_0_);
	RTHOOK(19);
	loc8 = F188_3471(RTCW(loc7), loc3, NULL);
	RTHOOK(20);
	F511_7331(RTCW(loc8), (EIF_BOOLEAN) 1);
	RTHOOK(21);
	F527_7585(RTCW(loc8));
	for (;;) {
		RTHOOK(22);
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc8)+ _CHROFF_21_7_);
		if (tb1) break;
		RTHOOK(23);
		loc2 = F522_7549(Current, loc5);
		RTHOOK(24);
		if ((EIF_BOOLEAN)(loc2 != ((EIF_INTEGER_32) -1L))) {
			RTHOOK(25);
			if ((EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 100L))) {
				RTHOOK(26);
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 100L);
			} else {
				RTHOOK(27);
				ti4_1 = eif_max_int32 (loc1,loc2);
				loc1 = (EIF_INTEGER_32) ti4_1;
			}
		}
		RTHOOK(28);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		tr4_1 = (EIF_REAL_32) ((EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) (loc1) /  (EIF_REAL_64) (((EIF_INTEGER_32) 100L))) * (EIF_REAL_64) 0.9));
		F1377_13211(RTCW(tr1), tr4_1);
		RTHOOK(29);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		tr2 = RTOUCR(1,F499_7172, (Current));
		tr2 = F215_3870(RTCW(tr2), arg1);
		tr3 = eif_out__i4_s1((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 * ((EIF_INTEGER_32) 90L)) / ((EIF_INTEGER_32) 100L)));
		tr3 = F1237_11118(RTCW(tr3));
		tr2 = F1242_11323(RTCW(tr2), tr3);
		tr3 = F1237_11118(RTMS_EX_H("%",1,37));
		tr2 = F1242_11323(RTCW(tr2), tr3);
		F1276_11891(RTCW(tr1), tr2);
		RTHOOK(30);
		tr8_1 = (EIF_REAL_64) (loc1);
		tr8_2 = (EIF_REAL_64) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 100L) * *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_3_0_4_)));
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_3_0_3_);
		tr8_3 = (EIF_REAL_64) (ti4_1);
		tr1 = RTLNS(eif_new_type(1510, 0x00).id, 1510, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)tr1 = (EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) (tr8_1 * (EIF_REAL_64) 0.9) + tr8_2)) /  (EIF_REAL_64) (tr8_3));
		loc4 = F1509_14703(RTCW(tr1));
		RTHOOK(31);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr8_1 = (EIF_REAL_64) (loc1);
		tr8_2 = (EIF_REAL_64) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 100L) * *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_3_0_4_)));
		tr8_3 = (EIF_REAL_64) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 100L) * *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_3_0_3_)));
		tr4_1 = (EIF_REAL_32) ((EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) (tr8_1 * (EIF_REAL_64) 0.9) + tr8_2)) /  (EIF_REAL_64) (tr8_3)));
		F1377_13211(RTCW(tr1), tr4_1);
		RTHOOK(32);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tr2 = RTOUCR(1,F499_7172, (Current));
		tr3 = eif_out__i4_s1(loc4);
		tr2 = F215_3871(RTCW(tr2), tr3);
		F1276_11891(RTCW(tr1), tr2);
	}
	RTHOOK(33);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_3_0_4_))++;
	RTHOOK(34);
	RTLE;
	RTEE;
}

/* {WIZARD_FINAL_STATE}.find_time */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
EIF_INTEGER_32 F522_7549 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc3 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_INTEGER_32  EIF_VOLATILE ti4_1;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_BOOLEAN  EIF_VOLATILE tb2;
	EIF_VOLATILE EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	RTXD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLR(4,loc2);
	RTLR(5,saved_except);
	RTLIU(6);
	RTXSLS;
	
	RTEAA("find_time", 521, Current, 5, 1, 7683);
	RTGC;
	RTE_T
	RTHOOK(1);
	if ((EIF_BOOLEAN) !loc3) {
		RTHOOK(2);
		tr1 = F214_3834(Current);
		F1262_11774(RTCW(tr1), ((EIF_INTEGER_32) 100L));
		RTHOOK(3);
		F1262_11770(RTCV(F214_3834(Current)));
		RTHOOK(4);
		tr1 = RTLNS(eif_new_type(1147, 0x00).id, 1147, _OBJSIZ_5_7_2_4_1_1_2_1_);
		F1148_10324(RTCW(tr1), arg1);
		loc1 = (EIF_REFERENCE) tr1;
		RTHOOK(5);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8700[Dtype(RTCW(loc1))-1146])(loc1);
		if (tb1) {
			RTHOOK(6);
			F1146_10112(RTCW(loc1));
			RTHOOK(7);
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7706[Dtype(RTCW(loc1))-780])(loc1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R8756[Dtype(RTCW(loc1))-1146])(loc1, ti4_1);
			RTHOOK(8);
			loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
			RTHOOK(9);
			F1146_10129(RTCW(loc1));
			RTHOOK(10);
			tb1 = '\01';
			tr1 = RTMS_EX_H("finished",8,1338032740);
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(loc2))-7])(loc2, tr1);
			if (!tb2) {
				tr1 = RTMS_EX_H("finished\012",9,1087091978);
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(loc2))-7])(loc2, tr1);
				tb1 = tb2;
			}
			if (tb1) {
				RTHOOK(11);
				Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 100L);
				RTHOOK(12);
				F1146_10175(RTCW(loc1));
			} else {
				RTHOOK(13);
				loc4 = F522_7550(Current, loc2);
				RTHOOK(14);
				loc5 = F522_7551(Current, loc2);
				RTHOOK(15);
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc4 != ((EIF_INTEGER_32) -1L)) && (EIF_BOOLEAN)(loc5 != ((EIF_INTEGER_32) -1L)))) {
					RTHOOK(16);
					Result = eif_min_int32 ((EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 6L) - loc4) * ((EIF_INTEGER_32) 100L)) + loc5) / ((EIF_INTEGER_32) 7L)),((EIF_INTEGER_32) 99L));
				} else {
					RTHOOK(17);
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				}
			}
		} else {
			RTHOOK(18);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		}
	} else {
		RTHOOK(19);
		Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	}
	RTE_E
	RTXSC;
	RTHOOK(20);
	loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(21);
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTHOOK(22);
	RTEOK;
	RTLE;
	return Result;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {WIZARD_FINAL_STATE}.degree_from_output */
EIF_INTEGER_32 F522_7550 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,loc2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("degree_from_output", 521, Current, 2, 1, 7684);
	RTGC;
	RTHOOK(1);
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R9817[Dtype(RTCW(arg1))-1243])(arg1, (EIF_CHARACTER_8) '\011', ((EIF_INTEGER_32) 1L));
	RTHOOK(2);
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 1L))) {
		RTHOOK(3);
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R9681[Dtype(RTCW(arg1))-1240])(arg1, ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
		RTHOOK(4);
		tb1 = F1237_11090(RTCW(loc2));
		if (tb1) {
			RTHOOK(5);
			Result = F1237_11124(RTCW(loc2));
		}
	}
	RTHOOK(6);
	if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) -1L))) {
		RTHOOK(7);
		Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		RTHOOK(8);
		if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) -2L))) {
			RTHOOK(9);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		}
	}
	RTHOOK(10);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (Result > ((EIF_INTEGER_32) 6L)) || (EIF_BOOLEAN) (Result < ((EIF_INTEGER_32) 0L)))) {
		RTHOOK(11);
		RTHOOK(12);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	}
	RTHOOK(14);
	RTLE;
	RTEE;
	return Result;
}

/* {WIZARD_FINAL_STATE}.percentage_from_output */
EIF_INTEGER_32 F522_7551 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,loc2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("percentage_from_output", 521, Current, 2, 1, 7685);
	RTGC;
	RTHOOK(1);
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTHOOK(2);
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R9817[Dtype(RTCW(arg1))-1243])(arg1, (EIF_CHARACTER_8) '\011', ((EIF_INTEGER_32) 1L));
	RTHOOK(3);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R9681[Dtype(RTCW(arg1))-1240])(arg1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 2L)));
	RTHOOK(4);
	tb1 = F1237_11090(RTCW(loc2));
	if (tb1) {
		RTHOOK(5);
		Result = F1237_11124(RTCW(loc2));
		RTHOOK(6);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (Result > ((EIF_INTEGER_32) 100L)) || (EIF_BOOLEAN) (Result < ((EIF_INTEGER_32) 0L)))) {
			RTHOOK(7);
			RTHOOK(8);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		}
	}
	RTHOOK(10);
	RTLE;
	RTEE;
	return Result;
}

/* {WIZARD_FINAL_STATE}.pixmap_icon_location */
static EIF_REFERENCE F522_7552_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(306)

	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("pixmap_icon_location", 521, Current, 0, 0, 7686);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1303, 0x00).id, 1303, _OBJSIZ_2_1_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("eiffel_wizard_icon",18,1807830126);
	tr3 = RTOUCR(104,F214_3830, (Current));
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(tr2)-1243])(tr2, tr3);
	F1304_12619(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F522_7552 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(306,F522_7552_body,(Current));
}

/* {WIZARD_FINAL_STATE}.progress_filename */

EIF_REFERENCE F522_7553 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (305,RTMS_EX_H("progress.eif",12,222680934));
}

void EIF_Minit455 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
