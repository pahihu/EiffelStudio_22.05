/*
 * Code for class C_STRING
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "c_465.h"
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {C_STRING}.make */
void F532_7657 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("make", 531, Current, 0, 1, 7814);
	RTGC;
	RTHOOK(1);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9640[Dtype(RTCW(arg1))-1240])(arg1);
	F532_7658(Current, ti4_1);
	RTHOOK(2);
	F532_7685(Current, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {C_STRING}.make_empty */
void F532_7658 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make_empty", 531, Current, 0, 1, 7815);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_new_type(1140, 0).id);
	F1141_9694(RTCW(tr1), (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {C_STRING}.make_shared_from_pointer */
void F532_7661 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make_shared_from_pointer", 531, Current, 0, 1, 7818);
	RTGC;
	RTHOOK(1);
	ti4_1 = (EIF_INTEGER_32) strlen((char*) arg1);
	F532_7662(Current, arg1, ti4_1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {C_STRING}.make_shared_from_pointer_and_count */
void F532_7662 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make_shared_from_pointer_and_count", 531, Current, 0, 2, 7819);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_) = (EIF_INTEGER_32) arg2;
	RTHOOK(2);
	tr1 = RTLNSMART(eif_new_type(1140, 0).id);
	F1141_9697(RTCW(tr1), arg1, (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L)));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {C_STRING}.set_shared_from_pointer */
void F532_7665 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_shared_from_pointer", 531, Current, 0, 1, 7822);
	RTGC;
	RTHOOK(1);
	ti4_1 = (EIF_INTEGER_32) strlen((char*) arg1);
	F532_7666(Current, arg1, ti4_1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {C_STRING}.set_shared_from_pointer_and_count */
void F532_7666 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("set_shared_from_pointer_and_count", 531, Current, 0, 2, 7823);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_) = (EIF_INTEGER_32) arg2;
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_0_0_);
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(3);
		tr1 = RTLNSMART(eif_new_type(1140, 0).id);
		F1141_9697(RTCW(tr1), arg1, (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L)));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current);
		F1141_9699(RTCW(tr1), arg1, (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L)));
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {C_STRING}.substring */
EIF_REFERENCE F532_7669 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("substring", 531, Current, 1, 2, 7791);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg2 - arg1) + ((EIF_INTEGER_32) 1L));
	RTHOOK(2);
	Result = RTLNS(eif_new_type(1244, 0x00).id, 1244, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1243_11356(RTCW(Result), loc1);
	RTHOOK(3);
	F1245_11518(RTCW(Result), loc1);
	RTHOOK(4);
	F532_7674(Current, Result, arg1, arg2);
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {C_STRING}.substring_8 */
EIF_REFERENCE F532_7670 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("substring_8", 531, Current, 1, 2, 7792);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg2 - arg1) + ((EIF_INTEGER_32) 1L));
	RTHOOK(2);
	Result = RTLNS(eif_new_type(1244, 0x00).id, 1244, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1243_11356(RTCW(Result), loc1);
	RTHOOK(3);
	F1245_11518(RTCW(Result), loc1);
	RTHOOK(4);
	F532_7674(Current, Result, arg1, arg2);
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {C_STRING}.string */
EIF_REFERENCE F532_7671 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("string", 531, Current, 0, 0, 7793);
	RTGC;
	RTHOOK(1);
	tp1 = F532_7679(Current);
	ti4_1 = (EIF_INTEGER_32) strlen((char*) tp1);
	Result = F532_7669(Current, ((EIF_INTEGER_32) 1L), ti4_1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {C_STRING}.string_8 */
EIF_REFERENCE F532_7672 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("string_8", 531, Current, 0, 0, 7794);
	RTGC;
	RTHOOK(1);
	tp1 = F532_7679(Current);
	ti4_1 = (EIF_INTEGER_32) strlen((char*) tp1);
	Result = F532_7670(Current, ((EIF_INTEGER_32) 1L), ti4_1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {C_STRING}.copy_to_string */
void F532_7673 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("copy_to_string", 531, Current, 4, 4, 7795);
	RTGC;
	RTHOOK(1);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L));
	RTHOOK(2);
	loc3 = (EIF_INTEGER_32) arg3;
	RTHOOK(3);
	loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + (EIF_INTEGER_32) (arg4 - ((EIF_INTEGER_32) 1L)));
	RTHOOK(4);
	loc1 = *(EIF_REFERENCE *)(Current);
	for (;;) {
		RTHOOK(5);
		if ((EIF_BOOLEAN)(loc2 == loc4)) break;
		RTHOOK(6);
		tu1_1 = F1141_9705(RTCW(loc1), loc2);
		tu4_1 = (EIF_NATURAL_32) tu1_1;
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32, EIF_INTEGER_32)) R9699[Dtype(RTCW(arg1))-1241])(arg1, tu4_1, loc3);
		RTHOOK(7);
		loc2++;
		RTHOOK(8);
		loc3++;
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {C_STRING}.read_substring_into */
void F532_7674 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("read_substring_into", 531, Current, 4, 3, 7796);
	RTGC;
	RTHOOK(1);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L));
	RTHOOK(2);
	loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg3 - arg2);
	RTHOOK(3);
	loc1 = *(EIF_REFERENCE *)(Current);
	RTHOOK(4);
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(5);
		if ((EIF_BOOLEAN) (loc2 > loc4)) break;
		RTHOOK(6);
		tu1_1 = F1141_9705(RTCW(loc1), loc2);
		tu4_1 = (EIF_NATURAL_32) tu1_1;
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32, EIF_INTEGER_32)) R9699[Dtype(RTCW(arg1))-1241])(arg1, tu4_1, loc3);
		RTHOOK(7);
		loc2++;
		RTHOOK(8);
		loc3++;
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {C_STRING}.read_string_into */
void F532_7675 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("read_string_into", 531, Current, 0, 1, 7797);
	RTHOOK(1);
	F532_7674(Current, arg1, ((EIF_INTEGER_32) 1L), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_));
	RTHOOK(2);
	RTEE;
}

/* {C_STRING}.read_substring_into_character_8_area */
void F532_7676 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("read_substring_into_character_8_area", 531, Current, 0, 3, 7798);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	F1141_9724(RTCW(tr1), arg1, (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)), ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg3 - arg2) + ((EIF_INTEGER_32) 1L)));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {C_STRING}.read_substring_into_character_32_area */
void F532_7677 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 tw1;
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("read_substring_into_character_32_area", 531, Current, 4, 3, 7799);
	RTGC;
	RTHOOK(1);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L));
	RTHOOK(2);
	loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg3 - arg2);
	RTHOOK(3);
	loc1 = *(EIF_REFERENCE *)(Current);
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) (loc2 > loc4)) break;
		RTHOOK(5);
		tu1_1 = F1141_9705(RTCW(loc1), loc2);
		tw1 = (EIF_CHARACTER_32) tu1_1;
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_CHARACTER_32 *)RTCW(arg1) + (loc3)) = tw1;
		/* END INLINED CODE */
		;
		RTHOOK(6);
		loc2++;
		RTHOOK(7);
		loc3++;
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {C_STRING}.read_unicode_substring_into_character_32_area */
void F532_7678 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc5 = (EIF_NATURAL_32) 0;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("read_unicode_substring_into_character_32_area", 531, Current, 5, 3, 7800);
	RTGC;
	RTHOOK(1);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L));
	RTHOOK(2);
	loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg3 - arg2);
	RTHOOK(3);
	loc1 = *(EIF_REFERENCE *)(Current);
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) (loc2 > loc4)) break;
		RTHOOK(5);
		loc5 = F1141_9707(RTCW(loc1), loc2);
		RTHOOK(6);
		tw1 = (EIF_CHARACTER_32) loc5;
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_CHARACTER_32 *)RTCW(arg1) + (loc3)) = tw1;
		/* END INLINED CODE */
		;
		RTHOOK(7);
		loc2 += ((EIF_INTEGER_32) 4L);
		RTHOOK(8);
		loc3++;
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {C_STRING}.item */
EIF_POINTER F532_7679 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("item", 531, Current, 0, 0, 7801);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = *(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_0_1_0_1_0_0_);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {C_STRING}.capacity */
EIF_INTEGER_32 F532_7681 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("capacity", 531, Current, 0, 0, 7803);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_0_1_0_0_);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {C_STRING}.set_string */
void F532_7685 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("set_string", 531, Current, 0, 1, 7807);
	RTGC;
	RTHOOK(1);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9640[Dtype(RTCW(arg1))-1240])(arg1);
	F532_7686(Current, arg1, ((EIF_INTEGER_32) 1L), ti4_1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {C_STRING}.set_substring */
void F532_7686 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("set_substring", 531, Current, 3, 3, 7808);
	RTGC;
	RTHOOK(1);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg3 - arg2) + ((EIF_INTEGER_32) 1L));
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_) = (EIF_INTEGER_32) loc2;
	RTHOOK(3);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_0_1_0_0_);
	if ((EIF_BOOLEAN) (ti4_1 < loc3)) {
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current);
		F1141_9784(RTCW(tr1), loc3);
	}
	RTHOOK(6);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		RTHOOK(7);
		if ((EIF_BOOLEAN)(loc1 == loc2)) break;
		RTHOOK(8);
		tr1 = *(EIF_REFERENCE *)(Current);
		tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R9603[Dtype(RTCW(arg1))-1240])(arg1, (EIF_INTEGER_32) (loc1 + arg2));
		tu1_1 = (EIF_NATURAL_8) tu4_1;
		F1141_9725(RTCW(tr1), tu1_1, loc1);
		RTHOOK(9);
		loc1++;
	}
	RTHOOK(10);
	tr1 = *(EIF_REFERENCE *)(Current);
	F1141_9725(RTCW(tr1), (EIF_NATURAL_8) ((EIF_INTEGER_32) 0L), loc2);
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {C_STRING}.set_count */
void F532_7687 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("set_count", 531, Current, 1, 1, 7809);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_0_1_0_0_);
	if ((EIF_BOOLEAN) (ti4_1 < loc1)) {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current);
		F1141_9784(RTCW(tr1), loc1);
	}
	RTHOOK(4);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_) = (EIF_INTEGER_32) arg1;
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {C_STRING}.c_strlen */
EIF_INTEGER_32 F532_7690 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("c_strlen", 531, Current, 0, 1, 7812);Result = (EIF_INTEGER_32) strlen((char*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit465 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
