
#ifndef _C10_pr451_
#define _C10_pr451_

#ifdef __cplusplus
extern "C" {
#endif

extern void F518_7528(EIF_REFERENCE, EIF_REFERENCE);
extern void F518_7529(EIF_REFERENCE);
extern void EIF_Minit451(void);
extern void F517_7513(EIF_REFERENCE, EIF_INTEGER_64);
extern void F527_7597(EIF_REFERENCE);
extern void F291_4839(EIF_REFERENCE);
extern void F1139_9669(EIF_REFERENCE);
extern EIF_BOOLEAN F292_4864(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
