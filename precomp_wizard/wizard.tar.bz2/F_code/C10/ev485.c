/*
 * Code for class EV_PND_ACTION_SEQUENCE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev485.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PND_ACTION_SEQUENCE}.call */
void F918_8947 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTEAA("call", 917, Current, 1, 1, 11824);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		switch (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_2_0_1_)) {
			case 1L:
				RTHOOK(3);
				tr1 = eif_boxed_item(arg1,1);
				tr2 = RTCCL(tr1);
				if (F918_8952(Current, tr2)) {
					RTHOOK(4);
					{
						static EIF_TYPE_INDEX typarr0[] = {891,1230,0xFFF9,1,1186,0,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
						loc1 = RTLNS(typres0.id, 891, _OBJSIZ_1_1_0_1_0_0_0_0_);
					}
					ti4_1 = F892_8801(Current);
					F892_8780(RTCW(loc1), ti4_1);
					RTHOOK(5);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7658[Dtype(RTCW(loc1))-780])(loc1, Current);
					RTHOOK(6);
					tr1 = F916_8934(Current);
					F888_8724(RTCW(tr1), (EIF_BOOLEAN) 0);
					RTHOOK(7);
					F892_8811(RTCW(loc1));
					for (;;) {
						RTHOOK(9);
						tb1 = '\01';
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O7931[Dtype(loc1)-891]);
						ti4_2 = F892_8801(RTCW(loc1));
						if (!(EIF_BOOLEAN) (ti4_1 > ti4_2)) {
							tb2 = F888_8722(RTCV(F916_8934(Current)));
							tb1 = tb2;
						}
						if (tb1) break;
						RTHOOK(10);
						tr1 = F892_8785(RTCW(loc1));
						tb2 = F1230_11015(RTCW(tr1), arg1);
						if (tb2) {
							RTHOOK(11);
							tr1 = F892_8785(RTCW(loc1));
							F1230_11024(RTCW(tr1), arg1);
						}
						RTHOOK(12);
						F892_8813(RTCW(loc1));
					}
					RTHOOK(13);
					F888_8726(RTCV(F916_8934(Current)));
				}
				break;
			case 2L:
				RTHOOK(14);
				tr1 = F916_8936(Current);
				F890_8739(RTCW(tr1), arg1);
				break;
			case 3L:
				break;
			default:
				RTEC(EN_WHEN);
		}
	}
	RTHOOK(15);
	RTLE;
	RTEE;
}

/* {EV_PND_ACTION_SEQUENCE}.accepts_pebble */
EIF_BOOLEAN F918_8949 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTEAA("accepts_pebble", 917, Current, 2, 1, 11826);
	RTGC;
	RTHOOK(1);
	tr1 = RTCCL(arg1);
	if (F918_8952(Current, tr1)) {
		RTHOOK(2);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr1 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr1+1)->it_r = arg1;
		RTAR(tr1,arg1);
		loc2 = (EIF_REFERENCE) tr1;
		RTHOOK(3);
		loc1 = F892_8791(Current);
		RTHOOK(4);
		F892_8811(Current);
		for (;;) {
			RTHOOK(5);
			tb1 = '\01';
			if (!Result) {
				tb1 = F859_8654(Current);
			}
			if (tb1) break;
			RTHOOK(6);
			tr1 = F892_8785(Current);
			Result = F1230_11015(RTCW(tr1), loc2);
			RTHOOK(7);
			F892_8813(Current);
		}
		RTHOOK(8);
		F892_8816(Current, loc1);
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_PND_ACTION_SEQUENCE}.veto_pebble_function_result */
EIF_BOOLEAN F918_8952 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTEAA("veto_pebble_function_result", 917, Current, 2, 1, 11829);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTHOOK(2);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr1+1)->it_r = arg1;
		RTAR(tr1,arg1);
		loc1 = (EIF_REFERENCE) tr1;
		RTHOOK(3);
		Result = '\0';
		tb1 = F1230_11015(loc2, loc1);
		if (tb1) {
			tb1 = F1233_11056(loc2, loc1);
			Result = tb1;
		}
	} else {
		RTHOOK(4);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit485 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
