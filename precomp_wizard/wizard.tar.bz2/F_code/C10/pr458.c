/*
 * Code for class PROCESS_INFO_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pr458.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F525_7564
static EIF_INTEGER_32 inline_F525_7564 (void)
{
	return (EIF_INTEGER_32) (getpid())
	;
}
#define INLINE_F525_7564
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PROCESS_INFO_IMP}.process_id */
EIF_INTEGER_32 F525_7563 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("process_id", 524, Current, 0, 0, 7697);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) inline_F525_7564();
}

/* {PROCESS_INFO_IMP}.c_process_id */
EIF_INTEGER_32 F525_7564 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("c_process_id", 524, Current, 0, 0, 7696);
	Result = inline_F525_7564 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit458 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
