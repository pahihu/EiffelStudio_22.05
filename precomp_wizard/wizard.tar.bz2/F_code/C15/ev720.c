/*
 * Code for class EV_MULTI_COLUMN_LIST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev720.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_MULTI_COLUMN_LIST}.selected_item */
EIF_REFERENCE F1373_13132 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("selected_item", 1372, Current, 0, 0, 18319);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = F1644_16948(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_MULTI_COLUMN_LIST}.selected_items */
EIF_REFERENCE F1373_13133 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("selected_items", 1372, Current, 0, 0, 18320);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = F1644_16949(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_MULTI_COLUMN_LIST}.row_height */
EIF_INTEGER_32 F1373_13134 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("row_height", 1372, Current, 0, 0, 18321);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = F1644_16993(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_MULTI_COLUMN_LIST}.enable_multiple_selection */
void F1373_13142 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("enable_multiple_selection", 1372, Current, 0, 0, 18296);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1644_16956(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_MULTI_COLUMN_LIST}.set_column_titles */
void F1373_13150 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("set_column_titles", 1372, Current, 0, 1, 18304);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1623_16691(RTCW(tr1), arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_MULTI_COLUMN_LIST}.set_column_widths */
void F1373_13153 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("set_column_widths", 1372, Current, 0, 1, 18307);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1623_16694(RTCW(tr1), arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_MULTI_COLUMN_LIST}.implementation */
EIF_REFERENCE F1373_13162 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {EV_MULTI_COLUMN_LIST}.create_implementation */
void F1373_13163 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1372, Current, 0, 0, 18317);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1643, 0x00).id, 1643, _OBJSIZ_58_14_10_9_0_4_0_0_);
	F1644_16927(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit720 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
