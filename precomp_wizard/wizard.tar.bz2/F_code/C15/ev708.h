
#ifndef _C15_ev708_
#define _C15_ev708_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1361_12999(EIF_REFERENCE);
extern void F1361_13004(EIF_REFERENCE);
extern void F1361_13011(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1361_13012(EIF_REFERENCE);
extern void F1361_13013(EIF_REFERENCE);
extern void EIF_Minit708(void);
extern void F1618_16636(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F66_1133(EIF_REFERENCE);
extern void F1359_12956(EIF_REFERENCE);
extern void F1616_16540(EIF_REFERENCE);
extern EIF_REFERENCE F1155_10574(EIF_REFERENCE);
extern void F1618_16630(EIF_REFERENCE);
extern long O9889[];

#ifdef __cplusplus
}
#endif

#endif
