
#ifndef _C15_ev705_
#define _C15_ev705_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1358_12948(EIF_REFERENCE);
extern void F1358_12950(EIF_REFERENCE);
extern void F1358_12951(EIF_REFERENCE);
extern EIF_REFERENCE F1358_12953(EIF_REFERENCE);
extern void F1358_12954(EIF_REFERENCE);
extern void EIF_Minit705(void);
extern void F1615_16521(EIF_REFERENCE);
extern void F1615_16507(EIF_REFERENCE);
extern void F1615_16519(EIF_REFERENCE);
extern void F1615_16522(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
