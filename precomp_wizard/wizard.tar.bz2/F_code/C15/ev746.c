/*
 * Code for class EV_TOOL_BAR_SEPARATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev746.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TOOL_BAR_SEPARATOR}.implementation */
EIF_REFERENCE F1399_13404 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {EV_TOOL_BAR_SEPARATOR}.create_implementation */
void F1399_13405 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1398, Current, 0, 0, 18565);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1672, 0x00).id, 1672, _OBJSIZ_21_7_6_1_0_2_0_0_);
	F1673_17544(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit746 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
