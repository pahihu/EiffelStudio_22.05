/*
 * Code for class EV_TOOL_BAR_ITEM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev745.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TOOL_BAR_ITEM}.parent */
EIF_REFERENCE F1398_13403 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("parent", 1397, Current, 0, 0, 18563);
	RTGC;
	RTHOOK(1);
	Result = F1392_13357(Current);
	RTHOOK(2);
	RTLE;
	RTEE;
	return RTRV(eif_new_type(1371, 0x00), Result);
}

void EIF_Minit745 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
