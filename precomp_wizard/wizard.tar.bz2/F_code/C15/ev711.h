
#ifndef _C15_ev711_
#define _C15_ev711_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1364_13060(EIF_REFERENCE, EIF_REFERENCE);
extern void F1364_13061(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1364_13062(EIF_REFERENCE);
extern void EIF_Minit711(void);

#ifdef __cplusplus
}
#endif

#endif
