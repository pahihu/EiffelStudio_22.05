
#ifndef _C15_ev739_
#define _C15_ev739_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1392_13357(EIF_REFERENCE);
extern void EIF_Minit739(void);
extern char *(*R13843[])();
extern long O9889[];

#ifdef __cplusplus
}
#endif

#endif
