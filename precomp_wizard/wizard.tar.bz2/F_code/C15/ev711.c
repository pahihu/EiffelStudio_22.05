/*
 * Code for class EV_DOCKABLE_DIALOG
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev711.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DOCKABLE_DIALOG}.set_original_parent */
void F1364_13060 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_original_parent", 1363, Current, 0, 1, 18218);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EV_DOCKABLE_DIALOG}.set_original_parent_index */
void F1364_13061 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_original_parent_index", 1363, Current, 0, 1, 18219);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_1_) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EV_DOCKABLE_DIALOG}.set_expansion_was_disabled */
void F1364_13062 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_expansion_was_disabled", 1363, Current, 0, 0, 18220);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_7_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	RTEE;
}

void EIF_Minit711 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
