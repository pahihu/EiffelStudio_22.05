
#ifndef _C15_ev721_
#define _C15_ev721_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1374_13169(EIF_REFERENCE);
extern void F1374_13170(EIF_REFERENCE);
extern void EIF_Minit721(void);
extern void F1645_17000(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
