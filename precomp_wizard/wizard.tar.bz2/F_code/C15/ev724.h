
#ifndef _C15_ev724_
#define _C15_ev724_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1377_13211(EIF_REFERENCE, EIF_REAL_32);
extern void EIF_Minit724(void);
extern void F1626_16730(EIF_REFERENCE, EIF_REAL_32);

#ifdef __cplusplus
}
#endif

#endif
