/*
 * Code for class EV_WARNING_DIALOG
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev715.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_WARNING_DIALOG}.initialize */
void F1368_13099 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("initialize", 1367, Current, 0, 0, 18257);
	RTGC;
	RTHOOK(1);
	F1365_13066(Current);
	RTHOOK(2);
	tr1 = F288_4830(Current);
	F1359_12977(Current, tr1);
	RTHOOK(3);
	tr1 = RTOUCR(307,F66_1131, (RTCV(RTOUCR(278,F1155_10574, (Current)))));
	F1365_13074(Current, tr1);
	RTHOOK(4);
	tr1 = RTOUCR(307,F66_1131, (RTCV(RTOUCR(278,F1155_10574, (Current)))));
	F1361_13011(Current, tr1);
	RTHOOK(5);
	{
		static EIF_TYPE_INDEX typarr0[] = {1407,1244,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 1L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F288_4820(Current);
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F1408_13455)(tr2);
	F1365_13078(Current, tr1);
	RTHOOK(6);
	tr1 = F288_4820(Current);
	tr1 = F1365_13081(Current, tr1);
	F1363_13048(Current, tr1);
	RTHOOK(7);
	tr1 = F288_4820(Current);
	tr1 = F1365_13081(Current, tr1);
	F1363_13050(Current, tr1);
	RTHOOK(8);
	RTLE;
	RTEE;
}

void EIF_Minit715 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
