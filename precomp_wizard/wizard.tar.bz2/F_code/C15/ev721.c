/*
 * Code for class EV_LABEL
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev721.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_LABEL}.implementation */
EIF_REFERENCE F1374_13169 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {EV_LABEL}.create_implementation */
void F1374_13170 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1373, Current, 0, 0, 18328);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1644, 0x00).id, 1644, _OBJSIZ_44_13_10_6_1_2_0_0_);
	F1645_17000(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit721 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
