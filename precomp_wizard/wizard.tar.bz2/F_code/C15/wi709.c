/*
 * Code for class WIZARD_WINDOW
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "wi709.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WIZARD_WINDOW}.make */
void F1362_13014 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("make", 1361, Current, 0, 1, 18173);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	F1248_11522(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {WIZARD_WINDOW}.create_interface_objects */
void F1362_13015 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_interface_objects", 1361, Current, 0, 0, 18174);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_new_type(1352, 0).id);
	F1248_11522(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTLNSMART(eif_new_type(1379, 0).id);
	F1248_11522(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	tr1 = RTLNSMART(eif_new_type(1379, 0).id);
	F1248_11522(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	tr1 = RTLNSMART(eif_new_type(1379, 0).id);
	F1248_11522(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	RTHOOK(5);
	tr1 = RTLNSMART(eif_new_type(1379, 0).id);
	F1248_11522(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	RTHOOK(6);
	F1155_10572(Current);
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {WIZARD_WINDOW}.initialize */
void F1362_13016 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLIU(2);
	
	RTEAA("initialize", 1361, Current, 1, 0, 18175);
	RTGC;
	RTHOOK(1);
	F1361_12999(Current);
	RTHOOK(2);
	loc1 = RTLNS(eif_new_type(1352, 0x00).id, 1352, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1248_11522(RTCW(loc1));
	RTHOOK(3);
	F1341_12738(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_7_));
	RTHOOK(4);
	F1362_13017(Current, loc1);
	RTHOOK(5);
	F1348_12833(Current, loc1);
	RTHOOK(6);
	ti4_1 = F213_3821(Current, ((EIF_INTEGER_32) 503L));
	ti4_2 = F213_3821(Current, ((EIF_INTEGER_32) 385L));
	F1269_11854(Current, ti4_1, ti4_2);
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {WIZARD_WINDOW}.build_navigation_bar */
void F1362_13017 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,loc1);
	RTLR(6,loc3);
	RTLR(7,loc2);
	RTLR(8,arg1);
	RTLIU(9);
	
	RTEAA("build_navigation_bar", 1361, Current, 3, 1, 18176);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_new_type(1379, 0).id);
	tr2 = F214_3851(Current);
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = Current;
	RTAR(tr3,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1230,0xFFF9,0,1186,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A709_385, (EIF_POINTER) _A709_385, (EIF_POINTER)(F1362_13036),tr3, 1, 0);
	}
	F1380_13226(RTCW(tr1), tr2, tr4);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	F1277_11899(RTCW(tr1));
	RTHOOK(3);
	F213_3819(Current, *(EIF_REFERENCE *)(Current + _REFACS_9_));
	RTHOOK(4);
	tr1 = RTLNSMART(eif_new_type(1379, 0).id);
	tr2 = F214_3852(Current);
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = Current;
	RTAR(tr3,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1230,0xFFF9,0,1186,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A709_387, (EIF_POINTER) _A709_387, (EIF_POINTER)(F1362_13038),tr3, 1, 0);
	}
	F1380_13226(RTCW(tr1), tr2, tr4);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	F1277_11899(RTCW(tr1));
	RTHOOK(6);
	F213_3819(Current, *(EIF_REFERENCE *)(Current + _REFACS_10_));
	RTHOOK(7);
	tr1 = RTLNSMART(eif_new_type(1379, 0).id);
	tr2 = F214_3853(Current);
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = Current;
	RTAR(tr3,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1230,0xFFF9,0,1186,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A709_353, (EIF_POINTER) _A709_353, (EIF_POINTER)(F216_3895),tr3, 1, 0);
	}
	F1380_13226(RTCW(tr1), tr2, tr4);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
	RTHOOK(8);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	F1277_11899(RTCW(tr1));
	RTHOOK(9);
	F213_3819(Current, *(EIF_REFERENCE *)(Current + _REFACS_11_));
	RTHOOK(10);
	tr1 = RTLNSMART(eif_new_type(1379, 0).id);
	tr2 = F214_3854(Current);
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = Current;
	RTAR(tr3,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1230,0xFFF9,0,1186,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A709_354, (EIF_POINTER) _A709_354, (EIF_POINTER)(F216_3896),tr3, 1, 0);
	}
	F1380_13226(RTCW(tr1), tr2, tr4);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
	RTHOOK(11);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	F1277_11899(RTCW(tr1));
	RTHOOK(12);
	F213_3819(Current, *(EIF_REFERENCE *)(Current + _REFACS_12_));
	RTHOOK(13);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	F1347_12804(RTCW(tr1));
	RTHOOK(14);
	loc1 = RTLNS(eif_new_type(1353, 0x00).id, 1353, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1248_11522(RTCW(loc1));
	RTHOOK(15);
	F1341_12738(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_9_));
	RTHOOK(16);
	F1352_12903(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_9_));
	RTHOOK(17);
	F1341_12738(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_10_));
	RTHOOK(18);
	F1352_12903(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_10_));
	RTHOOK(19);
	loc3 = RTLNS(eif_new_type(1353, 0x00).id, 1353, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1248_11522(RTCW(loc3));
	RTHOOK(20);
	ti4_1 = F213_3821(Current, ((EIF_INTEGER_32) 11L));
	F1352_12901(RTCW(loc3), ti4_1);
	RTHOOK(21);
	ti4_1 = F213_3821(Current, ((EIF_INTEGER_32) 11L));
	F1352_12899(RTCW(loc3), ti4_1);
	RTHOOK(22);
	F1341_12738(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_12_));
	RTHOOK(23);
	F1352_12903(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_12_));
	RTHOOK(24);
	tr1 = RTLNS(eif_new_type(1354, 0x00).id, 1354, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1248_11522(RTCW(tr1));
	F1341_12738(RTCW(loc3), tr1);
	RTHOOK(25);
	F1341_12738(RTCW(loc3), loc1);
	RTHOOK(26);
	F1352_12903(RTCW(loc3), loc1);
	RTHOOK(27);
	F1341_12738(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_11_));
	RTHOOK(28);
	F1352_12903(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_11_));
	RTHOOK(29);
	loc2 = RTLNS(eif_new_type(1390, 0x00).id, 1390, _OBJSIZ_5_2_0_1_0_0_0_0_);
	F1248_11522(RTCW(loc2));
	RTHOOK(30);
	F1341_12738(RTCW(arg1), loc2);
	RTHOOK(31);
	F1352_12903(RTCW(arg1), loc2);
	RTHOOK(32);
	F1341_12738(RTCW(arg1), loc3);
	RTHOOK(33);
	F1352_12903(RTCW(arg1), loc3);
	RTHOOK(34);
	RTLE;
	RTEE;
}

/* {WIZARD_WINDOW}.load_first_state */
void F1362_13018 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("load_first_state", 1361, Current, 1, 0, 18177);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	loc1 = F243_4232(RTCW(tr1));
	RTHOOK(2);
	F216_3897(Current, loc1);
	RTHOOK(3);
	F1362_13037(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {WIZARD_WINDOW}.destroy */
void F1362_13020 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("destroy", 1361, Current, 1, 0, 18179);
	RTGC;
	RTHOOK(1);
	F1359_12968(Current);
	RTHOOK(2);
	tr1 = RTLNS(eif_new_type(1258, 0x00).id, 1258, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1248_11522(RTCW(tr1));
	tr1 = F1259_11732(RTCW(tr1));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		F1248_11525(loc1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {WIZARD_WINDOW}.set_final_state */
void F1362_13028 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("set_final_state", 1361, Current, 0, 1, 18187);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	F1276_11891(RTCW(tr1), arg1);
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_13_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {WIZARD_WINDOW}.set_intermediary_state */
void F1362_13029 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_intermediary_state", 1361, Current, 0, 0, 18188);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_13_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(2);
	RTEE;
}

/* {WIZARD_WINDOW}.disable_next_button */
void F1362_13030 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("disable_next_button", 1361, Current, 0, 0, 18189);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	F1346_12787(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {WIZARD_WINDOW}.disable_back_button */
void F1362_13031 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("disable_back_button", 1361, Current, 0, 0, 18190);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	F1346_12787(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {WIZARD_WINDOW}.disable_cancel_button */
void F1362_13032 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("disable_cancel_button", 1361, Current, 0, 0, 18191);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	F1346_12787(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {WIZARD_WINDOW}.enable_next_button */
void F1362_13033 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("enable_next_button", 1361, Current, 0, 0, 18192);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	F1346_12786(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {WIZARD_WINDOW}.enable_back_button */
void F1362_13034 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("enable_back_button", 1361, Current, 0, 0, 18193);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	F1346_12786(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {WIZARD_WINDOW}.enable_cancel_button */
void F1362_13035 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("enable_cancel_button", 1361, Current, 0, 0, 18194);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	F1346_12786(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {WIZARD_WINDOW}.previous_page */
void F1362_13036 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("previous_page", 1361, Current, 0, 0, 18195);
	RTGC;
	RTHOOK(1);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOUCR(111,F214_3826, (Current)))+ _LNGOFF_4_3_0_0_);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L))) {
		RTHOOK(2);
		F216_3893(Current);
	}
	RTHOOK(3);
	F1362_13037(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {WIZARD_WINDOW}.update_navigation */
void F1362_13037 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("update_navigation", 1361, Current, 0, 0, 18196);
	RTGC;
	RTHOOK(1);
	tb1 = '\01';
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOUCR(111,F214_3826, (Current)))+ _LNGOFF_4_3_0_0_);
	if (!(EIF_BOOLEAN) (ti4_1 < ((EIF_INTEGER_32) 1L))) {
		tb2 = F883_8679(RTCV(RTOUCR(111,F214_3826, (Current))));
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		F1346_12787(RTCW(tr1));
	} else {
		RTHOOK(3);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_13_4_)) {
			RTHOOK(4);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
			F1346_12786(RTCW(tr1));
		} else {
			RTHOOK(5);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
			F1346_12786(RTCW(tr1));
			RTHOOK(6);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
			tr2 = F214_3852(Current);
			F1276_11891(RTCW(tr1), tr2);
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {WIZARD_WINDOW}.next_page */
void F1362_13038 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("next_page", 1361, Current, 0, 0, 18197);
	RTGC;
	RTHOOK(1);
	tb1 = *(EIF_BOOLEAN *)(RTCV(RTOUCR(111,F214_3826, (Current)))+ _CHROFF_4_2_);
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(2);
		F216_3894(Current);
	}
	RTHOOK(3);
	F1362_13037(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

void EIF_Minit709 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
