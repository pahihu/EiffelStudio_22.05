/*
 * Code for class EV_VERTICAL_SEPARATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev737.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_VERTICAL_SEPARATOR}.implementation */
EIF_REFERENCE F1390_13353 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {EV_VERTICAL_SEPARATOR}.create_implementation */
void F1390_13354 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1389, Current, 0, 0, 18516);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1659, 0x00).id, 1659, _OBJSIZ_42_13_10_6_0_1_0_0_);
	F1660_17352(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit737 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
