
#ifndef _C15_ev719_
#define _C15_ev719_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1372_13120(EIF_REFERENCE);
extern EIF_REFERENCE F1372_13130(EIF_REFERENCE);
extern void EIF_Minit719(void);
extern void F1643_16909(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
