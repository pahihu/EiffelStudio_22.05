
#ifndef _C15_ev737_
#define _C15_ev737_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1390_13353(EIF_REFERENCE);
extern void F1390_13354(EIF_REFERENCE);
extern void EIF_Minit737(void);
extern void F1660_17352(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
