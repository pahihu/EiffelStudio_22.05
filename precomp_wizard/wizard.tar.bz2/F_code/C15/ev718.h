
#ifndef _C15_ev718_
#define _C15_ev718_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1371_13118(EIF_REFERENCE);
extern void F1371_13119(EIF_REFERENCE);
extern void EIF_Minit718(void);
extern void F1696_17893(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
