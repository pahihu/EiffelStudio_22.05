/*
 * Code for class EV_WINDOW
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev706.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_WINDOW}.initialize */
void F1359_12956 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,tr5);
	RTLIU(6);
	
	RTEAA("initialize", 1358, Current, 0, 0, 18113);
	RTGC;
	RTHOOK(1);
	F1248_11531(Current);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(RTCV(F1359_12964(Current)) + _REFACS_3_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1607,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	tr3 = *(EIF_REFERENCE *)(Current + O9889[dtype-1247]);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1230,0xFFF9,1,1186,1301,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A894_263_2, (EIF_POINTER) _A894_263_2, (EIF_POINTER)(F1616_16563),tr2, 1, 1);
	}
	F909_8875(RTCW(tr1), tr5);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(RTCV(F1359_12964(Current)) + _REFACS_4_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1607,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	tr3 = *(EIF_REFERENCE *)(Current + O9889[dtype-1247]);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1230,0xFFF9,1,1186,1301,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A894_264_2, (EIF_POINTER) _A894_264_2, (EIF_POINTER)(F1616_16564),tr2, 1, 1);
	}
	F909_8875(RTCW(tr1), tr5);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_WINDOW}.title */
EIF_REFERENCE F1359_12961 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("title", 1358, Current, 0, 0, 18118);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O9889[Dtype(Current)-1247]);
	Result = F1616_16544(RTCW(tr1));
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_WINDOW}.accelerators */
EIF_REFERENCE F1359_12964 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("accelerators", 1358, Current, 0, 0, 18121);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O9889[Dtype(Current)-1247]);
	Result = F1608_16392(RTCW(tr1));
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_WINDOW}.has */
EIF_BOOLEAN F1359_12965 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("has", 1358, Current, 0, 1, 18122);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O9889[Dtype(Current)-1247]);
	Result = F1608_16389(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_WINDOW}.destroy */
void F1359_12968 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("destroy", 1358, Current, 1, 0, 18125);
	RTGC;
	RTHOOK(1);
	F1248_11525(Current);
	RTHOOK(2);
	tr1 = F1259_11732(RTCV(RTOUCR(279,F374_5872, (Current))));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		F1262_11793(loc1, Current);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_WINDOW}.disable_user_resize */
void F1359_12971 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("disable_user_resize", 1358, Current, 0, 0, 18128);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O9889[Dtype(Current)-1247]);
	F1616_16551(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_WINDOW}.set_title */
void F1359_12977 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("set_title", 1358, Current, 1, 1, 18134);
	RTGC;
	RTHOOK(1);
	loc1 = arg1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + O9889[dtype-1247]);
		F1616_16560(RTCW(tr1), loc1);
	} else {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + O9889[dtype-1247]);
		tr2 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1240_11197(RTCW(tr2), arg1);
		F1616_16560(RTCW(tr1), tr2);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_WINDOW}.lock_update */
void F1359_12981 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("lock_update", 1358, Current, 0, 0, 18138);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O9889[Dtype(Current)-1247]);
	F1608_16405(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_WINDOW}.unlock_update */
void F1359_12982 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("unlock_update", 1358, Current, 0, 0, 18139);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O9889[Dtype(Current)-1247]);
	F1608_16406(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_WINDOW}.show */
void F1359_12983 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("show", 1358, Current, 1, 0, 18140);
	RTGC;
	RTHOOK(1);
	F1347_12805(Current);
	RTHOOK(2);
	tr1 = F1259_11732(RTCV(RTOUCR(279,F374_5872, (Current))));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		F1262_11792(loc1, Current);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_WINDOW}.implementation */
EIF_REFERENCE F1359_12986 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O9889[Dtype(Current)-1247]);
}


/* {EV_WINDOW}.create_implementation */
void F1359_12990 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1358, Current, 0, 0, 18147);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1615, 0x00).id, 1615, _OBJSIZ_59_21_10_11_0_4_0_0_);
	F1616_16540(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9889[Dtype(Current)-1247]) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit706 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
