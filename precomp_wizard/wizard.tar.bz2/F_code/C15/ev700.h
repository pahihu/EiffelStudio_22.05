
#ifndef _C15_ev700_
#define _C15_ev700_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1353_12906(EIF_REFERENCE);
extern void F1353_12907(EIF_REFERENCE);
extern void EIF_Minit700(void);
extern void F1602_16349(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
