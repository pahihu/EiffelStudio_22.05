/*
 * Code for class EV_BUTTON
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev727.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_BUTTON}.make_with_text_and_action */
void F1380_13226 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTEAA("make_with_text_and_action", 1379, Current, 0, 2, 18385);
	RTGC;
	RTHOOK(1);
	F1248_11522(Current);
	RTHOOK(2);
	F1276_11891(Current, arg1);
	RTHOOK(3);
	tr1 = F1181_10690(Current);
	F909_8875(RTCW(tr1), arg2);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_BUTTON}.default_identifier_name */
EIF_REFERENCE F1380_13227 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("default_identifier_name", 1379, Current, 0, 0, 18386);
	RTGC;
	RTHOOK(1);
	tb1 = F730_8337(RTCV(F1276_11890(Current)));
	if (tb1) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) F1339_12711(Current);
	} else {
		RTHOOK(4);
		Result = F1242_11339(RTCV(F1276_11890(Current)));
		RTHOOK(5);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
		F1242_11330(RTCW(Result), tw1);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_BUTTON}.is_default_push_button */
EIF_BOOLEAN F1380_13228 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("is_default_push_button", 1379, Current, 0, 0, 18387);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_46_11_);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_BUTTON}.enable_default_push_button */
void F1380_13229 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("enable_default_push_button", 1379, Current, 0, 0, 18388);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1650_17083(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_BUTTON}.disable_default_push_button */
void F1380_13230 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("disable_default_push_button", 1379, Current, 0, 0, 18389);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1650_17084(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_BUTTON}.implementation */
EIF_REFERENCE F1380_13232 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {EV_BUTTON}.create_implementation */
void F1380_13233 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1379, Current, 0, 0, 18392);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1649, 0x00).id, 1649, _OBJSIZ_46_14_10_6_0_3_0_0_);
	F1650_17074(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit727 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
