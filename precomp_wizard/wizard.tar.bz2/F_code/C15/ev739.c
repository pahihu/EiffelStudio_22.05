/*
 * Code for class EV_ITEM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev739.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_ITEM}.parent */
EIF_REFERENCE F1392_13357 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("parent", 1391, Current, 0, 0, 18519);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O9889[Dtype(Current)-1247]);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13843[Dtype(RTCW(tr1))-1666])(tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit739 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
