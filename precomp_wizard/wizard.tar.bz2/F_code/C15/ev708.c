/*
 * Code for class EV_TITLED_WINDOW
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev708.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TITLED_WINDOW}.initialize */
void F1361_12999 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("initialize", 1360, Current, 0, 0, 18156);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(277,F66_1133, (RTCV(RTOUCR(278,F1155_10574, (Current)))));
	F1361_13011(Current, tr1);
	RTHOOK(2);
	F1359_12956(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_TITLED_WINDOW}.raise */
void F1361_13004 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("raise", 1360, Current, 0, 0, 18161);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O9889[Dtype(Current)-1247]);
	F1618_16630(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_TITLED_WINDOW}.set_icon_pixmap */
void F1361_13011 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("set_icon_pixmap", 1360, Current, 0, 1, 18168);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O9889[Dtype(Current)-1247]);
	F1618_16636(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_TITLED_WINDOW}.implementation */
EIF_REFERENCE F1361_13012 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O9889[Dtype(Current)-1247]);
}


/* {EV_TITLED_WINDOW}.create_implementation */
void F1361_13013 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1360, Current, 0, 0, 18170);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1617, 0x00).id, 1617, _OBJSIZ_65_25_10_11_0_4_0_0_);
	F1616_16540(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9889[Dtype(Current)-1247]) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit708 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
