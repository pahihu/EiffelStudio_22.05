
#ifndef _C15_ev734_
#define _C15_ev734_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1387_13306(EIF_REFERENCE);
extern EIF_REFERENCE F1387_13316(EIF_REFERENCE);
extern void F1387_13317(EIF_REFERENCE);
extern void EIF_Minit734(void);
extern void F1657_17267(EIF_REFERENCE);
extern void F1657_17231(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
