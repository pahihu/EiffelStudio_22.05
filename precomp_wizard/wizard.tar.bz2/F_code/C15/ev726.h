
#ifndef _C15_ev726_
#define _C15_ev726_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1379_13224(EIF_REFERENCE);
extern void F1379_13225(EIF_REFERENCE);
extern void EIF_Minit726(void);
extern void F1649_17069(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
