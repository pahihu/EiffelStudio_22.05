/*
 * Code for class EV_HORIZONTAL_SEPARATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev738.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_HORIZONTAL_SEPARATOR}.implementation */
EIF_REFERENCE F1391_13355 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {EV_HORIZONTAL_SEPARATOR}.create_implementation */
void F1391_13356 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1390, Current, 0, 0, 18518);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1660, 0x00).id, 1660, _OBJSIZ_42_13_10_6_0_1_0_0_);
	F1661_17355(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit738 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
