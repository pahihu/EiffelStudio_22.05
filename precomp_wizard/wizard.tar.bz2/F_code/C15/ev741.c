/*
 * Code for class EV_HEADER_ITEM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev741.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_HEADER_ITEM}.implementation */
EIF_REFERENCE F1394_13377 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {EV_HEADER_ITEM}.create_implementation */
void F1394_13378 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1393, Current, 0, 0, 18540);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1666, 0x00).id, 1666, _OBJSIZ_22_8_6_4_0_4_0_0_);
	F1667_17419(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit741 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
