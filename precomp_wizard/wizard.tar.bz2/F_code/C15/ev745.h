
#ifndef _C15_ev745_
#define _C15_ev745_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1398_13403(EIF_REFERENCE);
extern void EIF_Minit745(void);
extern EIF_REFERENCE F1392_13357(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
