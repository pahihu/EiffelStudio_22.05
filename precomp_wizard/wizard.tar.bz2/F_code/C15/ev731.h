
#ifndef _C15_ev731_
#define _C15_ev731_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1384_13264(EIF_REFERENCE);
extern void EIF_Minit731(void);
extern void F1657_17241(EIF_REFERENCE, EIF_BOOLEAN);

#ifdef __cplusplus
}
#endif

#endif
