
#ifndef _C15_ev701_
#define _C15_ev701_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1354_12908(EIF_REFERENCE);
extern void F1354_12909(EIF_REFERENCE);
extern void EIF_Minit701(void);
extern void F1603_16352(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
