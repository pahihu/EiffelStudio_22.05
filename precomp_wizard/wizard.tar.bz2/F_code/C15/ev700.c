/*
 * Code for class EV_VERTICAL_BOX
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev700.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_VERTICAL_BOX}.implementation */
EIF_REFERENCE F1353_12906 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {EV_VERTICAL_BOX}.create_implementation */
void F1353_12907 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1352, Current, 0, 0, 18060);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1601, 0x00).id, 1601, _OBJSIZ_49_13_10_7_0_1_0_0_);
	F1602_16349(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit700 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
