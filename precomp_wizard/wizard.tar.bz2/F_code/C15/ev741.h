
#ifndef _C15_ev741_
#define _C15_ev741_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1394_13377(EIF_REFERENCE);
extern void F1394_13378(EIF_REFERENCE);
extern void EIF_Minit741(void);
extern void F1667_17419(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
