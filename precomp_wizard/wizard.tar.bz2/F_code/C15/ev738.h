
#ifndef _C15_ev738_
#define _C15_ev738_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1391_13355(EIF_REFERENCE);
extern void F1391_13356(EIF_REFERENCE);
extern void EIF_Minit738(void);
extern void F1661_17355(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
