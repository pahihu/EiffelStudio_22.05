
#ifndef _C15_ev746_
#define _C15_ev746_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1399_13404(EIF_REFERENCE);
extern void F1399_13405(EIF_REFERENCE);
extern void EIF_Minit746(void);
extern void F1673_17544(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
