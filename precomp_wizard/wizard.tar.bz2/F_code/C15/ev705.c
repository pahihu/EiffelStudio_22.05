/*
 * Code for class EV_SCROLLABLE_AREA
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev705.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_SCROLLABLE_AREA}.show_horizontal_scroll_bar */
void F1358_12948 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("show_horizontal_scroll_bar", 1357, Current, 0, 0, 18104);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1615_16519(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_SCROLLABLE_AREA}.show_vertical_scroll_bar */
void F1358_12950 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("show_vertical_scroll_bar", 1357, Current, 0, 0, 18106);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1615_16521(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_SCROLLABLE_AREA}.hide_vertical_scroll_bar */
void F1358_12951 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("hide_vertical_scroll_bar", 1357, Current, 0, 0, 18107);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1615_16522(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_SCROLLABLE_AREA}.implementation */
EIF_REFERENCE F1358_12953 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {EV_SCROLLABLE_AREA}.create_implementation */
void F1358_12954 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1357, Current, 0, 0, 18110);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1614, 0x00).id, 1614, _OBJSIZ_49_14_10_10_0_5_0_0_);
	F1615_16507(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit705 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
