
#ifndef _C15_ev722_
#define _C15_ev722_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1375_13176(EIF_REFERENCE);
extern void F1375_13177(EIF_REFERENCE);
extern void EIF_Minit722(void);
extern void F1646_17011(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
