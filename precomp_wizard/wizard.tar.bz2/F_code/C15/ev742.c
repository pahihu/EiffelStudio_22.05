/*
 * Code for class EV_MULTI_COLUMN_LIST_ROW
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev742.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_MULTI_COLUMN_LIST_ROW}.implementation */
EIF_REFERENCE F1395_13382 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_4_);
}


/* {EV_MULTI_COLUMN_LIST_ROW}.on_item_added_at */
void F1395_13383 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("on_item_added_at", 1394, Current, 0, 2, 18546);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1685_17649(RTCW(tr1), arg1, arg2);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_MULTI_COLUMN_LIST_ROW}.on_item_removed_at */
void F1395_13384 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("on_item_removed_at", 1394, Current, 0, 2, 18547);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1685_17650(RTCW(tr1), arg1, arg2);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_MULTI_COLUMN_LIST_ROW}.create_implementation */
void F1395_13385 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1394, Current, 0, 0, 18548);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1684, 0x00).id, 1684, _OBJSIZ_22_5_6_0_0_0_0_0_);
	F1685_17622(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	F909_8870(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit742 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
