/*
 * Code for class EV_CELL
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev702.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_CELL}.has */
EIF_BOOLEAN F1355_12910 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("has", 1354, Current, 0, 1, 18063);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	if ((EIF_BOOLEAN) !F1248_11526(Current)) {
		tb1 = '\0';
		if ((EIF_BOOLEAN)(arg1 != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current + O9889[Dtype(Current)-1247]);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O13427[Dtype(tr1)-1611]);
			tb1 = (EIF_BOOLEAN)(tr1 == arg1);
		}
		Result = tb1;
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_CELL}.is_empty */
EIF_BOOLEAN F1355_12911 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_empty", 1354, Current, 0, 0, 18064);
	RTGC;
	RTHOOK(1);
	Result = F1355_12913(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_CELL}.extendible */
EIF_BOOLEAN F1355_12912 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("extendible", 1354, Current, 0, 0, 18065);
	RTGC;
	RTHOOK(1);
	Result = F1355_12913(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_CELL}.full */
EIF_BOOLEAN F1355_12913 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("full", 1354, Current, 0, 0, 18066);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + O9889[Dtype(Current)-1247]);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O13427[Dtype(tr1)-1611]);
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		Result = (EIF_BOOLEAN) !F1248_11526(Current);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_CELL}.prunable */
EIF_BOOLEAN F1355_12914 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("prunable", 1354, Current, 0, 0, 18067);
	RTGC;
	RTHOOK(1);
	Result = F1248_11526(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_CELL}.readable */
EIF_BOOLEAN F1355_12916 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("readable", 1354, Current, 0, 0, 18069);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	if (F1355_12913(Current)) {
		Result = (EIF_BOOLEAN) !F1248_11526(Current);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_CELL}.prune */
void F1355_12918 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("prune", 1354, Current, 0, 1, 18071);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(F1348_12824(Current) == arg1)) {
		RTHOOK(2);
		F1355_12919(Current);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_CELL}.wipe_out */
void F1355_12919 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("wipe_out", 1354, Current, 0, 0, 18072);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O9889[Dtype(Current)-1247]);
	F1612_16462(RTCW(tr1), NULL);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_CELL}.linear_representation */
EIF_REFERENCE F1355_12920 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("linear_representation", 1354, Current, 1, 0, 18073);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {882,1346,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 882, _OBJSIZ_2_3_0_1_0_0_0_0_);
	}
	F883_8665(RTCW(loc1));
	RTHOOK(2);
	if (F1355_12916(Current)) {
		RTHOOK(3);
		tr1 = F1348_12824(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7657[Dtype(RTCW(loc1))-780])(loc1, tr1);
	}
	RTHOOK(4);
	RTHOOK(5);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) loc1;
}

/* {EV_CELL}.implementation */
EIF_REFERENCE F1355_12921 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O9889[Dtype(Current)-1247]);
}


/* {EV_CELL}.create_implementation */
void F1355_12922 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1354, Current, 0, 0, 18075);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1611, 0x00).id, 1611, _OBJSIZ_49_13_10_6_0_1_0_0_);
	F1612_16458(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9889[Dtype(Current)-1247]) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit702 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
