/*
 * Code for class EV_MESSAGE_DIALOG
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev712.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_MESSAGE_DIALOG}.make_with_text */
void F1365_13063 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("make_with_text", 1364, Current, 0, 1, 18254);
	RTGC;
	RTHOOK(1);
	F1248_11522(Current);
	RTHOOK(2);
	F1365_13076(Current, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_MESSAGE_DIALOG}.create_interface_objects */
void F1365_13065 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTEAA("create_interface_objects", 1364, Current, 1, 0, 18222);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {805,1379,1241,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F806_8436(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTLNSMART(eif_new_type(1353, 0).id);
	F1248_11522(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	tr1 = RTLNSMART(eif_new_type(1354, 0).id);
	F1248_11522(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	tr1 = RTLNSMART(eif_new_type(1357, 0).id);
	F1248_11522(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	RTHOOK(5);
	tr1 = RTLNSMART(eif_new_type(1373, 0).id);
	F1248_11522(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	RTHOOK(6);
	loc1 = RTLNS(eif_new_type(64, 0x00).id, 64, _OBJSIZ_0_0_0_0_0_0_0_0_);
	RTHOOK(7);
	tr1 = F65_1122(RTCW(loc1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) tr1;
	RTHOOK(8);
	tr1 = F65_1121(RTCW(loc1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {EV_MESSAGE_DIALOG}.initialize */
void F1365_13066 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(11);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLR(6,loc5);
	RTLR(7,tr2);
	RTLR(8,tr3);
	RTLR(9,tr4);
	RTLR(10,tr5);
	RTLIU(11);
	
	RTEAA("initialize", 1364, Current, 5, 0, 18223);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr1 = F1556_15750(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr1 = F1556_15751(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	loc1 = RTLNS(eif_new_type(1353, 0x00).id, 1353, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1248_11522(RTCW(loc1));
	RTHOOK(4);
	loc2 = RTLNS(eif_new_type(1352, 0x00).id, 1352, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1248_11522(RTCW(loc2));
	RTHOOK(5);
	loc3 = RTLNS(eif_new_type(1353, 0x00).id, 1353, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1248_11522(RTCW(loc3));
	RTHOOK(6);
	loc4 = RTLNS(eif_new_type(1352, 0x00).id, 1352, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1248_11522(RTCW(loc4));
	RTHOOK(7);
	F1363_13042(Current);
	RTHOOK(8);
	loc5 = RTLNS(eif_new_type(1280, 0x00).id, 1280, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1248_11522(RTCW(loc5));
	RTHOOK(9);
	ti4_1 = F1281_11986(RTCW(loc5));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_3_0_1_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 200L));
	RTHOOK(10);
	ti4_1 = F1281_11987(RTCW(loc5));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_3_0_2_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 200L));
	RTHOOK(11);
	F1341_12738(RTCW(loc4), *(EIF_REFERENCE *)(Current + _REFACS_10_));
	RTHOOK(12);
	F1352_12903(RTCW(loc4), *(EIF_REFERENCE *)(Current + _REFACS_10_));
	RTHOOK(13);
	tr1 = RTLNS(eif_new_type(1354, 0x00).id, 1354, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1248_11522(RTCW(tr1));
	F1341_12738(RTCW(loc4), tr1);
	RTHOOK(14);
	F1341_12738(RTCW(loc1), loc4);
	RTHOOK(15);
	F1341_12738(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_9_));
	RTHOOK(16);
	F1352_12901(RTCW(loc1), ((EIF_INTEGER_32) 10L));
	RTHOOK(17);
	tr1 = RTLNS(eif_new_type(1354, 0x00).id, 1354, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1248_11522(RTCW(tr1));
	F1341_12738(RTCW(loc3), tr1);
	RTHOOK(18);
	F1341_12738(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_7_));
	RTHOOK(19);
	F1352_12903(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_7_));
	RTHOOK(20);
	tr1 = RTLNS(eif_new_type(1354, 0x00).id, 1354, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1248_11522(RTCW(tr1));
	F1341_12738(RTCW(loc3), tr1);
	RTHOOK(21);
	F1341_12738(RTCW(loc2), loc1);
	RTHOOK(22);
	F1341_12738(RTCW(loc2), loc3);
	RTHOOK(23);
	F1352_12903(RTCW(loc2), loc3);
	RTHOOK(24);
	F1352_12901(RTCW(loc2), ((EIF_INTEGER_32) 14L));
	RTHOOK(25);
	F1352_12899(RTCW(loc2), ((EIF_INTEGER_32) 10L));
	RTHOOK(26);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	F1277_11901(RTCW(tr1));
	RTHOOK(27);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F1352_12901(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTHOOK(28);
	F1348_12833(Current, loc2);
	RTHOOK(29);
	tr1 = RTMS_EX_H("Use `set_text\' to modify this message.",38,1665955374);
	F1365_13076(Current, tr1);
	RTHOOK(30);
	tr1 = F1178_10673(Current);
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1230,0xFFF9,1,1186,1714,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A712_356_2, (EIF_POINTER) _A712_356_2, (EIF_POINTER)(F1365_13095),tr2, 1, 1);
	}
	F909_8875(RTCW(tr1), tr5);
	RTHOOK(31);
	F1359_12971(Current);
	RTHOOK(32);
	RTLE;
	RTEE;
}

/* {EV_MESSAGE_DIALOG}.pixmap */
EIF_REFERENCE F1365_13067 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("pixmap", 1364, Current, 0, 0, 18224);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	tb1 = F1355_12916(RTCW(tr1));
	if (tb1) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
		Result = F1348_12824(RTCW(tr1));
		Result = RTRV(eif_new_type(1375, 0x00), Result);
		
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_MESSAGE_DIALOG}.foreground_color */
EIF_REFERENCE F1365_13069 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_13_);
}


/* {EV_MESSAGE_DIALOG}.background_color */
EIF_REFERENCE F1365_13070 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_12_);
}


/* {EV_MESSAGE_DIALOG}.default_identifier_name */
EIF_REFERENCE F1365_13071 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("default_identifier_name", 1364, Current, 0, 0, 18228);
	RTGC;
	RTHOOK(1);
	tb1 = F730_8337(RTCV(F1359_12961(Current)));
	if (tb1) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) F1339_12711(Current);
	} else {
		RTHOOK(4);
		Result = F1242_11339(RTCV(F1359_12961(Current)));
		RTHOOK(5);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
		F1242_11330(RTCW(Result), tw1);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_MESSAGE_DIALOG}.set_background_color */
void F1365_13072 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("set_background_color", 1364, Current, 1, 1, 18229);
	RTGC;
	RTHOOK(1);
	tr1 = F1348_12824(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R10113[Dtype(RTCW(tr1))-1280])(tr1, arg1);
	RTHOOK(2);
	loc1 = F1348_12824(Current);
	loc1 = RTRV(eif_new_type(1347, 0x00), loc1);
	RTHOOK(3);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTHOOK(4);
		F1348_12841(RTCW(loc1));
	}
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	F1257_11716(RTCW(tr1), arg1);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_MESSAGE_DIALOG}.set_pixmap */
void F1365_13074 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("set_pixmap", 1364, Current, 2, 1, 18231);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(F1365_13067(Current) != NULL)) {
		RTHOOK(2);
		F1365_13075(Current);
	}
	RTHOOK(3);
	loc1 = RTLNS(eif_new_type(1375, 0x00).id, 1375, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1248_11522(RTCW(loc1));
	RTHOOK(4);
	F1376_13198(RTCW(loc1), arg1);
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	F1348_12833(RTCW(tr1), loc1);
	RTHOOK(6);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	ti4_1 = F1268_11843(RTCW(loc1));
	ti4_2 = F1268_11844(RTCW(loc1));
	F1347_12818(RTCW(tr1), ti4_1, ti4_2);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EV_MESSAGE_DIALOG}.remove_pixmap */
void F1365_13075 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("remove_pixmap", 1364, Current, 0, 0, 18232);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	F1355_12919(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_MESSAGE_DIALOG}.set_text */
void F1365_13076 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc4);
	RTLR(4,loc6);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTEAA("set_text", 1364, Current, 6, 1, 18233);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr1 = F1347_12792(RTCW(tr1));
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		RTHOOK(2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R10970[Dtype(loc5)-1352])(loc5, *(EIF_REFERENCE *)(Current + _REFACS_8_));
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		F1355_12918(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_9_));
		RTHOOK(4);
		loc4 = (EIF_REFERENCE) loc5;
	} else {
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		tr1 = F1347_12792(RTCW(tr1));
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			RTHOOK(6);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R10970[Dtype(loc6)-1352])(loc6, *(EIF_REFERENCE *)(Current + _REFACS_9_));
			RTHOOK(7);
			loc4 = (EIF_REFERENCE) loc6;
		}
	}
	RTHOOK(8);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	F1276_11891(RTCW(tr1), arg1);
	RTHOOK(9);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc1 = F1268_11843(RTCW(tr1));
	RTHOOK(10);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc2 = F1268_11844(RTCW(tr1));
	RTHOOK(11);
	if ((EIF_BOOLEAN) (loc1 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_3_0_1_))) {
		RTHOOK(12);
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(13);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		F1358_12948(RTCW(tr1));
		RTHOOK(14);
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_3_0_1_);
	} else {
		RTHOOK(15);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		F1358_12951(RTCW(tr1));
	}
	RTHOOK(16);
	if ((EIF_BOOLEAN) (loc2 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_3_0_2_))) {
		RTHOOK(17);
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(18);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		F1358_12950(RTCW(tr1));
		RTHOOK(19);
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_3_0_2_);
	} else {
		RTHOOK(20);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		F1358_12951(RTCW(tr1));
	}
	RTHOOK(21);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	F1347_12816(RTCW(tr1), loc1);
	RTHOOK(22);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	F1347_12817(RTCW(tr1), loc2);
	RTHOOK(23);
	if (loc3) {
		RTHOOK(24);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		F1348_12833(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_9_));
		RTHOOK(25);
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			RTHOOK(26);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R10967[Dtype(RTCW(loc4))-1352])(loc4, *(EIF_REFERENCE *)(Current + _REFACS_8_));
		}
	} else {
		RTHOOK(27);
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			RTHOOK(28);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R10967[Dtype(RTCW(loc4))-1352])(loc4, *(EIF_REFERENCE *)(Current + _REFACS_9_));
		}
	}
	RTHOOK(31);
	RTLE;
	RTEE;
}

/* {EV_MESSAGE_DIALOG}.set_buttons */
void F1365_13078 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_buttons", 1364, Current, 1, 1, 18235);
	RTGC;
	RTHOOK(1);
	F1365_13091(Current);
	RTHOOK(2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(3);
		ti4_1 = F938_9021(RTCW(arg1));
		if ((EIF_BOOLEAN) (loc1 > ti4_1)) break;
		RTHOOK(4);
		tr1 = F938_9015(RTCW(arg1), loc1);
		F1365_13092(Current, tr1);
		RTHOOK(5);
		loc1++;
	}
	RTHOOK(6);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F1352_12897(RTCW(tr1));
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_MESSAGE_DIALOG}.button */
EIF_REFERENCE F1365_13081 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("button", 1364, Current, 1, 1, 18238);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	tr2 = F1237_11118(RTCW(arg1));
	loc1 = F806_8442(RTCW(tr1), tr2);
	RTHOOK(2);
	RTCT0("l_result /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(3);
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) loc1;
}

/* {EV_MESSAGE_DIALOG}.clean_buttons */
void F1365_13091 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("clean_buttons", 1364, Current, 0, 0, 18248);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(F1363_13043(Current) != NULL)) {
		RTHOOK(2);
		F1363_13049(Current);
	}
	RTHOOK(3);
	if ((EIF_BOOLEAN)(F1363_13044(Current) != NULL)) {
		RTHOOK(4);
		F1363_13051(Current);
	}
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F1341_12751(RTCW(tr1));
	RTHOOK(6);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	F806_8490(RTCW(tr1));
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_MESSAGE_DIALOG}.add_button */
void F1365_13092 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTEAA("add_button", 1364, Current, 2, 1, 18249);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1379, 0x00).id, 1379, _OBJSIZ_6_2_0_1_0_0_0_0_);
	F1276_11889(RTCW(loc1), arg1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	tr2 = F1237_11118(RTCW(arg1));
	F806_8482(RTCW(tr1), loc1, tr2);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	loc2 = F724_8337(RTCW(tr1));
	RTHOOK(4);
	tr1 = F1181_10690(RTCW(loc1));
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1186,0,1236,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	((EIF_TYPED_VALUE *)tr2+2)->it_r = arg1;
	RTAR(tr2,arg1);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1230,0xFFF9,0,1186,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A712_355, (EIF_POINTER) _A712_355, (EIF_POINTER)(F1365_13094),tr2, 1, 0);
	}
	F909_8875(RTCW(tr1), tr3);
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F1341_12738(RTCW(tr1), loc1);
	RTHOOK(6);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F1352_12903(RTCW(tr1), loc1);
	RTHOOK(7);
	ti4_1 = F1268_11845(RTCW(loc1));
	ti4_1 = eif_max_int32 (ti4_1,((EIF_INTEGER_32) 75L));
	F1347_12816(RTCW(loc1), ti4_1);
	RTHOOK(8);
	F1277_11899(RTCW(loc1));
	RTHOOK(9);
	if (loc2) {
		RTHOOK(10);
		F1363_13048(Current, loc1);
	}
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {EV_MESSAGE_DIALOG}.on_button_press */
void F1365_13094 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("on_button_press", 1364, Current, 0, 1, 18251);
	RTGC;
	RTHOOK(1);
	tr1 = F1237_11118(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	if ((EIF_BOOLEAN) !F1248_11526(Current)) {
		RTHOOK(3);
		F1359_12968(Current);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_MESSAGE_DIALOG}.on_key_press */
void F1365_13095 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("on_key_press", 1364, Current, 0, 1, 18252);
	RTGC;
	RTHOOK(1);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 60L))) {
		RTHOOK(2);
		F1365_13096(Current, ((EIF_INTEGER_32) -1L));
	} else {
		RTHOOK(3);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 61L))) {
			RTHOOK(4);
			F1365_13096(Current, ((EIF_INTEGER_32) 1L));
		}
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_MESSAGE_DIALOG}.move_to_next_button */
void F1365_13096 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc3);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTEAA("move_to_next_button", 1364, Current, 4, 1, 18253);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	RTHOOK(2);
	ti4_1 = F1341_12727(RTCW(loc1));
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L))) {
		RTHOOK(3);
		loc2 = F1341_12722(RTCW(loc1));
		RTHOOK(4);
		F1341_12730(RTCW(loc1));
		for (;;) {
			RTHOOK(5);
			tb1 = '\01';
			tb2 = F859_8654(RTCW(loc1));
			if (!tb2) {
				tb1 = loc4;
			}
			if (tb1) break;
			RTHOOK(6);
			loc3 = F1341_12720(RTCW(loc1));
			RTHOOK(7);
			loc4 = F1347_12802(RTCW(loc3));
			RTHOOK(8);
			if ((EIF_BOOLEAN) !loc4) {
				RTHOOK(9);
				F1341_12732(RTCW(loc1));
			}
		}
		RTHOOK(10);
		if (loc4) {
			RTHOOK(11);
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				RTHOOK(12);
				if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) -1L))) {
					RTHOOK(13);
					tr1 = F835_8615(RTCW(loc1));
					if ((EIF_BOOLEAN)(tr1 == loc3)) {
						RTHOOK(14);
						tr1 = F835_8616(RTCW(loc1));
						F1347_12806(RTCW(tr1));
					} else {
						RTHOOK(15);
						F1341_12731(RTCW(loc1));
						RTHOOK(16);
						tr1 = F1341_12720(RTCW(loc1));
						F1347_12806(RTCW(tr1));
					}
				} else {
					RTHOOK(17);
					tr1 = F835_8616(RTCW(loc1));
					if ((EIF_BOOLEAN)(tr1 == loc3)) {
						RTHOOK(18);
						tr1 = F835_8615(RTCW(loc1));
						F1347_12806(RTCW(tr1));
					} else {
						RTHOOK(19);
						F1341_12732(RTCW(loc1));
						RTHOOK(20);
						tr1 = F1341_12720(RTCW(loc1));
						F1347_12806(RTCW(tr1));
					}
				}
			}
		} else {
			RTHOOK(21);
			tr1 = F835_8615(RTCW(loc1));
			F1347_12806(RTCW(tr1));
		}
		RTHOOK(22);
		F1341_12734(RTCW(loc1), loc2);
	}
	RTHOOK(23);
	RTLE;
	RTEE;
}

void EIF_Minit712 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
