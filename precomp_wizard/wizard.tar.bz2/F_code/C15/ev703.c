/*
 * Code for class EV_FRAME
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev703.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_FRAME}.default_identifier_name */
EIF_REFERENCE F1356_12924 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("default_identifier_name", 1355, Current, 0, 0, 18082);
	RTGC;
	RTHOOK(1);
	tb1 = F730_8337(RTCV(F1276_11890(Current)));
	if (tb1) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) F1339_12711(Current);
	} else {
		RTHOOK(4);
		Result = (EIF_REFERENCE) eif_builtin_ANY_twin__o (F1276_11890(Current));
		RTHOOK(5);
		F1242_11345(RTCW(Result));
		RTHOOK(6);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
		F1242_11330(RTCW(Result), tw1);
		RTHOOK(7);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
		F1242_11330(RTCW(Result), tw1);
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_FRAME}.implementation */
EIF_REFERENCE F1356_12929 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {EV_FRAME}.create_implementation */
void F1356_12930 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1355, Current, 0, 0, 18079);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1612, 0x00).id, 1612, _OBJSIZ_51_13_10_8_0_1_0_0_);
	F1613_16466(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit703 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
