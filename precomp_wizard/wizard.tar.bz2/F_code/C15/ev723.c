/*
 * Code for class EV_PIXMAP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev723.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PIXMAP}.make_with_size */
void F1376_13178 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make_with_size", 1375, Current, 0, 2, 18336);
	RTGC;
	RTHOOK(1);
	F1248_11522(Current);
	RTHOOK(2);
	F1376_13192(Current, arg1, arg2);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_PIXMAP}.make_with_pixel_buffer */
void F1376_13180 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("make_with_pixel_buffer", 1375, Current, 0, 1, 18338);
	RTGC;
	RTHOOK(1);
	F1248_11522(Current);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1699_18030(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_PIXMAP}.is_equal */
EIF_BOOLEAN F1376_13182 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_equal", 1375, Current, 0, 1, 18340);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		ti4_1 = F1268_11843(Current);
		ti4_2 = F1268_11844(RTCW(arg1));
		ti4_3 = F1268_11843(RTCW(arg1));
		ti4_4 = F1268_11844(Current);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_INTEGER_32) (ti4_1 * ti4_2) == (EIF_INTEGER_32) (ti4_3 * ti4_4));
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_PIXMAP}.set_with_named_path */
void F1376_13190 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("set_with_named_path", 1375, Current, 0, 1, 18348);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1699_18037(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_PIXMAP}.set_size */
void F1376_13192 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("set_size", 1375, Current, 0, 2, 18350);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1699_18041(RTCW(tr1), arg1, arg2);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_PIXMAP}.stretch */
void F1376_13194 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("stretch", 1375, Current, 0, 2, 18352);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1699_18040(RTCW(tr1), arg1, arg2);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_PIXMAP}.copy */
void F1376_13198 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("copy", 1375, Current, 0, 1, 18356);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_3_) == NULL)) {
		RTHOOK(2);
		F1248_11522(Current);
	}
	RTHOOK(3);
	tb1 = F1248_11526(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1699_18048(RTCW(tr1), arg1);
	} else {
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
		ti4_1 = F1699_18035(RTCW(tr2));
		tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
		ti4_2 = F1699_18036(RTCW(tr2));
		F1699_18041(RTCW(tr1), ti4_1, ti4_2);
		RTHOOK(6);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1699_18061(RTCW(tr1));
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_PIXMAP}.implementation */
EIF_REFERENCE F1376_13199 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {EV_PIXMAP}.create_implementation */
void F1376_13200 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1375, Current, 0, 0, 18358);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1698, 0x00).id, 1698, _OBJSIZ_48_18_10_9_0_4_0_1_);
	F1699_18028(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit723 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
