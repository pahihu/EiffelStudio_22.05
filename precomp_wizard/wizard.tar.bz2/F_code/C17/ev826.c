/*
 * Code for class EV_ENVIRONMENT_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev826.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_ENVIRONMENT_I}.application */
EIF_REFERENCE F1536_15227 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("application", 1535, Current, 1, 0, 21748);
	RTGC;
	RTHOOK(1);
	tr1 = RTOPCF(15239,F1536_15239, (Current));
	tr1 = F1536_15241(Current, tr1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_23_);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {EV_ENVIRONMENT_I}.application_i */
EIF_REFERENCE F1536_15229 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("application_i", 1535, Current, 1, 0, 21750);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tr1 = RTOPCF(15239,F1536_15239, (Current));
	tr1 = F1536_15241(Current, tr1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb2 = F1514_14805(loc1);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) loc1;
	} else {
		RTHOOK(4);
		tr1 = RTOPCF(15239,F1536_15239, (Current));
		Result = F1536_15242(Current, tr1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_ENVIRONMENT_I}.application_cell */
static EIF_REFERENCE F1536_15239_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("application_cell", 1535, Current, 0, 0, 21754);
	RTGC;
	RTOPP (15239);
#define Result RTOPR(15239)
	RTOC_GLOBAL(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {335,1537,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 335, _OBJSIZ_1_0_0_0_0_0_0_0_);
	}
	F336_5326(RTCW(tr1), NULL);
	Result = (EIF_REFERENCE) tr1;
	RTOPE (15239);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1536_15239 (EIF_REFERENCE Current)
{
	GTCX
	return RTOPCF(15239,F1536_15239_body,(Current));
}

/* {EV_ENVIRONMENT_I}.application_cell_item */
EIF_REFERENCE F1536_15241 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	
	
	RTEAA("application_cell_item", 1535, Current, 0, 1, 21756);
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {EV_ENVIRONMENT_I}.new_application_i */
EIF_REFERENCE F1536_15242 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,loc4);
	RTLR(5,Current);
	RTLIU(6);
	
	RTEAA("new_application_i", 1535, Current, 4, 1, 21757);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc3 = tr1;
	if ((EIF_BOOLEAN) !EIF_TEST(loc3)) {
		RTHOOK(2);
		Result = RTLNS(eif_new_type(1538, 0x00).id, 1538, _OBJSIZ_49_16_0_20_0_5_0_0_);
		F1539_15359(RTCW(Result));
		RTHOOK(3);
		F336_5326(RTCW(arg1), Result);
	} else {
		RTHOOK(4);
		loc4 = loc3;
		if (EIF_TEST(loc4)) {
			RTHOOK(5);
			tb1 = F1514_14805(loc4);
			if (tb1) {
				RTHOOK(6);
				Result = RTLNS(eif_new_type(1538, 0x00).id, 1538, _OBJSIZ_49_16_0_20_0_5_0_0_);
				F1539_15359(RTCW(Result));
				RTHOOK(7);
				F336_5326(RTCW(arg1), Result);
			} else {
				RTHOOK(8);
				RTHOOK(9);
				RTLE;
				RTEE;
				return (EIF_REFERENCE) loc4;
			}
		} else {
			RTHOOK(10);
			RTCT0("is_same_processor", EX_CHECK);
				RTCF0;
		}
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_ENVIRONMENT_I}.destroy */
void F1536_15243 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("destroy", 1535, Current, 0, 0, 21758);
	RTHOOK(1);
	F1514_14821(Current, (EIF_BOOLEAN) 1);
	RTHOOK(2);
	RTEE;
}

void EIF_Minit826 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
