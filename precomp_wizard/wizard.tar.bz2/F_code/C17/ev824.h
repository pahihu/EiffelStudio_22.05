
#ifndef _C17_ev824_
#define _C17_ev824_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1534_15194(EIF_REFERENCE);
extern void F1534_15195(EIF_REFERENCE);
extern EIF_REFERENCE F1534_15200(EIF_REFERENCE);
extern EIF_INTEGER_32 F1534_15208(EIF_REFERENCE);
extern EIF_INTEGER_32 F1534_15209(EIF_REFERENCE, EIF_INTEGER_32, EIF_BOOLEAN, EIF_BOOLEAN, EIF_BOOLEAN);
extern void EIF_Minit824(void);
extern void F916_8909(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
