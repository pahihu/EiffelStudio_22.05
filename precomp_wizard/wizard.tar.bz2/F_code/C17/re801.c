/*
 * Code for class reference REAL_64
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "re801.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {REAL_64}.is_less */
EIF_BOOLEAN F1510_14718 (EIF_REFERENCE Current, EIF_REAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_less", 1509, Current, 0, 1, 21385);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1510, 0x00).id, 1510, _OBJSIZ_0_0_0_0_0_0_0_1_);
	*(EIF_REAL_64 *)tr1 = arg1;
	Result = F1509_14688(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {REAL_64}.is_nan */
EIF_BOOLEAN F1510_14719 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_nan", 1509, Current, 0, 0, 21386);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) F1509_14694(Current);
}

/* {REAL_64}.is_negative_infinity */
EIF_BOOLEAN F1510_14720 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_negative_infinity", 1509, Current, 0, 0, 21387);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) F1509_14695(Current);
}

/* {REAL_64}.is_positive_infinity */
EIF_BOOLEAN F1510_14721 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_positive_infinity", 1509, Current, 0, 0, 21388);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) F1509_14696(Current);
}

/* {REAL_64}.truncated_to_integer */
EIF_INTEGER_32 F1510_14722 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("truncated_to_integer", 1509, Current, 0, 0, 21389);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) F1509_14699(Current);
}

/* {REAL_64}.truncated_to_integer_64 */
EIF_INTEGER_64 F1510_14723 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("truncated_to_integer_64", 1509, Current, 0, 0, 21390);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_64) F1509_14700(Current);
}

/* {REAL_64}.truncated_to_real */
EIF_REAL_32 F1510_14724 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("truncated_to_real", 1509, Current, 0, 0, 21391);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REAL_32) F1509_14701(Current);
}

/* {REAL_64}.floor_real_64 */
EIF_REAL_64 F1510_14726 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("floor_real_64", 1509, Current, 0, 0, 21369);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REAL_64) F1509_14706(Current);
}

/* {REAL_64}.plus */
EIF_REAL_64 F1510_14727 (EIF_REFERENCE Current, EIF_REAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("plus", 1509, Current, 0, 1, 21370);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1510, 0x00).id, 1510, _OBJSIZ_0_0_0_0_0_0_0_1_);
	*(EIF_REAL_64 *)tr1 = arg1;
	tr1 = F1509_14709(Current, tr1);
	Result = *(EIF_REAL_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {REAL_64}.minus */
EIF_REAL_64 F1510_14728 (EIF_REFERENCE Current, EIF_REAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("minus", 1509, Current, 0, 1, 21371);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1510, 0x00).id, 1510, _OBJSIZ_0_0_0_0_0_0_0_1_);
	*(EIF_REAL_64 *)tr1 = arg1;
	tr1 = F1509_14710(Current, tr1);
	Result = *(EIF_REAL_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {REAL_64}.product */
EIF_REAL_64 F1510_14729 (EIF_REFERENCE Current, EIF_REAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("product", 1509, Current, 0, 1, 21372);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1510, 0x00).id, 1510, _OBJSIZ_0_0_0_0_0_0_0_1_);
	*(EIF_REAL_64 *)tr1 = arg1;
	tr1 = F1509_14711(Current, tr1);
	Result = *(EIF_REAL_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {REAL_64}.quotient */
EIF_REAL_64 F1510_14730 (EIF_REFERENCE Current, EIF_REAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("quotient", 1509, Current, 0, 1, 21373);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1510, 0x00).id, 1510, _OBJSIZ_0_0_0_0_0_0_0_1_);
	*(EIF_REAL_64 *)tr1 = arg1;
	tr1 = F1509_14712(Current, tr1);
	Result = *(EIF_REAL_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {REAL_64}.power */
EIF_REAL_64 F1510_14731 (EIF_REFERENCE Current, EIF_REAL_64 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("power", 1509, Current, 0, 1, 21374);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REAL_64) F1509_14713(Current, arg1);
}

/* {REAL_64}.opposite */
EIF_REAL_64 F1510_14733 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("opposite", 1509, Current, 0, 0, 21376);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return *(EIF_REAL_64 *)F1509_14715(Current);
}

/* {REAL_64}.out */
EIF_REFERENCE F1510_14741 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("out", 1509, Current, 0, 0, 21384);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) F1509_14716(Current);
}

void EIF_Minit801 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
