/*
 * Code for class EV_MENU_ITEM_LIST_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev833.h"
#include <ev_any_imp.h>
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F1548_15579
static EIF_REFERENCE inline_F1548_15579 (EIF_POINTER arg1)
{
	return (EIF_REFERENCE) (c_ev_any_imp_get_eif_reference_from_object_id (arg1))
	;
}
#define INLINE_F1548_15579
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_MENU_ITEM_LIST_IMP}.insert_i_th */
void F1547_15563 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_POINTER loc6 = (EIF_POINTER) 0;
	EIF_POINTER loc7 = (EIF_POINTER) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc3);
	RTLR(4,loc8);
	RTLR(5,tr1);
	RTLR(6,loc4);
	RTLR(7,loc5);
	RTLIU(8);
	
	RTEAA("insert_i_th", 1546, Current, 8, 2, 22056);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1678, 0x00), loc1);
	RTHOOK(2);
	RTCT0("an_item_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(3);
	loc2 = *(EIF_INTEGER_32 *)(Current + O12739[dtype-1540]);
	RTHOOK(4);
	F1547_15564(Current, loc1, arg2);
	RTHOOK(5);
	loc3 = loc1;
	loc3 = RTRV(eif_new_type(1681, 0x00), loc3);
	RTHOOK(6);
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		
		RTHOOK(8);
		F1541_15527(Current, (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L)));
		for (;;) {
			RTHOOK(9);
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O12739[dtype-1540]) == (EIF_INTEGER_32) (F1542_15549(Current) + ((EIF_INTEGER_32) 1L)))) {
				tb2 = '\0';
				tr1 = F1542_15548(Current, *(EIF_INTEGER_32 *)(Current + O12739[dtype-1540]));
				loc8 = tr1;
				if (EIF_TEST(loc8)) {
					tr1 = *(EIF_REFERENCE *)(loc8 + _REFACS_3_);
					tb2 = F1547_15566(Current, tr1);
				}
				tb1 = tb2;
			}
			if (tb1) break;
			RTHOOK(10);
			loc4 = F1542_15548(Current, *(EIF_INTEGER_32 *)(Current + O12739[dtype-1540]));
			loc4 = RTRV(eif_new_type(1680, 0x00), loc4);
			RTHOOK(11);
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				RTHOOK(12);
				tp1 = (RTNA((RTCW(loc3))), ((EIF_POINTER) 0));
				(RTNA((RTCW(loc4), tp1)));
				RTHOOK(13);
				tp1 = (RTNA((RTCW(loc3))), ((EIF_POINTER) 0));
				if ((EIF_BOOLEAN)(tp1 != loc7)) {
					RTHOOK(14);
					tp1 = *(EIF_POINTER *)(RTCW(loc4)+ _PTROFF_26_8_6_2_0_0_);
					gtk_check_menu_item_set_active((GtkCheckMenuItem*) tp1, (gboolean) (EIF_BOOLEAN) 0);
				}
				RTHOOK(15);
				tp1 = (RTNA((RTCW(loc4))), ((EIF_POINTER) 0));
				(RTNA((RTCW(loc3), tp1)));
			}
			RTHOOK(16);
			F1541_15526(Current);
		}
	} else {
		RTHOOK(17);
		loc4 = loc1;
		loc4 = RTRV(eif_new_type(1680, 0x00), loc4);
		RTHOOK(18);
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			RTHOOK(19);
			loc3 = F1547_15565(Current, arg2);
			RTHOOK(20);
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				RTHOOK(21);
				tp1 = (RTNA((RTCW(loc3))), ((EIF_POINTER) 0));
				(RTNA((RTCW(loc4), tp1)));
				RTHOOK(22);
				tp1 = (RTNA((RTCW(loc3))), ((EIF_POINTER) 0));
				{
					/* INLINED CODE (ANY.default_pointer) */
					tp2 = (EIF_POINTER)  0;
					/* END INLINED CODE */
				}
				if ((EIF_BOOLEAN)(tp1 != tp2)) {
					RTHOOK(23);
					tp1 = *(EIF_POINTER *)(RTCW(loc4)+ _PTROFF_26_8_6_2_0_0_);
					gtk_check_menu_item_set_active((GtkCheckMenuItem*) tp1, (gboolean) (EIF_BOOLEAN) 0);
				}
				RTHOOK(24);
				tp1 = (RTNA((RTCW(loc4))), ((EIF_POINTER) 0));
				(RTNA((RTCW(loc3), tp1)));
			} else {
				RTHOOK(25);
				(RTNA((RTCW(loc4), F1547_15570(Current))));
				RTHOOK(26);
				loc6 = (RTNA((RTCW(loc4))), ((EIF_POINTER) 0));
				RTHOOK(27);
				{
					/* INLINED CODE (ANY.default_pointer) */
					tp1 = (EIF_POINTER)  0;
					/* END INLINED CODE */
				}
				if ((EIF_BOOLEAN)(F1547_15570(Current) != tp1)) {
					RTHOOK(28);
					tp1 = *(EIF_POINTER *)(RTCW(loc4)+ _PTROFF_26_8_6_2_0_0_);
					gtk_check_menu_item_set_active((GtkCheckMenuItem*) tp1, (gboolean) (EIF_BOOLEAN) 0);
				}
				RTHOOK(29);
				tp1 = (RTNA((RTCW(loc4))), ((EIF_POINTER) 0));
				F1547_15569(Current, tp1);
			}
		}
	}
	RTHOOK(30);
	if ((EIF_BOOLEAN) !F1547_15566(Current, loc1)) {
		RTHOOK(31);
		loc5 = loc1;
		loc5 = RTRV(eif_new_type(1679, 0x00), loc5);
		RTHOOK(32);
		if ((EIF_BOOLEAN)(loc5 != NULL)) {
			RTHOOK(33);
			tb2 = (RTNA((RTCW(loc5))), ((EIF_BOOLEAN) 0));
			if (tb2) {
				RTHOOK(34);
				(RTNA((RTCW(loc5))));
			}
		}
	}
	RTHOOK(35);
	F1541_15527(Current, loc2);
	RTHOOK(36);
	RTLE;
	RTEE;
}

/* {EV_MENU_ITEM_LIST_IMP}.insert_menu_item */
void F1547_15564 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("insert_menu_item", 1546, Current, 0, 2, 22057);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_26_8_6_2_0_4_);
	tp2 = F1679_17561(RTCW(arg1));
	gtk_menu_shell_insert((GtkMenuShell*) tp1, (GtkWidget*) tp2, (gint) (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + O12773[dtype-1541]);
	F892_8815(RTCW(tr1), arg2);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + O12773[dtype-1541]);
	tr2 = F1514_14806(RTCW(arg1));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7881[Dtype(RTCW(tr1))-891])(tr1, tr2);
	RTHOOK(4);
	F1672_17538(RTCW(arg1), Current);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_MENU_ITEM_LIST_IMP}.separator_imp_by_index */
EIF_REFERENCE F1547_15565 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("separator_imp_by_index", 1546, Current, 3, 1, 22058);
	RTGC;
	RTHOOK(1);
	loc1 = F1541_15514(Current);
	RTHOOK(2);
	F1541_15524(Current);
	RTHOOK(3);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(4);
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O12739[dtype-1540]) == (EIF_INTEGER_32) (F1542_15549(Current) + ((EIF_INTEGER_32) 1L)))) {
			tb1 = (EIF_BOOLEAN)(arg1 == loc2);
		}
		if (tb1) break;
		RTHOOK(5);
		loc3 = F1542_15548(Current, *(EIF_INTEGER_32 *)(Current + O12739[dtype-1540]));
		loc3 = RTRV(eif_new_type(1404, 0x00), loc3);
		RTHOOK(6);
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			RTHOOK(7);
			Result = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_3_);
			Result = RTRV(eif_new_type(1681, 0x00), Result);
		}
		RTHOOK(8);
		F1541_15526(Current);
		RTHOOK(9);
		loc2++;
	}
	RTHOOK(10);
	F1541_15528(Current, loc1);
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_MENU_ITEM_LIST_IMP}.is_menu_separator_imp */
EIF_BOOLEAN F1547_15566 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("is_menu_separator_imp", 1546, Current, 1, 1, 22059);
	RTGC;
	RTHOOK(1);
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(1681, 0x00), loc1);
	RTHOOK(2);
	RTHOOK(3);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(loc1 != NULL);
}

/* {EV_MENU_ITEM_LIST_IMP}.remove_i_th */
void F1547_15567 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_POINTER loc6 = (EIF_POINTER) 0;
	EIF_POINTER loc7 = (EIF_POINTER) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc8);
	RTLIU(6);
	
	RTEAA("remove_i_th", 1546, Current, 8, 1, 22060);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O12773[dtype-1541]);
	tr1 = F892_8786(RTCW(tr1), arg1);
	loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1671, 0x00), loc1);
	RTHOOK(2);
	RTCT0("item_imp_not_void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(3);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_26_8_6_2_0_4_);
	tp2 = *(EIF_POINTER *)(RTCW(loc1) + O12790[Dtype(loc1)-1547]);
	gtk_container_remove((GtkContainer*) tp1, (GtkWidget*) tp2);
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current + O12773[dtype-1541]);
	F892_8815(RTCW(tr1), arg1);
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(Current + O12773[dtype-1541]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R7675[Dtype(RTCW(tr1))-780])(tr1);
	RTHOOK(6);
	F1672_17538(RTCW(loc1), NULL);
	RTHOOK(7);
	loc2 = loc1;
	loc2 = RTRV(eif_new_type(1680, 0x00), loc2);
	RTHOOK(8);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTHOOK(9);
		tb1 = (RTNA((RTCW(loc2))), ((EIF_BOOLEAN) 0));
		if (tb1) {
			RTHOOK(10);
			tp1 = (RTNA((RTCW(loc2))), ((EIF_POINTER) 0));
			if ((EIF_BOOLEAN) ((EIF_INTEGER_32) g_slist_length((GSList*) tp1) > ((EIF_INTEGER_32) 1L))) {
				RTHOOK(11);
				tp1 = (RTNA((RTCW(loc2))), ((EIF_POINTER) 0));
				loc6 = (EIF_POINTER) g_slist_nth_data((GSList*) tp1, (guint) ((EIF_INTEGER_32) 0L));
				RTHOOK(12);
				tp1 = *(EIF_POINTER *)(RTCW(loc2)+ _PTROFF_26_8_6_2_0_0_);
				if ((EIF_BOOLEAN)(loc6 == tp1)) {
					RTHOOK(13);
					tp1 = (RTNA((RTCW(loc2))), ((EIF_POINTER) 0));
					loc6 = (EIF_POINTER) g_slist_nth_data((GSList*) tp1, (guint) ((EIF_INTEGER_32) 1L));
				}
				RTHOOK(14);
				loc2 = inline_F1548_15579(loc6);
				loc2 = RTRV(eif_new_type(1680, 0x00), loc2);
				RTHOOK(15);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					RTHOOK(16);
					(RTNA((RTCW(loc2))));
				}
			}
		}
		RTHOOK(17);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			RTHOOK(18);
			tp1 = *(EIF_POINTER *)(RTCW(loc2)+ _PTROFF_26_8_6_2_0_0_);
			gtk_radio_menu_item_set_group((GtkRadioMenuItem*) tp1, (GSList*) loc7);
		}
	} else {
		RTHOOK(19);
		loc3 = loc1;
		loc3 = RTRV(eif_new_type(1681, 0x00), loc3);
		RTHOOK(20);
		loc8 = *(EIF_REFERENCE *)(Current + O12205[dtype-1513]);
		RTHOOK(21);
		RTCT0("l_interface /= Void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc8 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		RTHOOK(22);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			ti4_1 = F1341_12727(RTCW(loc8));
			tb1 = (EIF_BOOLEAN) (arg1 <= ti4_1);
		}
		if (tb1) {
			RTHOOK(23);
			loc3 = F1547_15565(Current, arg1);
			RTHOOK(24);
			loc4 = F1341_12721(RTCW(loc8));
			RTHOOK(25);
			F1341_12733(RTCW(loc8), arg1);
			for (;;) {
				RTHOOK(26);
				tb1 = '\01';
				tb2 = F859_8654(RTCW(loc8));
				if (!tb2) {
					tr1 = F1341_12720(RTCW(loc8));
					tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
					tb1 = F1547_15566(Current, tr1);
				}
				if (tb1) break;
				RTHOOK(27);
				tr1 = F1341_12720(RTCW(loc8));
				loc2 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
				loc2 = RTRV(eif_new_type(1680, 0x00), loc2);
				RTHOOK(28);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					RTHOOK(29);
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					RTHOOK(30);
					if ((EIF_BOOLEAN)(loc3 != NULL)) {
						RTHOOK(31);
						tp1 = (RTNA((RTCW(loc3))), ((EIF_POINTER) 0));
						(RTNA((RTCW(loc2), tp1)));
						RTHOOK(32);
						tp1 = (RTNA((RTCW(loc2))), ((EIF_POINTER) 0));
						(RTNA((RTCW(loc3), tp1)));
					} else {
						RTHOOK(33);
						(RTNA((RTCW(loc2), F1547_15570(Current))));
						RTHOOK(34);
						tp1 = (RTNA((RTCW(loc2))), ((EIF_POINTER) 0));
						F1547_15569(Current, tp1);
					}
					RTHOOK(35);
					(RTNA((RTCW(loc2))));
				}
				RTHOOK(36);
				F1341_12732(RTCW(loc8));
			}
			RTHOOK(37);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc5 && (EIF_BOOLEAN)(loc3 == NULL))) {
				RTHOOK(38);
				F1547_15569(Current, loc7);
			}
			RTHOOK(39);
			F1341_12733(RTCW(loc8), loc4);
		}
	}
	RTHOOK(40);
	RTLE;
	RTEE;
}

/* {EV_MENU_ITEM_LIST_IMP}.radio_group_ref */
EIF_REFERENCE F1547_15568 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("radio_group_ref", 1546, Current, 1, 0, 22061);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		loc1 = RTLNS(eif_new_type(1196, 0x00).id, 1196, _OBJSIZ_0_0_0_0_0_1_0_0_);
		RTHOOK(4);
		tr1 = RTCCL(loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(5);
	RTHOOK(6);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) loc1;
}

/* {EV_MENU_ITEM_LIST_IMP}.set_radio_group */
void F1547_15569 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("set_radio_group", 1546, Current, 0, 1, 22062);
	RTGC;
	RTHOOK(1);
	tr1 = F1547_15568(Current);
	F1197_10976(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_MENU_ITEM_LIST_IMP}.radio_group */
EIF_POINTER F1547_15570 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("radio_group", 1546, Current, 0, 0, 22063);
	RTGC;
	RTHOOK(1);
	Result = *(EIF_POINTER *)(RTCV(F1547_15568(Current))+ _PTROFF_0_0_0_0_0_0_);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit833 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
