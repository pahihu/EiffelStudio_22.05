/*
 * Code for class EV_HELP_CONTEXTABLE_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev816.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_HELP_CONTEXTABLE_I}.help_context */
EIF_REFERENCE F1526_15012 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,loc3);
	RTLR(4,tr1);
	RTLR(5,loc4);
	RTLIU(6);
	
	RTEAA("help_context", 1525, Current, 4, 0, 21602);
	RTGC;
	RTHOOK(1);
	loc1 = Current;
	loc1 = RTRV(eif_new_type(1587, 0x00), loc1);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		for (;;) {
			RTHOOK(3);
			if (loc2) break;
			RTHOOK(4);
			Result = *(EIF_REFERENCE *)(RTCW(loc1) + O12347[Dtype(loc1)-1525]);
			RTHOOK(5);
			tb1 = '\0';
			tr1 = F1589_16150(RTCW(loc1));
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				tr1 = *(EIF_REFERENCE *)(loc3 + O9889[Dtype(loc3)-1247]);
				loc4 = tr1;
				tb1 = EIF_TEST(loc4);
			}
			if (tb1) {
				RTHOOK(6);
				loc1 = (EIF_REFERENCE) loc4;
			} else {
				RTHOOK(7);
				loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		}
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_HELP_CONTEXTABLE_I}.set_help_context */
void F1526_15013 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("set_help_context", 1525, Current, 1, 1, 21603);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O12347[Dtype(Current)-1525]) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	F1588_16137(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

void EIF_Minit816 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
