/*
 * Code for class EV_ENVIRONMENT_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev827.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_ENVIRONMENT_IMP}.make */
void F1537_15245 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("make", 1536, Current, 0, 0, 21761);
	RTHOOK(1);
	F1514_14820(Current, (EIF_BOOLEAN) 1);
	RTHOOK(2);
	RTEE;
}

void EIF_Minit827 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
