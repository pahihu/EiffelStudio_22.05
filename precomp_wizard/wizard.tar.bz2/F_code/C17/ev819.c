/*
 * Code for class EV_FONT_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev819.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_FONT_I}.set_values */
void F1529_15059 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_REFERENCE arg5)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg5);
	RTLIU(2);
	
	RTEAA("set_values", 1528, Current, 0, 5, 21638);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) != arg5)) {
		RTHOOK(2);
		F1529_15080(Current, arg5);
		RTHOOK(3);
		F1530_15113(Current);
	}
	RTHOOK(4);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_7_) != arg1)) {
		RTHOOK(5);
		F1530_15090(Current, arg1);
	}
	RTHOOK(6);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_5_) != arg2)) {
		RTHOOK(7);
		F1530_15092(Current, arg2);
	}
	RTHOOK(8);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_4_) != arg3)) {
		RTHOOK(9);
		F1530_15093(Current, arg3);
	}
	RTHOOK(10);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_3_) != arg4)) {
		RTHOOK(11);
		F1530_15094(Current, arg4);
	}
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {EV_FONT_I}.copy_font */
void F1529_15076 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("copy_font", 1528, Current, 0, 1, 21633);
	RTGC;
	RTHOOK(1);
	ti4_1 = F1256_11654(RTCW(arg1));
	ti4_2 = F1256_11656(RTCW(arg1));
	ti4_3 = F1256_11657(RTCW(arg1));
	ti4_4 = F1256_11658(RTCW(arg1));
	tr1 = F1256_11661(RTCW(arg1));
	F1530_15096(Current, ti4_1, ti4_2, ti4_3, ti4_4, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_FONT_I}.copy_preferred_families */
void F1529_15080 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("copy_preferred_families", 1528, Current, 1, 1, 21635);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_3_);
	F916_8917(RTCW(tr1));
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_4_);
	F916_8917(RTCW(tr1));
	RTHOOK(4);
	F909_8887(RTCW(loc1));
	RTHOOK(5);
	F909_8876(RTCW(loc1), arg1);
	RTHOOK(6);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_3_);
	F916_8919(RTCW(tr1));
	RTHOOK(7);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_4_);
	F916_8919(RTCW(tr1));
	RTHOOK(8);
	RTLE;
	RTEE;
}

void EIF_Minit819 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
