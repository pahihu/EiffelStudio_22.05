/*
 * Code for class EV_APPLICATION_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev828.h"
#include "eif_built_in.h"
#include "eif_helpers.h"
#include "eif_memory.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_APPLICATION_I}.make */
void F1538_15254 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("make", 1537, Current, 1, 0, 21803);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {891,1230,0xFFF9,0,1186,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F892_8780(RTCW(tr1), ((EIF_INTEGER_32) 25L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_thread_capable__b) {
		RTHOOK(3);
		tr1 = RTLNSMART(eif_new_type(1138, 0).id);
		F1139_9669(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_33_) = (EIF_REFERENCE) tr1;
		RTHOOK(4);
		tr1 = RTLNSMART(eif_new_type(1138, 0).id);
		F1139_9669(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_34_) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(5);
	{
		static EIF_TYPE_INDEX typarr0[] = {809,1486,1486,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F810_8436(RTCW(tr1), ((EIF_INTEGER_32) 8L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_27_) = (EIF_REFERENCE) tr1;
	RTHOOK(6);
	{
		static EIF_TYPE_INDEX typarr0[] = {894,1486,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F895_8780(RTCW(tr1), ((EIF_INTEGER_32) 8L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_26_) = (EIF_REFERENCE) tr1;
	RTHOOK(7);
	tr1 = RTLNS(eif_new_type(313, 0x00).id, 313, _OBJSIZ_0_0_0_0_0_0_0_0_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_32_) = (EIF_REFERENCE) tr1;
	RTHOOK(8);
	loc1 = RTLNS(eif_new_type(1714, 0x00).id, 1714, _OBJSIZ_0_0_0_1_0_0_0_0_);
	F1715_18227(RTCW(loc1), ((EIF_INTEGER_32) 27L));
	RTHOOK(9);
	tr1 = RTLNSMART(eif_new_type(1301, 0).id);
	F1302_12540(RTCW(tr1), loc1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_30_) = (EIF_REFERENCE) tr1;
	RTHOOK(10);
	tr1 = RTLNSMART(eif_new_type(1301, 0).id);
	F1302_12540(RTCW(tr1), loc1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_31_) = (EIF_REFERENCE) tr1;
	RTHOOK(11);
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr1 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
	RTAR(tr1,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1230,0xFFF9,0,1186,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2= RTLNRF(typres0.id, (EIF_POINTER) __A828_300, (EIF_POINTER) _A828_300, (EIF_POINTER)(F1538_15351),tr1, 1, 0);
	}
	RTAR(Current, tr2);
	*(EIF_REFERENCE *)(Current + _REFACS_39_) = (EIF_REFERENCE) tr2;
	RTHOOK(12);
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr1 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
	RTAR(tr1,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1230,0xFFF9,0,1186,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2= RTLNRF(typres0.id, (EIF_POINTER) __A828_243, (EIF_POINTER) _A828_243, (EIF_POINTER)(F1538_15294),tr1, 1, 0);
	}
	RTAR(Current, tr2);
	*(EIF_REFERENCE *)(Current + _REFACS_40_) = (EIF_REFERENCE) tr2;
	RTHOOK(13);
	F1538_15285(Current, *(EIF_REFERENCE *)(Current + _REFACS_30_));
	RTHOOK(14);
	F1538_15286(Current, *(EIF_REFERENCE *)(Current + _REFACS_31_));
	RTHOOK(15);
	tr1 = RTOUCR(280,F1538_15345, (Current));
	F339_5326(RTCW(tr1), (EIF_BOOLEAN) 1);
	RTHOOK(16);
	tr1 = F210_3696(Current);
	F917_8946(RTCW(tr1), NULL);
	RTHOOK(17);
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_49_16_0_0_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(18);
	F1538_15283(Current, (EIF_BOOLEAN) 1);
	RTHOOK(19);
	F1514_14820(Current, (EIF_BOOLEAN) 1);
	RTHOOK(20);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_I}.process_event_queue */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F1538_15260 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN EIF_VOLATILE loc3 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE EIF_VOLATILE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc6 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc8 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_REFERENCE  EIF_VOLATILE tr2 = NULL;
	EIF_REFERENCE  EIF_VOLATILE tr3 = NULL;
	EIF_INTEGER_32  EIF_VOLATILE ti4_1;
	EIF_INTEGER_32  EIF_VOLATILE ti4_2;
	EIF_INTEGER_32  EIF_VOLATILE ti4_3;
	EIF_INTEGER_32  EIF_VOLATILE ti4_4;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_BOOLEAN  EIF_VOLATILE tb2;
	EIF_BOOLEAN  EIF_VOLATILE tb3;
	RTLD;
	RTXD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc6);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,loc5);
	RTLR(7,saved_except);
	RTLIU(8);
	RTXSLS;
	
	RTEAA("process_event_queue", 1537, Current, 8, 1, 21811);
	RTGC;
	RTE_T
	RTHOOK(1);
	if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		F1539_15386(Current);
		RTHOOK(3);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_49_2_)) {
			RTHOOK(4);
			*(EIF_NATURAL_32 *)(Current+ _LNGOFF_49_16_0_0_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
		} else {
			RTHOOK(5);
			if ((EIF_BOOLEAN) (arg1 && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_49_1_))) {
				RTHOOK(6);
				(*(EIF_NATURAL_32 *)(Current+ _LNGOFF_49_16_0_0_)) += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
				RTHOOK(7);
				if ((EIF_BOOLEAN)(*(EIF_NATURAL_32 *)(Current+ _LNGOFF_49_16_0_0_) == ((EIF_NATURAL_32) 1500U))) {
					RTHOOK(8);
					if (*(EIF_BOOLEAN *)(Current+ _CHROFF_49_3_)) {
						RTHOOK(9);
						plsc();
						RTHOOK(10);
						eif_mem_coalesc();
					}
					RTHOOK(11);
					*(EIF_NATURAL_32 *)(Current+ _LNGOFF_49_16_0_0_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
				}
			} else {
				RTHOOK(12);
				*(EIF_NATURAL_32 *)(Current+ _LNGOFF_49_16_0_0_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
			}
		}
		RTHOOK(13);
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		RTHOOK(14);
		tb1 = '\0';
		tb2 = '\0';
		if ((EIF_BOOLEAN) !F1514_14805(Current)) {
			tb2 = (EIF_BOOLEAN)(loc1 != NULL);
		}
		if (tb2) {
			tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_49_1_);
		}
		if (tb1) {
			RTHOOK(15);
			if (F1538_15302(Current)) {
				RTHOOK(16);
				loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				RTHOOK(17);
				if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_25_) == NULL)) {
					RTHOOK(18);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					ti4_1 = F892_8801(RTCW(tr1));
					if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
						RTHOOK(19);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						tr1 = F892_8784(RTCW(tr1));
						tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_25_) = (EIF_REFERENCE) tr1;
						RTHOOK(20);
						loc6 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
					}
				} else {
					RTHOOK(21);
					tb1 = '\0';
					if (*(EIF_BOOLEAN *)(Current+ _CHROFF_49_0_)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
						ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
						tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
					}
					if (tb1) {
						RTHOOK(22);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
						tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						ti4_1 = F892_8801(RTCW(tr2));
						tr1 = F1408_13479(RTCW(tr1), ti4_1);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_25_) = (EIF_REFERENCE) tr1;
					} else {
						RTHOOK(23);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
						tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						ti4_1 = F892_8801(RTCW(tr2));
						tr1 = (EIF_REFERENCE) eif_builtin_SPECIAL_aliased_resized_area__i4_s (tr1, ti4_1);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_25_) = (EIF_REFERENCE) tr1;
					}
					RTHOOK(24);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
					tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					tr2 = F892_8784(RTCW(tr2));
					tr3 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					ti4_1 = F892_8801(RTCW(tr3));
					/* INLINED CODE (SPECIAL.copy_data) */
					sp_copy_data(RTCW(tr1),tr2,((EIF_INTEGER_32) 0L),((EIF_INTEGER_32) 0L),ti4_1);
					RT_SPECIAL_COUNT(tr1) = eif_max_int32(RT_SPECIAL_COUNT(tr1), ((EIF_INTEGER_32) 0L) + ti4_1);
					/* END INLINED CODE */
					;
					RTHOOK(25);
					loc6 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
				}
				RTHOOK(26);
				if ((EIF_BOOLEAN)(loc6 != NULL)) {
					RTHOOK(27);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					(FUNCTION_CAST(void, (EIF_REFERENCE)) R7661[Dtype(RTCW(tr1))-780])(tr1);
				}
				RTHOOK(28);
				F1538_15303(Current);
				RTHOOK(29);
				loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
			RTHOOK(30);
			if (F1538_15299(Current)) {
				RTHOOK(31);
				loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				RTHOOK(32);
				if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_24_) == NULL)) {
					RTHOOK(33);
					ti4_1 = F892_8801(RTCW(loc1));
					if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
						RTHOOK(34);
						tr1 = F892_8784(RTCW(loc1));
						tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_24_) = (EIF_REFERENCE) tr1;
						RTHOOK(35);
						loc5 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					}
				} else {
					RTHOOK(36);
					tb1 = '\0';
					if (*(EIF_BOOLEAN *)(Current+ _CHROFF_49_0_)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
						ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
						tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
					}
					if (tb1) {
						RTHOOK(37);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
						ti4_1 = F892_8801(RTCW(loc1));
						tr1 = F1408_13479(RTCW(tr1), ti4_1);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_24_) = (EIF_REFERENCE) tr1;
					} else {
						RTHOOK(38);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
						ti4_1 = F892_8801(RTCW(loc1));
						tr1 = (EIF_REFERENCE) eif_builtin_SPECIAL_aliased_resized_area__i4_s (tr1, ti4_1);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_24_) = (EIF_REFERENCE) tr1;
					}
					RTHOOK(39);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr2 = F892_8784(RTCW(loc1));
					ti4_1 = F892_8801(RTCW(loc1));
					/* INLINED CODE (SPECIAL.copy_data) */
					sp_copy_data(RTCW(tr1),tr2,((EIF_INTEGER_32) 0L),((EIF_INTEGER_32) 0L),ti4_1);
					RT_SPECIAL_COUNT(tr1) = eif_max_int32(RT_SPECIAL_COUNT(tr1), ((EIF_INTEGER_32) 0L) + ti4_1);
					/* END INLINED CODE */
					;
					RTHOOK(40);
					loc5 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				}
				RTHOOK(41);
				F1538_15300(Current);
				RTHOOK(42);
				loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
			RTHOOK(43);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_49_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			RTHOOK(44);
			if ((EIF_BOOLEAN)(loc6 != NULL)) {
				RTHOOK(45);
				loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				RTHOOK(46);
				loc8 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc6);
				for (;;) {
					RTHOOK(47);
					tb1 = '\01';
					if (!(EIF_BOOLEAN)(loc7 == loc8)) {
						tb1 = F1514_14805(Current);
					}
					if (tb1) break;
					RTHOOK(48);
					/* INLINED CODE (SPECIAL.item) */
					tr2 = *((EIF_REFERENCE *)RTCW(loc6) + (loc7));
					/* END INLINED CODE */
					tr1 = tr2;
					F1538_15262(Current, tr1);
					RTHOOK(49);
					loc7++;
				}
				RTHOOK(50);
				F1408_13484(RTCW(loc6));
			}
			RTHOOK(51);
			if ((EIF_BOOLEAN)(loc5 != NULL)) {
				RTHOOK(52);
				loc8 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc5);
				RTHOOK(53);
				loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				for (;;) {
					RTHOOK(54);
					tb2 = '\01';
					if (!(EIF_BOOLEAN)(loc7 == loc8)) {
						tb2 = F1514_14805(Current);
					}
					if (tb2) break;
					RTHOOK(55);
					/* INLINED CODE (SPECIAL.item) */
					tr2 = *((EIF_REFERENCE *)RTCW(loc5) + (loc7));
					/* END INLINED CODE */
					tr1 = tr2;
					(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE)) *(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_4_2_0_3_0_0_))(
						*(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_4_2_0_3_0_1_),
						*(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_));
					RTHOOK(56);
					loc7++;
				}
				RTHOOK(57);
				F1408_13484(RTCW(loc5));
			}
			RTHOOK(58);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_49_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			RTHOOK(59);
			tb3 = '\0';
			if (arg1) {
				tb3 = (EIF_BOOLEAN) !F1514_14805(Current);
			}
			if (tb3) {
				RTHOOK(60);
				F1539_15386(Current);
				RTHOOK(61);
				tb3 = '\0';
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_49_1_)) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					ti4_1 = F892_8801(RTCW(tr1));
					tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
				}
				if (tb3) {
					RTHOOK(62);
					F1539_15384(Current, ((EIF_INTEGER_32) 20L));
				}
			}
		}
	} else {
		RTHOOK(63);
		if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 1L))) {
			RTHOOK(64);
			tr1 = F1538_15342(Current);
			F1538_15337(Current, tr1);
		}
	}
	RTE_E
	RTXSC;
	RTHOOK(65);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_49_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(66);
	if (loc3) {
		RTHOOK(67);
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		RTHOOK(68);
		F1538_15303(Current);
	}
	RTHOOK(69);
	if (loc2) {
		RTHOOK(70);
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		RTHOOK(71);
		F1538_15300(Current);
	}
	RTHOOK(72);
	if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
		RTHOOK(73);
		loc4++;
		RTHOOK(74);
		RTER;
	}
	/* NOTREACHED */
	RTE_EE
	RTHOOK(75);
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {EV_APPLICATION_I}.call_separate_action */
void F1538_15262 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("call_separate_action", 1537, Current, 0, 1, 21813);
	RTHOOK(1);
	F1231_11046(RTCW(arg1), NULL);
	RTHOOK(2);
	RTEE;
}

/* {EV_APPLICATION_I}.set_invoke_garbage_collection_when_inactive */
void F1538_15283 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_invoke_garbage_collection_when_inactive", 1537, Current, 0, 1, 21827);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_49_3_) = (EIF_BOOLEAN) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EV_APPLICATION_I}.set_captured_widget */
void F1538_15284 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_captured_widget", 1537, Current, 0, 1, 21828);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_29_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {EV_APPLICATION_I}.set_help_accelerator */
void F1538_15285 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_help_accelerator", 1537, Current, 0, 1, 21829);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_30_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_39_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
		tr1 = F1302_12541(RTCW(tr1));
		tb2 = F892_8792(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_39_));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
		tr1 = F1302_12541(RTCW(tr1));
		F909_8875(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_39_));
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_I}.set_contextual_help_accelerator */
void F1538_15286 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_contextual_help_accelerator", 1537, Current, 0, 1, 21830);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_31_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_40_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
		tr1 = F1302_12541(RTCW(tr1));
		tb2 = F892_8792(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_40_));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
		tr1 = F1302_12541(RTCW(tr1));
		F909_8875(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_40_));
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_I}.set_help_engine */
void F1538_15287 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_help_engine", 1537, Current, 0, 1, 21831);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_32_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {EV_APPLICATION_I}.set_locked_window */
void F1538_15288 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_locked_window", 1537, Current, 0, 1, 21832);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_28_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EV_APPLICATION_I}.process_events */
void F1538_15289 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("process_events", 1537, Current, 0, 0, 21833);
	RTHOOK(1);
	F1538_15260(Current, (EIF_BOOLEAN) 0);
	RTHOOK(2);
	RTEE;
}

/* {EV_APPLICATION_I}.enable_contextual_help */
void F1538_15294 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("enable_contextual_help", 1537, Current, 1, 0, 21836);
	RTGC;
	RTHOOK(1);
	tr1 = F1539_15383(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_29_) = (EIF_REFERENCE) loc1;
		RTHOOK(3);
		tr1 = F1178_10667(loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_38_) = (EIF_REFERENCE) tr1;
		RTHOOK(4);
		tr1 = F1178_10667(loc1);
		F909_8887(RTCW(tr1));
		RTHOOK(5);
		tr1 = F1178_10667(loc1);
		tr2 = RTOUCR(281,F1538_15353, (Current));
		F916_8913(RTCW(tr1), tr2);
		RTHOOK(6);
		tr1 = F1347_12794(loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_37_) = (EIF_REFERENCE) tr1;
		RTHOOK(7);
		tr1 = RTLNS(eif_new_type(65, 0x00).id, 65, _OBJSIZ_0_0_0_0_0_0_0_0_);
		tr1 = RTOUCR(282,F66_1137, (RTCW(tr1)));
		F1347_12815(loc1, tr1);
		RTHOOK(8);
		F1347_12807(loc1);
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_I}.display_help_for_widget */
void F1538_15295 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("display_help_for_widget", 1537, Current, 1, 1, 21837);
	RTGC;
	RTHOOK(1);
	loc1 = F1261_11754(RTCW(arg1));
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
		tr2 = F1232_11050(RTCW(loc1), NULL);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4932[Dtype(RTCW(tr1))-313])(tr1, tr2);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_I}.try_idle_lock */
EIF_BOOLEAN F1538_15299 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("try_idle_lock", 1537, Current, 0, 0, 21841);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_33_) != NULL)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
		Result = F1139_9673(RTCW(tr1));
	} else {
		RTHOOK(3);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_APPLICATION_I}.idle_unlock */
void F1538_15300 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("idle_unlock", 1537, Current, 0, 0, 21842);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_33_) != NULL)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
		F1139_9674(RTCW(tr1));
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_I}.kamikaze_lock */
void F1538_15301 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("kamikaze_lock", 1537, Current, 0, 0, 21843);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_34_) != NULL)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
		F1139_9672(RTCW(tr1));
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_I}.try_kamikaze_lock */
EIF_BOOLEAN F1538_15302 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("try_kamikaze_lock", 1537, Current, 0, 0, 21844);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_34_) != NULL)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
		Result = F1139_9673(RTCW(tr1));
	} else {
		RTHOOK(3);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_APPLICATION_I}.kamikaze_unlock */
void F1538_15303 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("kamikaze_unlock", 1537, Current, 0, 0, 21845);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_34_) != NULL)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
		F1139_9674(RTCW(tr1));
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_I}.do_once_on_idle */
void F1538_15306 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("do_once_on_idle", 1537, Current, 0, 1, 21848);
	RTGC;
	RTHOOK(1);
	F1538_15301(Current);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tb1 = F892_8792(RTCW(tr1), arg1);
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7657[Dtype(RTCW(tr1))-780])(tr1, arg1);
	}
	RTHOOK(4);
	if ((EIF_BOOLEAN) !F1538_15344(Current)) {
		RTHOOK(5);
		{
			/* INLINED CODE (EV_APPLICATION_I.wake_up_gui_thread) */
			/* END INLINED CODE */
		}
		;
	}
	RTHOOK(6);
	F1538_15303(Current);
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_I}.increase_action_sequence_call_counter */
void F1538_15308 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("increase_action_sequence_call_counter", 1537, Current, 0, 0, 21850);
	RTHOOK(1);
	(*(EIF_NATURAL_32 *)(Current+ _LNGOFF_49_16_0_1_)) += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(2);
	RTEE;
}

/* {EV_APPLICATION_I}.pnd_screen */
static EIF_REFERENCE F1538_15315_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(283)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("pnd_screen", 1537, Current, 0, 0, 21855);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1280, 0x00).id, 1280, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1248_11522(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	F1279_11922(RTCW(Result));
	RTHOOK(3);
	tr1 = RTOUCR(284,F65_1097, (RTCV(RTOUCR(285,F1538_15316, (Current)))));
	F1265_11810(RTCW(Result), tr1);
	RTHOOK(4);
	F1279_11950(RTCW(Result));
	RTOTE;
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1538_15315 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(283,F1538_15315_body,(Current));
}

/* {EV_APPLICATION_I}.stock_colors */
static EIF_REFERENCE F1538_15316_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(285)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("stock_colors", 1537, Current, 0, 0, 21856);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(64, 0x00).id, 64, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1538_15316 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(285,F1538_15316_body,(Current));
}

/* {EV_APPLICATION_I}.set_x_y_origin */
void F1538_15319 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_x_y_origin", 1537, Current, 0, 2, 21859);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_7_) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_8_) = (EIF_INTEGER_32) arg2;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_I}.draw_rubber_band */
void F1538_15323 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("draw_rubber_band", 1537, Current, 0, 0, 21769);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(283,F1538_15315, (Current));
	F1279_11934(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_7_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_8_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_9_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_10_));
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_49_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_I}.erase_rubber_band */
void F1538_15324 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("erase_rubber_band", 1537, Current, 0, 0, 21770);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_49_4_)) {
		RTHOOK(2);
		tr1 = RTOUCR(283,F1538_15315, (Current));
		F1279_11934(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_7_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_8_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_9_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_10_));
		RTHOOK(3);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_49_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_I}.set_pnd_pointer_coords */
void F1538_15327 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_pnd_pointer_coords", 1537, Current, 0, 2, 21773);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_9_) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_10_) = (EIF_INTEGER_32) arg2;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_I}.create_target_menu */
void F1538_15328 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6, EIF_REFERENCE arg7, EIF_BOOLEAN arg8)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc10 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc12 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc13 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc22 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	RTCFDT;
	RTLD;
	
	RTLI(27);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc11);
	RTLR(3,loc3);
	RTLR(4,loc1);
	RTLR(5,loc7);
	RTLR(6,tr1);
	RTLR(7,tr2);
	RTLR(8,tr3);
	RTLR(9,tr4);
	RTLR(10,loc15);
	RTLR(11,loc16);
	RTLR(12,loc17);
	RTLR(13,arg6);
	RTLR(14,loc18);
	RTLR(15,arg7);
	RTLR(16,loc19);
	RTLR(17,loc4);
	RTLR(18,loc6);
	RTLR(19,loc5);
	RTLR(20,loc8);
	RTLR(21,loc9);
	RTLR(22,loc20);
	RTLR(23,arg5);
	RTLR(24,loc14);
	RTLR(25,loc21);
	RTLR(26,loc22);
	RTLIU(27);
	
	RTEAA("create_target_menu", 1537, Current, 22, 8, 21774);
	RTGC;
	RTHOOK(1);
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	RTHOOK(2);
	loc11 = RTLNS(eif_new_type(1405, 0x00).id, 1405, _OBJSIZ_6_1_0_1_0_0_0_0_);
	F1248_11522(RTCW(loc11));
	RTHOOK(3);
	loc3 = RTLNS(eif_new_type(1150, 0x00).id, 1150, _OBJSIZ_0_0_0_1_0_0_0_0_);
	RTHOOK(4);
	loc1 = F810_8450(RTCW(loc2));
	RTHOOK(5);
	F810_8475(RTCW(loc2));
	RTHOOK(6);
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr1 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
	RTAR(tr1,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1235,0xFFF9,2,1186,63,63,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A828_308_2_3, (EIF_POINTER) _A828_308_2_3, (EIF_POINTER)(0),tr1, 1, 2);
	}
	loc7 = (EIF_REFERENCE) tr4;
	for (;;) {
		RTHOOK(7);
		tb1 = F810_8470(RTCW(loc2));
		if (tb1) break;
		RTHOOK(8);
		tb2 = '\0';
		ti4_1 = F810_8448(RTCW(loc2));
		tr1 = F1151_10490(RTCW(loc3), ti4_1);
		loc15 = tr1;
		loc15 = RTRV(eif_new_type(1154, 0x00),loc15);
		if (EIF_TEST(loc15)) {
			tb3 = '\01';
			loc16 = loc15;
			loc16 = RTRV(eif_new_type(1284, 0x00),loc16);
			if (!((EIF_BOOLEAN) !EIF_TEST(loc16))) {
				tb4 = F1248_11526(loc16);
				tb3 = (EIF_BOOLEAN) !tb4;
			}
			tb2 = tb3;
		}
		if (tb2) {
			RTHOOK(9);
			tb2 = '\0';
			loc17 = RTCCL(arg6);
			if (EIF_TEST(loc17)) {
				tr1 = F1173_10644(loc15);
				tr2 = RTCCL(loc17);
				tb3 = F918_8949(RTCW(tr1), tr2);
				tb2 = tb3;
			}
			if (tb2) {
				RTHOOK(10);
				tb2 = '\0';
				loc18 = loc15;
				loc18 = RTRV(eif_new_type(1345, 0x00),loc18);
				if (EIF_TEST(loc18)) {
					tb3 = '\0';
					tb4 = F1248_11526(loc18);
					if ((EIF_BOOLEAN) !tb4) {
						tb4 = F1346_12784(loc18);
						tb3 = (EIF_BOOLEAN) !tb4;
					}
					tb2 = tb3;
				}
				if ((EIF_BOOLEAN) !tb2) {
					RTHOOK(11);
					loc13 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					RTHOOK(12);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc10 && (EIF_BOOLEAN)(arg7 != NULL))) {
						RTHOOK(13);
						tr1 = RTLNS(eif_new_type(1401, 0x00).id, 1401, _OBJSIZ_6_0_0_1_0_0_0_0_);
						tr2 = RTMS_EX_H("Pick",4,1349084011);
						F1402_13419(RTCW(tr1), tr2, arg7);
						F1341_12738(RTCW(loc11), tr1);
						RTHOOK(14);
						loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
					RTHOOK(15);
					tr1 = *(EIF_REFERENCE *)(loc15 + O9148[Dtype(loc15)-1154]);
					loc19 = tr1;
					if (EIF_TEST(loc19)) {
						RTHOOK(16);
						{
							static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,0,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr1 = RTLNTS(typres0.id, 2, 0);
						}
						((EIF_TYPED_VALUE *)tr1+1)->it_r = loc17;
						RTAR(tr1,loc17);
						loc4 = F1232_11050(loc19, tr1);
					}
					RTHOOK(17);
					if ((EIF_BOOLEAN)(loc4 != NULL)) {
						RTHOOK(18);
						(RTNA((RTCW(loc4), loc15)));
						RTHOOK(19);
						{
							static EIF_TYPE_INDEX typarr0[] = {444,63,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							loc6 = RTLNS(typres0.id, 444, _OBJSIZ_2_0_0_0_0_0_0_0_);
						}
						F445_6481(RTCW(loc6), loc4, loc7);
						RTHOOK(20);
						if ((EIF_BOOLEAN)(loc5 == NULL)) {
							RTHOOK(21);
							{
								static EIF_TYPE_INDEX typarr0[] = {580,444,63,0xFFFF};
								EIF_TYPE typres0;
								static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
								
								typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
								loc5 = RTLNS(typres0.id, 580, _OBJSIZ_4_1_0_1_0_0_0_0_);
							}
							F581_8196(RTCW(loc5), loc6);
						} else {
							RTHOOK(22);
							F581_8208(RTCW(loc5), loc6);
						}
						RTHOOK(23);
						loc4 = (EIF_REFERENCE) NULL;
					}
				}
			}
		}
		RTHOOK(24);
		F810_8476(RTCW(loc2));
	}
	RTHOOK(25);
	if (loc13) {
		RTHOOK(26);
		{
			static EIF_TYPE_INDEX typarr0[] = {891,63,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc8 = RTLNS(typres0.id, 891, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F892_8780(RTCW(loc8), ((EIF_INTEGER_32) 0L));
		RTHOOK(27);
		if ((EIF_BOOLEAN)(loc5 != NULL)) {
			RTHOOK(28);
			{
				EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[3] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {1230,0xFFF9,3,1186,1230,0xFFF9,0,1186,580,444,63,891,63,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A828_309_2_3_4, (EIF_POINTER) _A828_309_2_3_4, (EIF_POINTER)(0),tr1, 1, 3);
			}
			loc9 = (EIF_REFERENCE) tr4;
			RTHOOK(29);
			(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(RTCW(loc9)+ _PTROFF_4_2_0_3_0_0_))(
				*(EIF_POINTER *)(RTCW(loc9)+ _PTROFF_4_2_0_3_0_1_),
				*(EIF_REFERENCE *)(RTCW(loc9) + _REFACS_1_), loc9, loc5, loc8);
		}
		RTHOOK(30);
		loc12 = F1341_12727(RTCW(loc11));
		RTHOOK(31);
		tr1 = F1285_12036(RTCW(arg5));
		loc20 = tr1;
		if (EIF_TEST(loc20)) {
			RTHOOK(32);
			loc14 = (EIF_REFERENCE) RTCCL(arg6);
			RTHOOK(33);
			RTCT0("l_pebble /= Void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc14 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			RTHOOK(34);
			tr1 = RTCCL(loc14);
			(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(loc20+ _PTROFF_4_2_0_3_0_0_))(
				*(EIF_POINTER *)(loc20+ _PTROFF_4_2_0_3_0_1_),
				*(EIF_REFERENCE *)(loc20 + _REFACS_1_), loc11, loc8, arg5, tr1);
		} else {
			RTHOOK(35);
			F892_8811(RTCW(loc8));
			for (;;) {
				RTHOOK(36);
				tb2 = F859_8654(RTCW(loc8));
				if (tb2) break;
				RTHOOK(37);
				tr1 = F892_8785(RTCW(loc8));
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
				loc21 = tr1;
				if (EIF_TEST(loc21)) {
					RTHOOK(38);
					loc14 = (EIF_REFERENCE) RTCCL(arg6);
					RTHOOK(39);
					RTCT0("l_pebble /= Void", EX_CHECK);
					if ((EIF_BOOLEAN)(loc14 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					RTHOOK(40);
					tr1 = RTLNS(eif_new_type(1401, 0x00).id, 1401, _OBJSIZ_6_0_0_1_0_0_0_0_);
					tr2 = F892_8785(RTCW(loc8));
					tr2 = (RTNA((RTCW(tr2))), ((EIF_REFERENCE) 0));
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1186,917,0xFFF9,1,1186,0,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr3 = RTLNTS(typres0.id, 3, 0);
					}
					tr4 = F1173_10644(loc21);
					((EIF_TYPED_VALUE *)tr3+1)->it_r = tr4;
					RTAR(tr3,tr4);
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,0,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4 = RTLNTS(typres0.id, 2, 0);
					}
					((EIF_TYPED_VALUE *)tr4+1)->it_r = loc14;
					RTAR(tr4,loc14);
					((EIF_TYPED_VALUE *)tr3+2)->it_r = tr4;
					RTAR(tr3,tr4);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {1230,0xFFF9,0,1186,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A485_180, (EIF_POINTER) _A485_180, (EIF_POINTER)(F918_8947),tr3, 1, 0);
					}
					F1402_13419(RTCW(tr1), tr2, tr4);
					F1341_12738(RTCW(loc11), tr1);
				}
				RTHOOK(41);
				F892_8813(RTCW(loc8));
			}
		}
		RTHOOK(42);
		tb3 = '\0';
		tb4 = F1248_11526(RTCW(loc11));
		if ((EIF_BOOLEAN) !tb4) {
			ti4_1 = F1341_12727(RTCW(loc11));
			tb3 = (EIF_BOOLEAN) (ti4_1 > loc12);
		}
		if (tb3) {
			RTHOOK(43);
			F1406_13437(RTCW(loc11), NULL, (EIF_INTEGER_32) (arg3 - ((EIF_INTEGER_32) 3L)), (EIF_INTEGER_32) (arg4 - ((EIF_INTEGER_32) 3L)));
		} else {
			RTHOOK(44);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg7 != NULL) && (EIF_BOOLEAN) !arg8)) {
				RTHOOK(45);
				(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE)) *(EIF_POINTER *)(RTCW(arg7)+ _PTROFF_4_2_0_3_0_0_))(
					*(EIF_POINTER *)(RTCW(arg7)+ _PTROFF_4_2_0_3_0_1_),
					*(EIF_REFERENCE *)(RTCW(arg7) + _REFACS_1_));
			}
		}
	} else {
		RTHOOK(46);
		tr1 = F1285_12036(RTCW(arg5));
		loc22 = tr1;
		if (EIF_TEST(loc22)) {
			RTHOOK(47);
			loc11 = RTLNS(eif_new_type(1405, 0x00).id, 1405, _OBJSIZ_6_1_0_1_0_0_0_0_);
			F1248_11522(RTCW(loc11));
			RTHOOK(48);
			{
				static EIF_TYPE_INDEX typarr0[] = {891,63,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr1 = RTLNS(typres0.id, 891, _OBJSIZ_1_1_0_1_0_0_0_0_);
			}
			F892_8780(RTCW(tr1), ((EIF_INTEGER_32) 0L));
			tr2 = RTCCL(arg6);
			(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(loc22+ _PTROFF_4_2_0_3_0_0_))(
				*(EIF_POINTER *)(loc22+ _PTROFF_4_2_0_3_0_1_),
				*(EIF_REFERENCE *)(loc22 + _REFACS_1_), loc11, tr1, arg5, tr2);
			RTHOOK(49);
			tb3 = '\0';
			tb4 = '\0';
			tb5 = F1248_11526(RTCW(loc11));
			if ((EIF_BOOLEAN) !tb5) {
				ti4_1 = F1341_12727(RTCW(loc11));
				tb4 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
			}
			if (tb4) {
				tb3 = (EIF_BOOLEAN) !F1539_15392(Current);
			}
			if (tb3) {
				RTHOOK(50);
				F1406_13437(RTCW(loc11), NULL, (EIF_INTEGER_32) (arg3 - ((EIF_INTEGER_32) 3L)), (EIF_INTEGER_32) (arg4 - ((EIF_INTEGER_32) 3L)));
			}
		}
	}
	RTHOOK(51);
	tb3 = F810_8472(RTCW(loc2), loc1);
	if (tb3) {
		RTHOOK(52);
		F810_8477(RTCW(loc2), loc1);
	}
	RTHOOK(53);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_I}.set_tab_navigation_state */
void F1538_15331 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_tab_navigation_state", 1537, Current, 0, 1, 21777);
	RTHOOK(1);
	*(EIF_NATURAL_8 *)(Current+ _CHROFF_49_14_) = (EIF_NATURAL_8) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EV_APPLICATION_I}.call_post_launch_actions */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F1538_15336 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_BOOLEAN EIF_VOLATILE loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	RTLD;
	RTXD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,saved_except);
	RTLIU(3);
	RTXSLS;
	
	RTEAA("call_post_launch_actions", 1537, Current, 1, 0, 21782);
	RTGC;
	RTE_T
	RTHOOK(1);
	if ((EIF_BOOLEAN) !loc1) {
		RTHOOK(2);
		tr1 = F210_3694(Current);
		F917_8946(RTCW(tr1), NULL);
	} else {
		RTHOOK(3);
		tr1 = F1538_15342(Current);
		F1538_15337(Current, tr1);
	}
	RTE_E
	RTXSC;
	RTHOOK(4);
	if ((EIF_BOOLEAN) !loc1) {
		RTHOOK(5);
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(6);
		RTER;
	}
	/* NOTREACHED */
	RTE_EE
	RTHOOK(7);
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {EV_APPLICATION_I}.on_exception_action */
void F1538_15337 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,tr2);
	RTLR(5,arg1);
	RTLR(6,loc1);
	RTLIU(7);
	
	RTEAA("on_exception_action", 1537, Current, 3, 1, 21783);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTHOOK(2);
		F1359_12982(loc2);
	}
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTHOOK(4);
		F1347_12808(loc3);
	}
	RTHOOK(5);
	tb1 = '\0';
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_49_5_) && (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_8_) != NULL))) {
		tb2 = F724_8337(RTCV(F210_3707(Current)));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(6);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_49_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(7);
		tr1 = F210_3707(Current);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,378,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr2 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = arg1;
		RTAR(tr2,arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7959[Dtype(RTCW(tr1))-915])(tr1, tr2);
		RTHOOK(8);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_49_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		RTHOOK(9);
		loc1 = RTLNSMART(eif_new_type(1362, 0).id);
		F1248_11522(RTCW(loc1));
		RTHOOK(10);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_35_) = (EIF_REFERENCE) loc1;
		RTHOOK(11);
		F1538_15338(Current, loc1, arg1);
	}
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_I}.raise_default_exception_dialog */
void F1538_15338 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	RTCFDT;
	RTLD;
	
	RTLI(19);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc6);
	RTLR(5,loc4);
	RTLR(6,loc10);
	RTLR(7,loc11);
	RTLR(8,loc9);
	RTLR(9,loc3);
	RTLR(10,arg1);
	RTLR(11,loc5);
	RTLR(12,loc7);
	RTLR(13,Current);
	RTLR(14,tr2);
	RTLR(15,tr3);
	RTLR(16,loc8);
	RTLR(17,loc13);
	RTLR(18,loc12);
	RTLIU(19);
	
	RTEAA("raise_default_exception_dialog", 1537, Current, 13, 2, 21784);
	RTGC;
	RTHOOK(1);
	loc1 = F379_5927(RTCW(arg2));
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTHOOK(3);
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc1);
		loc1 = (EIF_REFERENCE) tr1;
		RTHOOK(4);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\015';
		F1242_11330(RTCW(loc1), tw1);
	}
	RTHOOK(5);
	loc2 = RTLNS(eif_new_type(1386, 0x00).id, 1386, _OBJSIZ_5_2_0_1_0_0_0_0_);
	F1248_11522(RTCW(loc2));
	RTHOOK(6);
	F1387_13306(RTCW(loc2));
	RTHOOK(7);
	F1384_13264(RTCW(loc2));
	RTHOOK(8);
	loc6 = RTLNS(eif_new_type(1255, 0x00).id, 1255, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1248_11522(RTCW(loc6));
	RTHOOK(9);
	F1256_11662(RTCW(loc6), ((EIF_INTEGER_32) 4L));
	RTHOOK(10);
	F1278_11904(RTCW(loc2), loc6);
	RTHOOK(11);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTHOOK(12);
		F1276_11891(RTCW(loc2), loc1);
	} else {
		RTHOOK(13);
		tr1 = RTMS_EX_H("No trace available.",19,2146208046);
		F1276_11891(RTCW(loc2), tr1);
	}
	RTHOOK(14);
	loc4 = RTLNS(eif_new_type(1352, 0x00).id, 1352, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1248_11522(RTCW(loc4));
	RTHOOK(15);
	loc10 = RTLNS(eif_new_type(1353, 0x00).id, 1353, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1248_11522(RTCW(loc10));
	RTHOOK(16);
	F1352_12899(RTCW(loc10), ((EIF_INTEGER_32) 5L));
	RTHOOK(17);
	F1352_12901(RTCW(loc10), ((EIF_INTEGER_32) 5L));
	RTHOOK(18);
	tr1 = RTLNS(eif_new_type(65, 0x00).id, 65, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = RTOUCR(286,F66_1130, (RTCW(tr1)));
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
	F1341_12738(RTCW(loc10), tr1);
	RTHOOK(19);
	tr1 = F835_8615(RTCW(loc10));
	F1352_12903(RTCW(loc10), tr1);
	RTHOOK(20);
	tr1 = F835_8615(RTCW(loc10));
	F1347_12818(RTCW(tr1), ((EIF_INTEGER_32) 32L), ((EIF_INTEGER_32) 32L));
	RTHOOK(21);
	loc11 = RTLNS(eif_new_type(1373, 0x00).id, 1373, _OBJSIZ_5_2_0_1_0_0_0_0_);
	F1248_11522(RTCW(loc11));
	RTHOOK(22);
	F1277_11901(RTCW(loc11));
	RTHOOK(23);
	tr1 = RTMS_EX_H("The following uncaught exception has occurred:\012\012Click Ignore to continue or Quit to exit the application",104,940859246);
	F1276_11891(RTCW(loc11), tr1);
	RTHOOK(24);
	F1341_12738(RTCW(loc10), loc11);
	RTHOOK(25);
	F1341_12738(RTCW(loc4), loc10);
	RTHOOK(26);
	F1352_12903(RTCW(loc4), loc10);
	RTHOOK(27);
	loc9 = RTLNS(eif_new_type(1355, 0x00).id, 1355, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1248_11522(RTCW(loc9));
	RTHOOK(28);
	loc3 = RTLNS(eif_new_type(1353, 0x00).id, 1353, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1248_11522(RTCW(loc3));
	RTHOOK(29);
	F1348_12833(RTCW(loc9), loc3);
	RTHOOK(30);
	F1352_12901(RTCW(loc3), ((EIF_INTEGER_32) 5L));
	RTHOOK(31);
	F1352_12899(RTCW(loc3), ((EIF_INTEGER_32) 5L));
	RTHOOK(32);
	F1341_12738(RTCW(loc3), loc2);
	RTHOOK(33);
	tr1 = RTMS_EX_H("Exception Trace",15,1881935717);
	F1276_11891(RTCW(loc9), tr1);
	RTHOOK(34);
	F1341_12738(RTCW(loc4), loc9);
	RTHOOK(35);
	F1348_12833(RTCW(arg1), loc4);
	RTHOOK(36);
	loc5 = RTLNS(eif_new_type(1353, 0x00).id, 1353, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1248_11522(RTCW(loc5));
	RTHOOK(37);
	F1341_12738(RTCW(loc4), loc5);
	RTHOOK(38);
	F1352_12903(RTCW(loc4), loc5);
	RTHOOK(39);
	loc7 = RTLNS(eif_new_type(1379, 0x00).id, 1379, _OBJSIZ_6_2_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("Ignore",6,1997112421);
	F1276_11889(RTCW(loc7), tr1);
	RTHOOK(40);
	tr1 = F1181_10690(RTCW(loc7));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1362,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = arg1;
	RTAR(tr2,arg1);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1230,0xFFF9,0,1186,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A710_267, (EIF_POINTER) _A710_267, (EIF_POINTER)(F1359_12968),tr2, 1, 0);
	}
	F909_8875(RTCW(tr1), tr3);
	RTHOOK(41);
	tr1 = RTLNS(eif_new_type(1354, 0x00).id, 1354, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1248_11522(RTCW(tr1));
	F1341_12738(RTCW(loc5), tr1);
	RTHOOK(42);
	F1341_12738(RTCW(loc5), loc7);
	RTHOOK(43);
	F1352_12903(RTCW(loc5), loc7);
	RTHOOK(44);
	loc8 = RTLNS(eif_new_type(1379, 0x00).id, 1379, _OBJSIZ_6_2_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("Quit",4,1366649204);
	F1276_11889(RTCW(loc8), tr1);
	RTHOOK(45);
	ti4_1 = F1268_11845(RTCW(loc7));
	F1347_12816(RTCW(loc8), ti4_1);
	RTHOOK(46);
	tr1 = F1181_10690(RTCW(loc8));
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1230,0xFFF9,0,1186,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A828_68, (EIF_POINTER) _A828_68, (EIF_POINTER)(F1514_14803),tr2, 1, 0);
	}
	F909_8875(RTCW(tr1), tr3);
	RTHOOK(47);
	F1341_12738(RTCW(loc5), loc8);
	RTHOOK(48);
	F1352_12903(RTCW(loc5), loc8);
	RTHOOK(49);
	F1352_12899(RTCW(loc5), ((EIF_INTEGER_32) 5L));
	RTHOOK(50);
	F1352_12901(RTCW(loc5), ((EIF_INTEGER_32) 5L));
	RTHOOK(51);
	tr1 = F379_5925(RTCW(arg2));
	loc13 = tr1;
	if (EIF_TEST(loc13)) {
		RTHOOK(52);
		loc12 = (EIF_REFERENCE) loc13;
	} else {
		RTHOOK(53);
		loc12 = RTMS_EX_H("",0,0);
	}
	RTHOOK(54);
	tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000c\000\000\000a\000\000\000u\000\000\000g\000\000\000h\000\000\000t\000\000\000 \000\000\000E\000\000\000x\000\000\000c\000\000\000e\000\000\000p\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000:\000\000\000 \000\000\000",20,182364448);
	tr2 = F1237_11118(RTCW(loc12));
	tr1 = F1242_11323(tr1, tr2);
	F1359_12977(RTCW(arg1), tr1);
	RTHOOK(55);
	F1347_12817(RTCW(arg1), ((EIF_INTEGER_32) 350L));
	RTHOOK(56);
	F1269_11854(RTCW(arg1), ((EIF_INTEGER_32) 500L), ((EIF_INTEGER_32) 300L));
	RTHOOK(57);
	F1361_13004(RTCW(arg1));
	RTHOOK(58);
	F1347_12806(RTCW(loc7));
	RTHOOK(59);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_I}.new_exception */
EIF_REFERENCE F1538_15342 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("new_exception", 1537, Current, 1, 0, 21788);
	RTGC;
	RTHOOK(1);
	loc1 = F245_4244(RTCV(RTOUCR(23,F377_5894, (Current))));
	RTHOOK(2);
	RTCT0("l_result /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(3);
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) loc1;
}

/* {EV_APPLICATION_I}.wake_up_gui_thread */
void F1538_15343 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("wake_up_gui_thread", 1537, Current, 0, 0, 21789);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_I}.is_gui_thread */
EIF_BOOLEAN F1538_15344 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("is_gui_thread", 1537, Current, 0, 0, 21790);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(280,F1538_15345, (Current));
	Result = *(EIF_BOOLEAN *)(RTCW(tr1) + O5147[Dtype(tr1)-335]);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_APPLICATION_I}.is_gui_thread_cell */
static EIF_REFERENCE F1538_15345_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(280)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("is_gui_thread_cell", 1537, Current, 0, 0, 21791);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {338,1195,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 338, _OBJSIZ_0_1_0_0_0_0_0_0_);
	}
	F339_5326(RTCW(tr1), (EIF_BOOLEAN) 0);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1538_15345 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(280,F1538_15345_body,(Current));
}

/* {EV_APPLICATION_I}.help_handler */
void F1538_15351 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("help_handler", 1537, Current, 1, 0, 21797);
	RTGC;
	RTHOOK(1);
	loc1 = F1539_15383(Current);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTHOOK(3);
		F1538_15295(Current, loc1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_I}.contextual_help_procedure */
static EIF_REFERENCE F1538_15353_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDD;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(281)
	dftype = Dftype(Current);

	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTEAA("contextual_help_procedure", 1537, Current, 0, 0, 21799);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr1 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
	RTAR(tr1,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1230,0xFFF9,8,1186,1486,1486,1486,1510,1510,1510,1486,1486,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A828_303_2_3_4_5_6_7_8_9, (EIF_POINTER) _A828_303_2_3_4_5_6_7_8_9, (EIF_POINTER)(F1538_15354),tr1, 1, 8);
	}
	Result = (EIF_REFERENCE) tr4;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1538_15353 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(281,F1538_15353_body,(Current));
}

/* {EV_APPLICATION_I}.contextual_help */
void F1538_15354 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLIU(2);
	
	RTEAA("contextual_help", 1537, Current, 1, 8, 21800);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg3 == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(2);
		F1538_15355(Current);
		RTHOOK(3);
		loc1 = F1281_11973(RTCV(RTOUCR(283,F1538_15315, (Current))));
		RTHOOK(4);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTHOOK(5);
			F1538_15295(Current, loc1);
		}
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_I}.disable_contextual_help */
void F1538_15355 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTEAA("disable_contextual_help", 1537, Current, 3, 0, 21801);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTHOOK(3);
			tr1 = F1178_10667(loc1);
			F835_8635(RTCW(tr1), loc2);
		}
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_37_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			RTHOOK(5);
			F1347_12815(loc1, loc3);
		}
		RTHOOK(6);
		F1347_12808(loc1);
	} else {
		
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_I}.inline-agent#1 of create_target_menu */
EIF_BOOLEAN F1538_21121 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,arg2);
	RTLR(5,Current);
	RTLIU(6);
	
	RTEAA("inline-agent#1 of create_target_menu", 1537, Current, 2, 2, 21804);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tr1 = (RTNA((RTCW(arg1))), ((EIF_REFERENCE) 0));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = (RTNA((RTCW(arg2))), ((EIF_REFERENCE) 0));
		loc2 = tr1;
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		RTHOOK(2);
		tb1 = F1240_11218(loc1, loc2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) tb1;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) 0;
}

/* {EV_APPLICATION_I}.inline-agent#2 of create_target_menu */
void F1538_21122 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg3);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("inline-agent#2 of create_target_menu", 1537, Current, 0, 3, 21805);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_2_);
		(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_0_))(
			*(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_1_),
			*(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_), arg1, tr1, arg3);
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2));
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7657[Dtype(RTCW(arg3))-780])(arg3, tr1);
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_3_);
		(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_0_))(
			*(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_1_),
			*(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_), arg1, tr1, arg3);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

void EIF_Minit828 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
