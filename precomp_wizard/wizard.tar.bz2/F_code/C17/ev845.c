/*
 * Code for class EV_DOCKABLE_SOURCE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev845.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DOCKABLE_SOURCE_IMP}.start_dragable_filter */
void F1559_15819 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_REAL_64 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_16 ti2_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("start_dragable_filter", 1558, Current, 0, 9, 22283);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O12993[dtype-1558])) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + O12837[dtype-1548]);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O13000[dtype-1558]) = (EIF_REFERENCE) tr1;
		RTHOOK(3);
		ti2_1 = (EIF_INTEGER_16) arg2;
		*(EIF_INTEGER_16 *)(Current + O4703[dtype-286]) = (EIF_INTEGER_16) ti2_1;
		RTHOOK(4);
		ti2_1 = (EIF_INTEGER_16) arg3;
		*(EIF_INTEGER_16 *)(Current + O4704[dtype-286]) = (EIF_INTEGER_16) ti2_1;
		RTHOOK(5);
		ti2_1 = (EIF_INTEGER_16) arg8;
		*(EIF_INTEGER_16 *)(Current + O12994[dtype-1558]) = (EIF_INTEGER_16) ti2_1;
		RTHOOK(6);
		ti2_1 = (EIF_INTEGER_16) arg9;
		*(EIF_INTEGER_16 *)(Current + O12995[dtype-1558]) = (EIF_INTEGER_16) ti2_1;
		RTHOOK(7);
		*(EIF_BOOLEAN *)(Current + O12993[dtype-1558]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EV_DOCKABLE_SOURCE_IMP}.dragable_motion */
void F1559_15823 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7)
{
	GTCX
	RTEX;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_INTEGER_16 ti2_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("dragable_motion", 1558, Current, 0, 7, 22287);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current + O12993[dtype-1558])) {
		RTHOOK(2);
		tb1 = '\01';
		ti2_1 = *(EIF_INTEGER_16 *)(Current + O12994[dtype-1558]);
		ti4_1 = (EIF_INTEGER_32) ti2_1;
		ti4_1 = eif_abs_int32 ((EIF_INTEGER_32) (ti4_1 - arg6));
		if (!(EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 3L))) {
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O12995[dtype-1558]);
			ti4_1 = (EIF_INTEGER_32) ti2_1;
			ti4_1 = eif_abs_int32 ((EIF_INTEGER_32) (ti4_1 - arg7));
			tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 3L));
		}
		if (tb1) {
			RTHOOK(3);
			*(EIF_BOOLEAN *)(Current + O12993[dtype-1558]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			RTHOOK(4);
			F1559_15827(Current, arg1, arg2, ((EIF_INTEGER_32) 1L), arg3, arg4, arg5, arg6, arg7);
			RTHOOK(5);
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O4703[dtype-286]);
			ti4_1 = (EIF_INTEGER_32) ti2_1;
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O4704[dtype-286]);
			ti4_2 = (EIF_INTEGER_32) ti2_1;
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O4703[dtype-286]);
			ti4_3 = (EIF_INTEGER_32) ti2_1;
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O4704[dtype-286]);
			ti4_4 = (EIF_INTEGER_32) ti2_1;
			F1559_15828(Current, ti4_1, ti4_2, ((EIF_INTEGER_32) 1L), (EIF_REAL_64) 0.0, (EIF_REAL_64) 0.0, (EIF_REAL_64) 0.0, (EIF_INTEGER_32) (arg6 + (EIF_INTEGER_32) (ti4_3 - arg1)), (EIF_INTEGER_32) (arg7 + (EIF_INTEGER_32) (ti4_4 - arg2)));
		}
	} else {
		RTHOOK(6);
		tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
		tr8_2 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
		F1558_15813(Current, arg1, arg2, tr8_1, tr8_2, (EIF_REAL_64) 0.5, arg6, arg7);
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_DOCKABLE_SOURCE_IMP}.start_dragable */
void F1559_15827 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("start_dragable", 1558, Current, 0, 8, 22291);
	RTGC;
	RTHOOK(1);
	F1587_16080(Current);
	RTHOOK(2);
	tr1 = RTOUCR(311,F1548_15602, (Current));
	F1539_15460(RTCW(tr1), Current);
	RTHOOK(3);
	tr1 = F1514_14806(Current);
	F1558_15811(Current, arg7, arg8, tr1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_DOCKABLE_SOURCE_IMP}.real_start_dragging */
void F1559_15828 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("real_start_dragging", 1558, Current, 0, 8, 22292);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(564,F1558_15806, (Current));
	F1549_15622(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_DOCKABLE_SOURCE_IMP}.end_dragable */
void F1559_15830 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("end_dragable", 1558, Current, 1, 8, 22294);
	RTGC;
	RTHOOK(1);
	if (F1558_15785(Current)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + O13000[Dtype(Current)-1558]);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			RTHOOK(3);
			F1549_15623(Current, loc1);
		} else {
			RTHOOK(4);
			tr1 = RTOUCR(321,F66_1135, (RTCV(RTOUCR(320,F287_4804, (Current)))));
			F1549_15623(Current, tr1);
		}
		RTHOOK(5);
		F1587_16081(Current);
		RTHOOK(6);
		tr1 = RTOUCR(311,F1548_15602, (Current));
		F1539_15460(RTCW(tr1), NULL);
		RTHOOK(7);
		F1558_15804(Current);
	}
	RTHOOK(8);
	F1559_15831(Current);
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {EV_DOCKABLE_SOURCE_IMP}.reset_drag_data */
void F1559_15831 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("reset_drag_data", 1558, Current, 0, 0, 22295);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O12993[dtype-1558]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(2);
	*(EIF_INTEGER_16 *)(Current + O4703[dtype-286]) = (EIF_INTEGER_16) (EIF_INTEGER_16) ((EIF_INTEGER_32) -1L);
	RTHOOK(3);
	*(EIF_INTEGER_16 *)(Current + O4704[dtype-286]) = (EIF_INTEGER_16) (EIF_INTEGER_16) ((EIF_INTEGER_32) -1L);
	RTHOOK(4);
	*(EIF_INTEGER_16 *)(Current + O12994[dtype-1558]) = (EIF_INTEGER_16) (EIF_INTEGER_16) ((EIF_INTEGER_32) -1L);
	RTHOOK(5);
	*(EIF_INTEGER_16 *)(Current + O12995[dtype-1558]) = (EIF_INTEGER_16) (EIF_INTEGER_16) ((EIF_INTEGER_32) -1L);
	RTHOOK(6);
	*(EIF_REFERENCE *)(Current + O13000[dtype-1558]) = (EIF_REFERENCE) NULL;
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_DOCKABLE_SOURCE_IMP}.update_buttons */
void F1559_15836 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("update_buttons", 1558, Current, 0, 3, 22296);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

void EIF_Minit845 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
