
#ifndef _C17_ev816_
#define _C17_ev816_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1526_15012(EIF_REFERENCE);
extern void F1526_15013(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit816(void);
extern EIF_REFERENCE F1589_16150(EIF_REFERENCE);
extern void F1588_16137(EIF_REFERENCE);
extern long O12347[];
extern long O9889[];

#ifdef __cplusplus
}
#endif

#endif
