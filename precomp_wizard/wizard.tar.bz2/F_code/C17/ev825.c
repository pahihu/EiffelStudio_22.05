/*
 * Code for class EV_ACCELERATOR_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev825.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_ACCELERATOR_IMP}.make */
void F1535_15213 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 1534, Current, 0, 0, 21740);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_new_type(1714, 0).id);
	F1715_18226(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	F1514_14820(Current, (EIF_BOOLEAN) 1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_ACCELERATOR_IMP}.key */
EIF_REFERENCE F1535_15214 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_2_);
}


/* {EV_ACCELERATOR_IMP}.shift_required */
EIF_BOOLEAN F1535_15215 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_3_3_);
}


/* {EV_ACCELERATOR_IMP}.alt_required */
EIF_BOOLEAN F1535_15216 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_3_2_);
}


/* {EV_ACCELERATOR_IMP}.control_required */
EIF_BOOLEAN F1535_15217 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_3_1_);
}


/* {EV_ACCELERATOR_IMP}.set_key */
void F1535_15218 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_key", 1534, Current, 0, 1, 21745);
	RTGC;
	RTHOOK(1);
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_ACCELERATOR_IMP}.enable_shift_required */
void F1535_15219 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("enable_shift_required", 1534, Current, 0, 0, 21746);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	RTEE;
}

/* {EV_ACCELERATOR_IMP}.enable_alt_required */
void F1535_15221 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("enable_alt_required", 1534, Current, 0, 0, 21733);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	RTEE;
}

/* {EV_ACCELERATOR_IMP}.enable_control_required */
void F1535_15223 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("enable_control_required", 1534, Current, 0, 0, 21735);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	RTEE;
}

/* {EV_ACCELERATOR_IMP}.destroy */
void F1535_15226 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("destroy", 1534, Current, 0, 0, 21738);
	RTHOOK(1);
	F1514_14821(Current, (EIF_BOOLEAN) 1);
	RTHOOK(2);
	RTEE;
}

void EIF_Minit825 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
