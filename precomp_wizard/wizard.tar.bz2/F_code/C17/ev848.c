/*
 * Code for class EV_SENSITIVE_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev848.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_SENSITIVE_I}.user_is_sensitive */
EIF_BOOLEAN F1562_15853 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("user_is_sensitive", 1561, Current, 0, 0, 22303);
	RTGC;
	RTHOOK(1);
	tb1 = '\01';
	if (!(EIF_BOOLEAN) !F1563_15867(Current)) {
		tb1 = F1563_15869(Current);
	}
	if (tb1) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) F1563_15863(Current);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) 0;
}

/* {EV_SENSITIVE_I}.user_enable_sensitive */
void F1562_15855 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("user_enable_sensitive", 1561, Current, 0, 0, 22305);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O13019[Dtype(Current)-1561]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(2);
	F1563_15864(Current);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_SENSITIVE_I}.user_disable_sensitive */
void F1562_15856 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("user_disable_sensitive", 1561, Current, 0, 0, 22306);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O13019[Dtype(Current)-1561]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	F1563_15865(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

void EIF_Minit848 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
