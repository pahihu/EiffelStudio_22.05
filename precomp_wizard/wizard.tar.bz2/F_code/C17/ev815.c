/*
 * Code for class EV_PIXEL_BUFFER_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev815.h"
#include "ev_c_util.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F175_2545
static EIF_INTEGER_32 inline_F175_2545 (void)
{
	return GDK_COLORSPACE_RGB;
	;
}
#define INLINE_F175_2545
#endif
#ifndef INLINE_F175_2572
static EIF_POINTER inline_F175_2572 (EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	return gdk_pixbuf_new ((GdkColorspace) arg1, (gboolean) arg2, (int) arg3, (int) arg4, (int) arg5);
	;
}
#define INLINE_F175_2572
#endif
#ifndef INLINE_F175_2574
static void inline_F175_2574 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gdk_pixbuf_fill ((GdkPixbuf*)arg1, (guint32) arg2);
	;
}
#define INLINE_F175_2574
#endif
#ifndef INLINE_F175_2570
static EIF_POINTER inline_F175_2570 (EIF_POINTER arg1)
{
	return gdk_pixbuf_new_from_xpm_data ((const char**) arg1);
	;
}
#define INLINE_F175_2570
#endif
#ifndef INLINE_F175_2408
static EIF_POINTER inline_F175_2408 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (g_object_ref_sink((gpointer) arg1))
	;
}
#define INLINE_F175_2408
#endif
#ifndef INLINE_F176_2791
static int inline_F176_2791 (EIF_POINTER arg1)
{
	return (int) (gtk_widget_has_screen ((GtkWidget*) arg1))
	;
}
#define INLINE_F176_2791
#endif
#ifndef INLINE_F176_2792
static EIF_POINTER inline_F176_2792 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gtk_widget_get_screen ((GtkWidget*) arg1))
	;
}
#define INLINE_F176_2792
#endif
#ifndef INLINE_F176_2756
static EIF_POINTER inline_F176_2756 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gtk_icon_theme_get_for_screen ((GdkScreen*) arg1))
	;
}
#define INLINE_F176_2756
#endif
#ifndef INLINE_F176_2757
static EIF_POINTER inline_F176_2757 (void)
{
	return gtk_icon_theme_get_default ();
	;
}
#define INLINE_F176_2757
#endif
#ifndef INLINE_F176_2755
static EIF_POINTER inline_F176_2755 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_8 arg3, EIF_INTEGER_8 arg4, EIF_POINTER arg5)
{
	return (EIF_POINTER) (gtk_icon_theme_load_icon ((GtkIconTheme *)arg1,
                          (const gchar *)arg2,
                          (gint)arg3,
                          (GtkIconLookupFlags)arg4,
                          (GError **)arg5))
	;
}
#define INLINE_F176_2755
#endif
#ifndef INLINE_F175_2410
static void inline_F175_2410 (EIF_POINTER arg1)
{
	g_object_unref((gpointer) arg1)
	;
}
#define INLINE_F175_2410
#endif
#ifndef INLINE_F175_2403
static int inline_F175_2403 (EIF_POINTER arg1)
{
	return (int) (GDK_IS_PIXBUF(arg1))
	;
}
#define INLINE_F175_2403
#endif
#ifndef INLINE_F175_2562
static EIF_POINTER inline_F175_2562 (EIF_POINTER arg1)
{
	return gdk_pixbuf_copy ((GdkPixbuf*)arg1);
	;
}
#define INLINE_F175_2562
#endif
#ifndef INLINE_F175_2409
static EIF_POINTER inline_F175_2409 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (g_object_ref((gpointer) arg1))
	;
}
#define INLINE_F175_2409
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PIXEL_BUFFER_IMP}.make_with_size */
void F1525_14984 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make_with_size", 1524, Current, 0, 2, 21574);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) ((EIF_INTEGER_32) GTK_MAJOR_VERSION >= ((EIF_INTEGER_32) 2L))) {
		RTHOOK(2);
		ti4_1 = inline_F175_2545();
		tp1 = inline_F175_2572(ti4_1, (EIF_BOOLEAN) 1, ((EIF_INTEGER_32) 8L), arg1, arg2);
		F1525_15006(Current, tp1);
		RTHOOK(3);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_4_2_0_0_0_0_);
		inline_F175_2574(tp1, ((EIF_INTEGER_32) 0L));
	} else {
		RTHOOK(4);
		tr1 = RTLNSMART(eif_new_type(1375, 0).id);
		F1376_13178(RTCW(tr1), arg1, arg2);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_PIXEL_BUFFER_IMP}.make */
void F1525_14987 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 1524, Current, 0, 0, 21577);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_new_type(1140, 0).id);
	tp1 = F1_33(Current);
	F1141_9697(RTCW(tr1), tp1, ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	F1514_14820(Current, (EIF_BOOLEAN) 1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_PIXEL_BUFFER_IMP}.set_from_stock */
void F1525_15002 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTEAA("set_from_stock", 1524, Current, 2, 1, 21592);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	F1525_15003(Current, tp1);
	RTHOOK(3);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_4_2_0_0_0_0_);
	tb1 = !tp1;
	if (tb1) {
		RTHOOK(4);
		loc2 = F1138_9659(RTCW(loc1));
		RTHOOK(5);
		F1242_11345(RTCW(loc2));
		RTHOOK(6);
		tb1 = '\01';
		tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000f\000\000\000o\000\000\000r\000\000\000m\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",11,684350830);
		tb2 = F1240_11216(RTCW(loc2), tr1);
		if (!tb2) {
			tr1 = RTMS32_EX_H("d\000\000\000i\000\000\000a\000\000\000l\000\000\000o\000\000\000g\000\000\000-\000\000\000i\000\000\000n\000\000\000f\000\000\000o\000\000\000r\000\000\000m\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",18,1358691950);
			tb2 = F1240_11216(RTCW(loc2), tr1);
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(7);
			tp1 = (EIF_POINTER) information_pixmap_xpm();
			tp1 = inline_F175_2570(tp1);
			F1525_15006(Current, tp1);
		} else {
			RTHOOK(8);
			tr1 = RTMS32_EX_H("d\000\000\000i\000\000\000a\000\000\000l\000\000\000o\000\000\000g\000\000\000-\000\000\000e\000\000\000r\000\000\000r\000\000\000o\000\000\000r\000\000\000",12,1766531442);
			tb1 = F1240_11216(RTCW(loc2), tr1);
			if (tb1) {
				RTHOOK(9);
				tp1 = (EIF_POINTER) error_pixmap_xpm();
				tp1 = inline_F175_2570(tp1);
				F1525_15006(Current, tp1);
			} else {
				RTHOOK(10);
				tr1 = RTMS32_EX_H("d\000\000\000i\000\000\000a\000\000\000l\000\000\000o\000\000\000g\000\000\000-\000\000\000q\000\000\000u\000\000\000e\000\000\000s\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",15,601717614);
				tb1 = F1240_11216(RTCW(loc2), tr1);
				if (tb1) {
					RTHOOK(11);
					tp1 = (EIF_POINTER) question_pixmap_xpm();
					tp1 = inline_F175_2570(tp1);
					F1525_15006(Current, tp1);
				} else {
					RTHOOK(12);
					tr1 = RTMS32_EX_H("d\000\000\000i\000\000\000a\000\000\000l\000\000\000o\000\000\000g\000\000\000-\000\000\000w\000\000\000a\000\000\000r\000\000\000n\000\000\000i\000\000\000n\000\000\000g\000\000\000",14,1187148903);
					tb1 = F1240_11216(RTCW(loc2), tr1);
					if (tb1) {
						RTHOOK(13);
						tp1 = (EIF_POINTER) warning_pixmap_xpm();
						tp1 = inline_F175_2570(tp1);
						F1525_15006(Current, tp1);
					} else {
						RTHOOK(14);
						F1525_14984(Current, ((EIF_INTEGER_32) 48L), ((EIF_INTEGER_32) 48L));
					}
				}
			}
		}
	}
	RTHOOK(15);
	RTLE;
	RTEE;
}

/* {EV_PIXEL_BUFFER_IMP}.set_from_stock_id */
void F1525_15003 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_POINTER loc5 = (EIF_POINTER) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,loc6);
	RTLIU(2);
	
	RTEAA("set_from_stock_id", 1524, Current, 6, 1, 21593);
	RTGC;
	RTHOOK(1);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	loc2 = (EIF_POINTER) gtk_label_new((gchar*) tp2);
	RTHOOK(2);
	tp1 = inline_F175_2408(loc2);
	loc2 = (EIF_POINTER) tp1;
	RTHOOK(3);
	if (EIF_TEST (inline_F176_2791(loc2))) {
		RTHOOK(4);
		loc5 = inline_F176_2792(loc2);
		RTHOOK(5);
		loc3 = inline_F176_2756(loc5);
	} else {
		RTHOOK(6);
		loc3 = inline_F176_2757();
	}
	RTHOOK(7);
	loc1 = inline_F176_2755(loc3, arg1, (EIF_INTEGER_8) ((EIF_INTEGER_32) 48L), (EIF_INTEGER_8) ((EIF_INTEGER_32) 0L), (EIF_POINTER *) &(loc4));
	RTHOOK(8);
	tb1 = !loc4;
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(9);
		loc6 = RTLNS(eif_new_type(1136, 0x00).id, 1136, _OBJSIZ_1_1_0_0_0_1_0_0_);
		F492_7118(RTCW(loc6), loc4);
		RTHOOK(10);
		F1137_9650(RTCW(loc6));
	}
	RTHOOK(11);
	inline_F175_2410(loc2);
	RTHOOK(12);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	loc2 = tp1;
	RTHOOK(13);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc1 != tp1)) {
		RTHOOK(14);
		if ((EIF_BOOLEAN) !EIF_TEST (inline_F175_2403(loc1))) {
		}
		RTHOOK(15);
		tp1 = inline_F175_2562(loc1);
		F1525_15006(Current, tp1);
		RTHOOK(16);
		inline_F175_2410(loc1);
	}
	RTHOOK(17);
	RTLE;
	RTEE;
}

/* {EV_PIXEL_BUFFER_IMP}.set_gdkpixbuf */
void F1525_15006 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_gdkpixbuf", 1524, Current, 1, 1, 21596);
	RTGC;
	RTHOOK(1);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current+ _PTROFF_4_2_0_0_0_0_) != tp1)) {
		RTHOOK(2);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_4_2_0_0_0_0_);
		inline_F175_2410(tp1);
	}
	RTHOOK(3);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(arg1 != tp1)) {
		RTHOOK(4);
		loc1 = inline_F175_2409(arg1);
		RTHOOK(5);
		if ((EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(gdk_pixbuf_get_has_alpha((GdkPixbuf*) arg1))) {
			RTHOOK(6);
			tp1 = (EIF_POINTER) gdk_pixbuf_add_alpha((GdkPixbuf*) loc1, (gboolean) (EIF_BOOLEAN) 0, (guchar) (EIF_NATURAL_8) ((EIF_INTEGER_32) 0L), (guchar) (EIF_NATURAL_8) ((EIF_INTEGER_32) 0L), (guchar) (EIF_NATURAL_8) ((EIF_INTEGER_32) 0L));
			*(EIF_POINTER *)(Current+ _PTROFF_4_2_0_0_0_0_) = (EIF_POINTER) tp1;
			RTHOOK(7);
			inline_F175_2410(arg1);
			RTHOOK(8);
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_4_2_0_0_0_0_);
			tp1 = inline_F175_2409(tp1);
			*(EIF_POINTER *)(Current+ _PTROFF_4_2_0_0_0_0_) = (EIF_POINTER) tp1;
		} else {
			RTHOOK(9);
			*(EIF_POINTER *)(Current+ _PTROFF_4_2_0_0_0_0_) = (EIF_POINTER) arg1;
		}
	} else {
		RTHOOK(10);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current+ _PTROFF_4_2_0_0_0_0_) = (EIF_POINTER) tp2;
	}
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {EV_PIXEL_BUFFER_IMP}.destroy */
void F1525_15009 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("destroy", 1524, Current, 0, 0, 21599);
	RTGC;
	RTHOOK(1);
	F1514_14822(Current, (EIF_BOOLEAN) 1);
	RTHOOK(2);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	F1525_15006(Current, tp2);
	RTHOOK(3);
	F1514_14821(Current, (EIF_BOOLEAN) 1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_PIXEL_BUFFER_IMP}.dispose */
void F1525_15010 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("dispose", 1524, Current, 0, 0, 21600);
	RTGC;
	RTHOOK(1);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	F1525_15006(Current, tp2);
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit815 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
