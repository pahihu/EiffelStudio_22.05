
#ifndef _C17_ev848_
#define _C17_ev848_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1562_15853(EIF_REFERENCE);
extern void F1562_15855(EIF_REFERENCE);
extern void F1562_15856(EIF_REFERENCE);
extern void EIF_Minit848(void);
extern EIF_BOOLEAN F1563_15863(EIF_REFERENCE);
extern void F1563_15864(EIF_REFERENCE);
extern void F1563_15865(EIF_REFERENCE);
extern EIF_BOOLEAN F1563_15869(EIF_REFERENCE);
extern EIF_BOOLEAN F1563_15867(EIF_REFERENCE);
extern long O13019[];

#ifdef __cplusplus
}
#endif

#endif
