
#ifndef _C17_ev827_
#define _C17_ev827_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1537_15245(EIF_REFERENCE);
extern void EIF_Minit827(void);
extern void F1514_14820(EIF_REFERENCE, EIF_BOOLEAN);

#ifdef __cplusplus
}
#endif

#endif
