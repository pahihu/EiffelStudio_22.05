/*
 * Code for class EV_FONT_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev820.h"
#include <string.h>
#include "eif_built_in.h"
#include <ev_gtk.h>
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_FONT_IMP}.make */
void F1530_15082 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLIU(7);
	
	RTEAA("make", 1529, Current, 1, 0, 21651);
	RTGC;
	RTHOOK(1);
	loc1 = RTOUCR(332,F1530_15130, (Current));
	RTHOOK(2);
	tp1 = (EIF_POINTER) pango_font_description_new();
	*(EIF_POINTER *)(Current+ _PTROFF_3_2_0_8_0_0_) = (EIF_POINTER) tp1;
	RTHOOK(3);
	{
		static EIF_TYPE_INDEX typarr0[] = {912,1241,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F913_8899(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_7_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	RTHOOK(5);
	tr1 = F1152_10504(RTCW(loc1));
	F1530_15091(Current, tr1);
	RTHOOK(6);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_49_16_0_4_);
	F1530_15095(Current, ti4_1);
	RTHOOK(7);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_49_16_0_5_);
	F1530_15093(Current, ti4_1);
	RTHOOK(8);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_49_16_0_6_);
	F1530_15092(Current, ti4_1);
	RTHOOK(9);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1230,0xFFF9,1,1186,1241,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A820_105_2, (EIF_POINTER) _A820_105_2, (EIF_POINTER)(F1530_15112),tr2, 1, 1);
	}
	F909_8875(RTCW(tr1), tr5);
	RTHOOK(10);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_3_);
	tr2 = F892_8788(RTCW(tr2));
	F909_8875(RTCW(tr1), tr2);
	RTHOOK(11);
	F1514_14820(Current, (EIF_BOOLEAN) 1);
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {EV_FONT_IMP}.font_is_default */
EIF_BOOLEAN F1530_15083 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("font_is_default", 1529, Current, 1, 0, 21652);
	RTGC;
	RTHOOK(1);
	loc1 = RTOUCR(332,F1530_15130, (Current));
	RTHOOK(2);
	Result = '\0';
	tb1 = '\0';
	tb2 = '\0';
	tb3 = '\0';
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_49_16_0_4_);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_2_) == ti4_1)) {
		tb3 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_7_) == ((EIF_INTEGER_32) 3L));
	}
	if (tb3) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_49_16_0_6_);
		tb2 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_5_) == ti4_1);
	}
	if (tb2) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_49_16_0_5_);
		tb1 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_4_) == ti4_1);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_22_);
		tb1 = F1240_11213(RTCW(tr1), tr2);
		Result = tb1;
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_FONT_IMP}.family */
EIF_INTEGER_32 F1530_15084 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_7_);
}


/* {EV_FONT_IMP}.weight */
EIF_INTEGER_32 F1530_15086 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_5_);
}


/* {EV_FONT_IMP}.shape */
EIF_INTEGER_32 F1530_15087 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_4_);
}


/* {EV_FONT_IMP}.height */
EIF_INTEGER_32 F1530_15088 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_3_);
}


/* {EV_FONT_IMP}.height_in_points */
EIF_INTEGER_32 F1530_15089 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_2_);
}


/* {EV_FONT_IMP}.set_family */
void F1530_15090 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_family", 1529, Current, 0, 1, 21659);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_7_) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	F1530_15113(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_FONT_IMP}.set_face_name */
void F1530_15091 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("set_face_name", 1529, Current, 1, 1, 21660);
	RTGC;
	RTHOOK(1);
	tr1 = F1237_11118(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTOUCR(332,F1530_15130, (Current));
	loc1 = F1539_15493(RTCW(tr1), arg1);
	RTHOOK(3);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_3_2_0_8_0_0_);
	tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	pango_font_description_set_family((PangoFontDescription*) tp1, (char*) tp2);
	RTHOOK(4);
	F1530_15099(Current);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_FONT_IMP}.set_weight */
void F1530_15092 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_weight", 1529, Current, 0, 1, 21661);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_5_) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_3_2_0_8_0_0_);
	ti4_1 = F1530_15121(Current);
	pango_font_description_set_weight((PangoFontDescription*) tp1, (PangoWeight) ti4_1);
	RTHOOK(3);
	F1530_15099(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_FONT_IMP}.set_shape */
void F1530_15093 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_shape", 1529, Current, 0, 1, 21662);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_4_) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_3_2_0_8_0_0_);
	ti4_1 = F1530_15120(Current);
	pango_font_description_set_style((PangoFontDescription*) tp1, (PangoStyle) ti4_1);
	RTHOOK(3);
	F1530_15099(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_FONT_IMP}.set_height */
void F1530_15094 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("set_height", 1529, Current, 0, 1, 21663);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(332,F1530_15130, (Current));
	ti4_1 = F1152_10500(RTCW(tr1), arg1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_2_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_3_) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_3_2_0_8_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_2_);
	ti4_2 = (EIF_INTEGER_32) PANGO_SCALE;
	pango_font_description_set_size((PangoFontDescription*) tp1, (gint) (EIF_INTEGER_32) (ti4_1 * ti4_2));
	RTHOOK(4);
	F1530_15099(Current);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_FONT_IMP}.set_height_in_points */
void F1530_15095 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("set_height_in_points", 1529, Current, 0, 1, 21664);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_2_) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	tr1 = RTOUCR(332,F1530_15130, (Current));
	ti4_1 = F1152_10499(RTCW(tr1), arg1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_3_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(3);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_3_2_0_8_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_2_);
	ti4_2 = (EIF_INTEGER_32) PANGO_SCALE;
	pango_font_description_set_size((PangoFontDescription*) tp1, (gint) (EIF_INTEGER_32) (ti4_1 * ti4_2));
	RTHOOK(4);
	F1530_15099(Current);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_FONT_IMP}.set_values */
void F1530_15096 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_REFERENCE arg5)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg5);
	RTLIU(2);
	
	RTEAA("set_values", 1529, Current, 0, 5, 21665);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	F1529_15059(Current, arg1, arg2, arg3, arg4, arg5);
	RTHOOK(3);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(4);
	F1530_15099(Current);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_FONT_IMP}.name */
EIF_REFERENCE F1530_15097 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_2_);
}


/* {EV_FONT_IMP}.calculate_font_metrics */
void F1530_15099 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("calculate_font_metrics", 1529, Current, 3, 0, 21668);
	RTGC;
	RTAOMS(15098,1);
	RTHOOK(1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_)) {
		RTHOOK(2);
		RTCOMS(tr1,15098,0,"Ag",2,16743);
		loc1 = F1530_15105(Current, tr1);
		RTHOOK(3);
		loc2 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (loc1, ((EIF_INTEGER_32) 5L));
		RTHOOK(4);
		loc3 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (loc1, ((EIF_INTEGER_32) 2L));
		RTHOOK(5);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_1_) = (EIF_INTEGER_32) loc2;
		RTHOOK(6);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_0_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_1_));
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_FONT_IMP}.ascent */
EIF_INTEGER_32 F1530_15100 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_1_);
}


/* {EV_FONT_IMP}.descent */
EIF_INTEGER_32 F1530_15101 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_0_);
}


/* {EV_FONT_IMP}.string_size */
EIF_REFERENCE F1530_15105 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_POINTER loc5 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc12 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc13 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc14 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc15 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc16 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc17 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc18 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc19 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc20 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc21);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTEAA("string_size", 1529, Current, 21, 1, 21674);
	RTGC;
	RTHOOK(1);
	loc21 = RTOUCR(332,F1530_15130, (Current));
	RTHOOK(2);
	loc1 = F1539_15493(RTCW(loc21), arg1);
	RTHOOK(3);
	loc2 = RTOUCB(EIF_POINTER,333,F1152_10501, (RTCW(loc21)));
	RTHOOK(4);
	tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_0_1_0_0_);
	pango_layout_set_text((PangoLayout*) loc2, (char*) tp1, (int) ti4_1);
	RTHOOK(5);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_3_2_0_8_0_0_);
	pango_layout_set_font_description((PangoLayout*) loc2, (PangoFontDescription*) tp1);
	RTHOOK(6);
	loc4 = (EIF_POINTER) calloc (sizeof(PangoRectangle), 1);
	RTHOOK(7);
	loc5 = RTOUCB(EIF_POINTER,334,F1530_15108, (Current));
	RTHOOK(8);
	pango_layout_get_pixel_extents((PangoLayout*) loc2, (PangoRectangle*) loc4, (PangoRectangle*) loc5);
	RTHOOK(9);
	loc3 = F1152_10502(RTCW(loc21));
	RTHOOK(10);
	loc20 = (EIF_INTEGER_32) pango_layout_iter_get_baseline((PangoLayoutIter*) loc3);
	ti4_1 = (EIF_INTEGER_32) PANGO_SCALE;
	loc20 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc20 / ti4_1);
	RTHOOK(11);
	pango_layout_iter_free((PangoLayoutIter*) loc3);
	RTHOOK(12);
	loc6 = (EIF_INTEGER_32) (((PangoRectangle *)loc5)->x);
	RTHOOK(13);
	loc7 = (EIF_INTEGER_32) (((PangoRectangle *)loc5)->y);
	RTHOOK(14);
	loc8 = (EIF_INTEGER_32) (((PangoRectangle *)loc5)->width);
	RTHOOK(15);
	loc9 = (EIF_INTEGER_32) (((PangoRectangle *)loc5)->height);
	RTHOOK(16);
	loc10 = (EIF_INTEGER_32) (((PangoRectangle *)loc4)->x);
	RTHOOK(17);
	loc11 = (EIF_INTEGER_32) (((PangoRectangle *)loc4)->y);
	RTHOOK(18);
	loc12 = (EIF_INTEGER_32) (((PangoRectangle *)loc4)->width);
	RTHOOK(19);
	loc13 = (EIF_INTEGER_32) (((PangoRectangle *)loc4)->height);
	RTHOOK(20);
	loc14 = (EIF_INTEGER_32) loc8;
	RTHOOK(21);
	loc15 = (EIF_INTEGER_32) loc9;
	RTHOOK(22);
	if ((EIF_BOOLEAN) (loc12 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(23);
		loc16 = (EIF_INTEGER_32) loc10;
		RTHOOK(24);
		loc17 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc16 + loc12) - loc8);
	}
	RTHOOK(25);
	if ((EIF_BOOLEAN) (loc13 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(26);
		loc18 = (EIF_INTEGER_32) loc11;
		RTHOOK(27);
		loc19 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc18 + loc13) - loc9);
	}
	RTHOOK(28);
	Result = RTOUCR(335,F1530_15106, (Current));
	RTHOOK(29);
	ti4_1 = eif_max_int32 (loc14,((EIF_INTEGER_32) 1L));
	F1187_10781(RTCW(Result), ti4_1, ((EIF_INTEGER_32) 1L));
	RTHOOK(30);
	ti4_1 = eif_max_int32 (loc15,((EIF_INTEGER_32) 1L));
	F1187_10781(RTCW(Result), ti4_1, ((EIF_INTEGER_32) 2L));
	RTHOOK(31);
	F1187_10781(RTCW(Result), loc16, ((EIF_INTEGER_32) 3L));
	RTHOOK(32);
	F1187_10781(RTCW(Result), loc17, ((EIF_INTEGER_32) 4L));
	RTHOOK(33);
	F1187_10781(RTCW(Result), loc20, ((EIF_INTEGER_32) 5L));
	RTHOOK(34);
	F1187_10781(RTCW(Result), loc18, ((EIF_INTEGER_32) 6L));
	RTHOOK(35);
	F1187_10781(RTCW(Result), loc19, ((EIF_INTEGER_32) 7L));
	RTHOOK(36);
	free(loc4);
	RTHOOK(37);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	pango_layout_set_font_description((PangoLayout*) loc2, (PangoFontDescription*) tp2);
	RTHOOK(38);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_FONT_IMP}.reusable_string_size_tuple */
static EIF_REFERENCE F1530_15106_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(335)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("reusable_string_size_tuple", 1529, Current, 0, 0, 21675);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,7,1186,1486,1486,1486,1486,1486,1486,1486,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNTS(typres0.id, 8, 1);
	}
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1530_15106 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(335,F1530_15106_body,(Current));
}

/* {EV_FONT_IMP}.string_width */
EIF_INTEGER_32 F1530_15107 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,loc4);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("string_width", 1529, Current, 4, 1, 21676);
	RTGC;
	RTHOOK(1);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9640[Dtype(RTCW(arg1))-1240])(arg1);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		loc4 = RTOUCR(332,F1530_15130, (Current));
		RTHOOK(3);
		loc2 = F1539_15493(RTCW(loc4), arg1);
		RTHOOK(4);
		loc1 = RTOUCB(EIF_POINTER,333,F1152_10501, (RTCW(loc4)));
		RTHOOK(5);
		tp1 = *(EIF_POINTER *)(RTCW(loc2)+ _PTROFF_0_1_0_1_0_0_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_0_1_0_0_);
		pango_layout_set_text((PangoLayout*) loc1, (char*) tp1, (int) ti4_1);
		RTHOOK(6);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_3_2_0_8_0_0_);
		pango_layout_set_font_description((PangoLayout*) loc1, (PangoFontDescription*) tp1);
		RTHOOK(7);
		pango_layout_get_pixel_size((PangoLayout*) loc1, (gint*) (EIF_INTEGER_32 *) &(Result), (gint*) (EIF_INTEGER_32 *) &(loc3));
		RTHOOK(8);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		pango_layout_set_font_description((PangoLayout*) loc1, (PangoFontDescription*) tp2);
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_FONT_IMP}.reusable_pango_rectangle_struct */
static EIF_POINTER F1530_15108_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRB(EIF_POINTER)
	RTOUDB(EIF_POINTER, 334)

	
	RTEAA("reusable_pango_rectangle_struct", 1529, Current, 0, 0, 21677);
	RTOTP;
	RTHOOK(1);
	Result = (EIF_POINTER) calloc (sizeof(PangoRectangle), 1);
	RTOTE;
	RTHOOK(2);
	RTEE;
	return Result;
#undef Result
}

EIF_POINTER F1530_15108 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_POINTER,334,F1530_15108_body,(Current));
}

/* {EV_FONT_IMP}.update_preferred_faces */
void F1530_15112 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("update_preferred_faces", 1529, Current, 0, 1, 21681);
	RTHOOK(1);
	F1530_15113(Current);
	RTHOOK(2);
	RTEE;
}

/* {EV_FONT_IMP}.update_font_face */
void F1530_15113 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("update_font_face", 1529, Current, 0, 0, 21682);
	RTGC;
	RTHOOK(1);
	tr1 = F1530_15114(Current);
	F1530_15091(Current, tr1);
	RTHOOK(2);
	F1530_15099(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_FONT_IMP}.pango_family_string */
EIF_REFERENCE F1530_15114 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc6);
	RTLR(4,loc3);
	RTLR(5,tr1);
	RTLR(6,Result);
	RTLIU(7);
	
	RTEAA("pango_family_string", 1529, Current, 6, 0, 21683);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	RTHOOK(2);
	tb1 = F724_8337(RTCW(loc1));
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(3);
		loc2 = RTOUCR(336,F1152_10519, (RTCV(RTOUCR(332,F1530_15130, (Current)))));
		RTHOOK(4);
		loc5 = F892_8801(RTCW(loc1));
		RTHOOK(5);
		loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			RTHOOK(6);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc6 != NULL) || (EIF_BOOLEAN) (loc4 > loc5))) break;
			RTHOOK(7);
			loc3 = F892_8786(RTCW(loc1), loc4);
			RTHOOK(8);
			tb1 = '\0';
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				tr1 = F1242_11339(RTCW(loc3));
				tb2 = F892_8792(RTCW(loc2), tr1);
				tb1 = tb2;
			}
			if (tb1) {
				RTHOOK(9);
				loc6 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc3);
			}
			RTHOOK(10);
			loc4++;
		}
	}
	RTHOOK(11);
	if ((EIF_BOOLEAN)(loc6 == NULL)) {
		RTHOOK(12);
		if (F1530_15083(Current)) {
			RTHOOK(13);
			tr1 = F1152_10504(RTCV(RTOUCR(332,F1530_15130, (Current))));
			Result = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
		} else {
			RTHOOK(14);
			Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F1240_11189(RTCW(Result), ((EIF_INTEGER_32) 10L));
			RTHOOK(15);
			switch (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_7_)) {
				case 1L:
					RTHOOK(16);
					tr1 = RTOUCR(337,F1530_15115, (Current));
					F1242_11304(RTCW(Result), tr1);
					break;
				case 2L:
					RTHOOK(17);
					tr1 = RTOUCR(338,F1530_15116, (Current));
					F1242_11304(RTCW(Result), tr1);
					break;
				case 4L:
					RTHOOK(18);
					tr1 = RTOUCR(339,F1530_15117, (Current));
					F1242_11304(RTCW(Result), tr1);
					break;
				case 3L:
					RTHOOK(19);
					tr1 = RTOUCR(340,F1530_15118, (Current));
					F1242_11304(RTCW(Result), tr1);
					break;
				case 5L:
					RTHOOK(20);
					tr1 = RTOUCR(341,F1530_15119, (Current));
					F1242_11304(RTCW(Result), tr1);
					break;
				default:
					RTEC(EN_WHEN);
			}
		}
	} else {
		RTHOOK(21);
		RTHOOK(22);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) loc6;
	}
	RTHOOK(23);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_FONT_IMP}.monospace_string */

EIF_REFERENCE F1530_15115 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (337,RTMS32_EX_H("m\000\000\000o\000\000\000n\000\000\000o\000\000\000s\000\000\000p\000\000\000a\000\000\000c\000\000\000e\000\000\000",9,1647103077));
}

/* {EV_FONT_IMP}.serif_string */

EIF_REFERENCE F1530_15116 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (338,RTMS32_EX_H("s\000\000\000e\000\000\000r\000\000\000i\000\000\000f\000\000\000",5,1702880102));
}

/* {EV_FONT_IMP}.courier_string */

EIF_REFERENCE F1530_15117 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (339,RTMS32_EX_H("c\000\000\000o\000\000\000u\000\000\000r\000\000\000i\000\000\000e\000\000\000r\000\000\000",7,427459442));
}

/* {EV_FONT_IMP}.sans_string */

EIF_REFERENCE F1530_15118 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (340,RTMS32_EX_H("s\000\000\000a\000\000\000n\000\000\000s\000\000\000",4,1935765107));
}

/* {EV_FONT_IMP}.lucida_string */

EIF_REFERENCE F1530_15119 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (341,RTMS32_EX_H("l\000\000\000u\000\000\000c\000\000\000i\000\000\000d\000\000\000a\000\000\000",6,1881086561));
}

/* {EV_FONT_IMP}.pango_style */
EIF_INTEGER_32 F1530_15120 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("pango_style", 1529, Current, 0, 0, 21689);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_4_) == ((EIF_INTEGER_32) 11L))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	} else {
		RTHOOK(4);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	}/* NOTREACHED */
	
}

/* {EV_FONT_IMP}.pango_weight */
EIF_INTEGER_32 F1530_15121 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("pango_weight", 1529, Current, 0, 0, 21690);
	RTGC;
	RTHOOK(1);
	switch (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_5_)) {
		case 8L:
			RTHOOK(2);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 700L);
			break;
		case 7L:
			RTHOOK(3);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 400L);
			break;
		case 6L:
			RTHOOK(4);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 200L);
			break;
		case 9L:
			RTHOOK(5);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 900L);
			break;
		default:
			RTHOOK(6);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 400L);
			break;
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_FONT_IMP}.app_implementation */
static EIF_REFERENCE F1530_15130_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(332)

	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("app_implementation", 1529, Current, 1, 0, 21646);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1258, 0x00).id, 1258, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1248_11522(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	loc1 = F1536_15229(RTCW(tr1));
	loc1 = RTRV(eif_new_type(1538, 0x00), loc1);
	RTHOOK(2);
	RTCT0("l_result /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(3);
	Result = (EIF_REFERENCE) loc1;
	RTOTE;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1530_15130 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(332,F1530_15130_body,(Current));
}

/* {EV_FONT_IMP}.destroy */
void F1530_15132 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("destroy", 1529, Current, 0, 0, 21648);
	RTHOOK(1);
	F1514_14821(Current, (EIF_BOOLEAN) 1);
	RTHOOK(2);
	RTEE;
}

/* {EV_FONT_IMP}.dispose */
void F1530_15133 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("dispose", 1529, Current, 0, 0, 21649);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_3_2_0_8_0_0_);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp2 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp3 = tp2;
	pango_font_description_set_family((PangoFontDescription*) tp1, (char*) tp3);
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_3_2_0_8_0_0_);
	pango_font_description_free((PangoFontDescription*) tp1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit820 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
