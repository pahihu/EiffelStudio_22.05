
#ifndef _C17_js803_
#define _C17_js803_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1513_14779(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F1513_14785(EIF_REFERENCE);
extern EIF_REFERENCE F1513_14787(EIF_REFERENCE);
extern void F1513_14792(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F1513_14796(EIF_REFERENCE);
extern EIF_REFERENCE F1513_14797(EIF_REFERENCE);
extern void EIF_Minit803(void);
extern void F1036_9262(EIF_REFERENCE);
extern void F892_8780(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F892_8801(EIF_REFERENCE);
extern EIF_REFERENCE F1036_9247(EIF_REFERENCE);
extern EIF_BOOLEAN F1036_9256(EIF_REFERENCE);
extern EIF_REFERENCE F892_8794(EIF_REFERENCE);
extern char *(*R9863[])();
extern char *(*R7657[])();
extern char *(*R9867[])();
extern char *(*R11594[])();
extern char *(*R9308[])();

#ifdef __cplusplus
}
#endif

#endif
