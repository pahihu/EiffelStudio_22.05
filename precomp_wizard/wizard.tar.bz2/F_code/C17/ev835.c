/*
 * Code for class EV_GTK_WIDGET_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev835.h"
#include <string.h>
#include <ev_any_imp.h>
#include <ev_gtk.h>
#include "eif_misc.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F176_2832
static void inline_F176_2832 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	gtk_widget_get_size_request ((GtkWidget*) arg1, (gint*) arg2, (gint*) arg3)
	;
}
#define INLINE_F176_2832
#endif
#ifndef INLINE_F175_2410
static void inline_F175_2410 (EIF_POINTER arg1)
{
	g_object_unref((gpointer) arg1)
	;
}
#define INLINE_F175_2410
#endif
#ifndef INLINE_F1548_15579
static EIF_REFERENCE inline_F1548_15579 (EIF_POINTER arg1)
{
	return (EIF_REFERENCE) (c_ev_any_imp_get_eif_reference_from_object_id (arg1))
	;
}
#define INLINE_F1548_15579
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GTK_WIDGET_IMP}.gdk_events_mask */
static EIF_INTEGER_32 F1549_15603_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
#define Result RTOTRB(EIF_INTEGER_32)
	RTOUDB(EIF_INTEGER_32, 608)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_events_mask", 1548, Current, 0, 0, 22115);
	RTGC;
	RTOTP;
	RTHOOK(1);
	ti4_1 = (EIF_INTEGER_32) GDK_EXPOSURE_MASK;
	ti4_2 = (EIF_INTEGER_32) GDK_POINTER_MOTION_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_BUTTON_PRESS_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_BUTTON_RELEASE_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_KEY_PRESS_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_KEY_RELEASE_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_ENTER_NOTIFY_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_LEAVE_NOTIFY_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_FOCUS_CHANGE_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_VISIBILITY_NOTIFY_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_POINTER_MOTION_HINT_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_SCROLL_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_STRUCTURE_MASK;
	Result = eif_bit_or(ti4_1,ti4_2);
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F1549_15603 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_INTEGER_32,608,F1549_15603_body,(Current));
}

/* {EV_GTK_WIDGET_IMP}.make */
void F1549_15604 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make", 1548, Current, 2, 0, 22116);
	RTGC;
	RTHOOK(1);
	loc1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R12814[dtype-1550])(Current);
	RTHOOK(2);
	loc2 = *(EIF_POINTER *)(Current + O12790[dtype-1547]);
	RTHOOK(3);
	ti4_1 = RTOUCB(EIF_INTEGER_32,608,F1549_15603, (Current));
	gtk_widget_add_events((GtkWidget*) loc1, (gint) ti4_1);
	RTHOOK(4);
	if ((EIF_BOOLEAN)(loc1 != loc2)) {
		RTHOOK(5);
		ti4_1 = RTOUCB(EIF_INTEGER_32,608,F1549_15603, (Current));
		gtk_widget_add_events((GtkWidget*) loc2, (gint) ti4_1);
	}
	RTHOOK(6);
	if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_WINDOW((loc2)))) {
		RTHOOK(7);
		gtk_widget_realize((GtkWidget*) loc2);
	} else {
		RTHOOK(8);
		gtk_widget_show((GtkWidget*) loc2);
	}
	RTHOOK(9);
	F1514_14820(Current, (EIF_BOOLEAN) 1);
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {EV_GTK_WIDGET_IMP}.screen_x */
EIF_INTEGER_32 F1549_15605 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("screen_x", 1548, Current, 3, 0, 22117);
	RTGC;
	RTHOOK(1);
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R12846[dtype-1550])(Current)) {
		RTHOOK(2);
		tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R12814[dtype-1550])(Current);
		tp1 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
		loc2 = (EIF_INTEGER_32) gdk_window_get_origin((GdkWindow*) tp1, (gint*) (EIF_INTEGER_32 *) &(loc1), (gint*) loc3);
		RTHOOK(3);
		Result = (EIF_INTEGER_32) loc1;
	}
	RTHOOK(4);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOUCR(311,F1548_15602, (Current)))+ _LNGOFF_49_16_0_11_);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.screen_y */
EIF_INTEGER_32 F1549_15606 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("screen_y", 1548, Current, 3, 0, 22118);
	RTGC;
	RTHOOK(1);
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R12846[dtype-1550])(Current)) {
		RTHOOK(2);
		tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R12814[dtype-1550])(Current);
		tp1 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
		loc2 = (EIF_INTEGER_32) gdk_window_get_origin((GdkWindow*) tp1, (gint*) loc3, (gint*) (EIF_INTEGER_32 *) &(loc1));
		RTHOOK(3);
		Result = (EIF_INTEGER_32) loc1;
	}
	RTHOOK(4);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOUCR(311,F1548_15602, (Current)))+ _LNGOFF_49_16_0_12_);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.x_position */
EIF_INTEGER_32 F1549_15607 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("x_position", 1548, Current, 1, 0, 22119);
	RTGC;
	RTHOOK(1);
	ti4_1 = (EIF_INTEGER_32) sizeof(GtkAllocation);
	tp1 = malloc((size_t)ti4_1);
	loc1 = (EIF_POINTER) tp1;
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current + O12790[Dtype(Current)-1547]);
	gtk_widget_get_allocation((GtkWidget*) tp1, (GtkAllocation*) loc1);
	RTHOOK(3);
	Result = (EIF_INTEGER_32) (((GtkAllocation *)loc1)->x);
	RTHOOK(4);
	free(loc1);
	RTHOOK(5);
	ti4_1 = eif_max_int32 (Result,((EIF_INTEGER_32) 0L));
	RTHOOK(6);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) ti4_1;
}

/* {EV_GTK_WIDGET_IMP}.y_position */
EIF_INTEGER_32 F1549_15608 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("y_position", 1548, Current, 1, 0, 22120);
	RTGC;
	RTHOOK(1);
	ti4_1 = (EIF_INTEGER_32) sizeof(GtkAllocation);
	tp1 = malloc((size_t)ti4_1);
	loc1 = (EIF_POINTER) tp1;
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current + O12790[Dtype(Current)-1547]);
	gtk_widget_get_allocation((GtkWidget*) tp1, (GtkAllocation*) loc1);
	RTHOOK(3);
	Result = (EIF_INTEGER_32) (((GtkAllocation *)loc1)->y);
	RTHOOK(4);
	free(loc1);
	RTHOOK(5);
	ti4_1 = eif_max_int32 (Result,((EIF_INTEGER_32) 0L));
	RTHOOK(6);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) ti4_1;
}

/* {EV_GTK_WIDGET_IMP}.widget_imp_at_pointer_position */
EIF_REFERENCE F1549_15609 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("widget_imp_at_pointer_position", 1548, Current, 0, 0, 22121);
	RTGC;
	RTHOOK(1);
	Result = F1539_15484(RTCV(RTOUCR(311,F1548_15602, (Current))));
	RTHOOK(2);
	RTLE;
	RTEE;
	return RTRV(eif_new_type(1588, 0x00), Result);
}

/* {EV_GTK_WIDGET_IMP}.minimum_width */
EIF_INTEGER_32 F1549_15610 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("minimum_width", 1548, Current, 0, 0, 22122);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R12824[Dtype(Current)-1550])(Current);
}

/* {EV_GTK_WIDGET_IMP}.minimum_height */
EIF_INTEGER_32 F1549_15611 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("minimum_height", 1548, Current, 0, 0, 22123);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R12825[Dtype(Current)-1550])(Current);
}

/* {EV_GTK_WIDGET_IMP}.real_minimum_width */
EIF_INTEGER_32 F1549_15612 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("real_minimum_width", 1548, Current, 1, 0, 22124);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !F1514_14805(Current)) {
		RTHOOK(2);
		Result = F1549_15614(Current);
		RTHOOK(3);
		loc1 = F1549_15616(Current);
		RTHOOK(4);
		if ((EIF_BOOLEAN) (loc1 > Result)) {
			RTHOOK(5);
			Result = (EIF_INTEGER_32) loc1;
		}
		RTHOOK(6);
		if ((EIF_BOOLEAN) (Result < ((EIF_INTEGER_32) 0L))) {
			RTHOOK(7);
			RTHOOK(8);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		}
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.real_minimum_height */
EIF_INTEGER_32 F1549_15613 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("real_minimum_height", 1548, Current, 1, 0, 22125);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !F1514_14805(Current)) {
		RTHOOK(2);
		Result = F1549_15615(Current);
		RTHOOK(3);
		loc1 = F1549_15617(Current);
		RTHOOK(4);
		if ((EIF_BOOLEAN) (loc1 > Result)) {
			RTHOOK(5);
			Result = (EIF_INTEGER_32) loc1;
		}
		RTHOOK(6);
		if ((EIF_BOOLEAN) (Result < ((EIF_INTEGER_32) 0L))) {
			RTHOOK(7);
			RTHOOK(8);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		}
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.width_request */
EIF_INTEGER_32 F1549_15614 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("width_request", 1548, Current, 0, 0, 22126);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O12790[Dtype(Current)-1547]);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp2 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp3 = tp2;
	inline_F176_2832(tp1, (EIF_INTEGER_32 *) &(Result), tp3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.height_request */
EIF_INTEGER_32 F1549_15615 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("height_request", 1548, Current, 0, 0, 22127);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O12790[Dtype(Current)-1547]);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp2 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp3 = tp2;
	inline_F176_2832(tp1, tp3, (EIF_INTEGER_32 *) &(Result));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.preferred_minimum_width */
EIF_INTEGER_32 F1549_15616 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("preferred_minimum_width", 1548, Current, 2, 0, 22128);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_POINTER *)(RTCV(RTOUCR(609,F1549_15620, (Current)))+ _PTROFF_0_1_0_1_0_0_);
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current + O12790[Dtype(Current)-1547]);
	gtk_widget_get_preferred_size((GtkWidget*) tp1, (GtkRequisition*) loc1, (GtkRequisition*) loc2);
	RTHOOK(3);
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (((GtkRequisition *)loc1)->width);
}

/* {EV_GTK_WIDGET_IMP}.preferred_minimum_height */
EIF_INTEGER_32 F1549_15617 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("preferred_minimum_height", 1548, Current, 2, 0, 22129);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_POINTER *)(RTCV(RTOUCR(609,F1549_15620, (Current)))+ _PTROFF_0_1_0_1_0_0_);
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current + O12790[Dtype(Current)-1547]);
	gtk_widget_get_preferred_size((GtkWidget*) tp1, (GtkRequisition*) loc1, (GtkRequisition*) loc2);
	RTHOOK(3);
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (((GtkRequisition *)loc1)->height);
}

/* {EV_GTK_WIDGET_IMP}.reusable_requisition_struct */
static EIF_REFERENCE F1549_15620_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(609)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("reusable_requisition_struct", 1548, Current, 0, 0, 22095);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1140, 0x00).id, 1140, _OBJSIZ_0_1_0_1_0_1_1_0_);
	ti4_1 = (EIF_INTEGER_32) sizeof(GtkRequisition);
	F1141_9694(RTCW(tr1), ti4_1);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1549_15620 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(609,F1549_15620_body,(Current));
}

/* {EV_GTK_WIDGET_IMP}.event_widget */
EIF_POINTER F1549_15621 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("event_widget", 1548, Current, 1, 0, 22096);
	RTGC;
	RTHOOK(1);
	loc1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R12814[dtype-1550])(Current);
	RTHOOK(2);
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(gtk_widget_get_has_window((GtkWidget*) loc1))) {
		RTHOOK(3);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_POINTER) loc1;
	} else {
		RTHOOK(5);
		RTHOOK(6);
		RTLE;
		RTEE;
		return (EIF_POINTER) *(EIF_POINTER *)(Current + O12790[dtype-1547]);
	}/* NOTREACHED */
	
}

/* {EV_GTK_WIDGET_IMP}.set_pointer_style */
void F1549_15622 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("set_pointer_style", 1548, Current, 0, 1, 22097);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != *(EIF_REFERENCE *)(Current + O12837[dtype-1548]))) {
		RTHOOK(2);
		if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R12846[dtype-1550])(Current)) {
			RTHOOK(3);
			F1549_15623(Current, arg1);
		}
		RTHOOK(4);
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current + O12837[dtype-1548]) = (EIF_REFERENCE) arg1;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_GTK_WIDGET_IMP}.internal_set_pointer_style */
void F1549_15623 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("internal_set_pointer_style", 1548, Current, 3, 1, 22098);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != *(EIF_REFERENCE *)(Current + O12836[dtype-1548]))) {
		RTHOOK(2);
		RTCT0("attached {EV_POINTER_STYLE_IMP} a_cursor.implementation as a_cursor_imp", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		loc3 = tr1;
		loc3 = RTRV(eif_new_type(1527, 0x00),loc3);
		if (EIF_TEST(loc3)) {
			RTCK0;
		} else {
			RTCF0;
		}
		RTHOOK(3);
		tp1 = *(EIF_POINTER *)(Current + O12790[dtype-1547]);
		loc2 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
		RTHOOK(4);
		tb1 = !loc2;
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(5);
			loc1 = F1528_15043(loc3);
			RTHOOK(6);
			gdk_window_set_cursor((GdkWindow*) loc2, (GdkCursor*) loc1);
			RTHOOK(7);
			inline_F175_2410(loc1);
			RTHOOK(8);
			RTAR(Current, arg1);
			*(EIF_REFERENCE *)(Current + O12836[dtype-1548]) = (EIF_REFERENCE) arg1;
		}
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {EV_GTK_WIDGET_IMP}.pointer_style */
EIF_REFERENCE F1549_15625 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O12837[Dtype(Current)-1548]);
}


/* {EV_GTK_WIDGET_IMP}.set_focus */
void F1549_15626 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_focus", 1548, Current, 0, 0, 22101);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R12840[dtype-1550])(Current)) {
		RTHOOK(2);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R12839[dtype-1550])(Current);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_GTK_WIDGET_IMP}.internal_set_focus */
void F1549_15627 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,loc5);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTEAA("internal_set_focus", 1548, Current, 5, 0, 22102);
	RTGC;
	RTHOOK(1);
	loc4 = RTOUCR(311,F1548_15602, (Current));
	RTHOOK(2);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_29_);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		tb2 = F1539_15467(RTCW(loc4));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(3);
		loc3 = F1514_14806(Current);
		RTHOOK(4);
		if ((EIF_BOOLEAN)(loc3 != loc5)) {
			RTHOOK(5);
			F1347_12808(loc5);
		}
	}
	RTHOOK(6);
	tp1 = *(EIF_POINTER *)(Current + O12790[dtype-1547]);
	if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_WINDOW((tp1)))) {
		RTHOOK(7);
		loc1 = *(EIF_POINTER *)(Current + O12790[dtype-1547]);
	} else {
		RTHOOK(8);
		tp1 = *(EIF_POINTER *)(Current + O12790[dtype-1547]);
		loc1 = (EIF_POINTER) gtk_widget_get_toplevel((GtkWidget*) tp1);
		RTHOOK(9);
		loc2 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R12814[dtype-1550])(Current);
		RTHOOK(10);
		if ((EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(gtk_widget_get_can_focus((GtkWidget*) loc2))) {
			RTHOOK(11);
			{
				/* INLINED CODE (ANY.default_pointer) */
				tp1 = (EIF_POINTER)  0;
				/* END INLINED CODE */
			}
			loc2 = tp1;
		}
	}
	RTHOOK(12);
	gtk_window_set_focus((GtkWindow*) loc1, (GtkWidget*) loc2);
	RTHOOK(13);
	tb1 = '\0';
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc2 != tp1)) {
		tb1 = (EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(gtk_widget_is_focus((GtkWidget*) loc2));
	}
	if (tb1) {
		RTHOOK(14);
		gtk_widget_grab_focus((GtkWidget*) loc2);
	}
	RTHOOK(15);
	RTLE;
	RTEE;
}

/* {EV_GTK_WIDGET_IMP}.has_focus */
EIF_BOOLEAN F1549_15628 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("has_focus", 1548, Current, 0, 0, 22103);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) F1549_15638(Current, (EIF_BOOLEAN) 1);
}

/* {EV_GTK_WIDGET_IMP}.width */
EIF_INTEGER_32 F1549_15629 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("width", 1548, Current, 3, 0, 22104);
	RTGC;
	RTHOOK(1);
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R12824[dtype-1550])(Current);
	RTHOOK(2);
	tb1 = '\01';
	if (!F1549_15633(Current)) {
		tp1 = *(EIF_POINTER *)(Current + O12790[dtype-1547]);
		tb1 = (EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(GTK_IS_WINDOW((tp1)));
	}
	if (tb1) {
		RTHOOK(3);
		ti4_1 = (EIF_INTEGER_32) sizeof(GtkAllocation);
		tp1 = malloc((size_t)ti4_1);
		loc3 = (EIF_POINTER) tp1;
		RTHOOK(4);
		tp1 = *(EIF_POINTER *)(Current + O12790[dtype-1547]);
		gtk_widget_get_allocation((GtkWidget*) tp1, (GtkAllocation*) loc3);
		RTHOOK(5);
		loc2 = (EIF_INTEGER_32) (((GtkAllocation *)loc3)->width);
		RTHOOK(6);
		tb1 = '\0';
		tp1 = *(EIF_POINTER *)(Current + O12790[dtype-1547]);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp2 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)((EIF_POINTER) gtk_widget_get_parent((GtkWidget*) tp1) != tp2)) {
			tb1 = (EIF_BOOLEAN) (loc2 < loc1);
		}
		if (tb1) {
			RTHOOK(7);
			tp1 = *(EIF_POINTER *)(Current + O12790[dtype-1547]);
			gtk_widget_get_allocation((GtkWidget*) tp1, (GtkAllocation*) loc3);
			RTHOOK(8);
			loc2 = (EIF_INTEGER_32) (((GtkAllocation *)loc3)->width);
		}
		RTHOOK(9);
		free(loc3);
	}
	RTHOOK(10);
	ti4_1 = eif_max_int32 (loc1,loc2);
	RTHOOK(11);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) ti4_1;
}

/* {EV_GTK_WIDGET_IMP}.height */
EIF_INTEGER_32 F1549_15630 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("height", 1548, Current, 3, 0, 22105);
	RTGC;
	RTHOOK(1);
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R12825[dtype-1550])(Current);
	RTHOOK(2);
	tb1 = '\01';
	if (!F1549_15633(Current)) {
		tp1 = *(EIF_POINTER *)(Current + O12790[dtype-1547]);
		tb1 = (EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(GTK_IS_WINDOW((tp1)));
	}
	if (tb1) {
		RTHOOK(3);
		ti4_1 = (EIF_INTEGER_32) sizeof(GtkAllocation);
		tp1 = malloc((size_t)ti4_1);
		loc3 = (EIF_POINTER) tp1;
		RTHOOK(4);
		tp1 = *(EIF_POINTER *)(Current + O12790[dtype-1547]);
		gtk_widget_get_allocation((GtkWidget*) tp1, (GtkAllocation*) loc3);
		RTHOOK(5);
		loc2 = (EIF_INTEGER_32) (((GtkAllocation *)loc3)->height);
		RTHOOK(6);
		tb1 = '\0';
		tp1 = *(EIF_POINTER *)(Current + O12790[dtype-1547]);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp2 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)((EIF_POINTER) gtk_widget_get_parent((GtkWidget*) tp1) != tp2)) {
			tb1 = (EIF_BOOLEAN) (loc2 < loc1);
		}
		if (tb1) {
			RTHOOK(7);
			tp1 = *(EIF_POINTER *)(Current + O12790[dtype-1547]);
			gtk_widget_get_allocation((GtkWidget*) tp1, (GtkAllocation*) loc3);
			RTHOOK(8);
			loc2 = (EIF_INTEGER_32) (((GtkAllocation *)loc3)->height);
		}
		RTHOOK(9);
		free(loc3);
	}
	RTHOOK(10);
	ti4_1 = eif_max_int32 (loc1,loc2);
	RTHOOK(11);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) ti4_1;
}

/* {EV_GTK_WIDGET_IMP}.show */
void F1549_15632 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	
	
	RTEAA("show", 1548, Current, 0, 0, 22107);
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O12790[Dtype(Current)-1547]);
	gtk_widget_show((GtkWidget*) tp1);
	RTHOOK(2);
	RTEE;
}

/* {EV_GTK_WIDGET_IMP}.is_show_requested */
EIF_BOOLEAN F1549_15633 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	
	
	RTEAA("is_show_requested", 1548, Current, 0, 0, 22108);
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O12790[Dtype(Current)-1547]);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) EIF_TEST(gtk_widget_get_visible((GtkWidget*) tp1));
}

/* {EV_GTK_WIDGET_IMP}.is_displayed */
EIF_BOOLEAN F1549_15634 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLIU(2);
	
	RTEAA("is_displayed", 1548, Current, 1, 0, 22109);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current + O12790[dtype-1547]) != tp1)) {
		tp1 = *(EIF_POINTER *)(Current + O12790[dtype-1547]);
		Result = (EIF_BOOLEAN) EIF_TEST(gtk_widget_get_mapped((GtkWidget*) tp1));
	}
	RTHOOK(2);
	if (Result) {
		RTHOOK(3);
		loc1 = F1549_15636(Current);
		RTHOOK(4);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTHOOK(5);
			tp1 = *(EIF_POINTER *)(RTCW(loc1) + O12790[Dtype(loc1)-1547]);
			Result = (EIF_BOOLEAN) EIF_TEST(gtk_widget_get_mapped((GtkWidget*) tp1));
		}
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.top_level_gtk_window_imp */
EIF_REFERENCE F1549_15635 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("top_level_gtk_window_imp", 1548, Current, 1, 0, 22110);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O12790[Dtype(Current)-1547]);
	loc1 = (EIF_POINTER) gtk_widget_get_toplevel((GtkWidget*) tp1);
	RTHOOK(2);
	tb1 = !loc1;
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(3);
		tr1 = RTLNTY2(eif_new_type(1549, 0x00), 0x00);
		tr2 = inline_F1548_15579(loc1);
		Result = F1305_12693(tr1, tr2);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.top_level_window_imp */
EIF_REFERENCE F1549_15636 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("top_level_window_imp", 1548, Current, 0, 0, 22111);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNTY2(eif_new_type(1615, 0x00), 0x00);
	tr2 = F1549_15635(Current);
	Result = F1305_12693(tr1, tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.top_level_window */
EIF_REFERENCE F1549_15637 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("top_level_window", 1548, Current, 1, 0, 22112);
	RTGC;
	RTHOOK(1);
	tr1 = F1549_15635(Current);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1615, 0x00),loc1);
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(loc1 + O12205[Dtype(loc1)-1513]);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {EV_GTK_WIDGET_IMP}.has_focus_internal */
EIF_BOOLEAN F1549_15638 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("has_focus_internal", 1548, Current, 3, 1, 22113);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O12790[Dtype(Current)-1547]);
	loc1 = (EIF_POINTER) gtk_widget_get_toplevel((GtkWidget*) tp1);
	RTHOOK(2);
	tb1 = '\0';
	tb2 = '\0';
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc1 != tp1)) {
		tb2 = (EIF_BOOLEAN) EIF_TEST(gtk_widget_is_toplevel((GtkWidget*) loc1));
	}
	if (tb2) {
		tb2 = '\01';
		if (arg1) {
			tb2 = (EIF_BOOLEAN) EIF_TEST(gtk_window_is_active((GtkWindow*) loc1));
		}
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(3);
		loc2 = (EIF_POINTER) gtk_window_get_focus((GtkWindow*) loc1);
		RTHOOK(4);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(loc2 != tp1)) {
			RTHOOK(5);
			tr1 = RTOUCR(311,F1548_15602, (Current));
			loc3 = F1539_15483(RTCW(tr1), loc2);
			loc3 = RTRV(eif_new_type(1588, 0x00), loc3);
			RTHOOK(6);
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				RTHOOK(7);
				RTHOOK(8);
				RTLE;
				RTEE;
				return (EIF_BOOLEAN) (EIF_BOOLEAN)(loc3 == Current);
			}
		}
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) 0;
}

void EIF_Minit835 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
