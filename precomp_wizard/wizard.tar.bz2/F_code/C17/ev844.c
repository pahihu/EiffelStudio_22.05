/*
 * Code for class EV_DOCKABLE_SOURCE_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev844.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DOCKABLE_SOURCE_I}.is_dock_executing */
EIF_BOOLEAN F1558_15785 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_dock_executing", 1557, Current, 0, 0, 22253);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O4701[Dtype(Current)-286]) != NULL);
}

/* {EV_DOCKABLE_SOURCE_I}.is_dockable */
EIF_BOOLEAN F1558_15787 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current + O12961[Dtype(Current)-1557]);
}


/* {EV_DOCKABLE_SOURCE_I}.is_external_docking_enabled */
EIF_BOOLEAN F1558_15789 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_external_docking_enabled", 1557, Current, 0, 0, 22257);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O12962[Dtype(Current)-1557]);
}

/* {EV_DOCKABLE_SOURCE_I}.is_external_docking_relative */
EIF_BOOLEAN F1558_15791 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_external_docking_relative", 1557, Current, 0, 0, 22259);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O12964[Dtype(Current)-1557]);
}

/* {EV_DOCKABLE_SOURCE_I}.get_next_target */
EIF_REFERENCE F1558_15792 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(11);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc4);
	RTLR(5,loc5);
	RTLR(6,tr1);
	RTLR(7,Result);
	RTLR(8,loc6);
	RTLR(9,loc7);
	RTLR(10,Current);
	RTLIU(11);
	
	RTEAA("get_next_target", 1557, Current, 7, 1, 22260);
	RTGC;
	RTHOOK(1);
	loc3 = F1347_12792(RTCW(arg1));
	RTHOOK(2);
	loc1 = loc3;
	loc1 = RTRV(eif_new_type(1347, 0x00), loc1);
	RTHOOK(3);
	loc2 = loc1;
	loc2 = RTRV(eif_new_type(1269, 0x00), loc2);
	RTHOOK(4);
	tb1 = '\0';
	tb2 = '\0';
	loc4 = loc3;
	if (EIF_TEST(loc4)) {
		tr1 = F1347_12796(loc4);
		loc5 = tr1;
		tb2 = EIF_TEST(loc5);
	}
	if (tb2) {
		tb2 = F1270_11857(loc5);
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(5);
		Result = (EIF_REFERENCE) loc5;
	} else {
		RTHOOK(6);
		tb1 = '\0';
		loc6 = loc2;
		if (EIF_TEST(loc6)) {
			tb2 = F1270_11857(loc6);
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(7);
			Result = (EIF_REFERENCE) loc6;
		}
	}
	for (;;) {
		RTHOOK(8);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result != NULL) || (EIF_BOOLEAN)(loc1 == NULL))) break;
		RTHOOK(9);
		loc3 = F1347_12792(RTCW(loc1));
		RTHOOK(10);
		loc1 = loc3;
		loc1 = RTRV(eif_new_type(1347, 0x00), loc1);
		RTHOOK(11);
		loc2 = loc1;
		loc2 = RTRV(eif_new_type(1269, 0x00), loc2);
		RTHOOK(12);
		tb1 = '\0';
		tb2 = '\0';
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			tr1 = F1347_12796(RTCW(loc3));
			loc7 = tr1;
			tb2 = EIF_TEST(loc7);
		}
		if (tb2) {
			tb2 = F1270_11857(loc7);
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(13);
			Result = (EIF_REFERENCE) loc7;
		} else {
			RTHOOK(14);
			tb1 = '\0';
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				tb2 = F1270_11857(RTCW(loc2));
				tb1 = tb2;
			}
			if (tb1) {
				RTHOOK(15);
				Result = (EIF_REFERENCE) loc2;
			}
		}
	}
	RTHOOK(17);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_DOCKABLE_SOURCE_I}.closest_dockable_target */
EIF_REFERENCE F1558_15793 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc3);
	RTLR(4,loc4);
	RTLR(5,tr1);
	RTLR(6,loc5);
	RTLR(7,Result);
	RTLIU(8);
	
	RTEAA("closest_dockable_target", 1557, Current, 5, 0, 22261);
	RTGC;
	RTHOOK(1);
	loc1 = F1549_15609(Current);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTHOOK(3);
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1) + O12205[Dtype(loc1)-1513]);
		loc2 = RTRV(eif_new_type(1269, 0x00), loc2);
		RTHOOK(4);
		loc3 = loc2;
		loc3 = RTRV(eif_new_type(1371, 0x00), loc3);
		RTHOOK(5);
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O13196[Dtype(loc1)-1587]);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			tb2 = F1270_11857(loc4);
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(6);
			RTHOOK(7);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) loc4;
		} else {
			RTHOOK(8);
			tb1 = '\0';
			tb2 = '\0';
			loc5 = loc2;
			if (EIF_TEST(loc5)) {
				tb3 = F1270_11857(loc5);
				tb2 = tb3;
			}
			if (tb2) {
				tb2 = '\0';
				if ((EIF_BOOLEAN)(loc3 != NULL)) {
					tb2 = (EIF_BOOLEAN)(F1558_15808(Current) != NULL);
				}
				tb1 = tb2;
			}
			if (tb1) {
				RTHOOK(9);
				RTHOOK(10);
				RTLE;
				RTEE;
				return (EIF_REFERENCE) loc2;
			} else {
				RTHOOK(11);
				tr1 = F1514_14806(RTCW(loc1));
				Result = F1558_15792(Current, tr1);
			}
		}
	}
	RTHOOK(13);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_DOCKABLE_SOURCE_I}.complete_dock */
void F1558_15804 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc18 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc22 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc23 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc24 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc25 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc26 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc27 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc28 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc29 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc30 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc31 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc32 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc33 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc34 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc35 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc36 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc37 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc38 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc39 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc40 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc41 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc42 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_16 ti2_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(40);
	RTLR(0,Current);
	RTLR(1,loc8);
	RTLR(2,loc29);
	RTLR(3,loc7);
	RTLR(4,loc30);
	RTLR(5,loc32);
	RTLR(6,tr1);
	RTLR(7,loc11);
	RTLR(8,loc14);
	RTLR(9,loc33);
	RTLR(10,loc31);
	RTLR(11,loc34);
	RTLR(12,loc5);
	RTLR(13,loc19);
	RTLR(14,loc13);
	RTLR(15,loc35);
	RTLR(16,loc12);
	RTLR(17,loc10);
	RTLR(18,loc6);
	RTLR(19,loc9);
	RTLR(20,loc3);
	RTLR(21,tr2);
	RTLR(22,tr3);
	RTLR(23,loc36);
	RTLR(24,loc1);
	RTLR(25,loc2);
	RTLR(26,loc37);
	RTLR(27,loc28);
	RTLR(28,loc38);
	RTLR(29,loc39);
	RTLR(30,loc40);
	RTLR(31,loc21);
	RTLR(32,loc24);
	RTLR(33,loc17);
	RTLR(34,loc16);
	RTLR(35,loc15);
	RTLR(36,loc41);
	RTLR(37,loc20);
	RTLR(38,loc42);
	RTLR(39,loc27);
	RTLIU(40);
	
	RTEAA("complete_dock", 1557, Current, 42, 0, 22270);
	RTGC;
	RTHOOK(1);
	*(EIF_REFERENCE *)(Current + O4712[dtype-286]) = (EIF_REFERENCE) NULL;
	RTHOOK(2);
	loc8 = F1558_15793(Current);
	RTHOOK(3);
	loc29 = F1558_15807(Current);
	loc29 = RTRV(eif_new_type(1588, 0), loc29);
	RTHOOK(4);
	if ((EIF_BOOLEAN)(loc29 != NULL)) {
		RTHOOK(5);
		loc7 = F1589_16150(RTCW(loc29));
		loc7 = RTRV(eif_new_type(1363, 0x00), loc7);
	} else {
		RTHOOK(6);
		loc30 = F1558_15808(Current);
		loc30 = RTRV(eif_new_type(1661, 0), loc30);
		RTHOOK(7);
		RTCT0("l_item_source_being_docked /= Void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc30 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		RTHOOK(8);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13843[Dtype(RTCW(loc30))-1666])(loc30);
		loc32 = tr1;
		if (EIF_TEST(loc32)) {
			RTHOOK(9);
			loc7 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10892[Dtype(loc32)-1352])(loc32);
			loc7 = RTRV(eif_new_type(1363, 0x00), loc7);
		}
	}
	RTHOOK(10);
	loc11 = loc8;
	loc11 = RTRV(eif_new_type(1371, 0x00), loc11);
	RTHOOK(11);
	loc14 = loc8;
	loc14 = RTRV(eif_new_type(1347, 0x00), loc14);
	RTHOOK(12);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc29 != NULL) && (EIF_BOOLEAN)(loc14 == NULL)) || (EIF_BOOLEAN) ((EIF_BOOLEAN)(loc30 != NULL) && (EIF_BOOLEAN)(loc11 == NULL)))) {
		RTHOOK(13);
		loc8 = (EIF_REFERENCE) NULL;
	}
	RTHOOK(14);
	if ((EIF_BOOLEAN)(loc8 == NULL)) {
		RTHOOK(15);
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + O4702[dtype-286]);
		loc33 = tr1;
		if (EIF_TEST(loc33)) {
			tb2 = F1558_15789(loc33);
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(16);
			if ((EIF_BOOLEAN)(loc7 == NULL)) {
				RTHOOK(17);
				loc31 = RTLNSMART(eif_new_type(1363, 0).id);
				F1248_11522(RTCW(loc31));
				RTHOOK(18);
				RTAR(Current, loc31);
				*(EIF_REFERENCE *)(Current + O4712[dtype-286]) = (EIF_REFERENCE) loc31;
				RTHOOK(19);
				tb1 = '\0';
				if ((EIF_BOOLEAN)(loc29 != NULL)) {
					tr1 = F1549_15636(RTCW(loc29));
					loc34 = tr1;
					tb1 = EIF_TEST(loc34);
				}
				if (tb1) {
					RTHOOK(20);
					loc5 = *(EIF_REFERENCE *)(loc34 + O12205[Dtype(loc34)-1513]);
					RTHOOK(21);
					tr1 = F1514_14806(RTCW(loc29));
					loc19 = F1347_12792(RTCW(tr1));
					loc19 = RTRV(eif_new_type(1269, 0x00), loc19);
					RTHOOK(22);
					RTCT0("original_parent_not_void", EX_CHECK);
					if ((EIF_BOOLEAN)(loc19 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					RTHOOK(23);
					F1364_13060(RTCW(loc31), loc19);
					RTHOOK(24);
					ti4_1 = F1558_15810(Current, loc29);
					F1364_13061(RTCW(loc31), ti4_1);
				} else {
					RTHOOK(25);
					RTCT0("l_item_source_being_docked /= Void", EX_CHECK);
					if ((EIF_BOOLEAN)(loc30 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					RTHOOK(26);
					loc13 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13844[Dtype(RTCW(loc30))-1666])(loc30);
					loc13 = RTRV(eif_new_type(1588, 0x00), loc13);
					RTHOOK(27);
					RTCT0("parent_is_widget", EX_CHECK);
					if ((EIF_BOOLEAN)(loc13 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					RTHOOK(28);
					tr1 = F1549_15636(RTCW(loc13));
					loc35 = tr1;
					if (EIF_TEST(loc35)) {
						RTHOOK(29);
						loc5 = *(EIF_REFERENCE *)(loc35 + O12205[Dtype(loc35)-1513]);
					}
					RTHOOK(30);
					RTCT0("original_widget_window /= Void", EX_CHECK);
					if ((EIF_BOOLEAN)(loc5 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					RTHOOK(31);
					tr1 = F1514_14806(RTCW(loc30));
					loc12 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10892[Dtype(RTCW(tr1))-1352])(tr1);
					loc12 = RTRV(eif_new_type(1269, 0x00), loc12);
					RTHOOK(32);
					RTCT0("parent_not_void", EX_CHECK);
					if ((EIF_BOOLEAN)(loc12 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					RTHOOK(33);
					F1364_13060(RTCW(loc31), loc12);
					RTHOOK(34);
					loc10 = loc30;
					loc10 = RTRV(eif_new_type(1687, 0x00), loc10);
					RTHOOK(35);
					RTCT0("item_was_tool_bar_button", EX_CHECK);
					if ((EIF_BOOLEAN)(loc10 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					RTHOOK(36);
					ti4_1 = F1558_15810(Current, loc10);
					F1364_13061(RTCW(loc31), ti4_1);
					RTHOOK(37);
					loc11 = loc12;
					loc11 = RTRV(eif_new_type(1371, 0x00), loc11);
					RTHOOK(38);
					RTCT0("tool_bar_not_void", EX_CHECK);
					if ((EIF_BOOLEAN)(loc11 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					RTHOOK(39);
					loc18 = *(EIF_INTEGER_32 *)(RTCW(loc31)+ _LNGOFF_7_4_0_1_);
					loc18 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc18 - ((EIF_INTEGER_32) 1L));
					RTHOOK(40);
					tb1 = '\0';
					tb2 = F724_8337(RTCW(loc11));
					if ((EIF_BOOLEAN) !tb2) {
						tb1 = (EIF_BOOLEAN) (loc18 >= ((EIF_INTEGER_32) 1L));
					}
					if (tb1) {
						RTHOOK(41);
						F1559_15836(Current, loc11, loc18, loc18);
					}
				}
				RTHOOK(42);
				if ((EIF_BOOLEAN)(loc29 != NULL)) {
					RTHOOK(43);
					tr1 = F1514_14806(RTCW(loc29));
					loc6 = F1347_12792(RTCW(tr1));
					loc6 = RTRV(eif_new_type(1351, 0x00), loc6);
					RTHOOK(44);
					tb1 = '\0';
					if ((EIF_BOOLEAN)(loc6 != NULL)) {
						tr1 = F1514_14806(RTCW(loc29));
						tb2 = F1352_12896(RTCW(loc6), tr1);
						tb1 = (EIF_BOOLEAN) !tb2;
					}
					if (tb1) {
						RTHOOK(45);
						F1364_13062(RTCW(loc31));
					}
				}
				RTHOOK(46);
				F1558_15814(Current);
				RTHOOK(47);
				if ((EIF_BOOLEAN)(loc29 != NULL)) {
					RTHOOK(48);
					tr1 = F1514_14806(RTCW(loc29));
					F1348_12833(RTCW(loc31), tr1);
				} else {
					RTHOOK(49);
					RTCT0("l_item_source_being_docked /= Void", EX_CHECK);
					if ((EIF_BOOLEAN)(loc30 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					RTHOOK(50);
					loc11 = RTLNS(eif_new_type(1371, 0x00).id, 1371, _OBJSIZ_5_3_0_1_0_0_0_0_);
					F1248_11522(RTCW(loc11));
					RTHOOK(51);
					F1348_12833(RTCW(loc31), loc11);
					RTHOOK(52);
					loc9 = *(EIF_REFERENCE *)(RTCW(loc30) + O12205[Dtype(loc30)-1513]);
					loc9 = RTRV(eif_new_type(1399, 0x00), loc9);
					RTHOOK(53);
					RTCT0("item_was_tool_bar_button", EX_CHECK);
					if ((EIF_BOOLEAN)(loc9 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					RTHOOK(54);
					F1341_12738(RTCW(loc11), loc9);
				}
				RTHOOK(55);
				loc3 = *(EIF_REFERENCE *)(RTCW(loc31) + _REFACS_3_);
				loc3 = RTRV(eif_new_type(1610, 0x00), loc3);
				RTHOOK(56);
				RTCT0("dialog_imp_not_void", EX_CHECK);
				if ((EIF_BOOLEAN)(loc3 != NULL)) {
					RTCK0;
				} else {
					RTCF0;
				}
				RTHOOK(57);
				F1619_16645(RTCW(loc3));
				RTHOOK(58);
				tr1 = F1179_10684(RTCW(loc31));
				{
					EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1186,0,1363,0xFFFF};
					EIF_TYPE typres0;
					typarr0[3] = dftype;
					
					typres0 = eif_compound_id(dftype, typarr0);
					tr2 = RTLNTS(typres0.id, 3, 0);
				}
				((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
				RTAR(tr2,Current);
				((EIF_TYPED_VALUE *)tr2+2)->it_r = loc31;
				RTAR(tr2,loc31);
				
				{
					static EIF_TYPE_INDEX typarr0[] = {1230,0xFFF9,0,1186,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr3= RTLNRF(typres0.id, (EIF_POINTER) __A844_100, (EIF_POINTER) _A844_100, (EIF_POINTER)(F1558_15805),tr2, 1, 0);
				}
				F909_8875(RTCW(tr1), tr3);
				RTHOOK(59);
				F1558_15812(Current, loc31);
				RTHOOK(60);
				tb1 = '\0';
				tr1 = *(EIF_REFERENCE *)(Current + O4701[dtype-286]);
				loc36 = tr1;
				if (EIF_TEST(loc36)) {
					tb2 = F1558_15791(loc36);
					tb1 = tb2;
				}
				if (tb1) {
					RTHOOK(61);
					RTCT0("original_widget_window /= Void", EX_CHECK);
					if ((EIF_BOOLEAN)(loc5 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					RTHOOK(62);
					F1363_13053(RTCW(loc31), loc5);
				} else {
					RTHOOK(63);
					F1359_12983(RTCW(loc31));
				}
				RTHOOK(64);
				loc1 = loc31;
				loc1 = RTRV(eif_new_type(1347, 0x00), loc1);
			} else {
				RTHOOK(65);
				F1558_15812(Current, loc7);
			}
			RTHOOK(66);
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O2304[dtype-172]) != NULL)) {
				RTHOOK(67);
				tr1 = F173_2326(Current);
				F917_8946(RTCW(tr1), NULL);
			}
		}
	} else {
		RTHOOK(68);
		loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(69);
		loc2 = *(EIF_REFERENCE *)(RTCW(loc8) + O9889[Dtype(loc8)-1247]);
		loc2 = RTRV(eif_new_type(1588, 0x00), loc2);
		RTHOOK(70);
		RTCT0("target_widget_not_void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		RTHOOK(71);
		loc1 = *(EIF_REFERENCE *)(RTCW(loc2) + O12205[Dtype(loc2)-1513]);
		loc1 = RTRV(eif_new_type(1347, 0x00), loc1);
	}
	RTHOOK(72);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc7 == NULL) || (EIF_BOOLEAN)(loc8 != NULL)) && (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O4712[dtype-286]) == NULL))) {
		RTHOOK(73);
		loc11 = loc8;
		loc11 = RTRV(eif_new_type(1371, 0x00), loc11);
		RTHOOK(74);
		if ((EIF_BOOLEAN) !(EIF_BOOLEAN) ((EIF_BOOLEAN)(loc11 != NULL) && (EIF_BOOLEAN)(loc29 != NULL))) {
			RTHOOK(75);
			loc26 = '\0';
			tr1 = RTLNS(eif_new_type(1258, 0x00).id, 1258, _OBJSIZ_2_0_0_0_0_0_0_0_);
			F1248_11522(RTCW(tr1));
			tr1 = F1259_11732(RTCW(tr1));
			loc37 = tr1;
			if (EIF_TEST(loc37)) {
				tr1 = F1262_11760(loc37);
				loc26 = (EIF_BOOLEAN)(tr1 == NULL);
			}
			RTHOOK(76);
			RTCT0("l_widget_source_being_docked /= Void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc29 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			RTHOOK(77);
			tb1 = '\0';
			if (loc26) {
				tr1 = F1549_15637(RTCW(loc29));
				tb1 = (EIF_BOOLEAN)(tr1 != NULL);
			}
			if (tb1) {
				RTHOOK(78);
				RTCT0("container /= Void", EX_CHECK);
				if ((EIF_BOOLEAN)(loc14 != NULL)) {
					RTCK0;
				} else {
					RTCF0;
				}
				RTHOOK(79);
				loc28 = *(EIF_REFERENCE *)(RTCW(loc14) + O9889[Dtype(loc14)-1247]);
				loc28 = RTRV(eif_new_type(1590, 0x00), loc28);
				RTHOOK(80);
				RTCT0("container_not_void", EX_CHECK);
				if ((EIF_BOOLEAN)(loc28 != NULL)) {
					RTCK0;
				} else {
					RTCF0;
				}
				RTHOOK(81);
				tr1 = F1549_15636(RTCW(loc28));
				loc38 = tr1;
				if (EIF_TEST(loc38)) {
					RTHOOK(82);
					F1608_16405(loc38);
				}
			}
			RTHOOK(83);
			tr1 = F1347_12792(RTCV(RTOUCR(313,F287_4810, (Current))));
			if ((EIF_BOOLEAN)(tr1 != NULL)) {
				RTHOOK(84);
				F1558_15814(Current);
				RTHOOK(85);
				F1558_15815(Current);
			}
			RTHOOK(86);
			loc39 = loc7;
			if (EIF_TEST(loc39)) {
				RTHOOK(87);
				F1359_12968(loc39);
			}
			RTHOOK(88);
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O2304[dtype-172]) != NULL)) {
				RTHOOK(89);
				tr1 = F173_2326(Current);
				F917_8946(RTCW(tr1), NULL);
			}
		} else {
			RTHOOK(90);
			loc40 = loc7;
			if (EIF_TEST(loc40)) {
				RTHOOK(91);
				F1558_15812(Current, loc40);
			}
		}
	}
	RTHOOK(92);
	if ((EIF_BOOLEAN)(loc29 == NULL)) {
		RTHOOK(93);
		RTCT0("l_item_source_being_docked /= Void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc30 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		RTHOOK(94);
		loc9 = *(EIF_REFERENCE *)(RTCW(loc30) + O12205[Dtype(loc30)-1513]);
		loc9 = RTRV(eif_new_type(1399, 0x00), loc9);
		RTHOOK(95);
		RTCT0("tool_bar_button_not_void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc9 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		RTHOOK(96);
		loc11 = loc8;
		loc11 = RTRV(eif_new_type(1371, 0x00), loc11);
		RTHOOK(97);
		if ((EIF_BOOLEAN)(loc11 != NULL)) {
			RTHOOK(98);
			tr1 = F1398_13403(RTCV(RTOUCR(562,F287_4813, (Current))));
			if ((EIF_BOOLEAN)(tr1 != NULL)) {
				RTHOOK(99);
				loc21 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13843[Dtype(RTCW(loc30))-1666])(loc30);
				loc21 = RTRV(eif_new_type(1371, 0x00), loc21);
				RTHOOK(100);
				RTCT0("original_tool_bar_not_void", EX_CHECK);
				if ((EIF_BOOLEAN)(loc21 != NULL)) {
					RTCK0;
				} else {
					RTCF0;
				}
				RTHOOK(101);
				loc24 = loc9;
				loc24 = RTRV(eif_new_type(1397, 0x00), loc24);
				RTHOOK(102);
				RTCT0("tool_bar_item /= Void", EX_CHECK);
				if ((EIF_BOOLEAN)(loc24 != NULL)) {
					RTCK0;
				} else {
					RTCF0;
				}
				RTHOOK(103);
				tr1 = RTOUCR(562,F287_4813, (Current));
				loc22 = F1341_12724(RTCW(loc21), tr1, ((EIF_INTEGER_32) 1L));
				RTHOOK(104);
				loc23 = F1341_12724(RTCW(loc21), loc24, ((EIF_INTEGER_32) 1L));
				RTHOOK(105);
				tr1 = F1398_13403(RTCW(loc24));
				loc25 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 == loc11);
				RTHOOK(106);
				F1558_15814(Current);
				RTHOOK(107);
				F1558_15816(Current);
				RTHOOK(108);
				if ((EIF_BOOLEAN) (loc25 && (EIF_BOOLEAN)(loc23 == (EIF_INTEGER_32) (loc22 + ((EIF_INTEGER_32) 2L))))) {
					RTHOOK(109);
					F1559_15836(Current, loc11, (EIF_INTEGER_32) (loc22 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (loc22 + ((EIF_INTEGER_32) 1L)));
				}
				RTHOOK(110);
				if ((EIF_BOOLEAN)(loc21 == loc11)) {
					RTHOOK(111);
					loc17 = *(EIF_REFERENCE *)(RTCW(loc11) + _REFACS_3_);
					loc17 = RTRV(eif_new_type(1642, 0x00), loc17);
					RTHOOK(112);
					RTCT0("tool_bar_imp_not_void", EX_CHECK);
					if ((EIF_BOOLEAN)(loc17 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					RTHOOK(113);
					{
						/* INLINED CODE (EV_TOOL_BAR_IMP.block_selection_for_docking) */
						(void) RTCW(loc17);
						/* END INLINED CODE */
					}
					;
				}
			} else {
				RTHOOK(114);
				loc17 = *(EIF_REFERENCE *)(RTCW(loc11) + _REFACS_3_);
				loc17 = RTRV(eif_new_type(1642, 0x00), loc17);
				RTHOOK(115);
				RTCT0("tool_bar_imp_not_void", EX_CHECK);
				if ((EIF_BOOLEAN)(loc17 != NULL)) {
					RTCK0;
				} else {
					RTCF0;
				}
				RTHOOK(116);
				ti4_1 = F1643_16921(RTCW(loc17));
				tr1 = F1341_12723(RTCW(loc11), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
				if ((EIF_BOOLEAN)(tr1 == loc9)) {
					RTHOOK(117);
					loc18 = F1341_12724(RTCW(loc11), loc9, ((EIF_INTEGER_32) 1L));
					RTHOOK(118);
					ti4_1 = F1341_12727(RTCW(loc11));
					if ((EIF_BOOLEAN) (loc18 < ti4_1)) {
						RTHOOK(119);
						loc16 = F1341_12723(RTCW(loc11), (EIF_INTEGER_32) (loc18 + ((EIF_INTEGER_32) 1L)));
						loc16 = RTRV(eif_new_type(1398, 0x00), loc16);
					}
					RTHOOK(120);
					if ((EIF_BOOLEAN) (loc18 > ((EIF_INTEGER_32) 1L))) {
						RTHOOK(121);
						loc15 = F1341_12723(RTCW(loc11), (EIF_INTEGER_32) (loc18 - ((EIF_INTEGER_32) 1L)));
						loc15 = RTRV(eif_new_type(1398, 0x00), loc15);
					}
					RTHOOK(122);
					tr1 = F1281_11971(RTCV(RTOUCR(563,F287_4817, (Current))));
					ti4_1 = F1300_12386(RTCW(tr1));
					ti2_1 = *(EIF_INTEGER_16 *)(Current + O4714[dtype-286]);
					ti4_2 = (EIF_INTEGER_32) ti2_1;
					if ((EIF_BOOLEAN) (ti4_1 > ti4_2)) {
						RTHOOK(123);
						if ((EIF_BOOLEAN)(loc16 != NULL)) {
							RTHOOK(124);
							F1341_12747(RTCW(loc11), loc16);
						} else {
							RTHOOK(125);
							if ((EIF_BOOLEAN)(loc15 == NULL)) {
								RTHOOK(126);
								ti4_1 = F1341_12724(RTCW(loc11), loc9, ((EIF_INTEGER_32) 1L));
								F1341_12733(RTCW(loc11), ti4_1);
								RTHOOK(127);
								tr1 = RTLNS(eif_new_type(1398, 0x00).id, 1398, _OBJSIZ_6_0_0_1_0_0_0_0_);
								F1248_11522(RTCW(tr1));
								F1341_12742(RTCW(loc11), tr1);
							}
						}
					} else {
						RTHOOK(128);
						if ((EIF_BOOLEAN)(loc15 != NULL)) {
							RTHOOK(129);
							F1341_12747(RTCW(loc11), loc15);
						} else {
							RTHOOK(130);
							if ((EIF_BOOLEAN)(loc16 == NULL)) {
								RTHOOK(131);
								ti4_1 = F1341_12724(RTCW(loc11), loc9, ((EIF_INTEGER_32) 1L));
								F1341_12733(RTCW(loc11), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
								RTHOOK(132);
								tr1 = RTLNS(eif_new_type(1398, 0x00).id, 1398, _OBJSIZ_6_0_0_1_0_0_0_0_);
								F1248_11522(RTCW(tr1));
								F1341_12742(RTCW(loc11), tr1);
							}
						}
					}
					RTHOOK(133);
					loc22 = F1341_12724(RTCW(loc11), loc9, ((EIF_INTEGER_32) 1L));
					RTHOOK(134);
					F1559_15836(Current, loc11, loc22, loc22);
				}
			}
		}
		RTHOOK(135);
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O2304[dtype-172]) != NULL)) {
			RTHOOK(136);
			tr1 = F173_2326(Current);
			F917_8946(RTCW(tr1), NULL);
		}
	}
	RTHOOK(137);
	tr1 = *(EIF_REFERENCE *)(Current + O4701[dtype-286]);
	loc41 = tr1;
	if (EIF_TEST(loc41)) {
		RTHOOK(138);
		loc20 = *(EIF_REFERENCE *)(loc41 + O12205[Dtype(loc41)-1513]);
		loc20 = RTRV(eif_new_type(1346, 0x00), loc20);
		RTHOOK(139);
		if ((EIF_BOOLEAN)(loc20 != NULL)) {
			RTHOOK(140);
			tr1 = F1178_10666(RTCW(loc20));
			F916_8919(RTCW(tr1));
		} else {
			RTHOOK(141);
			loc9 = *(EIF_REFERENCE *)(loc41 + O12205[Dtype(loc41)-1513]);
			loc9 = RTRV(eif_new_type(1399, 0x00), loc9);
			RTHOOK(142);
			if ((EIF_BOOLEAN)(loc9 != NULL)) {
				RTHOOK(143);
				tr1 = (RTNA((RTCW(loc9))), ((EIF_REFERENCE) 0));
				F916_8919(RTCW(tr1));
			} else {
				RTHOOK(144);
				RTCT0("type_not_supported", EX_CHECK);
					RTCF0;
			}
		}
	}
	RTHOOK(145);
	*(EIF_REFERENCE *)(Current + O4701[dtype-286]) = (EIF_REFERENCE) NULL;
	RTHOOK(146);
	tb1 = '\0';
	if (loc26) {
		tr1 = RTLNS(eif_new_type(1258, 0x00).id, 1258, _OBJSIZ_2_0_0_0_0_0_0_0_);
		F1248_11522(RTCW(tr1));
		tr1 = F1259_11732(RTCW(tr1));
		loc42 = tr1;
		tb1 = EIF_TEST(loc42);
	}
	if (tb1) {
		RTHOOK(147);
		loc27 = F1262_11760(loc42);
		RTHOOK(148);
		if ((EIF_BOOLEAN)(loc27 != NULL)) {
			RTHOOK(149);
			F1359_12982(RTCW(loc27));
		}
	}
	RTHOOK(153);
	RTLE;
	RTEE;
}

/* {EV_DOCKABLE_SOURCE_I}.close_dockable_dialog */
void F1558_15805 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(15);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc3);
	RTLR(3,loc4);
	RTLR(4,loc5);
	RTLR(5,loc6);
	RTLR(6,loc7);
	RTLR(7,loc8);
	RTLR(8,loc10);
	RTLR(9,loc11);
	RTLR(10,loc12);
	RTLR(11,tr1);
	RTLR(12,loc9);
	RTLR(13,Current);
	RTLR(14,tr2);
	RTLIU(15);
	
	RTEAA("close_dockable_dialog", 1557, Current, 12, 1, 22271);
	RTGC;
	RTHOOK(1);
	loc1 = F1348_12824(RTCW(arg1));
	RTHOOK(2);
	F1355_12919(RTCW(arg1));
	RTHOOK(3);
	loc3 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
	loc3 = RTRV(eif_new_type(1354, 0x00), loc3);
	RTHOOK(4);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		tb2 = F1355_12911(RTCW(loc3));
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(5);
		F1348_12833(RTCW(loc3), loc1);
	}
	RTHOOK(6);
	loc4 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
	loc4 = RTRV(eif_new_type(1348, 0x00), loc4);
	RTHOOK(7);
	if ((EIF_BOOLEAN)(loc4 != NULL)) {
		RTHOOK(8);
		loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_7_4_0_1_);
		RTHOOK(9);
		tb1 = F835_8627(RTCW(loc4), loc2);
		if (tb1) {
			RTHOOK(10);
			F1341_12733(RTCW(loc4), loc2);
		} else {
			RTHOOK(11);
			ti4_1 = F1341_12727(RTCW(loc4));
			F1341_12733(RTCW(loc4), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
		}
		RTHOOK(12);
		F1341_12742(RTCW(loc4), loc1);
		RTHOOK(13);
		loc5 = loc4;
		loc5 = RTRV(eif_new_type(1351, 0x00), loc5);
		RTHOOK(14);
		if ((EIF_BOOLEAN)(loc5 != NULL)) {
			RTHOOK(15);
			tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_7_3_);
			if (tb1) {
				RTHOOK(16);
				F1352_12903(RTCW(loc5), loc1);
			}
		}
	}
	RTHOOK(17);
	loc6 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
	loc6 = RTRV(eif_new_type(1371, 0x00), loc6);
	RTHOOK(18);
	if ((EIF_BOOLEAN)(loc6 != NULL)) {
		RTHOOK(19);
		loc7 = loc1;
		loc7 = RTRV(eif_new_type(1371, 0x00), loc7);
		RTHOOK(20);
		RTCT0("old_parent_was_tool_bar", EX_CHECK);
		if ((EIF_BOOLEAN)(loc7 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		RTHOOK(21);
		loc8 = F1341_12723(RTCW(loc7), ((EIF_INTEGER_32) 1L));
		loc8 = RTRV(eif_new_type(1399, 0x00), loc8);
		RTHOOK(22);
		RTCT0("tool_bar_button /= Void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc8 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		RTHOOK(23);
		F1341_12751(RTCW(loc7));
		RTHOOK(24);
		loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_7_4_0_1_);
		RTHOOK(25);
		tb1 = F835_8627(RTCW(loc6), loc2);
		if (tb1) {
			RTHOOK(26);
			F1341_12733(RTCW(loc6), loc2);
		} else {
			RTHOOK(27);
			ti4_1 = F1341_12727(RTCW(loc6));
			F1341_12733(RTCW(loc6), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
		}
		RTHOOK(28);
		F1341_12742(RTCW(loc6), loc8);
		RTHOOK(29);
		loc10 = (EIF_REFERENCE) loc8;
	} else {
		RTHOOK(30);
		loc10 = (EIF_REFERENCE) loc1;
	}
	RTHOOK(31);
	tb1 = '\0';
	loc11 = arg1;
	if (EIF_TEST(loc11)) {
		tr1 = *(EIF_REFERENCE *)(loc11 + _REFACS_6_);
		loc12 = tr1;
		tb1 = EIF_TEST(loc12);
	}
	if (tb1) {
		RTHOOK(32);
		loc9 = *(EIF_REFERENCE *)(loc12 + O9889[Dtype(loc12)-1247]);
		loc9 = RTRV(eif_new_type(1563, 0x00), loc9);
	}
	RTHOOK(33);
	RTCT0("target_not_void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc9 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(34);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc9) + _REFACS_2_);
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		RTHOOK(35);
		tr1 = F180_3423(RTCW(loc9));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1265,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr2 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = loc10;
		RTAR(tr2,loc10);
		F917_8946(RTCW(tr1), tr2);
	}
	RTHOOK(36);
	F1359_12968(RTCW(arg1));
	RTHOOK(38);
	RTLE;
	RTEE;
}

/* {EV_DOCKABLE_SOURCE_I}.drag_cursor */
static EIF_REFERENCE F1558_15806_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(564)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("drag_cursor", 1557, Current, 0, 0, 22272);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(65, 0x00).id, 65, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = RTOUCR(324,F66_1140, (RTCW(tr1)));
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1558_15806 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(564,F1558_15806_body,(Current));
}

/* {EV_DOCKABLE_SOURCE_I}.widget_source_being_docked */
EIF_REFERENCE F1558_15807 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTEAA("widget_source_being_docked", 1557, Current, 2, 0, 22273);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O4701[dtype-286]);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTHOOK(2);
		loc1 = *(EIF_REFERENCE *)(loc2 + O12205[Dtype(loc2)-1513]);
		loc1 = RTRV(eif_new_type(1346, 0x00), loc1);
		RTHOOK(3);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTHOOK(4);
			Result = *(EIF_REFERENCE *)(Current + O4701[dtype-286]);
			RTHOOK(5);
			RTLE;
			RTEE;
			return RTRV(eif_new_type(1588, 0x00), Result);
		}
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_DOCKABLE_SOURCE_I}.item_source_being_docked */
EIF_REFERENCE F1558_15808 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	
	
	RTEAA("item_source_being_docked", 1557, Current, 0, 0, 22274);
	RTHOOK(1);
	Result = *(EIF_REFERENCE *)(Current + O4701[Dtype(Current)-286]);
	RTHOOK(2);
	RTEE;
	return RTRV(eif_new_type(1661, 0x00), Result);
}

/* {EV_DOCKABLE_SOURCE_I}.position_in_parent */
EIF_INTEGER_32 F1558_15810 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc4);
	RTLR(5,loc5);
	RTLR(6,Current);
	RTLIU(7);
	
	RTEAA("position_in_parent", 1557, Current, 5, 1, 22275);
	RTGC;
	RTHOOK(1);
	loc3 = *(EIF_REFERENCE *)(RTCW(arg1) + O12205[Dtype(arg1)-1513]);
	loc3 = RTRV(eif_new_type(1346, 0x00), loc3);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		RTHOOK(3);
		loc1 = F1347_12792(RTCW(loc3));
		loc1 = RTRV(eif_new_type(1354, 0x00), loc1);
		RTHOOK(4);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTHOOK(5);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		}
		RTHOOK(6);
		loc2 = F1347_12792(RTCW(loc3));
		loc2 = RTRV(eif_new_type(1351, 0x00), loc2);
		RTHOOK(7);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			RTHOOK(8);
			Result = F1341_12724(RTCW(loc2), loc3, ((EIF_INTEGER_32) 1L));
			RTHOOK(9);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) Result;
		}
	} else {
		RTHOOK(10);
		loc4 = *(EIF_REFERENCE *)(RTCW(arg1) + O12205[Dtype(arg1)-1513]);
		loc4 = RTRV(eif_new_type(1399, 0x00), loc4);
		RTHOOK(11);
		RTCT0("source_was_widget_or_tool_bar_button", EX_CHECK);
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		RTHOOK(12);
		loc5 = (RTNA((RTCW(loc4))), ((EIF_REFERENCE) 0));
		loc5 = RTRV(eif_new_type(1371, 0x00), loc5);
		RTHOOK(13);
		RTCT0("tool_bar /= Void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc5 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		RTHOOK(14);
		Result = F1341_12724(RTCW(loc5), loc4, ((EIF_INTEGER_32) 1L));
		RTHOOK(15);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) Result;
	}
	RTHOOK(16);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_DOCKABLE_SOURCE_I}.initialize_transport */
void F1558_15811 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_16 ti2_1;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg3);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTEAA("initialize_transport", 1557, Current, 3, 3, 22276);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O2303[dtype-172]) != NULL)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + O2303[dtype-172]);
		F917_8946(RTCW(tr1), NULL);
	}
	RTHOOK(3);
	loc1 = arg3;
	loc1 = RTRV(eif_new_type(1346, 0x00), loc1);
	RTHOOK(4);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTHOOK(5);
		tr1 = F1178_10666(RTCW(loc1));
		F916_8917(RTCW(tr1));
	} else {
		RTHOOK(6);
		loc2 = arg3;
		loc2 = RTRV(eif_new_type(1399, 0x00), loc2);
		RTHOOK(7);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			RTHOOK(8);
			tr1 = (RTNA((RTCW(loc2))), ((EIF_REFERENCE) 0));
			F916_8917(RTCW(tr1));
		} else {
			
		}
	}
	RTHOOK(10);
	tr1 = F1266_11817(RTCW(arg3));
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTHOOK(11);
		tr1 = *(EIF_REFERENCE *)(loc3 + O9889[Dtype(loc3)-1247]);
		*(EIF_REFERENCE *)(Current + O4701[dtype-286]) = RTRV(eif_new_type(1557, 0), tr1);
		RTAR(Current, tr1);
	} else {
		RTHOOK(12);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + O9889[Dtype(arg3)-1247]);
		*(EIF_REFERENCE *)(Current + O4701[dtype-286]) = RTRV(eif_new_type(1557, 0), tr1);
		RTAR(Current, tr1);
	}
	RTHOOK(13);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + O9889[Dtype(arg3)-1247]);
	*(EIF_REFERENCE *)(Current + O4702[dtype-286]) = RTRV(eif_new_type(1557, 0), tr1);
	RTAR(Current, tr1);
	RTHOOK(14);
	ti2_1 = (EIF_INTEGER_16) arg1;
	*(EIF_INTEGER_16 *)(Current + O4714[dtype-286]) = (EIF_INTEGER_16) ti2_1;
	RTHOOK(15);
	ti2_1 = (EIF_INTEGER_16) arg2;
	*(EIF_INTEGER_16 *)(Current + O4715[dtype-286]) = (EIF_INTEGER_16) ti2_1;
	RTHOOK(17);
	RTLE;
	RTEE;
}

/* {EV_DOCKABLE_SOURCE_I}.move_dialog_to_pointer */
void F1558_15812 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_16 ti2_1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("move_dialog_to_pointer", 1557, Current, 3, 1, 22277);
	RTGC;
	RTHOOK(1);
	loc3 = F1268_11844(RTCW(arg1));
	ti4_1 = F1348_12839(RTCW(arg1));
	ti4_2 = F1268_11843(RTCW(arg1));
	ti4_3 = F1348_12838(RTCW(arg1));
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc3 - ti4_1) - (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_2 - ti4_3) / ((EIF_INTEGER_32) 2L)));
	RTHOOK(2);
	tr1 = F1281_11971(RTCV(RTOUCR(563,F287_4817, (Current))));
	loc1 = F1300_12386(RTCW(tr1));
	RTHOOK(3);
	tr1 = F1281_11971(RTCV(RTOUCR(563,F287_4817, (Current))));
	loc2 = F1300_12388(RTCW(tr1));
	RTHOOK(4);
	ti2_1 = *(EIF_INTEGER_16 *)(Current + O4703[dtype-286]);
	ti4_1 = (EIF_INTEGER_32) ti2_1;
	F1269_11849(RTCW(arg1), (EIF_INTEGER_32) (loc1 - ti4_1));
	RTHOOK(5);
	ti2_1 = *(EIF_INTEGER_16 *)(Current + O4704[dtype-286]);
	ti4_1 = (EIF_INTEGER_32) ti2_1;
	F1269_11850(RTCW(arg1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 - ti4_1) - loc3));
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_DOCKABLE_SOURCE_I}.execute_dragging */
void F1558_15813 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc12 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc13 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTLD;
	
	RTLI(16);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc15);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc16);
	RTLR(6,loc4);
	RTLR(7,loc6);
	RTLR(8,tr2);
	RTLR(9,loc14);
	RTLR(10,loc5);
	RTLR(11,loc17);
	RTLR(12,loc18);
	RTLR(13,loc19);
	RTLR(14,loc11);
	RTLR(15,loc10);
	RTLIU(16);
	
	RTEAA("execute_dragging", 1557, Current, 19, 7, 22278);
	RTGC;
	RTHOOK(1);
	loc2 = F1558_15793(Current);
	RTHOOK(2);
	tr1 = F1558_15807(Current);
	loc15 = tr1;
	if (EIF_TEST(loc15)) {
		RTHOOK(3);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			tb1 = (EIF_BOOLEAN)(loc2 != RTOUCR(313,F287_4810, (Current)));
		}
		if (tb1) {
			RTHOOK(4);
			loc3 = loc2;
			loc3 = RTRV(eif_new_type(1347, 0x00), loc3);
			RTHOOK(5);
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				RTHOOK(6);
				tr1 = F1270_11856(RTCW(loc2));
				if ((EIF_BOOLEAN)(tr1 != NULL)) {
					RTHOOK(7);
					loc12 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
				RTHOOK(8);
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				for (;;) {
					RTHOOK(9);
					tb1 = '\01';
					tb2 = '\01';
					if (!(EIF_BOOLEAN)(loc2 == NULL)) {
						tb3 = '\0';
						if ((EIF_BOOLEAN)(loc2 != NULL)) {
							tr1 = F1270_11856(RTCW(loc2));
							tb3 = (EIF_BOOLEAN)(tr1 == NULL);
						}
						tb2 = tb3;
					}
					if (!tb2) {
						tb2 = '\0';
						tb3 = '\0';
						if ((EIF_BOOLEAN)(loc2 != NULL)) {
							tr1 = F1270_11856(RTCW(loc2));
							tb3 = (EIF_BOOLEAN)(tr1 != NULL);
						}
						if (tb3) {
							tb2 = (EIF_BOOLEAN) !loc12;
						}
						tb1 = tb2;
					}
					if (tb1) break;
					RTHOOK(10);
					loc1++;
					RTHOOK(11);
					tr1 = F1270_11856(RTCW(loc2));
					loc16 = tr1;
					if (EIF_TEST(loc16)) {
						RTHOOK(12);
						tr1 = F1514_14806(loc15);
						tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(loc16+ _PTROFF_4_3_0_3_0_0_))(
							*(EIF_POINTER *)(loc16+ _PTROFF_4_3_0_3_0_1_),
							*(EIF_REFERENCE *)(loc16 + _REFACS_1_), tr1);
						loc12 = tb2;
						RTHOOK(13);
						if (loc12) {
							RTHOOK(14);
							loc2 = F1558_15792(Current, loc3);
						}
					}
				}
				RTHOOK(15);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					RTHOOK(16);
					loc3 = loc2;
					loc3 = RTRV(eif_new_type(1347, 0x00), loc3);
					RTHOOK(17);
					RTCT0("container_not_void", EX_CHECK);
					if ((EIF_BOOLEAN)(loc3 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					RTHOOK(18);
					tr1 = F1347_12792(RTCV(RTOUCR(313,F287_4810, (Current))));
					if ((EIF_BOOLEAN)(tr1 != loc3)) {
						RTHOOK(19);
						F287_4812(Current);
					}
					RTHOOK(20);
					loc4 = *(EIF_REFERENCE *)(RTCW(loc3) + O9889[Dtype(loc3)-1247]);
					loc4 = RTRV(eif_new_type(1600, 0x00), loc4);
					RTHOOK(21);
					loc6 = *(EIF_REFERENCE *)(RTCW(loc3) + O9889[Dtype(loc3)-1247]);
					loc6 = RTRV(eif_new_type(1603, 0x00), loc6);
				}
			}
			RTHOOK(22);
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				RTHOOK(23);
				loc7 = F1598_16324(RTCW(loc4));
				RTHOOK(24);
				if ((EIF_BOOLEAN)(loc7 != ((EIF_INTEGER_32) -1L))) {
					RTHOOK(25);
					tb2 = '\01';
					ti4_1 = F1542_15549(RTCW(loc4));
					if (!(EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
						tb3 = '\01';
						ti4_1 = F1542_15549(RTCW(loc4));
						ti4_1 = eif_min_int32 (loc7,ti4_1);
						tr1 = F1542_15548(RTCW(loc4), ti4_1);
						if (!(EIF_BOOLEAN)(tr1 == RTOUCR(313,F287_4810, (Current)))) {
							ti4_1 = eif_max_int32 ((EIF_INTEGER_32) (loc7 - ((EIF_INTEGER_32) 1L)),((EIF_INTEGER_32) 1L));
							tr1 = F1542_15548(RTCW(loc4), ti4_1);
							tb3 = (EIF_BOOLEAN)(tr1 == RTOUCR(313,F287_4810, (Current)));
						}
						tb2 = (EIF_BOOLEAN) !tb3;
					}
					if (tb2) {
						RTHOOK(26);
						tr1 = *(EIF_REFERENCE *)(loc15 + O12205[Dtype(loc15)-1513]);
						loc8 = F1541_15518(RTCW(loc4), tr1, ((EIF_INTEGER_32) 1L));
						RTHOOK(27);
						tb2 = '\0';
						tr1 = F1589_16150(loc15);
						tr2 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_26_);
						if ((EIF_BOOLEAN)(tr1 == tr2)) {
							tb2 = (EIF_BOOLEAN) ((EIF_BOOLEAN)(loc8 == loc7) || (EIF_BOOLEAN)(loc8 == (EIF_INTEGER_32) (loc7 - ((EIF_INTEGER_32) 1L))));
						}
						if (tb2) {
							RTHOOK(28);
							tr1 = *(EIF_REFERENCE *)(loc15 + O12205[Dtype(loc15)-1513]);
							loc13 = F1541_15518(RTCW(loc4), tr1, ((EIF_INTEGER_32) 1L));
							RTHOOK(29);
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc13 == loc7) || (EIF_BOOLEAN)((EIF_INTEGER_32) (loc13 + ((EIF_INTEGER_32) 1L)) == loc7))) {
								RTHOOK(30);
								F287_4812(Current);
							}
						} else {
							RTHOOK(31);
							tr1 = F1347_12792(RTCV(RTOUCR(313,F287_4810, (Current))));
							if ((EIF_BOOLEAN)(tr1 != NULL)) {
								RTHOOK(32);
								tr1 = RTOUCR(565,F287_4811, (Current));
								loc9 = F1558_15810(Current, tr1);
								RTHOOK(33);
								if ((EIF_BOOLEAN) (loc9 < loc7)) {
									RTHOOK(34);
									loc7--;
								}
							}
							RTHOOK(35);
							loc14 = F1549_15636(RTCW(loc4));
							RTHOOK(36);
							RTCT0("l_top_level_window_imp /= Void", EX_CHECK);
							if ((EIF_BOOLEAN)(loc14 != NULL)) {
								RTCK0;
							} else {
								RTCF0;
							}
							RTHOOK(37);
							F1608_16405(RTCW(loc14));
							RTHOOK(38);
							F287_4812(Current);
							RTHOOK(39);
							loc5 = F1541_15514(RTCW(loc4));
							RTHOOK(40);
							F1541_15527(RTCW(loc4), loc7);
							RTHOOK(41);
							tr1 = RTOUCR(313,F287_4810, (Current));
							F1541_15535(RTCW(loc4), tr1);
							RTHOOK(42);
							tr1 = RTOUCR(313,F287_4810, (Current));
							F1601_16341(RTCW(loc4), tr1, (EIF_BOOLEAN) 0);
							RTHOOK(43);
							F1541_15528(RTCW(loc4), loc5);
							RTHOOK(44);
							F1608_16406(RTCW(loc14));
						}
					}
				}
			}
			RTHOOK(45);
			if ((EIF_BOOLEAN)(loc6 != NULL)) {
				RTHOOK(46);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc6) + O13427[Dtype(loc6)-1611]);
				if ((EIF_BOOLEAN)(tr1 == NULL)) {
					RTHOOK(47);
					F287_4812(Current);
					RTHOOK(48);
					tr1 = RTOUCR(313,F287_4810, (Current));
					F1604_16354(RTCW(loc6), tr1);
				}
			}
		} else {
			RTHOOK(49);
			if ((EIF_BOOLEAN)(loc2 != RTOUCR(313,F287_4810, (Current)))) {
				RTHOOK(50);
				F287_4812(Current);
			}
		}
	} else {
		RTHOOK(51);
		tb2 = '\0';
		loc17 = loc2;
		if (EIF_TEST(loc17)) {
			tr1 = F1558_15808(Current);
			loc18 = tr1;
			tb2 = EIF_TEST(loc18);
		}
		if (tb2) {
			RTHOOK(52);
			tr1 = F1270_11856(loc17);
			loc19 = tr1;
			if (EIF_TEST(loc19)) {
				RTHOOK(53);
				loc11 = *(EIF_REFERENCE *)(loc18 + O12205[Dtype(loc18)-1513]);
				loc11 = RTRV(eif_new_type(1399, 0x00), loc11);
				
				RTHOOK(55);
				if ((EIF_BOOLEAN)(loc11 != NULL)) {
					RTHOOK(56);
					tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(loc19+ _PTROFF_4_3_0_3_0_0_))(
						*(EIF_POINTER *)(loc19+ _PTROFF_4_3_0_3_0_1_),
						*(EIF_REFERENCE *)(loc19 + _REFACS_1_), loc11);
					tb2 = tb2;
					if ((EIF_BOOLEAN) !tb2) {
						RTHOOK(57);
						loc10 = *(EIF_REFERENCE *)(loc17 + O9889[Dtype(loc17)-1247]);
						loc10 = RTRV(eif_new_type(1642, 0x00), loc10);
					}
				}
			} else {
				RTHOOK(58);
				loc10 = *(EIF_REFERENCE *)(loc17 + O9889[Dtype(loc17)-1247]);
				loc10 = RTRV(eif_new_type(1642, 0x00), loc10);
			}
			RTHOOK(59);
			if ((EIF_BOOLEAN)(loc10 != NULL)) {
				RTHOOK(60);
				loc7 = F1643_16921(RTCW(loc10));
				RTHOOK(61);
				if ((EIF_BOOLEAN)(loc7 != ((EIF_INTEGER_32) -1L))) {
					RTHOOK(62);
					ti4_1 = F1542_15549(RTCW(loc10));
					if ((EIF_BOOLEAN) (loc7 < ti4_1)) {
						RTHOOK(63);
						loc7++;
					}
					RTHOOK(64);
					tb2 = '\01';
					ti4_1 = F1542_15549(RTCW(loc10));
					ti4_1 = eif_min_int32 (loc7,ti4_1);
					tr1 = F1542_15548(RTCW(loc10), ti4_1);
					if (!(EIF_BOOLEAN)(tr1 == RTOUCR(562,F287_4813, (Current)))) {
						ti4_1 = eif_max_int32 ((EIF_INTEGER_32) (loc7 - ((EIF_INTEGER_32) 1L)),((EIF_INTEGER_32) 1L));
						tr1 = F1542_15548(RTCW(loc10), ti4_1);
						tb2 = (EIF_BOOLEAN)(tr1 == RTOUCR(562,F287_4813, (Current)));
					}
					if ((EIF_BOOLEAN) !tb2) {
						RTHOOK(65);
						loc11 = *(EIF_REFERENCE *)(loc18 + O12205[Dtype(loc18)-1513]);
						loc11 = RTRV(eif_new_type(1399, 0x00), loc11);
						
						RTHOOK(67);
						loc8 = F1541_15518(RTCW(loc10), loc11, ((EIF_INTEGER_32) 1L));
						RTHOOK(68);
						tb2 = '\0';
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13843[Dtype(loc18)-1666])(loc18);
						tr2 = *(EIF_REFERENCE *)(RTCW(loc10) + _REFACS_25_);
						if ((EIF_BOOLEAN)(tr1 == tr2)) {
							tb2 = (EIF_BOOLEAN) ((EIF_BOOLEAN)(loc8 == loc7) || (EIF_BOOLEAN)(loc8 == (EIF_INTEGER_32) (loc7 - ((EIF_INTEGER_32) 1L))));
						}
						if (tb2) {
							RTHOOK(69);
							F287_4815(Current);
						} else {
							RTHOOK(70);
							tr1 = F1347_12792(RTCV(RTOUCR(313,F287_4810, (Current))));
							if ((EIF_BOOLEAN)(tr1 != NULL)) {
								RTHOOK(71);
								if ((EIF_BOOLEAN) (loc9 < loc7)) {
									RTHOOK(72);
									loc7--;
								}
							}
							RTHOOK(73);
							F287_4815(Current);
							RTHOOK(74);
							F1541_15527(RTCW(loc10), loc7);
							RTHOOK(75);
							tr1 = RTOUCR(562,F287_4813, (Current));
							F1541_15535(RTCW(loc10), tr1);
						}
					}
				}
			}
		} else {
			RTHOOK(76);
			F287_4815(Current);
		}
	}
	RTHOOK(77);
	RTLE;
	RTEE;
}

/* {EV_DOCKABLE_SOURCE_I}.unparent_source_being_docked */
void F1558_15814 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLIU(6);
	
	RTEAA("unparent_source_being_docked", 1557, Current, 4, 0, 22279);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tr1 = F1558_15807(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1514_14806(loc1);
		tr1 = F1347_12792(RTCW(tr1));
		loc2 = tr1;
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		RTHOOK(2);
		tr1 = F1514_14806(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R10970[Dtype(loc2)-1352])(loc2, tr1);
		
	} else {
		RTHOOK(4);
		tb1 = '\0';
		tr1 = F1558_15808(Current);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			tr1 = F1514_14806(loc3);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10892[Dtype(RTCW(tr1))-1352])(tr1);
			loc4 = tr1;
			tb1 = EIF_TEST(loc4);
		}
		if (tb1) {
			RTHOOK(5);
			tr1 = F1514_14806(loc3);
			F1341_12747(loc4, tr1);
			
		} else {
			
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EV_DOCKABLE_SOURCE_I}.replace_insert_label */
void F1558_15815 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc6);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,loc4);
	RTLR(5,loc1);
	RTLR(6,tr2);
	RTLR(7,loc2);
	RTLR(8,tr3);
	RTLIU(9);
	
	RTEAA("replace_insert_label", 1557, Current, 7, 0, 22280);
	RTGC;
	RTHOOK(1);
	tr1 = F1347_12792(RTCV(RTOUCR(313,F287_4810, (Current))));
	loc6 = tr1;
	if (EIF_TEST(loc6)) {
		RTHOOK(2);
		loc3 = *(EIF_REFERENCE *)(loc6 + O9889[Dtype(loc6)-1247]);
		loc3 = RTRV(eif_new_type(1563, 0x00), loc3);
	}
	RTHOOK(3);
	loc4 = F1558_15807(Current);
	RTHOOK(4);
	RTCT0("l_widget_source_being_docked /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc4 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(5);
	RTCT0("target_not_void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(6);
	loc1 = F1347_12792(RTCV(RTOUCR(313,F287_4810, (Current))));
	loc1 = RTRV(eif_new_type(1351, 0x00), loc1);
	RTHOOK(7);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTHOOK(8);
		tr1 = F1514_14806(RTCW(loc4));
		tr2 = RTOUCR(313,F287_4810, (Current));
		ti4_1 = F1341_12724(RTCW(loc1), tr2, ((EIF_INTEGER_32) 1L));
		F1341_12743(RTCW(loc1), tr1, ti4_1);
	}
	RTHOOK(9);
	loc2 = F1347_12792(RTCV(RTOUCR(313,F287_4810, (Current))));
	loc2 = RTRV(eif_new_type(1354, 0x00), loc2);
	RTHOOK(10);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTHOOK(11);
		tr1 = F1514_14806(RTCW(loc4));
		F1348_12834(RTCW(loc2), tr1);
	}
	RTHOOK(12);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_2_);
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		RTHOOK(13);
		tr1 = F180_3423(RTCW(loc3));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1346,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr2 = RTLNTS(typres0.id, 2, 0);
		}
		tr3 = F1514_14806(RTCW(loc4));
		((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
		RTAR(tr2,tr3);
		F917_8946(RTCW(tr1), tr2);
	}
	RTHOOK(16);
	RTLE;
	RTEE;
}

/* {EV_DOCKABLE_SOURCE_I}.replace_insert_sep */
void F1558_15816 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc7);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTEAA("replace_insert_sep", 1557, Current, 8, 0, 22281);
	RTGC;
	RTHOOK(1);
	loc1 = F1398_13403(RTCV(RTOUCR(562,F287_4813, (Current))));
	loc1 = RTRV(eif_new_type(1371, 0x00), loc1);
	RTHOOK(2);
	RTCT0("parent_was_tool_bar", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(3);
	tr1 = F1558_15808(Current);
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		RTHOOK(4);
		loc2 = *(EIF_REFERENCE *)(loc7 + O12205[Dtype(loc7)-1513]);
		loc2 = RTRV(eif_new_type(1397, 0x00), loc2);
	}
	RTHOOK(5);
	RTCT0("tool_bar_item_not_void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(6);
	loc3 = loc2;
	loc3 = RTRV(eif_new_type(1265, 0x00), loc3);
	RTHOOK(7);
	RTCT0("source_not_void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(8);
	tr1 = RTOUCR(562,F287_4813, (Current));
	loc4 = F1341_12724(RTCW(loc1), tr1, ((EIF_INTEGER_32) 1L));
	RTHOOK(9);
	tr1 = RTOUCR(562,F287_4813, (Current));
	ti4_1 = F1341_12724(RTCW(loc1), tr1, ((EIF_INTEGER_32) 1L));
	F1341_12743(RTCW(loc1), loc2, ti4_1);
	RTHOOK(10);
	if ((EIF_BOOLEAN)(loc5 == (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 2L)))) {
		RTHOOK(11);
		F1559_15836(Current, loc1, loc5, loc4);
	}
	RTHOOK(12);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_3_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		RTHOOK(13);
		tr1 = F1174_10647(RTCW(loc1));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1265,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr2 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = loc3;
		RTAR(tr2,loc3);
		F917_8946(RTCW(tr1), tr2);
	}
	RTHOOK(17);
	RTLE;
	RTEE;
}

void EIF_Minit844 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
