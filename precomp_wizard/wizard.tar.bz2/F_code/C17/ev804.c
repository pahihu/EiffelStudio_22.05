/*
 * Code for class EV_ANY_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev804.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_ANY_I}.assign_interface */
void F1514_14800 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("assign_interface", 1513, Current, 0, 1, 21462);
	RTGC;
	RTHOOK(1);
	F1514_14815(Current, ((EIF_INTEGER_8) 0L), (EIF_BOOLEAN) 1);
	RTHOOK(2);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O12205[Dtype(Current)-1513]) = (EIF_REFERENCE) arg1;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_ANY_I}.safe_destroy */
void F1514_14803 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("safe_destroy", 1513, Current, 0, 0, 21463);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !F1514_14819(Current)) {
		RTHOOK(2);
		F1514_14822(Current, (EIF_BOOLEAN) 1);
		RTHOOK(3);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R12202[Dtype(Current)-1519])(Current);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_ANY_I}.is_destroyed */
EIF_BOOLEAN F1514_14805 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_destroyed", 1513, Current, 0, 0, 21464);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) F1514_14816(Current, ((EIF_INTEGER_8) 2L));
}

/* {EV_ANY_I}.attached_interface */
EIF_REFERENCE F1514_14806 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("attached_interface", 1513, Current, 0, 0, 21465);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O12205[dtype-1513]) != NULL)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + O12205[dtype-1513]);
	} else {
		RTHOOK(4);
		RTCT0("False", EX_CHECK);
			RTCF0;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {EV_ANY_I}.set_state_flag */
void F1514_14815 (EIF_REFERENCE Current, EIF_INTEGER_8 arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_8 ti1_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_state_flag", 1513, Current, 0, 2, 21474);
	RTGC;
	RTHOOK(1);
	ti1_1 = *(EIF_INTEGER_8 *)(Current + O12206[dtype-1513]);
	ti4_1 = (EIF_INTEGER_32) arg1;
	ti1_1 = eif_set_bit(EIF_INTEGER_8,ti1_1,arg2,ti4_1);
	*(EIF_INTEGER_8 *)(Current + O12206[dtype-1513]) = (EIF_INTEGER_8) ti1_1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_ANY_I}.get_state_flag */
EIF_BOOLEAN F1514_14816 (EIF_REFERENCE Current, EIF_INTEGER_8 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_8 ti1_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("get_state_flag", 1513, Current, 0, 1, 21475);
	RTGC;
	RTHOOK(1);
	ti1_1 = *(EIF_INTEGER_8 *)(Current + O12206[Dtype(Current)-1513]);
	ti4_1 = (EIF_INTEGER_32) arg1;
	Result = eif_bit_test(EIF_INTEGER_8,ti1_1,ti4_1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_ANY_I}.is_in_destroy */
EIF_BOOLEAN F1514_14819 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_in_destroy", 1513, Current, 0, 0, 21453);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) F1514_14816(Current, ((EIF_INTEGER_8) 3L));
}

/* {EV_ANY_I}.set_is_initialized */
void F1514_14820 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_is_initialized", 1513, Current, 0, 1, 21454);
	RTHOOK(1);
	F1514_14815(Current, ((EIF_INTEGER_8) 1L), arg1);
	RTHOOK(3);
	RTEE;
}

/* {EV_ANY_I}.set_is_destroyed */
void F1514_14821 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_is_destroyed", 1513, Current, 0, 1, 21455);
	RTHOOK(1);
	F1514_14815(Current, ((EIF_INTEGER_8) 2L), arg1);
	RTHOOK(3);
	RTEE;
}

/* {EV_ANY_I}.set_is_in_destroy */
void F1514_14822 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_is_in_destroy", 1513, Current, 0, 1, 21456);
	RTHOOK(1);
	F1514_14815(Current, ((EIF_INTEGER_8) 3L), arg1);
	RTHOOK(3);
	RTEE;
}

void EIF_Minit804 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
