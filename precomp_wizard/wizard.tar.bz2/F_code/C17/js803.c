/*
 * Code for class JSON_ARRAY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "js803.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {JSON_ARRAY}.make */
void F1513_14779 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 1512, Current, 0, 1, 21444);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {891,1475,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F892_8780(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {JSON_ARRAY}.representation */
EIF_REFERENCE F1513_14785 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Result);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("representation", 1512, Current, 1, 0, 21450);
	RTGC;
	RTHOOK(1);
	Result = RTMS_EX_H("[",1,91);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = F892_8794(RTCW(tr1));
	for (;;) {
		tb1 = F1036_9256(loc1);
		if (tb1) break;
		RTHOOK(3);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L))) {
			RTHOOK(4);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R9867[Dtype(RTCW(Result))-1244])(Result, (EIF_CHARACTER_8) ',');
		}
		RTHOOK(5);
		tr1 = F1036_9247(loc1);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11594[Dtype(RTCW(tr1))-1476])(tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9863[Dtype(RTCW(Result))-1244])(Result, tr1);
		RTHOOK(6);
		F1036_9262(loc1);
	}
	RTHOOK(7);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R9867[Dtype(RTCW(Result))-1244])(Result, (EIF_CHARACTER_8) ']');
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {JSON_ARRAY}.new_cursor */
EIF_REFERENCE F1513_14787 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("new_cursor", 1512, Current, 0, 0, 21430);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F892_8794(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {JSON_ARRAY}.add */
void F1513_14792 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("add", 1512, Current, 0, 1, 21435);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7657[Dtype(RTCW(tr1))-780])(tr1, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {JSON_ARRAY}.hash_code */
EIF_INTEGER_32 F1513_14796 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("hash_code", 1512, Current, 2, 0, 21439);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = F892_8794(RTCW(tr1));
	for (;;) {
		tb1 = F1036_9256(loc2);
		if (tb1) break;
		RTHOOK(2);
		if (loc1) {
			RTHOOK(3);
			ti4_1 = eif_bit_shift_left((EIF_INTEGER_32) (Result % ((EIF_INTEGER_32) 8388593L)),((EIF_INTEGER_32) 8L));
			tr1 = F1036_9247(loc2);
			ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9308[Dtype(RTCW(tr1))-1186])(tr1);
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 + ti4_2);
		} else {
			RTHOOK(4);
			tr1 = F1036_9247(loc2);
			Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9308[Dtype(RTCW(tr1))-1186])(tr1);
			RTHOOK(5);
			loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		RTHOOK(6);
		F1036_9262(loc2);
	}
	RTHOOK(7);
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = F892_8801(RTCW(tr1));
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result % ti4_1);
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {JSON_ARRAY}.array_representation */
EIF_REFERENCE F1513_14797 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("array_representation", 1512, Current, 0, 0, 21440);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current);
}

void EIF_Minit803 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
