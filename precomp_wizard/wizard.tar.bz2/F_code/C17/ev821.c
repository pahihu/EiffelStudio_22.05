/*
 * Code for class EV_COLOR_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev821.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_COLOR_I}.default_name */

EIF_REFERENCE F1531_15158 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (331,RTMS32_EX_H("n\000\000\000o\000\000\000n\000\000\000a\000\000\000m\000\000\000e\000\000\000",6,2069000037));
}

void EIF_Minit821 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
