/*
 * Code for class EV_POINTER_STYLE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev818.h"
#include "ev_c_util.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F48_850
static EIF_INTEGER_32 inline_F48_850 (void)
{
	return gdk_display_get_default_cursor_size ((GdkDisplay*) gdk_display_get_default());
	;
}
#define INLINE_F48_850
#endif
#ifndef INLINE_F175_2563
static EIF_INTEGER_32 inline_F175_2563 (EIF_POINTER arg1)
{
	return gdk_pixbuf_get_width ((GdkPixbuf*)arg1);
	;
}
#define INLINE_F175_2563
#endif
#ifndef INLINE_F175_2564
static EIF_INTEGER_32 inline_F175_2564 (EIF_POINTER arg1)
{
	return gdk_pixbuf_get_height ((GdkPixbuf*)arg1);
	;
}
#define INLINE_F175_2564
#endif
#ifndef INLINE_F175_2409
static EIF_POINTER inline_F175_2409 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (g_object_ref((gpointer) arg1))
	;
}
#define INLINE_F175_2409
#endif
#ifndef INLINE_F175_2410
static void inline_F175_2410 (EIF_POINTER arg1)
{
	g_object_unref((gpointer) arg1)
	;
}
#define INLINE_F175_2410
#endif
#ifndef INLINE_F175_2570
static EIF_POINTER inline_F175_2570 (EIF_POINTER arg1)
{
	return gdk_pixbuf_new_from_xpm_data ((const char**) arg1);
	;
}
#define INLINE_F175_2570
#endif
#ifndef INLINE_F175_2403
static int inline_F175_2403 (EIF_POINTER arg1)
{
	return (int) (GDK_IS_PIXBUF(arg1))
	;
}
#define INLINE_F175_2403
#endif
#ifndef INLINE_F175_2562
static EIF_POINTER inline_F175_2562 (EIF_POINTER arg1)
{
	return gdk_pixbuf_copy ((GdkPixbuf*)arg1);
	;
}
#define INLINE_F175_2562
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_POINTER_STYLE_IMP}.make */
void F1528_15031 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("make", 1527, Current, 0, 0, 21627);
	RTHOOK(1);
	F1514_14820(Current, (EIF_BOOLEAN) 1);
	RTHOOK(2);
	RTEE;
}

/* {EV_POINTER_STYLE_IMP}.init_predefined */
void F1528_15033 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("init_predefined", 1527, Current, 2, 1, 21629);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	switch (arg1) {
		case 3L:
			RTHOOK(3);
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 15L);
			RTHOOK(4);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 15L);
			break;
		case 5L:
			RTHOOK(5);
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
			RTHOOK(6);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
			break;
		case 6L:
			RTHOOK(7);
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
			RTHOOK(8);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
			break;
		case 7L:
			RTHOOK(9);
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
			RTHOOK(10);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
			break;
		case 8L:
			RTHOOK(11);
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
			RTHOOK(12);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
			break;
		case 9L:
			RTHOOK(13);
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
			RTHOOK(14);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
			break;
		case 10L:
			RTHOOK(15);
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
			RTHOOK(16);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
			break;
		case 11L:
			RTHOOK(17);
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
			RTHOOK(18);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
			break;
		case 12L:
			RTHOOK(19);
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			RTHOOK(20);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
			break;
		case 1L:
			RTHOOK(21);
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16L);
			RTHOOK(22);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16L);
			break;
		case 14L:
			RTHOOK(23);
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
			RTHOOK(24);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
			break;
		default:
			RTHOOK(25);
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			RTHOOK(26);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			break;
	}
	RTHOOK(27);
	F1528_15035(Current, loc1);
	RTHOOK(28);
	F1528_15036(Current, loc2);
	RTHOOK(29);
	RTLE;
	RTEE;
}

/* {EV_POINTER_STYLE_IMP}.set_x_hotspot */
void F1528_15035 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_x_hotspot", 1527, Current, 0, 1, 21610);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EV_POINTER_STYLE_IMP}.set_y_hotspot */
void F1528_15036 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_y_hotspot", 1527, Current, 0, 1, 21611);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_1_) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EV_POINTER_STYLE_IMP}.destroy */
void F1528_15037 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("destroy", 1527, Current, 0, 0, 21612);
	RTGC;
	RTHOOK(1);
	F1514_14822(Current, (EIF_BOOLEAN) 1);
	RTHOOK(2);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	F1528_15046(Current, tp2);
	RTHOOK(3);
	F1514_14821(Current, (EIF_BOOLEAN) 1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_POINTER_STYLE_IMP}.width */
EIF_INTEGER_32 F1528_15038 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("width", 1527, Current, 0, 0, 21613);
	RTGC;
	RTHOOK(1);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current+ _PTROFF_1_1_0_3_0_0_) == tp1)) {
		RTHOOK(2);
		ti4_1 = inline_F48_850();
	} else {
		RTHOOK(3);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_1_1_0_3_0_0_);
		ti4_1 = inline_F175_2563(tp1);
	}
	Result = (EIF_INTEGER_32) ti4_1;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_POINTER_STYLE_IMP}.height */
EIF_INTEGER_32 F1528_15039 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("height", 1527, Current, 0, 0, 21614);
	RTGC;
	RTHOOK(1);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current+ _PTROFF_1_1_0_3_0_0_) == tp1)) {
		RTHOOK(2);
		ti4_1 = inline_F48_850();
	} else {
		RTHOOK(3);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_1_1_0_3_0_0_);
		ti4_1 = inline_F175_2564(tp1);
	}
	Result = (EIF_INTEGER_32) ti4_1;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_POINTER_STYLE_IMP}.x_hotspot */
EIF_INTEGER_32 F1528_15040 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
}


/* {EV_POINTER_STYLE_IMP}.y_hotspot */
EIF_INTEGER_32 F1528_15041 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_1_);
}


/* {EV_POINTER_STYLE_IMP}.gdk_cursor_from_pointer_style */
EIF_POINTER F1528_15043 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_cursor_from_pointer_style", 1527, Current, 1, 0, 21618);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_POINTER) gdk_display_get_default();
	RTHOOK(2);
	RTHOOK(3);
	RTLE;
	RTEE;
	return (EIF_POINTER) F1528_15044(Current, loc1);
}

/* {EV_POINTER_STYLE_IMP}.gdk_cursor_from_pointer_style_for_display */
EIF_POINTER F1528_15044 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_cursor_from_pointer_style_for_display", 1527, Current, 1, 1, 21619);
	RTGC;
	RTHOOK(1);
	switch (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_)) {
		case 1L:
			RTHOOK(2);
			ti4_1 = (EIF_INTEGER_32) GDK_WATCH;
			Result = (EIF_POINTER) gdk_cursor_new_for_display((GdkDisplay *) arg1, (GdkCursorType) ti4_1);
			break;
		case 2L:
			RTHOOK(3);
			ti4_1 = (EIF_INTEGER_32) GDK_LEFT_PTR;
			Result = (EIF_POINTER) gdk_cursor_new_for_display((GdkDisplay *) arg1, (GdkCursorType) ti4_1);
			break;
		case 3L:
			RTHOOK(4);
			ti4_1 = (EIF_INTEGER_32) GDK_CROSSHAIR;
			Result = (EIF_POINTER) gdk_cursor_new_for_display((GdkDisplay *) arg1, (GdkCursorType) ti4_1);
			break;
		case 5L:
			RTHOOK(5);
			ti4_1 = (EIF_INTEGER_32) GDK_XTERM;
			Result = (EIF_POINTER) gdk_cursor_new_for_display((GdkDisplay *) arg1, (GdkCursorType) ti4_1);
			break;
		case 7L:
			RTHOOK(6);
			ti4_1 = (EIF_INTEGER_32) GDK_FLEUR;
			Result = (EIF_POINTER) gdk_cursor_new_for_display((GdkDisplay *) arg1, (GdkCursorType) ti4_1);
			break;
		case 8L:
			RTHOOK(7);
			ti4_1 = (EIF_INTEGER_32) GDK_SB_V_DOUBLE_ARROW;
			Result = (EIF_POINTER) gdk_cursor_new_for_display((GdkDisplay *) arg1, (GdkCursorType) ti4_1);
			break;
		case 13L:
			RTHOOK(8);
			ti4_1 = (EIF_INTEGER_32) GDK_WATCH;
			Result = (EIF_POINTER) gdk_cursor_new_for_display((GdkDisplay *) arg1, (GdkCursorType) ti4_1);
			break;
		case 4L:
			RTHOOK(9);
			ti4_1 = (EIF_INTEGER_32) GDK_QUESTION_ARROW;
			Result = (EIF_POINTER) gdk_cursor_new_for_display((GdkDisplay *) arg1, (GdkCursorType) ti4_1);
			break;
		case 15L:
			RTHOOK(10);
			ti4_1 = (EIF_INTEGER_32) GDK_HAND2;
			Result = (EIF_POINTER) gdk_cursor_new_for_display((GdkDisplay *) arg1, (GdkCursorType) ti4_1);
			break;
		case 6L:
			RTHOOK(11);
			tp1 = (EIF_POINTER) no_cursor_xpm();
			loc1 = F1528_15045(Current, tp1);
			break;
		case 9L:
			RTHOOK(12);
			tp1 = (EIF_POINTER) sizenwse_cursor_xpm();
			loc1 = F1528_15045(Current, tp1);
			break;
		case 10L:
			RTHOOK(13);
			tp1 = (EIF_POINTER) sizenesw_cursor_xpm();
			loc1 = F1528_15045(Current, tp1);
			break;
		case 11L:
			RTHOOK(14);
			tp1 = (EIF_POINTER) sizewe_cursor_xpm();
			loc1 = F1528_15045(Current, tp1);
			break;
		case 12L:
			RTHOOK(15);
			tp1 = (EIF_POINTER) uparrow_cursor_xpm();
			loc1 = F1528_15045(Current, tp1);
			break;
		case 14L:
			RTHOOK(16);
			tp1 = (EIF_POINTER) sizewe_cursor_xpm();
			loc1 = F1528_15045(Current, tp1);
			break;
		default:
			RTHOOK(17);
			loc1 = *(EIF_POINTER *)(Current+ _PTROFF_1_1_0_3_0_0_);
			RTHOOK(18);
			tp1 = inline_F175_2409(loc1);
			loc1 = (EIF_POINTER) tp1;
			break;
	}
	RTHOOK(19);
	tb1 = '\0';
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(Result == tp1)) {
		tb1 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) != ((EIF_INTEGER_32) 2L));
	}
	if (tb1) {
		
		RTHOOK(21);
		tp1 = (EIF_POINTER) gdk_display_get_default();
		ti4_1 = F1255_11644(RTCV(F1514_14806(Current)));
		ti4_2 = F1255_11645(RTCV(F1514_14806(Current)));
		Result = (EIF_POINTER) gdk_cursor_new_from_pixbuf((GdkDisplay*) tp1, (GdkPixbuf*) loc1, (gint) ti4_1, (gint) ti4_2);
		RTHOOK(22);
		inline_F175_2410(loc1);
	}
	RTHOOK(23);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_POINTER_STYLE_IMP}.image_from_xpm_data */
EIF_POINTER F1528_15045 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("image_from_xpm_data", 1527, Current, 0, 1, 21620);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_POINTER) inline_F175_2570(arg1);
}

/* {EV_POINTER_STYLE_IMP}.set_gdkpixbuf */
void F1528_15046 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_gdkpixbuf", 1527, Current, 0, 1, 21621);
	RTGC;
	RTHOOK(1);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current+ _PTROFF_1_1_0_3_0_0_) != tp1)) {
		RTHOOK(2);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_1_1_0_3_0_0_);
		inline_F175_2410(tp1);
	}
	RTHOOK(3);
	*(EIF_POINTER *)(Current+ _PTROFF_1_1_0_3_0_0_) = (EIF_POINTER) arg1;
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_POINTER_STYLE_IMP}.copy_from_pointer_style */
void F1528_15048 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("copy_from_pointer_style", 1527, Current, 1, 1, 21623);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(Dftype(Current), 0),loc1);
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tp1 = *(EIF_POINTER *)(loc1+ _PTROFF_1_1_0_3_0_0_);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp2 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(tp1 != tp2)) {
			RTHOOK(3);
			tp1 = *(EIF_POINTER *)(loc1+ _PTROFF_1_1_0_3_0_0_);
			if ((EIF_BOOLEAN) !EIF_TEST (inline_F175_2403(tp1))) {
			}
			RTHOOK(4);
			tp1 = *(EIF_POINTER *)(loc1+ _PTROFF_1_1_0_3_0_0_);
			tp1 = inline_F175_2562(tp1);
			F1528_15046(Current, tp1);
		}
		RTHOOK(5);
		ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_0_);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) ti4_1;
	} else {
		
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_POINTER_STYLE_IMP}.dispose */
void F1528_15050 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("dispose", 1527, Current, 0, 0, 21625);
	RTGC;
	RTHOOK(1);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	F1528_15046(Current, tp2);
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit818 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
