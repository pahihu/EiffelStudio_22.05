/*
 * Code for class EV_ANY_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev834.h"
#include <ev_gtk_callback_marshal.h>
#include "eif_built_in.h"
#include <ev_any_imp.h>
#include <ev_gtk.h>
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F175_2408
static EIF_POINTER inline_F175_2408 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (g_object_ref_sink((gpointer) arg1))
	;
}
#define INLINE_F175_2408
#endif
#ifndef INLINE_F175_2407
static int inline_F175_2407 (EIF_POINTER arg1)
{
	return (int) (g_object_is_floating((gpointer) arg1))
	;
}
#define INLINE_F175_2407
#endif
#ifndef INLINE_F175_2409
static EIF_POINTER inline_F175_2409 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (g_object_ref((gpointer) arg1))
	;
}
#define INLINE_F175_2409
#endif
#ifndef INLINE_F178_3178
static int inline_F178_3178 (EIF_POINTER arg1)
{
	return (int) (GTK_IS_WIDGET(arg1))
	;
}
#define INLINE_F178_3178
#endif
#ifndef INLINE_F175_2406
static EIF_NATURAL_32 inline_F175_2406 (EIF_POINTER arg1)
{
	return (EIF_NATURAL_32) (((GObject*)arg1)->ref_count)
	;
}
#define INLINE_F175_2406
#endif
#ifndef INLINE_F1548_15579
static EIF_REFERENCE inline_F1548_15579 (EIF_POINTER arg1)
{
	return (EIF_REFERENCE) (c_ev_any_imp_get_eif_reference_from_object_id (arg1))
	;
}
#define INLINE_F1548_15579
#endif
#ifndef INLINE_F176_2794
static void inline_F176_2794 (EIF_POINTER arg1)
{
	gtk_widget_destroy((GtkWidget*) arg1)
	;
}
#define INLINE_F176_2794
#endif
#ifndef INLINE_F1156_10592
static int inline_F1156_10592 (void)
{
	return (int) ((EIF_BOOLEAN) c_ev_gtk_callback_marshal_is_enabled)
	;
}
#define INLINE_F1156_10592
#endif
#ifndef INLINE_F1156_10593
static void inline_F1156_10593 (EIF_BOOLEAN arg1)
{
	c_ev_gtk_callback_marshal_set_is_enabled((int)arg1)
	;
}
#define INLINE_F1156_10593
#endif
#ifndef INLINE_F175_2413
static void inline_F175_2413 (EIF_POINTER arg1)
{
	g_object_run_dispose((GObject *) arg1)
	;
}
#define INLINE_F175_2413
#endif
#ifndef INLINE_F175_2410
static void inline_F175_2410 (EIF_POINTER arg1)
{
	g_object_unref((gpointer) arg1)
	;
}
#define INLINE_F175_2410
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_ANY_IMP}.c_object */
EIF_POINTER F1548_15575 (EIF_REFERENCE Current)
{
	return *(EIF_POINTER *)(Current + O12790[Dtype(Current)-1547]);
}


/* {EV_ANY_IMP}.set_c_object */
void F1548_15577 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("set_c_object", 1547, Current, 1, 1, 22069);
	RTGC;
	RTHOOK(1);
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R12803[dtype-1550])(Current)) {
		RTHOOK(2);
		loc1 = (EIF_POINTER) gtk_event_box_new();
		RTHOOK(3);
		tp1 = inline_F175_2408(loc1);
		loc1 = (EIF_POINTER) tp1;
		RTHOOK(4);
		gtk_container_add((GtkContainer*) loc1, (GtkWidget*) arg1);
		RTHOOK(5);
		gtk_widget_show((GtkWidget*) arg1);
	} else {
		RTHOOK(6);
		if (EIF_TEST (inline_F175_2407(arg1))) {
			RTHOOK(7);
			*(EIF_BOOLEAN *)(Current + O12791[dtype-1547]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			RTHOOK(8);
			loc1 = inline_F175_2408(arg1);
		} else {
			
			RTHOOK(10);
			loc1 = (EIF_POINTER) arg1;
			RTHOOK(11);
			tp1 = inline_F175_2409(loc1);
			loc1 = (EIF_POINTER) tp1;
		}
	}
	RTHOOK(12);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O9088[dtype-1150]) == ((EIF_INTEGER_32) 0L))) {
		RTHOOK(13);
		ti4_1 = (EIF_INTEGER_32) eif_builtin_IDENTIFIED_ROUTINES_eif_current_object_id__i4 (Current);
		*(EIF_INTEGER_32 *)(Current + O9088[dtype-1150]) = (EIF_INTEGER_32) ti4_1;
	}
	RTHOOK(14);
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O9088[dtype-1150]);
	set_eif_oid_in_c_object((loc1), (ti4_1), ((EIF_POINTER) A834_84));
	RTHOOK(15);
	*(EIF_POINTER *)(Current + O12790[dtype-1547]) = (EIF_POINTER) loc1;
	RTHOOK(16);
	tb1 = '\0';
	if (EIF_TEST (inline_F178_3178(loc1))) {
		tb1 = (EIF_BOOLEAN) EIF_TEST(gtk_widget_is_toplevel((GtkWidget*) loc1));
	}
	if (tb1) {
		RTHOOK(17);
		if ((EIF_BOOLEAN)(inline_F175_2406(loc1) != (EIF_NATURAL_32) ((EIF_INTEGER_32) 2L))) {
			
			RTHOOK(19);
			tr2 = (EIF_REFERENCE) eif_builtin_ANY_generator__s1 (Current);
			tr3 = RTMS_EX_H(".set_c_object: unexpected ref count for c_object=",49,1740544573);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(RTCW(tr2))-1243])(tr2, tr3);
			tr3 = eif_out__p_s1(loc1);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(RTCW(tr2))-1243])(tr2, tr3);
			tr3 = RTMS_EX_H(" #",2,8227);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(RTCW(tr2))-1243])(tr2, tr3);
			tu4_1 = inline_F175_2406(loc1);
			tr3 = eif_out__u4_s1(tu4_1);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(RTCW(tr2))-1243])(tr2, tr3);
			tr3 = RTMS_EX_H(" /= 2 !\012",8,1002112522);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(RTCW(tr2))-1243])(tr2, tr3);
			tr1 = RTLNS(eif_new_type(174, 0x00).id, 174, _OBJSIZ_0_0_0_0_0_0_0_0_);
			F175_2404(RTCW(tr1), tr2);
		}
	} else {
		RTHOOK(20);
		if ((EIF_BOOLEAN)(inline_F175_2406(loc1) != (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L))) {
			
			RTHOOK(22);
			tr2 = (EIF_REFERENCE) eif_builtin_ANY_generator__s1 (Current);
			tr3 = RTMS_EX_H(".set_c_object: unexpected ref count for c_object=",49,1740544573);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(RTCW(tr2))-1243])(tr2, tr3);
			tr3 = eif_out__p_s1(loc1);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(RTCW(tr2))-1243])(tr2, tr3);
			tr3 = RTMS_EX_H(" #",2,8227);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(RTCW(tr2))-1243])(tr2, tr3);
			tu4_1 = inline_F175_2406(loc1);
			tr3 = eif_out__u4_s1(tu4_1);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(RTCW(tr2))-1243])(tr2, tr3);
			tr3 = RTMS_EX_H(" /= 1 !\012",8,985335306);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(RTCW(tr2))-1243])(tr2, tr3);
			tr1 = RTLNS(eif_new_type(174, 0x00).id, 174, _OBJSIZ_0_0_0_0_0_0_0_0_);
			F175_2404(RTCW(tr1), tr2);
		}
	}
	RTHOOK(23);
	RTLE;
	RTEE;
}

/* {EV_ANY_IMP}.update_gtk_name */
void F1548_15578 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("update_gtk_name", 1547, Current, 3, 0, 22070);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {EV_ANY_IMP}.eif_object_from_c */
EIF_REFERENCE F1548_15579 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("eif_object_from_c", 1547, Current, 0, 1, 22071);
	Result = inline_F1548_15579 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_ANY_IMP}.destroy */
void F1548_15580 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("destroy", 1547, Current, 1, 0, 22072);
	RTGC;
	RTHOOK(1);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	F1548_15587(Current, tp2);
	RTHOOK(2);
	loc1 = *(EIF_POINTER *)(Current + O12790[Dtype(Current)-1547]);
	RTHOOK(3);
	tb1 = '\0';
	tb2 = !loc1;
	if ((EIF_BOOLEAN) !tb2) {
		tb1 = EIF_TEST (inline_F178_3178(loc1));
	}
	if (tb1) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) EIF_TEST(gtk_widget_is_toplevel((GtkWidget*) loc1))) {
			RTHOOK(5);
			if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_WINDOW((loc1)))) {
			} else {
				
				RTHOOK(7);
				inline_F176_2794(loc1);
			}
		} else {
			RTHOOK(8);
			inline_F176_2794(loc1);
		}
	}
	RTHOOK(9);
	F1514_14821(Current, (EIF_BOOLEAN) 1);
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {EV_ANY_IMP}.real_signal_connect */
void F1548_15581 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,arg2);
	RTLR(5,arg3);
	RTLIU(6);
	
	RTEAA("real_signal_connect", 1547, Current, 1, 3, 22073);
	RTGC;
	RTHOOK(1);
	loc1 = RTOUCR(311,F1548_15602, (Current));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_42_);
	tr2 = RTLNS(eif_new_type(1137, 0x00).id, 1137, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F1138_9661(RTCW(tr2), arg2);
	F1156_10578(RTCW(tr1), arg1, tr2, arg3, (EIF_BOOLEAN) 0);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_42_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_0_1_0_1_);
	F1548_15586(Current, arg1, arg2, ti4_1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_ANY_IMP}.real_signal_connect_after */
void F1548_15582 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,tr2);
	RTLR(5,arg3);
	RTLIU(6);
	
	RTEAA("real_signal_connect_after", 1547, Current, 1, 3, 22074);
	RTGC;
	RTHOOK(1);
	loc1 = RTOUCR(311,F1548_15602, (Current));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_42_);
	tr2 = F1539_15493(RTCW(loc1), arg2);
	F1156_10578(RTCW(tr1), arg1, tr2, arg3, (EIF_BOOLEAN) 1);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_42_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_0_1_0_1_);
	F1548_15586(Current, arg1, arg2, ti4_1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_ANY_IMP}.last_signal_connection */
EIF_REFERENCE F1548_15585 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("last_signal_connection", 1547, Current, 1, 0, 22077);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O12802[Dtype(Current)-1547]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7871[Dtype(loc1)-882])(loc1);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {EV_ANY_IMP}.record_signal_connection */
void F1548_15586 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("record_signal_connection", 1547, Current, 1, 3, 22078);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg3 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		loc1 = *(EIF_REFERENCE *)(Current + O12802[dtype-1547]);
		RTHOOK(3);
		if ((EIF_BOOLEAN)(loc1 == NULL)) {
			RTHOOK(4);
			{
				EIF_TYPE_INDEX typarr0[] = {891,0,0,0xFFFF};
				EIF_TYPE typres0;
				{
					EIF_TYPE l_type;
					static EIF_TYPE_INDEX typarr2[] = {858,1135,0xFFFF};
					EIF_TYPE typres2;
					static EIF_TYPE typcache2 = {INVALID_DTYPE, 0};
					
					typres2 = (typcache2.id != INVALID_DTYPE ? typcache2 : (typcache2 = eif_compound_id(Dftype(Current), typarr2)));
					l_type = eif_final_id(Y7670,Y7670_gen_type,typres2.id,679);
					typarr0[1] = l_type.annotations | 0xFF00;
					typarr0[2] = l_type.id;
				}
				
				typres0 = eif_compound_id(Dftype(Current), typarr0);
				loc1 = RTLNS(typres0.id, 891, _OBJSIZ_1_1_0_1_0_0_0_0_);
			}
			F892_8780(RTCW(loc1), ((EIF_INTEGER_32) 1L));
			RTHOOK(5);
			RTAR(Current, loc1);
			*(EIF_REFERENCE *)(Current + O12802[dtype-1547]) = (EIF_REFERENCE) loc1;
		}
		RTHOOK(6);
		tr1 = RTLNS(eif_new_type(1135, 0x00).id, 1135, _OBJSIZ_0_1_0_1_0_1_0_0_);
		F1136_9639(RTCW(tr1), arg1, arg3);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7715[Dtype(RTCW(loc1))-882])(loc1, tr1);
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_ANY_IMP}.disconnect_all_recorded_connections */
void F1548_15587 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("disconnect_all_recorded_connections", 1547, Current, 2, 1, 22079);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O12802[dtype-1547]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R7637[Dtype(loc1)-882])(loc1);
		for (;;) {
			RTHOOK(3);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7636[Dtype(loc1)-882])(loc1);
			if (tb1) break;
			RTHOOK(4);
			tb2 = '\0';
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7670[Dtype(loc1)-780])(loc1);
			loc2 = tr1;
			if (EIF_TEST(loc2)) {
				tb3 = *(EIF_BOOLEAN *)(loc2+ _CHROFF_0_0_);
				tb2 = tb3;
			}
			if (tb2) {
				RTHOOK(5);
				tb2 = '\01';
				tb3 = !arg1;
				if (!tb3) {
					tp1 = *(EIF_POINTER *)(loc2+ _PTROFF_0_1_0_1_0_0_);
					tb2 = (EIF_BOOLEAN)(tp1 == arg1);
				}
				if (tb2) {
					RTHOOK(6);
					F1136_9642(loc2);
					RTHOOK(7);
					(FUNCTION_CAST(void, (EIF_REFERENCE)) R7675[Dtype(loc1)-780])(loc1);
				} else {
					RTHOOK(8);
					(FUNCTION_CAST(void, (EIF_REFERENCE)) R7650[Dtype(loc1)-882])(loc1);
				}
			} else {
				RTHOOK(9);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R7675[Dtype(loc1)-780])(loc1);
			}
		}
		RTHOOK(10);
		tb2 = F724_8337(loc1);
		if (tb2) {
			RTHOOK(11);
			*(EIF_REFERENCE *)(Current + O12802[dtype-1547]) = (EIF_REFERENCE) NULL;
		} else {
			RTHOOK(12);
			{
				/* INLINED CODE (ANY.do_nothing) */
				/* END INLINED CODE */
			}
			;
		}
	}
	RTHOOK(13);
	RTLE;
	RTEE;
}

/* {EV_ANY_IMP}.needs_event_box */
EIF_BOOLEAN F1548_15589 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("needs_event_box", 1547, Current, 0, 0, 22081);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {EV_ANY_IMP}.dispose */
void F1548_15591 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("dispose", 1547, Current, 1, 0, 22083);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_POINTER *)(Current + O12790[Dtype(Current)-1547]);
	RTHOOK(2);
	tb1 = '\0';
	tb2 = !loc1;
	if ((EIF_BOOLEAN) !tb2) {
		tb1 = EIF_TEST (inline_F178_3178(loc1));
	}
	if (tb1) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) EIF_TEST(gtk_widget_is_toplevel((GtkWidget*) loc1))) {
			RTHOOK(4);
			inline_F176_2794(loc1);
		} else {
			RTHOOK(5);
			inline_F176_2794(loc1);
		}
	}
	RTHOOK(6);
	F1151_10495(Current);
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_ANY_IMP}.c_object_dispose */
void F1548_15592 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("c_object_dispose", 1547, Current, 2, 0, 22084);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O12804[dtype-1547])) {
		RTHOOK(2);
		*(EIF_BOOLEAN *)(Current + O12804[dtype-1547]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(3);
		loc2 = EIF_TEST (inline_F1156_10592());
		RTHOOK(4);
		inline_F1156_10593((EIF_BOOLEAN) 0);
		RTHOOK(5);
		loc1 = *(EIF_POINTER *)(Current + O12790[dtype-1547]);
		RTHOOK(6);
		tb1 = !loc1;
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(7);
			if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_WINDOW((loc1)))) {
				RTHOOK(8);
				inline_F176_2794(loc1);
			} else {
				RTHOOK(9);
				if (EIF_TEST (inline_F178_3178(loc1))) {
					RTHOOK(10);
					inline_F176_2794(loc1);
				} else {
					RTHOOK(11);
					inline_F175_2413(loc1);
				}
			}
			RTHOOK(12);
			inline_F175_2410(loc1);
			RTHOOK(13);
			{
				/* INLINED CODE (ANY.default_pointer) */
				tp1 = (EIF_POINTER)  0;
				/* END INLINED CODE */
			}
			tp2 = tp1;
			*(EIF_POINTER *)(Current + O12790[dtype-1547]) = (EIF_POINTER) tp2;
		}
		RTHOOK(14);
		F1514_14821(Current, (EIF_BOOLEAN) 1);
		RTHOOK(15);
		inline_F1156_10593(loc2);
	}
	RTHOOK(19);
	RTLE;
	RTEE;
}

/* {EV_ANY_IMP}.process_draw_event */
EIF_BOOLEAN F1548_15593 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("process_draw_event", 1547, Current, 0, 1, 22085);
	RTGC;
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) 0;
}

/* {EV_ANY_IMP}.process_gdk_event */
void F1548_15594 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("process_gdk_event", 1547, Current, 0, 2, 22086);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {EV_ANY_IMP}.process_configure_event */
EIF_BOOLEAN F1548_15595 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("process_configure_event", 1547, Current, 0, 4, 22087);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) 0;
}

/* {EV_ANY_IMP}.process_button_event */
void F1548_15598 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("process_button_event", 1547, Current, 0, 2, 22090);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {EV_ANY_IMP}.process_scroll_event */
EIF_BOOLEAN F1548_15600 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("process_scroll_event", 1547, Current, 0, 1, 22092);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) 0;
}

/* {EV_ANY_IMP}.visual_widget */
EIF_POINTER F1548_15601 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("visual_widget", 1547, Current, 0, 0, 22093);
	RTGC;
	RTHOOK(1);
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R12803[dtype-1550])(Current)) {
		RTHOOK(2);
		tp1 = *(EIF_POINTER *)(Current + O12790[dtype-1547]);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_POINTER) (EIF_POINTER) gtk_bin_get_child((GtkBin*) tp1);
	} else {
		RTHOOK(4);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_POINTER) *(EIF_POINTER *)(Current + O12790[dtype-1547]);
	}/* NOTREACHED */
	
}

/* {EV_ANY_IMP}.app_implementation */
static EIF_REFERENCE F1548_15602_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(311)

	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("app_implementation", 1547, Current, 2, 0, 22094);
	RTGC;
	RTOTP;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1258, 0x00).id, 1258, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1248_11522(RTCW(loc1));
	RTHOOK(2);
	RTCT0("attached {EV_APPLICATION_IMP} env.implementation.application_i as l_app_imp", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
	tr1 = F1536_15229(RTCW(tr1));
	loc2 = tr1;
	loc2 = RTRV(eif_new_type(1538, 0x00),loc2);
	if (EIF_TEST(loc2)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(3);
	Result = (EIF_REFERENCE) loc2;
	RTOTE;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1548_15602 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(311,F1548_15602_body,(Current));
}

void EIF_Minit834 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
