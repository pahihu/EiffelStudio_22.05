
#ifndef _C17_ev821_
#define _C17_ev821_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1531_15158(EIF_REFERENCE);
extern void EIF_Minit821(void);

#ifdef __cplusplus
}
#endif

#endif
