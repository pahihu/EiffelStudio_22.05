/*
 * Code for class EV_COLOR_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev822.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_COLOR_IMP}.make */
void F1532_15162 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 1531, Current, 0, 0, 21696);
	RTGC;
	RTHOOK(1);
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (RTOUCR(331,F1531_15158, (Current)));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	F1514_14820(Current, (EIF_BOOLEAN) 1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_COLOR_IMP}.red */
EIF_REAL_32 F1532_15163 (EIF_REFERENCE Current)
{
	return *(EIF_REAL_32 *)(Current+ _R32OFF_2_1_0_3_2_);
}


/* {EV_COLOR_IMP}.green */
EIF_REAL_32 F1532_15164 (EIF_REFERENCE Current)
{
	return *(EIF_REAL_32 *)(Current+ _R32OFF_2_1_0_3_1_);
}


/* {EV_COLOR_IMP}.blue */
EIF_REAL_32 F1532_15165 (EIF_REFERENCE Current)
{
	return *(EIF_REAL_32 *)(Current+ _R32OFF_2_1_0_3_0_);
}


/* {EV_COLOR_IMP}.name */
EIF_REFERENCE F1532_15166 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


/* {EV_COLOR_IMP}.set_red */
void F1532_15167 (EIF_REFERENCE Current, EIF_REAL_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("set_red", 1531, Current, 0, 1, 21701);
	RTGC;
	RTHOOK(1);
	*(EIF_REAL_32 *)(Current+ _R32OFF_2_1_0_3_2_) = (EIF_REAL_32) arg1;
	RTHOOK(2);
	tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 65535L));
	tr1 = RTLNS(eif_new_type(1507, 0x00).id, 1507, _OBJSIZ_0_0_0_0_1_0_0_0_);
	*(EIF_REAL_32 *)tr1 = (EIF_REAL_32) (arg1 * tr4_1);
	ti4_1 = F1506_14638(RTCW(tr1));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_COLOR_IMP}.set_green */
void F1532_15168 (EIF_REFERENCE Current, EIF_REAL_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("set_green", 1531, Current, 0, 1, 21702);
	RTGC;
	RTHOOK(1);
	*(EIF_REAL_32 *)(Current+ _R32OFF_2_1_0_3_1_) = (EIF_REAL_32) arg1;
	RTHOOK(2);
	tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 65535L));
	tr1 = RTLNS(eif_new_type(1507, 0x00).id, 1507, _OBJSIZ_0_0_0_0_1_0_0_0_);
	*(EIF_REAL_32 *)tr1 = (EIF_REAL_32) (arg1 * tr4_1);
	ti4_1 = F1506_14638(RTCW(tr1));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_1_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_COLOR_IMP}.set_blue */
void F1532_15169 (EIF_REFERENCE Current, EIF_REAL_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("set_blue", 1531, Current, 0, 1, 21703);
	RTGC;
	RTHOOK(1);
	*(EIF_REAL_32 *)(Current+ _R32OFF_2_1_0_3_0_) = (EIF_REAL_32) arg1;
	RTHOOK(2);
	tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 65535L));
	tr1 = RTLNS(eif_new_type(1507, 0x00).id, 1507, _OBJSIZ_0_0_0_0_1_0_0_0_);
	*(EIF_REAL_32 *)tr1 = (EIF_REAL_32) (arg1 * tr4_1);
	ti4_1 = F1506_14638(RTCW(tr1));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_0_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_COLOR_IMP}.rgb_24_bit */
EIF_INTEGER_32 F1532_15171 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("rgb_24_bit", 1531, Current, 0, 0, 21705);
	RTGC;
	RTHOOK(1);
	Result = F1532_15173(Current);
	ti4_1 = F1532_15174(Current);
	ti4_2 = F1532_15175(Current);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (Result * ((EIF_INTEGER_32) 65536L)) + (EIF_INTEGER_32) (ti4_1 * ((EIF_INTEGER_32) 256L))) + ti4_2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_COLOR_IMP}.red_8_bit */
EIF_INTEGER_32 F1532_15173 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("red_8_bit", 1531, Current, 0, 0, 21707);
	RTGC;
	RTHOOK(1);
	tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 255L));
	tr1 = RTLNS(eif_new_type(1507, 0x00).id, 1507, _OBJSIZ_0_0_0_0_1_0_0_0_);
	*(EIF_REAL_32 *)tr1 = (EIF_REAL_32) (*(EIF_REAL_32 *)(Current+ _R32OFF_2_1_0_3_2_) * tr4_1);
	Result = F1506_14638(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_COLOR_IMP}.green_8_bit */
EIF_INTEGER_32 F1532_15174 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("green_8_bit", 1531, Current, 0, 0, 21708);
	RTGC;
	RTHOOK(1);
	tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 255L));
	tr1 = RTLNS(eif_new_type(1507, 0x00).id, 1507, _OBJSIZ_0_0_0_0_1_0_0_0_);
	*(EIF_REAL_32 *)tr1 = (EIF_REAL_32) (*(EIF_REAL_32 *)(Current+ _R32OFF_2_1_0_3_1_) * tr4_1);
	Result = F1506_14638(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_COLOR_IMP}.blue_8_bit */
EIF_INTEGER_32 F1532_15175 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("blue_8_bit", 1531, Current, 0, 0, 21709);
	RTGC;
	RTHOOK(1);
	tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 255L));
	tr1 = RTLNS(eif_new_type(1507, 0x00).id, 1507, _OBJSIZ_0_0_0_0_1_0_0_0_);
	*(EIF_REAL_32 *)tr1 = (EIF_REAL_32) (*(EIF_REAL_32 *)(Current+ _R32OFF_2_1_0_3_0_) * tr4_1);
	Result = F1506_14638(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_COLOR_IMP}.set_red_with_8_bit */
void F1532_15176 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_red_with_8_bit", 1531, Current, 0, 1, 21710);
	RTHOOK(1);
	F1532_15182(Current, (EIF_INTEGER_32) (arg1 * ((EIF_INTEGER_32) 257L)));
	RTHOOK(2);
	RTEE;
}

/* {EV_COLOR_IMP}.set_green_with_8_bit */
void F1532_15177 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_green_with_8_bit", 1531, Current, 0, 1, 21711);
	RTHOOK(1);
	F1532_15183(Current, (EIF_INTEGER_32) (arg1 * ((EIF_INTEGER_32) 257L)));
	RTHOOK(2);
	RTEE;
}

/* {EV_COLOR_IMP}.set_blue_with_8_bit */
void F1532_15178 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_blue_with_8_bit", 1531, Current, 0, 1, 21712);
	RTHOOK(1);
	F1532_15184(Current, (EIF_INTEGER_32) (arg1 * ((EIF_INTEGER_32) 257L)));
	RTHOOK(2);
	RTEE;
}

/* {EV_COLOR_IMP}.red_16_bit */
EIF_INTEGER_32 F1532_15179 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_);
}


/* {EV_COLOR_IMP}.green_16_bit */
EIF_INTEGER_32 F1532_15180 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_1_);
}


/* {EV_COLOR_IMP}.blue_16_bit */
EIF_INTEGER_32 F1532_15181 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_0_);
}


/* {EV_COLOR_IMP}.set_red_with_16_bit */
void F1532_15182 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REAL_32 tr4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_red_with_16_bit", 1531, Current, 0, 1, 21716);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	tr4_1 = (EIF_REAL_32) ((EIF_REAL_64) ((EIF_REAL_64) (arg1) /  (EIF_REAL_64) (((EIF_INTEGER_32) 65535L))));
	*(EIF_REAL_32 *)(Current+ _R32OFF_2_1_0_3_2_) = (EIF_REAL_32) tr4_1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_COLOR_IMP}.set_green_with_16_bit */
void F1532_15183 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REAL_32 tr4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_green_with_16_bit", 1531, Current, 0, 1, 21717);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_1_) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	tr4_1 = (EIF_REAL_32) ((EIF_REAL_64) ((EIF_REAL_64) (arg1) /  (EIF_REAL_64) (((EIF_INTEGER_32) 65535L))));
	*(EIF_REAL_32 *)(Current+ _R32OFF_2_1_0_3_1_) = (EIF_REAL_32) tr4_1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_COLOR_IMP}.set_blue_with_16_bit */
void F1532_15184 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REAL_32 tr4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_blue_with_16_bit", 1531, Current, 0, 1, 21718);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_0_) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	tr4_1 = (EIF_REAL_32) ((EIF_REAL_64) ((EIF_REAL_64) (arg1) /  (EIF_REAL_64) (((EIF_INTEGER_32) 65535L))));
	*(EIF_REAL_32 *)(Current+ _R32OFF_2_1_0_3_0_) = (EIF_REAL_32) tr4_1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_COLOR_IMP}.set_with_other */
void F1532_15185 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("set_with_other", 1531, Current, 1, 1, 21719);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc1 = RTRV(eif_new_type(1531, 0x00), loc1);
	RTHOOK(2);
	RTCT0("imp_not_void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(3);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_2_1_0_2_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(4);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_2_1_0_1_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_1_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(5);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_2_1_0_0_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_0_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(6);
	tr4_1 = *(EIF_REAL_32 *)(RTCW(loc1)+ _R32OFF_2_1_0_3_2_);
	*(EIF_REAL_32 *)(Current+ _R32OFF_2_1_0_3_2_) = (EIF_REAL_32) tr4_1;
	RTHOOK(7);
	tr4_1 = *(EIF_REAL_32 *)(RTCW(loc1)+ _R32OFF_2_1_0_3_1_);
	*(EIF_REAL_32 *)(Current+ _R32OFF_2_1_0_3_1_) = (EIF_REAL_32) tr4_1;
	RTHOOK(8);
	tr4_1 = *(EIF_REAL_32 *)(RTCW(loc1)+ _R32OFF_2_1_0_3_0_);
	*(EIF_REAL_32 *)(Current+ _R32OFF_2_1_0_3_0_) = (EIF_REAL_32) tr4_1;
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {EV_COLOR_IMP}.delta */
EIF_REAL_32 F1532_15186 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("delta", 1531, Current, 0, 0, 21720);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REAL_32) (EIF_REAL_32) ((EIF_REAL_64) ((EIF_REAL_32) 1.0) /  (EIF_REAL_64) ((EIF_REAL_32) 255.0));
}

/* {EV_COLOR_IMP}.destroy */
void F1532_15187 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("destroy", 1531, Current, 0, 0, 21721);
	RTHOOK(1);
	F1514_14821(Current, (EIF_BOOLEAN) 1);
	RTHOOK(2);
	RTEE;
}

void EIF_Minit822 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
