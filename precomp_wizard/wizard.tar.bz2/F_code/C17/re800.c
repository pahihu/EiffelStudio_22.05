/*
 * Code for class REAL_64
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "re800.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {REAL_64}.is_less */
EIF_BOOLEAN F1511_14718 (EIF_REFERENCE Current, EIF_REAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_less", 1510, Current, 0, 1, 21361);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1510, 0x00).id, 1510, _OBJSIZ_0_0_0_0_0_0_0_1_);
	*(EIF_REAL_64 *)tr1 = arg1;
	Result = F1509_14688(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {REAL_64}.is_nan */
EIF_BOOLEAN F1511_14719 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_nan", 1510, Current, 0, 0, 21362);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) F1509_14694(Current);
}

/* {REAL_64}.is_negative_infinity */
EIF_BOOLEAN F1511_14720 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_negative_infinity", 1510, Current, 0, 0, 21363);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) F1509_14695(Current);
}

/* {REAL_64}.is_positive_infinity */
EIF_BOOLEAN F1511_14721 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_positive_infinity", 1510, Current, 0, 0, 21364);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) F1509_14696(Current);
}

/* {REAL_64}.truncated_to_integer */
EIF_INTEGER_32 F1511_14722 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("truncated_to_integer", 1510, Current, 0, 0, 21365);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) F1509_14699(Current);
}

/* {REAL_64}.truncated_to_integer_64 */
EIF_INTEGER_64 F1511_14723 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("truncated_to_integer_64", 1510, Current, 0, 0, 21366);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_64) F1509_14700(Current);
}

/* {REAL_64}.truncated_to_real */
EIF_REAL_32 F1511_14724 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("truncated_to_real", 1510, Current, 0, 0, 21367);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REAL_32) F1509_14701(Current);
}

/* {REAL_64}.floor_real_64 */
EIF_REAL_64 F1511_14726 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("floor_real_64", 1510, Current, 0, 0, 21345);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REAL_64) F1509_14706(Current);
}

/* {REAL_64}.plus */
EIF_REAL_64 F1511_14727 (EIF_REFERENCE Current, EIF_REAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("plus", 1510, Current, 0, 1, 21346);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1510, 0x00).id, 1510, _OBJSIZ_0_0_0_0_0_0_0_1_);
	*(EIF_REAL_64 *)tr1 = arg1;
	tr1 = F1509_14709(Current, tr1);
	Result = *(EIF_REAL_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {REAL_64}.minus */
EIF_REAL_64 F1511_14728 (EIF_REFERENCE Current, EIF_REAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("minus", 1510, Current, 0, 1, 21347);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1510, 0x00).id, 1510, _OBJSIZ_0_0_0_0_0_0_0_1_);
	*(EIF_REAL_64 *)tr1 = arg1;
	tr1 = F1509_14710(Current, tr1);
	Result = *(EIF_REAL_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {REAL_64}.product */
EIF_REAL_64 F1511_14729 (EIF_REFERENCE Current, EIF_REAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("product", 1510, Current, 0, 1, 21348);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1510, 0x00).id, 1510, _OBJSIZ_0_0_0_0_0_0_0_1_);
	*(EIF_REAL_64 *)tr1 = arg1;
	tr1 = F1509_14711(Current, tr1);
	Result = *(EIF_REAL_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {REAL_64}.quotient */
EIF_REAL_64 F1511_14730 (EIF_REFERENCE Current, EIF_REAL_64 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("quotient", 1510, Current, 0, 1, 21349);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1510, 0x00).id, 1510, _OBJSIZ_0_0_0_0_0_0_0_1_);
	*(EIF_REAL_64 *)tr1 = arg1;
	tr1 = F1509_14712(Current, tr1);
	Result = *(EIF_REAL_64 *)(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {REAL_64}.power */
EIF_REAL_64 F1511_14731 (EIF_REFERENCE Current, EIF_REAL_64 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("power", 1510, Current, 0, 1, 21350);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REAL_64) F1509_14713(Current, arg1);
}

/* {REAL_64}.opposite */
EIF_REAL_64 F1511_14733 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("opposite", 1510, Current, 0, 0, 21352);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return *(EIF_REAL_64 *)F1509_14715(Current);
}

/* {REAL_64}.out */
EIF_REFERENCE F1511_14741 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("out", 1510, Current, 0, 0, 21360);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) F1509_14716(Current);
}

void EIF_Minit800 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
