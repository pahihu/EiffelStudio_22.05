/*
 * Code for class EV_COLORIZABLE_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev842.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_COLORIZABLE_I}.foreground_color */
EIF_REFERENCE F1556_15750 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("foreground_color", 1555, Current, 1, 0, 22225);
	RTGC;
	RTHOOK(1);
	RTCT0("attached foreground_color_internal as l_result", EX_CHECK);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R12933[Dtype(Current)-1601])(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(2);
	Result = (EIF_REFERENCE) loc1;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_COLORIZABLE_I}.background_color */
EIF_REFERENCE F1556_15751 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("background_color", 1555, Current, 1, 0, 22226);
	RTGC;
	RTHOOK(1);
	RTCT0("attached background_color_internal as l_result", EX_CHECK);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R12934[Dtype(Current)-1601])(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(2);
	Result = (EIF_REFERENCE) loc1;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit842 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
