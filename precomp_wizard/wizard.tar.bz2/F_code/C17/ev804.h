
#ifndef _C17_ev804_
#define _C17_ev804_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1514_14800(EIF_REFERENCE, EIF_REFERENCE);
extern void F1514_14803(EIF_REFERENCE);
extern EIF_BOOLEAN F1514_14805(EIF_REFERENCE);
extern EIF_REFERENCE F1514_14806(EIF_REFERENCE);
extern void F1514_14815(EIF_REFERENCE, EIF_INTEGER_8, EIF_BOOLEAN);
extern EIF_BOOLEAN F1514_14816(EIF_REFERENCE, EIF_INTEGER_8);
extern EIF_BOOLEAN F1514_14819(EIF_REFERENCE);
extern void F1514_14820(EIF_REFERENCE, EIF_BOOLEAN);
extern void F1514_14821(EIF_REFERENCE, EIF_BOOLEAN);
extern void F1514_14822(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit804(void);
extern char *(*R12202[])();
extern long O12205[];
extern long O12206[];

#ifdef __cplusplus
}
#endif

#endif
