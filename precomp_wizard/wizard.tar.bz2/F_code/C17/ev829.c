/*
 * Code for class EV_APPLICATION_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev829.h"
#include <string.h>
#include "eif_except.h"
#include "eif_main.h"
#include "eif_built_in.h"
#include <gmodule.h>
#include "ev_c_util.h"
#include <stdlib.h>
#include <ev_any_imp.h>
#include <ev_gtk.h>
#include "eif_argv.h"
#include "eif_misc.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F175_2382
static void inline_F175_2382 (EIF_POINTER arg1)
{
	return gdk_set_allowed_backends ( (const gchar*) arg1);
	;
}
#define INLINE_F175_2382
#endif
#ifndef INLINE_F275_4639
static int inline_F275_4639 (void)
{
	#ifdef WORKBENCH
	return EIF_TEST(is_debug_mode());
#else
	return EIF_FALSE;
#endif
	;
}
#define INLINE_F275_4639
#endif
#ifndef INLINE_F175_2419
static EIF_POINTER inline_F175_2419 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gdk_display_get_default_screen ((GdkDisplay*) arg1))
	;
}
#define INLINE_F175_2419
#endif
#ifndef INLINE_F175_2578
static EIF_POINTER inline_F175_2578 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gdk_screen_get_system_visual ((GdkScreen*) arg1))
	;
}
#define INLINE_F175_2578
#endif
#ifndef INLINE_F175_2476
static EIF_INTEGER_32 inline_F175_2476 (EIF_POINTER arg1)
{
	return (EIF_INTEGER_32) (gdk_visual_get_depth ((GdkVisual*) arg1))
	;
}
#define INLINE_F175_2476
#endif
#ifndef INLINE_F174_2330
static void inline_F174_2330 (EIF_POINTER arg1)
{
	#ifdef GDK_WINDOWING_X11
	return gdk_x11_display_error_trap_push ((GdkDisplay *)arg1);
#endif
	;
}
#define INLINE_F174_2330
#endif
#ifndef INLINE_F175_2581
static EIF_POINTER inline_F175_2581 (void)
{
	return gdk_screen_get_default()
	;
}
#define INLINE_F175_2581
#endif
#ifndef INLINE_F1539_15365
static int inline_F1539_15365 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	return (FUNCTION_CAST(gboolean, (GdkScreen*)) arg1)((GdkScreen*) arg2);
	;
}
#define INLINE_F1539_15365
#endif
#ifndef INLINE_F175_2421
static EIF_INTEGER_32 inline_F175_2421 (EIF_POINTER arg1)
{
	return gdk_display_get_n_monitors ((GdkDisplay*) arg1)
	;
}
#define INLINE_F175_2421
#endif
#ifndef INLINE_F175_2427
static void inline_F175_2427 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gdk_monitor_get_geometry ((GdkMonitor*) arg1, (GdkRectangle*) arg2)
	;
}
#define INLINE_F175_2427
#endif
#ifndef INLINE_F1539_15502
static void inline_F1539_15502 (EIF_POINTER arg1)
{
	{
				  GdkDisplay *display = gdk_display_get_default ();
				  int num_monitors = gdk_display_get_n_monitors (display);

				  gint x, y, w, h;

				  x = y = G_MAXINT;
				  w = h = G_MININT;

				  for (int i = 0; i < num_monitors; i++)
				    {
				      GdkRectangle rect;
				      GdkMonitor *monitor = gdk_display_get_monitor (display, i);
				      gdk_monitor_get_geometry (monitor, &rect);

				      x = MIN (x, rect.x);
				      y = MIN (y, rect.y);
				      w = MAX (w, rect.x + rect.width);
				      h = MAX (h, rect.y + rect.height);
				    }

				  ((GdkRectangle *)arg1)->width = w - x;
				  ((GdkRectangle *)arg1)->height = h - y;
				}
	;
}
#define INLINE_F1539_15502
#endif
#ifndef INLINE_F175_2410
static void inline_F175_2410 (EIF_POINTER arg1)
{
	g_object_unref((gpointer) arg1)
	;
}
#define INLINE_F175_2410
#endif
#ifndef INLINE_F48_848
static EIF_POINTER inline_F48_848 (void)
{
	return (GdkDevice*) gdk_seat_get_pointer((GdkSeat*) gdk_display_get_default_seat ((GdkDisplay*) gdk_display_get_default()));
	;
}
#define INLINE_F48_848
#endif
#ifndef INLINE_F48_845
static void inline_F48_845 (EIF_POINTER arg1, EIF_INTEGER_32* arg2, EIF_INTEGER_32* arg3)
{
	return gdk_device_get_position ((GdkDevice*) arg1, NULL, (gint*) arg2, (gint*) arg3);
	;
}
#define INLINE_F48_845
#endif
#ifndef INLINE_F275_4638
static void inline_F275_4638 (EIF_BOOLEAN arg1)
{
	#ifdef WORKBENCH
	set_debug_mode (arg1 ? 1 : 0);
#endif
	;
}
#define INLINE_F275_4638
#endif
#ifndef INLINE_F1548_15579
static EIF_REFERENCE inline_F1548_15579 (EIF_POINTER arg1)
{
	return (EIF_REFERENCE) (c_ev_any_imp_get_eif_reference_from_object_id (arg1))
	;
}
#define INLINE_F1548_15579
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_APPLICATION_IMP}.make */
void F1539_15359 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_REFERENCE tr6 = NULL;
	EIF_REFERENCE tr7 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,tr5);
	RTLR(6,tr6);
	RTLR(7,tr7);
	RTLIU(8);
	
	RTEAA("make", 1538, Current, 0, 0, 21953);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(177, 0x00).id, 177, _OBJSIZ_0_0_0_0_0_0_0_0_);
	if (RTOUCB(EIF_BOOLEAN,533,F178_3145, (RTCW(tr1)))) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(1137, 0x00).id, 1137, _OBJSIZ_0_1_0_1_0_1_0_0_);
		tr2 = RTMS_EX_H("x11",3,7876913);
		F1138_9661(RTCW(tr1), tr2);
		tp1 = *(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_0_1_0_1_0_0_);
		inline_F175_2382(tp1);
	}
	RTHOOK(3);
	tr1 = RTMS_EX_H("0",1,48);
	tr2 = RTMS_EX_H("LIBOVERLAY_SCROLLBAR",20,1673493842);
	F517_7510(Current, tr1, tr2);
	RTHOOK(4);
	tr1 = RTLNSMART(eif_new_type(1241, 0).id);
	F1240_11189(RTCW(tr1), ((EIF_INTEGER_32) 4L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_47_) = (EIF_REFERENCE) tr1;
	RTHOOK(5);
	tb1 = (EIF_BOOLEAN) EIF_TEST(gtk_init_check (&eif_argc, &eif_argv));
	*(EIF_BOOLEAN *)(Current+ _CHROFF_49_11_) = (EIF_BOOLEAN) tb1;
	RTHOOK(6);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,4,1186,1228,1486,1486,1498,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_48_) = (EIF_REFERENCE) tr1;
	RTHOOK(7);
	tr1 = RTLNSMART(eif_new_type(1155, 0).id);
	F1156_10575(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_42_) = (EIF_REFERENCE) tr1;
	RTHOOK(8);
	{
		static EIF_TYPE_INDEX typarr0[] = {883,1486,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F884_8665(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_43_) = (EIF_REFERENCE) tr1;
	RTHOOK(9);
	tr1 = F1237_11118(RTMS_EX_H("",0,0));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_22_) = (EIF_REFERENCE) tr1;
	RTHOOK(10);
	F1538_15254(Current);
	RTHOOK(11);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_49_11_)) {
		RTHOOK(12);
		F1539_15496(Current);
		RTHOOK(13);
		tb1 = EIF_TEST (inline_F275_4639());
		*(EIF_BOOLEAN *)(Current+ _CHROFF_49_12_) = (EIF_BOOLEAN) tb1;
		RTHOOK(14);
		enable_ev_gtk_log((EIF_INTEGER) ((EIF_INTEGER_32) 0L));
		RTHOOK(15);
		gdk_set_show_events((gboolean) (EIF_BOOLEAN) 0);
		RTHOOK(16);
		tp1 = (EIF_POINTER) gdk_display_get_default();
		tp1 = inline_F175_2419(tp1);
		tp1 = inline_F175_2578(tp1);
		ti4_1 = inline_F175_2476(tp1);
		ti4_1 = eif_min_int32 (ti4_1,((EIF_INTEGER_32) 24L));
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_18_) = (EIF_INTEGER_32) ti4_1;
		RTHOOK(17);
		F1152_10497(Current);
		RTHOOK(18);
		F1539_15459(Current, ((EIF_INTEGER_32) 500L));
		RTHOOK(19);
		if (RTOUCB(EIF_BOOLEAN,534,F1539_15366, (Current))) {
			RTHOOK(20);
			tp1 = (EIF_POINTER) gdk_display_get_default();
			inline_F174_2330(tp1);
		}
		RTHOOK(21);
		F1539_15361(Current);
		RTHOOK(22);
		tp1 = (EIF_POINTER) gtk_im_context_simple_new();
		*(EIF_POINTER *)(Current+ _PTROFF_49_16_0_20_0_3_) = (EIF_POINTER) tp1;
		RTHOOK(23);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_42_);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_16_0_20_0_3_);
		tr2 = RTLNS(eif_new_type(54, 0x00).id, 54, _OBJSIZ_0_0_0_0_0_0_0_0_);
		tr3 = RTOUCR(535,F55_996, (RTCW(tr2)));
		{
			EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,0,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr4 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr4+1)->it_r = Current;
		RTAR(tr4,Current);
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1233,0xFFF9,1,1186,1228,1228,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr7= RTLNRF(typres0.id, (EIF_POINTER) __A829_425_2, (EIF_POINTER) _A829_425_2, (EIF_POINTER)(F1539_15360),tr4, 1, 1);
		}
		F1156_10579(RTCW(tr1), tp1, tr3, tr7);
	} else {
		RTHOOK(24);
		tr1 = RTMS_EX_H("EiffelVision application could not launch, check DISPLAY environment variable\012",78,1906588938);
		F1_27(Current, tr1);
		RTHOOK(25);
		esdie(((EIF_INTEGER_32) 0L));
	}
	RTHOOK(26);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_IMP}.on_char_event */
EIF_POINTER F1539_15360 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("on_char_event", 1538, Current, 1, 1, 21954);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_POINTER) g_value_peek_pointer((GValue*) arg1);
	RTHOOK(2);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc1 != tp1)) {
		RTHOOK(3);
		tr1 = RTOUCR(536,F1539_15494, (Current));
		F1138_9663(RTCW(tr1), loc1);
	} else {
		RTHOOK(4);
		tr1 = RTOUCR(536,F1539_15494, (Current));
		tr2 = RTMS_EX_H("",0,0);
		F1138_9661(RTCW(tr1), tr2);
	}
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_47_);
	F1242_11333(RTCW(tr1));
	RTHOOK(6);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_47_);
	tr2 = F1138_9659(RTCV(RTOUCR(536,F1539_15494, (Current))));
	F1242_11304(RTCW(tr1), tr2);
	RTHOOK(7);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_16_0_20_0_3_);
	gtk_im_context_reset((GtkIMContext*) tp1);
	RTHOOK(8);
	RTLE;
	RTEE;
	return (EIF_POINTER) 0;
}

/* {EV_APPLICATION_IMP}.update_screen_meta_data */
void F1539_15361 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("update_screen_meta_data", 1538, Current, 3, 0, 21955);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_49_13_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(2);
	loc2 = RTOUCB(EIF_POINTER,537,F1539_15364, (Current));
	RTHOOK(3);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc2 != tp1)) {
		RTHOOK(4);
		tp1 = inline_F175_2581();
		tb1 = EIF_TEST (inline_F1539_15365(loc2, tp1));
		*(EIF_BOOLEAN *)(Current+ _CHROFF_49_7_) = (EIF_BOOLEAN) tb1;
	}
	RTHOOK(5);
	tp1 = (EIF_POINTER) gdk_display_get_default();
	ti4_1 = inline_F175_2421(tp1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_17_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(6);
	loc1 = RTOUCB(EIF_POINTER,538,F1539_15492, (Current));
	RTHOOK(7);
	tp1 = (EIF_POINTER) gdk_display_get_default();
	tp1 = (EIF_POINTER) gdk_display_get_primary_monitor((GdkDisplay*) tp1);
	*(EIF_POINTER *)(Current+ _PTROFF_49_16_0_20_0_1_) = (EIF_POINTER) tp1;
	RTHOOK(8);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_16_0_20_0_1_);
	inline_F175_2427(tp1, loc1);
	RTHOOK(9);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_11_) = (EIF_INTEGER_32) (EIF_INTEGER_32) -(EIF_INTEGER_32) (((GdkRectangle *)loc1)->x);
	RTHOOK(10);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_12_) = (EIF_INTEGER_32) (EIF_INTEGER_32) -(EIF_INTEGER_32) (((GdkRectangle *)loc1)->y);
	RTHOOK(11);
	ti4_1 = (EIF_INTEGER_32) (((GdkRectangle *)loc1)->width);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_15_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(12);
	ti4_1 = (EIF_INTEGER_32) (((GdkRectangle *)loc1)->height);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_16_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(13);
	loc3 = (EIF_POINTER) calloc (sizeof(GdkRectangle), 1);
	RTHOOK(14);
	inline_F1539_15502(loc3);
	RTHOOK(15);
	ti4_1 = (EIF_INTEGER_32) (((GdkRectangle *)loc3)->width);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_13_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(16);
	ti4_1 = (EIF_INTEGER_32) (((GdkRectangle *)loc3)->height);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_14_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(17);
	free(loc3);
	RTHOOK(18);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_IMP}.gdk_screen_is_composited_symbol */
static EIF_POINTER F1539_15364_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRB(EIF_POINTER)
	RTOUDB(EIF_POINTER, 537)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("gdk_screen_is_composited_symbol", 1538, Current, 0, 0, 21958);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTMS_EX_H("gdk_screen_is_composited",24,1829865316);
	Result = F1539_15390(Current, tr1);
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_POINTER F1539_15364 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_POINTER,537,F1539_15364_body,(Current));
}

/* {EV_APPLICATION_IMP}.gdk_screen_is_composited_call */
EIF_BOOLEAN F1539_15365 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_screen_is_composited_call", 1538, Current, 0, 2, 21959);
	Result = EIF_TEST(inline_F1539_15365 ((EIF_POINTER) arg1, (EIF_POINTER) arg2));
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_APPLICATION_IMP}.is_x11_session */
static EIF_BOOLEAN F1539_15366_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	
#define Result RTOTRB(EIF_BOOLEAN)
	RTOUDB(EIF_BOOLEAN, 534)

	
	RTEAA("is_x11_session", 1538, Current, 0, 0, 21960);
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(177, 0x00).id, 177, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = RTOUCB(EIF_BOOLEAN,532,F178_3144, (RTCW(tr1)));
	RTOTE;
	RTHOOK(2);
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F1539_15366 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_BOOLEAN,534,F1539_15366_body,(Current));
}

/* {EV_APPLICATION_IMP}.has_x11_support */
static EIF_BOOLEAN F1539_15367_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRB(EIF_BOOLEAN)
	RTOUDB(EIF_BOOLEAN, 539)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("has_x11_support", 1538, Current, 1, 0, 21961);
	RTGC;
	RTAOMS(15366,1);
	RTOTP;
	RTHOOK(1);
	Result = RTOUCB(EIF_BOOLEAN,534,F1539_15366, (Current));
	RTHOOK(2);
	if (Result) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_mac__b) {
			RTHOOK(4);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			RTHOOK(5);
			RTCOMS(tr2,15366,0,"EV_HAS_X11_SUPPORT",18,1084065108);
			tr1 = RTLNS(eif_new_type(516, 0x00).id, 516, _OBJSIZ_0_0_0_1_0_0_0_0_);
			tr2 = F517_7497(RTCW(tr1), tr2);
			loc1 = tr2;
			if (EIF_TEST(loc1)) {
				RTHOOK(6);
				tr1 = RTMS_EX_H("no",2,28271);
				Result = F1237_11101(loc1, tr1);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
			}
		}
	}
	RTOTE;
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F1539_15367 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_BOOLEAN,539,F1539_15367_body,(Current));
}

/* {EV_APPLICATION_IMP}.call_post_launch_actions */
void F1539_15368 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("call_post_launch_actions", 1538, Current, 0, 0, 21962);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_49_11_)) {
		RTHOOK(2);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_16_0_20_0_3_);
		tp2 = F1539_15488(Current);
		gtk_im_context_set_client_window((GtkIMContext*) tp1, (GdkWindow*) tp2);
		RTHOOK(3);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_16_0_20_0_3_);
		gtk_im_context_focus_in((GtkIMContext*) tp1);
	}
	RTHOOK(4);
	F1538_15336(Current);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_IMP}.is_display_remote */
EIF_BOOLEAN F1539_15380 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_49_13_);
}


/* {EV_APPLICATION_IMP}.set_currently_shown_control */
void F1539_15381 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_currently_shown_control", 1538, Current, 0, 1, 21975);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_41_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EV_APPLICATION_IMP}.focused_widget */
EIF_REFERENCE F1539_15383 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,loc5);
	RTLR(6,loc6);
	RTLR(7,Result);
	RTLIU(8);
	
	RTEAA("focused_widget", 1538, Current, 6, 0, 21977);
	RTGC;
	RTHOOK(1);
	loc1 = F1539_15397(Current);
	RTHOOK(2);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7452[Dtype(RTCW(loc1))-554])(loc1);
	loc4 = (EIF_REFERENCE) tr1;
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8078[Dtype(loc4)-967])(loc4);
		if (tb1) break;
		RTHOOK(3);
		if ((EIF_BOOLEAN)(Result != NULL)) break;
		RTHOOK(4);
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8077[Dtype(loc4)-967])(loc4);
		RTHOOK(5);
		tb2 = F1347_12802(RTCW(loc2));
		if (tb2) {
			RTHOOK(6);
			tb2 = F1355_12913(RTCW(loc2));
			if (tb2) {
				RTHOOK(7);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + O9889[Dtype(loc2)-1247]);
				loc5 = tr1;
				loc5 = RTRV(eif_new_type(1615, 0x00),loc5);
				if (EIF_TEST(loc5)) {
					RTHOOK(8);
					tp1 = *(EIF_POINTER *)(loc5 + O12790[Dtype(loc5)-1547]);
					loc3 = (EIF_POINTER) gtk_window_get_focus((GtkWindow*) tp1);
					RTHOOK(9);
					tb2 = !loc3;
					if ((EIF_BOOLEAN) !tb2) {
						RTHOOK(10);
						tr1 = F1539_15483(Current, loc3);
						loc6 = tr1;
						loc6 = RTRV(eif_new_type(1588, 0x00),loc6);
						if (EIF_TEST(loc6)) {
							RTHOOK(11);
							Result = *(EIF_REFERENCE *)(loc6 + O12205[Dtype(loc6)-1513]);
						}
					}
				} else {
					
				}
			} else {
				RTHOOK(13);
				Result = (EIF_REFERENCE) loc2;
			}
		}
		RTHOOK(14);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R8079[Dtype(loc4)-967])(loc4);
	}
	RTHOOK(15);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_APPLICATION_IMP}.wait_for_input */
void F1539_15384 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("wait_for_input", 1538, Current, 0, 1, 21978);
	RTHOOK(1);
	F1539_15456(Current, arg1);
	RTHOOK(2);
	RTEE;
}

/* {EV_APPLICATION_IMP}.print_debug_event */
void F1539_15385 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2, EIF_POINTER arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("print_debug_event", 1538, Current, 2, 3, 21979);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_IMP}.process_underlying_toolkit_event_queue */
void F1539_15386 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_POINTER loc13 = (EIF_POINTER) 0;
	EIF_POINTER loc14 = (EIF_POINTER) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc17 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc18 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc19 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc20 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc21 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc22 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc23 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc24 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc25 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc26 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc27 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc28 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc29 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc30 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc31 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc32 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc33 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc34 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc35 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc36 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc37 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc38 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc39 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc40 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc41 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_INTEGER_8 ti1_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(24);
	RTLR(0,loc15);
	RTLR(1,Current);
	RTLR(2,loc16);
	RTLR(3,loc30);
	RTLR(4,tr1);
	RTLR(5,loc31);
	RTLR(6,loc32);
	RTLR(7,loc8);
	RTLR(8,loc10);
	RTLR(9,loc9);
	RTLR(10,tr2);
	RTLR(11,loc33);
	RTLR(12,tr3);
	RTLR(13,loc34);
	RTLR(14,loc12);
	RTLR(15,loc11);
	RTLR(16,loc35);
	RTLR(17,loc36);
	RTLR(18,loc37);
	RTLR(19,loc38);
	RTLR(20,loc39);
	RTLR(21,loc40);
	RTLR(22,loc25);
	RTLR(23,loc41);
	RTLIU(24);
	
	RTEAA("process_underlying_toolkit_event_queue", 1538, Current, 41, 0, 21980);
	RTGC;
	RTAOMS(15385,2);
	RTHOOK(1);
	loc15 = RTOUCR(540,F1539_15401, (Current));
	RTHOOK(2);
	loc16 = RTOUCR(541,F1539_15402, (Current));
	for (;;) {
		RTHOOK(3);
		tb1 = '\01';
		if (!loc17) {
			tb1 = F1514_14805(Current);
		}
		if (tb1) break;
		RTHOOK(4);
		loc1 = (EIF_POINTER) gdk_event_get();
		RTHOOK(5);
		tb2 = !loc1;
		if ((EIF_BOOLEAN) !tb2) {
			RTHOOK(6);
			loc3 = (EIF_POINTER) gtk_get_event_widget((GdkEvent*) loc1);
			RTHOOK(7);
			ti1_1 = (EIF_INTEGER_8) (((GdkEventAny *)loc1)->send_event);
			loc29 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti1_1 != (EIF_INTEGER_8) ((EIF_INTEGER_32) 0L));
			RTHOOK(8);
			loc27 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			RTHOOK(9);
			loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			RTHOOK(10);
			loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			RTHOOK(11);
			loc4 = (EIF_POINTER) gtk_grab_get_current();
			RTHOOK(12);
			tb2 = !loc4;
			if (tb2) {
				RTHOOK(13);
				loc24 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				RTHOOK(14);
				loc4 = (EIF_POINTER) loc3;
			} else {
				RTHOOK(15);
				loc24 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				RTHOOK(16);
				tb2 = '\0';
				tr1 = F1539_15468(Current);
				loc30 = tr1;
				if (EIF_TEST(loc30)) {
					tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R12846[Dtype(loc30)-1550])(loc30);
					tb2 = (EIF_BOOLEAN) !tb3;
				}
				if (tb2) {
					RTHOOK(17);
					tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
					tr8_2 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
					tr8_3 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
					F1587_16099(loc30, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), tr8_1, tr8_2, tr8_3, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
				} else {
					RTHOOK(18);
					tb2 = '\0';
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
					loc31 = tr1;
					if (EIF_TEST(loc31)) {
						tb3 = F1347_12801(loc31);
						tb2 = (EIF_BOOLEAN) !tb3;
					}
					if (tb2) {
						RTHOOK(19);
						F1347_12808(loc31);
					}
				}
			}
			RTHOOK(20);
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_8) (((GdkEventAny *)loc1)->type);
			RTHOOK(21);
			switch (loc2) {
				case 3L:
					RTHOOK(22);
					loc28 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					RTHOOK(23);
					*(EIF_BOOLEAN *)(Current+ _CHROFF_49_8_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					RTHOOK(24);
					tr8_1 = (EIF_REAL_64) (((GdkEventMotion *)loc1)->x);
					loc19 = (EIF_INTEGER_32) tr8_1;
					RTHOOK(25);
					tr8_1 = (EIF_REAL_64) (((GdkEventMotion *)loc1)->y);
					loc20 = (EIF_INTEGER_32) tr8_1;
					RTHOOK(26);
					tr8_1 = (EIF_REAL_64) (((GdkEventMotion *)loc1)->x_root);
					loc21 = (EIF_INTEGER_32) tr8_1;
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_11_);
					loc21 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc21 + ti4_1);
					RTHOOK(27);
					tr8_1 = (EIF_REAL_64) (((GdkEventMotion *)loc1)->y_root);
					loc22 = (EIF_INTEGER_32) tr8_1;
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_12_);
					loc22 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc22 + ti4_1);
					RTHOOK(28);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_48_);
					tp1 = (EIF_POINTER) (((GdkEventMotion *)loc1)->window);
					
					eif_put_pointer_item(RTCW(tr1),1,tp1);
					RTHOOK(29);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_48_);
					
					eif_put_integer_32_item(RTCW(tr1),2,loc21);
					RTHOOK(30);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_48_);
					
					eif_put_integer_32_item(RTCW(tr1),3,loc22);
					RTHOOK(31);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_48_);
					tu4_1 = (EIF_NATURAL_32) (((GdkEventMotion *)loc1)->state);
					
					eif_put_natural_32_item(RTCW(tr1),4,tu4_1);
					RTHOOK(32);
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					RTHOOK(33);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
					loc32 = tr1;
					if (EIF_TEST(loc32)) {
						RTHOOK(34);
						loc8 = *(EIF_REFERENCE *)(loc32 + O9889[Dtype(loc32)-1247]);
						loc8 = RTRV(eif_new_type(1586, 0x00), loc8);
					} else {
						RTHOOK(35);
						if ((EIF_BOOLEAN)(F1539_15468(Current) != NULL)) {
							RTHOOK(36);
							loc8 = F1539_15468(Current);
						} else {
							RTHOOK(37);
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_48_);
							tp2 = eif_pointer_item(RTCW(tr1),1);
							loc8 = F1539_15485(Current, tp2);
							loc8 = RTRV(eif_new_type(1586, 0x00), loc8);
						}
					}
					RTHOOK(38);
					tb2 = '\0';
					if ((EIF_BOOLEAN)(loc8 != NULL)) {
						tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R12846[Dtype(RTCW(loc8))-1550])(loc8);
						tb2 = tb3;
					}
					if (tb2) {
						RTHOOK(39);
						loc10 = F1549_15636(RTCW(loc8));
						RTHOOK(40);
						if ((EIF_BOOLEAN)(loc10 != NULL)) {
							RTHOOK(41);
							tb2 = F1616_16583(RTCW(loc10));
							if ((EIF_BOOLEAN) !tb2) {
								RTHOOK(42);
								gtk_main_do_event((GdkEvent*) loc1);
								RTHOOK(43);
								if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_9_) != NULL)) {
									RTHOOK(44);
									loc9 = loc8;
									loc9 = RTRV(eif_new_type(1588, 0x00), loc9);
									RTHOOK(45);
									if ((EIF_BOOLEAN)(loc9 != NULL)) {
										RTHOOK(46);
										tr1 = F1514_14806(RTCW(loc9));
										
										eif_put_reference_item(RTCW(loc16),1,tr1);
										RTHOOK(47);
										
										eif_put_integer_32_item(RTCW(loc16),2,loc21);
										RTHOOK(48);
										
										eif_put_integer_32_item(RTCW(loc16),3,loc22);
										RTHOOK(49);
										tr2 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
										(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7959[Dtype(RTCW(tr2))-915])(tr2, loc16);
										RTHOOK(50);
										tr2 = RTOUCR(542,F1539_15490, (Current));
										
										eif_put_reference_item(RTCW(loc16),1,tr2);
									}
								}
								RTHOOK(51);
								tp2 = *(EIF_POINTER *)(RTCW(loc8) + O12790[Dtype(loc8)-1547]);
								ti4_1 = (EIF_INTEGER_32) gtk_widget_get_state_flags((GtkWidget*) tp2);
								ti4_2 = (EIF_INTEGER_32) GTK_STATE_FLAG_INSENSITIVE;
								ti4_1 = eif_bit_and(ti4_1,ti4_2);
								if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
									RTHOOK(52);
									tp2 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R12814[Dtype(RTCW(loc8))-1550])(loc8);
									if ((EIF_BOOLEAN)((EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp2) != (EIF_POINTER) (((GdkEventMotion *)loc1)->window))) {
										RTHOOK(53);
										tp2 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R12814[Dtype(RTCW(loc8))-1550])(loc8);
										gtk_widget_realize((GtkWidget*) tp2);
										RTHOOK(54);
										tp2 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R12814[Dtype(RTCW(loc8))-1550])(loc8);
										tp2 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp2);
										loc18 = (EIF_INTEGER_32) gdk_window_get_origin((GdkWindow*) tp2, (gint*) (EIF_INTEGER_32 *) &(loc19), (gint*) (EIF_INTEGER_32 *) &(loc20));
										RTHOOK(55);
										loc19 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc21 - loc19);
										RTHOOK(56);
										loc20 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc22 - loc20);
									}
									RTHOOK(57);
									
									eif_put_integer_32_item(RTCW(loc15),1,loc19);
									RTHOOK(58);
									
									eif_put_integer_32_item(RTCW(loc15),2,loc20);
									RTHOOK(59);
									
									eif_put_real_64_item(RTCW(loc15),3,(EIF_REAL_64) 0.5);
									RTHOOK(60);
									
									eif_put_real_64_item(RTCW(loc15),4,(EIF_REAL_64) 0.5);
									RTHOOK(61);
									
									eif_put_real_64_item(RTCW(loc15),5,(EIF_REAL_64) 0.5);
									RTHOOK(62);
									
									eif_put_integer_32_item(RTCW(loc15),6,loc21);
									RTHOOK(63);
									
									eif_put_integer_32_item(RTCW(loc15),7,loc22);
									RTHOOK(64);
									(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R13173[Dtype(RTCW(loc8))-1601])(loc8, loc15);
								}
							}
						} else {
							RTHOOK(65);
							gtk_main_do_event((GdkEvent*) loc1);
						}
					} else {
						RTHOOK(66);
						gtk_main_do_event((GdkEvent*) loc1);
					}
					RTHOOK(67);
					loc9 = (EIF_REFERENCE) NULL;
					RTHOOK(68);
					loc8 = (EIF_REFERENCE) NULL;
					RTHOOK(69);
					*(EIF_BOOLEAN *)(Current+ _CHROFF_49_8_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					RTHOOK(70);
					if ((EIF_BOOLEAN)((EIF_INTEGER_32) (((GdkEventMotion *)loc1)->is_hint) != ((EIF_INTEGER_32) 0L))) {
						RTHOOK(71);
						F1539_15474(Current);
					}
					break;
				case 4L:
				case 5L:
				case 6L:
				case 7L:
					RTHOOK(72);
					loc28 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					RTHOOK(73);
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					RTHOOK(74);
					F1539_15403(Current, loc1, (EIF_BOOLEAN) 0);
					break;
				case 31L:
					RTHOOK(75);
					if ((EIF_BOOLEAN) !F1539_15467(Current)) {
						RTHOOK(76);
						tr3 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
						loc33 = tr3;
						if (EIF_TEST(loc33)) {
							RTHOOK(77);
							tr8_1 = (EIF_REAL_64) (((GdkEventScroll *)loc1)->x_root);
							ti4_1 = (EIF_INTEGER_32) tr8_1;
							tr8_1 = (EIF_REAL_64) (((GdkEventScroll *)loc1)->y_root);
							ti4_2 = (EIF_INTEGER_32) tr8_1;
							(RTNA((loc33, (EIF_INTEGER_32) GDK_BUTTON_PRESS, ((EIF_INTEGER_32) 2L), (EIF_INTEGER_32) (ti4_1 + *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_11_)), (EIF_INTEGER_32) (ti4_2 + *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_12_)))));
						}
						RTHOOK(78);
						tp2 = eif_pointer_item(RTCV(F1539_15473(Current)),1);
						{
							/* INLINED CODE (ANY.default_pointer) */
							tp3 = (EIF_POINTER)  0;
							/* END INLINED CODE */
						}
						if ((EIF_BOOLEAN)(tp2 != tp3)) {
							RTHOOK(79);
							tr3 = *(EIF_REFERENCE *)(Current + _REFACS_48_);
							tp2 = eif_pointer_item(RTCW(tr3),1);
							loc9 = F1539_15485(Current, tp2);
							loc9 = RTRV(eif_new_type(1588, 0x00), loc9);
						} else {
							RTHOOK(80);
							loc9 = (EIF_REFERENCE) NULL;
						}
						RTHOOK(81);
						if ((EIF_BOOLEAN)(loc9 == NULL)) {
							RTHOOK(82);
							loc9 = F1539_15483(Current, loc3);
							loc9 = RTRV(eif_new_type(1588, 0x00), loc9);
						}
						RTHOOK(83);
						if ((EIF_BOOLEAN)(loc9 != NULL)) {
							RTHOOK(84);
							if ((EIF_BOOLEAN)((EIF_INTEGER_32) (((GdkEventScroll *)loc1)->direction) == (EIF_INTEGER_32) GDK_SCROLL_UP)) {
								RTHOOK(85);
								loc23 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
							} else {
								RTHOOK(86);
								loc23 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
							}
							RTHOOK(87);
							ti4_1 = (EIF_INTEGER_32) GDK_BUTTON_PRESS;
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64, EIF_INTEGER_32, EIF_INTEGER_32)) R13175[Dtype(RTCW(loc9))-1601])(loc9, ti4_1, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc23, (EIF_REAL_64) 0.5, (EIF_REAL_64) 0.5, (EIF_REAL_64) 0.5, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
						}
						RTHOOK(88);
						loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						RTHOOK(89);
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					}
					RTHOOK(90);
					loc28 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					break;
				case 20L:
				case 21L:
					break;
				case 16L:
					break;
				case 2L:
					break;
				case 30L:
					break;
				case 12L:
					RTHOOK(91);
					loc10 = F1539_15483(Current, loc3);
					loc10 = RTRV(eif_new_type(1615, 0x00), loc10);
					RTHOOK(92);
					if ((EIF_BOOLEAN)(loc10 != NULL)) {
						RTHOOK(93);
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						RTHOOK(94);
						gtk_main_do_event((GdkEvent*) loc1);
						RTHOOK(95);
						ti1_1 = (EIF_INTEGER_8) (((GdkEventFocus *)loc1)->in);
						tr3 = RTLNS(eif_new_type(1492, 0x00).id, 1492, _OBJSIZ_0_1_0_0_0_0_0_0_);
						*(EIF_INTEGER_8 *)tr3 = ti1_1;
						tb2 = F1491_14163(RTCW(tr3));
						F1616_16595(RTCW(loc10), tb2);
						RTHOOK(96);
						loc10 = (EIF_REFERENCE) NULL;
					}
					break;
				case 13L:
					RTHOOK(97);
					tr3 = F1539_15483(Current, loc3);
					loc34 = tr3;
					loc34 = RTRV(eif_new_type(1549, 0x00),loc34);
					if (EIF_TEST(loc34)) {
						RTHOOK(98);
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						RTHOOK(99);
						gtk_main_do_event((GdkEvent*) loc1);
						RTHOOK(100);
						ti4_1 = (EIF_INTEGER_32) (((GdkEventConfigure *)loc1)->x);
						ti4_2 = (EIF_INTEGER_32) (((GdkEventConfigure *)loc1)->y);
						ti4_3 = (EIF_INTEGER_32) (((GdkEventConfigure *)loc1)->width);
						ti4_4 = (EIF_INTEGER_32) (((GdkEventConfigure *)loc1)->height);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R12879[Dtype(loc34)-1550])(loc34, ti4_1, ti4_2, ti4_3, ti4_4);
						RTHOOK(101);
						loc12 = (EIF_REFERENCE) NULL;
					}
					break;
				case 14L:
					RTHOOK(102);
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					RTHOOK(103);
					gtk_main_do_event((GdkEvent*) loc1);
					RTHOOK(104);
					loc9 = F1539_15483(Current, loc3);
					loc9 = RTRV(eif_new_type(1588, 0x00), loc9);
					RTHOOK(105);
					if ((EIF_BOOLEAN)(loc9 != NULL)) {
						RTHOOK(106);
						(FUNCTION_CAST(void, (EIF_REFERENCE)) R13236[Dtype(RTCW(loc9))-1601])(loc9);
					}
					RTHOOK(107);
					loc9 = (EIF_REFERENCE) NULL;
					break;
				case 15L:
					RTHOOK(108);
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					RTHOOK(109);
					gtk_main_do_event((GdkEvent*) loc1);
					RTHOOK(110);
					loc11 = F1539_15483(Current, loc3);
					loc11 = RTRV(eif_new_type(1548, 0x00), loc11);
					RTHOOK(111);
					if ((EIF_BOOLEAN)(loc11 != NULL)) {
						RTHOOK(112);
						tr3 = *(EIF_REFERENCE *)(RTCW(loc11) + O12205[Dtype(loc11)-1513]);
						if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_41_) == tr3)) {
							RTHOOK(113);
							F1539_15381(Current, NULL);
						}
						RTHOOK(114);
						loc9 = loc11;
						loc9 = RTRV(eif_new_type(1588, 0x00), loc9);
						RTHOOK(115);
						if ((EIF_BOOLEAN)(loc9 != NULL)) {
							RTHOOK(116);
							F1589_16176(RTCW(loc9));
							RTHOOK(117);
							loc9 = (EIF_REFERENCE) NULL;
						}
						RTHOOK(118);
						loc11 = (EIF_REFERENCE) NULL;
					}
					break;
				case 17L:
					break;
				case 18L:
					break;
				case 19L:
					RTHOOK(119);
					tr3 = F1539_15383(Current);
					loc35 = tr3;
					if (EIF_TEST(loc35)) {
						RTHOOK(120);
						loc9 = *(EIF_REFERENCE *)(loc35 + O9889[Dtype(loc35)-1247]);
						loc9 = RTRV(eif_new_type(1588, 0x00), loc9);
					} else {
						RTHOOK(121);
						tr3 = RTLNS(eif_new_type(1280, 0x00).id, 1280, _OBJSIZ_2_0_0_0_0_0_0_0_);
						F1248_11522(RTCW(tr3));
						tr3 = F1281_11973(RTCW(tr3));
						loc36 = tr3;
						if (EIF_TEST(loc36)) {
							RTHOOK(122);
							loc9 = *(EIF_REFERENCE *)(loc36 + O9889[Dtype(loc36)-1247]);
							loc9 = RTRV(eif_new_type(1588, 0x00), loc9);
						}
					}
					RTHOOK(123);
					loc37 = loc9;
					loc37 = RTRV(eif_new_type(1654, 0x00),loc37);
					if (EIF_TEST(loc37)) {
						RTHOOK(124);
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						RTHOOK(125);
						gtk_main_do_event((GdkEvent*) loc1);
						RTHOOK(126);
						(RTNA((loc37)));
					}
					RTHOOK(127);
					loc9 = (EIF_REFERENCE) NULL;
					break;
				case 28L:
					break;
				case 29L:
					break;
				case 32L:
					RTHOOK(128);
					loc10 = F1539_15483(Current, loc3);
					loc10 = RTRV(eif_new_type(1615, 0x00), loc10);
					RTHOOK(129);
					if ((EIF_BOOLEAN)(loc10 != NULL)) {
						RTHOOK(130);
						ti4_1 = (EIF_INTEGER_32) (((GdkEventWindowState *)loc1)->changed_mask);
						ti4_2 = (EIF_INTEGER_32) (((GdkEventWindowState *)loc1)->new_window_state);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R13465[Dtype(RTCW(loc10))-1615])(loc10, ti4_1, ti4_2);
						RTHOOK(131);
						loc10 = (EIF_REFERENCE) NULL;
					}
					break;
				case 10L:
				case 11L:
					RTHOOK(132);
					loc13 = (EIF_POINTER) (((GdkEventAny *)loc1)->window);
					RTHOOK(133);
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					RTHOOK(134);
					tb2 = '\0';
					tb3 = !loc13;
					if ((EIF_BOOLEAN) !tb3) {
						tb2 = (EIF_BOOLEAN)((EIF_INTEGER_32) (((GdkEventCrossing *)loc1)->mode) == ((EIF_INTEGER_32) 0L));
					}
					if (tb2) {
						RTHOOK(135);
						gdk_window_get_user_data((GdkWindow*) loc13, (gpointer*) (EIF_POINTER *) &(loc14));
						RTHOOK(136);
						tb2 = !loc14;
						if ((EIF_BOOLEAN) !tb2) {
							RTHOOK(137);
							if ((EIF_BOOLEAN) !F1539_15467(Current)) {
								RTHOOK(138);
								tb2 = '\0';
								tr3 = F1539_15483(Current, loc14);
								loc38 = tr3;
								loc38 = RTRV(eif_new_type(1586, 0x00),loc38);
								if (EIF_TEST(loc38)) {
									tp2 = *(EIF_POINTER *)(loc38 + O12790[Dtype(loc38)-1547]);
									tb2 = (EIF_BOOLEAN)(tp2 == loc14);
								}
								if (tb2) {
									RTHOOK(139);
									loc10 = F1549_15636(loc38);
									RTHOOK(140);
									tb2 = '\01';
									if (!(EIF_BOOLEAN)(loc10 == NULL)) {
										tb3 = F1616_16583(RTCW(loc10));
										tb2 = (EIF_BOOLEAN) !tb3;
									}
									if (tb2) {
										RTHOOK(141);
										loc39 = loc38;
										loc39 = RTRV(eif_new_type(1588, 0x00),loc39);
										if (EIF_TEST(loc39)) {
											RTHOOK(142);
											ti1_1 = (EIF_INTEGER_8) (((GdkEventAny *)loc1)->type);
											F1589_16148(loc39, (EIF_BOOLEAN)(ti1_1 == ((EIF_INTEGER_8) 10L)));
										}
										RTHOOK(143);
										loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
									}
									RTHOOK(144);
									loc11 = (EIF_REFERENCE) NULL;
									RTHOOK(145);
									loc10 = (EIF_REFERENCE) NULL;
									RTHOOK(146);
									{
										/* INLINED CODE (ANY.default_pointer) */
										tp2 = (EIF_POINTER)  0;
										/* END INLINED CODE */
									}
									loc14 = tp2;
								} else {
									RTHOOK(147);
									gtk_main_do_event((GdkEvent*) loc1);
									RTHOOK(148);
									loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								}
							}
						}
					}
					RTHOOK(149);
					{
						/* INLINED CODE (ANY.default_pointer) */
						tp2 = (EIF_POINTER)  0;
						/* END INLINED CODE */
					}
					loc13 = tp2;
					break;
				case 8L:
				case 9L:
					RTHOOK(150);
					loc28 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					RTHOOK(151);
					loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					RTHOOK(152);
					tr3 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
					loc40 = tr3;
					if (EIF_TEST(loc40)) {
						RTHOOK(153);
						loc11 = (EIF_REFERENCE) loc40;
						RTHOOK(154);
						loc13 = (EIF_POINTER) (((GdkEventAny *)loc1)->window);
						RTHOOK(155);
						tp2 = *(EIF_POINTER *)(RTCW(loc11) + O12790[Dtype(loc11)-1547]);
						tp2 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp2);
						(((GdkEventAny *)loc1)->window = (GdkWindow*)(tp2));
					} else {
						RTHOOK(156);
						if (loc24) {
							RTHOOK(157);
							loc11 = F1539_15483(Current, loc4);
							loc11 = RTRV(eif_new_type(1548, 0x00), loc11);
						} else {
							RTHOOK(158);
							loc12 = F1539_15483(Current, loc4);
							loc12 = RTRV(eif_new_type(1549, 0x00), loc12);
							RTHOOK(159);
							loc11 = (EIF_REFERENCE) loc12;
						}
					}
					RTHOOK(160);
					if ((EIF_BOOLEAN)(loc11 != NULL)) {
						RTHOOK(161);
						loc12 = F1549_15635(RTCW(loc11));
						RTHOOK(162);
						if ((EIF_BOOLEAN)(loc12 != NULL)) {
							RTHOOK(163);
							loc10 = loc12;
							loc10 = RTRV(eif_new_type(1615, 0x00), loc10);
							RTHOOK(164);
							tb2 = '\01';
							if (!(EIF_BOOLEAN)(loc10 == NULL)) {
								tb3 = F1616_16583(RTCW(loc10));
								tb2 = (EIF_BOOLEAN) !tb3;
							}
							if (tb2) {
								RTHOOK(165);
								*(EIF_BOOLEAN *)(Current+ _CHROFF_49_9_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								RTHOOK(166);
								tr3 = *(EIF_REFERENCE *)(Current + _REFACS_48_);
								tu4_2 = (EIF_NATURAL_32) (((GdkEventKey *)loc1)->state);
								
								eif_put_natural_32_item(RTCW(tr3),4,tu4_2);
								RTHOOK(167);
								loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								RTHOOK(168);
								F1550_15672(RTCW(loc12), loc1);
								RTHOOK(169);
								*(EIF_BOOLEAN *)(Current+ _CHROFF_49_9_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							}
							RTHOOK(170);
							loc11 = (EIF_REFERENCE) NULL;
							RTHOOK(171);
							loc12 = (EIF_REFERENCE) NULL;
							RTHOOK(172);
							loc10 = (EIF_REFERENCE) NULL;
						}
					}
					RTHOOK(173);
					tb2 = !loc13;
					if ((EIF_BOOLEAN) !tb2) {
						RTHOOK(174);
						(((GdkEventAny *)loc1)->window = (GdkWindow*)(loc13));
						RTHOOK(175);
						{
							/* INLINED CODE (ANY.default_pointer) */
							tp2 = (EIF_POINTER)  0;
							/* END INLINED CODE */
						}
						loc13 = tp2;
					}
					break;
				case 0L:
					RTHOOK(176);
					loc28 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					RTHOOK(177);
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					RTHOOK(178);
					loc12 = F1539_15483(Current, loc3);
					loc12 = RTRV(eif_new_type(1549, 0x00), loc12);
					RTHOOK(179);
					if ((EIF_BOOLEAN)(loc12 != NULL)) {
						RTHOOK(180);
						(FUNCTION_CAST(void, (EIF_REFERENCE)) R12878[Dtype(RTCW(loc12))-1550])(loc12);
						RTHOOK(181);
						loc12 = (EIF_REFERENCE) NULL;
					}
					break;
				case 1L:
					break;
				case 22L:
					break;
				case 23L:
					break;
				case 24L:
					break;
				case 25L:
					break;
				case 26L:
					RTHOOK(182);
					F1539_15404(Current, loc1);
					break;
				case 27L:
					break;
				case -1L:
					break;
				case 33L:
					RTHOOK(183);
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					RTHOOK(184);
					loc25 = RTLNS(eif_new_type(1244, 0x00).id, 1244, _OBJSIZ_1_1_0_3_0_0_0_0_);
					tp2 = (EIF_POINTER) (((GdkEventSetting *)loc1)->name);
					F1243_11359(RTCW(loc25), tp2);
					RTHOOK(185);
					RTCOMS(tr3,15385,0,"gtk-theme-name",14,97340261);
					tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(loc25))-7])(loc25, tr3);
					if (tb2) {
						RTHOOK(186);
						loc26 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						RTHOOK(187);
						RTCOMS(tr3,15385,1,"gtk-font-name",13,1067777893);
						tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(loc25))-7])(loc25, tr3);
						if (tb2) {
							RTHOOK(188);
							loc26 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						}
					}
					RTHOOK(189);
					loc25 = (EIF_REFERENCE) NULL;
					RTHOOK(190);
					gtk_main_do_event((GdkEvent*) loc1);
					RTHOOK(191);
					tr3 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
					loc41 = tr3;
					if ((EIF_BOOLEAN) (loc26 && EIF_TEST(loc41))) {
						RTHOOK(192);
						F917_8946(loc41, NULL);
					}
					RTHOOK(193);
					loc26 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					break;
				case 34L:
					break;
				case 35L:
					break;
				case 36L:
					break;
				case 37L:
					break;
				case 38L:
					break;
				case 39L:
					break;
				case 40L:
					break;
				case 41L:
					break;
				case 42L:
					break;
				case 43L:
					break;
				case 44L:
					break;
				case 45L:
					break;
				case 46L:
					break;
				case 47L:
					break;
				case 48L:
					break;
				default:
					RTHOOK(194);
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					break;
			}
			RTHOOK(195);
			if (loc5) {
				RTHOOK(196);
				if (loc6) {
					RTHOOK(197);
					gtk_propagate_event((GtkWidget*) loc4, (GdkEvent*) loc1);
				} else {
					RTHOOK(198);
					tb2 = !loc3;
					if ((EIF_BOOLEAN) !tb2) {
						RTHOOK(199);
						loc7 = (EIF_BOOLEAN) EIF_TEST(gtk_widget_event((GtkWidget*) loc3, (GdkEvent*) loc1));
					} else {
						RTHOOK(200);
						gtk_main_do_event((GdkEvent*) loc1);
					}
				}
			}
			RTHOOK(201);
			gdk_event_free((GdkEvent*) loc1);
		} else {
			RTHOOK(202);
			if ((EIF_BOOLEAN) EIF_TEST(g_main_context_pending (NULL))) {
				RTHOOK(203);
				F1539_15387(Current);
			} else {
				RTHOOK(204);
				loc17 = (EIF_BOOLEAN) EIF_TEST(g_main_context_pending (NULL));
				loc17 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc17;
			}
		}
	}
	RTHOOK(205);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_49_1_) = (EIF_BOOLEAN) loc27;
	RTHOOK(206);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_49_2_) = (EIF_BOOLEAN) loc28;
	RTHOOK(207);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_IMP}.process_gtk_events */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F1539_15387 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_BOOLEAN EIF_VOLATILE loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	RTLD;
	RTXD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,saved_except);
	RTLIU(2);
	RTXSLS;
	
	RTEAA("process_gtk_events", 1538, Current, 1, 0, 21981);
	RTGC;
	RTE_T
	RTHOOK(1);
	if ((EIF_BOOLEAN) !loc1) {
		RTHOOK(2);
		g_main_context_dispatch(g_main_context_default());
	}
	RTE_E
	RTXSC;
	RTHOOK(3);
	loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(4);
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTHOOK(5);
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {EV_APPLICATION_IMP}.process_pending_events_on_default_context */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F1539_15388 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_BOOLEAN EIF_VOLATILE loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN EIF_VOLATILE loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	RTLD;
	RTXD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,saved_except);
	RTLIU(2);
	RTXSLS;
	
	RTEAA("process_pending_events_on_default_context", 1538, Current, 2, 0, 21982);
	RTGC;
	RTE_T
	RTHOOK(1);
	if ((EIF_BOOLEAN) !loc2) {
		for (;;) {
			RTHOOK(2);
			if ((EIF_BOOLEAN) EIF_TEST(g_main_context_pending (NULL))) break;
			RTHOOK(3);
			loc1 = (EIF_BOOLEAN) EIF_TEST(g_main_context_iteration(NULL, FALSE));
		}
	}
	RTE_E
	RTXSC;
	RTHOOK(4);
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(5);
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTHOOK(6);
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {EV_APPLICATION_IMP}.symbol_from_symbol_name */
EIF_POINTER F1539_15390 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("symbol_from_symbol_name", 1538, Current, 4, 1, 21984);
	RTGC;
	RTHOOK(1);
	loc1 = F1539_15391(Current);
	RTHOOK(2);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc1 != tp1)) {
		RTHOOK(3);
		loc2 = RTLNS(eif_new_type(1137, 0x00).id, 1137, _OBJSIZ_0_1_0_1_0_1_0_0_);
		F1138_9661(RTCW(loc2), arg1);
		RTHOOK(4);
		tp1 = *(EIF_POINTER *)(RTCW(loc2)+ _PTROFF_0_1_0_1_0_0_);
		loc3 = (EIF_BOOLEAN) EIF_TEST(g_module_symbol((GModule*) loc1, (gchar*) tp1, (gpointer*) (EIF_POINTER *) &(loc4)));
		RTHOOK(5);
		if (loc3) {
			RTHOOK(6);
			RTHOOK(7);
			RTLE;
			RTEE;
			return (EIF_POINTER) loc4;
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return (EIF_POINTER) 0;
}

/* {EV_APPLICATION_IMP}.main_module */
EIF_POINTER F1539_15391 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("main_module", 1538, Current, 0, 0, 21985);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) EIF_TEST(g_module_supported())) {
		RTHOOK(2);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		Result = (EIF_POINTER) g_module_open((gchar*) tp2, (GModuleFlags) ((EIF_INTEGER_32) 0L));
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_APPLICATION_IMP}.ctrl_pressed */
EIF_BOOLEAN F1539_15392 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("ctrl_pressed", 1538, Current, 0, 0, 21986);
	RTGC;
	RTHOOK(1);
	tu4_1 = F1539_15472(Current);
	tu4_2 = (EIF_NATURAL_32) GDK_CONTROL_MASK;
	tu4_1 = eif_bit_and(tu4_1,tu4_2);
	tu4_2 = (EIF_NATURAL_32) GDK_CONTROL_MASK;
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu4_1 == tu4_2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_APPLICATION_IMP}.alt_pressed */
EIF_BOOLEAN F1539_15393 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("alt_pressed", 1538, Current, 0, 0, 21987);
	RTGC;
	RTHOOK(1);
	tu4_1 = F1539_15472(Current);
	tu4_2 = (EIF_NATURAL_32) GDK_MOD1_MASK;
	tu4_1 = eif_bit_and(tu4_1,tu4_2);
	tu4_2 = (EIF_NATURAL_32) GDK_MOD1_MASK;
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu4_1 == tu4_2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_APPLICATION_IMP}.shift_pressed */
EIF_BOOLEAN F1539_15394 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("shift_pressed", 1538, Current, 0, 0, 21988);
	RTGC;
	RTHOOK(1);
	tu4_1 = F1539_15472(Current);
	tu4_2 = (EIF_NATURAL_32) GDK_SHIFT_MASK;
	tu4_1 = eif_bit_and(tu4_1,tu4_2);
	tu4_2 = (EIF_NATURAL_32) GDK_SHIFT_MASK;
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu4_1 == tu4_2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_APPLICATION_IMP}.windows */
EIF_REFERENCE F1539_15397 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,loc3);
	RTLR(1,loc4);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLR(4,loc1);
	RTLR(5,tr1);
	RTLR(6,loc2);
	RTLIU(7);
	
	RTEAA("windows", 1538, Current, 4, 0, 21991);
	RTGC;
	RTHOOK(1);
	loc3 = RTLNS(eif_new_type(1150, 0x00).id, 1150, _OBJSIZ_0_0_0_1_0_0_0_0_);
	RTHOOK(2);
	{
		static EIF_TYPE_INDEX typarr0[] = {882,1358,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc4 = RTLNS(typres0.id, 882, _OBJSIZ_2_3_0_1_0_0_0_0_);
	}
	F883_8665(RTCW(loc4));
	RTHOOK(3);
	Result = (EIF_REFERENCE) loc4;
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_43_);
	loc1 = F884_8671(RTCW(tr1));
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_43_);
	F884_8684(RTCW(tr1));
	for (;;) {
		RTHOOK(6);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_43_);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_2_2_);
		if (tb1) break;
		RTHOOK(7);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_43_);
		ti4_1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7670[Dtype(RTCW(tr1))-780])(tr1));
		loc2 = F1151_10490(RTCW(loc3), ti4_1);
		loc2 = RTRV(eif_new_type(1615, 0x00), loc2);
		RTHOOK(8);
		tb2 = '\01';
		if (!(EIF_BOOLEAN)(loc2 == NULL)) {
			tb3 = F1514_14805(RTCW(loc2));
			tb2 = tb3;
		}
		if (tb2) {
			RTHOOK(9);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_43_);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R7675[Dtype(RTCW(tr1))-780])(tr1);
		} else {
			RTHOOK(10);
			tr1 = F1514_14806(RTCW(loc2));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7657[Dtype(RTCW(loc4))-780])(loc4, tr1);
			RTHOOK(11);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_43_);
			F884_8686(RTCW(tr1));
		}
	}
	RTHOOK(12);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_43_);
	F884_8690(RTCW(tr1), loc1);
	RTHOOK(13);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_APPLICATION_IMP}.motion_tuple */
static EIF_REFERENCE F1539_15401_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(540)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("motion_tuple", 1538, Current, 0, 0, 21995);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,7,1186,1486,1486,1510,1510,1510,1486,1486,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNTS(typres0.id, 8, 1);
	}
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1539_15401 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(540,F1539_15401_body,(Current));
}

/* {EV_APPLICATION_IMP}.app_motion_tuple */
static EIF_REFERENCE F1539_15402_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(541)

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("app_motion_tuple", 1538, Current, 0, 0, 21996);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,1186,1346,1486,1486,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNTS(typres0.id, 4, 0);
	}
	tr2 = RTOUCR(543,F1539_15489, (Current));
	((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
	RTAR(tr1,tr2);
	((EIF_TYPED_VALUE *)tr1+2)->it_i4 = ((EIF_INTEGER_32) 0L);
	((EIF_TYPED_VALUE *)tr1+3)->it_i4 = ((EIF_INTEGER_32) 0L);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1539_15402 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(541,F1539_15402_body,(Current));
}

/* {EV_APPLICATION_IMP}.process_button_event */
void F1539_15403 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,loc10);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,loc4);
	RTLR(6,loc5);
	RTLR(7,loc7);
	RTLR(8,loc11);
	RTLIU(9);
	
	RTEAA("process_button_event", 1538, Current, 11, 2, 21997);
	RTGC;
	RTHOOK(1);
	tr8_1 = (EIF_REAL_64) (((GdkEventButton *)arg1)->x_root);
	loc8 = (EIF_INTEGER_32) tr8_1;
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_11_);
	loc8 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc8 + ti4_1);
	RTHOOK(2);
	tr8_1 = (EIF_REAL_64) (((GdkEventButton *)arg1)->y_root);
	loc9 = (EIF_INTEGER_32) tr8_1;
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_12_);
	loc9 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc9 + ti4_1);
	RTHOOK(3);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_49_8_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(4);
	loc3 = *(EIF_REFERENCE *)(Current + _REFACS_48_);
	RTHOOK(5);
	tp1 = (EIF_POINTER) (((GdkEventButton *)arg1)->window);
	
	eif_put_pointer_item(RTCW(loc3),1,tp1);
	RTHOOK(6);
	
	eif_put_integer_32_item(RTCW(loc3),2,loc8);
	RTHOOK(7);
	
	eif_put_integer_32_item(RTCW(loc3),3,loc9);
	RTHOOK(8);
	tu4_1 = (EIF_NATURAL_32) (((GdkEventButton *)arg1)->state);
	
	eif_put_natural_32_item(RTCW(loc3),4,tu4_1);
	RTHOOK(9);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
	loc10 = tr1;
	if (EIF_TEST(loc10)) {
		RTHOOK(10);
		loc1 = *(EIF_REFERENCE *)(loc10 + O9889[Dtype(loc10)-1247]);
		loc1 = RTRV(eif_new_type(1586, 0x00), loc1);
	} else {
		RTHOOK(11);
		if ((EIF_BOOLEAN)(F1539_15468(Current) != NULL)) {
			RTHOOK(12);
			loc1 = F1539_15468(Current);
		} else {
			RTHOOK(13);
			loc2 = eif_pointer_item(RTCW(loc3),1);
			RTHOOK(14);
			tb1 = !loc2;
			if ((EIF_BOOLEAN) !tb1) {
				RTHOOK(15);
				loc1 = F1539_15485(Current, loc2);
				loc1 = RTRV(eif_new_type(1586, 0x00), loc1);
			}
		}
	}
	RTHOOK(16);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTHOOK(17);
		loc4 = F1549_15636(RTCW(loc1));
		loc4 = RTRV(eif_new_type(1615, 0x00), loc4);
		RTHOOK(18);
		loc5 = loc4;
		loc5 = RTRV(eif_new_type(1616, 0x00), loc5);
		RTHOOK(19);
		if ((EIF_BOOLEAN)(loc5 != NULL)) {
			RTHOOK(20);
			loc7 = loc1;
			loc7 = RTRV(eif_new_type(1653, 0x00), loc7);
		}
		RTHOOK(21);
		loc6 = '\01';
		tb1 = '\01';
		tb2 = '\0';
		tb3 = '\0';
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc5 != NULL) && (EIF_BOOLEAN)(loc7 != NULL))) {
			tb3 = (EIF_BOOLEAN)((EIF_INTEGER_32) (((GdkEventButton *)arg1)->button) == ((EIF_INTEGER_32) 3L));
		}
		if (tb3) {
			tb3 = '\0';
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O13118[Dtype(loc1)-1585]);
			if ((EIF_BOOLEAN)(tr1 == NULL)) {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O13119[Dtype(loc1)-1585]);
				tb3 = (EIF_BOOLEAN)(tr1 == NULL);
			}
			tb2 = tb3;
		}
		if (!tb2) {
			tp2 = *(EIF_POINTER *)(RTCW(loc1) + O12790[Dtype(loc1)-1547]);
			tb1 = (EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(gtk_widget_is_sensitive((GtkWidget*) tp2));
		}
		if (!tb1) {
			tb1 = '\0';
			tb2 = '\0';
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				tb3 = F1616_16583(RTCW(loc4));
				tb2 = tb3;
			}
			if (tb2) {
				tb1 = (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_29_) == NULL);
			}
			loc6 = tb1;
		}
	}
	RTHOOK(22);
	if ((EIF_BOOLEAN)(loc5 == NULL)) {
		RTHOOK(23);
		loc5 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
	}
	RTHOOK(24);
	if ((EIF_BOOLEAN)(loc5 != NULL)) {
		RTHOOK(25);
		(RTNA((RTCW(loc5), (EIF_INTEGER_32) (((GdkEventButton *)arg1)->type), (EIF_INTEGER_32) (((GdkEventButton *)arg1)->button), loc8, loc9)));
	}
	RTHOOK(26);
	if ((EIF_BOOLEAN) !loc6) {
		RTHOOK(27);
		tb1 = '\0';
		tb2 = '\0';
		if ((EIF_BOOLEAN)(F1539_15468(Current) == NULL)) {
			tb2 = (EIF_BOOLEAN) !arg2;
		}
		if (tb2) {
			tb2 = '\01';
			if (!(EIF_BOOLEAN)(loc1 == NULL)) {
				tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13172[Dtype(RTCW(loc1))-1601])(loc1);
				tb2 = (EIF_BOOLEAN) !tb3;
			}
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(28);
			gtk_main_do_event((GdkEvent*) arg1);
		}
		RTHOOK(29);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTHOOK(30);
			tb1 = '\0';
			tb2 = '\0';
			if ((EIF_BOOLEAN) !arg2) {
				tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13172[Dtype(RTCW(loc1))-1601])(loc1);
				tb2 = tb3;
			}
			if (tb2) {
				loc11 = loc1;
				tb1 = EIF_TEST(loc11);
			}
			if (tb1) {
				RTHOOK(31);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_BOOLEAN)) R12811[Dtype(loc11)-1550])(loc11, arg1, arg2);
			} else {
				RTHOOK(32);
				ti4_1 = (EIF_INTEGER_32) (((GdkEventButton *)arg1)->type);
				tr8_1 = (EIF_REAL_64) (((GdkEventButton *)arg1)->x);
				ti4_2 = (EIF_INTEGER_32) tr8_1;
				tr8_1 = (EIF_REAL_64) (((GdkEventButton *)arg1)->y);
				ti4_3 = (EIF_INTEGER_32) tr8_1;
				ti4_4 = (EIF_INTEGER_32) (((GdkEventButton *)arg1)->button);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64, EIF_INTEGER_32, EIF_INTEGER_32)) R13185[Dtype(RTCW(loc1))-1601])(loc1, ti4_1, ti4_2, ti4_3, ti4_4, (EIF_REAL_64) 0.5, (EIF_REAL_64) 0.5, (EIF_REAL_64) 0.5, loc8, loc9);
			}
		}
	}
	RTHOOK(33);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_49_8_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(34);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_IMP}.handle_dnd */
void F1539_15404 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_POINTER loc5 = (EIF_POINTER) 0;
	EIF_POINTER loc6 = (EIF_POINTER) 0;
	EIF_POINTER loc7 = (EIF_POINTER) 0;
	EIF_NATURAL_32 loc8 = (EIF_NATURAL_32) 0;
	EIF_POINTER loc9 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc12 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc15 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc17);
	RTLR(1,loc18);
	RTLR(2,loc13);
	RTLR(3,tr1);
	RTLR(4,loc14);
	RTLR(5,tr2);
	RTLR(6,loc16);
	RTLR(7,Current);
	RTLR(8,tr3);
	RTLIU(9);
	
	RTEAA("handle_dnd", 1538, Current, 18, 1, 21998);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_POINTER) (((GdkEventDND *)arg1)->context);
	RTHOOK(2);
	loc4 = (EIF_POINTER) gdk_drag_context_get_source_window((GdkDragContext*) loc1);
	RTHOOK(3);
	loc6 = (EIF_POINTER) gdk_drag_get_selection((GdkDragContext*) loc1);
	RTHOOK(4);
	loc8 = (EIF_NATURAL_32) (((GdkEventDND *)arg1)->time);
	RTHOOK(5);
	loc2 = (EIF_POINTER) gdk_drag_context_list_targets((GdkDragContext*) loc1);
	RTHOOK(6);
	loc17 = RTMS_EX_H("STRING",6,1544365639);
	RTHOOK(7);
	loc18 = RTMS_EX_H("file://",7,1704345391);
	for (;;) {
		RTHOOK(8);
		tb1 = !loc2;
		if (tb1) break;
		RTHOOK(9);
		loc3 = (EIF_POINTER) (((GList *)loc2)->data);
		RTHOOK(10);
		tb2 = !loc3;
		if ((EIF_BOOLEAN) !tb2) {
			RTHOOK(11);
			gdk_selection_convert((GdkWindow*) loc4, (GdkAtom) loc6, (GdkAtom) loc3, (guint32) loc8);
			RTHOOK(12);
			loc12 = (EIF_INTEGER_32) gdk_selection_property_get((GdkWindow*) loc4, (guchar**) (EIF_POINTER *) &(loc9), (GdkAtom*) (EIF_INTEGER_32 *) &(loc10), (gint*) (EIF_INTEGER_32 *) &(loc11));
			RTHOOK(13);
			tb2 = !loc9;
			if ((EIF_BOOLEAN) !tb2) {
				RTHOOK(14);
				loc13 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
				tp1 = (EIF_POINTER) gdk_atom_name((GdkAtom) loc3);
				F1240_11193(RTCW(loc13), tp1);
				RTHOOK(15);
				tr1 = F1237_11118(RTCW(loc17));
				tb2 = F1240_11213(RTCW(loc13), tr1);
				if (tb2) {
					RTHOOK(16);
					loc13 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F1240_11193(RTCW(loc13), loc9);
					RTHOOK(17);
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
					loc14 = F1237_11137(RTCW(loc13), tw1);
					RTHOOK(18);
					(FUNCTION_CAST(void, (EIF_REFERENCE)) R7637[Dtype(RTCW(loc14))-882])(loc14);
					for (;;) {
						RTHOOK(19);
						tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7648[Dtype(RTCW(loc14))-882])(loc14);
						if (tb2) break;
						RTHOOK(20);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7670[Dtype(RTCW(loc14))-780])(loc14);
						ti4_1 = F1240_11206(RTCW(tr1), loc18, ((EIF_INTEGER_32) 1L));
						if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
							RTHOOK(21);
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7670[Dtype(RTCW(loc14))-780])(loc14);
							tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7670[Dtype(RTCW(loc14))-780])(loc14);
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_1_1_0_2_);
							tr1 = F1242_11351(RTCW(tr1), ((EIF_INTEGER_32) 8L), ti4_1);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7674[Dtype(RTCW(loc14))-882])(loc14, tr1);
							RTHOOK(22);
							loc15 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							RTHOOK(23);
							(FUNCTION_CAST(void, (EIF_REFERENCE)) R7650[Dtype(RTCW(loc14))-882])(loc14);
						} else {
							RTHOOK(24);
							(FUNCTION_CAST(void, (EIF_REFERENCE)) R7675[Dtype(RTCW(loc14))-780])(loc14);
						}
					}
				}
			}
		}
		RTHOOK(25);
		tp1 = (EIF_POINTER) (((GList *)loc2)->next);
		loc2 = (EIF_POINTER) tp1;
	}
	RTHOOK(26);
	if ((EIF_BOOLEAN) (loc15 && (EIF_BOOLEAN)(loc14 != NULL))) {
		RTHOOK(27);
		loc5 = (EIF_POINTER) gdk_drag_context_get_dest_window((GdkDragContext*) loc1);
		RTHOOK(28);
		tb3 = !loc5;
		if ((EIF_BOOLEAN) !tb3) {
			RTHOOK(29);
			gdk_window_get_user_data((GdkWindow*) loc5, (gpointer*) (EIF_POINTER *) &(loc7));
			RTHOOK(30);
			tb3 = !loc7;
			if ((EIF_BOOLEAN) !tb3) {
				RTHOOK(31);
				loc16 = F1539_15483(Current, loc7);
				loc16 = RTRV(eif_new_type(1588, 0x00), loc16);
				RTHOOK(32);
				tb3 = '\0';
				if ((EIF_BOOLEAN)(loc16 != NULL)) {
					tb4 = F1514_14805(RTCW(loc16));
					tb3 = (EIF_BOOLEAN) !tb4;
				}
				if (tb3) {
					RTHOOK(33);
					tr1 = *(EIF_REFERENCE *)(RTCW(loc16) + O4768[Dtype(loc16)-292]);
					if ((EIF_BOOLEAN)(tr1 != NULL)) {
						RTHOOK(34);
						tr1 = F293_4871(RTCW(loc16));
						{
							static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,858,1241,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr2 = RTLNTS(typres0.id, 2, 0);
						}
						((EIF_TYPED_VALUE *)tr2+1)->it_r = loc14;
						RTAR(tr2,loc14);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7959[Dtype(RTCW(tr1))-915])(tr1, tr2);
					}
					RTHOOK(35);
					if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_7_) != NULL)) {
						RTHOOK(36);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
						{
							static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1186,1346,858,1241,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr2 = RTLNTS(typres0.id, 3, 0);
						}
						tr3 = F1514_14806(RTCW(loc16));
						((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
						RTAR(tr2,tr3);
						((EIF_TYPED_VALUE *)tr2+2)->it_r = loc14;
						RTAR(tr2,loc14);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7959[Dtype(RTCW(tr1))-915])(tr1, tr2);
					}
				}
			}
		}
	}
	RTHOOK(37);
	gdk_drop_finish((GdkDragContext*) loc1, (gboolean) loc15, (guint32) loc8);
	RTHOOK(38);
	gtk_drag_finish((GdkDragContext*) loc1, (gboolean) loc15, (gboolean) (EIF_BOOLEAN) 0, (guint32) loc8);
	RTHOOK(39);
	g_free((gpointer) loc9);
	RTHOOK(40);
	g_free((gpointer) loc2);
	RTHOOK(41);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_IMP}.sleep */
void F1539_15456 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_64 ti8_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("sleep", 1538, Current, 0, 1, 21904);
	RTGC;
	RTHOOK(1);
	ti8_1 = (EIF_INTEGER_64) arg1;
	F517_7513(Current, (EIF_INTEGER_64) (((EIF_INTEGER_64) RTI64C(1000000)) * ti8_1));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_IMP}.destroy */
void F1539_15457 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("destroy", 1538, Current, 0, 0, 21905);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !F1514_14805(Current)) {
		RTHOOK(2);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current+ _PTROFF_49_16_0_20_0_2_) != tp1)) {
			RTHOOK(3);
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_16_0_20_0_2_);
			inline_F175_2410(tp1);
		}
		RTHOOK(4);
		F1514_14821(Current, (EIF_BOOLEAN) 1);
		RTHOOK(5);
		tr1 = F210_3735(Current);
		F917_8946(RTCW(tr1), NULL);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_IMP}.tooltip_delay */
EIF_INTEGER_32 F1539_15458 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_19_);
}


/* {EV_APPLICATION_IMP}.set_tooltip_delay */
void F1539_15459 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_tooltip_delay", 1538, Current, 0, 1, 21907);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_19_) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EV_APPLICATION_IMP}.set_docking_source */
void F1539_15460 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_docking_source", 1538, Current, 0, 1, 21908);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_46_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EV_APPLICATION_IMP}.on_pick */
void F1539_15461 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTEAA("on_pick", 1538, Current, 0, 2, 21909);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_45_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	tr1 = F1183_10697(RTCV(F1514_14806(Current)));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,0,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = arg2;
	RTAR(tr2,arg2);
	F918_8947(RTCW(tr1), tr2);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_IMP}.on_drop */
void F1539_15462 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("on_drop", 1538, Current, 0, 1, 21910);
	RTHOOK(1);
	*(EIF_REFERENCE *)(Current + _REFACS_45_) = (EIF_REFERENCE) NULL;
	RTHOOK(2);
	RTEE;
}

/* {EV_APPLICATION_IMP}.pnd_source_hint */
static EIF_REFERENCE F1539_15463_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(544)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("pnd_source_hint", 1538, Current, 0, 0, 21911);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1251, 0x00).id, 1251, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1248_11522(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1539_15463 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(544,F1539_15463_body,(Current));
}

/* {EV_APPLICATION_IMP}.activate_docking_source_hint */
void F1539_15464 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg3);
	RTLIU(3);
	
	RTEAA("activate_docking_source_hint", 1538, Current, 0, 3, 21912);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !RTOUCB(EIF_BOOLEAN,539,F1539_15367, (Current))) {
		RTHOOK(2);
		tr1 = RTOUCR(544,F1539_15463, (Current));
		F1252_11594(RTCW(tr1), arg1, arg2, ((EIF_INTEGER_32) 50L), ((EIF_INTEGER_32) 50L), arg3);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_IMP}.deactivate_docking_source_hint */
void F1539_15465 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("deactivate_docking_source_hint", 1538, Current, 0, 0, 21913);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if ((EIF_BOOLEAN) !RTOUCB(EIF_BOOLEAN,539,F1539_15367, (Current))) {
		tb2 = F1252_11593(RTCV(RTOUCR(544,F1539_15463, (Current))));
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(2);
		F1252_11595(RTCV(RTOUCR(544,F1539_15463, (Current))));
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_IMP}.is_in_transport */
EIF_BOOLEAN F1539_15467 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_in_transport", 1538, Current, 0, 0, 21915);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	if (!(EIF_BOOLEAN)(F1539_15468(Current) != NULL)) {
		Result = (EIF_BOOLEAN)(F1539_15469(Current) != NULL);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_APPLICATION_IMP}.pick_and_drop_source */
EIF_REFERENCE F1539_15468 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("pick_and_drop_source", 1538, Current, 0, 0, 21916);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_45_);
}

/* {EV_APPLICATION_IMP}.docking_source */
EIF_REFERENCE F1539_15469 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("docking_source", 1538, Current, 0, 0, 21917);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_46_);
}

/* {EV_APPLICATION_IMP}.keyboard_modifier_mask */
EIF_NATURAL_32 F1539_15472 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLIU(2);
	
	RTEAA("keyboard_modifier_mask", 1538, Current, 1, 0, 21920);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_49_9_)) {
		RTHOOK(2);
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_48_);
	} else {
		RTHOOK(3);
		loc1 = F1539_15473(Current);
	}
	RTHOOK(4);
	tu4_1 = eif_natural_32_item(RTCW(loc1),4);
	RTHOOK(5);
	RTLE;
	RTEE;
	return (EIF_NATURAL_32) tu4_1;
}

/* {EV_APPLICATION_IMP}.retrieve_display_data */
EIF_REFERENCE F1539_15473 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("retrieve_display_data", 1538, Current, 0, 0, 21921);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_49_8_)) {
		RTHOOK(2);
		F1539_15474(Current);
	}
	RTHOOK(3);
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_48_);
}

/* {EV_APPLICATION_IMP}.update_display_data */
void F1539_15474 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_NATURAL_32 loc2 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_POINTER loc6 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("update_display_data", 1538, Current, 6, 0, 21922);
	RTGC;
	RTHOOK(1);
	loc5 = *(EIF_REFERENCE *)(Current + _REFACS_48_);
	RTHOOK(2);
	loc6 = inline_F48_848();
	RTHOOK(3);
	inline_F48_845(loc6, (EIF_INTEGER_32 *) &(loc3), (EIF_INTEGER_32 *) &(loc4));
	RTHOOK(4);
	loc1 = (EIF_POINTER) gdk_device_get_window_at_position((GdkDevice*) loc6, (gint*) (EIF_INTEGER_32 *) &(loc3), (gint*) (EIF_INTEGER_32 *) &(loc4));
	RTHOOK(5);
	tb1 = !loc1;
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(6);
		tp1 = (EIF_POINTER) gdk_window_get_device_position((GdkWindow*) loc1, (GdkDevice *) loc6, (gint*) (EIF_INTEGER_32 *) &(loc3), (gint*) (EIF_INTEGER_32 *) &(loc4), (GdkModifierType*) (EIF_NATURAL_32 *) &(loc2));
		loc1 = (EIF_POINTER) tp1;
		RTHOOK(7);
		inline_F48_845(loc6, (EIF_INTEGER_32 *) &(loc3), (EIF_INTEGER_32 *) &(loc4));
		RTHOOK(8);
		
		eif_put_pointer_item(RTCW(loc5),1,loc1);
		RTHOOK(9);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_11_);
		
		eif_put_integer_32_item(RTCW(loc5),2,(EIF_INTEGER_32) (loc3 + ti4_1));
		RTHOOK(10);
		ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_12_);
		
		eif_put_integer_32_item(RTCW(loc5),3,(EIF_INTEGER_32) (loc4 + ti4_2));
		RTHOOK(11);
		
		eif_put_natural_32_item(RTCW(loc5),4,loc2);
	}
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_IMP}.enable_debugger */
void F1539_15479 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("enable_debugger", 1538, Current, 0, 0, 21927);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_49_10_)) {
		RTHOOK(2);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_49_10_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		RTHOOK(3);
		tb1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_49_12_);
		inline_F275_4638(tb1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_IMP}.disable_debugger */
void F1539_15480 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("disable_debugger", 1538, Current, 0, 0, 21928);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_49_10_)) {
		RTHOOK(2);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_49_10_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(3);
		tb1 = EIF_TEST (inline_F275_4639());
		*(EIF_BOOLEAN *)(Current+ _CHROFF_49_12_) = (EIF_BOOLEAN) tb1;
		RTHOOK(4);
		F275_4637(Current);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_IMP}.eif_object_from_gtk_object */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
EIF_REFERENCE F1539_15483 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTED;
	EIF_POINTER EIF_VOLATILE loc1 = (EIF_POINTER) 0;
	EIF_BOOLEAN EIF_VOLATILE loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_POINTER  EIF_VOLATILE tp1;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_BOOLEAN  EIF_VOLATILE tb2;
	EIF_BOOLEAN  EIF_VOLATILE tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	RTXD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,saved_except);
	RTLIU(3);
	RTXSLS;
	
	RTEAA("eif_object_from_gtk_object", 1538, Current, 2, 1, 21931);
	RTGC;
	RTE_T
	RTHOOK(1);
	if ((EIF_BOOLEAN) !loc2) {
		RTHOOK(2);
		loc1 = (EIF_POINTER) arg1;
		for (;;) {
			RTHOOK(3);
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(Result != NULL)) {
				tb2 = !loc1;
				tb1 = tb2;
			}
			if (tb1) break;
			RTHOOK(4);
			Result = inline_F1548_15579(loc1);
			RTHOOK(5);
			tp1 = (EIF_POINTER) gtk_widget_get_parent((GtkWidget*) loc1);
			loc1 = (EIF_POINTER) tp1;
		}
		RTHOOK(6);
		tb2 = '\0';
		if ((EIF_BOOLEAN)(Result != NULL)) {
			tb3 = F1514_14805(RTCW(Result));
			tb2 = tb3;
		}
		if (tb2) {
			RTHOOK(7);
			Result = (EIF_REFERENCE) NULL;
		}
	} else {
		
	}
	RTE_E
	RTXSC;
	RTHOOK(9);
	Result = (EIF_REFERENCE) NULL;
	RTHOOK(10);
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(11);
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTHOOK(12);
	RTEOK;
	RTLE;
	return Result;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {EV_APPLICATION_IMP}.gtk_widget_imp_at_pointer_position */
EIF_REFERENCE F1539_15484 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_widget_imp_at_pointer_position", 1538, Current, 3, 0, 21932);
	RTGC;
	RTHOOK(1);
	tp1 = inline_F48_848();
	loc3 = (EIF_POINTER) gdk_device_get_window_at_position((GdkDevice*) tp1, (gint*) (EIF_INTEGER_32 *) &(loc1), (gint*) (EIF_INTEGER_32 *) &(loc2));
	RTHOOK(2);
	tb1 = !loc3;
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(3);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) F1539_15485(Current, loc3);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {EV_APPLICATION_IMP}.gtk_widget_from_gdk_window */
EIF_REFERENCE F1539_15485 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("gtk_widget_from_gdk_window", 1538, Current, 1, 1, 21933);
	RTGC;
	RTHOOK(1);
	gdk_window_get_user_data((GdkWindow*) arg1, (gpointer*) (EIF_POINTER *) &(loc1));
	RTHOOK(2);
	tb1 = !loc1;
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(3);
		Result = F1539_15483(Current, loc1);
		RTHOOK(4);
		RTLE;
		RTEE;
		return RTRV(eif_new_type(1548, 0x00), Result);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_APPLICATION_IMP}.default_gtk_window */
static EIF_POINTER F1539_15487_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
#define Result RTOTRB(EIF_POINTER)
	RTOUDB(EIF_POINTER, 545)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("default_gtk_window", 1538, Current, 0, 0, 21935);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTOUCR(546,F1539_15491, (Current));
	Result = *(EIF_POINTER *)(RTCW(tr1) + O12790[Dtype(tr1)-1547]);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_43_);
	ti4_1 = F1151_10489(RTCV(RTOUCR(546,F1539_15491, (Current))));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7660[Dtype(RTCW(tr1))-805])(tr1, (EIF_REFERENCE) &ti4_1);
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_POINTER F1539_15487 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_POINTER,545,F1539_15487_body,(Current));
}

/* {EV_APPLICATION_IMP}.default_gdk_window */
EIF_POINTER F1539_15488 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_gdk_window", 1538, Current, 0, 0, 21936);
	RTGC;
	RTHOOK(1);
	tp1 = RTOUCB(EIF_POINTER,545,F1539_15487, (Current));
	Result = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_APPLICATION_IMP}.default_widget */
static EIF_REFERENCE F1539_15489_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(543)

	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("default_widget", 1538, Current, 1, 0, 21937);
	RTGC;
	RTOTP;
	RTHOOK(1);
	RTCT0("attached {EV_WIDGET} default_window as l_widget", EX_CHECK);
	tr1 = RTOUCR(542,F1539_15490, (Current));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(2);
	Result = (EIF_REFERENCE) loc1;
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1539_15489 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(543,F1539_15489_body,(Current));
}

/* {EV_APPLICATION_IMP}.default_window */
static EIF_REFERENCE F1539_15490_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(542)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("default_window", 1538, Current, 0, 0, 21938);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1358, 0x00).id, 1358, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1248_11522(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1539_15490 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(542,F1539_15490_body,(Current));
}

/* {EV_APPLICATION_IMP}.default_window_imp */
static EIF_REFERENCE F1539_15491_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(546)

	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("default_window_imp", 1538, Current, 1, 0, 21939);
	RTGC;
	RTOTP;
	RTHOOK(1);
	RTCT0("attached {EV_WINDOW_IMP} default_window.implementation as win", EX_CHECK);
	tr1 = RTOUCR(542,F1539_15490, (Current));
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O9889[Dtype(tr1)-1247]);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1615, 0x00),loc1);
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(2);
	Result = (EIF_REFERENCE) loc1;
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1539_15491 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(546,F1539_15491_body,(Current));
}

/* {EV_APPLICATION_IMP}.reusable_rectangle_struct */
static EIF_POINTER F1539_15492_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRB(EIF_POINTER)
	RTOUDB(EIF_POINTER, 538)

	
	RTEAA("reusable_rectangle_struct", 1538, Current, 0, 0, 21940);
	RTOTP;
	RTHOOK(1);
	Result = (EIF_POINTER) calloc (sizeof(GdkRectangle), 1);
	RTOTE;
	RTHOOK(2);
	RTEE;
	return Result;
#undef Result
}

EIF_POINTER F1539_15492 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_POINTER,538,F1539_15492_body,(Current));
}

/* {EV_APPLICATION_IMP}.c_string_from_eiffel_string */
EIF_REFERENCE F1539_15493 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("c_string_from_eiffel_string", 1538, Current, 0, 1, 21941);
	RTGC;
	RTHOOK(1);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9640[Dtype(RTCW(arg1))-1240])(arg1);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1000L))) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(1137, 0x00).id, 1137, _OBJSIZ_0_1_0_1_0_1_0_0_);
		F1138_9661(RTCW(tr1), arg1);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(4);
		Result = RTOUCR(536,F1539_15494, (Current));
		RTHOOK(5);
		F1138_9661(RTCW(Result), arg1);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_APPLICATION_IMP}.reusable_gtk_c_string */
static EIF_REFERENCE F1539_15494_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(536)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("reusable_gtk_c_string", 1538, Current, 0, 0, 21942);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1137, 0x00).id, 1137, _OBJSIZ_0_1_0_1_0_1_0_0_);
	tr2 = RTMS_EX_H("",0,0);
	F1138_9661(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1539_15494 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(536,F1539_15494_body,(Current));
}

/* {EV_APPLICATION_IMP}.initialize_threading */
void F1539_15496 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("initialize_threading", 1538, Current, 0, 0, 21944);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_thread_capable__b) {
		RTHOOK(2);
		tr1 = RTLNSMART(eif_new_type(1138, 0).id);
		F1139_9669(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_33_) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_IMP}.enable_ev_gtk_log */
void F1539_15499 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("enable_ev_gtk_log", 1538, Current, 0, 1, 21947);enable_ev_gtk_log((EIF_INTEGER) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {EV_APPLICATION_IMP}.gtk_init_check */
EIF_BOOLEAN F1539_15501 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_init_check", 1538, Current, 0, 0, 21949);
	Result = (EIF_BOOLEAN) EIF_TEST(gtk_init_check (&eif_argc, &eif_argv));
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_APPLICATION_IMP}.c_get_screen_geometry */
void F1539_15502 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("c_get_screen_geometry", 1538, Current, 0, 1, 21950);
	inline_F1539_15502 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
}

void EIF_Minit829 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
