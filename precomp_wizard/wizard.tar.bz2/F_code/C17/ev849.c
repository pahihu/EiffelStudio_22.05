/*
 * Code for class EV_SENSITIVE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev849.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_SENSITIVE_IMP}.is_sensitive */
EIF_BOOLEAN F1563_15863 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_sensitive", 1562, Current, 0, 0, 22308);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !F1514_14805(Current)) {
		RTHOOK(2);
		tp1 = *(EIF_POINTER *)(Current + O12790[Dtype(Current)-1547]);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) EIF_TEST(gtk_widget_is_sensitive((GtkWidget*) tp1));
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) 0;
}

/* {EV_SENSITIVE_IMP}.enable_sensitive */
void F1563_15864 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("enable_sensitive", 1562, Current, 0, 0, 22309);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O12790[dtype-1547]);
	gtk_widget_set_sensitive((GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 1);
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current + O12790[dtype-1547]);
	if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_EVENT_BOX((tp1)))) {
		RTHOOK(3);
		tp1 = *(EIF_POINTER *)(Current + O12790[dtype-1547]);
		gtk_event_box_set_visible_window((GtkEventBox*) tp1, (gboolean) (EIF_BOOLEAN) 1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_SENSITIVE_IMP}.disable_sensitive */
void F1563_15865 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("disable_sensitive", 1562, Current, 0, 0, 22310);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O12790[dtype-1547]);
	gtk_widget_set_sensitive((GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 0);
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current + O12790[dtype-1547]);
	if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_EVENT_BOX((tp1)))) {
		RTHOOK(3);
		tp1 = *(EIF_POINTER *)(Current + O12790[dtype-1547]);
		gtk_event_box_set_visible_window((GtkEventBox*) tp1, (gboolean) (EIF_BOOLEAN) 0);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_SENSITIVE_IMP}.has_parent */
EIF_BOOLEAN F1563_15867 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("has_parent", 1562, Current, 0, 0, 22311);
	RTGC;
	RTHOOK(1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13028[Dtype(Current)-1601])(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 != NULL);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_SENSITIVE_IMP}.parent_is_sensitive */
EIF_BOOLEAN F1563_15869 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("parent_is_sensitive", 1562, Current, 1, 0, 22312);
	RTGC;
	RTHOOK(1);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13028[Dtype(Current)-1601])(Current);
	loc1 = RTRV(eif_new_type(1345, 0x00), loc1);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTHOOK(3);
		tb1 = F1346_12784(RTCW(loc1));
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) tb1;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) 0;
}

void EIF_Minit849 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
