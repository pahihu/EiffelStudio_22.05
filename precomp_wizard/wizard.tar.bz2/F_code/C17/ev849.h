
#ifndef _C17_ev849_
#define _C17_ev849_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1563_15863(EIF_REFERENCE);
extern void F1563_15864(EIF_REFERENCE);
extern void F1563_15865(EIF_REFERENCE);
extern EIF_BOOLEAN F1563_15867(EIF_REFERENCE);
extern EIF_BOOLEAN F1563_15869(EIF_REFERENCE);
extern void EIF_Minit849(void);
extern EIF_BOOLEAN F1346_12784(EIF_REFERENCE);
extern EIF_BOOLEAN F1514_14805(EIF_REFERENCE);
extern char *(*R13028[])();
extern long O12790[];

#ifdef __cplusplus
}
#endif

#endif
