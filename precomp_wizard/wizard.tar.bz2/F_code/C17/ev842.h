
#ifndef _C17_ev842_
#define _C17_ev842_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1556_15750(EIF_REFERENCE);
extern EIF_REFERENCE F1556_15751(EIF_REFERENCE);
extern void EIF_Minit842(void);
extern char *(*R12933[])();
extern char *(*R12934[])();

#ifdef __cplusplus
}
#endif

#endif
