
#ifndef _C17_ev809_
#define _C17_ev809_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1519_14922(EIF_REFERENCE);
extern void EIF_Minit809(void);
extern EIF_REFERENCE F1514_14806(EIF_REFERENCE);
extern void F917_8946(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1514_14805(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
