/*
 * Code for class EV_ACCELERATOR_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev824.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_ACCELERATOR_I}.enable_parented */
void F1534_15194 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("enable_parented", 1533, Current, 0, 0, 21726);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	RTEE;
}

/* {EV_ACCELERATOR_I}.disable_parented */
void F1534_15195 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("disable_parented", 1533, Current, 0, 0, 21727);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(2);
	RTEE;
}

/* {EV_ACCELERATOR_I}.actions */
EIF_REFERENCE F1534_15200 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("actions", 1533, Current, 0, 0, 21728);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) == NULL)) {
		RTHOOK(2);
		tr1 = RTLNSMART(eif_new_type(936, 0).id);
		F916_8909(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(3);
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_1_);
}

/* {EV_ACCELERATOR_I}.hash_code */
EIF_INTEGER_32 F1534_15208 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("hash_code", 1533, Current, 0, 0, 21729);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_0_0_0_0_);
	Result = F1534_15209(Current, ti4_1, *(EIF_BOOLEAN *)(Current+ _CHROFF_3_1_), *(EIF_BOOLEAN *)(Current+ _CHROFF_3_2_), *(EIF_BOOLEAN *)(Current+ _CHROFF_3_3_));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_ACCELERATOR_I}.hash_code_function */
EIF_INTEGER_32 F1534_15209 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN arg3, EIF_BOOLEAN arg4)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("hash_code_function", 1533, Current, 0, 4, 21730);
	RTGC;
	RTHOOK(1);
	Result = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	if (arg2) {
		RTHOOK(3);
		Result += ((EIF_INTEGER_32) 2048L);
	}
	RTHOOK(4);
	if (arg3) {
		RTHOOK(5);
		Result += ((EIF_INTEGER_32) 1024L);
	}
	RTHOOK(6);
	if (arg4) {
		RTHOOK(7);
		RTHOOK(8);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 512L));
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit824 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
