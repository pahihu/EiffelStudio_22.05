/*
 * Code for class LOCALIZED_PRINTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "lo1025.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LOCALIZED_PRINTER}.localized_print_error */
void F1747_18982 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("localized_print_error", 1746, Current, 1, 1, 25109);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		loc1 = arg1;
		loc1 = RTRV(eif_new_type(1242, 0x00),loc1);
		if (EIF_TEST(loc1)) {
			RTHOOK(3);
			tr1 = RTOUCR(37,F100_1653, (RTCV(RTOUCR(6,F1_24, (Current)))));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8713[Dtype(RTCW(tr1))-1144])(tr1, loc1);
		} else {
			RTHOOK(4);
			tr1 = RTOUCR(37,F100_1653, (RTCV(RTOUCR(6,F1_24, (Current)))));
			tr2 = F1237_11119(RTCW(arg1));
			F1148_10346(RTCW(tr1), tr2);
		}
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

void EIF_Minit1025 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
