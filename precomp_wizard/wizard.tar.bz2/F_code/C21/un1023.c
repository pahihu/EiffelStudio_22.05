/*
 * Code for class UNICODE_CONVERSION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "un1023.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UNICODE_CONVERSION}.is_code_page_valid */
EIF_BOOLEAN F1745_18928 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("is_code_page_valid", 1744, Current, 0, 1, 25055);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R9618[Dtype(RTCW(arg1))-1240])(arg1);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(2);
		tr1 = RTOUCR(266,F1745_18940, (Current));
		Result = F806_8444(RTCW(tr1), arg1);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {UNICODE_CONVERSION}.is_code_page_convertible */
EIF_BOOLEAN F1745_18929 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("is_code_page_convertible", 1744, Current, 0, 2, 25056);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	if ((EIF_BOOLEAN)(arg1 == RTOUCR(267,F71_1255, (Current)))) {
		Result = (EIF_BOOLEAN)(arg2 == RTOUCR(268,F71_1257, (Current)));
	}
	RTHOOK(2);
	if ((EIF_BOOLEAN) !Result) {
		RTHOOK(3);
		tr1 = RTOUCR(267,F71_1255, (Current));
		tb1 = F1243_11382(RTCW(arg1), tr1);
		if (tb1) {
			RTHOOK(4);
			Result = '\01';
			tr1 = RTOUCR(267,F71_1255, (Current));
			tb1 = F1243_11382(RTCW(arg2), tr1);
			if (!tb1) {
				tr1 = RTOUCR(268,F71_1257, (Current));
				tb1 = F1243_11382(RTCW(arg2), tr1);
				Result = tb1;
			}
		} else {
			RTHOOK(5);
			tr1 = RTOUCR(268,F71_1257, (Current));
			tb1 = F1243_11382(RTCW(arg1), tr1);
			if (tb1) {
				RTHOOK(6);
				Result = '\01';
				tb1 = '\01';
				tr1 = RTOUCR(268,F71_1257, (Current));
				tb2 = F1243_11382(RTCW(arg2), tr1);
				if (!tb2) {
					tr1 = RTOUCR(267,F71_1255, (Current));
					tb2 = F1243_11382(RTCW(arg2), tr1);
					tb1 = tb2;
				}
				if (!tb1) {
					tr1 = RTOUCR(269,F71_1256, (Current));
					tb1 = F1243_11382(RTCW(arg2), tr1);
					Result = tb1;
				}
			} else {
				RTHOOK(7);
				tr1 = RTOUCR(269,F71_1256, (Current));
				tb1 = F1243_11382(RTCW(arg1), tr1);
				if (tb1) {
					RTHOOK(8);
					Result = '\01';
					tr1 = RTOUCR(269,F71_1256, (Current));
					tb1 = F1243_11382(RTCW(arg2), tr1);
					if (!tb1) {
						tr1 = RTOUCR(268,F71_1257, (Current));
						tb1 = F1243_11382(RTCW(arg2), tr1);
						Result = tb1;
					}
				} else {
					RTHOOK(9);
					tr1 = RTOUCR(270,F71_1254, (Current));
					tb1 = F1243_11382(RTCW(arg1), tr1);
					if (tb1) {
						RTHOOK(10);
						tr1 = RTOUCR(270,F71_1254, (Current));
						Result = F1243_11382(RTCW(arg2), tr1);
					}
				}
			}
		}
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {UNICODE_CONVERSION}.convert_to */
void F1745_18933 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg3);
	RTLR(3,arg2);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTEAA("convert_to", 1744, Current, 0, 3, 25060);
	RTGC;
	RTHOOK(1);
	F1743_18895(Current);
	RTHOOK(2);
	tb1 = F1243_11382(RTCW(arg1), arg3);
	if (tb1) {
		RTHOOK(3);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(4);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R9615[Dtype(RTCW(arg2))-1240])(arg2);
		if (tb1) {
			RTHOOK(5);
			tr1 = F1237_11112(RTCW(arg2));
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		} else {
			RTHOOK(6);
			tr1 = F1237_11118(RTCW(arg2));
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		}
	} else {
		RTHOOK(7);
		tr1 = RTOUCR(267,F71_1255, (Current));
		tb1 = F1243_11382(RTCW(arg1), tr1);
		if (tb1) {
			RTHOOK(8);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R9617[Dtype(RTCW(arg2))-1240])(arg2);
			if (tb1) {
				RTHOOK(9);
				tr1 = F1237_11112(RTCW(arg2));
			} else {
				RTHOOK(10);
				tr2 = RTLNS(eif_new_type(85, 0x00).id, 85, _OBJSIZ_0_0_0_0_0_0_0_0_);
				tr1 = F86_1480(RTCW(tr2), arg2);
			}
			tr1 = F1745_18934(Current, tr1);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
			RTHOOK(11);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			RTHOOK(12);
			tr1 = RTOUCR(268,F71_1257, (Current));
			tb1 = F1243_11382(RTCW(arg1), tr1);
			if (tb1) {
				RTHOOK(13);
				tr1 = RTOUCR(267,F71_1255, (Current));
				tb1 = F1243_11382(RTCW(arg3), tr1);
				if (tb1) {
					RTHOOK(14);
					tr1 = F1237_11118(RTCW(arg2));
					tr1 = F1745_18935(Current, tr1);
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
					RTHOOK(15);
					*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					RTHOOK(16);
					tr1 = RTOUCR(269,F71_1256, (Current));
					tb1 = F1243_11382(RTCW(arg3), tr1);
					if (tb1) {
						RTHOOK(17);
						tr1 = F1237_11118(RTCW(arg2));
						tr1 = F1745_18936(Current, tr1);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
						RTHOOK(18);
						*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						RTHOOK(19);
						*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
				}
			} else {
				RTHOOK(20);
				tr1 = RTOUCR(269,F71_1256, (Current));
				tb1 = F1243_11382(RTCW(arg1), tr1);
				if (tb1) {
					RTHOOK(21);
					tr1 = RTOUCR(268,F71_1257, (Current));
					tb1 = F1243_11382(RTCW(arg3), tr1);
					if (tb1) {
						RTHOOK(22);
						tr1 = F1237_11118(RTCW(arg2));
						tr1 = F1745_18937(Current, tr1);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
						RTHOOK(23);
						*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
				}
			}
		}
	}
	RTHOOK(24);
	RTLE;
	RTEE;
}

/* {UNICODE_CONVERSION}.utf8_to_utf32 */
EIF_REFERENCE F1745_18934 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("utf8_to_utf32", 1744, Current, 0, 1, 25061);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(85, 0x00).id, 85, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = F86_1494(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {UNICODE_CONVERSION}.utf32_to_utf8 */
EIF_REFERENCE F1745_18935 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("utf32_to_utf8", 1744, Current, 0, 1, 25062);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(85, 0x00).id, 85, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = F86_1480(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {UNICODE_CONVERSION}.utf32_to_utf16 */
EIF_REFERENCE F1745_18936 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("utf32_to_utf16", 1744, Current, 3, 1, 25063);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9759[Dtype(arg1)-1239]);
	F1240_11189(RTCW(Result), (EIF_INTEGER_32) (ti4_1 * ((EIF_INTEGER_32) 2L)));
	RTHOOK(2);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(3);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9759[Dtype(arg1)-1239]);
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) (loc2 > loc3)) break;
		RTHOOK(5);
		tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R9603[Dtype(RTCW(arg1))-1240])(arg1, loc2);
		loc1 = eif_bit_and(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 1048575L));
		RTHOOK(6);
		if ((EIF_BOOLEAN) (loc1 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 65535L))) {
			RTHOOK(7);
			loc1 -= (EIF_NATURAL_32) ((EIF_INTEGER_32) 65536L);
			RTHOOK(8);
			tu4_1 = eif_bit_shift_right(loc1,((EIF_INTEGER_32) 10L));
			tu4_1 = eif_bit_or(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 55296L));
			F1239_11159(RTCW(Result), tu4_1);
			RTHOOK(9);
			tu4_1 = eif_bit_and(loc1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 1023L));
			tu4_1 = eif_bit_or(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 56320L));
			F1239_11159(RTCW(Result), tu4_1);
		} else {
			RTHOOK(10);
			F1239_11159(RTCW(Result), loc1);
		}
		RTHOOK(11);
		loc2++;
	}
	RTHOOK(13);
	RTLE;
	RTEE;
	return Result;
}

/* {UNICODE_CONVERSION}.utf16_to_utf32 */
EIF_REFERENCE F1745_18937 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc3 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc4 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc5 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("utf16_to_utf32", 1744, Current, 5, 1, 25064);
	RTGC;
	RTHOOK(1);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9759[Dtype(arg1)-1239]);
	RTHOOK(2);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1240_11189(RTCW(Result), loc2);
	RTHOOK(3);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		RTHOOK(5);
		loc3 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R9603[Dtype(RTCW(arg1))-1240])(arg1, loc1);
		RTHOOK(6);
		loc1++;
		RTHOOK(7);
		loc4 = eif_bit_and(loc3,(EIF_NATURAL_32) ((EIF_INTEGER_32) 65535L));
		RTHOOK(8);
		if ((EIF_BOOLEAN) (loc1 <= loc2)) {
			RTHOOK(9);
			tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R9603[Dtype(RTCW(arg1))-1240])(arg1, loc1);
			loc5 = eif_bit_and(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 65535L));
		}
		RTHOOK(10);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc4 >= (EIF_NATURAL_32) ((EIF_INTEGER_32) 55296L)) && (EIF_BOOLEAN) (loc4 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 56319L))) && (EIF_BOOLEAN) (loc1 <= loc2)) && (EIF_BOOLEAN) (loc5 >= (EIF_NATURAL_32) ((EIF_INTEGER_32) 56320L))) && (EIF_BOOLEAN) (loc5 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 57343L)))) {
			RTHOOK(11);
			tu4_1 = eif_bit_and(loc4,(EIF_NATURAL_32) ((EIF_INTEGER_32) 1023L));
			tu4_1 = eif_bit_shift_left(tu4_1,((EIF_INTEGER_32) 10L));
			tu4_2 = eif_bit_and(loc5,(EIF_NATURAL_32) ((EIF_INTEGER_32) 1023L));
			F1239_11159(RTCW(Result), (EIF_NATURAL_32) ((EIF_NATURAL_32) (tu4_1 + tu4_2) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 65536L)));
			RTHOOK(12);
			loc1++;
		} else {
			RTHOOK(13);
			F1239_11159(RTCW(Result), loc4);
		}
	}
	RTHOOK(15);
	RTLE;
	RTEE;
	return Result;
}

/* {UNICODE_CONVERSION}.unicode_encodings */
static EIF_REFERENCE F1745_18940_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(266)

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("unicode_encodings", 1744, Current, 0, 0, 25067);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {814,1242,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 814, _OBJSIZ_7_4_0_7_0_0_0_0_);
	}
	F806_8436(RTCW(tr1), ((EIF_INTEGER_32) 8L));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTOUCR(270,F71_1254, (Current));
	tr2 = RTOUCR(270,F71_1254, (Current));
	F806_8482(RTCW(Result), tr1, tr2);
	RTHOOK(3);
	tr1 = RTOUCR(267,F71_1255, (Current));
	tr2 = RTOUCR(267,F71_1255, (Current));
	F806_8482(RTCW(Result), tr1, tr2);
	RTHOOK(4);
	tr1 = RTOUCR(269,F71_1256, (Current));
	tr2 = RTOUCR(269,F71_1256, (Current));
	F806_8482(RTCW(Result), tr1, tr2);
	RTHOOK(5);
	tr1 = RTOUCR(271,F71_1258, (Current));
	tr2 = RTOUCR(271,F71_1258, (Current));
	F806_8482(RTCW(Result), tr1, tr2);
	RTHOOK(6);
	tr1 = RTOUCR(268,F71_1257, (Current));
	tr2 = RTOUCR(268,F71_1257, (Current));
	F806_8482(RTCW(Result), tr1, tr2);
	RTHOOK(7);
	tr1 = RTOUCR(272,F71_1259, (Current));
	tr2 = RTOUCR(272,F71_1259, (Current));
	F806_8482(RTCW(Result), tr1, tr2);
	RTHOOK(8);
	tr1 = RTOUCR(273,F71_1260, (Current));
	tr2 = RTOUCR(273,F71_1260, (Current));
	F806_8482(RTCW(Result), tr1, tr2);
	RTHOOK(9);
	tr1 = RTOUCR(274,F71_1261, (Current));
	tr2 = RTOUCR(274,F71_1261, (Current));
	F806_8482(RTCW(Result), tr1, tr2);
	RTOTE;
	RTHOOK(10);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1745_18940 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(266,F1745_18940_body,(Current));
}

void EIF_Minit1023 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
