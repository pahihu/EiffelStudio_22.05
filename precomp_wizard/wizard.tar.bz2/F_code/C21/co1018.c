/*
 * Code for class CONF_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co1018.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_FILE}.file_path */
EIF_REFERENCE F1740_18828 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("file_path", 1739, Current, 0, 0, 24957);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1303, 0x00).id, 1303, _OBJSIZ_2_1_0_0_0_0_0_0_);
	F1304_12619(RTCW(tr1), *(EIF_REFERENCE *)(Current + O14752[Dtype(Current)-1739]));
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {CONF_FILE}.set_file_name */
void F1740_18830 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("set_file_name", 1739, Current, 1, 1, 24959);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O14749[dtype-1739]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	tr1 = F1237_11118(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O14752[dtype-1739]) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	loc1 = RTLNS(eif_new_type(1303, 0x00).id, 1303, _OBJSIZ_2_1_0_0_0_0_0_0_);
	F1304_12619(RTCW(loc1), arg1);
	RTHOOK(4);
	tr1 = F1304_12634(RTCW(loc1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O14751[dtype-1739]) = (EIF_REFERENCE) tr1;
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {CONF_FILE}.set_file_date */
void F1740_18831 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_file_date", 1739, Current, 0, 0, 24960);
	RTGC;
	RTHOOK(1);
	ti4_1 = F273_4627(Current, *(EIF_REFERENCE *)(Current + O14752[dtype-1739]));
	*(EIF_INTEGER_32 *)(Current + O14754[dtype-1739]) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit1018 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
