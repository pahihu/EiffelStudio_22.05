
#ifndef _C21_lo1025_
#define _C21_lo1025_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1747_18982(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1025(void);
extern void F1148_10346(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F100_1653(EIF_REFERENCE);
extern EIF_REFERENCE F1237_11119(EIF_REFERENCE);
extern EIF_REFERENCE F1_24(EIF_REFERENCE);
extern char *(*R8713[])();

#ifdef __cplusplus
}
#endif

#endif
