/*
 * Code for class CONF_SYSTEM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co1020.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_SYSTEM}.make_with_uuid */
void F1742_18844 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,arg1);
	RTLR(4,arg3);
	RTLR(5,arg4);
	RTLIU(6);
	
	RTEAA("make_with_uuid", 1741, Current, 0, 4, 24983);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {814,1300,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F815_8548(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	{
		static EIF_TYPE_INDEX typarr0[] = {891,1300,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F892_8780(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_15_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	{
		static EIF_TYPE_INDEX typarr0[] = {805,1300,1298,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F806_8437(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9662[Dtype(RTCW(arg2))-1240])(arg2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(5);
	F1740_18830(Current, arg1);
	RTHOOK(6);
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg3;
	RTHOOK(7);
	RTAR(Current, arg4);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg4;
	RTHOOK(8);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_16_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(14);
	RTLE;
	RTEE;
}

/* {CONF_SYSTEM}.target */
EIF_REFERENCE F1742_18855 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("target", 1741, Current, 0, 1, 24994);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	Result = F806_8442(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_SYSTEM}.compilable_targets */
EIF_REFERENCE F1742_18869 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("compilable_targets", 1741, Current, 2, 0, 25008);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {814,1300,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNSMART(typres0.id);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_7_4_0_6_);
	F806_8436(RTCW(Result), ti4_1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F806_8475(RTCW(tr1));
	for (;;) {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tb1 = F806_8470(RTCW(tr1));
		if (tb1) break;
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		loc1 = F806_8448(RTCW(tr1));
		RTHOOK(5);
		tb2 = '\0';
		tr1 = F1301_12444(RTCW(loc1));
		if ((EIF_BOOLEAN)(tr1 != NULL)) {
			tb3 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_29_0_);
			tb2 = (EIF_BOOLEAN) !tb3;
		}
		if (tb2) {
			RTHOOK(6);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_4_);
			F806_8483(RTCW(Result), loc1, tr1);
		}
		RTHOOK(7);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		F806_8476(RTCW(tr1));
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_SYSTEM}.set_is_generated_uuid */
void F1742_18879 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_is_generated_uuid", 1741, Current, 0, 1, 25018);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_16_2_) = (EIF_BOOLEAN) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_SYSTEM}.set_readonly */
void F1742_18881 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_readonly", 1741, Current, 0, 1, 25020);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_16_3_) = (EIF_BOOLEAN) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_SYSTEM}.set_description */
void F1742_18882 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_description", 1741, Current, 0, 1, 25021);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_SYSTEM}.add_target */
void F1742_18884 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("add_target", 1741, Current, 0, 1, 25023);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
	tr2 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr2);
	F806_8483(RTCW(tr1), arg1, tr2);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F892_8820(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_SYSTEM}.set_library_target */
void F1742_18886 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_library_target", 1741, Current, 0, 1, 24972);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

void EIF_Minit1020 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
