/*
 * Code for class UC_V510_CTYPE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "uc1001.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UC_V510_CTYPE}.lower_code */
EIF_INTEGER_32 F1723_18401 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("lower_code", 1722, Current, 4, 1, 24584);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 65536L));
	RTHOOK(2);
	loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 65536L));
	RTHOOK(3);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 / ((EIF_INTEGER_32) 256L));
	RTHOOK(4);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 % ((EIF_INTEGER_32) 256L));
	RTHOOK(5);
	tr1 = RTOUCR(692,F1722_18399, (Current));
	/* INLINED CODE (SPECIAL.item) */
	tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (loc1));
	/* END INLINED CODE */
	tr1 = tr3;
	/* INLINED CODE (SPECIAL.item) */
	tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (loc2));
	/* END INLINED CODE */
	tr1 = tr3;
	Result = F941_9014(RTCW(tr1), (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)));
	RTHOOK(6);
	if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) -1L))) {
		RTHOOK(7);
		RTHOOK(8);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) arg1;
	}
	RTHOOK(10);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_V510_CTYPE}.upper_code */
EIF_INTEGER_32 F1723_18402 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("upper_code", 1722, Current, 4, 1, 24585);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 65536L));
	RTHOOK(2);
	loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 65536L));
	RTHOOK(3);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 / ((EIF_INTEGER_32) 256L));
	RTHOOK(4);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 % ((EIF_INTEGER_32) 256L));
	RTHOOK(5);
	tr1 = RTOUCR(693,F1721_18375, (Current));
	/* INLINED CODE (SPECIAL.item) */
	tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (loc1));
	/* END INLINED CODE */
	tr1 = tr3;
	/* INLINED CODE (SPECIAL.item) */
	tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (loc2));
	/* END INLINED CODE */
	tr1 = tr3;
	Result = F941_9014(RTCW(tr1), (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)));
	RTHOOK(6);
	if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) -1L))) {
		RTHOOK(7);
		RTHOOK(8);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) arg1;
	}
	RTHOOK(10);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit1001 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
