
#ifndef _C21_en1021_
#define _C21_en1021_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1743_18895(EIF_REFERENCE);
extern EIF_REFERENCE F1743_18896(EIF_REFERENCE);
extern void EIF_Minit1021(void);
extern EIF_REFERENCE F294_4911(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F294_4912(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1237_11118(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
