/*
 * Code for class CONF_DIRECTORY_LOCATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co1045.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_DIRECTORY_LOCATION}.make */
void F1767_19745 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTEAA("make", 1766, Current, 0, 2, 25849);
	RTGC;
	RTHOOK(1);
	F1767_19747(Current, arg1);
	RTHOOK(2);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg2;
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {CONF_DIRECTORY_LOCATION}.set_path */
void F1767_19747 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("set_path", 1766, Current, 1, 1, 25848);
	RTGC;
	RTHOOK(1);
	loc1 = F1765_19740(Current, arg1);
	RTHOOK(2);
	tb1 = F730_8337(RTCW(loc1));
	if (tb1) {
		RTHOOK(3);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
		F1242_11317(RTCW(loc1), tw1);
	}
	RTHOOK(4);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
	tw1 = F1242_11271(RTCW(loc1), ti4_1);
	tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\\';
	if ((EIF_BOOLEAN)(tw1 != tw2)) {
		RTHOOK(5);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\\';
		F1242_11317(RTCW(loc1), tw1);
	}
	RTHOOK(6);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
	RTHOOK(7);
	RTLE;
	RTEE;
}

void EIF_Minit1045 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
