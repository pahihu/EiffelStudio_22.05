/*
 * Code for class CONF_CONDITION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co1029.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_CONDITION}.make */
void F1751_19563 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 1750, Current, 0, 0, 25697);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {814,0xFFF9,2,1186,1713,1713,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F806_8436(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	{
		static EIF_TYPE_INDEX typarr0[] = {814,814,41,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F815_8548(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_CONDITION}.make_with_target */
void F1751_19564 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("make_with_target", 1750, Current, 0, 1, 25698);
	RTGC;
	RTHOOK(1);
	F1751_19563(Current);
	RTHOOK(2);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_CONDITION}.set_target */
void F1751_19577 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_target", 1750, Current, 0, 1, 25711);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {CONF_CONDITION}.add_platform */
void F1751_19578 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("add_platform", 1750, Current, 2, 1, 25712);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1186,894,1486,1195,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		{
			static EIF_TYPE_INDEX typarr0[] = {894,1486,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNS(typres0.id, 894, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F895_8780(RTCW(tr2), ((EIF_INTEGER_32) 1L));
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		((EIF_TYPED_VALUE *)tr1+2)->it_b = (EIF_BOOLEAN) 0;
		loc1 = (EIF_REFERENCE) tr1;
		RTHOOK(4);
		F1187_10755(RTCW(loc1));
		RTHOOK(5);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(6);
	tr1 = eif_boxed_item(loc1,1);
	F895_8820(RTCW(tr1), arg1);
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {CONF_CONDITION}.exclude_platform */
void F1751_19579 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("exclude_platform", 1750, Current, 2, 1, 25713);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1186,894,1486,1195,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		{
			static EIF_TYPE_INDEX typarr0[] = {894,1486,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNS(typres0.id, 894, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F895_8780(RTCW(tr2), ((EIF_INTEGER_32) 1L));
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		((EIF_TYPED_VALUE *)tr1+2)->it_b = (EIF_BOOLEAN) 1;
		loc1 = (EIF_REFERENCE) tr1;
		RTHOOK(4);
		F1187_10755(RTCW(loc1));
		RTHOOK(5);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(6);
	tr1 = eif_boxed_item(loc1,1);
	F895_8820(RTCW(tr1), arg1);
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {CONF_CONDITION}.add_build */
void F1751_19581 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("add_build", 1750, Current, 2, 1, 25715);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1186,894,1486,1195,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		{
			static EIF_TYPE_INDEX typarr0[] = {894,1486,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNS(typres0.id, 894, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F895_8780(RTCW(tr2), ((EIF_INTEGER_32) 1L));
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		((EIF_TYPED_VALUE *)tr1+2)->it_b = (EIF_BOOLEAN) 0;
		loc1 = (EIF_REFERENCE) tr1;
		RTHOOK(4);
		F1187_10755(RTCW(loc1));
		RTHOOK(5);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(6);
	tr1 = eif_boxed_item(loc1,1);
	F895_8820(RTCW(tr1), arg1);
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {CONF_CONDITION}.exclude_build */
void F1751_19582 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("exclude_build", 1750, Current, 2, 1, 25716);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1186,894,1486,1195,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		{
			static EIF_TYPE_INDEX typarr0[] = {894,1486,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNS(typres0.id, 894, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F895_8780(RTCW(tr2), ((EIF_INTEGER_32) 1L));
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		((EIF_TYPED_VALUE *)tr1+2)->it_b = (EIF_BOOLEAN) 1;
		loc1 = (EIF_REFERENCE) tr1;
		RTHOOK(4);
		F1187_10755(RTCW(loc1));
		RTHOOK(5);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(6);
	tr1 = eif_boxed_item(loc1,1);
	F895_8820(RTCW(tr1), arg1);
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {CONF_CONDITION}.add_concurrency */
void F1751_19584 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("add_concurrency", 1750, Current, 2, 1, 25718);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1186,894,1486,1195,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		{
			static EIF_TYPE_INDEX typarr0[] = {894,1486,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNS(typres0.id, 894, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F895_8780(RTCW(tr2), ((EIF_INTEGER_32) 1L));
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		((EIF_TYPED_VALUE *)tr1+2)->it_b = (EIF_BOOLEAN) 0;
		loc1 = (EIF_REFERENCE) tr1;
		RTHOOK(4);
		F1187_10755(RTCW(loc1));
		RTHOOK(5);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(6);
	tr1 = eif_boxed_item(loc1,1);
	F895_8820(RTCW(tr1), arg1);
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {CONF_CONDITION}.exclude_concurrency */
void F1751_19585 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("exclude_concurrency", 1750, Current, 2, 1, 25719);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1186,894,1486,1195,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		{
			static EIF_TYPE_INDEX typarr0[] = {894,1486,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNS(typres0.id, 894, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F895_8780(RTCW(tr2), ((EIF_INTEGER_32) 1L));
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		((EIF_TYPED_VALUE *)tr1+2)->it_b = (EIF_BOOLEAN) 1;
		loc1 = (EIF_REFERENCE) tr1;
		RTHOOK(4);
		F1187_10755(RTCW(loc1));
		RTHOOK(5);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(6);
	tr1 = eif_boxed_item(loc1,1);
	F895_8820(RTCW(tr1), arg1);
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {CONF_CONDITION}.add_void_safety */
void F1751_19587 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("add_void_safety", 1750, Current, 2, 1, 25721);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1186,894,1486,1195,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		{
			static EIF_TYPE_INDEX typarr0[] = {894,1486,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNS(typres0.id, 894, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F895_8780(RTCW(tr2), ((EIF_INTEGER_32) 1L));
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		((EIF_TYPED_VALUE *)tr1+2)->it_b = (EIF_BOOLEAN) 0;
		loc1 = (EIF_REFERENCE) tr1;
		RTHOOK(4);
		F1187_10755(RTCW(loc1));
		RTHOOK(5);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(6);
	tr1 = eif_boxed_item(loc1,1);
	F895_8820(RTCW(tr1), arg1);
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {CONF_CONDITION}.exclude_void_safety */
void F1751_19588 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("exclude_void_safety", 1750, Current, 2, 1, 25722);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1186,894,1486,1195,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		{
			static EIF_TYPE_INDEX typarr0[] = {894,1486,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNS(typres0.id, 894, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F895_8780(RTCW(tr2), ((EIF_INTEGER_32) 1L));
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		((EIF_TYPED_VALUE *)tr1+2)->it_b = (EIF_BOOLEAN) 1;
		loc1 = (EIF_REFERENCE) tr1;
		RTHOOK(4);
		F1187_10755(RTCW(loc1));
		RTHOOK(5);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(6);
	tr1 = eif_boxed_item(loc1,1);
	F895_8820(RTCW(tr1), arg1);
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {CONF_CONDITION}.set_dotnet */
void F1751_19590 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("set_dotnet", 1750, Current, 0, 1, 25724);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {338,1195,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F339_5326(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {CONF_CONDITION}.set_dynamic_runtime */
void F1751_19591 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("set_dynamic_runtime", 1750, Current, 0, 1, 25725);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {338,1195,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F339_5326(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {CONF_CONDITION}.add_custom */
void F1751_19594 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,loc1);
	RTLR(5,arg3);
	RTLR(6,arg2);
	RTLIU(7);
	
	RTEAA("add_custom", 1750, Current, 2, 3, 25728);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F806_8442(RTCW(tr1), arg1);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTHOOK(2);
		loc1 = (EIF_REFERENCE) loc2;
	} else {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr1[] = {814,814,41,0xFFFF};
			EIF_TYPE typres1;
			static EIF_TYPE typcache1 = {INVALID_DTYPE, 0};
			
			typres1 = (typcache1.id != INVALID_DTYPE ? typcache1 : (typcache1 = eif_compound_id(dftype, typarr1)));
			loc1 = RTLNSMART(eif_final_id(Y7753,Y7753_gen_type,typres1.id,805).id);
		}
		F806_8436(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		F806_8483(RTCW(tr1), loc1, arg1);
	}
	RTHOOK(5);
	F806_8483(RTCW(loc1), arg3, arg2);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {CONF_CONDITION}.add_version */
void F1751_19598 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,arg3);
	RTLIU(6);
	
	RTEAA("add_version", 1750, Current, 1, 3, 25692);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1186,1713,1713,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = arg1;
	RTAR(tr1,arg1);
	((EIF_TYPED_VALUE *)tr1+2)->it_r = arg2;
	RTAR(tr1,arg2);
	loc1 = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	F1187_10755(RTCW(loc1));
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F806_8483(RTCW(tr1), loc1, arg3);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {CONF_CONDITION}.is_equal */
EIF_BOOLEAN F1751_19599 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("is_equal", 1750, Current, 0, 1, 25693);
	RTGC;
	RTHOOK(1);
	tr1 = F1751_19600(Current);
	tr2 = F1751_19600(RTCW(arg1));
	Result = F1240_11213(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_CONDITION}.text */
EIF_REFERENCE F1751_19600 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(10);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLR(6,loc3);
	RTLR(7,loc4);
	RTLR(8,loc5);
	RTLR(9,loc6);
	RTLIU(10);
	
	RTEAA("text", 1750, Current, 6, 0, 25694);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1237_11059(RTCW(Result));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTOUCR(567,F457_6706, (Current));
	F1751_19601(Current, tr1, tr2, Result);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr2 = RTOUCR(568,F457_6707, (Current));
	F1751_19601(Current, tr1, tr2, Result);
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = RTOUCR(569,F457_6708, (Current));
	F1751_19601(Current, tr1, tr2, Result);
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr2 = RTOUCR(570,F457_6709, (Current));
	F1751_19601(Current, tr1, tr2, Result);
	RTHOOK(6);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F806_8475(RTCW(tr1));
	for (;;) {
		RTHOOK(7);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tb1 = F806_8470(RTCW(tr1));
		if (tb1) break;
		RTHOOK(8);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tr1 = F806_8448(RTCW(tr1));
		tr1 = eif_boxed_item(tr1,1);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			RTHOOK(9);
			tr1 = F1714_18201(loc1);
			F1242_11304(RTCW(Result), tr1);
			RTHOOK(10);
			tr1 = RTMS_EX_H(" <= ",4,540818720);
			F1242_11303(RTCW(Result), tr1);
		}
		RTHOOK(11);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tr1 = F806_8449(RTCW(tr1));
		F1242_11303(RTCW(Result), tr1);
		RTHOOK(12);
		tr1 = RTMS_EX_H(" version",8,1405022062);
		F1242_11303(RTCW(Result), tr1);
		RTHOOK(13);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tr1 = F806_8448(RTCW(tr1));
		tr1 = eif_boxed_item(tr1,2);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTHOOK(14);
			tr1 = RTMS_EX_H(" <= ",4,540818720);
			F1242_11303(RTCW(Result), tr1);
			RTHOOK(15);
			tr1 = F1714_18201(loc2);
			F1242_11304(RTCW(Result), tr1);
		}
		RTHOOK(16);
		tr1 = RTMS_EX_H(" and ",5,1634870304);
		F1242_11303(RTCW(Result), tr1);
		RTHOOK(17);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		F806_8476(RTCW(tr1));
	}
	RTHOOK(18);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTHOOK(19);
		tb2 = *(EIF_BOOLEAN *)(loc3 + O5147[Dtype(loc3)-335]);
		if (tb2) {
			RTHOOK(20);
			tr1 = RTMS_EX_H(".NET and ",9,605383200);
			F1242_11303(RTCW(Result), tr1);
		} else {
			RTHOOK(21);
			tr1 = RTMS_EX_H("not .NET and ",13,608823840);
			F1242_11303(RTCW(Result), tr1);
		}
	}
	RTHOOK(22);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		RTHOOK(23);
		tb2 = *(EIF_BOOLEAN *)(loc4 + O5147[Dtype(loc4)-335]);
		if (tb2) {
			RTHOOK(24);
			tr1 = RTMS_EX_H("dynamic_runtime and ",20,444064800);
			F1242_11303(RTCW(Result), tr1);
		} else {
			RTHOOK(25);
			tr1 = RTMS_EX_H("not dynamic_runtime and ",24,593065760);
			F1242_11303(RTCW(Result), tr1);
		}
	}
	RTHOOK(26);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	loc5 = F806_8451(RTCW(tr1));
	for (;;) {
		tb2 = F1023_9232(loc5);
		if (tb2) break;
		RTHOOK(27);
		tr1 = F1023_9229(loc5);
		loc6 = F806_8451(RTCW(tr1));
		for (;;) {
			tb3 = F1023_9232(loc6);
			if (tb3) break;
			RTHOOK(28);
			tr1 = F1023_9230(loc5);
			F1242_11303(RTCW(Result), tr1);
			RTHOOK(29);
			tr1 = F1023_9229(loc6);
			tb4 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_0_0_);
			if (tb4) {
				RTHOOK(30);
				tr1 = F1023_9229(loc6);
				tb4 = F42_617(RTCW(tr1));
				if (tb4) {
					RTHOOK(31);
					tr1 = RTMS_EX_H(" /<caseless>= ",14,934141216);
					F1242_11303(RTCW(Result), tr1);
				} else {
					RTHOOK(32);
					tr1 = F1023_9229(loc6);
					tb4 = F42_619(RTCW(tr1));
					if (tb4) {
						RTHOOK(33);
						tr1 = RTMS_EX_H(" /<wildcard>= ",14,701941024);
						F1242_11303(RTCW(Result), tr1);
					} else {
						RTHOOK(34);
						tr1 = F1023_9229(loc6);
						tb4 = F42_618(RTCW(tr1));
						if (tb4) {
							RTHOOK(35);
							tr1 = RTMS_EX_H(" /<regexp>= ",12,1388727584);
							F1242_11303(RTCW(Result), tr1);
						} else {
							RTHOOK(36);
							tr1 = RTMS_EX_H(" /= ",4,539966752);
							F1242_11303(RTCW(Result), tr1);
						}
					}
				}
			} else {
				RTHOOK(37);
				tr1 = F1023_9229(loc6);
				tb4 = F42_617(RTCW(tr1));
				if (tb4) {
					RTHOOK(38);
					tr1 = RTMS_EX_H(" =<caseless>= ",14,1213916192);
					F1242_11303(RTCW(Result), tr1);
				} else {
					RTHOOK(39);
					tr1 = F1023_9229(loc6);
					tb4 = F42_619(RTCW(tr1));
					if (tb4) {
						RTHOOK(40);
						tr1 = RTMS_EX_H(" =<wildcard>= ",14,981716000);
						F1242_11303(RTCW(Result), tr1);
					} else {
						RTHOOK(41);
						tr1 = F1023_9229(loc6);
						tb4 = F42_618(RTCW(tr1));
						if (tb4) {
							RTHOOK(42);
							tr1 = RTMS_EX_H(" =<regexp>= ",12,1485495584);
							F1242_11303(RTCW(Result), tr1);
						} else {
							RTHOOK(43);
							tr1 = RTMS_EX_H(" = ",3,2112800);
							F1242_11303(RTCW(Result), tr1);
						}
					}
				}
			}
			RTHOOK(44);
			tr1 = F1023_9230(loc6);
			F1242_11303(RTCW(Result), tr1);
			RTHOOK(45);
			tr1 = RTMS_EX_H(" and ",5,1634870304);
			F1242_11303(RTCW(Result), tr1);
			RTHOOK(46);
			F1023_9233(loc6);
		}
		RTHOOK(47);
		F1023_9233(loc5);
	}
	RTHOOK(48);
	tb4 = F730_8337(RTCW(Result));
	if ((EIF_BOOLEAN) !tb4) {
		RTHOOK(49);
		F1242_11328(RTCW(Result), ((EIF_INTEGER_32) 5L));
	}
	RTHOOK(51);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_CONDITION}.append_list */
void F1751_19601 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,arg1);
	RTLR(1,loc2);
	RTLR(2,Current);
	RTLR(3,loc3);
	RTLR(4,tr1);
	RTLR(5,arg3);
	RTLR(6,loc1);
	RTLR(7,loc4);
	RTLR(8,arg2);
	RTLIU(9);
	
	RTEAA("append_list", 1750, Current, 4, 3, 25695);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		tb1 = '\0';
		loc2 = arg1;
		if (EIF_TEST(loc2)) {
			tr1 = eif_boxed_item(loc2,1);
			loc3 = tr1;
			tb1 = EIF_TEST(loc3);
		}
		if (tb1) {
			RTHOOK(3);
			tb1 = eif_boolean_item(loc2,2);
			if (tb1) {
				RTHOOK(4);
				tr1 = RTMS_EX_H("not ",4,1852797984);
				F1242_11303(RTCW(arg3), tr1);
				RTHOOK(5);
				loc1 = RTMS_EX_H(" and ",5,1634870304);
			} else {
				RTHOOK(6);
				loc1 = RTMS_EX_H(" or ",4,544174624);
			}
			RTHOOK(7);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '(';
			F1242_11317(RTCW(arg3), tw1);
			RTHOOK(8);
			F895_8811(loc3);
			for (;;) {
				RTHOOK(9);
				tb1 = F862_8654(loc3);
				if (tb1) break;
				RTHOOK(10);
				ti4_1 = F895_8785(loc3);
				tr1 = F808_8442(RTCW(arg2), ti4_1);
				loc4 = tr1;
				if (EIF_TEST(loc4)) {
					RTHOOK(11);
					F1242_11303(RTCW(arg3), loc4);
				} else {
					
					RTHOOK(13);
					tr1 = RTMS_EX_H("False",5,1635034981);
					F1242_11303(RTCW(arg3), tr1);
				}
				RTHOOK(14);
				F1242_11303(RTCW(arg3), loc1);
				RTHOOK(15);
				F895_8813(loc3);
			}
			RTHOOK(16);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			F1242_11328(RTCW(arg3), ti4_1);
			RTHOOK(17);
			tr1 = RTMS_EX_H(") and ",6,1715479584);
			F1242_11303(RTCW(arg3), tr1);
		} else {
			
		}
	}
	RTHOOK(19);
	RTLE;
	RTEE;
}

void EIF_Minit1029 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
