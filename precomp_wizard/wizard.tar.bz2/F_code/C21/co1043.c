/*
 * Code for class CONF_LOCATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co1043.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_LOCATION}.evaluated_path */
EIF_REFERENCE F1765_19729 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("evaluated_path", 1764, Current, 0, 0, 25832);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F1301_12435(RTCW(tr1));
	Result = F1765_19730(Current, tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_LOCATION}.evaluated_path_relative_to_location */
EIF_REFERENCE F1765_19730 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(11);
	RTLR(0,loc10);
	RTLR(1,Current);
	RTLR(2,loc11);
	RTLR(3,tr1);
	RTLR(4,loc7);
	RTLR(5,loc5);
	RTLR(6,loc6);
	RTLR(7,tr2);
	RTLR(8,loc12);
	RTLR(9,Result);
	RTLR(10,arg1);
	RTLIU(11);
	
	RTEAA("evaluated_path_relative_to_location", 1764, Current, 12, 1, 25833);
	RTGC;
	RTAOMS(19729,1);
	RTHOOK(1);
	loc10 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1240_11191(RTCW(loc10), *(EIF_REFERENCE *)(Current));
	RTHOOK(2);
	tb1 = '\0';
	tb2 = '\0';
	tb3 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc11 = tr1;
	if (EIF_TEST(loc11)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc10)+ _LNGOFF_1_1_0_2_);
		tb3 = (EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 2L));
	}
	if (tb3) {
		tw1 = F1242_11271(RTCW(loc10), ((EIF_INTEGER_32) 1L));
		tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '$';
		tb2 = (EIF_BOOLEAN)(tw1 == tw2);
	}
	if (tb2) {
		tw1 = F1242_11271(RTCW(loc10), ((EIF_INTEGER_32) 2L));
		tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '|';
		tb1 = (EIF_BOOLEAN)(tw1 == tw2);
	}
	if (tb1) {
		RTHOOK(3);
		tr1 = F1765_19729(loc11);
		loc7 = F1304_12658(RTCW(tr1));
		RTHOOK(4);
		F1242_11280(RTCW(loc10), loc7, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 2L));
		RTHOOK(5);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\\';
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc7) + O9759[Dtype(loc7)-1239]);
		F1242_11322(RTCW(loc10), tw1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
	}
	RTHOOK(6);
	loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(7);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '$';
	loc1 = F1240_11201(RTCW(loc10), tw1, loc8);
	for (;;) {
		RTHOOK(8);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L)) || loc9)) break;
		RTHOOK(9);
		loc5 = (EIF_REFERENCE) NULL;
		RTHOOK(10);
		loc4 = (EIF_INTEGER_32) loc1;
		RTHOOK(11);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
			tw1 = F1242_11271(RTCW(loc10), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
			tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '{';
			tb1 = (EIF_BOOLEAN)(tw1 == tw2);
		}
		if (tb1) {
			RTHOOK(12);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '}';
			loc2 = F1240_11201(RTCW(loc10), tw1, loc1);
			RTHOOK(13);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 != ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (loc2 > (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L))))) {
				RTHOOK(14);
				loc5 = F1242_11351(RTCW(loc10), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)), (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
			}
		} else {
			RTHOOK(15);
			tb1 = '\0';
			if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
				tw1 = F1242_11271(RTCW(loc10), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
				tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '(';
				tb1 = (EIF_BOOLEAN)(tw1 == tw2);
			}
			if (tb1) {
				RTHOOK(16);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ')';
				loc8 = F1240_11201(RTCW(loc10), tw1, loc1);
				loc8 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 2L));
			} else {
				RTHOOK(17);
				if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
					RTHOOK(18);
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
					loc2 = F1240_11201(RTCW(loc10), tw1, loc1);
					loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
					RTHOOK(19);
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\\';
					loc3 = F1240_11201(RTCW(loc10), tw1, loc1);
					loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L));
					RTHOOK(20);
					if ((EIF_BOOLEAN) (loc2 < loc1)) {
						RTHOOK(21);
						loc2 = *(EIF_INTEGER_32 *)(RTCW(loc10)+ _LNGOFF_1_1_0_2_);
					}
					RTHOOK(22);
					if ((EIF_BOOLEAN) (loc3 > loc1)) {
						RTHOOK(23);
						ti4_1 = eif_min_int32 (loc2,loc3);
						loc2 = (EIF_INTEGER_32) ti4_1;
					}
					RTHOOK(24);
					loc5 = F1242_11351(RTCW(loc10), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)), loc2);
				}
			}
		}
		RTHOOK(25);
		if ((EIF_BOOLEAN)(loc5 != NULL)) {
			RTHOOK(26);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tr1 = F1301_12457(RTCW(tr1));
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9662[Dtype(RTCW(loc5))-1240])(loc5);
			loc6 = F806_8442(RTCW(tr1), tr2);
			RTHOOK(27);
			if ((EIF_BOOLEAN)(loc6 == NULL)) {
				RTHOOK(28);
				tr1 = RTOUCR(511,F504_7211, (Current));
				loc6 = F517_7497(RTCW(tr1), loc5);
				RTHOOK(29);
				tb1 = '\0';
				if ((EIF_BOOLEAN)(loc6 == NULL)) {
					tb1 = F498_7168(Current);
				}
				if (tb1) {
					RTHOOK(30);
					tr1 = F498_7170(Current);
					loc6 = F1793_20652(RTCW(tr1), loc5);
				}
				RTHOOK(31);
				if ((EIF_BOOLEAN)(loc6 == NULL)) {
					RTHOOK(32);
					RTCOMS32(tr1,19729,0,"",0,0);
					loc6 = (EIF_REFERENCE) tr1;
				}
				RTHOOK(33);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				F1301_12434(RTCW(tr1), loc6, loc5);
			}
			RTHOOK(34);
			tr1 = F1765_19740(Current, loc6);
			F1242_11280(RTCW(loc10), tr1, loc1, loc2);
		}
		RTHOOK(35);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '$';
		loc1 = F1240_11201(RTCW(loc10), tw1, loc8);
		RTHOOK(36);
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
			RTHOOK(37);
			loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc4 == loc1);
		}
	}
	RTHOOK(38);
	tr1 = F296_4924(Current);
	tr1 = F38_589(RTCW(tr1), loc10);
	loc12 = tr1;
	if (EIF_TEST(loc12)) {
		RTHOOK(39);
		loc10 = F1237_11118(loc12);
	}
	RTHOOK(40);
	tb1 = RTOUCB(EIF_BOOLEAN,512,F31_283, (RTCV(RTOUCR(513,F357_5469, (Current)))));
	if (tb1) {
		RTHOOK(41);
		F1242_11345(RTCW(loc10));
	} else {
		RTHOOK(42);
		F1765_19741(Current, loc10);
	}
	RTHOOK(43);
	Result = RTLNS(eif_new_type(1303, 0x00).id, 1303, _OBJSIZ_2_1_0_0_0_0_0_0_);
	F1304_12619(RTCW(Result), loc10);
	RTHOOK(44);
	tb1 = F1304_12628(RTCW(Result));
	if (tb1) {
		RTHOOK(45);
		tb1 = F1304_12627(RTCW(Result));
		if (tb1) {
			RTHOOK(46);
			tr1 = arg1;
		} else {
			RTHOOK(47);
			tr2 = F1304_12647(RTCW(arg1), Result);
			tr1 = tr2;
		}
		tr1 = F1304_12640(RTCV(tr1));
		Result = (EIF_REFERENCE) tr1;
	}
	RTHOOK(49);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_LOCATION}.set_parent */
void F1765_19735 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_parent", 1764, Current, 0, 1, 25837);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CONF_LOCATION}.is_equal */
EIF_BOOLEAN F1765_19737 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("is_equal", 1764, Current, 0, 1, 25839);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	Result = F1_10(Current, *(EIF_REFERENCE *)(Current), tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_LOCATION}.to_internal_format */
EIF_REFERENCE F1765_19740 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("to_internal_format", 1764, Current, 0, 1, 25842);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1242_11265(RTCW(Result), arg1);
	RTHOOK(2);
	F1242_11288(RTCW(Result));
	RTHOOK(3);
	F1242_11289(RTCW(Result));
	RTHOOK(4);
	tr1 = RTMS32_EX_H("/\000\000\000",1,47);
	tr2 = RTMS32_EX_H("\\\000\000\000",1,92);
	F1242_11281(RTCW(Result), tr1, tr2);
	RTHOOK(5);
	tb1 = '\0';
	tb2 = '\0';
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 2L))) {
		tw1 = F1242_11271(RTCW(Result), ((EIF_INTEGER_32) 1L));
		tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '$';
		tb2 = (EIF_BOOLEAN)(tw1 == tw2);
	}
	if (tb2) {
		tw1 = F1242_11271(RTCW(Result), ((EIF_INTEGER_32) 2L));
		tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\\';
		tb1 = (EIF_BOOLEAN)(tw1 == tw2);
	}
	if (tb1) {
		RTHOOK(6);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '|';
		F1242_11291(RTCW(Result), tw1, ((EIF_INTEGER_32) 2L));
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_LOCATION}.update_path_to_unix */
void F1765_19741 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("update_path_to_unix", 1764, Current, 0, 1, 25843);
	RTGC;
	RTHOOK(1);
	tr1 = RTMS32_EX_H("\\\000\000\000",1,92);
	tr2 = RTMS32_EX_H("/\000\000\000",1,47);
	F1242_11281(RTCW(arg1), tr1, tr2);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit1043 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
