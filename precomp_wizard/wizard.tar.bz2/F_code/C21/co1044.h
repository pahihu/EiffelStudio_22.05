
#ifndef _C21_co1044_
#define _C21_co1044_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1766_19742(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1766_19744(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1044(void);
extern EIF_REFERENCE F1765_19740(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
