/*
 * Code for class JSON_PARSER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "js1046.h"
#include "eif_built_in.h"
#include <ctype.h>
#include "eif_helpers.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {JSON_PARSER}.make_with_string */
void F1768_19749 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("make_with_string", 1767, Current, 0, 1, 25852);
	RTGC;
	RTHOOK(1);
	F1768_19751(Current);
	RTHOOK(2);
	F115_1883(Current, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {JSON_PARSER}.initialize */
void F1768_19751 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("initialize", 1767, Current, 1, 0, 25854);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1244, 0x00).id, 1244, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1237_11059(RTCW(loc1));
	RTHOOK(2);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) loc1;
	RTHOOK(3);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) loc1;
	RTHOOK(4);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) loc1;
	RTHOOK(5);
	tr1 = RTLNSMART(eif_new_type(1476, 0).id);
	F1477_13758(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(6);
	tr1 = RTLNSMART(eif_new_type(1476, 0).id);
	F1477_13757(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTHOOK(7);
	tr1 = RTLNSMART(eif_new_type(1477, 0).id);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTHOOK(8);
	{
		static EIF_TYPE_INDEX typarr0[] = {882,1244,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F883_8665(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {JSON_PARSER}.is_valid */
EIF_BOOLEAN F1768_19753 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_valid", 1767, Current, 0, 0, 25856);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_9_1_);
}

/* {JSON_PARSER}.json_string_buffer_size */
EIF_INTEGER_32 F1768_19762 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("json_string_buffer_size", 1767, Current, 0, 0, 25865);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 512L);
}

/* {JSON_PARSER}.json_number_buffer_size */
EIF_INTEGER_32 F1768_19763 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("json_number_buffer_size", 1767, Current, 0, 0, 25866);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
}

/* {JSON_PARSER}.parsed_json_object */
EIF_REFERENCE F1768_19765 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("parsed_json_object", 1767, Current, 1, 0, 25868);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1511, 0x00),loc1);
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) loc1;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {JSON_PARSER}.reset */
void F1768_19767 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("reset", 1767, Current, 0, 0, 25870);
	RTGC;
	RTHOOK(1);
	F115_1884(Current);
	RTHOOK(2);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) NULL;
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R7661[Dtype(RTCW(tr1))-780])(tr1);
	RTHOOK(4);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(5);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(6);
	F1768_19796(Current);
	RTHOOK(7);
	tr1 = RTLNSMART(eif_new_type(1477, 0).id);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTHOOK(8);
	tr1 = RTLNSMART(eif_new_type(1476, 0).id);
	F1477_13758(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(9);
	tr1 = RTLNSMART(eif_new_type(1476, 0).id);
	F1477_13757(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {JSON_PARSER}.parse_content */
void F1768_19769 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("parse_content", 1767, Current, 0, 0, 25872);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_9_0_)) {
		RTHOOK(2);
		F1768_19795(Current);
		RTHOOK(3);
		if (F1768_19788(Current)) {
			RTHOOK(4);
			tr1 = F1768_19776(Current);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
			RTHOOK(5);
			tb1 = '\0';
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_9_1_)) {
				tb1 = F1768_19787(Current);
			}
			if (tb1) {
				RTHOOK(6);
				tr1 = RTMS_EX_H("Remaining element outside the main json value",45,341899109);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_0_);
				F1768_19771(Current, tr1, ti4_1);
			}
		} else {
			RTHOOK(7);
			tr1 = RTMS_EX_H("Syntax error unexpected token, expecting \'{\' or \'[\'",51,1020017191);
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_0_);
			F1768_19771(Current, tr1, ti4_1);
		}
		RTHOOK(8);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_9_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(9);
		F1768_19796(Current);
		RTHOOK(10);
		tr1 = RTMS_EX_H("",0,0);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		
	}
	RTHOOK(13);
	RTLE;
	RTEE;
}

/* {JSON_PARSER}.report_error */
void F1768_19770 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("report_error", 1767, Current, 0, 1, 25873);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7715[Dtype(RTCW(tr1))-882])(tr1, arg1);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {JSON_PARSER}.report_error_at */
void F1768_19771 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("report_error_at", 1767, Current, 0, 2, 25874);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg2 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		tr1 = RTMS_EX_H(" (position: ",12,1385097760);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(RTCW(arg1))-1243])(arg1, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_0_);
		tr2 = eif_out__i4_s1(ti4_1);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(RTCW(tr1))-1243])(tr1, tr2);
		tr2 = RTMS_EX_H(")",1,41);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(RTCW(tr1))-1243])(tr1, tr2);
		F1768_19770(Current, tr1);
	} else {
		RTHOOK(3);
		F1768_19770(Current, arg1);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {JSON_PARSER}.next_json_value */
EIF_REFERENCE F1768_19776 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("next_json_value", 1767, Current, 1, 0, 25879);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_9_1_)) {
		RTHOOK(2);
		F115_1889(Current);
		RTHOOK(3);
		loc1 = F115_1895(Current);
		RTHOOK(4);
		switch (loc1) {
			case (EIF_CHARACTER_8) '{':
				RTHOOK(5);
				Result = F1768_19777(Current);
				break;
			case (EIF_CHARACTER_8) '\"':
				RTHOOK(6);
				Result = F1768_19778(Current);
				break;
			case (EIF_CHARACTER_8) '[':
				RTHOOK(7);
				Result = F1768_19779(Current);
				break;
			default:
				RTHOOK(8);
				tb1 = '\01';
				tb2 = EIF_TEST(isdigit(loc1));
				if (!tb2) {
					tb1 = (EIF_BOOLEAN)(loc1 == (EIF_CHARACTER_8) '-');
				}
				if (tb1) {
					RTHOOK(9);
					Result = F1768_19780(Current);
				} else {
					RTHOOK(10);
					if (F1768_19781(Current)) {
						RTHOOK(11);
						Result = *(EIF_REFERENCE *)(Current + _REFACS_5_);
						RTHOOK(12);
						F115_1887(Current);
						RTHOOK(13);
						F115_1887(Current);
						RTHOOK(14);
						F115_1887(Current);
					} else {
						RTHOOK(15);
						if (F1768_19783(Current)) {
							RTHOOK(16);
							Result = *(EIF_REFERENCE *)(Current + _REFACS_4_);
							RTHOOK(17);
							F115_1887(Current);
							RTHOOK(18);
							F115_1887(Current);
							RTHOOK(19);
							F115_1887(Current);
						} else {
							RTHOOK(20);
							if (F1768_19782(Current)) {
								RTHOOK(21);
								Result = *(EIF_REFERENCE *)(Current + _REFACS_3_);
								RTHOOK(22);
								F115_1887(Current);
								RTHOOK(23);
								F115_1887(Current);
								RTHOOK(24);
								F115_1887(Current);
								RTHOOK(25);
								F115_1887(Current);
							} else {
								RTHOOK(26);
								tr1 = RTMS_EX_H("JSON value is not well formed",29,1143638628);
								ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_0_);
								F1768_19771(Current, tr1, ti4_1);
								RTHOOK(27);
								Result = (EIF_REFERENCE) NULL;
							}
						}
					}
				}
				break;
		}
	}
	RTHOOK(29);
	RTLE;
	RTEE;
	return Result;
}

/* {JSON_PARSER}.next_json_object */
EIF_REFERENCE F1768_19777 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTEAA("next_json_object", 1767, Current, 3, 0, 25880);
	RTGC;
	RTHOOK(1);
	F115_1887(Current);
	RTHOOK(2);
	F115_1889(Current);
	RTHOOK(3);
	if ((EIF_BOOLEAN)(F115_1895(Current) == (EIF_CHARACTER_8) '}')) {
		RTHOOK(4);
		tr1 = RTLNS(eif_new_type(1511, 0x00).id, 1511, _OBJSIZ_1_0_0_0_0_0_0_0_);
		F1512_14742(RTCW(tr1), ((EIF_INTEGER_32) 0L));
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(6);
		Result = RTLNS(eif_new_type(1511, 0x00).id, 1511, _OBJSIZ_1_0_0_0_0_0_0_0_);
		F1512_14742(RTCW(Result), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_2_));
		RTHOOK(7);
		F115_1888(Current);
		RTHOOK(8);
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		for (;;) {
			RTHOOK(9);
			if ((EIF_BOOLEAN) !loc1) break;
			RTHOOK(10);
			F115_1887(Current);
			RTHOOK(11);
			F115_1889(Current);
			RTHOOK(12);
			loc2 = F1768_19778(Current);
			RTHOOK(13);
			F115_1887(Current);
			RTHOOK(14);
			F115_1889(Current);
			RTHOOK(15);
			if ((EIF_BOOLEAN)(F115_1895(Current) == (EIF_CHARACTER_8) ':')) {
				RTHOOK(16);
				F115_1887(Current);
				RTHOOK(17);
				F115_1889(Current);
			} else {
				RTHOOK(18);
				tr1 = RTMS_EX_H("\012 Input string is a not well formed JSON, expected [:] found [",62,979945051);
				tr2 = eif_out__c1_s1(F115_1895(Current));
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(tr1)-1243])(tr1, tr2);
				tr2 = RTMS_EX_H("]",1,93);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(RTCW(tr1))-1243])(tr1, tr2);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_0_);
				F1768_19771(Current, tr1, ti4_1);
				RTHOOK(19);
				loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
			RTHOOK(20);
			loc3 = F1768_19776(Current);
			RTHOOK(21);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_9_1_) && (EIF_BOOLEAN) ((EIF_BOOLEAN)(loc3 != NULL) && (EIF_BOOLEAN)(loc2 != NULL)))) {
				RTHOOK(22);
				F1512_14746(RTCW(Result), loc3, loc2);
				RTHOOK(23);
				F115_1887(Current);
				RTHOOK(24);
				F115_1889(Current);
				RTHOOK(25);
				if ((EIF_BOOLEAN)(F115_1895(Current) == (EIF_CHARACTER_8) '}')) {
					RTHOOK(26);
					loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				} else {
					RTHOOK(27);
					if ((EIF_BOOLEAN)(F115_1895(Current) != (EIF_CHARACTER_8) ',')) {
						RTHOOK(28);
						loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						RTHOOK(29);
						tr1 = RTMS_EX_H("JSON Object syntactically malformed expected , found [",54,605843291);
						tr2 = eif_out__c1_s1(F115_1895(Current));
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(tr1)-1243])(tr1, tr2);
						tr2 = RTMS_EX_H("]",1,93);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(RTCW(tr1))-1243])(tr1, tr2);
						ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_0_);
						F1768_19771(Current, tr1, ti4_1);
					}
				}
			} else {
				RTHOOK(30);
				loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
		}
	}
	RTHOOK(31);
	RTLE;
	RTEE;
	return Result;
}

/* {JSON_PARSER}.next_json_string */
EIF_REFERENCE F1768_19778 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_8 loc2 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLIU(5);
	
	RTEAA("next_json_string", 1767, Current, 4, 0, 25881);
	RTGC;
	RTHOOK(1);
	loc3 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R9728[Dtype(RTCW(loc3))-1241])(loc3);
	RTHOOK(3);
	if ((EIF_BOOLEAN)(F115_1895(Current) == (EIF_CHARACTER_8) '\"')) {
		RTHOOK(4);
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		for (;;) {
			RTHOOK(5);
			if ((EIF_BOOLEAN) !loc1) break;
			RTHOOK(6);
			F115_1887(Current);
			RTHOOK(7);
			loc2 = F115_1895(Current);
			RTHOOK(8);
			if ((EIF_BOOLEAN)(loc2 == (EIF_CHARACTER_8) '\"')) {
				RTHOOK(9);
				loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			} else {
				RTHOOK(10);
				if ((EIF_BOOLEAN)(loc2 == (EIF_CHARACTER_8) '\\')) {
					RTHOOK(11);
					F115_1887(Current);
					RTHOOK(12);
					loc2 = F115_1895(Current);
					RTHOOK(13);
					if ((EIF_BOOLEAN)(loc2 == (EIF_CHARACTER_8) 'u')) {
						RTHOOK(14);
						loc4 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_1_1_0_2_);
						loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L));
						RTHOOK(15);
						tr1 = RTMS_EX_H("\\u",2,23669);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9863[Dtype(RTCW(loc3))-1244])(loc3, tr1);
						RTHOOK(16);
						F1768_19784(Current, loc3);
						RTHOOK(17);
						loc2 = F115_1895(Current);
						RTHOOK(18);
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_1_1_0_2_);
						if ((EIF_BOOLEAN) !F1768_19786(Current, loc3, loc4, ti4_1)) {
							RTHOOK(19);
							loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							RTHOOK(20);
							tr1 = RTMS_EX_H("Input string is not well formed JSON, expected Unicode value, found [",69,2033199195);
							tr2 = eif_out__c1_s1(loc2);
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(tr1)-1243])(tr1, tr2);
							tr2 = RTMS_EX_H("]",1,93);
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(RTCW(tr1))-1243])(tr1, tr2);
							ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_0_);
							F1768_19771(Current, tr1, ti4_1);
						}
					} else {
						RTHOOK(21);
						tb1 = '\01';
						tb2 = '\0';
						if ((EIF_BOOLEAN) !F114_1880(Current, loc2)) {
							tb2 = (EIF_BOOLEAN) !F114_1881(Current, loc2);
						}
						if (!tb2) {
							tb1 = (EIF_BOOLEAN)(loc2 == (EIF_CHARACTER_8) '\012');
						}
						if (tb1) {
							RTHOOK(22);
							loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							RTHOOK(23);
							tr1 = RTMS_EX_H("Input string is not well formed JSON, found [",45,1899730011);
							tr2 = eif_out__c1_s1(loc2);
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(tr1)-1243])(tr1, tr2);
							tr2 = RTMS_EX_H("]",1,93);
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(RTCW(tr1))-1243])(tr1, tr2);
							ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_0_);
							F1768_19771(Current, tr1, ti4_1);
						} else {
							RTHOOK(24);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R9867[Dtype(RTCW(loc3))-1244])(loc3, (EIF_CHARACTER_8) '\\');
							RTHOOK(25);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R9867[Dtype(RTCW(loc3))-1244])(loc3, loc2);
						}
					}
				} else {
					RTHOOK(26);
					tb1 = '\0';
					if (F114_1880(Current, loc2)) {
						tb1 = (EIF_BOOLEAN)(loc2 != (EIF_CHARACTER_8) '/');
					}
					if (tb1) {
						RTHOOK(27);
						loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						RTHOOK(28);
						tr1 = RTMS_EX_H("Input string is not well formed JSON, found [",45,1899730011);
						tr2 = eif_out__c1_s1(loc2);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(tr1)-1243])(tr1, tr2);
						tr2 = RTMS_EX_H("]",1,93);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(RTCW(tr1))-1243])(tr1, tr2);
						ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_0_);
						F1768_19771(Current, tr1, ti4_1);
					} else {
						RTHOOK(29);
						if ((EIF_BOOLEAN)(loc2 == (EIF_CHARACTER_8) '\000')) {
							RTHOOK(30);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R9867[Dtype(RTCW(loc3))-1244])(loc3, loc2);
						} else {
							RTHOOK(31);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R9867[Dtype(RTCW(loc3))-1244])(loc3, loc2);
						}
					}
				}
			}
		}
		RTHOOK(32);
		Result = RTLNS(eif_new_type(1478, 0x00).id, 1478, _OBJSIZ_1_0_0_0_0_0_0_0_);
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc3);
		F1479_13774(RTCW(Result), tr1);
	} else {
		RTHOOK(33);
		RTHOOK(34);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) NULL;
	}
	RTHOOK(35);
	RTLE;
	RTEE;
	return Result;
}

/* {JSON_PARSER}.parse_array */
EIF_REFERENCE F1768_19779 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("parse_array", 1767, Current, 3, 0, 25882);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1512, 0x00).id, 1512, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F1513_14779(RTCW(Result), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_1_));
	RTHOOK(2);
	F115_1887(Current);
	RTHOOK(3);
	F115_1889(Current);
	RTHOOK(4);
	if ((EIF_BOOLEAN)(F115_1895(Current) == (EIF_CHARACTER_8) ']')) {
	} else {
		RTHOOK(5);
		F115_1888(Current);
		RTHOOK(6);
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		for (;;) {
			RTHOOK(7);
			if ((EIF_BOOLEAN) !loc1) break;
			RTHOOK(8);
			F115_1887(Current);
			RTHOOK(9);
			F115_1889(Current);
			RTHOOK(10);
			loc2 = F1768_19776(Current);
			RTHOOK(11);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_9_1_) && (EIF_BOOLEAN)(loc2 != NULL))) {
				RTHOOK(12);
				F1513_14792(RTCW(Result), loc2);
				RTHOOK(13);
				F115_1887(Current);
				RTHOOK(14);
				F115_1889(Current);
				RTHOOK(15);
				loc3 = F115_1895(Current);
				RTHOOK(16);
				if ((EIF_BOOLEAN)(loc3 == (EIF_CHARACTER_8) ']')) {
					RTHOOK(17);
					loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				} else {
					RTHOOK(18);
					if ((EIF_BOOLEAN)(loc3 != (EIF_CHARACTER_8) ',')) {
						RTHOOK(19);
						loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						RTHOOK(20);
						tr1 = RTMS_EX_H("Array is not well formed JSON, found [",38,206143579);
						tr2 = eif_out__c1_s1(loc3);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(tr1)-1243])(tr1, tr2);
						tr2 = RTMS_EX_H("]",1,93);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(RTCW(tr1))-1243])(tr1, tr2);
						ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_0_);
						F1768_19771(Current, tr1, ti4_1);
					}
				}
			} else {
				RTHOOK(21);
				loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				RTHOOK(22);
				tr1 = RTMS_EX_H("Array is not well formed JSON, found [",38,206143579);
				tr2 = eif_out__c1_s1(F115_1895(Current));
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(tr1)-1243])(tr1, tr2);
				tr2 = RTMS_EX_H("]",1,93);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(RTCW(tr1))-1243])(tr1, tr2);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_0_);
				F1768_19771(Current, tr1, ti4_1);
			}
		}
	}
	RTHOOK(23);
	RTLE;
	RTEE;
	return Result;
}

/* {JSON_PARSER}.next_json_number */
EIF_REFERENCE F1768_19780 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_INTEGER_64 ti8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("next_json_number", 1767, Current, 4, 0, 25883);
	RTGC;
	RTHOOK(1);
	loc4 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R9728[Dtype(RTCW(loc4))-1241])(loc4);
	RTHOOK(3);
	tc1 = F115_1895(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R9867[Dtype(RTCW(loc4))-1244])(loc4, tc1);
	RTHOOK(4);
	loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	for (;;) {
		RTHOOK(5);
		if ((EIF_BOOLEAN) !loc1) break;
		RTHOOK(6);
		F115_1887(Current);
		RTHOOK(7);
		loc3 = F115_1895(Current);
		RTHOOK(8);
		tb1 = '\01';
		tb2 = '\01';
		tb3 = '\01';
		tb4 = '\01';
		if (!(EIF_BOOLEAN) !F115_1892(Current)) {
			tb4 = F114_1879(Current, loc3);
		}
		if (!tb4) {
			tb3 = (EIF_BOOLEAN)(loc3 == (EIF_CHARACTER_8) ',');
		}
		if (!tb3) {
			tb2 = (EIF_BOOLEAN)(loc3 == (EIF_CHARACTER_8) '\012');
		}
		if (!tb2) {
			tb1 = (EIF_BOOLEAN)(loc3 == (EIF_CHARACTER_8) '\015');
		}
		if (tb1) {
			RTHOOK(9);
			loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			RTHOOK(10);
			F115_1888(Current);
		} else {
			RTHOOK(11);
			tc1 = F115_1895(Current);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R9867[Dtype(RTCW(loc4))-1244])(loc4, tc1);
		}
	}
	RTHOOK(12);
	if (F1768_19785(Current, loc4)) {
		RTHOOK(13);
		tb1 = F1237_11092(RTCW(loc4));
		if (tb1) {
			RTHOOK(14);
			Result = RTLNS(eif_new_type(1479, 0x00).id, 1479, _OBJSIZ_1_0_0_1_0_0_0_0_);
			ti8_1 = F1237_11126(RTCW(loc4));
			F1480_13801(RTCW(Result), ti8_1);
			RTHOOK(15);
			loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			RTHOOK(16);
			tb1 = F1237_11085(RTCW(loc4));
			if (tb1) {
				RTHOOK(17);
				Result = RTLNS(eif_new_type(1479, 0x00).id, 1479, _OBJSIZ_1_0_0_1_0_0_0_0_);
				tr8_1 = F1237_11134(RTCW(loc4));
				F1480_13803(RTCW(Result), tr8_1);
			}
		}
	} else {
		RTHOOK(18);
		tr1 = RTMS_EX_H("Expected a number, found [",26,1659187803);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(tr1)-1243])(tr1, loc4);
		tr2 = RTMS_EX_H("]",1,93);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(RTCW(tr1))-1243])(tr1, tr2);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_0_);
		F1768_19771(Current, tr1, ti4_1);
	}
	RTHOOK(19);
	RTLE;
	RTEE;
	return Result;
}

/* {JSON_PARSER}.is_null */
EIF_BOOLEAN F1768_19781 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("is_null", 1767, Current, 0, 0, 25884);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(687,F1768_19791, (Current));
	Result = F115_1891(Current, tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 4L));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {JSON_PARSER}.is_false */
EIF_BOOLEAN F1768_19782 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("is_false", 1767, Current, 0, 0, 25885);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(688,F1768_19789, (Current));
	Result = F115_1891(Current, tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 5L));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {JSON_PARSER}.is_true */
EIF_BOOLEAN F1768_19783 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("is_true", 1767, Current, 0, 0, 25886);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(689,F1768_19790, (Current));
	Result = F115_1891(Current, tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 4L));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {JSON_PARSER}.read_unicode_info */
void F1768_19784 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("read_unicode_info", 1767, Current, 1, 1, 25887);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(2);
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 4L))) {
			tb1 = (EIF_BOOLEAN) !F115_1892(Current);
		}
		if (tb1) break;
		RTHOOK(3);
		F115_1887(Current);
		RTHOOK(4);
		tc1 = F115_1895(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R9867[Dtype(RTCW(arg1))-1244])(arg1, tc1);
		RTHOOK(5);
		loc1++;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {JSON_PARSER}.is_valid_number */
EIF_BOOLEAN F1768_19785 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("is_valid_number", 1767, Current, 4, 1, 25888);
	RTGC;
	RTHOOK(1);
	loc4 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R9728[Dtype(RTCW(loc4))-1241])(loc4);
	RTHOOK(3);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	RTHOOK(4);
	if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
		RTHOOK(5);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		RTHOOK(6);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(7);
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		RTHOOK(8);
		loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7739[Dtype(RTCW(arg1))-805])(arg1, loc2));
		RTHOOK(9);
		if ((EIF_BOOLEAN)(loc1 == (EIF_CHARACTER_8) '-')) {
			RTHOOK(10);
			F1245_11483(RTCW(loc4), loc1);
			RTHOOK(11);
			loc2++;
			RTHOOK(12);
			if ((EIF_BOOLEAN) (loc2 > loc3)) {
				RTHOOK(13);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			} else {
				RTHOOK(14);
				loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7739[Dtype(RTCW(arg1))-805])(arg1, loc2));
			}
		}
		RTHOOK(15);
		tb1 = '\0';
		if (Result) {
			tb2 = EIF_TEST(isdigit(loc1));
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(16);
			if ((EIF_BOOLEAN)(loc1 == (EIF_CHARACTER_8) '0')) {
				RTHOOK(17);
				F1245_11483(RTCW(loc4), loc1);
				RTHOOK(18);
				loc2++;
				RTHOOK(19);
				if ((EIF_BOOLEAN) (loc2 <= loc3)) {
					RTHOOK(20);
					loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7739[Dtype(RTCW(arg1))-805])(arg1, loc2));
				}
			} else {
				RTHOOK(21);
				F1245_11483(RTCW(loc4), loc1);
				RTHOOK(22);
				loc2++;
				RTHOOK(23);
				if ((EIF_BOOLEAN) (loc2 <= loc3)) {
					RTHOOK(24);
					loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7739[Dtype(RTCW(arg1))-805])(arg1, loc2));
					for (;;) {
						RTHOOK(25);
						tb1 = '\01';
						if (!(EIF_BOOLEAN) (loc2 > loc3)) {
							tb2 = EIF_TEST(isdigit(loc1));
							tb1 = (EIF_BOOLEAN) !tb2;
						}
						if (tb1) break;
						RTHOOK(26);
						F1245_11483(RTCW(loc4), loc1);
						RTHOOK(27);
						loc2++;
						RTHOOK(28);
						if ((EIF_BOOLEAN) (loc2 <= loc3)) {
							RTHOOK(29);
							loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7739[Dtype(RTCW(arg1))-805])(arg1, loc2));
						}
					}
				}
			}
		}
	}
	RTHOOK(30);
	if ((EIF_BOOLEAN) (loc2 > loc3)) {
	} else {
		RTHOOK(31);
		if (Result) {
			RTHOOK(32);
			if ((EIF_BOOLEAN)(loc1 == (EIF_CHARACTER_8) '.')) {
				RTHOOK(33);
				F1245_11483(RTCW(loc4), loc1);
				RTHOOK(34);
				loc2++;
				RTHOOK(35);
				loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7739[Dtype(RTCW(arg1))-805])(arg1, loc2));
				RTHOOK(36);
				tb2 = EIF_TEST(isdigit(loc1));
				if (tb2) {
					for (;;) {
						RTHOOK(37);
						tb2 = '\01';
						if (!(EIF_BOOLEAN) (loc2 > loc3)) {
							tb3 = EIF_TEST(isdigit(loc1));
							tb2 = (EIF_BOOLEAN) !tb3;
						}
						if (tb2) break;
						RTHOOK(38);
						F1245_11483(RTCW(loc4), loc1);
						RTHOOK(39);
						loc2++;
						RTHOOK(40);
						if ((EIF_BOOLEAN) (loc2 <= loc3)) {
							RTHOOK(41);
							loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7739[Dtype(RTCW(arg1))-805])(arg1, loc2));
						}
					}
				} else {
					RTHOOK(42);
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				}
			}
		}
		RTHOOK(43);
		if (Result) {
			RTHOOK(44);
			if (F114_1882(Current, loc1)) {
				RTHOOK(45);
				F1245_11483(RTCW(loc4), loc1);
				RTHOOK(46);
				loc2++;
				RTHOOK(47);
				loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7739[Dtype(RTCW(arg1))-805])(arg1, loc2));
				RTHOOK(48);
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == (EIF_CHARACTER_8) '+') || (EIF_BOOLEAN)(loc1 == (EIF_CHARACTER_8) '-'))) {
					RTHOOK(49);
					F1245_11483(RTCW(loc4), loc1);
					RTHOOK(50);
					loc2++;
					RTHOOK(51);
					if ((EIF_BOOLEAN) (loc2 <= loc3)) {
						RTHOOK(52);
						loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7739[Dtype(RTCW(arg1))-805])(arg1, loc2));
					}
				}
				RTHOOK(53);
				tb3 = EIF_TEST(isdigit(loc1));
				if (tb3) {
					for (;;) {
						RTHOOK(54);
						tb3 = '\01';
						if (!(EIF_BOOLEAN) (loc2 > loc3)) {
							tb4 = EIF_TEST(isdigit(loc1));
							tb3 = (EIF_BOOLEAN) !tb4;
						}
						if (tb3) break;
						RTHOOK(55);
						F1245_11483(RTCW(loc4), loc1);
						RTHOOK(56);
						loc2++;
						RTHOOK(57);
						if ((EIF_BOOLEAN) (loc2 <= loc3)) {
							RTHOOK(58);
							loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7739[Dtype(RTCW(arg1))-805])(arg1, loc2));
						}
					}
				} else {
					RTHOOK(59);
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				}
			}
		}
		RTHOOK(60);
		if (Result) {
			for (;;) {
				RTHOOK(61);
				tb4 = '\01';
				if (!(EIF_BOOLEAN) (loc2 > loc3)) {
					tb5 = eif_builtin_CHARACTER_8_is_space__c1_b(loc1);
					tb4 = (EIF_BOOLEAN) !tb5;
				}
				if (tb4) break;
				RTHOOK(62);
				F1245_11483(RTCW(loc4), loc1);
				RTHOOK(63);
				loc2++;
				RTHOOK(64);
				if ((EIF_BOOLEAN) (loc2 <= loc3)) {
					RTHOOK(65);
					loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7739[Dtype(RTCW(arg1))-805])(arg1, loc2));
				}
			}
			RTHOOK(66);
			Result = '\0';
			if ((EIF_BOOLEAN) (loc2 > loc3)) {
				tb5 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R9824[Dtype(RTCW(loc4))-1243])(loc4, arg1);
				Result = tb5;
			}
		}
	}
	RTHOOK(67);
	RTLE;
	RTEE;
	return Result;
}

/* {JSON_PARSER}.is_substring_valid_unicode */
EIF_BOOLEAN F1768_19786 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_substring_valid_unicode", 1767, Current, 1, 3, 25889);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tb2 = '\0';
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) (arg3 - arg2) == ((EIF_INTEGER_32) 5L))) {
		tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7739[Dtype(RTCW(arg1))-805])(arg1, arg2));
		tb2 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\\');
	}
	if (tb2) {
		tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7739[Dtype(RTCW(arg1))-805])(arg1, (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L))));
		tb1 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) 'u');
	}
	if (tb1) {
		RTHOOK(2);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(3);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 2L));
		for (;;) {
			RTHOOK(4);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > arg3) || (EIF_BOOLEAN)(Result == (EIF_BOOLEAN) 0))) break;
			RTHOOK(5);
			tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7739[Dtype(RTCW(arg1))-805])(arg1, loc1));
			switch (tc1) {
				case (EIF_CHARACTER_8) '0':
				case (EIF_CHARACTER_8) '1':
				case (EIF_CHARACTER_8) '2':
				case (EIF_CHARACTER_8) '3':
				case (EIF_CHARACTER_8) '4':
				case (EIF_CHARACTER_8) '5':
				case (EIF_CHARACTER_8) '6':
				case (EIF_CHARACTER_8) '7':
				case (EIF_CHARACTER_8) '8':
				case (EIF_CHARACTER_8) '9':
				case (EIF_CHARACTER_8) 'A':
				case (EIF_CHARACTER_8) 'B':
				case (EIF_CHARACTER_8) 'C':
				case (EIF_CHARACTER_8) 'D':
				case (EIF_CHARACTER_8) 'E':
				case (EIF_CHARACTER_8) 'F':
				case (EIF_CHARACTER_8) 'a':
				case (EIF_CHARACTER_8) 'b':
				case (EIF_CHARACTER_8) 'c':
				case (EIF_CHARACTER_8) 'd':
				case (EIF_CHARACTER_8) 'e':
				case (EIF_CHARACTER_8) 'f':
					break;
				default:
					RTHOOK(6);
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					break;
			}
			RTHOOK(7);
			loc1++;
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {JSON_PARSER}.extra_elements */
EIF_BOOLEAN F1768_19787 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("extra_elements", 1767, Current, 1, 0, 25890);
	RTGC;
	RTHOOK(1);
	if (F115_1892(Current)) {
		RTHOOK(2);
		F115_1887(Current);
	}
	RTHOOK(3);
	loc1 = F115_1895(Current);
	for (;;) {
		RTHOOK(4);
		tb1 = '\01';
		if (!(EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 != (EIF_CHARACTER_8) ' ') || (EIF_BOOLEAN)(loc1 != (EIF_CHARACTER_8) '\015')) || (EIF_BOOLEAN)(loc1 != (EIF_CHARACTER_8) '\000')) || (EIF_BOOLEAN)(loc1 != (EIF_CHARACTER_8) '\011')) || (EIF_BOOLEAN)(loc1 != (EIF_CHARACTER_8) '\012'))) {
			tb1 = (EIF_BOOLEAN) !F115_1892(Current);
		}
		if (tb1) break;
		RTHOOK(5);
		F115_1887(Current);
		RTHOOK(6);
		loc1 = F115_1895(Current);
	}
	RTHOOK(7);
	RTHOOK(8);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) F115_1892(Current);
}

/* {JSON_PARSER}.is_valid_start_symbol */
EIF_BOOLEAN F1768_19788 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("is_valid_start_symbol", 1767, Current, 1, 0, 25891);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_2_);
		tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		RTHOOK(2);
		Result = '\01';
		tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7739[Dtype(loc1)-805])(loc1, ((EIF_INTEGER_32) 1L)));
		if (!(EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '{')) {
			tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7739[Dtype(loc1)-805])(loc1, ((EIF_INTEGER_32) 1L)));
			Result = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '[');
		}
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {JSON_PARSER}.false_id */

EIF_REFERENCE F1768_19789 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (688,RTMS_EX_H("false",5,1635280741));
}

/* {JSON_PARSER}.true_id */

EIF_REFERENCE F1768_19790 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (689,RTMS_EX_H("true",4,1953658213));
}

/* {JSON_PARSER}.null_id */

EIF_REFERENCE F1768_19791 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (687,RTMS_EX_H("null",4,1853189228));
}

/* {JSON_PARSER}.initialize_buffers */
void F1768_19795 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("initialize_buffers", 1767, Current, 0, 0, 25898);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_new_type(1244, 0).id);
	tr2 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_1_1_0_2_);
	ti4_2 = F1768_19762(Current);
	ti4_1 = eif_min_int32 (ti4_1,ti4_2);
	F1243_11356(RTCW(tr1), ti4_1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTLNSMART(eif_new_type(1244, 0).id);
	ti4_1 = F1768_19763(Current);
	F1243_11356(RTCW(tr1), ti4_1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	tr1 = RTLNSMART(eif_new_type(1244, 0).id);
	ti4_1 = F1768_19763(Current);
	F1243_11356(RTCW(tr1), ti4_1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {JSON_PARSER}.free_buffers */
void F1768_19796 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("free_buffers", 1767, Current, 1, 0, 25899);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1244, 0x00).id, 1244, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1237_11059(RTCW(loc1));
	RTHOOK(2);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) loc1;
	RTHOOK(3);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) loc1;
	RTHOOK(4);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) loc1;
	RTHOOK(5);
	RTLE;
	RTEE;
}

void EIF_Minit1046 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
