/*
 * Code for class I18N_FORMATTING_ACTIONS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i11011.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_FORMATTING_ACTIONS}.hour_12_padded_action */
EIF_REFERENCE F1733_18646 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("hour_12_padded_action", 1732, Current, 0, 1, 24789);
	RTGC;
	RTHOOK(1);
	ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 12L))) {
		RTHOOK(2);
		tr1 = RTOUCR(606,F158_2246, (Current));
		ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
		Result = F20_157(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 12L)), ((EIF_INTEGER_32) 2L));
	} else {
		RTHOOK(3);
		tr1 = RTOUCR(606,F158_2246, (Current));
		ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
		Result = F20_157(RTCW(tr1), ti4_1, ((EIF_INTEGER_32) 2L));
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_FORMATTING_ACTIONS}.hour_12_action */
EIF_REFERENCE F1733_18647 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("hour_12_action", 1732, Current, 0, 1, 24790);
	RTGC;
	RTHOOK(1);
	ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 12L))) {
		RTHOOK(2);
		Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
		ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
		tr1 = eif_out__i4_s1((EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 12L)));
		F1242_11265(RTCW(Result), tr1);
	} else {
		RTHOOK(3);
		Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
		ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
		tr1 = eif_out__i4_s1(ti4_1);
		F1242_11265(RTCW(Result), tr1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_FORMATTING_ACTIONS}.hour_24_action */
EIF_REFERENCE F1733_18648 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("hour_24_action", 1732, Current, 0, 1, 24791);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
	tr1 = eif_out__i4_s1(ti4_1);
	F1242_11265(RTCW(Result), tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_FORMATTING_ACTIONS}.minutes_action */
EIF_REFERENCE F1733_18650 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("minutes_action", 1732, Current, 0, 1, 24793);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
	tr1 = eif_out__i4_s1(ti4_1);
	F1242_11265(RTCW(Result), tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_FORMATTING_ACTIONS}.minutes_padded_action */
EIF_REFERENCE F1733_18651 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("minutes_padded_action", 1732, Current, 0, 1, 24794);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(606,F158_2246, (Current));
	ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
	Result = F20_157(RTCW(tr1), ti4_1, ((EIF_INTEGER_32) 2L));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_FORMATTING_ACTIONS}.seconds_action */
EIF_REFERENCE F1733_18652 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("seconds_action", 1732, Current, 0, 1, 24795);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
	tr1 = eif_out__i4_s1(ti4_1);
	F1242_11265(RTCW(Result), tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_FORMATTING_ACTIONS}.seconds_padded_action */
EIF_REFERENCE F1733_18653 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("seconds_padded_action", 1732, Current, 0, 1, 24796);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(606,F158_2246, (Current));
	ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
	Result = F20_157(RTCW(tr1), ti4_1, ((EIF_INTEGER_32) 2L));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_FORMATTING_ACTIONS}.am_pm_1_action */
EIF_REFERENCE F1733_18654 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("am_pm_1_action", 1732, Current, 0, 1, 24797);
	RTGC;
	RTHOOK(1);
	ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 12L))) {
		RTHOOK(2);
		Result = RTMS32_EX_H("p\000\000\000",1,112);
	} else {
		RTHOOK(3);
		Result = RTMS32_EX_H("m\000\000\000",1,109);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_FORMATTING_ACTIONS}.am_pm_lowercase_action */
EIF_REFERENCE F1733_18655 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Result);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("am_pm_lowercase_action", 1732, Current, 0, 2, 24798);
	RTGC;
	RTHOOK(1);
	ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 12L))) {
		RTHOOK(2);
		Result = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_27_);
	} else {
		RTHOOK(3);
		Result = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_26_);
	}
	RTHOOK(4);
	tb1 = F1240_11221(RTCW(Result));
	if (tb1) {
		RTHOOK(5);
		F1242_11345(RTCW(Result));
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_FORMATTING_ACTIONS}.am_pm_uppercase_action */
EIF_REFERENCE F1733_18656 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Result);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("am_pm_uppercase_action", 1732, Current, 0, 2, 24799);
	RTGC;
	RTHOOK(1);
	ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 12L))) {
		RTHOOK(2);
		Result = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_27_);
	} else {
		RTHOOK(3);
		Result = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_26_);
	}
	RTHOOK(4);
	tb1 = F1240_11221(RTCW(Result));
	if (tb1) {
		RTHOOK(5);
		F1242_11346(RTCW(Result));
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_FORMATTING_ACTIONS}.day_of_month_action */
EIF_REFERENCE F1733_18657 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("day_of_month_action", 1732, Current, 0, 1, 24800);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
	tr1 = eif_out__i4_s1(ti4_1);
	F1242_11265(RTCW(Result), tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_FORMATTING_ACTIONS}.day_of_month_padded_action */
EIF_REFERENCE F1733_18658 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("day_of_month_padded_action", 1732, Current, 0, 1, 24801);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(606,F158_2246, (Current));
	ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
	Result = F20_157(RTCW(tr1), ti4_1, ((EIF_INTEGER_32) 2L));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_FORMATTING_ACTIONS}.abbreviated_day_name_action */
EIF_REFERENCE F1733_18659 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("abbreviated_day_name_action", 1732, Current, 0, 2, 24802);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_32_);
	ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
	Result = F938_9014(RTCW(tr1), ti4_1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_FORMATTING_ACTIONS}.day_name_action */
EIF_REFERENCE F1733_18660 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("day_name_action", 1732, Current, 0, 2, 24803);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_30_);
	ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
	Result = F938_9014(RTCW(tr1), ti4_1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_FORMATTING_ACTIONS}.day_of_year_action */
EIF_REFERENCE F1733_18661 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("day_of_year_action", 1732, Current, 0, 1, 24804);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(606,F158_2246, (Current));
	ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
	Result = F20_157(RTCW(tr1), ti4_1, ((EIF_INTEGER_32) 3L));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_FORMATTING_ACTIONS}.day_of_week_action */
EIF_REFERENCE F1733_18662 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("day_of_week_action", 1732, Current, 0, 1, 24805);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
	tr1 = eif_out__i4_s1((EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
	F1242_11265(RTCW(Result), tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_FORMATTING_ACTIONS}.day_of_week_0_action */
EIF_REFERENCE F1733_18663 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("day_of_week_0_action", 1732, Current, 0, 1, 24806);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
	tr1 = eif_out__i4_s1(ti4_1);
	F1242_11265(RTCW(Result), tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_FORMATTING_ACTIONS}.month_action */
EIF_REFERENCE F1733_18664 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("month_action", 1732, Current, 0, 1, 24807);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
	tr1 = eif_out__i4_s1(ti4_1);
	F1242_11265(RTCW(Result), tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_FORMATTING_ACTIONS}.month_padded_action */
EIF_REFERENCE F1733_18665 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("month_padded_action", 1732, Current, 0, 1, 24808);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(606,F158_2246, (Current));
	ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
	Result = F20_157(RTCW(tr1), ti4_1, ((EIF_INTEGER_32) 2L));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_FORMATTING_ACTIONS}.abbreviated_month_name_action */
EIF_REFERENCE F1733_18666 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("abbreviated_month_name_action", 1732, Current, 0, 2, 24809);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_33_);
	ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
	Result = F938_9014(RTCW(tr1), ti4_1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_FORMATTING_ACTIONS}.month_name_action */
EIF_REFERENCE F1733_18667 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("month_name_action", 1732, Current, 0, 2, 24810);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_31_);
	ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
	Result = F938_9014(RTCW(tr1), ti4_1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_FORMATTING_ACTIONS}.century_number_action */
EIF_REFERENCE F1733_18668 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("century_number_action", 1732, Current, 0, 1, 24811);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
	tr1 = eif_out__i4_s1((EIF_INTEGER_32) (ti4_1 / ((EIF_INTEGER_32) 100L)));
	F1242_11265(RTCW(Result), tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_FORMATTING_ACTIONS}.week_number_iso_action */
EIF_REFERENCE F1733_18669 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("week_number_iso_action", 1732, Current, 0, 1, 24812);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(606,F158_2246, (Current));
	ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
	Result = F20_157(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)), ((EIF_INTEGER_32) 2L));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_FORMATTING_ACTIONS}.week_number_sunday_as_first_action */
EIF_REFERENCE F1733_18670 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("week_number_sunday_as_first_action", 1732, Current, 0, 1, 24813);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(606,F158_2246, (Current));
	ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
	Result = F20_157(RTCW(tr1), ti4_1, ((EIF_INTEGER_32) 2L));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_FORMATTING_ACTIONS}.week_number_monday_as_first_action */
EIF_REFERENCE F1733_18671 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("week_number_monday_as_first_action", 1732, Current, 0, 1, 24814);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(606,F158_2246, (Current));
	ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
	Result = F20_157(RTCW(tr1), ti4_1, ((EIF_INTEGER_32) 2L));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_FORMATTING_ACTIONS}.iso_year_with_century_action */
EIF_REFERENCE F1733_18672 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("iso_year_with_century_action", 1732, Current, 0, 1, 24815);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
	tr1 = eif_out__i4_s1(ti4_1);
	F1242_11265(RTCW(Result), tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_FORMATTING_ACTIONS}.iso_year_without_century_action */
EIF_REFERENCE F1733_18673 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("iso_year_without_century_action", 1732, Current, 0, 1, 24785);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(606,F158_2246, (Current));
	ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
	Result = F20_157(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 % ((EIF_INTEGER_32) 100L)), ((EIF_INTEGER_32) 2L));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_FORMATTING_ACTIONS}.year_1_action */
EIF_REFERENCE F1733_18674 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("year_1_action", 1732, Current, 0, 1, 24786);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(606,F158_2246, (Current));
	ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
	Result = F20_157(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 % ((EIF_INTEGER_32) 10L)), ((EIF_INTEGER_32) 1L));
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_FORMATTING_ACTIONS}.year_2_action */
EIF_REFERENCE F1733_18675 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("year_2_action", 1732, Current, 0, 1, 24787);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(606,F158_2246, (Current));
	ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
	Result = F20_157(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 % ((EIF_INTEGER_32) 100L)), ((EIF_INTEGER_32) 2L));
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_FORMATTING_ACTIONS}.year_4_action */
EIF_REFERENCE F1733_18676 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("year_4_action", 1732, Current, 0, 1, 24788);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = (RTNA((RTCW(arg1))), ((EIF_INTEGER_32) 0));
	tr1 = eif_out__i4_s1(ti4_1);
	F1242_11265(RTCW(Result), tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit1011 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
