
#ifndef _C21_co1018_
#define _C21_co1018_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1740_18828(EIF_REFERENCE);
extern void F1740_18830(EIF_REFERENCE, EIF_REFERENCE);
extern void F1740_18831(EIF_REFERENCE);
extern void EIF_Minit1018(void);
extern EIF_REFERENCE F1304_12634(EIF_REFERENCE);
extern void F1304_12619(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F273_4627(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1237_11118(EIF_REFERENCE);
extern long O14751[];
extern long O14752[];
extern long O14754[];
extern long O14749[];

#ifdef __cplusplus
}
#endif

#endif
