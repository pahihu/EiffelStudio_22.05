/*
 * Code for class ENCODING_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "en1022.h"
#include <string.h>
#include <iconv.h>
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F1744_18927
static EIF_POINTER inline_F1744_18927 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32* arg4, EIF_INTEGER_32* arg5)
{
	size_t insize = 0;
iconv_t cd = (iconv_t) arg1;
size_t nconv, avail, alloc;
char *res, *tres, *wrptr, *inptr;
char **l_inptr = &inptr;

insize = (size_t)arg3;
alloc = avail = insize + insize/4;

if (!(res = malloc(alloc))) {
	*arg5 = 1;
	return NULL;
} else {
	*arg5 = 0;
	wrptr = res;   /* duplicate pointers because they */
	inptr = arg2; /* get modified by iconv */
	
	/* Reset the descriptor to intial state. */
	iconv (cd, NULL, 0, NULL, 0);
	
	do {				
		nconv = iconv (cd, l_inptr, &insize, &wrptr, &avail); /*convertions */
		
		if (nconv == (size_t)(-1)) {
			if (errno == E2BIG) { /* need more room for result */							
				tres = realloc(res, alloc += 20);
				avail += 20;
				if (!tres) {
					*arg5 = 2;
					break;
				}
				wrptr = tres + (wrptr - res);
				res = tres;
			}
			else if (errno == EILSEQ) {
				*arg5 = 4;
				break;
			}
			else if (errno == EINVAL){
				*arg5 = 5;
				break;
			}
			else if (errno == EBADF){
				*arg5 = 6;
				break;
			}
			else{
				*arg5 = 7;
				break;
			}
		}
	} while (insize);
	
	*arg4 = alloc - avail;
	
	return res;
}
	;
}
#define INLINE_F1744_18927
#endif
#ifndef INLINE_F1744_18926
static EIF_POINTER inline_F1744_18926 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32* arg3, EIF_BOOLEAN* arg4)
{
	iconv_t cd;

cd = iconv_open (arg2, arg1);
if (cd == (iconv_t)(-1)) {
	*arg3 = 3;
	return NULL;
}
*arg4 = EIF_TRUE;
return cd;
	;
}
#define INLINE_F1744_18926
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ENCODING_IMP}.convert_to */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F1744_18905 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER EIF_VOLATILE loc3 = (EIF_POINTER) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE EIF_VOLATILE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc6 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc7 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc8 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN EIF_VOLATILE loc9 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_POINTER  EIF_VOLATILE tp1;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_INTEGER_32  EIF_VOLATILE ti4_1;
	EIF_NATURAL_32  EIF_VOLATILE tu4_1;
	EIF_CHARACTER_32  EIF_VOLATILE tw1;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_BOOLEAN  EIF_VOLATILE tb2;
	EIF_BOOLEAN  EIF_VOLATILE tb3;
	RTLD;
	RTXD;
	
	RTLI(12);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc5);
	RTLR(3,arg2);
	RTLR(4,tr1);
	RTLR(5,arg3);
	RTLR(6,loc1);
	RTLR(7,loc6);
	RTLR(8,loc10);
	RTLR(9,loc11);
	RTLR(10,loc12);
	RTLR(11,saved_except);
	RTLIU(12);
	RTXSLS;
	
	RTEAA("convert_to", 1743, Current, 12, 3, 25050);
	RTGC;
	RTE_T
	RTHOOK(1);
	if ((EIF_BOOLEAN) !loc9) {
		RTHOOK(2);
		loc7 = '\01';
		if (!F1744_18912(Current, arg1)) {
			tb1 = '\0';
			if ((EIF_BOOLEAN) !RTOUCB(EIF_BOOLEAN,343,F294_4915, (Current))) {
				tb1 = (EIF_BOOLEAN) !F1744_18913(Current, arg1);
			}
			loc7 = tb1;
		}
		RTHOOK(3);
		if (F1744_18911(Current, arg1)) {
			RTHOOK(4);
			tr1 = F1237_11118(RTCW(arg2));
			loc5 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
			RTHOOK(5);
			tr1 = RTOUCR(344,F1744_18915, (Current));
			tb1 = F44_645(RTCW(tr1), arg1, arg3);
			if ((EIF_BOOLEAN) !tb1) {
				RTHOOK(6);
				if (((loc7) != (RTOUCB(EIF_BOOLEAN,343,F294_4915, (Current))))) {
					RTHOOK(7);
					tw1 = RTOUCB(EIF_CHARACTER_32,345,F1744_18922, (Current));
				} else {
					RTHOOK(8);
					tw1 = RTOUCB(EIF_CHARACTER_32,346,F1744_18923, (Current));
				}
				F1242_11294(RTCW(loc5), tw1);
			}
			RTHOOK(9);
			loc1 = F1744_18921(Current, loc5);
			RTHOOK(10);
			loc2 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 * ((EIF_INTEGER_32) 4L));
		} else {
			RTHOOK(11);
			if (F1744_18910(Current, arg1)) {
				RTHOOK(12);
				tr1 = F1237_11118(RTCW(arg2));
				loc5 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
				RTHOOK(13);
				tr1 = RTOUCR(344,F1744_18915, (Current));
				tb1 = F44_645(RTCW(tr1), arg1, arg3);
				if ((EIF_BOOLEAN) !tb1) {
					RTHOOK(14);
					if (((loc7) != (RTOUCB(EIF_BOOLEAN,343,F294_4915, (Current))))) {
						RTHOOK(15);
						tw1 = RTOUCB(EIF_CHARACTER_32,345,F1744_18922, (Current));
					} else {
						RTHOOK(16);
						tw1 = RTOUCB(EIF_CHARACTER_32,347,F1744_18924, (Current));
					}
					F1242_11294(RTCW(loc5), tw1);
				}
				RTHOOK(17);
				loc1 = F294_4905(Current, loc5);
				RTHOOK(18);
				loc2 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
				loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 * ((EIF_INTEGER_32) 2L));
			} else {
				RTHOOK(19);
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R9617[Dtype(RTCW(arg2))-1240])(arg2);
				if (tb1) {
					RTHOOK(20);
					loc6 = F1237_11112(RTCW(arg2));
				} else {
					RTHOOK(21);
					tr1 = RTLNS(eif_new_type(85, 0x00).id, 85, _OBJSIZ_0_0_0_0_0_0_0_0_);
					loc6 = F86_1480(RTCW(tr1), arg2);
				}
				RTHOOK(22);
				loc1 = F294_4904(Current, loc6);
				RTHOOK(23);
				loc2 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
			}
		}
		RTHOOK(24);
		tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
		loc3 = F1744_18916(Current, arg1, arg3, tp1, loc2, (EIF_INTEGER_32 *) &(loc4), (EIF_INTEGER_32 *) &(loc8));
		RTHOOK(25);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc8 == ((EIF_INTEGER_32) 0L))) {
			{
				/* INLINED CODE (ANY.default_pointer) */
				tp1 = (EIF_POINTER)  0;
				/* END INLINED CODE */
			}
			tb1 = (EIF_BOOLEAN)(loc3 != tp1);
		}
		if (tb1) {
			RTHOOK(26);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			RTHOOK(27);
			if (F1744_18911(Current, arg3)) {
				RTHOOK(28);
				loc5 = F294_4908(Current, loc3, loc4);
				RTHOOK(29);
				tb1 = F730_8337(RTCW(loc5));
				if ((EIF_BOOLEAN) !tb1) {
					RTHOOK(30);
					tu4_1 = F1242_11273(RTCW(loc5), ((EIF_INTEGER_32) 1L));
					if (F1744_18919(Current, tu4_1)) {
						RTHOOK(31);
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
						tr1 = F1242_11351(RTCW(loc5), ((EIF_INTEGER_32) 2L), ti4_1);
						loc5 = (EIF_REFERENCE) tr1;
						RTHOOK(32);
						tb1 = '\01';
						tb2 = '\0';
						if (F1744_18912(Current, arg3)) {
							tb2 = RTOUCB(EIF_BOOLEAN,343,F294_4915, (Current));
						}
						if (!tb2) {
							tb2 = '\0';
							if (F1744_18913(Current, arg3)) {
								tb2 = (EIF_BOOLEAN) !RTOUCB(EIF_BOOLEAN,343,F294_4915, (Current));
							}
							tb1 = tb2;
						}
						if (tb1) {
							RTHOOK(33);
							tr1 = F294_4913(Current, loc5);
							loc5 = (EIF_REFERENCE) tr1;
						}
					} else {
						RTHOOK(34);
						tu4_1 = F1242_11273(RTCW(loc5), ((EIF_INTEGER_32) 1L));
						if (F1744_18920(Current, tu4_1)) {
							RTHOOK(35);
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
							tr1 = F1242_11351(RTCW(loc5), ((EIF_INTEGER_32) 2L), ti4_1);
							loc5 = (EIF_REFERENCE) tr1;
							RTHOOK(36);
							tb1 = '\01';
							tb2 = '\01';
							tb3 = '\0';
							if (F1744_18913(Current, arg3)) {
								tb3 = RTOUCB(EIF_BOOLEAN,343,F294_4915, (Current));
							}
							if (!tb3) {
								tb3 = '\0';
								if (F1744_18912(Current, arg3)) {
									tb3 = (EIF_BOOLEAN) !RTOUCB(EIF_BOOLEAN,343,F294_4915, (Current));
								}
								tb2 = tb3;
							}
							if (!tb2) {
								tb1 = (EIF_BOOLEAN) !F1744_18914(Current, arg3);
							}
							if (tb1) {
								RTHOOK(37);
								tr1 = F294_4913(Current, loc5);
								loc5 = (EIF_REFERENCE) tr1;
							}
						}
					}
				}
				RTHOOK(38);
				loc10 = (EIF_REFERENCE) loc5;
			} else {
				RTHOOK(39);
				if (F1744_18910(Current, arg3)) {
					RTHOOK(40);
					loc5 = F294_4907(Current, loc3, loc4);
					RTHOOK(41);
					tb1 = F730_8337(RTCW(loc5));
					if ((EIF_BOOLEAN) !tb1) {
						RTHOOK(42);
						tu4_1 = F1242_11273(RTCW(loc5), ((EIF_INTEGER_32) 1L));
						if (F1744_18919(Current, tu4_1)) {
							RTHOOK(43);
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
							tr1 = F1242_11351(RTCW(loc5), ((EIF_INTEGER_32) 2L), ti4_1);
							loc5 = (EIF_REFERENCE) tr1;
							RTHOOK(44);
							tb1 = '\01';
							tb2 = '\0';
							if (F1744_18912(Current, arg3)) {
								tb2 = RTOUCB(EIF_BOOLEAN,343,F294_4915, (Current));
							}
							if (!tb2) {
								tb2 = '\0';
								if (F1744_18913(Current, arg3)) {
									tb2 = (EIF_BOOLEAN) !RTOUCB(EIF_BOOLEAN,343,F294_4915, (Current));
								}
								tb1 = tb2;
							}
							if (tb1) {
								RTHOOK(45);
								tr1 = F294_4914(Current, loc5);
								loc5 = (EIF_REFERENCE) tr1;
							}
						} else {
							RTHOOK(46);
							tu4_1 = F1242_11273(RTCW(loc5), ((EIF_INTEGER_32) 1L));
							if (F1744_18920(Current, tu4_1)) {
								RTHOOK(47);
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
								tr1 = F1242_11351(RTCW(loc5), ((EIF_INTEGER_32) 2L), ti4_1);
								loc5 = (EIF_REFERENCE) tr1;
								RTHOOK(48);
								tb1 = '\01';
								tb2 = '\01';
								tb3 = '\0';
								if (F1744_18913(Current, arg3)) {
									tb3 = RTOUCB(EIF_BOOLEAN,343,F294_4915, (Current));
								}
								if (!tb3) {
									tb3 = '\0';
									if (F1744_18912(Current, arg3)) {
										tb3 = (EIF_BOOLEAN) !RTOUCB(EIF_BOOLEAN,343,F294_4915, (Current));
									}
									tb2 = tb3;
								}
								if (!tb2) {
									tb1 = (EIF_BOOLEAN) !F1744_18914(Current, arg3);
								}
								if (tb1) {
									RTHOOK(49);
									tr1 = F294_4914(Current, loc5);
									loc5 = (EIF_REFERENCE) tr1;
								}
							}
						}
					}
					RTHOOK(50);
					*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					RTHOOK(51);
					loc10 = (EIF_REFERENCE) loc5;
				} else {
					RTHOOK(52);
					loc10 = F294_4906(Current, loc3, loc4);
				}
			}
			RTHOOK(53);
			RTAR(Current, loc10);
			*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc10;
		} else {
			RTHOOK(54);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
		RTHOOK(55);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(loc3 != tp1)) {
			RTHOOK(56);
			free(loc3);
		}
	}
	RTE_E
	RTXSC;
	RTHOOK(57);
	loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(58);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc3 != tp1)) {
		RTHOOK(59);
		free(loc3);
	}
	RTHOOK(60);
	loc11 = F245_4244(RTCV(RTOUCR(23,F377_5894, (Current))));
	RTHOOK(61);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc11 != NULL)) {
		tr1 = F379_5929(RTCW(loc11));
		loc12 = tr1;
		loc12 = RTRV(eif_new_type(388, 0x00),loc12);
		tb1 = EIF_TEST(loc12);
	}
	if (tb1) {
		RTHOOK(62);
		RTER;
	}
	/* NOTREACHED */
	RTE_EE
	RTHOOK(63);
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {ENCODING_IMP}.is_code_page_valid */
EIF_BOOLEAN F1744_18906 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_code_page_valid", 1743, Current, 0, 1, 25051);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R9618[Dtype(RTCW(arg1))-1240])(arg1);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) F1744_18909(Current, arg1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) 0;
}

/* {ENCODING_IMP}.is_code_page_convertible */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
EIF_BOOLEAN F1744_18907 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	RTED;
	EIF_INTEGER_32 EIF_VOLATILE loc1 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN EIF_VOLATILE loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_VOLATILE EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	RTXD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,saved_except);
	RTLIU(5);
	RTXSLS;
	
	RTEAA("is_code_page_convertible", 1743, Current, 2, 2, 25052);
	RTGC;
	RTE_T
	RTHOOK(1);
	if ((EIF_BOOLEAN) !loc2) {
		RTHOOK(2);
		Result = F1744_18917(Current, arg1, arg2, (EIF_INTEGER_32 *) &(loc1));
		RTHOOK(3);
		if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
			RTHOOK(4);
			tr1 = F1744_18925(Current, loc1);
			F379_5921(RTCW(tr1));
		}
	}
	RTE_E
	RTXSC;
	RTHOOK(5);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(6);
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(7);
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTHOOK(8);
	RTEOK;
	RTLE;
	return Result;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {ENCODING_IMP}.is_known_code_page */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
EIF_BOOLEAN F1744_18909 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTED;
	EIF_INTEGER_32 EIF_VOLATILE loc1 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN EIF_VOLATILE loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_VOLATILE EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	RTXD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,saved_except);
	RTLIU(4);
	RTXSLS;
	
	RTEAA("is_known_code_page", 1743, Current, 2, 1, 25054);
	RTGC;
	RTE_T
	RTHOOK(1);
	if ((EIF_BOOLEAN) !loc2) {
		RTHOOK(2);
		tr1 = RTOUCR(267,F71_1255, (Current));
		tb1 = F1243_11382(RTCW(arg1), tr1);
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(3);
			Result = F1744_18918(Current, arg1, (EIF_INTEGER_32 *) &(loc1));
			RTHOOK(4);
			if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
				RTHOOK(5);
				tr1 = F1744_18925(Current, loc1);
				F379_5921(RTCW(tr1));
			}
		} else {
			RTHOOK(6);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	RTE_E
	RTXSC;
	RTHOOK(7);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(8);
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(9);
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTHOOK(10);
	RTEOK;
	RTLE;
	return Result;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {ENCODING_IMP}.is_two_byte_code_page */
EIF_BOOLEAN F1744_18910 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("is_two_byte_code_page", 1743, Current, 0, 1, 25032);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(348,F192_3527, (Current));
	Result = F806_8444(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {ENCODING_IMP}.is_four_byte_code_page */
EIF_BOOLEAN F1744_18911 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("is_four_byte_code_page", 1743, Current, 0, 1, 25033);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(349,F192_3528, (Current));
	Result = F806_8444(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {ENCODING_IMP}.is_big_endian_code_page */
EIF_BOOLEAN F1744_18912 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("is_big_endian_code_page", 1743, Current, 0, 1, 25034);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(350,F192_3530, (Current));
	Result = F806_8444(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {ENCODING_IMP}.is_little_endian_code_page */
EIF_BOOLEAN F1744_18913 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("is_little_endian_code_page", 1743, Current, 0, 1, 25035);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(351,F192_3529, (Current));
	Result = F806_8444(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {ENCODING_IMP}.is_endianness_specified */
EIF_BOOLEAN F1744_18914 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_endianness_specified", 1743, Current, 0, 1, 25036);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	if (!F1744_18912(Current, arg1)) {
		Result = F1744_18913(Current, arg1);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {ENCODING_IMP}.descriptor_cache */
static EIF_REFERENCE F1744_18915_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(344)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("descriptor_cache", 1743, Current, 0, 0, 25037);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(43, 0x00).id, 43, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F44_639(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1744_18915 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(344,F1744_18915_body,(Current));
}

/* {ENCODING_IMP}.iconv_imp */
EIF_POINTER F1744_18916 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_POINTER arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32* arg5, EIF_INTEGER_32* arg6)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("iconv_imp", 1743, Current, 0, 6, 25038);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(344,F1744_18915, (Current));
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(RTCW(arg1))-1243])(arg1, arg2);
	F44_641(RTCW(tr1), tr2);
	
	RTHOOK(3);
	tp1 = F44_644(RTCV(RTOUCR(344,F1744_18915, (Current))));
	Result = inline_F1744_18927(tp1, arg3, arg4, arg5, arg6);
	RTHOOK(4);
	tr1 = RTOUCR(344,F1744_18915, (Current));
	F44_642(RTCW(tr1), arg1, arg2);
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {ENCODING_IMP}.is_codeset_convertible */
EIF_BOOLEAN F1744_18917 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32* arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,loc1);
	RTLR(6,loc2);
	RTLIU(7);
	
	RTEAA("is_codeset_convertible", 1743, Current, 5, 3, 25039);
	RTGC;
	RTHOOK(1);
	loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R9829[Dtype(RTCW(arg1))-1243])(arg1, arg2);
	RTHOOK(2);
	tr1 = RTOUCR(344,F1744_18915, (Current));
	F44_641(RTCW(tr1), loc3);
	RTHOOK(3);
	tb1 = F44_643(RTCV(RTOUCR(344,F1744_18915, (Current))));
	if (tb1) {
		RTHOOK(4);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		RTHOOK(6);
		loc1 = F294_4904(Current, arg1);
		RTHOOK(7);
		loc2 = F294_4904(Current, arg2);
		RTHOOK(8);
		tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
		tp2 = *(EIF_POINTER *)(RTCW(loc2)+ _PTROFF_0_1_0_1_0_0_);
		loc4 = inline_F1744_18926(tp1, tp2, arg3, (EIF_BOOLEAN *) &(loc5));
		RTHOOK(9);
		if (loc5) {
			RTHOOK(10);
			tr1 = RTOUCR(344,F1744_18915, (Current));
			F44_640(RTCW(tr1), loc4, loc3);
			RTHOOK(11);
			RTHOOK(12);
			RTLE;
			RTEE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	RTHOOK(13);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) 0;
}

/* {ENCODING_IMP}.c_codeset_valid */
EIF_BOOLEAN F1744_18918 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32* arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("c_codeset_valid", 1743, Current, 0, 2, 25040);
	RTGC;
	RTHOOK(1);
	tr1 = RTMS_EX_H("utf-8",5,1953751864);
	Result = F1744_18917(Current, arg1, tr1, arg2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {ENCODING_IMP}.same_endian */
EIF_BOOLEAN F1744_18919 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	RTEAA("same_endian", 1743, Current, 0, 1, 25041);
	RTHOOK(1);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(arg1 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 65279L));
	RTHOOK(2);
	RTEE;
	return Result;
}

/* {ENCODING_IMP}.reverse_endian */
EIF_BOOLEAN F1744_18920 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	RTEAA("reverse_endian", 1743, Current, 0, 1, 25042);
	RTHOOK(1);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 65534L)) || (EIF_BOOLEAN)(arg1 == (EIF_NATURAL_32) ((EIF_INTEGER_64) RTI64C(4294836224))));
	RTHOOK(2);
	RTEE;
	return Result;
}

/* {ENCODING_IMP}.string_32_to_pointer */
EIF_REFERENCE F1744_18921 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("string_32_to_pointer", 1743, Current, 5, 1, 25043);
	RTGC;
	RTHOOK(1);
	loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(2);
	loc4 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9759[Dtype(arg1)-1239]);
	RTHOOK(3);
	Result = RTLNS(eif_new_type(1140, 0x00).id, 1140, _OBJSIZ_0_1_0_1_0_1_1_0_);
	F1141_9694(RTCW(Result), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L)) * ((EIF_INTEGER_32) 4L)));
	RTHOOK(4);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc4 - loc5) + ((EIF_INTEGER_32) 1L));
	RTHOOK(5);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)) * ((EIF_INTEGER_32) 4L));
	RTHOOK(6);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_0_1_0_0_);
	if ((EIF_BOOLEAN) (ti4_1 < loc3)) {
		RTHOOK(7);
		F1141_9784(RTCW(Result), loc3);
	}
	RTHOOK(8);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		RTHOOK(9);
		if ((EIF_BOOLEAN)(loc1 == loc2)) break;
		RTHOOK(10);
		tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R9603[Dtype(RTCW(arg1))-1240])(arg1, (EIF_INTEGER_32) (loc1 + loc5));
		F1141_9727(RTCW(Result), tu4_1, (EIF_INTEGER_32) (loc1 * ((EIF_INTEGER_32) 4L)));
		RTHOOK(11);
		loc1++;
	}
	RTHOOK(12);
	F1141_9727(RTCW(Result), (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (loc1 * ((EIF_INTEGER_32) 4L)));
	RTHOOK(13);
	RTLE;
	RTEE;
	return Result;
}

/* {ENCODING_IMP}.byte_order_mark */
static EIF_CHARACTER_32 F1744_18922_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRB(EIF_CHARACTER_32)
	RTOUDB(EIF_CHARACTER_32, 345)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("byte_order_mark", 1743, Current, 0, 0, 25044);
	RTGC;
	RTOTP;
	RTHOOK(1);
	Result = (EIF_CHARACTER_32) ((EIF_INTEGER_32) 65279L);
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_CHARACTER_32 F1744_18922 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_CHARACTER_32,345,F1744_18922_body,(Current));
}

/* {ENCODING_IMP}.byte_order_mark_32_reverse */
static EIF_CHARACTER_32 F1744_18923_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRB(EIF_CHARACTER_32)
	RTOUDB(EIF_CHARACTER_32, 346)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("byte_order_mark_32_reverse", 1743, Current, 0, 0, 25045);
	RTGC;
	RTOTP;
	RTHOOK(1);
	Result = (EIF_CHARACTER_32) ((EIF_INTEGER_64) RTI64C(4294836224));
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_CHARACTER_32 F1744_18923 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_CHARACTER_32,346,F1744_18923_body,(Current));
}

/* {ENCODING_IMP}.byte_order_mark_16_reverse */
static EIF_CHARACTER_32 F1744_18924_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRB(EIF_CHARACTER_32)
	RTOUDB(EIF_CHARACTER_32, 347)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("byte_order_mark_16_reverse", 1743, Current, 0, 0, 25046);
	RTGC;
	RTOTP;
	RTHOOK(1);
	Result = (EIF_CHARACTER_32) ((EIF_INTEGER_32) 65534L);
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_CHARACTER_32 F1744_18924 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_CHARACTER_32,347,F1744_18924_body,(Current));
}

/* {ENCODING_IMP}.conversion_exception */
EIF_REFERENCE F1744_18925 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("conversion_exception", 1743, Current, 0, 1, 25047);
	RTGC;
	RTHOOK(1);
	switch (arg1) {
		case 1L:
			RTHOOK(2);
			Result = RTLNS(eif_new_type(388, 0x00).id, 388, _OBJSIZ_5_1_0_1_0_0_0_0_);
			tr1 = RTMS_EX_H("`malloc\' error",14,583574386);
			F389_5984(RTCW(Result), tr1);
			break;
		case 2L:
			RTHOOK(3);
			Result = RTLNS(eif_new_type(388, 0x00).id, 388, _OBJSIZ_5_1_0_1_0_0_0_0_);
			tr1 = RTMS_EX_H("`realloc\' error",15,1198130290);
			F389_5984(RTCW(Result), tr1);
			break;
		case 3L:
			RTHOOK(4);
			Result = RTLNS(eif_new_type(388, 0x00).id, 388, _OBJSIZ_5_1_0_1_0_0_0_0_);
			tr1 = RTMS_EX_H("`iconv_open\' error",18,665611378);
			F389_5984(RTCW(Result), tr1);
			break;
		case 4L:
			RTHOOK(5);
			Result = RTLNS(eif_new_type(388, 0x00).id, 388, _OBJSIZ_5_1_0_1_0_0_0_0_);
			tr1 = RTMS_EX_H("EILSEQ error in `iconv\'. Input conversion stopped due to an input byte that does not belong to the input codeset.",113,266392366);
			F389_5984(RTCW(Result), tr1);
			break;
		case 5L:
			RTHOOK(6);
			Result = RTLNS(eif_new_type(388, 0x00).id, 388, _OBJSIZ_5_1_0_1_0_0_0_0_);
			tr1 = RTMS_EX_H("EINVAL error in `iconv\'. Input conversion stopped due to an incomplete character or shift sequence at the end of the input buffer.",130,1207171630);
			F389_5984(RTCW(Result), tr1);
			break;
		case 6L:
			RTHOOK(7);
			Result = RTLNS(eif_new_type(388, 0x00).id, 388, _OBJSIZ_5_1_0_1_0_0_0_0_);
			tr1 = RTMS_EX_H("EBADF error in `iconv\'. The cd argument is not a valid open conversion descriptor.",82,1722040110);
			F389_5984(RTCW(Result), tr1);
			break;
		case 7L:
			RTHOOK(8);
			Result = RTLNS(eif_new_type(388, 0x00).id, 388, _OBJSIZ_5_1_0_1_0_0_0_0_);
			tr1 = RTMS_EX_H("Unexpected error in `iconv\'",27,1286010151);
			F389_5984(RTCW(Result), tr1);
			break;
		case 8L:
			RTHOOK(9);
			Result = RTLNS(eif_new_type(388, 0x00).id, 388, _OBJSIZ_5_1_0_1_0_0_0_0_);
			tr1 = RTMS_EX_H("`iconv_close\' error",19,1032340594);
			F389_5984(RTCW(Result), tr1);
			break;
		default:
			RTHOOK(10);
			Result = RTLNS(eif_new_type(388, 0x00).id, 388, _OBJSIZ_5_1_0_1_0_0_0_0_);
			tr1 = RTMS_EX_H("Unexpected error",16,578286706);
			F389_5984(RTCW(Result), tr1);
			break;
	}
	RTHOOK(12);
	RTLE;
	RTEE;
	return Result;
}

/* {ENCODING_IMP}.c_iconv_open */
EIF_POINTER F1744_18926 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32* arg3, EIF_BOOLEAN* arg4)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("c_iconv_open", 1743, Current, 0, 4, 25048);
	Result = inline_F1744_18926 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_INTEGER_32*) arg3, (EIF_BOOLEAN*) arg4);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {ENCODING_IMP}.c_iconv */
EIF_POINTER F1744_18927 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32* arg4, EIF_INTEGER_32* arg5)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("c_iconv", 1743, Current, 0, 5, 25049);
	Result = inline_F1744_18927 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_INTEGER_32) arg3, (EIF_INTEGER_32*) arg4, (EIF_INTEGER_32*) arg5);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit1022 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
