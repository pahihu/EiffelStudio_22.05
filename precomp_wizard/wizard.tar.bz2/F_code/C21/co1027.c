/*
 * Code for class CONF_INTERFACE_NAMES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co1027.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_INTERFACE_NAMES}.e_internal_parse_error */
EIF_REFERENCE F1749_19456 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_internal_parse_error", 1748, Current, 0, 0, 25568);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("Cannot parse configuration file. Unknown internal error.",56,572767278);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_invalid_tag */
EIF_REFERENCE F1749_19457 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_invalid_tag", 1748, Current, 0, 1, 25569);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid tag/tag position \'$1\'",29,1128956967);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_invalid_value */
EIF_REFERENCE F1749_19458 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_invalid_value", 1748, Current, 0, 1, 25570);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid or empty value for \'$1\'",31,1272069671);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_invalid_attribute */
EIF_REFERENCE F1749_19459 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_invalid_attribute", 1748, Current, 0, 1, 25571);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid attribute \'$1\'",22,399476519);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_unsupported_attribute */
EIF_REFERENCE F1749_19460 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_unsupported_attribute", 1748, Current, 0, 1, 25572);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Attribute \'$1\' is no longer supported for this element.",55,1313146926);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_missing_attribute */
EIF_REFERENCE F1749_19461 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_missing_attribute", 1748, Current, 0, 1, 25573);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Missing attribute \'$1\'",22,445998631);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_invalid_content */
EIF_REFERENCE F1749_19462 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_invalid_content", 1748, Current, 0, 1, 25574);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid content: $1",19,500652337);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_system_no_name */
EIF_REFERENCE F1749_19463 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_system_no_name", 1748, Current, 0, 0, 25575);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("Incorrect system tag, no name specified.",40,920394542);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_system_name */
EIF_REFERENCE F1749_19464 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_system_name", 1748, Current, 0, 1, 25576);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid system name $1.",23,1844033582);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_system_invalid_uuid */
EIF_REFERENCE F1749_19465 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_system_invalid_uuid", 1748, Current, 0, 1, 25577);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Incorrect system tag $1 invalid UUID specified.",47,432980526);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_multiple_target_with_name */
EIF_REFERENCE F1749_19466 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_multiple_target_with_name", 1748, Current, 0, 1, 25578);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Multiple targets with name $1.",30,901095214);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_target_parent */
EIF_REFERENCE F1749_19467 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,arg2);
	RTLR(6,Result);
	RTLIU(7);
	
	RTEAA("e_parse_incorrect_target_parent", 1748, Current, 0, 2, 25579);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Missing parent target: $1 in target $2",38,397130546);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1186,1236,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	((EIF_TYPED_VALUE *)tr3+2)->it_r = arg2;
	RTAR(tr3,arg2);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_target_no_name */
EIF_REFERENCE F1749_19469 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_target_no_name", 1748, Current, 0, 0, 25581);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("Target without a name specified.",32,1002044718);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_target_invalid_name */
EIF_REFERENCE F1749_19470 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_target_invalid_name", 1748, Current, 0, 1, 25582);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid target name $1.",23,1782017582);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_root_all */
EIF_REFERENCE F1749_19471 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_root_all", 1748, Current, 0, 0, 25583);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("Invalid value for all_classes attribute in root tag.",52,856382254);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_root */
EIF_REFERENCE F1749_19472 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_root", 1748, Current, 0, 0, 25584);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("Invalid root tag.",17,14597934);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_root_cluster */
EIF_REFERENCE F1749_19473 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_root_cluster", 1748, Current, 0, 0, 25585);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("Invalid root cluster.",21,1514168622);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_root_class */
EIF_REFERENCE F1749_19474 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_root_class", 1748, Current, 0, 0, 25586);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("Invalid root class.",19,932237358);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_root_feature */
EIF_REFERENCE F1749_19475 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_root_feature", 1748, Current, 0, 0, 25587);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("Invalid root procedure.",23,1447810862);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_setting_no_name */
EIF_REFERENCE F1749_19476 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_setting_no_name", 1748, Current, 0, 0, 25588);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("Invalid setting tag, no name specified.",39,1357443118);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_setting */
EIF_REFERENCE F1749_19477 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_setting", 1748, Current, 0, 1, 25589);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid setting tag $1.",23,630025518);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_setting_value */
EIF_REFERENCE F1749_19478 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_setting_value", 1748, Current, 0, 1, 25590);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid value for setting $1.",29,2079571758);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_file_rule */
EIF_REFERENCE F1749_19479 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_file_rule", 1748, Current, 0, 0, 25591);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("Invalid file_rule tag.",22,1232171822);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_external */
EIF_REFERENCE F1749_19480 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_external", 1748, Current, 0, 0, 25592);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("Invalid external tag.",21,305412142);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_action_invalid */
EIF_REFERENCE F1749_19481 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_action_invalid", 1748, Current, 0, 1, 25593);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid action tag $1.",22,1423975726);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_action_succeed */
EIF_REFERENCE F1749_19482 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_action_succeed", 1748, Current, 0, 1, 25594);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Non boolean value for succeed attribute of action $1.",53,1247440174);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_action_no_command */
EIF_REFERENCE F1749_19483 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_action_no_command", 1748, Current, 0, 0, 25595);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("Invalid action tag.",19,1747474990);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_variable_no_name */
EIF_REFERENCE F1749_19484 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_variable_no_name", 1748, Current, 0, 0, 25596);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("Invalid variable tag.",21,766237486);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_library_no_name */
EIF_REFERENCE F1749_19486 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_library_no_name", 1748, Current, 0, 0, 25598);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("Invalid library tag.",20,533826350);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_library_name */
EIF_REFERENCE F1749_19487 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_library_name", 1748, Current, 0, 1, 25599);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid library name $1.",24,797493806);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_library */
EIF_REFERENCE F1749_19488 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_library", 1748, Current, 0, 1, 25600);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid library tag $1.",23,1521673262);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_precompile_no_name */
EIF_REFERENCE F1749_19490 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_precompile_no_name", 1748, Current, 0, 0, 25602);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("Invalid precompile tag.",23,740139054);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_precompile_name */
EIF_REFERENCE F1749_19491 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_precompile_name", 1748, Current, 0, 1, 25603);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid precompile name $1.",27,438962222);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_precompile */
EIF_REFERENCE F1749_19492 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_precompile", 1748, Current, 0, 1, 25604);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid precompile tag $1.",26,1268614958);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_precompile_multiple */
EIF_REFERENCE F1749_19494 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,arg2);
	RTLR(6,Result);
	RTLIU(7);
	
	RTEAA("e_parse_incorrect_precompile_multiple", 1748, Current, 0, 2, 25606);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid precompile tag $1, there is already another precompile specified $2.",76,2020039982);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1186,1236,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	((EIF_TYPED_VALUE *)tr3+2)->it_r = arg2;
	RTAR(tr3,arg2);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_assembly_no_name */
EIF_REFERENCE F1749_19495 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_assembly_no_name", 1748, Current, 0, 0, 25607);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("Invalid assembly tag no name specified.",39,1199055662);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_assembly_name */
EIF_REFERENCE F1749_19496 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_assembly_name", 1748, Current, 0, 1, 25608);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid assembly name $1.",25,802585902);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_assembly */
EIF_REFERENCE F1749_19497 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_assembly", 1748, Current, 0, 1, 25609);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid assembly tag $1 no location specified.",46,162868782);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_cluster_no_name */
EIF_REFERENCE F1749_19499 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_cluster_no_name", 1748, Current, 0, 0, 25611);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("Invalid cluster tag no name specified.",38,775220526);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_cluster_name */
EIF_REFERENCE F1749_19500 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_cluster_name", 1748, Current, 0, 1, 25612);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid cluster name $1.",24,1008770606);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_cluster */
EIF_REFERENCE F1749_19501 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_cluster", 1748, Current, 0, 1, 25613);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid cluster tag $1 no location specified.",45,896843566);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_cluster_conflict */
EIF_REFERENCE F1749_19502 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_cluster_conflict", 1748, Current, 0, 1, 25614);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid cluster tag there is already a group with the name $1.",62,924025902);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_override_no_name */
EIF_REFERENCE F1749_19503 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_override_no_name", 1748, Current, 0, 0, 25615);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("Invalid override tag no name specified.",39,228885806);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_override_name */
EIF_REFERENCE F1749_19504 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_override_name", 1748, Current, 0, 1, 25616);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid override name $1.",25,707149102);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_override */
EIF_REFERENCE F1749_19505 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_override", 1748, Current, 0, 1, 25617);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid override tag $1 no location specified.",46,2053781294);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_debug_no_name */
EIF_REFERENCE F1749_19507 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_debug_no_name", 1748, Current, 0, 0, 25619);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("Invalid debug tag.",18,1017523246);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_debug */
EIF_REFERENCE F1749_19508 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_debug", 1748, Current, 0, 1, 25620);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid debug tag $1.",21,1000221486);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_warning_no_name */
EIF_REFERENCE F1749_19509 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_warning_no_name", 1748, Current, 0, 0, 25621);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("Invalid warning tag.",20,1554314030);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_warning */
EIF_REFERENCE F1749_19510 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_warning", 1748, Current, 0, 1, 25622);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid warning tag $1.",23,2071586350);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_renaming_no_name */
EIF_REFERENCE F1749_19511 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_renaming_no_name", 1748, Current, 0, 0, 25623);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("Invalid renaming tag.",21,943068974);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_renaming_no_new */
EIF_REFERENCE F1749_19512 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_renaming_no_new", 1748, Current, 0, 1, 25624);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid renaming tag, no new name specified for $1.",51,723573806);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_renaming_no_old */
EIF_REFERENCE F1749_19513 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_renaming_no_old", 1748, Current, 0, 1, 25625);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid renaming tag, no old name specified for $1.",51,911450926);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_class_opt */
EIF_REFERENCE F1749_19514 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_class_opt", 1748, Current, 0, 0, 25626);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("Invalid class_option tag.",25,1606584878);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_option_override */
EIF_REFERENCE F1749_19515 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_option_override", 1748, Current, 0, 1, 25627);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Library option \"$1\" cannot be overridden outside the library.",61,912991278);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_visible */
EIF_REFERENCE F1749_19516 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_visible", 1748, Current, 0, 1, 25628);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid visible tag on $1.",26,420685870);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_visible_feature */
EIF_REFERENCE F1749_19517 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_visible_feature", 1748, Current, 0, 1, 25629);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Incorrect feature name $1 in visible clause .",45,1732298030);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_visible_class */
EIF_REFERENCE F1749_19518 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_visible_class", 1748, Current, 0, 1, 25630);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Incorrect class name $1 in visible clause .",43,2104216110);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_uses */
EIF_REFERENCE F1749_19519 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_uses", 1748, Current, 0, 1, 25631);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid uses tag in group $1.",29,918257966);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_overrides */
EIF_REFERENCE F1749_19520 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_overrides", 1748, Current, 0, 1, 25632);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid overrides tag in group $1.",34,816658478);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_condition */
EIF_REFERENCE F1749_19521 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_condition", 1748, Current, 0, 0, 25633);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("Invalid condition tag.",22,1360920878);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_platform_mult */
EIF_REFERENCE F1749_19522 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_platform_mult", 1748, Current, 0, 0, 25634);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("Cannot have multiple platform specifications in one condition.",62,1414380590);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_platform_conflict */
EIF_REFERENCE F1749_19523 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_platform_conflict", 1748, Current, 0, 0, 25635);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("Value and exclude attribute in platform condition cannot appear at the same time.",81,2138170158);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_platform_none */
EIF_REFERENCE F1749_19524 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_platform_none", 1748, Current, 0, 0, 25636);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("No value or excluded-value specified in platform condition.",59,1233620526);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_platform */
EIF_REFERENCE F1749_19525 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_platform", 1748, Current, 0, 1, 25637);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid platform $1.",20,453053486);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_build_mult */
EIF_REFERENCE F1749_19526 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_build_mult", 1748, Current, 0, 0, 25638);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("Cannot have multiple build specifications in one condition.",59,550406446);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_build_conflict */
EIF_REFERENCE F1749_19527 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_build_conflict", 1748, Current, 0, 0, 25639);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("Value and exclude attribute in build condition cannot appear at the same time.",78,1780802350);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_build_none */
EIF_REFERENCE F1749_19528 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_build_none", 1748, Current, 0, 0, 25640);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("No value or excluded-value specified in build condition.",56,400633134);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_build */
EIF_REFERENCE F1749_19529 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_build", 1748, Current, 0, 1, 25641);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid build $1.",17,1066298414);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_multithreaded */
EIF_REFERENCE F1749_19530 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_multithreaded", 1748, Current, 0, 0, 25642);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("No valid value specified in multithreaded condition.",52,1547612718);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_concurrency */
EIF_REFERENCE F1749_19531 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_concurrency", 1748, Current, 0, 1, 25643);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid concurrency condition $1.",33,812965678);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_void_safety */
EIF_REFERENCE F1749_19532 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_void_safety", 1748, Current, 0, 1, 25644);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid void_safety condition $1.",33,1750704430);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_dotnet */
EIF_REFERENCE F1749_19533 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_dotnet", 1748, Current, 0, 0, 25645);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("No valid value specified in .NET condition.",43,467556398);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_dynamic_runtime */
EIF_REFERENCE F1749_19534 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_dynamic_runtime", 1748, Current, 0, 0, 25646);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("No valid value specified in dynamic runtime condition.",54,761611566);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_version_min */
EIF_REFERENCE F1749_19535 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_version_min", 1748, Current, 0, 1, 25647);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid minimum version number in version condition: ",53,430672160);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_version_max */
EIF_REFERENCE F1749_19536 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_version_max", 1748, Current, 0, 1, 25648);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid maximum version number in version condition: ",53,582231328);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_version_no_type */
EIF_REFERENCE F1749_19537 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_version_no_type", 1748, Current, 0, 0, 25649);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("No version type specified in version condition.",47,184137262);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_version_no_version */
EIF_REFERENCE F1749_19538 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_version_no_version", 1748, Current, 0, 1, 25650);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("No minimum or maximum version in version condition $1 specified.",64,790179630);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_version_type */
EIF_REFERENCE F1749_19539 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_version_type", 1748, Current, 0, 1, 25651);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Invalid version type $1 in version condition.",45,1885535790);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_version_min_max */
EIF_REFERENCE F1749_19540 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_version_min_max", 1748, Current, 0, 1, 25652);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Minimum version cannot be greater than maximum version in version condition $1.",79,638589230);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_custom_no_name */
EIF_REFERENCE F1749_19541 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_custom_no_name", 1748, Current, 0, 0, 25653);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("No name attribute in custom condition.",38,1294095406);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_custom_conflict */
EIF_REFERENCE F1749_19543 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_incorrect_custom_conflict", 1748, Current, 0, 1, 25655);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Value and exclude attribute in custom condition $1 cannot appear at the same time.",82,1706507310);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_mapping */
EIF_REFERENCE F1749_19544 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_mapping", 1748, Current, 0, 0, 25656);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("Invalid mapping tag.",20,1023125806);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_incorrect_description */
EIF_REFERENCE F1749_19545 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_incorrect_description", 1748, Current, 0, 0, 25657);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("Invalid description tag.",24,1977759790);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_more_than_one_note */
EIF_REFERENCE F1749_19546 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("e_parse_more_than_one_note", 1748, Current, 0, 1, 25658);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = F1748_18985(Current);
	tr3 = RTMS_EX_H("Multiple note elements under $1.",32,284655150);
	tr2 = F82_1449(RTCW(tr2), tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
	RTAR(tr3,arg1);
	Result = F82_1453(RTCW(tr1), tr2, tr3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_external_outside_target_element */
EIF_REFERENCE F1749_19547 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("e_parse_external_outside_target_element", 1748, Current, 0, 0, 25659);
	RTGC;
	RTHOOK(1);
	tr1 = F1748_18985(Current);
	tr2 = RTMS_EX_H("External element found outside a target element.",48,414953518);
	Result = F82_1449(RTCW(tr1), tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_INTERFACE_NAMES}.e_parse_invalid_regexp */
EIF_REFERENCE F1749_19548 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,arg2);
	RTLR(1,arg3);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,arg1);
	RTLR(7,Result);
	RTLIU(8);
	
	RTEAA("e_parse_invalid_regexp", 1748, Current, 0, 4, 25660);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg2 != NULL) && (EIF_BOOLEAN)(arg3 != NULL))) {
		RTHOOK(2);
		if ((EIF_BOOLEAN)(arg4 == ((EIF_INTEGER_32) 0L))) {
			RTHOOK(3);
			tr1 = F1748_18985(Current);
			tr2 = F1748_18985(Current);
			tr3 = RTMS_EX_H("Invalid regular expression \"$1\" in \"$2\": $3.",44,29675566);
			tr2 = F82_1449(RTCW(tr2), tr3);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,1186,1236,1236,1236,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr3 = RTLNTS(typres0.id, 4, 0);
			}
			((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
			RTAR(tr3,arg1);
			((EIF_TYPED_VALUE *)tr3+2)->it_r = arg2;
			RTAR(tr3,arg2);
			((EIF_TYPED_VALUE *)tr3+3)->it_r = arg3;
			RTAR(tr3,arg3);
			Result = F82_1453(RTCW(tr1), tr2, tr3);
		} else {
			RTHOOK(4);
			tr1 = F1748_18985(Current);
			tr2 = F1748_18985(Current);
			tr3 = RTMS_EX_H("Invalid regular expression \"$1\" (error position: $4) in \"$2\": $3.",65,22094382);
			tr2 = F82_1449(RTCW(tr2), tr3);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,4,1186,1236,1236,1236,1486,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr3 = RTLNTS(typres0.id, 5, 0);
			}
			((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
			RTAR(tr3,arg1);
			((EIF_TYPED_VALUE *)tr3+2)->it_r = arg2;
			RTAR(tr3,arg2);
			((EIF_TYPED_VALUE *)tr3+3)->it_r = arg3;
			RTAR(tr3,arg3);
			((EIF_TYPED_VALUE *)tr3+4)->it_i4 = arg4;
			Result = F82_1453(RTCW(tr1), tr2, tr3);
		}
	} else {
		RTHOOK(5);
		if ((EIF_BOOLEAN)(arg2 != NULL)) {
			RTHOOK(6);
			tr1 = F1748_18985(Current);
			tr2 = F1748_18985(Current);
			tr3 = RTMS_EX_H("Invalid regular expression \"$1\" in \"$2\".",40,867593774);
			tr2 = F82_1449(RTCW(tr2), tr3);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1186,1236,1236,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr3 = RTLNTS(typres0.id, 3, 0);
			}
			((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
			RTAR(tr3,arg1);
			((EIF_TYPED_VALUE *)tr3+2)->it_r = arg2;
			RTAR(tr3,arg2);
			Result = F82_1453(RTCW(tr1), tr2, tr3);
		} else {
			RTHOOK(7);
			if ((EIF_BOOLEAN)(arg3 != NULL)) {
				RTHOOK(8);
				if ((EIF_BOOLEAN)(arg4 == ((EIF_INTEGER_32) 0L))) {
					RTHOOK(9);
					tr1 = F1748_18985(Current);
					tr2 = F1748_18985(Current);
					tr3 = RTMS_EX_H("Invalid regular expression \"$1\": $2.",36,1540005934);
					tr2 = F82_1449(RTCW(tr2), tr3);
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1186,1236,1236,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr3 = RTLNTS(typres0.id, 3, 0);
					}
					((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
					RTAR(tr3,arg1);
					((EIF_TYPED_VALUE *)tr3+2)->it_r = arg3;
					RTAR(tr3,arg3);
					Result = F82_1453(RTCW(tr1), tr2, tr3);
				} else {
					RTHOOK(10);
					tr1 = F1748_18985(Current);
					tr2 = F1748_18985(Current);
					tr3 = RTMS_EX_H("Invalid regular expression \"$1\" (error position: $3): $2.",57,2077588526);
					tr2 = F82_1449(RTCW(tr2), tr3);
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,1186,1236,1236,1486,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr3 = RTLNTS(typres0.id, 4, 0);
					}
					((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
					RTAR(tr3,arg1);
					((EIF_TYPED_VALUE *)tr3+2)->it_r = arg3;
					RTAR(tr3,arg3);
					((EIF_TYPED_VALUE *)tr3+3)->it_i4 = arg4;
					Result = F82_1453(RTCW(tr1), tr2, tr3);
				}
			} else {
				RTHOOK(11);
				tr1 = F1748_18985(Current);
				tr2 = F1748_18985(Current);
				tr3 = RTMS_EX_H("Invalid regular expression: \"$1\".",33,1445287214);
				tr2 = F82_1449(RTCW(tr2), tr3);
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1186,1236,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr3 = RTLNTS(typres0.id, 2, 0);
				}
				((EIF_TYPED_VALUE *)tr3+1)->it_r = arg1;
				RTAR(tr3,arg1);
				Result = F82_1453(RTCW(tr1), tr2, tr3);
			}
		}
	}
	RTHOOK(12);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit1027 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
