/*
 * Code for class I18N_HOST_LOCALE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i11024.h"
#include <eif_eiffel.h>
#include "eif_langinfo.h"
#include <locale.h>
#include <eif_langinfo.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F1746_18978
static int inline_F1746_18978 (void)
{
	#if EIF_OS == EIF_OS_SUNOS
	return (EIF_BOOLEAN)1;
#else
	return (EIF_BOOLEAN)0;
#endif
	;
}
#define INLINE_F1746_18978
#endif
#ifndef INLINE_F226_4038
static EIF_INTEGER_32 inline_F226_4038 (void)
{
	return D_FMT;
	;
}
#define INLINE_F226_4038
#endif
#ifndef INLINE_F226_4039
static EIF_INTEGER_32 inline_F226_4039 (void)
{
	return T_FMT;
	;
}
#define INLINE_F226_4039
#endif
#ifndef INLINE_F226_4035
static EIF_INTEGER_32 inline_F226_4035 (void)
{
	return AM_STR;
	;
}
#define INLINE_F226_4035
#endif
#ifndef INLINE_F226_4036
static EIF_INTEGER_32 inline_F226_4036 (void)
{
	return PM_STR;
	;
}
#define INLINE_F226_4036
#endif
#ifndef INLINE_F226_4037
static EIF_INTEGER_32 inline_F226_4037 (void)
{
	return D_T_FMT;
	;
}
#define INLINE_F226_4037
#endif
#ifndef INLINE_F226_4004
static EIF_INTEGER_32 inline_F226_4004 (void)
{
	return DAY_1;
	;
}
#define INLINE_F226_4004
#endif
#ifndef INLINE_F226_4023
static EIF_INTEGER_32 inline_F226_4023 (void)
{
	return MON_1;
	;
}
#define INLINE_F226_4023
#endif
#ifndef INLINE_F226_3997
static EIF_INTEGER_32 inline_F226_3997 (void)
{
	return ABDAY_1;
	;
}
#define INLINE_F226_3997
#endif
#ifndef INLINE_F226_4011
static EIF_INTEGER_32 inline_F226_4011 (void)
{
	return ABMON_1;
	;
}
#define INLINE_F226_4011
#endif
#ifndef INLINE_F226_4041
static EIF_INTEGER_32 inline_F226_4041 (void)
{
	return CRNCYSTR;
	;
}
#define INLINE_F226_4041
#endif
#ifndef INLINE_F225_3992
static EIF_POINTER inline_F225_3992 (void)
{
	#if EIF_OS == EIF_OS_OPENBSD
	return locale_charset ();
#else
	return nl_langinfo (CODESET);
#endif
	;
}
#define INLINE_F225_3992
#endif
#ifndef INLINE_F225_3996
static EIF_INTEGER_32 inline_F225_3996 (void)
{
	return LC_ALL;
	;
}
#define INLINE_F225_3996
#endif
#ifndef INLINE_F225_3995
static EIF_POINTER inline_F225_3995 (EIF_INTEGER_32 arg1, EIF_POINTER arg2)
{
	return setlocale((int) arg1, (const char *) arg2);
	;
}
#define INLINE_F225_3995
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_HOST_LOCALE_IMP}.create_locale_info */
EIF_REFERENCE F1746_18942 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("create_locale_info", 1745, Current, 0, 1, 25093);
	RTGC;
	RTHOOK(1);
	if (EIF_TEST (inline_F1746_18978())) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		tr1 = F1746_18980(Current, tr1);
		F225_3988(Current, tr1);
	} else {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		F225_3988(Current, tr1);
	}
	RTHOOK(4);
	Result = RTLNS(eif_new_type(230, 0x00).id, 230, _OBJSIZ_35_0_0_5_0_0_0_0_);
	F231_4160(RTCW(Result));
	RTHOOK(5);
	F1746_18949(Current, Result);
	RTHOOK(6);
	F231_4162(RTCW(Result), arg1);
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.is_available */
EIF_BOOLEAN F1746_18943 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("is_available", 1745, Current, 0, 1, 25094);
	RTGC;
	RTHOOK(1);
	if (EIF_TEST (inline_F1746_18978())) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		tr1 = F1746_18980(Current, tr1);
		Result = F225_3991(Current, tr1);
	} else {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		Result = F225_3991(Current, tr1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.available_locales */
EIF_REFERENCE F1746_18944 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc1);
	RTLIU(6);
	
	RTEAA("available_locales", 1745, Current, 3, 0, 25095);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {882,1718,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 882, _OBJSIZ_2_3_0_1_0_0_0_0_);
	}
	F883_8665(RTCW(Result));
	RTHOOK(2);
	loc2 = RTLNS(eif_new_type(1142, 0x00).id, 1142, _OBJSIZ_3_0_0_1_0_2_0_0_);
	tr1 = RTMS_EX_H("/usr/share/i18n/locales/",24,2077116975);
	F1143_9798(RTCW(loc2), tr1);
	RTHOOK(3);
	tb1 = F1143_9823(RTCW(loc2));
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(4);
		tr1 = RTMS_EX_H("/usr/lib/locale",15,443040613);
		F1143_9798(RTCW(loc2), tr1);
	}
	RTHOOK(5);
	tb1 = F1143_9823(RTCW(loc2));
	if (tb1) {
		RTHOOK(6);
		loc3 = F1143_9817(RTCW(loc2));
		RTHOOK(7);
		F892_8811(RTCW(loc3));
		for (;;) {
			RTHOOK(8);
			tb1 = F859_8654(RTCW(loc3));
			if (tb1) break;
			RTHOOK(9);
			loc1 = RTLNS(eif_new_type(1718, 0x00).id, 1718, _OBJSIZ_6_0_0_0_0_0_0_0_);
			tr1 = F892_8785(RTCW(loc3));
			F1719_18315(RTCW(loc1), tr1);
			RTHOOK(10);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
			if (F225_3991(Current, tr1)) {
				RTHOOK(11);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7657[Dtype(RTCW(Result))-780])(Result, loc1);
			}
			RTHOOK(12);
			F892_8813(RTCW(loc3));
		}
	}
	RTHOOK(13);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.default_locale_id */
EIF_REFERENCE F1746_18945 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("default_locale_id", 1745, Current, 0, 0, 25096);
	RTGC;
	RTHOOK(1);
	tr1 = RTMS_EX_H("",0,0);
	F225_3988(Current, tr1);
	RTHOOK(2);
	RTHOOK(3);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) F1746_18947(Current);
}

/* {I18N_HOST_LOCALE_IMP}.system_locale_id */
EIF_REFERENCE F1746_18946 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("system_locale_id", 1745, Current, 0, 0, 25097);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) F1746_18945(Current);
}

/* {I18N_HOST_LOCALE_IMP}.current_locale_id */
EIF_REFERENCE F1746_18947 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("current_locale_id", 1745, Current, 0, 0, 25098);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1718, 0x00).id, 1718, _OBJSIZ_6_0_0_0_0_0_0_0_);
	tr1 = F1746_18948(Current);
	F1719_18315(RTCW(Result), tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.locale_name */
EIF_REFERENCE F1746_18948 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("locale_name", 1745, Current, 0, 0, 25099);
	RTGC;
	RTHOOK(1);
	Result = F1237_11118(RTCV(F225_3993(Current)));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.fill */
void F1746_18949 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("fill", 1745, Current, 0, 1, 25100);
	RTGC;
	RTHOOK(1);
	F1746_18950(Current, arg1);
	RTHOOK(2);
	F1746_18951(Current, arg1);
	RTHOOK(3);
	F1746_18952(Current, arg1);
	RTHOOK(4);
	F1746_18953(Current, arg1);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {I18N_HOST_LOCALE_IMP}.fill_date_time_info */
void F1746_18950 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("fill_date_time_info", 1745, Current, 0, 1, 25101);
	RTGC;
	RTHOOK(1);
	tr1 = F1746_18958(Current);
	F230_4138(RTCW(arg1), tr1);
	RTHOOK(2);
	tr1 = F1746_18954(Current);
	F230_4139(RTCW(arg1), tr1);
	RTHOOK(3);
	tr1 = F1746_18955(Current);
	F230_4141(RTCW(arg1), tr1);
	RTHOOK(4);
	tr1 = F1746_18956(Current);
	F230_4143(RTCW(arg1), tr1);
	RTHOOK(5);
	tr1 = F1746_18957(Current);
	F230_4144(RTCW(arg1), tr1);
	RTHOOK(6);
	tr1 = F1746_18959(Current);
	F230_4134(RTCW(arg1), tr1);
	RTHOOK(7);
	tr1 = F1746_18960(Current);
	F230_4136(RTCW(arg1), tr1);
	RTHOOK(8);
	tr1 = F1746_18961(Current);
	F230_4135(RTCW(arg1), tr1);
	RTHOOK(9);
	tr1 = F1746_18962(Current);
	F230_4137(RTCW(arg1), tr1);
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {I18N_HOST_LOCALE_IMP}.fill_numeric_info */
void F1746_18951 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("fill_numeric_info", 1745, Current, 0, 1, 25102);
	RTGC;
	RTHOOK(1);
	tr1 = F1746_18963(Current);
	F228_4105(RTCW(arg1), tr1);
	RTHOOK(2);
	tr1 = F1746_18964(Current);
	F228_4107(RTCW(arg1), tr1);
	RTHOOK(3);
	tr1 = F1746_18965(Current);
	F228_4111(RTCW(arg1), tr1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {I18N_HOST_LOCALE_IMP}.fill_currency_info */
void F1746_18952 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("fill_currency_info", 1745, Current, 0, 1, 25103);
	RTGC;
	RTHOOK(1);
	tr1 = F1746_18966(Current);
	F227_4074(RTCW(arg1), tr1);
	RTHOOK(2);
	ti4_1 = F1746_18967(Current);
	F227_4075(RTCW(arg1), ti4_1);
	RTHOOK(3);
	tr1 = F1746_18968(Current);
	F227_4076(RTCW(arg1), tr1);
	RTHOOK(4);
	ti4_1 = F1746_18969(Current);
	F227_4077(RTCW(arg1), ti4_1);
	RTHOOK(5);
	tr1 = F1746_18970(Current);
	F227_4078(RTCW(arg1), tr1);
	RTHOOK(6);
	tr1 = F1746_18971(Current);
	F227_4080(RTCW(arg1), tr1);
	RTHOOK(7);
	tr1 = F1746_18972(Current);
	F227_4081(RTCW(arg1), tr1);
	RTHOOK(8);
	tr1 = F1746_18973(Current);
	F227_4082(RTCW(arg1), tr1);
	RTHOOK(9);
	tr1 = F1746_18975(Current);
	F227_4083(RTCW(arg1), tr1);
	RTHOOK(10);
	ti4_1 = F1746_18976(Current);
	F227_4086(RTCW(arg1), ti4_1);
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {I18N_HOST_LOCALE_IMP}.fill_code_page_info */
void F1746_18953 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("fill_code_page_info", 1745, Current, 1, 1, 25104);
	RTGC;
	RTHOOK(1);
	loc1 = F1746_18974(Current);
	RTHOOK(2);
	F229_4117(RTCW(arg1), loc1);
	RTHOOK(3);
	F229_4118(RTCW(arg1), loc1);
	RTHOOK(4);
	F229_4119(RTCW(arg1), loc1);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {I18N_HOST_LOCALE_IMP}.get_long_date_format */
EIF_REFERENCE F1746_18954 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("get_long_date_format", 1745, Current, 0, 0, 25105);
	RTGC;
	RTHOOK(1);
	ti4_1 = inline_F226_4038();
	tr1 = F225_3989(Current, ti4_1);
	Result = F1746_18979(Current, tr1);
	RTHOOK(2);
	tr1 = RTMS32_EX_H("%\000\000\000",1,37);
	tr2 = RTMS32_EX_H("&\000\000\000",1,38);
	F1242_11281(RTCW(Result), tr1, tr2);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.get_long_time_format */
EIF_REFERENCE F1746_18955 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("get_long_time_format", 1745, Current, 0, 0, 25106);
	RTGC;
	RTHOOK(1);
	ti4_1 = inline_F226_4039();
	tr1 = F225_3989(Current, ti4_1);
	Result = F1746_18979(Current, tr1);
	RTHOOK(2);
	tr1 = RTMS32_EX_H("%\000\000\000",1,37);
	tr2 = RTMS32_EX_H("&\000\000\000",1,38);
	F1242_11281(RTCW(Result), tr1, tr2);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.get_am_suffix */
EIF_REFERENCE F1746_18956 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("get_am_suffix", 1745, Current, 0, 0, 25107);
	RTGC;
	RTHOOK(1);
	ti4_1 = inline_F226_4035();
	tr1 = F225_3989(Current, ti4_1);
	Result = F1746_18979(Current, tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.get_pm_suffix */
EIF_REFERENCE F1746_18957 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("get_pm_suffix", 1745, Current, 0, 0, 25068);
	RTGC;
	RTHOOK(1);
	ti4_1 = inline_F226_4036();
	tr1 = F225_3989(Current, ti4_1);
	Result = F1746_18979(Current, tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.get_date_time_format */
EIF_REFERENCE F1746_18958 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("get_date_time_format", 1745, Current, 0, 0, 25069);
	RTGC;
	RTHOOK(1);
	ti4_1 = inline_F226_4037();
	tr1 = F225_3989(Current, ti4_1);
	Result = F1746_18979(Current, tr1);
	RTHOOK(2);
	tr1 = RTMS32_EX_H("%\000\000\000",1,37);
	tr2 = RTMS32_EX_H("&\000\000\000",1,38);
	F1242_11281(RTCW(Result), tr1, tr2);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.get_day_names */
EIF_REFERENCE F1746_18959 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc3);
	RTLIU(4);
	
	RTEAA("get_day_names", 1745, Current, 3, 0, 25070);
	RTGC;
	RTHOOK(1);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
	RTHOOK(2);
	{
		static EIF_TYPE_INDEX typarr0[] = {937,1241,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 937, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	tr1 = RTMS32_EX_H("",0,0);
	F938_9009(RTCW(Result), tr1, ((EIF_INTEGER_32) 1L), loc2);
	RTHOOK(3);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_1_);
	for (;;) {
		RTHOOK(5);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_0_);
		if ((EIF_BOOLEAN) (loc1 > ti4_1)) break;
		RTHOOK(6);
		ti4_2 = inline_F226_4004();
		tr1 = F225_3989(Current, (EIF_INTEGER_32) (ti4_2 + (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)) % loc2)));
		loc3 = F1746_18979(Current, tr1);
		RTHOOK(7);
		F938_9033(RTCW(Result), loc3, loc1);
		RTHOOK(8);
		loc1++;
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.get_month_names */
EIF_REFERENCE F1746_18960 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("get_month_names", 1745, Current, 2, 0, 25071);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {937,1241,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 937, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	tr1 = RTMS32_EX_H("",0,0);
	F938_9009(RTCW(Result), tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 12L));
	RTHOOK(2);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_1_);
	for (;;) {
		RTHOOK(4);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_0_);
		if ((EIF_BOOLEAN) (loc1 > ti4_1)) break;
		RTHOOK(5);
		ti4_2 = inline_F226_4023();
		tr1 = F225_3989(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_2 + loc1) - ((EIF_INTEGER_32) 1L)));
		loc2 = F1746_18979(Current, tr1);
		RTHOOK(6);
		F938_9033(RTCW(Result), loc2, loc1);
		RTHOOK(7);
		loc1++;
	}
	RTHOOK(10);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.get_abbreviated_day_names */
EIF_REFERENCE F1746_18961 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc3);
	RTLIU(4);
	
	RTEAA("get_abbreviated_day_names", 1745, Current, 3, 0, 25072);
	RTGC;
	RTHOOK(1);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
	RTHOOK(2);
	{
		static EIF_TYPE_INDEX typarr0[] = {937,1241,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 937, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	tr1 = RTMS32_EX_H("",0,0);
	F938_9009(RTCW(Result), tr1, ((EIF_INTEGER_32) 1L), loc2);
	RTHOOK(3);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_1_);
	for (;;) {
		RTHOOK(5);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_0_);
		if ((EIF_BOOLEAN) (loc1 > ti4_1)) break;
		RTHOOK(6);
		ti4_2 = inline_F226_3997();
		tr1 = F225_3989(Current, (EIF_INTEGER_32) (ti4_2 + (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)) % loc2)));
		loc3 = F1746_18979(Current, tr1);
		RTHOOK(7);
		F938_9033(RTCW(Result), loc3, loc1);
		RTHOOK(8);
		loc1++;
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.get_abbreviated_month_names */
EIF_REFERENCE F1746_18962 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("get_abbreviated_month_names", 1745, Current, 2, 0, 25073);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {937,1241,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 937, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	tr1 = RTMS32_EX_H("",0,0);
	F938_9009(RTCW(Result), tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 12L));
	RTHOOK(2);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_1_);
	for (;;) {
		RTHOOK(4);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_0_);
		if ((EIF_BOOLEAN) (loc1 > ti4_1)) break;
		RTHOOK(5);
		ti4_2 = inline_F226_4011();
		tr1 = F225_3989(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_2 + loc1) - ((EIF_INTEGER_32) 1L)));
		loc2 = F1746_18979(Current, tr1);
		RTHOOK(6);
		F938_9033(RTCW(Result), loc2, loc1);
		RTHOOK(7);
		loc1++;
	}
	RTHOOK(10);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.get_value_decimal_separator */
EIF_REFERENCE F1746_18963 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("get_value_decimal_separator", 1745, Current, 0, 0, 25074);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tp1 = (EIF_POINTER) localeconv();
	tp1 = (EIF_POINTER) (((struct lconv *)tp1)->decimal_point);
	F1240_11193(RTCW(Result), tp1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.get_value_group_separator */
EIF_REFERENCE F1746_18964 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("get_value_group_separator", 1745, Current, 0, 0, 25075);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tp1 = (EIF_POINTER) localeconv();
	tp1 = (EIF_POINTER) (((struct lconv *)tp1)->thousands_sep);
	F1240_11193(RTCW(Result), tp1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.get_value_grouping */
EIF_REFERENCE F1746_18965 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("get_value_grouping", 1745, Current, 0, 0, 25076);
	RTGC;
	RTHOOK(1);
	tp1 = (EIF_POINTER) localeconv();
	tp1 = (EIF_POINTER) (((struct lconv *)tp1)->grouping);
	Result = F1746_18977(Current, tp1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.get_currency_symbol */
EIF_REFERENCE F1746_18966 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("get_currency_symbol", 1745, Current, 0, 0, 25077);
	RTGC;
	RTHOOK(1);
	ti4_1 = inline_F226_4041();
	tr1 = F225_3989(Current, ti4_1);
	Result = F1746_18979(Current, tr1);
	RTHOOK(2);
	F1242_11326(RTCW(Result), ((EIF_INTEGER_32) 1L));
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.get_currency_symbol_location */
EIF_INTEGER_32 F1746_18967 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("get_currency_symbol_location", 1745, Current, 1, 0, 25078);
	RTGC;
	RTHOOK(1);
	ti4_1 = inline_F226_4041();
	tr1 = F225_3989(Current, ti4_1);
	loc1 = F1746_18979(Current, tr1);
	RTHOOK(2);
	tb1 = F730_8337(RTCW(loc1));
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(3);
		tw1 = F1242_11271(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
		tb1 = tw1 == tw2;
		if (tb1) {
			RTHOOK(4);
			RTHOOK(5);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		} else {
			RTHOOK(6);
			tw1 = F1242_11271(RTCW(loc1), ((EIF_INTEGER_32) 1L));
			tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '+';
			tb1 = tw1 == tw2;
			if (tb1) {
				RTHOOK(7);
				Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			} else {
				RTHOOK(8);
				tw1 = F1242_11271(RTCW(loc1), ((EIF_INTEGER_32) 1L));
				tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
				tb1 = tw1 == tw2;
				if (tb1) {
					RTHOOK(9);
					RTHOOK(10);
					RTLE;
					RTEE;
					return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
				} else {
					RTHOOK(11);
					RTHOOK(12);
					RTLE;
					RTEE;
					return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				}
			}
		}
	} else {
		RTHOOK(13);
		RTHOOK(14);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	}
	RTHOOK(16);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.get_currency_decimal_separator */
EIF_REFERENCE F1746_18968 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("get_currency_decimal_separator", 1745, Current, 0, 0, 25079);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tp1 = (EIF_POINTER) localeconv();
	tp1 = (EIF_POINTER) (((struct lconv *)tp1)->mon_decimal_point);
	F1240_11193(RTCW(Result), tp1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.get_currency_numbers_after_decimal_separator */
EIF_INTEGER_32 F1746_18969 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_NATURAL_32 tu4_1;
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("get_currency_numbers_after_decimal_separator", 1745, Current, 0, 0, 25080);
	RTGC;
	RTHOOK(1);
	tp1 = (EIF_POINTER) localeconv();
	tc1 = (EIF_CHARACTER_8) (((struct lconv *)tp1)->frac_digits);
	tu4_1 = (EIF_NATURAL_32) tc1;
	Result = (EIF_INTEGER_32) tu4_1;
	RTHOOK(2);
	if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 255L))) {
		RTHOOK(3);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.get_currency_group_separator */
EIF_REFERENCE F1746_18970 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("get_currency_group_separator", 1745, Current, 0, 0, 25081);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tp1 = (EIF_POINTER) localeconv();
	tp1 = (EIF_POINTER) (((struct lconv *)tp1)->mon_thousands_sep);
	F1240_11193(RTCW(Result), tp1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.get_currency_positive_sign */
EIF_REFERENCE F1746_18971 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("get_currency_positive_sign", 1745, Current, 0, 0, 25082);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tp1 = (EIF_POINTER) localeconv();
	tp1 = (EIF_POINTER) (((struct lconv *)tp1)->positive_sign);
	F1240_11193(RTCW(Result), tp1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.get_currency_negative_sign */
EIF_REFERENCE F1746_18972 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("get_currency_negative_sign", 1745, Current, 0, 0, 25083);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tp1 = (EIF_POINTER) localeconv();
	tp1 = (EIF_POINTER) (((struct lconv *)tp1)->negative_sign);
	F1240_11193(RTCW(Result), tp1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.get_currency_grouping */
EIF_REFERENCE F1746_18973 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("get_currency_grouping", 1745, Current, 0, 0, 25084);
	RTGC;
	RTHOOK(1);
	tp1 = (EIF_POINTER) localeconv();
	tp1 = (EIF_POINTER) (((struct lconv *)tp1)->mon_grouping);
	Result = F1746_18977(Current, tp1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.get_code_page */
EIF_REFERENCE F1746_18974 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("get_code_page", 1745, Current, 1, 0, 25085);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(531, 0x00).id, 531, _OBJSIZ_1_0_0_1_0_0_0_0_);
	tp1 = inline_F225_3992();
	F532_7661(RTCW(loc1), tp1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
	Result = F1746_18979(Current, tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.get_int_currency_symbol */
EIF_REFERENCE F1746_18975 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("get_int_currency_symbol", 1745, Current, 0, 0, 25086);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tp1 = (EIF_POINTER) localeconv();
	tp1 = (EIF_POINTER) (((struct lconv *)tp1)->int_curr_symbol);
	F1240_11193(RTCW(Result), tp1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.get_int_currency_numbers_after_decimal_separator */
EIF_INTEGER_32 F1746_18976 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_NATURAL_32 tu4_1;
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("get_int_currency_numbers_after_decimal_separator", 1745, Current, 0, 0, 25087);
	RTGC;
	RTHOOK(1);
	tp1 = (EIF_POINTER) localeconv();
	tc1 = (EIF_CHARACTER_8) (((struct lconv *)tp1)->int_frac_digits);
	tu4_1 = (EIF_NATURAL_32) tc1;
	Result = (EIF_INTEGER_32) tu4_1;
	RTHOOK(2);
	if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 255L))) {
		RTHOOK(3);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.pointer_to_array */
EIF_REFERENCE F1746_18977 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_CHARACTER_32 tw1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("pointer_to_array", 1745, Current, 3, 1, 25088);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1240_11193(RTCW(loc1), arg1);
	RTHOOK(2);
	{
		static EIF_TYPE_INDEX typarr0[] = {940,1486,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 940, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
	F941_9009(RTCW(Result), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L), ti4_1);
	RTHOOK(3);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(4);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (loc2 > ti4_1)) break;
		RTHOOK(5);
		tw1 = F1242_11271(RTCW(loc1), loc2);
		tu4_1 = (EIF_NATURAL_32) tw1;
		loc3 = (EIF_INTEGER_32) tu4_1;
		RTHOOK(6);
		if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 255L))) {
			RTHOOK(7);
			loc2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		} else {
			RTHOOK(8);
			F941_9033(RTCW(Result), loc3, loc2);
		}
		RTHOOK(9);
		loc2++;
	}
	RTHOOK(10);
	if ((EIF_BOOLEAN)(loc3 != ((EIF_INTEGER_32) 255L))) {
		RTHOOK(11);
		F941_9035(RTCW(Result), ((EIF_INTEGER_32) 0L), loc2);
	}
	RTHOOK(12);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.c_is_solaris */
EIF_BOOLEAN F1746_18978 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("c_is_solaris", 1745, Current, 0, 0, 25089);
	Result = EIF_TEST(inline_F1746_18978 ());
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.utf8_pointer_to_string */
EIF_REFERENCE F1746_18979 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,Result);
	RTLIU(5);
	
	RTEAA("utf8_pointer_to_string", 1745, Current, 1, 1, 25090);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(531, 0x00).id, 531, _OBJSIZ_1_0_0_1_0_0_0_0_);
	tp1 = *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_0_1_0_1_0_0_);
	F532_7661(RTCW(loc1), tp1);
	RTHOOK(2);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_0_0_0_);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(3);
		tr1 = F532_7671(RTCW(loc1));
		Result = F1745_18934(Current, tr1);
	} else {
		RTHOOK(4);
		Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1237_11059(RTCW(Result));
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) Result;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_HOST_LOCALE_IMP}.guess_proper_locale */
EIF_REFERENCE F1746_18980 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(10);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,loc5);
	RTLR(3,tr1);
	RTLR(4,loc4);
	RTLR(5,loc8);
	RTLR(6,loc7);
	RTLR(7,Current);
	RTLR(8,loc6);
	RTLR(9,Result);
	RTLIU(10);
	
	RTEAA("guess_proper_locale", 1745, Current, 8, 1, 25091);
	RTGC;
	RTHOOK(1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_CHARACTER_32)) R9621[Dtype(RTCW(arg1))-1240])(arg1, tw1);
	if (tb1) {
		RTHOOK(2);
		loc1 = RTLNS(eif_new_type(531, 0x00).id, 531, _OBJSIZ_1_0_0_1_0_0_0_0_);
		F532_7657(RTCW(loc1), arg1);
		RTHOOK(3);
		ti4_1 = inline_F225_3996();
		tp1 = F532_7679(RTCW(loc1));
		loc2 = inline_F225_3995(ti4_1, tp1);
		RTHOOK(4);
		if ((EIF_BOOLEAN)(loc2 == loc3)) {
			RTHOOK(5);
			loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9662[Dtype(RTCW(arg1))-1240])(arg1);
			RTHOOK(6);
			loc1 = RTLNS(eif_new_type(531, 0x00).id, 531, _OBJSIZ_1_0_0_1_0_0_0_0_);
			tr1 = RTMS_EX_H("",0,0);
			F532_7657(RTCW(loc1), tr1);
			RTHOOK(7);
			ti4_1 = inline_F225_3996();
			tp1 = F532_7679(RTCW(loc1));
			loc2 = inline_F225_3995(ti4_1, tp1);
			RTHOOK(8);
			if ((EIF_BOOLEAN)(loc2 != loc3)) {
				RTHOOK(9);
				loc1 = RTLNS(eif_new_type(531, 0x00).id, 531, _OBJSIZ_1_0_0_1_0_0_0_0_);
				F532_7661(RTCW(loc1), loc2);
				RTHOOK(10);
				loc4 = F532_7671(RTCW(loc1));
				RTHOOK(11);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9662[Dtype(RTCW(loc4))-1240])(loc4);
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R9645[Dtype(RTCW(tr1))-1240])(tr1, loc5);
				if (tb1) {
					RTHOOK(12);
					loc8 = (EIF_REFERENCE) loc4;
				}
			}
			RTHOOK(13);
			if ((EIF_BOOLEAN)(loc8 == NULL)) {
				RTHOOK(14);
				loc7 = F1746_18944(Current);
				RTHOOK(15);
				F883_8684(RTCW(loc7));
				for (;;) {
					RTHOOK(16);
					tb1 = '\01';
					tb2 = *(EIF_BOOLEAN *)(RTCW(loc7) + O7899[Dtype(loc7)-882]);
					if (!tb2) {
						tb1 = (EIF_BOOLEAN)(loc8 != NULL);
					}
					if (tb1) break;
					RTHOOK(17);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7670[Dtype(RTCW(loc7))-780])(loc7);
					loc6 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
					RTHOOK(18);
					tb2 = F1240_11221(RTCW(loc6));
					if (tb2) {
						RTHOOK(19);
						loc4 = F1237_11112(RTCW(loc6));
						RTHOOK(20);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9662[Dtype(RTCW(loc4))-1240])(loc4);
						tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R9645[Dtype(RTCW(tr1))-1240])(tr1, loc5);
						if (tb2) {
							RTHOOK(21);
							loc8 = (EIF_REFERENCE) loc4;
						}
					}
					RTHOOK(22);
					(FUNCTION_CAST(void, (EIF_REFERENCE)) R7650[Dtype(RTCW(loc7))-882])(loc7);
				}
			}
		}
	}
	RTHOOK(23);
	if ((EIF_BOOLEAN)(loc8 == NULL)) {
		RTHOOK(24);
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R9617[Dtype(RTCW(arg1))-1240])(arg1);
		if (tb2) {
			RTHOOK(25);
			tr1 = F1237_11112(RTCW(arg1));
			RTHOOK(26);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) tr1;
		} else {
			RTHOOK(27);
			tr1 = RTLNS(eif_new_type(85, 0x00).id, 85, _OBJSIZ_0_0_0_0_0_0_0_0_);
			Result = F86_1480(RTCW(tr1), arg1);
		}
	} else {
		RTHOOK(28);
		RTHOOK(29);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) loc8;
	}
	RTHOOK(31);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit1024 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
