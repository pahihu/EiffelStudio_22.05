/*
 * Code for class SHARED_LOCALE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sh1026.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SHARED_LOCALE}.locale */
EIF_REFERENCE F1748_18985 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("locale", 1747, Current, 0, 0, 25115);
	RTGC;
	RTHOOK(1);
	Result = *(EIF_REFERENCE *)(RTCV(RTOUCR(614,F1748_18991, (Current))));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {SHARED_LOCALE}.locale_manager */
static EIF_REFERENCE F1748_18986_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(615)

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("locale_manager", 1747, Current, 0, 0, 25116);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tb1 = '\0';
	if (F498_7168(Current)) {
		tb2 = *(EIF_BOOLEAN *)(RTCV(F498_7170(Current))+ _CHROFF_0_0_);
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(1717, 0x00).id, 1717, _OBJSIZ_2_0_0_0_0_0_0_0_);
		tr2 = RTOUCR(3,F1793_20585, (RTCV(F498_7170(Current))));
		tr2 = F1304_12658(RTCW(tr2));
		F1718_18304(RTCW(tr1), tr2);
		Result = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(3);
		tr1 = RTLNS(eif_new_type(1717, 0x00).id, 1717, _OBJSIZ_2_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H(".",1,46);
		F1718_18304(RTCW(tr1), tr2);
		Result = (EIF_REFERENCE) tr1;
	}
	RTOTE;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1748_18986 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(615,F1748_18986_body,(Current));
}

/* {SHARED_LOCALE}.locale_internal */
static EIF_REFERENCE F1748_18991_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(614)

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("locale_internal", 1747, Current, 0, 0, 25121);
	RTGC;
	RTOTP;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {335,81,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 335, _OBJSIZ_1_0_0_0_0_0_0_0_);
	}
	tr2 = RTOUCR(616,F1748_18993, (Current));
	F336_5326(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1748_18991 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(614,F1748_18991_body,(Current));
}

/* {SHARED_LOCALE}.empty_locale */
static EIF_REFERENCE F1748_18993_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(616)

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("empty_locale", 1747, Current, 0, 0, 25123);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTOUCR(615,F1748_18986, (Current));
	tr2 = RTLNS(eif_new_type(1718, 0x00).id, 1718, _OBJSIZ_6_0_0_0_0_0_0_0_);
	tr3 = RTMS_EX_H("",0,0);
	F1719_18315(RTCW(tr2), tr3);
	Result = F1718_18305(RTCW(tr1), tr2);
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1748_18993 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(616,F1748_18993_body,(Current));
}

void EIF_Minit1026 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
