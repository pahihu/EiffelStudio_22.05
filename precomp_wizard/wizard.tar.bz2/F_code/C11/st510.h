
#ifndef _C11_st510_
#define _C11_st510_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1061_9279(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F1061_9280(EIF_REFERENCE);
extern EIF_REFERENCE F1061_9281(EIF_REFERENCE);
extern EIF_REFERENCE F1061_9283(EIF_REFERENCE);
extern EIF_INTEGER_32 F1061_9284(EIF_REFERENCE);
extern void EIF_Minit510(void);
extern EIF_INTEGER_32 F1243_11409(EIF_REFERENCE);
extern char *(*R9837[])();

#ifdef __cplusplus
}
#endif

#endif
