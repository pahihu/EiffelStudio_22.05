
#ifndef _C11_kl544_
#define _C11_kl544_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_8 F1119_9454(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F1119_9458(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit544(void);

#ifdef __cplusplus
}
#endif

#endif
