/*
 * Code for class RANDOM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ra505.h"
#include <math.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RANDOM}.set_seed */
void F970_9107 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_seed", 969, Current, 0, 1, 12661);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_1_) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_3_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_1_);
	RTHOOK(3);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {RANDOM}.modulus */
static EIF_INTEGER_32 F970_9109_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRB(EIF_INTEGER_32)
	RTOUDB(EIF_INTEGER_32, 598)

	
	RTEAA("modulus", 969, Current, 0, 0, 12663);
	RTOTP;
	RTHOOK(1);
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	RTOTE;
	RTHOOK(2);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F970_9109 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_INTEGER_32,598,F970_9109_body,(Current));
}

/* {RANDOM}.multiplier */
static EIF_INTEGER_32 F970_9110_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRB(EIF_INTEGER_32)
	RTOUDB(EIF_INTEGER_32, 599)

	
	RTEAA("multiplier", 969, Current, 0, 0, 12664);
	RTOTP;
	RTHOOK(1);
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16807L);
	RTOTE;
	RTHOOK(2);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F970_9110 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_INTEGER_32,599,F970_9110_body,(Current));
}

/* {RANDOM}.increment */
static EIF_INTEGER_32 F970_9111_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRB(EIF_INTEGER_32)
	RTOUDB(EIF_INTEGER_32, 600)

	
	RTEAA("increment", 969, Current, 0, 0, 12665);
	RTOTP;
	RTHOOK(1);
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTOTE;
	RTHOOK(2);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F970_9111 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_INTEGER_32,600,F970_9111_body,(Current));
}

/* {RANDOM}.has */
EIF_BOOLEAN F970_9114 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("has", 969, Current, 0, 1, 12645);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	if ((EIF_BOOLEAN) (arg1 < RTOUCB(EIF_INTEGER_32,598,F970_9109, (Current)))) {
		Result = (EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 0L));
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {RANDOM}.i_th */
EIF_INTEGER_32 F970_9115 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("i_th", 969, Current, 1, 1, 12646);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg1 >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_2_))) {
		RTHOOK(2);
		Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_3_);
		RTHOOK(3);
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_2_);
	} else {
		RTHOOK(4);
		Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_1_);
	}
	for (;;) {
		RTHOOK(5);
		if ((EIF_BOOLEAN)(loc1 == arg1)) break;
		RTHOOK(6);
		ti4_1 = F970_9121(Current, Result);
		Result = (EIF_INTEGER_32) ti4_1;
		RTHOOK(7);
		loc1++;
	}
	RTHOOK(8);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_3_) = (EIF_INTEGER_32) Result;
	RTHOOK(9);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_2_) = (EIF_INTEGER_32) arg1;
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {RANDOM}.new_cursor */
EIF_REFERENCE F970_9120 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("new_cursor", 969, Current, 0, 0, 12651);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_1_0_4_0_0_0_0_);
	F970_9107(RTCW(Result), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_1_));
	RTHOOK(2);
	F723_8327(RTCW(Result));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {RANDOM}.randomize */
EIF_INTEGER_32 F970_9121 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_REAL_64 tr8_4;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("randomize", 969, Current, 0, 1, 12652);
	RTGC;
	RTHOOK(1);
	tr8_1 = RTOUCB(EIF_REAL_64,601,F970_9126, (Current));
	tr8_2 = (EIF_REAL_64) (arg1);
	tr8_3 = RTOUCB(EIF_REAL_64,602,F970_9127, (Current));
	tr8_4 = RTOUCB(EIF_REAL_64,603,F970_9125, (Current));
	tr8_1 = F970_9122(Current, (EIF_REAL_64) ((EIF_REAL_64) (tr8_1 * tr8_2) + tr8_3), tr8_4);
	Result = (EIF_INTEGER_32) tr8_1;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {RANDOM}.double_mod */
EIF_REAL_64 F970_9122 (EIF_REFERENCE Current, EIF_REAL_64 arg1, EIF_REAL_64 arg2)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("double_mod", 969, Current, 0, 2, 12653);
	RTGC;
	RTHOOK(1);
	Result = (EIF_REAL_64) floor((double) (EIF_REAL_64) ((EIF_REAL_64) (arg1) /  (EIF_REAL_64) (arg2)));
	Result = (EIF_REAL_64) (EIF_REAL_64) (arg1 - (EIF_REAL_64) (Result * arg2));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {RANDOM}.dmod */
static EIF_REAL_64 F970_9125_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRB(EIF_REAL_64)
	RTOUDB(EIF_REAL_64, 603)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("dmod", 969, Current, 0, 0, 12656);
	RTGC;
	RTOTP;
	RTHOOK(1);
	Result = (EIF_REAL_64) (RTOUCB(EIF_INTEGER_32,598,F970_9109, (Current)));
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REAL_64 F970_9125 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_REAL_64,603,F970_9125_body,(Current));
}

/* {RANDOM}.dmul */
static EIF_REAL_64 F970_9126_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRB(EIF_REAL_64)
	RTOUDB(EIF_REAL_64, 601)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("dmul", 969, Current, 0, 0, 12657);
	RTGC;
	RTOTP;
	RTHOOK(1);
	Result = (EIF_REAL_64) (RTOUCB(EIF_INTEGER_32,599,F970_9110, (Current)));
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REAL_64 F970_9126 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_REAL_64,601,F970_9126_body,(Current));
}

/* {RANDOM}.dinc */
static EIF_REAL_64 F970_9127_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRB(EIF_REAL_64)
	RTOUDB(EIF_REAL_64, 602)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("dinc", 969, Current, 0, 0, 12658);
	RTGC;
	RTOTP;
	RTHOOK(1);
	Result = (EIF_REAL_64) (RTOUCB(EIF_INTEGER_32,600,F970_9111, (Current)));
	RTOTE;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REAL_64 F970_9127 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCB(EIF_REAL_64,602,F970_9127_body,(Current));
}

void EIF_Minit505 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
