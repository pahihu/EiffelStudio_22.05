
#ifndef _C11_co537_
#define _C11_co537_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1112_9404(EIF_REFERENCE);
extern void EIF_Minit537(void);

#ifdef __cplusplus
}
#endif

#endif
