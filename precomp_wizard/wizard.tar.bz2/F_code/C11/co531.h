
#ifndef _C11_co531_
#define _C11_co531_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1106_9373(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1106_9376(EIF_REFERENCE);
extern void EIF_Minit531(void);
extern void F1242_11304(EIF_REFERENCE, EIF_REFERENCE);
extern void F1242_11303(EIF_REFERENCE, EIF_REFERENCE);
extern void F1242_11317(EIF_REFERENCE, EIF_CHARACTER_32);

#ifdef __cplusplus
}
#endif

#endif
