
#ifndef _C11_kl541_
#define _C11_kl541_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F1116_9413_body(EIF_REFERENCE);
extern EIF_REFERENCE F1116_9413(EIF_REFERENCE);
extern void EIF_Minit541(void);

#ifdef __cplusplus
}
#endif

#endif
