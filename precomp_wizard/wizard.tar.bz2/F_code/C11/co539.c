/*
 * Code for class CONF_ERROR_REGEXP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co539.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_ERROR_REGEXP}.make */
void F1114_9408 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTEAA("make", 1113, Current, 0, 3, 13646);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg2;
	RTHOOK(3);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_3_) = (EIF_INTEGER_32) arg3;
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {CONF_ERROR_REGEXP}.text */
EIF_REFERENCE F1114_9409 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("text", 1113, Current, 0, 0, 13647);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(474,F421_6046, (Current));
	Result = F1749_19548(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_2_), *(EIF_REFERENCE *)(Current + _REFACS_1_), *(EIF_REFERENCE *)(Current), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_3_));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit539 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
