/*
 * Code for class CONF_ERROR_PARSE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co533.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_ERROR_PARSE}.text */
EIF_REFERENCE F1108_9390 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,tr1);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTEAA("text", 1107, Current, 2, 0, 13634);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = RTMS32_EX_H("P\000\000\000a\000\000\000r\000\000\000s\000\000\000e\000\000\000 \000\000\000e\000\000\000r\000\000\000r\000\000\000o\000\000\000r\000\000\000",11,62499698);
	F1240_11191(RTCW(Result), tr1);
	RTHOOK(2);
	switch (*(EIF_INTEGER_32 *)(Current + O8253[dtype-1107])) {
		case 1L:
			RTHOOK(3);
			tr1 = RTMS32_EX_H(" \000\000\000(\000\000\000X\000\000\000M\000\000\000L\000\000\000 \000\000\000s\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000)\000\000\000 \000\000\000",14,1829568544);
			F1242_11304(RTCW(Result), tr1);
			break;
		case 2L:
			RTHOOK(4);
			tr1 = RTMS32_EX_H(" \000\000\000(\000\000\000A\000\000\000C\000\000\000E\000\000\000 \000\000\000s\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000)\000\000\000 \000\000\000",14,1394758688);
			F1242_11304(RTCW(Result), tr1);
			break;
	}
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(6);
		tr1 = RTMS32_EX_H(" \000\000\000i\000\000\000n\000\000\000 \000\000\000",4,543780384);
		tr1 = F1242_11323(tr1, loc1);
		tr2 = RTMS32_EX_H(" \000\000\000(\000\000\000l\000\000\000i\000\000\000n\000\000\000e\000\000\000 \000\000\000",7,774604064);
		tr1 = F1242_11323(RTCW(tr1), tr2);
		F1242_11304(RTCW(Result), tr1);
		RTHOOK(7);
		F1242_11307(RTCW(Result), *(EIF_INTEGER_32 *)(Current + O8251[dtype-1107]));
		RTHOOK(8);
		tr1 = RTMS32_EX_H(",\000\000\000 \000\000\000c\000\000\000o\000\000\000l\000\000\000u\000\000\000m\000\000\000n\000\000\000 \000\000\000",9,933104928);
		F1242_11304(RTCW(Result), tr1);
		RTHOOK(9);
		F1242_11307(RTCW(Result), *(EIF_INTEGER_32 *)(Current + O8252[dtype-1107]));
		RTHOOK(10);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ')';
		F1242_11317(RTCW(Result), tw1);
	}
	RTHOOK(11);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTHOOK(12);
		tr1 = RTMS32_EX_H(":\000\000\000 \000\000\000",2,14880);
		F1242_11304(RTCW(Result), tr1);
		RTHOOK(13);
		F1242_11303(RTCW(Result), loc2);
	}
	RTHOOK(14);
	RTLE;
	RTEE;
	return Result;
}

/* {CONF_ERROR_PARSE}.set_xml_parse_mode */
void F1108_9392 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_xml_parse_mode", 1107, Current, 0, 0, 13636);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O8253[Dtype(Current)-1107]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(2);
	RTEE;
}

/* {CONF_ERROR_PARSE}.set_position */
void F1108_9394 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("set_position", 1107, Current, 0, 3, 13623);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current + O8251[dtype-1107]) = (EIF_INTEGER_32) arg2;
	RTHOOK(3);
	*(EIF_INTEGER_32 *)(Current + O8252[dtype-1107]) = (EIF_INTEGER_32) arg3;
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {CONF_ERROR_PARSE}.set_message */
void F1108_9395 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_message", 1107, Current, 0, 1, 13624);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

void EIF_Minit533 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
