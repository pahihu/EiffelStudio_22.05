/*
 * Code for class CONF_ERROR_CYCLE_IN_REDIRECTION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co530.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_ERROR_CYCLE_IN_REDIRECTION}.make */
void F1105_9369 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTEAA("make", 1104, Current, 0, 2, 13605);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	{
		static EIF_TYPE_INDEX typarr0[] = {891,1303,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7706[Dtype(RTCW(arg2))-780])(arg2);
	F892_8780(RTCW(tr1), ti4_1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7716[Dtype(RTCW(tr1))-882])(tr1, arg2);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {CONF_ERROR_CYCLE_IN_REDIRECTION}.text */
EIF_REFERENCE F1105_9372 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Result);
	RTLR(2,loc1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("text", 1104, Current, 1, 0, 13608);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = RTMS32_EX_H("C\000\000\000y\000\000\000c\000\000\000l\000\000\000e\000\000\000 \000\000\000i\000\000\000n\000\000\000 \000\000\000c\000\000\000o\000\000\000n\000\000\000f\000\000\000i\000\000\000g\000\000\000u\000\000\000r\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000 \000\000\000f\000\000\000i\000\000\000l\000\000\000e\000\000\000 \000\000\000r\000\000\000e\000\000\000d\000\000\000i\000\000\000r\000\000\000e\000\000\000c\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000:\000\000\000",40,352391738);
	F1240_11191(RTCW(Result), tr1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = F892_8794(RTCW(tr1));
	for (;;) {
		tb1 = F1036_9256(loc1);
		if (tb1) break;
		RTHOOK(3);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
		F1242_11317(RTCW(Result), tw1);
		RTHOOK(4);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\011';
		F1242_11317(RTCW(Result), tw1);
		RTHOOK(5);
		tr1 = F1036_9247(loc1);
		tr1 = F1304_12658(RTCW(tr1));
		F1242_11304(RTCW(Result), tr1);
		RTHOOK(6);
		F1036_9262(loc1);
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit530 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
