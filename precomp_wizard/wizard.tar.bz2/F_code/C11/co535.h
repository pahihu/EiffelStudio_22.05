
#ifndef _C11_co535_
#define _C11_co535_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1110_9402(EIF_REFERENCE);
extern void EIF_Minit535(void);

#ifdef __cplusplus
}
#endif

#endif
