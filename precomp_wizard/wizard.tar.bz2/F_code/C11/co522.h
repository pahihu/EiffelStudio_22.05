
#ifndef _C11_co522_
#define _C11_co522_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1097_9344(EIF_REFERENCE);
extern void EIF_Minit522(void);
extern EIF_REFERENCE F86_1480(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R8213[])();

#ifdef __cplusplus
}
#endif

#endif
