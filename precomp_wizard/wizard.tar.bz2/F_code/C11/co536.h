
#ifndef _C11_co536_
#define _C11_co536_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1111_9403(EIF_REFERENCE);
extern void EIF_Minit536(void);

#ifdef __cplusplus
}
#endif

#endif
