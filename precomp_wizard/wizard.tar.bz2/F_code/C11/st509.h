
#ifndef _C11_st509_
#define _C11_st509_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1060_9273(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F1060_9274(EIF_REFERENCE);
extern EIF_REFERENCE F1060_9275(EIF_REFERENCE);
extern EIF_REFERENCE F1060_9277(EIF_REFERENCE);
extern EIF_INTEGER_32 F1060_9278(EIF_REFERENCE);
extern void EIF_Minit509(void);
extern EIF_INTEGER_32 F1240_11241(EIF_REFERENCE);
extern char *(*R9757[])();

#ifdef __cplusplus
}
#endif

#endif
