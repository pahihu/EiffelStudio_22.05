/*
 * Code for class UC_UTF8_ROUTINES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "uc546.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UC_UTF8_ROUTINES}.encoded_first_value */
EIF_INTEGER_32 F1126_9537 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("encoded_first_value", 1125, Current, 0, 1, 13811);
	RTGC;
	RTHOOK(1);
	Result = (EIF_INTEGER_32) (arg1);
	RTHOOK(2);
	if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '')) {
	} else {
		RTHOOK(3);
		if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\337')) {
			RTHOOK(4);
			Result %= ((EIF_INTEGER_32) 32L);
		} else {
			RTHOOK(5);
			if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\357')) {
				RTHOOK(6);
				Result %= ((EIF_INTEGER_32) 16L);
			} else {
				RTHOOK(7);
				if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\364')) {
					RTHOOK(8);
					RTHOOK(9);
					RTLE;
					RTEE;
					return (EIF_INTEGER_32) (EIF_INTEGER_32) (Result % ((EIF_INTEGER_32) 8L));
				}
			}
		}
	}
	RTHOOK(12);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.encoded_next_value */
EIF_INTEGER_32 F1126_9538 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("encoded_next_value", 1125, Current, 0, 1, 13812);
	RTGC;
	RTHOOK(1);
	Result = (EIF_INTEGER_32) (arg1);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result % ((EIF_INTEGER_32) 64L));
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.encoded_byte_count */
EIF_INTEGER_32 F1126_9543 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("encoded_byte_count", 1125, Current, 0, 1, 13817);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '')) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		RTHOOK(4);
		if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\337')) {
			RTHOOK(5);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		} else {
			RTHOOK(6);
			if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\357')) {
				RTHOOK(7);
				RTHOOK(8);
				RTLE;
				RTEE;
				return (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
			} else {
				RTHOOK(9);
				RTHOOK(10);
				RTLE;
				RTEE;
				return (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
			}
		}
	}
	RTHOOK(13);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.substring_byte_count */
EIF_INTEGER_32 F1126_9545 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLR(4,loc4);
	RTLR(5,loc5);
	RTLR(6,loc6);
	RTLIU(7);
	
	RTEAA("substring_byte_count", 1125, Current, 6, 3, 13819);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg2 <= arg3)) {
		RTHOOK(2);
		tb1 = '\0';
		tr1 = RTOUCR(672,F1116_9413, (Current));
		tr2 = RTOUCR(673,F1126_9582, (Current));
		tb2 = F14_118(RTCW(tr1), arg1, tr2);
		if (tb2) {
			loc4 = arg1;
			loc4 = RTRV(eif_new_type(1244, 0x00),loc4);
			tb1 = EIF_TEST(loc4);
		}
		if (tb1) {
			RTHOOK(3);
			loc3 = (EIF_INTEGER_32) arg2;
			for (;;) {
				RTHOOK(4);
				if ((EIF_BOOLEAN) (loc3 > arg3)) break;
				RTHOOK(5);
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7739[Dtype(loc4)-805])(loc4, loc3));
				Result += F1126_9547(Current, tc1);
				RTHOOK(6);
				loc3++;
			}
		} else {
			RTHOOK(7);
			tb1 = '\0';
			tr1 = RTOUCR(672,F1116_9413, (Current));
			tr2 = RTOUCR(674,F1126_9583, (Current));
			tb2 = F14_118(RTCW(tr1), arg1, tr2);
			if (tb2) {
				loc5 = arg1;
				loc5 = RTRV(eif_new_type(1797, 0x00),loc5);
				tb1 = EIF_TEST(loc5);
			}
			if (tb1) {
				RTHOOK(8);
				tb1 = '\0';
				if ((EIF_BOOLEAN)(arg2 == ((EIF_INTEGER_32) 1L))) {
					ti4_1 = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_2_);
					tb1 = (EIF_BOOLEAN)(arg3 == ti4_1);
				}
				if (tb1) {
					RTHOOK(9);
					Result = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_3_);
				} else {
					RTHOOK(10);
					loc1 = F1798_20863(loc5, arg2);
					RTHOOK(11);
					ti4_1 = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN)(arg3 == ti4_1)) {
						RTHOOK(12);
						Result = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_3_);
						Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (Result - loc1) + ((EIF_INTEGER_32) 1L));
					} else {
						RTHOOK(13);
						loc2 = F1798_20862(loc5, loc1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg3 - arg2) + ((EIF_INTEGER_32) 1L)));
						RTHOOK(14);
						Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - loc1);
					}
				}
			} else {
				RTHOOK(15);
				loc6 = arg1;
				loc6 = RTRV(eif_new_type(1798, 0x00),loc6);
				if (EIF_TEST(loc6)) {
					RTHOOK(16);
					tb1 = '\0';
					if ((EIF_BOOLEAN)(arg2 == ((EIF_INTEGER_32) 1L))) {
						ti4_1 = *(EIF_INTEGER_32 *)(loc6);
						tb1 = (EIF_BOOLEAN)(arg3 == ti4_1);
					}
					if (tb1) {
						RTHOOK(17);
						Result = *(EIF_INTEGER_32 *)(loc6);
						RTHOOK(18);
						RTLE;
						RTEE;
						return (EIF_INTEGER_32) Result;
					} else {
						RTHOOK(19);
						loc1 = (RTNA((loc6, arg2)), ((EIF_INTEGER_32) 0));
						RTHOOK(20);
						ti4_1 = *(EIF_INTEGER_32 *)(loc6);
						if ((EIF_BOOLEAN)(arg3 == ti4_1)) {
							RTHOOK(21);
							Result = *(EIF_INTEGER_32 *)(loc6);
							Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (Result - loc1) + ((EIF_INTEGER_32) 1L));
						} else {
							RTHOOK(22);
							loc2 = (RTNA((loc6, loc1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg3 - arg2) + ((EIF_INTEGER_32) 1L)))), ((EIF_INTEGER_32) 0));
							RTHOOK(23);
							RTHOOK(24);
							RTLE;
							RTEE;
							return (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - loc1);
						}
					}
				} else {
					RTHOOK(25);
					loc3 = (EIF_INTEGER_32) arg2;
					for (;;) {
						RTHOOK(26);
						if ((EIF_BOOLEAN) (loc3 > arg3)) break;
						RTHOOK(27);
						tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R9604[Dtype(RTCW(arg1))-1240])(arg1, loc3);
						Result += F1126_9548(Current, tw1);
						RTHOOK(28);
						loc3++;
					}
				}
			}
		}
	}
	RTHOOK(30);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.character_byte_count */
EIF_INTEGER_32 F1126_9546 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("character_byte_count", 1125, Current, 0, 1, 13820);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) F1126_9547(Current, arg1);
}

/* {UC_UTF8_ROUTINES}.character_8_byte_count */
EIF_INTEGER_32 F1126_9547 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("character_8_byte_count", 1125, Current, 0, 1, 13821);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '')) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		RTHOOK(4);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	}/* NOTREACHED */
	
}

/* {UC_UTF8_ROUTINES}.character_32_byte_count */
EIF_INTEGER_32 F1126_9548 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 tu4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("character_32_byte_count", 1125, Current, 0, 1, 13822);
	RTGC;
	RTHOOK(1);
	tu4_1 = (EIF_NATURAL_32) arg1;
	Result = F1126_9550(Current, tu4_1);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.code_byte_count */
EIF_INTEGER_32 F1126_9549 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 tu4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("code_byte_count", 1125, Current, 0, 1, 13823);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg1 <= ((EIF_INTEGER_32) 1114111L))) {
		RTHOOK(2);
		tu4_1 = (EIF_NATURAL_32) arg1;
		Result = F1126_9550(Current, tu4_1);
	} else {
		RTHOOK(3);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.natural_32_code_byte_count */
EIF_INTEGER_32 F1126_9550 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("natural_32_code_byte_count", 1125, Current, 0, 1, 13824);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg1 < ((EIF_NATURAL_32) 128U))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		RTHOOK(4);
		if ((EIF_BOOLEAN) (arg1 < ((EIF_NATURAL_32) 2048U))) {
			RTHOOK(5);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		} else {
			RTHOOK(6);
			if ((EIF_BOOLEAN) (arg1 < ((EIF_NATURAL_32) 55296U))) {
				RTHOOK(7);
				Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
			} else {
				RTHOOK(8);
				if ((EIF_BOOLEAN) (arg1 <= ((EIF_NATURAL_32) 57343U))) {
					RTHOOK(9);
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				} else {
					RTHOOK(10);
					if ((EIF_BOOLEAN) (arg1 < ((EIF_NATURAL_32) 65536U))) {
						RTHOOK(11);
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
					} else {
						RTHOOK(12);
						if ((EIF_BOOLEAN) (arg1 <= ((EIF_NATURAL_32) 1114111U))) {
							RTHOOK(13);
							RTHOOK(14);
							RTLE;
							RTEE;
							return (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
						} else {
							RTHOOK(15);
							RTHOOK(16);
							RTLE;
							RTEE;
							return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						}
					}
				}
			}
		}
	}
	RTHOOK(19);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.string_to_utf8 */
EIF_REFERENCE F1126_9553 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("string_to_utf8", 1125, Current, 1, 1, 13827);
	RTGC;
	RTHOOK(1);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9640[Dtype(RTCW(arg1))-1240])(arg1);
	Result = F1126_9554(Current, arg1, ((EIF_INTEGER_32) 1L), ti4_1);
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.substring_to_utf8 */
EIF_REFERENCE F1126_9554 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("substring_to_utf8", 1125, Current, 1, 3, 13828);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1244, 0x00).id, 1244, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = F1126_9545(Current, arg1, arg2, arg3);
	F1243_11356(RTCW(Result), ti4_1);
	RTHOOK(2);
	F1126_9557(Current, Result, arg1, arg2, arg3);
	RTHOOK(10);
	RTLE;
	RTEE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.append_substring_to_utf8 */
void F1126_9557 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("append_substring_to_utf8", 1125, Current, 3, 4, 13831);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg3 <= arg4)) {
		RTHOOK(2);
		loc1 = (EIF_INTEGER_32) arg3;
		RTHOOK(3);
		loc2 = (EIF_INTEGER_32) arg4;
		for (;;) {
			RTHOOK(4);
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			RTHOOK(5);
			tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R9603[Dtype(RTCW(arg2))-1240])(arg2, loc1);
			F1126_9559(Current, arg1, tu4_1);
			RTHOOK(6);
			loc1++;
		}
	}
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {UC_UTF8_ROUTINES}.append_natural_32_code_to_utf8 */
void F1126_9559 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_NATURAL_32 arg2)
{
	GTCX
	RTEX;
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc2 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_NATURAL_32 loc4 = (EIF_NATURAL_32) 0;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("append_natural_32_code_to_utf8", 1125, Current, 4, 2, 13833);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg2 < ((EIF_NATURAL_32) 128U))) {
		RTHOOK(2);
		tc1 = (EIF_CHARACTER_8) arg2;
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R9867[Dtype(RTCW(arg1))-1244])(arg1, tc1);
	} else {
		RTHOOK(3);
		if ((EIF_BOOLEAN) (arg2 < ((EIF_NATURAL_32) 2048U))) {
			RTHOOK(4);
			loc4 = (EIF_NATURAL_32) arg2;
			RTHOOK(5);
			loc1 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (loc4 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L)));
			RTHOOK(6);
			loc4 /= (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L);
			RTHOOK(7);
			tc1 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) (loc4 + (EIF_NATURAL_32) ((EIF_INTEGER_32) 192L)));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R9867[Dtype(RTCW(arg1))-1244])(arg1, tc1);
			RTHOOK(8);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R9867[Dtype(RTCW(arg1))-1244])(arg1, loc1);
		} else {
			RTHOOK(9);
			if ((EIF_BOOLEAN) (arg2 < ((EIF_NATURAL_32) 65536U))) {
				RTHOOK(10);
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (arg2 >= ((EIF_NATURAL_32) 55296U)) && (EIF_BOOLEAN) (arg2 <= ((EIF_NATURAL_32) 57343U)))) {
					RTHOOK(11);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R9867[Dtype(RTCW(arg1))-1244])(arg1, (EIF_CHARACTER_8) '\377');
				} else {
					RTHOOK(12);
					loc4 = (EIF_NATURAL_32) arg2;
					RTHOOK(13);
					loc2 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (loc4 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L)));
					RTHOOK(14);
					loc4 /= (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L);
					RTHOOK(15);
					loc1 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (loc4 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L)));
					RTHOOK(16);
					loc4 /= (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L);
					RTHOOK(17);
					tc1 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) (loc4 + (EIF_NATURAL_32) ((EIF_INTEGER_32) 224L)));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R9867[Dtype(RTCW(arg1))-1244])(arg1, tc1);
					RTHOOK(18);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R9867[Dtype(RTCW(arg1))-1244])(arg1, loc1);
					RTHOOK(19);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R9867[Dtype(RTCW(arg1))-1244])(arg1, loc2);
				}
			} else {
				RTHOOK(20);
				if ((EIF_BOOLEAN) (arg2 <= ((EIF_NATURAL_32) 1114111U))) {
					RTHOOK(21);
					loc4 = (EIF_NATURAL_32) arg2;
					RTHOOK(22);
					loc3 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (loc4 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L)));
					RTHOOK(23);
					loc4 /= (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L);
					RTHOOK(24);
					loc2 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (loc4 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L)));
					RTHOOK(25);
					loc4 /= (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L);
					RTHOOK(26);
					loc1 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (loc4 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L)));
					RTHOOK(27);
					loc4 /= (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L);
					RTHOOK(28);
					tc1 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) (loc4 + (EIF_NATURAL_32) ((EIF_INTEGER_32) 240L)));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R9867[Dtype(RTCW(arg1))-1244])(arg1, tc1);
					RTHOOK(29);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R9867[Dtype(RTCW(arg1))-1244])(arg1, loc1);
					RTHOOK(30);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R9867[Dtype(RTCW(arg1))-1244])(arg1, loc2);
					RTHOOK(31);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R9867[Dtype(RTCW(arg1))-1244])(arg1, loc3);
				} else {
					RTHOOK(32);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R9867[Dtype(RTCW(arg1))-1244])(arg1, (EIF_CHARACTER_8) '\377');
				}
			}
		}
	}
	RTHOOK(35);
	RTLE;
	RTEE;
}

/* {UC_UTF8_ROUTINES}.dummy_string */

EIF_REFERENCE F1126_9582 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (673,RTMS_EX_H("",0,0));
}

/* {UC_UTF8_ROUTINES}.dummy_uc_string */
static EIF_REFERENCE F1126_9583_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(674)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("dummy_uc_string", 1125, Current, 0, 0, 13857);
	RTGC;
	RTOTP;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1797, 0x00).id, 1797, _OBJSIZ_1_1_0_6_0_0_0_0_);
	F1798_20759(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1126_9583 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(674,F1126_9583_body,(Current));
}

void EIF_Minit546 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
