
#ifndef _C11_co540_
#define _C11_co540_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1115_9412(EIF_REFERENCE);
extern void EIF_Minit540(void);

#ifdef __cplusplus
}
#endif

#endif
