/*
 * Code for class KL_INTEGER_ROUTINES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl544.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_INTEGER_ROUTINES}.to_character */
EIF_CHARACTER_8 F1119_9454 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_CHARACTER_8 tc1;
	
	
	RTEAA("to_character", 1118, Current, 0, 1, 13710);
	RTHOOK(1);
	tc1 = (EIF_CHARACTER_8) arg1;
	RTHOOK(2);
	RTEE;
	return (EIF_CHARACTER_8) tc1;
}

/* {KL_INTEGER_ROUTINES}.to_integer */
EIF_INTEGER_32 F1119_9458 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("to_integer", 1118, Current, 0, 1, 13695);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) arg1;
}

void EIF_Minit544 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
