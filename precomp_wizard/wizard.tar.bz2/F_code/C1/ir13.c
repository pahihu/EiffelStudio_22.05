/*
 * Code for class IRON_CLIENT_DB
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir13.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_CLIENT_DB}.make */
void F18_141 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("make", 17, Current, 0, 1, 175);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {IRON_CLIENT_DB}.revision */
EIF_INTEGER_32 F18_143 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("revision", 17, Current, 2, 0, 177);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1146, 0x00).id, 1146, _OBJSIZ_4_6_2_4_1_1_2_1_);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = RTOUCR(658,F505_7218, (RTCW(tr1)));
	F1146_10043(RTCW(loc1), tr1);
	RTHOOK(2);
	tb1 = '\0';
	tb2 = F1146_10077(RTCW(loc1));
	if (tb2) {
		tb2 = F1146_10080(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(3);
		F1146_10112(RTCW(loc1));
		RTHOOK(4);
		F1146_10190(RTCW(loc1));
		RTHOOK(5);
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
		RTHOOK(6);
		tb1 = F1237_11090(RTCW(loc2));
		if (tb1) {
			RTHOOK(7);
			Result = F1237_11124(RTCW(loc2));
		} else {
			RTHOOK(8);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		}
		RTHOOK(9);
		F1146_10129(RTCW(loc1));
	} else {
		RTHOOK(10);
		RTHOOK(11);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	}
	RTHOOK(12);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_CLIENT_DB}.repositories */
EIF_REFERENCE F18_144 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("repositories", 17, Current, 1, 0, 178);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(256, 0x00).id, 256, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = RTOUCR(657,F505_7217, (RTCW(tr1)));
	F257_4398(RTCW(loc1), tr1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
	RTHOOK(3);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {IRON_CLIENT_DB}.installed_packages */
EIF_REFERENCE F18_145 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(15);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLR(6,loc6);
	RTLR(7,loc4);
	RTLR(8,loc7);
	RTLR(9,loc8);
	RTLR(10,loc9);
	RTLR(11,Result);
	RTLR(12,loc10);
	RTLR(13,tr2);
	RTLR(14,loc11);
	RTLIU(15);
	
	RTEAA("installed_packages", 17, Current, 11, 0, 179);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {891,1289,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc5 = RTLNSMART(typres0.id);
	}
	F892_8780(RTCW(loc5), ((EIF_INTEGER_32) 0L));
	RTHOOK(2);
	F567_8076(RTCW(loc5));
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = RTOUCR(659,F505_7221, (RTCW(tr1)));
	RTHOOK(4);
	{
		static EIF_TYPE_INDEX typarr0[] = {891,1303,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc3 = RTLNS(typres0.id, 891, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F892_8780(RTCW(loc3), ((EIF_INTEGER_32) 10L));
	RTHOOK(5);
	loc2 = RTLNS(eif_new_type(111, 0x00).id, 111, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F112_1848(RTCW(loc2), loc3);
	RTHOOK(6);
	tr1 = F1304_12638(RTCW(loc1));
	tr1 = F1304_12640(RTCW(tr1));
	F112_1852(RTCW(loc2), tr1);
	RTHOOK(7);
	loc6 = F892_8794(RTCW(loc3));
	for (;;) {
		tb1 = F1036_9256(loc6);
		if (tb1) break;
		RTHOOK(8);
		loc4 = RTLNS(eif_new_type(9, 0x00).id, 9, _OBJSIZ_4_0_0_0_0_0_0_0_);
		tr1 = F1036_9247(loc6);
		F10_94(RTCW(loc4), tr1);
		RTHOOK(9);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_3_);
		loc7 = tr1;
		if (EIF_TEST(loc7)) {
			RTHOOK(10);
			F892_8820(RTCW(loc5), loc7);
		} else {
			RTHOOK(11);
			tb2 = '\0';
			tr1 = F1036_9247(loc6);
			tr1 = F18_152(Current, tr1);
			loc8 = tr1;
			if (EIF_TEST(loc8)) {
				tr1 = F18_153(Current, loc8);
				loc9 = tr1;
				tb2 = EIF_TEST(loc9);
			}
			if (tb2) {
				RTHOOK(12);
				F892_8820(RTCW(loc5), loc9);
			}
		}
		RTHOOK(13);
		F1036_9262(loc6);
	}
	RTHOOK(14);
	{
		static EIF_TYPE_INDEX typarr0[] = {891,1289,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		Result = RTLNS(typres0.id, 891, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	ti4_1 = F892_8801(RTCW(loc5));
	F892_8780(RTCW(Result), ti4_1);
	RTHOOK(15);
	F567_8076(RTCW(Result));
	RTHOOK(16);
	loc10 = F892_8794(RTCV(F18_144(Current)));
	for (;;) {
		tb2 = F1036_9256(loc10);
		if (tb2) break;
		RTHOOK(17);
		tb3 = F724_8337(RTCW(loc5));
		if (tb3) break;
		RTHOOK(18);
		F892_8811(RTCW(loc5));
		for (;;) {
			RTHOOK(19);
			tb4 = F859_8654(RTCW(loc5));
			if (tb4) break;
			RTHOOK(20);
			tr1 = F1036_9247(loc10);
			tr2 = F892_8785(RTCW(loc5));
			tr2 = *(EIF_REFERENCE *)(RTCW(tr2));
			tb5 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R7507[Dtype(RTCW(tr1))-1287])(tr1, tr2);
			if (tb5) {
				RTHOOK(21);
				tr1 = F892_8785(RTCW(loc5));
				F892_8820(RTCW(Result), tr1);
				RTHOOK(22);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R7675[Dtype(RTCW(loc5))-780])(loc5);
			} else {
				RTHOOK(23);
				F892_8813(RTCW(loc5));
			}
		}
		RTHOOK(24);
		F1036_9262(loc10);
	}
	RTHOOK(25);
	tb5 = F724_8337(RTCW(loc5));
	if ((EIF_BOOLEAN) !tb5) {
		RTHOOK(26);
		loc11 = F892_8794(RTCW(loc5));
		for (;;) {
			tb5 = F1036_9256(loc11);
			if (tb5) break;
			RTHOOK(27);
			tr1 = F1036_9247(loc11);
			F892_8820(RTCW(Result), tr1);
			RTHOOK(28);
			F1036_9262(loc11);
		}
	}
	RTHOOK(29);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_CLIENT_DB}.quick_installed_package */
EIF_REFERENCE F18_146 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(16);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLR(6,loc6);
	RTLR(7,loc7);
	RTLR(8,arg1);
	RTLR(9,loc4);
	RTLR(10,loc8);
	RTLR(11,loc9);
	RTLR(12,loc10);
	RTLR(13,loc11);
	RTLR(14,tr2);
	RTLR(15,Result);
	RTLIU(16);
	
	RTEAA("quick_installed_package", 17, Current, 11, 1, 180);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {891,1289,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc5 = RTLNS(typres0.id, 891, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F892_8780(RTCW(loc5), ((EIF_INTEGER_32) 0L));
	RTHOOK(2);
	F567_8076(RTCW(loc5));
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = RTOUCR(659,F505_7221, (RTCW(tr1)));
	RTHOOK(4);
	{
		static EIF_TYPE_INDEX typarr0[] = {891,1303,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc3 = RTLNS(typres0.id, 891, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F892_8780(RTCW(loc3), ((EIF_INTEGER_32) 10L));
	RTHOOK(5);
	loc2 = RTLNS(eif_new_type(111, 0x00).id, 111, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F112_1848(RTCW(loc2), loc3);
	RTHOOK(6);
	tr1 = F1304_12638(RTCW(loc1));
	tr1 = F1304_12640(RTCW(tr1));
	F112_1852(RTCW(loc2), tr1);
	RTHOOK(7);
	loc6 = F892_8794(RTCW(loc3));
	for (;;) {
		tb1 = F1036_9256(loc6);
		if (tb1) break;
		RTHOOK(8);
		tb2 = '\0';
		tr1 = F1036_9247(loc6);
		tr1 = F18_152(Current, tr1);
		tr1 = F18_154(Current, tr1);
		loc7 = tr1;
		if (EIF_TEST(loc7)) {
			tb3 = F1237_11101(loc7, arg1);
			tb2 = tb3;
		}
		if (tb2) {
			RTHOOK(9);
			loc4 = RTLNS(eif_new_type(9, 0x00).id, 9, _OBJSIZ_4_0_0_0_0_0_0_0_);
			tr1 = F1036_9247(loc6);
			F10_94(RTCW(loc4), tr1);
			RTHOOK(10);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_3_);
			loc8 = tr1;
			if (EIF_TEST(loc8)) {
				RTHOOK(11);
				F892_8820(RTCW(loc5), loc8);
			} else {
				RTHOOK(12);
				tb2 = '\0';
				tr1 = F1036_9247(loc6);
				tr1 = F18_152(Current, tr1);
				loc9 = tr1;
				if (EIF_TEST(loc9)) {
					tr1 = F18_153(Current, loc9);
					loc10 = tr1;
					tb2 = EIF_TEST(loc10);
				}
				if (tb2) {
					RTHOOK(13);
					F892_8820(RTCW(loc5), loc10);
				}
			}
		}
		RTHOOK(14);
		F1036_9262(loc6);
	}
	RTHOOK(15);
	loc11 = F892_8794(RTCV(F18_144(Current)));
	for (;;) {
		tb2 = F1036_9256(loc11);
		if (tb2) break;
		RTHOOK(16);
		tb3 = '\01';
		tb4 = F724_8337(RTCW(loc5));
		if (!tb4) {
			tb3 = (EIF_BOOLEAN)(Result != NULL);
		}
		if (tb3) break;
		RTHOOK(17);
		F892_8811(RTCW(loc5));
		for (;;) {
			RTHOOK(18);
			tb4 = '\01';
			tb5 = F859_8654(RTCW(loc5));
			if (!tb5) {
				tb4 = (EIF_BOOLEAN)(Result != NULL);
			}
			if (tb4) break;
			RTHOOK(19);
			tr1 = F1036_9247(loc11);
			tr2 = F892_8785(RTCW(loc5));
			tr2 = *(EIF_REFERENCE *)(RTCW(tr2));
			tb5 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R7507[Dtype(RTCW(tr1))-1287])(tr1, tr2);
			if (tb5) {
				RTHOOK(20);
				Result = F892_8785(RTCW(loc5));
				RTHOOK(21);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R7675[Dtype(RTCW(loc5))-780])(loc5);
			} else {
				RTHOOK(22);
				F892_8813(RTCW(loc5));
			}
		}
		RTHOOK(23);
		F1036_9262(loc11);
	}
	RTHOOK(24);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_CLIENT_DB}.file_content */
EIF_REFERENCE F18_152 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("file_content", 17, Current, 1, 1, 186);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1146, 0x00).id, 1146, _OBJSIZ_4_6_2_4_1_1_2_1_);
	F1146_10043(RTCW(loc1), arg1);
	RTHOOK(2);
	tb1 = '\0';
	tb2 = F1146_10077(RTCW(loc1));
	if (tb2) {
		tb2 = F1146_10096(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(3);
		F1146_10112(RTCW(loc1));
		RTHOOK(4);
		Result = RTLNS(eif_new_type(1244, 0x00).id, 1244, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1243_11356(RTCW(Result), ((EIF_INTEGER_32) 1024L));
		for (;;) {
			RTHOOK(5);
			tb1 = F599_8235(RTCW(loc1));
			if (tb1) break;
			RTHOOK(6);
			F1146_10191(RTCW(loc1), ((EIF_INTEGER_32) 1024L));
			RTHOOK(7);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9863[Dtype(RTCW(Result))-1244])(Result, tr1);
		}
		RTHOOK(8);
		F1146_10129(RTCW(loc1));
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_CLIENT_DB}.repo_package_from_json_string */
EIF_REFERENCE F18_153 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("repo_package_from_json_string", 17, Current, 1, 1, 187);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(257, 0x00).id, 257, _OBJSIZ_0_0_0_0_0_0_0_0_);
	RTHOOK(2);
	tr1 = F258_4409(RTCW(loc1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {IRON_CLIENT_DB}.repo_package_identifier_from_json_string */
EIF_REFERENCE F18_154 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("repo_package_identifier_from_json_string", 17, Current, 1, 1, 188);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		loc1 = RTLNS(eif_new_type(257, 0x00).id, 257, _OBJSIZ_0_0_0_0_0_0_0_0_);
		RTHOOK(3);
		tr1 = F258_4411(RTCW(loc1), arg1);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

void EIF_Minit13 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
