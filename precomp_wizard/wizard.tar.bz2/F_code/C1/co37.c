/*
 * Code for class CONF_CONDITION_CUSTOM_ATTRIBUTES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co37.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_CONDITION_CUSTOM_ATTRIBUTES}.is_case_insensitive */
EIF_BOOLEAN F42_617 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_case_insensitive", 41, Current, 0, 0, 737);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_NATURAL_8 *)(Current+ _CHROFF_0_1_) == ((EIF_NATURAL_8) 2U));
}

/* {CONF_CONDITION_CUSTOM_ATTRIBUTES}.is_regular_expression */
EIF_BOOLEAN F42_618 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_regular_expression", 41, Current, 0, 0, 738);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_NATURAL_8 *)(Current+ _CHROFF_0_1_) == ((EIF_NATURAL_8) 3U));
}

/* {CONF_CONDITION_CUSTOM_ATTRIBUTES}.is_wildcard */
EIF_BOOLEAN F42_619 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_wildcard", 41, Current, 0, 0, 739);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_NATURAL_8 *)(Current+ _CHROFF_0_1_) == ((EIF_NATURAL_8) 4U));
}

/* {CONF_CONDITION_CUSTOM_ATTRIBUTES}.set_inverted */
void F42_628 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_inverted", 41, Current, 0, 1, 731);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_0_0_) = (EIF_BOOLEAN) arg1;
	RTHOOK(2);
	RTEE;
}

/* {CONF_CONDITION_CUSTOM_ATTRIBUTES}.set_match */
void F42_629 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_match", 41, Current, 0, 1, 732);
	RTHOOK(1);
	*(EIF_NATURAL_8 *)(Current+ _CHROFF_0_1_) = (EIF_NATURAL_8) arg1;
	RTHOOK(3);
	RTEE;
}

void EIF_Minit37 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
