/*
 * Code for class EV_GTK_ENUMS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev32.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GTK_ENUMS}.gdk_expose_enum */
EIF_INTEGER_32 F37_562 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_expose_enum", 36, Current, 0, 0, 691);
	Result = (EIF_INTEGER_32) GDK_EXPOSE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_motion_notify_enum */
EIF_INTEGER_32 F37_563 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_motion_notify_enum", 36, Current, 0, 0, 692);
	Result = (EIF_INTEGER_32) GDK_MOTION_NOTIFY;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_button_press_enum */
EIF_INTEGER_32 F37_564 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_button_press_enum", 36, Current, 0, 0, 693);
	Result = (EIF_INTEGER_32) GDK_BUTTON_PRESS;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_2button_press_enum */
EIF_INTEGER_32 F37_565 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_2button_press_enum", 36, Current, 0, 0, 694);
	Result = (EIF_INTEGER_32) GDK_2BUTTON_PRESS;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_button_release_enum */
EIF_INTEGER_32 F37_567 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_button_release_enum", 36, Current, 0, 0, 696);
	Result = (EIF_INTEGER_32) GDK_BUTTON_RELEASE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_watch_enum */
EIF_INTEGER_32 F37_578 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_watch_enum", 36, Current, 0, 0, 675);
	Result = (EIF_INTEGER_32) GDK_WATCH;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_xterm_enum */
EIF_INTEGER_32 F37_579 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_xterm_enum", 36, Current, 0, 0, 676);
	Result = (EIF_INTEGER_32) GDK_XTERM;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_crosshair_enum */
EIF_INTEGER_32 F37_580 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_crosshair_enum", 36, Current, 0, 0, 677);
	Result = (EIF_INTEGER_32) GDK_CROSSHAIR;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_question_arrow_enum */
EIF_INTEGER_32 F37_581 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_question_arrow_enum", 36, Current, 0, 0, 678);
	Result = (EIF_INTEGER_32) GDK_QUESTION_ARROW;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_left_ptr_enum */
EIF_INTEGER_32 F37_582 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_left_ptr_enum", 36, Current, 0, 0, 679);
	Result = (EIF_INTEGER_32) GDK_LEFT_PTR;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_fleur_enum */
EIF_INTEGER_32 F37_583 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_fleur_enum", 36, Current, 0, 0, 680);
	Result = (EIF_INTEGER_32) GDK_FLEUR;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_size_sb_v_double_arrow_enum */
EIF_INTEGER_32 F37_584 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_size_sb_v_double_arrow_enum", 36, Current, 0, 0, 681);
	Result = (EIF_INTEGER_32) GDK_SB_V_DOUBLE_ARROW;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_hand2_enum */
EIF_INTEGER_32 F37_585 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_hand2_enum", 36, Current, 0, 0, 682);
	Result = (EIF_INTEGER_32) GDK_HAND2;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_ENUMS}.gtk_style_provider_priority_application */
EIF_NATURAL_32 F37_586 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_style_provider_priority_application", 36, Current, 0, 0, 683);
	Result = (EIF_NATURAL_32) GTK_STYLE_PROVIDER_PRIORITY_APPLICATION;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit32 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
