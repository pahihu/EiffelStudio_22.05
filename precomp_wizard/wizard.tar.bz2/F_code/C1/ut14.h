
#ifndef _C1_ut14_
#define _C1_ut14_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F19_155(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit14(void);
extern EIF_REFERENCE F86_1494(EIF_REFERENCE, EIF_REFERENCE);
extern void F1237_11059(EIF_REFERENCE);
extern char *(*R8756[])();

#ifdef __cplusplus
}
#endif

#endif
