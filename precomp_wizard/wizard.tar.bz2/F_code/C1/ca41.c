/*
 * Code for class CAIRO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ca41.h"
#include <cairo.h>
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F46_691
static EIF_NATURAL_32 inline_F46_691 (EIF_POINTER arg1)
{
	return (EIF_NATURAL_32) (cairo_get_reference_count((cairo_t*) arg1))
	;
}
#define INLINE_F46_691
#endif
#ifndef INLINE_F46_697
static void inline_F46_697 (EIF_POINTER arg1)
{
	cairo_surface_destroy((cairo_surface_t*) arg1)
	;
}
#define INLINE_F46_697
#endif
#ifndef INLINE_F46_740
static void inline_F46_740 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	double len = 2.0;
if (arg2) {
	cairo_set_dash ((cairo_t *) arg1, &len, 1, 0.0);
} else {
	cairo_set_dash ((cairo_t *) arg1, NULL, 0, 0.0);
}
	;
}
#define INLINE_F46_740
#endif
#ifndef INLINE_F46_755
static void inline_F46_755 (EIF_POINTER arg1)
{
	cairo_paint ((cairo_t*)arg1)
	;
}
#define INLINE_F46_755
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CAIRO}.operator_source */
EIF_INTEGER_8 F46_674 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("operator_source", 45, Current, 0, 0, 784);
	Result = (EIF_INTEGER_8) CAIRO_OPERATOR_SOURCE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.operator_over */
EIF_INTEGER_8 F46_675 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("operator_over", 45, Current, 0, 0, 785);
	Result = (EIF_INTEGER_8) CAIRO_OPERATOR_OVER;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.operator_atop */
EIF_INTEGER_8 F46_680 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("operator_atop", 45, Current, 0, 0, 790);
	Result = (EIF_INTEGER_8) CAIRO_OPERATOR_ATOP;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.operator_difference */
EIF_INTEGER_8 F46_686 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("operator_difference", 45, Current, 0, 0, 796);
	Result = (EIF_INTEGER_8) CAIRO_OPERATOR_DIFFERENCE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.operator_exclusion */
EIF_INTEGER_8 F46_687 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("operator_exclusion", 45, Current, 0, 0, 797);
	Result = (EIF_INTEGER_8) CAIRO_OPERATOR_EXCLUSION;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.operator_multiply */
EIF_INTEGER_8 F46_688 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("operator_multiply", 45, Current, 0, 0, 798);
	Result = (EIF_INTEGER_8) CAIRO_OPERATOR_MULTIPLY;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.create_context */
EIF_POINTER F46_689 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("create_context", 45, Current, 0, 1, 799);Result = (EIF_POINTER) cairo_create((cairo_surface_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.get_reference_count */
EIF_NATURAL_32 F46_691 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("get_reference_count", 45, Current, 0, 1, 801);
	Result = inline_F46_691 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.destroy */
void F46_692 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("destroy", 45, Current, 0, 1, 802);cairo_destroy((cairo_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.set_source_surface */
void F46_696 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_source_surface", 45, Current, 0, 4, 806);cairo_set_source_surface((cairo_t*) arg1, (cairo_surface_t*) arg2, (double) arg3, (double) arg4);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.surface_destroy */
void F46_697 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("surface_destroy", 45, Current, 0, 1, 807);
	inline_F46_697 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.surface_flush */
void F46_700 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("surface_flush", 45, Current, 0, 1, 810);cairo_surface_flush((cairo_surface_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.image_surface_create */
EIF_POINTER F46_714 (EIF_REFERENCE Current, EIF_INTEGER_8 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("image_surface_create", 45, Current, 0, 3, 824);Result = (EIF_POINTER) cairo_image_surface_create((cairo_format_t) arg1, (int) arg2, (int) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.image_surface_get_width */
EIF_INTEGER_32 F46_718 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("image_surface_get_width", 45, Current, 0, 1, 828);Result = (EIF_INTEGER_32) cairo_image_surface_get_width((cairo_surface_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.image_surface_get_height */
EIF_INTEGER_32 F46_719 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("image_surface_get_height", 45, Current, 0, 1, 829);Result = (EIF_INTEGER_32) cairo_image_surface_get_height((cairo_surface_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.clip_extents */
void F46_722 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64* arg2, EIF_REAL_64* arg3, EIF_REAL_64* arg4, EIF_REAL_64* arg5)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("clip_extents", 45, Current, 0, 5, 832);cairo_clip_extents((cairo_t*) arg1, (double*) arg2, (double*) arg3, (double*) arg4, (double*) arg5);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.save */
void F46_732 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("save", 45, Current, 0, 1, 842);cairo_save((cairo_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.restore */
void F46_733 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("restore", 45, Current, 0, 1, 843);cairo_restore((cairo_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.set_operator */
void F46_738 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_8 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_operator", 45, Current, 0, 2, 848);cairo_set_operator((cairo_t*) arg1, (cairo_operator_t) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.set_antialias */
void F46_739 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_8 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_antialias", 45, Current, 0, 2, 849);cairo_set_antialias((cairo_t*) arg1, (cairo_antialias_t) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.set_dashed_line_style */
void F46_740 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_dashed_line_style", 45, Current, 0, 2, 850);
	inline_F46_740 ((EIF_POINTER) arg1, (EIF_BOOLEAN) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.fill */
void F46_743 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("fill", 45, Current, 0, 1, 853);
	RTHOOK(1);
	cairo_fill((cairo_t*) arg1);
	RTHOOK(2);
	RTEE;
}

/* {CAIRO}.cairo_fill */
void F46_744 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("cairo_fill", 45, Current, 0, 1, 854);cairo_fill((cairo_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.scale */
void F46_753 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("scale", 45, Current, 0, 3, 863);cairo_scale((cairo_t*) arg1, (double) arg2, (double) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.paint */
void F46_755 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("paint", 45, Current, 0, 1, 865);
	inline_F46_755 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.stroke */
void F46_756 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("stroke", 45, Current, 0, 1, 866);cairo_stroke((cairo_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.stroke_preserve */
void F46_757 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("stroke_preserve", 45, Current, 0, 1, 867);cairo_stroke_preserve((cairo_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.move_to */
void F46_758 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("move_to", 45, Current, 0, 3, 868);cairo_move_to((cairo_t*) arg1, (double) arg2, (double) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.line_to */
void F46_759 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("line_to", 45, Current, 0, 3, 869);cairo_line_to((cairo_t*) arg1, (double) arg2, (double) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.rectangle */
void F46_760 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("rectangle", 45, Current, 0, 5, 870);cairo_rectangle((cairo_t*) arg1, (double) arg2, (double) arg3, (double) arg4, (double) arg5);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.set_source_rgba */
void F46_761 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_source_rgba", 45, Current, 0, 5, 871);cairo_set_source_rgba((cairo_t*) arg1, (double) arg2, (double) arg3, (double) arg4, (double) arg5);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.set_source_rgb */
void F46_762 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_source_rgb", 45, Current, 0, 4, 872);cairo_set_source_rgb((cairo_t*) arg1, (double) arg2, (double) arg3, (double) arg4);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.arc_negative */
void F46_765 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("arc_negative", 45, Current, 0, 6, 875);cairo_arc_negative((cairo_t*) arg1, (double) arg2, (double) arg3, (double) arg4, (double) arg5, (double) arg6);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.set_line_width */
void F46_766 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_line_width", 45, Current, 0, 2, 876);cairo_set_line_width((cairo_t*) arg1, (double) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.set_line_cap */
void F46_767 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_8 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_line_cap", 45, Current, 0, 2, 877);cairo_set_line_cap((cairo_t*) arg1, (cairo_line_cap_t) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.close_path */
void F46_772 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("close_path", 45, Current, 0, 1, 882);cairo_close_path((cairo_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.cairo_content_color_alpha */
EIF_INTEGER_32 F46_781 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("cairo_content_color_alpha", 45, Current, 0, 0, 891);
	Result = (EIF_INTEGER_32) CAIRO_CONTENT_COLOR_ALPHA;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit41 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
