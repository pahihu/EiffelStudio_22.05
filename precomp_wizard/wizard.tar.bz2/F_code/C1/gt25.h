
#ifndef _C1_gt25_
#define _C1_gt25_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F30_279(EIF_REFERENCE);
extern EIF_BOOLEAN F30_280(EIF_REFERENCE, EIF_POINTER, EIF_POINTER, EIF_INTEGER_32, EIF_POINTER*);
extern void EIF_Minit25(void);

#ifdef __cplusplus
}
#endif

#endif
