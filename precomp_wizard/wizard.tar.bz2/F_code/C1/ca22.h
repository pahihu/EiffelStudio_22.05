
#ifndef _C1_ca22_
#define _C1_ca22_

#ifdef __cplusplus
extern "C" {
#endif

extern void F27_261(EIF_REFERENCE);
extern void F27_262(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F27_265(EIF_REFERENCE, EIF_INTEGER_32);
extern void F27_266(EIF_REFERENCE);
extern void F27_267(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit22(void);
extern void F1411_13447(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern char *(*R7739[])();

#ifdef __cplusplus
}
#endif

#endif
