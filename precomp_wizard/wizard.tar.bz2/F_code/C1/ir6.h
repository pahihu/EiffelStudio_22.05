
#ifndef _C1_ir6_
#define _C1_ir6_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F11_106(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit6(void);
extern void F254_4365(EIF_REFERENCE, EIF_REFERENCE);
extern void F255_4378(EIF_REFERENCE, EIF_REFERENCE);
extern long O4273[];

#ifdef __cplusplus
}
#endif

#endif
