
#ifndef _C1_pu12_
#define _C1_pu12_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F17_125(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_NATURAL_32 F17_134(EIF_REFERENCE, EIF_NATURAL_32, EIF_NATURAL_32, EIF_BOOLEAN);
extern EIF_CHARACTER_8 F17_135(EIF_REFERENCE, EIF_NATURAL_32);
extern EIF_NATURAL_32 F17_136(EIF_REFERENCE, EIF_NATURAL_32, EIF_NATURAL_32, EIF_REFERENCE);
extern EIF_NATURAL_32 F17_137(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_NATURAL_32 F17_140(EIF_REFERENCE);
extern void EIF_Minit12(void);
extern void F1243_11356(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R9700[])();
extern char *(*R9867[])();
extern char *(*R9640[])();
extern char *(*R9603[])();

#ifdef __cplusplus
}
#endif

#endif
