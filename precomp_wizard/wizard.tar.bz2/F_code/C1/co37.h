
#ifndef _C1_co37_
#define _C1_co37_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F42_617(EIF_REFERENCE);
extern EIF_BOOLEAN F42_618(EIF_REFERENCE);
extern EIF_BOOLEAN F42_619(EIF_REFERENCE);
extern void F42_628(EIF_REFERENCE, EIF_BOOLEAN);
extern void F42_629(EIF_REFERENCE, EIF_NATURAL_8);
extern void EIF_Minit37(void);

#ifdef __cplusplus
}
#endif

#endif
