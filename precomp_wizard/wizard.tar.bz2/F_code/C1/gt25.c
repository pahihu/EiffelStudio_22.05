/*
 * Code for class GTK_CSS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gt25.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GTK_CSS}.gtk_css_provider_new */
EIF_POINTER F30_279 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_css_provider_new", 29, Current, 0, 0, 314);Result = (EIF_POINTER) gtk_css_provider_new();
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK_CSS}.gtk_css_provider_load_from_data */
EIF_BOOLEAN F30_280 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_POINTER* arg4)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_css_provider_load_from_data", 29, Current, 0, 4, 315);Result = (EIF_BOOLEAN) EIF_TEST(gtk_css_provider_load_from_data((GtkCssProvider*) arg1, (const gchar*) arg2, (gssize) arg3, (GError**) arg4));
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit25 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
