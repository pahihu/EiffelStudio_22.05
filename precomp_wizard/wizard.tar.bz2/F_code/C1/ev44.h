
#ifndef _C1_ev44_
#define _C1_ev44_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F49_853(EIF_REFERENCE);
extern EIF_REFERENCE F49_856(EIF_REFERENCE);
extern EIF_REFERENCE F49_860(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit44(void);
extern void F1138_9661(EIF_REFERENCE, EIF_REFERENCE);
extern void F1257_11685(EIF_REFERENCE, EIF_REAL_32, EIF_REAL_32, EIF_REAL_32);

#ifdef __cplusplus
}
#endif

#endif
