
#ifndef _C1_gt47_
#define _C1_gt47_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F52_906(EIF_REFERENCE);
extern EIF_POINTER F52_924(EIF_REFERENCE);
extern EIF_POINTER F52_925(EIF_REFERENCE);
extern EIF_POINTER F52_932(EIF_REFERENCE);
extern EIF_POINTER F52_933(EIF_REFERENCE);
extern void EIF_Minit47(void);

#ifdef __cplusplus
}
#endif

#endif
