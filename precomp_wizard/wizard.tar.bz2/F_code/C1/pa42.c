/*
 * Code for class PANGO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pa42.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F47_837
static EIF_POINTER inline_F47_837 (void)
{
	return pango_attr_list_new();
	;
}
#define INLINE_F47_837
#endif
#ifndef INLINE_F47_840
static EIF_POINTER inline_F47_840 (EIF_POINTER arg1)
{
	return pango_attr_font_desc_new ((const PangoFontDescription *)arg1);
	;
}
#define INLINE_F47_840
#endif
#ifndef INLINE_F47_841
static void inline_F47_841 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	pango_attr_list_insert ((PangoAttrList *)arg1, (PangoAttribute *)arg2);
	;
}
#define INLINE_F47_841
#endif
#ifndef INLINE_F47_842
static void inline_F47_842 (EIF_POINTER arg1)
{
	pango_attr_list_unref ((PangoAttrList *)arg1);
	;
}
#define INLINE_F47_842
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PANGO}.scale */
EIF_INTEGER_32 F47_785 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("scale", 46, Current, 0, 0, 924);
	Result = (EIF_INTEGER_32) PANGO_SCALE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.font_description_new */
EIF_POINTER F47_788 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("font_description_new", 46, Current, 0, 0, 927);Result = (EIF_POINTER) pango_font_description_new();
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.font_description_free */
void F47_789 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("font_description_free", 46, Current, 0, 1, 928);pango_font_description_free((PangoFontDescription*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.font_description_set_family */
void F47_792 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("font_description_set_family", 46, Current, 0, 2, 931);pango_font_description_set_family((PangoFontDescription*) arg1, (char*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.font_description_set_style */
void F47_794 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("font_description_set_style", 46, Current, 0, 2, 933);pango_font_description_set_style((PangoFontDescription*) arg1, (PangoStyle) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.font_description_set_weight */
void F47_796 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("font_description_set_weight", 46, Current, 0, 2, 935);pango_font_description_set_weight((PangoFontDescription*) arg1, (PangoWeight) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.font_description_set_size */
void F47_798 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("font_description_set_size", 46, Current, 0, 2, 937);pango_font_description_set_size((PangoFontDescription*) arg1, (gint) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.layout_set_font_description */
void F47_801 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("layout_set_font_description", 46, Current, 0, 2, 940);pango_layout_set_font_description((PangoLayout*) arg1, (PangoFontDescription*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.layout_get_pixel_size */
void F47_803 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32* arg2, EIF_INTEGER_32* arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("layout_get_pixel_size", 46, Current, 0, 3, 942);pango_layout_get_pixel_size((PangoLayout*) arg1, (gint*) arg2, (gint*) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.layout_get_iter */
EIF_POINTER F47_804 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("layout_get_iter", 46, Current, 0, 1, 943);Result = (EIF_POINTER) pango_layout_get_iter((PangoLayout*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.layout_set_text */
void F47_805 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("layout_set_text", 46, Current, 0, 3, 944);pango_layout_set_text((PangoLayout*) arg1, (char*) arg2, (int) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.layout_iter_get_baseline */
EIF_INTEGER_32 F47_806 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("layout_iter_get_baseline", 46, Current, 0, 1, 945);Result = (EIF_INTEGER_32) pango_layout_iter_get_baseline((PangoLayoutIter*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.layout_iter_free */
void F47_807 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("layout_iter_free", 46, Current, 0, 1, 946);pango_layout_iter_free((PangoLayoutIter*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.layout_get_pixel_extents */
void F47_809 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("layout_get_pixel_extents", 46, Current, 0, 3, 948);pango_layout_get_pixel_extents((PangoLayout*) arg1, (PangoRectangle*) arg2, (PangoRectangle*) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.new_rectangle_struct */
EIF_POINTER F47_821 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("new_rectangle_struct", 46, Current, 0, 0, 898);
	Result = (EIF_POINTER) calloc (sizeof(PangoRectangle), 1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.rectangle_struct_x */
EIF_INTEGER_32 F47_822 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("rectangle_struct_x", 46, Current, 0, 1, 899);Result = (EIF_INTEGER_32) (((PangoRectangle *)arg1)->x);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.rectangle_struct_y */
EIF_INTEGER_32 F47_823 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("rectangle_struct_y", 46, Current, 0, 1, 900);Result = (EIF_INTEGER_32) (((PangoRectangle *)arg1)->y);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.rectangle_struct_width */
EIF_INTEGER_32 F47_824 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("rectangle_struct_width", 46, Current, 0, 1, 901);Result = (EIF_INTEGER_32) (((PangoRectangle *)arg1)->width);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.rectangle_struct_height */
EIF_INTEGER_32 F47_825 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("rectangle_struct_height", 46, Current, 0, 1, 902);Result = (EIF_INTEGER_32) (((PangoRectangle *)arg1)->height);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.pango_attr_list_new */
EIF_POINTER F47_837 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("pango_attr_list_new", 46, Current, 0, 0, 914);
	Result = inline_F47_837 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.pango_attr_font_desc_new */
EIF_POINTER F47_840 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("pango_attr_font_desc_new", 46, Current, 0, 1, 917);
	Result = inline_F47_840 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.pango_attr_list_insert */
void F47_841 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("pango_attr_list_insert", 46, Current, 0, 2, 918);
	inline_F47_841 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.pango_attr_list_unref */
void F47_842 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("pango_attr_list_unref", 46, Current, 0, 1, 919);
	inline_F47_842 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
}

void EIF_Minit42 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
