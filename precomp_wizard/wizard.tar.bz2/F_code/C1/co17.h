
#ifndef _C1_co17_
#define _C1_co17_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F22_173(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit17(void);
extern void F507_7241(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
