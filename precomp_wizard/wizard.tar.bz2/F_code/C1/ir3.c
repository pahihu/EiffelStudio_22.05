/*
 * Code for class IRON_PACKAGE_INFO_FILE_PARSER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir3.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_PACKAGE_INFO_FILE_PARSER}.make */
void F8_48 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 7, Current, 0, 0, 102);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_new_type(1241, 0).id);
	F1237_11059(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.set_callbacks */
void F8_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_callbacks", 7, Current, 0, 1, 105);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.package_token */

EIF_REFERENCE F8_52 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (694,RTMS_EX_H("package",7,382506597));
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.setup_token */

EIF_REFERENCE F8_53 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (695,RTMS_EX_H("setup",5,1703014256));
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.project_token */

EIF_REFERENCE F8_54 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (696,RTMS_EX_H("project",7,399506036));
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.note_token */

EIF_REFERENCE F8_55 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (697,RTMS_EX_H("note",4,1852798053));
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.end_token */

EIF_REFERENCE F8_56 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (698,RTMS_EX_H("end",3,6647396));
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse */
void F8_57 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("parse", 7, Current, 1, 1, 111);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1147, 0x00).id, 1147, _OBJSIZ_5_7_2_4_1_1_2_1_);
	F1148_10324(RTCW(loc1), arg1);
	RTHOOK(2);
	tb1 = '\0';
	tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8700[Dtype(RTCW(loc1))-1146])(loc1);
	if (tb2) {
		tb2 = F1146_10080(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(3);
		F1146_10112(RTCW(loc1));
		RTHOOK(4);
		F8_58(Current, loc1);
		RTHOOK(5);
		F1146_10129(RTCW(loc1));
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_file */
void F8_58 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("parse_file", 7, Current, 2, 1, 112);
	RTGC;
	RTHOOK(1);
	loc2 = RTLNS(eif_new_type(1244, 0x00).id, 1244, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1243_11356(RTCW(loc2), ((EIF_INTEGER_32) 2046L));
	RTHOOK(2);
	loc1 = F599_8235(RTCW(arg1));
	for (;;) {
		RTHOOK(3);
		if (loc1) break;
		RTHOOK(4);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R8756[Dtype(RTCW(arg1))-1146])(arg1, ((EIF_INTEGER_32) 2046L));
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9865[Dtype(RTCW(loc2))-1244])(loc2, tr1);
		RTHOOK(6);
		loc1 = '\01';
		tb1 = F599_8235(RTCW(arg1));
		if (!tb1) {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
			loc1 = (EIF_BOOLEAN) (ti4_1 < ((EIF_INTEGER_32) 2046L));
		}
	}
	RTHOOK(7);
	F8_59(Current, loc2);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_text */
void F8_59 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	struct eif_ex_79 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(85, 0x00).id);
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("parse_text", 7, Current, 1, 1, 113);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1242_11333(RTCW(tr1));
	RTHOOK(2);
	F86_1497(RTCW(loc1), arg1, *(EIF_REFERENCE *)(Current + _REFACS_1_));
	RTHOOK(3);
	F8_60(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_buffer */
void F8_60 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("parse_buffer", 7, Current, 2, 0, 114);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tb1 = F730_8337(RTCW(tr1));
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) tb1;
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_))) break;
		RTHOOK(5);
		loc1 = F8_73(Current);
		RTHOOK(6);
		switch (loc1) {
			case (EIF_CHARACTER_8) '-':
				RTHOOK(7);
				loc1 = F8_70(Current);
				RTHOOK(8);
				F8_61(Current);
				break;
			case (EIF_CHARACTER_8) 'p':
				RTHOOK(9);
				loc1 = F8_70(Current);
				RTHOOK(10);
				loc2 = F8_76(Current);
				RTHOOK(11);
				tr1 = F1237_11118(RTCV(RTOUCR(694,F8_52, (Current))));
				tb1 = F1240_11214(RTCW(loc2), tr1);
				if (tb1) {
					RTHOOK(12);
					F8_62(Current);
				} else {
					RTHOOK(13);
					tr1 = F1237_11118(RTCV(RTOUCR(696,F8_54, (Current))));
					tb1 = F1240_11214(RTCW(loc2), tr1);
					if (tb1) {
						RTHOOK(14);
						F8_65(Current);
					} else {
						RTHOOK(15);
						tr1 = F1237_11118(RTMS_EX_H("Unexpected character [p].",25,883275054));
						F8_69(Current, tr1);
					}
				}
				break;
			case (EIF_CHARACTER_8) 's':
				RTHOOK(16);
				loc1 = F8_70(Current);
				RTHOOK(17);
				loc2 = F8_76(Current);
				RTHOOK(18);
				tr1 = RTOUCR(695,F8_53, (Current));
				tb1 = F1237_11101(RTCW(loc2), tr1);
				if (tb1) {
					RTHOOK(19);
					F8_63(Current);
				} else {
					RTHOOK(20);
					tr1 = F1237_11118(RTMS_EX_H("Unexpected character [s].",25,883471662));
					F8_69(Current, tr1);
				}
				break;
			case (EIF_CHARACTER_8) 'n':
				RTHOOK(21);
				loc1 = F8_70(Current);
				RTHOOK(22);
				loc2 = F8_76(Current);
				RTHOOK(23);
				tr1 = RTOUCR(697,F8_55, (Current));
				tb1 = F1237_11101(RTCW(loc2), tr1);
				if (tb1) {
					RTHOOK(24);
					F8_67(Current);
				} else {
					RTHOOK(25);
					tr1 = F1237_11118(RTMS_EX_H("Unexpected character [n].",25,883143982));
					F8_69(Current, tr1);
				}
				break;
			case (EIF_CHARACTER_8) 'e':
				RTHOOK(26);
				loc1 = F8_70(Current);
				RTHOOK(27);
				loc2 = F8_76(Current);
				RTHOOK(28);
				tr1 = F1237_11118(RTCV(RTOUCR(698,F8_56, (Current))));
				tb1 = F1240_11214(RTCW(loc2), tr1);
				if ((EIF_BOOLEAN) !tb1) {
					RTHOOK(29);
					tr1 = F1237_11118(RTMS_EX_H("Unexpected character [e].",25,882554158));
					F8_69(Current, tr1);
				}
				break;
			case (EIF_CHARACTER_8) '\000':
				RTHOOK(30);
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
					RTHOOK(31);
					tr1 = F1237_11118(RTMS_EX_H("Unexpected null character.",26,830567726));
					F8_69(Current, tr1);
				}
				break;
			default:
				RTHOOK(32);
				tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
				tr2 = F8_82(Current, loc1);
				tr1 = F1242_11323(tr1, tr2);
				tr2 = F1237_11118(RTMS_EX_H("].",2,23854));
				tr1 = F1242_11323(RTCW(tr1), tr2);
				F8_69(Current, tr1);
				break;
		}
	}
	RTHOOK(33);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_comment */
void F8_61 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("parse_comment", 7, Current, 3, 0, 115);
	RTGC;
	RTHOOK(1);
	loc1 = F8_71(Current);
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
	if ((EIF_BOOLEAN)(loc1 == tw1)) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			RTHOOK(4);
			loc1 = F8_71(Current);
			RTHOOK(5);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
			if ((EIF_BOOLEAN)(loc1 == tw1)) {
				RTHOOK(6);
				loc2 = F8_75(Current);
				RTHOOK(7);
				tr1 = *(EIF_REFERENCE *)(Current);
				loc3 = tr1;
				if (EIF_TEST(loc3)) {
					RTHOOK(8);
					{
						/* INLINED CODE (IRON_PACKAGE_INFO_FILE_PARSER_CALLBACKS.on_comment) */
						(void) loc3;
						/* END INLINED CODE */
					}
					;
				}
			} else {
				RTHOOK(9);
				tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
				tr2 = F8_82(Current, loc1);
				tr1 = F1242_11323(tr1, tr2);
				tr2 = F1237_11118(RTMS_EX_H("].",2,23854));
				tr1 = F1242_11323(RTCW(tr1), tr2);
				F8_69(Current, tr1);
			}
		}
	} else {
		RTHOOK(10);
		tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
		tr2 = F8_82(Current, loc1);
		tr1 = F1242_11323(tr1, tr2);
		tr2 = F1237_11118(RTMS_EX_H("].",2,23854));
		tr1 = F1242_11323(RTCW(tr1), tr2);
		F8_69(Current, tr1);
	}
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_package_declaration */
void F8_62 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 loc2 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLIU(4);
	
	RTEAA("parse_package_declaration", 7, Current, 3, 0, 116);
	RTGC;
	RTHOOK(1);
	loc2 = F8_73(Current);
	RTHOOK(2);
	tb1 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(loc2 != tw1)) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_);
	}
	if (tb1) {
		RTHOOK(3);
		loc2 = F8_70(Current);
		RTHOOK(4);
		loc1 = F8_78(Current);
		RTHOOK(5);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R9618[Dtype(RTCW(loc1))-1240])(loc1);
		if (tb1) {
			RTHOOK(6);
			tr1 = F1237_11118(RTMS_EX_H("Invalid package name",20,1534212709));
			F8_69(Current, tr1);
		} else {
			RTHOOK(7);
			tr1 = *(EIF_REFERENCE *)(Current);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				RTHOOK(8);
				F255_4382(loc3, loc1);
			}
		}
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_setup_declaration */
void F8_63 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_32 loc5 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("parse_setup_declaration", 7, Current, 5, 0, 117);
	RTGC;
	RTHOOK(1);
	loc5 = F8_73(Current);
	RTHOOK(2);
	tb1 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(loc5 != tw1)) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_);
	}
	if (tb1) {
		RTHOOK(3);
		loc5 = F8_70(Current);
		RTHOOK(4);
		loc1 = F8_80(Current);
		RTHOOK(5);
		loc5 = F8_70(Current);
		for (;;) {
			RTHOOK(6);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || loc4) || *(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_))) break;
			RTHOOK(7);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R9618[Dtype(RTCW(loc1))-1240])(loc1);
			if (tb1) {
				RTHOOK(8);
				loc5 = F8_71(Current);
				RTHOOK(9);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				if ((EIF_BOOLEAN)(loc5 == tw1)) {
					RTHOOK(10);
					loc5 = F8_70(Current);
					RTHOOK(11);
					F8_61(Current);
					RTHOOK(12);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_))) {
						RTHOOK(13);
						loc5 = F8_73(Current);
						RTHOOK(14);
						loc5 = F8_70(Current);
						RTHOOK(15);
						loc1 = F8_80(Current);
						RTHOOK(16);
						loc5 = F8_70(Current);
					}
				} else {
					RTHOOK(17);
					tr1 = F1237_11118(RTMS_EX_H("Invalid setup name",18,1945739621));
					F8_69(Current, tr1);
					RTHOOK(18);
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			} else {
				RTHOOK(19);
				tr1 = F1237_11118(RTCV(RTOUCR(696,F8_54, (Current))));
				tb1 = F1240_11214(RTCW(loc1), tr1);
				if (tb1) {
					RTHOOK(20);
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					RTHOOK(21);
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					RTHOOK(22);
					tr1 = F1237_11118(RTCV(RTOUCR(697,F8_55, (Current))));
					tb1 = F1240_11214(RTCW(loc1), tr1);
					if (tb1) {
						RTHOOK(23);
						loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						RTHOOK(24);
						loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						RTHOOK(25);
						tr1 = F1237_11118(RTCV(RTOUCR(698,F8_56, (Current))));
						tb1 = F1240_11214(RTCW(loc1), tr1);
						if (tb1) {
							RTHOOK(26);
							loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						} else {
							RTHOOK(27);
							F8_64(Current, loc1);
							RTHOOK(28);
							loc5 = F8_70(Current);
							RTHOOK(29);
							loc5 = F8_73(Current);
							for (;;) {
								RTHOOK(30);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
								if ((EIF_BOOLEAN)(loc5 != tw1)) break;
								RTHOOK(31);
								loc5 = F8_70(Current);
								RTHOOK(32);
								F8_61(Current);
								RTHOOK(33);
								loc5 = F8_73(Current);
							}
							RTHOOK(34);
							loc5 = F8_70(Current);
							RTHOOK(35);
							loc1 = F8_80(Current);
							RTHOOK(36);
							loc5 = F8_70(Current);
						}
					}
				}
			}
		}
		RTHOOK(37);
		if (loc2) {
			RTHOOK(38);
			F8_67(Current);
		} else {
			RTHOOK(39);
			if (loc3) {
				RTHOOK(40);
				F8_65(Current);
			}
		}
	}
	RTHOOK(41);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_setup_item_declaration */
void F8_64 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_32 loc4 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc5);
	RTLR(5,arg1);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTEAA("parse_setup_item_declaration", 7, Current, 5, 1, 118);
	RTGC;
	RTHOOK(1);
	loc4 = F8_73(Current);
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '=';
	if ((EIF_BOOLEAN)(loc4 == tw1)) {
		RTHOOK(3);
		loc4 = F8_74(Current);
		RTHOOK(4);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		if ((EIF_BOOLEAN)(loc4 == tw1)) {
			RTHOOK(5);
			tr1 = F1237_11118(RTMS_EX_H("Syntax error in setup declaration",33,1339518062));
			F8_69(Current, tr1);
		} else {
			RTHOOK(6);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
			if ((EIF_BOOLEAN)(loc4 == tw1)) {
				RTHOOK(7);
				loc4 = F8_71(Current);
				RTHOOK(8);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
				if ((EIF_BOOLEAN)(loc4 == tw1)) {
					RTHOOK(9);
					loc1 = F8_75(Current);
					RTHOOK(10);
					tb1 = F1237_11077(RTCW(loc1));
					if (tb1) {
						RTHOOK(11);
						loc2 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
						F1237_11059(RTCW(loc2));
						for (;;) {
							RTHOOK(12);
							if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || loc3)) break;
							RTHOOK(13);
							loc1 = F8_75(Current);
							RTHOOK(14);
							F1242_11289(RTCW(loc1));
							RTHOOK(15);
							tr1 = F1237_11118(RTMS_EX_H("]\"",2,23842));
							tb1 = F1240_11225(RTCW(loc1), tr1);
							if (tb1) {
								RTHOOK(16);
								tb1 = '\01';
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
								if (!(EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
									ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
									tb2 = F1240_11222(RTCW(loc1), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 2L)));
									tb1 = tb2;
								}
								if (tb1) {
									RTHOOK(17);
									loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								} else {
									RTHOOK(18);
									F1242_11304(RTCW(loc2), loc1);
									RTHOOK(19);
									tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
									F1242_11317(RTCW(loc2), tw1);
								}
							} else {
								RTHOOK(20);
								F1242_11304(RTCW(loc2), loc1);
								RTHOOK(21);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
								F1242_11317(RTCW(loc2), tw1);
							}
						}
						RTHOOK(22);
						if (loc3) {
							RTHOOK(23);
							F8_83(Current, loc2);
						}
					} else {
						RTHOOK(24);
						F1242_11295(RTCW(loc1), loc4);
						RTHOOK(25);
						F1242_11289(RTCW(loc1));
						RTHOOK(26);
						tr1 = F1237_11118(RTMS_EX_H("\"",1,34));
						tb1 = F1240_11225(RTCW(loc1), tr1);
						if (tb1) {
							RTHOOK(27);
							F1242_11328(RTCW(loc1), ((EIF_INTEGER_32) 1L));
						} else {
							RTHOOK(28);
							tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
							F1242_11295(RTCW(loc1), tw1);
						}
						RTHOOK(29);
						loc2 = (EIF_REFERENCE) loc1;
					}
				} else {
					RTHOOK(30);
					loc1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F1237_11059(RTCW(loc1));
					RTHOOK(31);
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
					F1242_11317(RTCW(loc1), tw1);
					RTHOOK(32);
					F1242_11317(RTCW(loc1), loc4);
					RTHOOK(33);
					tr1 = F8_75(Current);
					F1242_11304(RTCW(loc1), tr1);
					RTHOOK(34);
					F1242_11288(RTCW(loc1));
					RTHOOK(35);
					F1242_11289(RTCW(loc1));
					RTHOOK(36);
					tb1 = '\0';
					tb2 = '\0';
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 2L))) {
						tw1 = F1242_11271(RTCW(loc1), ((EIF_INTEGER_32) 1L));
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb2 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb2) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						tw1 = F1242_11271(RTCW(loc1), ti4_1);
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb1 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb1) {
						RTHOOK(37);
						F1242_11326(RTCW(loc1), ((EIF_INTEGER_32) 1L));
						RTHOOK(38);
						F1242_11328(RTCW(loc1), ((EIF_INTEGER_32) 1L));
					}
					RTHOOK(39);
					loc2 = (EIF_REFERENCE) loc1;
					RTHOOK(40);
					loc4 = F8_73(Current);
				}
			} else {
				RTHOOK(41);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
				if ((EIF_BOOLEAN)(loc4 == tw1)) {
					RTHOOK(42);
					loc1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F1237_11059(RTCW(loc1));
					RTHOOK(43);
					loc2 = (EIF_REFERENCE) loc1;
				} else {
					RTHOOK(44);
					loc4 = F8_70(Current);
					RTHOOK(45);
					loc1 = F8_75(Current);
					RTHOOK(46);
					F1242_11288(RTCW(loc1));
					RTHOOK(47);
					F1242_11289(RTCW(loc1));
					RTHOOK(48);
					loc2 = (EIF_REFERENCE) loc1;
				}
			}
		}
		RTHOOK(49);
		tr1 = *(EIF_REFERENCE *)(Current);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			RTHOOK(50);
			if ((EIF_BOOLEAN)(loc2 == NULL)) {
				RTHOOK(51);
				loc2 = F1237_11118(RTMS_EX_H("",0,0));
			}
			RTHOOK(52);
			F255_4383(loc5, arg1, loc2);
		}
	} else {
		RTHOOK(53);
		tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
		tr2 = F8_82(Current, loc4);
		tr1 = F1242_11323(tr1, tr2);
		tr2 = F1237_11118(RTMS_EX_H("].",2,23854));
		tr1 = F1242_11323(RTCW(tr1), tr2);
		F8_69(Current, tr1);
	}
	RTHOOK(54);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_projects_declaration */
void F8_65 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_32 loc5 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("parse_projects_declaration", 7, Current, 5, 0, 119);
	RTGC;
	RTHOOK(1);
	loc5 = F8_73(Current);
	RTHOOK(2);
	tb1 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(loc5 != tw1)) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_);
	}
	if (tb1) {
		RTHOOK(3);
		loc5 = F8_70(Current);
		RTHOOK(4);
		loc1 = F8_80(Current);
		RTHOOK(5);
		loc5 = F8_70(Current);
		for (;;) {
			RTHOOK(6);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || loc4) || *(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_))) break;
			RTHOOK(7);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R9618[Dtype(RTCW(loc1))-1240])(loc1);
			if (tb1) {
				RTHOOK(8);
				loc5 = F8_71(Current);
				RTHOOK(9);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				if ((EIF_BOOLEAN)(loc5 == tw1)) {
					RTHOOK(10);
					loc5 = F8_70(Current);
					RTHOOK(11);
					F8_61(Current);
					RTHOOK(12);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_))) {
						RTHOOK(13);
						loc5 = F8_73(Current);
						RTHOOK(14);
						loc5 = F8_70(Current);
						RTHOOK(15);
						loc1 = F8_80(Current);
						RTHOOK(16);
						loc5 = F8_70(Current);
					}
				} else {
					RTHOOK(17);
					tr1 = F1237_11118(RTMS_EX_H("Invalid project name",20,415510117));
					F8_69(Current, tr1);
					RTHOOK(18);
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			} else {
				RTHOOK(19);
				tr1 = F1237_11118(RTCV(RTOUCR(695,F8_53, (Current))));
				tb1 = F1240_11214(RTCW(loc1), tr1);
				if (tb1) {
					RTHOOK(20);
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					RTHOOK(21);
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					RTHOOK(22);
					tr1 = F1237_11118(RTCV(RTOUCR(697,F8_55, (Current))));
					tb1 = F1240_11214(RTCW(loc1), tr1);
					if (tb1) {
						RTHOOK(23);
						loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						RTHOOK(24);
						loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						RTHOOK(25);
						tr1 = F1237_11118(RTCV(RTOUCR(698,F8_56, (Current))));
						tb1 = F1240_11214(RTCW(loc1), tr1);
						if (tb1) {
							RTHOOK(26);
							loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						} else {
							RTHOOK(27);
							F8_66(Current, loc1);
							RTHOOK(28);
							loc5 = F8_70(Current);
							RTHOOK(29);
							loc5 = F8_73(Current);
							for (;;) {
								RTHOOK(30);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
								if ((EIF_BOOLEAN)(loc5 != tw1)) break;
								RTHOOK(31);
								loc5 = F8_70(Current);
								RTHOOK(32);
								F8_61(Current);
								RTHOOK(33);
								loc5 = F8_73(Current);
							}
							RTHOOK(34);
							loc5 = F8_70(Current);
							RTHOOK(35);
							loc1 = F8_80(Current);
							RTHOOK(36);
							loc5 = F8_70(Current);
						}
					}
				}
			}
		}
		RTHOOK(37);
		if (loc2) {
			RTHOOK(38);
			F8_67(Current);
		} else {
			RTHOOK(39);
			if (loc3) {
				RTHOOK(40);
				F8_63(Current);
			}
		}
	}
	RTHOOK(41);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_project_item_declaration */
void F8_66 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 loc2 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc3);
	RTLR(4,arg1);
	RTLR(5,loc4);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTEAA("parse_project_item_declaration", 7, Current, 4, 1, 120);
	RTGC;
	RTHOOK(1);
	loc2 = F8_73(Current);
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '=';
	if ((EIF_BOOLEAN)(loc2 == tw1)) {
		RTHOOK(3);
		loc2 = F8_73(Current);
		RTHOOK(4);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		if ((EIF_BOOLEAN)(loc2 == tw1)) {
			RTHOOK(5);
			tr1 = F1237_11118(RTMS_EX_H("Syntax error in project declaration",35,1660760430));
			F8_69(Current, tr1);
		} else {
			RTHOOK(6);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
			if ((EIF_BOOLEAN)(loc2 == tw1)) {
				RTHOOK(7);
				loc1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
				F1237_11059(RTCW(loc1));
				RTHOOK(8);
				loc2 = F8_71(Current);
				for (;;) {
					RTHOOK(9);
					tb1 = '\01';
					if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb1 = (EIF_BOOLEAN)(loc2 == tw1);
					}
					if (tb1) break;
					RTHOOK(10);
					F1242_11317(RTCW(loc1), loc2);
					RTHOOK(11);
					loc2 = F8_71(Current);
				}
				RTHOOK(12);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
				if ((EIF_BOOLEAN)(loc2 == tw1)) {
					RTHOOK(13);
					tr1 = *(EIF_REFERENCE *)(Current);
					loc3 = tr1;
					if (EIF_TEST(loc3)) {
						RTHOOK(14);
						F255_4384(loc3, arg1, loc1);
					}
					RTHOOK(15);
					loc2 = F8_73(Current);
				}
			} else {
				RTHOOK(16);
				loc1 = F8_75(Current);
				RTHOOK(17);
				F1242_11288(RTCW(loc1));
				RTHOOK(18);
				F1242_11289(RTCW(loc1));
				RTHOOK(19);
				tr1 = *(EIF_REFERENCE *)(Current);
				loc4 = tr1;
				if (EIF_TEST(loc4)) {
					RTHOOK(20);
					F255_4384(loc4, arg1, loc1);
				}
			}
		}
	} else {
		RTHOOK(21);
		tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
		tr2 = F8_82(Current, loc2);
		tr1 = F1242_11323(tr1, tr2);
		tr2 = F1237_11118(RTMS_EX_H("].",2,23854));
		tr1 = F1242_11323(RTCW(tr1), tr2);
		F8_69(Current, tr1);
	}
	RTHOOK(22);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_notes_declaration */
void F8_67 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_32 loc2 = (EIF_CHARACTER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("parse_notes_declaration", 7, Current, 3, 0, 121);
	RTGC;
	RTHOOK(1);
	loc2 = F8_73(Current);
	RTHOOK(2);
	tb1 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(loc2 != tw1)) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_);
	}
	if (tb1) {
		RTHOOK(3);
		loc2 = F8_70(Current);
		RTHOOK(4);
		loc1 = F8_81(Current);
		RTHOOK(5);
		loc2 = F8_70(Current);
		for (;;) {
			RTHOOK(6);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || loc3) || *(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_))) break;
			RTHOOK(7);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R9618[Dtype(RTCW(loc1))-1240])(loc1);
			if (tb1) {
				RTHOOK(8);
				loc2 = F8_71(Current);
				RTHOOK(9);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				if ((EIF_BOOLEAN)(loc2 == tw1)) {
					RTHOOK(10);
					loc2 = F8_70(Current);
					RTHOOK(11);
					F8_61(Current);
					RTHOOK(12);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_))) {
						RTHOOK(13);
						loc2 = F8_73(Current);
						RTHOOK(14);
						loc2 = F8_70(Current);
						RTHOOK(15);
						loc1 = F8_81(Current);
						RTHOOK(16);
						loc2 = F8_70(Current);
					}
				} else {
					RTHOOK(17);
					tr1 = F1237_11118(RTMS_EX_H("Invalid note name",17,17618021));
					F8_69(Current, tr1);
					RTHOOK(18);
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			} else {
				RTHOOK(19);
				tr1 = F1237_11118(RTCV(RTOUCR(694,F8_52, (Current))));
				tb1 = F1240_11214(RTCW(loc1), tr1);
				if (tb1) {
					RTHOOK(20);
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					RTHOOK(21);
					tr1 = F1237_11118(RTCV(RTOUCR(695,F8_53, (Current))));
					tb1 = F1240_11214(RTCW(loc1), tr1);
					if (tb1) {
						RTHOOK(22);
						loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						RTHOOK(23);
						tr1 = F1237_11118(RTCV(RTOUCR(698,F8_56, (Current))));
						tb1 = F1240_11214(RTCW(loc1), tr1);
						if (tb1) {
							RTHOOK(24);
							loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						} else {
							RTHOOK(25);
							F8_68(Current, loc1);
							RTHOOK(26);
							loc2 = F8_70(Current);
							RTHOOK(27);
							loc2 = F8_73(Current);
							for (;;) {
								RTHOOK(28);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
								if ((EIF_BOOLEAN)(loc2 != tw1)) break;
								RTHOOK(29);
								loc2 = F8_70(Current);
								RTHOOK(30);
								F8_61(Current);
								RTHOOK(31);
								loc2 = F8_73(Current);
							}
							RTHOOK(32);
							loc2 = F8_70(Current);
							RTHOOK(33);
							loc1 = F8_81(Current);
							RTHOOK(34);
							loc2 = F8_70(Current);
						}
					}
				}
			}
		}
		RTHOOK(35);
		if (loc3) {
			RTHOOK(36);
			tr1 = F1237_11118(RTCV(RTOUCR(694,F8_52, (Current))));
			tb1 = F1240_11214(RTCW(loc1), tr1);
			if (tb1) {
				RTHOOK(37);
				F8_62(Current);
			} else {
				RTHOOK(38);
				tr1 = F1237_11118(RTCV(RTOUCR(695,F8_53, (Current))));
				tb1 = F1240_11214(RTCW(loc1), tr1);
				if (tb1) {
					RTHOOK(39);
					F8_63(Current);
				}
			}
		}
	}
	RTHOOK(40);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.parse_note_item_declaration */
void F8_68 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_32 loc4 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc5);
	RTLR(5,arg1);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTEAA("parse_note_item_declaration", 7, Current, 5, 1, 122);
	RTGC;
	RTHOOK(1);
	loc4 = F8_73(Current);
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
	if ((EIF_BOOLEAN)(loc4 == tw1)) {
		RTHOOK(3);
		loc4 = F8_74(Current);
		RTHOOK(4);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		if ((EIF_BOOLEAN)(loc4 == tw1)) {
			RTHOOK(5);
			tr1 = F1237_11118(RTMS_EX_H("Syntax error in note declaration",32,1224969838));
			F8_69(Current, tr1);
		} else {
			RTHOOK(6);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
			if ((EIF_BOOLEAN)(loc4 == tw1)) {
				RTHOOK(7);
				loc4 = F8_71(Current);
				RTHOOK(8);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
				if ((EIF_BOOLEAN)(loc4 == tw1)) {
					RTHOOK(9);
					loc1 = F8_75(Current);
					RTHOOK(10);
					tb1 = F1237_11077(RTCW(loc1));
					if (tb1) {
						RTHOOK(11);
						loc2 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
						F1237_11059(RTCW(loc2));
						for (;;) {
							RTHOOK(12);
							if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) || loc3)) break;
							RTHOOK(13);
							loc1 = F8_75(Current);
							RTHOOK(14);
							F1242_11289(RTCW(loc1));
							RTHOOK(15);
							tr1 = F1237_11118(RTMS_EX_H("]\"",2,23842));
							tb1 = F1240_11225(RTCW(loc1), tr1);
							if (tb1) {
								RTHOOK(16);
								tb1 = '\01';
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
								if (!(EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
									ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
									tb2 = F1240_11222(RTCW(loc1), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 2L)));
									tb1 = tb2;
								}
								if (tb1) {
									RTHOOK(17);
									loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								} else {
									RTHOOK(18);
									F1242_11304(RTCW(loc2), loc1);
									RTHOOK(19);
									tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
									F1242_11317(RTCW(loc2), tw1);
								}
							} else {
								RTHOOK(20);
								F1242_11304(RTCW(loc2), loc1);
								RTHOOK(21);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
								F1242_11317(RTCW(loc2), tw1);
							}
						}
						RTHOOK(22);
						if (loc3) {
							RTHOOK(23);
							F8_83(Current, loc2);
						}
					} else {
						RTHOOK(24);
						F1242_11295(RTCW(loc1), loc4);
						RTHOOK(25);
						F1242_11289(RTCW(loc1));
						RTHOOK(26);
						tr1 = F1237_11118(RTMS_EX_H("\"",1,34));
						tb1 = F1240_11225(RTCW(loc1), tr1);
						if (tb1) {
							RTHOOK(27);
							F1242_11328(RTCW(loc1), ((EIF_INTEGER_32) 1L));
						} else {
							RTHOOK(28);
							tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
							F1242_11295(RTCW(loc1), tw1);
						}
						RTHOOK(29);
						loc2 = (EIF_REFERENCE) loc1;
					}
				} else {
					RTHOOK(30);
					loc1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F1237_11059(RTCW(loc1));
					RTHOOK(31);
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
					F1242_11317(RTCW(loc1), tw1);
					RTHOOK(32);
					F1242_11317(RTCW(loc1), loc4);
					RTHOOK(33);
					tr1 = F8_75(Current);
					F1242_11304(RTCW(loc1), tr1);
					RTHOOK(34);
					F1242_11288(RTCW(loc1));
					RTHOOK(35);
					F1242_11289(RTCW(loc1));
					RTHOOK(36);
					tb1 = '\0';
					tb2 = '\0';
					tb3 = '\0';
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 2L))) {
						tw1 = F1242_11271(RTCW(loc1), ((EIF_INTEGER_32) 1L));
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb3 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb3) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						tw1 = F1242_11271(RTCW(loc1), ti4_1);
						tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb2 = (EIF_BOOLEAN)(tw1 == tw2);
					}
					if (tb2) {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						ti4_1 = F1240_11201(RTCW(loc1), tw1, ((EIF_INTEGER_32) 2L));
						ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
						tb1 = (EIF_BOOLEAN)(ti4_1 == ti4_2);
					}
					if (tb1) {
						RTHOOK(37);
						F1242_11326(RTCW(loc1), ((EIF_INTEGER_32) 1L));
						RTHOOK(38);
						F1242_11328(RTCW(loc1), ((EIF_INTEGER_32) 1L));
					}
					RTHOOK(39);
					loc2 = (EIF_REFERENCE) loc1;
					RTHOOK(40);
					loc4 = F8_73(Current);
				}
			} else {
				RTHOOK(41);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
				if ((EIF_BOOLEAN)(loc4 == tw1)) {
					RTHOOK(42);
					loc1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F1237_11059(RTCW(loc1));
					RTHOOK(43);
					loc2 = (EIF_REFERENCE) loc1;
				} else {
					RTHOOK(44);
					loc4 = F8_70(Current);
					RTHOOK(45);
					loc1 = F8_75(Current);
					RTHOOK(46);
					F1242_11288(RTCW(loc1));
					RTHOOK(47);
					F1242_11289(RTCW(loc1));
					RTHOOK(48);
					loc2 = (EIF_REFERENCE) loc1;
				}
			}
		}
		RTHOOK(49);
		tr1 = *(EIF_REFERENCE *)(Current);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			RTHOOK(50);
			if ((EIF_BOOLEAN)(loc2 == NULL)) {
				RTHOOK(51);
				loc2 = F1237_11118(RTMS_EX_H("",0,0));
			}
			RTHOOK(52);
			F255_4385(loc5, arg1, loc2);
		}
	} else {
		RTHOOK(53);
		tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000[\000\000\000",22,407802203);
		tr2 = F8_82(Current, loc4);
		tr1 = F1242_11323(tr1, tr2);
		tr2 = F1237_11118(RTMS_EX_H("].",2,23854));
		tr1 = F1242_11323(RTCW(tr1), tr2);
		F8_69(Current, tr1);
	}
	RTHOOK(54);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.report_error */
void F8_69 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("report_error", 7, Current, 1, 1, 123);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		{
			/* INLINED CODE (IRON_PACKAGE_INFO_FILE_PARSER_CALLBACKS.on_error) */
			(void) loc1;
			/* END INLINED CODE */
		}
		;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.previous_character */
EIF_CHARACTER_32 F8_70 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("previous_character", 7, Current, 0, 0, 124);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_) >= ((EIF_INTEGER_32) 1L))) {
		RTHOOK(2);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_))--;
		RTHOOK(3);
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_) > ((EIF_INTEGER_32) 0L))) {
			RTHOOK(4);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			Result = F1242_11271(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_));
		} else {
			RTHOOK(5);
			Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		}
		RTHOOK(6);
		F8_72(Current);
	} else {
		RTHOOK(7);
		Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		RTHOOK(8);
		tr1 = F1237_11118(RTMS_EX_H("out of input",12,330662516));
		F8_69(Current, tr1);
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_character */
EIF_CHARACTER_32 F8_71 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("next_character", 7, Current, 0, 0, 85);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
		RTHOOK(2);
		tr1 = F1237_11118(RTMS_EX_H("out of input",12,330662516));
		F8_69(Current, tr1);
		RTHOOK(3);
		Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	} else {
		RTHOOK(4);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_))++;
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = F1242_11271(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_));
		RTHOOK(6);
		F8_72(Current);
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.update_end_of_input */
void F8_72 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("update_end_of_input", 7, Current, 0, 0, 86);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_2_0_0_) > ti4_1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_non_whitespace_character */
EIF_CHARACTER_32 F8_73 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("next_non_whitespace_character", 7, Current, 0, 0, 87);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
		RTHOOK(2);
		tr1 = F1237_11118(RTMS_EX_H("out of input",12,330662516));
		F8_69(Current, tr1);
		RTHOOK(3);
		Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	} else {
		RTHOOK(4);
		Result = F8_71(Current);
		for (;;) {
			RTHOOK(5);
			tb1 = '\01';
			if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
				tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = Result;
				tb2 = F1188_10895(RTCW(tr1));
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) break;
			RTHOOK(6);
			Result = F8_71(Current);
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_non_whitespace_character_until_eol */
EIF_CHARACTER_32 F8_74 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("next_non_whitespace_character_until_eol", 7, Current, 0, 0, 88);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
		RTHOOK(2);
		tr1 = F1237_11118(RTMS_EX_H("out of input",12,330662516));
		F8_69(Current, tr1);
		RTHOOK(3);
		Result = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	} else {
		RTHOOK(4);
		Result = F8_71(Current);
		for (;;) {
			RTHOOK(5);
			tb1 = '\01';
			tb2 = '\01';
			if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
				tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = Result;
				tb3 = F1188_10895(RTCW(tr1));
				tb2 = (EIF_BOOLEAN) !tb3;
			}
			if (!tb2) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
				tb1 = (EIF_BOOLEAN)(Result == tw1);
			}
			if (tb1) break;
			RTHOOK(6);
			Result = F8_71(Current);
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_text_until_eol */
EIF_REFERENCE F8_75 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("next_text_until_eol", 7, Current, 1, 0, 89);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1237_11059(RTCW(Result));
	RTHOOK(2);
	loc1 = F8_71(Current);
	for (;;) {
		RTHOOK(3);
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
			tb1 = (EIF_BOOLEAN)(loc1 == tw1);
		}
		if (tb1) break;
		RTHOOK(4);
		F1242_11317(RTCW(Result), loc1);
		RTHOOK(5);
		loc1 = F8_71(Current);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_alphabetic */
EIF_REFERENCE F8_76 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("next_alphabetic", 7, Current, 1, 0, 90);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1237_11059(RTCW(Result));
	RTHOOK(2);
	loc1 = F8_71(Current);
	for (;;) {
		RTHOOK(3);
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = loc1;
			tb2 = F1188_10889(RTCW(tr1));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) break;
		RTHOOK(4);
		F1242_11317(RTCW(Result), loc1);
		RTHOOK(5);
		loc1 = F8_71(Current);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_package_name */
EIF_REFERENCE F8_78 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("next_package_name", 7, Current, 1, 0, 92);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1237_11059(RTCW(Result));
	RTHOOK(2);
	loc1 = F8_71(Current);
	for (;;) {
		RTHOOK(3);
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tb2 = '\01';
			tb3 = '\01';
			tb4 = '\01';
			tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = loc1;
			tb5 = F1188_10897(RTCW(tr1));
			if (!tb5) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
				tb4 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb4) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				tb3 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb3) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '+';
				tb2 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) break;
		RTHOOK(4);
		F1242_11317(RTCW(Result), loc1);
		RTHOOK(5);
		loc1 = F8_71(Current);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_alpha_numeric_or_dash */
EIF_REFERENCE F8_80 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("next_alpha_numeric_or_dash", 7, Current, 1, 0, 94);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1237_11059(RTCW(Result));
	RTHOOK(2);
	loc1 = F8_71(Current);
	for (;;) {
		RTHOOK(3);
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tb2 = '\01';
			tb3 = '\01';
			tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = loc1;
			tb4 = F1188_10897(RTCW(tr1));
			if (!tb4) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
				tb3 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb3) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				tb2 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) break;
		RTHOOK(4);
		F1242_11317(RTCW(Result), loc1);
		RTHOOK(5);
		loc1 = F8_71(Current);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.next_alpha_numeric_with_bracket */
EIF_REFERENCE F8_81 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("next_alpha_numeric_with_bracket", 7, Current, 2, 0, 95);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1237_11059(RTCW(Result));
	RTHOOK(2);
	loc1 = F8_71(Current);
	for (;;) {
		RTHOOK(3);
		tb1 = '\01';
		if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tb2 = '\01';
			tb3 = '\01';
			tb4 = '\01';
			tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = loc1;
			tb5 = F1188_10897(RTCW(tr1));
			if (!tb5) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
				tb4 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb4) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
				tb3 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb3) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
				tb2 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) break;
		RTHOOK(4);
		F1242_11317(RTCW(Result), loc1);
		RTHOOK(5);
		loc1 = F8_71(Current);
		RTHOOK(6);
		if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
			RTHOOK(7);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
			if ((EIF_BOOLEAN)(loc1 != tw1)) {
				RTHOOK(8);
				loc2--;
			}
		} else {
			RTHOOK(9);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
			if ((EIF_BOOLEAN)(loc1 == tw1)) {
				RTHOOK(10);
				loc2++;
			}
		}
	}
	RTHOOK(11);
	if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(12);
		tr1 = RTMS32_EX_H("I\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000n\000\000\000o\000\000\000t\000\000\000e\000\000\000 \000\000\000n\000\000\000a\000\000\000m\000\000\000e\000\000\000 \000\000\000w\000\000\000i\000\000\000t\000\000\000h\000\000\000 \000\000\000b\000\000\000r\000\000\000a\000\000\000c\000\000\000k\000\000\000e\000\000\000t\000\000\000 \000\000\000\"\000\000\000",32,304418082);
		tr1 = F1242_11323(tr1, Result);
		tr2 = F1237_11118(RTMS_EX_H("\"",1,34));
		tr1 = F1242_11323(RTCW(tr1), tr2);
		F8_69(Current, tr1);
	}
	RTHOOK(13);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.character_to_string */
EIF_REFERENCE F8_82 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("character_to_string", 7, Current, 0, 1, 96);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1240_11189(RTCW(Result), ((EIF_INTEGER_32) 1L));
	RTHOOK(2);
	F1242_11317(RTCW(Result), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {IRON_PACKAGE_INFO_FILE_PARSER}.normalize_multiline */
void F8_83 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,loc6);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("normalize_multiline", 7, Current, 6, 1, 97);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(2);
	loc2 = (EIF_INTEGER_32) loc1;
	RTHOOK(3);
	loc5 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) (loc1 > loc5)) break;
		RTHOOK(5);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
		loc3 = F1240_11201(RTCW(arg1), tw1, loc1);
		RTHOOK(6);
		if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
			RTHOOK(7);
			loc3 = (EIF_INTEGER_32) loc5;
		}
		RTHOOK(8);
		if ((EIF_BOOLEAN)(loc3 == loc1)) {
		} else {
			RTHOOK(9);
			if ((EIF_BOOLEAN)(loc6 == NULL)) {
				RTHOOK(10);
				loc2 = (EIF_INTEGER_32) loc1;
				for (;;) {
					RTHOOK(11);
					tw1 = F1242_11271(RTCW(arg1), loc2);
					tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
					*(EIF_CHARACTER_32 *)tr1 = tw1;
					tb1 = F1188_10895(RTCW(tr1));
					if ((EIF_BOOLEAN) !tb1) break;
					RTHOOK(12);
					loc2++;
				}
				RTHOOK(13);
				loc6 = F1242_11351(RTCW(arg1), loc1, (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
			} else {
				RTHOOK(14);
				loc2 = (EIF_INTEGER_32) loc1;
				RTHOOK(15);
				loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					RTHOOK(16);
					tb2 = '\01';
					tb3 = '\01';
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
					if (!(EIF_BOOLEAN) (loc4 > ti4_1)) {
						tw1 = F1242_11271(RTCW(loc6), loc4);
						tw2 = F1242_11271(RTCW(arg1), loc2);
						tb3 = (EIF_BOOLEAN)(tw1 != tw2);
					}
					if (!tb3) {
						tb2 = (EIF_BOOLEAN) (loc2 > loc3);
					}
					if (tb2) break;
					RTHOOK(17);
					loc4++;
					RTHOOK(18);
					loc2++;
				}
				RTHOOK(19);
				tb3 = '\0';
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN) (loc4 <= ti4_1)) {
					tw1 = F1242_11271(RTCW(loc6), loc4);
					tw2 = F1242_11271(RTCW(arg1), loc2);
					tb3 = (EIF_BOOLEAN)(tw1 != tw2);
				}
				if (tb3) {
					RTHOOK(20);
					F1242_11286(RTCW(loc6), (EIF_INTEGER_32) (loc4 - ((EIF_INTEGER_32) 1L)));
				}
			}
		}
		RTHOOK(21);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
	}
	RTHOOK(22);
	tb3 = '\0';
	if ((EIF_BOOLEAN)(loc6 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
		tb3 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb3) {
		RTHOOK(23);
		tb3 = F1240_11224(RTCW(arg1), loc6);
		if (tb3) {
			RTHOOK(24);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_1_0_2_);
			F1242_11326(RTCW(arg1), ti4_1);
		}
		RTHOOK(25);
		tr1 = RTMS32_EX_H("\012\000\000\000",1,10);
		tr1 = F1242_11323(tr1, loc6);
		tr2 = RTMS32_EX_H("\012\000\000\000",1,10);
		F1242_11281(RTCW(arg1), tr1, tr2);
	}
	RTHOOK(26);
	RTLE;
	RTEE;
}

void EIF_Minit3 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
