/*
 * Code for class BYTE_CODE_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "by30.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BYTE_CODE_CONSTANTS}.extract_max */
EIF_NATURAL_32 F36_554 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("extract_max", 35, Current, 0, 0, 582);
	RTGC;
	RTHOOK(1);
	Result = (EIF_NATURAL_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 2147483647L) - ((EIF_INTEGER_32) 1L)) - ((EIF_INTEGER_32) 70L));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit30 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
