/*
 * Code for class IRON_PACKAGE_FILE_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir6.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_PACKAGE_FILE_FACTORY}.new_package_file */
EIF_REFERENCE F11_106 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("new_package_file", 10, Current, 1, 1, 138);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(254, 0x00).id, 254, _OBJSIZ_5_2_0_0_0_0_0_0_);
	F255_4378(RTCW(loc1), arg1);
	RTHOOK(2);
	Result = (EIF_REFERENCE) loc1;
	RTHOOK(3);
	tb1 = *(EIF_BOOLEAN *)(RTCW(Result) + O4273[Dtype(Result)-252]);
	if (tb1) {
		RTHOOK(4);
		Result = RTLNS(eif_new_type(253, 0x00).id, 253, _OBJSIZ_4_2_0_0_0_0_0_0_);
		F254_4365(RTCW(Result), arg1);
		RTHOOK(5);
		tb1 = *(EIF_BOOLEAN *)(RTCW(Result) + O4273[Dtype(Result)-252]);
		if (tb1) {
			RTHOOK(6);
			RTHOOK(7);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) loc1;
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit6 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
