
#ifndef _C1_gd24_
#define _C1_gd24_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F29_278(EIF_REFERENCE);
extern void EIF_Minit24(void);

#ifdef __cplusplus
}
#endif

#endif
