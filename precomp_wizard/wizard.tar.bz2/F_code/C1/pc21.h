
#ifndef _C1_pc21_
#define _C1_pc21_

#ifdef __cplusplus
extern "C" {
#endif

extern void F26_251(EIF_REFERENCE);
extern void F26_252(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F26_254(EIF_REFERENCE, EIF_INTEGER_32);
extern void F26_255(EIF_REFERENCE, EIF_REFERENCE);
extern void F26_256(EIF_REFERENCE, EIF_INTEGER_32);
extern void F26_257(EIF_REFERENCE, EIF_REFERENCE);
extern void F26_258(EIF_REFERENCE, EIF_REFERENCE);
extern void F26_259(EIF_REFERENCE);
extern void EIF_Minit21(void);
extern void F1413_13447(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern char *(*R9815[])();

#ifdef __cplusplus
}
#endif

#endif
