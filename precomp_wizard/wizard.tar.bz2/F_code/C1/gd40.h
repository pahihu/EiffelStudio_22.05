
#ifndef _C1_gd40_
#define _C1_gd40_

#ifdef __cplusplus
extern "C" {
#endif

extern void F45_651(EIF_REFERENCE, EIF_POINTER, EIF_POINTER, EIF_REAL_64, EIF_REAL_64);
extern void EIF_Minit40(void);

#ifdef __cplusplus
}
#endif

#endif
