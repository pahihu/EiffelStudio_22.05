/*
 * Code for class GDK_ENUMS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gd24.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F29_278
static EIF_INTEGER_32 inline_F29_278 (void)
{
	return GDK_SEAT_CAPABILITY_ALL;
	;
}
#define INLINE_F29_278
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GDK_ENUMS}.seat_capability_all */
EIF_INTEGER_32 F29_278 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("seat_capability_all", 28, Current, 0, 0, 313);
	Result = inline_F29_278 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit24 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
