/*
 * Code for class GTK_PROPERTIES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gt47.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F52_906
static EIF_POINTER inline_F52_906 (void)
{
	static char *v = "x-offset";
return (EIF_POINTER) v;
	;
}
#define INLINE_F52_906
#endif
#ifndef INLINE_F52_924
static EIF_POINTER inline_F52_924 (void)
{
	static char *v = "xalign";
return (EIF_POINTER) v;
	;
}
#define INLINE_F52_924
#endif
#ifndef INLINE_F52_925
static EIF_POINTER inline_F52_925 (void)
{
	static char *v = "justify";
return (EIF_POINTER) v;
	;
}
#define INLINE_F52_925
#endif
#ifndef INLINE_F52_932
static EIF_POINTER inline_F52_932 (void)
{
	static char *v = "gtk-menu-bar-accel";
return (EIF_POINTER) v;
	;
}
#define INLINE_F52_932
#endif
#ifndef INLINE_F52_933
static EIF_POINTER inline_F52_933 (void)
{
	static char *v = "gtk-menu-images";
return (EIF_POINTER) v;
	;
}
#define INLINE_F52_933
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GTK_PROPERTIES}.x_offset */
EIF_POINTER F52_906 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("x_offset", 51, Current, 0, 0, 1027);
	Result = inline_F52_906 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK_PROPERTIES}.xalign */
EIF_POINTER F52_924 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("xalign", 51, Current, 0, 0, 1015);
	Result = inline_F52_924 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK_PROPERTIES}.justify */
EIF_POINTER F52_925 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("justify", 51, Current, 0, 0, 1016);
	Result = inline_F52_925 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK_PROPERTIES}.gtk_menu_bar_accel */
EIF_POINTER F52_932 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_menu_bar_accel", 51, Current, 0, 0, 1023);
	Result = inline_F52_932 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK_PROPERTIES}.gtk_menu_icons */
EIF_POINTER F52_933 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_menu_icons", 51, Current, 0, 0, 1024);
	Result = inline_F52_933 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit47 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
