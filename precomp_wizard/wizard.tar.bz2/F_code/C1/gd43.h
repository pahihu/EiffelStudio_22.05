
#ifndef _C1_gd43_
#define _C1_gd43_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F48_844(EIF_REFERENCE, EIF_INTEGER_32*, EIF_INTEGER_32*);
extern void F48_845(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32*, EIF_INTEGER_32*);
extern EIF_POINTER F48_848(EIF_REFERENCE);
extern EIF_INTEGER_32 F48_850(EIF_REFERENCE);
extern void EIF_Minit43(void);

#ifdef __cplusplus
}
#endif

#endif
