
#ifndef _C1_gt49_
#define _C1_gt49_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F54_939(EIF_REFERENCE);
extern EIF_INTEGER_32 F54_941(EIF_REFERENCE);
extern void EIF_Minit49(void);

#ifdef __cplusplus
}
#endif

#endif
