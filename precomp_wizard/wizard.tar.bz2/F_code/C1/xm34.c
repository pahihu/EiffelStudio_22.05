/*
 * Code for class XML_NAMESPACE_RESOLVER_CONTEXT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm34.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.make */
void F39_595 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 38, Current, 0, 0, 704);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {882,805,1239,1241,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F883_8665(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.reset */
void F39_596 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("reset", 38, Current, 0, 0, 705);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R7661[Dtype(RTCW(tr1))-780])(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.add_default */
void F39_597 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("add_default", 38, Current, 0, 1, 706);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(596,F39_609, (Current));
	F39_598(Current, arg1, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.add */
void F39_598 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("add", 38, Current, 0, 2, 707);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = F883_8668(RTCW(tr1));
	tr2 = F39_606(Current, arg2);
	F806_8483(RTCW(tr1), arg1, tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.shallow_has */
EIF_BOOLEAN F39_600 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("shallow_has", 38, Current, 0, 1, 709);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O7900[Dtype(tr1)-882]);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = F883_8668(RTCW(tr1));
		tr2 = F39_606(Current, arg1);
		tb1 = F806_8444(RTCW(tr1), tr2);
		Result = tb1;
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.has */
EIF_BOOLEAN F39_601 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTEAA("has", 38, Current, 2, 1, 710);
	RTGC;
	RTHOOK(1);
	loc1 = F39_606(Current, arg1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7452[Dtype(RTCW(tr1))-554])(tr1);
	tb1 = EIF_FALSE;
	for (;;) {
		if (tb1) break;
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8078[Dtype(loc2)-967])(loc2);
		if (tb2) break;
		RTHOOK(3);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8077[Dtype(loc2)-967])(loc2);
		tb3 = F806_8444(RTCW(tr1), loc1);
		tb1 = tb3;
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R8079[Dtype(loc2)-967])(loc2);
	}
	Result = (EIF_BOOLEAN) tb1;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.resolve_default */
EIF_REFERENCE F39_602 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("resolve_default", 38, Current, 0, 0, 711);
	RTGC;
	RTHOOK(1);
	tr1 = RTOUCR(596,F39_609, (Current));
	Result = F39_603(Current, tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.resolve */
EIF_REFERENCE F39_603 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc3);
	RTLR(3,arg1);
	RTLR(4,loc4);
	RTLR(5,tr1);
	RTLR(6,loc1);
	RTLR(7,loc5);
	RTLIU(8);
	
	RTEAA("resolve", 38, Current, 5, 1, 712);
	RTGC;
	RTHOOK(1);
	Result = RTOUCR(597,F39_610, (Current));
	RTHOOK(2);
	loc3 = F39_606(Current, arg1);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7452[Dtype(RTCW(tr1))-554])(tr1);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8078[Dtype(loc4)-967])(loc4);
		if (tb1) break;
		RTHOOK(4);
		if (loc2) break;
		RTHOOK(5);
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8077[Dtype(loc4)-967])(loc4);
		RTHOOK(6);
		tb2 = '\0';
		tb3 = F806_8444(RTCW(loc1), loc3);
		if (tb3) {
			tr1 = F806_8442(RTCW(loc1), loc3);
			loc5 = tr1;
			tb2 = EIF_TEST(loc5);
		}
		if (tb2) {
			RTHOOK(7);
			Result = (EIF_REFERENCE) loc5;
			RTHOOK(8);
			loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		RTHOOK(9);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R8079[Dtype(loc4)-967])(loc4);
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.push */
void F39_604 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("push", 38, Current, 0, 0, 713);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = F39_608(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7880[Dtype(RTCW(tr1))-882])(tr1, tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.pop */
void F39_605 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("pop", 38, Current, 0, 0, 714);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O7900[Dtype(tr1)-882]);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current);
		F883_8684(RTCW(tr1));
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R7675[Dtype(RTCW(tr1))-780])(tr1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.to_context_key */
EIF_REFERENCE F39_606 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	
	
	RTEAA("to_context_key", 38, Current, 0, 1, 715);
	RTHOOK(1);
	tr1 = F1237_11119(RTCW(arg1));
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.new_string_string_table */
EIF_REFERENCE F39_608 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("new_string_string_table", 38, Current, 0, 0, 717);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {805,1239,1241,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 805, _OBJSIZ_7_3_0_7_0_0_0_0_);
	}
	F806_8436(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.default_pseudo_prefix */

EIF_REFERENCE F39_609 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (596,RTMS32_EX_H("",0,0));
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.default_namespace */

EIF_REFERENCE F39_610 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (597,RTMS32_EX_H("",0,0));
}

void EIF_Minit34 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
