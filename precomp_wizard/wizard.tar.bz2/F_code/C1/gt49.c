/*
 * Code for class GTK_ALIGN
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gt49.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F54_939
static EIF_INTEGER_32 inline_F54_939 (void)
{
	return GTK_ALIGN_START
	;
}
#define INLINE_F54_939
#endif
#ifndef INLINE_F54_941
static EIF_INTEGER_32 inline_F54_941 (void)
{
	return GTK_ALIGN_CENTER
	;
}
#define INLINE_F54_941
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GTK_ALIGN}.gtk_align_start */
EIF_INTEGER_32 F54_939 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_align_start", 53, Current, 0, 0, 1049);
	Result = inline_F54_939 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK_ALIGN}.gtk_align_center */
EIF_INTEGER_32 F54_941 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_align_center", 53, Current, 0, 0, 1051);
	Result = inline_F54_941 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit49 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
