/*
 * Code for class IRON_REPOSITORY_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ir7.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IRON_REPOSITORY_FACTORY}.new_repository */
EIF_REFERENCE F12_108 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,Result);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("new_repository", 11, Current, 1, 1, 140);
	RTGC;
	RTHOOK(1);
	tb1 = '\01';
	tr1 = RTMS_EX_H("https://",8,441357103);
	tb2 = F1237_11106(RTCW(arg1), tr1);
	if (!tb2) {
		tr1 = RTMS_EX_H("http://",7,769736239);
		tb2 = F1237_11106(RTCW(arg1), tr1);
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(2);
		loc1 = RTLNS(eif_new_type(1782, 0x00).id, 1782, _OBJSIZ_6_2_0_1_0_0_0_0_);
		F1783_20352(RTCW(loc1), arg1);
		RTHOOK(3);
		Result = RTLNS(eif_new_type(1287, 0x00).id, 1287, _OBJSIZ_4_0_0_0_0_0_0_0_);
		tr1 = F1783_20370(RTCW(loc1));
		F1288_12067(RTCW(Result), tr1);
	} else {
		RTHOOK(4);
		tr1 = RTMS_EX_H("file://",7,1704345391);
		tb1 = F1237_11106(RTCW(arg1), tr1);
		if (tb1) {
			RTHOOK(5);
			loc1 = RTLNS(eif_new_type(1782, 0x00).id, 1782, _OBJSIZ_6_2_0_1_0_0_0_0_);
			F1783_20352(RTCW(loc1), arg1);
			RTHOOK(6);
			Result = RTLNS(eif_new_type(1288, 0x00).id, 1288, _OBJSIZ_3_0_0_0_0_0_0_0_);
			tr1 = F1783_20370(RTCW(loc1));
			F1289_12080(RTCW(Result), tr1);
		} else {
			RTHOOK(7);
			Result = RTLNS(eif_new_type(1288, 0x00).id, 1288, _OBJSIZ_3_0_0_0_0_0_0_0_);
			F1289_12078(RTCW(Result), arg1);
			RTHOOK(8);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) Result;
		}
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit7 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
