/*
 * Code for class CONF_LOCATION_MAPPER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co33.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_LOCATION_MAPPER}.make */
void F38_588 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 37, Current, 0, 0, 703);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {891,161,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F892_8780(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {CONF_LOCATION_MAPPER}.mapped_path */
EIF_REFERENCE F38_589 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTEAA("mapped_path", 37, Current, 3, 1, 697);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = F892_8794(RTCW(tr1));
	for (;;) {
		tb1 = F1036_9256(loc2);
		if (tb1) break;
		RTHOOK(3);
		tr1 = F1036_9247(loc2);
		tr1 = F163_2264(RTCW(tr1), loc1);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			RTHOOK(4);
			loc1 = (EIF_REFERENCE) loc3;
		}
		RTHOOK(5);
		F1036_9262(loc2);
	}
	RTHOOK(6);
	RTHOOK(7);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) loc1;
}

/* {CONF_LOCATION_MAPPER}.refresh */
void F38_592 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("refresh", 37, Current, 1, 0, 700);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = F892_8794(RTCW(tr1));
	for (;;) {
		tb1 = F1036_9256(loc1);
		if (tb1) break;
		RTHOOK(2);
		tr1 = F1036_9247(loc1);
		F163_2266(RTCW(tr1));
		RTHOOK(3);
		F1036_9262(loc1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {CONF_LOCATION_MAPPER}.register */
void F38_593 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("register", 37, Current, 0, 1, 701);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	F892_8820(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit33 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
