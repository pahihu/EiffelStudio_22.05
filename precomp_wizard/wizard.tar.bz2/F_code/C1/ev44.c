/*
 * Code for class EV_STOCK_COLORS_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev44.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F176_2794
static void inline_F176_2794 (EIF_POINTER arg1)
{
	gtk_widget_destroy((GtkWidget*) arg1)
	;
}
#define INLINE_F176_2794
#endif
#ifndef INLINE_F176_2694
static EIF_POINTER inline_F176_2694 (void)
{
	return (EIF_POINTER) (GTK_STYLE_PROPERTY_COLOR)
	;
}
#define INLINE_F176_2694
#endif
#ifndef INLINE_F176_2716
static void inline_F176_2716 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_POINTER arg3, EIF_POINTER arg4)
{
	gtk_style_context_get (arg1, arg2, arg3, arg4, NULL)
	;
}
#define INLINE_F176_2716
#endif
#ifndef INLINE_F176_2693
static EIF_POINTER inline_F176_2693 (void)
{
	return (EIF_POINTER) (GTK_STYLE_PROPERTY_BACKGROUND_COLOR)
	;
}
#define INLINE_F176_2693
#endif
#ifndef INLINE_F176_2695
static EIF_POINTER inline_F176_2695 (void)
{
	return (EIF_POINTER) (GTK_STYLE_PROPERTY_FONT)
	;
}
#define INLINE_F176_2695
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_STOCK_COLORS_IMP}.default_background_color */
EIF_REFERENCE F49_853 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("default_background_color", 48, Current, 1, 0, 963);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_POINTER) gtk_dialog_new();
	RTHOOK(2);
	ti4_1 = (EIF_INTEGER_32) GTK_STATE_NORMAL;
	Result = F49_860(Current, loc1, ((EIF_INTEGER_32) 4L), ti4_1);
	RTHOOK(3);
	inline_F176_2794(loc1);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_STOCK_COLORS_IMP}.default_foreground_color */
EIF_REFERENCE F49_856 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("default_foreground_color", 48, Current, 1, 0, 966);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_POINTER) gtk_dialog_new();
	RTHOOK(2);
	ti4_1 = (EIF_INTEGER_32) GTK_STATE_NORMAL;
	Result = F49_860(Current, loc1, ((EIF_INTEGER_32) 3L), ti4_1);
	RTHOOK(3);
	inline_F176_2794(loc1);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_STOCK_COLORS_IMP}.color_from_state */
EIF_REFERENCE F49_860 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REAL_32 loc3 = (EIF_REAL_32) 0;
	EIF_REAL_32 loc4 = (EIF_REAL_32) 0;
	EIF_REAL_32 loc5 = (EIF_REAL_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REAL_32 loc7 = (EIF_REAL_32) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc6);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("color_from_state", 48, Current, 7, 3, 970);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_POINTER) gtk_widget_get_style_context((GtkWidget*) arg1);
	RTHOOK(2);
	gtk_style_context_save((GtkStyleContext*) loc1);
	RTHOOK(3);
	gtk_style_context_set_state((GtkStyleContext*) loc1, (GtkStateFlags) arg3);
	RTHOOK(4);
	switch (arg2) {
		case 3L:
			RTHOOK(5);
			ti4_1 = (EIF_INTEGER_32) gtk_style_context_get_state((GtkStyleContext*) loc1);
			tp1 = inline_F176_2694();
			inline_F176_2716(loc1, ti4_1, tp1, (EIF_POINTER *) &(loc2));
			break;
		case 4L:
			RTHOOK(6);
			ti4_1 = (EIF_INTEGER_32) gtk_style_context_get_state((GtkStyleContext*) loc1);
			tp1 = inline_F176_2693();
			inline_F176_2716(loc1, ti4_1, tp1, (EIF_POINTER *) &(loc2));
			break;
		case 1L:
			RTHOOK(7);
			ti4_1 = (EIF_INTEGER_32) gtk_style_context_get_state((GtkStyleContext*) loc1);
			tp1 = inline_F176_2695();
			inline_F176_2716(loc1, ti4_1, tp1, (EIF_POINTER *) &(loc2));
			break;
		case 2L:
			RTHOOK(8);
			loc6 = RTLNS(eif_new_type(1137, 0x00).id, 1137, _OBJSIZ_0_1_0_1_0_1_0_0_);
			tr1 = RTMS_EX_H("background-color",16,693867890);
			F1138_9661(RTCW(loc6), tr1);
			RTHOOK(9);
			ti4_1 = (EIF_INTEGER_32) gtk_style_context_get_state((GtkStyleContext*) loc1);
			tp1 = *(EIF_POINTER *)(RTCW(loc6)+ _PTROFF_0_1_0_1_0_0_);
			inline_F176_2716(loc1, ti4_1, tp1, (EIF_POINTER *) &(loc2));
			break;
		default:
			RTEC(EN_WHEN);
	}
	RTHOOK(10);
	gtk_style_context_restore((GtkStyleContext*) loc1);
	RTHOOK(11);
	tr8_1 = (EIF_REAL_64) (((GdkRGBA *)loc2)->red);
	loc3 = (EIF_REAL_32) (tr8_1);
	RTHOOK(12);
	tr8_1 = (EIF_REAL_64) (((GdkRGBA *)loc2)->green);
	loc4 = (EIF_REAL_32) (tr8_1);
	RTHOOK(13);
	tr8_1 = (EIF_REAL_64) (((GdkRGBA *)loc2)->blue);
	loc5 = (EIF_REAL_32) (tr8_1);
	RTHOOK(14);
	Result = RTLNS(eif_new_type(1256, 0x00).id, 1256, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1257_11685(RTCW(Result), loc3, loc4, loc5);
	RTHOOK(15);
	gdk_rgba_free((GdkRGBA*) loc2);
	RTHOOK(16);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit44 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
