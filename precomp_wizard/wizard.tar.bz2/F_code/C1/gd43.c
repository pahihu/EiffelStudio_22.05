/*
 * Code for class GDK_HELPERS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gd43.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F48_844
static EIF_POINTER inline_F48_844 (EIF_INTEGER_32* arg1, EIF_INTEGER_32* arg2)
{
	return (GdkWindow*) gdk_device_get_window_at_position((GdkDevice*) gdk_seat_get_pointer((GdkSeat*) gdk_display_get_default_seat ((GdkDisplay*) gdk_display_get_default())), (gint*) arg1, (gint*) arg2);
	;
}
#define INLINE_F48_844
#endif
#ifndef INLINE_F48_845
static void inline_F48_845 (EIF_POINTER arg1, EIF_INTEGER_32* arg2, EIF_INTEGER_32* arg3)
{
	return gdk_device_get_position ((GdkDevice*) arg1, NULL, (gint*) arg2, (gint*) arg3);
	;
}
#define INLINE_F48_845
#endif
#ifndef INLINE_F48_848
static EIF_POINTER inline_F48_848 (void)
{
	return (GdkDevice*) gdk_seat_get_pointer((GdkSeat*) gdk_display_get_default_seat ((GdkDisplay*) gdk_display_get_default()));
	;
}
#define INLINE_F48_848
#endif
#ifndef INLINE_F48_850
static EIF_INTEGER_32 inline_F48_850 (void)
{
	return gdk_display_get_default_cursor_size ((GdkDisplay*) gdk_display_get_default());
	;
}
#define INLINE_F48_850
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GDK_HELPERS}.window_at */
EIF_POINTER F48_844 (EIF_REFERENCE Current, EIF_INTEGER_32* arg1, EIF_INTEGER_32* arg2)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("window_at", 47, Current, 0, 2, 954);
	Result = inline_F48_844 ((EIF_INTEGER_32*) arg1, (EIF_INTEGER_32*) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK_HELPERS}.device_get_position */
void F48_845 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32* arg2, EIF_INTEGER_32* arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("device_get_position", 47, Current, 0, 3, 955);
	inline_F48_845 ((EIF_POINTER) arg1, (EIF_INTEGER_32*) arg2, (EIF_INTEGER_32*) arg3);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK_HELPERS}.default_device */
EIF_POINTER F48_848 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_device", 47, Current, 0, 0, 958);
	Result = inline_F48_848 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK_HELPERS}.default_cursor_size */
EIF_INTEGER_32 F48_850 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_cursor_size", 47, Current, 0, 0, 960);
	Result = inline_F48_850 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit43 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
