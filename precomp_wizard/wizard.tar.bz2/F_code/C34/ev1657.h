
#ifndef _C34_ev1657_
#define _C34_ev1657_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1542_15547(EIF_REFERENCE);
extern EIF_REFERENCE F1542_15548(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F1542_15549(EIF_REFERENCE);
extern void EIF_Minit1657(void);
extern void F1514_14820(EIF_REFERENCE, EIF_BOOLEAN);
extern char *(*R7663[])();
extern char *(*R7706[])();
extern char *(*R7917[])();
extern long O12773[];
extern EIF_TYPE_INDEX Y12773[];
extern EIF_TYPE_INDEX *Y12773_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
