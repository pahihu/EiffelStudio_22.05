
#ifndef _C34_dy1699_
#define _C34_dy1699_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F672_8266(EIF_REFERENCE);
extern void EIF_Minit1699(void);

#ifdef __cplusplus
}
#endif

#endif
