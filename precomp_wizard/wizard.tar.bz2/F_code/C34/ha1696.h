
#ifndef _C34_ha1696_
#define _C34_ha1696_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F1029_9229(EIF_REFERENCE);
extern EIF_REFERENCE F1029_9230(EIF_REFERENCE);
extern EIF_BOOLEAN F1029_9232(EIF_REFERENCE);
extern void F1029_9233(EIF_REFERENCE);
extern EIF_REFERENCE F1029_9234(EIF_REFERENCE);
extern void EIF_Minit1696(void);
extern EIF_INTEGER_32 F812_8481(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F1019_9221(EIF_REFERENCE);
extern EIF_INTEGER_32 F812_8480(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R11373[])();
extern char *(*R7739[])();

#ifdef __cplusplus
}
#endif

#endif
