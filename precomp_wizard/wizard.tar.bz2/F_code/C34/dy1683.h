
#ifndef _C34_dy1683_
#define _C34_dy1683_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F679_8266(EIF_REFERENCE);
extern void EIF_Minit1683(void);

#ifdef __cplusplus
}
#endif

#endif
