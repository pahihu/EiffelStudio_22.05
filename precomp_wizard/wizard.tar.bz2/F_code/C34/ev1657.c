/*
 * Code for class EV_DYNAMIC_LIST_IMP [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1657.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DYNAMIC_LIST_IMP}.make */
void F1542_15547 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 1541, Current, 0, 0, 22042);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_final_id(Y12773,Y12773_gen_type,Dftype(Current),1541).id);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R7917[Dtype(RTCW(tr1))-891])(tr1, ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O12773[Dtype(Current)-1541]) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	F1514_14820(Current, (EIF_BOOLEAN) 1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_DYNAMIC_LIST_IMP}.i_th */
EIF_REFERENCE F1542_15548 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("i_th", 1541, Current, 0, 1, 22043);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O12773[Dtype(Current)-1541]);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R7663[Dtype(RTCW(tr1))-832])(tr1, (EIF_REFERENCE) &arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_DYNAMIC_LIST_IMP}.count */
EIF_INTEGER_32 F1542_15549 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("count", 1541, Current, 0, 0, 22044);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O12773[Dtype(Current)-1541]);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7706[Dtype(RTCW(tr1))-780])(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit1657 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
