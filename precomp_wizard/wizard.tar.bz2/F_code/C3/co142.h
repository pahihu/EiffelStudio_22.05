
#ifndef _C3_co142_
#define _C3_co142_

#ifdef __cplusplus
extern "C" {
#endif

extern void F166_2279(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit142(void);

#ifdef __cplusplus
}
#endif

#endif
