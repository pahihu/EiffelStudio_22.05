
#ifndef _C3_sh134_
#define _C3_sh134_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F158_2246_body(EIF_REFERENCE);
extern EIF_REFERENCE F158_2246(EIF_REFERENCE);
extern void EIF_Minit134(void);

#ifdef __cplusplus
}
#endif

#endif
