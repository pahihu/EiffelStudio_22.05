
#ifndef _C3_ev147_
#define _C3_ev147_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F173_2326(EIF_REFERENCE);
extern void EIF_Minit147(void);
extern void F916_8909(EIF_REFERENCE);
extern long O2304[];

#ifdef __cplusplus
}
#endif

#endif
