
#ifndef _C3_pa143_
#define _C3_pa143_

#ifdef __cplusplus
extern "C" {
#endif

extern void F169_2298(EIF_REFERENCE);
extern EIF_REFERENCE F169_2318(EIF_REFERENCE);
extern void EIF_Minit143(void);

#ifdef __cplusplus
}
#endif

#endif
