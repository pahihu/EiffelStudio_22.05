/*
 * Code for class GDK
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gd149.h"
#include <stdlib.h>
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F175_2382
static void inline_F175_2382 (EIF_POINTER arg1)
{
	return gdk_set_allowed_backends ( (const gchar*) arg1);
	;
}
#define INLINE_F175_2382
#endif
#ifndef INLINE_F175_2403
static int inline_F175_2403 (EIF_POINTER arg1)
{
	return (int) (GDK_IS_PIXBUF(arg1))
	;
}
#define INLINE_F175_2403
#endif
#ifndef INLINE_F175_2405
static void inline_F175_2405 (EIF_POINTER arg1)
{
	printf((char*) arg1)
	;
}
#define INLINE_F175_2405
#endif
#ifndef INLINE_F175_2406
static EIF_NATURAL_32 inline_F175_2406 (EIF_POINTER arg1)
{
	return (EIF_NATURAL_32) (((GObject*)arg1)->ref_count)
	;
}
#define INLINE_F175_2406
#endif
#ifndef INLINE_F175_2407
static int inline_F175_2407 (EIF_POINTER arg1)
{
	return (int) (g_object_is_floating((gpointer) arg1))
	;
}
#define INLINE_F175_2407
#endif
#ifndef INLINE_F175_2408
static EIF_POINTER inline_F175_2408 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (g_object_ref_sink((gpointer) arg1))
	;
}
#define INLINE_F175_2408
#endif
#ifndef INLINE_F175_2409
static EIF_POINTER inline_F175_2409 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (g_object_ref((gpointer) arg1))
	;
}
#define INLINE_F175_2409
#endif
#ifndef INLINE_F175_2410
static void inline_F175_2410 (EIF_POINTER arg1)
{
	g_object_unref((gpointer) arg1)
	;
}
#define INLINE_F175_2410
#endif
#ifndef INLINE_F175_2413
static void inline_F175_2413 (EIF_POINTER arg1)
{
	g_object_run_dispose((GObject *) arg1)
	;
}
#define INLINE_F175_2413
#endif
#ifndef INLINE_F175_2419
static EIF_POINTER inline_F175_2419 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gdk_display_get_default_screen ((GdkDisplay*) arg1))
	;
}
#define INLINE_F175_2419
#endif
#ifndef INLINE_F175_2421
static EIF_INTEGER_32 inline_F175_2421 (EIF_POINTER arg1)
{
	return gdk_display_get_n_monitors ((GdkDisplay*) arg1)
	;
}
#define INLINE_F175_2421
#endif
#ifndef INLINE_F175_2426
static void inline_F175_2426 (EIF_POINTER arg1)
{
	gdk_display_flush ((GdkDisplay *)arg1);
	;
}
#define INLINE_F175_2426
#endif
#ifndef INLINE_F175_2427
static void inline_F175_2427 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gdk_monitor_get_geometry ((GdkMonitor*) arg1, (GdkRectangle*) arg2)
	;
}
#define INLINE_F175_2427
#endif
#ifndef INLINE_F175_2457
static EIF_POINTER inline_F175_2457 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	return gdk_window_create_similar_surface ((GdkWindow *)arg1,
                                   (cairo_content_t)arg2,
                                   (int)arg3,
                                   (int)arg4);
	;
}
#define INLINE_F175_2457
#endif
#ifndef INLINE_F175_2470
static void inline_F175_2470 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4)
{
	return gdk_cairo_set_source_pixbuf ((cairo_t *) arg1, (const GdkPixbuf *) arg2, (gdouble) arg3, (gdouble) arg4);
	;
}
#define INLINE_F175_2470
#endif
#ifndef INLINE_F175_2476
static EIF_INTEGER_32 inline_F175_2476 (EIF_POINTER arg1)
{
	return (EIF_INTEGER_32) (gdk_visual_get_depth ((GdkVisual*) arg1))
	;
}
#define INLINE_F175_2476
#endif
#ifndef INLINE_F175_2545
static EIF_INTEGER_32 inline_F175_2545 (void)
{
	return GDK_COLORSPACE_RGB;
	;
}
#define INLINE_F175_2545
#endif
#ifndef INLINE_F175_2548
static void inline_F175_2548 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	{
	GType type = G_TYPE_STRING;
	memcpy ((char *) arg1 + arg2, &type, sizeof(GType));
}
	;
}
#define INLINE_F175_2548
#endif
#ifndef INLINE_F175_2549
static void inline_F175_2549 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	{
	GType type = GDK_TYPE_PIXBUF;
	memcpy ((char *) arg1 + arg2, &type, sizeof(GType));
}
	;
}
#define INLINE_F175_2549
#endif
#ifndef INLINE_F175_2550
static EIF_POINTER inline_F175_2550 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	return (EIF_POINTER) (gdk_pixbuf_scale_simple ((GdkPixbuf*) arg1, (int) arg2, (int) arg3, (int) arg4))
	;
}
#define INLINE_F175_2550
#endif
#ifndef INLINE_F175_2559
static EIF_POINTER inline_F175_2559 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	return gdk_pixbuf_get_from_surface ((cairo_surface_t *) arg1, (gint) arg2, (gint) arg3, (gint) arg4, (gint) arg5);
	;
}
#define INLINE_F175_2559
#endif
#ifndef INLINE_F175_2560
static EIF_POINTER inline_F175_2560 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	return gdk_pixbuf_get_from_window ((GdkWindow *) arg1, (gint) arg2, (gint) arg3, (gint) arg4, (gint) arg5);
	;
}
#define INLINE_F175_2560
#endif
#ifndef INLINE_F175_2562
static EIF_POINTER inline_F175_2562 (EIF_POINTER arg1)
{
	return gdk_pixbuf_copy ((GdkPixbuf*)arg1);
	;
}
#define INLINE_F175_2562
#endif
#ifndef INLINE_F175_2563
static EIF_INTEGER_32 inline_F175_2563 (EIF_POINTER arg1)
{
	return gdk_pixbuf_get_width ((GdkPixbuf*)arg1);
	;
}
#define INLINE_F175_2563
#endif
#ifndef INLINE_F175_2564
static EIF_INTEGER_32 inline_F175_2564 (EIF_POINTER arg1)
{
	return gdk_pixbuf_get_height ((GdkPixbuf*)arg1);
	;
}
#define INLINE_F175_2564
#endif
#ifndef INLINE_F175_2568
static EIF_POINTER inline_F175_2568 (EIF_POINTER arg1, EIF_POINTER* arg2)
{
	return gdk_pixbuf_new_from_file ((char*) arg1, (GError**) arg2);
	;
}
#define INLINE_F175_2568
#endif
#ifndef INLINE_F175_2570
static EIF_POINTER inline_F175_2570 (EIF_POINTER arg1)
{
	return gdk_pixbuf_new_from_xpm_data ((const char**) arg1);
	;
}
#define INLINE_F175_2570
#endif
#ifndef INLINE_F175_2572
static EIF_POINTER inline_F175_2572 (EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	return gdk_pixbuf_new ((GdkColorspace) arg1, (gboolean) arg2, (int) arg3, (int) arg4, (int) arg5);
	;
}
#define INLINE_F175_2572
#endif
#ifndef INLINE_F175_2574
static void inline_F175_2574 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gdk_pixbuf_fill ((GdkPixbuf*)arg1, (guint32) arg2);
	;
}
#define INLINE_F175_2574
#endif
#ifndef INLINE_F175_2576
static EIF_INTEGER_32 inline_F175_2576 (EIF_POINTER arg1)
{
	return gdk_screen_get_resolution ((GdkScreen*)arg1);
	;
}
#define INLINE_F175_2576
#endif
#ifndef INLINE_F175_2577
static int inline_F175_2577 (EIF_POINTER arg1)
{
	return gdk_screen_is_composited ((GdkScreen*)arg1);
	;
}
#define INLINE_F175_2577
#endif
#ifndef INLINE_F175_2578
static EIF_POINTER inline_F175_2578 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gdk_screen_get_system_visual ((GdkScreen*) arg1))
	;
}
#define INLINE_F175_2578
#endif
#ifndef INLINE_F175_2579
static EIF_POINTER inline_F175_2579 (EIF_POINTER arg1)
{
	return gdk_screen_get_rgba_visual ((GdkScreen*)arg1);
	;
}
#define INLINE_F175_2579
#endif
#ifndef INLINE_F175_2581
static EIF_POINTER inline_F175_2581 (void)
{
	return gdk_screen_get_default()
	;
}
#define INLINE_F175_2581
#endif
#ifndef INLINE_F175_2583
static EIF_POINTER inline_F175_2583 (EIF_POINTER arg1)
{
	return gdk_screen_get_root_window ((GdkScreen *)arg1);;
	;
}
#define INLINE_F175_2583
#endif
#ifndef INLINE_F175_2584
static EIF_POINTER inline_F175_2584 (void)
{
	return gdk_get_default_root_window();
	;
}
#define INLINE_F175_2584
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GDK}.gdk_set_allowed_backends */
void F175_2382 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_set_allowed_backends", 174, Current, 0, 1, 2773);
	inline_F175_2382 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.g_free */
void F175_2383 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_free", 174, Current, 0, 1, 2774);g_free((gpointer) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.g_malloc */
EIF_POINTER F175_2384 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_malloc", 174, Current, 0, 1, 2775);Result = (EIF_POINTER) g_malloc((gulong) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.g_realloc */
EIF_POINTER F175_2385 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_realloc", 174, Current, 0, 2, 2776);Result = (EIF_POINTER) g_realloc((gpointer) arg1, (gulong) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.g_list_free */
void F175_2387 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_list_free", 174, Current, 0, 1, 2778);g_list_free((GList*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.g_list_length */
EIF_INTEGER_32 F175_2390 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_list_length", 174, Current, 0, 1, 2781);Result = (EIF_INTEGER_32) g_list_length((GList*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.g_list_nth_data */
EIF_POINTER F175_2392 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_list_nth_data", 174, Current, 0, 2, 2783);Result = (EIF_POINTER) g_list_nth_data((GList*) arg1, (guint) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.glist_struct_data */
EIF_POINTER F175_2394 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("glist_struct_data", 174, Current, 0, 1, 2785);Result = (EIF_POINTER) (((GList *)arg1)->data);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.glist_struct_next */
EIF_POINTER F175_2395 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("glist_struct_next", 174, Current, 0, 1, 2786);Result = (EIF_POINTER) (((GList *)arg1)->next);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.g_slist_free */
void F175_2397 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_slist_free", 174, Current, 0, 1, 2788);g_slist_free((GSList*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.g_slist_index */
EIF_INTEGER_32 F175_2398 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_slist_index", 174, Current, 0, 2, 2789);Result = (EIF_INTEGER_32) g_slist_index((GSList*) arg1, (gpointer) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.g_slist_length */
EIF_INTEGER_32 F175_2399 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_slist_length", 174, Current, 0, 1, 2790);Result = (EIF_INTEGER_32) g_slist_length((GSList*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.g_slist_nth_data */
EIF_POINTER F175_2400 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_slist_nth_data", 174, Current, 0, 2, 2791);Result = (EIF_POINTER) g_slist_nth_data((GSList*) arg1, (guint) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gslist_struct_data */
EIF_POINTER F175_2401 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gslist_struct_data", 174, Current, 0, 1, 2792);Result = (EIF_POINTER) (((GSList *)arg1)->data);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gslist_struct_next */
EIF_POINTER F175_2402 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gslist_struct_next", 174, Current, 0, 1, 2793);Result = (EIF_POINTER) (((GSList *)arg1)->next);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_is_pixbuf */
EIF_BOOLEAN F175_2403 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_is_pixbuf", 174, Current, 0, 1, 2794);
	Result = EIF_TEST(inline_F175_2403 ((EIF_POINTER) arg1));
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.printf */
void F175_2404 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("printf", 174, Current, 1, 1, 2795);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1));
	RTHOOK(2);
	inline_F175_2405(loc1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {GDK}.c_printf */
void F175_2405 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("c_printf", 174, Current, 0, 1, 2796);
	inline_F175_2405 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.internal_g_object_ref_count */
EIF_NATURAL_32 F175_2406 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("internal_g_object_ref_count", 174, Current, 0, 1, 2797);
	Result = inline_F175_2406 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.g_object_is_floating */
EIF_BOOLEAN F175_2407 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_object_is_floating", 174, Current, 0, 1, 2798);
	Result = EIF_TEST(inline_F175_2407 ((EIF_POINTER) arg1));
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.g_object_ref_sink */
EIF_POINTER F175_2408 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_object_ref_sink", 174, Current, 0, 1, 2799);
	Result = inline_F175_2408 ((EIF_POINTER) arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.g_object_ref */
EIF_POINTER F175_2409 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_object_ref", 174, Current, 0, 1, 2800);
	Result = inline_F175_2409 ((EIF_POINTER) arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.g_object_unref */
void F175_2410 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_object_unref", 174, Current, 0, 1, 2801);
	inline_F175_2410 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.g_object_run_dispose */
void F175_2413 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("g_object_run_dispose", 174, Current, 0, 1, 2804);
	inline_F175_2413 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_display_get_default */
EIF_POINTER F175_2415 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_display_get_default", 174, Current, 0, 0, 2806);Result = (EIF_POINTER) gdk_display_get_default();
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_display_get_default_seat */
EIF_POINTER F175_2416 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_display_get_default_seat", 174, Current, 0, 1, 2807);Result = (EIF_POINTER) gdk_display_get_default_seat((GdkDisplay*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_display_get_primary_monitor */
EIF_POINTER F175_2417 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_display_get_primary_monitor", 174, Current, 0, 1, 2808);Result = (EIF_POINTER) gdk_display_get_primary_monitor((GdkDisplay*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_display_get_default_screen */
EIF_POINTER F175_2419 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_display_get_default_screen", 174, Current, 0, 1, 2810);
	Result = inline_F175_2419 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_display_get_n_monitors */
EIF_INTEGER_32 F175_2421 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_display_get_n_monitors", 174, Current, 0, 1, 2812);
	Result = inline_F175_2421 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_display_flush */
void F175_2426 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_display_flush", 174, Current, 0, 1, 2817);
	inline_F175_2426 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_monitor_get_geometry */
void F175_2427 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_monitor_get_geometry", 174, Current, 0, 2, 2818);
	inline_F175_2427 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_window_get_position */
void F175_2435 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32* arg2, EIF_INTEGER_32* arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_window_get_position", 174, Current, 0, 3, 2826);gdk_window_get_position((GdkWindow*) arg1, (gint*) arg2, (gint*) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_window_get_device_position */
EIF_POINTER F175_2436 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32* arg3, EIF_INTEGER_32* arg4, EIF_POINTER arg5)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_window_get_device_position", 174, Current, 0, 5, 2827);Result = (EIF_POINTER) gdk_window_get_device_position((GdkWindow*) arg1, (GdkDevice *) arg2, (gint*) arg3, (gint*) arg4, (GdkModifierType*) arg5);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_window_get_origin */
EIF_INTEGER_32 F175_2441 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_window_get_origin", 174, Current, 0, 3, 2832);Result = (EIF_INTEGER_32) gdk_window_get_origin((GdkWindow*) arg1, (gint*) arg2, (gint*) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_window_get_user_data */
void F175_2442 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER* arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_window_get_user_data", 174, Current, 0, 2, 2833);gdk_window_get_user_data((GdkWindow*) arg1, (gpointer*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_window_hide */
void F175_2443 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_window_hide", 174, Current, 0, 1, 2834);gdk_window_hide((GdkWindow*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_window_raise */
void F175_2447 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_window_raise", 174, Current, 0, 1, 2838);gdk_window_raise((GdkWindow*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_window_set_cursor */
void F175_2448 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_window_set_cursor", 174, Current, 0, 2, 2839);gdk_window_set_cursor((GdkWindow*) arg1, (GdkCursor*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_window_set_decorations */
void F175_2449 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_window_set_decorations", 174, Current, 0, 2, 2840);gdk_window_set_decorations((GdkWindow*) arg1, (GdkWMDecoration) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_window_set_functions */
void F175_2451 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_window_set_functions", 174, Current, 0, 2, 2842);gdk_window_set_functions((GdkWindow*) arg1, (GdkWMFunction) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_window_create_similar_surface */
EIF_POINTER F175_2457 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_window_create_similar_surface", 174, Current, 0, 4, 2848);
	Result = inline_F175_2457 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2, (EIF_INTEGER_32) arg3, (EIF_INTEGER_32) arg4);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_window_invalidate_rect */
void F175_2461 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_BOOLEAN arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_window_invalidate_rect", 174, Current, 0, 3, 2852);gdk_window_invalidate_rect((GdkWindow*) arg1, (GdkRectangle*) arg2, (gboolean) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_cairo_set_source_pixbuf */
void F175_2470 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_cairo_set_source_pixbuf", 174, Current, 0, 4, 2861);
	inline_F175_2470 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_REAL_64) arg3, (EIF_REAL_64) arg4);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_seat_grab */
EIF_INTEGER_32 F175_2472 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_BOOLEAN arg4, EIF_POINTER arg5, EIF_POINTER arg6, EIF_POINTER arg7, EIF_POINTER arg8)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_seat_grab", 174, Current, 0, 8, 2863);Result = (EIF_INTEGER_32) gdk_seat_grab((GdkSeat*) arg1, (GdkWindow*) arg2, (GdkSeatCapabilities) arg3, (gboolean) arg4, (GdkCursor*) arg5, (const GdkEvent*) arg6, (GdkSeatGrabPrepareFunc) arg7, (gpointer) arg8);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_seat_ungrab */
void F175_2473 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_seat_ungrab", 174, Current, 0, 1, 2864);gdk_seat_ungrab((GdkSeat*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_device_get_window_at_position */
EIF_POINTER F175_2475 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32* arg2, EIF_INTEGER_32* arg3)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_device_get_window_at_position", 174, Current, 0, 3, 2866);Result = (EIF_POINTER) gdk_device_get_window_at_position((GdkDevice*) arg1, (gint*) arg2, (gint*) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_visual_get_depth */
EIF_INTEGER_32 F175_2476 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_visual_get_depth", 174, Current, 0, 1, 2867);
	Result = inline_F175_2476 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_free */
void F175_2477 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_free", 174, Current, 0, 1, 2868);gdk_event_free((GdkEvent*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_event_get */
EIF_POINTER F175_2478 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_get", 174, Current, 0, 0, 2869);Result = (EIF_POINTER) gdk_event_get();
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_focus_struct_in */
EIF_INTEGER_8 F175_2480 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_focus_struct_in", 174, Current, 0, 1, 2871);Result = (EIF_INTEGER_8) (((GdkEventFocus *)arg1)->in);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_any_struct_send_event */
EIF_INTEGER_8 F175_2481 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_any_struct_send_event", 174, Current, 0, 1, 2561);Result = (EIF_INTEGER_8) (((GdkEventAny *)arg1)->send_event);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_any_struct_window */
EIF_POINTER F175_2482 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_any_struct_window", 174, Current, 0, 1, 2562);Result = (EIF_POINTER) (((GdkEventAny *)arg1)->window);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.set_gdk_event_any_struct_window */
void F175_2483 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_gdk_event_any_struct_window", 174, Current, 0, 2, 2563);(((GdkEventAny *)arg1)->window = (GdkWindow*)(arg2));
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_event_any_struct_type */
EIF_INTEGER_8 F175_2484 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_any_struct_type", 174, Current, 0, 1, 2564);Result = (EIF_INTEGER_8) (((GdkEventAny *)arg1)->type);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_button_struct_button */
EIF_INTEGER_32 F175_2485 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_button_struct_button", 174, Current, 0, 1, 2565);Result = (EIF_INTEGER_32) (((GdkEventButton *)arg1)->button);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_button_struct_window */
EIF_POINTER F175_2486 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_button_struct_window", 174, Current, 0, 1, 2566);Result = (EIF_POINTER) (((GdkEventButton *)arg1)->window);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_button_struct_state */
EIF_NATURAL_32 F175_2487 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_button_struct_state", 174, Current, 0, 1, 2567);Result = (EIF_NATURAL_32) (((GdkEventButton *)arg1)->state);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_button_struct_type */
EIF_INTEGER_32 F175_2488 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_button_struct_type", 174, Current, 0, 1, 2568);Result = (EIF_INTEGER_32) (((GdkEventButton *)arg1)->type);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_button_struct_x */
EIF_REAL_64 F175_2489 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_button_struct_x", 174, Current, 0, 1, 2569);Result = (EIF_REAL_64) (((GdkEventButton *)arg1)->x);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_button_struct_x_root */
EIF_REAL_64 F175_2490 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_button_struct_x_root", 174, Current, 0, 1, 2570);Result = (EIF_REAL_64) (((GdkEventButton *)arg1)->x_root);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_scroll_struct_x_root */
EIF_REAL_64 F175_2491 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_scroll_struct_x_root", 174, Current, 0, 1, 2571);Result = (EIF_REAL_64) (((GdkEventScroll *)arg1)->x_root);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_button_struct_y */
EIF_REAL_64 F175_2492 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_button_struct_y", 174, Current, 0, 1, 2572);Result = (EIF_REAL_64) (((GdkEventButton *)arg1)->y);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_button_struct_y_root */
EIF_REAL_64 F175_2493 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_button_struct_y_root", 174, Current, 0, 1, 2573);Result = (EIF_REAL_64) (((GdkEventButton *)arg1)->y_root);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_scroll_struct_y_root */
EIF_REAL_64 F175_2494 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_scroll_struct_y_root", 174, Current, 0, 1, 2574);Result = (EIF_REAL_64) (((GdkEventScroll *)arg1)->y_root);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_configure_struct_x */
EIF_INTEGER_32 F175_2495 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_configure_struct_x", 174, Current, 0, 1, 2575);Result = (EIF_INTEGER_32) (((GdkEventConfigure *)arg1)->x);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_configure_struct_y */
EIF_INTEGER_32 F175_2496 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_configure_struct_y", 174, Current, 0, 1, 2576);Result = (EIF_INTEGER_32) (((GdkEventConfigure *)arg1)->y);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_configure_struct_height */
EIF_INTEGER_32 F175_2497 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_configure_struct_height", 174, Current, 0, 1, 2577);Result = (EIF_INTEGER_32) (((GdkEventConfigure *)arg1)->height);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_configure_struct_width */
EIF_INTEGER_32 F175_2498 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_configure_struct_width", 174, Current, 0, 1, 2578);Result = (EIF_INTEGER_32) (((GdkEventConfigure *)arg1)->width);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_setting_struct_name */
EIF_POINTER F175_2499 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_setting_struct_name", 174, Current, 0, 1, 2579);Result = (EIF_POINTER) (((GdkEventSetting *)arg1)->name);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_crossing_struct_mode */
EIF_INTEGER_32 F175_2501 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_crossing_struct_mode", 174, Current, 0, 1, 2581);Result = (EIF_INTEGER_32) (((GdkEventCrossing *)arg1)->mode);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_key_struct_keyval */
EIF_NATURAL_32 F175_2509 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_key_struct_keyval", 174, Current, 0, 1, 2589);Result = (EIF_NATURAL_32) (((GdkEventKey *)arg1)->keyval);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_key_struct_state */
EIF_NATURAL_32 F175_2510 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_key_struct_state", 174, Current, 0, 1, 2590);Result = (EIF_NATURAL_32) (((GdkEventKey *)arg1)->state);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_key_struct_type */
EIF_INTEGER_32 F175_2511 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_key_struct_type", 174, Current, 0, 1, 2591);Result = (EIF_INTEGER_32) (((GdkEventKey *)arg1)->type);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_motion_struct_is_hint */
EIF_INTEGER_32 F175_2512 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_motion_struct_is_hint", 174, Current, 0, 1, 2592);Result = (EIF_INTEGER_32) (((GdkEventMotion *)arg1)->is_hint);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_motion_struct_state */
EIF_NATURAL_32 F175_2513 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_motion_struct_state", 174, Current, 0, 1, 2593);Result = (EIF_NATURAL_32) (((GdkEventMotion *)arg1)->state);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_motion_struct_window */
EIF_POINTER F175_2514 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_motion_struct_window", 174, Current, 0, 1, 2594);Result = (EIF_POINTER) (((GdkEventMotion *)arg1)->window);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_motion_struct_x */
EIF_REAL_64 F175_2515 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_motion_struct_x", 174, Current, 0, 1, 2595);Result = (EIF_REAL_64) (((GdkEventMotion *)arg1)->x);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_motion_struct_x_root */
EIF_REAL_64 F175_2516 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_motion_struct_x_root", 174, Current, 0, 1, 2596);Result = (EIF_REAL_64) (((GdkEventMotion *)arg1)->x_root);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_motion_struct_y */
EIF_REAL_64 F175_2517 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_motion_struct_y", 174, Current, 0, 1, 2597);Result = (EIF_REAL_64) (((GdkEventMotion *)arg1)->y);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_motion_struct_y_root */
EIF_REAL_64 F175_2518 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_motion_struct_y_root", 174, Current, 0, 1, 2598);Result = (EIF_REAL_64) (((GdkEventMotion *)arg1)->y_root);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_dnd_struct_context */
EIF_POINTER F175_2519 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_dnd_struct_context", 174, Current, 0, 1, 2599);Result = (EIF_POINTER) (((GdkEventDND *)arg1)->context);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_dnd_struct_time */
EIF_NATURAL_32 F175_2520 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_dnd_struct_time", 174, Current, 0, 1, 2600);Result = (EIF_NATURAL_32) (((GdkEventDND *)arg1)->time);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_event_scroll_struct_scroll_direction */
EIF_INTEGER_32 F175_2521 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_event_scroll_struct_scroll_direction", 174, Current, 0, 1, 2601);Result = (EIF_INTEGER_32) (((GdkEventScroll *)arg1)->direction);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.c_gdk_rgba_struct_allocate */
EIF_POINTER F175_2527 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("c_gdk_rgba_struct_allocate", 174, Current, 0, 0, 2607);
	Result = (EIF_POINTER) calloc (sizeof(GdkRGBA), 1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.rgba_free */
void F175_2528 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("rgba_free", 174, Current, 0, 1, 2608);gdk_rgba_free((GdkRGBA*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.rgba_struct_red */
EIF_REAL_64 F175_2539 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("rgba_struct_red", 174, Current, 0, 1, 2619);Result = (EIF_REAL_64) (((GdkRGBA *)arg1)->red);
	
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.rgba_struct_green */
EIF_REAL_64 F175_2540 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("rgba_struct_green", 174, Current, 0, 1, 2620);Result = (EIF_REAL_64) (((GdkRGBA *)arg1)->green);
	
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.rgba_struct_blue */
EIF_REAL_64 F175_2541 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("rgba_struct_blue", 174, Current, 0, 1, 2621);Result = (EIF_REAL_64) (((GdkRGBA *)arg1)->blue);
	
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.rgba_struct_alpha */
EIF_REAL_64 F175_2542 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("rgba_struct_alpha", 174, Current, 0, 1, 2622);Result = (EIF_REAL_64) (((GdkRGBA *)arg1)->alpha);
	
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_colorspace_rgb_enum */
EIF_INTEGER_32 F175_2545 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_colorspace_rgb_enum", 174, Current, 0, 0, 2625);
	Result = inline_F175_2545 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.sizeof_gtype */
EIF_INTEGER_32 F175_2546 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("sizeof_gtype", 174, Current, 0, 0, 2626);
	Result = (EIF_INTEGER_32) sizeof(GType);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.add_g_type_string */
void F175_2548 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("add_g_type_string", 174, Current, 0, 2, 2628);
	inline_F175_2548 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.add_gdk_type_pixbuf */
void F175_2549 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("add_gdk_type_pixbuf", 174, Current, 0, 2, 2629);
	inline_F175_2549 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_pixbuf_scale_simple */
EIF_POINTER F175_2550 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_pixbuf_scale_simple", 174, Current, 0, 4, 2630);
	Result = inline_F175_2550 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2, (EIF_INTEGER_32) arg3, (EIF_INTEGER_32) arg4);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_pixbuf_get_has_alpha */
EIF_BOOLEAN F175_2555 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_pixbuf_get_has_alpha", 174, Current, 0, 1, 2635);Result = (EIF_BOOLEAN) EIF_TEST(gdk_pixbuf_get_has_alpha((GdkPixbuf*) arg1));
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_pixbuf_get_from_surface */
EIF_POINTER F175_2559 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_pixbuf_get_from_surface", 174, Current, 0, 5, 2639);
	Result = inline_F175_2559 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2, (EIF_INTEGER_32) arg3, (EIF_INTEGER_32) arg4, (EIF_INTEGER_32) arg5);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_pixbuf_get_from_window */
EIF_POINTER F175_2560 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_pixbuf_get_from_window", 174, Current, 0, 5, 2640);
	Result = inline_F175_2560 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2, (EIF_INTEGER_32) arg3, (EIF_INTEGER_32) arg4, (EIF_INTEGER_32) arg5);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_pixbuf_copy */
EIF_POINTER F175_2562 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_pixbuf_copy", 174, Current, 0, 1, 2642);
	Result = inline_F175_2562 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_pixbuf_get_width */
EIF_INTEGER_32 F175_2563 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_pixbuf_get_width", 174, Current, 0, 1, 2643);
	Result = inline_F175_2563 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_pixbuf_get_height */
EIF_INTEGER_32 F175_2564 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_pixbuf_get_height", 174, Current, 0, 1, 2644);
	Result = inline_F175_2564 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_pixbuf_new_from_file */
EIF_POINTER F175_2568 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER* arg2)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_pixbuf_new_from_file", 174, Current, 0, 2, 2648);
	Result = inline_F175_2568 ((EIF_POINTER) arg1, (EIF_POINTER*) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_pixbuf_new_from_xpm_data */
EIF_POINTER F175_2570 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_pixbuf_new_from_xpm_data", 174, Current, 0, 1, 2650);
	Result = inline_F175_2570 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_pixbuf_new */
EIF_POINTER F175_2572 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_pixbuf_new", 174, Current, 0, 5, 2652);
	Result = inline_F175_2572 ((EIF_INTEGER_32) arg1, (EIF_BOOLEAN) arg2, (EIF_INTEGER_32) arg3, (EIF_INTEGER_32) arg4, (EIF_INTEGER_32) arg5);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_pixbuf_fill */
void F175_2574 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_pixbuf_fill", 174, Current, 0, 2, 2654);
	inline_F175_2574 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_pixbuf_add_alpha */
EIF_POINTER F175_2575 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2, EIF_NATURAL_8 arg3, EIF_NATURAL_8 arg4, EIF_NATURAL_8 arg5)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_pixbuf_add_alpha", 174, Current, 0, 5, 2655);Result = (EIF_POINTER) gdk_pixbuf_add_alpha((GdkPixbuf*) arg1, (gboolean) arg2, (guchar) arg3, (guchar) arg4, (guchar) arg5);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_screen_get_resolution */
EIF_INTEGER_32 F175_2576 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_screen_get_resolution", 174, Current, 0, 1, 2656);
	Result = inline_F175_2576 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_screen_is_composited */
EIF_BOOLEAN F175_2577 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_screen_is_composited", 174, Current, 0, 1, 2657);
	Result = EIF_TEST(inline_F175_2577 ((EIF_POINTER) arg1));
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_screen_get_system_visual */
EIF_POINTER F175_2578 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_screen_get_system_visual", 174, Current, 0, 1, 2658);
	Result = inline_F175_2578 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_screen_get_rgba_visual */
EIF_POINTER F175_2579 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_screen_get_rgba_visual", 174, Current, 0, 1, 2659);
	Result = inline_F175_2579 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_screen_get_default */
EIF_POINTER F175_2581 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_screen_get_default", 174, Current, 0, 0, 2661);
	Result = inline_F175_2581 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_set_show_events */
void F175_2582 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_set_show_events", 174, Current, 0, 1, 2662);gdk_set_show_events((gboolean) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_screen_get_root_window */
EIF_POINTER F175_2583 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_screen_get_root_window", 174, Current, 0, 1, 2663);
	Result = inline_F175_2583 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_get_default_root_window */
EIF_POINTER F175_2584 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_get_default_root_window", 174, Current, 0, 0, 2664);
	Result = inline_F175_2584 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.c_gdk_geometry_struct_allocate */
EIF_POINTER F175_2587 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("c_gdk_geometry_struct_allocate", 174, Current, 0, 0, 2667);
	Result = (EIF_POINTER) calloc (sizeof(GdkGeometry), 1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.set_gdk_geometry_struct_max_height */
void F175_2592 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_gdk_geometry_struct_max_height", 174, Current, 0, 2, 2672);(((GdkGeometry *)arg1)->max_height = (gint)(arg2));
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.set_gdk_geometry_struct_max_width */
void F175_2593 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_gdk_geometry_struct_max_width", 174, Current, 0, 2, 2673);(((GdkGeometry *)arg1)->max_width = (gint)(arg2));
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.set_gdk_geometry_struct_min_height */
void F175_2595 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_gdk_geometry_struct_min_height", 174, Current, 0, 2, 2675);(((GdkGeometry *)arg1)->min_height = (gint)(arg2));
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.set_gdk_geometry_struct_min_width */
void F175_2596 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_gdk_geometry_struct_min_width", 174, Current, 0, 2, 2676);(((GdkGeometry *)arg1)->min_width = (gint)(arg2));
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_rectangle_struct_height */
EIF_INTEGER_32 F175_2600 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_rectangle_struct_height", 174, Current, 0, 1, 2680);Result = (EIF_INTEGER_32) (((GdkRectangle *)arg1)->height);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_rectangle_struct_width */
EIF_INTEGER_32 F175_2601 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_rectangle_struct_width", 174, Current, 0, 1, 2681);Result = (EIF_INTEGER_32) (((GdkRectangle *)arg1)->width);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_rectangle_struct_x */
EIF_INTEGER_32 F175_2602 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_rectangle_struct_x", 174, Current, 0, 1, 2682);Result = (EIF_INTEGER_32) (((GdkRectangle *)arg1)->x);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_rectangle_struct_y */
EIF_INTEGER_32 F175_2603 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_rectangle_struct_y", 174, Current, 0, 1, 2683);Result = (EIF_INTEGER_32) (((GdkRectangle *)arg1)->y);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.c_gdk_rectangle_struct_allocate */
EIF_POINTER F175_2604 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("c_gdk_rectangle_struct_allocate", 174, Current, 0, 0, 2684);
	Result = (EIF_POINTER) calloc (sizeof(GdkRectangle), 1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_cursor_new_for_display */
EIF_POINTER F175_2606 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_cursor_new_for_display", 174, Current, 0, 2, 2686);Result = (EIF_POINTER) gdk_cursor_new_for_display((GdkDisplay *) arg1, (GdkCursorType) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_cursor_new_from_pixbuf */
EIF_POINTER F175_2607 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_cursor_new_from_pixbuf", 174, Current, 0, 4, 2687);Result = (EIF_POINTER) gdk_cursor_new_from_pixbuf((GdkDisplay*) arg1, (GdkPixbuf*) arg2, (gint) arg3, (gint) arg4);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_selection_property_get */
EIF_INTEGER_32 F175_2608 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER* arg2, EIF_POINTER arg3, EIF_INTEGER_32* arg4)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_selection_property_get", 174, Current, 0, 4, 2688);Result = (EIF_INTEGER_32) gdk_selection_property_get((GdkWindow*) arg1, (guchar**) arg2, (GdkAtom*) arg3, (gint*) arg4);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_drag_get_selection */
EIF_POINTER F175_2609 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_drag_get_selection", 174, Current, 0, 1, 2689);Result = (EIF_POINTER) gdk_drag_get_selection((GdkDragContext*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_drag_context_get_source_window */
EIF_POINTER F175_2610 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_drag_context_get_source_window", 174, Current, 0, 1, 2690);Result = (EIF_POINTER) gdk_drag_context_get_source_window((GdkDragContext*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_drag_context_get_dest_window */
EIF_POINTER F175_2611 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_drag_context_get_dest_window", 174, Current, 0, 1, 2691);Result = (EIF_POINTER) gdk_drag_context_get_dest_window((GdkDragContext*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_drag_context_list_targets */
EIF_POINTER F175_2612 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_drag_context_list_targets", 174, Current, 0, 1, 2692);Result = (EIF_POINTER) gdk_drag_context_list_targets((GdkDragContext*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_selection_convert */
void F175_2613 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_NATURAL_32 arg4)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_selection_convert", 174, Current, 0, 4, 2693);gdk_selection_convert((GdkWindow*) arg1, (GdkAtom) arg2, (GdkAtom) arg3, (guint32) arg4);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_drop_finish */
void F175_2614 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2, EIF_NATURAL_32 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_drop_finish", 174, Current, 0, 3, 2694);gdk_drop_finish((GdkDragContext*) arg1, (gboolean) arg2, (guint32) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK}.gdk_atom_name */
EIF_POINTER F175_2617 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_atom_name", 174, Current, 0, 1, 2697);Result = (EIF_POINTER) gdk_atom_name((GdkAtom) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_control_mask_enum */
EIF_NATURAL_32 F175_2626 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_control_mask_enum", 174, Current, 0, 0, 2706);
	Result = (EIF_NATURAL_32) GDK_CONTROL_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_mod1_mask_enum */
EIF_NATURAL_32 F175_2627 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_mod1_mask_enum", 174, Current, 0, 0, 2707);
	Result = (EIF_NATURAL_32) GDK_MOD1_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_shift_mask_enum */
EIF_NATURAL_32 F175_2628 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_shift_mask_enum", 174, Current, 0, 0, 2708);
	Result = (EIF_NATURAL_32) GDK_SHIFT_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_button_press_enum */
EIF_INTEGER_32 F175_2630 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_button_press_enum", 174, Current, 0, 0, 2710);
	Result = (EIF_INTEGER_32) GDK_BUTTON_PRESS;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_2button_press_enum */
EIF_INTEGER_32 F175_2631 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_2button_press_enum", 174, Current, 0, 0, 2711);
	Result = (EIF_INTEGER_32) GDK_2BUTTON_PRESS;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_3button_press_enum */
EIF_INTEGER_32 F175_2632 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_3button_press_enum", 174, Current, 0, 0, 2712);
	Result = (EIF_INTEGER_32) GDK_3BUTTON_PRESS;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_button_release_enum */
EIF_INTEGER_32 F175_2633 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_button_release_enum", 174, Current, 0, 0, 2713);
	Result = (EIF_INTEGER_32) GDK_BUTTON_RELEASE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_exposure_mask_enum */
EIF_INTEGER_32 F175_2634 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_exposure_mask_enum", 174, Current, 0, 0, 2714);
	Result = (EIF_INTEGER_32) GDK_EXPOSURE_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_pointer_motion_mask_enum */
EIF_INTEGER_32 F175_2635 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_pointer_motion_mask_enum", 174, Current, 0, 0, 2715);
	Result = (EIF_INTEGER_32) GDK_POINTER_MOTION_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_pointer_motion_hint_mask_enum */
EIF_INTEGER_32 F175_2636 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_pointer_motion_hint_mask_enum", 174, Current, 0, 0, 2716);
	Result = (EIF_INTEGER_32) GDK_POINTER_MOTION_HINT_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_button_press_mask_enum */
EIF_INTEGER_32 F175_2640 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_button_press_mask_enum", 174, Current, 0, 0, 2720);
	Result = (EIF_INTEGER_32) GDK_BUTTON_PRESS_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_button_release_mask_enum */
EIF_INTEGER_32 F175_2641 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_button_release_mask_enum", 174, Current, 0, 0, 2721);
	Result = (EIF_INTEGER_32) GDK_BUTTON_RELEASE_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_key_press_enum */
EIF_INTEGER_32 F175_2646 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_key_press_enum", 174, Current, 0, 0, 2726);
	Result = (EIF_INTEGER_32) GDK_KEY_PRESS;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_key_press_mask_enum */
EIF_INTEGER_32 F175_2648 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_key_press_mask_enum", 174, Current, 0, 0, 2728);
	Result = (EIF_INTEGER_32) GDK_KEY_PRESS_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_key_release_mask_enum */
EIF_INTEGER_32 F175_2649 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_key_release_mask_enum", 174, Current, 0, 0, 2729);
	Result = (EIF_INTEGER_32) GDK_KEY_RELEASE_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_enter_notify_mask_enum */
EIF_INTEGER_32 F175_2650 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_enter_notify_mask_enum", 174, Current, 0, 0, 2730);
	Result = (EIF_INTEGER_32) GDK_ENTER_NOTIFY_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_leave_notify_mask_enum */
EIF_INTEGER_32 F175_2651 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_leave_notify_mask_enum", 174, Current, 0, 0, 2731);
	Result = (EIF_INTEGER_32) GDK_LEAVE_NOTIFY_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_focus_change_mask_enum */
EIF_INTEGER_32 F175_2652 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_focus_change_mask_enum", 174, Current, 0, 0, 2732);
	Result = (EIF_INTEGER_32) GDK_FOCUS_CHANGE_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_visibility_notify_mask_enum */
EIF_INTEGER_32 F175_2653 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_visibility_notify_mask_enum", 174, Current, 0, 0, 2733);
	Result = (EIF_INTEGER_32) GDK_VISIBILITY_NOTIFY_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_structure_mask_enum */
EIF_INTEGER_32 F175_2654 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_structure_mask_enum", 174, Current, 0, 0, 2734);
	Result = (EIF_INTEGER_32) GDK_STRUCTURE_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_scroll_mask_enum */
EIF_INTEGER_32 F175_2659 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_scroll_mask_enum", 174, Current, 0, 0, 2739);
	Result = (EIF_INTEGER_32) GDK_SCROLL_MASK;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_decor_all_enum */
EIF_INTEGER_32 F175_2666 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_decor_all_enum", 174, Current, 0, 0, 2746);
	Result = (EIF_INTEGER_32) GDK_DECOR_ALL;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_decor_border_enum */
EIF_INTEGER_32 F175_2667 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_decor_border_enum", 174, Current, 0, 0, 2747);
	Result = (EIF_INTEGER_32) GDK_DECOR_BORDER;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_hint_max_size_enum */
EIF_INTEGER_32 F175_2670 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_hint_max_size_enum", 174, Current, 0, 0, 2750);
	Result = (EIF_INTEGER_32) GDK_HINT_MAX_SIZE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_hint_min_size_enum */
EIF_INTEGER_32 F175_2671 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_hint_min_size_enum", 174, Current, 0, 0, 2751);
	Result = (EIF_INTEGER_32) GDK_HINT_MIN_SIZE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_func_close_enum */
EIF_INTEGER_32 F175_2672 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_func_close_enum", 174, Current, 0, 0, 2752);
	Result = (EIF_INTEGER_32) GDK_FUNC_CLOSE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_func_move_enum */
EIF_INTEGER_32 F175_2673 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_func_move_enum", 174, Current, 0, 0, 2753);
	Result = (EIF_INTEGER_32) GDK_FUNC_MOVE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_func_resize_enum */
EIF_INTEGER_32 F175_2674 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_func_resize_enum", 174, Current, 0, 0, 2754);
	Result = (EIF_INTEGER_32) GDK_FUNC_RESIZE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_window_state_iconified_enum */
EIF_INTEGER_32 F175_2679 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_window_state_iconified_enum", 174, Current, 0, 0, 2759);
	Result = (EIF_INTEGER_32) GDK_WINDOW_STATE_ICONIFIED;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_window_state_maximized_enum */
EIF_INTEGER_32 F175_2680 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_window_state_maximized_enum", 174, Current, 0, 0, 2760);
	Result = (EIF_INTEGER_32) GDK_WINDOW_STATE_MAXIMIZED;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_scroll_up_enum */
EIF_INTEGER_32 F175_2685 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_scroll_up_enum", 174, Current, 0, 0, 2765);
	Result = (EIF_INTEGER_32) GDK_SCROLL_UP;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_interp_bilinear */
EIF_INTEGER_32 F175_2688 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_interp_bilinear", 174, Current, 0, 0, 2768);
	Result = (EIF_INTEGER_32) GDK_INTERP_BILINEAR;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK}.gdk_interp_nearest */
EIF_INTEGER_32 F175_2690 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_interp_nearest", 174, Current, 0, 0, 2770);
	Result = (EIF_INTEGER_32) GDK_INTERP_NEAREST;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit149 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
