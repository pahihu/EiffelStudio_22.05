
#ifndef _C3_ev132_
#define _C3_ev132_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F156_2243(EIF_REFERENCE);
extern void EIF_Minit132(void);
extern void F916_8909(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
