
#ifndef _C3_ev124_
#define _C3_ev124_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F148_2170_body(EIF_REFERENCE);
extern EIF_REFERENCE F148_2170(EIF_REFERENCE);
static EIF_REFERENCE F148_2173_body(EIF_REFERENCE);
extern EIF_REFERENCE F148_2173(EIF_REFERENCE);
extern void EIF_Minit124(void);
extern void F1241_11242(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
