
#ifndef _C3_ev146_
#define _C3_ev146_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F172_2323(EIF_REFERENCE);
extern void EIF_Minit146(void);
extern void F916_8909(EIF_REFERENCE);
extern long O2300[];

#ifdef __cplusplus
}
#endif

#endif
