/*
 * Code for class CONF_LOCATION_IRON_MAPPING
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co139.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONF_LOCATION_IRON_MAPPING}.make */
void F163_2261 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTEAA("make", 162, Current, 0, 2, 2455);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg2;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {CONF_LOCATION_IRON_MAPPING}.mapped_location */
EIF_REFERENCE F163_2264 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,Current);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTEAA("mapped_location", 162, Current, 2, 1, 2449);
	RTGC;
	RTHOOK(1);
	tb1 = '\01';
	tb2 = '\01';
	tr1 = F1237_11118(RTMS_EX_H("iron:",5,1920711738));
	tb3 = F1240_11224(RTCW(arg1), tr1);
	if (!tb3) {
		tr1 = F1237_11118(RTMS_EX_H("http:",5,1954586682));
		tb3 = F1240_11224(RTCW(arg1), tr1);
		tb2 = tb3;
	}
	if (!tb2) {
		tr1 = F1237_11118(RTMS_EX_H("https:",6,11409978));
		tb2 = F1240_11224(RTCW(arg1), tr1);
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(2);
		loc1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1240_11191(RTCW(loc1), arg1);
		RTHOOK(3);
		F163_2269(Current, loc1);
		RTHOOK(4);
		tr1 = F163_2267(Current);
		tr1 = F508_7277(RTCW(tr1), loc1);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTHOOK(5);
			tr1 = F1304_12658(loc2);
			RTHOOK(6);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) tr1;
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {CONF_LOCATION_IRON_MAPPING}.refresh */
void F163_2266 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("refresh", 162, Current, 1, 0, 2451);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tb1 = F508_7252(loc1);
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(3);
			*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) NULL;
		}
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {CONF_LOCATION_IRON_MAPPING}.iron_api */
EIF_REFERENCE F163_2267 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTEAA("iron_api", 162, Current, 2, 0, 2452);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	RTHOOK(2);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tb2 = F508_7252(RTCW(loc1));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(3);
		loc1 = (EIF_REFERENCE) NULL;
	}
	RTHOOK(4);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(5);
		loc2 = RTLNS(eif_new_type(21, 0x00).id, 21, _OBJSIZ_0_0_0_0_0_0_0_0_);
		RTHOOK(6);
		loc1 = F22_173(RTCW(loc2), *(EIF_REFERENCE *)(Current), *(EIF_REFERENCE *)(Current + _REFACS_1_));
		RTHOOK(7);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(8);
	RTHOOK(9);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) loc1;
}

/* {CONF_LOCATION_IRON_MAPPING}.update_location_to_uri */
void F163_2269 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("update_location_to_uri", 162, Current, 0, 1, 2454);
	RTGC;
	RTHOOK(1);
	tr1 = RTMS32_EX_H("\\\000\000\000",1,92);
	tr2 = RTMS32_EX_H("/\000\000\000",1,47);
	F1242_11281(RTCW(arg1), tr1, tr2);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit139 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
