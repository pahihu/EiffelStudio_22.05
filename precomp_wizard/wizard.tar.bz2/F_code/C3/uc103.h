
#ifndef _C3_uc103_
#define _C3_uc103_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F125_1969_body(EIF_REFERENCE);
extern EIF_REFERENCE F125_1969(EIF_REFERENCE);
extern void EIF_Minit103(void);

#ifdef __cplusplus
}
#endif

#endif
