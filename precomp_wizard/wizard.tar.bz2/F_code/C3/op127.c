/*
 * Code for class OPTION_ROUTINES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "op127.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {OPTION_ROUTINES}.is_option_caseless */
EIF_BOOLEAN F151_2206 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_option_caseless", 150, Current, 0, 1, 2401);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 1L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L));
}

/* {OPTION_ROUTINES}.is_option_multiline */
EIF_BOOLEAN F151_2207 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_option_multiline", 150, Current, 0, 1, 2402);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 2L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L));
}

/* {OPTION_ROUTINES}.is_option_dotall */
EIF_BOOLEAN F151_2208 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_option_dotall", 150, Current, 0, 1, 2403);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 4L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L));
}

/* {OPTION_ROUTINES}.is_option_undef */
EIF_BOOLEAN F151_2211 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_option_undef", 150, Current, 0, 1, 2406);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 32L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L));
}

/* {OPTION_ROUTINES}.set_option_caseless */
EIF_INTEGER_32 F151_2213 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_option_caseless", 150, Current, 0, 1, 2408);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 1L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L));
	} else {
		RTHOOK(4);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) arg1;
	}/* NOTREACHED */
	
}

/* {OPTION_ROUTINES}.unset_option_caseless */
EIF_INTEGER_32 F151_2214 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("unset_option_caseless", 150, Current, 0, 1, 2409);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 1L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L));
	} else {
		RTHOOK(4);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) arg1;
	}/* NOTREACHED */
	
}

/* {OPTION_ROUTINES}.set_option_multiline */
EIF_INTEGER_32 F151_2215 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_option_multiline", 150, Current, 0, 1, 2410);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 2L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 2L));
	} else {
		RTHOOK(4);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) arg1;
	}/* NOTREACHED */
	
}

/* {OPTION_ROUTINES}.unset_option_multiline */
EIF_INTEGER_32 F151_2216 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("unset_option_multiline", 150, Current, 0, 1, 2411);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 2L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 2L));
	} else {
		RTHOOK(4);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) arg1;
	}/* NOTREACHED */
	
}

/* {OPTION_ROUTINES}.set_option_dotall */
EIF_INTEGER_32 F151_2217 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_option_dotall", 150, Current, 0, 1, 2412);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 4L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 4L));
	} else {
		RTHOOK(4);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) arg1;
	}/* NOTREACHED */
	
}

/* {OPTION_ROUTINES}.unset_option_dotall */
EIF_INTEGER_32 F151_2218 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("unset_option_dotall", 150, Current, 0, 1, 2413);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 4L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 4L));
	} else {
		RTHOOK(4);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) arg1;
	}/* NOTREACHED */
	
}

/* {OPTION_ROUTINES}.to_option_ims */
EIF_INTEGER_32 F151_2225 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("to_option_ims", 150, Current, 0, 1, 2420);
	RTGC;
	RTHOOK(1);
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(2);
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 1L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(3);
		Result += ((EIF_INTEGER_32) 1L);
	}
	RTHOOK(4);
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 2L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(5);
		Result += ((EIF_INTEGER_32) 2L);
	}
	RTHOOK(6);
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 / ((EIF_INTEGER_32) 4L)) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(7);
		RTHOOK(8);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 4L));
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit127 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
