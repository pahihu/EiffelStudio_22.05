
#ifndef _C3_im133_
#define _C3_im133_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F157_2245_body(EIF_REFERENCE);
extern EIF_REFERENCE F157_2245(EIF_REFERENCE);
extern void EIF_Minit133(void);

#ifdef __cplusplus
}
#endif

#endif
