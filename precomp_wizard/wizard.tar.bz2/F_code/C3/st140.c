/*
 * Code for class STRING_EXPANDER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "st140.h"
#include <ctype.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {STRING_EXPANDER}.expand_string_32 */
EIF_REFERENCE F164_2271 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_CHARACTER_32 loc2 = (EIF_CHARACTER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(9);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,loc10);
	RTLR(3,Current);
	RTLR(4,loc5);
	RTLR(5,tr1);
	RTLR(6,loc6);
	RTLR(7,loc11);
	RTLR(8,loc12);
	RTLIU(9);
	
	RTEAA("expand_string_32", 163, Current, 12, 2, 2458);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9640[Dtype(RTCW(arg1))-1240])(arg1);
	F1240_11189(RTCW(Result), ti4_1);
	RTHOOK(2);
	{
		static EIF_TYPE_INDEX typarr0[] = {805,1241,1241,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc10 = RTLNS(typres0.id, 805, _OBJSIZ_7_3_0_7_0_0_0_0_);
	}
	F806_8436(RTCW(loc10), ((EIF_INTEGER_32) 13L));
	RTHOOK(3);
	loc5 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1240_11189(RTCW(loc5), ((EIF_INTEGER_32) 128L));
	RTHOOK(4);
	loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(5);
	loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9640[Dtype(RTCW(arg1))-1240])(arg1);
	for (;;) {
		RTHOOK(6);
		if ((EIF_BOOLEAN) (loc4 > loc3)) break;
		RTHOOK(7);
		loc1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R9604[Dtype(RTCW(arg1))-1240])(arg1, loc4);
		RTHOOK(8);
		tb1 = '\0';
		if ((EIF_BOOLEAN) !loc8) {
			tw1 = (EIF_CHARACTER_32) F164_2274(Current);
			tb1 = (EIF_BOOLEAN)(loc1 == tw1);
		}
		if (tb1) {
			RTHOOK(9);
			loc4++;
			RTHOOK(10);
			if ((EIF_BOOLEAN) (loc4 <= loc3)) {
				RTHOOK(11);
				loc2 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R9604[Dtype(RTCW(arg1))-1240])(arg1, loc4);
				RTHOOK(12);
				tb1 = '\01';
				tb2 = '\01';
				tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = loc2;
				tb3 = F1188_10889(RTCW(tr1));
				if (!tb3) {
					tb2 = (EIF_BOOLEAN)(loc2 == (EIF_CHARACTER_32) 123U);
				}
				if (!tb2) {
					tb1 = (EIF_BOOLEAN)(loc2 == (EIF_CHARACTER_32) 40U);
				}
				if (tb1) {
					RTHOOK(13);
					tb1 = F730_8337(RTCW(loc5));
					if ((EIF_BOOLEAN) !tb1) {
						RTHOOK(14);
						F1242_11304(RTCW(Result), loc5);
						RTHOOK(15);
						F1242_11333(RTCW(loc5));
					}
					RTHOOK(16);
					tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
					*(EIF_CHARACTER_32 *)tr1 = loc2;
					loc9 = F1188_10889(RTCW(tr1));
					loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc9;
					RTHOOK(17);
					if ((EIF_BOOLEAN) !loc9) {
						RTHOOK(18);
						F1242_11317(RTCW(loc5), loc2);
					}
					RTHOOK(19);
					loc4++;
					RTHOOK(20);
					loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					for (;;) {
						RTHOOK(21);
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc7 || (EIF_BOOLEAN) (loc4 > loc3))) break;
						RTHOOK(22);
						loc1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R9604[Dtype(RTCW(arg1))-1240])(arg1, loc4);
						RTHOOK(23);
						if (loc9) {
							RTHOOK(24);
							loc7 = '\01';
							tb1 = '\0';
							tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '{';
							if ((EIF_BOOLEAN)(loc2 == tw1)) {
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '}';
								tb1 = (EIF_BOOLEAN)(loc1 == tw1);
							}
							if (!tb1) {
								tb1 = '\0';
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '(';
								if ((EIF_BOOLEAN)(loc2 == tw1)) {
									tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ')';
									tb1 = (EIF_BOOLEAN)(loc1 == tw1);
								}
								loc7 = tb1;
							}
							loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc7;
						} else {
							RTHOOK(25);
							loc7 = '\01';
							tb1 = '\01';
							tr1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_0_0_0_1_0_0_0_0_);
							*(EIF_CHARACTER_32 *)tr1 = loc1;
							tb2 = F1188_10889(RTCW(tr1));
							if (!tb2) {
								tb2 = EIF_TEST(isdigit(loc1));
								tb1 = tb2;
							}
							if (!tb1) {
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
								loc7 = (EIF_BOOLEAN)(loc1 == tw1);
							}
						}
						RTHOOK(26);
						if (loc7) {
							RTHOOK(27);
							F1242_11317(RTCW(loc5), loc1);
							RTHOOK(28);
							loc4++;
						} else {
							RTHOOK(29);
							if ((EIF_BOOLEAN) !loc9) {
								RTHOOK(30);
								loc4--;
							}
						}
					}
					RTHOOK(31);
					tb1 = F730_8337(RTCW(loc5));
					if ((EIF_BOOLEAN) !tb1) {
						RTHOOK(32);
						loc6 = (EIF_REFERENCE) loc5;
						RTHOOK(33);
						tb1 = '\0';
						tb2 = F806_8444(RTCW(loc10), loc6);
						if (tb2) {
							tr1 = F806_8442(RTCW(loc10), loc6);
							loc11 = tr1;
							tb1 = EIF_TEST(loc11);
						}
						if (tb1) {
							RTHOOK(34);
							F1242_11304(RTCW(Result), loc11);
						} else {
							RTHOOK(35);
							tr1 = F506_7240(Current, loc6);
							loc12 = tr1;
							if (EIF_TEST(loc12)) {
								RTHOOK(36);
								F1242_11304(RTCW(Result), loc12);
								RTHOOK(37);
								F806_8482(RTCW(loc10), loc12, loc6);
							} else {
								RTHOOK(38);
								if (arg2) {
									RTHOOK(39);
									tw1 = (EIF_CHARACTER_32) F164_2274(Current);
									F1242_11317(RTCW(Result), tw1);
									RTHOOK(40);
									tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '{';
									F1242_11317(RTCW(Result), tw1);
									RTHOOK(41);
									F1242_11304(RTCW(Result), loc5);
									RTHOOK(42);
									tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '}';
									F1242_11317(RTCW(Result), tw1);
								}
							}
						}
						RTHOOK(43);
						F1242_11333(RTCW(loc5));
					}
				} else {
					RTHOOK(44);
					F1242_11317(RTCW(loc5), loc2);
				}
			} else {
				RTHOOK(45);
				F1242_11317(RTCW(loc5), loc1);
			}
		} else {
			RTHOOK(46);
			tw1 = (EIF_CHARACTER_32) F164_2275(Current);
			if ((EIF_BOOLEAN)(loc1 == tw1)) {
				RTHOOK(47);
				loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc8;
				RTHOOK(48);
				if ((EIF_BOOLEAN) !loc8) {
					RTHOOK(49);
					F1242_11317(RTCW(loc5), loc1);
				}
			} else {
				RTHOOK(50);
				F1242_11317(RTCW(loc5), loc1);
			}
		}
		RTHOOK(51);
		tw1 = (EIF_CHARACTER_32) F164_2275(Current);
		if ((EIF_BOOLEAN)(loc1 != tw1)) {
			RTHOOK(52);
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
		RTHOOK(53);
		loc4++;
	}
	RTHOOK(54);
	tb1 = F730_8337(RTCW(loc5));
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(55);
		F1242_11304(RTCW(Result), loc5);
	}
	RTHOOK(57);
	RTLE;
	RTEE;
	return Result;
}

/* {STRING_EXPANDER}.id_specifier_char */
EIF_CHARACTER_8 F164_2274 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("id_specifier_char", 163, Current, 0, 0, 2459);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_CHARACTER_8) (EIF_CHARACTER_8) '$';
}

/* {STRING_EXPANDER}.esc_specifier_char */
EIF_CHARACTER_8 F164_2275 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("esc_specifier_char", 163, Current, 0, 0, 2460);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_CHARACTER_8) (EIF_CHARACTER_8) '%';
}

void EIF_Minit140 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
