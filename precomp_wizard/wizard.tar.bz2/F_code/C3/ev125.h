
#ifndef _C3_ev125_
#define _C3_ev125_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F149_2184(EIF_REFERENCE);
extern EIF_REFERENCE F149_2186(EIF_REFERENCE);
extern void EIF_Minit125(void);
extern void F916_8909(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
