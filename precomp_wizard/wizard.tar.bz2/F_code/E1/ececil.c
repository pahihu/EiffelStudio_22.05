#include "eif_eiffel.h"
#include "eif_rout_obj.h"
#include "eaddress.h"
#include "eoffsets.h"

#ifdef __cplusplus
extern "C" {
#endif

	/* DESCRIPTOR_CACHE c_iconv_close */
void _A39_42_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_p);
}

	/* DESCRIPTOR_CACHE c_iconv_close */
void __A39_42_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_one_plural_form */
EIF_INTEGER_32 _A62_50_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_one_plural_form */
EIF_INTEGER_32 __A62_50_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_two_plural_forms_singular_one */
EIF_INTEGER_32 _A62_51_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_two_plural_forms_singular_one */
EIF_INTEGER_32 __A62_51_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_two_plural_forms_singular_one_zero */
EIF_INTEGER_32 _A62_52_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_two_plural_forms_singular_one_zero */
EIF_INTEGER_32 __A62_52_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_zero */
EIF_INTEGER_32 _A62_53_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_zero */
EIF_INTEGER_32 __A62_53_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_one_two */
EIF_INTEGER_32 _A62_54_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_one_two */
EIF_INTEGER_32 __A62_54_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_twelve_to_nineteen */
EIF_INTEGER_32 _A62_55_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_twelve_to_nineteen */
EIF_INTEGER_32 __A62_55_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_slavic */
EIF_INTEGER_32 _A62_56_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_slavic */
EIF_INTEGER_32 __A62_56_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_polish */
EIF_INTEGER_32 _A62_57_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_three_plural_forms_special_polish */
EIF_INTEGER_32 __A62_57_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_PLURAL_TOOLS reduce_four_plural_forms_special_slovenian */
EIF_INTEGER_32 _A62_58_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* I18N_PLURAL_TOOLS reduce_four_plural_forms_special_slovenian */
EIF_INTEGER_32 __A62_58_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* WIZARD_STATE_WINDOW change_entries */
void _A191_106 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_STATE_WINDOW change_entries */
void __A191_106 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_STATE_WINDOW check_wizard_status */
void _A191_89 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_STATE_WINDOW check_wizard_status */
void __A191_89 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_INTERMEDIARY_STATE_WINDOW create_help_context */
EIF_REFERENCE _A192_100 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* WIZARD_INTERMEDIARY_STATE_WINDOW create_help_context */
EIF_REFERENCE __A192_100 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* WIZARD_INITIAL_STATE_WINDOW create_help_context */
EIF_REFERENCE _A193_99 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* WIZARD_INITIAL_STATE_WINDOW create_help_context */
EIF_REFERENCE __A193_99 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* THREAD thr_get_terminated */
EIF_BOOLEAN A253_51 (EIF_REFERENCE Current)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F291_4854)(Current);
}

	/* THREAD thr_main */
void A253_50 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) F291_4853)(Current, arg1);
}

	/* THREAD thr_set_terminated */
void A253_52 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_BOOLEAN)) F291_4855)(Current, arg1);
}

	/* WIZARD_FIRST_STATE on_precompilable_libraries_pointer_motion */
void _A434_136_2_3_4_5_6_7_8 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4, open [2].it_i4, open [3].it_r8, open [4].it_r8, open [5].it_r8, open [6].it_i4, open [7].it_i4, closed [2].it_r);
}

	/* WIZARD_FIRST_STATE on_precompilable_libraries_pointer_motion */
void __A434_136_2_3_4_5_6_7_8 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2, EIF_INTEGER_32 op_3, EIF_REAL_64 op_4, EIF_REAL_64 op_5, EIF_REAL_64 op_6, EIF_INTEGER_32 op_7, EIF_INTEGER_32 op_8)
{
	f_ptr (closed [1].it_r, op_2, op_3, op_4, op_5, op_6, op_7, op_8, closed [2].it_r);
}

	/* WIZARD_FIRST_STATE add_all_items */
void _A434_127 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_FIRST_STATE add_all_items */
void __A434_127 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_FIRST_STATE add_items */
void _A434_128 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_FIRST_STATE add_items */
void __A434_128 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_FIRST_STATE remove_items */
void _A434_130 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_FIRST_STATE remove_items */
void __A434_130 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_FIRST_STATE remove_all_items */
void _A434_129 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_FIRST_STATE remove_all_items */
void __A434_129 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_FIRST_STATE browse */
void _A434_133 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_FIRST_STATE browse */
void __A434_133 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_FIRST_STATE enable_add_b */
void _A434_131_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* WIZARD_FIRST_STATE enable_add_b */
void __A434_131_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* WIZARD_FIRST_STATE enable_remove_b */
void _A434_132_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* WIZARD_FIRST_STATE enable_remove_b */
void __A434_132_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* WIZARD_FIRST_STATE inline-agent#1 of build */
void _A434_145_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F501_20975)(closed [1].it_r, open [1].it_r);
}

	/* WIZARD_FIRST_STATE inline-agent#1 of build */
void __A434_145_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F501_20975)(closed [1].it_r, op_2);
}

	/* WIZARD_FIRST_STATE inline-agent#2 of build */
void _A434_146_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F501_20976)(closed [1].it_r, open [1].it_r);
}

	/* WIZARD_FIRST_STATE inline-agent#2 of build */
void __A434_146_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F501_20976)(closed [1].it_r, op_2);
}

	/* WIZARD_FIRST_STATE inline-agent#3 of build */
void _A434_147_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F501_20977)(closed [1].it_r, open [1].it_r);
}

	/* WIZARD_FIRST_STATE inline-agent#3 of build */
void __A434_147_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F501_20977)(closed [1].it_r, op_2);
}

	/* WIZARD_FIRST_STATE inline-agent#4 of build */
void _A434_148_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F501_20978)(closed [1].it_r, open [1].it_r);
}

	/* WIZARD_FIRST_STATE inline-agent#4 of build */
void __A434_148_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F501_20978)(closed [1].it_r, op_2);
}

	/* CONF_LOAD_PARSE_CALLBACKS create_external_cflag */
void _A470_562_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CONF_LOAD_PARSE_CALLBACKS create_external_cflag */
void __A470_562_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CONF_LOAD_PARSE_CALLBACKS create_external_linker_flag */
void _A470_563_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* CONF_LOAD_PARSE_CALLBACKS create_external_linker_flag */
void __A470_563_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* CONF_LOAD_PARSE_CALLBACKS fake inline-agent#20986#448#406# of on_start_tag_finish */
EIF_REFERENCE _A470_639_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F537_20986)(closed [1].it_r, open [1].it_r);
}

	/* CONF_LOAD_PARSE_CALLBACKS fake inline-agent#20986#448#406# of on_start_tag_finish */
EIF_REFERENCE __A470_639_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F537_20986)(closed [1].it_r, op_2);
}

	/* CONF_LOAD_PARSE_CALLBACKS fake inline-agent#20987#448#407# of on_start_tag_finish */
EIF_REFERENCE _A470_640_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F537_20987)(closed [1].it_r, open [1].it_r);
}

	/* CONF_LOAD_PARSE_CALLBACKS fake inline-agent#20987#448#407# of on_start_tag_finish */
EIF_REFERENCE __A470_640_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F537_20987)(closed [1].it_r, op_2);
}

	/* CONF_LOAD_PARSE_CALLBACKS fake inline-agent#20988#448#405# of on_start_tag_finish */
EIF_REFERENCE _A470_641_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F537_20988)(closed [1].it_r, open [1].it_r);
}

	/* CONF_LOAD_PARSE_CALLBACKS fake inline-agent#20988#448#405# of on_start_tag_finish */
EIF_REFERENCE __A470_641_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) F537_20988)(closed [1].it_r, op_2);
}

	/* MISMATCH_INFORMATION wipe_out */
void A479_98 (EIF_REFERENCE Current)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F806_8490)(Current);
}

	/* MISMATCH_INFORMATION internal_put */
void A479_162 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_POINTER arg2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_POINTER)) F820_8563)(Current, arg1, arg2);
}

	/* MISMATCH_INFORMATION set_string_versions */
void A479_163 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_POINTER)) F820_8564)(Current, arg1, arg2);
}

	/* EV_ACCELERATOR_LIST enable_item_parented */
void _A484_166_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EV_ACCELERATOR_LIST enable_item_parented */
void __A484_166_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* EV_ACCELERATOR_LIST disable_item_parented */
void _A484_167_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EV_ACCELERATOR_LIST disable_item_parented */
void __A484_167_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* EV_MENU_ITEM_SELECT_ACTION_SEQUENCE wrapper */
void _A487_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* EV_MENU_ITEM_SELECT_ACTION_SEQUENCE wrapper */
void __A487_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* EV_DOCKABLE_SOURCE_ACTION_SEQUENCE wrapper */
void _A490_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* EV_DOCKABLE_SOURCE_ACTION_SEQUENCE wrapper */
void __A490_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* EV_MULTI_COLUMN_LIST_ROW_SELECT_ACTION_SEQUENCE wrapper */
void _A492_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* EV_MULTI_COLUMN_LIST_ROW_SELECT_ACTION_SEQUENCE wrapper */
void __A492_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* EV_HEADER_ITEM_ACTION_SEQUENCE wrapper */
void _A493_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* EV_HEADER_ITEM_ACTION_SEQUENCE wrapper */
void __A493_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* EV_KEY_ACTION_SEQUENCE wrapper */
void _A496_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* EV_KEY_ACTION_SEQUENCE wrapper */
void __A496_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* EV_POINTER_MOTION_ACTION_SEQUENCE wrapper */
void _A498_181_2_3_4_5_6_7_8 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4, open [2].it_i4, open [3].it_r8, open [4].it_r8, open [5].it_r8, open [6].it_i4, open [7].it_i4, closed [2].it_r);
}

	/* EV_POINTER_MOTION_ACTION_SEQUENCE wrapper */
void __A498_181_2_3_4_5_6_7_8 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2, EIF_INTEGER_32 op_3, EIF_REAL_64 op_4, EIF_REAL_64 op_5, EIF_REAL_64 op_6, EIF_INTEGER_32 op_7, EIF_INTEGER_32 op_8)
{
	f_ptr (closed [1].it_r, op_2, op_3, op_4, op_5, op_6, op_7, op_8, closed [2].it_r);
}

	/* EV_PND_START_ACTION_SEQUENCE wrapper */
void _A499_181_2_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4, open [2].it_i4, closed [2].it_r);
}

	/* EV_PND_START_ACTION_SEQUENCE wrapper */
void __A499_181_2_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2, EIF_INTEGER_32 op_3)
{
	f_ptr (closed [1].it_r, op_2, op_3, closed [2].it_r);
}

	/* EV_GEOMETRY_ACTION_SEQUENCE wrapper */
void _A500_181_2_3_4_5 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4, open [2].it_i4, open [3].it_i4, open [4].it_i4, closed [2].it_r);
}

	/* EV_GEOMETRY_ACTION_SEQUENCE wrapper */
void __A500_181_2_3_4_5 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2, EIF_INTEGER_32 op_3, EIF_INTEGER_32 op_4, EIF_INTEGER_32 op_5)
{
	f_ptr (closed [1].it_r, op_2, op_3, op_4, op_5, closed [2].it_r);
}

	/* EV_PND_MOTION_ACTION_SEQUENCE wrapper */
void _A501_181_2_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4, open [2].it_i4, open [3].it_r, closed [2].it_r);
}

	/* EV_PND_MOTION_ACTION_SEQUENCE wrapper */
void __A501_181_2_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2, EIF_INTEGER_32 op_3, EIF_REFERENCE op_4)
{
	f_ptr (closed [1].it_r, op_2, op_3, op_4, closed [2].it_r);
}

	/* EV_POINTER_BUTTON_ACTION_SEQUENCE wrapper */
void _A502_181_2_3_4_5_6_7_8_9 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4, open [2].it_i4, open [3].it_i4, open [4].it_r8, open [5].it_r8, open [6].it_r8, open [7].it_i4, open [8].it_i4, closed [2].it_r);
}

	/* EV_POINTER_BUTTON_ACTION_SEQUENCE wrapper */
void __A502_181_2_3_4_5_6_7_8_9 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2, EIF_INTEGER_32 op_3, EIF_INTEGER_32 op_4, EIF_REAL_64 op_5, EIF_REAL_64 op_6, EIF_REAL_64 op_7, EIF_INTEGER_32 op_8, EIF_INTEGER_32 op_9)
{
	f_ptr (closed [1].it_r, op_2, op_3, op_4, op_5, op_6, op_7, op_8, op_9, closed [2].it_r);
}

	/* EV_NOTIFY_ACTION_SEQUENCE wrapper */
void _A503_180 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_NOTIFY_ACTION_SEQUENCE wrapper */
void __A503_180 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_NOTIFY_ACTION_SEQUENCE call */
void _A503_175 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_NOTIFY_ACTION_SEQUENCE call */
void __A503_175 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_MENU_ITEM_IMP on_activate */
void _A965_278 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* EV_MENU_ITEM_IMP on_activate */
void __A965_278 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* HASH_TABLE [G#1, G#2] put */
void _A1193_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* HASH_TABLE [NATURAL_32, G#2] put */
void _A1180_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_n4, closed [3].it_r);
}

	/* HASH_TABLE [G#1, INTEGER_32] put */
void _A1271_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	EIF_REFERENCE arg2 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (3);
	
	RTLR(0,closed [1].it_r);
	RTLR(2,arg2);
	RTLR(1,closed [2].it_r);
	RTLIU(3);
	arg2 = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg2 = closed [3].it_i4;
	f_ptr (closed [1].it_r, closed [2].it_r, arg2);
	RTLE;
}

	/* HASH_TABLE [INTEGER_32, G#2] put */
void _A1361_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (3);
	
	RTLR(0,closed [1].it_r);
	RTLR(2,closed [3].it_r);
	RTLR(1,arg1);
	RTLIU(3);
	arg1 = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg1 = closed [2].it_i4;
	f_ptr (closed [1].it_r, arg1, closed [3].it_r);
	RTLE;
}

	/* HASH_TABLE [INTEGER_32, INTEGER_32] put */
void _A1518_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* HASH_TABLE [INTEGER_32, NATURAL_32] put */
void _A1679_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_NATURAL_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_n4);
}

	/* HASH_TABLE [POINTER, G#2] put */
void _A1695_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p, closed [3].it_r);
}

	/* HASH_TABLE [NATURAL_8, G#2] put */
void _A1702_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_8, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_n1, closed [3].it_r);
}

	/* HASH_TABLE [BOOLEAN, G#2] put */
void _A1734_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_b, closed [3].it_r);
}

	/* HASH_TABLE [G#1, G#2] put */
void __A1193_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* HASH_TABLE [NATURAL_32, G#2] put */
void __A1180_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_n4, closed [3].it_r);
}

	/* HASH_TABLE [G#1, INTEGER_32] put */
void __A1271_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	EIF_REFERENCE arg2 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (3);
	
	RTLR(0,closed [1].it_r);
	RTLR(2,arg2);
	RTLR(1,closed [2].it_r);
	RTLIU(3);
	arg2 = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg2 = closed [3].it_i4;
	f_ptr (closed [1].it_r, closed [2].it_r, arg2);
	RTLE;
}

	/* HASH_TABLE [INTEGER_32, G#2] put */
void __A1361_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (3);
	
	RTLR(0,closed [1].it_r);
	RTLR(2,closed [3].it_r);
	RTLR(1,arg1);
	RTLIU(3);
	arg1 = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg1 = closed [2].it_i4;
	f_ptr (closed [1].it_r, arg1, closed [3].it_r);
	RTLE;
}

	/* HASH_TABLE [INTEGER_32, INTEGER_32] put */
void __A1518_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* HASH_TABLE [INTEGER_32, NATURAL_32] put */
void __A1679_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_NATURAL_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_n4);
}

	/* HASH_TABLE [POINTER, G#2] put */
void __A1695_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_p, closed [3].it_r);
}

	/* HASH_TABLE [NATURAL_8, G#2] put */
void __A1702_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_8, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_n1, closed [3].it_r);
}

	/* HASH_TABLE [BOOLEAN, G#2] put */
void __A1734_90 ( void(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_b, closed [3].it_r);
}

	/* HASH_TABLE [G#1, G#2] remove */
void _A1193_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* HASH_TABLE [NATURAL_32, G#2] remove */
void _A1180_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* HASH_TABLE [G#1, INTEGER_32] remove */
void _A1271_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (2);
	
	RTLR(0,closed [1].it_r);
	RTLR(1,arg1);
	RTLIU(2);
	arg1 = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg1 = closed [2].it_i4;
	f_ptr (closed [1].it_r, arg1);
	RTLE;
}

	/* HASH_TABLE [INTEGER_32, G#2] remove */
void _A1361_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* HASH_TABLE [INTEGER_32, INTEGER_32] remove */
void _A1518_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4);
}

	/* HASH_TABLE [INTEGER_32, NATURAL_32] remove */
void _A1679_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_n4);
}

	/* HASH_TABLE [POINTER, G#2] remove */
void _A1695_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* HASH_TABLE [NATURAL_8, G#2] remove */
void _A1702_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* HASH_TABLE [BOOLEAN, G#2] remove */
void _A1734_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* HASH_TABLE [G#1, G#2] remove */
void __A1193_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* HASH_TABLE [NATURAL_32, G#2] remove */
void __A1180_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* HASH_TABLE [G#1, INTEGER_32] remove */
void __A1271_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (2);
	
	RTLR(0,closed [1].it_r);
	RTLR(1,arg1);
	RTLIU(2);
	arg1 = RTLNS(eif_new_type(1486, 0x00).id, 1486, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg1 = closed [2].it_i4;
	f_ptr (closed [1].it_r, arg1);
	RTLE;
}

	/* HASH_TABLE [INTEGER_32, G#2] remove */
void __A1361_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* HASH_TABLE [INTEGER_32, INTEGER_32] remove */
void __A1518_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4);
}

	/* HASH_TABLE [INTEGER_32, NATURAL_32] remove */
void __A1679_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_n4);
}

	/* HASH_TABLE [POINTER, G#2] remove */
void __A1695_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* HASH_TABLE [NATURAL_8, G#2] remove */
void __A1702_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* HASH_TABLE [BOOLEAN, G#2] remove */
void __A1734_96 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_GTK_CALLBACK_MARSHAL marshal */
void A576_408 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_POINTER arg3, EIF_POINTER arg4)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_POINTER, EIF_POINTER)) F1156_10584)(Current, arg1, arg2, arg3, arg4);
}

	/* EV_GTK_CALLBACK_MARSHAL on_timeout_intermediary */
void _A576_140 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL on_timeout_intermediary */
void __A576_140 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL gtk_dialog_response_event */
EIF_POINTER _A576_339_3 ( EIF_POINTER(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, closed [2].it_p, open [1].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL gtk_dialog_response_event */
EIF_POINTER __A576_339_3 ( EIF_POINTER(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_3)
{
	return f_ptr (closed [1].it_r, closed [2].it_p, op_3);
}

	/* EV_GTK_CALLBACK_MARSHAL on_widget_mapped_signal_intermediary */
void _A576_326 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_widget_mapped_signal_intermediary */
void __A576_326 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_widget_unmapped_signal_intermediary */
void _A576_327 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_widget_unmapped_signal_intermediary */
void __A576_327 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_widget_hide_signal_intermediary */
void _A576_328 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_widget_hide_signal_intermediary */
void __A576_328 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_size_allocate_event */
void _A576_333_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, open [1].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_size_allocate_event */
void __A576_333_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_3)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, op_3);
}

	/* EV_GTK_CALLBACK_MARSHAL on_notebook_page_switch_event */
void _A576_325_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p, open [1].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_notebook_page_switch_event */
void __A576_325_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_3)
{
	f_ptr (closed [1].it_r, closed [2].it_p, op_3);
}

	/* EV_GTK_CALLBACK_MARSHAL on_set_focus_event */
void _A576_334_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, open [1].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_set_focus_event */
void __A576_334_3 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_3)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, op_3);
}

	/* EV_GTK_CALLBACK_MARSHAL tree_row_expansion_change_intermediary */
void _A576_317_4_5 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_BOOLEAN, EIF_INTEGER_32, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_b, open [1].it_i4, open [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL tree_row_expansion_change_intermediary */
void __A576_317_4_5 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_BOOLEAN, EIF_INTEGER_32, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_4, EIF_POINTER op_5)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_b, op_4, op_5);
}

	/* EV_GTK_CALLBACK_MARSHAL on_pnd_deferred_item_parent_selection_change */
void _A576_320 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL on_pnd_deferred_item_parent_selection_change */
void __A576_320 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL mcl_column_resize_callback */
void _A576_315 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL mcl_column_resize_callback */
void __A576_315 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL mcl_column_click_callback */
void _A576_314 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL mcl_column_click_callback */
void __A576_314 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL on_gauge_value_changed_intermediary */
void _A576_332 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_gauge_value_changed_intermediary */
void __A576_332 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL button_select_intermediary */
void _A576_337 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL button_select_intermediary */
void __A576_337 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL text_field_return_intermediary */
void _A576_336 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL text_field_return_intermediary */
void __A576_336 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL on_combo_box_toggle_button_event */
void _A576_321 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL on_combo_box_toggle_button_event */
void __A576_321 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL text_component_change_intermediary */
void _A576_335 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL text_component_change_intermediary */
void __A576_335 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL text_buffer_mark_set_intermediary */
void _A576_316_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, open [1].it_i4, open [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL text_buffer_mark_set_intermediary */
void __A576_316_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_3, EIF_POINTER op_4)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, op_3, op_4);
}

	/* EV_GTK_CALLBACK_MARSHAL gdk_event_dispatcher */
void _A576_323_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, open [1].it_i4, open [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL gdk_event_dispatcher */
void __A576_323_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_3, EIF_POINTER op_4)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, op_3, op_4);
}

	/* EV_GTK_CALLBACK_MARSHAL draw_actions_event */
EIF_BOOLEAN _A576_329_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, closed [2].it_p, open [1].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL draw_actions_event */
EIF_BOOLEAN __A576_329_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_3)
{
	return f_ptr (closed [1].it_r, closed [2].it_p, op_3);
}

	/* EV_GTK_CALLBACK_MARSHAL menu_item_activate_intermediary */
void _A576_338 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL menu_item_activate_intermediary */
void __A576_338 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL new_toolbar_item_select_actions_intermediary */
void _A576_312 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL new_toolbar_item_select_actions_intermediary */
void __A576_312 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL toolbar_item_select_actions_intermediary */
void _A576_322 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL toolbar_item_select_actions_intermediary */
void __A576_322 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4);
}

	/* EV_GTK_CALLBACK_MARSHAL configure_event */
EIF_BOOLEAN _A576_330_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, closed [2].it_p, open [1].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL configure_event */
EIF_BOOLEAN __A576_330_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_3)
{
	return f_ptr (closed [1].it_r, closed [2].it_p, op_3);
}

	/* EV_GTK_CALLBACK_MARSHAL scroll_event */
EIF_BOOLEAN _A576_331_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, closed [2].it_p, open [1].it_p);
}

	/* EV_GTK_CALLBACK_MARSHAL scroll_event */
EIF_BOOLEAN __A576_331_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_3)
{
	return f_ptr (closed [1].it_r, closed [2].it_p, op_3);
}

	/* WIZARD_WINDOW cancel_actions */
void _A709_353 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_WINDOW cancel_actions */
void __A709_353 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_WINDOW previous_page */
void _A709_385 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_WINDOW previous_page */
void __A709_385 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_WINDOW next_page */
void _A709_387 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_WINDOW next_page */
void __A709_387 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_WINDOW show_help */
void _A709_354 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* WIZARD_WINDOW show_help */
void __A709_354 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* EXECUTION_ENVIRONMENT item */
EIF_REFERENCE _A450_40_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EXECUTION_ENVIRONMENT item */
EIF_REFERENCE __A450_40_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* EV_WINDOW_I connect_accelerator */
void _A894_263_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EV_WINDOW_I connect_accelerator */
void __A894_263_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* EV_WINDOW_I disconnect_accelerator */
void _A894_264_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EV_WINDOW_I disconnect_accelerator */
void __A894_264_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* EV_DIALOG dialog_key_press_action */
void _A710_314_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EV_DIALOG dialog_key_press_action */
void __A710_314_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* EV_DIALOG destroy */
void _A710_267 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* EV_DIALOG destroy */
void __A710_267 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* EV_MESSAGE_DIALOG on_button_press */
void _A712_355 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_MESSAGE_DIALOG on_button_press */
void __A712_355 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_MESSAGE_DIALOG on_key_press */
void _A712_356_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EV_MESSAGE_DIALOG on_key_press */
void __A712_356_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* EV_FONT_IMP update_preferred_faces */
void _A820_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EV_FONT_IMP update_preferred_faces */
void __A820_105_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* EV_APPLICATION_I contextual_help */
void _A828_303_2_3_4_5_6_7_8_9 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4, open [2].it_i4, open [3].it_i4, open [4].it_r8, open [5].it_r8, open [6].it_r8, open [7].it_i4, open [8].it_i4);
}

	/* EV_APPLICATION_I contextual_help */
void __A828_303_2_3_4_5_6_7_8_9 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2, EIF_INTEGER_32 op_3, EIF_INTEGER_32 op_4, EIF_REAL_64 op_5, EIF_REAL_64 op_6, EIF_REAL_64 op_7, EIF_INTEGER_32 op_8, EIF_INTEGER_32 op_9)
{
	f_ptr (closed [1].it_r, op_2, op_3, op_4, op_5, op_6, op_7, op_8, op_9);
}

	/* EV_APPLICATION_I safe_destroy */
void _A828_68 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* EV_APPLICATION_I safe_destroy */
void __A828_68 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* EV_APPLICATION_I inline-agent#1 of create_target_menu */
EIF_BOOLEAN _A828_308_2_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1538_21121)(closed [1].it_r, open [1].it_r, open [2].it_r);
}

	/* EV_APPLICATION_I inline-agent#1 of create_target_menu */
EIF_BOOLEAN __A828_308_2_3 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_3)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1538_21121)(closed [1].it_r, op_2, op_3);
}

	/* EV_APPLICATION_I inline-agent#2 of create_target_menu */
void _A828_309_2_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1538_21122)(closed [1].it_r, open [1].it_r, open [2].it_r, open [3].it_r);
}

	/* EV_APPLICATION_I inline-agent#2 of create_target_menu */
void __A828_309_2_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_3, EIF_REFERENCE op_4)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1538_21122)(closed [1].it_r, op_2, op_3, op_4);
}

	/* EV_APPLICATION_I help_handler */
void _A828_300 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* EV_APPLICATION_I help_handler */
void __A828_300 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* EV_APPLICATION_I enable_contextual_help */
void _A828_243 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* EV_APPLICATION_I enable_contextual_help */
void __A828_243 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* EV_PND_ACTION_SEQUENCE call */
void _A485_180 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_PND_ACTION_SEQUENCE call */
void __A485_180 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_APPLICATION_IMP on_char_event */
EIF_POINTER _A829_425_2 ( EIF_POINTER(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_p);
}

	/* EV_APPLICATION_IMP on_char_event */
EIF_POINTER __A829_425_2 ( EIF_POINTER(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* EV_ANY_IMP c_object_dispose */
void A834_84 (EIF_REFERENCE Current)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R12805[Dtype(Current) - 1550])(Current);
}

	/* EV_DOCKABLE_SOURCE_HINT_IMP on_timeout */
void _A837_447 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* EV_DOCKABLE_SOURCE_HINT_IMP on_timeout */
void __A837_447 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* EV_DOCKABLE_SOURCE_I close_dockable_dialog */
void _A844_100 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_DOCKABLE_SOURCE_I close_dockable_dialog */
void __A844_100 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* EV_PICK_AND_DROPABLE_IMP inline-agent#1 of start_transport */
void _A873_232 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) F1587_21130)(closed [1].it_r, closed [2].it_r, closed [3].it_i4, closed [4].it_i4, closed [5].it_i4, closed [6].it_i4);
}

	/* EV_PICK_AND_DROPABLE_IMP inline-agent#1 of start_transport */
void __A873_232 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32), EIF_TYPED_VALUE * closed)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) F1587_21130)(closed [1].it_r, closed [2].it_r, closed [3].it_i4, closed [4].it_i4, closed [5].it_i4, closed [6].it_i4);
}

	/* EV_GAUGE_IMP set_range */
void _A933_424 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* EV_GAUGE_IMP set_range */
void __A933_424 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* EV_MENU_IMP c_gtk_menu_popup_at_pointer */
void _A969_326 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_NATURAL_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_p, closed [3].it_i4, closed [4].it_i4, closed [5].it_i4, closed [6].it_n4);
}

	/* EV_MENU_IMP c_gtk_menu_popup_at_pointer */
void __A969_326 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_NATURAL_32), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_p, closed [3].it_i4, closed [4].it_i4, closed [5].it_i4, closed [6].it_n4);
}

	/* I18N_FORMAT_STRING_PARSER day_of_month_action */
EIF_REFERENCE _A1050_113_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_month_action */
EIF_REFERENCE __A1050_113_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER day_of_month_padded_action */
EIF_REFERENCE _A1050_114_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_month_padded_action */
EIF_REFERENCE __A1050_114_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER month_action */
EIF_REFERENCE _A1050_120_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER month_action */
EIF_REFERENCE __A1050_120_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER day_name_action */
EIF_REFERENCE _A1050_116_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_name_action */
EIF_REFERENCE __A1050_116_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER week_number_sunday_as_first_action */
EIF_REFERENCE _A1050_126_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER week_number_sunday_as_first_action */
EIF_REFERENCE __A1050_126_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER year_4_action */
EIF_REFERENCE _A1050_132_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER year_4_action */
EIF_REFERENCE __A1050_132_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER abbreviated_day_name_action */
EIF_REFERENCE _A1050_115_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER abbreviated_day_name_action */
EIF_REFERENCE __A1050_115_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_year_action */
EIF_REFERENCE _A1050_117_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_year_action */
EIF_REFERENCE __A1050_117_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER day_of_week_action */
EIF_REFERENCE _A1050_118_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_week_action */
EIF_REFERENCE __A1050_118_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER day_of_week_0_action */
EIF_REFERENCE _A1050_119_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER day_of_week_0_action */
EIF_REFERENCE __A1050_119_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER month_padded_action */
EIF_REFERENCE _A1050_121_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER month_padded_action */
EIF_REFERENCE __A1050_121_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER abbreviated_month_name_action */
EIF_REFERENCE _A1050_122_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER abbreviated_month_name_action */
EIF_REFERENCE __A1050_122_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER month_name_action */
EIF_REFERENCE _A1050_123_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER month_name_action */
EIF_REFERENCE __A1050_123_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER century_number_action */
EIF_REFERENCE _A1050_124_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER century_number_action */
EIF_REFERENCE __A1050_124_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER iso_year_with_century_action */
EIF_REFERENCE _A1050_128_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER iso_year_with_century_action */
EIF_REFERENCE __A1050_128_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER iso_year_without_century_action */
EIF_REFERENCE _A1050_129_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER iso_year_without_century_action */
EIF_REFERENCE __A1050_129_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER week_number_iso_action */
EIF_REFERENCE _A1050_125_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER week_number_iso_action */
EIF_REFERENCE __A1050_125_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER week_number_monday_as_first_action */
EIF_REFERENCE _A1050_127_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER week_number_monday_as_first_action */
EIF_REFERENCE __A1050_127_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER year_1_action */
EIF_REFERENCE _A1050_130_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER year_1_action */
EIF_REFERENCE __A1050_130_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER year_2_action */
EIF_REFERENCE _A1050_131_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER year_2_action */
EIF_REFERENCE __A1050_131_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER hour_12_padded_action */
EIF_REFERENCE _A1050_102_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER hour_12_padded_action */
EIF_REFERENCE __A1050_102_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER hour_12_action */
EIF_REFERENCE _A1050_103_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER hour_12_action */
EIF_REFERENCE __A1050_103_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER hour_24_action */
EIF_REFERENCE _A1050_104_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER hour_24_action */
EIF_REFERENCE __A1050_104_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER minutes_action */
EIF_REFERENCE _A1050_106_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER minutes_action */
EIF_REFERENCE __A1050_106_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER minutes_padded_action */
EIF_REFERENCE _A1050_107_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER minutes_padded_action */
EIF_REFERENCE __A1050_107_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER seconds_action */
EIF_REFERENCE _A1050_108_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER seconds_action */
EIF_REFERENCE __A1050_108_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER seconds_padded_action */
EIF_REFERENCE _A1050_109_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER seconds_padded_action */
EIF_REFERENCE __A1050_109_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_1_action */
EIF_REFERENCE _A1050_110_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_1_action */
EIF_REFERENCE __A1050_110_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_lowercase_action */
EIF_REFERENCE _A1050_111_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_lowercase_action */
EIF_REFERENCE __A1050_111_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_uppercase_action */
EIF_REFERENCE _A1050_112_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* I18N_FORMAT_STRING_PARSER am_pm_uppercase_action */
EIF_REFERENCE __A1050_112_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* EIFFEL_ENV safe_create_dir */
void _A1071_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* EIFFEL_ENV safe_create_dir */
void __A1071_181_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* STRING_8 is_empty */
EIF_BOOLEAN _A628_163_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F729_8337)(open [1].it_r);
}

	/* STRING_8 is_empty */
EIF_BOOLEAN __A628_163_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F729_8337)(op_1);
}


#ifdef __cplusplus
}
#endif
