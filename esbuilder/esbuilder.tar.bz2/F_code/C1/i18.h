
#ifndef _C1_i18_
#define _C1_i18_

#ifdef __cplusplus
extern "C" {
#endif

extern void F8_84(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit8(void);
extern void F469_6621(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
