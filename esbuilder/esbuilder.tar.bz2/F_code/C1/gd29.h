
#ifndef _C1_gd29_
#define _C1_gd29_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F34_462(EIF_REFERENCE);
extern void EIF_Minit29(void);

#ifdef __cplusplus
}
#endif

#endif
