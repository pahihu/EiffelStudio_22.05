
#ifndef _C1_cl36_
#define _C1_cl36_

#ifdef __cplusplus
extern "C" {
#endif

extern void F42_490(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F42_496(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit36(void);
extern EIF_INTEGER_32 F2299_28879(EIF_REFERENCE);
extern EIF_INTEGER_32 F2299_28876(EIF_REFERENCE);
extern EIF_INTEGER_32 F2299_28877(EIF_REFERENCE);
extern EIF_INTEGER_32 F2299_28878(EIF_REFERENCE);
extern char *(*R22608[])();

#ifdef __cplusplus
}
#endif

#endif
