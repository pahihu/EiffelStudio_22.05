
#ifndef _C1_gb48_
#define _C1_gb48_

#ifdef __cplusplus
extern "C" {
#endif

extern void F55_778(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit48(void);

#ifdef __cplusplus
}
#endif

#endif
