/*
 * Code for class C_DATE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "c_19.h"
#include <string.h>
#include "eif_time.h"
#include <time.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F23_357
static void inline_F23_357 (EIF_POINTER arg1)
{
	#ifdef EIF_WINDOWS
    			static const uint64_t EPOCH = ((uint64_t) 116444736000000000ULL);

				SYSTEMTIME  system_time;
				FILETIME    file_time;
				uint64_t    time;
				struct timeval *tp = (struct timeval *) arg1;

				GetSystemTime (&system_time );
				SystemTimeToFileTime (&system_time, &file_time );
				time = ((uint64_t) file_time.dwLowDateTime );
				time += ((uint64_t) file_time.dwHighDateTime) << 32;

				tp->tv_sec  = (long) ((time - EPOCH) / 10000000L);
				tp->tv_usec = (long) (system_time.wMilliseconds * 1000);
			#else
				gettimeofday((struct timeval *) arg1, NULL);
			#endif
	;
}
#define INLINE_F23_357
#endif
#ifndef INLINE_F23_361
static void inline_F23_361 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	*(time_t *) arg2 = (((struct timeval *)arg1)->tv_sec);
	;
}
#define INLINE_F23_361
#endif
#ifndef INLINE_F23_365
static EIF_POINTER inline_F23_365 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gmtime ((time_t *) arg1))
	;
}
#define INLINE_F23_365
#endif
#ifndef INLINE_F23_364
static EIF_POINTER inline_F23_364 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (localtime ((time_t *) arg1))
	;
}
#define INLINE_F23_364
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {C_DATE}.default_create */
void F23_345 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("default_create", 22, Current, 0, 0, 366);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(2);
	F23_348(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {C_DATE}.update */
void F23_348 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("update", 22, Current, 4, 0, 369);
	RTGC;
	RTHOOK(1);
	ti4_1 = (EIF_INTEGER_32) sizeof(struct timeval);
	tp1 = malloc((size_t)ti4_1);
	loc1 = (EIF_POINTER) tp1;
	RTHOOK(2);
	ti4_1 = (EIF_INTEGER_32) sizeof(time_t);
	tp1 = malloc((size_t)ti4_1);
	loc3 = (EIF_POINTER) tp1;
	RTHOOK(3);
	inline_F23_357(loc1);
	RTHOOK(4);
	inline_F23_361(loc1, loc3);
	RTHOOK(5);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
		RTHOOK(6);
		loc2 = inline_F23_365(loc3);
	} else {
		RTHOOK(7);
		loc2 = inline_F23_364(loc3);
	}
	RTHOOK(8);
	tr1 = RTLNSMART(eif_new_type(1208, 0).id);
	ti4_1 = (EIF_INTEGER_32) sizeof(struct tm);
	F1209_10430(RTCW(tr1), loc2, ti4_1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(9);
	loc4 = (EIF_INTEGER_32) (((struct timeval *)loc1)->tv_usec);
	RTHOOK(10);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc4 < ((EIF_INTEGER_32) 0L)) || (EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 999999L)))) {
		RTHOOK(11);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		RTHOOK(12);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) loc4;
	}
	RTHOOK(13);
	free(loc3);
	RTHOOK(14);
	free(loc1);
	RTHOOK(15);
	RTLE;
	RTEE;
}

/* {C_DATE}.year_now */
EIF_INTEGER_32 F23_349 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("year_now", 22, Current, 0, 0, 370);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tp1 = *(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_0_1_0_1_0_0_);
	Result = (EIF_INTEGER_32) (((struct tm *)tp1)->tm_year);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 1900L) + Result);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {C_DATE}.month_now */
EIF_INTEGER_32 F23_350 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("month_now", 22, Current, 0, 0, 371);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tp1 = *(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_0_1_0_1_0_0_);
	Result = (EIF_INTEGER_32) (((struct tm *)tp1)->tm_mon);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 1L));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {C_DATE}.day_now */
EIF_INTEGER_32 F23_351 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("day_now", 22, Current, 0, 0, 372);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tp1 = *(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_0_1_0_1_0_0_);
	Result = (EIF_INTEGER_32) (((struct tm *)tp1)->tm_mday);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {C_DATE}.hour_now */
EIF_INTEGER_32 F23_352 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("hour_now", 22, Current, 0, 0, 373);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tp1 = *(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_0_1_0_1_0_0_);
	Result = (EIF_INTEGER_32) (((struct tm *)tp1)->tm_hour);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {C_DATE}.minute_now */
EIF_INTEGER_32 F23_353 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("minute_now", 22, Current, 0, 0, 374);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tp1 = *(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_0_1_0_1_0_0_);
	Result = (EIF_INTEGER_32) (((struct tm *)tp1)->tm_min);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {C_DATE}.second_now */
EIF_INTEGER_32 F23_354 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("second_now", 22, Current, 0, 0, 375);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tp1 = *(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_0_1_0_1_0_0_);
	Result = (EIF_INTEGER_32) (((struct tm *)tp1)->tm_sec);
	RTHOOK(2);
	if ((EIF_BOOLEAN) (Result > ((EIF_INTEGER_32) 59L))) {
		RTHOOK(3);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 59L);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {C_DATE}.millisecond_now */
EIF_INTEGER_32 F23_355 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("millisecond_now", 22, Current, 0, 0, 349);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) / ((EIF_INTEGER_32) 1000L));
}

/* {C_DATE}.gettimeofday */
void F23_357 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gettimeofday", 22, Current, 0, 1, 351);
	inline_F23_357 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {C_DATE}.timeval_structure_size */
EIF_INTEGER_32 F23_358 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("timeval_structure_size", 22, Current, 0, 0, 352);
	Result = (EIF_INTEGER_32) sizeof(struct timeval);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {C_DATE}.time_t_structure_size */
EIF_INTEGER_32 F23_359 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("time_t_structure_size", 22, Current, 0, 0, 353);
	Result = (EIF_INTEGER_32) sizeof(time_t);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {C_DATE}.tm_structure_size */
EIF_INTEGER_32 F23_360 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("tm_structure_size", 22, Current, 0, 0, 354);
	Result = (EIF_INTEGER_32) sizeof(struct tm);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {C_DATE}.get_time */
void F23_361 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("get_time", 22, Current, 0, 2, 355);
	inline_F23_361 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {C_DATE}.get_micro */
EIF_INTEGER_32 F23_362 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("get_micro", 22, Current, 0, 1, 356);Result = (EIF_INTEGER_32) (((struct timeval *)arg1)->tv_usec);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {C_DATE}.localtime */
EIF_POINTER F23_364 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("localtime", 22, Current, 0, 1, 358);
	Result = inline_F23_364 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {C_DATE}.gmtime */
EIF_POINTER F23_365 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gmtime", 22, Current, 0, 1, 359);
	Result = inline_F23_365 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {C_DATE}.get_tm_year */
EIF_INTEGER_32 F23_366 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("get_tm_year", 22, Current, 0, 1, 360);Result = (EIF_INTEGER_32) (((struct tm *)arg1)->tm_year);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {C_DATE}.get_tm_mon */
EIF_INTEGER_32 F23_367 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("get_tm_mon", 22, Current, 0, 1, 361);Result = (EIF_INTEGER_32) (((struct tm *)arg1)->tm_mon);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {C_DATE}.get_tm_mday */
EIF_INTEGER_32 F23_368 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("get_tm_mday", 22, Current, 0, 1, 362);Result = (EIF_INTEGER_32) (((struct tm *)arg1)->tm_mday);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {C_DATE}.get_tm_hour */
EIF_INTEGER_32 F23_369 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("get_tm_hour", 22, Current, 0, 1, 363);Result = (EIF_INTEGER_32) (((struct tm *)arg1)->tm_hour);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {C_DATE}.get_tm_min */
EIF_INTEGER_32 F23_370 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("get_tm_min", 22, Current, 0, 1, 364);Result = (EIF_INTEGER_32) (((struct tm *)arg1)->tm_min);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {C_DATE}.get_tm_sec */
EIF_INTEGER_32 F23_371 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("get_tm_sec", 22, Current, 0, 1, 365);Result = (EIF_INTEGER_32) (((struct tm *)arg1)->tm_sec);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit19 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
