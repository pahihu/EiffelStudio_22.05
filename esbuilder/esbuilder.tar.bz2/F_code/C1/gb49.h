
#ifndef _C1_gb49_
#define _C1_gb49_

#ifdef __cplusplus
extern "C" {
#endif

extern void F56_779(EIF_REFERENCE);
extern void F56_783(EIF_REFERENCE);
extern void F56_784(EIF_REFERENCE);
extern void F56_785(EIF_REFERENCE);
extern void F56_786(EIF_REFERENCE);
extern void F56_787(EIF_REFERENCE);
extern void F56_788(EIF_REFERENCE);
extern EIF_REFERENCE F56_789(EIF_REFERENCE);
extern EIF_BOOLEAN F56_790(EIF_REFERENCE);
extern void F56_791(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit49(void);
extern EIF_REFERENCE F1147_10116(EIF_REFERENCE);
extern void F1147_10144(EIF_REFERENCE);
extern void F1147_10142(EIF_REFERENCE);
extern EIF_BOOLEAN F940_9502(EIF_REFERENCE);
extern void F1147_10111(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R7993[])();

#ifdef __cplusplus
}
#endif

#endif
