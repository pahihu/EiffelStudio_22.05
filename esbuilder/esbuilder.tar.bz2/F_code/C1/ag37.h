
#ifndef _C1_ag37_
#define _C1_ag37_

#ifdef __cplusplus
extern "C" {
#endif

extern void F43_497(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit37(void);

#ifdef __cplusplus
}
#endif

#endif
