
#ifndef _C1_i14_
#define _C1_i14_

#ifdef __cplusplus
extern "C" {
#endif

extern void F4_43(EIF_REFERENCE, EIF_REFERENCE);
extern void F4_44(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit4(void);

#ifdef __cplusplus
}
#endif

#endif
