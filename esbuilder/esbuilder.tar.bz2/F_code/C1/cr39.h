
#ifndef _C1_cr39_
#define _C1_cr39_

#ifdef __cplusplus
extern "C" {
#endif

extern void F45_505(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit39(void);

#ifdef __cplusplus
}
#endif

#endif
