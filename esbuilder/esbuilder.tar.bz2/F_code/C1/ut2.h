
#ifndef _C1_ut2_
#define _C1_ut2_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F2_35(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit2(void);
extern EIF_REFERENCE F105_1489(EIF_REFERENCE, EIF_REFERENCE);
extern void F1500_14155(EIF_REFERENCE);
extern char *(*R8808[])();
extern long O8736[];

#ifdef __cplusplus
}
#endif

#endif
