/*
 * Code for class GDK_CAIRO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gd45.h"
#include "ev_gtk.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F52_753
static EIF_POINTER inline_F52_753 (void)
{
	return cairo_region_create();
	;
}
#define INLINE_F52_753
#endif
#ifndef INLINE_F52_754
static void inline_F52_754 (EIF_POINTER arg1)
{
	cairo_region_destroy(arg1)
	;
}
#define INLINE_F52_754
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GDK_CAIRO}.set_source_pixbuf */
void F52_750 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_source_pixbuf", 51, Current, 0, 4, 731);gdk_cairo_set_source_pixbuf((cairo_t*) arg1, (GdkPixbuf*) arg2, (double) arg3, (double) arg4);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {GDK_CAIRO}.cairo_region_create */
EIF_POINTER F52_753 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("cairo_region_create", 51, Current, 0, 0, 734);
	Result = inline_F52_753 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GDK_CAIRO}.cairo_region_destroy */
void F52_754 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("cairo_region_destroy", 51, Current, 0, 1, 735);
	inline_F52_754 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
}

void EIF_Minit45 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
