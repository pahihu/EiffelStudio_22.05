
#ifndef _C1_kl13_
#define _C1_kl13_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,124)
static EIF_REFERENCE F14_124_body(EIF_REFERENCE);
extern EIF_REFERENCE F14_124(EIF_REFERENCE);
RTOSHF (EIF_REFERENCE,125)
static EIF_REFERENCE F14_125_body(EIF_REFERENCE);
extern EIF_REFERENCE F14_125(EIF_REFERENCE);
extern void EIF_Minit13(void);

#ifdef __cplusplus
}
#endif

#endif
