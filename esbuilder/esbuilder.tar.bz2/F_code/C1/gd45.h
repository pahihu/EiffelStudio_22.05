
#ifndef _C1_gd45_
#define _C1_gd45_

#ifdef __cplusplus
extern "C" {
#endif

extern void F52_750(EIF_REFERENCE, EIF_POINTER, EIF_POINTER, EIF_REAL_64, EIF_REAL_64);
extern EIF_POINTER F52_753(EIF_REFERENCE);
extern void F52_754(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit45(void);

#ifdef __cplusplus
}
#endif

#endif
