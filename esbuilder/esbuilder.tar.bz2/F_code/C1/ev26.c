/*
 * Code for class EV_TEXT_ALIGNMENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev26.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TEXT_ALIGNMENT}.set_left_alignment */
void F31_437 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_left_alignment", 30, Current, 0, 0, 415);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(3);
	RTEE;
}

/* {EV_TEXT_ALIGNMENT}.set_center_alignment */
void F31_438 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_center_alignment", 30, Current, 0, 0, 416);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(3);
	RTEE;
}

/* {EV_TEXT_ALIGNMENT}.set_right_alignment */
void F31_439 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_right_alignment", 30, Current, 0, 0, 417);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	RTHOOK(3);
	RTEE;
}

/* {EV_TEXT_ALIGNMENT}.is_left_aligned */
EIF_BOOLEAN F31_440 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_left_aligned", 30, Current, 0, 0, 418);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) == ((EIF_INTEGER_32) 0L));
}

/* {EV_TEXT_ALIGNMENT}.is_center_aligned */
EIF_BOOLEAN F31_441 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_center_aligned", 30, Current, 0, 0, 419);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) == ((EIF_INTEGER_32) 1L));
}

void EIF_Minit26 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
