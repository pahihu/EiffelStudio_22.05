/*
 * Code for class PANGO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pa43.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F50_567
static void inline_F50_567 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	(FUNCTION_CAST(void, (PangoLayout*, gint)) arg1)((PangoLayout*) arg2, (gint) arg3);
	;
}
#define INLINE_F50_567
#endif
#ifndef INLINE_F50_617
static EIF_POINTER inline_F50_617 (void)
{
	return pango_attr_list_new();
	;
}
#define INLINE_F50_617
#endif
#ifndef INLINE_F50_620
static EIF_POINTER inline_F50_620 (EIF_POINTER arg1)
{
	return pango_attr_font_desc_new ((const PangoFontDescription *)arg1);
	;
}
#define INLINE_F50_620
#endif
#ifndef INLINE_F50_621
static void inline_F50_621 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	pango_attr_list_insert ((PangoAttrList *)arg1, (PangoAttribute *)arg2);
	;
}
#define INLINE_F50_621
#endif
#ifndef INLINE_F50_622
static void inline_F50_622 (EIF_POINTER arg1)
{
	pango_attr_list_unref ((PangoAttrList *)arg1);
	;
}
#define INLINE_F50_622
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PANGO}.underline_none_enum */
EIF_INTEGER_32 F50_562 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("underline_none_enum", 49, Current, 0, 0, 543);
	Result = (EIF_INTEGER_32) PANGO_UNDERLINE_NONE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.underline_single_enum */
EIF_INTEGER_32 F50_563 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("underline_single_enum", 49, Current, 0, 0, 544);
	Result = (EIF_INTEGER_32) PANGO_UNDERLINE_SINGLE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.scale */
EIF_INTEGER_32 F50_565 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("scale", 49, Current, 0, 0, 546);
	Result = (EIF_INTEGER_32) PANGO_SCALE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.layout_set_ellipsize_call */
void F50_567 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("layout_set_ellipsize_call", 49, Current, 0, 3, 548);
	inline_F50_567 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_INTEGER_32) arg3);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.font_description_new */
EIF_POINTER F50_568 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("font_description_new", 49, Current, 0, 0, 549);Result = (EIF_POINTER) pango_font_description_new();
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.font_description_free */
void F50_569 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("font_description_free", 49, Current, 0, 1, 550);pango_font_description_free((PangoFontDescription*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.font_description_set_family */
void F50_572 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("font_description_set_family", 49, Current, 0, 2, 553);pango_font_description_set_family((PangoFontDescription*) arg1, (char*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.font_description_set_style */
void F50_574 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("font_description_set_style", 49, Current, 0, 2, 555);pango_font_description_set_style((PangoFontDescription*) arg1, (PangoStyle) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.font_description_set_weight */
void F50_576 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("font_description_set_weight", 49, Current, 0, 2, 557);pango_font_description_set_weight((PangoFontDescription*) arg1, (PangoWeight) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.font_description_set_size */
void F50_578 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("font_description_set_size", 49, Current, 0, 2, 559);pango_font_description_set_size((PangoFontDescription*) arg1, (gint) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.layout_set_font_description */
void F50_581 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("layout_set_font_description", 49, Current, 0, 2, 562);pango_layout_set_font_description((PangoLayout*) arg1, (PangoFontDescription*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.layout_set_width */
void F50_582 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("layout_set_width", 49, Current, 0, 2, 563);pango_layout_set_width((PangoLayout*) arg1, (int) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.layout_get_pixel_size */
void F50_583 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32* arg2, EIF_INTEGER_32* arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("layout_get_pixel_size", 49, Current, 0, 3, 564);pango_layout_get_pixel_size((PangoLayout*) arg1, (gint*) arg2, (gint*) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.layout_get_iter */
EIF_POINTER F50_584 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("layout_get_iter", 49, Current, 0, 1, 565);Result = (EIF_POINTER) pango_layout_get_iter((PangoLayout*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.layout_set_text */
void F50_585 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("layout_set_text", 49, Current, 0, 3, 566);pango_layout_set_text((PangoLayout*) arg1, (char*) arg2, (int) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.layout_iter_get_baseline */
EIF_INTEGER_32 F50_586 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("layout_iter_get_baseline", 49, Current, 0, 1, 567);Result = (EIF_INTEGER_32) pango_layout_iter_get_baseline((PangoLayoutIter*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.layout_iter_free */
void F50_587 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("layout_iter_free", 49, Current, 0, 1, 568);pango_layout_iter_free((PangoLayoutIter*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.layout_get_pixel_extents */
void F50_589 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("layout_get_pixel_extents", 49, Current, 0, 3, 570);pango_layout_get_pixel_extents((PangoLayout*) arg1, (PangoRectangle*) arg2, (PangoRectangle*) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.cairo_create_layout */
EIF_POINTER F50_596 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("cairo_create_layout", 49, Current, 0, 1, 577);Result = (EIF_POINTER) pango_cairo_create_layout((cairo_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.cairo_show_layout */
void F50_598 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("cairo_show_layout", 49, Current, 0, 2, 579);pango_cairo_show_layout((cairo_t*) arg1, (PangoLayout*) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.new_rectangle_struct */
EIF_POINTER F50_601 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("new_rectangle_struct", 49, Current, 0, 0, 582);
	Result = (EIF_POINTER) calloc (sizeof(PangoRectangle), 1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.rectangle_struct_x */
EIF_INTEGER_32 F50_602 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("rectangle_struct_x", 49, Current, 0, 1, 583);Result = (EIF_INTEGER_32) (((PangoRectangle *)arg1)->x);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.rectangle_struct_y */
EIF_INTEGER_32 F50_603 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("rectangle_struct_y", 49, Current, 0, 1, 584);Result = (EIF_INTEGER_32) (((PangoRectangle *)arg1)->y);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.rectangle_struct_width */
EIF_INTEGER_32 F50_604 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("rectangle_struct_width", 49, Current, 0, 1, 585);Result = (EIF_INTEGER_32) (((PangoRectangle *)arg1)->width);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.rectangle_struct_height */
EIF_INTEGER_32 F50_605 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("rectangle_struct_height", 49, Current, 0, 1, 586);Result = (EIF_INTEGER_32) (((PangoRectangle *)arg1)->height);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.tab_array_new */
EIF_POINTER F50_606 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("tab_array_new", 49, Current, 0, 2, 587);Result = (EIF_POINTER) pango_tab_array_new((gint) arg1, (gboolean) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.tab_array_resize */
void F50_607 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("tab_array_resize", 49, Current, 0, 2, 588);pango_tab_array_resize((PangoTabArray*) arg1, (gint) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.tab_array_set_tab */
void F50_608 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("tab_array_set_tab", 49, Current, 0, 4, 589);pango_tab_array_set_tab((PangoTabArray*) arg1, (gint) arg2, (PangoTabAlign) arg3, (gint) arg4);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.pango_attr_list_new */
EIF_POINTER F50_617 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("pango_attr_list_new", 49, Current, 0, 0, 598);
	Result = inline_F50_617 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.pango_attr_font_desc_new */
EIF_POINTER F50_620 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("pango_attr_font_desc_new", 49, Current, 0, 1, 601);
	Result = inline_F50_620 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {PANGO}.pango_attr_list_insert */
void F50_621 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("pango_attr_list_insert", 49, Current, 0, 2, 602);
	inline_F50_621 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {PANGO}.pango_attr_list_unref */
void F50_622 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("pango_attr_list_unref", 49, Current, 0, 1, 603);
	inline_F50_622 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
}

void EIF_Minit43 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
