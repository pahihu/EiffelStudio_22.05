
#ifndef _C1_gb47_
#define _C1_gb47_

#ifdef __cplusplus
extern "C" {
#endif

extern void F54_772(EIF_REFERENCE);
extern void F54_773(EIF_REFERENCE);
extern void F54_774(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit47(void);
extern EIF_REFERENCE F1147_10116(EIF_REFERENCE);
extern void F1147_10142(EIF_REFERENCE);
extern void F1147_10151(EIF_REFERENCE, EIF_REFERENCE);
extern void F1147_10111(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F827_9290(EIF_REFERENCE);
extern char *(*R8012[])();
extern char *(*R23986[])();

#ifdef __cplusplus
}
#endif

#endif
