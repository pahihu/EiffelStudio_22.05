/*
 * Code for class I18N_PLURAL_TOOLS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "i15.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {I18N_PLURAL_TOOLS}.mo_header_to_plural_form */
EIF_INTEGER_32 F5_51 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg2);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("mo_header_to_plural_form", 4, Current, 0, 2, 55);
	RTGC;
	RTHOOK(1);
	switch (arg1) {
		case 1L:
			RTHOOK(2);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			break;
		case 2L:
			RTHOOK(3);
			tr1 = RTMS_EX_H("n != 1;",7,619025723);
			tb1 = F1500_14200(RTCW(arg2), tr1);
			if (tb1) {
				RTHOOK(4);
				Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
			} else {
				RTHOOK(5);
				Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
			}
			break;
		case 3L:
			RTHOOK(6);
			tb1 = '\0';
			tb2 = '\0';
			tr1 = RTMS_EX_H("!=",2,8509);
			tb3 = F1500_14199(RTCW(arg2), tr1);
			if (tb3) {
				tr1 = RTMS_EX_H("4",1,52);
				tb3 = F1500_14199(RTCW(arg2), tr1);
				tb2 = (EIF_BOOLEAN) !tb3;
			}
			if (tb2) {
				tr1 = RTMS_EX_H("20",2,12848);
				tb2 = F1500_14199(RTCW(arg2), tr1);
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				RTHOOK(7);
				Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
			} else {
				RTHOOK(8);
				tb1 = '\0';
				tr1 = RTMS_EX_H("!=",2,8509);
				tb2 = F1500_14199(RTCW(arg2), tr1);
				if ((EIF_BOOLEAN) !tb2) {
					tr1 = RTMS_EX_H("4",1,52);
					tb2 = F1500_14199(RTCW(arg2), tr1);
					tb1 = (EIF_BOOLEAN) !tb2;
				}
				if (tb1) {
					RTHOOK(9);
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
				} else {
					RTHOOK(10);
					tb1 = '\0';
					tr1 = RTMS_EX_H("20",2,12848);
					tb2 = F1500_14199(RTCW(arg2), tr1);
					if (tb2) {
						tr1 = RTMS_EX_H("4",1,52);
						tb2 = F1500_14199(RTCW(arg2), tr1);
						tb1 = (EIF_BOOLEAN) !tb2;
					}
					if (tb1) {
						RTHOOK(11);
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
					} else {
						RTHOOK(12);
						tr1 = RTMS_EX_H("!=",2,8509);
						tb1 = F1500_14199(RTCW(arg2), tr1);
						if (tb1) {
							RTHOOK(13);
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
						} else {
							RTHOOK(14);
							Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
						}
					}
				}
			}
			break;
		case 4L:
			RTHOOK(15);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 9L);
			break;
		default:
			RTHOOK(16);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			break;
	}
	RTHOOK(17);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_PLURAL_TOOLS}.get_reduction_agent */
EIF_REFERENCE F5_66 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("get_reduction_agent", 4, Current, 0, 1, 70);
	RTGC;
	RTHOOK(1);
	switch (arg1) {
		case 1L:
			RTHOOK(2);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[3] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {1496,0xFFF9,1,1419,1425,1425,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A5_50_2, (EIF_POINTER) _A5_50_2, (EIF_POINTER)(F5_68),tr1, 1, 1);
			}
			Result = (EIF_REFERENCE) tr4;
			break;
		case 2L:
			RTHOOK(3);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[3] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {1496,0xFFF9,1,1419,1425,1425,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A5_51_2, (EIF_POINTER) _A5_51_2, (EIF_POINTER)(F5_69),tr1, 1, 1);
			}
			Result = (EIF_REFERENCE) tr4;
			break;
		case 0L:
		case 3L:
			RTHOOK(4);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[3] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {1496,0xFFF9,1,1419,1425,1425,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A5_52_2, (EIF_POINTER) _A5_52_2, (EIF_POINTER)(F5_70),tr1, 1, 1);
			}
			Result = (EIF_REFERENCE) tr4;
			break;
		case 4L:
			RTHOOK(5);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[3] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {1496,0xFFF9,1,1419,1425,1425,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A5_53_2, (EIF_POINTER) _A5_53_2, (EIF_POINTER)(F5_71),tr1, 1, 1);
			}
			Result = (EIF_REFERENCE) tr4;
			break;
		case 5L:
			RTHOOK(6);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[3] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {1496,0xFFF9,1,1419,1425,1425,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A5_54_2, (EIF_POINTER) _A5_54_2, (EIF_POINTER)(F5_72),tr1, 1, 1);
			}
			Result = (EIF_REFERENCE) tr4;
			break;
		case 6L:
			RTHOOK(7);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[3] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {1496,0xFFF9,1,1419,1425,1425,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A5_55_2, (EIF_POINTER) _A5_55_2, (EIF_POINTER)(F5_73),tr1, 1, 1);
			}
			Result = (EIF_REFERENCE) tr4;
			break;
		case 7L:
			RTHOOK(8);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[3] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {1496,0xFFF9,1,1419,1425,1425,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A5_56_2, (EIF_POINTER) _A5_56_2, (EIF_POINTER)(F5_74),tr1, 1, 1);
			}
			Result = (EIF_REFERENCE) tr4;
			break;
		case 8L:
			RTHOOK(9);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[3] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {1496,0xFFF9,1,1419,1425,1425,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A5_57_2, (EIF_POINTER) _A5_57_2, (EIF_POINTER)(F5_75),tr1, 1, 1);
			}
			Result = (EIF_REFERENCE) tr4;
			break;
		case 9L:
			RTHOOK(10);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[3] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {1496,0xFFF9,1,1419,1425,1425,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A5_58_2, (EIF_POINTER) _A5_58_2, (EIF_POINTER)(F5_76),tr1, 1, 1);
			}
			Result = (EIF_REFERENCE) tr4;
			break;
		default:
			RTEC(EN_WHEN);
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_PLURAL_TOOLS}.get_nplural */
EIF_INTEGER_32 F5_67 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("get_nplural", 4, Current, 0, 1, 71);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg1 <= ((EIF_INTEGER_32) 3L))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	} else {
		RTHOOK(4);
		if ((EIF_BOOLEAN) (arg1 <= ((EIF_INTEGER_32) 1L))) {
			RTHOOK(5);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			RTHOOK(6);
			if ((EIF_BOOLEAN) (arg1 <= ((EIF_INTEGER_32) 8L))) {
				RTHOOK(7);
				RTHOOK(8);
				RTLE;
				RTEE;
				return (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
			} else {
				RTHOOK(9);
				RTHOOK(10);
				RTLE;
				RTEE;
				return (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
			}
		}
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {I18N_PLURAL_TOOLS}.reduce_one_plural_form */
EIF_INTEGER_32 F5_68 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("reduce_one_plural_form", 4, Current, 0, 1, 72);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
}

/* {I18N_PLURAL_TOOLS}.reduce_two_plural_forms_singular_one */
EIF_INTEGER_32 F5_69 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("reduce_two_plural_forms_singular_one", 4, Current, 0, 1, 73);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		RTHOOK(4);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}/* NOTREACHED */
	
}

/* {I18N_PLURAL_TOOLS}.reduce_two_plural_forms_singular_one_zero */
EIF_INTEGER_32 F5_70 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("reduce_two_plural_forms_singular_one_zero", 4, Current, 0, 1, 74);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg1 > ((EIF_INTEGER_32) 1L))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		RTHOOK(4);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	}/* NOTREACHED */
	
}

/* {I18N_PLURAL_TOOLS}.reduce_three_plural_forms_special_zero */
EIF_INTEGER_32 F5_71 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("reduce_three_plural_forms_special_zero", 4, Current, 0, 1, 48);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 10L)) == ((EIF_INTEGER_32) 1L)) && (EIF_BOOLEAN)((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) != ((EIF_INTEGER_32) 11L)))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		RTHOOK(4);
		if ((EIF_BOOLEAN)(arg1 != ((EIF_INTEGER_32) 0L))) {
			RTHOOK(5);
			RTHOOK(6);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			RTHOOK(7);
			RTHOOK(8);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		}
	}/* NOTREACHED */
	
}

/* {I18N_PLURAL_TOOLS}.reduce_three_plural_forms_special_one_two */
EIF_INTEGER_32 F5_72 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("reduce_three_plural_forms_special_one_two", 4, Current, 0, 1, 49);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		RTHOOK(4);
		if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 2L))) {
			RTHOOK(5);
			RTHOOK(6);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			RTHOOK(7);
			RTHOOK(8);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		}
	}/* NOTREACHED */
	
}

/* {I18N_PLURAL_TOOLS}.reduce_three_plural_forms_special_twelve_to_nineteen */
EIF_INTEGER_32 F5_73 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("reduce_three_plural_forms_special_twelve_to_nineteen", 4, Current, 0, 1, 50);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 10L)) == ((EIF_INTEGER_32) 1L)) && (EIF_BOOLEAN)((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) != ((EIF_INTEGER_32) 11L)))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		RTHOOK(4);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 10L)) >= ((EIF_INTEGER_32) 2L)) && (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) < ((EIF_INTEGER_32) 10L)) || (EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) >= ((EIF_INTEGER_32) 20L))))) {
			RTHOOK(5);
			RTHOOK(6);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			RTHOOK(7);
			RTHOOK(8);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		}
	}/* NOTREACHED */
	
}

/* {I18N_PLURAL_TOOLS}.reduce_three_plural_forms_special_slavic */
EIF_INTEGER_32 F5_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("reduce_three_plural_forms_special_slavic", 4, Current, 0, 1, 51);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 10L)) == ((EIF_INTEGER_32) 1L)) && (EIF_BOOLEAN)((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) != ((EIF_INTEGER_32) 11L)))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		RTHOOK(4);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 10L)) >= ((EIF_INTEGER_32) 2L)) && (EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 10L)) <= ((EIF_INTEGER_32) 4L))) && (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) < ((EIF_INTEGER_32) 10L)) || (EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) >= ((EIF_INTEGER_32) 20L))))) {
			RTHOOK(5);
			RTHOOK(6);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			RTHOOK(7);
			RTHOOK(8);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		}
	}/* NOTREACHED */
	
}

/* {I18N_PLURAL_TOOLS}.reduce_three_plural_forms_special_polish */
EIF_INTEGER_32 F5_75 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("reduce_three_plural_forms_special_polish", 4, Current, 0, 1, 52);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		RTHOOK(4);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 10L)) >= ((EIF_INTEGER_32) 2L)) && (EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 10L)) <= ((EIF_INTEGER_32) 4L))) && (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) < ((EIF_INTEGER_32) 10L)) || (EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) >= ((EIF_INTEGER_32) 20L))))) {
			RTHOOK(5);
			RTHOOK(6);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			RTHOOK(7);
			RTHOOK(8);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		}
	}/* NOTREACHED */
	
}

/* {I18N_PLURAL_TOOLS}.reduce_four_plural_forms_special_slovenian */
EIF_INTEGER_32 F5_76 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("reduce_four_plural_forms_special_slovenian", 4, Current, 0, 1, 53);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		RTHOOK(4);
		if ((EIF_BOOLEAN)((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) == ((EIF_INTEGER_32) 2L))) {
			RTHOOK(5);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			RTHOOK(6);
			if ((EIF_BOOLEAN)((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 100L)) == ((EIF_INTEGER_32) 3L))) {
				RTHOOK(7);
				RTHOOK(8);
				RTLE;
				RTEE;
				return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
			} else {
				RTHOOK(9);
				RTHOOK(10);
				RTLE;
				RTEE;
				return (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
			}
		}
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit5 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
