/*
 * Code for class GB_BOOLEAN_TREE_ITEM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gb49.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GB_BOOLEAN_TREE_ITEM}.default_create */
void F56_779 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("default_create", 55, Current, 0, 0, 762);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1146,55,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1147_10111(RTCW(tr1), ((EIF_INTEGER_32) 3L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {GB_BOOLEAN_TREE_ITEM}.enable_selected */
void F56_783 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("enable_selected", 55, Current, 0, 0, 766);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	RTEE;
}

/* {GB_BOOLEAN_TREE_ITEM}.disable_selected */
void F56_784 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("disable_selected", 55, Current, 0, 0, 767);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(3);
	RTEE;
}

/* {GB_BOOLEAN_TREE_ITEM}.enable_state */
void F56_785 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("enable_state", 55, Current, 0, 0, 768);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	RTEE;
}

/* {GB_BOOLEAN_TREE_ITEM}.disable_state */
void F56_786 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("disable_state", 55, Current, 0, 0, 769);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(3);
	RTEE;
}

/* {GB_BOOLEAN_TREE_ITEM}.start */
void F56_787 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("start", 55, Current, 0, 0, 770);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	F1147_10142(RTCW(tr1));
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {GB_BOOLEAN_TREE_ITEM}.forth */
void F56_788 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("forth", 55, Current, 0, 0, 771);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	F1147_10144(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {GB_BOOLEAN_TREE_ITEM}.item */
EIF_REFERENCE F56_789 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("item", 55, Current, 0, 0, 772);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F1147_10116(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {GB_BOOLEAN_TREE_ITEM}.off */
EIF_BOOLEAN F56_790 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("off", 55, Current, 0, 0, 773);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F940_9502(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {GB_BOOLEAN_TREE_ITEM}.extend */
void F56_791 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("extend", 55, Current, 0, 1, 774);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7993[Dtype(RTCW(tr1))-878])(tr1, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit49 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
