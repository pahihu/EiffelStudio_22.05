
#ifndef _C1_er25_
#define _C1_er25_

#ifdef __cplusplus
extern "C" {
#endif

extern void F30_423(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_BOOLEAN F30_431(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit25(void);

#ifdef __cplusplus
}
#endif

#endif
