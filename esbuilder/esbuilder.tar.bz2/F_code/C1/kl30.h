
#ifndef _C1_kl30_
#define _C1_kl30_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F35_463(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit30(void);

#ifdef __cplusplus
}
#endif

#endif
