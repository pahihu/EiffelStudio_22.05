
#ifndef _C1_ev18_
#define _C1_ev18_

#ifdef __cplusplus
extern "C" {
#endif

extern void F22_340(EIF_REFERENCE);
extern void F22_342(EIF_REFERENCE);
extern void F22_344(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit18(void);

#ifdef __cplusplus
}
#endif

#endif
