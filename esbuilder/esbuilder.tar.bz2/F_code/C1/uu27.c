/*
 * Code for class UUID_GENERATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "uu27.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UUID_GENERATOR}.generate_uuid */
EIF_REFERENCE F32_447 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("generate_uuid", 31, Current, 0, 0, 426);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1382, 0x00).id, 1382, _OBJSIZ_0_0_3_1_0_0_1_0_);
	tr1 = RTOSCF(450,F32_450, (Current));
	tr2 = RTOSCF(449,F32_449, (Current));
	tr1 = F32_448(Current, tr1, tr2);
	F1383_12754(RTCW(Result), tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {UUID_GENERATOR}.segments */
EIF_REFERENCE F32_448 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_8 tu1_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTEAA("segments", 31, Current, 2, 2, 427);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {923,1443,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 923, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F924_9406(RTCW(Result), ((EIF_NATURAL_8) 0U), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 16L));
	RTHOOK(2);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O5375[Dtype(arg1)-361]);
	RTHOOK(3);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 16L))) break;
		RTHOOK(5);
		if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 2147483647L))) {
			RTHOOK(6);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			RTHOOK(7);
			ti4_1 = F32_451(Current);
			F1015_9667(RTCW(arg2), ti4_1);
		} else {
			RTHOOK(8);
			loc2++;
		}
		RTHOOK(9);
		ti4_1 = F1015_9675(RTCW(arg2), loc2);
		tu1_1 = (EIF_NATURAL_8) ti4_1;
		F924_9430(RTCW(Result), tu1_1, loc1);
		RTHOOK(10);
		loc1++;
	}
	RTHOOK(11);
	F363_5875(RTCW(arg1), loc2);
	RTHOOK(12);
	tu1_1 = F924_9411(RTCW(Result), ((EIF_INTEGER_32) 7L));
	tu1_1 = eif_bit_and(tu1_1,(EIF_NATURAL_8) ((EIF_INTEGER_32) 15L));
	tu1_1 = eif_bit_or(tu1_1,(EIF_NATURAL_8) ((EIF_INTEGER_32) 64L));
	F924_9430(RTCW(Result), tu1_1, ((EIF_INTEGER_32) 7L));
	RTHOOK(13);
	tu1_1 = F924_9411(RTCW(Result), ((EIF_INTEGER_32) 9L));
	tu1_1 = eif_bit_and(tu1_1,(EIF_NATURAL_8) ((EIF_INTEGER_32) 63L));
	tu1_1 = eif_bit_or(tu1_1,(EIF_NATURAL_8) ((EIF_INTEGER_32) 128L));
	F924_9430(RTCW(Result), tu1_1, ((EIF_INTEGER_32) 9L));
	RTHOOK(14);
	RTLE;
	RTEE;
	return Result;
}

/* {UUID_GENERATOR}.rand */
static EIF_REFERENCE F32_449_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("rand", 31, Current, 0, 0, 428);
	RTGC;
	RTOSP (449);
#define Result RTOSR(449)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1014, 0x00).id, 1014, _OBJSIZ_0_1_0_4_0_0_0_0_);
	ti4_1 = F32_451(Current);
	F1015_9667(RTCW(tr1), ti4_1);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (449);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F32_449 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(449,F32_449_body,(Current));
}

/* {UUID_GENERATOR}.rand_count */
static EIF_REFERENCE F32_450_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("rand_count", 31, Current, 0, 0, 429);
	RTGC;
	RTOSP (450);
#define Result RTOSR(450)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {362,1425,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 362, _OBJSIZ_0_0_0_1_0_0_0_0_);
	}
	F363_5875(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (450);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F32_450 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(450,F32_450_body,(Current));
}

/* {UUID_GENERATOR}.seed */
EIF_INTEGER_32 F32_451 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_64 loc1 = (EIF_NATURAL_64) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_NATURAL_64 tu8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("seed", 31, Current, 2, 0, 430);
	RTGC;
	RTHOOK(1);
	loc2 = RTLNS(eif_new_type(22, 0x00).id, 22, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F23_345(RTCW(loc2));
	RTHOOK(2);
	ti4_1 = F23_349(RTCW(loc2));
	loc1 = (EIF_NATURAL_64) (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1970L));
	loc1 = (EIF_NATURAL_64) (EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) (loc1 * (EIF_NATURAL_64) ((EIF_INTEGER_32) 12L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 30L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 24L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 1000L));
	RTHOOK(3);
	ti4_1 = F23_350(RTCW(loc2));
	tu8_1 = (EIF_NATURAL_64) ti4_1;
	loc1 += (EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) (tu8_1 * (EIF_NATURAL_64) ((EIF_INTEGER_32) 30L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 24L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 1000L));
	RTHOOK(4);
	ti4_1 = F23_351(RTCW(loc2));
	tu8_1 = (EIF_NATURAL_64) ti4_1;
	loc1 += (EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) (tu8_1 * (EIF_NATURAL_64) ((EIF_INTEGER_32) 24L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 1000L));
	RTHOOK(5);
	ti4_1 = F23_352(RTCW(loc2));
	tu8_1 = (EIF_NATURAL_64) ti4_1;
	loc1 += (EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) (tu8_1 * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 1000L));
	RTHOOK(6);
	ti4_1 = F23_353(RTCW(loc2));
	tu8_1 = (EIF_NATURAL_64) ti4_1;
	loc1 += (EIF_NATURAL_64) ((EIF_NATURAL_64) (tu8_1 * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 1000L));
	RTHOOK(7);
	ti4_1 = F23_354(RTCW(loc2));
	tu8_1 = (EIF_NATURAL_64) ti4_1;
	loc1 += (EIF_NATURAL_64) (tu8_1 * (EIF_NATURAL_64) ((EIF_INTEGER_32) 1000L));
	RTHOOK(8);
	ti4_1 = F23_355(RTCW(loc2));
	tu8_1 = (EIF_NATURAL_64) ti4_1;
	loc1 += tu8_1;
	RTHOOK(9);
	tu8_1 = eif_bit_shift_right(loc1,((EIF_INTEGER_32) 32L));
	tu8_1 = eif_bit_xor(tu8_1,loc1);
	ti4_1 = (EIF_INTEGER_32) tu8_1;
	Result = eif_bit_and(ti4_1,((EIF_INTEGER_32) 2147483647L));
	RTHOOK(10);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit27 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
