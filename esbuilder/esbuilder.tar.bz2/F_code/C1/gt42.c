/*
 * Code for class GTK_ALIGN
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gt42.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F49_558
static EIF_INTEGER_32 inline_F49_558 (void)
{
	return GTK_ALIGN_START
	;
}
#define INLINE_F49_558
#endif
#ifndef INLINE_F49_559
static EIF_INTEGER_32 inline_F49_559 (void)
{
	return GTK_ALIGN_END
	;
}
#define INLINE_F49_559
#endif
#ifndef INLINE_F49_560
static EIF_INTEGER_32 inline_F49_560 (void)
{
	return GTK_ALIGN_CENTER
	;
}
#define INLINE_F49_560
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GTK_ALIGN}.gtk_align_start */
EIF_INTEGER_32 F49_558 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_align_start", 48, Current, 0, 0, 538);
	Result = inline_F49_558 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK_ALIGN}.gtk_align_end */
EIF_INTEGER_32 F49_559 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_align_end", 48, Current, 0, 0, 539);
	Result = inline_F49_559 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {GTK_ALIGN}.gtk_align_center */
EIF_INTEGER_32 F49_560 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_align_center", 48, Current, 0, 0, 540);
	Result = inline_F49_560 ();
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit42 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
