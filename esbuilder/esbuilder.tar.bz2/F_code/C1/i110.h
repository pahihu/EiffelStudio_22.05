
#ifndef _C1_i110_
#define _C1_i110_

#ifdef __cplusplus
extern "C" {
#endif

extern void F10_99(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit10(void);
extern void F146_2088(EIF_REFERENCE, EIF_REFERENCE);
extern long O1963[];
extern long O1964[];

#ifdef __cplusplus
}
#endif

#endif
