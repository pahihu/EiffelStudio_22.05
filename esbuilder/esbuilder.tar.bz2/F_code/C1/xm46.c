/*
 * Code for class XML_NAMESPACE_RESOLVER_CONTEXT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm46.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.make */
void F53_756 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 52, Current, 0, 0, 738);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {989,1135,1507,1509,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F990_9546(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.reset */
void F53_757 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("reset", 52, Current, 0, 0, 739);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R7997[Dtype(RTCW(tr1))-878])(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.add_default */
void F53_758 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("add_default", 52, Current, 0, 1, 740);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(770,F53_770, (Current));
	F53_759(Current, arg1, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.add */
void F53_759 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("add", 52, Current, 0, 2, 741);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = F990_9549(RTCW(tr1));
	tr2 = F53_767(Current, arg2);
	F1136_10027(RTCW(tr1), arg1, tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.shallow_has */
EIF_BOOLEAN F53_761 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("shallow_has", 52, Current, 0, 1, 743);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O8167[Dtype(tr1)-989]);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = F990_9549(RTCW(tr1));
		tr2 = F53_767(Current, arg1);
		tb1 = F1136_9988(RTCW(tr1), tr2);
		Result = tb1;
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.has */
EIF_BOOLEAN F53_762 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTEAA("has", 52, Current, 2, 1, 744);
	RTGC;
	RTHOOK(1);
	loc1 = F53_767(Current, arg1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7815[Dtype(RTCW(tr1))-668])(tr1);
	tb1 = EIF_FALSE;
	for (;;) {
		if (tb1) break;
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8184[Dtype(loc2)-1011])(loc2);
		if (tb2) break;
		RTHOOK(3);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8183[Dtype(loc2)-1011])(loc2);
		tb3 = F1136_9988(RTCW(tr1), loc1);
		tb1 = tb3;
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R8185[Dtype(loc2)-1011])(loc2);
	}
	Result = (EIF_BOOLEAN) tb1;
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.resolve_default */
EIF_REFERENCE F53_763 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("resolve_default", 52, Current, 0, 0, 745);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(770,F53_770, (Current));
	Result = F53_764(Current, tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.resolve */
EIF_REFERENCE F53_764 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc3);
	RTLR(3,arg1);
	RTLR(4,loc4);
	RTLR(5,tr1);
	RTLR(6,loc1);
	RTLR(7,loc5);
	RTLIU(8);
	
	RTEAA("resolve", 52, Current, 5, 1, 746);
	RTGC;
	RTHOOK(1);
	Result = RTOSCF(771,F53_771, (Current));
	RTHOOK(2);
	loc3 = F53_767(Current, arg1);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7815[Dtype(RTCW(tr1))-668])(tr1);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8184[Dtype(loc4)-1011])(loc4);
		if (tb1) break;
		RTHOOK(4);
		if (loc2) break;
		RTHOOK(5);
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8183[Dtype(loc4)-1011])(loc4);
		RTHOOK(6);
		tb2 = '\0';
		tb3 = F1136_9988(RTCW(loc1), loc3);
		if (tb3) {
			tr1 = F1136_9986(RTCW(loc1), loc3);
			loc5 = tr1;
			tb2 = EIF_TEST(loc5);
		}
		if (tb2) {
			RTHOOK(7);
			Result = (EIF_REFERENCE) loc5;
			RTHOOK(8);
			loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		RTHOOK(9);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R8185[Dtype(loc4)-1011])(loc4);
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.push */
void F53_765 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("push", 52, Current, 0, 0, 747);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = F53_769(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8140[Dtype(RTCW(tr1))-989])(tr1, tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.pop */
void F53_766 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("pop", 52, Current, 0, 0, 748);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O8167[Dtype(tr1)-989]);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current);
		F990_9565(RTCW(tr1));
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R8012[Dtype(RTCW(tr1))-878])(tr1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.to_context_key */
EIF_REFERENCE F53_767 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	
	
	RTEAA("to_context_key", 52, Current, 0, 1, 749);
	RTHOOK(1);
	tr1 = F1500_14215(RTCW(arg1));
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.new_string_string_table */
EIF_REFERENCE F53_769 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("new_string_string_table", 52, Current, 0, 0, 751);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1135,1507,1509,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1135, _OBJSIZ_7_3_0_7_0_0_0_0_);
	}
	F1136_9980(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.default_pseudo_prefix */

EIF_REFERENCE F53_770 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (770,RTMS32_EX_H("",0,0));
}

/* {XML_NAMESPACE_RESOLVER_CONTEXT}.default_namespace */

EIF_REFERENCE F53_771 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (771,RTMS32_EX_H("",0,0));
}

void EIF_Minit46 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
