/*
 * Code for class CAIRO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ca44.h"
#include <ev_gtk.h>
#include <cairo.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F51_658
static EIF_NATURAL_32 inline_F51_658 (EIF_POINTER arg1)
{
	return (EIF_NATURAL_32) (cairo_get_reference_count((cairo_t*) arg1))
	;
}
#define INLINE_F51_658
#endif
#ifndef INLINE_F51_664
static void inline_F51_664 (EIF_POINTER arg1)
{
	cairo_surface_destroy((cairo_surface_t*) arg1)
	;
}
#define INLINE_F51_664
#endif
#ifndef INLINE_F51_707
static void inline_F51_707 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	double len = 2.0;
if (arg2) {
	cairo_set_dash ((cairo_t *) arg1, &len, 1, 0.0);
} else {
	cairo_set_dash ((cairo_t *) arg1, NULL, 0, 0.0);
}
	;
}
#define INLINE_F51_707
#endif
#ifndef INLINE_F51_718
static int inline_F51_718 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	return  cairo_region_equal ((const cairo_region_t *)arg1, (const cairo_region_t *)arg2);
	;
}
#define INLINE_F51_718
#endif
#ifndef INLINE_F51_719
static EIF_POINTER inline_F51_719 (EIF_POINTER arg1)
{
	return  cairo_region_copy ((const cairo_region_t *)arg1);
	;
}
#define INLINE_F51_719
#endif
#ifndef INLINE_F51_722
static void inline_F51_722 (EIF_POINTER arg1)
{
	cairo_paint ((cairo_t*)arg1)
	;
}
#define INLINE_F51_722
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CAIRO}.operator_source */
EIF_INTEGER_8 F51_641 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("operator_source", 50, Current, 0, 0, 719);
	Result = (EIF_INTEGER_8) CAIRO_OPERATOR_SOURCE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.operator_over */
EIF_INTEGER_8 F51_642 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("operator_over", 50, Current, 0, 0, 720);
	Result = (EIF_INTEGER_8) CAIRO_OPERATOR_OVER;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.operator_atop */
EIF_INTEGER_8 F51_647 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("operator_atop", 50, Current, 0, 0, 725);
	Result = (EIF_INTEGER_8) CAIRO_OPERATOR_ATOP;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.operator_difference */
EIF_INTEGER_8 F51_653 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("operator_difference", 50, Current, 0, 0, 606);
	Result = (EIF_INTEGER_8) CAIRO_OPERATOR_DIFFERENCE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.operator_exclusion */
EIF_INTEGER_8 F51_654 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("operator_exclusion", 50, Current, 0, 0, 607);
	Result = (EIF_INTEGER_8) CAIRO_OPERATOR_EXCLUSION;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.operator_multiply */
EIF_INTEGER_8 F51_655 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("operator_multiply", 50, Current, 0, 0, 608);
	Result = (EIF_INTEGER_8) CAIRO_OPERATOR_MULTIPLY;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.create_context */
EIF_POINTER F51_656 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("create_context", 50, Current, 0, 1, 609);Result = (EIF_POINTER) cairo_create((cairo_surface_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.get_reference_count */
EIF_NATURAL_32 F51_658 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("get_reference_count", 50, Current, 0, 1, 611);
	Result = inline_F51_658 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.destroy */
void F51_659 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("destroy", 50, Current, 0, 1, 612);cairo_destroy((cairo_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.set_source_surface */
void F51_663 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_source_surface", 50, Current, 0, 4, 616);cairo_set_source_surface((cairo_t*) arg1, (cairo_surface_t*) arg2, (double) arg3, (double) arg4);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.surface_destroy */
void F51_664 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("surface_destroy", 50, Current, 0, 1, 617);
	inline_F51_664 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.surface_flush */
void F51_667 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("surface_flush", 50, Current, 0, 1, 620);cairo_surface_flush((cairo_surface_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.image_surface_create */
EIF_POINTER F51_681 (EIF_REFERENCE Current, EIF_INTEGER_8 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("image_surface_create", 50, Current, 0, 3, 634);Result = (EIF_POINTER) cairo_image_surface_create((cairo_format_t) arg1, (int) arg2, (int) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.image_surface_get_width */
EIF_INTEGER_32 F51_685 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("image_surface_get_width", 50, Current, 0, 1, 638);Result = (EIF_INTEGER_32) cairo_image_surface_get_width((cairo_surface_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.image_surface_get_height */
EIF_INTEGER_32 F51_686 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("image_surface_get_height", 50, Current, 0, 1, 639);Result = (EIF_INTEGER_32) cairo_image_surface_get_height((cairo_surface_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.clip */
void F51_687 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("clip", 50, Current, 0, 1, 640);cairo_clip((cairo_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.reset_clip */
void F51_688 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("reset_clip", 50, Current, 0, 1, 641);cairo_reset_clip((cairo_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.clip_extents */
void F51_689 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64* arg2, EIF_REAL_64* arg3, EIF_REAL_64* arg4, EIF_REAL_64* arg5)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("clip_extents", 50, Current, 0, 5, 642);cairo_clip_extents((cairo_t*) arg1, (double*) arg2, (double*) arg3, (double*) arg4, (double*) arg5);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.save */
void F51_699 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("save", 50, Current, 0, 1, 652);cairo_save((cairo_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.restore */
void F51_700 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("restore", 50, Current, 0, 1, 653);cairo_restore((cairo_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.set_operator */
void F51_705 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_8 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_operator", 50, Current, 0, 2, 658);cairo_set_operator((cairo_t*) arg1, (cairo_operator_t) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.set_antialias */
void F51_706 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_8 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_antialias", 50, Current, 0, 2, 659);cairo_set_antialias((cairo_t*) arg1, (cairo_antialias_t) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.set_dashed_line_style */
void F51_707 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_dashed_line_style", 50, Current, 0, 2, 660);
	inline_F51_707 ((EIF_POINTER) arg1, (EIF_BOOLEAN) arg2);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.fill */
void F51_710 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("fill", 50, Current, 0, 1, 663);
	RTHOOK(1);
	cairo_fill((cairo_t*) arg1);
	RTHOOK(2);
	RTEE;
}

/* {CAIRO}.cairo_fill */
void F51_711 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("cairo_fill", 50, Current, 0, 1, 664);cairo_fill((cairo_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.translate */
void F51_713 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("translate", 50, Current, 0, 3, 666);cairo_translate((cairo_t*) arg1, (double) arg2, (double) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.cairo_equal */
EIF_BOOLEAN F51_718 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("cairo_equal", 50, Current, 0, 2, 671);
	Result = EIF_TEST(inline_F51_718 ((EIF_POINTER) arg1, (EIF_POINTER) arg2));
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.cairo_copy */
EIF_POINTER F51_719 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("cairo_copy", 50, Current, 0, 1, 672);
	Result = inline_F51_719 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {CAIRO}.scale */
void F51_720 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("scale", 50, Current, 0, 3, 673);cairo_scale((cairo_t*) arg1, (double) arg2, (double) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.rotate */
void F51_721 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("rotate", 50, Current, 0, 2, 674);cairo_rotate((cairo_t*) arg1, (double) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.paint */
void F51_722 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("paint", 50, Current, 0, 1, 675);
	inline_F51_722 ((EIF_POINTER) arg1);
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.stroke */
void F51_723 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("stroke", 50, Current, 0, 1, 676);cairo_stroke((cairo_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.stroke_preserve */
void F51_724 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("stroke_preserve", 50, Current, 0, 1, 677);cairo_stroke_preserve((cairo_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.move_to */
void F51_725 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("move_to", 50, Current, 0, 3, 678);cairo_move_to((cairo_t*) arg1, (double) arg2, (double) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.line_to */
void F51_726 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("line_to", 50, Current, 0, 3, 679);cairo_line_to((cairo_t*) arg1, (double) arg2, (double) arg3);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.rectangle */
void F51_727 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("rectangle", 50, Current, 0, 5, 680);cairo_rectangle((cairo_t*) arg1, (double) arg2, (double) arg3, (double) arg4, (double) arg5);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.set_source_rgba */
void F51_728 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_source_rgba", 50, Current, 0, 5, 681);cairo_set_source_rgba((cairo_t*) arg1, (double) arg2, (double) arg3, (double) arg4, (double) arg5);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.set_source_rgb */
void F51_729 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_source_rgb", 50, Current, 0, 4, 682);cairo_set_source_rgb((cairo_t*) arg1, (double) arg2, (double) arg3, (double) arg4);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.arc_negative */
void F51_732 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("arc_negative", 50, Current, 0, 6, 685);cairo_arc_negative((cairo_t*) arg1, (double) arg2, (double) arg3, (double) arg4, (double) arg5, (double) arg6);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.set_line_width */
void F51_733 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_line_width", 50, Current, 0, 2, 686);cairo_set_line_width((cairo_t*) arg1, (double) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.set_line_cap */
void F51_734 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_8 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_line_cap", 50, Current, 0, 2, 687);cairo_set_line_cap((cairo_t*) arg1, (cairo_line_cap_t) arg2);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.close_path */
void F51_739 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("close_path", 50, Current, 0, 1, 692);cairo_close_path((cairo_t*) arg1);
	
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {CAIRO}.cairo_content_color_alpha */
EIF_INTEGER_32 F51_748 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("cairo_content_color_alpha", 50, Current, 0, 0, 701);
	Result = (EIF_INTEGER_32) CAIRO_CONTENT_COLOR_ALPHA;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit44 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
