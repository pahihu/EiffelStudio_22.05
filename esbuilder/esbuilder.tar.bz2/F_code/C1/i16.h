
#ifndef _C1_i16_
#define _C1_i16_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F6_77(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit6(void);
extern void F144_2062(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
