
#ifndef _C1_ev20_
#define _C1_ev20_

#ifdef __cplusplus
extern "C" {
#endif

extern void F25_387(EIF_REFERENCE, EIF_INTEGER_32);
extern void F25_388(EIF_REFERENCE, EIF_INTEGER_32);
extern void F25_389(EIF_REFERENCE, EIF_INTEGER_32);
extern void F25_390(EIF_REFERENCE, EIF_INTEGER_32);
extern void F25_391(EIF_REFERENCE, EIF_INTEGER_32);
extern void F25_392(EIF_REFERENCE, EIF_INTEGER_32);
extern void F25_393(EIF_REFERENCE, EIF_INTEGER_32);
extern void F25_394(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit20(void);

#ifdef __cplusplus
}
#endif

#endif
