
#ifndef _C1_gt42_
#define _C1_gt42_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F49_558(EIF_REFERENCE);
extern EIF_INTEGER_32 F49_559(EIF_REFERENCE);
extern EIF_INTEGER_32 F49_560(EIF_REFERENCE);
extern void EIF_Minit42(void);

#ifdef __cplusplus
}
#endif

#endif
