
#ifndef _C1_co38_
#define _C1_co38_

#ifdef __cplusplus
extern "C" {
#endif

extern void F44_501(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit38(void);

#ifdef __cplusplus
}
#endif

#endif
