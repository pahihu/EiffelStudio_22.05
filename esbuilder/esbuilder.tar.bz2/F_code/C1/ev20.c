/*
 * Code for class EV_GRID_LABEL_ITEM_LAYOUT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev20.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GRID_LABEL_ITEM_LAYOUT}.set_pixmap_x */
void F25_387 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_pixmap_x", 24, Current, 0, 1, 385);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_0_) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {EV_GRID_LABEL_ITEM_LAYOUT}.set_pixmap_y */
void F25_388 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_pixmap_y", 24, Current, 0, 1, 386);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_1_) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {EV_GRID_LABEL_ITEM_LAYOUT}.set_text_x */
void F25_389 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_text_x", 24, Current, 0, 1, 387);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_4_) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {EV_GRID_LABEL_ITEM_LAYOUT}.set_text_y */
void F25_390 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_text_y", 24, Current, 0, 1, 388);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_5_) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {EV_GRID_LABEL_ITEM_LAYOUT}.set_available_text_width */
void F25_391 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_available_text_width", 24, Current, 0, 1, 389);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_6_) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {EV_GRID_LABEL_ITEM_LAYOUT}.set_checkbox_x */
void F25_392 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_checkbox_x", 24, Current, 0, 1, 390);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_2_) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {EV_GRID_LABEL_ITEM_LAYOUT}.set_checkbox_y */
void F25_393 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_checkbox_y", 24, Current, 0, 1, 391);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_3_) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {EV_GRID_LABEL_ITEM_LAYOUT}.set_has_text_pixmap_overlapping */
void F25_394 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_has_text_pixmap_overlapping", 24, Current, 0, 1, 392);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_0_0_) = (EIF_BOOLEAN) arg1;
	RTHOOK(3);
	RTEE;
}

void EIF_Minit20 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
