
#ifndef _C1_su34_
#define _C1_su34_

#ifdef __cplusplus
extern "C" {
#endif

extern void F40_480(EIF_REFERENCE, EIF_REFERENCE);
extern void F40_481(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit34(void);
extern void F2010_22715(EIF_REFERENCE, EIF_INTEGER_32);
extern void F2010_22731(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
