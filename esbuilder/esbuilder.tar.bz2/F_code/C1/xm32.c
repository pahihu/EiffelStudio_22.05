/*
 * Code for class XML_UTILITIES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm32.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XML_UTILITIES}.escaped_xml */
EIF_REFERENCE F37_471 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("escaped_xml", 36, Current, 0, 1, 451);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(474,F37_474, (Current));
	Result = F2009_22709(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_UTILITIES}.escaped_unicode_xml */
EIF_REFERENCE F37_472 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("escaped_unicode_xml", 36, Current, 0, 1, 452);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(474,F37_474, (Current));
	Result = F2009_22710(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_UTILITIES}.xml_encoder */
static EIF_REFERENCE F37_474_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("xml_encoder", 36, Current, 0, 0, 454);
	RTGC;
	RTOSP (474);
#define Result RTOSR(474)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(2008, 0x00).id, 2008, _OBJSIZ_0_1_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (474);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F37_474 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(474,F37_474_body,(Current));
}

void EIF_Minit32 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
