/*
 * Code for class MANAGED_SHORTCUT_GROUP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ma11.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {MANAGED_SHORTCUT_GROUP}.key_combination */
EIF_REFERENCE F12_113 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN arg3, EIF_BOOLEAN arg4)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTEAA("key_combination", 11, Current, 1, 4, 113);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current);
		loc1 = F1147_10122(RTCW(tr1));
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current);
		F1147_10142(RTCW(tr1));
		for (;;) {
			RTHOOK(4);
			tb1 = '\01';
			tr1 = *(EIF_REFERENCE *)(Current);
			tb2 = F964_9526(RTCW(tr1));
			if (!tb2) {
				tb1 = (EIF_BOOLEAN)(Result != NULL);
			}
			if (tb1) break;
			RTHOOK(5);
			tr1 = *(EIF_REFERENCE *)(Current);
			tr1 = F1147_10116(RTCW(tr1));
			tb2 = F177_2350(RTCW(tr1), arg1, arg2, arg3, arg4);
			if (tb2) {
				RTHOOK(6);
				tr1 = *(EIF_REFERENCE *)(Current);
				Result = F1147_10116(RTCW(tr1));
			}
			RTHOOK(7);
			tr1 = *(EIF_REFERENCE *)(Current);
			F1147_10144(RTCW(tr1));
		}
		RTHOOK(8);
		tr1 = *(EIF_REFERENCE *)(Current);
		F1147_10147(RTCW(tr1), loc1);
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit11 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
