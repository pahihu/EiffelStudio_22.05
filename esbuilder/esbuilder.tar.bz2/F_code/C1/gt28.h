
#ifndef _C1_gt28_
#define _C1_gt28_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F33_452(EIF_REFERENCE);
extern EIF_BOOLEAN F33_453(EIF_REFERENCE, EIF_POINTER, EIF_POINTER, EIF_INTEGER_32, EIF_POINTER*);
extern void EIF_Minit28(void);

#ifdef __cplusplus
}
#endif

#endif
