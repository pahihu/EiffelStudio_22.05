
#ifndef _C1_ev26_
#define _C1_ev26_

#ifdef __cplusplus
extern "C" {
#endif

extern void F31_437(EIF_REFERENCE);
extern void F31_438(EIF_REFERENCE);
extern void F31_439(EIF_REFERENCE);
extern EIF_BOOLEAN F31_440(EIF_REFERENCE);
extern EIF_BOOLEAN F31_441(EIF_REFERENCE);
extern void EIF_Minit26(void);

#ifdef __cplusplus
}
#endif

#endif
