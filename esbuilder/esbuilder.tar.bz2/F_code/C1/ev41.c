/*
 * Code for class EV_GTK_ENUMS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev41.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GTK_ENUMS}.gdk_expose_enum */
EIF_INTEGER_32 F48_531 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_expose_enum", 47, Current, 0, 0, 512);
	Result = (EIF_INTEGER_32) GDK_EXPOSE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_motion_notify_enum */
EIF_INTEGER_32 F48_532 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_motion_notify_enum", 47, Current, 0, 0, 513);
	Result = (EIF_INTEGER_32) GDK_MOTION_NOTIFY;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_button_press_enum */
EIF_INTEGER_32 F48_533 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_button_press_enum", 47, Current, 0, 0, 514);
	Result = (EIF_INTEGER_32) GDK_BUTTON_PRESS;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_2button_press_enum */
EIF_INTEGER_32 F48_534 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_2button_press_enum", 47, Current, 0, 0, 515);
	Result = (EIF_INTEGER_32) GDK_2BUTTON_PRESS;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_button_release_enum */
EIF_INTEGER_32 F48_536 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_button_release_enum", 47, Current, 0, 0, 517);
	Result = (EIF_INTEGER_32) GDK_BUTTON_RELEASE;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_watch_enum */
EIF_INTEGER_32 F48_547 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_watch_enum", 47, Current, 0, 0, 528);
	Result = (EIF_INTEGER_32) GDK_WATCH;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_xterm_enum */
EIF_INTEGER_32 F48_548 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_xterm_enum", 47, Current, 0, 0, 529);
	Result = (EIF_INTEGER_32) GDK_XTERM;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_crosshair_enum */
EIF_INTEGER_32 F48_549 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_crosshair_enum", 47, Current, 0, 0, 530);
	Result = (EIF_INTEGER_32) GDK_CROSSHAIR;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_question_arrow_enum */
EIF_INTEGER_32 F48_550 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_question_arrow_enum", 47, Current, 0, 0, 531);
	Result = (EIF_INTEGER_32) GDK_QUESTION_ARROW;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_left_ptr_enum */
EIF_INTEGER_32 F48_551 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_left_ptr_enum", 47, Current, 0, 0, 532);
	Result = (EIF_INTEGER_32) GDK_LEFT_PTR;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_fleur_enum */
EIF_INTEGER_32 F48_552 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_fleur_enum", 47, Current, 0, 0, 533);
	Result = (EIF_INTEGER_32) GDK_FLEUR;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_size_sb_v_double_arrow_enum */
EIF_INTEGER_32 F48_553 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_size_sb_v_double_arrow_enum", 47, Current, 0, 0, 534);
	Result = (EIF_INTEGER_32) GDK_SB_V_DOUBLE_ARROW;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_hand2_enum */
EIF_INTEGER_32 F48_554 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_hand2_enum", 47, Current, 0, 0, 535);
	Result = (EIF_INTEGER_32) GDK_HAND2;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_ENUMS}.gtk_style_provider_priority_application */
EIF_NATURAL_32 F48_555 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_style_provider_priority_application", 47, Current, 0, 0, 536);
	Result = (EIF_NATURAL_32) GTK_STYLE_PROVIDER_PRIORITY_APPLICATION;
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit41 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
