
#ifndef _C7_in308_
#define _C7_in308_

#ifdef __cplusplus
extern "C" {
#endif

extern void F354_5755(EIF_REFERENCE);
extern EIF_BOOLEAN F354_5756(EIF_REFERENCE, EIF_NATURAL_64, EIF_NATURAL_64, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit308(void);
extern void F1259_11871(EIF_REFERENCE, EIF_NATURAL_64);

#ifdef __cplusplus
}
#endif

#endif
