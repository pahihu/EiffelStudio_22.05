
#ifndef _C7_xm347_
#define _C7_xm347_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F405_6303(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit347(void);

#ifdef __cplusplus
}
#endif

#endif
