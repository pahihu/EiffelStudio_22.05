/*
 * Code for class YY_UNICODE_BUFFER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "yy329.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {YY_UNICODE_BUFFER}.make_from_utf8_string */
void F387_6028 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,loc2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("make_from_utf8_string", 386, Current, 2, 1, 5862);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	RTHOOK(2);
	loc2 = F387_6032(Current, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)));
	RTHOOK(3);
	loc1 = F654_8950(RTCW(loc2), arg1, ((EIF_INTEGER_32) 1L));
	RTHOOK(4);
	F654_8942(RTCW(loc2), (EIF_CHARACTER_8) '\000', (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
	RTHOOK(5);
	F654_8942(RTCW(loc2), (EIF_CHARACTER_8) '\000', (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)));
	RTHOOK(6);
	F385_5998(Current, loc2);
	RTHOOK(7);
	*(EIF_INTEGER_32 *)(Current + O5461[Dtype(Current)-384]) = (EIF_INTEGER_32) loc1;
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {YY_UNICODE_BUFFER}.new_default_buffer */
EIF_REFERENCE F387_6032 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("new_default_buffer", 386, Current, 0, 1, 5866);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_final_id(Y5460,Y5460_gen_type,Dftype(Current),384).id);
	F654_8927(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

void EIF_Minit329 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
