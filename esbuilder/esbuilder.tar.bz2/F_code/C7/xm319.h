
#ifndef _C7_xm319_
#define _C7_xm319_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F377_5931(EIF_REFERENCE);
extern void F377_5932(EIF_REFERENCE);
extern void F377_5935(EIF_REFERENCE, EIF_REFERENCE);
extern void F377_5936(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit319(void);
extern void F1510_14566(EIF_REFERENCE, EIF_REFERENCE);
extern void F1510_14565(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
