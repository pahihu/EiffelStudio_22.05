/*
 * Code for class XML_CHARACTER_8_INPUT_STREAM_UTF8_FILTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm343.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XML_CHARACTER_8_INPUT_STREAM_UTF8_FILTER}.make */
void F401_6243 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("make", 400, Current, 0, 1, 6056);
	RTHOOK(1);
	F400_6233(Current, arg1);
	RTHOOK(2);
	RTEE;
}

/* {XML_CHARACTER_8_INPUT_STREAM_UTF8_FILTER}.last_character_code */
EIF_NATURAL_32 F401_6244 (EIF_REFERENCE Current)
{
	return *(EIF_NATURAL_32 *)(Current+ _LNGOFF_1_0_0_0_);
}


/* {XML_CHARACTER_8_INPUT_STREAM_UTF8_FILTER}.read_character_code */
void F401_6245 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc2 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc3 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc4 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("read_character_code", 400, Current, 4, 0, 6058);
	RTGC;
	RTHOOK(1);
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_1_0_0_0_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(2);
	loc1 = F401_6246(Current);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5634[Dtype(RTCW(tr1))-398])(tr1);
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 127L))) {
			RTHOOK(5);
			*(EIF_NATURAL_32 *)(Current+ _LNGOFF_1_0_0_0_) = (EIF_NATURAL_32) loc1;
		} else {
			RTHOOK(6);
			if ((EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 223L))) {
				RTHOOK(7);
				loc2 = F401_6246(Current);
				RTHOOK(8);
				tr1 = *(EIF_REFERENCE *)(Current);
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5634[Dtype(RTCW(tr1))-398])(tr1);
				if ((EIF_BOOLEAN) !tb1) {
					RTHOOK(9);
					tu4_1 = eif_bit_and(loc1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 31L));
					tu4_1 = eif_bit_shift_left(tu4_1,((EIF_INTEGER_32) 6L));
					tu4_2 = eif_bit_and(loc2,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
					tu4_1 = eif_bit_or(tu4_1,tu4_2);
					*(EIF_NATURAL_32 *)(Current+ _LNGOFF_1_0_0_0_) = (EIF_NATURAL_32) tu4_1;
				}
			} else {
				RTHOOK(10);
				if ((EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 239L))) {
					RTHOOK(11);
					loc2 = F401_6246(Current);
					RTHOOK(12);
					tr1 = *(EIF_REFERENCE *)(Current);
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5634[Dtype(RTCW(tr1))-398])(tr1);
					if ((EIF_BOOLEAN) !tb1) {
						RTHOOK(13);
						loc3 = F401_6246(Current);
						RTHOOK(14);
						tr1 = *(EIF_REFERENCE *)(Current);
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5634[Dtype(RTCW(tr1))-398])(tr1);
						if ((EIF_BOOLEAN) !tb1) {
							RTHOOK(15);
							tu4_1 = eif_bit_and(loc1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 15L));
							tu4_1 = eif_bit_shift_left(tu4_1,((EIF_INTEGER_32) 12L));
							tu4_2 = eif_bit_and(loc2,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
							tu4_2 = eif_bit_shift_left(tu4_2,((EIF_INTEGER_32) 6L));
							tu4_1 = eif_bit_or(tu4_1,tu4_2);
							tu4_2 = eif_bit_and(loc3,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
							tu4_1 = eif_bit_or(tu4_1,tu4_2);
							*(EIF_NATURAL_32 *)(Current+ _LNGOFF_1_0_0_0_) = (EIF_NATURAL_32) tu4_1;
						}
					}
				} else {
					RTHOOK(16);
					if ((EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 247L))) {
						RTHOOK(17);
						loc2 = F401_6246(Current);
						RTHOOK(18);
						tr1 = *(EIF_REFERENCE *)(Current);
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5634[Dtype(RTCW(tr1))-398])(tr1);
						if ((EIF_BOOLEAN) !tb1) {
							RTHOOK(19);
							loc3 = F401_6246(Current);
							RTHOOK(20);
							tr1 = *(EIF_REFERENCE *)(Current);
							tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5634[Dtype(RTCW(tr1))-398])(tr1);
							if ((EIF_BOOLEAN) !tb1) {
								RTHOOK(21);
								loc4 = F401_6246(Current);
								RTHOOK(22);
								tr1 = *(EIF_REFERENCE *)(Current);
								tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5634[Dtype(RTCW(tr1))-398])(tr1);
								if ((EIF_BOOLEAN) !tb1) {
									RTHOOK(23);
									tu4_1 = eif_bit_and(loc1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 7L));
									tu4_1 = eif_bit_shift_left(tu4_1,((EIF_INTEGER_32) 18L));
									tu4_2 = eif_bit_and(loc2,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
									tu4_2 = eif_bit_shift_left(tu4_2,((EIF_INTEGER_32) 12L));
									tu4_1 = eif_bit_or(tu4_1,tu4_2);
									tu4_2 = eif_bit_and(loc3,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
									tu4_2 = eif_bit_shift_left(tu4_2,((EIF_INTEGER_32) 6L));
									tu4_1 = eif_bit_or(tu4_1,tu4_2);
									tu4_2 = eif_bit_and(loc4,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
									tu4_1 = eif_bit_or(tu4_1,tu4_2);
									*(EIF_NATURAL_32 *)(Current+ _LNGOFF_1_0_0_0_) = (EIF_NATURAL_32) tu4_1;
								}
							}
						}
					}
				}
			}
		}
	}
	RTHOOK(24);
	RTLE;
	RTEE;
}

/* {XML_CHARACTER_8_INPUT_STREAM_UTF8_FILTER}.source_next_character_code */
EIF_NATURAL_32 F401_6246 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("source_next_character_code", 400, Current, 0, 0, 6059);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	F402_6249(RTCW(tr1));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F402_6247(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit343 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
