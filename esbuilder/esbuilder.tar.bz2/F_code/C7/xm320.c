/*
 * Code for class XML_CHARACTER_8_OUTPUT_STREAM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm320.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XML_CHARACTER_8_OUTPUT_STREAM}.put_string_32 */
void F378_5938 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("put_string_32", 377, Current, 0, 1, 5774);
	RTGC;
	RTHOOK(1);
	tb1 = F1508_14483(RTCW(arg1));
	if (tb1) {
		RTHOOK(2);
		tr1 = F1500_14208(RTCW(arg1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5395[Dtype(Current)-375])(Current, tr1);
	} else {
		
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {XML_CHARACTER_8_OUTPUT_STREAM}.put_string_32_escaped */
void F378_5939 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("put_string_32_escaped", 377, Current, 0, 1, 5775);
	RTGC;
	RTHOOK(1);
	tr1 = F375_5916(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5395[Dtype(Current)-375])(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit320 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
