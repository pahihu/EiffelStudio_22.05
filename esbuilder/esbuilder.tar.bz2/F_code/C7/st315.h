
#ifndef _C7_st315_
#define _C7_st315_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F361_5871(EIF_REFERENCE);
extern EIF_INTEGER_32 F361_5872(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit315(void);
extern char *(*R11486[])();
extern char *(*R11449[])();
extern char *(*R11682[])();

#ifdef __cplusplus
}
#endif

#endif
