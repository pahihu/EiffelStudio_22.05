
#ifndef _C7_xm349_
#define _C7_xm349_

#ifdef __cplusplus
extern "C" {
#endif

extern void F407_6321(EIF_REFERENCE, EIF_REFERENCE);
extern void F407_6322(EIF_REFERENCE);
extern void F407_6323(EIF_REFERENCE);
extern void F407_6324(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN);
extern void F407_6325(EIF_REFERENCE, EIF_REFERENCE);
extern void F407_6326(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F407_6327(EIF_REFERENCE, EIF_REFERENCE);
extern void F407_6328(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F407_6329(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F407_6330(EIF_REFERENCE);
extern void F407_6331(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F407_6332(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit349(void);
extern char *(*R5701[])();
extern char *(*R5702[])();
extern char *(*R5703[])();
extern char *(*R5704[])();
extern char *(*R5705[])();
extern char *(*R5706[])();
extern char *(*R5707[])();
extern char *(*R5708[])();
extern char *(*R5709[])();
extern char *(*R5710[])();
extern char *(*R5711[])();
extern long O5717[];

#ifdef __cplusplus
}
#endif

#endif
