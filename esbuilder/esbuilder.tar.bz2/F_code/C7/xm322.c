/*
 * Code for class XML_STRING_8_OUTPUT_STREAM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm322.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XML_STRING_8_OUTPUT_STREAM}.is_open_write */
EIF_BOOLEAN F380_5954 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {XML_STRING_8_OUTPUT_STREAM}.flush */
void F380_5955 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("flush", 379, Current, 0, 0, 5791);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XML_STRING_8_OUTPUT_STREAM}.put_string_8 */
void F380_5957 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("put_string_8", 379, Current, 0, 1, 5793);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11633[Dtype(RTCW(tr1))-1504])(tr1, arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit322 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
