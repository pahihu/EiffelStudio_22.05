/*
 * Code for class XML_STANDARD_PARSER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm338.h"
#include <ctype.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XML_STANDARD_PARSER}.make */
void F396_6103 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 395, Current, 0, 0, 5926);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(476, 0x00).id, 476, _OBJSIZ_1_0_0_0_0_0_0_0_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTOSCF(6178,F396_6178, (Current));
	F396_6126(Current, tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.parse_from_stream */
void F396_6104 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("parse_from_stream", 395, Current, 0, 1, 5927);
	RTGC;
	RTHOOK(1);
	F396_6126(Current, arg1);
	RTHOOK(2);
	F396_6130(Current);
	RTHOOK(3);
	tr1 = RTOSCF(6178,F396_6178, (Current));
	F396_6126(Current, tr1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.parse_from_file */
void F396_6107 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("parse_from_file", 395, Current, 1, 1, 5930);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1250, 0x00).id, 1250, _OBJSIZ_3_3_0_7_0_0_0_0_);
	F1251_11680(RTCW(loc1), arg1);
	RTHOOK(2);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8019[Dtype(RTCW(arg1))-878])(arg1);
	F1251_11695(RTCW(loc1), ti4_1, ((EIF_INTEGER_32) 16384L));
	RTHOOK(3);
	F1251_11696(RTCW(loc1));
	RTHOOK(4);
	F396_6104(Current, loc1);
	RTHOOK(5);
	F1251_11697(RTCW(loc1));
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.set_callbacks */
void F396_6110 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_callbacks", 395, Current, 0, 1, 5933);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {XML_STANDARD_PARSER}.set_encoding */
void F396_6111 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc3);
	RTLR(5,arg1);
	RTLR(6,tr2);
	RTLR(7,loc4);
	RTLIU(8);
	
	RTEAA("set_encoding", 395, Current, 4, 1, 5934);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc2 = tr1;
	loc2 = RTRV(eif_new_type(401, 0x00),loc2);
	if (EIF_TEST(loc2)) {
		RTHOOK(2);
		loc1 = (EIF_REFERENCE) loc2;
	} else {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc3 = tr1;
		loc3 = RTRV(eif_new_type(399, 0x00),loc3);
		if (EIF_TEST(loc3)) {
			RTHOOK(4);
			loc1 = *(EIF_REFERENCE *)(loc3);
		}
	}
	RTHOOK(5);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(6);
		tr1 = RTMS32_EX_H("I\000\000\000n\000\000\000t\000\000\000e\000\000\000r\000\000\000n\000\000\000a\000\000\000l\000\000\000 \000\000\000e\000\000\000r\000\000\000r\000\000\000o\000\000\000r\000\000\000:\000\000\000 \000\000\000u\000\000\000n\000\000\000a\000\000\000b\000\000\000l\000\000\000e\000\000\000 \000\000\000t\000\000\000o\000\000\000 \000\000\000u\000\000\000s\000\000\000e\000\000\000 \000\000\000e\000\000\000n\000\000\000c\000\000\000o\000\000\000d\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000\"\000\000\000",40,1493525538);
		tr2 = F1500_14215(RTCW(arg1));
		tr1 = F1510_14585(tr1, tr2);
		tr2 = RTMS32_EX_H("\"\000\000\000.\000\000\000",2,8750);
		tr1 = F1510_14585(RTCW(tr1), tr2);
		F396_6140(Current, tr1);
	} else {
		RTHOOK(7);
		tr1 = F396_6151(Current, arg1, loc1);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			RTHOOK(8);
			RTAR(Current, loc4);
			*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc4;
		} else {
			RTHOOK(9);
			tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000s\000\000\000u\000\000\000p\000\000\000p\000\000\000o\000\000\000r\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000e\000\000\000n\000\000\000c\000\000\000o\000\000\000d\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000\"\000\000\000",22,967152674);
			tr2 = F1500_14215(RTCW(arg1));
			tr1 = F1510_14585(tr1, tr2);
			tr2 = RTMS32_EX_H("\"\000\000\000.\000\000\000",2,8750);
			tr1 = F1510_14585(RTCW(tr1), tr2);
			F396_6140(Current, tr1);
			RTHOOK(10);
			tr1 = RTLNS(eif_new_type(400, 0x00).id, 400, _OBJSIZ_1_0_0_1_0_0_0_0_);
			F401_6243(RTCW(tr1), loc1);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
		}
	}
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.error_occurred */
EIF_BOOLEAN F396_6113 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("error_occurred", 395, Current, 0, 0, 5936);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_3_) != NULL);
}

/* {XML_STANDARD_PARSER}.truncation_reported */
EIF_BOOLEAN F396_6114 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_5_2_);
}


/* {XML_STANDARD_PARSER}.error_message */
EIF_REFERENCE F396_6117 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_4_);
}


/* {XML_STANDARD_PARSER}.error_position */
EIF_REFERENCE F396_6118 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {XML_STANDARD_PARSER}.position */
EIF_REFERENCE F396_6119 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("position", 395, Current, 1, 0, 5942);
	RTGC;
	RTHOOK(1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5555[Dtype(Current)-395])(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) loc1;
	} else {
		RTHOOK(4);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) F396_6120(Current);
	}/* NOTREACHED */
	
}

/* {XML_STANDARD_PARSER}.buffer_position */
EIF_REFERENCE F396_6120 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("buffer_position", 395, Current, 0, 0, 5943);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1252, 0x00).id, 1252, _OBJSIZ_1_0_0_3_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5633[Dtype(RTCW(tr1))-398])(tr1);
	tr1 = F1500_14214(RTCW(tr1));
	ti4_1 = F396_6121(Current);
	ti4_2 = F396_6123(Current);
	ti4_3 = F396_6122(Current);
	F1253_11726(RTCW(Result), tr1, ti4_1, ti4_2, ti4_3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STANDARD_PARSER}.byte_index */
EIF_INTEGER_32 F396_6121 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("byte_index", 395, Current, 0, 0, 5944);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5636[Dtype(RTCW(tr1))-398])(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STANDARD_PARSER}.line */
EIF_INTEGER_32 F396_6122 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("line", 395, Current, 0, 0, 5945);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5637[Dtype(RTCW(tr1))-398])(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STANDARD_PARSER}.column */
EIF_INTEGER_32 F396_6123 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("column", 395, Current, 0, 0, 5946);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5638[Dtype(RTCW(tr1))-398])(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STANDARD_PARSER}.reset */
void F396_6124 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 tw1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("reset", 395, Current, 0, 0, 5947);
	RTGC;
	RTHOOK(1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	*(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]) = (EIF_CHARACTER_32) tw1;
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	*(EIF_CHARACTER_32 *)(Current + O5583[dtype-395]) = (EIF_CHARACTER_32) tw1;
	RTHOOK(3);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(4);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) NULL;
	RTHOOK(5);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) NULL;
	RTHOOK(6);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
	RTHOOK(7);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_5_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.set_buffer */
void F396_6126 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("set_buffer", 395, Current, 0, 1, 5949);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5634[Dtype(RTCW(arg1))-398])(arg1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) = (EIF_BOOLEAN) tb1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.checkpoint_position */
EIF_REFERENCE F396_6127 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("checkpoint_position", 395, Current, 0, 0, 5950);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {XML_STANDARD_PARSER}.set_checkpoint_position */
void F396_6128 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_checkpoint_position", 395, Current, 0, 0, 5951);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.unset_checkpoint_position */
void F396_6129 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("unset_checkpoint_position", 395, Current, 0, 0, 5952);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.parse */
void F396_6130 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc4);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc5);
	RTLIU(5);
	
	RTEAA("parse", 395, Current, 5, 0, 5953);
	RTGC;
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5552[dtype-395])(Current);
	RTHOOK(2);
	loc4 = *(EIF_REFERENCE *)(Current);
	RTHOOK(3);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5933[Dtype(RTCW(loc4))-476])(loc4);
	RTHOOK(4);
	loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(5);
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(6);
	loc1 = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1500_14155(RTCW(loc1));
	for (;;) {
		RTHOOK(7);
		if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_))) break;
		RTHOOK(8);
		F396_6158(Current);
		RTHOOK(9);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
		} else {
			RTHOOK(10);
			switch (*(EIF_CHARACTER_32 *)(Current + O5582[dtype-395])) {
				case (EIF_CHARACTER_8) '\000':
					
					RTHOOK(12);
					tr1 = RTMS_EX_H("Null character!",15,996057121);
					F396_6145(Current, tr1);
					break;
				case (EIF_CHARACTER_8) '<':
					RTHOOK(13);
					if (loc2) {
						RTHOOK(14);
						if (loc3) {
							RTHOOK(15);
							tr1 = F396_6149(Current, loc1);
							loc5 = tr1;
							if (EIF_TEST(loc5)) {
								RTHOOK(16);
								F396_6147(Current, loc5);
								RTHOOK(17);
								ti4_1 = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_2_);
								F1510_14588(RTCW(loc1), ti4_1);
							}
							RTHOOK(18);
							loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						}
						RTHOOK(19);
						if ((EIF_BOOLEAN) !F396_6176(Current, loc1)) {
							RTHOOK(20);
							F396_6146(Current, loc1);
						}
						RTHOOK(21);
						F1510_14595(RTCW(loc1));
					} else {
						RTHOOK(22);
						tb1 = F835_9290(RTCW(loc1));
						if ((EIF_BOOLEAN) !tb1) {
							RTHOOK(23);
							tr1 = F1508_14466(RTCW(loc1));
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5943[Dtype(RTCW(loc4))-476])(loc4, tr1);
							RTHOOK(24);
							F1510_14595(RTCW(loc1));
						}
					}
					RTHOOK(25);
					F396_6158(Current);
					RTHOOK(26);
					if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
						RTHOOK(27);
						tr1 = RTMS_EX_H("Input ends with \'<\' character",29,1434827122);
						F396_6141(Current, tr1);
					} else {
						RTHOOK(28);
						switch (*(EIF_CHARACTER_32 *)(Current + O5582[dtype-395])) {
							case (EIF_CHARACTER_8) '\?':
								RTHOOK(29);
								F396_6134(Current);
								break;
							case (EIF_CHARACTER_8) '/':
								RTHOOK(30);
								F396_6132(Current);
								break;
							case (EIF_CHARACTER_8) '!':
								RTHOOK(31);
								F396_6158(Current);
								RTHOOK(32);
								if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
									RTHOOK(33);
									tr1 = RTMS_EX_H("Input ends with \'<!\'",20,1960991271);
									F396_6141(Current, tr1);
								} else {
									RTHOOK(34);
									switch (*(EIF_CHARACTER_32 *)(Current + O5582[dtype-395])) {
										case (EIF_CHARACTER_8) '-':
											RTHOOK(35);
											F396_6157(Current);
											RTHOOK(36);
											F396_6136(Current);
											break;
										case (EIF_CHARACTER_8) '[':
											RTHOOK(37);
											F396_6157(Current);
											RTHOOK(38);
											F396_6135(Current);
											break;
										case (EIF_CHARACTER_8) 'D':
											RTHOOK(39);
											F396_6157(Current);
											RTHOOK(40);
											F396_6137(Current);
											break;
										default:
											RTHOOK(41);
											F396_6142(Current, NULL);
											break;
									}
								}
								break;
							default:
								RTHOOK(42);
								F396_6157(Current);
								RTHOOK(43);
								loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								RTHOOK(44);
								F396_6131(Current);
								break;
						}
					}
					break;
				case (EIF_CHARACTER_8) '&':
					RTHOOK(45);
					tr1 = F396_6162(Current);
					F1510_14568(RTCW(loc1), tr1);
					break;
				case (EIF_CHARACTER_8) '>':
					RTHOOK(46);
					F396_6142(Current, NULL);
					break;
				default:
					RTHOOK(47);
					F1510_14579(RTCW(loc1), *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]));
					break;
			}
		}
	}
	RTHOOK(48);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_)) {
		RTHOOK(49);
		tb1 = '\0';
		tb2 = F835_9290(RTCW(loc1));
		if ((EIF_BOOLEAN) !tb2) {
			tb1 = (EIF_BOOLEAN) !F396_6176(Current, loc1);
		}
		if (tb1) {
			RTHOOK(50);
			tr1 = F1508_14466(RTCW(loc1));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5943[Dtype(RTCW(loc4))-476])(loc4, tr1);
			RTHOOK(51);
			F1510_14595(RTCW(loc1));
		}
		RTHOOK(52);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5934[Dtype(RTCW(loc4))-476])(loc4);
	}
	RTHOOK(53);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.parse_start_tag */
void F396_6131 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc4);
	RTLR(4,tr2);
	RTLR(5,loc2);
	RTLR(6,tr3);
	RTLIU(7);
	
	RTEAA("parse_start_tag", 395, Current, 4, 0, 5954);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
		RTHOOK(2);
		F396_6141(Current, NULL);
	} else {
		RTHOOK(3);
		loc1 = F396_6161(Current);
		RTHOOK(4);
		tr1 = eif_boxed_item(loc1,2);
		tb1 = F835_9290(RTCW(tr1));
		if (tb1) {
			RTHOOK(5);
			tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000s\000\000\000t\000\000\000a\000\000\000r\000\000\000t\000\000\000 \000\000\000t\000\000\000a\000\000\000g\000\000\000 \000\000\000v\000\000\000a\000\000\000l\000\000\000u\000\000\000e\000\000\000.\000\000\000",24,1280155182);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
		} else {
			RTHOOK(6);
			loc4 = *(EIF_REFERENCE *)(Current);
			RTHOOK(7);
			tr1 = eif_boxed_item(loc1,1);
			tr2 = eif_boxed_item(loc1,2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5939[Dtype(RTCW(loc4))-476])(loc4, NULL, tr1, tr2);
			RTHOOK(8);
			tw1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
			tr1 = RTLNS(eif_new_type(1452, 0x00).id, 1452, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = tw1;
			tb1 = F1451_13991(RTCW(tr1));
			if (tb1) {
				RTHOOK(9);
				F396_6160(Current);
			}
			RTHOOK(10);
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
				RTHOOK(11);
				tr1 = RTMS_EX_H("in start tag declaration",24,735103342);
				F396_6141(Current, tr1);
			} else {
				RTHOOK(12);
				switch (*(EIF_CHARACTER_32 *)(Current + O5582[dtype-395])) {
					case (EIF_CHARACTER_8) '>':
						RTHOOK(13);
						(FUNCTION_CAST(void, (EIF_REFERENCE)) R5941[Dtype(RTCW(loc4))-476])(loc4);
						break;
					case (EIF_CHARACTER_8) '/':
						RTHOOK(14);
						if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
							RTHOOK(15);
							tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000c\000\000\000o\000\000\000m\000\000\000p\000\000\000l\000\000\000e\000\000\000t\000\000\000e\000\000\000 \000\000\000s\000\000\000t\000\000\000a\000\000\000r\000\000\000t\000\000\000 \000\000\000t\000\000\000a\000\000\000g\000\000\000",20,618822503);
							F396_6141(Current, tr1);
						} else {
							RTHOOK(16);
							F396_6158(Current);
							RTHOOK(17);
							tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
							if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]) == tw1)) {
								RTHOOK(18);
								(FUNCTION_CAST(void, (EIF_REFERENCE)) R5941[Dtype(RTCW(loc4))-476])(loc4);
								RTHOOK(19);
								tr1 = eif_boxed_item(loc1,1);
								tr2 = eif_boxed_item(loc1,2);
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5942[Dtype(RTCW(loc4))-476])(loc4, NULL, tr1, tr2);
							} else {
								RTHOOK(20);
								tr1 = RTMS32_EX_H("u\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000\'\000\000\000",22,169384743);
								tr2 = F396_6166(Current, *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]));
								tr1 = F1510_14585(tr1, tr2);
								tr2 = RTMS32_EX_H("\'\000\000\000 \000\000\000a\000\000\000f\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000c\000\000\000l\000\000\000o\000\000\000s\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000/\000\000\000 \000\000\000i\000\000\000n\000\000\000 \000\000\000s\000\000\000t\000\000\000a\000\000\000r\000\000\000t\000\000\000 \000\000\000t\000\000\000a\000\000\000g\000\000\000.\000\000\000",31,20660270);
								tr1 = F1510_14585(RTCW(tr1), tr2);
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
							}
						}
						break;
					default:
						RTHOOK(21);
						F396_6157(Current);
						RTHOOK(22);
						loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						for (;;) {
							RTHOOK(23);
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) || loc3) || *(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_))) break;
							RTHOOK(24);
							loc2 = F396_6165(Current);
							RTHOOK(25);
							if ((EIF_BOOLEAN)(loc2 != NULL)) {
								RTHOOK(26);
								tr1 = eif_boxed_item(loc2,1);
								tr2 = eif_boxed_item(loc2,2);
								tr3 = eif_boxed_item(loc2,3);
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5940[Dtype(RTCW(loc4))-476])(loc4, NULL, tr1, tr2, tr3);
								RTHOOK(27);
								if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
									RTHOOK(28);
									tr1 = RTMS_EX_H("in start tag declaration",24,735103342);
									F396_6141(Current, tr1);
								} else {
									RTHOOK(29);
									F396_6157(Current);
								}
							} else {
								RTHOOK(30);
								if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
									RTHOOK(31);
									tr1 = RTMS_EX_H("in start tag declaration",24,735103342);
									F396_6141(Current, tr1);
								} else {
									RTHOOK(32);
									switch (*(EIF_CHARACTER_32 *)(Current + O5582[dtype-395])) {
										case (EIF_CHARACTER_8) '>':
											RTHOOK(33);
											(FUNCTION_CAST(void, (EIF_REFERENCE)) R5941[Dtype(RTCW(loc4))-476])(loc4);
											break;
										case (EIF_CHARACTER_8) '/':
											RTHOOK(34);
											F396_6158(Current);
											RTHOOK(35);
											if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
												RTHOOK(36);
												tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000c\000\000\000o\000\000\000m\000\000\000p\000\000\000l\000\000\000e\000\000\000t\000\000\000e\000\000\000 \000\000\000s\000\000\000t\000\000\000a\000\000\000r\000\000\000t\000\000\000 \000\000\000t\000\000\000a\000\000\000g\000\000\000 \000\000\000e\000\000\000n\000\000\000d\000\000\000i\000\000\000n\000\000\000g\000\000\000",27,2035617383);
												F396_6141(Current, tr1);
											} else {
												RTHOOK(37);
												tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
												if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]) == tw1)) {
													RTHOOK(38);
													loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
													RTHOOK(39);
													(FUNCTION_CAST(void, (EIF_REFERENCE)) R5941[Dtype(RTCW(loc4))-476])(loc4);
													RTHOOK(40);
													tr1 = eif_boxed_item(loc1,1);
													tr2 = eif_boxed_item(loc1,2);
													(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5942[Dtype(RTCW(loc4))-476])(loc4, NULL, tr1, tr2);
												} else {
													RTHOOK(41);
													tr1 = RTMS32_EX_H("u\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000\'\000\000\000",22,169384743);
													tr2 = F396_6166(Current, *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]));
													tr1 = F1510_14585(tr1, tr2);
													tr2 = RTMS32_EX_H("\'\000\000\000 \000\000\000a\000\000\000f\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000c\000\000\000l\000\000\000o\000\000\000s\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000/\000\000\000 \000\000\000i\000\000\000n\000\000\000 \000\000\000s\000\000\000t\000\000\000a\000\000\000r\000\000\000t\000\000\000 \000\000\000t\000\000\000a\000\000\000g\000\000\000",30,1266758247);
													tr1 = F1510_14585(RTCW(tr1), tr2);
													(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
												}
											}
											break;
										default:
											RTHOOK(42);
											tr1 = RTMS32_EX_H("u\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000\'\000\000\000",22,169384743);
											tr2 = F396_6166(Current, *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]));
											tr1 = F1510_14585(tr1, tr2);
											tr2 = RTMS32_EX_H("\'\000\000\000 \000\000\000i\000\000\000n\000\000\000 \000\000\000s\000\000\000t\000\000\000a\000\000\000r\000\000\000t\000\000\000 \000\000\000t\000\000\000a\000\000\000g\000\000\000",14,1961969255);
											tr1 = F1510_14585(RTCW(tr1), tr2);
											(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
											break;
									}
									RTHOOK(43);
									loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								}
							}
						}
						break;
				}
			}
		}
	}
	RTHOOK(44);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.parse_end_tag */
void F396_6132 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTEAA("parse_end_tag", 395, Current, 1, 0, 5955);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
		RTHOOK(2);
		F396_6141(Current, NULL);
	} else {
		RTHOOK(3);
		loc1 = F396_6161(Current);
		RTHOOK(4);
		tr1 = eif_boxed_item(loc1,2);
		tb1 = F835_9290(RTCW(tr1));
		if (tb1) {
			RTHOOK(5);
			tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000e\000\000\000n\000\000\000d\000\000\000 \000\000\000t\000\000\000a\000\000\000g\000\000\000 \000\000\000v\000\000\000a\000\000\000l\000\000\000u\000\000\000e\000\000\000.\000\000\000",22,1226534958);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
		} else {
			RTHOOK(6);
			tw1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
			tr1 = RTLNS(eif_new_type(1452, 0x00).id, 1452, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = tw1;
			tb1 = F1451_13991(RTCW(tr1));
			if (tb1) {
				RTHOOK(7);
				F396_6160(Current);
			}
			RTHOOK(8);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
			if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]) == tw1)) {
				RTHOOK(9);
				tr1 = *(EIF_REFERENCE *)(Current);
				tr2 = eif_boxed_item(loc1,1);
				tr3 = eif_boxed_item(loc1,2);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5942[Dtype(RTCW(tr1))-476])(tr1, NULL, tr2, tr3);
			} else {
				RTHOOK(10);
				tr1 = RTMS32_EX_H("u\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000\'\000\000\000",22,169384743);
				tr2 = F396_6166(Current, *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]));
				tr1 = F1510_14585(tr1, tr2);
				tr2 = RTMS32_EX_H("\'\000\000\000 \000\000\000i\000\000\000n\000\000\000 \000\000\000e\000\000\000n\000\000\000d\000\000\000 \000\000\000t\000\000\000a\000\000\000g\000\000\000",12,1228033127);
				tr1 = F1510_14585(RTCW(tr1), tr2);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
			}
		}
	}
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.parse_declaration */
void F396_6133 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,loc6);
	RTLR(6,loc4);
	RTLIU(7);
	
	RTEAA("parse_declaration", 395, Current, 6, 0, 5956);
	RTGC;
	RTHOOK(1);
	loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_)) {
		RTHOOK(3);
		F396_6158(Current);
		RTHOOK(4);
		tw1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
		tr1 = RTLNS(eif_new_type(1452, 0x00).id, 1452, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)tr1 = tw1;
		tb1 = F1451_13991(RTCW(tr1));
		if (tb1) {
			RTHOOK(5);
			F396_6160(Current);
		}
		RTHOOK(6);
		switch (*(EIF_CHARACTER_32 *)(Current + O5582[dtype-395])) {
			case (EIF_CHARACTER_8) '\?':
				RTHOOK(7);
				F396_6158(Current);
				RTHOOK(8);
				if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
					RTHOOK(9);
					tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000c\000\000\000o\000\000\000m\000\000\000p\000\000\000l\000\000\000e\000\000\000t\000\000\000e\000\000\000 \000\000\000x\000\000\000m\000\000\000l\000\000\000 \000\000\000d\000\000\000e\000\000\000c\000\000\000l\000\000\000a\000\000\000r\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",26,870850158);
					F396_6141(Current, tr1);
				} else {
					RTHOOK(10);
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
					if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]) == tw1)) {
						RTHOOK(11);
						if ((EIF_BOOLEAN)(loc1 != NULL)) {
							RTHOOK(12);
							F396_6138(Current, loc1, loc2, loc3);
						} else {
							RTHOOK(13);
							tr1 = RTMS32_EX_H("m\000\000\000i\000\000\000s\000\000\000s\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000v\000\000\000e\000\000\000r\000\000\000s\000\000\000i\000\000\000o\000\000\000n\000\000\000 \000\000\000i\000\000\000n\000\000\000 \000\000\000x\000\000\000m\000\000\000l\000\000\000 \000\000\000d\000\000\000e\000\000\000c\000\000\000l\000\000\000a\000\000\000r\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",34,383714414);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
						}
					} else {
						RTHOOK(14);
						tr1 = RTMS32_EX_H("u\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000\'\000\000\000",22,169384743);
						tr2 = F396_6166(Current, *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]));
						tr1 = F1510_14585(tr1, tr2);
						tr2 = RTMS32_EX_H("\'\000\000\000 \000\000\000a\000\000\000f\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000c\000\000\000l\000\000\000o\000\000\000s\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000\?\000\000\000 \000\000\000i\000\000\000n\000\000\000 \000\000\000x\000\000\000m\000\000\000l\000\000\000 \000\000\000d\000\000\000e\000\000\000c\000\000\000l\000\000\000a\000\000\000r\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",36,885578862);
						tr1 = F1510_14585(RTCW(tr1), tr2);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
					}
				}
				break;
			default:
				RTHOOK(15);
				F396_6157(Current);
				RTHOOK(16);
				loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				for (;;) {
					RTHOOK(17);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc5 || *(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_)) || *(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_))) break;
					RTHOOK(18);
					loc6 = F396_6165(Current);
					RTHOOK(19);
					if ((EIF_BOOLEAN)(loc6 != NULL)) {
						RTHOOK(20);
						loc4 = eif_boxed_item(loc6,2);
						RTHOOK(21);
						tr1 = RTOSCF(6183,F396_6183, (Current));
						tb1 = F1508_14476(RTCW(loc4), tr1);
						if (tb1) {
							RTHOOK(22);
							loc1 = eif_boxed_item(loc6,3);
						} else {
							RTHOOK(23);
							tr1 = RTOSCF(6184,F396_6184, (Current));
							tb1 = F1508_14476(RTCW(loc4), tr1);
							if (tb1) {
								RTHOOK(24);
								loc2 = eif_boxed_item(loc6,3);
							} else {
								RTHOOK(25);
								tr1 = RTOSCF(6185,F396_6185, (Current));
								tb1 = F1508_14476(RTCW(loc4), tr1);
								if (tb1) {
									RTHOOK(26);
									loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								} else {
									RTHOOK(27);
									tr1 = RTMS32_EX_H("u\000\000\000n\000\000\000k\000\000\000n\000\000\000o\000\000\000w\000\000\000n\000\000\000 \000\000\000x\000\000\000m\000\000\000l\000\000\000 \000\000\000d\000\000\000e\000\000\000c\000\000\000l\000\000\000a\000\000\000r\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000 \000\000\000a\000\000\000t\000\000\000t\000\000\000r\000\000\000i\000\000\000b\000\000\000u\000\000\000t\000\000\000e\000\000\000 \000\000\000[\000\000\000",35,508354139);
									tr2 = F1500_14215(RTCW(loc4));
									tr1 = F1510_14585(tr1, tr2);
									tr2 = RTMS32_EX_H("]\000\000\000",1,93);
									tr1 = F1510_14585(RTCW(tr1), tr2);
									(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
								}
							}
						}
						RTHOOK(28);
						F396_6157(Current);
					} else {
						RTHOOK(29);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\?';
						if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]) == tw1)) {
							RTHOOK(30);
							F396_6160(Current);
							RTHOOK(31);
							if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
								RTHOOK(32);
								tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000c\000\000\000o\000\000\000m\000\000\000p\000\000\000l\000\000\000e\000\000\000t\000\000\000e\000\000\000 \000\000\000e\000\000\000n\000\000\000d\000\000\000 \000\000\000o\000\000\000f\000\000\000 \000\000\000x\000\000\000m\000\000\000l\000\000\000 \000\000\000d\000\000\000e\000\000\000c\000\000\000l\000\000\000a\000\000\000r\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",33,760619886);
								F396_6141(Current, tr1);
							} else {
								RTHOOK(33);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
								if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]) == tw1)) {
									RTHOOK(34);
									loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
									RTHOOK(35);
									if ((EIF_BOOLEAN)(loc1 != NULL)) {
										RTHOOK(36);
										F396_6138(Current, loc1, loc2, loc3);
									} else {
										RTHOOK(37);
										tr1 = RTMS32_EX_H("m\000\000\000i\000\000\000s\000\000\000s\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000v\000\000\000e\000\000\000r\000\000\000s\000\000\000i\000\000\000o\000\000\000n\000\000\000 \000\000\000i\000\000\000n\000\000\000 \000\000\000x\000\000\000m\000\000\000l\000\000\000 \000\000\000d\000\000\000e\000\000\000c\000\000\000l\000\000\000a\000\000\000r\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",34,383714414);
										(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
									}
								} else {
									RTHOOK(38);
									tr1 = RTMS32_EX_H("u\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000\'\000\000\000",22,169384743);
									tr2 = F396_6166(Current, *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]));
									tr1 = F1510_14585(tr1, tr2);
									tr2 = RTMS32_EX_H("\'\000\000\000 \000\000\000a\000\000\000f\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000c\000\000\000l\000\000\000o\000\000\000s\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000\?\000\000\000 \000\000\000i\000\000\000n\000\000\000 \000\000\000x\000\000\000m\000\000\000l\000\000\000 \000\000\000d\000\000\000e\000\000\000c\000\000\000l\000\000\000a\000\000\000r\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",36,885578862);
									tr1 = F1510_14585(RTCW(tr1), tr2);
									(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
								}
							}
						}
						RTHOOK(39);
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
				}
				break;
		}
	}
	RTHOOK(40);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.parse_processing_instruction */
void F396_6134 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,tr2);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTEAA("parse_processing_instruction", 395, Current, 4, 0, 5957);
	RTGC;
	RTHOOK(1);
	F396_6158(Current);
	RTHOOK(2);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
		RTHOOK(3);
		tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000c\000\000\000o\000\000\000m\000\000\000p\000\000\000l\000\000\000e\000\000\000t\000\000\000e\000\000\000 \000\000\000p\000\000\000r\000\000\000o\000\000\000c\000\000\000e\000\000\000s\000\000\000s\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000i\000\000\000n\000\000\000s\000\000\000t\000\000\000r\000\000\000u\000\000\000c\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",33,1635038062);
		F396_6141(Current, tr1);
	} else {
		RTHOOK(4);
		loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
		RTHOOK(5);
		loc2 = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1508_14451(RTCW(loc2), ((EIF_INTEGER_32) 6L));
		for (;;) {
			RTHOOK(6);
			tb1 = '\01';
			tb2 = '\01';
			tb3 = '\01';
			if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
				tr1 = RTLNS(eif_new_type(1452, 0x00).id, 1452, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = loc1;
				tb4 = F1451_13991(RTCW(tr1));
				tb3 = tb4;
			}
			if (!tb3) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\?';
				tb2 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb2) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
				tb1 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (tb1) break;
			RTHOOK(7);
			F1510_14579(RTCW(loc2), loc1);
			RTHOOK(8);
			F396_6158(Current);
			RTHOOK(9);
			loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
		}
		RTHOOK(10);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
			RTHOOK(11);
			tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000c\000\000\000o\000\000\000m\000\000\000p\000\000\000l\000\000\000e\000\000\000t\000\000\000e\000\000\000 \000\000\000p\000\000\000r\000\000\000o\000\000\000c\000\000\000e\000\000\000s\000\000\000s\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000i\000\000\000n\000\000\000s\000\000\000t\000\000\000r\000\000\000u\000\000\000c\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",33,1635038062);
			F396_6141(Current, tr1);
		} else {
			RTHOOK(12);
			tb2 = F835_9290(RTCW(loc2));
			if (tb2) {
				RTHOOK(13);
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
					RTHOOK(14);
					F396_6157(Current);
				}
				RTHOOK(15);
				tr1 = RTMS32_EX_H("I\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000p\000\000\000r\000\000\000o\000\000\000c\000\000\000e\000\000\000s\000\000\000s\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000i\000\000\000n\000\000\000s\000\000\000t\000\000\000r\000\000\000u\000\000\000c\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000 \000\000\000s\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000 \000\000\000<\000\000\000\?\000\000\000",40,1005310015);
				tr2 = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
				F1508_14452(RTCW(tr2), *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]), ((EIF_INTEGER_32) 1L));
				tr1 = F1510_14585(tr1, tr2);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
			} else {
				RTHOOK(16);
				tr1 = RTOSCF(6189,F396_6189, (Current));
				tb2 = F1508_14476(RTCW(loc2), tr1);
				if (tb2) {
					RTHOOK(17);
					F396_6133(Current);
				} else {
					RTHOOK(18);
					loc3 = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F1500_14155(RTCW(loc3));
					RTHOOK(19);
					F396_6158(Current);
					for (;;) {
						RTHOOK(20);
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) || loc4) || *(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_))) break;
						RTHOOK(21);
						loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
						RTHOOK(22);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\?';
						if ((EIF_BOOLEAN)(loc1 == tw1)) {
							RTHOOK(23);
							F396_6158(Current);
							RTHOOK(24);
							loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
							RTHOOK(25);
							tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
							if ((EIF_BOOLEAN)(loc1 == tw1)) {
								RTHOOK(26);
								loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								RTHOOK(27);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\?';
								if ((EIF_BOOLEAN)(loc1 == tw1)) {
									RTHOOK(28);
									tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\?';
									F1510_14579(RTCW(loc3), tw1);
								} else {
									RTHOOK(29);
									tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\?';
									F1510_14579(RTCW(loc3), tw1);
									RTHOOK(30);
									F1510_14579(RTCW(loc3), loc1);
									RTHOOK(31);
									F396_6158(Current);
									RTHOOK(32);
									if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
										RTHOOK(33);
										tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000c\000\000\000o\000\000\000m\000\000\000p\000\000\000l\000\000\000e\000\000\000t\000\000\000e\000\000\000 \000\000\000p\000\000\000r\000\000\000o\000\000\000c\000\000\000e\000\000\000s\000\000\000s\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000i\000\000\000n\000\000\000s\000\000\000t\000\000\000r\000\000\000u\000\000\000c\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",33,1635038062);
										F396_6141(Current, tr1);
									}
								}
							}
						} else {
							RTHOOK(34);
							F1510_14579(RTCW(loc3), loc1);
							RTHOOK(35);
							F396_6158(Current);
						}
					}
					RTHOOK(36);
					if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_))) {
						RTHOOK(37);
						tr1 = RTMS32_EX_H("c\000\000\000o\000\000\000u\000\000\000l\000\000\000d\000\000\000 \000\000\000n\000\000\000o\000\000\000t\000\000\000 \000\000\000f\000\000\000i\000\000\000n\000\000\000d\000\000\000 \000\000\000e\000\000\000n\000\000\000d\000\000\000 \000\000\000o\000\000\000f\000\000\000 \000\000\000P\000\000\000r\000\000\000o\000\000\000c\000\000\000e\000\000\000s\000\000\000s\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000I\000\000\000n\000\000\000s\000\000\000t\000\000\000r\000\000\000u\000\000\000c\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",44,395533678);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
					} else {
						RTHOOK(38);
						tr1 = *(EIF_REFERENCE *)(Current);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5937[Dtype(RTCW(tr1))-476])(tr1, loc2, loc3);
					}
				}
			}
		}
	}
	RTHOOK(39);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.parse_cdata */
void F396_6135 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("parse_cdata", 395, Current, 3, 0, 5958);
	RTGC;
	RTHOOK(1);
	F396_6158(Current);
	RTHOOK(2);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
		RTHOOK(3);
		tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000c\000\000\000o\000\000\000m\000\000\000p\000\000\000l\000\000\000e\000\000\000t\000\000\000e\000\000\000 \000\000\000C\000\000\000D\000\000\000A\000\000\000T\000\000\000A\000\000\000 \000\000\000s\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000",23,2086846584);
		F396_6141(Current, tr1);
	} else {
		RTHOOK(4);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
		if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]) != tw1)) {
			RTHOOK(5);
			tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000s\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000 \000\000\000<\000\000\000!\000\000\000",17,1133362721);
			tr2 = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F1508_14452(RTCW(tr2), *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]), ((EIF_INTEGER_32) 1L));
			tr1 = F1510_14585(tr1, tr2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
		} else {
			RTHOOK(6);
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
				RTHOOK(7);
				tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000c\000\000\000o\000\000\000m\000\000\000p\000\000\000l\000\000\000e\000\000\000t\000\000\000e\000\000\000 \000\000\000C\000\000\000D\000\000\000A\000\000\000T\000\000\000A\000\000\000 \000\000\000s\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000",23,2086846584);
				F396_6141(Current, tr1);
			} else {
				RTHOOK(8);
				F396_6158(Current);
				RTHOOK(9);
				loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
				RTHOOK(10);
				loc2 = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
				F1508_14451(RTCW(loc2), ((EIF_INTEGER_32) 6L));
				for (;;) {
					RTHOOK(11);
					tb1 = '\01';
					if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '[';
						tb1 = (EIF_BOOLEAN)(loc1 == tw1);
					}
					if (tb1) break;
					RTHOOK(12);
					tr1 = RTLNS(eif_new_type(1452, 0x00).id, 1452, _OBJSIZ_0_0_0_1_0_0_0_0_);
					*(EIF_CHARACTER_32 *)tr1 = loc1;
					tw1 = F1451_13979(RTCW(tr1));
					F1510_14579(RTCW(loc2), tw1);
					RTHOOK(13);
					F396_6158(Current);
					RTHOOK(14);
					loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
				}
				RTHOOK(15);
				tr1 = RTOSCF(6186,F396_6186, (Current));
				tb2 = F1500_14200(RTCW(loc2), tr1);
				if (tb2) {
					RTHOOK(16);
					F1510_14595(RTCW(loc2));
					RTHOOK(17);
					F396_6158(Current);
					for (;;) {
						RTHOOK(18);
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) || loc3) || *(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_))) break;
						RTHOOK(19);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
						if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]) == tw1)) {
							RTHOOK(20);
							F396_6158(Current);
							RTHOOK(21);
							tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
							if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]) == tw1)) {
								RTHOOK(22);
								F396_6158(Current);
								RTHOOK(23);
								loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
								RTHOOK(24);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
								if ((EIF_BOOLEAN)(loc1 == tw1)) {
									RTHOOK(25);
									loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								} else {
									RTHOOK(26);
									tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
									if ((EIF_BOOLEAN)(loc1 == tw1)) {
										RTHOOK(27);
										tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
										F1510_14579(RTCW(loc2), tw1);
										RTHOOK(28);
										if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
											RTHOOK(29);
											F396_6157(Current);
										}
									} else {
										RTHOOK(30);
										tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
										F1510_14579(RTCW(loc2), tw1);
										RTHOOK(31);
										tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
										F1510_14579(RTCW(loc2), tw1);
										RTHOOK(32);
										F1510_14579(RTCW(loc2), loc1);
										RTHOOK(33);
										F396_6158(Current);
									}
								}
							} else {
								RTHOOK(34);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
								F1510_14579(RTCW(loc2), tw1);
								RTHOOK(35);
								F1510_14579(RTCW(loc2), *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]));
								RTHOOK(36);
								F396_6158(Current);
							}
						} else {
							RTHOOK(37);
							F1510_14579(RTCW(loc2), *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]));
							RTHOOK(38);
							F396_6158(Current);
						}
					}
					RTHOOK(39);
					if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_))) {
						RTHOOK(40);
						tr1 = RTMS32_EX_H("c\000\000\000o\000\000\000u\000\000\000l\000\000\000d\000\000\000 \000\000\000n\000\000\000o\000\000\000t\000\000\000 \000\000\000f\000\000\000i\000\000\000n\000\000\000d\000\000\000 \000\000\000e\000\000\000n\000\000\000d\000\000\000 \000\000\000o\000\000\000f\000\000\000 \000\000\000C\000\000\000D\000\000\000A\000\000\000T\000\000\000A\000\000\000 \000\000\000c\000\000\000o\000\000\000n\000\000\000t\000\000\000e\000\000\000n\000\000\000t\000\000\000",35,1405547892);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
					} else {
						RTHOOK(41);
						tr1 = *(EIF_REFERENCE *)(Current);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5943[Dtype(RTCW(tr1))-476])(tr1, loc2);
					}
				} else {
					RTHOOK(42);
					tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000s\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000 \000\000\000<\000\000\000!\000\000\000[\000\000\000",18,231082587);
					tr1 = F1510_14585(tr1, loc2);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
				}
			}
		}
	}
	RTHOOK(43);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.parse_comment */
void F396_6136 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTEAA("parse_comment", 395, Current, 3, 0, 5959);
	RTGC;
	RTHOOK(1);
	F396_6158(Current);
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
	if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]) != tw1)) {
		RTHOOK(3);
		tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000c\000\000\000o\000\000\000m\000\000\000m\000\000\000e\000\000\000n\000\000\000t\000\000\000 \000\000\000s\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000",22,1894025080);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
	} else {
		RTHOOK(4);
		F396_6158(Current);
		RTHOOK(5);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
		if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]) != tw1)) {
			RTHOOK(6);
			tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000c\000\000\000o\000\000\000m\000\000\000m\000\000\000e\000\000\000n\000\000\000t\000\000\000 \000\000\000s\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000",22,1894025080);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
		} else {
			RTHOOK(7);
			loc2 = RTLNSMART(eif_new_type(1509, 0).id);
			F1500_14155(RTCW(loc2));
			RTHOOK(8);
			F396_6158(Current);
			for (;;) {
				RTHOOK(9);
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) || loc3) || *(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_))) break;
				RTHOOK(10);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
				if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]) == tw1)) {
					RTHOOK(11);
					F396_6158(Current);
					RTHOOK(12);
					loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
					RTHOOK(13);
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
					if ((EIF_BOOLEAN)(loc1 == tw1)) {
						RTHOOK(14);
						F396_6158(Current);
						RTHOOK(15);
						loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
						RTHOOK(16);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
						if ((EIF_BOOLEAN)(loc1 == tw1)) {
							RTHOOK(17);
							loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						} else {
							RTHOOK(18);
							tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
							if ((EIF_BOOLEAN)(loc1 == tw1)) {
								RTHOOK(19);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
								F1510_14579(RTCW(loc2), tw1);
								RTHOOK(20);
								if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
									RTHOOK(21);
									F396_6157(Current);
								}
							} else {
								RTHOOK(22);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
								F1510_14579(RTCW(loc2), tw1);
								RTHOOK(23);
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
								F1510_14579(RTCW(loc2), tw1);
								RTHOOK(24);
								F1510_14579(RTCW(loc2), loc1);
								RTHOOK(25);
								if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
									RTHOOK(26);
									F396_6158(Current);
								}
							}
						}
					} else {
						RTHOOK(27);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
						F1510_14579(RTCW(loc2), tw1);
						RTHOOK(28);
						F1510_14579(RTCW(loc2), loc1);
						RTHOOK(29);
						F396_6158(Current);
					}
				} else {
					RTHOOK(30);
					F1510_14579(RTCW(loc2), *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]));
					RTHOOK(31);
					F396_6158(Current);
				}
			}
			RTHOOK(32);
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_)) {
				RTHOOK(33);
				tr1 = RTMS32_EX_H("c\000\000\000o\000\000\000u\000\000\000l\000\000\000d\000\000\000 \000\000\000n\000\000\000o\000\000\000t\000\000\000 \000\000\000f\000\000\000i\000\000\000n\000\000\000d\000\000\000 \000\000\000e\000\000\000n\000\000\000d\000\000\000 \000\000\000o\000\000\000f\000\000\000 \000\000\000c\000\000\000o\000\000\000m\000\000\000m\000\000\000e\000\000\000n\000\000\000t\000\000\000",29,1755692148);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
			} else {
				RTHOOK(34);
				tr1 = *(EIF_REFERENCE *)(Current);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5938[Dtype(RTCW(tr1))-476])(tr1, loc2);
			}
		}
	}
	RTHOOK(35);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.parse_doctype */
void F396_6137 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("parse_doctype", 395, Current, 5, 0, 5960);
	RTGC;
	RTHOOK(1);
	F396_6158(Current);
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'D';
	if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]) != tw1)) {
		RTHOOK(3);
		tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000s\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000 \000\000\000<\000\000\000!\000\000\000",17,1133362721);
		tr2 = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1508_14452(RTCW(tr2), *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]), ((EIF_INTEGER_32) 1L));
		tr1 = F1510_14585(tr1, tr2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
	} else {
		RTHOOK(4);
		loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
		RTHOOK(5);
		loc2 = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1508_14451(RTCW(loc2), ((EIF_INTEGER_32) 6L));
		for (;;) {
			RTHOOK(6);
			tb1 = '\01';
			tb2 = '\01';
			if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
				tr1 = RTLNS(eif_new_type(1452, 0x00).id, 1452, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = loc1;
				tb3 = F1451_13991(RTCW(tr1));
				tb2 = tb3;
			}
			if (!tb2) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
				tb1 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (tb1) break;
			RTHOOK(7);
			tr1 = RTLNS(eif_new_type(1452, 0x00).id, 1452, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)tr1 = loc1;
			tw1 = F1451_13979(RTCW(tr1));
			F1510_14579(RTCW(loc2), tw1);
			RTHOOK(8);
			F396_6158(Current);
			RTHOOK(9);
			loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
		}
		RTHOOK(10);
		tr1 = RTOSCF(6187,F396_6187, (Current));
		tb2 = F1500_14200(RTCW(loc2), tr1);
		if (tb2) {
			RTHOOK(11);
			loc2 = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F1500_14155(RTCW(loc2));
			RTHOOK(12);
			F396_6158(Current);
			for (;;) {
				RTHOOK(13);
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) || loc5) || *(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_))) break;
				RTHOOK(14);
				loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
				RTHOOK(15);
				if (loc4) {
					RTHOOK(16);
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
					if ((EIF_BOOLEAN)(loc1 == tw1)) {
						RTHOOK(17);
						loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					}
					RTHOOK(18);
					F1510_14579(RTCW(loc2), loc1);
					RTHOOK(19);
					F396_6158(Current);
				} else {
					RTHOOK(20);
					switch (loc1) {
						case (EIF_CHARACTER_8) '\"':
							RTHOOK(21);
							loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							RTHOOK(22);
							F1510_14579(RTCW(loc2), loc1);
							RTHOOK(23);
							F396_6158(Current);
							break;
						case (EIF_CHARACTER_8) '<':
							RTHOOK(24);
							loc3++;
							RTHOOK(25);
							F1510_14579(RTCW(loc2), loc1);
							RTHOOK(26);
							F396_6158(Current);
							break;
						case (EIF_CHARACTER_8) '>':
							RTHOOK(27);
							if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
								RTHOOK(28);
								loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								RTHOOK(29);
								loc3--;
								RTHOOK(30);
								F1510_14579(RTCW(loc2), loc1);
								RTHOOK(31);
								F396_6158(Current);
							}
							break;
						default:
							RTHOOK(32);
							F1510_14579(RTCW(loc2), loc1);
							RTHOOK(33);
							F396_6158(Current);
							break;
					}
				}
			}
			RTHOOK(34);
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_)) {
				RTHOOK(35);
				tr1 = RTMS32_EX_H("c\000\000\000o\000\000\000u\000\000\000l\000\000\000d\000\000\000 \000\000\000n\000\000\000o\000\000\000t\000\000\000 \000\000\000f\000\000\000i\000\000\000n\000\000\000d\000\000\000 \000\000\000e\000\000\000n\000\000\000d\000\000\000 \000\000\000o\000\000\000f\000\000\000 \000\000\000D\000\000\000O\000\000\000C\000\000\000T\000\000\000Y\000\000\000P\000\000\000E\000\000\000 \000\000\000c\000\000\000o\000\000\000n\000\000\000t\000\000\000e\000\000\000n\000\000\000t\000\000\000",37,1848231284);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
			} else {
				RTHOOK(36);
				{
					/* INLINED CODE (XML_STANDARD_PARSER.register_doctype) */
					/* END INLINED CODE */
				}
				;
			}
		} else {
			RTHOOK(37);
			tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000s\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000 \000\000\000<\000\000\000!\000\000\000",17,1133362721);
			tr1 = F1510_14585(tr1, loc2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
		}
	}
	RTHOOK(38);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.on_xml_declaration */
void F396_6138 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Current);
	RTLR(5,arg2);
	RTLR(6,loc2);
	RTLIU(7);
	
	RTEAA("on_xml_declaration", 395, Current, 2, 3, 5961);
	RTGC;
	RTHOOK(1);
	tb1 = F1508_14483(RTCW(arg1));
	if (tb1) {
		RTHOOK(2);
		loc1 = (EIF_REFERENCE) arg1;
		RTHOOK(3);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O11684[Dtype(loc1)-1507]);
		if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 3L))) {
			RTHOOK(4);
			tb1 = '\0';
			tb2 = '\0';
			tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11450[Dtype(RTCW(loc1))-1503])(loc1, ((EIF_INTEGER_32) 1L));
			tb3 = EIF_TEST(isdigit(tw1));
			if (tb3) {
				tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11450[Dtype(RTCW(loc1))-1503])(loc1, ((EIF_INTEGER_32) 2L));
				tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
				tb2 = (EIF_BOOLEAN)(tw1 == tw2);
			}
			if (tb2) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O11684[Dtype(loc1)-1507]);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R11527[Dtype(RTCW(loc1))-1503])(loc1, ((EIF_INTEGER_32) 3L), ti4_1);
				tb2 = F1500_14186(RTCW(tr1));
				tb1 = tb2;
			}
			if (tb1) {
				RTHOOK(5);
				tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11450[Dtype(RTCW(loc1))-1503])(loc1, ((EIF_INTEGER_32) 1L));
				tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '1';
				if ((EIF_BOOLEAN)(tw1 != tw2)) {
					RTHOOK(6);
					tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000s\000\000\000u\000\000\000p\000\000\000p\000\000\000o\000\000\000r\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000x\000\000\000m\000\000\000l\000\000\000 \000\000\000v\000\000\000e\000\000\000r\000\000\000s\000\000\000i\000\000\000o\000\000\000n\000\000\000 \000\000\000i\000\000\000n\000\000\000f\000\000\000o\000\000\000:\000\000\000 \000\000\000\"\000\000\000",31,1770213922);
					tr1 = F1510_14585(tr1, arg1);
					tr2 = RTMS32_EX_H("\"\000\000\000.\000\000\000",2,8750);
					tr1 = F1510_14585(RTCW(tr1), tr2);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
				}
			} else {
				RTHOOK(7);
				loc1 = (EIF_REFERENCE) NULL;
			}
		} else {
			RTHOOK(8);
			loc1 = (EIF_REFERENCE) NULL;
		}
	}
	RTHOOK(9);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(10);
		tr1 = RTMS32_EX_H("I\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000x\000\000\000m\000\000\000l\000\000\000 \000\000\000v\000\000\000e\000\000\000r\000\000\000s\000\000\000i\000\000\000o\000\000\000n\000\000\000 \000\000\000i\000\000\000n\000\000\000f\000\000\000o\000\000\000:\000\000\000 \000\000\000\"\000\000\000",27,1032730658);
		tr1 = F1510_14585(tr1, arg1);
		tr2 = RTMS32_EX_H("\"\000\000\000.\000\000\000",2,8750);
		tr1 = F1510_14585(RTCW(tr1), tr2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
	} else {
		RTHOOK(11);
		if ((EIF_BOOLEAN)(arg2 != NULL)) {
			RTHOOK(12);
			tb1 = F1508_14483(RTCW(arg2));
			if (tb1) {
				RTHOOK(13);
				loc2 = (EIF_REFERENCE) arg2;
				RTHOOK(14);
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11464[Dtype(RTCW(loc2))-1503])(loc2);
				if (tb1) {
					RTHOOK(15);
					loc2 = (EIF_REFERENCE) NULL;
				}
			} else {
				RTHOOK(16);
				tr1 = RTMS32_EX_H("I\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000x\000\000\000m\000\000\000l\000\000\000 \000\000\000e\000\000\000n\000\000\000c\000\000\000o\000\000\000d\000\000\000i\000\000\000n\000\000\000g\000\000\000:\000\000\000 \000\000\000\"\000\000\000",23,1382329890);
				tr1 = F1510_14585(tr1, arg2);
				tr2 = RTMS32_EX_H("\"\000\000\000.\000\000\000",2,8750);
				tr1 = F1510_14585(RTCW(tr1), tr2);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
			}
		}
	}
	RTHOOK(17);
	if ((EIF_BOOLEAN)(loc2 == NULL)) {
		RTHOOK(18);
		tr1 = RTOSCF(6148,F396_6148, (Current));
		F396_6111(Current, tr1);
	} else {
		RTHOOK(19);
		F396_6111(Current, loc2);
	}
	RTHOOK(20);
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R5935[Dtype(RTCW(tr1))-476])(tr1, arg1, arg2, arg3);
	RTHOOK(21);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.report_error */
void F396_6139 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTEAA("report_error", 395, Current, 2, 1, 5962);
	RTGC;
	RTHOOK(1);
	loc2 = F396_6119(Current);
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5557[Dtype(Current)-395])(Current);
	RTHOOK(3);
	loc1 = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R11486[Dtype(RTCW(arg1))-1503])(arg1);
	F1508_14451(RTCW(loc1), ti4_1);
	RTHOOK(4);
	F1510_14565(RTCW(loc1), arg1);
	RTHOOK(5);
	tr1 = RTLNSMART(eif_new_type(1509, 0).id);
	F1508_14453(RTCW(tr1), loc1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTHOOK(6);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_3_) == NULL)) {
		RTHOOK(7);
		RTAR(Current, loc2);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) loc2;
	}
	RTHOOK(8);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(9);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
	F1510_14579(RTCW(loc1), tw1);
	RTHOOK(10);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '(';
	F1510_14579(RTCW(loc1), tw1);
	RTHOOK(11);
	tr1 = RTMS32_EX_H("p\000\000\000o\000\000\000s\000\000\000i\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000=\000\000\000",9,2064843837);
	F1510_14568(RTCW(loc1), tr1);
	RTHOOK(12);
	tr1 = F1253_11732(RTCW(loc2));
	F1510_14568(RTCW(loc1), tr1);
	RTHOOK(13);
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5936[Dtype(RTCW(tr1))-476])(tr1, loc1);
	RTHOOK(15);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.report_warning */
void F396_6140 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("report_warning", 395, Current, 1, 1, 5963);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O11684[Dtype(arg1)-1507]);
	F1508_14451(RTCW(loc1), ti4_1);
	RTHOOK(2);
	F1510_14565(RTCW(loc1), arg1);
	RTHOOK(3);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc1;
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.report_truncated_content */
void F396_6141 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("report_truncated_content", 395, Current, 0, 1, 5964);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_2_)) {
	} else {
		RTHOOK(2);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_5_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(3);
		if ((EIF_BOOLEAN)(arg1 != NULL)) {
			RTHOOK(4);
			tr1 = RTMS32_EX_H("E\000\000\000n\000\000\000d\000\000\000 \000\000\000o\000\000\000f\000\000\000 \000\000\000i\000\000\000n\000\000\000p\000\000\000u\000\000\000t\000\000\000:\000\000\000 \000\000\000",14,500258080);
			tr2 = F1500_14215(RTCW(arg1));
			tr1 = F1510_14585(tr1, tr2);
			F396_6140(Current, tr1);
		} else {
			RTHOOK(5);
			tr1 = RTMS32_EX_H("E\000\000\000n\000\000\000d\000\000\000 \000\000\000o\000\000\000f\000\000\000 \000\000\000i\000\000\000n\000\000\000p\000\000\000u\000\000\000t\000\000\000.\000\000\000",13,446549550);
			F396_6140(Current, tr1);
		}
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.report_syntax_error */
void F396_6142 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("report_syntax_error", 395, Current, 0, 1, 5965);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(2);
		tr1 = RTMS32_EX_H("S\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000 \000\000\000e\000\000\000r\000\000\000r\000\000\000o\000\000\000r\000\000\000:\000\000\000 \000\000\000",14,1046907424);
		tr2 = F1500_14215(RTCW(arg1));
		tr1 = F1510_14585(tr1, tr2);
		F396_6140(Current, tr1);
	} else {
		RTHOOK(3);
		tr1 = RTMS32_EX_H("S\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000 \000\000\000e\000\000\000r\000\000\000r\000\000\000o\000\000\000r\000\000\000.\000\000\000",13,1480481838);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[Dtype(Current)-395])(Current, tr1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.report_unsupported_bom_value */
void F396_6143 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,tr2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("report_unsupported_bom_value", 395, Current, 0, 1, 5966);
	RTGC;
	RTHOOK(1);
	tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000s\000\000\000u\000\000\000p\000\000\000p\000\000\000o\000\000\000r\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000B\000\000\000O\000\000\000M\000\000\000 \000\000\000v\000\000\000a\000\000\000l\000\000\000u\000\000\000e\000\000\000 \000\000\000\"\000\000\000",23,1980359714);
	tr2 = F1500_14215(RTCW(arg1));
	tr1 = F1510_14585(tr1, tr2);
	tr2 = RTMS32_EX_H("\"\000\000\000.\000\000\000",2,8750);
	tr1 = F1510_14585(RTCW(tr1), tr2);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[Dtype(Current)-395])(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.report_missing_attribute_value */
void F396_6144 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("report_missing_attribute_value", 395, Current, 0, 2, 5967);
	RTGC;
	RTHOOK(1);
	tr1 = RTMS32_EX_H("A\000\000\000t\000\000\000t\000\000\000r\000\000\000i\000\000\000b\000\000\000u\000\000\000t\000\000\000e\000\000\000s\000\000\000 \000\000\000w\000\000\000i\000\000\000t\000\000\000h\000\000\000o\000\000\000u\000\000\000t\000\000\000 \000\000\000a\000\000\000n\000\000\000y\000\000\000 \000\000\000v\000\000\000a\000\000\000l\000\000\000u\000\000\000e\000\000\000 \000\000\000a\000\000\000r\000\000\000e\000\000\000 \000\000\000f\000\000\000o\000\000\000r\000\000\000b\000\000\000i\000\000\000d\000\000\000d\000\000\000e\000\000\000n\000\000\000",42,1447267438);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[Dtype(Current)-395])(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.report_unexpected_content */
void F396_6145 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("report_unexpected_content", 395, Current, 0, 1, 5968);
	RTGC;
	RTHOOK(1);
	tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000o\000\000\000n\000\000\000t\000\000\000e\000\000\000n\000\000\000t\000\000\000 \000\000\000(\000\000\000n\000\000\000o\000\000\000t\000\000\000 \000\000\000w\000\000\000e\000\000\000l\000\000\000l\000\000\000-\000\000\000f\000\000\000o\000\000\000r\000\000\000m\000\000\000e\000\000\000d\000\000\000 \000\000\000X\000\000\000M\000\000\000L\000\000\000)\000\000\000",40,1259693865);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[Dtype(Current)-395])(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.report_unexpected_content_in_prolog */
void F396_6146 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("report_unexpected_content_in_prolog", 395, Current, 0, 1, 5969);
	RTGC;
	RTHOOK(1);
	tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000o\000\000\000n\000\000\000t\000\000\000e\000\000\000n\000\000\000t\000\000\000 \000\000\000i\000\000\000n\000\000\000 \000\000\000p\000\000\000r\000\000\000o\000\000\000l\000\000\000o\000\000\000g\000\000\000 \000\000\000(\000\000\000n\000\000\000o\000\000\000t\000\000\000 \000\000\000w\000\000\000e\000\000\000l\000\000\000l\000\000\000-\000\000\000f\000\000\000o\000\000\000r\000\000\000m\000\000\000e\000\000\000d\000\000\000 \000\000\000X\000\000\000M\000\000\000L\000\000\000)\000\000\000",50,176380713);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[Dtype(Current)-395])(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.set_encoding_from_bom */
void F396_6147 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	struct eif_ex_91 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(104, 0x00).id);
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("set_encoding_from_bom", 395, Current, 1, 1, 5970);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(1526,F105_1526, (RTCW(loc1)));
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11492[Dtype(RTCW(arg1))-1503])(arg1, tr1);
	if (tb1) {
		RTHOOK(2);
		tr1 = RTMS_EX_H("UTF-8",5,1414538040);
		F396_6111(Current, tr1);
	} else {
		RTHOOK(3);
		F396_6143(Current, arg1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.default_encoding */

EIF_REFERENCE F396_6148 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6148,RTMS32_EX_H("U\000\000\000T\000\000\000F\000\000\000-\000\000\0008\000\000\000",5,1414538040));
}

/* {XML_STANDARD_PARSER}.bom */
EIF_REFERENCE F396_6149 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("bom", 395, Current, 3, 1, 5972);
	RTGC;
	RTHOOK(1);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O11684[Dtype(arg1)-1507]);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 0L))) {
	} else {
		RTHOOK(3);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			RTHOOK(4);
			tb1 = '\01';
			if (!(EIF_BOOLEAN) (loc1 > loc2)) {
				tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11450[Dtype(RTCW(arg1))-1503])(arg1, loc1);
				tb1 = (EIF_BOOLEAN) !F396_6150(Current, tw1);
			}
			if (tb1) break;
			RTHOOK(5);
			loc1++;
		}
		RTHOOK(6);
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 1L))) {
			RTHOOK(7);
			loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R11527[Dtype(RTCW(arg1))-1503])(arg1, ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
			RTHOOK(8);
			tb2 = F1508_14483(RTCW(loc3));
			if (tb2) {
				RTHOOK(9);
				tr1 = F1500_14208(RTCW(loc3));
				RTHOOK(10);
				RTLE;
				RTEE;
				return (EIF_REFERENCE) tr1;
			}
		}
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {XML_STANDARD_PARSER}.is_bom_character */
EIF_BOOLEAN F396_6150 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_bom_character", 395, Current, 0, 1, 5973);
	RTGC;
	RTHOOK(1);
	switch (arg1) {
		case (EIF_CHARACTER_8) '\273':
		case (EIF_CHARACTER_8) '\277':
		case (EIF_CHARACTER_8) '\357':
			RTHOOK(2);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			break;
		case (EIF_CHARACTER_8) '\376':
		case (EIF_CHARACTER_8) '\377':
			RTHOOK(3);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			break;
		case (EIF_CHARACTER_8) '\000':
			RTHOOK(4);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			break;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STANDARD_PARSER}.new_encoded_buffer */
EIF_REFERENCE F396_6151 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("new_encoded_buffer", 395, Current, 0, 2, 5974);
	RTGC;
	RTHOOK(1);
	tr1 = RTMS_EX_H("UTF-8",5,1414538040);
	tb1 = F1500_14197(RTCW(arg1), tr1);
	if (tb1) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(400, 0x00).id, 400, _OBJSIZ_1_0_0_1_0_0_0_0_);
		F401_6243(RTCW(tr1), arg2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(4);
		tr1 = RTMS_EX_H("ISO-8859-1",10,1255164721);
		tb1 = F1500_14197(RTCW(arg1), tr1);
		if (tb1) {
			RTHOOK(5);
			RTHOOK(6);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) arg2;
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {XML_STANDARD_PARSER}.register_doctype */
void F396_6152 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("register_doctype", 395, Current, 0, 1, 5975);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.report_error_from_callback */
void F396_6153 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("report_error_from_callback", 395, Current, 0, 1, 5976);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[Dtype(Current)-395])(Current, arg1);
	RTHOOK(2);
	RTEE;
}

/* {XML_STANDARD_PARSER}.rewind_character */
void F396_6157 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTCDT;
	
	
	RTEAA("rewind_character", 395, Current, 0, 0, 5980);
	RTHOOK(1);
	*(EIF_CHARACTER_32 *)(Current + O5583[dtype-395]) = (EIF_CHARACTER_32) *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
	RTHOOK(3);
	RTEE;
}

/* {XML_STANDARD_PARSER}.read_character */
void F396_6158 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("read_character", 395, Current, 1, 0, 5981);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_CHARACTER_32 *)(Current + O5583[dtype-395]);
	RTHOOK(2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
	if ((EIF_BOOLEAN)(loc1 == tw1)) {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5634[Dtype(RTCW(tr1))-398])(tr1);
		if (tb1) {
			RTHOOK(4);
			tr1 = RTMS32_EX_H("N\000\000\000o\000\000\000 \000\000\000m\000\000\000o\000\000\000r\000\000\000e\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000s\000\000\000",18,147221875);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
		} else {
			RTHOOK(5);
			loc1 = F396_6159(Current, *(EIF_REFERENCE *)(Current + _REFACS_2_));
		}
	} else {
		RTHOOK(6);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
		*(EIF_CHARACTER_32 *)(Current + O5583[dtype-395]) = (EIF_CHARACTER_32) tw1;
		RTHOOK(7);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5634[Dtype(RTCW(tr1))-398])(tr1);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) = (EIF_BOOLEAN) tb1;
	}
	RTHOOK(8);
	*(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]) = (EIF_CHARACTER_32) loc1;
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.internal_next_character */
EIF_CHARACTER_32 F396_6159 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc2 = (EIF_NATURAL_32) 0;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("internal_next_character", 395, Current, 2, 1, 5982);
	RTGC;
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5640[Dtype(RTCW(arg1))-398])(arg1);
	RTHOOK(2);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5634[Dtype(RTCW(arg1))-398])(arg1);
	if (tb1) {
		RTHOOK(3);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(4);
		loc1 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	} else {
		RTHOOK(5);
		loc2 = RTOSCF(6194,F396_6194, (Current));
		RTHOOK(6);
		loc1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE)) R5639[Dtype(RTCW(arg1))-398])(arg1);
		RTHOOK(7);
		if ((EIF_BOOLEAN)(loc1 == loc2)) {
			for (;;) {
				RTHOOK(8);
				tb1 = '\01';
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5634[Dtype(RTCW(arg1))-398])(arg1);
				if (!tb2) {
					tb1 = (EIF_BOOLEAN)(loc1 != loc2);
				}
				if (tb1) break;
				RTHOOK(9);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R5640[Dtype(RTCW(arg1))-398])(arg1);
				RTHOOK(10);
				loc1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE)) R5639[Dtype(RTCW(arg1))-398])(arg1);
			}
			RTHOOK(11);
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5634[Dtype(RTCW(arg1))-398])(arg1);
			if (tb2) {
				RTHOOK(12);
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5634[Dtype(RTCW(arg1))-398])(arg1);
				*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) = (EIF_BOOLEAN) tb2;
				RTHOOK(13);
				loc1 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
			}
		}
		RTHOOK(14);
		tw1 = (EIF_CHARACTER_32) loc1;
		RTHOOK(15);
		RTLE;
		RTEE;
		return (EIF_CHARACTER_32) tw1;
	}
	RTHOOK(17);
	RTLE;
	RTEE;
	return (EIF_CHARACTER_32) 0;
}

/* {XML_STANDARD_PARSER}.read_until_non_space_character */
void F396_6160 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("read_until_non_space_character", 395, Current, 1, 0, 5983);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
		RTHOOK(2);
		tr1 = RTMS_EX_H("Out of Input data.",18,2026462766);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
		
	} else {
		RTHOOK(4);
		F396_6158(Current);
		RTHOOK(5);
		loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
		for (;;) {
			RTHOOK(6);
			tb1 = '\01';
			if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
				tr1 = RTLNS(eif_new_type(1452, 0x00).id, 1452, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = loc1;
				tb2 = F1451_13991(RTCW(tr1));
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) break;
			RTHOOK(7);
			F396_6158(Current);
			RTHOOK(8);
			loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
		}
		RTHOOK(9);
		*(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]) = (EIF_CHARACTER_32) loc1;
	}
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {XML_STANDARD_PARSER}.next_tag */
EIF_REFERENCE F396_6161 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("next_tag", 395, Current, 3, 0, 5984);
	RTGC;
	RTHOOK(1);
	loc3 = F396_6179(Current);
	RTHOOK(2);
	F396_6160(Current);
	RTHOOK(3);
	loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
	RTHOOK(4);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
		RTHOOK(5);
		tr1 = RTMS_EX_H("Can not find tag name",21,636553317);
		F396_6141(Current, tr1);
	} else {
		RTHOOK(6);
		if (F396_6170(Current, loc1)) {
			for (;;) {
				RTHOOK(7);
				tb1 = '\01';
				if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
					tb1 = (EIF_BOOLEAN) !F396_6171(Current, loc1);
				}
				if (tb1) break;
				RTHOOK(8);
				tb2 = '\0';
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
				if ((EIF_BOOLEAN)(loc1 == tw1)) {
					tb2 = (EIF_BOOLEAN)(loc2 == NULL);
				}
				if (tb2) {
					RTHOOK(9);
					loc2 = F1508_14466(RTCW(loc3));
					RTHOOK(10);
					F1510_14595(RTCW(loc3));
				} else {
					RTHOOK(11);
					F1510_14579(RTCW(loc3), loc1);
				}
				RTHOOK(12);
				F396_6158(Current);
				RTHOOK(13);
				loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
			}
		}
	}
	RTHOOK(14);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1419,1509,1509,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = loc2;
	RTAR(tr1,loc2);
	tr2 = F1508_14466(RTCW(loc3));
	((EIF_TYPED_VALUE *)tr1+2)->it_r = tr2;
	RTAR(tr1,tr2);
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(15);
	F1510_14595(RTCW(loc3));
	RTHOOK(17);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STANDARD_PARSER}.next_entity */
EIF_REFERENCE F396_6162 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("next_entity", 395, Current, 4, 0, 5985);
	RTGC;
	RTHOOK(1);
	loc4 = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1500_14155(RTCW(loc4));
	RTHOOK(2);
	F396_6158(Current);
	RTHOOK(3);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '#';
	if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]) == tw1)) {
		RTHOOK(4);
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(5);
		F396_6158(Current);
		RTHOOK(6);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'x';
		if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]) == tw1)) {
			RTHOOK(7);
			loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			RTHOOK(8);
			F396_6158(Current);
		}
	}
	RTHOOK(9);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
		
		RTHOOK(11);
		tr1 = RTMS32_EX_H("I\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000e\000\000\000n\000\000\000t\000\000\000i\000\000\000t\000\000\000y\000\000\000 \000\000\000s\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000",21,1738705016);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
		RTHOOK(12);
		Result = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_1_0_2_);
		F1508_14451(RTCW(Result), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 3L)));
		RTHOOK(13);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
		F1510_14579(RTCW(Result), tw1);
		RTHOOK(14);
		if (loc2) {
			RTHOOK(15);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '#';
			F1510_14579(RTCW(Result), tw1);
			RTHOOK(16);
			if (loc3) {
				RTHOOK(17);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'x';
				F1510_14579(RTCW(Result), tw1);
			}
		}
		RTHOOK(18);
		F1510_14568(RTCW(Result), loc4);
	} else {
		RTHOOK(19);
		loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
		RTHOOK(20);
		if (loc2) {
			RTHOOK(21);
			if (loc3) {
				for (;;) {
					RTHOOK(22);
					tb1 = '\01';
					tb2 = '\01';
					if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
						tr1 = RTLNS(eif_new_type(1452, 0x00).id, 1452, _OBJSIZ_0_0_0_1_0_0_0_0_);
						*(EIF_CHARACTER_32 *)tr1 = loc1;
						tb3 = F1451_13990(RTCW(tr1));
						tb2 = (EIF_BOOLEAN) !tb3;
					}
					if (!tb2) {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ';';
						tb1 = (EIF_BOOLEAN)(loc1 == tw1);
					}
					if (tb1) break;
					RTHOOK(23);
					F1510_14579(RTCW(loc4), loc1);
					RTHOOK(24);
					F396_6158(Current);
					RTHOOK(25);
					loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
				}
			} else {
				for (;;) {
					RTHOOK(26);
					tb2 = '\01';
					tb3 = '\01';
					if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
						tb4 = EIF_TEST(isdigit(loc1));
						tb3 = (EIF_BOOLEAN) !tb4;
					}
					if (!tb3) {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ';';
						tb2 = (EIF_BOOLEAN)(loc1 == tw1);
					}
					if (tb2) break;
					RTHOOK(27);
					F1510_14579(RTCW(loc4), loc1);
					RTHOOK(28);
					F396_6158(Current);
					RTHOOK(29);
					loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
				}
			}
		} else {
			for (;;) {
				RTHOOK(30);
				tb3 = '\01';
				tb4 = '\01';
				if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
					tb4 = (EIF_BOOLEAN) !F396_6172(Current, loc1);
				}
				if (!tb4) {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ';';
					tb3 = (EIF_BOOLEAN)(loc1 == tw1);
				}
				if (tb3) break;
				RTHOOK(31);
				F1510_14579(RTCW(loc4), loc1);
				RTHOOK(32);
				F396_6158(Current);
				RTHOOK(33);
				loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
			}
		}
		RTHOOK(34);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ';';
		if ((EIF_BOOLEAN)(loc1 == tw1)) {
			RTHOOK(35);
			if (loc2) {
				RTHOOK(36);
				if (loc3) {
					RTHOOK(37);
					Result = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F1508_14451(RTCW(Result), ((EIF_INTEGER_32) 1L));
					RTHOOK(38);
					tu4_1 = F396_6168(Current, loc4);
					F1502_14255(RTCW(Result), tu4_1);
				} else {
					RTHOOK(39);
					tb4 = F1500_14186(RTCW(loc4));
					if (tb4) {
						RTHOOK(40);
						Result = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
						F1508_14451(RTCW(Result), ((EIF_INTEGER_32) 1L));
						RTHOOK(41);
						tu4_1 = F1500_14226(RTCW(loc4));
						F1502_14255(RTCW(Result), tu4_1);
					} else {
						RTHOOK(42);
						Result = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_1_0_2_);
						F1508_14451(RTCW(Result), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 2L)));
						RTHOOK(43);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
						F1510_14579(RTCW(Result), tw1);
						RTHOOK(44);
						F1510_14568(RTCW(Result), loc4);
						RTHOOK(45);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ';';
						F1510_14579(RTCW(Result), tw1);
					}
				}
			} else {
				RTHOOK(46);
				Result = F396_6167(Current, loc4);
				RTHOOK(47);
				RTLE;
				RTEE;
				return (EIF_REFERENCE) Result;
			}
		} else {
			RTHOOK(48);
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
				RTHOOK(49);
				Result = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_1_0_2_);
				F1508_14451(RTCW(Result), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 3L)));
				RTHOOK(50);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
				F1510_14579(RTCW(Result), tw1);
				RTHOOK(51);
				if (loc2) {
					RTHOOK(52);
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '#';
					F1510_14579(RTCW(Result), tw1);
					RTHOOK(53);
					if (loc3) {
						RTHOOK(54);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'x';
						F1510_14579(RTCW(Result), tw1);
					}
				}
				RTHOOK(55);
				F1510_14568(RTCW(Result), loc4);
				RTHOOK(56);
				tr1 = RTMS32_EX_H("I\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000e\000\000\000n\000\000\000t\000\000\000i\000\000\000t\000\000\000y\000\000\000 \000\000\000s\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000 \000\000\000",22,580163872);
				tr1 = F1510_14585(tr1, loc4);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
			} else {
				RTHOOK(57);
				F396_6157(Current);
				RTHOOK(58);
				Result = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_1_0_2_);
				F1508_14451(RTCW(Result), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 3L)));
				RTHOOK(59);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
				F1510_14579(RTCW(Result), tw1);
				RTHOOK(60);
				if (loc2) {
					RTHOOK(61);
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '#';
					F1510_14579(RTCW(Result), tw1);
					RTHOOK(62);
					if (loc3) {
						RTHOOK(63);
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'x';
						F1510_14579(RTCW(Result), tw1);
					}
				}
				RTHOOK(64);
				F1510_14568(RTCW(Result), loc4);
				RTHOOK(65);
				tr1 = RTMS32_EX_H("I\000\000\000n\000\000\000v\000\000\000a\000\000\000l\000\000\000i\000\000\000d\000\000\000 \000\000\000e\000\000\000n\000\000\000t\000\000\000i\000\000\000t\000\000\000y\000\000\000 \000\000\000s\000\000\000y\000\000\000n\000\000\000t\000\000\000a\000\000\000x\000\000\000 \000\000\000",22,580163872);
				tr1 = F1510_14585(tr1, loc4);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
			}
		}
	}
	RTHOOK(66);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STANDARD_PARSER}.next_attribute_name */
EIF_REFERENCE F396_6163 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLIU(5);
	
	RTEAA("next_attribute_name", 395, Current, 3, 0, 5986);
	RTGC;
	RTHOOK(1);
	loc2 = F396_6180(Current);
	RTHOOK(2);
	F396_6160(Current);
	RTHOOK(3);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
		RTHOOK(4);
		tr1 = RTMS_EX_H("no tag closure",14,1150800997);
		F396_6141(Current, tr1);
	} else {
		RTHOOK(5);
		loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
		RTHOOK(6);
		if (F396_6173(Current, loc1)) {
			RTHOOK(7);
			F1510_14579(RTCW(loc2), loc1);
			RTHOOK(8);
			F396_6158(Current);
			RTHOOK(9);
			loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
			for (;;) {
				RTHOOK(10);
				tb1 = '\01';
				if (!*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
					tb1 = (EIF_BOOLEAN) !F396_6174(Current, loc1);
				}
				if (tb1) break;
				RTHOOK(11);
				F1510_14579(RTCW(loc2), loc1);
				RTHOOK(12);
				F396_6158(Current);
				RTHOOK(13);
				loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
			}
		}
	}
	RTHOOK(14);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
	loc3 = F1508_14463(RTCW(loc2), tw1, ((EIF_INTEGER_32) 1L));
	RTHOOK(15);
	if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 1L))) {
		RTHOOK(16);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1419,1509,1509,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		tr2 = F1510_14613(RTCW(loc2), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L)));
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
		tr2 = F1510_14613(RTCW(loc2), (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)), ti4_1);
		((EIF_TYPED_VALUE *)tr1+2)->it_r = tr2;
		RTAR(tr1,tr2);
		Result = (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(17);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1419,65534,1509,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		tr2 = F1508_14466(RTCW(loc2));
		((EIF_TYPED_VALUE *)tr1+2)->it_r = tr2;
		RTAR(tr1,tr2);
		Result = (EIF_REFERENCE) tr1;
	}
	RTHOOK(18);
	F1510_14595(RTCW(loc2));
	RTHOOK(20);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STANDARD_PARSER}.next_attribute_value */
EIF_REFERENCE F396_6164 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("next_attribute_value", 395, Current, 5, 0, 5987);
	RTGC;
	RTHOOK(1);
	loc5 = F396_6181(Current);
	RTHOOK(2);
	F396_6158(Current);
	RTHOOK(3);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
		RTHOOK(4);
		tr1 = RTMS_EX_H("No attribute value",18,1751605349);
		F396_6141(Current, tr1);
	} else {
		RTHOOK(5);
		loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
		RTHOOK(6);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
		if ((EIF_BOOLEAN)(loc1 == tw1)) {
			RTHOOK(7);
			loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			RTHOOK(8);
			F396_6158(Current);
			RTHOOK(9);
			loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
		} else {
			RTHOOK(10);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\'';
			if ((EIF_BOOLEAN)(loc1 == tw1)) {
				RTHOOK(11);
				loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				RTHOOK(12);
				F396_6158(Current);
				RTHOOK(13);
				loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
			} else {
				RTHOOK(14);
				tb1 = '\01';
				tb2 = '\01';
				tr1 = RTLNS(eif_new_type(1452, 0x00).id, 1452, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = loc1;
				tb3 = F1451_13991(RTCW(tr1));
				if (!tb3) {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '/';
					tb2 = (EIF_BOOLEAN)(loc1 == tw1);
				}
				if (!tb2) {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
					tb1 = (EIF_BOOLEAN)(loc1 == tw1);
				}
				if (tb1) {
					RTHOOK(15);
					tr1 = RTMS32_EX_H("u\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000s\000\000\000p\000\000\000a\000\000\000c\000\000\000e\000\000\000 \000\000\000a\000\000\000f\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000=\000\000\000 \000\000\000i\000\000\000n\000\000\000 \000\000\000a\000\000\000t\000\000\000t\000\000\000r\000\000\000i\000\000\000b\000\000\000u\000\000\000t\000\000\000e\000\000\000 \000\000\000d\000\000\000e\000\000\000c\000\000\000l\000\000\000a\000\000\000r\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",49,1583729262);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
				}
			}
		}
	}
	RTHOOK(16);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
		RTHOOK(17);
		tr1 = RTMS_EX_H("No attribute value",18,1751605349);
		F396_6141(Current, tr1);
	} else {
		RTHOOK(18);
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_)) {
			RTHOOK(19);
			loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			for (;;) {
				RTHOOK(20);
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) || loc4) || *(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_))) break;
				RTHOOK(21);
				tb1 = '\0';
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc2 && (EIF_BOOLEAN) !loc3)) {
					tb2 = '\01';
					tb3 = '\01';
					tr1 = RTLNS(eif_new_type(1452, 0x00).id, 1452, _OBJSIZ_0_0_0_1_0_0_0_0_);
					*(EIF_CHARACTER_32 *)tr1 = loc1;
					tb4 = F1451_13991(RTCW(tr1));
					if (!tb4) {
						tb3 = (EIF_BOOLEAN)(loc1 == (EIF_CHARACTER_32) 47U);
					}
					if (!tb3) {
						tb2 = (EIF_BOOLEAN)(loc1 == (EIF_CHARACTER_32) 62U);
					}
					tb1 = tb2;
				}
				if (tb1) {
					RTHOOK(22);
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					RTHOOK(23);
					switch (loc1) {
						case (EIF_CHARACTER_8) '&':
							RTHOOK(24);
							tr1 = F396_6162(Current);
							F1510_14568(RTCW(loc5), tr1);
							break;
						case (EIF_CHARACTER_8) '\"':
							RTHOOK(25);
							if (loc2) {
								RTHOOK(26);
								loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								RTHOOK(27);
								if (loc3) {
									RTHOOK(28);
									F1510_14579(RTCW(loc5), loc1);
								} else {
									RTHOOK(29);
									tr1 = RTMS32_EX_H("u\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000\"\000\000\000 \000\000\000i\000\000\000n\000\000\000 \000\000\000a\000\000\000t\000\000\000t\000\000\000r\000\000\000i\000\000\000b\000\000\000u\000\000\000t\000\000\000e\000\000\000 \000\000\000v\000\000\000a\000\000\000l\000\000\000u\000\000\000e\000\000\000",31,571762533);
									(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
								}
							}
							break;
						case (EIF_CHARACTER_8) '\'':
							RTHOOK(30);
							if (loc3) {
								RTHOOK(31);
								loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								RTHOOK(32);
								if (loc2) {
									RTHOOK(33);
									F1510_14579(RTCW(loc5), loc1);
								} else {
									RTHOOK(34);
									tr1 = RTMS32_EX_H("u\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000\'\000\000\000 \000\000\000i\000\000\000n\000\000\000 \000\000\000a\000\000\000t\000\000\000t\000\000\000r\000\000\000i\000\000\000b\000\000\000u\000\000\000t\000\000\000e\000\000\000 \000\000\000v\000\000\000a\000\000\000l\000\000\000u\000\000\000e\000\000\000",31,1685525861);
									(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
								}
							}
							break;
						default:
							RTHOOK(35);
							F1510_14579(RTCW(loc5), loc1);
							break;
					}
					RTHOOK(36);
					if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
						RTHOOK(37);
						F396_6158(Current);
					}
					RTHOOK(38);
					loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
				}
			}
			RTHOOK(39);
			if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_))) {
				RTHOOK(40);
				if (loc4) {
					RTHOOK(41);
					Result = F1508_14466(RTCW(loc5));
				} else {
					RTHOOK(42);
					tr1 = RTMS_EX_H("attribute value is truncated",28,1727624804);
					F396_6141(Current, tr1);
				}
			} else {
				RTHOOK(43);
				Result = F1508_14466(RTCW(loc5));
			}
		}
	}
	RTHOOK(44);
	F1510_14595(RTCW(loc5));
	RTHOOK(46);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STANDARD_PARSER}.next_attribute_data */
EIF_REFERENCE F396_6165 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc6);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc3);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,Result);
	RTLR(7,loc4);
	RTLIU(8);
	
	RTEAA("next_attribute_data", 395, Current, 6, 0, 5988);
	RTGC;
	RTHOOK(1);
	loc6 = F396_6163(Current);
	RTHOOK(2);
	loc2 = eif_boxed_item(loc6,2);
	RTHOOK(3);
	loc3 = eif_boxed_item(loc6,1);
	RTHOOK(4);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11464[Dtype(RTCW(loc2))-1503])(loc2);
	if (tb1) {
		RTHOOK(5);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
			RTHOOK(6);
			tr1 = RTMS_EX_H("in start tag declaration",24,735103342);
			F396_6141(Current, tr1);
		} else {
			RTHOOK(7);
			loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
			RTHOOK(8);
			tb1 = '\01';
			tb2 = '\01';
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
			if (!(EIF_BOOLEAN)(loc1 == tw1)) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '/';
				tb2 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (!tb2) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\?';
				tb1 = (EIF_BOOLEAN)(loc1 == tw1);
			}
			if (tb1) {
			} else {
				RTHOOK(9);
				tr1 = RTMS_EX_H("Error with attribute declaration.",33,49419310);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
			}
		}
	} else {
		RTHOOK(10);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5556[dtype-395])(Current);
		RTHOOK(11);
		loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
		RTHOOK(12);
		tr1 = RTLNS(eif_new_type(1452, 0x00).id, 1452, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)tr1 = loc1;
		tb1 = F1451_13991(RTCW(tr1));
		if (tb1) {
			RTHOOK(13);
			loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			RTHOOK(14);
			F396_6160(Current);
			RTHOOK(15);
			loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
		}
		RTHOOK(16);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
			RTHOOK(17);
			tr1 = RTMS_EX_H("only attribute name",19,354778725);
			F396_6141(Current, tr1);
		} else {
			RTHOOK(18);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '=';
			if ((EIF_BOOLEAN)(loc1 == tw1)) {
				RTHOOK(19);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R5557[dtype-395])(Current);
			} else {
				RTHOOK(20);
				tb1 = '\01';
				tb2 = '\01';
				if (!loc5) {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
					tb2 = (EIF_BOOLEAN)(loc1 == tw1);
				}
				if (!tb2) {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '/';
					tb1 = (EIF_BOOLEAN)(loc1 == tw1);
				}
				if (tb1) {
					RTHOOK(21);
					F396_6144(Current, loc3, loc2);
					RTHOOK(22);
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,1419,1507,1507,1509,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr1 = RTLNTS(typres0.id, 4, 0);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_r = loc3;
					RTAR(tr1,loc3);
					((EIF_TYPED_VALUE *)tr1+2)->it_r = loc2;
					RTAR(tr1,loc2);
					tr2 = RTMS32_EX_H("",0,0);
					((EIF_TYPED_VALUE *)tr1+3)->it_r = tr2;
					RTAR(tr1,tr2);
					Result = (EIF_REFERENCE) tr1;
				} else {
					RTHOOK(23);
					tr1 = RTMS32_EX_H("u\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000\'\000\000\000",22,169384743);
					tr2 = F396_6166(Current, loc1);
					tr1 = F1510_14585(tr1, tr2);
					tr2 = RTMS32_EX_H("\'\000\000\000 \000\000\000i\000\000\000n\000\000\000 \000\000\000a\000\000\000t\000\000\000t\000\000\000r\000\000\000i\000\000\000b\000\000\000u\000\000\000t\000\000\000e\000\000\000 \000\000\000n\000\000\000a\000\000\000m\000\000\000e\000\000\000",19,886221413);
					tr1 = F1510_14585(RTCW(tr1), tr2);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
				}
			}
			RTHOOK(24);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(Result == NULL) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_))) {
				
				RTHOOK(26);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R5556[dtype-395])(Current);
				RTHOOK(27);
				F396_6158(Current);
				RTHOOK(28);
				loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
				RTHOOK(29);
				tr1 = RTLNS(eif_new_type(1452, 0x00).id, 1452, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = loc1;
				tb1 = F1451_13991(RTCW(tr1));
				if (tb1) {
					RTHOOK(30);
					F396_6160(Current);
					RTHOOK(31);
					loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
				}
				RTHOOK(32);
				if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
					RTHOOK(33);
					tr1 = RTMS_EX_H("expecting attribute value after = sign",38,1641746030);
					F396_6141(Current, tr1);
				} else {
					RTHOOK(34);
					F396_6157(Current);
					RTHOOK(35);
					loc4 = F396_6164(Current);
					RTHOOK(36);
					if ((EIF_BOOLEAN)(loc4 == NULL)) {
						RTHOOK(37);
						if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_))) {
						} else {
							RTHOOK(38);
							tr1 = RTMS_EX_H("expecting valid attribute value",31,1278772069);
							F396_6142(Current, tr1);
						}
					} else {
						RTHOOK(39);
						(FUNCTION_CAST(void, (EIF_REFERENCE)) R5557[dtype-395])(Current);
						RTHOOK(40);
						{
							static EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,1419,1507,1507,1507,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr1 = RTLNTS(typres0.id, 4, 0);
						}
						((EIF_TYPED_VALUE *)tr1+1)->it_r = loc3;
						RTAR(tr1,loc3);
						((EIF_TYPED_VALUE *)tr1+2)->it_r = loc2;
						RTAR(tr1,loc2);
						((EIF_TYPED_VALUE *)tr1+3)->it_r = loc4;
						RTAR(tr1,loc4);
						Result = (EIF_REFERENCE) tr1;
						RTHOOK(41);
						if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_)) {
							RTHOOK(42);
							tr1 = RTMS_EX_H("in start tag declaration",24,735103342);
							F396_6141(Current, tr1);
						} else {
							RTHOOK(43);
							loc1 = *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]);
							RTHOOK(44);
							tb1 = '\01';
							tb2 = '\01';
							tb3 = '\01';
							tr1 = RTLNS(eif_new_type(1452, 0x00).id, 1452, _OBJSIZ_0_0_0_1_0_0_0_0_);
							*(EIF_CHARACTER_32 *)tr1 = loc1;
							tb4 = F1451_13991(RTCW(tr1));
							if (!tb4) {
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
								tb3 = (EIF_BOOLEAN)(loc1 == tw1);
							}
							if (!tb3) {
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '/';
								tb2 = (EIF_BOOLEAN)(loc1 == tw1);
							}
							if (!tb2) {
								tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\?';
								tb1 = (EIF_BOOLEAN)(loc1 == tw1);
							}
							if (tb1) {
							} else {
								RTHOOK(45);
								tr1 = RTMS32_EX_H("u\000\000\000n\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000e\000\000\000d\000\000\000 \000\000\000c\000\000\000h\000\000\000a\000\000\000r\000\000\000a\000\000\000c\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000\'\000\000\000",22,169384743);
								tr2 = F396_6166(Current, *(EIF_CHARACTER_32 *)(Current + O5582[dtype-395]));
								tr1 = F1510_14585(tr1, tr2);
								tr2 = RTMS32_EX_H("\'\000\000\000 \000\000\000a\000\000\000f\000\000\000t\000\000\000e\000\000\000r\000\000\000 \000\000\000a\000\000\000t\000\000\000t\000\000\000r\000\000\000i\000\000\000b\000\000\000u\000\000\000t\000\000\000e\000\000\000 \000\000\000d\000\000\000e\000\000\000c\000\000\000l\000\000\000a\000\000\000r\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000 \000\000\000(\000\000\000e\000\000\000x\000\000\000p\000\000\000e\000\000\000c\000\000\000t\000\000\000i\000\000\000n\000\000\000g\000\000\000 \000\000\000w\000\000\000h\000\000\000i\000\000\000t\000\000\000e\000\000\000 \000\000\000s\000\000\000p\000\000\000a\000\000\000c\000\000\000e\000\000\000 \000\000\000o\000\000\000r\000\000\000 \000\000\000\'\000\000\000>\000\000\000\'\000\000\000 \000\000\000o\000\000\000r\000\000\000 \000\000\000\'\000\000\000/\000\000\000\'\000\000\000 \000\000\000o\000\000\000r\000\000\000 \000\000\000\'\000\000\000\?\000\000\000\'\000\000\000 \000\000\000)\000\000\000",75,395492393);
								tr1 = F1510_14585(RTCW(tr1), tr2);
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5567[dtype-395])(Current, tr1);
							}
						}
					}
				}
			}
		}
	}
	RTHOOK(47);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STANDARD_PARSER}.character_output */
EIF_REFERENCE F396_6166 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 tu4_1;
	EIF_CHARACTER_32 tw1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("character_output", 395, Current, 0, 1, 5989);
	RTGC;
	RTHOOK(1);
	switch (arg1) {
		case (EIF_CHARACTER_8) '\000':
			RTHOOK(2);
			Result = RTMS32_EX_H("%\000\000\000U\000\000\000",2,9557);
			break;
		case (EIF_CHARACTER_8) '\011':
			RTHOOK(3);
			Result = RTMS32_EX_H("%\000\000\000T\000\000\000",2,9556);
			break;
		case (EIF_CHARACTER_8) '\012':
			RTHOOK(4);
			Result = RTMS32_EX_H("%\000\000\000N\000\000\000",2,9550);
			break;
		default:
			RTHOOK(5);
			if (F396_6175(Current, arg1)) {
				RTHOOK(6);
				Result = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
				F1500_14155(RTCW(Result));
				RTHOOK(7);
				F1510_14579(RTCW(Result), arg1);
			} else {
				RTHOOK(8);
				Result = RTMS32_EX_H("&\000\000\000#\000\000\000",2,9763);
				RTHOOK(9);
				tu4_1 = (EIF_NATURAL_32) arg1;
				F1510_14575(RTCW(Result), tu4_1);
				RTHOOK(10);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ';';
				F1510_14579(RTCW(Result), tw1);
			}
			break;
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STANDARD_PARSER}.resolved_entity */
EIF_REFERENCE F396_6167 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("resolved_entity", 395, Current, 1, 1, 5990);
	RTGC;
	RTHOOK(1);
	tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11450[Dtype(RTCW(arg1))-1503])(arg1, ((EIF_INTEGER_32) 1L));
	tr1 = RTLNS(eif_new_type(1452, 0x00).id, 1452, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_CHARACTER_32 *)tr1 = tw1;
	tw1 = F1451_13981(RTCW(tr1));
	switch (tw1) {
		case (EIF_CHARACTER_8) 'a':
			RTHOOK(2);
			tb1 = '\0';
			tb2 = '\0';
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O11684[Dtype(arg1)-1507]);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 3L))) {
				tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11450[Dtype(RTCW(arg1))-1503])(arg1, ((EIF_INTEGER_32) 2L));
				tr1 = RTLNS(eif_new_type(1452, 0x00).id, 1452, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = tw1;
				tw1 = F1451_13981(RTCW(tr1));
				tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'm';
				tb2 = (EIF_BOOLEAN)(tw1 == tw2);
			}
			if (tb2) {
				tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11450[Dtype(RTCW(arg1))-1503])(arg1, ((EIF_INTEGER_32) 3L));
				tr1 = RTLNS(eif_new_type(1452, 0x00).id, 1452, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = tw1;
				tw1 = F1451_13981(RTCW(tr1));
				tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'p';
				tb1 = (EIF_BOOLEAN)(tw1 == tw2);
			}
			if (tb1) {
				RTHOOK(3);
				loc1 = RTMS32_EX_H("&\000\000\000",1,38);
			} else {
				RTHOOK(4);
				tb1 = '\0';
				tb2 = '\0';
				tb3 = '\0';
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O11684[Dtype(arg1)-1507]);
				if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 4L))) {
					tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11450[Dtype(RTCW(arg1))-1503])(arg1, ((EIF_INTEGER_32) 2L));
					tr1 = RTLNS(eif_new_type(1452, 0x00).id, 1452, _OBJSIZ_0_0_0_1_0_0_0_0_);
					*(EIF_CHARACTER_32 *)tr1 = tw1;
					tw1 = F1451_13981(RTCW(tr1));
					tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'p';
					tb3 = (EIF_BOOLEAN)(tw1 == tw2);
				}
				if (tb3) {
					tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11450[Dtype(RTCW(arg1))-1503])(arg1, ((EIF_INTEGER_32) 3L));
					tr1 = RTLNS(eif_new_type(1452, 0x00).id, 1452, _OBJSIZ_0_0_0_1_0_0_0_0_);
					*(EIF_CHARACTER_32 *)tr1 = tw1;
					tw1 = F1451_13981(RTCW(tr1));
					tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'o';
					tb2 = (EIF_BOOLEAN)(tw1 == tw2);
				}
				if (tb2) {
					tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11450[Dtype(RTCW(arg1))-1503])(arg1, ((EIF_INTEGER_32) 4L));
					tr1 = RTLNS(eif_new_type(1452, 0x00).id, 1452, _OBJSIZ_0_0_0_1_0_0_0_0_);
					*(EIF_CHARACTER_32 *)tr1 = tw1;
					tw1 = F1451_13981(RTCW(tr1));
					tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 's';
					tb1 = (EIF_BOOLEAN)(tw1 == tw2);
				}
				if (tb1) {
					RTHOOK(5);
					loc1 = RTMS32_EX_H("\'\000\000\000",1,39);
				}
			}
			break;
		case (EIF_CHARACTER_8) 'q':
			RTHOOK(6);
			tb1 = '\0';
			tb2 = '\0';
			tb3 = '\0';
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O11684[Dtype(arg1)-1507]);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 4L))) {
				tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11450[Dtype(RTCW(arg1))-1503])(arg1, ((EIF_INTEGER_32) 2L));
				tr1 = RTLNS(eif_new_type(1452, 0x00).id, 1452, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = tw1;
				tw1 = F1451_13981(RTCW(tr1));
				tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'u';
				tb3 = (EIF_BOOLEAN)(tw1 == tw2);
			}
			if (tb3) {
				tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11450[Dtype(RTCW(arg1))-1503])(arg1, ((EIF_INTEGER_32) 3L));
				tr1 = RTLNS(eif_new_type(1452, 0x00).id, 1452, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = tw1;
				tw1 = F1451_13981(RTCW(tr1));
				tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'o';
				tb2 = (EIF_BOOLEAN)(tw1 == tw2);
			}
			if (tb2) {
				tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11450[Dtype(RTCW(arg1))-1503])(arg1, ((EIF_INTEGER_32) 4L));
				tr1 = RTLNS(eif_new_type(1452, 0x00).id, 1452, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = tw1;
				tw1 = F1451_13981(RTCW(tr1));
				tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 't';
				tb1 = (EIF_BOOLEAN)(tw1 == tw2);
			}
			if (tb1) {
				RTHOOK(7);
				loc1 = RTMS32_EX_H("\"\000\000\000",1,34);
			}
			break;
		case (EIF_CHARACTER_8) 'l':
			RTHOOK(8);
			tb1 = '\0';
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O11684[Dtype(arg1)-1507]);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
				tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11450[Dtype(RTCW(arg1))-1503])(arg1, ((EIF_INTEGER_32) 2L));
				tr1 = RTLNS(eif_new_type(1452, 0x00).id, 1452, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = tw1;
				tw1 = F1451_13981(RTCW(tr1));
				tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 't';
				tb1 = (EIF_BOOLEAN)(tw1 == tw2);
			}
			if (tb1) {
				RTHOOK(9);
				loc1 = RTMS32_EX_H("<\000\000\000",1,60);
			}
			break;
		case (EIF_CHARACTER_8) 'g':
			RTHOOK(10);
			tb1 = '\0';
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O11684[Dtype(arg1)-1507]);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
				tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11450[Dtype(RTCW(arg1))-1503])(arg1, ((EIF_INTEGER_32) 2L));
				tr1 = RTLNS(eif_new_type(1452, 0x00).id, 1452, _OBJSIZ_0_0_0_1_0_0_0_0_);
				*(EIF_CHARACTER_32 *)tr1 = tw1;
				tw1 = F1451_13981(RTCW(tr1));
				tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 't';
				tb1 = (EIF_BOOLEAN)(tw1 == tw2);
			}
			if (tb1) {
				RTHOOK(11);
				loc1 = RTMS32_EX_H(">\000\000\000",1,62);
			}
			break;
	}
	RTHOOK(12);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(13);
		loc1 = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O11684[Dtype(arg1)-1507]);
		F1508_14451(RTCW(loc1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 2L)));
		RTHOOK(14);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
		F1510_14579(RTCW(loc1), tw1);
		RTHOOK(15);
		F1510_14565(RTCW(loc1), arg1);
		RTHOOK(16);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ';';
		F1510_14579(RTCW(loc1), tw1);
	}
	RTHOOK(17);
	RTHOOK(18);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) loc1;
}

/* {XML_STANDARD_PARSER}.hexa_string_to_natural_32 */
EIF_NATURAL_32 F396_6168 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("hexa_string_to_natural_32", 395, Current, 0, 1, 5991);
	RTGC;
	RTHOOK(1);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11464[Dtype(RTCW(arg1))-1503])(arg1);
	if (tb1) {
		RTHOOK(2);
		Result = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
	} else {
		RTHOOK(3);
		tr1 = RTOSCF(6169,F396_6169, (Current));
		F356_5785(RTCW(tr1), ((EIF_INTEGER_32) 13L));
		RTHOOK(4);
		tr1 = RTOSCF(6169,F396_6169, (Current));
		F356_5786(RTCW(tr1), arg1, ((EIF_INTEGER_32) 13L));
		RTHOOK(5);
		Result = F356_5798(RTCV(RTOSCF(6169,F396_6169, (Current))));
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STANDARD_PARSER}.ctoi_convertor */
static EIF_REFERENCE F396_6169_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("ctoi_convertor", 395, Current, 0, 0, 5992);
	RTGC;
	RTOSP (6169);
#define Result RTOSR(6169)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(355, 0x00).id, 355, _OBJSIZ_2_4_0_3_0_0_2_0_);
	F356_5780(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTMS_EX_H("x ",2,30752);
	F355_5774(RTCW(Result), tr1);
	RTHOOK(3);
	tr1 = RTMS_EX_H(" ",1,32);
	F355_5775(RTCW(Result), tr1);
	RTHOOK(4);
	F355_5773(RTCW(Result), (EIF_BOOLEAN) 1);
	RTHOOK(5);
	F355_5772(RTCW(Result), (EIF_BOOLEAN) 1);
	RTOSE (6169);
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_6169 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6169,F396_6169_body,(Current));
}

/* {XML_STANDARD_PARSER}.is_valid_tag_start_character */
EIF_BOOLEAN F396_6170 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_valid_tag_start_character", 395, Current, 0, 1, 5993);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) F396_6173(Current, arg1);
}

/* {XML_STANDARD_PARSER}.is_valid_tag_character */
EIF_BOOLEAN F396_6171 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_valid_tag_character", 395, Current, 0, 1, 5994);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) F396_6174(Current, arg1);
}

/* {XML_STANDARD_PARSER}.is_valid_entity_character */
EIF_BOOLEAN F396_6172 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_valid_entity_character", 395, Current, 0, 1, 5995);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) F396_6174(Current, arg1);
}

/* {XML_STANDARD_PARSER}.is_valid_name_start_character */
EIF_BOOLEAN F396_6173 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_valid_name_start_character", 395, Current, 1, 1, 5996);
	RTGC;
	RTHOOK(1);
	tb1 = '\01';
	tb2 = '\01';
	tb3 = '\01';
	tb4 = '\0';
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'a';
	if ((EIF_BOOLEAN) (tw1 <= arg1)) {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'z';
		tb4 = (EIF_BOOLEAN) (arg1 <= tw1);
	}
	if (!tb4) {
		tb4 = '\0';
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'A';
		if ((EIF_BOOLEAN) (tw1 <= arg1)) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) 'Z';
			tb4 = (EIF_BOOLEAN) (arg1 <= tw1);
		}
		tb3 = tb4;
	}
	if (!tb3) {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
		tb2 = (EIF_BOOLEAN)(arg1 == tw1);
	}
	if (!tb2) {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
		tb1 = (EIF_BOOLEAN)(arg1 == tw1);
	}
	if (tb1) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		RTHOOK(4);
		loc1 = (EIF_NATURAL_32) arg1;
		RTHOOK(5);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 192L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 214L))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 216L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 246L)))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 248L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 767L)))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 880L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 893L)))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 895L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 8191L)))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 8204L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 8205L)))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 8304L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 8591L)))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 11264L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 12271L)))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 12289L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 55295L)))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 63744L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 64975L)))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 65008L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 65533L)))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 65536L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 983039L))))) {
			RTHOOK(6);
			RTHOOK(7);
			RTLE;
			RTEE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) 0;
}

/* {XML_STANDARD_PARSER}.is_valid_name_character */
EIF_BOOLEAN F396_6174 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_valid_name_character", 395, Current, 1, 1, 5997);
	RTGC;
	RTHOOK(1);
	Result = F396_6173(Current, arg1);
	RTHOOK(2);
	if ((EIF_BOOLEAN) !Result) {
		RTHOOK(3);
		tb1 = '\01';
		tb2 = '\01';
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '-';
		if (!(EIF_BOOLEAN)(arg1 == tw1)) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
			tb2 = (EIF_BOOLEAN)(arg1 == tw1);
		}
		if (!tb2) {
			tb2 = '\0';
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '0';
			if ((EIF_BOOLEAN) (tw1 <= arg1)) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '9';
				tb2 = (EIF_BOOLEAN) (arg1 <= tw1);
			}
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(4);
			RTHOOK(5);
			RTLE;
			RTEE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			RTHOOK(6);
			loc1 = (EIF_NATURAL_32) arg1;
			RTHOOK(7);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 183L)) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 768L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 879L)))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_NATURAL_32) ((EIF_INTEGER_32) 8255L) <= loc1) && (EIF_BOOLEAN) (loc1 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 8256L))))) {
				RTHOOK(8);
				RTHOOK(9);
				RTLE;
				RTEE;
				return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		}
	}
	RTHOOK(10);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STANDARD_PARSER}.is_printable */
EIF_BOOLEAN F396_6175 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTEX;
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_32 loc2 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_printable", 395, Current, 2, 1, 5998);
	RTGC;
	RTHOOK(1);
	if ((EIF_FALSE)) {
		RTHOOK(2);
		tr1 = RTLNS(eif_new_type(1455, 0x00).id, 1455, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)tr1 = loc1;
		tb1 = F1454_14032(RTCW(tr1));
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) tb1;
	} else {
		RTHOOK(4);
		tb1 = '\0';
		loc2 = arg1;
		if ((EIF_TRUE)) {
			tb2 = (loc2 <= 0xFF);
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(5);
			tc1 = (EIF_CHARACTER_8) loc2;
			tr1 = RTLNS(eif_new_type(1455, 0x00).id, 1455, _OBJSIZ_0_1_0_0_0_0_0_0_);
			*(EIF_CHARACTER_8 *)tr1 = tc1;
			Result = F1454_14032(RTCW(tr1));
		}
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STANDARD_PARSER}.is_blank */
EIF_BOOLEAN F396_6176 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_blank", 395, Current, 2, 1, 5999);
	RTGC;
	RTHOOK(1);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(3);
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R11486[Dtype(RTCW(arg1))-1503])(arg1);
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > loc2) || (EIF_BOOLEAN) !Result)) break;
		RTHOOK(5);
		tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11449[Dtype(RTCW(arg1))-1503])(arg1, loc1);
		switch (tu4_1) {
			case 9U:
			case 10U:
			case 13U:
			case 32U:
				break;
			default:
				RTHOOK(6);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				break;
		}
		RTHOOK(7);
		loc1++;
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STANDARD_PARSER}.empty_buffer */
static EIF_REFERENCE F396_6178_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("empty_buffer", 395, Current, 0, 0, 6001);
	RTGC;
	RTOSP (6178);
#define Result RTOSR(6178)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1251, 0x00).id, 1251, _OBJSIZ_2_2_0_4_0_0_0_0_);
	F1252_11710(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = F1500_14214(RTMS_EX_H("Empty-string-buffer",19,890082162));
	F1252_11719(RTCW(Result), tr1);
	RTOSE (6178);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_6178 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6178,F396_6178_body,(Current));
}

/* {XML_STANDARD_PARSER}.new_string_tag */
EIF_REFERENCE F396_6179 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("new_string_tag", 395, Current, 0, 0, 6002);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) RTOSCF(6190,F396_6190, (Current));
}

/* {XML_STANDARD_PARSER}.new_string_attribute_name */
EIF_REFERENCE F396_6180 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("new_string_attribute_name", 395, Current, 0, 0, 6003);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) RTOSCF(6191,F396_6191, (Current));
}

/* {XML_STANDARD_PARSER}.new_string_attribute_value */
EIF_REFERENCE F396_6181 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("new_string_attribute_value", 395, Current, 0, 0, 6004);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) RTOSCF(6192,F396_6192, (Current));
}

/* {XML_STANDARD_PARSER}.new_string_comment_value */
EIF_REFERENCE F396_6182 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("new_string_comment_value", 395, Current, 0, 0, 6005);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) RTOSCF(6193,F396_6193, (Current));
}

/* {XML_STANDARD_PARSER}.str_version */

EIF_REFERENCE F396_6183 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6183,RTMS32_EX_H("v\000\000\000e\000\000\000r\000\000\000s\000\000\000i\000\000\000o\000\000\000n\000\000\000",7,1397649262));
}

/* {XML_STANDARD_PARSER}.str_encoding */

EIF_REFERENCE F396_6184 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6184,RTMS32_EX_H("e\000\000\000n\000\000\000c\000\000\000o\000\000\000d\000\000\000i\000\000\000n\000\000\000g\000\000\000",8,1433733735));
}

/* {XML_STANDARD_PARSER}.str_standalone */

EIF_REFERENCE F396_6185 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6185,RTMS32_EX_H("s\000\000\000t\000\000\000a\000\000\000n\000\000\000d\000\000\000a\000\000\000l\000\000\000o\000\000\000n\000\000\000e\000\000\000",10,1099491941));
}

/* {XML_STANDARD_PARSER}.str_cdata */

EIF_REFERENCE F396_6186 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6186,RTMS32_EX_H("C\000\000\000D\000\000\000A\000\000\000T\000\000\000A\000\000\000",5,1145646657));
}

/* {XML_STANDARD_PARSER}.str_doctype */

EIF_REFERENCE F396_6187 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6187,RTMS32_EX_H("D\000\000\000O\000\000\000C\000\000\000T\000\000\000Y\000\000\000P\000\000\000E\000\000\000",7,1436817989));
}

/* {XML_STANDARD_PARSER}.str_xml */

EIF_REFERENCE F396_6189 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6189,RTMS32_EX_H("x\000\000\000m\000\000\000l\000\000\000",3,7892332));
}

/* {XML_STANDARD_PARSER}.tmp_string_tag */
static EIF_REFERENCE F396_6190_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("tmp_string_tag", 395, Current, 0, 0, 6013);
	RTGC;
	RTOSP (6190);
#define Result RTOSR(6190)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1508_14451(RTCW(tr1), ((EIF_INTEGER_32) 25L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (6190);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_6190 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6190,F396_6190_body,(Current));
}

/* {XML_STANDARD_PARSER}.tmp_string_attribute_name */
static EIF_REFERENCE F396_6191_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("tmp_string_attribute_name", 395, Current, 0, 0, 6014);
	RTGC;
	RTOSP (6191);
#define Result RTOSR(6191)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1508_14451(RTCW(tr1), ((EIF_INTEGER_32) 20L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (6191);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_6191 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6191,F396_6191_body,(Current));
}

/* {XML_STANDARD_PARSER}.tmp_string_attribute_value */
static EIF_REFERENCE F396_6192_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("tmp_string_attribute_value", 395, Current, 0, 0, 6015);
	RTGC;
	RTOSP (6192);
#define Result RTOSR(6192)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1508_14451(RTCW(tr1), ((EIF_INTEGER_32) 50L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (6192);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_6192 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6192,F396_6192_body,(Current));
}

/* {XML_STANDARD_PARSER}.tmp_string_comment_value */
static EIF_REFERENCE F396_6193_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("tmp_string_comment_value", 395, Current, 0, 0, 6016);
	RTGC;
	RTOSP (6193);
#define Result RTOSR(6193)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1508_14451(RTCW(tr1), ((EIF_INTEGER_32) 100L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (6193);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_6193 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6193,F396_6193_body,(Current));
}

/* {XML_STANDARD_PARSER}.carriage_return_character_code */
static EIF_NATURAL_32 F396_6194_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("carriage_return_character_code", 395, Current, 0, 0, 5925);
	RTGC;
	RTOSP (6194);
#define Result RTOSR(6194)
	RTHOOK(1);
	Result = (EIF_NATURAL_32) (EIF_CHARACTER_8) '\015';
	RTOSE (6194);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_NATURAL_32 F396_6194 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6194,F396_6194_body,(Current));
}

void EIF_Minit338 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
