/*
 * Code for class STRING_TO_NUMERIC_CONVERTOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "st309.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {STRING_TO_NUMERIC_CONVERTOR}.set_trailing_separators_acceptable */
void F355_5772 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_trailing_separators_acceptable", 354, Current, 0, 1, 5592);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O5294[Dtype(Current)-354]) = (EIF_BOOLEAN) arg1;
	RTHOOK(3);
	RTEE;
}

/* {STRING_TO_NUMERIC_CONVERTOR}.set_leading_separators_acceptable */
void F355_5773 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_leading_separators_acceptable", 354, Current, 0, 1, 5593);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O5295[Dtype(Current)-354]) = (EIF_BOOLEAN) arg1;
	RTHOOK(3);
	RTEE;
}

/* {STRING_TO_NUMERIC_CONVERTOR}.set_leading_separators */
void F355_5774 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("set_leading_separators", 354, Current, 0, 1, 5594);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_new_type(1504, 0).id);
	F1503_14287(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {STRING_TO_NUMERIC_CONVERTOR}.set_trailing_separators */
void F355_5775 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("set_trailing_separators", 354, Current, 0, 1, 5595);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_new_type(1504, 0).id);
	F1503_14287(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit309 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
