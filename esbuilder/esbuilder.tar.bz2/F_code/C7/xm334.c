/*
 * Code for class XM_UNICODE_STRUCTURE_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm334.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_UNICODE_STRUCTURE_FACTORY}.same_string */
EIF_BOOLEAN F392_6073 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTEAA("same_string", 391, Current, 0, 2, 5916);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(6072,F391_6072, (Current));
	Result = F1929_21289(RTCW(tr1), arg1, arg2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {XM_UNICODE_STRUCTURE_FACTORY}.new_string_set */
EIF_REFERENCE F392_6074 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("new_string_set", 391, Current, 0, 0, 5917);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {2162,1504,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 2162, _OBJSIZ_7_0_0_9_0_0_0_0_);
	}
	F2161_24566(RTCW(Result));
	RTHOOK(2);
	tr1 = RTOSCF(6072,F391_6072, (Current));
	F2118_23899(RTCW(Result), tr1);
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {XM_UNICODE_STRUCTURE_FACTORY}.new_string_bilinked_list */
EIF_REFERENCE F392_6075 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("new_string_bilinked_list", 391, Current, 0, 0, 5918);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {2137,1504,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 2137, _OBJSIZ_4_0_0_1_0_0_0_0_);
	}
	F2136_24078(RTCW(Result));
	RTHOOK(2);
	tr1 = RTOSCF(6072,F391_6072, (Current));
	F2118_23899(RTCW(Result), tr1);
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {XM_UNICODE_STRUCTURE_FACTORY}.new_string_stack */
EIF_REFERENCE F392_6077 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("new_string_stack", 391, Current, 0, 0, 5909);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {2147,1504,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 2147, _OBJSIZ_2_0_0_1_0_0_0_0_);
	}
	F2148_24247(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {XM_UNICODE_STRUCTURE_FACTORY}.new_string_queue */
EIF_REFERENCE F392_6078 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("new_string_queue", 391, Current, 0, 0, 5910);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {2143,1504,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 2143, _OBJSIZ_3_0_0_1_0_0_0_0_);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {XM_UNICODE_STRUCTURE_FACTORY}.new_detachable_string_queue */
EIF_REFERENCE F392_6079 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("new_detachable_string_queue", 391, Current, 0, 0, 5911);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {2143,1504,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 2143, _OBJSIZ_3_0_0_1_0_0_0_0_);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {XM_UNICODE_STRUCTURE_FACTORY}.new_string_string_table */
EIF_REFERENCE F392_6080 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("new_string_string_table", 391, Current, 0, 0, 5912);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {2158,1504,1504,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 2158, _OBJSIZ_11_0_0_9_0_0_0_0_);
	}
	F2155_24486(RTCW(Result));
	RTHOOK(2);
	tr1 = RTOSCF(6072,F391_6072, (Current));
	F2155_24502(RTCW(Result), tr1);
	RTHOOK(3);
	tr1 = RTOSCF(6072,F391_6072, (Current));
	F2118_23899(RTCW(Result), tr1);
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit334 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
