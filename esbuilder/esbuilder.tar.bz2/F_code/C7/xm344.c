/*
 * Code for class XML_CHARACTER_8_INPUT_STREAM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm344.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XML_CHARACTER_8_INPUT_STREAM}.last_character_code */
EIF_NATURAL_32 F402_6247 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_8 tc1;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("last_character_code", 401, Current, 0, 0, 6060);
	RTGC;
	RTHOOK(1);
	tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE)) R5658[Dtype(Current)-1250])(Current);
	Result = (EIF_NATURAL_32) tc1;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_CHARACTER_8_INPUT_STREAM}.read_character_code */
void F402_6249 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("read_character_code", 401, Current, 0, 0, 6061);
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5659[Dtype(Current)-1250])(Current);
	RTHOOK(2);
	RTEE;
}

void EIF_Minit344 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
