
#ifndef _C7_xm343_
#define _C7_xm343_

#ifdef __cplusplus
extern "C" {
#endif

extern void F401_6243(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_NATURAL_32 F401_6244(EIF_REFERENCE);
extern void F401_6245(EIF_REFERENCE);
extern EIF_NATURAL_32 F401_6246(EIF_REFERENCE);
extern void EIF_Minit343(void);
extern EIF_NATURAL_32 F402_6247(EIF_REFERENCE);
extern void F400_6233(EIF_REFERENCE, EIF_REFERENCE);
extern void F402_6249(EIF_REFERENCE);
extern char *(*R5634[])();

#ifdef __cplusplus
}
#endif

#endif
