
#ifndef _C7_xm344_
#define _C7_xm344_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_32 F402_6247(EIF_REFERENCE);
extern void F402_6249(EIF_REFERENCE);
extern void EIF_Minit344(void);
extern char *(*R5658[])();
extern char *(*R5659[])();

#ifdef __cplusplus
}
#endif

#endif
