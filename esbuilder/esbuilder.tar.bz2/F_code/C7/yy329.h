
#ifndef _C7_yy329_
#define _C7_yy329_

#ifdef __cplusplus
extern "C" {
#endif

extern void F387_6028(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F387_6032(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit329(void);
extern void F654_8942(EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32);
extern void F654_8927(EIF_REFERENCE, EIF_INTEGER_32);
extern void F385_5998(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F654_8950(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern long O5461[];
extern EIF_TYPE_INDEX Y5460[];
extern EIF_TYPE_INDEX *Y5460_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
