/*
 * Code for class EIFFEL_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ei301.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EIFFEL_CONSTANTS}.ise_eiffel_env */

EIF_REFERENCE F347_5667 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (5667,RTMS_EX_H("ISE_EIFFEL",10,960687436));
}

/* {EIFFEL_CONSTANTS}.ise_library_env */

EIF_REFERENCE F347_5668 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (5668,RTMS_EX_H("ISE_LIBRARY",11,552576601));
}

/* {EIFFEL_CONSTANTS}.eiffel_library_env */

EIF_REFERENCE F347_5669 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (5669,RTMS_EX_H("EIFFEL_LIBRARY",14,1735641689));
}

/* {EIFFEL_CONSTANTS}.ise_iron_path_env */

EIF_REFERENCE F347_5670 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (5670,RTMS_EX_H("ISE_IRON_PATH",13,591182408));
}

/* {EIFFEL_CONSTANTS}.iron_path_env */

EIF_REFERENCE F347_5671 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (5671,RTMS_EX_H("IRON_PATH",9,490076488));
}

/* {EIFFEL_CONSTANTS}.ise_precomp_env */

EIF_REFERENCE F347_5672 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (5672,RTMS_EX_H("ISE_PRECOMP",11,185338448));
}

/* {EIFFEL_CONSTANTS}.ise_platform_env */

EIF_REFERENCE F347_5673 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (5673,RTMS_EX_H("ISE_PLATFORM",12,1318550605));
}

/* {EIFFEL_CONSTANTS}.ise_c_compiler_env */

EIF_REFERENCE F347_5674 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (5674,RTMS_EX_H("ISE_C_COMPILER",14,1981921618));
}

/* {EIFFEL_CONSTANTS}.ise_user_files_env */

EIF_REFERENCE F347_5677 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (5677,RTMS_EX_H("ISE_USER_FILES",14,1880819283));
}

/* {EIFFEL_CONSTANTS}.ise_app_data_env */

EIF_REFERENCE F347_5678 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (5678,RTMS_EX_H("ISE_APP_DATA",12,1175984961));
}

/* {EIFFEL_CONSTANTS}.two_digit_minimum_major_version */
static EIF_REFERENCE F347_5685_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("two_digit_minimum_major_version", 346, Current, 0, 0, 5507);
	RTGC;
	RTOSP (5685);
#define Result RTOSR(5685)
	RTOC_NEW(Result);
	RTHOOK(1);
	ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_16) 22U);
	Result = F347_5687(Current, ti4_1);
	RTOSE (5685);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F347_5685 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(5685,F347_5685_body,(Current));
}

/* {EIFFEL_CONSTANTS}.two_digit_minimum_minor_version */
static EIF_REFERENCE F347_5686_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("two_digit_minimum_minor_version", 346, Current, 0, 0, 5508);
	RTGC;
	RTOSP (5686);
#define Result RTOSR(5686)
	RTOC_NEW(Result);
	RTHOOK(1);
	ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_16) 5U);
	Result = F347_5687(Current, ti4_1);
	RTOSE (5686);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F347_5686 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(5686,F347_5686_body,(Current));
}

/* {EIFFEL_CONSTANTS}.two_digit_minimum_string */
EIF_REFERENCE F347_5687 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("two_digit_minimum_string", 346, Current, 0, 1, 5509);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1504, 0x00).id, 1504, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1503_14285(RTCW(Result), ((EIF_INTEGER_32) 2L));
	RTHOOK(2);
	if ((EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 10L))) {
		RTHOOK(3);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R11637[Dtype(RTCW(Result))-1504])(Result, (EIF_CHARACTER_8) '0');
	}
	RTHOOK(4);
	F1505_14401(RTCW(Result), arg1);
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit301 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
