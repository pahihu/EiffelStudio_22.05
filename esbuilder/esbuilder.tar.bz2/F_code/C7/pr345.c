/*
 * Code for class PREFERENCE_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pr345.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PREFERENCE_CONSTANTS}.l_name */
EIF_REFERENCE F403_6251 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("l_name", 402, Current, 0, 0, 6062);
	RTGC;
	RTHOOK(1);
	Result = F1500_14214(RTMS_EX_H("Name",4,1315007845));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {PREFERENCE_CONSTANTS}.l_literal_value */
EIF_REFERENCE F403_6252 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("l_literal_value", 402, Current, 0, 0, 6063);
	RTGC;
	RTHOOK(1);
	Result = F1500_14214(RTMS_EX_H("Literal Value",13,1227990117));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {PREFERENCE_CONSTANTS}.l_status */
EIF_REFERENCE F403_6253 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("l_status", 402, Current, 0, 0, 6064);
	RTGC;
	RTHOOK(1);
	Result = F1500_14214(RTMS_EX_H("Status",6,1799097715));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {PREFERENCE_CONSTANTS}.l_type */
EIF_REFERENCE F403_6254 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("l_type", 402, Current, 0, 0, 6065);
	RTGC;
	RTHOOK(1);
	Result = F1500_14214(RTMS_EX_H("Type",4,1417244773));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {PREFERENCE_CONSTANTS}.l_request_restart */
EIF_REFERENCE F403_6255 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("l_request_restart", 402, Current, 0, 0, 6066);
	RTGC;
	RTHOOK(1);
	Result = F1500_14214(RTMS_EX_H(" (REQUIRES RESTART)",19,1950363177));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {PREFERENCE_CONSTANTS}.l_restore_default */
EIF_REFERENCE F403_6266 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("l_restore_default", 402, Current, 0, 0, 6077);
	RTGC;
	RTHOOK(1);
	Result = F1500_14214(RTMS_EX_H("Restore Default",15,1420008820));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {PREFERENCE_CONSTANTS}.p_default_value */
EIF_REFERENCE F403_6273 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("p_default_value", 402, Current, 0, 0, 6084);
	RTGC;
	RTHOOK(1);
	Result = F1500_14214(RTMS_EX_H("default",7,626575476));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {PREFERENCE_CONSTANTS}.user_value */
EIF_REFERENCE F403_6274 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("user_value", 402, Current, 0, 0, 6085);
	RTGC;
	RTHOOK(1);
	Result = F1500_14214(RTMS_EX_H("user set",8,670280308));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {PREFERENCE_CONSTANTS}.auto_value */
EIF_REFERENCE F403_6275 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("auto_value", 402, Current, 0, 0, 6086);
	RTGC;
	RTHOOK(1);
	Result = F1500_14214(RTMS_EX_H("auto",4,1635087471));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {PREFERENCE_CONSTANTS}.no_description_text */
EIF_REFERENCE F403_6276 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("no_description_text", 402, Current, 0, 0, 6087);
	RTGC;
	RTHOOK(1);
	Result = F1500_14214(RTMS_EX_H("No description available for this preference.",45,408043822));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {PREFERENCE_CONSTANTS}.preferences_title */
EIF_REFERENCE F403_6277 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("preferences_title", 402, Current, 0, 0, 6088);
	RTGC;
	RTHOOK(1);
	Result = F1500_14214(RTMS_EX_H("Preferences",11,527165043));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {PREFERENCE_CONSTANTS}.restore_preference_string */
EIF_REFERENCE F403_6278 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("restore_preference_string", 402, Current, 0, 0, 6089);
	RTGC;
	RTHOOK(1);
	Result = F1500_14214(RTMS_EX_H("This will reset ALL preferences to their default values\012 and all previous settings will be overwritten.  Are you sure\?",118,2096783167));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {PREFERENCE_CONSTANTS}.preferences_root */
EIF_REFERENCE F403_6280 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("preferences_root", 402, Current, 0, 0, 6091);
	RTGC;
	RTHOOK(1);
	Result = F1500_14214(RTMS_EX_H("Preferences root",16,1650758772));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {PREFERENCE_CONSTANTS}.alt_text */

EIF_REFERENCE F403_6281 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6281,RTMS_EX_H("Alt",3,4287604));
}

/* {PREFERENCE_CONSTANTS}.ctrl_text */

EIF_REFERENCE F403_6282 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6282,RTMS_EX_H("Ctrl",4,1131704940));
}

/* {PREFERENCE_CONSTANTS}.shift_text */

EIF_REFERENCE F403_6283 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6283,RTMS_EX_H("Shift",5,1752375412));
}

/* {PREFERENCE_CONSTANTS}.shortcut_delimiter */

EIF_REFERENCE F403_6284 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6284,RTMS32_EX_H("+\000\000\000",1,43));
}

void EIF_Minit345 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
