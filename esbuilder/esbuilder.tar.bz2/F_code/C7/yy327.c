/*
 * Code for class YY_BUFFER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "yy327.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {YY_BUFFER}.make */
void F385_5997 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("make", 384, Current, 2, 1, 5831);
	RTGC;
	RTHOOK(1);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	RTHOOK(2);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5480[Dtype(Current)-384])(Current, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)));
	RTHOOK(3);
	F189_2467(RTCW(loc1), arg1, ((EIF_INTEGER_32) 1L));
	RTHOOK(4);
	tc1 = (EIF_CHARACTER_8) '\000';
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R2432[Dtype(RTCW(loc1))-653])(loc1, (EIF_REFERENCE) &tc1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
	RTHOOK(5);
	tc1 = (EIF_CHARACTER_8) '\000';
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R2432[Dtype(RTCW(loc1))-653])(loc1, (EIF_REFERENCE) &tc1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)));
	RTHOOK(6);
	F385_5998(Current, loc1);
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {YY_BUFFER}.make_from_buffer */
void F385_5998 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("make_from_buffer", 384, Current, 0, 1, 5832);
	RTGC;
	RTHOOK(1);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R2431[Dtype(RTCW(arg1))-653])(arg1);
	*(EIF_INTEGER_32 *)(Current + O5462[dtype-384]) = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 2L));
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current + O5461[dtype-384]) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current + O5462[dtype-384]);
	RTHOOK(3);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(4);
	*(EIF_INTEGER_32 *)(Current + O5466[dtype-384]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(5);
	*(EIF_INTEGER_32 *)(Current + O5464[dtype-384]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(6);
	*(EIF_INTEGER_32 *)(Current + O5465[dtype-384]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(7);
	*(EIF_INTEGER_32 *)(Current + O5463[dtype-384]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(8);
	*(EIF_BOOLEAN *)(Current + O5467[dtype-384]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(13);
	RTLE;
	RTEE;
}

/* {YY_BUFFER}.name */
EIF_REFERENCE F385_5999 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("name", 384, Current, 0, 0, 5833);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) RTOSCF(6024,F385_6024, (Current));
}

/* {YY_BUFFER}.set_position */
void F385_6009 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_position", 384, Current, 0, 3, 5843);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O5463[dtype-384]) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current + O5464[dtype-384]) = (EIF_INTEGER_32) arg2;
	RTHOOK(3);
	*(EIF_INTEGER_32 *)(Current + O5465[dtype-384]) = (EIF_INTEGER_32) arg3;
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {YY_BUFFER}.set_index */
void F385_6010 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_index", 384, Current, 0, 1, 5844);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O5466[Dtype(Current)-384]) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {YY_BUFFER}.fill */
void F385_6015 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("fill", 384, Current, 0, 0, 5849);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O5472[Dtype(Current)-384]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(2);
	RTEE;
}

/* {YY_BUFFER}.flush */
void F385_6016 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("flush", 384, Current, 0, 0, 5850);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tc1 = (EIF_CHARACTER_8) '\000';
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R2432[Dtype(RTCW(tr1))-653])(tr1, (EIF_REFERENCE) &tc1, ((EIF_INTEGER_32) 1L));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current);
	tc1 = (EIF_CHARACTER_8) '\000';
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R2432[Dtype(RTCW(tr1))-653])(tr1, (EIF_REFERENCE) &tc1, ((EIF_INTEGER_32) 2L));
	RTHOOK(3);
	*(EIF_INTEGER_32 *)(Current + O5461[dtype-384]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(4);
	*(EIF_INTEGER_32 *)(Current + O5466[dtype-384]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(5);
	*(EIF_INTEGER_32 *)(Current + O5464[dtype-384]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(6);
	*(EIF_INTEGER_32 *)(Current + O5465[dtype-384]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(7);
	*(EIF_INTEGER_32 *)(Current + O5463[dtype-384]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(8);
	*(EIF_BOOLEAN *)(Current + O5467[dtype-384]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(9);
	*(EIF_BOOLEAN *)(Current + O5472[dtype-384]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(13);
	RTLE;
	RTEE;
}

/* {YY_BUFFER}.compact_left */
void F385_6018 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("compact_left", 384, Current, 1, 0, 5852);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_INTEGER_32 *)(Current + O5461[dtype-384]);
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O5466[dtype-384]);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 - ti4_1) + ((EIF_INTEGER_32) 1L));
	RTHOOK(2);
	if ((EIF_BOOLEAN) (loc1 >= *(EIF_INTEGER_32 *)(Current + O5462[dtype-384]))) {
		RTHOOK(3);
		F385_6021(Current);
	}
	RTHOOK(4);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5466[dtype-384]) != ((EIF_INTEGER_32) 1L))) {
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R2434[Dtype(RTCW(tr1))-653])(tr1, *(EIF_INTEGER_32 *)(Current + O5466[dtype-384]), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)));
		RTHOOK(6);
		*(EIF_INTEGER_32 *)(Current + O5466[dtype-384]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		RTHOOK(7);
		*(EIF_INTEGER_32 *)(Current + O5461[dtype-384]) = (EIF_INTEGER_32) loc1;
	}
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {YY_BUFFER}.new_default_buffer */
EIF_REFERENCE F385_6020 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("new_default_buffer", 384, Current, 0, 1, 5854);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(654, 0x00).id, 654, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F655_8958(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {YY_BUFFER}.resize */
void F385_6021 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("resize", 384, Current, 0, 0, 5855);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5462[dtype-384]) == ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		ti4_1 = RTOSCF(6022,F385_6022, (Current));
		*(EIF_INTEGER_32 *)(Current + O5462[dtype-384]) = (EIF_INTEGER_32) ti4_1;
	} else {
		RTHOOK(3);
		(*(EIF_INTEGER_32 *)(Current + O5462[dtype-384])) *= ((EIF_INTEGER_32) 2L);
	}
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R2431[Dtype(RTCW(tr1))-653])(tr1);
	if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5462[dtype-384]) + ((EIF_INTEGER_32) 2L)) > ti4_1)) {
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R2436[Dtype(RTCW(tr1))-653])(tr1, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5462[dtype-384]) + ((EIF_INTEGER_32) 2L)));
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {YY_BUFFER}.default_capacity */
static EIF_INTEGER_32 F385_6022_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEAA("default_capacity", 384, Current, 0, 0, 5856);
	RTOSP (6022);
#define Result RTOSR(6022)
	RTHOOK(1);
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16384L);
	RTOSE (6022);
	RTHOOK(3);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F385_6022 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6022,F385_6022_body,(Current));
}

/* {YY_BUFFER}.name_constant */

EIF_REFERENCE F385_6024 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6024,RTMS_EX_H("<string>",8,1911048254));
}

void EIF_Minit327 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
