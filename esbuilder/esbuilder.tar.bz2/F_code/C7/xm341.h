
#ifndef _C7_xm341_
#define _C7_xm341_

#ifdef __cplusplus
extern "C" {
#endif
RTOSHF (EIF_REFERENCE, 6218)


extern EIF_REFERENCE F399_6218(EIF_REFERENCE);
extern EIF_BOOLEAN F399_6220(EIF_REFERENCE);
extern EIF_INTEGER_32 F399_6222(EIF_REFERENCE);
extern EIF_INTEGER_32 F399_6223(EIF_REFERENCE);
extern EIF_INTEGER_32 F399_6224(EIF_REFERENCE);
extern EIF_NATURAL_32 F399_6225(EIF_REFERENCE);
extern void F399_6227(EIF_REFERENCE);
extern void F399_6228(EIF_REFERENCE);
extern void EIF_Minit341(void);
extern char *(*R11450[])();

#ifdef __cplusplus
}
#endif

#endif
