
#ifndef _C7_kl316_
#define _C7_kl316_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F374_5890(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit316(void);
extern char *(*R11585[])();

#ifdef __cplusplus
}
#endif

#endif
