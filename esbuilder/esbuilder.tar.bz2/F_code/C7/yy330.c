/*
 * Code for class YY_FILE_BUFFER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "yy330.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {YY_FILE_BUFFER}.make */
void F388_6033 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("make", 387, Current, 0, 1, 5868);
	RTGC;
	RTHOOK(1);
	ti4_1 = RTOSCF(6022,F385_6022, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R5492[Dtype(Current)-387])(Current, arg1, ti4_1);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {YY_FILE_BUFFER}.make_with_size */
void F388_6034 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("make_with_size", 387, Current, 0, 2, 5869);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O5462[dtype-384]) = (EIF_INTEGER_32) arg2;
	RTHOOK(2);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5480[dtype-384])(Current, (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 2L)));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	F388_6039(Current, arg1);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {YY_FILE_BUFFER}.make_from_string */
void F388_6035 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("make_from_string", 387, Current, 0, 1, 5870);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O5494[dtype-387]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	tr1 = RTOSCF(5555,F334_5555, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	F385_5997(Current, arg1);
	RTHOOK(4);
	*(EIF_BOOLEAN *)(Current + O5472[dtype-384]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {YY_FILE_BUFFER}.name */
EIF_REFERENCE F388_6036 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("name", 387, Current, 0, 0, 5871);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4807[Dtype(RTCW(tr1))-1926])(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {YY_FILE_BUFFER}.set_file */
void F388_6039 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_file", 387, Current, 0, 1, 5874);
	RTHOOK(1);
	F388_6040(Current, arg1, *(EIF_INTEGER_32 *)(Current + O5462[Dtype(Current)-384]));
	RTHOOK(6);
	RTEE;
}

/* {YY_FILE_BUFFER}.set_file_with_size */
void F388_6040 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_file_with_size", 387, Current, 0, 2, 5875);
	RTGC;
	RTHOOK(1);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4805[Dtype(RTCW(arg1))-1926])(arg1);
	*(EIF_BOOLEAN *)(Current + O5494[dtype-387]) = (EIF_BOOLEAN) tb1;
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5476[dtype-384])(Current);
	RTHOOK(3);
	if ((EIF_BOOLEAN) (arg2 > *(EIF_INTEGER_32 *)(Current + O5462[dtype-384]))) {
		RTHOOK(4);
		*(EIF_INTEGER_32 *)(Current + O5462[dtype-384]) = (EIF_INTEGER_32) arg2;
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R2436[Dtype(RTCW(tr1))-653])(tr1, (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 2L)));
	}
	RTHOOK(6);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {YY_FILE_BUFFER}.fill */
void F388_6043 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("fill", 387, Current, 3, 0, 5878);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O5472[dtype-384]) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O5494[dtype-387]))) {
		RTHOOK(2);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5478[dtype-384])(Current);
		RTHOOK(3);
		loc3 = *(EIF_REFERENCE *)(Current);
		RTHOOK(4);
		if (*(EIF_BOOLEAN *)(Current + O5473[dtype-384])) {
			RTHOOK(5);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R4799[Dtype(RTCW(tr1))-1926])(tr1);
			RTHOOK(6);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4805[Dtype(RTCW(tr1))-1926])(tr1);
			if ((EIF_BOOLEAN) !tb1) {
				RTHOOK(7);
				(*(EIF_INTEGER_32 *)(Current + O5461[dtype-384]))++;
				RTHOOK(8);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4808[Dtype(RTCW(tr1))-1926])(tr1));
				ti4_1 = *(EIF_INTEGER_32 *)(Current + O5461[dtype-384]);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R2432[Dtype(RTCW(loc3))-653])(loc3, (EIF_REFERENCE) &tc1, ti4_1);
				RTHOOK(9);
				*(EIF_BOOLEAN *)(Current + O5472[dtype-384]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				RTHOOK(10);
				*(EIF_BOOLEAN *)(Current + O5472[dtype-384]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				RTHOOK(11);
				*(EIF_BOOLEAN *)(Current + O5494[dtype-387]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		} else {
			RTHOOK(12);
			loc1 = *(EIF_INTEGER_32 *)(Current + O5462[dtype-384]);
			ti4_1 = *(EIF_INTEGER_32 *)(Current + O5461[dtype-384]);
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ti4_1);
			RTHOOK(13);
			loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R2433[Dtype(RTCW(loc3))-653])(loc3, *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5461[dtype-384]) + ((EIF_INTEGER_32) 1L)), loc1);
			RTHOOK(14);
			if ((EIF_BOOLEAN) (loc2 < loc1)) {
				RTHOOK(15);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4805[Dtype(RTCW(tr1))-1926])(tr1);
				*(EIF_BOOLEAN *)(Current + O5494[dtype-387]) = (EIF_BOOLEAN) tb1;
			}
			RTHOOK(16);
			if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
				RTHOOK(17);
				*(EIF_BOOLEAN *)(Current + O5472[dtype-384]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				RTHOOK(18);
				*(EIF_BOOLEAN *)(Current + O5472[dtype-384]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
			RTHOOK(19);
			(*(EIF_INTEGER_32 *)(Current + O5461[dtype-384])) += loc2;
		}
		RTHOOK(20);
		tc1 = (EIF_CHARACTER_8) '\000';
		ti4_1 = *(EIF_INTEGER_32 *)(Current + O5461[dtype-384]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R2432[Dtype(RTCW(loc3))-653])(loc3, (EIF_REFERENCE) &tc1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
		RTHOOK(21);
		tc1 = (EIF_CHARACTER_8) '\000';
		ti4_1 = *(EIF_INTEGER_32 *)(Current + O5461[dtype-384]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R2432[Dtype(RTCW(loc3))-653])(loc3, (EIF_REFERENCE) &tc1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 2L)));
	} else {
		RTHOOK(22);
		*(EIF_BOOLEAN *)(Current + O5472[dtype-384]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTHOOK(23);
	RTLE;
	RTEE;
}

void EIF_Minit330 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
