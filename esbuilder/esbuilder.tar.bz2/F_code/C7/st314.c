/*
 * Code for class STRING_8_SEARCHER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "st314.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {STRING_8_SEARCHER}.max_code_point_value */
EIF_INTEGER_32 F360_5867 (EIF_REFERENCE Current)
{
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 255L);
}

/* {STRING_8_SEARCHER}.substring_index_with_deltas */
EIF_INTEGER_32 F360_5868 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,loc7);
	RTLR(3,loc6);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("substring_index_with_deltas", 359, Current, 8, 4, 5688);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == arg2)) {
		RTHOOK(2);
		if ((EIF_BOOLEAN)(arg3 == ((EIF_INTEGER_32) 1L))) {
			RTHOOK(3);
			RTHOOK(4);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		}
	} else {
		RTHOOK(5);
		loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R11486[Dtype(RTCW(arg2))-1503])(arg2);
		
		RTHOOK(7);
		loc7 = *(EIF_REFERENCE *)(RTCW(arg1));
		RTHOOK(8);
		loc8 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R11607[Dtype(RTCW(arg1))-1503])(arg1);
		RTHOOK(9);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg3 + loc8);
		RTHOOK(10);
		loc6 = *(EIF_REFERENCE *)(Current);
		RTHOOK(11);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg4 + ((EIF_INTEGER_32) 1L)) + loc8);
		for (;;) {
			RTHOOK(12);
			if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + loc4) > loc3)) break;
			RTHOOK(13);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			RTHOOK(14);
			loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			for (;;) {
				RTHOOK(15);
				if ((EIF_BOOLEAN)(loc2 == loc4)) break;
				RTHOOK(16);
				/* INLINED CODE (SPECIAL.item) */
				tc2 = *((EIF_CHARACTER_8 *)RTCW(loc7) + ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + loc2) - ((EIF_INTEGER_32) 1L))));
				/* END INLINED CODE */
				tc1 = tc2;
				tu4_1 = (EIF_NATURAL_32) tc1;
				tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11449[Dtype(RTCW(arg2))-1503])(arg2, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
				if ((EIF_BOOLEAN)(tu4_1 != tu4_2)) {
					RTHOOK(17);
					loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 - ((EIF_INTEGER_32) 1L));
					RTHOOK(18);
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				}
				RTHOOK(19);
				loc2++;
			}
			RTHOOK(20);
			if (loc5) {
				RTHOOK(21);
				Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - loc8);
				RTHOOK(22);
				loc1 = (EIF_INTEGER_32) loc3;
			} else {
				RTHOOK(23);
				if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + loc4) <= arg4)) {
					RTHOOK(24);
					/* INLINED CODE (SPECIAL.item) */
					tc2 = *((EIF_CHARACTER_8 *)RTCW(loc7) + ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + loc4) - ((EIF_INTEGER_32) 1L))));
					/* END INLINED CODE */
					tc1 = tc2;
					ti4_1 = (EIF_INTEGER_32) (tc1);
					/* INLINED CODE (SPECIAL.item) */
					ti4_3 = *((EIF_INTEGER_32 *)RTCW(loc6) + (ti4_1));
					/* END INLINED CODE */
					ti4_1 = ti4_3;
					loc1 += ti4_1;
				} else {
					RTHOOK(25);
					loc1++;
				}
			}
		}
	}
	RTHOOK(26);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit314 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
