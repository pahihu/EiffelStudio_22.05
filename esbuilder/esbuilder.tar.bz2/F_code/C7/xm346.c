/*
 * Code for class XM_CALLBACKS_SOURCE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm346.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_CALLBACKS_SOURCE}.null_callbacks */
EIF_REFERENCE F404_6290 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("null_callbacks", 403, Current, 0, 0, 6100);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(405, 0x00).id, 405, _OBJSIZ_0_0_0_0_0_0_0_0_);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

void EIF_Minit346 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
