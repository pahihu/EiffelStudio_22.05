
#ifndef _C7_xm335_
#define _C7_xm335_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F393_6084(EIF_REFERENCE);
extern void EIF_Minit335(void);
extern void F2155_24486(EIF_REFERENCE);
extern EIF_REFERENCE F391_6072(EIF_REFERENCE);
extern void F2155_24502(EIF_REFERENCE, EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,6072)

#ifdef __cplusplus
}
#endif

#endif
