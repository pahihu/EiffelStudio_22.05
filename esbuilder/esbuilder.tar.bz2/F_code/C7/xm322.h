
#ifndef _C7_xm322_
#define _C7_xm322_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F380_5954(EIF_REFERENCE);
extern void F380_5955(EIF_REFERENCE);
extern void F380_5957(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit322(void);
extern char *(*R11633[])();

#ifdef __cplusplus
}
#endif

#endif
