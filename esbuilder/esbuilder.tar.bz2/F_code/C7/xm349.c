/*
 * Code for class XM_FORWARD_CALLBACKS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm349.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_FORWARD_CALLBACKS}.set_callbacks */
void F407_6321 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_callbacks", 406, Current, 0, 1, 6129);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O5717[Dtype(Current)-406]) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {XM_FORWARD_CALLBACKS}.on_start */
void F407_6322 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("on_start", 406, Current, 0, 0, 6130);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O5717[Dtype(Current)-406]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5701[Dtype(RTCW(tr1))-405])(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XM_FORWARD_CALLBACKS}.on_finish */
void F407_6323 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("on_finish", 406, Current, 0, 0, 6131);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O5717[Dtype(Current)-406]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5702[Dtype(RTCW(tr1))-405])(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XM_FORWARD_CALLBACKS}.on_xml_declaration */
void F407_6324 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTEAA("on_xml_declaration", 406, Current, 0, 3, 6118);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O5717[Dtype(Current)-406]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R5703[Dtype(RTCW(tr1))-405])(tr1, arg1, arg2, arg3);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XM_FORWARD_CALLBACKS}.on_error */
void F407_6325 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("on_error", 406, Current, 0, 1, 6119);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O5717[Dtype(Current)-406]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5704[Dtype(RTCW(tr1))-405])(tr1, arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XM_FORWARD_CALLBACKS}.on_processing_instruction */
void F407_6326 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTEAA("on_processing_instruction", 406, Current, 0, 2, 6120);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O5717[Dtype(Current)-406]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5705[Dtype(RTCW(tr1))-405])(tr1, arg1, arg2);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XM_FORWARD_CALLBACKS}.on_comment */
void F407_6327 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("on_comment", 406, Current, 0, 1, 6121);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O5717[Dtype(Current)-406]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5706[Dtype(RTCW(tr1))-405])(tr1, arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XM_FORWARD_CALLBACKS}.on_start_tag */
void F407_6328 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTEAA("on_start_tag", 406, Current, 0, 3, 6122);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O5717[Dtype(Current)-406]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5707[Dtype(RTCW(tr1))-405])(tr1, arg1, arg2, arg3);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XM_FORWARD_CALLBACKS}.on_attribute */
void F407_6329 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLR(5,arg4);
	RTLIU(6);
	
	RTEAA("on_attribute", 406, Current, 0, 4, 6123);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O5717[Dtype(Current)-406]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5708[Dtype(RTCW(tr1))-405])(tr1, arg1, arg2, arg3, arg4);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XM_FORWARD_CALLBACKS}.on_start_tag_finish */
void F407_6330 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("on_start_tag_finish", 406, Current, 0, 0, 6124);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O5717[Dtype(Current)-406]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5709[Dtype(RTCW(tr1))-405])(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XM_FORWARD_CALLBACKS}.on_end_tag */
void F407_6331 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTEAA("on_end_tag", 406, Current, 0, 3, 6125);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O5717[Dtype(Current)-406]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5710[Dtype(RTCW(tr1))-405])(tr1, arg1, arg2, arg3);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XM_FORWARD_CALLBACKS}.on_content */
void F407_6332 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("on_content", 406, Current, 0, 1, 6126);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O5717[Dtype(Current)-406]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5711[Dtype(RTCW(tr1))-405])(tr1, arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit349 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
