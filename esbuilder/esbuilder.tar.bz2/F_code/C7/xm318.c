/*
 * Code for class XML_NULL_OUTPUT_STREAM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm318.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XML_NULL_OUTPUT_STREAM}.is_open_write */
EIF_BOOLEAN F376_5922 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {XML_NULL_OUTPUT_STREAM}.flush */
void F376_5923 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("flush", 375, Current, 0, 0, 5758);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XML_NULL_OUTPUT_STREAM}.put_string_8 */
void F376_5925 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("put_string_8", 375, Current, 0, 1, 5760);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XML_NULL_OUTPUT_STREAM}.put_string_32 */
void F376_5927 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("put_string_32", 375, Current, 0, 1, 5762);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

void EIF_Minit318 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
