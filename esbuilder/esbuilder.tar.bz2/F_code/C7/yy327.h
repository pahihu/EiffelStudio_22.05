
#ifndef _C7_yy327_
#define _C7_yy327_

#ifdef __cplusplus
extern "C" {
#endif

extern void F385_5997(EIF_REFERENCE, EIF_REFERENCE);
extern void F385_5998(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F385_5999(EIF_REFERENCE);
extern void F385_6009(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F385_6010(EIF_REFERENCE, EIF_INTEGER_32);
extern void F385_6015(EIF_REFERENCE);
extern void F385_6016(EIF_REFERENCE);
extern void F385_6018(EIF_REFERENCE);
extern EIF_REFERENCE F385_6020(EIF_REFERENCE, EIF_INTEGER_32);
extern void F385_6021(EIF_REFERENCE);
RTOSHF (EIF_INTEGER_32,6022)
static EIF_INTEGER_32 F385_6022_body(EIF_REFERENCE);
extern EIF_INTEGER_32 F385_6022(EIF_REFERENCE);RTOSHF (EIF_REFERENCE, 6024)


extern EIF_REFERENCE F385_6024(EIF_REFERENCE);
extern void EIF_Minit327(void);
extern void F655_8958(EIF_REFERENCE, EIF_INTEGER_32);
extern void F189_2467(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R2431[])();
extern char *(*R2432[])();
extern char *(*R2434[])();
extern char *(*R2436[])();
extern char *(*R5480[])();
extern long O5472[];
extern long O5461[];
extern long O5462[];
extern long O5463[];
extern long O5464[];
extern long O5465[];
extern long O5466[];
extern long O5467[];

#ifdef __cplusplus
}
#endif

#endif
