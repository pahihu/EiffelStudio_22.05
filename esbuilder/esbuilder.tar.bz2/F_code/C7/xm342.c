/*
 * Code for class XML_CHARACTER_8_INPUT_STREAM_FILTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm342.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XML_CHARACTER_8_INPUT_STREAM_FILTER}.set_source */
void F400_6233 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_source", 399, Current, 0, 1, 6048);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {XML_CHARACTER_8_INPUT_STREAM_FILTER}.name */
EIF_REFERENCE F400_6235 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("name", 399, Current, 0, 0, 6050);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5633[Dtype(RTCW(tr1))-398])(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_CHARACTER_8_INPUT_STREAM_FILTER}.end_of_input */
EIF_BOOLEAN F400_6236 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("end_of_input", 399, Current, 0, 0, 6051);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5634[Dtype(RTCW(tr1))-398])(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_CHARACTER_8_INPUT_STREAM_FILTER}.index */
EIF_INTEGER_32 F400_6238 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("index", 399, Current, 0, 0, 6053);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5636[Dtype(RTCW(tr1))-398])(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_CHARACTER_8_INPUT_STREAM_FILTER}.line */
EIF_INTEGER_32 F400_6239 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("line", 399, Current, 0, 0, 6054);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5637[Dtype(RTCW(tr1))-398])(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_CHARACTER_8_INPUT_STREAM_FILTER}.column */
EIF_INTEGER_32 F400_6240 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("column", 399, Current, 0, 0, 6055);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5638[Dtype(RTCW(tr1))-398])(tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit342 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
