
#ifndef _C7_st312_
#define _C7_st312_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F358_5835(EIF_REFERENCE);
extern void F358_5843(EIF_REFERENCE, EIF_INTEGER_32);
extern void F358_5845(EIF_REFERENCE, EIF_CHARACTER_8);
extern void EIF_Minit312(void);
extern char *(*R7861[])();

#ifdef __cplusplus
}
#endif

#endif
