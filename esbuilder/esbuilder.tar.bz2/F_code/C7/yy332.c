/*
 * Code for class YY_UNICODE_FILE_BUFFER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "yy332.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {YY_UNICODE_FILE_BUFFER}.make_from_utf8_string */
void F390_6057 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("make_from_utf8_string", 389, Current, 0, 1, 5892);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O5494[dtype-387]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	tr1 = RTOSCF(5555,F334_5555, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	F387_6028(Current, arg1);
	RTHOOK(4);
	*(EIF_BOOLEAN *)(Current + O5472[dtype-384]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {YY_UNICODE_FILE_BUFFER}.set_default_encoding */
void F390_6068 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_default_encoding", 389, Current, 0, 1, 5903);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O5504[Dtype(Current)-389]) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {YY_UNICODE_FILE_BUFFER}.fill */
void F390_6069 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_CHARACTER_8 tc3;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("fill", 389, Current, 4, 0, 5904);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O5472[dtype-384]) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O5494[dtype-387]))) {
		RTHOOK(2);
		F390_6071(Current);
		RTHOOK(3);
		loc3 = *(EIF_REFERENCE *)(Current);
		RTHOOK(4);
		if (*(EIF_BOOLEAN *)(Current + O5473[dtype-384])) {
			RTHOOK(5);
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5505[dtype-389]) == ((EIF_INTEGER_32) 1L))) {
				RTHOOK(6);
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				RTHOOK(7);
				loc2 = F654_8952(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5461[dtype-384]) + ((EIF_INTEGER_32) 1L)), loc1);
			} else {
				RTHOOK(8);
				if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5505[dtype-389]) == ((EIF_INTEGER_32) 2L))) {
					RTHOOK(9);
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					RTHOOK(10);
					loc2 = F654_8951(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5461[dtype-384]) + ((EIF_INTEGER_32) 1L)), loc1);
				} else {
					RTHOOK(11);
					if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5504[dtype-389]) == ((EIF_INTEGER_32) 1L))) {
						RTHOOK(12);
						*(EIF_INTEGER_32 *)(Current + O5505[dtype-389]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						RTHOOK(13);
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						RTHOOK(14);
						loc2 = F654_8952(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5461[dtype-384]) + ((EIF_INTEGER_32) 1L)), loc1);
					} else {
						RTHOOK(15);
						*(EIF_INTEGER_32 *)(Current + O5505[dtype-389]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
						RTHOOK(16);
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						RTHOOK(17);
						loc2 = F654_8951(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5461[dtype-384]) + ((EIF_INTEGER_32) 1L)), loc1);
					}
				}
			}
		} else {
			RTHOOK(18);
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5505[dtype-389]) == ((EIF_INTEGER_32) 1L))) {
				RTHOOK(19);
				loc1 = *(EIF_INTEGER_32 *)(Current + O5462[dtype-384]);
				ti4_1 = *(EIF_INTEGER_32 *)(Current + O5461[dtype-384]);
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ti4_1);
				RTHOOK(20);
				loc2 = F654_8952(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5461[dtype-384]) + ((EIF_INTEGER_32) 1L)), loc1);
			} else {
				RTHOOK(21);
				if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5505[dtype-389]) == ((EIF_INTEGER_32) 2L))) {
					RTHOOK(22);
					loc1 = *(EIF_INTEGER_32 *)(Current + O5462[dtype-384]);
					ti4_1 = *(EIF_INTEGER_32 *)(Current + O5461[dtype-384]);
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ti4_1);
					RTHOOK(23);
					loc2 = F654_8951(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5461[dtype-384]) + ((EIF_INTEGER_32) 1L)), loc1);
				} else {
					RTHOOK(24);
					if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5504[dtype-389]) == ((EIF_INTEGER_32) 1L))) {
						RTHOOK(25);
						*(EIF_INTEGER_32 *)(Current + O5505[dtype-389]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						RTHOOK(26);
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						RTHOOK(27);
						loc4 = *(EIF_INTEGER_32 *)(Current + O5461[dtype-384]);
						loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L));
						RTHOOK(28);
						loc2 = F654_8952(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_1_), loc4, loc1);
						RTHOOK(29);
						if ((EIF_BOOLEAN) (loc2 >= loc1)) {
							RTHOOK(30);
							tc1 = F654_8930(RTCW(loc3), loc4);
							tw1 = (EIF_CHARACTER_32) tc1;
							tr1 = RTLNS(eif_new_type(182, 0x00).id, 182, _OBJSIZ_0_0_0_0_0_0_0_0_);
							if ((EIF_BOOLEAN)(tw1 == RTOSCF(2380,F183_2380, (RTCW(tr1))))) {
								RTHOOK(31);
								*(EIF_BOOLEAN *)(Current + O5509[dtype-389]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								RTHOOK(32);
								loc1 = *(EIF_INTEGER_32 *)(Current + O5462[dtype-384]);
								ti4_1 = *(EIF_INTEGER_32 *)(Current + O5461[dtype-384]);
								loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ti4_1);
								RTHOOK(33);
								loc2 = F654_8952(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5461[dtype-384]) + ((EIF_INTEGER_32) 1L)), loc1);
							}
						}
					} else {
						RTHOOK(34);
						loc1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(12163,F1332_12163, (Current)))+ _LNGOFF_1_1_0_2_);
						RTHOOK(35);
						loc4 = *(EIF_INTEGER_32 *)(Current + O5461[dtype-384]);
						loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L));
						RTHOOK(36);
						loc2 = F654_8951(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_1_), loc4, loc1);
						for (;;) {
							RTHOOK(37);
							tb1 = '\01';
							if (!(EIF_BOOLEAN) (loc2 >= loc1)) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4805[Dtype(RTCW(tr1))-1926])(tr1);
								tb1 = tb2;
							}
							if (tb1) break;
							RTHOOK(38);
							ti4_1 = F654_8951(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (loc4 + loc2), (EIF_INTEGER_32) (loc1 - loc2));
							loc2 += ti4_1;
						}
						RTHOOK(39);
						tb2 = '\0';
						if ((EIF_BOOLEAN) (loc2 >= loc1)) {
							tc1 = F654_8930(RTCW(loc3), loc4);
							tc1 = (EIF_CHARACTER_8) tc1;
							tc2 = F654_8930(RTCW(loc3), (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L)));
							tc2 = (EIF_CHARACTER_8) tc2;
							tc3 = F654_8930(RTCW(loc3), (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 2L)));
							tc3 = (EIF_CHARACTER_8) tc3;
							tr1 = RTLNS(eif_new_type(1331, 0x00).id, 1331, _OBJSIZ_0_0_0_0_0_0_0_0_);
							tb2 = F1332_12159(RTCW(tr1), tc1, tc2, tc3);
						}
						if (tb2) {
							RTHOOK(40);
							*(EIF_BOOLEAN *)(Current + O5509[dtype-389]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							RTHOOK(41);
							*(EIF_INTEGER_32 *)(Current + O5505[dtype-389]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
							RTHOOK(42);
							loc1 = *(EIF_INTEGER_32 *)(Current + O5462[dtype-384]);
							ti4_1 = *(EIF_INTEGER_32 *)(Current + O5461[dtype-384]);
							loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ti4_1);
							RTHOOK(43);
							loc2 = F654_8952(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5461[dtype-384]) + ((EIF_INTEGER_32) 1L)), loc1);
						} else {
							RTHOOK(44);
							*(EIF_INTEGER_32 *)(Current + O5505[dtype-389]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
						}
					}
				}
			}
		}
		RTHOOK(45);
		if ((EIF_BOOLEAN) (loc2 < loc1)) {
			RTHOOK(46);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4805[Dtype(RTCW(tr1))-1926])(tr1);
			*(EIF_BOOLEAN *)(Current + O5494[dtype-387]) = (EIF_BOOLEAN) tb2;
		}
		RTHOOK(47);
		(*(EIF_INTEGER_32 *)(Current + O5461[dtype-384])) += loc2;
		RTHOOK(48);
		if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
			RTHOOK(49);
			*(EIF_BOOLEAN *)(Current + O5472[dtype-384]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			RTHOOK(50);
			*(EIF_BOOLEAN *)(Current + O5472[dtype-384]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
		RTHOOK(51);
		F654_8942(RTCW(loc3), (EIF_CHARACTER_8) '\000', (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5461[dtype-384]) + ((EIF_INTEGER_32) 1L)));
		RTHOOK(52);
		F654_8942(RTCW(loc3), (EIF_CHARACTER_8) '\000', (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5461[dtype-384]) + ((EIF_INTEGER_32) 2L)));
	} else {
		RTHOOK(53);
		*(EIF_BOOLEAN *)(Current + O5472[dtype-384]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTHOOK(54);
	RTLE;
	RTEE;
}

/* {YY_UNICODE_FILE_BUFFER}.flush */
void F390_6070 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("flush", 389, Current, 0, 0, 5905);
	RTGC;
	RTHOOK(1);
	F385_6016(Current);
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current + O5505[dtype-389]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(3);
	*(EIF_BOOLEAN *)(Current + O5509[dtype-389]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {YY_UNICODE_FILE_BUFFER}.compact_left */
void F390_6071 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("compact_left", 389, Current, 3, 0, 5906);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5505[dtype-389]) == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(2);
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		RTHOOK(3);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5505[dtype-389]) == ((EIF_INTEGER_32) 2L))) {
			RTHOOK(4);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			RTHOOK(5);
			if (*(EIF_BOOLEAN *)(Current + O5473[dtype-384])) {
				RTHOOK(6);
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			} else {
				RTHOOK(7);
				loc2 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(12163,F1332_12163, (Current)))+ _LNGOFF_1_1_0_2_);
			}
		}
	}
	RTHOOK(8);
	loc3 = *(EIF_INTEGER_32 *)(Current + O5462[dtype-384]);
	RTHOOK(9);
	loc1 = *(EIF_INTEGER_32 *)(Current + O5461[dtype-384]);
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O5466[dtype-384]);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 - ti4_1) + ((EIF_INTEGER_32) 1L));
	RTHOOK(10);
	if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + loc2) > loc3)) {
		RTHOOK(11);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5462[dtype-384]) == ((EIF_INTEGER_32) 0L))) {
			RTHOOK(12);
			ti4_1 = RTOSCF(6022,F385_6022, (Current));
			*(EIF_INTEGER_32 *)(Current + O5462[dtype-384]) = (EIF_INTEGER_32) ti4_1;
		} else {
			RTHOOK(13);
			(*(EIF_INTEGER_32 *)(Current + O5462[dtype-384])) *= ((EIF_INTEGER_32) 2L);
		}
		RTHOOK(14);
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O5462[dtype-384]) < (EIF_INTEGER_32) (loc3 + loc2))) {
			RTHOOK(15);
			*(EIF_INTEGER_32 *)(Current + O5462[dtype-384]) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + loc2);
		}
		RTHOOK(16);
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = F654_8938(RTCW(tr1));
		if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5462[dtype-384]) + ((EIF_INTEGER_32) 2L)) > ti4_1)) {
			RTHOOK(17);
			tr1 = *(EIF_REFERENCE *)(Current);
			F654_8955(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5462[dtype-384]) + ((EIF_INTEGER_32) 2L)));
		}
	}
	RTHOOK(18);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5466[dtype-384]) != ((EIF_INTEGER_32) 1L))) {
		RTHOOK(19);
		tr1 = *(EIF_REFERENCE *)(Current);
		F654_8953(RTCW(tr1), *(EIF_INTEGER_32 *)(Current + O5466[dtype-384]), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)));
		RTHOOK(20);
		*(EIF_INTEGER_32 *)(Current + O5466[dtype-384]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		RTHOOK(21);
		*(EIF_INTEGER_32 *)(Current + O5461[dtype-384]) = (EIF_INTEGER_32) loc1;
	}
	RTHOOK(26);
	RTLE;
	RTEE;
}

void EIF_Minit332 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
