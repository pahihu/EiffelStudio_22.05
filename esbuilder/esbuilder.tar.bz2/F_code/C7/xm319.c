/*
 * Code for class XML_STRING_32_OUTPUT_STREAM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm319.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XML_STRING_32_OUTPUT_STREAM}.is_open_write */
EIF_BOOLEAN F377_5931 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {XML_STRING_32_OUTPUT_STREAM}.flush */
void F377_5932 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("flush", 376, Current, 0, 0, 5767);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XML_STRING_32_OUTPUT_STREAM}.put_string_8 */
void F377_5935 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("put_string_8", 376, Current, 0, 1, 5770);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	F1510_14565(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_STRING_32_OUTPUT_STREAM}.put_string_32 */
void F377_5936 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("put_string_32", 376, Current, 0, 1, 5771);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	F1510_14566(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit319 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
