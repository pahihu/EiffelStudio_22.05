
#ifndef _C7_xm321_
#define _C7_xm321_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F379_5941(EIF_REFERENCE);
extern void F379_5945(EIF_REFERENCE);
extern void F379_5947(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit321(void);
extern EIF_REFERENCE F1500_14208(EIF_REFERENCE);
extern EIF_BOOLEAN F1211_10679(EIF_REFERENCE);
extern char *(*R11574[])();
extern char *(*R8765[])();
extern char *(*R11633[])();
extern long O11609[];

#ifdef __cplusplus
}
#endif

#endif
