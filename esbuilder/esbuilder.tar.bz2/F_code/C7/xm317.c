/*
 * Code for class XML_OUTPUT_STREAM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm317.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XML_OUTPUT_STREAM}.put_string_general */
void F375_5896 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTEAA("put_string_general", 374, Current, 2, 1, 5733);
	RTGC;
	RTHOOK(1);
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(1502, 0x00),loc1);
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5395[dtype-375])(Current, loc1);
	} else {
		RTHOOK(3);
		loc2 = arg1;
		loc2 = RTRV(eif_new_type(1507, 0x00),loc2);
		if (EIF_TEST(loc2)) {
			RTHOOK(4);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5397[dtype-375])(Current, loc2);
		} else {
			
			RTHOOK(6);
			tr1 = F1500_14214(RTCW(arg1));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5397[dtype-375])(Current, tr1);
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {XML_OUTPUT_STREAM}.put_string_32_escaped */
void F375_5900 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("put_string_32_escaped", 374, Current, 0, 1, 5736);
	RTGC;
	RTHOOK(1);
	tr1 = F375_5917(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5397[Dtype(Current)-375])(Current, tr1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {XML_OUTPUT_STREAM}.xml_escaped_string */
EIF_REFERENCE F375_5916 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("xml_escaped_string", 374, Current, 0, 1, 5751);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(5918,F375_5918, (Current));
	Result = F37_471(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_OUTPUT_STREAM}.xml_escaped_unicode_string */
EIF_REFERENCE F375_5917 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("xml_escaped_unicode_string", 374, Current, 0, 1, 5752);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(5918,F375_5918, (Current));
	Result = F37_472(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_OUTPUT_STREAM}.xml_utilities */
static EIF_REFERENCE F375_5918_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("xml_utilities", 374, Current, 0, 0, 5753);
	RTGC;
	RTOSP (5918);
#define Result RTOSR(5918)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(36, 0x00).id, 36, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (5918);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F375_5918 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(5918,F375_5918_body,(Current));
}

void EIF_Minit317 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
