
#ifndef _C7_xm318_
#define _C7_xm318_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F376_5922(EIF_REFERENCE);
extern void F376_5923(EIF_REFERENCE);
extern void F376_5925(EIF_REFERENCE, EIF_REFERENCE);
extern void F376_5927(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit318(void);

#ifdef __cplusplus
}
#endif

#endif
