/*
 * Code for class XML_STRING_32_INPUT_STREAM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm341.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XML_STRING_32_INPUT_STREAM}.name */

EIF_REFERENCE F399_6218 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6218,RTMS32_EX_H("S\000\000\000T\000\000\000R\000\000\000I\000\000\000N\000\000\000G\000\000\000",6,1544365639));
}

/* {XML_STRING_32_INPUT_STREAM}.end_of_input */
EIF_BOOLEAN F399_6220 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_);
}


/* {XML_STRING_32_INPUT_STREAM}.index */
EIF_INTEGER_32 F399_6222 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("index", 398, Current, 0, 0, 6039);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) - ((EIF_INTEGER_32) 1L));
}

/* {XML_STRING_32_INPUT_STREAM}.line */
EIF_INTEGER_32 F399_6223 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_4_);
}


/* {XML_STRING_32_INPUT_STREAM}.column */
EIF_INTEGER_32 F399_6224 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
}


/* {XML_STRING_32_INPUT_STREAM}.last_character_code */
EIF_NATURAL_32 F399_6225 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 tw1;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("last_character_code", 398, Current, 0, 0, 6042);
	RTGC;
	RTHOOK(1);
	tw1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_1_1_0_0_);
	Result = (EIF_NATURAL_32) tw1;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STRING_32_INPUT_STREAM}.read_character_code */
void F399_6227 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("read_character_code", 398, Current, 0, 0, 6044);
	RTHOOK(1);
	F399_6228(Current);
	RTHOOK(2);
	RTEE;
}

/* {XML_STRING_32_INPUT_STREAM}.read_character */
void F399_6228 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("read_character", 398, Current, 1, 0, 6045);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_1_))) {
		RTHOOK(2);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current);
		loc1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11450[Dtype(RTCW(tr1))-1503])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_));
		RTHOOK(4);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_))++;
		RTHOOK(5);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
		if ((EIF_BOOLEAN)(*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_1_1_0_0_) == tw1)) {
			RTHOOK(6);
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_4_))++;
			RTHOOK(7);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		} else {
			RTHOOK(8);
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))++;
		}
		RTHOOK(9);
		*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_CHARACTER_32) loc1;
	}
	RTHOOK(10);
	RTLE;
	RTEE;
}

void EIF_Minit341 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
