
#ifndef _C7_xm320_
#define _C7_xm320_

#ifdef __cplusplus
extern "C" {
#endif

extern void F378_5938(EIF_REFERENCE, EIF_REFERENCE);
extern void F378_5939(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit320(void);
extern EIF_REFERENCE F1500_14208(EIF_REFERENCE);
extern EIF_BOOLEAN F1508_14483(EIF_REFERENCE);
extern EIF_REFERENCE F375_5916(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5395[])();

#ifdef __cplusplus
}
#endif

#endif
