
#ifndef _C7_yy331_
#define _C7_yy331_

#ifdef __cplusplus
extern "C" {
#endif

extern void F389_6053(EIF_REFERENCE);
extern void F389_6054(EIF_REFERENCE);
extern void F389_6055(EIF_REFERENCE);
extern void EIF_Minit331(void);
extern EIF_BOOLEAN F1332_12159(EIF_REFERENCE, EIF_CHARACTER_8, EIF_CHARACTER_8, EIF_CHARACTER_8);
extern EIF_CHARACTER_8 F1930_21290(EIF_REFERENCE, EIF_INTEGER_32);
extern void F385_6016(EIF_REFERENCE);
extern EIF_INTEGER_32 F385_6022(EIF_REFERENCE);
extern EIF_REFERENCE F1332_12163(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,12163)
RTOSHF(EIF_INTEGER_32,6022)
extern char *(*R2430[])();
extern char *(*R2431[])();
extern char *(*R2432[])();
extern char *(*R2433[])();
extern char *(*R2434[])();
extern char *(*R2436[])();
extern char *(*R4805[])();

#ifdef __cplusplus
}
#endif

#endif
