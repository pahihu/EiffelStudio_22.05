/*
 * Code for class STRING_32_SEARCHER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "st315.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {STRING_32_SEARCHER}.max_code_point_value */
EIF_INTEGER_32 F361_5871 (EIF_REFERENCE Current)
{
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2000L);
}

/* {STRING_32_SEARCHER}.substring_index_with_deltas */
EIF_INTEGER_32 F361_5872 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,loc8);
	RTLR(3,loc7);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("substring_index_with_deltas", 360, Current, 9, 4, 5692);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == arg2)) {
		RTHOOK(2);
		if ((EIF_BOOLEAN)(arg3 == ((EIF_INTEGER_32) 1L))) {
			RTHOOK(3);
			RTHOOK(4);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		}
	} else {
		RTHOOK(5);
		loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R11486[Dtype(RTCW(arg2))-1503])(arg2);
		
		RTHOOK(7);
		loc8 = *(EIF_REFERENCE *)(RTCW(arg1));
		RTHOOK(8);
		loc9 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R11682[Dtype(RTCW(arg1))-1508])(arg1);
		RTHOOK(9);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg3 + loc9);
		RTHOOK(10);
		loc7 = *(EIF_REFERENCE *)(Current);
		RTHOOK(11);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg4 + ((EIF_INTEGER_32) 1L)) + loc9);
		for (;;) {
			RTHOOK(12);
			if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + loc4) > loc3)) break;
			RTHOOK(13);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			RTHOOK(14);
			loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			for (;;) {
				RTHOOK(15);
				if ((EIF_BOOLEAN)(loc2 == loc4)) break;
				RTHOOK(16);
				/* INLINED CODE (SPECIAL.item) */
				tw2 = *((EIF_CHARACTER_32 *)RTCW(loc8) + ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + loc2) - ((EIF_INTEGER_32) 1L))));
				/* END INLINED CODE */
				tw1 = tw2;
				tu4_1 = (EIF_NATURAL_32) tw1;
				tu4_2 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R11449[Dtype(RTCW(arg2))-1503])(arg2, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
				if ((EIF_BOOLEAN)(tu4_1 != tu4_2)) {
					RTHOOK(17);
					loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 - ((EIF_INTEGER_32) 1L));
					RTHOOK(18);
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				}
				RTHOOK(19);
				loc2++;
			}
			RTHOOK(20);
			if (loc5) {
				RTHOOK(21);
				Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - loc9);
				RTHOOK(22);
				loc1 = (EIF_INTEGER_32) loc3;
			} else {
				RTHOOK(23);
				if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + loc4) <= arg4)) {
					RTHOOK(24);
					/* INLINED CODE (SPECIAL.item) */
					tw2 = *((EIF_CHARACTER_32 *)RTCW(loc8) + ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + loc4) - ((EIF_INTEGER_32) 1L))));
					/* END INLINED CODE */
					tw1 = tw2;
					loc6 = (EIF_INTEGER_32) (tw1);
					RTHOOK(25);
					if ((EIF_BOOLEAN) (loc6 > ((EIF_INTEGER_32) 2000L))) {
						RTHOOK(26);
						loc1++;
					} else {
						RTHOOK(27);
						/* INLINED CODE (SPECIAL.item) */
						ti4_2 = *((EIF_INTEGER_32 *)RTCW(loc7) + (loc6));
						/* END INLINED CODE */
						ti4_1 = ti4_2;
						loc1 += ti4_1;
					}
				} else {
					RTHOOK(28);
					loc1++;
				}
			}
		}
	}
	RTHOOK(29);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit315 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
