/*
 * Code for class XM_EIFFEL_UNICODE_STRUCTURE_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm335.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_EIFFEL_UNICODE_STRUCTURE_FACTORY}.new_entities_table */
EIF_REFERENCE F393_6084 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("new_entities_table", 392, Current, 0, 0, 5919);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {2158,2291,1504,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 2158, _OBJSIZ_11_0_0_9_0_0_0_0_);
	}
	F2155_24486(RTCW(Result));
	RTHOOK(2);
	tr1 = RTOSCF(6072,F391_6072, (Current));
	F2155_24502(RTCW(Result), tr1);
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit335 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
