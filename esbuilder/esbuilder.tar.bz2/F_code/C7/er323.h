
#ifndef _C7_er323_
#define _C7_er323_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F381_5967(EIF_REFERENCE);
extern EIF_INTEGER_32 F381_5968(EIF_REFERENCE);
extern void EIF_Minit323(void);

#ifdef __cplusplus
}
#endif

#endif
