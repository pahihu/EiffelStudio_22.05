/*
 * Code for class XML_STOPPABLE_PARSER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm339.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XML_STOPPABLE_PARSER}.reset */
void F397_6200 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("reset", 396, Current, 0, 0, 6017);
	RTGC;
	RTHOOK(1);
	F396_6124(Current);
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_5_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {XML_STOPPABLE_PARSER}.checkpoint_position */
EIF_REFERENCE F397_6201 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("checkpoint_position", 396, Current, 0, 0, 6018);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_5_0_2_) > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		Result = RTLNS(eif_new_type(1252, 0x00).id, 1252, _OBJSIZ_1_0_0_3_0_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5633[Dtype(RTCW(tr1))-398])(tr1);
		tr1 = F1500_14214(RTCW(tr1));
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_5_0_4_);
		ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_5_0_3_);
		ti4_3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_5_0_2_);
		F1253_11726(RTCW(Result), tr1, ti4_1, ti4_2, ti4_3);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {XML_STOPPABLE_PARSER}.set_checkpoint_position */
void F397_6205 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_checkpoint_position", 396, Current, 0, 0, 6022);
	RTGC;
	RTHOOK(1);
	ti4_1 = F396_6122(Current);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_5_0_2_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(2);
	ti4_1 = F396_6123(Current);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_5_0_3_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(3);
	ti4_1 = F396_6121(Current);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_5_0_4_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {XML_STOPPABLE_PARSER}.unset_checkpoint_position */
void F397_6206 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("unset_checkpoint_position", 396, Current, 0, 0, 6023);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_5_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_5_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(3);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_5_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {XML_STOPPABLE_PARSER}.report_error */
void F397_6207 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("report_error", 396, Current, 0, 1, 6024);
	RTGC;
	RTHOOK(1);
	F396_6139(Current, arg1);
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_5_3_);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit339 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
