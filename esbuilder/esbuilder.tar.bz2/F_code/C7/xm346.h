
#ifndef _C7_xm346_
#define _C7_xm346_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F404_6290(EIF_REFERENCE);
extern void EIF_Minit346(void);

#ifdef __cplusplus
}
#endif

#endif
