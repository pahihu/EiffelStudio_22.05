/*
 * Code for class XM_CALLBACKS_NULL
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm348.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_CALLBACKS_NULL}.make */
void F406_6307 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make", 405, Current, 0, 0, 6105);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XM_CALLBACKS_NULL}.on_start */
void F406_6309 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("on_start", 405, Current, 0, 0, 6107);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XM_CALLBACKS_NULL}.on_finish */
void F406_6310 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("on_finish", 405, Current, 0, 0, 6108);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XM_CALLBACKS_NULL}.on_xml_declaration */
void F406_6311 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("on_xml_declaration", 405, Current, 0, 3, 6109);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XM_CALLBACKS_NULL}.on_error */
void F406_6312 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("on_error", 405, Current, 0, 1, 6110);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XM_CALLBACKS_NULL}.on_processing_instruction */
void F406_6313 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("on_processing_instruction", 405, Current, 0, 2, 6111);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XM_CALLBACKS_NULL}.on_comment */
void F406_6314 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("on_comment", 405, Current, 0, 1, 6112);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XM_CALLBACKS_NULL}.on_start_tag */
void F406_6315 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("on_start_tag", 405, Current, 0, 3, 6113);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XM_CALLBACKS_NULL}.on_attribute */
void F406_6316 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("on_attribute", 405, Current, 0, 4, 6114);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XM_CALLBACKS_NULL}.on_start_tag_finish */
void F406_6317 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("on_start_tag_finish", 405, Current, 0, 0, 6115);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XM_CALLBACKS_NULL}.on_end_tag */
void F406_6318 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("on_end_tag", 405, Current, 0, 3, 6116);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XM_CALLBACKS_NULL}.on_content */
void F406_6319 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("on_content", 405, Current, 0, 1, 6117);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

void EIF_Minit348 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
