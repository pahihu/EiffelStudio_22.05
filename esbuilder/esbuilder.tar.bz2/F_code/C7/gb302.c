/*
 * Code for class GB_ABOUT_DIALOG_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gb302.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GB_ABOUT_DIALOG_CONSTANTS}.t_version_info */
static EIF_REFERENCE F348_5688_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_16 tu2_1;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("t_version_info", 347, Current, 0, 0, 5516);
	RTGC;
	RTOSP (5688);
#define Result RTOSR(5688)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS_EX_H("EiffelBuild ",12,838497056);
	RTHOOK(2);
	tr1 = RTOSCF(5685,F347_5685, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11635[Dtype(RTCW(Result))-1504])(Result, tr1);
	RTHOOK(3);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R11637[Dtype(RTCW(Result))-1504])(Result, (EIF_CHARACTER_8) '.');
	RTHOOK(4);
	tr1 = RTOSCF(5686,F347_5686, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11635[Dtype(RTCW(Result))-1504])(Result, tr1);
	RTHOOK(5);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R11637[Dtype(RTCW(Result))-1504])(Result, (EIF_CHARACTER_8) '.');
	RTHOOK(6);
	tu4_1 = (EIF_NATURAL_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 9999L) + ((EIF_INTEGER_32) 1L));
	tu2_1 = (EIF_NATURAL_16) (EIF_NATURAL_32) (F348_5691(Current) / tu4_1);
	tr1 = eif_out__u2_s1(tu2_1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11633[Dtype(RTCW(Result))-1504])(Result, tr1);
	RTHOOK(7);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R11637[Dtype(RTCW(Result))-1504])(Result, (EIF_CHARACTER_8) '.');
	RTHOOK(8);
	tu4_1 = (EIF_NATURAL_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 9999L) + ((EIF_INTEGER_32) 1L));
	tu2_1 = (EIF_NATURAL_16) (EIF_NATURAL_32) (F348_5691(Current) % tu4_1);
	tr1 = eif_out__u2_s1(tu2_1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11633[Dtype(RTCW(Result))-1504])(Result, tr1);
	RTOSE (5688);
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F348_5688 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(5688,F348_5688_body,(Current));
}

/* {GB_ABOUT_DIALOG_CONSTANTS}.t_copyright_info */
static EIF_REFERENCE F348_5689_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("t_copyright_info", 347, Current, 0, 0, 5517);
	RTGC;
	RTOSP (5689);
#define Result RTOSR(5689)
	RTOC_NEW(Result);
	RTHOOK(1);
	Result = RTMS_EX_H("Copyright (C) 1985-2022 Eiffel Software Inc.\012All rights reserved",64,1671427428);
	RTOSE (5689);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F348_5689 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(5689,F348_5689_body,(Current));
}

/* {GB_ABOUT_DIALOG_CONSTANTS}.t_info */
static EIF_REFERENCE F348_5690_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("t_info", 347, Current, 0, 0, 5518);
	RTGC;
	RTOSP (5690);
#define Result RTOSR(5690)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1504, 0x00).id, 1504, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1503_14285(RTCW(tr1), ((EIF_INTEGER_32) 500L));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = RTMS_EX_H("Eiffel Software\0125949 Hollister Ave., Goleta, CA 93117 USA\012Telephone: 805-685-1006\012Fax 805-685-6869\012\012Web Customer Support: http://support.eiffel.com\012Visit Eiffel on the Web: http://www.eiffel.com\012",195,1125241354);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11633[Dtype(RTCW(Result))-1504])(Result, tr1);
	RTOSE (5690);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F348_5690 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(5690,F348_5690_body,(Current));
}

/* {GB_ABOUT_DIALOG_CONSTANTS}.svn_revision */
EIF_NATURAL_32 F348_5691 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	
	
	RTEAA("svn_revision", 347, Current, 0, 0, 5519);
	RTHOOK(1);
	Result = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 106292L);
	RTHOOK(2);
	RTEE;
	return Result;
}

void EIF_Minit302 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
