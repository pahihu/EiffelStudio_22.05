
#ifndef _C7_st314_
#define _C7_st314_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F360_5867(EIF_REFERENCE);
extern EIF_INTEGER_32 F360_5868(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit314(void);
extern char *(*R11607[])();
extern char *(*R11486[])();
extern char *(*R11449[])();

#ifdef __cplusplus
}
#endif

#endif
