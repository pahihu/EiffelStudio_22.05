
#ifndef _C7_st313_
#define _C7_st313_

#ifdef __cplusplus
extern "C" {
#endif

extern void F359_5854(EIF_REFERENCE);
extern void F359_5855(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F359_5858(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_REFERENCE F359_5860(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F359_5864(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE);
extern void EIF_Minit313(void);
extern void F1151_10111(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1262_11873(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern char *(*R5368[])();
extern char *(*R11449[])();
extern char *(*R7993[])();
extern char *(*R11486[])();
extern char *(*R5366[])();

#ifdef __cplusplus
}
#endif

#endif
