
#ifndef _C7_xm342_
#define _C7_xm342_

#ifdef __cplusplus
extern "C" {
#endif

extern void F400_6233(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F400_6235(EIF_REFERENCE);
extern EIF_BOOLEAN F400_6236(EIF_REFERENCE);
extern EIF_INTEGER_32 F400_6238(EIF_REFERENCE);
extern EIF_INTEGER_32 F400_6239(EIF_REFERENCE);
extern EIF_INTEGER_32 F400_6240(EIF_REFERENCE);
extern void EIF_Minit342(void);
extern char *(*R5633[])();
extern char *(*R5634[])();
extern char *(*R5636[])();
extern char *(*R5637[])();
extern char *(*R5638[])();

#ifdef __cplusplus
}
#endif

#endif
