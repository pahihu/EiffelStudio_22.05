
#ifndef _C7_yy330_
#define _C7_yy330_

#ifdef __cplusplus
extern "C" {
#endif

extern void F388_6033(EIF_REFERENCE, EIF_REFERENCE);
extern void F388_6034(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F388_6035(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F388_6036(EIF_REFERENCE);
extern void F388_6039(EIF_REFERENCE, EIF_REFERENCE);
extern void F388_6040(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F388_6043(EIF_REFERENCE);
extern void EIF_Minit330(void);
extern EIF_REFERENCE F334_5555(EIF_REFERENCE);
extern void F385_5997(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F385_6022(EIF_REFERENCE);
RTOSHF(EIF_INTEGER_32,6022)
RTOSHF(EIF_REFERENCE,5555)
extern char *(*R4799[])();
extern char *(*R5492[])();
extern char *(*R2432[])();
extern char *(*R2433[])();
extern char *(*R2436[])();
extern char *(*R4805[])();
extern char *(*R4807[])();
extern char *(*R4808[])();
extern char *(*R5476[])();
extern char *(*R5478[])();
extern char *(*R5480[])();
extern long O5472[];
extern long O5473[];
extern long O5494[];
extern long O5461[];
extern long O5462[];

#ifdef __cplusplus
}
#endif

#endif
