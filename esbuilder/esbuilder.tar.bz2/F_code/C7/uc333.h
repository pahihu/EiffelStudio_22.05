
#ifndef _C7_uc333_
#define _C7_uc333_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,6072)
static EIF_REFERENCE F391_6072_body(EIF_REFERENCE);
extern EIF_REFERENCE F391_6072(EIF_REFERENCE);
extern void EIF_Minit333(void);

#ifdef __cplusplus
}
#endif

#endif
