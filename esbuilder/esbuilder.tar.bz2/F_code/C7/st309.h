
#ifndef _C7_st309_
#define _C7_st309_

#ifdef __cplusplus
extern "C" {
#endif

extern void F355_5772(EIF_REFERENCE, EIF_BOOLEAN);
extern void F355_5773(EIF_REFERENCE, EIF_BOOLEAN);
extern void F355_5774(EIF_REFERENCE, EIF_REFERENCE);
extern void F355_5775(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit309(void);
extern void F1503_14287(EIF_REFERENCE, EIF_REFERENCE);
extern long O5294[];
extern long O5295[];

#ifdef __cplusplus
}
#endif

#endif
