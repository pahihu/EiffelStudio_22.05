
#ifndef _C7_nu307_
#define _C7_nu307_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_64 F353_5733(EIF_REFERENCE);
extern void EIF_Minit307(void);

#ifdef __cplusplus
}
#endif

#endif
