/*
 * Code for class YY_UTF8_FILE_BUFFER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "yy331.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {YY_UTF8_FILE_BUFFER}.fill */
void F389_6053 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc7 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_CHARACTER_8 tc3;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("fill", 388, Current, 8, 0, 5888);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_3_))) {
		RTHOOK(2);
		F389_6055(Current);
		RTHOOK(3);
		loc3 = *(EIF_REFERENCE *)(Current);
		RTHOOK(4);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_2_)) {
			RTHOOK(5);
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_7_) == ((EIF_INTEGER_32) 1L))) {
				RTHOOK(6);
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				RTHOOK(7);
				loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R2433[Dtype(RTCW(loc3))-653])(loc3, *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_) + ((EIF_INTEGER_32) 1L)), loc1);
			} else {
				RTHOOK(8);
				if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_7_) == ((EIF_INTEGER_32) 2L))) {
					RTHOOK(9);
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					RTHOOK(10);
					loc6 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_);
					loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L)) + loc1);
					RTHOOK(11);
					loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R2433[Dtype(RTCW(loc3))-653])(loc3, *(EIF_REFERENCE *)(Current + _REFACS_1_), loc6, loc1);
				} else {
					RTHOOK(12);
					if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_6_) == ((EIF_INTEGER_32) 1L))) {
						RTHOOK(13);
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_7_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						RTHOOK(14);
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						RTHOOK(15);
						loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R2433[Dtype(RTCW(loc3))-653])(loc3, *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_) + ((EIF_INTEGER_32) 1L)), loc1);
					} else {
						RTHOOK(16);
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_7_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
						RTHOOK(17);
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						RTHOOK(18);
						loc6 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_);
						loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L)) + loc1);
						RTHOOK(19);
						loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R2433[Dtype(RTCW(loc3))-653])(loc3, *(EIF_REFERENCE *)(Current + _REFACS_1_), loc6, loc1);
					}
				}
			}
		} else {
			RTHOOK(20);
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_7_) == ((EIF_INTEGER_32) 1L))) {
				RTHOOK(21);
				loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_);
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ti4_1);
				RTHOOK(22);
				loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R2433[Dtype(RTCW(loc3))-653])(loc3, *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_) + ((EIF_INTEGER_32) 1L)), loc1);
			} else {
				RTHOOK(23);
				if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_7_) == ((EIF_INTEGER_32) 2L))) {
					RTHOOK(24);
					loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_);
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_);
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 - ti4_1) / ((EIF_INTEGER_32) 2L));
					RTHOOK(25);
					loc6 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_);
					loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L)) + loc1);
					RTHOOK(26);
					loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R2433[Dtype(RTCW(loc3))-653])(loc3, *(EIF_REFERENCE *)(Current + _REFACS_1_), loc6, loc1);
				} else {
					RTHOOK(27);
					loc1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(12163,F1332_12163, (Current)))+ _LNGOFF_1_1_0_2_);
					RTHOOK(28);
					loc6 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_);
					loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L)) + loc1);
					RTHOOK(29);
					loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R2433[Dtype(RTCW(loc3))-653])(loc3, *(EIF_REFERENCE *)(Current + _REFACS_1_), loc6, loc1);
					for (;;) {
						RTHOOK(30);
						tb1 = '\01';
						if (!(EIF_BOOLEAN) (loc2 >= loc1)) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4805[Dtype(RTCW(tr1))-1926])(tr1);
							tb1 = tb2;
						}
						if (tb1) break;
						RTHOOK(31);
						ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R2433[Dtype(RTCW(loc3))-653])(loc3, *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (loc6 + loc2), (EIF_INTEGER_32) (loc1 - loc2));
						loc2 += ti4_1;
					}
					RTHOOK(32);
					tb2 = '\0';
					if ((EIF_BOOLEAN) (loc2 >= loc1)) {
						tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R2430[Dtype(RTCW(loc3))-653])(loc3, loc6));
						tc2 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R2430[Dtype(RTCW(loc3))-653])(loc3, (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L))));
						tc3 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R2430[Dtype(RTCW(loc3))-653])(loc3, (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 2L))));
						tr1 = RTLNS(eif_new_type(1331, 0x00).id, 1331, _OBJSIZ_0_0_0_0_0_0_0_0_);
						tb2 = F1332_12159(RTCW(tr1), tc1, tc2, tc3);
					}
					if (tb2) {
						RTHOOK(33);
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_7_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						RTHOOK(34);
						loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_);
						ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_);
						loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ti4_1);
						RTHOOK(35);
						loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R2433[Dtype(RTCW(loc3))-653])(loc3, *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_) + ((EIF_INTEGER_32) 1L)), loc1);
					} else {
						RTHOOK(36);
						if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_6_) == ((EIF_INTEGER_32) 1L))) {
							RTHOOK(37);
							*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_7_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						} else {
							RTHOOK(38);
							*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_7_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
						}
					}
				}
			}
		}
		RTHOOK(39);
		if ((EIF_BOOLEAN) (loc2 < loc1)) {
			RTHOOK(40);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4805[Dtype(RTCW(tr1))-1926])(tr1);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_2_3_) = (EIF_BOOLEAN) tb2;
		}
		RTHOOK(41);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_7_) == ((EIF_INTEGER_32) 2L))) {
			RTHOOK(42);
			loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			RTHOOK(43);
			loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_);
			for (;;) {
				RTHOOK(44);
				if ((EIF_BOOLEAN) (loc4 > loc2)) break;
				RTHOOK(45);
				loc7 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R2430[Dtype(RTCW(loc3))-653])(loc3, loc6));
				RTHOOK(46);
				loc8 = (EIF_INTEGER_32) (loc7);
				RTHOOK(47);
				if ((EIF_BOOLEAN) (loc8 <= ((EIF_INTEGER_32) 127L))) {
					RTHOOK(48);
					loc5++;
					RTHOOK(49);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R2432[Dtype(RTCW(loc3))-653])(loc3, (EIF_REFERENCE) &loc7, loc5);
				} else {
					RTHOOK(50);
					loc5++;
					RTHOOK(51);
					tr1 = RTLNS(eif_new_type(1929, 0x00).id, 1929, _OBJSIZ_0_0_0_0_0_0_0_0_);
					tc1 = F1930_21290(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc8 / ((EIF_INTEGER_32) 64L)) + ((EIF_INTEGER_32) 192L)));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R2432[Dtype(RTCW(loc3))-653])(loc3, (EIF_REFERENCE) &tc1, loc5);
					RTHOOK(52);
					loc5++;
					RTHOOK(53);
					tr1 = RTLNS(eif_new_type(1929, 0x00).id, 1929, _OBJSIZ_0_0_0_0_0_0_0_0_);
					tc1 = F1930_21290(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc8 % ((EIF_INTEGER_32) 64L)) + ((EIF_INTEGER_32) 128L)));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R2432[Dtype(RTCW(loc3))-653])(loc3, (EIF_REFERENCE) &tc1, loc5);
				}
				RTHOOK(54);
				loc6++;
				RTHOOK(55);
				loc4++;
			}
			RTHOOK(56);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_) = (EIF_INTEGER_32) loc5;
		} else {
			RTHOOK(57);
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_)) += loc2;
		}
		RTHOOK(58);
		if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
			RTHOOK(59);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			RTHOOK(60);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
		RTHOOK(61);
		tc1 = (EIF_CHARACTER_8) '\000';
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R2432[Dtype(RTCW(loc3))-653])(loc3, (EIF_REFERENCE) &tc1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
		RTHOOK(62);
		tc1 = (EIF_CHARACTER_8) '\000';
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R2432[Dtype(RTCW(loc3))-653])(loc3, (EIF_REFERENCE) &tc1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 2L)));
	} else {
		RTHOOK(63);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTHOOK(64);
	RTLE;
	RTEE;
}

/* {YY_UTF8_FILE_BUFFER}.flush */
void F389_6054 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("flush", 388, Current, 0, 0, 5889);
	RTGC;
	RTHOOK(1);
	F385_6016(Current);
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_7_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {YY_UTF8_FILE_BUFFER}.compact_left */
void F389_6055 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("compact_left", 388, Current, 3, 0, 5890);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_7_) == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(2);
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		RTHOOK(3);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_7_) == ((EIF_INTEGER_32) 2L))) {
			RTHOOK(4);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		} else {
			RTHOOK(5);
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_2_)) {
				RTHOOK(6);
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
			} else {
				RTHOOK(7);
				loc2 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(12163,F1332_12163, (Current)))+ _LNGOFF_1_1_0_2_);
				loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 * ((EIF_INTEGER_32) 2L));
			}
		}
	}
	RTHOOK(8);
	loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_);
	RTHOOK(9);
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_5_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 - ti4_1) + ((EIF_INTEGER_32) 1L));
	RTHOOK(10);
	if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + loc2) > loc3)) {
		RTHOOK(11);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_) == ((EIF_INTEGER_32) 0L))) {
			RTHOOK(12);
			ti4_1 = RTOSCF(6022,F385_6022, (Current));
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_) = (EIF_INTEGER_32) ti4_1;
		} else {
			RTHOOK(13);
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_)) *= ((EIF_INTEGER_32) 2L);
		}
		RTHOOK(14);
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_) < (EIF_INTEGER_32) (loc3 + loc2))) {
			RTHOOK(15);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + loc2);
		}
		RTHOOK(16);
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R2431[Dtype(RTCW(tr1))-653])(tr1);
		if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_) + ((EIF_INTEGER_32) 2L)) > ti4_1)) {
			RTHOOK(17);
			tr1 = *(EIF_REFERENCE *)(Current);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R2436[Dtype(RTCW(tr1))-653])(tr1, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_) + ((EIF_INTEGER_32) 2L)));
		}
	}
	RTHOOK(18);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_5_) != ((EIF_INTEGER_32) 1L))) {
		RTHOOK(19);
		tr1 = *(EIF_REFERENCE *)(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R2434[Dtype(RTCW(tr1))-653])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_5_), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)));
		RTHOOK(20);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		RTHOOK(21);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_) = (EIF_INTEGER_32) loc1;
	}
	RTHOOK(26);
	RTLE;
	RTEE;
}

void EIF_Minit331 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
