
#ifndef _C21_ev1016_
#define _C21_ev1016_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1739_18174(EIF_REFERENCE);
extern void EIF_Minit1016(void);

#ifdef __cplusplus
}
#endif

#endif
