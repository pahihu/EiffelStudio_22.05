
#ifndef _C21_ev1015_
#define _C21_ev1015_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1738_18166(EIF_REFERENCE);
extern void F1738_18167(EIF_REFERENCE);
extern void F1738_18168(EIF_REFERENCE);
extern EIF_BOOLEAN F1738_18170(EIF_REFERENCE);
extern EIF_BOOLEAN F1738_18172(EIF_REFERENCE);
extern void EIF_Minit1015(void);
extern EIF_BOOLEAN F1377_12721(EIF_REFERENCE);
extern EIF_BOOLEAN F1687_17102(EIF_REFERENCE);
extern char *(*R14614[])();
extern long O14438[];

#ifdef __cplusplus
}
#endif

#endif
