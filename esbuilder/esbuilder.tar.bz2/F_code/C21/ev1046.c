/*
 * Code for class EV_FILE_DIALOG_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1046.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F220_3702
static EIF_POINTER inline_F220_3702 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	return (EIF_POINTER) (gtk_file_chooser_dialog_new ((gchar*) arg1, (GtkWindow*) arg2, (GtkFileChooserAction) arg3, NULL, NULL))
	;
}
#define INLINE_F220_3702
#endif
#ifndef INLINE_F220_3686
static EIF_POINTER inline_F220_3686 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	return (EIF_POINTER) (gtk_dialog_add_button ((GtkDialog*) arg1, (gchar*) arg2, (gint) arg3))
	;
}
#define INLINE_F220_3686
#endif
#ifndef INLINE_F220_3707
static void inline_F220_3707 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	gtk_file_chooser_set_local_only ((GtkFileChooser*) arg1, (gboolean) arg2)
	;
}
#define INLINE_F220_3707
#endif
#ifndef INLINE_F220_3688
static void inline_F220_3688 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_dialog_set_default_response ((GtkDialog*) arg1, (gint) arg2)
	;
}
#define INLINE_F220_3688
#endif
#ifndef INLINE_F220_3704
static EIF_POINTER inline_F220_3704 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gtk_file_chooser_get_filename ((GtkFileChooser*) arg1))
	;
}
#define INLINE_F220_3704
#endif
#ifndef INLINE_F220_3694
static void inline_F220_3694 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_file_chooser_remove_filter ((GtkFileChooser*) arg1, (GtkFileFilter*) arg2)
	;
}
#define INLINE_F220_3694
#endif
#ifndef INLINE_F220_3691
static void inline_F220_3691 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_file_filter_set_name ((GtkFileFilter*) arg1, (gchar*) arg2)
	;
}
#define INLINE_F220_3691
#endif
#ifndef INLINE_F220_3690
static void inline_F220_3690 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_file_filter_add_pattern ((GtkFileFilter*) arg1, (gchar*) arg2)
	;
}
#define INLINE_F220_3690
#endif
#ifndef INLINE_F220_3693
static void inline_F220_3693 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_file_chooser_add_filter ((GtkFileChooser*) arg1, (GtkFileFilter*) arg2)
	;
}
#define INLINE_F220_3693
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_FILE_DIALOG_IMP}.make */
void F1769_18551 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("make", 1768, Current, 2, 0, 24416);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_1_0_1_0_0_);
	tr1 = RTMS_EX_H("Select file",11,1098209125);
	F1206_10395(RTCW(loc1), tr1);
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp2 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp3 = tp2;
	ti4_1 = F1770_18573(Current);
	tp1 = inline_F220_3702(tp1, tp3, ti4_1);
	F1726_17949(Current, tp1);
	RTHOOK(3);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_11_6_0_1_0_0_);
	tr1 = RTLNS(eif_new_type(219, 0x00).id, 219, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tp2 = F220_3458(RTCW(tr1));
	ti4_1 = (EIF_INTEGER_32) GTK_RESPONSE_OK;
	loc2 = inline_F220_3686(tp1, tp2, ti4_1);
	RTHOOK(4);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_11_6_0_1_0_0_);
	tr1 = RTLNS(eif_new_type(219, 0x00).id, 219, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tp2 = F220_3468(RTCW(tr1));
	ti4_1 = (EIF_INTEGER_32) GTK_RESPONSE_CANCEL;
	loc2 = inline_F220_3686(tp1, tp2, ti4_1);
	RTHOOK(5);
	{
		static EIF_TYPE_INDEX typarr0[] = {1146,0xFFF9,2,1419,1499,1499,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1147_10111(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	RTHOOK(6);
	F1765_18517(Current);
	RTHOOK(7);
	F1687_17117(Current, (EIF_BOOLEAN) 0);
	RTHOOK(8);
	tr1 = RTMS32_EX_H("*\000\000\000.\000\000\000*\000\000\000",3,2764330);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	RTHOOK(9);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_11_6_0_1_0_0_);
	inline_F220_3707(tp1, (EIF_BOOLEAN) 1);
	RTHOOK(10);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_11_6_0_1_0_0_);
	ti4_1 = (EIF_INTEGER_32) GTK_RESPONSE_ACCEPT;
	inline_F220_3688(tp1, ti4_1);
	RTHOOK(11);
	F1765_18525(Current);
	RTHOOK(12);
	tr1 = F642_8804(RTCV(RTOSCF(17974,F1726_17974, (Current))));
	F1769_18558(Current, tr1);
	RTHOOK(13);
	F1687_17117(Current, (EIF_BOOLEAN) 1);
	RTHOOK(14);
	RTLE;
	RTEE;
}

/* {EV_FILE_DIALOG_IMP}.full_file_path */
EIF_REFERENCE F1769_18552 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("full_file_path", 1768, Current, 1, 0, 24417);
	RTGC;
	RTHOOK(1);
	if (F1765_18527(Current)) {
		RTHOOK(2);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_11_6_0_1_0_0_);
		loc1 = inline_F220_3704(tp1);
		RTHOOK(3);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(loc1 != tp1)) {
			RTHOOK(4);
			Result = RTLNS(eif_new_type(1385, 0x00).id, 1385, _OBJSIZ_2_1_0_0_0_0_0_0_);
			F1386_12836(RTCW(Result), loc1);
			RTHOOK(5);
			g_free((gpointer) loc1);
		} else {
			RTHOOK(6);
			Result = RTLNS(eif_new_type(1385, 0x00).id, 1385, _OBJSIZ_2_1_0_0_0_0_0_0_);
			F1386_12830(RTCW(Result));
			RTHOOK(7);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) Result;
		}
	} else {
		RTHOOK(8);
		Result = RTLNS(eif_new_type(1385, 0x00).id, 1385, _OBJSIZ_2_1_0_0_0_0_0_0_);
		F1386_12830(RTCW(Result));
		RTHOOK(9);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) Result;
	}
	RTHOOK(10);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_FILE_DIALOG_IMP}.filter */
EIF_REFERENCE F1769_18553 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_10_);
}


/* {EV_FILE_DIALOG_IMP}.start_path */
EIF_REFERENCE F1769_18555 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_9_);
}


/* {EV_FILE_DIALOG_IMP}.set_start_path */
void F1769_18558 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTEAA("set_start_path", 1768, Current, 1, 1, 24423);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	loc1 = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F1206_10390(RTCW(loc1), arg1);
	RTHOOK(3);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_11_6_0_1_0_0_);
	tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	gtk_file_chooser_set_current_folder((GtkFileChooser*) tp1, (gchar*) tp2);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_FILE_DIALOG_IMP}.on_ok */
void F1769_18559 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTEAA("on_ok", 1768, Current, 3, 0, 24424);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_11_6_0_1_0_0_);
	loc3 = inline_F220_3704(tp1);
	RTHOOK(2);
	tb1 = !loc3;
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(3);
		loc1 = RTLNS(eif_new_type(1385, 0x00).id, 1385, _OBJSIZ_2_1_0_0_0_0_0_0_);
		F1386_12836(RTCW(loc1), loc3);
		RTHOOK(4);
		loc2 = RTLNS(eif_new_type(1211, 0x00).id, 1211, _OBJSIZ_4_6_2_4_1_1_2_1_);
		F1211_10619(RTCW(loc2), loc1);
		RTHOOK(5);
		tb1 = '\01';
		tb2 = F1211_10653(RTCW(loc2));
		if (!(EIF_BOOLEAN) !tb2) {
			tb2 = F1211_10662(RTCW(loc2));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			RTHOOK(6);
			F1765_18531(Current);
		}
		RTHOOK(7);
		g_free((gpointer) loc3);
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EV_FILE_DIALOG_IMP}.remove_file_filters */
void F1769_18560 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("remove_file_filters", 1768, Current, 3, 0, 24425);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_11_6_0_1_0_0_);
	loc1 = (EIF_POINTER) gtk_file_chooser_list_filters((GtkFileChooser*) tp1);
	RTHOOK(2);
	tb1 = !loc1;
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(3);
		loc2 = (EIF_POINTER) g_slist_nth_data((GSList*) loc1, (guint) loc3);
		for (;;) {
			RTHOOK(4);
			tb1 = !loc2;
			if (tb1) break;
			RTHOOK(5);
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_11_6_0_1_0_0_);
			inline_F220_3694(tp1, loc2);
			RTHOOK(6);
			loc3++;
			RTHOOK(7);
			loc2 = (EIF_POINTER) g_slist_nth_data((GSList*) loc1, (guint) loc3);
		}
		RTHOOK(8);
		g_slist_free((GSList*) loc1);
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {EV_FILE_DIALOG_IMP}.show_modal_to_window */
void F1769_18561 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,loc3);
	RTLR(4,loc1);
	RTLR(5,loc5);
	RTLR(6,tr2);
	RTLR(7,arg1);
	RTLIU(8);
	
	RTEAA("show_modal_to_window", 1768, Current, 5, 1, 24426);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tb1 = F827_9290(RTCW(tr1));
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(2);
		F1769_18560(Current);
	}
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F1147_10142(RTCW(tr1));
	for (;;) {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tb1 = F940_9502(RTCW(tr1));
		if (tb1) break;
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr1 = F1147_10116(RTCW(tr1));
		loc2 = F1420_12922(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		loc2 = RTRV(eif_new_type(1499, 0x00), loc2);
		RTHOOK(6);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr1 = F1147_10116(RTCW(tr1));
		loc3 = F1420_12922(RTCW(tr1), ((EIF_INTEGER_32) 2L));
		loc3 = RTRV(eif_new_type(1499, 0x00), loc3);
		RTHOOK(7);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			RTHOOK(8);
			tr1 = F1500_14215(RTCW(loc2));
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ';';
			loc1 = F1500_14233(RTCW(tr1), tw1);
			RTHOOK(9);
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				RTHOOK(10);
				loc4 = (EIF_POINTER) gtk_file_filter_new();
				RTHOOK(11);
				loc5 = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_1_0_1_0_0_);
				F1206_10395(RTCW(loc5), loc3);
				RTHOOK(12);
				tp1 = *(EIF_POINTER *)(RTCW(loc5)+ _PTROFF_0_1_0_1_0_0_);
				inline_F220_3691(loc4, tp1);
				RTHOOK(13);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R7973[Dtype(RTCW(loc1))-989])(loc1);
				for (;;) {
					RTHOOK(14);
					tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7972[Dtype(RTCW(loc1))-989])(loc1);
					if (tb2) break;
					RTHOOK(15);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8007[Dtype(RTCW(loc1))-878])(loc1);
					tr2 = RTMS_EX_H("*.*",3,2764330);
					tb3 = F1500_14200(RTCW(tr1), tr2);
					if (tb3) {
						RTHOOK(16);
						loc5 = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_1_0_1_0_0_);
						tr1 = RTMS_EX_H("*",1,42);
						F1206_10395(RTCW(loc5), tr1);
					} else {
						RTHOOK(17);
						loc5 = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_1_0_1_0_0_);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8007[Dtype(RTCW(loc1))-878])(loc1);
						F1206_10395(RTCW(loc5), tr1);
					}
					RTHOOK(18);
					tp1 = *(EIF_POINTER *)(RTCW(loc5)+ _PTROFF_0_1_0_1_0_0_);
					inline_F220_3690(loc4, tp1);
					RTHOOK(19);
					(FUNCTION_CAST(void, (EIF_REFERENCE)) R7986[Dtype(RTCW(loc1))-989])(loc1);
				}
				RTHOOK(20);
				tp1 = *(EIF_POINTER *)(Current+ _PTROFF_11_6_0_1_0_0_);
				inline_F220_3693(tp1, loc4);
			}
		}
		RTHOOK(21);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		F1147_10144(RTCW(tr1));
	}
	RTHOOK(22);
	F1765_18520(Current, arg1);
	RTHOOK(23);
	RTLE;
	RTEE;
}

void EIF_Minit1046 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
