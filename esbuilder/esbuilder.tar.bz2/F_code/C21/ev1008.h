
#ifndef _C21_ev1008_
#define _C21_ev1008_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1731_18103(EIF_REFERENCE);
extern EIF_REFERENCE F1731_18104(EIF_REFERENCE);
extern void EIF_Minit1008(void);
extern char *(*R14565[])();
extern char *(*R14566[])();

#ifdef __cplusplus
}
#endif

#endif
