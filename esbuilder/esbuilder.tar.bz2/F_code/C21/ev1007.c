/*
 * Code for class EV_DOCKABLE_SOURCE_HINT_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1007.h"
#include <math.h>
#include <ev_gtk.h>
#include "eif_built_in.h"
#include "eif_helpers.h"
#include <cairo.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F219_3187
static EIF_POINTER inline_F219_3187 (void)
{
	return gdk_screen_get_default()
	;
}
#define INLINE_F219_3187
#endif
#ifndef INLINE_F219_3185
static EIF_POINTER inline_F219_3185 (EIF_POINTER arg1)
{
	return gdk_screen_get_rgba_visual ((GdkScreen*)arg1);
	;
}
#define INLINE_F219_3185
#endif
#ifndef INLINE_F219_3183
static int inline_F219_3183 (EIF_POINTER arg1)
{
	return gdk_screen_is_composited ((GdkScreen*)arg1);
	;
}
#define INLINE_F219_3183
#endif
#ifndef INLINE_F221_3734
static void inline_F221_3734 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_widget_set_visual ((GtkWidget *)arg1, (GdkVisual *)arg2)
	;
}
#define INLINE_F221_3734
#endif
#ifndef INLINE_F222_3761
static void inline_F222_3761 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	gtk_window_set_skip_taskbar_hint ((GtkWindow*) arg1, (gboolean) arg2);
	;
}
#define INLINE_F222_3761
#endif
#ifndef INLINE_F222_3809
static void inline_F222_3809 (EIF_POINTER arg1)
{
	gtk_widget_show_all ((GtkWidget *)arg1)
	;
}
#define INLINE_F222_3809
#endif
#ifndef INLINE_F219_3190
static EIF_POINTER inline_F219_3190 (void)
{
	return gdk_get_default_root_window();
	;
}
#define INLINE_F219_3190
#endif
#ifndef INLINE_F219_3166
static EIF_POINTER inline_F219_3166 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	return gdk_pixbuf_get_from_window ((GdkWindow *) arg1, (gint) arg2, (gint) arg3, (gint) arg4, (gint) arg5);
	;
}
#define INLINE_F219_3166
#endif
#ifndef INLINE_F219_3016
static void inline_F219_3016 (EIF_POINTER arg1)
{
	g_object_unref((gpointer) arg1)
	;
}
#define INLINE_F219_3016
#endif
#ifndef INLINE_F219_3076
static void inline_F219_3076 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4)
{
	return gdk_cairo_set_source_pixbuf ((cairo_t *) arg1, (const GdkPixbuf *) arg2, (gdouble) arg3, (gdouble) arg4);
	;
}
#define INLINE_F219_3076
#endif
#ifndef INLINE_F51_722
static void inline_F51_722 (EIF_POINTER arg1)
{
	cairo_paint ((cairo_t*)arg1)
	;
}
#define INLINE_F51_722
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.make */
void F1730_18064 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc4);
	RTLR(2,tr1);
	RTLR(3,loc5);
	RTLR(4,loc6);
	RTLR(5,loc7);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTEAA("make", 1729, Current, 7, 0, 23995);
	RTGC;
	RTHOOK(1);
	F1687_17117(Current, (EIF_BOOLEAN) 0);
	RTHOOK(2);
	ti4_1 = (EIF_INTEGER_32) GTK_WINDOW_POPUP;
	loc1 = (EIF_POINTER) gtk_window_new((GtkWindowType) ti4_1);
	RTHOOK(3);
	F1726_17949(Current, loc1);
	RTHOOK(4);
	loc4 = RTOSCF(17974,F1726_17974, (Current));
	RTHOOK(5);
	loc2 = inline_F219_3187();
	RTHOOK(6);
	loc3 = inline_F219_3185(loc2);
	RTHOOK(7);
	tb1 = '\0';
	tb2 = !loc3;
	if ((EIF_BOOLEAN) !tb2) {
		tb1 = EIF_TEST (inline_F219_3183(loc2));
	}
	if (tb1) {
		RTHOOK(8);
		inline_F221_3734(loc1, loc3);
	}
	RTHOOK(9);
	gtk_widget_set_app_paintable((GtkWidget*) loc1, (gboolean) (EIF_BOOLEAN) 1);
	RTHOOK(10);
	inline_F222_3761(loc1, (EIF_BOOLEAN) 1);
	RTHOOK(11);
	gtk_box_set_homogeneous((GtkBox*) loc1, (gboolean) (EIF_BOOLEAN) 1);
	RTHOOK(12);
	gtk_container_set_border_width((GtkContainer*) loc1, (guint) ((EIF_INTEGER_32) 0L));
	RTHOOK(13);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_43_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_0_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7993[Dtype(RTCW(tr1))-878])(tr1, (EIF_REFERENCE) &ti4_1);
	RTHOOK(14);
	loc5 = RTLNS(eif_new_type(1684, 0x00).id, 1684, _OBJSIZ_5_2_0_1_0_0_0_0_);
	F1345_12285(RTCW(loc5));
	RTHOOK(15);
	RTAR(Current, loc5);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) loc5;
	RTHOOK(16);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_3_);
	loc6 = tr1;
	loc6 = RTRV(eif_new_type(1919, 0x00),loc6);
	if (EIF_TEST(loc6)) {
		RTHOOK(17);
		tp1 = *(EIF_POINTER *)(loc6+ _PTROFF_48_19_10_9_0_0_);
		gtk_container_add((GtkContainer*) loc1, (GtkWidget*) tp1);
	}
	RTHOOK(18);
	inline_F222_3809(loc1);
	RTHOOK(19);
	F1687_17117(Current, (EIF_BOOLEAN) 1);
	RTHOOK(20);
	F1730_18065(Current);
	RTHOOK(21);
	tr2 = RTMS_EX_H("EV_PND_STYLE",12,2127107909);
	tr1 = RTLNS(eif_new_type(641, 0x00).id, 641, _OBJSIZ_0_0_0_1_0_0_0_0_);
	tr2 = F642_8808(RTCW(tr1), tr2);
	loc7 = tr2;
	if (EIF_TEST(loc7)) {
		RTHOOK(22);
		tr1 = RTMS_EX_H("-transparent",12,1378668404);
		tb1 = F1500_14199(loc7, tr1);
		if (tb1) {
			RTHOOK(23);
			F1730_18067(Current);
		}
		RTHOOK(24);
		tr1 = RTMS_EX_H("+screenshot",11,282083188);
		tb1 = F1500_14199(loc7, tr1);
		if (tb1) {
			RTHOOK(25);
			F1730_18068(Current);
		}
		RTHOOK(26);
		tr1 = RTMS_EX_H("+colors",7,35068275);
		tb1 = F1500_14199(loc7, tr1);
		if (tb1) {
			RTHOOK(27);
			F1730_18069(Current);
		}
		RTHOOK(28);
		tr1 = RTMS_EX_H("+blinking",9,944402279);
		tb1 = F1500_14199(loc7, tr1);
		if (tb1) {
			RTHOOK(29);
			F1730_18070(Current);
		}
		RTHOOK(30);
		if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_mac__b) {
			RTHOOK(31);
			tr1 = RTMS_EX_H("+transparent",12,2134684020);
			tb1 = F1500_14199(loc7, tr1);
			if ((EIF_BOOLEAN) !tb1) {
				RTHOOK(32);
				F1730_18067(Current);
			}
		}
	} else {
		RTHOOK(33);
		if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_mac__b) {
			RTHOOK(34);
			F1730_18067(Current);
		}
	}
	RTHOOK(35);
	RTLE;
	RTEE;
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.initialize_defaults */
void F1730_18065 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("initialize_defaults", 1729, Current, 0, 0, 23996);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_10_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 20L);
	RTHOOK(3);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 40L);
	RTHOOK(4);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.disable_transparency */
void F1730_18067 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("disable_transparency", 1729, Current, 0, 0, 23998);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_10_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(2);
	RTEE;
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.enable_screenshot_hack_enabled */
void F1730_18068 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("enable_screenshot_hack_enabled", 1729, Current, 0, 0, 23999);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_10_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	RTEE;
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.enable_colors */
void F1730_18069 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("enable_colors", 1729, Current, 0, 0, 24000);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_10_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	RTEE;
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.enable_blinking */
void F1730_18070 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("enable_blinking", 1729, Current, 0, 0, 24001);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_10_7_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	RTEE;
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.set_size */
void F1730_18083 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("set_size", 1729, Current, 0, 2, 24014);
	RTGC;
	RTHOOK(1);
	F1729_18035(Current, arg1, arg2);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1575_15202(RTCW(tr1), arg1, arg2);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.get_pixbuf */
void F1730_18084 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("get_pixbuf", 1729, Current, 4, 0, 24015);
	RTGC;
	RTHOOK(1);
	loc3 = RTLNSMART(eif_new_type(1254, 0).id);
	ti4_1 = F1729_18044(Current);
	ti4_2 = F1729_18046(Current);
	ti4_3 = F1729_18036(Current);
	ti4_4 = F1729_18037(Current);
	F1255_11751(RTCW(loc3), ti4_1, ti4_2, ti4_3, ti4_4);
	RTHOOK(2);
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	RTHOOK(3);
	if ((EIF_BOOLEAN)(loc2 == NULL)) {
		RTHOOK(4);
		tr1 = RTLNSMART(eif_new_type(1254, 0).id);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_0_);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_2_);
		ti4_1 = eif_max_int32 ((EIF_INTEGER_32) (ti4_1 - ti4_2),((EIF_INTEGER_32) 1L));
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_1_);
		ti4_3 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_3_);
		ti4_2 = eif_max_int32 ((EIF_INTEGER_32) (ti4_2 - ti4_3),((EIF_INTEGER_32) 1L));
		ti4_3 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_2_);
		ti4_4 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_3_);
		F1255_11751(RTCW(tr1), ti4_1, ti4_2, (EIF_INTEGER_32) (((EIF_INTEGER_32) 3L) * ti4_3), (EIF_INTEGER_32) (((EIF_INTEGER_32) 3L) * ti4_4));
		loc3 = (EIF_REFERENCE) tr1;
	}
	RTHOOK(5);
	tb1 = '\01';
	if (!(EIF_BOOLEAN)(loc2 == NULL)) {
		tb2 = F1255_11768(RTCW(loc2), loc3);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(6);
		F1730_18085(Current);
		RTHOOK(7);
		loc1 = inline_F219_3190();
		RTHOOK(8);
		tb1 = !loc1;
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(9);
			loc4 = F1728_18020(Current);
			RTHOOK(10);
			if (loc4) {
				RTHOOK(11);
				F1729_18050(Current);
			}
			RTHOOK(12);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_0_);
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_1_);
			ti4_3 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_2_);
			ti4_4 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_3_);
			tp1 = inline_F219_3166(loc1, ti4_1, ti4_2, ti4_3, ti4_4);
			*(EIF_POINTER *)(Current+ _PTROFF_10_10_0_9_0_2_) = (EIF_POINTER) tp1;
			RTHOOK(13);
			if (loc4) {
				RTHOOK(14);
				F1729_18049(Current);
			}
			RTHOOK(15);
			RTAR(Current, loc3);
			*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) loc3;
		}
	}
	RTHOOK(16);
	RTLE;
	RTEE;
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.discard_pixbuf */
void F1730_18085 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("discard_pixbuf", 1729, Current, 0, 0, 24016);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_10_10_0_9_0_2_);
	tb1 = !tp1;
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(2);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_10_10_0_9_0_2_);
		inline_F219_3016(tp1);
		RTHOOK(3);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current+ _PTROFF_10_10_0_9_0_2_) = (EIF_POINTER) tp2;
		RTHOOK(4);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) NULL;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.update */
void F1730_18086 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REAL_64 loc7 = (EIF_REAL_64) 0;
	EIF_REAL_64 loc8 = (EIF_REAL_64) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc10 = (EIF_POINTER) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc13);
	RTLR(1,Current);
	RTLR(2,loc11);
	RTLR(3,loc12);
	RTLR(4,arg1);
	RTLR(5,loc14);
	RTLR(6,tr1);
	RTLR(7,loc15);
	RTLR(8,loc16);
	RTLR(9,loc17);
	RTLIU(10);
	
	RTEAA("update", 1729, Current, 17, 5, 24017);
	RTGC;
	RTHOOK(1);
	loc13 = RTOSCF(17974,F1726_17974, (Current));
	RTHOOK(2);
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_4_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_10_5_))) {
		RTHOOK(3);
		loc9 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_1_);
	} else {
		RTHOOK(4);
		loc9 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_1_);
		loc9 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc9 / ((EIF_INTEGER_32) 2L));
	}
	RTHOOK(5);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_3_)) += *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_4_);
	RTHOOK(6);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_4_) > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(7);
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_3_) >= loc9)) {
			RTHOOK(8);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_4_) = (EIF_INTEGER_32) (EIF_INTEGER_32) -*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_4_);
		}
	} else {
		RTHOOK(9);
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_3_) <= ((EIF_INTEGER_32) 1L))) {
			RTHOOK(10);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_4_) = (EIF_INTEGER_32) (EIF_INTEGER_32) -*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_4_);
		}
	}
	RTHOOK(11);
	loc11 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	RTHOOK(12);
	if ((EIF_BOOLEAN)(loc11 == NULL)) {
		RTHOOK(13);
		loc11 = F626_8304(RTCV(RTOSCF(18091,F1730_18091, (Current))));
	}
	RTHOOK(14);
	loc12 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	RTHOOK(15);
	if ((EIF_BOOLEAN)(loc12 == NULL)) {
		RTHOOK(16);
		loc12 = F626_8303(RTCV(RTOSCF(18091,F1730_18091, (Current))));
	}
	RTHOOK(17);
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_4_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_10_5_))) {
		RTHOOK(18);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc13)+ _LNGOFF_49_16_0_7_);
		ti4_2 = F1729_18036(Current);
		ti4_3 = *(EIF_INTEGER_32 *)(RTCW(loc13)+ _LNGOFF_49_16_0_8_);
		ti4_4 = F1729_18037(Current);
		F1729_18040(Current, (EIF_INTEGER_32) (ti4_1 - (EIF_INTEGER_32) (ti4_2 / ((EIF_INTEGER_32) 2L))), (EIF_INTEGER_32) (ti4_3 - (EIF_INTEGER_32) (ti4_4 / ((EIF_INTEGER_32) 2L))));
		RTHOOK(19);
		F1372_12605(RTCW(arg1));
		RTHOOK(20);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
		loc14 = tr1;
		loc14 = RTRV(eif_new_type(1919, 0x00),loc14);
		if (EIF_TEST(loc14)) {
			RTHOOK(21);
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_4_)) {
				RTHOOK(22);
				F1920_21095(loc14, (EIF_REAL_64) 0.0);
			}
			RTHOOK(23);
			loc10 = *(EIF_POINTER *)(loc14+ _PTROFF_48_19_10_9_0_1_);
		}
		RTHOOK(24);
		F1372_12607(RTCW(arg1));
		RTHOOK(25);
		tb1 = '\0';
		tb2 = '\0';
		tb3 = '\0';
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_5_)) {
			tb4 = !loc10;
			tb3 = (EIF_BOOLEAN) !tb4;
		}
		if (tb3) {
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_10_10_0_9_0_2_);
			tb3 = !tp1;
			tb2 = (EIF_BOOLEAN) !tb3;
		}
		if (tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			loc15 = tr1;
			tb1 = EIF_TEST(loc15);
		}
		if (tb1) {
			RTHOOK(26);
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_10_10_0_9_0_2_);
			ti4_1 = *(EIF_INTEGER_32 *)(loc15+ _LNGOFF_0_0_0_0_);
			tr8_1 = (EIF_REAL_64) ((EIF_INTEGER_32) -(EIF_INTEGER_32) (F1729_18044(Current) - ti4_1));
			ti4_1 = *(EIF_INTEGER_32 *)(loc15+ _LNGOFF_0_0_0_1_);
			tr8_2 = (EIF_REAL_64) ((EIF_INTEGER_32) -(EIF_INTEGER_32) (F1729_18046(Current) - ti4_1));
			inline_F219_3076(loc10, tp1, tr8_1, tr8_2);
			RTHOOK(27);
			inline_F51_722(loc10);
		}
		RTHOOK(28);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_3_);
		loc7 = (EIF_REAL_64) (ti4_1);
		tr8_1 = (EIF_REAL_64) (loc9);
		loc7 = (EIF_REAL_64) (EIF_REAL_64) ((EIF_REAL_64) 0.7 - (EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) 0.4 * loc7)) /  (EIF_REAL_64) (tr8_1)));
		RTHOOK(29);
		F1372_12595(RTCW(arg1), ((EIF_INTEGER_32) 3L));
		RTHOOK(30);
		ti4_1 = F1372_12587(RTCW(arg1));
		tr8_1 = (EIF_REAL_64) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * ti4_1));
		ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) (arg4) /  (EIF_REAL_64) (((EIF_INTEGER_32) 3L))) + (EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * arg4)) /  (EIF_REAL_64) (((EIF_INTEGER_32) 3L))) * (EIF_REAL_64) ((EIF_REAL_64) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_3_)) /  (EIF_REAL_64) (loc9)))) - tr8_1);
		loc1 = eif_max_int32 (ti4_1,((EIF_INTEGER_32) 1L));
		RTHOOK(31);
		ti4_1 = F1372_12587(RTCW(arg1));
		tr8_1 = (EIF_REAL_64) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * ti4_1));
		ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) (arg5) /  (EIF_REAL_64) (((EIF_INTEGER_32) 3L))) + (EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * arg5)) /  (EIF_REAL_64) (((EIF_INTEGER_32) 3L))) * (EIF_REAL_64) ((EIF_REAL_64) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_3_)) /  (EIF_REAL_64) (loc9)))) - tr8_1);
		loc2 = eif_max_int32 (ti4_1,((EIF_INTEGER_32) 1L));
		RTHOOK(32);
		loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 1L) + (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg4 - loc1) / ((EIF_INTEGER_32) 2L)));
		RTHOOK(33);
		loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 1L) + (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg5 - loc2) / ((EIF_INTEGER_32) 2L)));
		RTHOOK(34);
		tb1 = '\0';
		ti4_1 = F1372_12587(RTCW(arg1));
		if ((EIF_BOOLEAN) (loc1 > (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * ti4_1))) {
			ti4_1 = F1372_12587(RTCW(arg1));
			tb1 = (EIF_BOOLEAN) (loc2 > (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * ti4_1));
		}
		if (tb1) {
			RTHOOK(35);
			F1360_12513(RTCW(arg1), loc12);
			RTHOOK(36);
			tb1 = !loc10;
			if ((EIF_BOOLEAN) !tb1) {
				RTHOOK(37);
				tr4_1 = F1385_12791(RTCW(loc12));
				tr8_1 = (EIF_REAL_64) (tr4_1);
				tr4_1 = F1385_12792(RTCW(loc12));
				tr8_2 = (EIF_REAL_64) (tr4_1);
				tr4_1 = F1385_12793(RTCW(loc12));
				tr8_3 = (EIF_REAL_64) (tr4_1);
				cairo_set_source_rgba((cairo_t*) loc10, (double) tr8_1, (double) tr8_2, (double) tr8_3, (double) loc7);
			}
			RTHOOK(38);
			ti4_1 = F1372_12587(RTCW(arg1));
			ti4_2 = F1372_12587(RTCW(arg1));
			ti4_3 = F1372_12587(RTCW(arg1));
			ti4_4 = F1372_12587(RTCW(arg1));
			F1372_12622(RTCW(arg1), (EIF_INTEGER_32) (loc5 + ti4_1), (EIF_INTEGER_32) (loc6 + ti4_2), (EIF_INTEGER_32) (loc1 - (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * ti4_3)), (EIF_INTEGER_32) (loc2 - (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * ti4_4)));
		}
		RTHOOK(39);
		tb1 = !loc10;
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(40);
			tr4_1 = F1385_12791(RTCW(loc11));
			tr8_1 = (EIF_REAL_64) (tr4_1);
			tr4_1 = F1385_12792(RTCW(loc11));
			tr8_2 = (EIF_REAL_64) (tr4_1);
			tr4_1 = F1385_12793(RTCW(loc11));
			tr8_3 = (EIF_REAL_64) (tr4_1);
			cairo_set_source_rgba((cairo_t*) loc10, (double) tr8_1, (double) tr8_2, (double) tr8_3, (double) loc7);
		} else {
			RTHOOK(41);
			F1360_12513(RTCW(arg1), loc11);
		}
		RTHOOK(42);
		F1372_12622(RTCW(arg1), loc5, loc6, loc1, loc2);
		RTHOOK(43);
		F1372_12595(RTCW(arg1), ((EIF_INTEGER_32) 2L));
		RTHOOK(44);
		ti4_1 = F1372_12587(RTCW(arg1));
		tr8_1 = (EIF_REAL_64) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * ti4_1));
		ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) (arg4) /  (EIF_REAL_64) (((EIF_INTEGER_32) 2L))) - (EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) (arg4) /  (EIF_REAL_64) (((EIF_INTEGER_32) 2L))) * (EIF_REAL_64) ((EIF_REAL_64) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_3_)) /  (EIF_REAL_64) (loc9)))) - tr8_1);
		loc1 = eif_max_int32 (ti4_1,((EIF_INTEGER_32) 1L));
		RTHOOK(45);
		ti4_1 = F1372_12587(RTCW(arg1));
		tr8_1 = (EIF_REAL_64) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * ti4_1));
		ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) (arg5) /  (EIF_REAL_64) (((EIF_INTEGER_32) 2L))) - (EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) (arg5) /  (EIF_REAL_64) (((EIF_INTEGER_32) 2L))) * (EIF_REAL_64) ((EIF_REAL_64) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_3_)) /  (EIF_REAL_64) (loc9)))) - tr8_1);
		loc2 = eif_max_int32 (ti4_1,((EIF_INTEGER_32) 1L));
		RTHOOK(46);
		loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 1L) + (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg4 - loc1) / ((EIF_INTEGER_32) 2L)));
		RTHOOK(47);
		loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 1L) + (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg5 - loc2) / ((EIF_INTEGER_32) 2L)));
		RTHOOK(48);
		loc3 = *(EIF_INTEGER_32 *)(RTCW(loc13)+ _LNGOFF_49_16_0_9_);
		RTHOOK(49);
		loc4 = *(EIF_INTEGER_32 *)(RTCW(loc13)+ _LNGOFF_49_16_0_10_);
		RTHOOK(50);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_5_);
		ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_6_);
		loc8 = (EIF_REAL_64) atan((double) (EIF_REAL_64) ((EIF_REAL_64) ((EIF_INTEGER_32) (loc3 - ti4_1)) /  (EIF_REAL_64) ((EIF_INTEGER_32) (loc4 - ti4_2))));
		RTHOOK(51);
		if ((EIF_BOOLEAN) (loc3 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_5_))) {
			RTHOOK(52);
			if ((EIF_BOOLEAN) (loc4 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_6_))) {
				RTHOOK(53);
				tr8_1 = (EIF_REAL_64) (loc5);
				tr8_2 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg4 / ((EIF_INTEGER_32) 4L)));
				ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) (tr8_1 + (EIF_REAL_64) ((EIF_REAL_64) sin((double) loc8) * tr8_2));
				loc5 = (EIF_INTEGER_32) ti4_1;
				RTHOOK(54);
				tr8_1 = (EIF_REAL_64) (loc6);
				tr8_2 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg5 / ((EIF_INTEGER_32) 4L)));
				ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) (tr8_1 + (EIF_REAL_64) ((EIF_REAL_64) cos((double) loc8) * tr8_2));
				loc6 = (EIF_INTEGER_32) ti4_1;
			} else {
				RTHOOK(55);
				tr8_1 = (EIF_REAL_64) (loc5);
				tr8_2 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg4 / ((EIF_INTEGER_32) 4L)));
				ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) (tr8_1 - (EIF_REAL_64) ((EIF_REAL_64) sin((double) loc8) * tr8_2));
				loc5 = (EIF_INTEGER_32) ti4_1;
				RTHOOK(56);
				tr8_1 = (EIF_REAL_64) (loc6);
				tr8_2 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg5 / ((EIF_INTEGER_32) 4L)));
				ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) (tr8_1 - (EIF_REAL_64) ((EIF_REAL_64) cos((double) loc8) * tr8_2));
				loc6 = (EIF_INTEGER_32) ti4_1;
			}
		} else {
			RTHOOK(57);
			if ((EIF_BOOLEAN) (loc4 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_6_))) {
				RTHOOK(58);
				tr8_1 = (EIF_REAL_64) (loc5);
				tr8_2 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg4 / ((EIF_INTEGER_32) 4L)));
				ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) (tr8_1 + (EIF_REAL_64) ((EIF_REAL_64) sin((double) loc8) * tr8_2));
				loc5 = (EIF_INTEGER_32) ti4_1;
				RTHOOK(59);
				tr8_1 = (EIF_REAL_64) (loc6);
				tr8_2 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg5 / ((EIF_INTEGER_32) 4L)));
				ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) (tr8_1 + (EIF_REAL_64) ((EIF_REAL_64) cos((double) loc8) * tr8_2));
				loc6 = (EIF_INTEGER_32) ti4_1;
			} else {
				RTHOOK(60);
				tr8_1 = (EIF_REAL_64) (loc5);
				tr8_2 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg4 / ((EIF_INTEGER_32) 4L)));
				ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) (tr8_1 - (EIF_REAL_64) ((EIF_REAL_64) sin((double) loc8) * tr8_2));
				loc5 = (EIF_INTEGER_32) ti4_1;
				RTHOOK(61);
				tr8_1 = (EIF_REAL_64) (loc6);
				tr8_2 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg5 / ((EIF_INTEGER_32) 4L)));
				ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) (tr8_1 - (EIF_REAL_64) ((EIF_REAL_64) cos((double) loc8) * tr8_2));
				loc6 = (EIF_INTEGER_32) ti4_1;
			}
		}
		RTHOOK(62);
		tb1 = '\0';
		ti4_1 = F1372_12587(RTCW(arg1));
		if ((EIF_BOOLEAN) (loc1 < (EIF_INTEGER_32) (arg4 - (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * ti4_1)))) {
			ti4_1 = F1372_12587(RTCW(arg1));
			tb1 = (EIF_BOOLEAN) (loc2 < (EIF_INTEGER_32) (arg5 - (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * ti4_1)));
		}
		if (tb1) {
			RTHOOK(63);
			F1360_12513(RTCW(arg1), loc12);
			RTHOOK(64);
			tb1 = !loc10;
			if ((EIF_BOOLEAN) !tb1) {
				RTHOOK(65);
				tr4_1 = F1385_12791(RTCW(loc12));
				tr8_1 = (EIF_REAL_64) (tr4_1);
				tr4_1 = F1385_12792(RTCW(loc12));
				tr8_2 = (EIF_REAL_64) (tr4_1);
				tr4_1 = F1385_12793(RTCW(loc12));
				tr8_3 = (EIF_REAL_64) (tr4_1);
				cairo_set_source_rgba((cairo_t*) loc10, (double) tr8_1, (double) tr8_2, (double) tr8_3, (double) loc7);
			}
			RTHOOK(66);
			ti4_1 = F1372_12587(RTCW(arg1));
			ti4_2 = F1372_12587(RTCW(arg1));
			ti4_3 = F1372_12587(RTCW(arg1));
			ti4_4 = F1372_12587(RTCW(arg1));
			F1372_12622(RTCW(arg1), (EIF_INTEGER_32) (loc5 - ti4_1), (EIF_INTEGER_32) (loc6 - ti4_2), (EIF_INTEGER_32) (loc1 + (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * ti4_3)), (EIF_INTEGER_32) (loc2 + (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * ti4_4)));
		}
		RTHOOK(67);
		tb1 = !loc10;
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(68);
			tr4_1 = F1385_12791(RTCW(loc11));
			tr8_1 = (EIF_REAL_64) (tr4_1);
			tr4_1 = F1385_12792(RTCW(loc11));
			tr8_2 = (EIF_REAL_64) (tr4_1);
			tr4_1 = F1385_12793(RTCW(loc11));
			tr8_3 = (EIF_REAL_64) (tr4_1);
			cairo_set_source_rgba((cairo_t*) loc10, (double) tr8_1, (double) tr8_2, (double) tr8_3, (double) loc7);
		} else {
			RTHOOK(69);
			F1360_12513(RTCW(arg1), loc11);
		}
		RTHOOK(70);
		F1372_12626(RTCW(arg1), loc5, loc6, loc1, loc2);
		RTHOOK(71);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
		loc16 = tr1;
		loc16 = RTRV(eif_new_type(1919, 0x00),loc16);
		if (EIF_TEST(loc16)) {
			RTHOOK(72);
			tb1 = *(EIF_BOOLEAN *)(loc16+ _CHROFF_48_12_);
			if (tb1) {
				RTHOOK(73);
				F1920_21096(loc16);
			}
		}
		RTHOOK(74);
		F1372_12606(RTCW(arg1));
	} else {
		RTHOOK(75);
		if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_7_) && (EIF_BOOLEAN)((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_3_) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L)))) {
			RTHOOK(76);
			F1729_18050(Current);
		} else {
			RTHOOK(77);
			F1729_18049(Current);
		}
		RTHOOK(78);
		loc1 = F1729_18036(Current);
		RTHOOK(79);
		loc2 = F1729_18037(Current);
		RTHOOK(80);
		F1372_12605(RTCW(arg1));
		RTHOOK(81);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
		loc17 = tr1;
		loc17 = RTRV(eif_new_type(1919, 0x00),loc17);
		if (EIF_TEST(loc17)) {
			RTHOOK(82);
			loc10 = *(EIF_POINTER *)(loc17+ _PTROFF_48_19_10_9_0_1_);
		}
		RTHOOK(83);
		F1360_12514(RTCW(arg1), loc12);
		RTHOOK(84);
		F1372_12607(RTCW(arg1));
		RTHOOK(85);
		tb1 = !loc10;
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(86);
			loc7 = (EIF_REAL_64) (((EIF_INTEGER_32) 1L));
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_3_);
			loc7 = (EIF_REAL_64) (EIF_REAL_64) (loc7 - (EIF_REAL_64) ((EIF_REAL_64) (ti4_1) /  (EIF_REAL_64) (loc9)));
			RTHOOK(87);
			tr4_1 = F1385_12791(RTCW(loc11));
			tr8_1 = (EIF_REAL_64) (tr4_1);
			tr4_1 = F1385_12792(RTCW(loc11));
			tr8_2 = (EIF_REAL_64) (tr4_1);
			tr4_1 = F1385_12793(RTCW(loc11));
			tr8_3 = (EIF_REAL_64) (tr4_1);
			cairo_set_source_rgba((cairo_t*) loc10, (double) tr8_1, (double) tr8_2, (double) tr8_3, (double) loc7);
			RTHOOK(88);
			ti4_1 = F1729_18036(Current);
			ti4_2 = F1729_18037(Current);
			F1372_12625(RTCW(arg1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ti4_1, ti4_2);
		}
		RTHOOK(89);
		ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) ((EIF_REAL_64) ((EIF_INTEGER_32) (loc1 * *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_3_))) /  (EIF_REAL_64) (loc9));
		loc1 = (EIF_INTEGER_32) ti4_1;
		RTHOOK(90);
		ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) ((EIF_REAL_64) ((EIF_INTEGER_32) (loc2 * *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_3_))) /  (EIF_REAL_64) (loc9));
		loc2 = (EIF_INTEGER_32) ti4_1;
		RTHOOK(91);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 2L)) && (EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 2L)))) {
			RTHOOK(92);
			F1372_12595(RTCW(arg1), ((EIF_INTEGER_32) 1L));
			RTHOOK(93);
			tb1 = !loc10;
			if ((EIF_BOOLEAN) !tb1) {
				RTHOOK(94);
				tr4_1 = F1385_12791(RTCW(loc11));
				tr8_1 = (EIF_REAL_64) (tr4_1);
				tr4_1 = F1385_12792(RTCW(loc11));
				tr8_2 = (EIF_REAL_64) (tr4_1);
				tr4_1 = F1385_12793(RTCW(loc11));
				tr8_3 = (EIF_REAL_64) (tr4_1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_3_);
				cairo_set_source_rgba((cairo_t*) loc10, (double) tr8_1, (double) tr8_2, (double) tr8_3, (double) (EIF_REAL_64) ((EIF_REAL_64) (ti4_1) /  (EIF_REAL_64) (loc9)));
			} else {
				RTHOOK(95);
				F1360_12513(RTCW(arg1), loc11);
			}
			RTHOOK(96);
			ti4_1 = F1729_18036(Current);
			ti4_2 = F1729_18037(Current);
			F1372_12626(RTCW(arg1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - loc1) / ((EIF_INTEGER_32) 2L)), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_2 - loc2) / ((EIF_INTEGER_32) 2L)), loc1, loc2);
		}
		RTHOOK(97);
		F1372_12606(RTCW(arg1));
		RTHOOK(98);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc13)+ _LNGOFF_49_16_0_7_);
		ti4_2 = F1729_18036(Current);
		ti4_3 = *(EIF_INTEGER_32 *)(RTCW(loc13)+ _LNGOFF_49_16_0_8_);
		ti4_4 = F1729_18037(Current);
		F1729_18040(Current, (EIF_INTEGER_32) (ti4_1 - (EIF_INTEGER_32) (ti4_2 / ((EIF_INTEGER_32) 2L))), (EIF_INTEGER_32) (ti4_3 - (EIF_INTEGER_32) (ti4_4 / ((EIF_INTEGER_32) 2L))));
	}
	RTHOOK(99);
	RTLE;
	RTEE;
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.on_timeout */
void F1730_18087 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("on_timeout", 1729, Current, 1, 0, 24018);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		ti4_1 = F1362_12530(loc1);
		ti4_2 = F1362_12531(loc1);
		F1730_18086(Current, loc1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 1L), ti4_1, ti4_2);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.user_can_resize */
EIF_BOOLEAN F1730_18088 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("user_can_resize", 1729, Current, 0, 0, 24019);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) 0;
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.on_key_event */
void F1730_18089 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("on_key_event", 1729, Current, 0, 3, 24020);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.call_close_request_actions */
void F1730_18090 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("call_close_request_actions", 1729, Current, 0, 0, 24021);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.colors */
static EIF_REFERENCE F1730_18091_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("colors", 1729, Current, 0, 0, 24022);
	RTGC;
	RTOSP (18091);
#define Result RTOSR(18091)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(625, 0x00).id, 625, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) RTCCL(tr1);
	RTOSE (18091);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1730_18091 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(18091,F1730_18091_body,(Current));
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.is_activated */
EIF_BOOLEAN F1730_18092 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_10_8_);
}


/* {EV_DOCKABLE_SOURCE_HINT_IMP}.activate */
void F1730_18100 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_REFERENCE arg5)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,arg5);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc1);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLIU(8);
	
	RTEAA("activate", 1729, Current, 3, 5, 24031);
	RTGC;
	RTHOOK(1);
	loc2 = arg5;
	loc2 = RTRV(eif_new_type(1359, 0x00),loc2);
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_6_) && EIF_TEST(loc2))) {
		RTHOOK(2);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10350[Dtype(loc2)-1372])(loc2);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
		RTHOOK(3);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10351[Dtype(loc2)-1372])(loc2);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
		RTHOOK(4);
		if ((EIF_BOOLEAN) (RTEQ(*(EIF_REFERENCE *)(Current + _REFACS_8_), *(EIF_REFERENCE *)(Current + _REFACS_9_)) || (EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_8_) == NULL) || (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_9_) == NULL)))) {
			RTHOOK(5);
			*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) NULL;
			RTHOOK(6);
			*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) NULL;
		}
	}
	RTHOOK(7);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_10_8_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(8);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(9);
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_4_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_10_5_))) {
		RTHOOK(10);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_7_) = (EIF_INTEGER_32) arg3;
		RTHOOK(11);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_8_) = (EIF_INTEGER_32) arg4;
	} else {
		RTHOOK(12);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_7_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg3 / ((EIF_INTEGER_32) 3L));
		RTHOOK(13);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_8_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg4 / ((EIF_INTEGER_32) 3L));
	}
	RTHOOK(14);
	F1730_18083(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_7_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_8_));
	RTHOOK(15);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_10_7_)) {
		RTHOOK(16);
		F1729_18049(Current);
	}
	RTHOOK(17);
	tr1 = RTOSCF(17974,F1726_17974, (Current));
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTHOOK(18);
		ti4_1 = *(EIF_INTEGER_32 *)(loc3+ _LNGOFF_49_16_0_7_);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_5_) = (EIF_INTEGER_32) ti4_1;
		RTHOOK(19);
		ti4_1 = *(EIF_INTEGER_32 *)(loc3+ _LNGOFF_49_16_0_8_);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_6_) = (EIF_INTEGER_32) ti4_1;
	} else {
		RTHOOK(20);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_5_) = (EIF_INTEGER_32) arg1;
		RTHOOK(21);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_6_) = (EIF_INTEGER_32) arg2;
	}
	RTHOOK(22);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_5_);
	ti4_2 = F1729_18036(Current);
	ti4_3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_6_);
	ti4_4 = F1729_18037(Current);
	F1729_18040(Current, (EIF_INTEGER_32) (ti4_1 - (EIF_INTEGER_32) (ti4_2 / ((EIF_INTEGER_32) 2L))), (EIF_INTEGER_32) (ti4_3 - (EIF_INTEGER_32) (ti4_4 / ((EIF_INTEGER_32) 2L))));
	RTHOOK(23);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_5_)) {
		RTHOOK(24);
		F1730_18084(Current);
	}
	RTHOOK(25);
	loc1 = RTLNSMART(eif_new_type(1350, 0).id);
	F1345_12285(RTCW(loc1));
	RTHOOK(26);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) loc1;
	RTHOOK(27);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_2_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1493,0xFFF9,0,1419,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A1007_447, (EIF_POINTER) _A1007_447, (EIF_POINTER)(F1730_18087),tr2, 1, 0);
	}
	F1169_10217(RTCW(tr1), tr3);
	RTHOOK(28);
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_4_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_10_5_))) {
		RTHOOK(29);
		F1351_12396(RTCW(loc1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_2_));
	} else {
		RTHOOK(30);
		F1351_12396(RTCW(loc1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_2_) * ((EIF_INTEGER_32) 2L)));
	}
	RTHOOK(31);
	RTLE;
	RTEE;
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.deactivate */
void F1730_18101 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("deactivate", 1729, Current, 1, 0, 24032);
	RTGC;
	RTHOOK(1);
	F1729_18050(Current);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		F1345_12288(loc1);
		RTHOOK(4);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) loc1;
	}
	RTHOOK(5);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_5_)) {
		RTHOOK(6);
		F1730_18085(Current);
	}
	RTHOOK(7);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) NULL;
	RTHOOK(8);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) NULL;
	RTHOOK(9);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_10_8_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(10);
	RTLE;
	RTEE;
}

void EIF_Minit1007 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
