/*
 * Code for class EV_STANDARD_DIALOG_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1042.h"
#include <ev_gtk.h>
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_STANDARD_DIALOG_IMP}.make */
void F1765_18517 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,tr5);
	RTLIU(6);
	
	RTEAA("make", 1764, Current, 0, 0, 24382);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
	tr1 = RTOSCF(892,F68_892, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1419,1239,1491,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCV(RTOSCF(17974,F1726_17974, (Current))) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	tp2 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
	((EIF_TYPED_VALUE *)tr2+2)->it_p = tp2;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1497,0xFFF9,1,1419,1491,1491,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A655_339_3, (EIF_POINTER) _A655_339_3, (EIF_POINTER)(F1220_11184),tr2, 1, 1);
	}
	F1726_17953(Current, tp1, tr1, tr5);
	RTHOOK(2);
	F1728_17991(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_STANDARD_DIALOG_IMP}.selected_button */
EIF_REFERENCE F1765_18519 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O14897[Dtype(Current)-1764]);
}


/* {EV_STANDARD_DIALOG_IMP}.show_modal_to_window */
void F1765_18520 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("show_modal_to_window", 1764, Current, 0, 1, 24385);
	RTGC;
	RTHOOK(1);
	*(EIF_REFERENCE *)(Current + O14897[Dtype(Current)-1764]) = (EIF_REFERENCE) NULL;
	RTHOOK(2);
	F1729_18053(Current, arg1);
	RTHOOK(3);
	if (F1765_18527(Current)) {
		RTHOOK(4);
		tr1 = F166_2282(Current);
		F1177_10288(RTCW(tr1), NULL);
	} else {
		RTHOOK(5);
		tr1 = F166_2284(Current);
		F1177_10288(RTCW(tr1), NULL);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_STANDARD_DIALOG_IMP}.set_title */
void F1765_18521 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("set_title", 1764, Current, 1, 1, 24386);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F1206_10395(RTCW(loc1), arg1);
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current + O14438[Dtype(Current)-1725]);
	tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	gtk_window_set_title((GtkWindow*) tp1, (gchar*) tp2);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_STANDARD_DIALOG_IMP}.on_key_event */
void F1765_18522 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("on_key_event", 1764, Current, 0, 3, 24387);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {EV_STANDARD_DIALOG_IMP}.user_can_resize */
EIF_BOOLEAN F1765_18523 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_FALSE;
}

/* {EV_STANDARD_DIALOG_IMP}.blocking_condition */
EIF_BOOLEAN F1765_18524 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("blocking_condition", 1764, Current, 0, 0, 24389);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	tb1 = '\01';
	if (!F1687_17102(Current)) {
		tb1 = (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O14897[Dtype(Current)-1764]) != NULL);
	}
	if (!tb1) {
		tb1 = F1687_17102(RTCV(RTOSCF(17974,F1726_17974, (Current))));
		Result = tb1;
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_STANDARD_DIALOG_IMP}.enable_closeable */
void F1765_18525 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("enable_closeable", 1764, Current, 1, 0, 24390);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) GDK_FUNC_CLOSE;
	RTHOOK(2);
	ti4_1 = (EIF_INTEGER_32) GDK_FUNC_MOVE;
	ti4_1 = eif_bit_or(loc1,ti4_1);
	loc1 = (EIF_INTEGER_32) ti4_1;
	RTHOOK(3);
	ti4_1 = (EIF_INTEGER_32) GDK_FUNC_RESIZE;
	ti4_1 = eif_bit_or(loc1,ti4_1);
	loc1 = (EIF_INTEGER_32) ti4_1;
	RTHOOK(4);
	tp1 = *(EIF_POINTER *)(Current + O14438[Dtype(Current)-1725]);
	tp1 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
	gdk_window_set_functions((GdkWindow*) tp1, (GdkWMFunction) loc1);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_STANDARD_DIALOG_IMP}.call_close_request_actions */
void F1765_18526 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("call_close_request_actions", 1764, Current, 0, 0, 24391);
	RTHOOK(1);
	F1765_18532(Current);
	RTHOOK(2);
	RTEE;
}

/* {EV_STANDARD_DIALOG_IMP}.user_clicked_ok */
EIF_BOOLEAN F1765_18527 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("user_clicked_ok", 1764, Current, 0, 0, 24392);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O14897[dtype-1764]);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14869[dtype-1765])(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 == tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_STANDARD_DIALOG_IMP}.on_response */
void F1765_18530 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("on_response", 1764, Current, 0, 1, 24395);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GTK_RESPONSE_OK)) {
		RTHOOK(2);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14895[Dtype(Current)-1765])(Current);
	} else {
		RTHOOK(3);
		F1765_18532(Current);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_STANDARD_DIALOG_IMP}.on_ok */
void F1765_18531 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("on_ok", 1764, Current, 0, 0, 24396);
	RTGC;
	RTHOOK(1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14869[dtype-1765])(Current);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O14897[dtype-1764]) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	F1729_18050(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_STANDARD_DIALOG_IMP}.on_cancel */
void F1765_18532 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("on_cancel", 1764, Current, 0, 0, 24397);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(2271,F165_2271, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O14897[Dtype(Current)-1764]) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	F1729_18050(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit1042 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
