
#ifndef _C21_ev1012_
#define _C21_ev1012_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1735_18152(EIF_REFERENCE);
extern void EIF_Minit1012(void);
extern EIF_REFERENCE F1354_12447(EIF_REFERENCE);
extern void F1345_12285(EIF_REFERENCE);
extern EIF_REFERENCE F1687_17103(EIF_REFERENCE);
extern EIF_INTEGER_32 F1216_11061(EIF_REFERENCE);
extern char *(*R7993[])();
extern long O14600[];

#ifdef __cplusplus
}
#endif

#endif
