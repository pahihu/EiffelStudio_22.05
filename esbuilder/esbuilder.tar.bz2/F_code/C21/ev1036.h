
#ifndef _C21_ev1036_
#define _C21_ev1036_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1759_18492(EIF_REFERENCE);
extern void EIF_Minit1036(void);
extern EIF_REFERENCE F165_2267(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,2267)

#ifdef __cplusplus
}
#endif

#endif
