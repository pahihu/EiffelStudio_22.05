/*
 * Code for class EV_SELECTABLE_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1016.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_SELECTABLE_I}.is_selectable */
EIF_BOOLEAN F1739_18174 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_selectable", 1738, Current, 0, 0, 24082);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

void EIF_Minit1016 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
