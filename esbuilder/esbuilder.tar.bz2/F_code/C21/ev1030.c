/*
 * Code for class EV_FONTABLE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1030.h"
#include <ev_gtk.h>
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F50_617
static EIF_POINTER inline_F50_617 (void)
{
	return pango_attr_list_new();
	;
}
#define INLINE_F50_617
#endif
#ifndef INLINE_F50_620
static EIF_POINTER inline_F50_620 (EIF_POINTER arg1)
{
	return pango_attr_font_desc_new ((const PangoFontDescription *)arg1);
	;
}
#define INLINE_F50_620
#endif
#ifndef INLINE_F50_621
static void inline_F50_621 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	pango_attr_list_insert ((PangoAttrList *)arg1, (PangoAttribute *)arg2);
	;
}
#define INLINE_F50_621
#endif
#ifndef INLINE_F222_3954
static void inline_F222_3954 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_label_set_attributes ((GtkLabel *)arg1, (PangoAttrList *)arg2);
	;
}
#define INLINE_F222_3954
#endif
#ifndef INLINE_F50_622
static void inline_F50_622 (EIF_POINTER arg1)
{
	pango_attr_list_unref ((PangoAttrList *)arg1);
	;
}
#define INLINE_F50_622
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_FONTABLE_IMP}.font */
EIF_REFERENCE F1753_18382 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("font", 1752, Current, 1, 0, 24277);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + O14791[Dtype(Current)-1752]);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		tr1 = RTLNS(eif_new_type(1351, 0x00).id, 1351, _OBJSIZ_2_0_0_0_0_0_0_0_);
		F1345_12285(RTCW(tr1));
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(5);
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc1);
		RTHOOK(6);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {EV_FONTABLE_IMP}.set_font */
void F1753_18383 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,loc4);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTEAA("set_font", 1752, Current, 4, 1, 24273);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O14791[dtype-1752]) != arg1)) {
		RTHOOK(2);
		loc1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (arg1);
		RTHOOK(3);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + O14791[dtype-1752]) = (EIF_REFERENCE) loc1;
		RTHOOK(4);
		RTCT0("attached {EV_FONT_IMP} l_private_font.implementation as font_imp", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
		loc4 = tr1;
		loc4 = RTRV(eif_new_type(1701, 0x00),loc4);
		if (EIF_TEST(loc4)) {
			RTCK0;
		} else {
			RTCF0;
		}
		RTHOOK(5);
		tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R14790[dtype-1791])(Current);
		if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_LABEL((tp1)))) {
			RTHOOK(6);
			loc2 = inline_F50_617();
			RTHOOK(7);
			tp1 = *(EIF_POINTER *)(loc4+ _PTROFF_3_2_0_8_0_0_);
			loc3 = inline_F50_620(tp1);
			RTHOOK(8);
			inline_F50_621(loc2, loc3);
			RTHOOK(9);
			tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R14790[dtype-1791])(Current);
			inline_F222_3954(tp1, loc2);
			RTHOOK(10);
			inline_F50_622(loc2);
		} else {
		}
	}
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {EV_FONTABLE_IMP}.fontable_widget */
EIF_POINTER F1753_18385 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("fontable_widget", 1752, Current, 0, 0, 24274);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_POINTER) (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R14789[Dtype(Current)-1791])(Current);
}

void EIF_Minit1030 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
