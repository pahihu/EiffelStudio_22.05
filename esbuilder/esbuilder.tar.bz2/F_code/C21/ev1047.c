/*
 * Code for class EV_FILE_OPEN_DIALOG_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1047.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F220_3705
static EIF_POINTER inline_F220_3705 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gtk_file_chooser_get_filenames ((GtkFileChooser*) arg1))
	;
}
#define INLINE_F220_3705
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_FILE_OPEN_DIALOG_IMP}.make */
void F1770_18566 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 1769, Current, 0, 0, 24436);
	RTGC;
	RTHOOK(1);
	F1769_18551(Current);
	RTHOOK(2);
	tr1 = RTMS_EX_H("Open",4,1332766062);
	F1765_18521(Current, tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_FILE_OPEN_DIALOG_IMP}.full_file_path */
EIF_REFERENCE F1770_18568 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTEAA("full_file_path", 1769, Current, 2, 0, 24438);
	RTGC;
	RTHOOK(1);
	loc1 = F1770_18570(Current);
	RTHOOK(2);
	tb1 = F827_9290(RTCW(loc1));
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(3);
		loc2 = F1147_10119(RTCW(loc1));
	}
	RTHOOK(4);
	if ((EIF_BOOLEAN)(loc2 == NULL)) {
		RTHOOK(5);
		loc2 = F1769_18552(Current);
	}
	
	RTHOOK(7);
	RTHOOK(8);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) loc2;
}

/* {EV_FILE_OPEN_DIALOG_IMP}.file_paths */
EIF_REFERENCE F1770_18570 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("file_paths", 1769, Current, 3, 0, 24431);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1146,1385,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 1146, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F1147_10111(RTCW(Result), ((EIF_INTEGER_32) 1L));
	RTHOOK(2);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		tr1 = F1764_18516(Current);
		tb2 = F1508_14475(loc3, tr1);
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(3);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_11_6_0_1_0_0_);
		loc1 = inline_F220_3705(tp1);
	}
	RTHOOK(4);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc1 != tp1)) {
		for (;;) {
			RTHOOK(5);
			{
				/* INLINED CODE (ANY.default_pointer) */
				tp1 = (EIF_POINTER)  0;
				/* END INLINED CODE */
			}
			if ((EIF_BOOLEAN)(loc1 == tp1)) break;
			RTHOOK(6);
			loc2 = (EIF_POINTER) (((GSList *)loc1)->data);
			RTHOOK(7);
			tr1 = RTLNS(eif_new_type(1385, 0x00).id, 1385, _OBJSIZ_2_1_0_0_0_0_0_0_);
			F1386_12836(RTCW(tr1), loc2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7993[Dtype(RTCW(Result))-878])(Result, tr1);
			RTHOOK(8);
			g_free((gpointer) loc2);
			RTHOOK(9);
			tp2 = (EIF_POINTER) (((GSList *)loc1)->next);
			loc1 = (EIF_POINTER) tp2;
		}
		RTHOOK(10);
		g_slist_free((GSList*) loc1);
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_FILE_OPEN_DIALOG_IMP}.file_chooser_action */
EIF_INTEGER_32 F1770_18573 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("file_chooser_action", 1769, Current, 0, 0, 24434);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) (EIF_INTEGER_32) GTK_FILE_CHOOSER_ACTION_OPEN;
}

void EIF_Minit1047 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
