/*
 * Code for class EV_GTK_WIDGET_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1005.h"
#include <string.h>
#include <ev_any_imp.h>
#include <ev_gtk.h>
#include "eif_helpers.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F220_3438
static void inline_F220_3438 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	gtk_widget_get_size_request ((GtkWidget*) arg1, (gint*) arg2, (gint*) arg3)
	;
}
#define INLINE_F220_3438
#endif
#ifndef INLINE_F219_3016
static void inline_F219_3016 (EIF_POINTER arg1)
{
	g_object_unref((gpointer) arg1)
	;
}
#define INLINE_F219_3016
#endif
#ifndef INLINE_F1726_17951
static EIF_REFERENCE inline_F1726_17951 (EIF_POINTER arg1)
{
	return (EIF_REFERENCE) (c_ev_any_imp_get_eif_reference_from_object_id (arg1))
	;
}
#define INLINE_F1726_17951
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GTK_WIDGET_IMP}.gdk_events_mask */
static EIF_INTEGER_32 F1728_17990_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gdk_events_mask", 1727, Current, 0, 0, 23924);
	RTGC;
	RTOSP (17990);
#define Result RTOSR(17990)
	RTHOOK(1);
	ti4_1 = (EIF_INTEGER_32) GDK_EXPOSURE_MASK;
	ti4_2 = (EIF_INTEGER_32) GDK_POINTER_MOTION_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_BUTTON_PRESS_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_BUTTON_RELEASE_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_KEY_PRESS_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_KEY_RELEASE_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_ENTER_NOTIFY_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_LEAVE_NOTIFY_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_FOCUS_CHANGE_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_VISIBILITY_NOTIFY_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_POINTER_MOTION_HINT_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_SCROLL_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_STRUCTURE_MASK;
	Result = eif_bit_or(ti4_1,ti4_2);
	RTOSE (17990);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F1728_17990 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(17990,F1728_17990_body,(Current));
}

/* {EV_GTK_WIDGET_IMP}.make */
void F1728_17991 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make", 1727, Current, 2, 0, 23925);
	RTGC;
	RTHOOK(1);
	loc1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R14462[dtype-1726])(Current);
	RTHOOK(2);
	loc2 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
	RTHOOK(3);
	ti4_1 = RTOSCF(17990,F1728_17990, (Current));
	gtk_widget_add_events((GtkWidget*) loc1, (gint) ti4_1);
	RTHOOK(4);
	if ((EIF_BOOLEAN)(loc1 != loc2)) {
		RTHOOK(5);
		ti4_1 = RTOSCF(17990,F1728_17990, (Current));
		gtk_widget_add_events((GtkWidget*) loc2, (gint) ti4_1);
	}
	RTHOOK(6);
	if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_WINDOW((loc2)))) {
		RTHOOK(7);
		gtk_widget_realize((GtkWidget*) loc2);
	} else {
		RTHOOK(8);
		gtk_widget_show((GtkWidget*) loc2);
	}
	RTHOOK(9);
	F1687_17117(Current, (EIF_BOOLEAN) 1);
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {EV_GTK_WIDGET_IMP}.screen_x */
EIF_INTEGER_32 F1728_17992 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("screen_x", 1727, Current, 3, 0, 23926);
	RTGC;
	RTHOOK(1);
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14497[dtype-1729])(Current)) {
		RTHOOK(2);
		tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R14462[dtype-1726])(Current);
		tp1 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
		loc2 = (EIF_INTEGER_32) gdk_window_get_origin((GdkWindow*) tp1, (gint*) (EIF_INTEGER_32 *) &(loc1), (gint*) loc3);
		RTHOOK(3);
		Result = (EIF_INTEGER_32) loc1;
	}
	RTHOOK(4);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(17974,F1726_17974, (Current)))+ _LNGOFF_49_16_0_11_);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.screen_y */
EIF_INTEGER_32 F1728_17993 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("screen_y", 1727, Current, 3, 0, 23927);
	RTGC;
	RTHOOK(1);
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14497[dtype-1729])(Current)) {
		RTHOOK(2);
		tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R14462[dtype-1726])(Current);
		tp1 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
		loc2 = (EIF_INTEGER_32) gdk_window_get_origin((GdkWindow*) tp1, (gint*) loc3, (gint*) (EIF_INTEGER_32 *) &(loc1));
		RTHOOK(3);
		Result = (EIF_INTEGER_32) loc1;
	}
	RTHOOK(4);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(17974,F1726_17974, (Current)))+ _LNGOFF_49_16_0_12_);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.x_position */
EIF_INTEGER_32 F1728_17994 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("x_position", 1727, Current, 1, 0, 23928);
	RTGC;
	RTHOOK(1);
	ti4_1 = (EIF_INTEGER_32) sizeof(GtkAllocation);
	tp1 = malloc((size_t)ti4_1);
	loc1 = (EIF_POINTER) tp1;
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current + O14438[Dtype(Current)-1725]);
	gtk_widget_get_allocation((GtkWidget*) tp1, (GtkAllocation*) loc1);
	RTHOOK(3);
	Result = (EIF_INTEGER_32) (((GtkAllocation *)loc1)->x);
	RTHOOK(4);
	free(loc1);
	RTHOOK(5);
	ti4_1 = eif_max_int32 (Result,((EIF_INTEGER_32) 0L));
	RTHOOK(6);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) ti4_1;
}

/* {EV_GTK_WIDGET_IMP}.y_position */
EIF_INTEGER_32 F1728_17995 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("y_position", 1727, Current, 1, 0, 23929);
	RTGC;
	RTHOOK(1);
	ti4_1 = (EIF_INTEGER_32) sizeof(GtkAllocation);
	tp1 = malloc((size_t)ti4_1);
	loc1 = (EIF_POINTER) tp1;
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current + O14438[Dtype(Current)-1725]);
	gtk_widget_get_allocation((GtkWidget*) tp1, (GtkAllocation*) loc1);
	RTHOOK(3);
	Result = (EIF_INTEGER_32) (((GtkAllocation *)loc1)->y);
	RTHOOK(4);
	free(loc1);
	RTHOOK(5);
	ti4_1 = eif_max_int32 (Result,((EIF_INTEGER_32) 0L));
	RTHOOK(6);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) ti4_1;
}

/* {EV_GTK_WIDGET_IMP}.widget_imp_at_pointer_position */
EIF_REFERENCE F1728_17996 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("widget_imp_at_pointer_position", 1727, Current, 0, 0, 23930);
	RTGC;
	RTHOOK(1);
	Result = F1712_17781(RTCV(RTOSCF(17974,F1726_17974, (Current))));
	RTHOOK(2);
	RTLE;
	RTEE;
	return RTRV(eif_new_type(1773, 0x00), Result);
}

/* {EV_GTK_WIDGET_IMP}.minimum_width */
EIF_INTEGER_32 F1728_17997 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("minimum_width", 1727, Current, 0, 0, 23931);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R14475[Dtype(Current)-1729])(Current);
}

/* {EV_GTK_WIDGET_IMP}.minimum_height */
EIF_INTEGER_32 F1728_17998 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("minimum_height", 1727, Current, 0, 0, 23932);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R14476[Dtype(Current)-1729])(Current);
}

/* {EV_GTK_WIDGET_IMP}.real_minimum_width */
EIF_INTEGER_32 F1728_17999 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("real_minimum_width", 1727, Current, 1, 0, 23933);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !F1687_17102(Current)) {
		RTHOOK(2);
		Result = F1728_18001(Current);
		RTHOOK(3);
		loc1 = F1728_18003(Current);
		RTHOOK(4);
		if ((EIF_BOOLEAN) (loc1 > Result)) {
			RTHOOK(5);
			Result = (EIF_INTEGER_32) loc1;
		}
		RTHOOK(6);
		if ((EIF_BOOLEAN) (Result < ((EIF_INTEGER_32) 0L))) {
			RTHOOK(7);
			RTHOOK(8);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		}
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.real_minimum_height */
EIF_INTEGER_32 F1728_18000 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("real_minimum_height", 1727, Current, 1, 0, 23934);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !F1687_17102(Current)) {
		RTHOOK(2);
		Result = F1728_18002(Current);
		RTHOOK(3);
		loc1 = F1728_18004(Current);
		RTHOOK(4);
		if ((EIF_BOOLEAN) (loc1 > Result)) {
			RTHOOK(5);
			Result = (EIF_INTEGER_32) loc1;
		}
		RTHOOK(6);
		if ((EIF_BOOLEAN) (Result < ((EIF_INTEGER_32) 0L))) {
			RTHOOK(7);
			RTHOOK(8);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		}
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.width_request */
EIF_INTEGER_32 F1728_18001 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("width_request", 1727, Current, 0, 0, 23935);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O14438[Dtype(Current)-1725]);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp2 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp3 = tp2;
	inline_F220_3438(tp1, (EIF_INTEGER_32 *) &(Result), tp3);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.height_request */
EIF_INTEGER_32 F1728_18002 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("height_request", 1727, Current, 0, 0, 23936);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O14438[Dtype(Current)-1725]);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp2 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp3 = tp2;
	inline_F220_3438(tp1, tp3, (EIF_INTEGER_32 *) &(Result));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.preferred_minimum_width */
EIF_INTEGER_32 F1728_18003 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("preferred_minimum_width", 1727, Current, 2, 0, 23937);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_POINTER *)(RTCV(RTOSCF(18007,F1728_18007, (Current)))+ _PTROFF_0_1_0_1_0_0_);
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current + O14438[Dtype(Current)-1725]);
	gtk_widget_get_preferred_size((GtkWidget*) tp1, (GtkRequisition*) loc1, (GtkRequisition*) loc2);
	RTHOOK(3);
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (((GtkRequisition *)loc1)->width);
}

/* {EV_GTK_WIDGET_IMP}.preferred_minimum_height */
EIF_INTEGER_32 F1728_18004 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("preferred_minimum_height", 1727, Current, 2, 0, 23938);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_POINTER *)(RTCV(RTOSCF(18007,F1728_18007, (Current)))+ _PTROFF_0_1_0_1_0_0_);
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current + O14438[Dtype(Current)-1725]);
	gtk_widget_get_preferred_size((GtkWidget*) tp1, (GtkRequisition*) loc1, (GtkRequisition*) loc2);
	RTHOOK(3);
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (((GtkRequisition *)loc1)->height);
}

/* {EV_GTK_WIDGET_IMP}.reusable_requisition_struct */
static EIF_REFERENCE F1728_18007_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("reusable_requisition_struct", 1727, Current, 0, 0, 23941);
	RTGC;
	RTOSP (18007);
#define Result RTOSR(18007)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_0_1_0_1_0_1_1_0_);
	ti4_1 = (EIF_INTEGER_32) sizeof(GtkRequisition);
	F1209_10428(RTCW(tr1), ti4_1);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (18007);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1728_18007 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(18007,F1728_18007_body,(Current));
}

/* {EV_GTK_WIDGET_IMP}.event_widget */
EIF_POINTER F1728_18008 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("event_widget", 1727, Current, 1, 0, 23942);
	RTGC;
	RTHOOK(1);
	loc1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R14462[dtype-1726])(Current);
	RTHOOK(2);
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(gtk_widget_get_has_window((GtkWidget*) loc1))) {
		RTHOOK(3);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_POINTER) loc1;
	} else {
		RTHOOK(5);
		RTHOOK(6);
		RTLE;
		RTEE;
		return (EIF_POINTER) *(EIF_POINTER *)(Current + O14438[dtype-1725]);
	}/* NOTREACHED */
	
}

/* {EV_GTK_WIDGET_IMP}.set_pointer_style */
void F1728_18009 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("set_pointer_style", 1727, Current, 0, 1, 23943);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != *(EIF_REFERENCE *)(Current + O14488[dtype-1727]))) {
		RTHOOK(2);
		if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14497[dtype-1729])(Current)) {
			RTHOOK(3);
			F1728_18010(Current, arg1);
		}
		RTHOOK(4);
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current + O14488[dtype-1727]) = (EIF_REFERENCE) arg1;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_GTK_WIDGET_IMP}.internal_set_pointer_style */
void F1728_18010 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("internal_set_pointer_style", 1727, Current, 3, 1, 23944);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != *(EIF_REFERENCE *)(Current + O14487[dtype-1727]))) {
		RTHOOK(2);
		RTCT0("attached {EV_POINTER_STYLE_IMP} a_cursor.implementation as a_cursor_imp", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		loc3 = tr1;
		loc3 = RTRV(eif_new_type(1703, 0x00),loc3);
		if (EIF_TEST(loc3)) {
			RTCK0;
		} else {
			RTCF0;
		}
		RTHOOK(3);
		tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
		loc2 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
		RTHOOK(4);
		tb1 = !loc2;
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(5);
			loc1 = F1704_17471(loc3);
			RTHOOK(6);
			gdk_window_set_cursor((GdkWindow*) loc2, (GdkCursor*) loc1);
			RTHOOK(7);
			inline_F219_3016(loc1);
			RTHOOK(8);
			RTAR(Current, arg1);
			*(EIF_REFERENCE *)(Current + O14487[dtype-1727]) = (EIF_REFERENCE) arg1;
		}
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {EV_GTK_WIDGET_IMP}.pointer_style */
EIF_REFERENCE F1728_18012 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O14488[Dtype(Current)-1727]);
}


/* {EV_GTK_WIDGET_IMP}.set_focus */
void F1728_18013 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_focus", 1727, Current, 0, 0, 23947);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14491[dtype-1729])(Current)) {
		RTHOOK(2);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14490[dtype-1729])(Current);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_GTK_WIDGET_IMP}.internal_set_focus */
void F1728_18014 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,loc5);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTEAA("internal_set_focus", 1727, Current, 5, 0, 23948);
	RTGC;
	RTHOOK(1);
	loc4 = RTOSCF(17974,F1726_17974, (Current));
	RTHOOK(2);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_29_);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		tb2 = F1712_17764(RTCW(loc4));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(3);
		loc3 = F1687_17103(Current);
		RTHOOK(4);
		if ((EIF_BOOLEAN)(loc3 != loc5)) {
			RTHOOK(5);
			F1575_15192(loc5);
		}
	}
	RTHOOK(6);
	tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
	if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_WINDOW((tp1)))) {
		RTHOOK(7);
		loc1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
	} else {
		RTHOOK(8);
		tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
		loc1 = (EIF_POINTER) gtk_widget_get_toplevel((GtkWidget*) tp1);
		RTHOOK(9);
		loc2 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R14462[dtype-1726])(Current);
		RTHOOK(10);
		if ((EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(gtk_widget_get_can_focus((GtkWidget*) loc2))) {
			RTHOOK(11);
			{
				/* INLINED CODE (ANY.default_pointer) */
				tp1 = (EIF_POINTER)  0;
				/* END INLINED CODE */
			}
			loc2 = tp1;
		}
	}
	RTHOOK(12);
	gtk_window_set_focus((GtkWindow*) loc1, (GtkWidget*) loc2);
	RTHOOK(13);
	tb1 = '\0';
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc2 != tp1)) {
		tb1 = (EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(gtk_widget_is_focus((GtkWidget*) loc2));
	}
	if (tb1) {
		RTHOOK(14);
		gtk_widget_grab_focus((GtkWidget*) loc2);
	}
	RTHOOK(15);
	RTLE;
	RTEE;
}

/* {EV_GTK_WIDGET_IMP}.has_focus */
EIF_BOOLEAN F1728_18015 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("has_focus", 1727, Current, 0, 0, 23949);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) F1728_18025(Current, (EIF_BOOLEAN) 1);
}

/* {EV_GTK_WIDGET_IMP}.width */
EIF_INTEGER_32 F1728_18016 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("width", 1727, Current, 3, 0, 23950);
	RTGC;
	RTHOOK(1);
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R14475[dtype-1729])(Current);
	RTHOOK(2);
	tb1 = '\01';
	if (!F1728_18020(Current)) {
		tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
		tb1 = (EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(GTK_IS_WINDOW((tp1)));
	}
	if (tb1) {
		RTHOOK(3);
		ti4_1 = (EIF_INTEGER_32) sizeof(GtkAllocation);
		tp1 = malloc((size_t)ti4_1);
		loc3 = (EIF_POINTER) tp1;
		RTHOOK(4);
		tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
		gtk_widget_get_allocation((GtkWidget*) tp1, (GtkAllocation*) loc3);
		RTHOOK(5);
		loc2 = (EIF_INTEGER_32) (((GtkAllocation *)loc3)->width);
		RTHOOK(6);
		tb1 = '\0';
		tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp2 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)((EIF_POINTER) gtk_widget_get_parent((GtkWidget*) tp1) != tp2)) {
			tb1 = (EIF_BOOLEAN) (loc2 < loc1);
		}
		if (tb1) {
			RTHOOK(7);
			tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
			gtk_widget_get_allocation((GtkWidget*) tp1, (GtkAllocation*) loc3);
			RTHOOK(8);
			loc2 = (EIF_INTEGER_32) (((GtkAllocation *)loc3)->width);
		}
		RTHOOK(9);
		free(loc3);
	}
	RTHOOK(10);
	ti4_1 = eif_max_int32 (loc1,loc2);
	RTHOOK(11);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) ti4_1;
}

/* {EV_GTK_WIDGET_IMP}.height */
EIF_INTEGER_32 F1728_18017 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("height", 1727, Current, 3, 0, 23951);
	RTGC;
	RTHOOK(1);
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R14476[dtype-1729])(Current);
	RTHOOK(2);
	tb1 = '\01';
	if (!F1728_18020(Current)) {
		tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
		tb1 = (EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(GTK_IS_WINDOW((tp1)));
	}
	if (tb1) {
		RTHOOK(3);
		ti4_1 = (EIF_INTEGER_32) sizeof(GtkAllocation);
		tp1 = malloc((size_t)ti4_1);
		loc3 = (EIF_POINTER) tp1;
		RTHOOK(4);
		tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
		gtk_widget_get_allocation((GtkWidget*) tp1, (GtkAllocation*) loc3);
		RTHOOK(5);
		loc2 = (EIF_INTEGER_32) (((GtkAllocation *)loc3)->height);
		RTHOOK(6);
		tb1 = '\0';
		tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp2 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)((EIF_POINTER) gtk_widget_get_parent((GtkWidget*) tp1) != tp2)) {
			tb1 = (EIF_BOOLEAN) (loc2 < loc1);
		}
		if (tb1) {
			RTHOOK(7);
			tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
			gtk_widget_get_allocation((GtkWidget*) tp1, (GtkAllocation*) loc3);
			RTHOOK(8);
			loc2 = (EIF_INTEGER_32) (((GtkAllocation *)loc3)->height);
		}
		RTHOOK(9);
		free(loc3);
	}
	RTHOOK(10);
	ti4_1 = eif_max_int32 (loc1,loc2);
	RTHOOK(11);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) ti4_1;
}

/* {EV_GTK_WIDGET_IMP}.show */
void F1728_18019 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	
	
	RTEAA("show", 1727, Current, 0, 0, 23953);
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O14438[Dtype(Current)-1725]);
	gtk_widget_show((GtkWidget*) tp1);
	RTHOOK(2);
	RTEE;
}

/* {EV_GTK_WIDGET_IMP}.is_show_requested */
EIF_BOOLEAN F1728_18020 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	
	
	RTEAA("is_show_requested", 1727, Current, 0, 0, 23954);
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O14438[Dtype(Current)-1725]);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) EIF_TEST(gtk_widget_get_visible((GtkWidget*) tp1));
}

/* {EV_GTK_WIDGET_IMP}.is_displayed */
EIF_BOOLEAN F1728_18021 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLIU(2);
	
	RTEAA("is_displayed", 1727, Current, 1, 0, 23955);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current + O14438[dtype-1725]) != tp1)) {
		tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
		Result = (EIF_BOOLEAN) EIF_TEST(gtk_widget_get_mapped((GtkWidget*) tp1));
	}
	RTHOOK(2);
	if (Result) {
		RTHOOK(3);
		loc1 = F1728_18023(Current);
		RTHOOK(4);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTHOOK(5);
			tp1 = *(EIF_POINTER *)(RTCW(loc1) + O14438[Dtype(loc1)-1725]);
			Result = (EIF_BOOLEAN) EIF_TEST(gtk_widget_get_mapped((GtkWidget*) tp1));
		}
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.top_level_gtk_window_imp */
EIF_REFERENCE F1728_18022 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("top_level_gtk_window_imp", 1727, Current, 1, 0, 23956);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O14438[Dtype(Current)-1725]);
	loc1 = (EIF_POINTER) gtk_widget_get_toplevel((GtkWidget*) tp1);
	RTHOOK(2);
	tb1 = !loc1;
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(3);
		tr1 = RTLNTY2(eif_new_type(1728, 0x00), 0x00);
		tr2 = inline_F1726_17951(loc1);
		Result = F1387_12906(tr1, tr2);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.top_level_window_imp */
EIF_REFERENCE F1728_18023 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("top_level_window_imp", 1727, Current, 0, 0, 23957);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNTY2(eif_new_type(1810, 0x00), 0x00);
	tr2 = F1728_18022(Current);
	Result = F1387_12906(tr1, tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.top_level_window */
EIF_REFERENCE F1728_18024 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("top_level_window", 1727, Current, 1, 0, 23958);
	RTGC;
	RTHOOK(1);
	tr1 = F1728_18022(Current);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1810, 0x00),loc1);
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(loc1 + O13786[Dtype(loc1)-1686]);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {EV_GTK_WIDGET_IMP}.has_focus_internal */
EIF_BOOLEAN F1728_18025 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("has_focus_internal", 1727, Current, 3, 1, 23959);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O14438[Dtype(Current)-1725]);
	loc1 = (EIF_POINTER) gtk_widget_get_toplevel((GtkWidget*) tp1);
	RTHOOK(2);
	tb1 = '\0';
	tb2 = '\0';
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc1 != tp1)) {
		tb2 = (EIF_BOOLEAN) EIF_TEST(gtk_widget_is_toplevel((GtkWidget*) loc1));
	}
	if (tb2) {
		tb2 = '\01';
		if (arg1) {
			tb2 = (EIF_BOOLEAN) EIF_TEST(gtk_window_is_active((GtkWindow*) loc1));
		}
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(3);
		loc2 = (EIF_POINTER) gtk_window_get_focus((GtkWindow*) loc1);
		RTHOOK(4);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(loc2 != tp1)) {
			RTHOOK(5);
			tr1 = RTOSCF(17974,F1726_17974, (Current));
			loc3 = F1712_17780(RTCW(tr1), loc2);
			loc3 = RTRV(eif_new_type(1773, 0x00), loc3);
			RTHOOK(6);
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				RTHOOK(7);
				RTHOOK(8);
				RTLE;
				RTEE;
				return (EIF_BOOLEAN) (EIF_BOOLEAN)(loc3 == Current);
			}
		}
	}
	RTHOOK(9);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) 0;
}

void EIF_Minit1005 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
