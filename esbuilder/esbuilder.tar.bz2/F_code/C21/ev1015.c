/*
 * Code for class EV_SENSITIVE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1015.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_SENSITIVE_IMP}.is_sensitive */
EIF_BOOLEAN F1738_18166 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_sensitive", 1737, Current, 0, 0, 24076);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !F1687_17102(Current)) {
		RTHOOK(2);
		tp1 = *(EIF_POINTER *)(Current + O14438[Dtype(Current)-1725]);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) EIF_TEST(gtk_widget_is_sensitive((GtkWidget*) tp1));
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) 0;
}

/* {EV_SENSITIVE_IMP}.enable_sensitive */
void F1738_18167 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("enable_sensitive", 1737, Current, 0, 0, 24077);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
	gtk_widget_set_sensitive((GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 1);
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
	if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_EVENT_BOX((tp1)))) {
		RTHOOK(3);
		tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
		gtk_event_box_set_visible_window((GtkEventBox*) tp1, (gboolean) (EIF_BOOLEAN) 1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_SENSITIVE_IMP}.disable_sensitive */
void F1738_18168 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("disable_sensitive", 1737, Current, 0, 0, 24078);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
	gtk_widget_set_sensitive((GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 0);
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
	if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_EVENT_BOX((tp1)))) {
		RTHOOK(3);
		tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
		gtk_event_box_set_visible_window((GtkEventBox*) tp1, (gboolean) (EIF_BOOLEAN) 0);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_SENSITIVE_IMP}.has_parent */
EIF_BOOLEAN F1738_18170 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("has_parent", 1737, Current, 0, 0, 24079);
	RTGC;
	RTHOOK(1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14614[Dtype(Current)-1786])(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 != NULL);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_SENSITIVE_IMP}.parent_is_sensitive */
EIF_BOOLEAN F1738_18172 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("parent_is_sensitive", 1737, Current, 1, 0, 24080);
	RTGC;
	RTHOOK(1);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14614[Dtype(Current)-1786])(Current);
	loc1 = RTRV(eif_new_type(1376, 0x00), loc1);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTHOOK(3);
		tb1 = F1377_12721(RTCW(loc1));
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) tb1;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) 0;
}

void EIF_Minit1015 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
