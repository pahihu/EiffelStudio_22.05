/*
 * Code for class EV_DOCKABLE_TARGET_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1012.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DOCKABLE_TARGET_I}.enable_docking */
void F1735_18152 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("enable_docking", 1734, Current, 2, 0, 24067);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O14600[Dtype(Current)-1734]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	tr1 = RTLNS(eif_new_type(1353, 0x00).id, 1353, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1345_12285(RTCW(tr1));
	tr1 = F1354_12447(RTCW(tr1));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_1_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_26_);
		ti4_1 = F1216_11061(RTCV(F1687_17103(Current)));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7993[Dtype(RTCW(tr1))-878])(tr1, (EIF_REFERENCE) &ti4_1);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

void EIF_Minit1012 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
