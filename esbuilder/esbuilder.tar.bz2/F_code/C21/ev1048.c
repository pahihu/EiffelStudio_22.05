/*
 * Code for class EV_PICK_AND_DROPABLE_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1048.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PICK_AND_DROPABLE_I}.set_pebble */
void F1771_18585 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_pebble", 1770, Current, 0, 1, 24469);
	RTGC;
	RTHOOK(1);
	*(EIF_REFERENCE *)(Current + O14906[dtype-1770]) = (EIF_REFERENCE) NULL;
	RTHOOK(2);
	tr1 = RTCCL(arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O14905[dtype-1770]) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R14919[dtype-1786])(Current);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_PICK_AND_DROPABLE_I}.set_pebble_function */
void F1771_18586 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("set_pebble_function", 1770, Current, 0, 1, 24470);
	RTGC;
	RTHOOK(1);
	*(EIF_REFERENCE *)(Current + O14905[dtype-1770]) = (EIF_REFERENCE) NULL;
	RTHOOK(2);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O14906[dtype-1770]) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R14919[dtype-1786])(Current);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_PICK_AND_DROPABLE_I}.remove_pebble */
void F1771_18587 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("remove_pebble", 1770, Current, 0, 0, 24471);
	RTGC;
	RTHOOK(1);
	*(EIF_REFERENCE *)(Current + O14905[dtype-1770]) = (EIF_REFERENCE) NULL;
	RTHOOK(2);
	*(EIF_REFERENCE *)(Current + O14906[dtype-1770]) = (EIF_REFERENCE) NULL;
	RTHOOK(3);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R14920[dtype-1786])(Current);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_PICK_AND_DROPABLE_I}.reset_pebble_function */
void F1771_18588 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("reset_pebble_function", 1770, Current, 0, 0, 24472);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O14906[dtype-1770]) != NULL)) {
		RTHOOK(2);
		*(EIF_REFERENCE *)(Current + O14905[dtype-1770]) = (EIF_REFERENCE) NULL;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_PICK_AND_DROPABLE_I}.set_accept_cursor */
void F1771_18596 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_accept_cursor", 1770, Current, 0, 1, 24478);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O14909[Dtype(Current)-1770]) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EV_PICK_AND_DROPABLE_I}.set_deny_cursor */
void F1771_18597 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_deny_cursor", 1770, Current, 0, 1, 24479);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O14910[Dtype(Current)-1770]) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {EV_PICK_AND_DROPABLE_I}.mode_is_pick_and_drop */
EIF_BOOLEAN F1771_18601 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTCDT;
	
	
	RTEAA("mode_is_pick_and_drop", 1770, Current, 0, 0, 24483);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_8 *)(Current + O14938[dtype-1770]) == ((EIF_INTEGER_8) 0L)) || (EIF_BOOLEAN)(*(EIF_INTEGER_8 *)(Current + O14938[dtype-1770]) == ((EIF_INTEGER_8) 3L)));
}

/* {EV_PICK_AND_DROPABLE_I}.mode_is_drag_and_drop */
EIF_BOOLEAN F1771_18602 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("mode_is_drag_and_drop", 1770, Current, 0, 0, 24439);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_8 *)(Current + O14938[Dtype(Current)-1770]) == ((EIF_INTEGER_8) 1L));
}

/* {EV_PICK_AND_DROPABLE_I}.mode_is_target_menu */
EIF_BOOLEAN F1771_18603 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("mode_is_target_menu", 1770, Current, 0, 0, 24440);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_8 *)(Current + O14938[Dtype(Current)-1770]) == ((EIF_INTEGER_8) 2L));
}

/* {EV_PICK_AND_DROPABLE_I}.mode_is_configurable_target_menu */
EIF_BOOLEAN F1771_18604 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("mode_is_configurable_target_menu", 1770, Current, 0, 0, 24441);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_8 *)(Current + O14938[Dtype(Current)-1770]) == ((EIF_INTEGER_8) 3L));
}

/* {EV_PICK_AND_DROPABLE_I}.execute */
void F1771_18615 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_16 ti2_1;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTEAA("execute", 1770, Current, 3, 7, 24450);
	RTGC;
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R14950[dtype-1786])(Current);
	RTHOOK(2);
	ti2_1 = (EIF_INTEGER_16) arg6;
	*(EIF_INTEGER_16 *)(Current + O5086[dtype-332]) = (EIF_INTEGER_16) ti2_1;
	RTHOOK(3);
	ti2_1 = (EIF_INTEGER_16) arg7;
	*(EIF_INTEGER_16 *)(Current + O5087[dtype-332]) = (EIF_INTEGER_16) ti2_1;
	RTHOOK(4);
	tr1 = F1771_18627(Current);
	F1711_17624(RTCW(tr1), arg6, arg7);
	RTHOOK(5);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R14949[dtype-1786])(Current);
	RTHOOK(6);
	loc1 = F1771_18617(Current);
	RTHOOK(7);
	loc2 = loc1;
	loc2 = RTRV(eif_new_type(1556, 0x00), loc2);
	RTHOOK(8);
	tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(18628,F1771_18628, (Current))) + _REFACS_1_);
	loc3 = F1706_17488(RTCW(tr1));
	loc3 = RTRV(eif_new_type(1711, 0x00), loc3);
	RTHOOK(9);
	RTCT0("application /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(10);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_6_);
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		RTHOOK(11);
		tr1 = F258_4271(RTCW(loc3));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,1419,1425,1425,1556,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr2 = RTLNTS(typres0.id, 4, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_i4 = arg1;
		((EIF_TYPED_VALUE *)tr2+2)->it_i4 = arg2;
		((EIF_TYPED_VALUE *)tr2+3)->it_r = loc2;
		RTAR(tr2,loc2);
		F1177_10288(RTCW(tr1), tr2);
	}
	RTHOOK(12);
	F1771_18616(Current, loc1);
	RTHOOK(13);
	RTLE;
	RTEE;
}

/* {EV_PICK_AND_DROPABLE_I}.update_pointer_style */
void F1771_18616 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc2);
	RTLR(6,loc3);
	RTLIU(7);
	
	RTEAA("update_pointer_style", 1770, Current, 3, 1, 24451);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + O14905[dtype-1770]);
	loc1 = RTCCL(tr1);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && EIF_TEST(loc1))) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9249[Dtype(RTCW(arg1))-1222])(arg1);
		tr2 = RTCCL(loc1);
		tb2 = F1178_10291(RTCW(tr1), tr2);
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + O14909[dtype-1770]);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTHOOK(3);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R14954[dtype-1786])(Current, loc2);
		} else {
			RTHOOK(4);
			tr1 = RTOSCF(5535,F333_5535, (Current));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R14954[dtype-1786])(Current, tr1);
		}
	} else {
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + O14910[dtype-1770]);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			RTHOOK(6);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R14954[dtype-1786])(Current, loc3);
		} else {
			RTHOOK(7);
			tr1 = RTOSCF(5536,F333_5536, (Current));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R14954[dtype-1786])(Current, tr1);
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EV_PICK_AND_DROPABLE_I}.pointed_target */
EIF_REFERENCE F1771_18617 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_16 ti2_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTEAA("pointed_target", 1770, Current, 5, 0, 24452);
	RTGC;
	RTHOOK(1);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14948[dtype-1786])(Current);
	RTHOOK(2);
	Result = (EIF_REFERENCE) loc1;
	RTHOOK(3);
	loc2 = loc1;
	loc2 = RTRV(eif_new_type(1574, 0x00), loc2);
	RTHOOK(4);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + O10182[Dtype(loc2)-1344]);
		loc3 = *(EIF_REFERENCE *)(RTCW(tr1) + O14982[Dtype(tr1)-1772]);
		RTHOOK(6);
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			RTHOOK(7);
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O5086[dtype-332]);
			loc4 = (EIF_INTEGER_32) ti2_1;
			ti4_1 = F1362_12528(RTCW(loc2));
			loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 - ti4_1);
			RTHOOK(8);
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O5087[dtype-332]);
			loc5 = (EIF_INTEGER_32) ti2_1;
			ti4_1 = F1362_12529(RTCW(loc2));
			loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 - ti4_1);
			RTHOOK(9);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1419,1425,1425,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
				tr1 = RTLNTS(typres0.id, 3, 1);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_i4 = loc4;
			((EIF_TYPED_VALUE *)tr1+2)->it_i4 = loc5;
			Result = F1495_14146(RTCW(loc3), tr1);
		}
	}
	RTHOOK(10);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_PICK_AND_DROPABLE_I}.call_pebble_function */
void F1771_18621 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("call_pebble_function", 1770, Current, 1, 4, 24453);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O14906[dtype-1770]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1419,1425,1425,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 1);
		}
		((EIF_TYPED_VALUE *)tr1+1)->it_i4 = arg1;
		((EIF_TYPED_VALUE *)tr1+2)->it_i4 = arg2;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11441[Dtype(loc1)-1494])(loc1, tr1);
		tr1 = RTCCL(tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O14905[dtype-1770]) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_PICK_AND_DROPABLE_I}.modify_widget_appearance */
void F1771_18622 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("modify_widget_appearance", 1770, Current, 2, 1, 24454);
	RTGC;
	RTHOOK(1);
	loc2 = F1712_17694(RTCV(F1771_18627(Current)));
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R7973[Dtype(RTCW(loc2))-989])(loc2);
	for (;;) {
		RTHOOK(3);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7972[Dtype(RTCW(loc2))-989])(loc2);
		if (tb1) break;
		RTHOOK(4);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7971[Dtype(RTCW(loc2))-989])(loc2);
		loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O10182[Dtype(tr1)-1344]);
		loc1 = RTRV(eif_new_type(1810, 0x00), loc1);
		RTHOOK(5);
		RTCT0("window_implementation_not_void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		RTHOOK(6);
		F1802_19500(RTCW(loc1), arg1);
		RTHOOK(7);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R7986[Dtype(RTCW(loc2))-989])(loc2);
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EV_PICK_AND_DROPABLE_I}.application_implementation */
EIF_REFERENCE F1771_18627 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("application_implementation", 1770, Current, 0, 0, 24456);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(18628,F1771_18628, (Current))) + _REFACS_1_);
	Result = F1706_17488(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_PICK_AND_DROPABLE_I}.environment */
static EIF_REFERENCE F1771_18628_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("environment", 1770, Current, 0, 0, 24457);
	RTGC;
	RTOSP (18628);
#define Result RTOSR(18628)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1353, 0x00).id, 1353, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1345_12285(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (18628);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1771_18628 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(18628,F1771_18628_body,(Current));
}

void EIF_Minit1048 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
