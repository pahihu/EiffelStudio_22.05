
#ifndef _C21_ev1031_
#define _C21_ev1031_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1754_18389(EIF_REFERENCE);
extern void F1754_18395(EIF_REFERENCE);
extern void EIF_Minit1031(void);
extern void F1687_17118(EIF_REFERENCE, EIF_BOOLEAN);
extern void F1687_17117(EIF_REFERENCE, EIF_BOOLEAN);
extern void F1206_10395(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
