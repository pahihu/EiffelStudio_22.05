/*
 * Code for class EV_GRID_CHECKABLE_LABEL_ITEM_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1035.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GRID_CHECKABLE_LABEL_ITEM_I}.make */
void F1758_18471 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 1757, Current, 0, 0, 24372);
	RTGC;
	RTHOOK(1);
	F1757_18456(Current);
	RTHOOK(2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_22_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	{
		static EIF_TYPE_INDEX typarr0[] = {1176,0xFFF9,1,1419,1521,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1176_10251(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_22_6_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 13L);
	RTHOOK(5);
	F1758_18477(Current);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_GRID_CHECKABLE_LABEL_ITEM_I}.required_width */
EIF_INTEGER_32 F1758_18475 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("required_width", 1757, Current, 0, 0, 24376);
	RTGC;
	RTHOOK(1);
	Result = F1757_18457(Current);
	ti4_1 = F1522_14867(RTCV(F1687_17103(Current)));
	ti4_2 = *(EIF_INTEGER_32 *)(RTCV(F1687_17103(Current))+ _LNGOFF_7_4_0_3_);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (Result + ti4_1) + ti4_2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_CHECKABLE_LABEL_ITEM_I}.update_check_figure_size */
RTEOMS(18476,1);
void F1758_18477 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("update_check_figure_size", 1757, Current, 2, 0, 24363);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTHOOK(2);
		loc1 = *(EIF_REFERENCE *)(loc2 + _REFACS_4_);
	}
	RTHOOK(3);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(4);
		loc1 = RTOSCF(18461,F1757_18461, (Current));
	}
	RTHOOK(5);
	ti4_1 = F1352_12422(RTCW(loc1), RTOMS(18476,0));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_22_6_0_3_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_GRID_CHECKABLE_LABEL_ITEM_I}.set_is_checked */
void F1758_18480 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("set_is_checked", 1757, Current, 0, 1, 24366);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_22_4_) = (EIF_BOOLEAN) arg1;
	RTHOOK(2);
	tb1 = '\0';
	if (F1755_18419(Current)) {
		tb1 = (EIF_BOOLEAN) !F1755_18422(Current);
	}
	if (tb1) {
		RTHOOK(3);
		F1755_18418(Current);
	}
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y13786,Y13786_gen_type,Dftype(Current),1686);
			typarr0[3] = l_type.annotations | 0xFF00;
			typarr0[4] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	tr3 = F1687_17103(Current);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8518[Dtype(RTCW(tr1))-1175])(tr1, tr2);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_GRID_CHECKABLE_LABEL_ITEM_I}.toggle_is_checked */
void F1758_18481 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("toggle_is_checked", 1757, Current, 0, 0, 24367);
	RTHOOK(1);
	F1758_18480(Current, (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_22_4_));
	RTHOOK(2);
	RTEE;
}

/* {EV_GRID_CHECKABLE_LABEL_ITEM_I}.draw_additional */
void F1758_18482 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,loc7);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTEAA("draw_additional", 1757, Current, 7, 3, 24368);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_0_1_0_2_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + arg3);
	RTHOOK(2);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_0_1_0_3_);
	RTHOOK(3);
	loc6 = F1522_14867(RTCV(F1687_17103(Current)));
	RTHOOK(4);
	loc3 = F1372_12587(RTCW(arg1));
	RTHOOK(5);
	loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(6);
	F1372_12595(RTCW(arg1), loc4);
	RTHOOK(7);
	F1372_12621(RTCW(arg1), loc1, loc2, loc6, loc6);
	RTHOOK(8);
	F1372_12621(RTCW(arg1), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (loc6 - ((EIF_INTEGER_32) 2L)), (EIF_INTEGER_32) (loc6 - ((EIF_INTEGER_32) 2L)));
	RTHOOK(9);
	tr1 = F1687_17103(Current);
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		RTHOOK(10);
		tb1 = F1522_14843(loc7);
		if (tb1) {
			RTHOOK(11);
			loc1 += (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * loc4);
			RTHOOK(12);
			loc2 += (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * loc4);
			RTHOOK(13);
			loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc6 - (EIF_INTEGER_32) (((EIF_INTEGER_32) 5L) * loc4));
			RTHOOK(14);
			if ((EIF_BOOLEAN) (loc5 > ((EIF_INTEGER_32) 12L))) {
				RTHOOK(15);
				loc5 -= ((EIF_INTEGER_32) 2L);
				RTHOOK(16);
				loc1++;
				RTHOOK(17);
				loc2++;
			}
			RTHOOK(18);
			tb1 = *(EIF_BOOLEAN *)(loc7+ _CHROFF_7_1_);
			if (tb1) {
				RTHOOK(19);
				F1758_18484(Current, arg1, loc5, loc1, loc2);
			} else {
				RTHOOK(20);
				F1758_18483(Current, arg1, loc5, loc1, loc2);
			}
		}
	}
	RTHOOK(21);
	F1372_12595(RTCW(arg1), loc3);
	RTHOOK(22);
	RTLE;
	RTEE;
}

/* {EV_GRID_CHECKABLE_LABEL_ITEM_I}.draw_check_sign_at */
void F1758_18483 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("draw_check_sign_at", 1757, Current, 9, 4, 24369);
	RTGC;
	RTHOOK(1);
	loc9 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 / ((EIF_INTEGER_32) 3L));
	RTHOOK(2);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(3);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + loc9);
	RTHOOK(4);
	loc4 = (EIF_INTEGER_32) arg2;
	RTHOOK(5);
	loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(6);
	loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 + loc9);
	RTHOOK(7);
	loc7 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc6 + loc9);
	RTHOOK(8);
	loc8 = (EIF_INTEGER_32) arg2;
	RTHOOK(9);
	{
		static EIF_TYPE_INDEX typarr0[] = {921,1253,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 921, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	tr1 = RTLNS(eif_new_type(1253, 0x00).id, 1253, _OBJSIZ_0_0_0_0_0_0_0_2_);
	F1254_11734(RTCW(tr1), (EIF_INTEGER_32) (arg3 + loc2), (EIF_INTEGER_32) (arg4 + loc6));
	F922_9406(RTCW(loc1), tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 6L));
	RTHOOK(10);
	tr1 = RTLNS(eif_new_type(1253, 0x00).id, 1253, _OBJSIZ_0_0_0_0_0_0_0_2_);
	F1254_11734(RTCW(tr1), (EIF_INTEGER_32) (arg3 + loc3), (EIF_INTEGER_32) (arg4 + loc7));
	F922_9430(RTCW(loc1), tr1, ((EIF_INTEGER_32) 2L));
	RTHOOK(11);
	tr1 = RTLNS(eif_new_type(1253, 0x00).id, 1253, _OBJSIZ_0_0_0_0_0_0_0_2_);
	F1254_11734(RTCW(tr1), (EIF_INTEGER_32) (arg3 + loc4), (EIF_INTEGER_32) (arg4 + loc5));
	F922_9430(RTCW(loc1), tr1, ((EIF_INTEGER_32) 3L));
	RTHOOK(12);
	tr1 = RTLNS(eif_new_type(1253, 0x00).id, 1253, _OBJSIZ_0_0_0_0_0_0_0_2_);
	F1254_11734(RTCW(tr1), (EIF_INTEGER_32) (arg3 + loc4), (EIF_INTEGER_32) (arg4 + loc6));
	F922_9430(RTCW(loc1), tr1, ((EIF_INTEGER_32) 4L));
	RTHOOK(13);
	tr1 = RTLNS(eif_new_type(1253, 0x00).id, 1253, _OBJSIZ_0_0_0_0_0_0_0_2_);
	F1254_11734(RTCW(tr1), (EIF_INTEGER_32) (arg3 + loc3), (EIF_INTEGER_32) (arg4 + loc8));
	F922_9430(RTCW(loc1), tr1, ((EIF_INTEGER_32) 5L));
	RTHOOK(14);
	tr1 = RTLNS(eif_new_type(1253, 0x00).id, 1253, _OBJSIZ_0_0_0_0_0_0_0_2_);
	F1254_11734(RTCW(tr1), (EIF_INTEGER_32) (arg3 + loc2), (EIF_INTEGER_32) (arg4 + loc7));
	F922_9430(RTCW(loc1), tr1, ((EIF_INTEGER_32) 6L));
	RTHOOK(15);
	F1372_12627(RTCW(arg1), loc1);
	RTHOOK(16);
	RTLE;
	RTEE;
}

/* {EV_GRID_CHECKABLE_LABEL_ITEM_I}.draw_indeterminate_sign_at */
void F1758_18484 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	
	
	RTEAA("draw_indeterminate_sign_at", 1757, Current, 0, 4, 24370);
	RTHOOK(1);
	F1372_12625(RTCW(arg1), (EIF_INTEGER_32) (arg3 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (arg4 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)));
	RTHOOK(2);
	RTEE;
}

void EIF_Minit1035 (void)
{
	GTCX
	RTPOMS(18476,0,"__",2,24415);
}


#ifdef __cplusplus
}
#endif
