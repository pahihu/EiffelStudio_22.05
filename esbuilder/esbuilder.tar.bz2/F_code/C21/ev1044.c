/*
 * Code for class EV_COLOR_DIALOG_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1044.h"
#include <string.h>
#include <ev_gtk.h>
#include "eif_built_in.h"
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F219_3136
static void inline_F219_3136 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GdkRGBA *rgba = (GdkRGBA *) arg1;
rgba->blue = (arg2 & 0xFF) / 255.0;
rgba->green = ((arg2 >> 8) & 0xFF) / 255.0;
rgba->red = ((arg2 >> 16) & 0xFF) / 255.0;
rgba->alpha = 1.0;
	;
}
#define INLINE_F219_3136
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_COLOR_DIALOG_IMP}.make */
void F1767_18539 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("make", 1766, Current, 1, 0, 24404);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_1_0_1_0_0_);
	tr1 = RTMS_EX_H("Color selection dialog",22,962004583);
	F1206_10395(RTCW(loc1), tr1);
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp2 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp3 = tp2;
	tp1 = (EIF_POINTER) gtk_color_chooser_dialog_new((gchar*) tp1, (GtkWindow*) tp3);
	F1726_17949(Current, tp1);
	RTHOOK(3);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_9_5_0_1_0_0_);
	gtk_color_chooser_set_use_alpha((GtkColorChooser*) tp1, (gboolean) (EIF_BOOLEAN) 0);
	RTHOOK(4);
	F1765_18517(Current);
	RTHOOK(5);
	F1687_17117(Current, (EIF_BOOLEAN) 0);
	RTHOOK(6);
	F1765_18525(Current);
	RTHOOK(7);
	F1729_18062(Current);
	RTHOOK(8);
	F1687_17117(Current, (EIF_BOOLEAN) 1);
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {EV_COLOR_DIALOG_IMP}.color */
EIF_REFERENCE F1767_18540 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_32 tr4_1;
	EIF_REAL_32 tr4_2;
	EIF_REAL_32 tr4_3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("color", 1766, Current, 2, 0, 24405);
	RTGC;
	RTHOOK(1);
	if (F1765_18527(Current)) {
		RTHOOK(2);
		loc1 = (EIF_POINTER) calloc (sizeof(GdkRGBA), 1);
		RTHOOK(3);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_9_5_0_1_0_0_);
		gtk_color_chooser_get_rgba((GtkColorChooser*) tp1, (GdkRGBA*) loc1);
		RTHOOK(4);
		Result = RTLNS(eif_new_type(1384, 0x00).id, 1384, _OBJSIZ_2_0_0_0_0_0_0_0_);
		tr8_1 = (EIF_REAL_64) (((GdkRGBA *)loc1)->red);
		tr4_1 = (EIF_REAL_32) (tr8_1);
		tr8_1 = (EIF_REAL_64) (((GdkRGBA *)loc1)->green);
		tr4_2 = (EIF_REAL_32) (tr8_1);
		tr8_1 = (EIF_REAL_64) (((GdkRGBA *)loc1)->blue);
		tr4_3 = (EIF_REAL_32) (tr8_1);
		F1385_12790(RTCW(Result), tr4_1, tr4_2, tr4_3);
		RTHOOK(5);
		free(loc1);
	} else {
		RTHOOK(6);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTHOOK(7);
			Result = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc2);
			RTHOOK(8);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) Result;
		} else {
			RTHOOK(9);
			Result = RTLNS(eif_new_type(1384, 0x00).id, 1384, _OBJSIZ_2_0_0_0_0_0_0_0_);
			F1345_12285(RTCW(Result));
			RTHOOK(10);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) Result;
		}
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_COLOR_DIALOG_IMP}.set_color */
void F1767_18541 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_color", 1766, Current, 1, 1, 24406);
	RTGC;
	RTHOOK(1);
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	loc1 = (EIF_POINTER) calloc (sizeof(GdkRGBA), 1);
	RTHOOK(3);
	ti4_1 = F1385_12803(RTCW(arg1));
	inline_F219_3136(loc1, ti4_1);
	RTHOOK(4);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_9_5_0_1_0_0_);
	gtk_color_chooser_set_rgba((GtkColorChooser*) tp1, (GdkRGBA*) loc1);
	RTHOOK(5);
	free(loc1);
	RTHOOK(6);
	RTLE;
	RTEE;
}

void EIF_Minit1044 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
