
#ifndef _C21_ev1030_
#define _C21_ev1030_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1753_18382(EIF_REFERENCE);
extern void F1753_18383(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_POINTER F1753_18385(EIF_REFERENCE);
extern void EIF_Minit1030(void);
extern void F1345_12285(EIF_REFERENCE);
extern char *(*R14789[])();
extern char *(*R14790[])();
extern long O14791[];

#ifdef __cplusplus
}
#endif

#endif
