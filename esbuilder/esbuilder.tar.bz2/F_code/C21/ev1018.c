/*
 * Code for class EV_GRID_ROW_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1018.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GRID_ROW_I}.make */
void F1741_18182 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 1740, Current, 0, 0, 24100);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1158,1740,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1159_10177(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTHOOK(3);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(4);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_6_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(5);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(6);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_7_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(7);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(8);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_8_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(9);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(10);
	F1687_17117(Current, (EIF_BOOLEAN) 1);
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {EV_GRID_ROW_I}.flag_index_of_first_item_dirty_if_needed */
void F1741_18184 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("flag_index_of_first_item_dirty_if_needed", 1740, Current, 0, 1, 24102);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_)) {
		RTHOOK(2);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) (arg1 <= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_0_)) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_0_) == ((EIF_INTEGER_32) 0L)));
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_GRID_ROW_I}.set_index */
void F1741_18186 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	
	
	RTEAA("set_index", 1740, Current, 2, 1, 24104);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_3_) = (EIF_INTEGER_32) arg1;
	RTHOOK(5);
	RTEE;
}

/* {EV_GRID_ROW_I}.set_subrow_index */
void F1741_18187 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	
	
	RTEAA("set_subrow_index", 1740, Current, 2, 1, 24105);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_4_) = (EIF_INTEGER_32) arg1;
	RTHOOK(5);
	RTEE;
}

/* {EV_GRID_ROW_I}.set_parent_i */
void F1741_18188 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("set_parent_i", 1740, Current, 0, 2, 24106);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_8_) = (EIF_INTEGER_32) arg2;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_GRID_ROW_I}.subrow */
EIF_REFERENCE F1741_18189 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("subrow", 1740, Current, 1, 1, 24107);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	loc1 = F1147_10117(RTCW(tr1), arg1);
	RTHOOK(2);
	RTCT0("l_row /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(3);
	tr1 = F1687_17103(RTCW(loc1));
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {EV_GRID_ROW_I}.parent_row */
EIF_REFERENCE F1741_18191 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("parent_row", 1740, Current, 2, 0, 24109);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_4_);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {EV_GRID_ROW_I}.parent */
EIF_REFERENCE F1741_18192 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("parent", 1740, Current, 1, 0, 24110);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(loc1 + O13786[Dtype(loc1)-1686]);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {EV_GRID_ROW_I}.parent_row_root */
EIF_REFERENCE F1741_18193 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,loc1);
	RTLR(5,loc4);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTEAA("parent_row_root", 1740, Current, 5, 0, 24111);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tr1 = F1741_18192(Current);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tb2 = F1594_15717(loc2);
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			RTHOOK(3);
			loc1 = (EIF_REFERENCE) loc3;
			for (;;) {
				RTHOOK(4);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_10_);
				if ((EIF_BOOLEAN)(tr1 == NULL)) break;
				RTHOOK(5);
				tr2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_10_);
				loc4 = tr2;
				if (EIF_TEST(loc4)) {
					RTHOOK(6);
					loc1 = (EIF_REFERENCE) loc4;
				}
			}
			RTHOOK(7);
			tr2 = F1687_17103(RTCW(loc1));
			RTHOOK(8);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) tr2;
		} else {
			RTHOOK(9);
			RTHOOK(10);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) F1687_17103(Current);
		}
	}
	RTHOOK(12);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {EV_GRID_ROW_I}.item */
EIF_REFERENCE F1741_18194 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("item", 1740, Current, 1, 1, 24112);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = F1798_19050(loc1, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_3_));
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {EV_GRID_ROW_I}.selected_items */
EIF_REFERENCE F1741_18195 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc4);
	RTLR(3,loc3);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTEAA("selected_items", 1740, Current, 4, 0, 24113);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(2);
	loc2 = F1741_18213(Current);
	RTHOOK(3);
	{
		static EIF_TYPE_INDEX typarr0[] = {1146,1518,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 1146, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F1147_10111(RTCW(Result), loc2);
	RTHOOK(4);
	loc4 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	RTHOOK(5);
	RTCT0("temp_parent_i /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc4 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	for (;;) {
		RTHOOK(6);
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		RTHOOK(7);
		loc3 = F1798_19437(RTCW(loc4), loc1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_3_));
		RTHOOK(8);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			tb2 = F1755_18420(RTCW(loc3));
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(9);
			tr1 = F1687_17103(RTCW(loc3));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7993[Dtype(RTCW(Result))-878])(Result, tr1);
		}
		RTHOOK(10);
		loc1++;
	}
	RTHOOK(13);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_ROW_I}.height */
EIF_INTEGER_32 F1741_18197 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("height", 1740, Current, 1, 0, 24115);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_1_);
		RTHOOK(3);
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) -1L))) {
			tb2 = *(EIF_BOOLEAN *)(loc1+ _CHROFF_113_19_);
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(4);
			Result = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_113_55_10_6_);
			RTHOOK(5);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) Result;
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_ROW_I}.is_selected */
EIF_BOOLEAN F1741_18199 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("is_selected", 1740, Current, 1, 0, 24117);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tb1 = '\01';
		tb2 = F1798_19205(loc1);
		if (!tb2) {
			tb1 = (EIF_BOOLEAN)(F1741_18214(Current) == ((EIF_INTEGER_32) 0L));
		}
		if (tb1) {
			RTHOOK(3);
			RTHOOK(4);
			RTLE;
			RTEE;
			return (EIF_BOOLEAN) *(EIF_BOOLEAN *)(Current+ _CHROFF_11_2_);
		} else {
			RTHOOK(5);
			RTHOOK(6);
			RTLE;
			RTEE;
			return (EIF_BOOLEAN) F1741_18203(Current);
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) 0;
}

/* {EV_GRID_ROW_I}.is_selectable */
EIF_BOOLEAN F1741_18200 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_selectable", 1740, Current, 0, 0, 24118);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_9_) != NULL);
}

/* {EV_GRID_ROW_I}.internal_update_selection */
void F1741_18202 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTEAA("internal_update_selection", 1740, Current, 5, 1, 24120);
	RTGC;
	RTHOOK(1);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(2);
	loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_3_);
	RTHOOK(3);
	loc5 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	RTHOOK(4);
	RTCT0("a_parent_i /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc5 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(5);
	loc3 = F1741_18213(Current);
	for (;;) {
		RTHOOK(6);
		if ((EIF_BOOLEAN) (loc2 > loc3)) break;
		RTHOOK(7);
		loc1 = F1798_19437(RTCW(loc5), loc2, loc4);
		RTHOOK(8);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTHOOK(9);
			if (arg1) {
				RTHOOK(10);
				F1755_18428(RTCW(loc1));
			} else {
				RTHOOK(11);
				F1755_18429(RTCW(loc1));
			}
		}
		RTHOOK(12);
		loc2++;
	}
	RTHOOK(13);
	RTLE;
	RTEE;
}

/* {EV_GRID_ROW_I}.internal_are_all_non_void_items_selected */
EIF_BOOLEAN F1741_18203 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc6);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTEAA("internal_are_all_non_void_items_selected", 1740, Current, 6, 0, 24121);
	RTGC;
	RTHOOK(1);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(2);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	loc3 = F1741_18213(Current);
	RTHOOK(4);
	loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_3_);
	RTHOOK(5);
	loc6 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	RTHOOK(6);
	RTCT0("l_parent_i /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc6 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	for (;;) {
		RTHOOK(7);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc2 > loc3))) break;
		RTHOOK(8);
		loc1 = F1798_19437(RTCW(loc6), loc2, loc5);
		RTHOOK(9);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTHOOK(10);
			loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			RTHOOK(11);
			Result = F1755_18420(RTCW(loc1));
		}
		RTHOOK(12);
		loc2++;
	}
	RTHOOK(13);
	if ((EIF_BOOLEAN) !loc4) {
		RTHOOK(14);
		RTHOOK(15);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTHOOK(16);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_ROW_I}.virtual_y_position */
EIF_INTEGER_32 F1741_18204 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("virtual_y_position", 1740, Current, 2, 0, 24122);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc1 = tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc2 = tr1;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_3_) && EIF_TEST(loc1)) && EIF_TEST(loc2))) {
		RTHOOK(2);
		Result = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_113_55_10_16_);
		ti4_1 = *(EIF_INTEGER_32 *)(loc2+ _LNGOFF_7_0_0_0_);
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	} else {
		RTHOOK(3);
		Result = F1741_18205(Current);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) Result;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_ROW_I}.virtual_y_position_unlocked */
EIF_INTEGER_32 F1741_18205 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("virtual_y_position_unlocked", 1740, Current, 2, 0, 24123);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		F1798_19263(loc1);
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_88_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTHOOK(4);
			ti4_1 = F1151_10118(loc2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_3_));
			RTHOOK(5);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ti4_1;
		} else {
			RTHOOK(6);
			Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_3_);
			ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_113_55_10_6_);
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (Result - ((EIF_INTEGER_32) 1L)) * ti4_1);
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_ROW_I}.is_expandable */
EIF_BOOLEAN F1741_18206 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_expandable", 1740, Current, 0, 0, 24124);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	if ((EIF_BOOLEAN)(F1741_18192(Current) != NULL)) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (F1741_18209(Current) > ((EIF_INTEGER_32) 0L))) {
			tb1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_11_4_);
		}
		Result = tb1;
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_ROW_I}.hash_code */
EIF_INTEGER_32 F1741_18207 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_8_);
}


/* {EV_GRID_ROW_I}.subrow_count */
EIF_INTEGER_32 F1741_18209 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("subrow_count", 1740, Current, 1, 0, 24127);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	Result = F1147_10132(RTCW(tr1));
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_ROW_I}.count */
EIF_INTEGER_32 F1741_18213 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("count", 1740, Current, 1, 0, 24131);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_86_);
		Result = F1147_10132(RTCW(tr1));
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_ROW_I}.index_of_first_item */
EIF_INTEGER_32 F1741_18214 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("index_of_first_item", 1740, Current, 0, 0, 24132);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_)) {
		RTHOOK(2);
		ti4_1 = F1741_18215(Current);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_0_) = (EIF_INTEGER_32) ti4_1;
		RTHOOK(3);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_11_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTHOOK(4);
	RTHOOK(5);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_0_);
}

/* {EV_GRID_ROW_I}.index_of_first_item_value */
EIF_INTEGER_32 F1741_18215 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc9);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,loc5);
	RTLR(5,loc4);
	RTLR(6,loc6);
	RTLIU(7);
	
	RTEAA("index_of_first_item_value", 1740, Current, 9, 0, 24133);
	RTGC;
	RTHOOK(1);
	loc9 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	RTHOOK(2);
	RTCT0("l_parent_i /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc9 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc9) + _REFACS_84_);
	loc2 = F1147_10118(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_3_));
	RTHOOK(4);
	RTCT0("current_row_list /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc9) + _REFACS_86_);
	loc5 = F1147_10115(RTCW(tr1));
	RTHOOK(6);
	loc3 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc2);
	RTHOOK(7);
	loc8 = F1741_18213(Current);
	RTHOOK(8);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		RTHOOK(9);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc4 != NULL) || (EIF_BOOLEAN)(loc1 == loc8))) break;
		RTHOOK(10);
		/* INLINED CODE (SPECIAL.item) */
		tr1 = *((EIF_REFERENCE *)RTCW(loc5) + (loc1));
		/* END INLINED CODE */
		loc6 = tr1;
		RTHOOK(11);
		if ((EIF_BOOLEAN)(loc6 != NULL)) {
			RTHOOK(12);
			loc7 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_9_4_0_1_);
		}
		RTHOOK(13);
		if ((EIF_BOOLEAN) (loc7 < loc3)) {
			RTHOOK(14);
			/* INLINED CODE (SPECIAL.item) */
			tr1 = *((EIF_REFERENCE *)RTCW(loc2) + (loc7));
			/* END INLINED CODE */
			loc4 = tr1;
		}
		RTHOOK(15);
		loc1++;
	}
	RTHOOK(16);
	if ((EIF_BOOLEAN)(loc4 != NULL)) {
		RTHOOK(17);
		RTHOOK(18);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) loc1;
	}
	RTHOOK(20);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) 0;
}

/* {EV_GRID_ROW_I}.unlock */
void F1741_18221 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("unlock", 1740, Current, 1, 0, 24139);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc1 = tr1;
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_3_) && EIF_TEST(loc1))) {
		RTHOOK(2);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_11_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		RTHOOK(3);
		F1798_19089(loc1, Current);
		RTHOOK(4);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) NULL;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_GRID_ROW_I}.expand */
void F1741_18222 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTEAA("expand", 1740, Current, 1, 0, 24140);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_)) {
		RTHOOK(2);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(3);
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		RTHOOK(4);
		RTCT0("l_parent_i /= Void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		RTHOOK(5);
		if ((EIF_BOOLEAN) (F1741_18209(Current) > ((EIF_INTEGER_32) 0L))) {
			RTHOOK(6);
			ti4_1 = F1741_18264(Current);
			F1741_18260(Current, ti4_1);
			RTHOOK(7);
			if (F1741_18265(Current)) {
				RTHOOK(8);
				F1798_19261(RTCW(loc1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_3_));
			}
		}
		RTHOOK(9);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_41_);
		if ((EIF_BOOLEAN)(tr1 != NULL)) {
			RTHOOK(10);
			tr1 = F1246_11579(RTCW(loc1));
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0,0xFFFF};
				EIF_TYPE typres0;
				{
					EIF_TYPE l_type;
					l_type = eif_final_id(Y13786,Y13786_gen_type,Dftype(Current),1686);
					typarr0[3] = l_type.annotations | 0xFF00;
					typarr0[4] = l_type.id;
				}
				
				typres0 = eif_compound_id(Dftype(Current), typarr0);
				tr2 = RTLNTS(typres0.id, 2, 0);
			}
			tr3 = F1687_17103(Current);
			((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
			RTAR(tr2,tr3);
			F1177_10288(RTCW(tr1), tr2);
		}
		RTHOOK(11);
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_2_) != NULL)) {
			RTHOOK(12);
			tr1 = F140_2042(Current);
			F1177_10288(RTCW(tr1), NULL);
		}
		RTHOOK(13);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_4_)) {
			RTHOOK(14);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_11_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			RTHOOK(15);
			ti4_1 = F1741_18209(Current);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
		}
		RTHOOK(16);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTHOOK(17);
			F1798_19183(RTCW(loc1));
		}
	}
	RTHOOK(20);
	RTLE;
	RTEE;
}

/* {EV_GRID_ROW_I}.collapse */
void F1741_18223 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTEAA("collapse", 1740, Current, 1, 0, 24141);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_)) {
		RTHOOK(2);
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		RTHOOK(3);
		RTCT0("l_parent_i /= Void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		RTHOOK(4);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		RTHOOK(5);
		F1741_18260(Current, (EIF_INTEGER_32) -F1741_18264(Current));
		RTHOOK(6);
		if (F1741_18265(Current)) {
			RTHOOK(7);
			F1798_19261(RTCW(loc1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_3_));
		}
		RTHOOK(8);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_42_);
		if ((EIF_BOOLEAN)(tr1 != NULL)) {
			RTHOOK(9);
			tr1 = F1246_11580(RTCW(loc1));
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0,0xFFFF};
				EIF_TYPE typres0;
				{
					EIF_TYPE l_type;
					l_type = eif_final_id(Y13786,Y13786_gen_type,Dftype(Current),1686);
					typarr0[3] = l_type.annotations | 0xFF00;
					typarr0[4] = l_type.id;
				}
				
				typres0 = eif_compound_id(Dftype(Current), typarr0);
				tr2 = RTLNTS(typres0.id, 2, 0);
			}
			tr3 = F1687_17103(Current);
			((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
			RTAR(tr2,tr3);
			F1177_10288(RTCW(tr1), tr2);
		}
		RTHOOK(10);
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_3_) != NULL)) {
			RTHOOK(11);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1177_10288(RTCW(tr1), NULL);
		}
		RTHOOK(12);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTHOOK(13);
			F1798_19183(RTCW(loc1));
		}
	}
	RTHOOK(16);
	RTLE;
	RTEE;
}

/* {EV_GRID_ROW_I}.set_height */
void F1741_18224 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_height", 1740, Current, 2, 1, 24142);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_1_) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTHOOK(3);
		F1798_19261(loc2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_3_));
		RTHOOK(4);
		F1798_19183(loc2);
		RTHOOK(5);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_3_)) {
			RTHOOK(6);
			F1798_19370(loc2, Current);
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EV_GRID_ROW_I}.ensure_visible */
void F1741_18225 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("ensure_visible", 1740, Current, 5, 0, 24143);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTHOOK(2);
		F1798_19320(loc3);
		RTHOOK(3);
		F1798_19317(loc3);
		RTHOOK(4);
		loc1 = F1741_18204(Current);
		RTHOOK(5);
		loc2 = F1741_18197(Current);
		RTHOOK(6);
		tb1 = '\01';
		ti4_1 = F1798_19073(loc3);
		if (!(EIF_BOOLEAN) (loc1 < ti4_1)) {
			ti4_1 = *(EIF_INTEGER_32 *)(loc3+ _LNGOFF_113_55_10_9_);
			tb1 = (EIF_BOOLEAN) (loc2 >= ti4_1);
		}
		if (tb1) {
			RTHOOK(7);
			ti4_1 = F1798_19072(loc3);
			F1798_19165(loc3, ti4_1, loc1);
		} else {
			RTHOOK(8);
			ti4_1 = F1798_19073(loc3);
			ti4_2 = *(EIF_INTEGER_32 *)(loc3+ _LNGOFF_113_55_10_9_);
			if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + loc2) > (EIF_INTEGER_32) (ti4_1 + ti4_2))) {
				RTHOOK(9);
				ti4_1 = F1798_19072(loc3);
				ti4_2 = *(EIF_INTEGER_32 *)(loc3+ _LNGOFF_113_55_10_9_);
				F1798_19165(loc3, ti4_1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + loc2) - ti4_2));
			}
		}
	}
	RTHOOK(13);
	RTLE;
	RTEE;
}

/* {EV_GRID_ROW_I}.enable_select */
void F1741_18241 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTEAA("enable_select", 1740, Current, 1, 0, 24159);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !F1741_18199(Current)) {
		RTHOOK(2);
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		RTHOOK(3);
		RTCT0("l_parent_i /= Void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		RTHOOK(4);
		tb1 = '\01';
		tb2 = F1798_19205(RTCW(loc1));
		if (!tb2) {
			tb1 = (EIF_BOOLEAN)(F1741_18214(Current) == ((EIF_INTEGER_32) 0L));
		}
		if (tb1) {
			RTHOOK(5);
			tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_113_35_);
			if (tb1) {
				RTHOOK(6);
				F1798_19057(RTCW(loc1));
			}
			RTHOOK(7);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_11_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			RTHOOK(8);
			F1798_19427(RTCW(loc1), Current);
			RTHOOK(9);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_31_);
			if ((EIF_BOOLEAN)(tr1 != NULL)) {
				RTHOOK(10);
				tr1 = F1246_11575(RTCW(loc1));
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0,0xFFFF};
					EIF_TYPE typres0;
					{
						EIF_TYPE l_type;
						l_type = eif_final_id(Y13786,Y13786_gen_type,Dftype(Current),1686);
						typarr0[3] = l_type.annotations | 0xFF00;
						typarr0[4] = l_type.id;
					}
					
					typres0 = eif_compound_id(Dftype(Current), typarr0);
					tr2 = RTLNTS(typres0.id, 2, 0);
				}
				tr3 = F1687_17103(Current);
				((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
				RTAR(tr2,tr3);
				F1177_10288(RTCW(tr1), tr2);
			}
			RTHOOK(11);
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) != NULL)) {
				RTHOOK(12);
				tr1 = *(EIF_REFERENCE *)(Current);
				F1177_10288(RTCW(tr1), NULL);
			}
		} else {
			RTHOOK(13);
			F1741_18202(Current, (EIF_BOOLEAN) 1);
		}
		RTHOOK(14);
		F1798_19284(RTCW(loc1), Current);
	}
	RTHOOK(15);
	RTLE;
	RTEE;
}

/* {EV_GRID_ROW_I}.disable_select */
void F1741_18242 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTEAA("disable_select", 1740, Current, 2, 0, 24160);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb2 = '\01';
		tb3 = F1798_19205(loc1);
		if (!tb3) {
			tb2 = (EIF_BOOLEAN)(F1741_18214(Current) == ((EIF_INTEGER_32) 0L));
		}
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(2);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_2_)) {
			RTHOOK(3);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_11_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			RTHOOK(4);
			F1798_19429(loc1, Current);
			RTHOOK(5);
			tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_33_);
			if ((EIF_BOOLEAN)(tr1 != NULL)) {
				RTHOOK(6);
				tr1 = F1246_11576(loc1);
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0,0xFFFF};
					EIF_TYPE typres0;
					{
						EIF_TYPE l_type;
						l_type = eif_final_id(Y13786,Y13786_gen_type,dftype,1686);
						typarr0[3] = l_type.annotations | 0xFF00;
						typarr0[4] = l_type.id;
					}
					
					typres0 = eif_compound_id(dftype, typarr0);
					tr2 = RTLNTS(typres0.id, 2, 0);
				}
				tr3 = F1687_17103(Current);
				((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
				RTAR(tr2,tr3);
				F1177_10288(RTCW(tr1), tr2);
			}
			RTHOOK(7);
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) != NULL)) {
				RTHOOK(8);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,65534,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr2 = RTLNTS(typres0.id, 2, 0);
				}
				F1177_10288(RTCW(tr1), tr2);
			}
		}
	} else {
		RTHOOK(9);
		F1741_18202(Current, (EIF_BOOLEAN) 0);
	}
	RTHOOK(10);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTHOOK(11);
		F1798_19284(loc2, Current);
	}
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {EV_GRID_ROW_I}.destroy */
void F1741_18243 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("destroy", 1740, Current, 1, 0, 24161);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		F1798_19243(loc1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_3_));
	}
	RTHOOK(3);
	F1687_17118(Current, (EIF_BOOLEAN) 1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_GRID_ROW_I}.clear */
void F1741_18244 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLIU(2);
	
	RTEAA("clear", 1740, Current, 3, 0, 24162);
	RTGC;
	RTHOOK(1);
	loc1 = F1741_18213(Current);
	RTHOOK(2);
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	RTHOOK(3);
	RTCT0("a_parent_i /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(4);
	loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_3_);
	for (;;) {
		RTHOOK(5);
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) break;
		RTHOOK(6);
		F1798_19434(RTCW(loc2), loc1, loc3, NULL);
		RTHOOK(7);
		loc1--;
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {EV_GRID_ROW_I}.update_for_item_removal */
void F1741_18245 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("update_for_item_removal", 1740, Current, 1, 1, 24163);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tb2 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb3 = *(EIF_BOOLEAN *)(loc1+ _CHROFF_113_34_);
		tb2 = tb3;
	}
	if (tb2) {
		tb1 = (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_10_) != NULL);
	}
	if (tb1) {
		RTHOOK(2);
		F1741_18250(Current);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_GRID_ROW_I}.update_for_removal */
void F1741_18246 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("update_for_removal", 1740, Current, 1, 0, 24164);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_3_)) {
		RTHOOK(2);
		F1741_18221(Current);
	}
	RTHOOK(3);
	F1741_18244(Current);
	RTHOOK(4);
	F1741_18242(Current);
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(6);
		F1741_18247(loc1, Current);
	}
	RTHOOK(7);
	F1741_18263(Current);
	RTHOOK(8);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) NULL;
	RTHOOK(9);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(10);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(14);
	RTLE;
	RTEE;
}

/* {EV_GRID_ROW_I}.update_for_subrow_removal */
void F1741_18247 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("update_for_subrow_removal", 1740, Current, 0, 1, 24165);
	RTGC;
	RTHOOK(1);
	F1741_18259(Current, ((EIF_INTEGER_32) -1L));
	RTHOOK(2);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_)) {
		RTHOOK(3);
		F1741_18260(Current, ((EIF_INTEGER_32) -1L));
	}
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_11_7_0_4_);
	F1147_10166(RTCW(tr1), ti4_1);
	RTHOOK(5);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_11_7_0_4_);
	F1741_18248(Current, ti4_1);
	RTHOOK(6);
	if ((EIF_BOOLEAN)(F1741_18209(Current) == ((EIF_INTEGER_32) 0L))) {
		RTHOOK(7);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_11_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {EV_GRID_ROW_I}.update_subrow_indices */
void F1741_18248 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLIU(3);
	
	RTEAA("update_subrow_indices", 1740, Current, 4, 1, 24166);
	RTGC;
	RTHOOK(1);
	loc4 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	RTHOOK(2);
	loc1 = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	loc2 = F1147_10132(RTCW(loc4));
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		RTHOOK(5);
		loc3 = F1147_10118(RTCW(loc4), loc1);
		RTHOOK(6);
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			RTHOOK(7);
			F1741_18187(RTCW(loc3), loc1);
		}
		RTHOOK(8);
		loc1++;
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {EV_GRID_ROW_I}.update_depths_in_tree */
void F1741_18250 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("update_depths_in_tree", 1740, Current, 1, 0, 24168);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_11_7_0_5_);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_5_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L));
		RTHOOK(3);
		ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_11_7_0_6_);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_6_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L));
	} else {
		RTHOOK(4);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		RTHOOK(5);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_6_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_GRID_ROW_I}.set_subrow_count_recursive */
void F1741_18256 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_subrow_count_recursive", 1740, Current, 0, 1, 24086);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_2_) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {EV_GRID_ROW_I}.set_expanded_subrow_count_recursive */
void F1741_18257 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_expanded_subrow_count_recursive", 1740, Current, 0, 1, 24087);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_7_) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {EV_GRID_ROW_I}.update_parent_node_counts_recursively */
void F1741_18259 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("update_parent_node_counts_recursively", 1740, Current, 1, 1, 24089);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_REFERENCE) Current;
	for (;;) {
		RTHOOK(2);
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		
		RTHOOK(4);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_11_7_0_2_);
		F1741_18256(RTCW(loc1), (EIF_INTEGER_32) (ti4_1 + arg1));
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_10_);
		loc1 = (EIF_REFERENCE) tr1;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_GRID_ROW_I}.update_parent_expanded_node_counts_recursively */
void F1741_18260 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("update_parent_expanded_node_counts_recursively", 1740, Current, 1, 1, 24090);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_REFERENCE) Current;
	for (;;) {
		RTHOOK(2);
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(loc1 == NULL)) {
			tb2 = '\0';
			if ((EIF_BOOLEAN)(loc1 != Current)) {
				tb3 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_11_1_);
				tb2 = (EIF_BOOLEAN) !tb3;
			}
			tb1 = tb2;
		}
		if (tb1) break;
		
		RTHOOK(4);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_11_7_0_7_);
		F1741_18257(RTCW(loc1), (EIF_INTEGER_32) (ti4_1 + arg1));
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_10_);
		loc1 = (EIF_REFERENCE) tr1;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_GRID_ROW_I}.unparent */
void F1741_18263 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("unparent", 1740, Current, 0, 0, 24093);
	RTGC;
	RTHOOK(1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) NULL;
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_7_0_8_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_GRID_ROW_I}.contained_expanded_items_recursive */
EIF_INTEGER_32 F1741_18264 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTEAA("contained_expanded_items_recursive", 1740, Current, 3, 0, 24094);
	RTGC;
	RTHOOK(1);
	loc3 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	RTHOOK(2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) (loc1 > F1741_18209(Current))) break;
		RTHOOK(4);
		Result++;
		RTHOOK(5);
		loc2 = F1147_10117(RTCW(loc3), loc1);
		RTHOOK(6);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			RTHOOK(7);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_11_7_0_7_);
			Result += ti4_1;
		}
		RTHOOK(8);
		loc1++;
	}
	RTHOOK(10);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_ROW_I}.displayed_in_grid_tree */
EIF_BOOLEAN F1741_18265 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("displayed_in_grid_tree", 1740, Current, 1, 0, 24095);
	RTGC;
	RTHOOK(1);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	for (;;) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == NULL) || (EIF_BOOLEAN) !Result)) break;
		
		RTHOOK(5);
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_11_1_);
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(6);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
		RTHOOK(7);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_10_);
		loc1 = (EIF_REFERENCE) tr1;
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit1018 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
