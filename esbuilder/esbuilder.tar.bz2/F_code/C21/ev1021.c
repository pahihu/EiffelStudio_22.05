/*
 * Code for class EV_ITEM_PIXMAP_SCALER_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1021.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_ITEM_PIXMAP_SCALER_I}.set_pixmaps_size */
void F1744_18328 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_pixmaps_size", 1743, Current, 0, 2, 24235);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O14748[dtype-1743]) != arg1) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O14749[dtype-1743]) != arg2))) {
		RTHOOK(2);
		*(EIF_INTEGER_32 *)(Current + O14748[dtype-1743]) = (EIF_INTEGER_32) arg1;
		RTHOOK(3);
		*(EIF_INTEGER_32 *)(Current + O14749[dtype-1743]) = (EIF_INTEGER_32) arg2;
		RTHOOK(4);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14751[dtype-1791])(Current);
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_ITEM_PIXMAP_SCALER_I}.initialize_pixmaps */
void F1744_18330 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("initialize_pixmaps", 1743, Current, 0, 0, 24236);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O14748[dtype-1743]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16L);
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current + O14749[dtype-1743]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16L);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit1021 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
