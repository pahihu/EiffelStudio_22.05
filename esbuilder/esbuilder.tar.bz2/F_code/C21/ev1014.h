
#ifndef _C21_ev1014_
#define _C21_ev1014_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1737_18156(EIF_REFERENCE);
extern void F1737_18158(EIF_REFERENCE);
extern void F1737_18159(EIF_REFERENCE);
extern void EIF_Minit1014(void);
extern char *(*R14608[])();
extern char *(*R14609[])();
extern char *(*R14610[])();
extern char *(*R14611[])();
extern char *(*R14612[])();
extern long O14605[];

#ifdef __cplusplus
}
#endif

#endif
