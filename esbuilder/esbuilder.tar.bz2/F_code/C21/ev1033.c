/*
 * Code for class EV_GRID_DRAWABLE_ITEM_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1033.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GRID_DRAWABLE_ITEM_I}.required_width */
EIF_INTEGER_32 F1756_18448 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("required_width", 1755, Current, 0, 0, 24339);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_22_3_0_1_);
}

/* {EV_GRID_DRAWABLE_ITEM_I}.perform_redraw */
void F1756_18450 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_REFERENCE arg6)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,arg6);
	RTLIU(6);
	
	RTEAA("perform_redraw", 1755, Current, 2, 6, 24341);
	RTGC;
	RTHOOK(1);
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	RTHOOK(2);
	RTCT0("l_parent_i /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(3);
	tr1 = F1798_19367(RTCW(loc2));
	loc1 = RTOSCF(11501,F1242_11501, (RTCW(tr1)));
	RTHOOK(4);
	tb1 = '\01';
	ti4_1 = F1362_12530(RTCW(loc1));
	if (!(EIF_BOOLEAN) (ti4_1 < arg3)) {
		ti4_1 = F1362_12531(RTCW(loc1));
		tb1 = (EIF_BOOLEAN) (ti4_1 < arg4);
	}
	if (tb1) {
		RTHOOK(5);
		F1686_17088(RTCW(loc1), arg3, arg4);
	}
	RTHOOK(6);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_21_) != NULL)) {
		RTHOOK(7);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,1685,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr2 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = loc1;
		RTAR(tr2,loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8518[Dtype(RTCW(tr1))-1175])(tr1, tr2);
	}
	RTHOOK(8);
	tr1 = RTOSCF(18438,F1755_18438, (Current));
	F1255_11788(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), arg3, arg4);
	RTHOOK(9);
	tr1 = RTOSCF(18438,F1755_18438, (Current));
	F1372_12618(RTCW(arg6), arg5, ((EIF_INTEGER_32) 0L), loc1, tr1);
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {EV_GRID_DRAWABLE_ITEM_I}.expose_actions */
EIF_REFERENCE F1756_18452 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("expose_actions", 1755, Current, 0, 0, 24343);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_21_) == NULL)) {
		RTHOOK(2);
		tr1 = F1756_18453(Current);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(3);
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_21_);
}

/* {EV_GRID_DRAWABLE_ITEM_I}.create_expose_actions */
EIF_REFERENCE F1756_18453 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_expose_actions", 1755, Current, 0, 0, 24344);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1176,0xFFF9,1,1419,1371,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1176, _OBJSIZ_9_2_0_2_0_0_0_0_);
	}
	F1176_10251(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

void EIF_Minit1033 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
