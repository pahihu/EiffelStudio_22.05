/*
 * Code for class EV_GRID_LABEL_ITEM_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1034.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GRID_LABEL_ITEM_I}.make */
void F1757_18456 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make", 1756, Current, 0, 0, 24347);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O14847[Dtype(Current)-1756]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	F1755_18398(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_GRID_LABEL_ITEM_I}.required_width */
EIF_INTEGER_32 F1757_18457 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("required_width", 1756, Current, 2, 0, 24348);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		Result = F1521_14815(loc1);
		ti4_1 = F1757_18458(Current);
		ti4_2 = *(EIF_INTEGER_32 *)(loc1 + O11915[Dtype(loc1)-1520]);
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (Result + ti4_1) + ti4_2);
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_5_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTHOOK(4);
			ti4_1 = F1362_12530(loc2);
			ti4_2 = *(EIF_INTEGER_32 *)(loc1 + O11918[Dtype(loc1)-1520]);
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (Result + ti4_1) + ti4_2);
		}
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_LABEL_ITEM_I}.text_width */
EIF_INTEGER_32 F1757_18458 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("text_width", 1756, Current, 0, 0, 24349);
	RTGC;
	RTHOOK(1);
	F1757_18465(Current);
	RTHOOK(2);
	RTHOOK(3);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current + O14845[Dtype(Current)-1756]);
}

/* {EV_GRID_LABEL_ITEM_I}.text_height */
EIF_INTEGER_32 F1757_18459 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("text_height", 1756, Current, 0, 0, 24350);
	RTGC;
	RTHOOK(1);
	F1757_18465(Current);
	RTHOOK(2);
	RTHOOK(3);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current + O14846[Dtype(Current)-1756]);
}

/* {EV_GRID_LABEL_ITEM_I}.string_size_changed */
void F1757_18460 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("string_size_changed", 1756, Current, 0, 0, 24351);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O14847[Dtype(Current)-1756]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	RTEE;
}

/* {EV_GRID_LABEL_ITEM_I}.internal_default_font */
static EIF_REFERENCE F1757_18461_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("internal_default_font", 1756, Current, 0, 0, 24352);
	RTGC;
	RTOSP (18461);
#define Result RTOSR(18461)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1351, 0x00).id, 1351, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1345_12285(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (18461);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1757_18461 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(18461,F1757_18461_body,(Current));
}

/* {EV_GRID_LABEL_ITEM_I}.recompute_text_dimensions */
void F1757_18465 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc6);
	RTLR(6,loc1);
	RTLIU(7);
	
	RTEAA("recompute_text_dimensions", 1756, Current, 6, 0, 24356);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current + O14847[dtype-1756])) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			RTHOOK(3);
			loc2 = *(EIF_REFERENCE *)(loc5 + _REFACS_3_);
			RTHOOK(4);
			tb1 = F835_9290(RTCW(loc2));
			if (tb1) {
				RTHOOK(5);
				loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				RTHOOK(6);
				loc2 = RTMS32_EX_H(" \000\000\000",1,32);
			}
			RTHOOK(7);
			loc3 = *(EIF_REFERENCE *)(loc5 + _REFACS_4_);
			RTHOOK(8);
			if ((EIF_BOOLEAN)(loc3 == NULL)) {
				RTHOOK(9);
				loc3 = RTOSCF(18461,F1757_18461, (Current));
			}
			RTHOOK(10);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
			loc6 = tr1;
			if (EIF_TEST(loc6)) {
				RTHOOK(11);
				loc1 = RTOSCF(18466,F1757_18466, (Current));
				RTHOOK(12);
				F1807_19562(loc6, loc2, loc3, loc1);
			} else {
				RTHOOK(13);
				loc1 = F1352_12426(RTCW(loc3), loc2);
			}
			RTHOOK(14);
			if (loc4) {
				RTHOOK(15);
				*(EIF_INTEGER_32 *)(Current + O14845[dtype-1756]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			} else {
				RTHOOK(16);
				ti4_1 = eif_integer_32_item(RTCW(loc1),1);
				*(EIF_INTEGER_32 *)(Current + O14845[dtype-1756]) = (EIF_INTEGER_32) ti4_1;
			}
			RTHOOK(17);
			ti4_1 = eif_integer_32_item(RTCW(loc1),2);
			*(EIF_INTEGER_32 *)(Current + O14846[dtype-1756]) = (EIF_INTEGER_32) ti4_1;
		}
	}
	RTHOOK(18);
	*(EIF_BOOLEAN *)(Current + O14847[dtype-1756]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(20);
	RTLE;
	RTEE;
}

/* {EV_GRID_LABEL_ITEM_I}.text_dimensions */
static EIF_REFERENCE F1757_18466_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("text_dimensions", 1756, Current, 0, 0, 24357);
	RTGC;
	RTOSP (18466);
#define Result RTOSR(18466)
	RTOC_NEW(Result);
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1419,1425,1425,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNTS(typres0.id, 3, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_i4 = ((EIF_INTEGER_32) 0L);
	((EIF_TYPED_VALUE *)tr1+2)->it_i4 = ((EIF_INTEGER_32) 0L);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (18466);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1757_18466 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(18466,F1757_18466_body,(Current));
}

/* {EV_GRID_LABEL_ITEM_I}.perform_redraw */
void F1757_18467 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_REFERENCE arg6)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc12 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc13 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc14 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc15 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc16 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc17 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc18 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc22 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc23 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc24 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(11);
	RTLR(0,loc20);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc21);
	RTLR(4,loc22);
	RTLR(5,arg6);
	RTLR(6,loc23);
	RTLR(7,loc19);
	RTLR(8,loc24);
	RTLR(9,loc2);
	RTLR(10,loc1);
	RTLIU(11);
	
	RTEAA("perform_redraw", 1756, Current, 24, 6, 24358);
	RTGC;
	RTHOOK(1);
	RTCT0("attached interface as l_interface and attached parent_i as l_parent_i and attached column_i as l_column_i", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	loc20 = tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	loc21 = tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
	loc22 = tr1;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (EIF_TEST(loc20) && EIF_TEST(loc21)) && EIF_TEST(loc22))) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(2);
	F1372_12605(RTCW(arg6));
	RTHOOK(3);
	F1757_18465(Current);
	RTHOOK(4);
	loc15 = *(EIF_BOOLEAN *)(loc21+ _CHROFF_113_40_);
	RTHOOK(5);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(loc21 + _REFACS_78_);
	if ((EIF_BOOLEAN)(tr1 == loc20)) {
		tr1 = *(EIF_REFERENCE *)(loc21 + _REFACS_77_);
		loc23 = tr1;
		tb1 = EIF_TEST(loc23);
	}
	if (tb1) {
		RTHOOK(6);
		loc16 = F1575_15186(loc23);
	}
	RTHOOK(7);
	loc19 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R11935[Dtype(loc20)-1520])(loc20, arg3, arg4);
	RTHOOK(8);
	tr1 = *(EIF_REFERENCE *)(loc20 + _REFACS_6_);
	loc24 = tr1;
	if (EIF_TEST(loc24)) {
		RTHOOK(9);
		(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(loc24+ _PTROFF_4_2_0_3_0_0_))(
			*(EIF_POINTER *)(loc24+ _PTROFF_4_2_0_3_0_1_),
			*(EIF_REFERENCE *)(loc24 + _REFACS_1_), loc20, loc19);
	}
	RTHOOK(10);
	loc7 = *(EIF_INTEGER_32 *)(RTCW(loc19)+ _LNGOFF_0_1_0_4_);
	RTHOOK(11);
	loc8 = *(EIF_INTEGER_32 *)(RTCW(loc19)+ _LNGOFF_0_1_0_5_);
	RTHOOK(12);
	loc9 = *(EIF_INTEGER_32 *)(RTCW(loc19)+ _LNGOFF_0_1_0_0_);
	RTHOOK(13);
	loc10 = *(EIF_INTEGER_32 *)(RTCW(loc19)+ _LNGOFF_0_1_0_1_);
	RTHOOK(14);
	loc3 = F1521_14815(loc20);
	RTHOOK(15);
	loc4 = *(EIF_INTEGER_32 *)(loc20 + O11915[Dtype(loc20)-1520]);
	RTHOOK(16);
	loc5 = *(EIF_INTEGER_32 *)(loc20 + O11916[Dtype(loc20)-1520]);
	RTHOOK(17);
	loc6 = *(EIF_INTEGER_32 *)(loc20 + O11917[Dtype(loc20)-1520]);
	RTHOOK(18);
	loc2 = *(EIF_REFERENCE *)(loc20 + _REFACS_5_);
	RTHOOK(19);
	F1372_12629(RTCW(arg6));
	RTHOOK(20);
	loc1 = F1755_18442(Current);
	RTHOOK(21);
	F1360_12513(RTCW(arg6), loc1);
	RTHOOK(22);
	tb1 = '\0';
	if (F1755_18420(Current)) {
		tb1 = (EIF_BOOLEAN) !loc16;
	}
	if (tb1) {
		RTHOOK(23);
		if (loc15) {
			RTHOOK(24);
			tr1 = *(EIF_REFERENCE *)(loc21 + _REFACS_80_);
			F1360_12513(RTCW(arg6), tr1);
		} else {
			RTHOOK(25);
			tr1 = *(EIF_REFERENCE *)(loc21 + _REFACS_81_);
			F1360_12513(RTCW(arg6), tr1);
		}
		RTHOOK(26);
		tb1 = F1521_14832(loc20);
		if (tb1) {
			RTHOOK(27);
			loc11 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			RTHOOK(28);
			loc13 = (EIF_INTEGER_32) arg3;
			RTHOOK(29);
			loc12 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			RTHOOK(30);
			loc14 = (EIF_INTEGER_32) arg4;
		} else {
			RTHOOK(31);
			loc11 = (EIF_INTEGER_32) loc7;
			RTHOOK(32);
			loc13 = *(EIF_INTEGER_32 *)(Current + O14845[dtype-1756]);
			loc13 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc13 + ((EIF_INTEGER_32) 2L));
			RTHOOK(33);
			loc12 = (EIF_INTEGER_32) loc8;
			RTHOOK(34);
			loc14 = *(EIF_INTEGER_32 *)(Current + O14846[dtype-1756]);
		}
		RTHOOK(35);
		F1372_12625(RTCW(arg6), (EIF_INTEGER_32) (loc11 + arg5), loc12, loc13, loc14);
		RTHOOK(36);
		if (loc15) {
			RTHOOK(37);
			tr1 = *(EIF_REFERENCE *)(loc21 + _REFACS_82_);
			F1360_12513(RTCW(arg6), tr1);
		} else {
			RTHOOK(38);
			tr1 = *(EIF_REFERENCE *)(loc21 + _REFACS_83_);
			F1360_12513(RTCW(arg6), tr1);
		}
		RTHOOK(39);
		F1372_12629(RTCW(arg6));
	} else {
		RTHOOK(40);
		tr1 = F1755_18443(Current);
		F1360_12513(RTCW(arg6), tr1);
	}
	RTHOOK(41);
	loc17 = F1742_18279(loc22);
	loc17 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc17 - loc4);
	RTHOOK(42);
	loc18 = F1755_18407(Current);
	loc18 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc18 - loc6);
	RTHOOK(43);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc17 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (loc18 > ((EIF_INTEGER_32) 0L)))) {
		RTHOOK(44);
		tr1 = RTOSCF(18438,F1755_18438, (Current));
		ti4_1 = F1742_18279(loc22);
		ti4_2 = F1755_18407(Current);
		F1255_11788(RTCW(tr1), loc3, loc5, (EIF_INTEGER_32) (ti4_1 - loc4), (EIF_INTEGER_32) (ti4_2 - loc6));
		RTHOOK(45);
		tr1 = RTOSCF(18438,F1755_18438, (Current));
		F1372_12597(RTCW(arg6), tr1);
		RTHOOK(46);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R14850[dtype-1756])(Current, arg6, loc19, arg5);
		RTHOOK(47);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			RTHOOK(48);
			F1372_12617(RTCW(arg6), (EIF_INTEGER_32) (loc9 + arg5), loc10, loc2);
		}
		RTHOOK(49);
		tr1 = *(EIF_REFERENCE *)(loc20 + _REFACS_3_);
		F1757_18469(Current, tr1, arg6, loc19, arg5);
		RTHOOK(50);
		F1372_12599(RTCW(arg6));
		RTHOOK(51);
		F1372_12629(RTCW(arg6));
	}
	RTHOOK(52);
	F1372_12606(RTCW(arg6));
	RTHOOK(53);
	RTLE;
	RTEE;
}

/* {EV_GRID_LABEL_ITEM_I}.draw_additional */
void F1757_18468 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("draw_additional", 1756, Current, 0, 3, 24359);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {EV_GRID_LABEL_ITEM_I}.draw_text */
void F1757_18469 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,arg2);
	RTLR(5,arg3);
	RTLR(6,arg1);
	RTLIU(7);
	
	RTEAA("draw_text", 1756, Current, 2, 4, 24360);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_4_);
		loc2 = tr1;
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		RTHOOK(2);
		F1371_12585(RTCW(arg2), loc2);
	} else {
		RTHOOK(3);
		tr1 = RTOSCF(18461,F1757_18461, (Current));
		F1371_12585(RTCW(arg2), tr1);
	}
	RTHOOK(4);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg3)+ _LNGOFF_0_1_0_6_);
	if ((EIF_BOOLEAN) (ti4_1 < *(EIF_INTEGER_32 *)(Current + O14845[Dtype(Current)-1756]))) {
		RTHOOK(5);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg3)+ _LNGOFF_0_1_0_4_);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg3)+ _LNGOFF_0_1_0_5_);
		ti4_3 = *(EIF_INTEGER_32 *)(RTCW(arg3)+ _LNGOFF_0_1_0_6_);
		ti4_3 = eif_max_int32 (ti4_3,((EIF_INTEGER_32) 1L));
		F1372_12614(RTCW(arg2), (EIF_INTEGER_32) (ti4_1 + arg4), ti4_2, arg1, ti4_3);
	} else {
		RTHOOK(6);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg3)+ _LNGOFF_0_1_0_4_);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg3)+ _LNGOFF_0_1_0_5_);
		F1372_12612(RTCW(arg2), (EIF_INTEGER_32) (ti4_1 + arg4), ti4_2, arg1);
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

void EIF_Minit1034 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
