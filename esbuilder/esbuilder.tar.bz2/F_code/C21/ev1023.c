/*
 * Code for class EV_TOOLTIPABLE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1023.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TOOLTIPABLE_IMP}.tooltip */
EIF_REFERENCE F1746_18337 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("tooltip", 1745, Current, 2, 0, 24241);
	RTGC;
	RTHOOK(1);
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R14757[Dtype(Current)-1849])(Current);
	loc1 = (EIF_POINTER) gtk_widget_get_tooltip_text((GtkWidget*) tp1);
	RTHOOK(2);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc1 != tp1)) {
		RTHOOK(3);
		loc2 = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_1_0_1_0_0_);
		F1206_10397(RTCW(loc2), loc1);
		RTHOOK(4);
		tr1 = F1206_10393(RTCW(loc2));
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTHOOK(6);
		Result = F1500_14214(RTMS_EX_H("",0,0));
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_TOOLTIPABLE_IMP}.set_tooltip */
void F1746_18338 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTEAA("set_tooltip", 1745, Current, 1, 1, 24242);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(17974,F1726_17974, (Current));
	loc1 = F1712_17790(RTCW(tr1), arg1);
	RTHOOK(2);
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R14757[Dtype(Current)-1849])(Current);
	tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	gtk_widget_set_tooltip_text((GtkWidget*) tp1, (gchar*) tp2);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit1023 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
