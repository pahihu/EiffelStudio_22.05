/*
 * Code for class EV_FONT_DIALOG_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1043.h"
#include <ev_gtk.h>
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_FONT_DIALOG_IMP}.make */
void F1766_18534 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("make", 1765, Current, 1, 0, 24399);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_1_0_1_0_0_);
	tr1 = RTMS_EX_H("Font Selection Dialog",21,1034172519);
	F1206_10395(RTCW(loc1), tr1);
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp2 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp3 = tp2;
	tp1 = (EIF_POINTER) gtk_font_chooser_dialog_new((gchar*) tp1, (GtkWindow*) tp3);
	F1726_17949(Current, tp1);
	RTHOOK(3);
	F1765_18517(Current);
	RTHOOK(4);
	F1765_18525(Current);
	RTHOOK(5);
	F1687_17117(Current, (EIF_BOOLEAN) 1);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_FONT_DIALOG_IMP}.font */
EIF_REFERENCE F1766_18535 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(11);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc4);
	RTLR(5,tr1);
	RTLR(6,loc5);
	RTLR(7,loc9);
	RTLR(8,loc8);
	RTLR(9,tr2);
	RTLR(10,loc7);
	RTLIU(11);
	
	RTEAA("font", 1765, Current, 9, 0, 24400);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1351, 0x00).id, 1351, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1345_12285(RTCW(Result));
	RTHOOK(2);
	if (F1765_18527(Current)) {
		RTHOOK(3);
		loc1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_1_);
		loc1 = RTRV(eif_new_type(1701, 0x00), loc1);
		RTHOOK(4);
		RTCT0("font_imp /= Void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		RTHOOK(5);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_8_5_0_1_0_0_);
		loc3 = (EIF_POINTER) gtk_font_chooser_get_font((GtkFontChooser*) tp1);
		RTHOOK(6);
		loc2 = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_1_0_1_0_0_);
		F1206_10397(RTCW(loc2), loc3);
		RTHOOK(7);
		tr1 = F1206_10393(RTCW(loc2));
		loc4 = F1510_14601(RTCW(tr1));
		RTHOOK(8);
		loc5 = RTOSCF(11149,F1218_11149, (RTCV(RTOSCF(17974,F1726_17974, (Current)))));
		RTHOOK(9);
		F1147_10142(RTCW(loc5));
		for (;;) {
			RTHOOK(10);
			tb1 = '\01';
			if (!loc6) {
				tb2 = F964_9526(RTCW(loc5));
				tb1 = tb2;
			}
			if (tb1) break;
			RTHOOK(11);
			loc9 = F1147_10116(RTCW(loc5));
			RTHOOK(12);
			tr1 = F1510_14601(RTCW(loc9));
			ti4_1 = F1508_14468(RTCW(loc4), tr1, ((EIF_INTEGER_32) 1L));
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
				RTHOOK(13);
				tb2 = '\01';
				if (!(EIF_BOOLEAN)(loc8 == NULL)) {
					tr1 = F1147_10116(RTCW(loc5));
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
					ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc8)+ _LNGOFF_1_1_0_2_);
					tb2 = (EIF_BOOLEAN) (ti4_1 > ti4_2);
				}
				if (tb2) {
					RTHOOK(14);
					loc8 = (EIF_REFERENCE) loc9;
				}
				RTHOOK(15);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc8)+ _LNGOFF_1_1_0_2_);
				ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_1_0_2_);
				loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
			}
			RTHOOK(16);
			F1147_10144(RTCW(loc5));
		}
		RTHOOK(17);
		RTCT0("selected_font_name /= Void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc8 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		RTHOOK(18);
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc8);
		F1702_17404(RTCW(loc1), tr1);
		RTHOOK(19);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
		tr2 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc8);
		F1169_10217(RTCW(tr1), tr2);
		RTHOOK(20);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
		loc7 = F1500_14233(RTCW(loc4), tw1);
		RTHOOK(21);
		F678_9061(RTCW(loc7));
		RTHOOK(22);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8131[Dtype(RTCW(loc7))-989])(loc7);
		ti4_1 = F1500_14220(RTCW(tr1));
		F1702_17408(RTCW(loc1), ti4_1);
		RTHOOK(23);
		tb2 = '\01';
		tr1 = F1500_14214(RTMS_EX_H("italic",6,1841824099));
		tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R7861[Dtype(RTCW(loc7))-878])(loc7, tr1);
		if (!tb3) {
			tr1 = F1500_14214(RTMS_EX_H("oblique",7,1996202853));
			tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R7861[Dtype(RTCW(loc7))-878])(loc7, tr1);
			tb2 = tb3;
		}
		if (tb2) {
			RTHOOK(24);
			F1702_17406(RTCW(loc1), ((EIF_INTEGER_32) 11L));
		} else {
			RTHOOK(25);
			F1702_17406(RTCW(loc1), ((EIF_INTEGER_32) 10L));
		}
		RTHOOK(26);
		tr1 = F1500_14214(RTMS_EX_H("bold",4,1651469412));
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R7861[Dtype(RTCW(loc7))-878])(loc7, tr1);
		if (tb2) {
			RTHOOK(27);
			F1702_17405(RTCW(loc1), ((EIF_INTEGER_32) 8L));
		} else {
			RTHOOK(28);
			tr1 = F1500_14214(RTMS_EX_H("light",5,1769214068));
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R7861[Dtype(RTCW(loc7))-878])(loc7, tr1);
			if (tb2) {
				RTHOOK(29);
				F1702_17405(RTCW(loc1), ((EIF_INTEGER_32) 6L));
			} else {
				RTHOOK(30);
				tr1 = F1500_14214(RTMS_EX_H("superbold",9,607903332));
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R7861[Dtype(RTCW(loc7))-878])(loc7, tr1);
				if (tb2) {
					RTHOOK(31);
					F1702_17405(RTCW(loc1), ((EIF_INTEGER_32) 9L));
				} else {
					RTHOOK(32);
					F1702_17405(RTCW(loc1), ((EIF_INTEGER_32) 7L));
				}
			}
		}
	}
	RTHOOK(33);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_FONT_DIALOG_IMP}.set_font */
void F1766_18536 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("set_font", 1765, Current, 1, 1, 24401);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc1 = RTRV(eif_new_type(1701, 0x00), loc1);
	RTHOOK(2);
	RTCT0("font_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(3);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_8_5_0_1_0_0_);
	tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_3_2_0_8_0_0_);
	gtk_font_chooser_set_font_desc((GtkFontChooser*) tp1, (PangoFontDescription*) tp2);
	RTHOOK(4);
	RTLE;
	RTEE;
}

void EIF_Minit1043 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
