/*
 * Code for class EV_STANDARD_DIALOG_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1036.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_STANDARD_DIALOG_I}.internal_accept */
EIF_REFERENCE F1759_18492 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("internal_accept", 1758, Current, 0, 0, 24377);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) RTOSCF(2267,F165_2267, (Current));
}

void EIF_Minit1036 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
