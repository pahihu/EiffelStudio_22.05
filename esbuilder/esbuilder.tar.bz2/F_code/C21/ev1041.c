/*
 * Code for class EV_FILE_OPEN_DIALOG_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1041.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_FILE_OPEN_DIALOG_I}.internal_accept */
EIF_REFERENCE F1764_18516 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("internal_accept", 1763, Current, 0, 0, 24381);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) RTOSCF(2268,F165_2268, (Current));
}

void EIF_Minit1041 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
