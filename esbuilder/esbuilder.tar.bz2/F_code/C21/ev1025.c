/*
 * Code for class EV_PIXMAPABLE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1025.h"
#include <ev_gtk.h>
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F72_966
static EIF_NATURAL_8 inline_F72_966 (void)
{
	return GTK_ORIENTATION_HORIZONTAL
	;
}
#define INLINE_F72_966
#endif
#ifndef INLINE_F221_3735
static EIF_POINTER inline_F221_3735 (EIF_NATURAL_8 arg1, EIF_INTEGER_32 arg2)
{
	return (EIF_POINTER) (gtk_box_new ((GtkOrientation)arg1, (gint)arg2))
	;
}
#define INLINE_F221_3735
#endif
#ifndef INLINE_F219_3165
static EIF_POINTER inline_F219_3165 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	return gdk_pixbuf_get_from_surface ((cairo_surface_t *) arg1, (gint) arg2, (gint) arg3, (gint) arg4, (gint) arg5);
	;
}
#define INLINE_F219_3165
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PIXMAPABLE_IMP}.pixmapable_imp_initialize */
void F1748_18348 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("pixmapable_imp_initialize", 1747, Current, 0, 0, 24253);
	RTGC;
	RTHOOK(1);
	tu1_1 = inline_F72_966();
	tp1 = inline_F221_3735(tu1_1, ((EIF_INTEGER_32) 0L));
	*(EIF_POINTER *)(Current + O14769[Dtype(Current)-1747]) = (EIF_POINTER) tp1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_PIXMAPABLE_IMP}.pixmap */
EIF_REFERENCE F1748_18349 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("pixmap", 1747, Current, 1, 0, 24254);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O14767[Dtype(Current)-1747]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = F1687_17103(loc1);
		Result = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_PIXMAPABLE_IMP}.set_pixmap */
void F1748_18350 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("set_pixmap", 1747, Current, 1, 1, 24255);
	RTGC;
	RTHOOK(1);
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (arg1);
	loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1921, 0), loc1);
	RTHOOK(2);
	RTCT0("l_internal_pixmap /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(3);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + O14767[Dtype(Current)-1747]) = (EIF_REFERENCE) loc1;
	RTHOOK(4);
	ti4_1 = F1922_21214(RTCW(loc1));
	ti4_2 = F1922_21215(RTCW(loc1));
	F1748_18352(Current, loc1, ti4_1, ti4_2);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_PIXMAPABLE_IMP}.remove_pixmap */
void F1748_18351 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("remove_pixmap", 1747, Current, 0, 0, 24256);
	RTGC;
	RTHOOK(1);
	*(EIF_REFERENCE *)(Current + O14767[dtype-1747]) = (EIF_REFERENCE) NULL;
	RTHOOK(2);
	F1748_18353(Current);
	RTHOOK(3);
	tp1 = *(EIF_POINTER *)(Current + O14769[dtype-1747]);
	gtk_widget_hide((GtkWidget*) tp1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_PIXMAPABLE_IMP}.internal_set_pixmap */
void F1748_18352 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("internal_set_pixmap", 1747, Current, 3, 3, 24247);
	RTGC;
	RTHOOK(1);
	F1748_18353(Current);
	RTHOOK(2);
	loc2 = *(EIF_REFERENCE *)(Current + O14767[dtype-1747]);
	loc2 = RTRV(eif_new_type(1921, 0), loc2);
	RTHOOK(3);
	RTCT0("l_internal_pixmap /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(4);
	tb1 = '\01';
	ti4_1 = F1922_21214(RTCW(loc2));
	if (!(EIF_BOOLEAN)(arg2 != ti4_1)) {
		ti4_1 = F1922_21215(RTCW(loc2));
		tb1 = (EIF_BOOLEAN)(arg3 != ti4_1);
	}
	if (tb1) {
		RTHOOK(5);
		F1922_21219(RTCW(arg1), arg2, arg3);
	}
	RTHOOK(6);
	tp1 = *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_48_18_10_9_0_2_);
	loc3 = inline_F219_3165(tp1, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), arg2, arg3);
	RTHOOK(7);
	loc1 = (EIF_POINTER) gtk_image_new_from_pixbuf((GdkPixbuf*) loc3);
	RTHOOK(8);
	gtk_widget_show((GtkWidget*) loc1);
	RTHOOK(9);
	tp1 = *(EIF_POINTER *)(Current + O14769[dtype-1747]);
	gtk_container_add((GtkContainer*) tp1, (GtkWidget*) loc1);
	RTHOOK(10);
	tp1 = *(EIF_POINTER *)(Current + O14769[dtype-1747]);
	gtk_widget_show((GtkWidget*) tp1);
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {EV_PIXMAPABLE_IMP}.internal_remove_pixmap */
void F1748_18353 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("internal_remove_pixmap", 1747, Current, 1, 0, 24248);
	RTGC;
	RTHOOK(1);
	loc1 = F1748_18355(Current);
	RTHOOK(2);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc1 != tp1)) {
		RTHOOK(3);
		tp1 = *(EIF_POINTER *)(Current + O14769[Dtype(Current)-1747]);
		gtk_container_remove((GtkContainer*) tp1, (GtkWidget*) loc1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_PIXMAPABLE_IMP}.gtk_pixmap */
EIF_POINTER F1748_18355 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("gtk_pixmap", 1747, Current, 2, 0, 24250);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O14769[Dtype(Current)-1747]);
	loc1 = (EIF_POINTER) gtk_container_get_children((GtkContainer*) tp1);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 != loc2)) {
		RTHOOK(3);
		Result = (EIF_POINTER) g_list_nth_data((GList*) loc1, (guint) ((EIF_INTEGER_32) 0L));
		RTHOOK(4);
		g_list_free((GList*) loc1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit1025 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
