/*
 * Code for class EV_GRID_ITEM_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1032.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GRID_ITEM_I}.make */
void F1755_18398 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make", 1754, Current, 0, 0, 24289);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O14835[Dtype(Current)-1754]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(2);
	F1687_17117(Current, (EIF_BOOLEAN) 1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_GRID_ITEM_I}.column */
EIF_REFERENCE F1755_18399 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("column", 1754, Current, 1, 0, 24290);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
	RTHOOK(2);
	RTCT0("l_column_i /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(3);
	tr1 = F1687_17103(RTCW(loc1));
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {EV_GRID_ITEM_I}.parent */
EIF_REFERENCE F1755_18400 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("parent", 1754, Current, 1, 0, 24291);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(loc1 + O13786[Dtype(loc1)-1686]);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {EV_GRID_ITEM_I}.row */
EIF_REFERENCE F1755_18401 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("row", 1754, Current, 1, 0, 24292);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
	RTHOOK(2);
	RTCT0("l_row_i /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(3);
	tr1 = F1687_17103(RTCW(loc1));
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {EV_GRID_ITEM_I}.virtual_x_position */
EIF_INTEGER_32 F1755_18402 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("virtual_x_position", 1754, Current, 2, 0, 24293);
	RTGC;
	RTHOOK(1);
	if (F1755_18440(Current)) {
		RTHOOK(2);
		Result = F1517_14714(RTCV(F1755_18399(Current)));
	} else {
		RTHOOK(3);
		Result = F1517_14715(RTCV(F1755_18399(Current)));
	}
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(5);
		ti4_1 = F1798_19275(loc1, Current);
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_ITEM_I}.virtual_y_position */
EIF_INTEGER_32 F1755_18403 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("virtual_y_position", 1754, Current, 2, 0, 24294);
	RTGC;
	RTHOOK(1);
	if (F1755_18439(Current)) {
		RTHOOK(2);
		Result = F1514_14639(RTCV(F1755_18401(Current)));
	} else {
		RTHOOK(3);
		Result = F1514_14640(RTCV(F1755_18401(Current)));
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_ITEM_I}.horizontal_indent */
EIF_INTEGER_32 F1755_18404 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("horizontal_indent", 1754, Current, 2, 0, 24295);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		ti4_1 = F1798_19275(loc1, Current);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ti4_1;
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) 0;
}

/* {EV_GRID_ITEM_I}.required_width */
EIF_INTEGER_32 F1755_18405 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("required_width", 1754, Current, 0, 0, 24296);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
}

/* {EV_GRID_ITEM_I}.width */
EIF_INTEGER_32 F1755_18406 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("width", 1754, Current, 1, 0, 24297);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		ti4_1 = F1742_18279(loc1);
		ti4_2 = F1755_18404(Current);
		Result = eif_max_int32 ((EIF_INTEGER_32) (ti4_1 - ti4_2),((EIF_INTEGER_32) 0L));
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_ITEM_I}.height */
EIF_INTEGER_32 F1755_18407 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("height", 1754, Current, 2, 0, 24298);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb2 = *(EIF_BOOLEAN *)(loc1+ _CHROFF_113_19_);
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(2);
		ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_113_55_10_6_);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ti4_1;
	} else {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			RTHOOK(5);
			ti4_1 = F1741_18197(loc2);
			RTHOOK(6);
			RTLE;
			RTEE;
			return (EIF_INTEGER_32) ti4_1;
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) 0;
}

/* {EV_GRID_ITEM_I}.hash_code */
EIF_INTEGER_32 F1755_18411 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O14835[Dtype(Current)-1754]);
}


/* {EV_GRID_ITEM_I}.is_displayed */
EIF_BOOLEAN F1755_18412 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTEAA("is_displayed", 1754, Current, 3, 0, 24303);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	tb1 = '\0';
	tb2 = '\0';
	tb3 = '\0';
	tb4 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb5 = F1728_18021(loc1);
		tb4 = tb5;
	}
	if (tb4) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
		loc2 = tr1;
		tb3 = EIF_TEST(loc2);
	}
	if (tb3) {
		tb3 = *(EIF_BOOLEAN *)(loc2+ _CHROFF_9_0_);
		tb2 = tb3;
	}
	if (tb2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
		loc3 = tr1;
		tb1 = EIF_TEST(loc3);
	}
	if (tb1) {
		tb1 = *(EIF_BOOLEAN *)(loc3+ _CHROFF_11_5_);
		Result = tb1;
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_ITEM_I}.activate */
void F1755_18413 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("activate", 1754, Current, 1, 0, 24304);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = F1687_17103(Current);
		F1798_19112(loc1, tr1);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_GRID_ITEM_I}.deactivate */
void F1755_18414 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("deactivate", 1754, Current, 1, 0, 24305);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = F1687_17103(Current);
		F1798_19113(loc1, tr1);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_GRID_ITEM_I}.enable_select */
void F1755_18415 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,loc3);
	RTLR(3,loc4);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTEAA("enable_select", 1754, Current, 4, 0, 24306);
	RTGC;
	RTHOOK(1);
	loc1 = F1755_18420(Current);
	RTHOOK(2);
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	RTHOOK(3);
	RTCT0("l_parent_i /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(4);
	loc3 = F1755_18401(Current);
	RTHOOK(5);
	loc4 = F1755_18399(Current);
	RTHOOK(6);
	tb1 = '\0';
	tb2 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_113_37_);
	if (tb2) {
		tb1 = (EIF_BOOLEAN) !loc1;
	}
	if (tb1) {
		RTHOOK(7);
		F1798_19057(RTCW(loc2));
	}
	RTHOOK(8);
	F1755_18428(Current);
	RTHOOK(9);
	if ((EIF_BOOLEAN) !loc1) {
		RTHOOK(10);
		tb1 = '\0';
		tb2 = '\0';
		tb3 = '\0';
		tb4 = F1798_19205(RTCW(loc2));
		if ((EIF_BOOLEAN) !tb4) {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_31_);
			tb3 = (EIF_BOOLEAN)(tr1 != NULL);
		}
		if (tb3) {
			tr1 = F1246_11575(RTCW(loc2));
			tb3 = F827_9290(RTCW(tr1));
			tb2 = (EIF_BOOLEAN) !tb3;
		}
		if (tb2) {
			tb2 = F1365_12551(RTCW(loc3));
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(11);
			tr1 = F1246_11575(RTCW(loc2));
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,1513,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr2 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr2+1)->it_r = loc3;
			RTAR(tr2,loc3);
			F1177_10288(RTCW(tr1), tr2);
		}
		RTHOOK(12);
		tb1 = '\0';
		tb2 = '\0';
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_32_);
		if ((EIF_BOOLEAN)(tr1 != NULL)) {
			tr1 = F1246_11577(RTCW(loc2));
			tb3 = F827_9290(RTCW(tr1));
			tb2 = (EIF_BOOLEAN) !tb3;
		}
		if (tb2) {
			tb2 = F1365_12551(RTCW(loc4));
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(13);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_1_);
			F1742_18317(RTCW(tr1), (EIF_BOOLEAN) 0);
			RTHOOK(14);
			tr1 = F1246_11577(RTCW(loc2));
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,1516,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr2 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr2+1)->it_r = loc4;
			RTAR(tr2,loc4);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8518[Dtype(RTCW(tr1))-1175])(tr1, tr2);
		}
	}
	RTHOOK(15);
	tb1 = F1687_17102(RTCW(loc2));
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(16);
		F1798_19277(RTCW(loc2), Current);
	}
	RTHOOK(17);
	RTLE;
	RTEE;
}

/* {EV_GRID_ITEM_I}.disable_select */
void F1755_18416 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc4);
	RTLR(2,loc5);
	RTLR(3,loc6);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTEAA("disable_select", 1754, Current, 6, 0, 24307);
	RTGC;
	RTHOOK(1);
	loc1 = F1755_18420(Current);
	RTHOOK(2);
	loc4 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	RTHOOK(3);
	RTCT0("l_parent_i /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc4 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(4);
	loc5 = F1755_18401(Current);
	RTHOOK(5);
	loc6 = F1755_18399(Current);
	RTHOOK(6);
	if (loc1) {
		RTHOOK(7);
		tb1 = '\0';
		tb2 = '\0';
		tb3 = '\0';
		tb4 = F1798_19205(RTCW(loc4));
		if ((EIF_BOOLEAN) !tb4) {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_33_);
			tb3 = (EIF_BOOLEAN)(tr1 != NULL);
		}
		if (tb3) {
			tr1 = F1246_11576(RTCW(loc4));
			tb3 = F827_9290(RTCW(tr1));
			tb2 = (EIF_BOOLEAN) !tb3;
		}
		if (tb2) {
			tb2 = F1365_12551(RTCW(loc5));
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(8);
			loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		RTHOOK(9);
		tb1 = '\0';
		tb2 = '\0';
		tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_34_);
		if ((EIF_BOOLEAN)(tr1 != NULL)) {
			tr1 = F1246_11578(RTCW(loc4));
			tb3 = F827_9290(RTCW(tr1));
			tb2 = (EIF_BOOLEAN) !tb3;
		}
		if (tb2) {
			tb2 = F1365_12551(RTCW(loc6));
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(10);
			loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	RTHOOK(11);
	F1755_18429(Current);
	RTHOOK(12);
	if (loc2) {
		RTHOOK(13);
		tr1 = F1246_11576(RTCW(loc4));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,1513,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = loc5;
		RTAR(tr2,loc5);
		F1177_10288(RTCW(tr1), tr2);
	}
	RTHOOK(14);
	if (loc3) {
		RTHOOK(15);
		tr1 = F1246_11578(RTCW(loc4));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,1516,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = loc6;
		RTAR(tr2,loc6);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8518[Dtype(RTCW(tr1))-1175])(tr1, tr2);
	}
	RTHOOK(16);
	tb1 = F1687_17102(RTCW(loc4));
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(17);
		F1798_19277(RTCW(loc4), Current);
	}
	RTHOOK(18);
	RTLE;
	RTEE;
}

/* {EV_GRID_ITEM_I}.ensure_visible */
void F1755_18417 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,loc6);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("ensure_visible", 1754, Current, 7, 0, 24308);
	RTGC;
	RTHOOK(1);
	loc5 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	RTHOOK(2);
	RTCT0("l_parent_i /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc5 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(3);
	F1798_19320(RTCW(loc5));
	RTHOOK(4);
	F1798_19317(RTCW(loc5));
	RTHOOK(5);
	loc6 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
	RTHOOK(6);
	RTCT0("l_column_i /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc6 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(7);
	F1514_14659(RTCV(F1755_18401(Current)));
	RTHOOK(8);
	ti4_1 = F1742_18279(RTCW(loc6));
	if ((EIF_BOOLEAN) (F1755_18404(Current) < ti4_1)) {
		RTHOOK(9);
		loc1 = F1755_18402(Current);
		RTHOOK(10);
		loc2 = F1755_18406(Current);
		RTHOOK(11);
		ti4_1 = F1798_19072(RTCW(loc5));
		if ((EIF_BOOLEAN) (loc1 < ti4_1)) {
			RTHOOK(12);
			ti4_1 = F1798_19073(RTCW(loc5));
			F1798_19165(RTCW(loc5), loc1, ti4_1);
		} else {
			RTHOOK(13);
			ti4_1 = F1798_19072(RTCW(loc5));
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_113_55_10_8_);
			if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + loc2) > (EIF_INTEGER_32) (ti4_1 + ti4_2))) {
				RTHOOK(14);
				tb1 = *(EIF_BOOLEAN *)(RTCW(loc5)+ _CHROFF_113_14_);
				if (tb1) {
					RTHOOK(15);
					loc4 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_9_4_0_0_);
					RTHOOK(16);
					loc3 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_113_55_10_8_);
					for (;;) {
						RTHOOK(17);
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 1L)) || (EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 0L)))) break;
						RTHOOK(18);
						tr1 = F1798_19048(RTCW(loc5), loc4);
						ti4_1 = F1517_14712(RTCW(tr1));
						loc3 -= ti4_1;
						RTHOOK(19);
						loc4--;
					}
					RTHOOK(20);
					tr1 = F1798_19048(RTCW(loc5), (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L)));
					ti4_1 = F1517_14712(RTCW(tr1));
					loc3 += ti4_1;
				}
				RTHOOK(21);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_113_55_10_8_);
				if ((EIF_BOOLEAN) (loc2 >= ti4_1)) {
					RTHOOK(22);
					ti4_1 = F1798_19073(RTCW(loc5));
					F1798_19165(RTCW(loc5), loc1, ti4_1);
				} else {
					RTHOOK(23);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_113_55_10_8_);
					ti4_2 = F1798_19073(RTCW(loc5));
					F1798_19165(RTCW(loc5), (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + loc2) + loc3) - ti4_1), ti4_2);
				}
			}
		}
	}
	RTHOOK(29);
	RTLE;
	RTEE;
}

/* {EV_GRID_ITEM_I}.redraw */
void F1755_18418 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("redraw", 1754, Current, 1, 0, 24309);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		F1798_19277(loc1, Current);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_GRID_ITEM_I}.is_parented */
EIF_BOOLEAN F1755_18419 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_parented", 1754, Current, 0, 0, 24310);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_18_) != NULL);
}

/* {EV_GRID_ITEM_I}.is_selected */
EIF_BOOLEAN F1755_18420 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("is_selected", 1754, Current, 2, 0, 24311);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb2 = F1798_19205(loc1);
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(2);
		Result = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tb1 = F1741_18199(loc2);
			Result = tb1;
		}
	} else {
		RTHOOK(3);
		Result = *(EIF_BOOLEAN *)(Current + O14819[Dtype(Current)-1754]);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) Result;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_ITEM_I}.is_selectable */
EIF_BOOLEAN F1755_18421 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_selectable", 1754, Current, 0, 0, 24312);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) F1755_18419(Current);
}

/* {EV_GRID_ITEM_I}.is_destroyed */
EIF_BOOLEAN F1755_18422 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("is_destroyed", 1754, Current, 1, 0, 24313);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	if (!F1687_17102(Current)) {
		tb1 = '\0';
		tb2 = '\0';
		if (F1755_18419(Current)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
			loc1 = tr1;
			tb2 = EIF_TEST(loc1);
		}
		if (tb2) {
			tb2 = F1687_17102(loc1);
			tb1 = tb2;
		}
		Result = tb1;
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_ITEM_I}.set_is_tab_navigatable */
void F1755_18427 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_is_tab_navigatable", 1754, Current, 0, 1, 24318);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O14812[Dtype(Current)-1754]) = (EIF_BOOLEAN) arg1;
	RTHOOK(3);
	RTEE;
}

/* {EV_GRID_ITEM_I}.enable_select_internal */
void F1755_18428 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTEAA("enable_select_internal", 1754, Current, 2, 0, 24319);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !F1755_18420(Current)) {
		RTHOOK(2);
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
		RTHOOK(3);
		RTCT0("l_parent_i /= Void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		RTHOOK(4);
		tb1 = '\0';
		tb2 = F1798_19205(RTCW(loc1));
		if (tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
			loc2 = tr1;
			tb1 = EIF_TEST(loc2);
		}
		if (tb1) {
			RTHOOK(5);
			F1741_18241(loc2);
		} else {
			RTHOOK(6);
			*(EIF_BOOLEAN *)(Current + O14819[Dtype(Current)-1754]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			RTHOOK(7);
			F1798_19430(RTCW(loc1), Current);
			RTHOOK(8);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_29_);
			if ((EIF_BOOLEAN)(tr1 != NULL)) {
				RTHOOK(9);
				tr1 = F1246_11573(RTCW(loc1));
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0,0xFFFF};
					EIF_TYPE typres0;
					{
						EIF_TYPE l_type;
						l_type = eif_final_id(Y13786,Y13786_gen_type,Dftype(Current),1686);
						typarr0[3] = l_type.annotations | 0xFF00;
						typarr0[4] = l_type.id;
					}
					
					typres0 = eif_compound_id(Dftype(Current), typarr0);
					tr2 = RTLNTS(typres0.id, 2, 0);
				}
				tr3 = F1687_17103(Current);
				((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
				RTAR(tr2,tr3);
				F1177_10288(RTCW(tr1), tr2);
			}
			RTHOOK(10);
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_9_) != NULL)) {
				RTHOOK(11);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
				F1177_10288(RTCW(tr1), NULL);
			}
		}
	}
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {EV_GRID_ITEM_I}.disable_select_internal */
void F1755_18429 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTEAA("disable_select_internal", 1754, Current, 2, 0, 24320);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if (F1755_18420(Current)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
		loc1 = tr1;
		tb1 = EIF_TEST(loc1);
	}
	if (tb1) {
		RTHOOK(2);
		tb1 = '\0';
		tb2 = F1798_19205(loc1);
		if (tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
			loc2 = tr1;
			tb1 = EIF_TEST(loc2);
		}
		if (tb1) {
			RTHOOK(3);
			F1741_18242(loc2);
		} else {
			RTHOOK(4);
			*(EIF_BOOLEAN *)(Current + O14819[Dtype(Current)-1754]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			RTHOOK(5);
			F1798_19432(loc1, Current);
			RTHOOK(6);
			tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_30_);
			if ((EIF_BOOLEAN)(tr1 != NULL)) {
				RTHOOK(7);
				tr1 = F1246_11574(loc1);
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0,0xFFFF};
					EIF_TYPE typres0;
					{
						EIF_TYPE l_type;
						l_type = eif_final_id(Y13786,Y13786_gen_type,Dftype(Current),1686);
						typarr0[3] = l_type.annotations | 0xFF00;
						typarr0[4] = l_type.id;
					}
					
					typres0 = eif_compound_id(Dftype(Current), typarr0);
					tr2 = RTLNTS(typres0.id, 2, 0);
				}
				tr3 = F1687_17103(Current);
				((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
				RTAR(tr2,tr3);
				F1177_10288(RTCW(tr1), tr2);
			}
			RTHOOK(8);
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_10_) != NULL)) {
				RTHOOK(9);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
				F1177_10288(RTCW(tr1), NULL);
			}
		}
	}
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {EV_GRID_ITEM_I}.set_parents */
void F1755_18431 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTEAA("set_parents", 1754, Current, 0, 4, 24322);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) arg2;
	RTHOOK(3);
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) arg3;
	RTHOOK(4);
	*(EIF_INTEGER_32 *)(Current + O14835[Dtype(Current)-1754]) = (EIF_INTEGER_32) arg4;
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {EV_GRID_ITEM_I}.update_for_removal */
void F1755_18432 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("update_for_removal", 1754, Current, 0, 0, 24323);
	RTGC;
	RTHOOK(1);
	*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) NULL;
	RTHOOK(2);
	*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) NULL;
	RTHOOK(3);
	*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) NULL;
	RTHOOK(4);
	*(EIF_INTEGER_32 *)(Current + O14835[Dtype(Current)-1754]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EV_GRID_ITEM_I}.destroy */
void F1755_18437 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTEAA("destroy", 1754, Current, 3, 0, 24328);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	loc1 = tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
	loc2 = tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
	loc3 = tr1;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (EIF_TEST(loc1) && EIF_TEST(loc2)) && EIF_TEST(loc3))) {
		RTHOOK(2);
		ti4_1 = *(EIF_INTEGER_32 *)(loc2+ _LNGOFF_9_4_0_0_);
		ti4_2 = *(EIF_INTEGER_32 *)(loc3+ _LNGOFF_11_7_0_3_);
		F1798_19434(loc1, ti4_1, ti4_2, NULL);
	}
	RTHOOK(3);
	F1687_17118(Current, (EIF_BOOLEAN) 1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_GRID_ITEM_I}.internal_rectangle */
static EIF_REFERENCE F1755_18438_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("internal_rectangle", 1754, Current, 0, 0, 24329);
	RTGC;
	RTOSP (18438);
#define Result RTOSR(18438)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1254, 0x00).id, 1254, _OBJSIZ_0_0_0_4_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (18438);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1755_18438 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(18438,F1755_18438_body,(Current));
}

/* {EV_GRID_ITEM_I}.row_locked_but_not_obscured_by_locked_column */
EIF_BOOLEAN F1755_18439 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLIU(6);
	
	RTEAA("row_locked_but_not_obscured_by_locked_column", 1754, Current, 4, 0, 24330);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tb2 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb3 = *(EIF_BOOLEAN *)(loc1+ _CHROFF_11_3_);
		tb2 = tb3;
	}
	if (tb2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
		loc2 = tr1;
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		RTHOOK(2);
		tb1 = *(EIF_BOOLEAN *)(loc2+ _CHROFF_9_1_);
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(3);
			RTHOOK(4);
			RTLE;
			RTEE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			RTHOOK(5);
			tb1 = '\0';
			tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_5_);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				tr1 = *(EIF_REFERENCE *)(loc2 + _REFACS_6_);
				loc4 = tr1;
				tb1 = EIF_TEST(loc4);
			}
			if (tb1) {
				RTHOOK(6);
				ti4_1 = *(EIF_INTEGER_32 *)(loc3+ _LNGOFF_7_0_0_1_);
				ti4_2 = *(EIF_INTEGER_32 *)(loc4+ _LNGOFF_7_0_0_1_);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ti4_2);
			}
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_ITEM_I}.column_locked_but_not_obscured_by_locked_row */
EIF_BOOLEAN F1755_18440 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLIU(6);
	
	RTEAA("column_locked_but_not_obscured_by_locked_row", 1754, Current, 4, 0, 24331);
	RTGC;
	RTHOOK(1);
	tb1 = F1517_14719(RTCV(F1755_18399(Current)));
	if (tb1) {
		RTHOOK(2);
		tb1 = F1514_14651(RTCV(F1755_18401(Current)));
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(3);
			RTHOOK(4);
			RTLE;
			RTEE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			RTHOOK(5);
			tb1 = '\0';
			tb2 = '\0';
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
			loc1 = tr1;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
			loc2 = tr1;
			if ((EIF_BOOLEAN) (EIF_TEST(loc1) && EIF_TEST(loc2))) {
				tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_6_);
				loc3 = tr1;
				tb2 = EIF_TEST(loc3);
			}
			if (tb2) {
				tr1 = *(EIF_REFERENCE *)(loc2 + _REFACS_5_);
				loc4 = tr1;
				tb1 = EIF_TEST(loc4);
			}
			if (tb1) {
				RTHOOK(6);
				ti4_1 = *(EIF_INTEGER_32 *)(loc3+ _LNGOFF_7_0_0_1_);
				ti4_2 = *(EIF_INTEGER_32 *)(loc4+ _LNGOFF_7_0_0_1_);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ti4_2);
			}
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_ITEM_I}.perform_redraw */
void F1755_18441 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_REFERENCE arg6)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,arg6);
	RTLR(3,loc1);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTEAA("perform_redraw", 1754, Current, 3, 6, 24332);
	RTGC;
	RTHOOK(1);
	loc3 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	RTHOOK(2);
	RTCT0("l_parent_i /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(3);
	loc2 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_113_40_);
	RTHOOK(4);
	F1372_12629(RTCW(arg6));
	RTHOOK(5);
	loc1 = F1755_18442(Current);
	RTHOOK(6);
	if (F1755_18420(Current)) {
		RTHOOK(7);
		if (loc2) {
			RTHOOK(8);
			tr1 = F1594_15627(RTCV(F1755_18444(Current)));
			F1360_12513(RTCW(arg6), tr1);
		} else {
			RTHOOK(9);
			tr1 = F1594_15628(RTCV(F1755_18444(Current)));
			F1360_12513(RTCW(arg6), tr1);
		}
		RTHOOK(10);
		F1372_12625(RTCW(arg6), (EIF_INTEGER_32) (((EIF_INTEGER_32) 0L) + arg5), ((EIF_INTEGER_32) 0L), arg3, arg4);
		RTHOOK(11);
		if (loc2) {
			RTHOOK(12);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_82_);
			F1360_12513(RTCW(arg6), tr1);
		} else {
			RTHOOK(13);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_83_);
			F1360_12513(RTCW(arg6), tr1);
		}
	} else {
		RTHOOK(14);
		tr1 = F1755_18443(Current);
		F1360_12513(RTCW(arg6), tr1);
	}
	RTHOOK(15);
	F1372_12629(RTCW(arg6));
	RTHOOK(16);
	RTLE;
	RTEE;
}

/* {EV_GRID_ITEM_I}.displayed_background_color */
EIF_REFERENCE F1755_18442 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("displayed_background_color", 1754, Current, 1, 0, 24333);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		tb1 = F1594_15735(RTCV(F1755_18444(Current)));
		if (tb1) {
			RTHOOK(4);
			loc1 = F1517_14716(RTCV(F1755_18399(Current)));
			RTHOOK(5);
			if ((EIF_BOOLEAN)(loc1 == NULL)) {
				RTHOOK(6);
				loc1 = F1514_14643(RTCV(F1755_18401(Current)));
				RTHOOK(7);
				if ((EIF_BOOLEAN)(loc1 == NULL)) {
					RTHOOK(8);
					loc1 = F1360_12512(RTCV(F1755_18444(Current)));
				}
			}
		} else {
			RTHOOK(9);
			loc1 = F1514_14643(RTCV(F1755_18401(Current)));
			RTHOOK(10);
			if ((EIF_BOOLEAN)(loc1 == NULL)) {
				RTHOOK(11);
				loc1 = F1517_14716(RTCV(F1755_18399(Current)));
				RTHOOK(12);
				if ((EIF_BOOLEAN)(loc1 == NULL)) {
					RTHOOK(13);
					loc1 = F1360_12512(RTCV(F1755_18444(Current)));
				}
			}
		}
		RTHOOK(14);
		RTCT0("l_result /= Void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
	}
	RTHOOK(15);
	RTHOOK(16);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) loc1;
}

/* {EV_GRID_ITEM_I}.displayed_foreground_color */
EIF_REFERENCE F1755_18443 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("displayed_foreground_color", 1754, Current, 1, 0, 24334);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		RTHOOK(3);
		tb1 = F1594_15735(RTCV(F1755_18444(Current)));
		if (tb1) {
			RTHOOK(4);
			loc1 = F1517_14717(RTCV(F1755_18399(Current)));
			RTHOOK(5);
			if ((EIF_BOOLEAN)(loc1 == NULL)) {
				RTHOOK(6);
				loc1 = F1514_14644(RTCV(F1755_18401(Current)));
				RTHOOK(7);
				if ((EIF_BOOLEAN)(loc1 == NULL)) {
					RTHOOK(8);
					loc1 = F1360_12511(RTCV(F1755_18444(Current)));
				}
			}
		} else {
			RTHOOK(9);
			loc1 = F1514_14644(RTCV(F1755_18401(Current)));
			RTHOOK(10);
			if ((EIF_BOOLEAN)(loc1 == NULL)) {
				RTHOOK(11);
				loc1 = F1517_14717(RTCV(F1755_18399(Current)));
				RTHOOK(12);
				if ((EIF_BOOLEAN)(loc1 == NULL)) {
					RTHOOK(13);
					loc1 = F1360_12511(RTCV(F1755_18444(Current)));
				}
			}
		}
		RTHOOK(14);
		RTCT0("l_result /= Void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
	}
	RTHOOK(15);
	RTHOOK(16);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) loc1;
}

/* {EV_GRID_ITEM_I}.attached_parent */
EIF_REFERENCE F1755_18444 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("attached_parent", 1754, Current, 1, 0, 24335);
	RTGC;
	RTHOOK(1);
	loc1 = F1755_18400(Current);
	RTHOOK(2);
	RTCT0("l_parent /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(3);
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) loc1;
}

void EIF_Minit1032 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
