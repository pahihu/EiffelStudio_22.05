/*
 * Code for class EV_DESELECTABLE_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1017.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DESELECTABLE_I}.toggle */
void F1740_18178 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("toggle", 1739, Current, 0, 0, 24084);
	RTGC;
	RTHOOK(1);
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14616[dtype-1740])(Current)) {
		RTHOOK(2);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14619[dtype-1740])(Current);
	} else {
		RTHOOK(3);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14617[dtype-1740])(Current);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

void EIF_Minit1017 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
