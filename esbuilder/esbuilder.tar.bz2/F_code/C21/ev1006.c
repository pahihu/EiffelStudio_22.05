/*
 * Code for class EV_GTK_WINDOW_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1006.h"
#include <string.h>
#include <ev_gtk.h>
#include <stdlib.h>
#include "eif_helpers.h"
#include <gdk/gdkkeysyms.h>
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GTK_WINDOW_IMP}.set_blocking_window */
void F1729_18028 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTEAA("set_blocking_window", 1728, Current, 1, 1, 23988);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !F1687_17102(Current)) {
		RTHOOK(2);
		if ((EIF_BOOLEAN)(arg1 != NULL)) {
			RTHOOK(3);
			loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + O10182[Dtype(arg1)-1344]);
			loc1 = RTRV(eif_new_type(1810, 0x00), loc1);
			RTHOOK(4);
			RTCT0("l_internal_blocking_window /= Void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc1 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			RTHOOK(5);
			RTAR(Current, loc1);
			*(EIF_REFERENCE *)(Current + O14508[dtype-1728]) = (EIF_REFERENCE) loc1;
			RTHOOK(6);
			F1811_19648(RTCW(loc1), Current);
		} else {
			RTHOOK(7);
			loc1 = *(EIF_REFERENCE *)(Current + O14508[dtype-1728]);
			RTHOOK(8);
			if ((EIF_BOOLEAN)(loc1 != NULL)) {
				RTHOOK(9);
				F1811_19649(RTCW(loc1), Current);
				RTHOOK(10);
				*(EIF_REFERENCE *)(Current + O14508[dtype-1728]) = (EIF_REFERENCE) NULL;
			}
		}
	} else {
		RTHOOK(11);
		*(EIF_REFERENCE *)(Current + O14508[dtype-1728]) = (EIF_REFERENCE) NULL;
	}
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {EV_GTK_WINDOW_IMP}.blocking_window */
EIF_REFERENCE F1729_18029 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("blocking_window", 1728, Current, 1, 0, 23989);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + O14508[Dtype(Current)-1728]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb2 = F1687_17102(loc1);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(loc1 + O13786[Dtype(loc1)-1686]);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) tr1;
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) 0;
}

/* {EV_GTK_WINDOW_IMP}.window_position_enum */
EIF_INTEGER_32 F1729_18030 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("window_position_enum", 1728, Current, 0, 0, 23990);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(F1729_18029(Current) != NULL)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) GTK_WIN_POS_CENTER_ON_PARENT;
	} else {
		RTHOOK(4);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R14507[Dtype(Current)-1729])(Current);
	}/* NOTREACHED */
	
}

/* {EV_GTK_WINDOW_IMP}.default_window_position */
EIF_INTEGER_32 F1729_18031 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("default_window_position", 1728, Current, 0, 0, 23991);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) (EIF_INTEGER_32) GTK_WIN_POS_NONE;
}

/* {EV_GTK_WINDOW_IMP}.set_width */
void F1729_18033 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_width", 1728, Current, 0, 1, 23993);
	RTGC;
	RTHOOK(1);
	ti4_1 = F1729_18037(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R14511[Dtype(Current)-1729])(Current, arg1, ti4_1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_GTK_WINDOW_IMP}.set_height */
void F1729_18034 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_height", 1728, Current, 0, 1, 23961);
	RTGC;
	RTHOOK(1);
	ti4_1 = F1729_18036(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R14511[Dtype(Current)-1729])(Current, ti4_1, arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_GTK_WINDOW_IMP}.set_size */
void F1729_18035 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_size", 1728, Current, 2, 2, 23962);
	RTGC;
	RTHOOK(1);
	ti4_1 = F1728_17997(Current);
	loc1 = eif_max_int32 (arg1,ti4_1);
	RTHOOK(2);
	ti4_1 = F1728_17998(Current);
	loc2 = eif_max_int32 (arg2,ti4_1);
	RTHOOK(3);
	tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
	gtk_window_set_default_size((GtkWindow*) tp1, (gint) loc1, (gint) loc2);
	RTHOOK(4);
	tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
	gtk_window_resize((GtkWindow*) tp1, (gint) loc1, (gint) loc2);
	RTHOOK(5);
	*(EIF_BOOLEAN *)(Current + O14515[dtype-1728]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(6);
	tb1 = '\0';
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14497[dtype-1729])(Current)) {
		tb1 = (EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14526[dtype-1729])(Current);
	}
	if (tb1) {
		RTHOOK(7);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14531[dtype-1729])(Current);
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EV_GTK_WINDOW_IMP}.width */
EIF_INTEGER_32 F1729_18036 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("width", 1728, Current, 0, 0, 23963);
	RTGC;
	RTHOOK(1);
	tb1 = '\01';
	if (!*(EIF_BOOLEAN *)(Current + O14515[dtype-1728])) {
		tb1 = (EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14497[dtype-1729])(Current);
	}
	if (tb1) {
		RTHOOK(2);
		tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp2 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp3 = tp2;
		gtk_window_get_default_size((GtkWindow*) tp1, (EIF_INTEGER_32*) (EIF_INTEGER_32 *) &(Result), (EIF_INTEGER_32*) tp3);
		RTHOOK(3);
		ti4_1 = F1728_17997(Current);
		ti4_1 = eif_max_int32 (Result,ti4_1);
		Result = (EIF_INTEGER_32) ti4_1;
	} else {
		RTHOOK(4);
		Result = F1728_18016(Current);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) Result;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_WINDOW_IMP}.height */
EIF_INTEGER_32 F1729_18037 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("height", 1728, Current, 0, 0, 23964);
	RTGC;
	RTHOOK(1);
	tb1 = '\01';
	if (!*(EIF_BOOLEAN *)(Current + O14515[dtype-1728])) {
		tb1 = (EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14497[dtype-1729])(Current);
	}
	if (tb1) {
		RTHOOK(2);
		tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp2 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp3 = tp2;
		gtk_window_get_default_size((GtkWindow*) tp1, (EIF_INTEGER_32*) tp3, (EIF_INTEGER_32*) (EIF_INTEGER_32 *) &(Result));
		RTHOOK(3);
		ti4_1 = F1728_17998(Current);
		ti4_1 = eif_max_int32 (Result,ti4_1);
		Result = (EIF_INTEGER_32) ti4_1;
	} else {
		RTHOOK(4);
		Result = F1728_18017(Current);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) Result;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_WINDOW_IMP}.set_x_position */
void F1729_18038 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_x_position", 1728, Current, 0, 1, 23965);
	RTGC;
	RTHOOK(1);
	ti4_1 = F1729_18046(Current);
	F1729_18040(Current, arg1, ti4_1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_GTK_WINDOW_IMP}.set_y_position */
void F1729_18039 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_y_position", 1728, Current, 0, 1, 23966);
	RTGC;
	RTHOOK(1);
	ti4_1 = F1729_18044(Current);
	F1729_18040(Current, ti4_1, arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_GTK_WINDOW_IMP}.set_position */
void F1729_18040 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_position", 1728, Current, 0, 2, 23967);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O14438[Dtype(Current)-1725]);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(17974,F1726_17974, (Current)))+ _LNGOFF_49_16_0_11_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(17974,F1726_17974, (Current)))+ _LNGOFF_49_16_0_12_);
	gtk_window_move((GtkWindow*) tp1, (gint) (EIF_INTEGER_32) (arg1 - ti4_1), (gint) (EIF_INTEGER_32) (arg2 - ti4_2));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_GTK_WINDOW_IMP}.client_width */
EIF_INTEGER_32 F1729_18042 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	RTEAA("client_width", 1728, Current, 1, 0, 23969);
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O14438[Dtype(Current)-1725]);
	gtk_window_get_size((GtkWindow*) tp1, (gint*) (EIF_INTEGER_32 *) &(Result), (gint*) (EIF_INTEGER_32 *) &(loc1));
	RTHOOK(2);
	RTEE;
	return Result;
}

/* {EV_GTK_WINDOW_IMP}.client_height */
EIF_INTEGER_32 F1729_18043 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	RTEAA("client_height", 1728, Current, 1, 0, 23970);
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O14438[Dtype(Current)-1725]);
	gtk_window_get_size((GtkWindow*) tp1, (gint*) (EIF_INTEGER_32 *) &(loc1), (gint*) (EIF_INTEGER_32 *) &(Result));
	RTHOOK(2);
	RTEE;
	return Result;
}

/* {EV_GTK_WINDOW_IMP}.x_position */
EIF_INTEGER_32 F1729_18044 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("x_position", 1728, Current, 1, 0, 23971);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O14438[Dtype(Current)-1725]);
	gtk_window_get_position((GtkWindow*) tp1, (gint*) (EIF_INTEGER_32 *) &(Result), (gint*) (EIF_INTEGER_32 *) &(loc1));
	RTHOOK(2);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(17974,F1726_17974, (Current)))+ _LNGOFF_49_16_0_11_);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_WINDOW_IMP}.screen_x */
EIF_INTEGER_32 F1729_18045 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("screen_x", 1728, Current, 1, 0, 23972);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O14438[Dtype(Current)-1725]);
	gtk_window_get_position((GtkWindow*) tp1, (gint*) (EIF_INTEGER_32 *) &(Result), (gint*) (EIF_INTEGER_32 *) &(loc1));
	RTHOOK(2);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(17974,F1726_17974, (Current)))+ _LNGOFF_49_16_0_11_);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_WINDOW_IMP}.y_position */
EIF_INTEGER_32 F1729_18046 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("y_position", 1728, Current, 1, 0, 23973);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O14438[Dtype(Current)-1725]);
	gtk_window_get_position((GtkWindow*) tp1, (gint*) (EIF_INTEGER_32 *) &(loc1), (gint*) (EIF_INTEGER_32 *) &(Result));
	RTHOOK(2);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(17974,F1726_17974, (Current)))+ _LNGOFF_49_16_0_12_);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_WINDOW_IMP}.screen_y */
EIF_INTEGER_32 F1729_18047 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("screen_y", 1728, Current, 1, 0, 23974);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O14438[Dtype(Current)-1725]);
	gtk_window_get_position((GtkWindow*) tp1, (gint*) (EIF_INTEGER_32 *) &(loc1), (gint*) (EIF_INTEGER_32 *) &(Result));
	RTHOOK(2);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(17974,F1726_17974, (Current)))+ _LNGOFF_49_16_0_12_);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_WINDOW_IMP}.default_wm_decorations */
EIF_INTEGER_32 F1729_18048 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("default_wm_decorations", 1728, Current, 0, 0, 23975);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
}

/* {EV_GTK_WINDOW_IMP}.show */
void F1729_18049 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("show", 1728, Current, 0, 0, 23976);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !F1728_18020(Current)) {
		RTHOOK(2);
		tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
		ti4_1 = F1729_18030(Current);
		gtk_window_set_position((GtkWindow*) tp1, (GtkWindowPosition) ti4_1);
		RTHOOK(3);
		tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
		gtk_widget_show((GtkWidget*) tp1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_GTK_WINDOW_IMP}.hide */
void F1729_18050 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("hide", 1728, Current, 5, 0, 23977);
	RTGC;
	RTHOOK(1);
	if (F1728_18020(Current)) {
		RTHOOK(2);
		tb1 = '\0';
		tb2 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + O14508[dtype-1728]);
		loc5 = tr1;
		if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O14521[dtype-1728]) && EIF_TEST(loc5))) {
			tb3 = F1687_17102(loc5);
			tb2 = (EIF_BOOLEAN) !tb3;
		}
		if (tb2) {
			tb2 = F1728_18020(loc5);
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(3);
			F1811_19684(loc5);
		}
		RTHOOK(4);
		loc1 = F1729_18044(Current);
		RTHOOK(5);
		loc2 = F1729_18046(Current);
		RTHOOK(6);
		loc3 = F1729_18036(Current);
		RTHOOK(7);
		loc4 = F1729_18037(Current);
		RTHOOK(8);
		*(EIF_BOOLEAN *)(Current + O14521[dtype-1728]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		RTHOOK(9);
		F1729_18028(Current, NULL);
		RTHOOK(10);
		tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
		gtk_widget_hide((GtkWidget*) tp1);
		RTHOOK(11);
		tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
		tp1 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
		gdk_window_hide((GdkWindow*) tp1);
		RTHOOK(12);
		tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
		gtk_window_set_default_size((GtkWindow*) tp1, (gint) loc3, (gint) loc4);
		RTHOOK(13);
		tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
		gtk_window_move((GtkWindow*) tp1, (gint) loc1, (gint) loc2);
	}
	RTHOOK(14);
	RTLE;
	RTEE;
}

/* {EV_GTK_WINDOW_IMP}.close */
void F1729_18051 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("close", 1728, Current, 0, 0, 23978);
	RTGC;
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R14519[dtype-1729])(Current);
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
	gtk_window_close((GtkWindow*) tp1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_GTK_WINDOW_IMP}.show_modal_to_window */
void F1729_18053 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("show_modal_to_window", 1728, Current, 1, 1, 23980);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + O10182[Dtype(arg1)-1344]);
	loc1 = RTRV(eif_new_type(1810, 0x00), loc1);
	RTHOOK(2);
	RTCT0("l_window_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(3);
	*(EIF_BOOLEAN *)(Current + O14521[dtype-1728]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(4);
	F1811_19683(RTCW(loc1));
	RTHOOK(5);
	F1729_18054(Current, arg1);
	RTHOOK(6);
	F1729_18055(Current);
	RTHOOK(7);
	*(EIF_BOOLEAN *)(Current + O14521[dtype-1728]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(8);
	tb1 = F1687_17102(RTCW(loc1));
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(9);
		tb1 = F1728_18020(RTCW(loc1));
		if (tb1) {
			RTHOOK(10);
			tp1 = *(EIF_POINTER *)(RTCW(loc1) + O14438[Dtype(loc1)-1725]);
			tp1 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
			gdk_window_raise((GdkWindow*) tp1);
		}
	}
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {EV_GTK_WINDOW_IMP}.show_relative_to_window */
void F1729_18054 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("show_relative_to_window", 1728, Current, 0, 1, 23981);
	RTGC;
	RTHOOK(1);
	F1729_18028(Current, arg1);
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R14495[Dtype(Current)-1729])(Current);
	RTHOOK(3);
	F1729_18028(Current, arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_GTK_WINDOW_IMP}.block */
void F1729_18055 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("block", 1728, Current, 1, 0, 23982);
	RTGC;
	RTHOOK(1);
	loc1 = RTOSCF(17974,F1726_17974, (Current));
	for (;;) {
		RTHOOK(2);
		if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14525[Dtype(Current)-1729])(Current)) break;
		RTHOOK(3);
		F1711_17557(RTCW(loc1), (EIF_BOOLEAN) 1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_GTK_WINDOW_IMP}.blocking_condition */
EIF_BOOLEAN F1729_18056 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("blocking_condition", 1728, Current, 0, 0, 23983);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	tb1 = '\01';
	if (!F1687_17102(Current)) {
		tb1 = (EIF_BOOLEAN) !F1728_18020(Current);
	}
	if (!tb1) {
		tb1 = F1687_17102(RTCV(RTOSCF(17974,F1726_17974, (Current))));
		Result = tb1;
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GTK_WINDOW_IMP}.process_key_event */
RTEOMS(18058,3);
void F1729_18059 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc12 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_32 loc13 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc17 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc18 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_CHARACTER_8 tc1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(16);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,loc8);
	RTLR(4,loc6);
	RTLR(5,loc15);
	RTLR(6,loc16);
	RTLR(7,tr1);
	RTLR(8,tr2);
	RTLR(9,loc2);
	RTLR(10,loc9);
	RTLR(11,loc14);
	RTLR(12,loc10);
	RTLR(13,loc11);
	RTLR(14,loc19);
	RTLR(15,tr3);
	RTLIU(16);
	
	RTEAA("process_key_event", 1728, Current, 19, 1, 23984);
	RTGC;
	RTHOOK(1);
	loc5 = RTOSCF(17974,F1726_17974, (Current));
	RTHOOK(2);
	loc1 = (EIF_NATURAL_32) (((GdkEventKey *)arg1)->keyval);
	RTHOOK(3);
	if ((EIF_BOOLEAN) (loc1 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L))) {
		RTHOOK(4);
		if ((EIF_BOOLEAN) !F630_8426(Current, loc1)) {
			RTHOOK(5);
			if ((EIF_BOOLEAN)(loc1 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 268828432L))) {
				RTHOOK(6);
				loc1 = (EIF_NATURAL_32) GDK_KEY_F11;
			} else {
				RTHOOK(7);
				if ((EIF_BOOLEAN)(loc1 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 268828433L))) {
					RTHOOK(8);
					loc1 = (EIF_NATURAL_32) GDK_KEY_F12;
				} else {
					RTHOOK(9);
					loc1 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
				}
			}
		}
		RTHOOK(10);
		if ((EIF_BOOLEAN) (loc1 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L))) {
			RTHOOK(11);
			loc3 = RTLNS(eif_new_type(2025, 0x00).id, 2025, _OBJSIZ_0_0_0_1_0_0_0_0_);
			ti4_1 = F630_8425(Current, loc1);
			F2026_22953(RTCW(loc3), ti4_1);
		}
	}
	RTHOOK(12);
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) (((GdkEventKey *)arg1)->type) == (EIF_INTEGER_32) GDK_KEY_PRESS)) {
		RTHOOK(13);
		loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(14);
		loc8 = Current;
		loc8 = RTRV(eif_new_type(1810, 0x00), loc8);
		RTHOOK(15);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc3 != NULL) && (EIF_BOOLEAN)(loc8 != NULL))) {
			RTHOOK(16);
			loc6 = *(EIF_REFERENCE *)(RTCW(loc8) + O15628[Dtype(loc8)-1801]);
			RTHOOK(17);
			tb1 = '\0';
			if ((EIF_BOOLEAN)(loc6 != NULL)) {
				tb2 = F827_9290(RTCW(loc6));
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				RTHOOK(18);
				loc15 = F1147_10118(RTCW(loc6), ((EIF_INTEGER_32) 1L));
				RTHOOK(19);
				if ((EIF_BOOLEAN)(loc15 != NULL)) {
					RTHOOK(20);
					loc16 = *(EIF_REFERENCE *)(RTCW(loc15) + _REFACS_1_);
					loc16 = RTRV(eif_new_type(1709, 0x00), loc16);
					RTHOOK(21);
					RTCT0("l_accel_imp /= Void", EX_CHECK);
					if ((EIF_BOOLEAN)(loc16 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					RTHOOK(22);
					tr1 = *(EIF_REFERENCE *)(RTCW(loc8) + O15624[Dtype(loc8)-1801]);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_0_);
					tb1 = F1712_17689(RTCW(loc5));
					tb2 = F1712_17690(RTCW(loc5));
					tb3 = F1712_17691(RTCW(loc5));
					ti4_1 = F1709_17532(RTCW(loc16), ti4_1, tb1, tb2, tb3);
					loc15 = F1140_9986(RTCW(tr1), ti4_1);
					RTHOOK(23);
					if ((EIF_BOOLEAN)(loc15 != NULL)) {
						RTHOOK(24);
						loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						RTHOOK(25);
						{
							static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1419,1200,0xFFF9,0,1419,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr1 = RTLNTS(typres0.id, 3, 0);
						}
						tr2 = F1356_12469(RTCW(loc15));
						((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
						RTAR(tr1,tr2);
						
						{
							static EIF_TYPE_INDEX typarr0[] = {1493,0xFFF9,0,1419,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr2= RTLNRF(typres0.id, (EIF_POINTER) __A616_175, (EIF_POINTER) _A616_175, (EIF_POINTER)(F1177_10288),tr1, 1, 0);
						}
						F1711_17603(RTCW(loc5), tr2);
					}
				}
			}
		}
		RTHOOK(26);
		loc2 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_47_);
		RTHOOK(27);
		F1510_14595(RTCW(loc2));
		RTHOOK(28);
		tp1 = *(EIF_POINTER *)(RTCW(loc5)+ _PTROFF_49_16_0_20_0_3_);
		loc17 = (EIF_BOOLEAN) EIF_TEST(gtk_im_context_filter_keypress((GtkIMContext*) tp1, (GdkEventKey*) arg1));
		RTHOOK(29);
		if ((EIF_BOOLEAN) !loc7) {
			RTHOOK(30);
			tb1 = '\0';
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				tb2 = F1500_14167(RTCW(loc2), ((EIF_INTEGER_32) 1L));
				tb1 = tb2;
			}
			if (tb1) {
				RTHOOK(31);
				loc13 = F1510_14534(RTCW(loc2), ((EIF_INTEGER_32) 1L));
				RTHOOK(32);
				tb1 = '\0';
				tb2 = '\0';
				tb3 = (loc13 <= 0xFF);
				if (tb3) {
					tc1 = (EIF_CHARACTER_8) loc13;
					tr1 = RTLNS(eif_new_type(1455, 0x00).id, 1455, _OBJSIZ_0_1_0_0_0_0_0_0_);
					*(EIF_CHARACTER_8 *)tr1 = tc1;
					tb3 = F1454_14032(RTCW(tr1));
					tb2 = (EIF_BOOLEAN) !tb3;
				}
				if (tb2) {
					ti4_1 = (EIF_INTEGER_32) (loc13);
					tb1 = (EIF_BOOLEAN) (ti4_1 <= ((EIF_INTEGER_32) 127L));
				}
				if (tb1) {
					RTHOOK(33);
					loc2 = (EIF_REFERENCE) NULL;
				}
			} else {
				RTHOOK(34);
				loc2 = (EIF_REFERENCE) NULL;
			}
			RTHOOK(35);
			tb1 = '\0';
			tb2 = '\0';
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				tr1 = F2026_22962(RTCW(loc3));
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
				tb2 = (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 1L));
			}
			if (tb2) {
				tb2 = F2026_22957(RTCW(loc3));
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				RTHOOK(36);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_0_);
				switch (ti4_1) {
					case 39L:
						RTHOOK(37);
						loc2 = (EIF_REFERENCE) RTOMS(18058,0);
						break;
					case 41L:
						RTHOOK(38);
						loc2 = (EIF_REFERENCE) RTOMS(18058,1);
						break;
					case 43L:
						RTHOOK(39);
						loc2 = (EIF_REFERENCE) RTOMS(18058,2);
						break;
					default:
						RTHOOK(40);
						loc2 = (EIF_REFERENCE) NULL;
						break;
				}
			}
		}
	}
	RTHOOK(41);
	tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
	tp1 = (EIF_POINTER) gtk_window_get_focus((GtkWindow*) tp1);
	loc9 = F1712_17780(RTCW(loc5), tp1);
	loc9 = RTRV(eif_new_type(1773, 0x00), loc9);
	RTHOOK(42);
	loc14 = (EIF_REFERENCE) Current;
	RTHOOK(43);
	if ((EIF_BOOLEAN)(loc9 == NULL)) {
		RTHOOK(44);
		loc9 = RTCCL(loc14);
		loc9 = RTRV(eif_new_type(1773, 0x00), loc9);
		RTHOOK(45);
		if ((EIF_BOOLEAN)(loc9 == NULL)) {
			RTHOOK(46);
			loc10 = RTCCL(loc14);
			loc10 = RTRV(eif_new_type(1764, 0x00), loc10);
		}
	}
	RTHOOK(47);
	tb1 = '\0';
	tb2 = '\0';
	if ((EIF_BOOLEAN)(loc9 != NULL)) {
		tb3 = F1738_18166(RTCW(loc9));
		tb2 = tb3;
	}
	if (tb2) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14987[Dtype(RTCW(loc9))-1786])(loc9);
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(48);
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			RTHOOK(49);
			loc12 = F1773_18687(RTCW(loc9), loc3);
			RTHOOK(50);
			if ((EIF_BOOLEAN) !loc12) {
				RTHOOK(51);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_0_);
				loc18 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 43L));
				RTHOOK(52);
				if (loc18) {
					RTHOOK(53);
					tb1 = F1712_17691(RTCW(loc5));
					if (tb1) {
						RTHOOK(54);
						F1711_17628(RTCW(loc5), ((EIF_NATURAL_8) 2U));
					} else {
						RTHOOK(55);
						F1711_17628(RTCW(loc5), ((EIF_NATURAL_8) 1U));
					}
				}
				RTHOOK(56);
				loc11 = loc9;
				loc11 = RTRV(eif_new_type(1712, 0x00), loc11);
				RTHOOK(57);
				tb1 = '\0';
				if ((EIF_BOOLEAN)(loc11 != NULL)) {
					tb2 = *(EIF_BOOLEAN *)(RTCW(loc11) + O15924[Dtype(loc11)-1848]);
					tb1 = (EIF_BOOLEAN) !tb2;
				}
				if (tb1) {
					RTHOOK(58);
					loc12 = '\01';
					tb1 = F2026_22960(RTCW(loc3));
					if (!tb1) {
						loc12 = loc18;
					}
				}
			}
		}
		RTHOOK(59);
		if ((EIF_BOOLEAN) !loc12) {
			RTHOOK(60);
			gtk_main_do_event((GdkEvent*) arg1);
		}
		RTHOOK(61);
		tb1 = '\0';
		tb2 = '\0';
		tb3 = '\0';
		tr1 = F1712_17765(RTCW(loc5));
		loc19 = tr1;
		if (EIF_TEST(loc19)) {
			tb3 = loc4;
		}
		if (tb3) {
			tb2 = (EIF_BOOLEAN)(loc3 != NULL);
		}
		if (tb2) {
			tb2 = '\01';
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_0_);
			if (!(EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 42L))) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_0_);
				tb2 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 96L));
			}
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(62);
			tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
			tr8_2 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
			tr8_3 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
			F1772_18653(loc19, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), tr8_1, tr8_2, tr8_3, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
		} else {
			RTHOOK(63);
			if (loc4) {
				RTHOOK(64);
				tb1 = '\0';
				if ((EIF_BOOLEAN)(loc3 != NULL)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_14_);
					tb1 = (EIF_BOOLEAN)(tr1 != NULL);
				}
				if (tb1) {
					RTHOOK(65);
					tr1 = F258_4287(RTCW(loc5));
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1419,1574,2025,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr2 = RTLNTS(typres0.id, 3, 0);
					}
					tr3 = F1687_17103(RTCW(loc9));
					((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
					RTAR(tr2,tr3);
					((EIF_TYPED_VALUE *)tr2+2)->it_r = loc3;
					RTAR(tr2,loc3);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8518[Dtype(RTCW(tr1))-1175])(tr1, tr2);
				}
				RTHOOK(66);
				tb1 = '\0';
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_15_);
					tb1 = (EIF_BOOLEAN)(tr1 != NULL);
				}
				if (tb1) {
					RTHOOK(67);
					tr1 = F258_4289(RTCW(loc5));
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1419,1574,1509,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr2 = RTLNTS(typres0.id, 3, 0);
					}
					tr3 = F1687_17103(RTCW(loc9));
					((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
					RTAR(tr2,tr3);
					((EIF_TYPED_VALUE *)tr2+2)->it_r = loc2;
					RTAR(tr2,loc2);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8518[Dtype(RTCW(tr1))-1175])(tr1, tr2);
				}
			} else {
				RTHOOK(68);
				tb1 = '\0';
				if ((EIF_BOOLEAN)(loc3 != NULL)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_16_);
					tb1 = (EIF_BOOLEAN)(tr1 != NULL);
				}
				if (tb1) {
					RTHOOK(69);
					tr1 = F258_4291(RTCW(loc5));
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1419,1574,2025,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr2 = RTLNTS(typres0.id, 3, 0);
					}
					tr3 = F1687_17103(RTCW(loc9));
					((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
					RTAR(tr2,tr3);
					((EIF_TYPED_VALUE *)tr2+2)->it_r = loc3;
					RTAR(tr2,loc3);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8518[Dtype(RTCW(tr1))-1175])(tr1, tr2);
				}
			}
			RTHOOK(70);
			if ((EIF_BOOLEAN) !loc12) {
				RTHOOK(71);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R14527[dtype-1729])(Current, loc3, loc2, loc4);
			}
			RTHOOK(72);
			tb1 = '\0';
			if ((EIF_BOOLEAN)(loc9 != loc14)) {
				tb2 = F1687_17102(RTCW(loc9));
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				RTHOOK(73);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R15010[Dtype(RTCW(loc9))-1786])(loc9, loc3, loc2, loc4);
			}
		}
	} else {
		RTHOOK(74);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc10 != NULL) && loc4)) {
			RTHOOK(75);
			{
				/* INLINED CODE (EV_STANDARD_DIALOG_IMP.on_key_event) */
				(void) RTCW(loc10);
				/* END INLINED CODE */
			}
			;
		}
		RTHOOK(76);
		gtk_main_do_event((GdkEvent*) arg1);
	}
	RTHOOK(77);
	if (loc18) {
		RTHOOK(78);
		F1711_17628(RTCW(loc5), ((EIF_NATURAL_8) 0U));
	}
	RTHOOK(79);
	RTLE;
	RTEE;
}

/* {EV_GTK_WINDOW_IMP}.on_size_allocate */
void F1729_18061 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	
	
	RTEAA("on_size_allocate", 1728, Current, 0, 4, 23985);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O14515[Dtype(Current)-1728]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(2);
	RTEE;
}

/* {EV_GTK_WINDOW_IMP}.forbid_resize */
void F1729_18062 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("forbid_resize", 1728, Current, 3, 0, 23986);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_POINTER) calloc (sizeof(GdkGeometry), 1);
	RTHOOK(2);
	loc2 = F1729_18036(Current);
	RTHOOK(3);
	loc3 = F1729_18037(Current);
	RTHOOK(4);
	(((GdkGeometry *)loc1)->max_width = (gint)(loc2));
	RTHOOK(5);
	(((GdkGeometry *)loc1)->max_height = (gint)(loc3));
	RTHOOK(6);
	(((GdkGeometry *)loc1)->min_width = (gint)(loc2));
	RTHOOK(7);
	(((GdkGeometry *)loc1)->min_height = (gint)(loc3));
	RTHOOK(8);
	tp1 = *(EIF_POINTER *)(Current + O14438[Dtype(Current)-1725]);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp2 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp3 = tp2;
	ti4_1 = (EIF_INTEGER_32) GDK_HINT_MAX_SIZE;
	ti4_2 = (EIF_INTEGER_32) GDK_HINT_MIN_SIZE;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	gtk_window_set_geometry_hints((GtkWindow*) tp1, (GtkWidget*) tp3, (GdkGeometry*) loc1, (GdkWindowHints) ti4_1);
	RTHOOK(9);
	free(loc1);
	RTHOOK(10);
	RTLE;
	RTEE;
}

void EIF_Minit1006 (void)
{
	GTCX
	RTPOMS32(18058,2,"\011\000\000\000",1,9);
	RTPOMS32(18058,1,"\012\000\000\000",1,10);
	RTPOMS32(18058,0," \000\000\000",1,32);
}


#ifdef __cplusplus
}
#endif
