/*
 * Code for class EV_DIRECTORY_DIALOG_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1045.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F220_3702
static EIF_POINTER inline_F220_3702 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	return (EIF_POINTER) (gtk_file_chooser_dialog_new ((gchar*) arg1, (GtkWindow*) arg2, (GtkFileChooserAction) arg3, NULL, NULL))
	;
}
#define INLINE_F220_3702
#endif
#ifndef INLINE_F220_3686
static EIF_POINTER inline_F220_3686 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	return (EIF_POINTER) (gtk_dialog_add_button ((GtkDialog*) arg1, (gchar*) arg2, (gint) arg3))
	;
}
#define INLINE_F220_3686
#endif
#ifndef INLINE_F220_3688
static void inline_F220_3688 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_dialog_set_default_response ((GtkDialog*) arg1, (gint) arg2)
	;
}
#define INLINE_F220_3688
#endif
#ifndef INLINE_F220_3704
static EIF_POINTER inline_F220_3704 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gtk_file_chooser_get_filename ((GtkFileChooser*) arg1))
	;
}
#define INLINE_F220_3704
#endif
#ifndef INLINE_F220_3706
static void inline_F220_3706 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_file_chooser_set_filename ((GtkFileChooser*) arg1, (gchar*) arg2)
	;
}
#define INLINE_F220_3706
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DIRECTORY_DIALOG_IMP}.make */
void F1768_18545 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("make", 1767, Current, 2, 0, 24410);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_1_0_1_0_0_);
	tr1 = RTMS_EX_H("Select directory",16,1164560505);
	F1206_10395(RTCW(loc1), tr1);
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp2 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp3 = tp2;
	ti4_1 = (EIF_INTEGER_32) GTK_FILE_CHOOSER_ACTION_SELECT_FOLDER;
	tp1 = inline_F220_3702(tp1, tp3, ti4_1);
	F1726_17949(Current, tp1);
	RTHOOK(3);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_9_5_0_1_0_0_);
	tr1 = RTLNS(eif_new_type(219, 0x00).id, 219, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tp2 = F220_3458(RTCW(tr1));
	ti4_1 = (EIF_INTEGER_32) GTK_RESPONSE_OK;
	loc2 = inline_F220_3686(tp1, tp2, ti4_1);
	RTHOOK(4);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_9_5_0_1_0_0_);
	tr1 = RTLNS(eif_new_type(219, 0x00).id, 219, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tp2 = F220_3468(RTCW(tr1));
	ti4_1 = (EIF_INTEGER_32) GTK_RESPONSE_CANCEL;
	loc2 = inline_F220_3686(tp1, tp2, ti4_1);
	RTHOOK(5);
	F1765_18517(Current);
	RTHOOK(6);
	F1687_17117(Current, (EIF_BOOLEAN) 0);
	RTHOOK(7);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_9_5_0_1_0_0_);
	ti4_1 = (EIF_INTEGER_32) GTK_RESPONSE_ACCEPT;
	inline_F220_3688(tp1, ti4_1);
	RTHOOK(8);
	F1765_18525(Current);
	RTHOOK(9);
	tr1 = F642_8804(RTCV(RTOSCF(17974,F1726_17974, (Current))));
	F1768_18548(Current, tr1);
	RTHOOK(10);
	F1687_17117(Current, (EIF_BOOLEAN) 1);
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {EV_DIRECTORY_DIALOG_IMP}.path */
EIF_REFERENCE F1768_18546 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("path", 1767, Current, 1, 0, 24411);
	RTGC;
	RTHOOK(1);
	if (F1765_18527(Current)) {
		RTHOOK(2);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_9_5_0_1_0_0_);
		loc1 = inline_F220_3704(tp1);
		RTHOOK(3);
		tb1 = !loc1;
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(4);
			Result = RTLNS(eif_new_type(1385, 0x00).id, 1385, _OBJSIZ_2_1_0_0_0_0_0_0_);
			F1386_12836(RTCW(Result), loc1);
			RTHOOK(5);
			g_free((gpointer) loc1);
		} else {
			RTHOOK(6);
			Result = RTLNS(eif_new_type(1385, 0x00).id, 1385, _OBJSIZ_2_1_0_0_0_0_0_0_);
			F1386_12830(RTCW(Result));
			RTHOOK(7);
			RTLE;
			RTEE;
			return (EIF_REFERENCE) Result;
		}
	} else {
		RTHOOK(8);
		Result = RTLNS(eif_new_type(1385, 0x00).id, 1385, _OBJSIZ_2_1_0_0_0_0_0_0_);
		F1386_12830(RTCW(Result));
		RTHOOK(9);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) Result;
	}
	RTHOOK(10);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_DIRECTORY_DIALOG_IMP}.start_path */
EIF_REFERENCE F1768_18547 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_8_);
}


/* {EV_DIRECTORY_DIALOG_IMP}.set_start_path */
void F1768_18548 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTEAA("set_start_path", 1767, Current, 1, 1, 24413);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	loc1 = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F1206_10390(RTCW(loc1), arg1);
	RTHOOK(3);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_9_5_0_1_0_0_);
	tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	inline_F220_3706(tp1, tp2);
	RTHOOK(4);
	RTLE;
	RTEE;
}

void EIF_Minit1045 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
