/*
 * Code for class EV_TEXTABLE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1027.h"
#include <ev_gtk.h>
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F222_3951
static void inline_F222_3951 (EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	gtk_label_set_xalign ((GtkLabel*) arg1, (gfloat) arg2)
	;
}
#define INLINE_F222_3951
#endif
#ifndef INLINE_F222_3952
static void inline_F222_3952 (EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	gtk_label_set_yalign ((GtkLabel*) arg1, (gfloat) arg2)
	;
}
#define INLINE_F222_3952
#endif
#ifndef INLINE_F221_3727
static void inline_F221_3727 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_widget_set_margin_start ((GtkWidget *)arg1, (gint)arg2)
	;
}
#define INLINE_F221_3727
#endif
#ifndef INLINE_F221_3729
static void inline_F221_3729 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_widget_set_margin_end ((GtkWidget *)arg1, (gint)arg2)
	;
}
#define INLINE_F221_3729
#endif
#ifndef INLINE_F222_3860
static EIF_INTEGER_32 inline_F222_3860 (void)
{
	return (EIF_INTEGER_32) (GTK_JUSTIFY_CENTER)
	;
}
#define INLINE_F222_3860
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TEXTABLE_IMP}.textable_imp_initialize */
void F1750_18361 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("textable_imp_initialize", 1749, Current, 0, 0, 24258);
	RTGC;
	RTHOOK(1);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	tp1 = (EIF_POINTER) gtk_label_new((gchar*) tp2);
	*(EIF_POINTER *)(Current + O14778[dtype-1749]) = (EIF_POINTER) tp1;
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current + O14778[dtype-1749]);
	inline_F222_3951(tp1, (EIF_REAL_32) 0.0);
	RTHOOK(3);
	tp1 = *(EIF_POINTER *)(Current + O14778[dtype-1749]);
	inline_F222_3952(tp1, (EIF_REAL_32) 0.5);
	RTHOOK(4);
	tp1 = *(EIF_POINTER *)(Current + O14778[dtype-1749]);
	inline_F221_3727(tp1, ((EIF_INTEGER_32) 2L));
	RTHOOK(5);
	tp1 = *(EIF_POINTER *)(Current + O14778[dtype-1749]);
	inline_F221_3729(tp1, ((EIF_INTEGER_32) 2L));
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_TEXTABLE_IMP}.text */
EIF_REFERENCE F1750_18362 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("text", 1749, Current, 2, 0, 24259);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O14780[dtype-1749]);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTHOOK(2);
		tr1 = F1500_14214(loc2);
		Result = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
	} else {
		RTHOOK(3);
		tp1 = *(EIF_POINTER *)(Current + O14778[dtype-1749]);
		loc1 = (EIF_POINTER) gtk_label_get_label((GtkLabel*) tp1);
		RTHOOK(4);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(loc1 != tp1)) {
			RTHOOK(5);
			tr1 = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_1_0_1_0_0_);
			F1206_10397(RTCW(tr1), loc1);
			Result = F1206_10393(RTCW(tr1));
		} else {
			RTHOOK(6);
			Result = F1500_14214(RTMS_EX_H("",0,0));
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_TEXTABLE_IMP}.text_alignment */
EIF_INTEGER_32 F1750_18363 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("text_alignment", 1749, Current, 1, 0, 24260);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O14778[Dtype(Current)-1749]);
	loc1 = (EIF_INTEGER_32) gtk_label_get_justify((GtkLabel*) tp1);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == inline_F222_3860())) {
		RTHOOK(3);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	} else {
		RTHOOK(5);
		if ((EIF_BOOLEAN)(loc1 == (EIF_INTEGER_32) GTK_JUSTIFY_LEFT)) {
			RTHOOK(6);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			RTHOOK(7);
			if ((EIF_BOOLEAN)(loc1 == (EIF_INTEGER_32) GTK_JUSTIFY_RIGHT)) {
				RTHOOK(8);
				RTHOOK(9);
				RTLE;
				RTEE;
				return (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
			} else {
				
			}
		}
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_TEXTABLE_IMP}.align_text_center */
void F1750_18364 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("align_text_center", 1749, Current, 0, 0, 24261);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O14778[dtype-1749]);
	inline_F222_3951(tp1, (EIF_REAL_32) 0.5);
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current + O14778[dtype-1749]);
	inline_F222_3952(tp1, (EIF_REAL_32) 0.5);
	RTHOOK(3);
	tp1 = *(EIF_POINTER *)(Current + O14778[dtype-1749]);
	ti4_1 = inline_F222_3860();
	gtk_label_set_justify((GtkLabel*) tp1, (GtkJustification) ti4_1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_TEXTABLE_IMP}.align_text_left */
void F1750_18365 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("align_text_left", 1749, Current, 0, 0, 24262);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O14778[dtype-1749]);
	inline_F222_3951(tp1, (EIF_REAL_32) 0.0);
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current + O14778[dtype-1749]);
	inline_F222_3952(tp1, (EIF_REAL_32) 0.5);
	RTHOOK(3);
	tp1 = *(EIF_POINTER *)(Current + O14778[dtype-1749]);
	ti4_1 = (EIF_INTEGER_32) GTK_JUSTIFY_LEFT;
	gtk_label_set_justify((GtkLabel*) tp1, (GtkJustification) ti4_1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_TEXTABLE_IMP}.align_text_right */
void F1750_18366 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("align_text_right", 1749, Current, 0, 0, 24263);
	RTGC;
	RTHOOK(1);
	tp1 = *(EIF_POINTER *)(Current + O14778[dtype-1749]);
	inline_F222_3951(tp1, (EIF_REAL_32) 1.0);
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(Current + O14778[dtype-1749]);
	inline_F222_3952(tp1, (EIF_REAL_32) 0.5);
	RTHOOK(3);
	tp1 = *(EIF_POINTER *)(Current + O14778[dtype-1749]);
	ti4_1 = (EIF_INTEGER_32) GTK_JUSTIFY_RIGHT;
	gtk_label_set_justify((GtkLabel*) tp1, (GtkJustification) ti4_1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_TEXTABLE_IMP}.set_text */
void F1750_18367 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTEAA("set_text", 1749, Current, 2, 1, 24264);
	RTGC;
	RTHOOK(1);
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14779[dtype-1851])(Current)) {
		RTHOOK(2);
		loc2 = F1500_14214(RTCW(arg1));
		RTHOOK(3);
		if ((EIF_BOOLEAN)(loc2 == arg1)) {
			RTHOOK(4);
			tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc2);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + O14780[dtype-1749]) = (EIF_REFERENCE) tr1;
		} else {
			RTHOOK(5);
			RTAR(Current, loc2);
			*(EIF_REFERENCE *)(Current + O14780[dtype-1749]) = (EIF_REFERENCE) loc2;
		}
		RTHOOK(6);
		tr1 = RTOSCF(17974,F1726_17974, (Current));
		tr2 = F1750_18372(Current, arg1);
		loc1 = F1712_17790(RTCW(tr1), tr2);
		RTHOOK(7);
		tp1 = *(EIF_POINTER *)(Current + O14778[dtype-1749]);
		tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
		gtk_label_set_text_with_mnemonic((GtkLabel*) tp1, (gchar*) tp2);
	} else {
		RTHOOK(8);
		tr1 = RTOSCF(17974,F1726_17974, (Current));
		loc1 = F1712_17790(RTCW(tr1), arg1);
		RTHOOK(9);
		*(EIF_REFERENCE *)(Current + O14780[dtype-1749]) = (EIF_REFERENCE) NULL;
		RTHOOK(10);
		tp1 = *(EIF_POINTER *)(Current + O14778[dtype-1749]);
		tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
		gtk_label_set_text((GtkLabel*) tp1, (gchar*) tp2);
	}
	RTHOOK(11);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_0_1_0_0_);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
		RTHOOK(12);
		tp1 = *(EIF_POINTER *)(Current + O14778[dtype-1749]);
		gtk_widget_hide((GtkWidget*) tp1);
	} else {
		RTHOOK(13);
		tp1 = *(EIF_POINTER *)(Current + O14778[dtype-1749]);
		gtk_widget_show((GtkWidget*) tp1);
	}
	RTHOOK(14);
	RTLE;
	RTEE;
}

/* {EV_TEXTABLE_IMP}.accelerators_enabled */
EIF_BOOLEAN F1750_18370 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("accelerators_enabled", 1749, Current, 0, 0, 24266);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {EV_TEXTABLE_IMP}.u_lined_filter */
EIF_REFERENCE F1750_18372 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 loc2 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("u_lined_filter", 1749, Current, 2, 1, 24268);
	RTGC;
	RTHOOK(1);
	Result = F1500_14214(RTCW(arg1));
	RTHOOK(2);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
	for (;;) {
		RTHOOK(3);
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) break;
		RTHOOK(4);
		loc2 = F1510_14533(RTCW(Result), loc1);
		RTHOOK(5);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
		if ((EIF_BOOLEAN)(loc2 == tw1)) {
			RTHOOK(6);
			if ((EIF_BOOLEAN)(Result == arg1)) {
				RTHOOK(7);
				tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (Result);
				Result = (EIF_REFERENCE) tr1;
			}
			RTHOOK(8);
			if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 1L))) {
				RTHOOK(9);
				loc2 = F1510_14533(RTCW(Result), (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
				RTHOOK(10);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
				if ((EIF_BOOLEAN)(loc2 == tw1)) {
					RTHOOK(11);
					F1510_14587(RTCW(Result), loc1);
					RTHOOK(12);
					loc1--;
				} else {
					RTHOOK(13);
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
					F1510_14553(RTCW(Result), tw1, loc1);
				}
			} else {
				RTHOOK(14);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
				F1510_14553(RTCW(Result), tw1, loc1);
			}
		} else {
			RTHOOK(15);
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
			if ((EIF_BOOLEAN)(loc2 == tw1)) {
				RTHOOK(16);
				if ((EIF_BOOLEAN)(Result == arg1)) {
					RTHOOK(17);
					tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (Result);
					Result = (EIF_REFERENCE) tr1;
				}
				RTHOOK(18);
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
				F1510_14584(RTCW(Result), tw1, loc1);
			}
		}
		RTHOOK(19);
		loc1--;
	}
	RTHOOK(20);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit1027 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
