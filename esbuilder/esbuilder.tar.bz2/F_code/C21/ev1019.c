/*
 * Code for class EV_GRID_COLUMN_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1019.h"
#include "eif_built_in.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GRID_COLUMN_I}.make */
void F1742_18269 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 1741, Current, 0, 0, 24176);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_4_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTHOOK(2);
	tr1 = RTLNSMART(eif_new_type(1560, 0).id);
	F1345_12285(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	F1561_15098(RTCW(tr1), Current);
	RTHOOK(4);
	F1687_17117(Current, (EIF_BOOLEAN) 1);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_GRID_COLUMN_I}.set_parent_i */
void F1742_18270 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_parent_i", 1741, Current, 0, 1, 24177);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {EV_GRID_COLUMN_I}.set_physical_index */
void F1742_18271 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_physical_index", 1741, Current, 0, 1, 24178);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_4_0_1_) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {EV_GRID_COLUMN_I}.item */
EIF_REFERENCE F1742_18276 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("item", 1741, Current, 0, 1, 24183);
	RTGC;
	RTHOOK(1);
	tr1 = F1742_18323(Current);
	Result = F1798_19050(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_4_0_0_), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_COLUMN_I}.parent */
EIF_REFERENCE F1742_18277 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("parent", 1741, Current, 0, 0, 24184);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_7_) != NULL)) {
		RTHOOK(2);
		tr1 = F1742_18323(Current);
		Result = *(EIF_REFERENCE *)(RTCW(tr1) + O13786[Dtype(tr1)-1686]);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_COLUMN_I}.width */
EIF_INTEGER_32 F1742_18279 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("width", 1741, Current, 1, 0, 24186);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tb2 = *(EIF_BOOLEAN *)(RTCV(F1742_18323(Current))+ _CHROFF_113_50_);
	if (tb2) {
		tb2 = *(EIF_BOOLEAN *)(RTCV(F1742_18323(Current))+ _CHROFF_113_20_);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(2);
		loc1 = *(EIF_REFERENCE *)(RTCV(F1742_18323(Current)) + _REFACS_87_);
		RTHOOK(3);
		Result = F1151_10117(RTCW(loc1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_4_0_0_) + ((EIF_INTEGER_32) 1L)));
		ti4_1 = F1151_10117(RTCW(loc1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_4_0_0_));
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result - ti4_1);
	} else {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		Result = F1362_12530(RTCW(tr1));
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_COLUMN_I}.virtual_x_position */
EIF_INTEGER_32 F1742_18281 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("virtual_x_position", 1741, Current, 1, 0, 24188);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_9_1_) && EIF_TEST(loc1))) {
		RTHOOK(2);
		Result = *(EIF_INTEGER_32 *)(RTCV(F1742_18323(Current))+ _LNGOFF_113_55_10_15_);
		ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_7_0_0_0_);
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	} else {
		RTHOOK(3);
		Result = F1742_18282(Current);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) Result;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_COLUMN_I}.virtual_x_position_unlocked */
EIF_INTEGER_32 F1742_18282 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("virtual_x_position_unlocked", 1741, Current, 0, 0, 24189);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_7_) != NULL)) {
		RTHOOK(2);
		F1798_19264(RTCV(F1742_18323(Current)));
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(RTCV(F1742_18323(Current)) + _REFACS_87_);
		Result = F1151_10118(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_4_0_0_));
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_COLUMN_I}.unlock */
void F1742_18289 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("unlock", 1741, Current, 0, 0, 24196);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(2);
	tr1 = F1742_18323(Current);
	F1798_19088(RTCW(tr1), Current);
	RTHOOK(3);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) NULL;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_GRID_COLUMN_I}.ensure_visible */
void F1742_18292 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("ensure_visible", 1741, Current, 7, 0, 24199);
	RTGC;
	RTHOOK(1);
	loc5 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	RTHOOK(2);
	RTCT0("l_parent_i /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc5 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(3);
	F1798_19320(RTCW(loc5));
	RTHOOK(4);
	F1798_19317(RTCW(loc5));
	RTHOOK(5);
	loc1 = F1742_18281(Current);
	RTHOOK(6);
	loc2 = F1742_18279(Current);
	RTHOOK(7);
	ti4_1 = F1798_19072(RTCW(loc5));
	if ((EIF_BOOLEAN) (loc1 < ti4_1)) {
		RTHOOK(8);
		ti4_1 = F1798_19073(RTCW(loc5));
		F1798_19165(RTCW(loc5), loc1, ti4_1);
	} else {
		RTHOOK(9);
		ti4_1 = F1798_19072(RTCW(loc5));
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_113_55_10_8_);
		if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + loc2) > (EIF_INTEGER_32) (ti4_1 + ti4_2))) {
			RTHOOK(10);
			tb1 = *(EIF_BOOLEAN *)(RTCW(loc5)+ _CHROFF_113_14_);
			if (tb1) {
				RTHOOK(11);
				loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_4_0_0_);
				RTHOOK(12);
				loc3 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_113_55_10_8_);
				for (;;) {
					RTHOOK(13);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 1L)) || (EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 0L)))) break;
					RTHOOK(14);
					tr1 = F1798_19048(RTCW(loc5), loc4);
					ti4_1 = F1517_14712(RTCW(tr1));
					loc3 -= ti4_1;
					RTHOOK(15);
					loc4--;
				}
				RTHOOK(16);
				tr1 = F1798_19048(RTCW(loc5), (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L)));
				ti4_1 = F1517_14712(RTCW(tr1));
				loc3 += ti4_1;
			}
			RTHOOK(17);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_113_55_10_8_);
			if ((EIF_BOOLEAN) (loc2 >= ti4_1)) {
				RTHOOK(18);
				ti4_1 = F1798_19073(RTCW(loc5));
				F1798_19165(RTCW(loc5), loc1, ti4_1);
			} else {
				RTHOOK(19);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_113_55_10_8_);
				ti4_2 = F1798_19073(RTCW(loc5));
				F1798_19165(RTCW(loc5), (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + loc2) + loc3) - ti4_1), ti4_2);
			}
		}
	}
	RTHOOK(24);
	RTLE;
	RTEE;
}

/* {EV_GRID_COLUMN_I}.required_width_of_item_span */
EIF_INTEGER_32 F1742_18293 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,loc7);
	RTLR(1,Current);
	RTLR(2,loc4);
	RTLR(3,loc3);
	RTLR(4,loc6);
	RTLR(5,loc5);
	RTLR(6,tr1);
	RTLIU(7);
	
	RTEAA("required_width_of_item_span", 1741, Current, 8, 2, 24200);
	RTGC;
	RTHOOK(1);
	loc7 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	RTHOOK(2);
	RTCT0("l_parent_i /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc7 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(3);
	loc1 = (EIF_INTEGER_32) arg1;
	RTHOOK(4);
	loc2 = F1798_19249(RTCW(loc7));
	RTHOOK(5);
	loc4 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_84_);
	for (;;) {
		RTHOOK(6);
		if ((EIF_BOOLEAN) (loc1 > arg2)) break;
		RTHOOK(7);
		loc3 = F1147_10118(RTCW(loc4), loc1);
		RTHOOK(8);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc3);
			tb1 = (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_4_0_1_) < ti4_1);
		}
		if (tb1) {
			RTHOOK(9);
			loc6 = F1798_19407(RTCW(loc7), loc1);
			RTHOOK(10);
			tb1 = *(EIF_BOOLEAN *)(RTCW(loc6)+ _CHROFF_11_5_);
			if (tb1) {
				RTHOOK(11);
				/* INLINED CODE (SPECIAL.item) */
				tr1 = *((EIF_REFERENCE *)RTCW(loc3) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_4_0_1_)));
				/* END INLINED CODE */
				loc5 = tr1;
				RTHOOK(12);
				if ((EIF_BOOLEAN)(loc5 != NULL)) {
					RTHOOK(13);
					tr1 = F1687_17103(RTCW(loc5));
					ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R11878[Dtype(RTCW(tr1))-1518])(tr1);
					ti4_2 = F1798_19275(RTCW(loc7), loc5);
					ti4_1 = eif_max_int32 (Result,(EIF_INTEGER_32) (ti4_1 + ti4_2));
					Result = (EIF_INTEGER_32) ti4_1;
				}
			}
			RTHOOK(14);
			tb1 = '\0';
			ti4_1 = F1741_18209(RTCW(loc6));
			if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
				tb2 = *(EIF_BOOLEAN *)(RTCW(loc6)+ _CHROFF_11_1_);
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				RTHOOK(15);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_11_7_0_2_);
				loc1 += ti4_1;
			}
		}
		RTHOOK(16);
		loc1++;
	}
	RTHOOK(18);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_COLUMN_I}.enable_select */
void F1742_18294 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("enable_select", 1741, Current, 0, 0, 24201);
	RTGC;
	RTHOOK(1);
	F1742_18314(Current, (EIF_BOOLEAN) 1);
	RTHOOK(2);
	F1742_18317(Current, (EIF_BOOLEAN) 1);
	RTHOOK(3);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_7_) != NULL)) {
		RTHOOK(4);
		tr1 = F1742_18323(Current);
		F1798_19282(RTCW(tr1), Current);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_GRID_COLUMN_I}.disable_select */
void F1742_18295 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("disable_select", 1741, Current, 1, 0, 24202);
	RTGC;
	RTHOOK(1);
	F1742_18314(Current, (EIF_BOOLEAN) 0);
	RTHOOK(2);
	F1742_18317(Current, (EIF_BOOLEAN) 0);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(4);
		F1798_19282(loc1, Current);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_GRID_COLUMN_I}.count */
EIF_INTEGER_32 F1742_18298 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("count", 1741, Current, 1, 0, 24205);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		ti4_1 = F1798_19249(loc1);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ti4_1;
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) 0;
}

/* {EV_GRID_COLUMN_I}.is_selected */
EIF_BOOLEAN F1742_18299 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTEAA("is_selected", 1741, Current, 6, 0, 24206);
	RTGC;
	RTHOOK(1);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(2);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	loc3 = F1742_18298(Current);
	RTHOOK(4);
	loc5 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	RTHOOK(5);
	RTCT0("a_parent_i /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc5 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(6);
	loc6 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_4_0_0_);
	for (;;) {
		RTHOOK(7);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc2 > loc3))) break;
		RTHOOK(8);
		loc1 = F1798_19437(RTCW(loc5), loc6, loc2);
		RTHOOK(9);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTHOOK(10);
			loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			RTHOOK(11);
			Result = F1755_18420(RTCW(loc1));
		}
		RTHOOK(12);
		loc2++;
	}
	RTHOOK(13);
	if ((EIF_BOOLEAN) !loc4) {
		RTHOOK(14);
		Result = *(EIF_BOOLEAN *)(Current+ _CHROFF_9_2_);
		RTHOOK(15);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) Result;
	}
	RTHOOK(16);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_COLUMN_I}.is_selectable */
EIF_BOOLEAN F1742_18301 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("is_selectable", 1741, Current, 0, 0, 24208);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_7_) != NULL);
}

/* {EV_GRID_COLUMN_I}.set_title */
void F1742_18303 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("set_title", 1741, Current, 0, 1, 24210);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	F1369_12572(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_GRID_COLUMN_I}.set_width */
void F1742_18306 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTEAA("set_width", 1741, Current, 2, 1, 24213);
	RTGC;
	RTHOOK(1);
	loc1 = F1742_18279(Current);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	loc2 = tr1;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != loc1) && EIF_TEST(loc2))) {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		F1560_15089(RTCW(tr1), arg1);
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(loc2 + _REFACS_93_);
		tr1 = F1512_14622(RTCW(tr1));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,1560,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr2 = RTLNTS(typres0.id, 2, 0);
		}
		tr3 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
		RTAR(tr2,tr3);
		F1177_10288(RTCW(tr1), tr2);
		RTHOOK(5);
		F1798_19262(loc2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_4_0_0_));
		RTHOOK(6);
		F1798_19183(loc2);
		RTHOOK(7);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_9_1_)) {
			RTHOOK(8);
			F1798_19369(loc2, Current);
		}
	}
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {EV_GRID_COLUMN_I}.clear */
void F1742_18307 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLIU(2);
	
	RTEAA("clear", 1741, Current, 4, 0, 24214);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(2);
	loc2 = F1742_18298(Current);
	RTHOOK(3);
	loc3 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	RTHOOK(4);
	RTCT0("a_parent_i /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(5);
	loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_4_0_0_);
	for (;;) {
		RTHOOK(6);
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		RTHOOK(7);
		F1798_19434(RTCW(loc3), loc4, loc1, NULL);
		RTHOOK(8);
		loc1++;
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {EV_GRID_COLUMN_I}.update_for_removal */
void F1742_18311 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("update_for_removal", 1741, Current, 0, 0, 24218);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_9_1_)) {
		RTHOOK(2);
		F1742_18289(Current);
	}
	RTHOOK(3);
	F1742_18307(Current);
	RTHOOK(4);
	F1742_18295(Current);
	RTHOOK(5);
	F1742_18313(Current, (EIF_BOOLEAN) 0);
	RTHOOK(6);
	F1742_18316(Current);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EV_GRID_COLUMN_I}.destroy */
void F1742_18312 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("destroy", 1741, Current, 1, 0, 24219);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		F1798_19242(loc1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_4_0_0_));
	}
	RTHOOK(3);
	F1687_17118(Current, (EIF_BOOLEAN) 1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_GRID_COLUMN_I}.set_is_show_requested */
void F1742_18313 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_is_show_requested", 1741, Current, 0, 1, 24220);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_0_) = (EIF_BOOLEAN) arg1;
	RTHOOK(3);
	RTEE;
}

/* {EV_GRID_COLUMN_I}.internal_update_selection */
void F1742_18314 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc4);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTEAA("internal_update_selection", 1741, Current, 6, 1, 24221);
	RTGC;
	RTHOOK(1);
	loc6 = F1742_18299(Current);
	RTHOOK(2);
	loc4 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	RTHOOK(3);
	RTCT0("a_parent_i /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc4 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(4);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(5);
	loc3 = F1742_18298(Current);
	RTHOOK(6);
	loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_4_0_0_);
	for (;;) {
		RTHOOK(7);
		if ((EIF_BOOLEAN) (loc2 > loc3)) break;
		RTHOOK(8);
		loc1 = F1798_19437(RTCW(loc4), loc5, loc2);
		RTHOOK(9);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTHOOK(10);
			if (arg1) {
				RTHOOK(11);
				F1755_18428(RTCW(loc1));
			} else {
				RTHOOK(12);
				F1755_18429(RTCW(loc1));
			}
		}
		RTHOOK(13);
		loc2++;
	}
	RTHOOK(14);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (arg1 && (EIF_BOOLEAN) !loc6) || loc6)) {
		RTHOOK(15);
		F1742_18315(Current, loc6);
	}
	RTHOOK(16);
	RTLE;
	RTEE;
}

/* {EV_GRID_COLUMN_I}.call_selection_events */
void F1742_18315 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("call_selection_events", 1741, Current, 0, 1, 24222);
	RTGC;
	RTHOOK(1);
	if (arg1) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(RTCV(F1742_18323(Current)) + _REFACS_32_);
		if ((EIF_BOOLEAN)(tr1 != NULL)) {
			RTHOOK(3);
			tr1 = F1246_11577(RTCV(F1742_18323(Current)));
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0,0xFFFF};
				EIF_TYPE typres0;
				{
					EIF_TYPE l_type;
					l_type = eif_final_id(Y13786,Y13786_gen_type,dftype,1686);
					typarr0[3] = l_type.annotations | 0xFF00;
					typarr0[4] = l_type.id;
				}
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr2 = RTLNTS(typres0.id, 2, 0);
			}
			tr3 = F1687_17103(Current);
			((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
			RTAR(tr2,tr3);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8518[Dtype(RTCW(tr1))-1175])(tr1, tr2);
		}
		RTHOOK(4);
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) != NULL)) {
			RTHOOK(5);
			tr1 = *(EIF_REFERENCE *)(Current);
			F1177_10288(RTCW(tr1), NULL);
		}
	} else {
		RTHOOK(6);
		tr1 = *(EIF_REFERENCE *)(RTCV(F1742_18323(Current)) + _REFACS_34_);
		if ((EIF_BOOLEAN)(tr1 != NULL)) {
			RTHOOK(7);
			tr1 = F1246_11578(RTCV(F1742_18323(Current)));
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0,0xFFFF};
				EIF_TYPE typres0;
				{
					EIF_TYPE l_type;
					l_type = eif_final_id(Y13786,Y13786_gen_type,dftype,1686);
					typarr0[3] = l_type.annotations | 0xFF00;
					typarr0[4] = l_type.id;
				}
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr2 = RTLNTS(typres0.id, 2, 0);
			}
			tr3 = F1687_17103(Current);
			((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
			RTAR(tr2,tr3);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8518[Dtype(RTCW(tr1))-1175])(tr1, tr2);
		}
		RTHOOK(8);
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) != NULL)) {
			RTHOOK(9);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			F1177_10288(RTCW(tr1), NULL);
		}
	}
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {EV_GRID_COLUMN_I}.unparent */
void F1742_18316 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("unparent", 1741, Current, 0, 0, 24223);
	RTHOOK(1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) NULL;
	RTHOOK(3);
	RTEE;
}

/* {EV_GRID_COLUMN_I}.set_internal_is_selected */
void F1742_18317 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_internal_is_selected", 1741, Current, 0, 1, 24224);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_2_) = (EIF_BOOLEAN) arg1;
	RTHOOK(3);
	RTEE;
}

/* {EV_GRID_COLUMN_I}.set_index */
void F1742_18318 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_index", 1741, Current, 0, 1, 24225);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_4_0_0_) = (EIF_INTEGER_32) arg1;
	RTHOOK(5);
	RTEE;
}

/* {EV_GRID_COLUMN_I}.attached_parent_i */
EIF_REFERENCE F1742_18323 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("attached_parent_i", 1741, Current, 1, 0, 24230);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	RTHOOK(2);
	RTCT0("l_parent_i /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(3);
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) loc1;
}

void EIF_Minit1019 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
