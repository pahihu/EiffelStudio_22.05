
#ifndef _C21_ev1021_
#define _C21_ev1021_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1744_18328(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1744_18330(EIF_REFERENCE);
extern void EIF_Minit1021(void);
extern char *(*R14751[])();
extern long O14748[];
extern long O14749[];

#ifdef __cplusplus
}
#endif

#endif
