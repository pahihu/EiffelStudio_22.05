/*
 * Code for class EV_CLIPBOARD_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1031.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_CLIPBOARD_IMP}.make */
RTEOMS(18388,2);
void F1754_18389 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("make", 1753, Current, 1, 0, 24279);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F1206_10395(RTCW(loc1), RTOMS(18388,0));
	RTHOOK(2);
	tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	tp1 = (EIF_POINTER) gdk_atom_intern((gchar*) tp1, (gint) ((EIF_INTEGER_32) 1L));
	tp1 = (EIF_POINTER) gtk_clipboard_get((GdkAtom) tp1);
	*(EIF_POINTER *)(Current+ _PTROFF_1_1_0_0_0_0_) = (EIF_POINTER) tp1;
	RTHOOK(3);
	loc1 = RTLNS(eif_new_type(1205, 0x00).id, 1205, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F1206_10395(RTCW(loc1), RTOMS(18388,1));
	RTHOOK(4);
	tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	tp1 = (EIF_POINTER) gdk_atom_intern((gchar*) tp1, (gint) ((EIF_INTEGER_32) 1L));
	tp1 = (EIF_POINTER) gtk_clipboard_get((GdkAtom) tp1);
	*(EIF_POINTER *)(Current+ _PTROFF_1_1_0_0_0_1_) = (EIF_POINTER) tp1;
	RTHOOK(5);
	F1687_17117(Current, (EIF_BOOLEAN) 1);
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_CLIPBOARD_IMP}.destroy */
void F1754_18395 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("destroy", 1753, Current, 0, 0, 24285);
	RTHOOK(1);
	F1687_17118(Current, (EIF_BOOLEAN) 1);
	RTHOOK(2);
	RTEE;
}

void EIF_Minit1031 (void)
{
	GTCX
	RTPOMS(18388,1,"PRIMARY",7,921107801);
	RTPOMS(18388,0,"CLIPBOARD",9,1396792132);
}


#ifdef __cplusplus
}
#endif
