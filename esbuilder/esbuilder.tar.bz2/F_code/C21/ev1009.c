/*
 * Code for class EV_COLORIZABLE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1009.h"
#include <ev_gtk.h>
#include "eif_built_in.h"
#include <stdlib.h>
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F220_3299
static EIF_POINTER inline_F220_3299 (void)
{
	return (EIF_POINTER) (GTK_STYLE_PROPERTY_BACKGROUND_COLOR)
	;
}
#define INLINE_F220_3299
#endif
#ifndef INLINE_F220_3322
static void inline_F220_3322 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_POINTER arg3, EIF_POINTER arg4)
{
	gtk_style_context_get (arg1, arg2, arg3, arg4, NULL)
	;
}
#define INLINE_F220_3322
#endif
#ifndef INLINE_F220_3300
static EIF_POINTER inline_F220_3300 (void)
{
	return (EIF_POINTER) (GTK_STYLE_PROPERTY_COLOR)
	;
}
#define INLINE_F220_3300
#endif
#ifndef INLINE_F219_3016
static void inline_F219_3016 (EIF_POINTER arg1)
{
	g_object_unref((gpointer) arg1)
	;
}
#define INLINE_F219_3016
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_COLORIZABLE_IMP}.background_color_internal */
RTEOMS(18110,1);
EIF_REFERENCE F1732_18111 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_32 tr4_1;
	EIF_REAL_32 tr4_2;
	EIF_REAL_32 tr4_3;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("background_color_internal", 1731, Current, 3, 0, 24039);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O14583[Dtype(Current)-1731]);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTHOOK(2);
		tr1 = F1687_17103(loc3);
		Result = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
	} else {
		RTHOOK(3);
		loc1 = F1732_18131(Current);
		RTHOOK(4);
		tr1 = RTLNS(eif_new_type(221, 0x00).id, 221, _OBJSIZ_0_0_0_0_0_0_0_0_);
		Result = F222_4022(RTCW(tr1), loc1, RTOMS(18110,0));
		RTHOOK(5);
		if ((EIF_BOOLEAN)(Result == NULL)) {
			RTHOOK(6);
			loc2 = (EIF_POINTER) calloc (sizeof(GdkRGBA), 1);
			RTHOOK(7);
			gtk_style_context_save((GtkStyleContext*) loc1);
			RTHOOK(8);
			ti4_1 = (EIF_INTEGER_32) GTK_STATE_NORMAL;
			gtk_style_context_set_state((GtkStyleContext*) loc1, (GtkStateFlags) ti4_1);
			RTHOOK(9);
			ti4_1 = (EIF_INTEGER_32) gtk_style_context_get_state((GtkStyleContext*) loc1);
			tp1 = inline_F220_3299();
			inline_F220_3322(loc1, ti4_1, tp1, (EIF_POINTER *) &(loc2));
			RTHOOK(10);
			Result = RTLNS(eif_new_type(1384, 0x00).id, 1384, _OBJSIZ_2_0_0_0_0_0_0_0_);
			tr8_1 = (EIF_REAL_64) (((GdkRGBA *)loc2)->red);
			tr4_1 = (EIF_REAL_32) (tr8_1);
			tr8_1 = (EIF_REAL_64) (((GdkRGBA *)loc2)->green);
			tr4_2 = (EIF_REAL_32) (tr8_1);
			tr8_1 = (EIF_REAL_64) (((GdkRGBA *)loc2)->blue);
			tr4_3 = (EIF_REAL_32) (tr8_1);
			F1385_12790(RTCW(Result), tr4_1, tr4_2, tr4_3);
			RTHOOK(11);
			gdk_rgba_free((GdkRGBA*) loc2);
			RTHOOK(12);
			gtk_style_context_restore((GtkStyleContext*) loc1);
		}
	}
	RTHOOK(13);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_COLORIZABLE_IMP}.foreground_color_internal */
RTEOMS(18111,1);
EIF_REFERENCE F1732_18112 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_32 tr4_1;
	EIF_REAL_32 tr4_2;
	EIF_REAL_32 tr4_3;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("foreground_color_internal", 1731, Current, 3, 0, 24040);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O14584[dtype-1731]);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTHOOK(2);
		tr1 = F1687_17103(loc3);
		Result = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
	} else {
		RTHOOK(3);
		loc1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R14586[dtype-1786])(Current);
		RTHOOK(4);
		tr1 = RTLNS(eif_new_type(221, 0x00).id, 221, _OBJSIZ_0_0_0_0_0_0_0_0_);
		Result = F222_4022(RTCW(tr1), loc1, RTOMS(18111,0));
		RTHOOK(5);
		if ((EIF_BOOLEAN)(Result == NULL)) {
			RTHOOK(6);
			loc2 = (EIF_POINTER) calloc (sizeof(GdkRGBA), 1);
			RTHOOK(7);
			gtk_style_context_save((GtkStyleContext*) loc1);
			RTHOOK(8);
			ti4_1 = (EIF_INTEGER_32) GTK_STATE_NORMAL;
			gtk_style_context_set_state((GtkStyleContext*) loc1, (GtkStateFlags) ti4_1);
			RTHOOK(9);
			ti4_1 = (EIF_INTEGER_32) gtk_style_context_get_state((GtkStyleContext*) loc1);
			tp1 = inline_F220_3300();
			inline_F220_3322(loc1, ti4_1, tp1, (EIF_POINTER *) &(loc2));
			RTHOOK(10);
			Result = RTLNS(eif_new_type(1384, 0x00).id, 1384, _OBJSIZ_2_0_0_0_0_0_0_0_);
			tr8_1 = (EIF_REAL_64) (((GdkRGBA *)loc2)->red);
			tr4_1 = (EIF_REAL_32) (tr8_1);
			tr8_1 = (EIF_REAL_64) (((GdkRGBA *)loc2)->green);
			tr4_2 = (EIF_REAL_32) (tr8_1);
			tr8_1 = (EIF_REAL_64) (((GdkRGBA *)loc2)->blue);
			tr4_3 = (EIF_REAL_32) (tr8_1);
			F1385_12790(RTCW(Result), tr4_1, tr4_2, tr4_3);
			RTHOOK(11);
			gdk_rgba_free((GdkRGBA*) loc2);
			RTHOOK(12);
			gtk_style_context_restore((GtkStyleContext*) loc1);
		}
	}
	RTHOOK(13);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_COLORIZABLE_IMP}.set_background_color */
void F1732_18113 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("set_background_color", 1731, Current, 2, 1, 24041);
	RTGC;
	RTHOOK(1);
	RTCT0("has_implementation", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1699, 0),loc1);
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O14583[dtype-1731]) != tr1)) {
		RTHOOK(3);
		if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14582[dtype-1786])(Current)) {
			RTHOOK(4);
			tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
			gtk_event_box_set_visible_window((GtkEventBox*) tp1, (gboolean) (EIF_BOOLEAN) 1);
		}
		RTHOOK(5);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + O14583[dtype-1731]) = (EIF_REFERENCE) loc1;
		RTHOOK(6);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_REFERENCE)) R14571[dtype-1786])(Current, *(EIF_POINTER *)(Current + O14438[dtype-1725]), arg1);
		RTHOOK(7);
		tb1 = '\0';
		tb2 = '\0';
		loc2 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R14580[dtype-1786])(Current);
		if ((EIF_TRUE)) {
			tb3 = !loc2;
			tb2 = (EIF_BOOLEAN) !tb3;
		}
		if (tb2) {
			tb1 = (EIF_BOOLEAN)(loc2 != *(EIF_POINTER *)(Current + O14438[dtype-1725]));
		}
		if (tb1) {
			RTHOOK(8);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_REFERENCE)) R14571[dtype-1786])(Current, loc2, arg1);
		}
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {EV_COLORIZABLE_IMP}.real_set_default_background_color */
void F1732_18114 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER loc5 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,loc4);
	RTLIU(6);
	
	RTEAA("real_set_default_background_color", 1731, Current, 5, 1, 24042);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_POINTER) gtk_widget_get_style_context((GtkWidget*) arg1);
	RTHOOK(2);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14573[Dtype(Current)-1786])(Current);
	tr2 = RTMS_EX_H(" { background: ",15,1494617120);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
	tr2 = RTLNS(eif_new_type(221, 0x00).id, 221, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr3 = F222_4024(RTCW(tr2));
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr3);
	tr2 = RTMS_EX_H(";}\012",3,3898634);
	loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
	RTHOOK(3);
	loc4 = RTLNS(eif_new_type(655, 0x00).id, 655, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F656_8975(RTCW(loc4), loc3);
	RTHOOK(4);
	loc2 = (EIF_POINTER) gtk_css_provider_new();
	RTHOOK(5);
	tu4_1 = (EIF_NATURAL_32) GTK_STYLE_PROVIDER_PRIORITY_APPLICATION;
	gtk_style_context_add_provider((GtkStyleContext*) loc1, (GtkStyleProvider*) loc2, (guint) tu4_1);
	RTHOOK(6);
	tp1 = F656_8997(RTCW(loc4));
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(gtk_css_provider_load_from_data((GtkCssProvider*) loc2, (const gchar*) tp1, (gssize) ((EIF_INTEGER_32) -1L), (GError**) (EIF_POINTER *) &(loc5)))) {
	}
	RTHOOK(7);
	tb1 = !loc2;
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(8);
		inline_F219_3016(loc2);
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {EV_COLORIZABLE_IMP}.real_set_background_color */
void F1732_18115 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg2);
	RTLR(1,loc7);
	RTLR(2,loc8);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTEAA("real_set_background_color", 1731, Current, 8, 2, 24043);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tb2 = !arg1;
	if ((EIF_BOOLEAN) !tb2) {
		tb1 = (EIF_BOOLEAN)(arg2 != NULL);
	}
	if (tb1) {
		RTHOOK(2);
		loc1 = (EIF_POINTER) gtk_widget_get_style_context((GtkWidget*) arg1);
		RTHOOK(3);
		loc7 = RTLNS(eif_new_type(1504, 0x00).id, 1504, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1503_14285(RTCW(loc7), ((EIF_INTEGER_32) 1024L));
		RTHOOK(4);
		loc2 = F1385_12813(RTCW(arg2));
		RTHOOK(5);
		loc3 = F1385_12814(RTCW(arg2));
		RTHOOK(6);
		loc4 = F1385_12815(RTCW(arg2));
		RTHOOK(7);
		loc5 = ((EIF_INTEGER_32) 65535L);
		RTHOOK(8);
		loc8 = RTMS_EX_H("background",10,1679743332);
		RTHOOK(9);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14573[dtype-1786])(Current);
		tr2 = RTMS_EX_H(" {",2,8315);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
		tr2 = F1732_18122(Current, loc8, (EIF_REAL_64) ((EIF_REAL_64) (loc2) /  (EIF_REAL_64) (loc5)), (EIF_REAL_64) ((EIF_REAL_64) (loc3) /  (EIF_REAL_64) (loc5)), (EIF_REAL_64) ((EIF_REAL_64) (loc4) /  (EIF_REAL_64) (loc5)));
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
		tr2 = RTMS_EX_H("}\012",2,32010);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11633[Dtype(RTCW(loc7))-1504])(loc7, tr1);
		RTHOOK(10);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14573[dtype-1786])(Current);
		tr2 = RTMS_EX_H(":active {",9,1799874939);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
		tr4_1 = (EIF_REAL_32) (loc2);
		tr2 = RTLNS(eif_new_type(1446, 0x00).id, 1446, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)tr2 = (EIF_REAL_32) (tr4_1 * 0.90912397f);
		ti4_1 = F1445_13855(RTCW(tr2));
		ti4_1 = eif_max_int32 (ti4_1,((EIF_INTEGER_32) 0L));
		tr4_1 = (EIF_REAL_32) (loc3);
		tr2 = RTLNS(eif_new_type(1446, 0x00).id, 1446, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)tr2 = (EIF_REAL_32) (tr4_1 * 0.90912397f);
		ti4_2 = F1445_13855(RTCW(tr2));
		ti4_2 = eif_max_int32 (ti4_2,((EIF_INTEGER_32) 0L));
		tr4_1 = (EIF_REAL_32) (loc4);
		tr2 = RTLNS(eif_new_type(1446, 0x00).id, 1446, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)tr2 = (EIF_REAL_32) (tr4_1 * 0.90912397f);
		ti4_3 = F1445_13855(RTCW(tr2));
		ti4_3 = eif_max_int32 (ti4_3,((EIF_INTEGER_32) 0L));
		tr2 = F1732_18122(Current, loc8, (EIF_REAL_64) ((EIF_REAL_64) (ti4_1) /  (EIF_REAL_64) (loc5)), (EIF_REAL_64) ((EIF_REAL_64) (ti4_2) /  (EIF_REAL_64) (loc5)), (EIF_REAL_64) ((EIF_REAL_64) (ti4_3) /  (EIF_REAL_64) (loc5)));
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
		tr2 = RTMS_EX_H("}\012",2,32010);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11633[Dtype(RTCW(loc7))-1504])(loc7, tr1);
		RTHOOK(11);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14573[dtype-1786])(Current);
		tr2 = RTMS_EX_H(":hover {",8,592401275);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
		tr4_1 = (EIF_REAL_32) (loc2);
		tr2 = RTLNS(eif_new_type(1446, 0x00).id, 1446, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)tr2 = (EIF_REAL_32) (tr4_1 * 1.0909488000000001f);
		ti4_1 = F1445_13855(RTCW(tr2));
		ti4_1 = eif_min_int32 (ti4_1,loc5);
		tr4_1 = (EIF_REAL_32) (loc3);
		tr2 = RTLNS(eif_new_type(1446, 0x00).id, 1446, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)tr2 = (EIF_REAL_32) (tr4_1 * 1.0909488000000001f);
		ti4_2 = F1445_13855(RTCW(tr2));
		ti4_2 = eif_min_int32 (ti4_2,loc5);
		tr4_1 = (EIF_REAL_32) (loc4);
		tr2 = RTLNS(eif_new_type(1446, 0x00).id, 1446, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)tr2 = (EIF_REAL_32) (tr4_1 * 1.0909488000000001f);
		ti4_3 = F1445_13855(RTCW(tr2));
		ti4_3 = eif_min_int32 (ti4_3,loc5);
		tr2 = F1732_18122(Current, loc8, (EIF_REAL_64) ((EIF_REAL_64) (ti4_1) /  (EIF_REAL_64) (loc5)), (EIF_REAL_64) ((EIF_REAL_64) (ti4_2) /  (EIF_REAL_64) (loc5)), (EIF_REAL_64) ((EIF_REAL_64) (ti4_3) /  (EIF_REAL_64) (loc5)));
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
		tr2 = RTMS_EX_H("}\012",2,32010);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11633[Dtype(RTCW(loc7))-1504])(loc7, tr1);
		RTHOOK(12);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14573[dtype-1786])(Current);
		tr2 = RTMS_EX_H(":selected {",11,263296123);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
		tr2 = F1732_18122(Current, loc8, (EIF_REAL_64) ((EIF_REAL_64) ((EIF_INTEGER_32) (loc5 - loc2)) /  (EIF_REAL_64) (loc5)), (EIF_REAL_64) ((EIF_REAL_64) ((EIF_INTEGER_32) (loc5 - loc3)) /  (EIF_REAL_64) (loc5)), (EIF_REAL_64) ((EIF_REAL_64) ((EIF_INTEGER_32) (loc5 - (EIF_INTEGER_32) (loc4 / ((EIF_INTEGER_32) 2L)))) /  (EIF_REAL_64) (loc5)));
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
		tr2 = RTMS_EX_H(";}\012",3,3898634);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11633[Dtype(RTCW(loc7))-1504])(loc7, tr1);
		RTHOOK(13);
		ti4_1 = eif_max_int32 (loc2,loc3);
		loc6 = eif_max_int32 (ti4_1,loc4);
		RTHOOK(14);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14573[dtype-1786])(Current);
		tr2 = RTMS_EX_H(":disabled {",11,1773468539);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
		tr2 = F1732_18122(Current, loc8, (EIF_REAL_64) ((EIF_REAL_64) ((EIF_INTEGER_32) (loc6 + (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 - loc6) / ((EIF_INTEGER_32) 4L)))) /  (EIF_REAL_64) (loc5)), (EIF_REAL_64) ((EIF_REAL_64) ((EIF_INTEGER_32) (loc6 + (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc3 - loc6) / ((EIF_INTEGER_32) 4L)))) /  (EIF_REAL_64) (loc5)), (EIF_REAL_64) ((EIF_REAL_64) ((EIF_INTEGER_32) (loc6 + (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc4 - loc6) / ((EIF_INTEGER_32) 4L)))) /  (EIF_REAL_64) (loc5)));
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
		tr2 = RTMS_EX_H(";}\012",3,3898634);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11633[Dtype(RTCW(loc7))-1504])(loc7, tr1);
		RTHOOK(15);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE)) R14574[dtype-1786])(Current, loc1, arg2, loc7);
	}
	RTHOOK(16);
	RTLE;
	RTEE;
}

/* {EV_COLORIZABLE_IMP}.set_foreground_color */
void F1732_18116 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTEAA("set_foreground_color", 1731, Current, 2, 1, 24044);
	RTGC;
	RTHOOK(1);
	RTCT0("has_implementation", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1699, 0),loc1);
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(2);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O14584[dtype-1731]) != loc1)) {
		RTHOOK(3);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + O14584[dtype-1731]) = (EIF_REFERENCE) loc1;
		RTHOOK(4);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_REFERENCE)) R14572[dtype-1786])(Current, *(EIF_POINTER *)(Current + O14438[dtype-1725]), arg1);
		RTHOOK(5);
		tb1 = '\0';
		tb2 = '\0';
		loc2 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R14580[dtype-1786])(Current);
		if ((EIF_TRUE)) {
			tb3 = !loc2;
			tb2 = (EIF_BOOLEAN) !tb3;
		}
		if (tb2) {
			tb1 = (EIF_BOOLEAN)(loc2 != *(EIF_POINTER *)(Current + O14438[dtype-1725]));
		}
		if (tb1) {
			RTHOOK(6);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_REFERENCE)) R14572[dtype-1786])(Current, loc2, arg1);
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_COLORIZABLE_IMP}.real_set_foreground_color */
void F1732_18117 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc5 = (EIF_POINTER) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,loc6);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("real_set_foreground_color", 1731, Current, 6, 2, 24045);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tb2 = !arg1;
	if ((EIF_BOOLEAN) !tb2) {
		tb1 = (EIF_BOOLEAN)(arg2 != NULL);
	}
	if (tb1) {
		RTHOOK(2);
		loc5 = (EIF_POINTER) gtk_widget_get_style_context((GtkWidget*) arg1);
		RTHOOK(3);
		loc1 = F1385_12813(RTCW(arg2));
		RTHOOK(4);
		loc2 = F1385_12814(RTCW(arg2));
		RTHOOK(5);
		loc3 = F1385_12815(RTCW(arg2));
		RTHOOK(6);
		loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 65535L);
		RTHOOK(7);
		loc6 = F1732_18124(Current, (EIF_REAL_64) ((EIF_REAL_64) (loc1) /  (EIF_REAL_64) (loc4)), (EIF_REAL_64) ((EIF_REAL_64) (loc2) /  (EIF_REAL_64) (loc4)), (EIF_REAL_64) ((EIF_REAL_64) (loc3) /  (EIF_REAL_64) (loc4)));
		RTHOOK(8);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14573[dtype-1786])(Current);
		tr2 = RTMS_EX_H(", ",2,11296);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14573[dtype-1786])(Current);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
		tr2 = RTMS_EX_H(":active, ",9,1799877920);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14573[dtype-1786])(Current);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
		tr2 = RTMS_EX_H(":hover { color:",15,673149498);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, loc6);
		tr2 = RTMS_EX_H("; }\012",4,991984906);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE)) R14575[dtype-1786])(Current, loc5, arg2, tr1);
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {EV_COLORIZABLE_IMP}.set_default_colors */
void F1732_18118 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_default_colors", 1731, Current, 1, 0, 24046);
	RTGC;
	RTHOOK(1);
	*(EIF_REFERENCE *)(Current + O14583[dtype-1731]) = (EIF_REFERENCE) NULL;
	RTHOOK(2);
	*(EIF_REFERENCE *)(Current + O14584[dtype-1731]) = (EIF_REFERENCE) NULL;
	RTHOOK(3);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_REFERENCE)) R14572[dtype-1786])(Current, *(EIF_POINTER *)(Current + O14438[dtype-1725]), NULL);
	RTHOOK(4);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_REFERENCE)) R14571[dtype-1786])(Current, *(EIF_POINTER *)(Current + O14438[dtype-1725]), NULL);
	RTHOOK(5);
	tb1 = '\0';
	tb2 = '\0';
	loc1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R14580[dtype-1786])(Current);
	if ((EIF_TRUE)) {
		tb3 = !loc1;
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tb1 = (EIF_BOOLEAN)(loc1 != *(EIF_POINTER *)(Current + O14438[dtype-1725]));
	}
	if (tb1) {
		RTHOOK(6);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_REFERENCE)) R14572[dtype-1786])(Current, loc1, NULL);
		RTHOOK(7);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_REFERENCE)) R14571[dtype-1786])(Current, loc1, NULL);
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EV_COLORIZABLE_IMP}.style_element_name */
EIF_REFERENCE F1732_18119 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("style_element_name", 1731, Current, 0, 0, 24047);
	RTGC;
	RTHOOK(1);
	Result = RTMS_EX_H("*",1,42);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_COLORIZABLE_IMP}.apply_background_color_to_style_context */
void F1732_18120 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,arg3);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("apply_background_color_to_style_context", 1731, Current, 4, 3, 24048);
	RTGC;
	RTHOOK(1);
	loc2 = RTLNS(eif_new_type(655, 0x00).id, 655, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F656_8975(RTCW(loc2), arg3);
	RTHOOK(2);
	loc1 = (EIF_POINTER) gtk_css_provider_new();
	RTHOOK(3);
	tu4_1 = (EIF_NATURAL_32) GTK_STYLE_PROVIDER_PRIORITY_APPLICATION;
	gtk_style_context_add_provider((GtkStyleContext*) arg1, (GtkStyleProvider*) loc1, (guint) tu4_1);
	RTHOOK(4);
	tp1 = F656_8997(RTCW(loc2));
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(gtk_css_provider_load_from_data((GtkCssProvider*) loc1, (const gchar*) tp1, (gssize) ((EIF_INTEGER_32) -1L), (GError**) (EIF_POINTER *) &(loc3)))) {
		RTHOOK(5);
		loc4 = RTLNS(eif_new_type(1204, 0x00).id, 1204, _OBJSIZ_1_1_0_0_0_1_0_0_);
		F517_7067(RTCW(loc4), loc3);
		RTHOOK(6);
		tr1 = F1205_10382(RTCW(loc4));
		F1_27(Current, tr1);
		RTHOOK(7);
		F1205_10384(RTCW(loc4));
	}
	RTHOOK(8);
	tb1 = !loc1;
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(9);
		inline_F219_3016(loc1);
	}
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {EV_COLORIZABLE_IMP}.apply_foreground_color_to_style_context */
void F1732_18121 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,arg3);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("apply_foreground_color_to_style_context", 1731, Current, 4, 3, 24049);
	RTGC;
	RTHOOK(1);
	loc2 = RTLNS(eif_new_type(655, 0x00).id, 655, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F656_8975(RTCW(loc2), arg3);
	RTHOOK(2);
	loc1 = (EIF_POINTER) gtk_css_provider_new();
	RTHOOK(3);
	tu4_1 = (EIF_NATURAL_32) GTK_STYLE_PROVIDER_PRIORITY_APPLICATION;
	gtk_style_context_add_provider((GtkStyleContext*) arg1, (GtkStyleProvider*) loc1, (guint) tu4_1);
	RTHOOK(4);
	tp1 = F656_8997(RTCW(loc2));
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(gtk_css_provider_load_from_data((GtkCssProvider*) loc1, (const gchar*) tp1, (gssize) ((EIF_INTEGER_32) -1L), (GError**) (EIF_POINTER *) &(loc3)))) {
		RTHOOK(5);
		loc4 = RTLNS(eif_new_type(1204, 0x00).id, 1204, _OBJSIZ_1_1_0_0_0_1_0_0_);
		F517_7067(RTCW(loc4), loc3);
		RTHOOK(6);
		tr1 = F1205_10382(RTCW(loc4));
		F1_27(Current, tr1);
		RTHOOK(7);
		F1205_10384(RTCW(loc4));
	}
	RTHOOK(8);
	tb1 = !loc1;
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(9);
		inline_F219_3016(loc1);
	}
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {EV_COLORIZABLE_IMP}.new_css_color_style_string */
EIF_REFERENCE F1732_18122 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("new_css_color_style_string", 1731, Current, 0, 4, 24050);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1504, 0x00).id, 1504, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1503_14287(RTCW(Result), arg1);
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R11637[Dtype(RTCW(Result))-1504])(Result, (EIF_CHARACTER_8) ':');
	RTHOOK(3);
	tr1 = F1732_18124(Current, arg2, arg3, arg4);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11633[Dtype(RTCW(Result))-1504])(Result, tr1);
	RTHOOK(4);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R11637[Dtype(RTCW(Result))-1504])(Result, (EIF_CHARACTER_8) ';');
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_COLORIZABLE_IMP}.new_rgb_color_string */
EIF_REFERENCE F1732_18124 (EIF_REFERENCE Current, EIF_REAL_64 arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("new_rgb_color_string", 1731, Current, 0, 3, 24052);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1504, 0x00).id, 1504, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1503_14285(RTCW(Result), ((EIF_INTEGER_32) 16L));
	RTHOOK(2);
	tr1 = RTMS_EX_H("rgb(",4,1919377960);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11633[Dtype(RTCW(Result))-1504])(Result, tr1);
	RTHOOK(3);
	tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 255L));
	ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) (arg1 * tr8_1);
	F1505_14401(RTCW(Result), ti4_1);
	RTHOOK(4);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R11637[Dtype(RTCW(Result))-1504])(Result, (EIF_CHARACTER_8) ',');
	RTHOOK(5);
	tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 255L));
	ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) (arg2 * tr8_1);
	F1505_14401(RTCW(Result), ti4_1);
	RTHOOK(6);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R11637[Dtype(RTCW(Result))-1504])(Result, (EIF_CHARACTER_8) ',');
	RTHOOK(7);
	tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 255L));
	ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) (arg3 * tr8_1);
	F1505_14401(RTCW(Result), ti4_1);
	RTHOOK(8);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R11637[Dtype(RTCW(Result))-1504])(Result, (EIF_CHARACTER_8) ')');
	RTHOOK(9);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_COLORIZABLE_IMP}.background_color_style_context */
EIF_POINTER F1732_18131 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("background_color_style_context", 1731, Current, 0, 0, 24056);
	RTGC;
	RTHOOK(1);
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R14580[Dtype(Current)-1786])(Current);
	Result = (EIF_POINTER) gtk_widget_get_style_context((GtkWidget*) tp1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_COLORIZABLE_IMP}.foreground_color_style_context */
EIF_POINTER F1732_18132 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("foreground_color_style_context", 1731, Current, 0, 0, 24057);
	RTGC;
	RTHOOK(1);
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R14580[Dtype(Current)-1786])(Current);
	Result = (EIF_POINTER) gtk_widget_get_style_context((GtkWidget*) tp1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit1009 (void)
{
	GTCX
	RTPOMS(18110,0,"theme_bg_color",14,404494194);
	RTPOMS(18111,0,"theme_fg_color",14,405415794);
}


#ifdef __cplusplus
}
#endif
