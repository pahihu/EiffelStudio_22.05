/*
 * Code for class EV_PICK_AND_DROPABLE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1049.h"
#include <ev_gtk.h>
#include "eif_built_in.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F222_3910
static void inline_F222_3910 (EIF_POINTER arg1)
{
	gtk_menu_shell_cancel((GtkMenuShell*)arg1);
	;
}
#define INLINE_F222_3910
#endif
#ifndef INLINE_F222_3795
static EIF_POINTER inline_F222_3795 (EIF_POINTER arg1)
{
	return gtk_widget_get_display ((GtkWidget *)arg1)
	;
}
#define INLINE_F222_3795
#endif
#ifndef INLINE_F34_462
static EIF_INTEGER_32 inline_F34_462 (void)
{
	return GDK_SEAT_CAPABILITY_ALL;
	;
}
#define INLINE_F34_462
#endif
#ifndef INLINE_F219_3032
static void inline_F219_3032 (EIF_POINTER arg1)
{
	gdk_display_flush ((GdkDisplay *)arg1);
	;
}
#define INLINE_F219_3032
#endif
#ifndef INLINE_F67_861
static EIF_POINTER inline_F67_861 (void)
{
	return (GdkDevice*) gdk_seat_get_pointer((GdkSeat*) gdk_display_get_default_seat ((GdkDisplay*) gdk_display_get_default()));
	;
}
#define INLINE_F67_861
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PICK_AND_DROPABLE_IMP}.button_actions_handled_by_signals */
EIF_BOOLEAN F1772_18630 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("button_actions_handled_by_signals", 1771, Current, 0, 0, 24485);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {EV_PICK_AND_DROPABLE_IMP}.on_pointer_motion */
void F1772_18631 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_16 loc5 = (EIF_INTEGER_16) 0;
	EIF_INTEGER_16 loc6 = (EIF_INTEGER_16) 0;
	EIF_INTEGER_16 loc7 = (EIF_INTEGER_16) 0;
	EIF_INTEGER_16 loc8 = (EIF_INTEGER_16) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,arg1);
	RTLR(5,loc9);
	RTLIU(6);
	
	RTEAA("on_pointer_motion", 1771, Current, 9, 1, 24486);
	RTGC;
	RTHOOK(1);
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	loc4 = (EIF_REFERENCE) Current;
	RTHOOK(4);
	loc1 = Current;
	loc1 = RTRV(eif_new_type(1721, 0x00), loc1);
	RTHOOK(5);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTHOOK(6);
		tb1 = '\0';
		if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14969[dtype-1786])(Current)) {
			tb2 = '\01';
			tb3 = *(EIF_BOOLEAN *)(RTCW(loc1) + O14406[Dtype(loc1)-1721]);
			if (!tb3) {
				tr1 = F1712_17766(RTCV(RTOSCF(17974,F1726_17974, (Current))));
				tb2 = (EIF_BOOLEAN)(tr1 == loc1);
			}
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(7);
			loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			RTHOOK(8);
			ti4_1 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (arg1, ((EIF_INTEGER_32) 1L));
			ti4_2 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (arg1, ((EIF_INTEGER_32) 2L));
			tr8_1 = F1420_12931(RTCW(arg1), ((EIF_INTEGER_32) 3L));
			tr8_2 = F1420_12931(RTCW(arg1), ((EIF_INTEGER_32) 4L));
			tr8_3 = F1420_12931(RTCW(arg1), ((EIF_INTEGER_32) 5L));
			ti4_3 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (arg1, ((EIF_INTEGER_32) 6L));
			ti4_4 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (arg1, ((EIF_INTEGER_32) 7L));
			F1722_17911(RTCW(loc1), ti4_1, ti4_2, tr8_1, tr8_2, tr8_3, ti4_3, ti4_4);
		} else {
			RTHOOK(9);
			tb1 = '\0';
			tb2 = '\0';
			tb3 = *(EIF_BOOLEAN *)(RTCW(loc1) + O14406[Dtype(loc1)-1721]);
			if (tb3) {
				tb2 = F1771_18602(Current);
			}
			if (tb2) {
				tr1 = F1712_17765(RTCV(RTOSCF(17974,F1726_17974, (Current))));
				tb1 = (EIF_BOOLEAN)(tr1 == NULL);
			}
			if (tb1) {
				RTHOOK(10);
				loc5 = *(EIF_INTEGER_16 *)(RTCW(loc1) + O5075[Dtype(loc1)-332]);
				RTHOOK(11);
				loc6 = *(EIF_INTEGER_16 *)(RTCW(loc1) + O5076[Dtype(loc1)-332]);
				RTHOOK(12);
				tb1 = '\01';
				ti4_1 = (EIF_INTEGER_32) loc5;
				ti4_2 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (arg1, ((EIF_INTEGER_32) 1L));
				ti4_1 = eif_abs_int32 ((EIF_INTEGER_32) (ti4_1 - ti4_2));
				ti4_2 = ((EIF_INTEGER_32) 3L);
				if (!(EIF_BOOLEAN) (ti4_1 > ti4_2)) {
					ti4_1 = (EIF_INTEGER_32) loc6;
					ti4_2 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (arg1, ((EIF_INTEGER_32) 2L));
					ti4_1 = eif_abs_int32 ((EIF_INTEGER_32) (ti4_1 - ti4_2));
					ti4_2 = ((EIF_INTEGER_32) 3L);
					tb1 = (EIF_BOOLEAN) (ti4_1 > ti4_2);
				}
				if (tb1) {
					RTHOOK(13);
					loc7 = *(EIF_INTEGER_16 *)(RTCW(loc1) + O14407[Dtype(loc1)-1721]);
					RTHOOK(14);
					loc8 = *(EIF_INTEGER_16 *)(RTCW(loc1) + O14408[Dtype(loc1)-1721]);
					RTHOOK(15);
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					RTHOOK(16);
					F1722_17919(RTCW(loc1));
					RTHOOK(17);
					ti4_1 = (EIF_INTEGER_32) loc5;
					ti4_2 = (EIF_INTEGER_32) loc6;
					ti4_3 = (EIF_INTEGER_32) loc7;
					ti4_4 = (EIF_INTEGER_32) loc8;
					F1772_18650(Current, ti4_1, ti4_2, ((EIF_INTEGER_32) 1L), (EIF_BOOLEAN) 1, (EIF_REAL_64) 0.0, (EIF_REAL_64) 0.0, (EIF_REAL_64) 0.0, ti4_3, ti4_4, (EIF_BOOLEAN) 0);
				}
			}
		}
		RTHOOK(18);
		tr1 = F1712_17766(RTCV(RTOSCF(17974,F1726_17974, (Current))));
		if ((EIF_BOOLEAN)(tr1 == loc1)) {
			RTHOOK(19);
			loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
	}
	RTHOOK(20);
	tb1 = '\0';
	if (loc3) {
		tr1 = F1712_17765(RTCV(RTOSCF(17974,F1726_17974, (Current))));
		tb1 = (EIF_BOOLEAN)(tr1 == loc4);
	}
	if (tb1) {
		RTHOOK(21);
		ti4_1 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (arg1, ((EIF_INTEGER_32) 1L));
		ti4_2 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (arg1, ((EIF_INTEGER_32) 2L));
		tr8_1 = F1420_12931(RTCW(arg1), ((EIF_INTEGER_32) 3L));
		tr8_2 = F1420_12931(RTCW(arg1), ((EIF_INTEGER_32) 4L));
		tr8_3 = F1420_12931(RTCW(arg1), ((EIF_INTEGER_32) 5L));
		ti4_3 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (arg1, ((EIF_INTEGER_32) 6L));
		ti4_4 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (arg1, ((EIF_INTEGER_32) 7L));
		F1771_18615(Current, ti4_1, ti4_2, tr8_1, tr8_2, tr8_3, ti4_3, ti4_4);
		RTHOOK(22);
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTHOOK(23);
	tb1 = '\0';
	if (loc2) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14961[dtype-1786])(Current);
		loc9 = tr1;
		tb1 = EIF_TEST(loc9);
	}
	if (tb1) {
		RTHOOK(24);
		F1177_10288(loc9, arg1);
	}
	RTHOOK(25);
	RTLE;
	RTEE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.enable_capture */
void F1772_18634 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("enable_capture", 1771, Current, 2, 0, 24487);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14963[dtype-1786])(Current)) {
		RTHOOK(2);
		loc2 = (EIF_POINTER) gtk_grab_get_current();
		RTHOOK(3);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(loc2 != tp1)) {
			RTHOOK(4);
			if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_MENU((loc2)))) {
				RTHOOK(5);
				inline_F222_3910(loc2);
			}
		}
		RTHOOK(6);
		if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14491[dtype-1729])(Current)) {
			RTHOOK(7);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R14490[dtype-1729])(Current);
		}
		RTHOOK(8);
		loc1 = *(EIF_REFERENCE *)(Current + O13786[dtype-1686]);
		loc1 = RTRV(eif_new_type(1574, 0x00), loc1);
		
		RTHOOK(10);
		tr1 = RTOSCF(17974,F1726_17974, (Current));
		F1711_17581(RTCW(tr1), loc1);
		RTHOOK(11);
		tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R14484[dtype-1729])(Current);
		gtk_grab_add((GtkWidget*) tp1);
		RTHOOK(12);
		tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(17974,F1726_17974, (Current))) + _REFACS_44_);
		if ((EIF_BOOLEAN)(tr1 != F1728_18023(Current))) {
			RTHOOK(13);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R14964[dtype-1786])(Current);
		}
		RTHOOK(14);
		F1712_17777(RTCV(RTOSCF(17974,F1726_17974, (Current))));
	}
	RTHOOK(15);
	RTLE;
	RTEE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.disable_capture */
void F1772_18635 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("disable_capture", 1771, Current, 0, 0, 24488);
	RTGC;
	RTHOOK(1);
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14963[dtype-1786])(Current)) {
		RTHOOK(2);
		tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R14484[dtype-1729])(Current);
		gtk_grab_remove((GtkWidget*) tp1);
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(17974,F1726_17974, (Current))) + _REFACS_44_);
		if ((EIF_BOOLEAN)(tr1 != F1728_18023(Current))) {
			RTHOOK(4);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R14965[dtype-1786])(Current);
		}
		RTHOOK(5);
		tr1 = RTOSCF(17974,F1726_17974, (Current));
		F1711_17581(RTCW(tr1), NULL);
	}
	RTHOOK(6);
	F1712_17776(RTCV(RTOSCF(17974,F1726_17974, (Current))));
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.has_capture */
EIF_BOOLEAN F1772_18636 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("has_capture", 1771, Current, 0, 0, 24489);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(17974,F1726_17974, (Current))) + _REFACS_29_);
	if (!(EIF_BOOLEAN)(tr1 == *(EIF_REFERENCE *)(Current + O13786[Dtype(Current)-1686]))) {
		tr1 = F1712_17765(RTCV(RTOSCF(17974,F1726_17974, (Current))));
		Result = (EIF_BOOLEAN)(tr1 == Current);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_PICK_AND_DROPABLE_IMP}.grab_keyboard_and_mouse */
void F1772_18637 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("grab_keyboard_and_mouse", 1771, Current, 4, 0, 24490);
	RTGC;
	RTHOOK(1);
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R14484[dtype-1729])(Current);
	loc2 = inline_F222_3795(tp1);
	RTHOOK(2);
	loc3 = (EIF_POINTER) gdk_display_get_default_seat((GdkDisplay*) loc2);
	RTHOOK(3);
	F1712_17777(RTCV(RTOSCF(17974,F1726_17974, (Current))));
	RTHOOK(4);
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R14484[dtype-1729])(Current);
	tp1 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
	ti4_1 = inline_F34_462();
	loc1 = (EIF_INTEGER_32) gdk_seat_grab((GdkSeat*) loc3, (GdkWindow*) tp1, (GdkSeatCapabilities) ti4_1, (gboolean) (EIF_BOOLEAN) 1, (GdkCursor*) loc4, (const GdkEvent*) loc4, (GdkSeatGrabPrepareFunc) loc4, (gpointer) loc4);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.release_keyboard_and_mouse */
void F1772_18638 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("release_keyboard_and_mouse", 1771, Current, 2, 0, 24491);
	RTGC;
	RTHOOK(1);
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R14484[Dtype(Current)-1729])(Current);
	loc1 = inline_F222_3795(tp1);
	RTHOOK(2);
	loc2 = (EIF_POINTER) gdk_display_get_default_seat((GdkDisplay*) loc1);
	RTHOOK(3);
	gdk_seat_ungrab((GdkSeat*) loc2);
	RTHOOK(4);
	F1712_17776(RTCV(RTOSCF(17974,F1726_17974, (Current))));
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.activate_docking_source_hint */
void F1772_18639 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg3);
	RTLIU(3);
	
	RTEAA("activate_docking_source_hint", 1771, Current, 0, 3, 24492);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(17974,F1726_17974, (Current));
	F1712_17761(RTCW(tr1), arg1, arg2, arg3);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.deactivate_docking_source_hint */
void F1772_18640 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("deactivate_docking_source_hint", 1771, Current, 0, 0, 24493);
	RTGC;
	RTHOOK(1);
	F1712_17762(RTCV(RTOSCF(17974,F1726_17974, (Current))));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.draw_rubber_band */
void F1772_18641 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("draw_rubber_band", 1771, Current, 0, 0, 24494);
	RTGC;
	RTHOOK(1);
	F1711_17620(RTCV(RTOSCF(17974,F1726_17974, (Current))));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.erase_rubber_band */
void F1772_18642 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("erase_rubber_band", 1771, Current, 0, 0, 24495);
	RTGC;
	RTHOOK(1);
	F1711_17621(RTCV(RTOSCF(17974,F1726_17974, (Current))));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.enable_transport */
void F1772_18643 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("enable_transport", 1771, Current, 0, 0, 24496);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O14930[Dtype(Current)-1770]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	RTEE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.disable_transport */
void F1772_18644 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("disable_transport", 1771, Current, 0, 0, 24497);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O14930[Dtype(Current)-1770]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(3);
	RTEE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.pre_pick_steps */
void F1772_18645 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_16 ti2_1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("pre_pick_steps", 1771, Current, 1, 4, 24498);
	RTGC;
	RTHOOK(1);
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R14484[dtype-1729])(Current);
	tp1 = inline_F222_3795(tp1);
	inline_F219_3032(tp1);
	RTHOOK(2);
	tr1 = F1771_18617(Current);
	F1771_18616(Current, tr1);
	RTHOOK(3);
	loc1 = *(EIF_REFERENCE *)(Current + O14905[dtype-1770]);
	RTHOOK(4);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTHOOK(5);
		tr1 = RTOSCF(17974,F1726_17974, (Current));
		tr2 = RTCCL(loc1);
		F1712_17758(RTCW(tr1), Current, tr2);
	}
	RTHOOK(6);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O4095[dtype-244]) != NULL)) {
		RTHOOK(7);
		tr1 = *(EIF_REFERENCE *)(Current + O4095[dtype-244]);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1419,1425,1425,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr2 = RTLNTS(typres0.id, 3, 1);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_i4 = arg1;
		((EIF_TYPED_VALUE *)tr2+2)->it_i4 = arg2;
		F1177_10288(RTCW(tr1), tr2);
	}
	RTHOOK(8);
	ti2_1 = (EIF_INTEGER_16) arg3;
	*(EIF_INTEGER_16 *)(Current + O5086[dtype-332]) = (EIF_INTEGER_16) ti2_1;
	RTHOOK(9);
	ti2_1 = (EIF_INTEGER_16) arg4;
	*(EIF_INTEGER_16 *)(Current + O5087[dtype-332]) = (EIF_INTEGER_16) ti2_1;
	RTHOOK(10);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_16 *)(Current + O14935[dtype-1770]) == (EIF_INTEGER_16) ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN)(*(EIF_INTEGER_16 *)(Current + O14936[dtype-1770]) == (EIF_INTEGER_16) ((EIF_INTEGER_32) 0L)))) {
		RTHOOK(11);
		tr1 = RTOSCF(17974,F1726_17974, (Current));
		F1711_17616(RTCW(tr1), arg3, arg4);
	} else {
		RTHOOK(12);
		ti2_1 = *(EIF_INTEGER_16 *)(Current + O14935[dtype-1770]);
		ti4_1 = (EIF_INTEGER_32) ti2_1;
		if ((EIF_BOOLEAN) (ti4_1 > (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R14426[dtype-1726])(Current))) {
			RTHOOK(13);
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R14426[dtype-1726])(Current);
			ti2_1 = (EIF_INTEGER_16) ti4_1;
			*(EIF_INTEGER_16 *)(Current + O14935[dtype-1770]) = (EIF_INTEGER_16) ti2_1;
		}
		RTHOOK(14);
		ti2_1 = *(EIF_INTEGER_16 *)(Current + O14936[dtype-1770]);
		ti4_1 = (EIF_INTEGER_32) ti2_1;
		if ((EIF_BOOLEAN) (ti4_1 > (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R14427[dtype-1726])(Current))) {
			RTHOOK(15);
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R14427[dtype-1726])(Current);
			ti2_1 = (EIF_INTEGER_16) ti4_1;
			*(EIF_INTEGER_16 *)(Current + O14936[dtype-1770]) = (EIF_INTEGER_16) ti2_1;
		}
		RTHOOK(16);
		tr1 = RTOSCF(17974,F1726_17974, (Current));
		ti2_1 = *(EIF_INTEGER_16 *)(Current + O14935[dtype-1770]);
		ti4_1 = (EIF_INTEGER_32) ti2_1;
		ti2_1 = *(EIF_INTEGER_16 *)(Current + O14936[dtype-1770]);
		ti4_2 = (EIF_INTEGER_32) ti2_1;
		F1711_17616(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + (EIF_INTEGER_32) (arg3 - arg1)), (EIF_INTEGER_32) (ti4_2 + (EIF_INTEGER_32) (arg4 - arg2)));
	}
	RTHOOK(17);
	F1771_18622(Current, (EIF_BOOLEAN) 1);
	RTHOOK(18);
	RTLE;
	RTEE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.able_to_transport */
EIF_BOOLEAN F1772_18648 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("able_to_transport", 1771, Current, 0, 1, 24500);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	tb1 = '\0';
	tb2 = '\0';
	if (F1771_18602(Current)) {
		tb2 = (EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 1L));
	}
	if (tb2) {
		tb1 = (EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14969[Dtype(Current)-1786])(Current);
	}
	if (!tb1) {
		tb1 = '\0';
		tb2 = '\0';
		if (F1771_18601(Current)) {
			tb2 = (EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 3L));
		}
		if (tb2) {
			tb1 = (EIF_BOOLEAN) !F1771_18604(Current);
		}
		Result = tb1;
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_PICK_AND_DROPABLE_IMP}.on_mouse_button_event */
void F1772_18649 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_REAL_64 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc4);
	RTLR(4,tr1);
	RTLR(5,loc5);
	RTLIU(6);
	
	RTEAA("on_mouse_button_event", 1771, Current, 6, 9, 24501);
	RTGC;
	RTHOOK(1);
	ti4_1 = (EIF_INTEGER_32) GDK_BUTTON_RELEASE;
	loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN)(arg1 != ti4_1);
	RTHOOK(2);
	loc1 = RTOSCF(17974,F1726_17974, (Current));
	RTHOOK(3);
	loc3 = F1712_17764(RTCW(loc1));
	loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc3;
	RTHOOK(4);
	loc2 = F1728_18023(Current);
	RTHOOK(5);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTHOOK(6);
		tb1 = F1712_17764(RTCW(loc1));
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(7);
			if ((EIF_BOOLEAN)(arg4 == ((EIF_INTEGER_32) 1L))) {
				RTHOOK(8);
				loc4 = Current;
				loc4 = RTRV(eif_new_type(1721, 0x00), loc4);
				RTHOOK(9);
				tb1 = '\0';
				tb2 = '\0';
				if ((EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_BUTTON_PRESS)) {
					tb2 = (EIF_BOOLEAN)(loc4 != NULL);
				}
				if (tb2) {
					tb2 = '\01';
					if (!(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14969[dtype-1786])(Current)) {
						tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_INTEGER_32)) R14971[dtype-1786])(Current, arg4);
					}
					tb1 = tb2;
				}
				if (tb1) {
					RTHOOK(10);
					F1722_17907(RTCW(loc4), arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
				}
				RTHOOK(11);
				tb1 = '\0';
				if ((EIF_BOOLEAN)(loc4 != NULL)) {
					tb1 = (EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_BUTTON_RELEASE);
				}
				if (tb1) {
					RTHOOK(12);
					F1722_17918(RTCW(loc4), arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
				}
			} else {
				RTHOOK(13);
				tb1 = '\01';
				tb2 = '\0';
				if ((EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_BUTTON_RELEASE)) {
					tb3 = '\0';
					tb4 = '\0';
					if (F1771_18601(Current)) {
						tb4 = (EIF_BOOLEAN)(arg4 == ((EIF_INTEGER_32) 3L));
					}
					if (tb4) {
						tb3 = (EIF_BOOLEAN) !F1771_18604(Current);
					}
					tb2 = tb3;
				}
				if (!tb2) {
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_INTEGER_32, EIF_BOOLEAN)) R14974[dtype-1786])(Current, arg4, loc6);
				}
				if (tb1) {
					RTHOOK(14);
					F1772_18650(Current, arg2, arg3, arg4, loc6, arg5, arg6, arg7, arg8, arg9, (EIF_BOOLEAN) 0);
					RTHOOK(15);
					tr1 = *(EIF_REFERENCE *)(Current + O14905[dtype-1770]);
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 == NULL);
				}
			}
		} else {
			RTHOOK(16);
			loc5 = (EIF_REFERENCE) Current;
			RTHOOK(17);
			loc4 = loc5;
			loc4 = RTRV(eif_new_type(1721, 0x00), loc4);
			RTHOOK(18);
			tb1 = '\0';
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				tb1 = (EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_BUTTON_RELEASE);
			}
			if (tb1) {
				RTHOOK(19);
				F1722_17918(RTCW(loc4), arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
			}
			RTHOOK(20);
			tb1 = '\0';
			if ((EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_BUTTON_RELEASE)) {
				tr1 = F1712_17765(RTCW(loc1));
				tb1 = (EIF_BOOLEAN)(tr1 == loc5);
			}
			if (tb1) {
				RTHOOK(21);
				F1772_18653(Current, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
			}
		}
		RTHOOK(22);
		if (loc3) {
			RTHOOK(23);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64, EIF_INTEGER_32, EIF_INTEGER_32)) R14962[dtype-1786])(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
		}
	}
	RTHOOK(24);
	RTLE;
	RTEE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.start_transport */
void F1772_18650 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_BOOLEAN arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_REAL_64 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_BOOLEAN arg10)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTEAA("start_transport", 1771, Current, 2, 10, 24502);
	RTGC;
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R14951[dtype-1786])(Current, arg1, arg2, arg8, arg9);
	RTHOOK(2);
	loc2 = *(EIF_REFERENCE *)(Current + O14905[dtype-1770]);
	RTHOOK(3);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R14918[dtype-1786])(Current);
	RTHOOK(4);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTHOOK(5);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,6,1419,0,0,1425,1425,1425,1425,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr1 = RTLNTS(typres0.id, 7, 0);
		}
		((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
		RTAR(tr1,Current);
		((EIF_TYPED_VALUE *)tr1+2)->it_r = loc2;
		RTAR(tr1,loc2);
		((EIF_TYPED_VALUE *)tr1+3)->it_i4 = arg1;
		((EIF_TYPED_VALUE *)tr1+4)->it_i4 = arg2;
		((EIF_TYPED_VALUE *)tr1+5)->it_i4 = arg8;
		((EIF_TYPED_VALUE *)tr1+6)->it_i4 = arg9;
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1493,0xFFF9,0,1419,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2= RTLNRF(typres0.id, (EIF_POINTER) __A1049_232, (EIF_POINTER) _A1049_232, (EIF_POINTER)(0),tr1, 1, 0);
		}
		loc1 = (EIF_REFERENCE) tr2;
	}
	RTHOOK(6);
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_INTEGER_32, EIF_BOOLEAN)) R14974[dtype-1786])(Current, arg3, arg4)) {
		RTHOOK(7);
		tr1 = RTOSCF(17974,F1726_17974, (Current));
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14973[dtype-1786])(Current);
		tr3 = RTCCL(loc2);
		F1711_17625(RTCW(tr1), arg1, arg2, arg8, arg9, tr2, tr3, loc1, arg10);
	} else {
		RTHOOK(8);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTHOOK(9);
			(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE)) *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_4_2_0_3_0_0_))(
				*(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_4_2_0_3_0_1_),
				*(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_));
		}
	}
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.pebble_source */
EIF_REFERENCE F1772_18651 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("pebble_source", 1771, Current, 0, 0, 24503);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) F1687_17103(Current);
}

/* {EV_PICK_AND_DROPABLE_IMP}.ready_for_pnd_menu */
EIF_BOOLEAN F1772_18652 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("ready_for_pnd_menu", 1771, Current, 0, 2, 24504);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	tb1 = '\0';
	tb2 = '\01';
	if (!F1771_18603(Current)) {
		tb2 = F1771_18604(Current);
	}
	if (tb2) {
		tb1 = (EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 3L));
	}
	if (tb1) {
		Result = (EIF_BOOLEAN) !arg2;
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_PICK_AND_DROPABLE_IMP}.end_transport */
void F1772_18653 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER loc5 = (EIF_POINTER) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,loc6);
	RTLR(3,tr1);
	RTLR(4,loc4);
	RTLR(5,loc2);
	RTLR(6,loc1);
	RTLR(7,loc7);
	RTLR(8,tr2);
	RTLIU(9);
	
	RTEAA("end_transport", 1771, Current, 7, 8, 24505);
	RTGC;
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R14956[dtype-1786])(Current);
	RTHOOK(2);
	loc3 = RTOSCF(17974,F1726_17974, (Current));
	RTHOOK(3);
	F1772_18640(Current);
	RTHOOK(4);
	F1772_18642(Current);
	RTHOOK(5);
	F1771_18622(Current, (EIF_BOOLEAN) 0);
	RTHOOK(6);
	if ((EIF_BOOLEAN) !F1687_17102(Current)) {
		RTHOOK(7);
		tr1 = *(EIF_REFERENCE *)(Current + O14488[dtype-1727]);
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			RTHOOK(8);
			F1728_18010(Current, loc6);
		} else {
			RTHOOK(9);
			tp1 = *(EIF_POINTER *)(Current + O14438[dtype-1725]);
			loc5 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
			RTHOOK(10);
			{
				/* INLINED CODE (ANY.default_pointer) */
				tp1 = (EIF_POINTER)  0;
				/* END INLINED CODE */
			}
			if ((EIF_BOOLEAN)(loc5 != tp1)) {
				RTHOOK(11);
				{
					/* INLINED CODE (ANY.default_pointer) */
					tp1 = (EIF_POINTER)  0;
					/* END INLINED CODE */
				}
				tp2 = tp1;
				gdk_window_set_cursor((GdkWindow*) loc5, (GdkCursor*) tp2);
			}
		}
	}
	RTHOOK(12);
	loc4 = *(EIF_REFERENCE *)(Current + O14905[dtype-1770]);
	RTHOOK(13);
	if ((EIF_BOOLEAN)(loc4 != NULL)) {
		RTHOOK(14);
		tr1 = RTCCL(loc4);
		F1712_17759(RTCW(loc3), tr1);
		RTHOOK(15);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr1+1)->it_r = loc4;
		RTAR(tr1,loc4);
		loc2 = (EIF_REFERENCE) tr1;
		RTHOOK(16);
		tb1 = '\01';
		if (!(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_INTEGER_32)) R14971[dtype-1786])(Current, arg3)) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_INTEGER_32, EIF_BOOLEAN)) R14974[dtype-1786])(Current, arg3, (EIF_BOOLEAN) 0);
		}
		if (tb1) {
			RTHOOK(17);
			loc1 = F1771_18617(Current);
			RTHOOK(18);
			tb1 = '\0';
			loc7 = loc1;
			if (EIF_TEST(loc7)) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9249[Dtype(loc7)-1222])(loc7);
				tr2 = RTCCL(loc4);
				tb2 = F1178_10291(RTCW(tr1), tr2);
				tb1 = tb2;
			}
			if (tb1) {
				RTHOOK(19);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9249[Dtype(loc7)-1222])(loc7);
				F1178_10289(RTCW(tr1), loc2);
				RTHOOK(20);
				tr1 = F258_4267(RTCW(loc3));
				F1178_10289(RTCW(tr1), loc2);
			} else {
				RTHOOK(21);
				tr1 = F258_4269(RTCW(loc3));
				F1178_10289(RTCW(tr1), loc2);
			}
		} else {
			RTHOOK(22);
			tr1 = F258_4269(RTCW(loc3));
			F1178_10289(RTCW(tr1), loc2);
		}
		RTHOOK(23);
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O4097[dtype-244]) != NULL)) {
			RTHOOK(24);
			tr1 = *(EIF_REFERENCE *)(Current + O4097[dtype-244]);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,1220,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr2 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr2+1)->it_r = loc1;
			RTAR(tr2,loc1);
			F1177_10288(RTCW(tr1), tr2);
		}
	}
	RTHOOK(25);
	F1772_18643(Current);
	RTHOOK(26);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R14975[dtype-1786])(Current, arg3);
	RTHOOK(27);
	RTLE;
	RTEE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.post_drop_steps */
void F1772_18654 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("post_drop_steps", 1771, Current, 0, 1, 24506);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(17974,F1726_17974, (Current));
	F1711_17616(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R14918[Dtype(Current)-1786])(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.real_pointed_target */
EIF_REFERENCE F1772_18655 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_POINTER tp4;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,loc7);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc4);
	RTLR(4,tr2);
	RTLR(5,Result);
	RTLR(6,loc5);
	RTLR(7,loc6);
	RTLIU(8);
	
	RTEAA("real_pointed_target", 1771, Current, 7, 0, 24507);
	RTGC;
	RTHOOK(1);
	loc7 = RTOSCF(17974,F1726_17974, (Current));
	RTHOOK(2);
	tb1 = *(EIF_BOOLEAN *)(RTCW(loc7)+ _CHROFF_49_8_);
	if (tb1) {
	} else {
		RTHOOK(3);
		F1712_17771(RTCW(loc7));
	}
	RTHOOK(4);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_48_);
	loc1 = eif_pointer_item(RTCW(tr1),1);
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_48_);
	loc2 = eif_integer_32_item(RTCW(tr1),2);
	RTHOOK(6);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_48_);
	loc3 = eif_integer_32_item(RTCW(tr1),3);
	RTHOOK(7);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc1 != tp1)) {
		RTHOOK(8);
		loc4 = F1712_17782(RTCW(loc7), loc1);
		loc4 = RTRV(eif_new_type(1771, 0x00), loc4);
		RTHOOK(9);
		tb1 = '\0';
		tb2 = '\0';
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			tp1 = *(EIF_POINTER *)(RTCW(loc4) + O14438[Dtype(loc4)-1725]);
			tb2 = (EIF_BOOLEAN) EIF_TEST(gtk_widget_is_sensitive((GtkWidget*) tp1));
		}
		if (tb2) {
			tb2 = F1687_17102(RTCW(loc4));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			RTHOOK(10);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_27_);
			tr2 = F1687_17103(RTCW(loc4));
			ti4_1 = F1216_11061(RTCW(tr2));
			tb1 = F1141_9988(RTCW(tr1), ti4_1);
			if (tb1) {
				RTHOOK(11);
				Result = *(EIF_REFERENCE *)(RTCW(loc4) + O13786[Dtype(loc4)-1686]);
			}
			RTHOOK(12);
			loc5 = loc4;
			loc5 = RTRV(eif_new_type(486, 0x00), loc5);
			RTHOOK(13);
			if ((EIF_BOOLEAN)(loc5 != NULL)) {
				RTHOOK(14);
				tp1 = *(EIF_POINTER *)(RTCW(loc4) + O14438[Dtype(loc4)-1725]);
				tp1 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
				tp2 = inline_F67_861();
				{
					/* INLINED CODE (ANY.default_pointer) */
					tp3 = (EIF_POINTER)  0;
					/* END INLINED CODE */
				}
				tp4 = tp3;
				loc1 = (EIF_POINTER) gdk_window_get_device_position((GdkWindow*) tp1, (GdkDevice *) tp2, (gint*) (EIF_INTEGER_32 *) &(loc2), (gint*) (EIF_INTEGER_32 *) &(loc3), (GdkModifierType*) tp4);
				RTHOOK(15);
				loc6 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6034[Dtype(RTCW(loc5))-1850])(loc5, loc2, loc3);
				RTHOOK(16);
				tb1 = '\0';
				if ((EIF_BOOLEAN)(loc6 != NULL)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_27_);
					tr2 = F1687_17103(RTCW(loc6));
					ti4_1 = F1216_11061(RTCW(tr2));
					tb2 = F1141_9988(RTCW(tr1), ti4_1);
					tb1 = tb2;
				}
				if (tb1) {
					RTHOOK(17);
					Result = *(EIF_REFERENCE *)(RTCW(loc6) + O13786[Dtype(loc6)-1686]);
					RTHOOK(18);
					RTLE;
					RTEE;
					return (EIF_REFERENCE) Result;
				}
			}
		}
	}
	RTHOOK(19);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_PICK_AND_DROPABLE_IMP}.inline-agent#1 of start_transport */
void F1772_31959 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTEAA("inline-agent#1 of start_transport", 1771, Current, 2, 5, 24484);
	RTGC;
	RTHOOK(1);
	tr1 = RTCCL(arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O14905[dtype-1770]) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTHOOK(3);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R14955[dtype-1786])(Current);
		RTHOOK(4);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R14968[dtype-1786])(Current, arg2, arg3, arg4, arg5);
		RTHOOK(5);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O4101[dtype-244]) != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current + O4101[dtype-244]);
			tr2 = RTCCL(arg1);
			tb2 = F1178_10291(RTCW(tr1), tr2);
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(6);
			tr1 = *(EIF_REFERENCE *)(Current + O14909[dtype-1770]);
			loc1 = tr1;
			if (EIF_TEST(loc1)) {
				RTHOOK(7);
				F1728_18010(Current, loc1);
			} else {
				RTHOOK(8);
				tr1 = RTOSCF(5535,F333_5535, (Current));
				F1728_18010(Current, tr1);
			}
		} else {
			RTHOOK(9);
			tr1 = *(EIF_REFERENCE *)(Current + O14910[dtype-1770]);
			loc2 = tr1;
			if (EIF_TEST(loc2)) {
				RTHOOK(10);
				F1728_18010(Current, loc2);
			} else {
				RTHOOK(11);
				tr1 = RTOSCF(5536,F333_5536, (Current));
				F1728_18010(Current, tr1);
			}
		}
	}
	RTHOOK(12);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14973[dtype-1786])(Current);
	F1772_18639(Current, arg4, arg5, tr1);
	RTHOOK(13);
	RTLE;
	RTEE;
}

void EIF_Minit1049 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
