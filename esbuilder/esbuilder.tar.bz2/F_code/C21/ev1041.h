
#ifndef _C21_ev1041_
#define _C21_ev1041_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1764_18516(EIF_REFERENCE);
extern void EIF_Minit1041(void);
extern EIF_REFERENCE F165_2268(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,2268)

#ifdef __cplusplus
}
#endif

#endif
