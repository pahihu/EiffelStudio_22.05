
#ifndef _C21_ev1017_
#define _C21_ev1017_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1740_18178(EIF_REFERENCE);
extern void EIF_Minit1017(void);
extern char *(*R14616[])();
extern char *(*R14617[])();
extern char *(*R14619[])();

#ifdef __cplusplus
}
#endif

#endif
