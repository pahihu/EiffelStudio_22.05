
#ifndef _C38_se1893_
#define _C38_se1893_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F865_9301(EIF_REFERENCE);
extern void F865_9303(EIF_REFERENCE, EIF_NATURAL_8);
extern void F865_9307(EIF_REFERENCE, EIF_NATURAL_8);
extern void EIF_Minit1893(void);
extern void F1149_10165(EIF_REFERENCE);
extern EIF_BOOLEAN F707_9220(EIF_REFERENCE);
extern void F1149_10148(EIF_REFERENCE, EIF_NATURAL_8);
extern EIF_BOOLEAN F942_9502(EIF_REFERENCE);
extern void F1149_10152(EIF_REFERENCE, EIF_NATURAL_8);
extern void F1149_10142(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
