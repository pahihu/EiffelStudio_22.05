/*
 * Code for class BILINEAR [NATURAL_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "bi1894.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BILINEAR}.off */
EIF_BOOLEAN F719_9230 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("off", 718, Current, 0, 0, 9379);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	if (!F966_9527(Current)) {
		Result = F966_9526(Current);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {BILINEAR}.search */
void F719_9233 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("search", 718, Current, 0, 1, 9380);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if (F966_9527(Current)) {
		tb1 = (EIF_BOOLEAN) !F829_9290(Current);
	}
	if (tb1) {
		RTHOOK(2);
		F1149_10144(Current);
	}
	RTHOOK(3);
	F707_9216(Current, arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

void EIF_Minit1894 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
