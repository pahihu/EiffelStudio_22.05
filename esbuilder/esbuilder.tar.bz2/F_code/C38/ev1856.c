/*
 * Code for class EV_LITE_ACTION_SEQUENCE [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1856.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_LITE_ACTION_SEQUENCE}.call */
void F1177_10288 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("call", 1176, Current, 0, 1, 14089);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (F1147_10132(Current) > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(8703,F636_8703, (Current))) + _REFACS_1_);
		tr1 = F1706_17488(RTCW(tr1));
		F1711_17605(RTCW(tr1));
		RTHOOK(3);
		F1176_10254(Current, arg1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

void EIF_Minit1856 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
