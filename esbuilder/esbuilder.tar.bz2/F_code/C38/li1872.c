/*
 * Code for class LINEAR [NATURAL_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li1872.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LINEAR}.has */
EIF_BOOLEAN F707_9214 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("has", 706, Current, 0, 1, 9243);
	RTGC;
	RTHOOK(1);
	F1149_10142(Current);
	RTHOOK(2);
	if ((EIF_BOOLEAN) !F942_9502(Current)) {
		RTHOOK(3);
		F1149_10148(Current, arg1);
	}
	RTHOOK(4);
	Result = F707_9220(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {LINEAR}.index_of */
EIF_INTEGER_32 F707_9215 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("index_of", 706, Current, 2, 2, 9244);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) && EIF_TRUE)) {
		RTHOOK(2);
		F1149_10142(Current);
		RTHOOK(3);
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			RTHOOK(4);
			tb1 = '\01';
			if (!F707_9220(Current)) {
				tb1 = (EIF_BOOLEAN)(loc1 == arg2);
			}
			if (tb1) break;
			RTHOOK(5);
			if ((F1149_10116(Current) == arg1)) {
				RTHOOK(6);
				loc1++;
			}
			RTHOOK(7);
			F1149_10144(Current);
			RTHOOK(8);
			loc2++;
		}
	} else {
		RTHOOK(9);
		F1149_10142(Current);
		RTHOOK(10);
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			RTHOOK(11);
			tb2 = '\01';
			if (!F707_9220(Current)) {
				tb2 = (EIF_BOOLEAN)(loc1 == arg2);
			}
			if (tb2) break;
			RTHOOK(12);
			if ((EIF_BOOLEAN)(F1149_10116(Current) == arg1)) {
				RTHOOK(13);
				loc1++;
			}
			RTHOOK(14);
			F1149_10144(Current);
			RTHOOK(15);
			loc2++;
		}
	}
	RTHOOK(16);
	if ((EIF_BOOLEAN)(loc1 == arg2)) {
		RTHOOK(17);
		RTHOOK(18);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
	}
	RTHOOK(20);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) 0;
}

/* {LINEAR}.search */
void F707_9216 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("search", 706, Current, 0, 1, 9245);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
		for (;;) {
			RTHOOK(2);
			tb1 = '\01';
			if (!F707_9220(Current)) {
				tb1 = (arg1 == F1149_10116(Current));
			}
			if (tb1) break;
			RTHOOK(3);
			F1149_10144(Current);
		}
	} else {
		for (;;) {
			RTHOOK(4);
			tb2 = '\01';
			if (!F707_9220(Current)) {
				tb2 = (EIF_BOOLEAN)(arg1 == F1149_10116(Current));
			}
			if (tb2) break;
			RTHOOK(5);
			F1149_10144(Current);
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {LINEAR}.item_for_iteration */
EIF_NATURAL_8 F707_9219 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("item_for_iteration", 706, Current, 0, 0, 9247);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_NATURAL_8) F1149_10116(Current);
}

/* {LINEAR}.exhausted */
EIF_BOOLEAN F707_9220 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("exhausted", 706, Current, 0, 0, 9248);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) F942_9502(Current);
}

/* {LINEAR}.off */
EIF_BOOLEAN F707_9222 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("off", 706, Current, 0, 0, 9249);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	if (!F829_9290(Current)) {
		Result = F966_9526(Current);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {LINEAR}.do_all */
void F707_9225 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_NATURAL_8 tu1_1;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTEAA("do_all", 706, Current, 3, 1, 9250);
	RTGC;
	RTHOOK(1);
	loc3 = Current;
	{
		static EIF_TYPE_INDEX typarr0[] = {801,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y7816,Y7816_gen_type,dftype,656);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		
		typres0 = eif_compound_id(dftype, typarr0);
		loc3 = RTRV(typres0,loc3);
	}
	if (EIF_TEST(loc3)) {
		RTHOOK(2);
		loc2 = (EIF_REFERENCE) loc3;
		RTHOOK(3);
		loc1 = F1149_10122(loc3);
	}
	RTHOOK(4);
	F1149_10142(Current);
	for (;;) {
		RTHOOK(5);
		if (F966_9526(Current)) break;
		RTHOOK(6);
		tu1_1 = F1149_10116(Current);
		(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_NATURAL_8)) *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_0_))(
			*(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_1_),
			*(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_), tu1_1);
		RTHOOK(7);
		F1149_10144(Current);
	}
	RTHOOK(8);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc2 != NULL) && (EIF_BOOLEAN)(loc1 != NULL))) {
		RTHOOK(9);
		F1149_10147(RTCW(loc2), loc1);
	}
	RTHOOK(10);
	RTLE;
	RTEE;
}

/* {LINEAR}.linear_representation */
EIF_REFERENCE F707_9229 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("linear_representation", 706, Current, 0, 0, 9254);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) Current;
}

void EIF_Minit1872 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
