/*
 * Code for class DYNAMIC_CHAIN [NATURAL_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "dy1898.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DYNAMIC_CHAIN}.extendible */
EIF_BOOLEAN F954_9511 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("extendible", 953, Current, 0, 0, 10913);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {DYNAMIC_CHAIN}.prune */
void F954_9517 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("prune", 953, Current, 0, 1, 10908);
	RTGC;
	RTHOOK(1);
	F1149_10148(Current, arg1);
	RTHOOK(2);
	if ((EIF_BOOLEAN) !F707_9220(Current)) {
		RTHOOK(3);
		F1149_10165(Current);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {DYNAMIC_CHAIN}.prune_all */
void F954_9518 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("prune_all", 953, Current, 0, 1, 10909);
	RTGC;
	RTHOOK(1);
	F1149_10142(Current);
	RTHOOK(2);
	F1149_10148(Current, arg1);
	for (;;) {
		RTHOOK(3);
		if (F707_9220(Current)) break;
		RTHOOK(4);
		F1149_10165(Current);
		RTHOOK(5);
		F1149_10148(Current, arg1);
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

void EIF_Minit1898 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
