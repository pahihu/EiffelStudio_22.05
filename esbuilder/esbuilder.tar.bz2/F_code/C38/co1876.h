
#ifndef _C38_co1876_
#define _C38_co1876_

#ifdef __cplusplus
extern "C" {
#endif

extern void F680_9061(EIF_REFERENCE);
extern void F680_9062(EIF_REFERENCE);
extern EIF_INTEGER_32 F680_9064(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1876(void);
extern char *(*R8043[])();
extern char *(*R8044[])();
extern char *(*R8019[])();
extern long O7864[];
extern EIF_TYPE_INDEX Y7816[];
extern EIF_TYPE_INDEX *Y7816_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
