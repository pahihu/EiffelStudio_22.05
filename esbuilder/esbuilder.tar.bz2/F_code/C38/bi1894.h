
#ifndef _C38_bi1894_
#define _C38_bi1894_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F719_9230(EIF_REFERENCE);
extern void F719_9233(EIF_REFERENCE, EIF_NATURAL_8);
extern void EIF_Minit1894(void);
extern void F707_9216(EIF_REFERENCE, EIF_NATURAL_8);
extern EIF_BOOLEAN F966_9527(EIF_REFERENCE);
extern void F1149_10144(EIF_REFERENCE);
extern EIF_BOOLEAN F829_9290(EIF_REFERENCE);
extern EIF_BOOLEAN F966_9526(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
