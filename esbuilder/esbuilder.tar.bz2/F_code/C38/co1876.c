/*
 * Code for class CONTAINER [NATURAL_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co1876.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONTAINER}.compare_objects */
void F680_9061 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("compare_objects", 679, Current, 0, 0, 8984);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O7864[Dtype(Current)-677]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	RTEE;
}

/* {CONTAINER}.compare_references */
void F680_9062 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("compare_references", 679, Current, 0, 0, 8985);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O7864[Dtype(Current)-677]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(3);
	RTEE;
}

/* {CONTAINER}.estimated_count_of */
EIF_INTEGER_32 F680_9064 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("estimated_count_of", 679, Current, 2, 1, 8986);
	RTGC;
	RTHOOK(1);
	loc1 = arg1;
	{
		static EIF_TYPE_INDEX typarr0[] = {828,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y7816,Y7816_gen_type,dftype,656);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		
		typres0 = eif_compound_id(dftype, typarr0);
		loc1 = RTRV(typres0,loc1);
	}
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8019[Dtype(loc1)-878])(loc1);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ti4_1;
	} else {
		RTHOOK(4);
		loc2 = arg1;
		{
			static EIF_TYPE_INDEX typarr0[] = {897,0,0,0xFFFF};
			EIF_TYPE typres0;
			{
				EIF_TYPE l_type;
				l_type = eif_final_id(Y7816,Y7816_gen_type,dftype,656);
				typarr0[1] = l_type.annotations | 0xFF00;
				typarr0[2] = l_type.id;
			}
			
			typres0 = eif_compound_id(dftype, typarr0);
			loc2 = RTRV(typres0,loc2);
		}
		if (EIF_TEST(loc2)) {
			RTHOOK(5);
			Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8044[Dtype(loc2)-919])(loc2);
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8043[Dtype(loc2)-919])(loc2);
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (Result - ti4_1) + ((EIF_INTEGER_32) 1L));
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit1876 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
