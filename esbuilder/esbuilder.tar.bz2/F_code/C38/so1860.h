
#ifndef _C38_so1860_
#define _C38_so1860_

#ifdef __cplusplus
extern "C" {
#endif

extern void F211_2840(EIF_REFERENCE, EIF_REFERENCE);
extern void F211_2849(EIF_REFERENCE, EIF_REFERENCE);
extern void F211_2850(EIF_REFERENCE, EIF_REFERENCE);
extern void F211_2851(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1860(void);
extern void F323_5449(EIF_REFERENCE, EIF_REFERENCE);
extern void F212_2855(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern char *(*R8043[])();
extern char *(*R8044[])();
extern char *(*R7862[])();
extern EIF_TYPE_INDEX Y2833[];
extern EIF_TYPE_INDEX *Y2833_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
