
#ifndef _C38_ha1866_
#define _C38_ha1866_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1066_9805(EIF_REFERENCE);
extern EIF_REFERENCE F1066_9806(EIF_REFERENCE);
extern EIF_BOOLEAN F1066_9808(EIF_REFERENCE);
extern void F1066_9809(EIF_REFERENCE);
extern EIF_REFERENCE F1066_9810(EIF_REFERENCE);
extern void EIF_Minit1866(void);
extern char *(*R8395[])();
extern char *(*R8396[])();
extern char *(*R8042[])();
extern char *(*R9796[])();
extern char *(*R8264[])();
extern long O8404[];
extern long O8405[];

#ifdef __cplusplus
}
#endif

#endif
