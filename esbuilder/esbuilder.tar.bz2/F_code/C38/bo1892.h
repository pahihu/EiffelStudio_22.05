
#ifndef _C38_bo1892_
#define _C38_bo1892_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F841_9292(EIF_REFERENCE);
extern void EIF_Minit1892(void);
extern char *(*R8019[])();
extern char *(*R8020[])();

#ifdef __cplusplus
}
#endif

#endif
