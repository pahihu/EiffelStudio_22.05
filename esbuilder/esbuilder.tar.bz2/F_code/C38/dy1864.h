
#ifndef _C38_dy1864_
#define _C38_dy1864_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F771_9256(EIF_REFERENCE);
extern void EIF_Minit1864(void);

#ifdef __cplusplus
}
#endif

#endif
