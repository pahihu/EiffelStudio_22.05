
#ifndef _C38_qu1857_
#define _C38_qu1857_

#ifdef __cplusplus
extern "C" {
#endif

extern void F212_2855(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit1857(void);
extern void F926_9430(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F926_9432(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F926_9411(EIF_REFERENCE, EIF_INTEGER_32);
extern void F926_9406(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern char *(*R4985[])();
extern char *(*R8000[])();
extern char *(*R8003[])();

#ifdef __cplusplus
}
#endif

#endif
