/*
 * Code for class COLLECTION [NATURAL_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co1885.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {COLLECTION}.fill */
void F731_9239 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("fill", 730, Current, 1, 1, 9414);
	RTGC;
	RTHOOK(1);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7868[Dtype(RTCW(arg1))-690])(arg1);
	RTHOOK(2);
	F1149_10142(RTCW(loc1));
	for (;;) {
		RTHOOK(3);
		tb1 = '\01';
		if (!(EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7989[dtype-878])(Current)) {
			tb2 = F942_9502(RTCW(loc1));
			tb1 = tb2;
		}
		if (tb1) break;
		RTHOOK(4);
		tu1_1 = F1149_10116(RTCW(loc1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7993[dtype-878])(Current, (EIF_REFERENCE) &tu1_1);
		RTHOOK(5);
		F1149_10144(RTCW(loc1));
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {COLLECTION}.prune_all */
void F731_9241 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("prune_all", 730, Current, 0, 1, 9415);
	RTGC;
	for (;;) {
		RTHOOK(1);
		if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R7861[dtype-878])(Current, (EIF_REFERENCE) &arg1)) break;
		RTHOOK(2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7995[dtype-878])(Current, (EIF_REFERENCE) &arg1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

void EIF_Minit1885 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
