
#ifndef _C38_fi1877_
#define _C38_fi1877_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F829_9290(EIF_REFERENCE);
extern void EIF_Minit1877(void);
extern char *(*R8019[])();

#ifdef __cplusplus
}
#endif

#endif
