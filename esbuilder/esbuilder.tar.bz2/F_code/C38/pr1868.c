/*
 * Code for class PREFERENCE_FACTORY [G#1, G#2]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pr1868.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PREFERENCE_FACTORY}.new_preference */
EIF_REFERENCE F572_7536 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(13);
	RTLR(0,loc1);
	RTLR(1,arg3);
	RTLR(2,loc2);
	RTLR(3,arg1);
	RTLR(4,tr1);
	RTLR(5,arg2);
	RTLR(6,Result);
	RTLR(7,loc4);
	RTLR(8,Current);
	RTLR(9,loc5);
	RTLR(10,arg4);
	RTLR(11,loc6);
	RTLR(12,loc3);
	RTLIU(13);
	
	RTEAA("new_preference", 571, Current, 6, 4, 7413);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_REFERENCE) arg3;
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	loc2 = F1136_9986(RTCW(tr1), loc1);
	RTHOOK(3);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTHOOK(4);
		Result = RTLNSMART(eif_gen_param(dftype, 2).id);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R6627[Dtype(RTCW(Result))-583])(Result, arg2, arg3, loc2);
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		tr1 = F1136_9986(RTCW(tr1), loc1);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			RTHOOK(6);
			tb1 = eif_boolean_item(loc4,3);
			F579_7569(RTCW(Result), tb1);
			RTHOOK(7);
			tb1 = eif_boolean_item(loc4,4);
			F579_7574(RTCW(Result), tb1);
		}
	} else {
		RTHOOK(8);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		tr1 = F1136_9986(RTCW(tr1), loc1);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			RTHOOK(9);
			loc2 = eif_boxed_item(loc5,2);
			RTHOOK(10);
			if ((EIF_BOOLEAN)(loc2 == NULL)) {
				RTHOOK(11);
				loc2 = RTMS32_EX_H("",0,0);
			}
			RTHOOK(12);
			Result = RTLNSMART(eif_gen_param(dftype, 2).id);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R6627[Dtype(RTCW(Result))-583])(Result, arg2, arg3, loc2);
			RTHOOK(13);
			tb1 = eif_boolean_item(loc5,3);
			F579_7569(RTCW(Result), tb1);
			RTHOOK(14);
			tb1 = eif_boolean_item(loc5,4);
			F579_7574(RTCW(Result), tb1);
		} else {
			RTHOOK(15);
			Result = RTLNSMART(eif_gen_param(dftype, 2).id);
			tr1 = RTCCL(arg4);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R6626[Dtype(RTCW(Result))-583])(Result, arg2, arg3, tr1);
		}
	}
	RTHOOK(16);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	tr1 = F1136_9986(RTCW(tr1), loc1);
	loc6 = tr1;
	if (EIF_TEST(loc6)) {
		RTHOOK(17);
		loc3 = eif_boxed_item(loc6,1);
		RTHOOK(18);
		loc2 = eif_boxed_item(loc6,2);
		RTHOOK(19);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11464[Dtype(RTCW(loc3))-1503])(loc3);
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			RTHOOK(20);
			F579_7568(RTCW(Result), loc3);
		}
		RTHOOK(21);
		if ((EIF_BOOLEAN)(loc2 == NULL)) {
			RTHOOK(22);
			loc2 = F1500_14214(RTMS_EX_H("",0,0));
		}
		RTHOOK(23);
		F579_7570(RTCW(Result), loc2);
	}
	RTHOOK(24);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	F1136_10026(RTCW(tr1), Result, loc1);
	RTHOOK(28);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit1868 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
