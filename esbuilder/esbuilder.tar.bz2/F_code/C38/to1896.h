
#ifndef _C38_to1896_
#define _C38_to1896_

#ifdef __cplusplus
extern "C" {
#endif

extern void F556_7454(EIF_REFERENCE, EIF_INTEGER_32);
extern void F556_7455(EIF_REFERENCE, EIF_NATURAL_8, EIF_INTEGER_32);
extern void F556_7461(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1896(void);
extern void F1260_11852(EIF_REFERENCE, EIF_NATURAL_8, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y6491[];
extern EIF_TYPE_INDEX *Y6491_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
