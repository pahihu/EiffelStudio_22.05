
#ifndef _C38_dy1899_
#define _C38_dy1899_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F774_9256(EIF_REFERENCE);
extern void EIF_Minit1899(void);

#ifdef __cplusplus
}
#endif

#endif
