/*
 * Code for class XM_LINKED_LIST [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm1855.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_LINKED_LIST}.before_addition */
void F2137_24163 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("before_addition", 2136, Current, 0, 1, 29704);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {XM_LINKED_LIST}.force_first */
void F2137_24176 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("force_first", 2136, Current, 0, 1, 29717);
	RTGC;
	RTHOOK(1);
	tr1 = RTCCL(arg1);
	{
		/* INLINED CODE (XM_LINKED_LIST.before_addition) */
		/* END INLINED CODE */
	}
	;
	RTHOOK(2);
	tr1 = RTCCL(arg1);
	F2136_24103(Current, tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {XM_LINKED_LIST}.force_last */
void F2137_24177 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("force_last", 2136, Current, 0, 1, 29718);
	RTGC;
	RTHOOK(1);
	tr1 = RTCCL(arg1);
	{
		/* INLINED CODE (XM_LINKED_LIST.before_addition) */
		/* END INLINED CODE */
	}
	;
	RTHOOK(2);
	tr1 = RTCCL(arg1);
	F2136_24105(Current, tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {XM_LINKED_LIST}.put_last */
void F2137_24182 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("put_last", 2136, Current, 0, 1, 29698);
	RTGC;
	RTHOOK(1);
	tr1 = RTCCL(arg1);
	{
		/* INLINED CODE (XM_LINKED_LIST.before_addition) */
		/* END INLINED CODE */
	}
	;
	RTHOOK(2);
	tr1 = RTCCL(arg1);
	F2136_24104(Current, tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {XM_LINKED_LIST}.replace */
void F2137_24185 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("replace", 2136, Current, 0, 2, 29701);
	RTGC;
	RTHOOK(1);
	tr1 = RTCCL(arg1);
	{
		/* INLINED CODE (XM_LINKED_LIST.before_addition) */
		/* END INLINED CODE */
	}
	;
	RTHOOK(2);
	tr1 = RTCCL(arg1);
	F2136_24106(Current, tr1, arg2);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit1855 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
