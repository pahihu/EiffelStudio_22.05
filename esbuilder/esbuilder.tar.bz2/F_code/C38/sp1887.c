/*
 * Code for class SPECIAL [NATURAL_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sp1887.h"
#include "eif_built_in.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SPECIAL}.make_empty */
void F1260_11851 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make_empty", 1259, Current, 0, 1, 15716);
	RTGC;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {SPECIAL}.make_filled */
void F1260_11852 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make_filled", 1259, Current, 0, 2, 15717);
	RTGC;
	RTHOOK(1);
	{
		/* INLINED CODE (SPECIAL.make_empty) */
		/* END INLINED CODE */
	}
	;
	RTHOOK(2);
	F1260_11873(Current, arg1, ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)));
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {SPECIAL}.item */
EIF_NATURAL_8 F1260_11854 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	return *((EIF_NATURAL_8 *) Current + arg1);
}

EIF_REFERENCE F1260_118541 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	EIF_REFERENCE Result;
	EIF_NATURAL_8 r = *((EIF_NATURAL_8 *) Current + arg1);
	Result = RTLNS(eif_new_type(1443, 0x00).id, 1443, _OBJSIZ_0_1_0_0_0_0_0_0_);
	*(EIF_NATURAL_8 *)Result = r;
	return Result;
}

/* {SPECIAL}.at */
EIF_NATURAL_8 F1260_11855 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	return *((EIF_NATURAL_8 *) Current + arg1);
}

EIF_REFERENCE F1260_118551 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	EIF_REFERENCE Result;
	EIF_NATURAL_8 r = *((EIF_NATURAL_8 *) Current + arg1);
	Result = RTLNS(eif_new_type(1443, 0x00).id, 1443, _OBJSIZ_0_1_0_0_0_0_0_0_);
	*(EIF_NATURAL_8 *)Result = r;
	return Result;
}

/* {SPECIAL}.item_address */
EIF_POINTER F1260_11857 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	return (EIF_POINTER) (Current + (rt_uint_ptr) arg1 * (rt_uint_ptr)sizeof(EIF_NATURAL_8));
}

/* {SPECIAL}.base_address */
EIF_POINTER F1260_11858 (EIF_REFERENCE Current)
{
	return (EIF_POINTER) Current;
}

/* {SPECIAL}.to_array */
EIF_REFERENCE F1260_11860 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("to_array", 1259, Current, 0, 0, 15675);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {923,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y7816,Y7816_gen_type,Dftype(Current),656);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		tr1 = RTLNS(typres0.id, 923, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F924_9409(RTCW(tr1), Current);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {SPECIAL}.new_cursor */
EIF_REFERENCE F1260_11861 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("new_cursor", 1259, Current, 0, 0, 15676);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1116,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y7816,Y7816_gen_type,Dftype(Current),656);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		tr1 = RTLNS(typres0.id, 1116, _OBJSIZ_1_0_0_2_0_0_0_0_);
	}
	F1117_9867(RTCW(tr1), Current);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {SPECIAL}.lower */
EIF_INTEGER_32 F1260_11862 (EIF_REFERENCE Current)
{
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
}

/* {SPECIAL}.upper */
EIF_INTEGER_32 F1260_11863 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("upper", 1259, Current, 0, 0, 15678);
	RTGC;
	RTHOOK(1);
	Result = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result - ((EIF_INTEGER_32) 1L));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {SPECIAL}.count */
EIF_INTEGER_32 F1260_11864 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("count", 1259, Current, 0, 0, 15679);
	Result = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {SPECIAL}.capacity */
EIF_INTEGER_32 F1260_11865 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("capacity", 1259, Current, 0, 0, 15680);
	Result = (EIF_INTEGER_32) eif_builtin_SPECIAL_capacity__i4 (Current);
	RTHOOK(1);
	RTLE;
	RTEE;
	return Result;
}

/* {SPECIAL}.same_items */
EIF_BOOLEAN F1260_11867 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_8 tu1_1;
	EIF_NATURAL_8 tu1_2;
	EIF_NATURAL_8 tu1_3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("same_items", 1259, Current, 3, 4, 15682);
	RTGC;
	RTHOOK(1);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		RTHOOK(3);
		loc1 = (EIF_INTEGER_32) arg2;
		RTHOOK(4);
		loc2 = (EIF_INTEGER_32) arg3;
		RTHOOK(5);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + arg4);
		for (;;) {
			RTHOOK(6);
			if ((EIF_BOOLEAN)(loc1 == loc3)) break;
			RTHOOK(7);
			/* INLINED CODE (SPECIAL.item) */
			tu1_2 = *((EIF_NATURAL_8 *)RTCW(arg1) + (loc1));
			/* END INLINED CODE */
			tu1_1 = tu1_2;
			/* INLINED CODE (SPECIAL.item) */
			tu1_3 = *((EIF_NATURAL_8 *)Current + (loc2));
			/* END INLINED CODE */
			if ((EIF_BOOLEAN)(tu1_1 != tu1_3)) {
				RTHOOK(8);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				RTHOOK(9);
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L));
			}
			RTHOOK(10);
			loc1++;
			RTHOOK(11);
			loc2++;
		}
	}
	RTHOOK(13);
	RTLE;
	RTEE;
	return Result;
}

/* {SPECIAL}.valid_index */
EIF_BOOLEAN F1260_11868 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("valid_index", 1259, Current, 0, 1, 15683);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	if ((EIF_BOOLEAN) (((EIF_INTEGER_32) 0L) <= arg1)) {
		Result = (EIF_BOOLEAN) (arg1 < (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current));
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {SPECIAL}.put */
void F1260_11869 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	*((EIF_NATURAL_8 *) Current + arg2) = arg1;
}

void F1260_118692 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	*((EIF_NATURAL_8 *) Current + arg2) = *(EIF_NATURAL_8 *)arg1;
}

/* {SPECIAL}.force */
void F1260_11870 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 arg3 = RT_SPECIAL_COUNT(Current);
	*((EIF_NATURAL_8 *) Current + arg2) = arg1;
	if (arg2 == arg3) { RT_SPECIAL_COUNT(Current) = arg3 + 1; }
}

void F1260_118702 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	*((EIF_NATURAL_8 *) Current + arg2) = *(EIF_NATURAL_8 *)arg1;
}

/* {SPECIAL}.extend */
void F1260_11871 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	EIF_INTEGER_32 arg2 = RT_SPECIAL_COUNT(Current)++;
	*((EIF_NATURAL_8 *) Current + arg2) = arg1;
}

void F1260_118712 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	
	EIF_INTEGER_32 arg2 = RT_SPECIAL_COUNT(Current)++;
	*((EIF_NATURAL_8 *) Current + arg2) = *(EIF_NATURAL_8 *)arg1;
}

/* {SPECIAL}.extend_filled */
void F1260_11872 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("extend_filled", 1259, Current, 0, 1, 15687);
	RTGC;
	RTHOOK(1);
	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current);
	ti4_2 = (EIF_INTEGER_32) eif_builtin_SPECIAL_capacity__i4 (Current);
	F1260_11873(Current, arg1, ti4_1, (EIF_INTEGER_32) (ti4_2 - ((EIF_INTEGER_32) 1L)));
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {SPECIAL}.fill_with */
void F1260_11873 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 i;
	for (i = arg2; i <= arg3; i++) {
		*((EIF_NATURAL_8 *) Current + i) = arg1;
	}
	RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), arg3 + 1);
}

void F1260_118732 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	EIF_INTEGER_32 i;
	EIF_NATURAL_8 arg1x = *(EIF_NATURAL_8 *)arg1;
	for (i = arg2; i < arg3; i++) {
	*((EIF_NATURAL_8 *) Current + i) = arg1x;
	}
	RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), arg3 + 1);
}

/* {SPECIAL}.fill_with_default */
void F1260_11874 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("fill_with_default", 1259, Current, 0, 2, 15689);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNTY2(eif_final_id(Y7816,Y7816_gen_type,Dftype(Current),656), 0x00);
	tu1_1 = F1392_12909(tr1);
	F1260_11873(Current, tu1_1, arg1, arg2);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {SPECIAL}.insert_data */
void F1260_11875 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("insert_data", 1259, Current, 6, 4, 15690);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - arg3);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
		RTHOOK(3);
		/* INLINED CODE (SPECIAL.copy_data) */
		memmove((EIF_NATURAL_8 *)Current + (arg3),(EIF_NATURAL_8 *)arg1 + arg2, (rt_uint_ptr)sizeof(EIF_NATURAL_8) * (rt_uint_ptr)arg4);
		RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), arg3 + arg4);
		/* END INLINED CODE */
		;
	} else {
		RTHOOK(4);
		if ((EIF_BOOLEAN) (arg4 <= loc1)) {
			RTHOOK(5);
			/* INLINED CODE (SPECIAL.overlapping_move) */
			memmove((EIF_NATURAL_8 *)Current + ((EIF_INTEGER_32) (arg3 + arg4)),(EIF_NATURAL_8 *)Current + arg3, (rt_uint_ptr)sizeof(EIF_NATURAL_8) * (rt_uint_ptr)loc1);
			RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), (EIF_INTEGER_32) (arg3 + arg4) + loc1);
			/* END INLINED CODE */
			;
			RTHOOK(6);
			/* INLINED CODE (SPECIAL.copy_data) */
			memmove((EIF_NATURAL_8 *)Current + (arg3),(EIF_NATURAL_8 *)arg1 + arg2, (rt_uint_ptr)sizeof(EIF_NATURAL_8) * (rt_uint_ptr)arg4);
			RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), arg3 + arg4);
			/* END INLINED CODE */
			;
		} else {
			RTHOOK(7);
			loc4 = (EIF_INTEGER_32) arg2;
			RTHOOK(8);
			loc6 = (EIF_INTEGER_32) arg3;
			RTHOOK(9);
			loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + arg4);
			RTHOOK(10);
			loc3 = (EIF_INTEGER_32) arg4;
			RTHOOK(11);
			loc2 = (EIF_INTEGER_32) loc1;
			for (;;) {
				RTHOOK(12);
				if ((EIF_BOOLEAN) (loc4 >= loc5)) break;
				RTHOOK(13);
				/* INLINED CODE (SPECIAL.overlapping_move) */
				memmove((EIF_NATURAL_8 *)Current + ((EIF_INTEGER_32) (loc6 + loc2)),(EIF_NATURAL_8 *)Current + loc6, (rt_uint_ptr)sizeof(EIF_NATURAL_8) * (rt_uint_ptr)loc1);
				RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), (EIF_INTEGER_32) (loc6 + loc2) + loc1);
				/* END INLINED CODE */
				;
				RTHOOK(14);
				/* INLINED CODE (SPECIAL.copy_data) */
				memmove((EIF_NATURAL_8 *)Current + (loc6),(EIF_NATURAL_8 *)arg1 + loc4, (rt_uint_ptr)sizeof(EIF_NATURAL_8) * (rt_uint_ptr)loc2);
				RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), loc6 + loc2);
				/* END INLINED CODE */
				;
				RTHOOK(15);
				loc6 += loc2;
				RTHOOK(16);
				loc4 += loc2;
				RTHOOK(17);
				loc3 -= loc1;
				RTHOOK(18);
				ti4_1 = eif_min_int32 (loc2,loc3);
				loc2 = (EIF_INTEGER_32) ti4_1;
			}
		}
	}
	RTHOOK(21);
	RTLE;
	RTEE;
}

/* {SPECIAL}.copy_data */
void F1260_11876 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_8 tu1_1;
	EIF_NATURAL_8 tu1_2;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("copy_data", 1259, Current, 3, 4, 15691);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == Current)) {
		RTHOOK(2);
		/* INLINED CODE (SPECIAL.overlapping_move) */
		memmove((EIF_NATURAL_8 *)Current + (arg3),(EIF_NATURAL_8 *)Current + arg2, (rt_uint_ptr)sizeof(EIF_NATURAL_8) * (rt_uint_ptr)arg4);
		RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), arg3 + arg4);
		/* END INLINED CODE */
		;
	} else {
		RTHOOK(3);
		loc1 = (EIF_INTEGER_32) arg2;
		RTHOOK(4);
		loc2 = (EIF_INTEGER_32) arg3;
		RTHOOK(5);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + arg4);
		for (;;) {
			RTHOOK(6);
			if ((EIF_BOOLEAN)(loc1 == loc3)) break;
			RTHOOK(7);
			/* INLINED CODE (SPECIAL.item) */
			tu1_2 = *((EIF_NATURAL_8 *)RTCW(arg1) + (loc1));
			/* END INLINED CODE */
			tu1_1 = tu1_2;
			F1260_11870(Current, tu1_1, loc2);
			RTHOOK(8);
			loc1++;
			RTHOOK(9);
			loc2++;
		}
	}
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {SPECIAL}.move_data */
void F1260_11877 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("move_data", 1259, Current, 0, 3, 15692);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == arg2)) {
	} else {
		RTHOOK(2);
		if ((EIF_BOOLEAN) (arg1 > arg2)) {
			RTHOOK(3);
			if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (arg2 + arg3) < arg1)) {
				RTHOOK(4);
				/* INLINED CODE (SPECIAL.move_data) */
				memcpy((EIF_NATURAL_8 *)Current + (arg2),(EIF_NATURAL_8 *)Current + arg1, (rt_uint_ptr)sizeof(EIF_NATURAL_8) * (rt_uint_ptr)arg3);
				RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), arg2 + arg3);
				/* END INLINED CODE */
				;
			} else {
				RTHOOK(5);
				/* INLINED CODE (SPECIAL.overlapping_move) */
				memmove((EIF_NATURAL_8 *)Current + (arg2),(EIF_NATURAL_8 *)Current + arg1, (rt_uint_ptr)sizeof(EIF_NATURAL_8) * (rt_uint_ptr)arg3);
				RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), arg2 + arg3);
				/* END INLINED CODE */
				;
			}
		} else {
			RTHOOK(6);
			if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (arg1 + arg3) < arg2)) {
				RTHOOK(7);
				/* INLINED CODE (SPECIAL.move_data) */
				memcpy((EIF_NATURAL_8 *)Current + (arg2),(EIF_NATURAL_8 *)Current + arg1, (rt_uint_ptr)sizeof(EIF_NATURAL_8) * (rt_uint_ptr)arg3);
				RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), arg2 + arg3);
				/* END INLINED CODE */
				;
			} else {
				RTHOOK(8);
				/* INLINED CODE (SPECIAL.overlapping_move) */
				memmove((EIF_NATURAL_8 *)Current + (arg2),(EIF_NATURAL_8 *)Current + arg1, (rt_uint_ptr)sizeof(EIF_NATURAL_8) * (rt_uint_ptr)arg3);
				RT_SPECIAL_COUNT(Current) = eif_max_int32(RT_SPECIAL_COUNT(Current), arg2 + arg3);
				/* END INLINED CODE */
				;
			}
		}
	}
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {SPECIAL}.overlapping_move */
void F1260_11878 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_8 tu1_1;
	EIF_NATURAL_8 tu1_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("overlapping_move", 1259, Current, 3, 3, 15693);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg1 < arg2)) {
		RTHOOK(2);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 + arg3) - ((EIF_INTEGER_32) 1L));
		RTHOOK(3);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L));
		RTHOOK(4);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 - arg1);
		RTHOOK(5);
		if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (arg2 + arg3) >= (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current))) {
			RTHOOK(6);
			/* INLINED CODE (SPECIAL.item) */
			tu1_2 = *((EIF_NATURAL_8 *)Current + (arg1));
			/* END INLINED CODE */
			tu1_1 = tu1_2;
			ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current);
			F1260_11873(Current, tu1_1, ti4_1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg2 + arg3) - ((EIF_INTEGER_32) 1L)));
		}
		
		for (;;) {
			RTHOOK(8);
			if ((EIF_BOOLEAN)(loc1 == loc2)) break;
			RTHOOK(9);
			/* INLINED CODE (SPECIAL.item) */
			tu1_2 = *((EIF_NATURAL_8 *)Current + (loc1));
			/* END INLINED CODE */
			tu1_1 = tu1_2;
			/* INLINED CODE (SPECIAL.put) */
			*((EIF_NATURAL_8 *)Current + ((EIF_INTEGER_32) (loc1 + loc3))) = tu1_1;
			/* END INLINED CODE */
			;
			RTHOOK(10);
			loc1--;
		}
	} else {
		RTHOOK(11);
		loc1 = (EIF_INTEGER_32) arg1;
		RTHOOK(12);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + arg3);
		RTHOOK(13);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 - arg2);
		
		for (;;) {
			RTHOOK(15);
			if ((EIF_BOOLEAN)(loc1 == loc2)) break;
			RTHOOK(16);
			/* INLINED CODE (SPECIAL.item) */
			tu1_2 = *((EIF_NATURAL_8 *)Current + (loc1));
			/* END INLINED CODE */
			tu1_1 = tu1_2;
			F1260_11870(Current, tu1_1, (EIF_INTEGER_32) (loc1 - loc3));
			RTHOOK(17);
			loc1++;
		}
	}
	RTHOOK(20);
	RTLE;
	RTEE;
}

/* {SPECIAL}.non_overlapping_move */
void F1260_11879 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_8 tu1_1;
	EIF_NATURAL_8 tu1_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("non_overlapping_move", 1259, Current, 3, 3, 15694);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + arg3);
	RTHOOK(3);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 - arg1);
	for (;;) {
		RTHOOK(4);
		if ((EIF_BOOLEAN)(loc1 == loc2)) break;
		RTHOOK(5);
		/* INLINED CODE (SPECIAL.item) */
		tu1_2 = *((EIF_NATURAL_8 *)Current + (loc1));
		/* END INLINED CODE */
		tu1_1 = tu1_2;
		F1260_11870(Current, tu1_1, (EIF_INTEGER_32) (loc1 + loc3));
		RTHOOK(6);
		loc1++;
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {SPECIAL}.keep_head */
void F1260_11880 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("keep_head", 1259, Current, 0, 1, 15695);
	RTHOOK(1);
	eif_builtin_SPECIAL_set_count__i4_ (Current, arg1);
	RTHOOK(4);
	RTEE;
}

/* {SPECIAL}.remove_tail */
void F1260_11883 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("remove_tail", 1259, Current, 0, 1, 15698);
	RTGC;
	RTHOOK(1);
	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current);
	F1260_11880(Current, (EIF_INTEGER_32) (ti4_1 - arg1));
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {SPECIAL}.resized_area */
EIF_REFERENCE F1260_11884 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_NATURAL_8 tu1_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("resized_area", 1259, Current, 0, 1, 15699);
	RTGC;
	RTHOOK(1);
	Result = RTLNSP2(Dftype(Current),0,arg1,sizeof(EIF_NATURAL_8), EIF_TRUE);
	RT_SPECIAL_COUNT(Result) = 0;
	RTHOOK(2);
	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current);
	ti4_1 = eif_min_int32 (arg1,ti4_1);
	/* INLINED CODE (SPECIAL.copy_data) */
	memmove((EIF_NATURAL_8 *)RTCW(Result) + (((EIF_INTEGER_32) 0L)),(EIF_NATURAL_8 *)Current + ((EIF_INTEGER_32) 0L), (rt_uint_ptr)sizeof(EIF_NATURAL_8) * (rt_uint_ptr)ti4_1);
	RT_SPECIAL_COUNT(Result) = eif_max_int32(RT_SPECIAL_COUNT(Result), ((EIF_INTEGER_32) 0L) + ti4_1);
	/* END INLINED CODE */
	;
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {SPECIAL}.resized_area_with_default */
EIF_REFERENCE F1260_11885 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_NATURAL_8 tu1_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("resized_area_with_default", 1259, Current, 0, 2, 15700);
	RTGC;
	RTHOOK(1);
	Result = RTLNSP2(Dftype(Current),0,arg2,sizeof(EIF_NATURAL_8), EIF_TRUE);
	RT_SPECIAL_COUNT(Result) = 0;
	RTHOOK(2);
	if ((EIF_BOOLEAN) (arg2 > (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current))) {
		RTHOOK(3);
		ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current);
		/* INLINED CODE (SPECIAL.copy_data) */
		memmove((EIF_NATURAL_8 *)RTCW(Result) + (((EIF_INTEGER_32) 0L)),(EIF_NATURAL_8 *)Current + ((EIF_INTEGER_32) 0L), (rt_uint_ptr)sizeof(EIF_NATURAL_8) * (rt_uint_ptr)ti4_1);
		RT_SPECIAL_COUNT(Result) = eif_max_int32(RT_SPECIAL_COUNT(Result), ((EIF_INTEGER_32) 0L) + ti4_1);
		/* END INLINED CODE */
		;
		RTHOOK(4);
		ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Current);
		F1260_11873(RTCW(Result), arg1, ti4_1, (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)));
	} else {
		RTHOOK(5);
		/* INLINED CODE (SPECIAL.copy_data) */
		memmove((EIF_NATURAL_8 *)RTCW(Result) + (((EIF_INTEGER_32) 0L)),(EIF_NATURAL_8 *)Current + ((EIF_INTEGER_32) 0L), (rt_uint_ptr)sizeof(EIF_NATURAL_8) * (rt_uint_ptr)arg2);
		RT_SPECIAL_COUNT(Result) = eif_max_int32(RT_SPECIAL_COUNT(Result), ((EIF_INTEGER_32) 0L) + arg2);
		/* END INLINED CODE */
		;
	}
	RTHOOK(11);
	RTLE;
	RTEE;
	return Result;
}

/* {SPECIAL}.aliased_resized_area */
EIF_REFERENCE F1260_11886 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("aliased_resized_area", 1259, Current, 0, 1, 15701);
	Result = (EIF_REFERENCE) eif_builtin_SPECIAL_aliased_resized_area__i4_s (Current, arg1);
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {SPECIAL}.aliased_resized_area_with_default */
EIF_REFERENCE F1260_11887 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("aliased_resized_area_with_default", 1259, Current, 0, 2, 15702);
	RTGC;
	RTHOOK(1);
	Result = (EIF_REFERENCE) eif_builtin_SPECIAL_aliased_resized_area__i4_s (Current, arg2);
	RTHOOK(2);
	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (Result);
	F1260_11873(RTCW(Result), arg1, ti4_1, (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)));
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {SPECIAL}.wipe_out */
void F1260_11889 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("wipe_out", 1259, Current, 0, 0, 15704);
	RTHOOK(1);
	eif_builtin_SPECIAL_set_count__i4_ (Current, ((EIF_INTEGER_32) 0L));
	RTHOOK(4);
	RTEE;
}

/* {SPECIAL}.clear_all */
void F1260_11890 (EIF_REFERENCE Current)
{
	memset (Current, 0, RT_SPECIAL_VISIBLE_SIZE(Current));
}

/* {SPECIAL}.do_all_in_bounds */
void F1260_11891 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("do_all_in_bounds", 1259, Current, 2, 3, 15706);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) arg2;
	RTHOOK(2);
	loc2 = (EIF_INTEGER_32) arg3;
	for (;;) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		RTHOOK(4);
		tu1_1 = 
			/* INLINED CODE (SPECIAL.item) */
			*((EIF_NATURAL_8 *)Current + (loc1))
			/* END INLINED CODE */;
		(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_NATURAL_8)) *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_0_))(
			*(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_1_),
			*(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_), tu1_1);
		RTHOOK(5);
		loc1++;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {SPECIAL}.there_exists_in_bounds */
EIF_BOOLEAN F1260_11893 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("there_exists_in_bounds", 1259, Current, 2, 3, 15708);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) arg2;
	RTHOOK(2);
	loc2 = (EIF_INTEGER_32) arg3;
	for (;;) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > loc2) || Result)) break;
		RTHOOK(4);
		tu1_1 = 
			/* INLINED CODE (SPECIAL.item) */
			*((EIF_NATURAL_8 *)Current + (loc1))
			/* END INLINED CODE */;
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_POINTER, EIF_REFERENCE, EIF_NATURAL_8)) *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_3_0_3_0_0_))(
			*(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_3_0_3_0_1_),
			*(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_), tu1_1);
		Result = tb1;
		RTHOOK(5);
		loc1++;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {SPECIAL}.element_size */
EIF_INTEGER_32 F1260_11898 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("element_size", 1259, Current, 0, 0, 15713);
	Result = (EIF_INTEGER_32) eif_builtin_SPECIAL_element_size__i4 (Current);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {SPECIAL}.set_count */
void F1260_11899 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("set_count", 1259, Current, 0, 1, 15714);
	eif_builtin_SPECIAL_set_count__i4_ (Current, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit1887 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
