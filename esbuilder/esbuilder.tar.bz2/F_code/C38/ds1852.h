
#ifndef _C38_ds1852_
#define _C38_ds1852_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F2103_23771(EIF_REFERENCE);
extern void F2103_23783(EIF_REFERENCE);
extern void EIF_Minit1852(void);
extern char *(*R18652[])();
extern char *(*R18383[])();
extern char *(*R18642[])();

#ifdef __cplusplus
}
#endif

#endif
