
#ifndef _C38_ge1889_
#define _C38_ge1889_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_8 F1079_9823(EIF_REFERENCE);
extern EIF_INTEGER_32 F1079_9824(EIF_REFERENCE);
extern EIF_INTEGER_32 F1079_9825(EIF_REFERENCE);
extern EIF_BOOLEAN F1079_9832(EIF_REFERENCE);
extern EIF_BOOLEAN F1079_9836(EIF_REFERENCE);
extern void F1079_9837(EIF_REFERENCE);
extern void F1079_9838(EIF_REFERENCE);
extern EIF_REFERENCE F1079_9839(EIF_REFERENCE);
extern void EIF_Minit1889(void);
extern char *(*R8283[])();
extern char *(*R8256[])();
extern long O8282[];
extern long O8284[];

#ifdef __cplusplus
}
#endif

#endif
