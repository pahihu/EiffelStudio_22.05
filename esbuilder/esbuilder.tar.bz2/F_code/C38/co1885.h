
#ifndef _C38_co1885_
#define _C38_co1885_

#ifdef __cplusplus
extern "C" {
#endif

extern void F731_9239(EIF_REFERENCE, EIF_REFERENCE);
extern void F731_9241(EIF_REFERENCE, EIF_NATURAL_8);
extern void EIF_Minit1885(void);
extern EIF_BOOLEAN F942_9502(EIF_REFERENCE);
extern void F1149_10144(EIF_REFERENCE);
extern EIF_NATURAL_8 F1149_10116(EIF_REFERENCE);
extern void F1149_10142(EIF_REFERENCE);
extern char *(*R7861[])();
extern char *(*R7868[])();
extern char *(*R7989[])();
extern char *(*R7993[])();
extern char *(*R7995[])();

#ifdef __cplusplus
}
#endif

#endif
