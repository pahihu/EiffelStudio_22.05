
#ifndef _C38_sp1888_
#define _C38_sp1888_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1117_9867(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F1117_9868(EIF_REFERENCE);
extern EIF_REFERENCE F1117_9869(EIF_REFERENCE);
extern EIF_INTEGER_32 F1117_9870(EIF_REFERENCE);
extern void EIF_Minit1888(void);
extern EIF_INTEGER_32 F1260_11863(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y8186[];
extern EIF_TYPE_INDEX *Y8186_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
