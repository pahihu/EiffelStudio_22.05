/*
 * Code for class DS_LIST_CURSOR [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds1852.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_LIST_CURSOR}.index */
EIF_INTEGER_32 F2103_23771 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("index", 2102, Current, 0, 0, 29332);
	RTGC;
	RTHOOK(1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R18383[Dtype(Current)-2087])(Current);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R18652[Dtype(RTCW(tr1))-2135])(tr1, Current);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {DS_LIST_CURSOR}.remove */
void F2103_23783 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("remove", 2102, Current, 0, 0, 29326);
	RTGC;
	RTHOOK(1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R18383[Dtype(Current)-2087])(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R18642[Dtype(RTCW(tr1))-2135])(tr1, Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit1852 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
