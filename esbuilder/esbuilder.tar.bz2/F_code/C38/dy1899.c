/*
 * Code for class DYNAMIC_TABLE [NATURAL_8, INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "dy1899.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DYNAMIC_TABLE}.prunable */
EIF_BOOLEAN F774_9256 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("prunable", 773, Current, 0, 0, 9465);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

void EIF_Minit1899 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
