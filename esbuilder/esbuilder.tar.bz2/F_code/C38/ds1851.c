/*
 * Code for class DS_BILINEAR_CURSOR [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds1851.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_BILINEAR_CURSOR}.is_last */
EIF_BOOLEAN F2086_23724 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("is_last", 2085, Current, 0, 0, 29236);
	RTGC;
	RTHOOK(1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R18383[Dtype(Current)-2087])(Current);
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R18557[Dtype(RTCW(tr1))-2125])(tr1, Current);
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {DS_BILINEAR_CURSOR}.off */
EIF_BOOLEAN F2086_23726 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("off", 2085, Current, 0, 0, 29237);
	RTGC;
	RTHOOK(1);
	Result = '\01';
	if (!(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8184[dtype-1011])(Current)) {
		Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R18401[dtype-2087])(Current);
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {DS_BILINEAR_CURSOR}.finish */
void F2086_23727 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("finish", 2085, Current, 0, 0, 29238);
	RTGC;
	RTHOOK(1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R18383[Dtype(Current)-2087])(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R18559[Dtype(RTCW(tr1))-2125])(tr1, Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {DS_BILINEAR_CURSOR}.back */
void F2086_23728 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("back", 2085, Current, 0, 0, 29239);
	RTGC;
	RTHOOK(1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R18383[Dtype(Current)-2087])(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R18560[Dtype(RTCW(tr1))-2125])(tr1, Current);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {DS_BILINEAR_CURSOR}.go_before */
void F2086_23730 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("go_before", 2085, Current, 0, 0, 29241);
	RTGC;
	RTHOOK(1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R18383[Dtype(Current)-2087])(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R18562[Dtype(RTCW(tr1))-2125])(tr1, Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit1851 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
