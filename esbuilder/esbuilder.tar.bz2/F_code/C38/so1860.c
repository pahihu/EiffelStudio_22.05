/*
 * Code for class SORTER [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "so1860.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SORTER}.make */
void F211_2840 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("make", 210, Current, 0, 1, 2913);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {SORTER}.sort */
void F211_2849 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("sort", 210, Current, 0, 1, 2922);
	RTHOOK(1);
	F211_2851(Current, arg1, *(EIF_REFERENCE *)(Current));
	RTHOOK(3);
	RTEE;
}

/* {SORTER}.reverse_sort */
void F211_2850 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("reverse_sort", 210, Current, 0, 1, 2923);
	RTGC;
	RTHOOK(1);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7862[Dtype(RTCW(arg1))-690])(arg1);
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(2);
		{
			static EIF_TYPE_INDEX typarr0[] = {322,0,0,0xFFFF};
			EIF_TYPE typres0;
			{
				EIF_TYPE l_type;
				l_type = eif_final_id(Y2833,Y2833_gen_type,Dftype(Current),210);
				typarr0[1] = l_type.annotations | 0xFF00;
				typarr0[2] = l_type.id;
			}
			
			typres0 = eif_compound_id(Dftype(Current), typarr0);
			tr1 = RTLNS(typres0.id, 322, _OBJSIZ_1_0_0_0_0_0_0_0_);
		}
		F323_5449(RTCW(tr1), *(EIF_REFERENCE *)(Current));
		F211_2851(Current, arg1, tr1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {SORTER}.sort_with_comparator */
void F211_2851 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("sort_with_comparator", 210, Current, 0, 2, 2924);
	RTGC;
	RTHOOK(1);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7862[Dtype(RTCW(arg1))-690])(arg1);
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(2);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8043[Dtype(RTCW(arg1))-919])(arg1);
		ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8044[Dtype(RTCW(arg1))-919])(arg1);
		F212_2855(Current, arg1, arg2, ti4_1, ti4_2);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

void EIF_Minit1860 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
