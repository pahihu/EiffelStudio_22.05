
#ifndef _C38_re1891_
#define _C38_re1891_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F853_9296(EIF_REFERENCE);
extern void EIF_Minit1891(void);
extern char *(*R8020[])();

#ifdef __cplusplus
}
#endif

#endif
