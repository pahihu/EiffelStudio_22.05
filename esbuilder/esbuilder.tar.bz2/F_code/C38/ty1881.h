
#ifndef _C38_ty1881_
#define _C38_ty1881_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_8 F1044_9777(EIF_REFERENCE);
extern void EIF_Minit1881(void);
extern char *(*R8042[])();
extern char *(*R8255[])();
extern char *(*R8268[])();

#ifdef __cplusplus
}
#endif

#endif
