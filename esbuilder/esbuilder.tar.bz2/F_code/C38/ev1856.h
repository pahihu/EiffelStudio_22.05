
#ifndef _C38_ev1856_
#define _C38_ev1856_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1177_10288(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1856(void);
extern EIF_INTEGER_32 F1147_10132(EIF_REFERENCE);
extern EIF_REFERENCE F1706_17488(EIF_REFERENCE);
extern EIF_REFERENCE F636_8703(EIF_REFERENCE);
extern void F1711_17605(EIF_REFERENCE);
extern void F1176_10254(EIF_REFERENCE, EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,8703)

#ifdef __cplusplus
}
#endif

#endif
