
#ifndef _C38_ev1867_
#define _C38_ev1867_

#ifdef __cplusplus
extern "C" {
#endif

extern void F489_6836(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_BOOLEAN);
extern EIF_REFERENCE F489_6838(EIF_REFERENCE);
extern void EIF_Minit1867(void);

#ifdef __cplusplus
}
#endif

#endif
