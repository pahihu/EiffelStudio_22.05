
#ifndef _C38_re1879_
#define _C38_re1879_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F898_9352(EIF_REFERENCE);
extern void EIF_Minit1879(void);
extern void F1056_9783(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R8267[])();
extern EIF_TYPE_INDEX Y7816[];
extern EIF_TYPE_INDEX *Y7816_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
