
#ifndef _C38_dy1898_
#define _C38_dy1898_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F954_9511(EIF_REFERENCE);
extern void F954_9517(EIF_REFERENCE, EIF_NATURAL_8);
extern void F954_9518(EIF_REFERENCE, EIF_NATURAL_8);
extern void EIF_Minit1898(void);
extern void F1149_10165(EIF_REFERENCE);
extern EIF_BOOLEAN F707_9220(EIF_REFERENCE);
extern void F1149_10148(EIF_REFERENCE, EIF_NATURAL_8);
extern void F1149_10142(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
