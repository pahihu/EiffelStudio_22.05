/*
 * Code for class SEQUENCE [NATURAL_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "se1893.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SEQUENCE}.readable */
EIF_BOOLEAN F865_9301 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("readable", 864, Current, 0, 0, 9658);
	RTGC;
	RTHOOK(1);
	Result = F942_9502(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {SEQUENCE}.force */
void F865_9303 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("force", 864, Current, 0, 1, 9660);
	RTHOOK(1);
	F1149_10152(Current, arg1);
	RTHOOK(4);
	RTEE;
}

/* {SEQUENCE}.prune_all */
void F865_9307 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("prune_all", 864, Current, 0, 1, 9664);
	RTGC;
	RTHOOK(1);
	F1149_10142(Current);
	for (;;) {
		RTHOOK(2);
		if (F707_9220(Current)) break;
		RTHOOK(3);
		F1149_10148(Current, arg1);
		RTHOOK(4);
		if ((EIF_BOOLEAN) !F707_9220(Current)) {
			RTHOOK(5);
			F1149_10165(Current);
		}
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

void EIF_Minit1893 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
