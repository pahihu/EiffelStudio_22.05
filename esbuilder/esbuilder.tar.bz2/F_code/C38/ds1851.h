
#ifndef _C38_ds1851_
#define _C38_ds1851_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F2086_23724(EIF_REFERENCE);
extern EIF_BOOLEAN F2086_23726(EIF_REFERENCE);
extern void F2086_23727(EIF_REFERENCE);
extern void F2086_23728(EIF_REFERENCE);
extern void F2086_23730(EIF_REFERENCE);
extern void EIF_Minit1851(void);
extern char *(*R18383[])();
extern char *(*R18560[])();
extern char *(*R18557[])();
extern char *(*R18559[])();
extern char *(*R18401[])();
extern char *(*R18562[])();
extern char *(*R8184[])();

#ifdef __cplusplus
}
#endif

#endif
