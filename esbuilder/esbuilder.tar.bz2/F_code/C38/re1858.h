
#ifndef _C38_re1858_
#define _C38_re1858_

#ifdef __cplusplus
extern "C" {
#endif

extern void F323_5449(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F323_5450(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1858(void);
extern char *(*R4985[])();

#ifdef __cplusplus
}
#endif

#endif
