/*
 * Code for class GB_CLIPBOARD
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gb1693.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GB_CLIPBOARD}.make_with_components */
void F2515_31160 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTEAA("make_with_components", 2514, Current, 0, 1, 36838);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	tr1 = RTLNSMART(eif_new_type(1200, 0).id);
	F1176_10251(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1493,0xFFF9,0,1419,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A1693_709, (EIF_POINTER) _A1693_709, (EIF_POINTER)(F2515_31171),tr2, 1, 0);
	}
	F1169_10217(RTCW(tr1), tr3);
	RTHOOK(4);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(5);
	{
		static EIF_TYPE_INDEX typarr0[] = {361,2243,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F362_5875(RTCW(tr1), NULL);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {GB_CLIPBOARD}.object */
EIF_REFERENCE F2515_31161 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("object", 2514, Current, 1, 0, 36839);
	RTGC;
	RTHOOK(1);
	Result = F2515_31166(Current);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(Result != NULL)) {
		RTHOOK(3);
		{
			static EIF_TYPE_INDEX typarr0[] = {1146,2515,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNS(typres0.id, 1146, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F1147_10111(RTCW(loc1), ((EIF_INTEGER_32) 20L));
		RTHOOK(4);
		F2516_31197(RTCW(Result), loc1);
		RTHOOK(5);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7993[Dtype(RTCW(loc1))-878])(loc1, Result);
		RTHOOK(6);
		F1147_10142(RTCW(loc1));
		for (;;) {
			RTHOOK(7);
			tb1 = F940_9502(RTCW(loc1));
			if (tb1) break;
			RTHOOK(8);
			tr1 = F1147_10116(RTCW(loc1));
			tr2 = RTMS_EX_H("",0,0);
			F2516_31238(RTCW(tr1), tr2);
			RTHOOK(9);
			tr1 = F1147_10116(RTCW(loc1));
			tr2 = *(EIF_REFERENCE *)(Current);
			tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_9_);
			ti4_1 = F95_1237(RTCW(tr2));
			F2516_31236(RTCW(tr1), ti4_1);
			RTHOOK(10);
			tr1 = *(EIF_REFERENCE *)(Current);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_7_);
			tr2 = F1147_10116(RTCW(loc1));
			F2537_31410(RTCW(tr1), tr2);
			RTHOOK(11);
			F1147_10144(RTCW(loc1));
		}
		RTHOOK(12);
		F1147_10142(RTCW(loc1));
		for (;;) {
			RTHOOK(13);
			tb2 = F940_9502(RTCW(loc1));
			if (tb2) break;
			RTHOOK(14);
			tb3 = '\0';
			tr1 = F1147_10116(RTCW(loc1));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_14_3_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
				tr1 = *(EIF_REFERENCE *)(Current);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_7_);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
				tr2 = F1147_10116(RTCW(loc1));
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_14_3_0_2_);
				tb4 = F1140_9988(RTCW(tr1), ti4_1);
				tb3 = (EIF_BOOLEAN) !tb4;
			}
			if (tb3) {
				RTHOOK(15);
				tr1 = F1147_10116(RTCW(loc1));
				F2516_31272(RTCW(tr1));
			}
			RTHOOK(16);
			F1147_10144(RTCW(loc1));
		}
	}
	RTHOOK(17);
	RTLE;
	RTEE;
	return Result;
}

/* {GB_CLIPBOARD}.object_stone */
EIF_REFERENCE F2515_31162 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(10);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc8);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLR(6,loc4);
	RTLR(7,loc3);
	RTLR(8,loc5);
	RTLR(9,loc6);
	RTLIU(10);
	
	RTEAA("object_stone", 2514, Current, 8, 0, 36840);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_0_)) {
		
		RTHOOK(3);
		Result = RTLNS(eif_new_type(418, 0x00).id, 418, _OBJSIZ_2_0_0_1_0_0_0_0_);
		F419_6439(RTCW(Result), *(EIF_REFERENCE *)(Current));
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		loc8 = (EIF_REFERENCE) eif_builtin_ANY_deep_twin__o (tr1);
		RTHOOK(5);
		loc1 = F2242_25801(RTCW(loc8));
		loc1 = RTRV(eif_new_type(2243, 0x00), loc1);
		RTHOOK(6);
		F2512_31146(Current, loc1);
		RTHOOK(7);
		loc1 = F2242_25801(RTCW(loc8));
		loc1 = RTRV(eif_new_type(2243, 0x00), loc1);
		RTHOOK(8);
		tr1 = RTOSCF(21667,F1951_21667, (Current));
		F2263_26045(Current, loc1, tr1);
		RTHOOK(9);
		loc1 = F2242_25801(RTCW(loc8));
		loc1 = RTRV(eif_new_type(2243, 0x00), loc1);
		RTHOOK(10);
		tr1 = RTOSCF(21679,F1951_21679, (Current));
		loc2 = F2263_26041(Current, loc1, tr1);
		loc2 = RTRV(eif_new_type(2243, 0x00), loc2);
		RTHOOK(11);
		loc4 = F2263_26039(Current, loc2);
		RTHOOK(12);
		tr1 = RTOSCF(21660,F1951_21660, (Current));
		loc3 = F1136_9987(RTCW(loc4), tr1);
		RTHOOK(13);
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			
			RTHOOK(15);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_1_);
			loc7 = F1500_14220(RTCW(tr1));
			RTHOOK(16);
			tr1 = *(EIF_REFERENCE *)(Current);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_7_);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			tb1 = F1140_9988(RTCW(tr1), loc7);
			if (tb1) {
				RTHOOK(17);
				F419_6442(RTCW(Result), loc7);
			}
		}
		RTHOOK(18);
		loc2 = F2242_25801(RTCW(loc8));
		loc2 = RTRV(eif_new_type(2243, 0x00), loc2);
		RTHOOK(19);
		tr1 = RTOSCF(21660,F1951_21660, (Current));
		loc5 = F2263_26046(Current, loc2, tr1);
		RTHOOK(20);
		F1147_10142(RTCW(loc5));
		for (;;) {
			RTHOOK(21);
			tb1 = F940_9502(RTCW(loc5));
			if (tb1) break;
			RTHOOK(22);
			tr1 = F1147_10116(RTCW(loc5));
			loc6 = F2242_25801(RTCW(tr1));
			loc6 = RTRV(eif_new_type(2238, 0x00), loc6);
			RTHOOK(23);
			if ((EIF_BOOLEAN)(loc6 != NULL)) {
				
				RTHOOK(25);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc6) + _REFACS_1_);
				loc7 = F1500_14220(RTCW(tr1));
				RTHOOK(26);
				tr1 = *(EIF_REFERENCE *)(Current);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_7_);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
				tb2 = F1140_9988(RTCW(tr1), loc7);
				if (tb2) {
					RTHOOK(27);
					tr1 = *(EIF_REFERENCE *)(RTCW(Result));
					F1141_10026(RTCW(tr1), loc7, loc7);
				}
			}
			RTHOOK(28);
			F1147_10144(RTCW(loc5));
		}
		RTHOOK(29);
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) Result;
		RTHOOK(30);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_6_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		RTHOOK(31);
		Result = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		RTHOOK(32);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) Result;
	}
	RTHOOK(33);
	RTLE;
	RTEE;
	return Result;
}

/* {GB_CLIPBOARD}.is_empty */
EIF_BOOLEAN F2515_31164 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("is_empty", 2514, Current, 0, 0, 36842);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 == NULL);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {GB_CLIPBOARD}.internal_object */
EIF_REFERENCE F2515_31166 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("internal_object", 2514, Current, 1, 0, 36844);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		loc1 = (EIF_REFERENCE) eif_builtin_ANY_deep_twin__o (tr1);
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_5_);
		F96_1264(RTCW(tr1));
		RTHOOK(4);
		F2512_31146(Current, loc1);
		RTHOOK(5);
		tr1 = RTOSCF(21667,F1951_21667, (Current));
		F2263_26045(Current, loc1, tr1);
		RTHOOK(6);
		Result = F2512_31144(Current, loc1, (EIF_BOOLEAN) 1);
		RTHOOK(7);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_5_);
		F96_1265(RTCW(tr1));
	}
	RTHOOK(8);
	RTLE;
	RTEE;
	return Result;
}

/* {GB_CLIPBOARD}.set_object */
void F2515_31167 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTEAA("set_object", 2514, Current, 3, 1, 36845);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		RTHOOK(2);
		F2516_31210(RTCW(arg1));
	}
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_10_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTHOOK(4);
	loc1 = RTLNS(eif_new_type(2508, 0x00).id, 2508, _OBJSIZ_4_0_0_2_0_0_0_0_);
	F2509_31088(RTCW(loc1), *(EIF_REFERENCE *)(Current));
	RTHOOK(5);
	F2509_31092(RTCW(loc1), arg1);
	RTHOOK(6);
	loc2 = F2509_31093(RTCW(loc1));
	RTHOOK(7);
	tb1 = F2516_31176(RTCW(arg1));
	if (tb1) {
		RTHOOK(8);
		loc3 = F2242_25801(RTCW(loc2));
		loc3 = RTRV(eif_new_type(2243, 0x00), loc3);
		RTHOOK(9);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_14_3_0_0_);
		F2512_31147(Current, loc3, ti4_1, ((EIF_INTEGER_32) 1L));
	}
	RTHOOK(10);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F362_5875(RTCW(tr1), loc2);
	RTHOOK(11);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tb1 = F827_9290(RTCW(tr1));
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(12);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1177_10288(RTCW(tr1), NULL);
	}
	RTHOOK(13);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(15);
	RTLE;
	RTEE;
}

/* {GB_CLIPBOARD}.history_changed */
void F2515_31171 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("history_changed", 2514, Current, 0, 0, 36849);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(3);
	RTEE;
}

void EIF_Minit1693 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
