/*
 * Code for class GB_COMPONENT_SELECTOR_ITEM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gb1691.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GB_COMPONENT_SELECTOR_ITEM}.components */
EIF_REFERENCE F2513_31150 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_6_);
}


/* {GB_COMPONENT_SELECTOR_ITEM}.make_from_object */
void F2513_31151 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg3);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("make_from_object", 2512, Current, 0, 3, 36829);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_4_);
	F2484_30926(RTCW(tr1), arg1, arg2);
	RTHOOK(2);
	F2513_31152(Current, arg2, arg3);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {GB_COMPONENT_SELECTOR_ITEM}.make_with_name */
void F2513_31152 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc1);
	RTLR(6,loc2);
	RTLIU(7);
	
	RTEAA("make_with_name", 2512, Current, 2, 2, 36830);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg2;
	RTHOOK(2);
	F1369_12570(Current, arg1);
	RTHOOK(3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr1 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
	RTAR(tr1,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1494,0xFFF9,0,1419,419,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2= RTLNRF(typres0.id, (EIF_POINTER) __A1691_663, (EIF_POINTER) _A1691_663, (EIF_POINTER)(F2513_31153),tr1, 1, 0);
	}
	F1557_15055(Current, tr2);
	RTHOOK(4);
	loc1 = RTLNS(eif_new_type(2513, 0x00).id, 2513, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F2514_31155(RTCW(loc1), arg1, *(EIF_REFERENCE *)(Current + _REFACS_6_));
	RTHOOK(5);
	loc2 = RTLNS(eif_new_type(631, 0x00).id, 631, _OBJSIZ_0_0_0_0_0_0_0_0_);
	RTHOOK(6);
	tr1 = F2514_31158(RTCW(loc1));
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11508[Dtype(RTCW(tr1))-1503])(tr1);
	tr1 = F632_8634(RTCW(loc2), tr1);
	F1364_12545(Current, tr1);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {GB_COMPONENT_SELECTOR_ITEM}.generate_pebble */
EIF_REFERENCE F2513_31153 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,Result);
	RTLIU(6);
	
	RTEAA("generate_pebble", 2512, Current, 1, 0, 36831);
	RTGC;
	RTHOOK(1);
	tb1 = F1683_17043(RTCV(RTOSCF(21677,F1951_21677, (Current))));
	if (tb1) {
		RTHOOK(2);
		loc1 = RTLNS(eif_new_type(2513, 0x00).id, 2513, _OBJSIZ_2_0_0_0_0_0_0_0_);
		tr1 = F1500_14211(RTCV(F1369_12571(Current)));
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		F2514_31155(RTCW(loc1), tr1, tr2);
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_9_);
		F1960_22057(RTCW(tr1), loc1);
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_9_);
		tb1 = F1575_15184(RTCW(tr1));
		if ((EIF_BOOLEAN) !tb1) {
			RTHOOK(5);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_11_);
			F1975_22235(RTCW(tr1));
		}
	} else {
		RTHOOK(6);
		Result = RTLNS(eif_new_type(419, 0x00).id, 419, _OBJSIZ_2_0_0_1_0_0_0_0_);
		tr1 = RTLNS(eif_new_type(2513, 0x00).id, 2513, _OBJSIZ_2_0_0_0_0_0_0_0_);
		tr2 = F1500_14211(RTCV(F1369_12571(Current)));
		tr3 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		F2514_31155(RTCW(tr1), tr2, tr3);
		F420_6443(RTCW(Result), tr1);
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit1691 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
