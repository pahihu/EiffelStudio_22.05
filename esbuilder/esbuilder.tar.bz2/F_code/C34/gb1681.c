/*
 * Code for class GB_EV_VIEWPORT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gb1681.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GB_EV_VIEWPORT}.generate_xml */
void F2503_31059 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("generate_xml", 2502, Current, 0, 1, 36747);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(22515,F1995_22515, (Current));
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	tr2 = F1147_10119(RTCW(tr2));
	ti4_1 = F1595_15773(RTCW(tr2));
	F2485_30972(Current, arg1, tr1, ti4_1);
	RTHOOK(2);
	tr1 = RTOSCF(22516,F1995_22516, (Current));
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	tr2 = F1147_10119(RTCW(tr2));
	ti4_1 = F1595_15774(RTCW(tr2));
	F2485_30972(Current, arg1, tr1, ti4_1);
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	tr1 = F1147_10119(RTCW(tr1));
	tb1 = F1593_15569(RTCW(tr1));
	if (tb1) {
		RTHOOK(4);
		tr1 = RTOSCF(22517,F1995_22517, (Current));
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
		tr2 = F1147_10119(RTCW(tr2));
		tr2 = F1576_15208(RTCW(tr2));
		ti4_1 = F1362_12530(RTCW(tr2));
		F2485_30972(Current, arg1, tr1, ti4_1);
		RTHOOK(5);
		tr1 = RTOSCF(22518,F1995_22518, (Current));
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
		tr2 = F1147_10119(RTCW(tr2));
		tr2 = F1576_15208(RTCW(tr2));
		ti4_1 = F1362_12531(RTCW(tr2));
		F2485_30972(Current, arg1, tr1, ti4_1);
	} else {
		RTHOOK(6);
		tr1 = RTOSCF(22517,F1995_22517, (Current));
		F2485_30972(Current, arg1, tr1, ((EIF_INTEGER_32) -1L));
		RTHOOK(7);
		tr1 = RTOSCF(22518,F1995_22518, (Current));
		F2485_30972(Current, arg1, tr1, ((EIF_INTEGER_32) -1L));
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {GB_EV_VIEWPORT}.modify_from_xml */
void F2503_31060 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("modify_from_xml", 2502, Current, 0, 1, 36748);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(9656,F999_9656, (Current));
	F54_774(RTCW(tr1), Current, arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {GB_EV_VIEWPORT}.modify_from_xml_after_build */
void F2503_31061 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("modify_from_xml_after_build", 2502, Current, 1, 1, 36749);
	RTGC;
	RTHOOK(1);
	tr1 = F2263_26039(Current, arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	tr2 = RTOSCF(22517,F1995_22517, (Current));
	loc1 = F1136_9987(RTCW(tr1), tr2);
	RTHOOK(3);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTHOOK(4);
		tr1 = RTOSCF(22517,F1995_22517, (Current));
		ti4_1 = F2485_30967(Current, tr1);
		F1995_22509(Current, ti4_1);
	}
	RTHOOK(5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	tr2 = RTOSCF(22518,F1995_22518, (Current));
	loc1 = F1136_9987(RTCW(tr1), tr2);
	RTHOOK(6);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTHOOK(7);
		tr1 = RTOSCF(22518,F1995_22518, (Current));
		ti4_1 = F2485_30967(Current, tr1);
		F1995_22511(Current, ti4_1);
	}
	RTHOOK(8);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	tr2 = RTOSCF(22515,F1995_22515, (Current));
	tr1 = F1136_9987(RTCW(tr1), tr2);
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		RTHOOK(9);
		tr1 = RTOSCF(22515,F1995_22515, (Current));
		ti4_1 = F2485_30967(Current, tr1);
		F1995_22506(Current, ti4_1);
	}
	RTHOOK(10);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	tr2 = RTOSCF(22516,F1995_22516, (Current));
	tr1 = F1136_9987(RTCW(tr1), tr2);
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		RTHOOK(11);
		tr1 = RTOSCF(22516,F1995_22516, (Current));
		ti4_1 = F2485_30967(Current, tr1);
		F1995_22507(Current, ti4_1);
	}
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {GB_EV_VIEWPORT}.generate_code */
EIF_REFERENCE F2503_31062 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,tr2);
	RTLR(6,arg2);
	RTLR(7,tr3);
	RTLIU(8);
	
	RTEAA("generate_code", 2502, Current, 1, 2, 36746);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1146,1504,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 1146, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F1147_10111(RTCW(Result), ((EIF_INTEGER_32) 2L));
	RTHOOK(2);
	tr1 = F2263_26039(Current, arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	tr2 = RTOSCF(22517,F1995_22517, (Current));
	loc1 = F1136_9987(RTCW(tr1), tr2);
	RTHOOK(4);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
		ti4_1 = F1500_14220(RTCW(tr1));
		tb1 = (EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		RTHOOK(5);
		tr1 = RTOSCF(22517,F1995_22517, (Current));
		tr2 = F2021_22824(RTCW(arg2));
		tr3 = RTMS_EX_H("set_item_width (",16,1228397864);
		tr1 = F2485_30980(Current, tr1, tr2, tr3);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8029[Dtype(RTCW(Result))-989])(Result, tr1);
	}
	RTHOOK(6);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	tr2 = RTOSCF(22518,F1995_22518, (Current));
	loc1 = F1136_9987(RTCW(tr1), tr2);
	RTHOOK(7);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
		ti4_1 = F1500_14220(RTCW(tr1));
		tb1 = (EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		RTHOOK(8);
		tr1 = RTOSCF(22518,F1995_22518, (Current));
		tr2 = F2021_22824(RTCW(arg2));
		tr3 = RTMS_EX_H("set_item_height (",17,1083792680);
		tr1 = F2485_30980(Current, tr1, tr2, tr3);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8029[Dtype(RTCW(Result))-989])(Result, tr1);
	}
	RTHOOK(9);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	tr2 = RTOSCF(22515,F1995_22515, (Current));
	loc1 = F1136_9987(RTCW(tr1), tr2);
	RTHOOK(10);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
		ti4_1 = F1500_14220(RTCW(tr1));
		tb1 = (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		RTHOOK(11);
		tr1 = RTOSCF(22515,F1995_22515, (Current));
		tr2 = F2021_22824(RTCW(arg2));
		tr3 = RTMS_EX_H("set_x_offset (",14,1894786088);
		tr1 = F2485_30980(Current, tr1, tr2, tr3);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8029[Dtype(RTCW(Result))-989])(Result, tr1);
	}
	RTHOOK(12);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	tr2 = RTOSCF(22516,F1995_22516, (Current));
	loc1 = F1136_9987(RTCW(tr1), tr2);
	RTHOOK(13);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
		ti4_1 = F1500_14220(RTCW(tr1));
		tb1 = (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		RTHOOK(14);
		tr1 = RTOSCF(22516,F1995_22516, (Current));
		tr2 = F2021_22824(RTCW(arg2));
		tr3 = RTMS_EX_H("set_y_offset (",14,1961921832);
		tr1 = F2485_30980(Current, tr1, tr2, tr3);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8029[Dtype(RTCW(Result))-989])(Result, tr1);
	}
	RTHOOK(15);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit1681 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
