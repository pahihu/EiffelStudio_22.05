/*
 * Code for class KI_PATHNAME
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ki1688.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KI_PATHNAME}.same_pathname */
EIF_BOOLEAN F2510_31115 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("same_pathname", 2509, Current, 0, 1, 36793);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == Current)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		RTHOOK(4);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_1_0_0_);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_1_0_0_) == ti4_1)) {
			RTHOOK(5);
			RTHOOK(6);
			RTLE;
			RTEE;
			return (EIF_BOOLEAN) F2510_31117(Current, arg1);
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) 0;
}

/* {KI_PATHNAME}.is_subpathname */
EIF_BOOLEAN F2510_31117 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTEAA("is_subpathname", 2509, Current, 2, 1, 36795);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == Current)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		RTHOOK(4);
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_1_0_0_);
		RTHOOK(5);
		tb1 = '\0';
		tb2 = '\0';
		tb3 = '\0';
		tb4 = '\0';
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_1_0_0_);
		if ((EIF_BOOLEAN) (loc2 <= ti4_1)) {
			tb5 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_4_0_);
			tb4 = (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) == tb5);
		}
		if (tb4) {
			tr1 = RTOSCF(6072,F391_6072, (Current));
			tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
			tb4 = F1929_21289(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_3_), tr2);
			tb3 = tb4;
		}
		if (tb3) {
			tr1 = RTOSCF(6072,F391_6072, (Current));
			tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
			tb3 = F1929_21289(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_2_), tr2);
			tb2 = tb3;
		}
		if (tb2) {
			tr1 = RTOSCF(6072,F391_6072, (Current));
			tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
			tb2 = F1929_21289(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_), tr2);
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(6);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			RTHOOK(7);
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				RTHOOK(8);
				if ((EIF_BOOLEAN) (loc1 > loc2)) break;
				RTHOOK(9);
				tr1 = RTOSCF(21261,F1925_21261, (Current));
				tr2 = F2511_31124(Current, loc1);
				tr3 = F2511_31124(RTCW(arg1), loc1);
				tb1 = F1338_12237(RTCW(tr1), tr2, tr3);
				if ((EIF_BOOLEAN) !tb1) {
					RTHOOK(10);
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					RTHOOK(11);
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
				}
				RTHOOK(12);
				loc1++;
			}
		}
	}
	RTHOOK(13);
	RTLE;
	RTEE;
	return Result;
}

/* {KI_PATHNAME}.is_equal */
EIF_BOOLEAN F2510_31119 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("is_equal", 2509, Current, 0, 1, 36797);
	RTGC;
	RTHOOK(1);
	tr1 = RTOSCF(12111,F1329_12111, (Current));
	tb1 = F35_463(RTCW(tr1), Current, arg1);
	if (tb1) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) F2510_31115(Current, arg1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) 0;
}

void EIF_Minit1688 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
