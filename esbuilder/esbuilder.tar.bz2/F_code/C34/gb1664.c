/*
 * Code for class GB_EV_GAUGE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gb1664.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GB_EV_GAUGE}.has_user_events */
EIF_BOOLEAN F2486_22330 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {GB_EV_GAUGE}.generate_xml */
void F2486_30981 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("generate_xml", 2485, Current, 1, 1, 36668);
	RTGC;
	RTHOOK(1);
	tr1 = F2485_30944(Current);
	tr1 = F524_7211(Current, tr1);
	loc1 = F2261_26019(Current, tr1);
	loc1 = RTRV(eif_new_type(1623, 0x00), loc1);
	RTHOOK(2);
	tb1 = '\01';
	ti4_1 = F1624_16019(RTCW(loc1));
	ti4_2 = F1624_16019(RTCV(F2485_30944(Current)));
	if (!(EIF_BOOLEAN)(ti4_1 != ti4_2)) {
		tr1 = RTOSCF(22344,F1984_22344, (Current));
		tb1 = F2485_30976(Current, tr1);
	}
	if (tb1) {
		RTHOOK(3);
		tr1 = RTOSCF(22344,F1984_22344, (Current));
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
		tr2 = F1147_10119(RTCW(tr2));
		ti4_1 = F1624_16019(RTCW(tr2));
		F2485_30972(Current, arg1, tr1, ti4_1);
	}
	RTHOOK(4);
	tb1 = '\01';
	ti4_1 = F1624_16020(RTCW(loc1));
	ti4_2 = F1624_16020(RTCV(F2485_30944(Current)));
	if (!(EIF_BOOLEAN)(ti4_1 != ti4_2)) {
		tr1 = RTOSCF(22345,F1984_22345, (Current));
		tb1 = F2485_30976(Current, tr1);
	}
	if (tb1) {
		RTHOOK(5);
		tr1 = RTOSCF(22345,F1984_22345, (Current));
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
		tr2 = F1147_10119(RTCW(tr2));
		ti4_1 = F1624_16020(RTCW(tr2));
		F2485_30972(Current, arg1, tr1, ti4_1);
	}
	RTHOOK(6);
	tb1 = '\01';
	ti4_1 = F1624_16021(RTCW(loc1));
	ti4_2 = F1624_16021(RTCV(F2485_30944(Current)));
	if (!(EIF_BOOLEAN)(ti4_1 != ti4_2)) {
		tr1 = RTOSCF(22346,F1984_22346, (Current));
		tb1 = F2485_30976(Current, tr1);
	}
	if (tb1) {
		RTHOOK(7);
		tr1 = RTOSCF(22346,F1984_22346, (Current));
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
		tr2 = F1147_10119(RTCW(tr2));
		ti4_1 = F1624_16021(RTCW(tr2));
		F2485_30972(Current, arg1, tr1, ti4_1);
	}
	RTHOOK(8);
	tb1 = '\01';
	tb2 = '\01';
	tb3 = '\01';
	tr1 = F1624_16022(RTCW(loc1));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O8064[Dtype(tr1)-919]);
	tr1 = F1624_16022(RTCV(F2485_30944(Current)));
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O8064[Dtype(tr1)-919]);
	if (!(EIF_BOOLEAN)(ti4_1 != ti4_2)) {
		tr1 = F1624_16022(RTCW(loc1));
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O8063[Dtype(tr1)-919]);
		tr1 = F1624_16022(RTCV(F2485_30944(Current)));
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O8063[Dtype(tr1)-919]);
		tb3 = (EIF_BOOLEAN)(ti4_1 != ti4_2);
	}
	if (!tb3) {
		tr1 = RTOSCF(22348,F1984_22348, (Current));
		tb2 = F2485_30976(Current, tr1);
	}
	if (!tb2) {
		tr1 = RTOSCF(22347,F1984_22347, (Current));
		tb1 = F2485_30976(Current, tr1);
	}
	if (tb1) {
		RTHOOK(9);
		tr1 = RTOSCF(22348,F1984_22348, (Current));
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
		tr2 = F1147_10119(RTCW(tr2));
		tr2 = F1624_16022(RTCW(tr2));
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2) + O8064[Dtype(tr2)-919]);
		F2485_30972(Current, arg1, tr1, ti4_1);
		RTHOOK(10);
		tr1 = RTOSCF(22347,F1984_22347, (Current));
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
		tr2 = F1147_10119(RTCW(tr2));
		tr2 = F1624_16022(RTCW(tr2));
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2) + O8063[Dtype(tr2)-919]);
		F2485_30972(Current, arg1, tr1, ti4_1);
	}
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {GB_EV_GAUGE}.modify_from_xml */
void F2486_30982 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLR(5,loc2);
	RTLR(6,loc3);
	RTLR(7,tr3);
	RTLR(8,tr4);
	RTLIU(9);
	
	RTEAA("modify_from_xml", 2485, Current, 3, 1, 36669);
	RTGC;
	RTHOOK(1);
	tr1 = F2263_26039(Current, arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
	tr2 = RTOSCF(22347,F1984_22347, (Current));
	loc1 = F1136_9987(RTCW(tr1), tr2);
	RTHOOK(3);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
		tr2 = RTOSCF(22348,F1984_22348, (Current));
		loc2 = F1136_9987(RTCW(tr1), tr2);
		
		RTHOOK(6);
		loc3 = RTLNS(eif_new_type(919, 0x00).id, 919, _OBJSIZ_0_1_0_2_0_0_0_0_);
		tr1 = RTOSCF(22348,F1984_22348, (Current));
		ti4_1 = F2485_30967(Current, tr1);
		tr1 = RTOSCF(22347,F1984_22347, (Current));
		ti4_2 = F2485_30967(Current, tr1);
		F920_9357(RTCW(loc3), ti4_1, ti4_2);
		RTHOOK(7);
		tr1 = F1624_16022(RTCV(F2485_30944(Current)));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8049[Dtype(RTCW(tr1))-919])(tr1, loc3);
		RTHOOK(8);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
		tr1 = F1147_10118(RTCW(tr1), ((EIF_INTEGER_32) 2L));
		tr1 = F1624_16022(RTCW(tr1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8049[Dtype(RTCW(tr1))-919])(tr1, loc3);
	}
	RTHOOK(9);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
	tr2 = RTOSCF(22344,F1984_22344, (Current));
	tr1 = F1136_9987(RTCW(tr1), tr2);
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		RTHOOK(10);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,1425,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 2, 1);
		}
		tr2 = RTOSCF(22344,F1984_22344, (Current));
		ti4_1 = F2485_30967(Current, tr2);
		((EIF_TYPED_VALUE *)tr1+1)->it_i4 = ti4_1;
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1493,0xFFF9,1,1419,1623,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr4= RTLNRF(typres0.id, (EIF_POINTER) __A905_212_1, (EIF_POINTER) _A905_212_1, 0, tr1, 0, 1);
		}
		F2485_30959(Current, tr4);
	}
	RTHOOK(11);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
	tr2 = RTOSCF(22345,F1984_22345, (Current));
	tr1 = F1136_9987(RTCW(tr1), tr2);
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		RTHOOK(12);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,1425,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 2, 1);
		}
		tr2 = RTOSCF(22345,F1984_22345, (Current));
		ti4_1 = F2485_30967(Current, tr2);
		((EIF_TYPED_VALUE *)tr1+1)->it_i4 = ti4_1;
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1493,0xFFF9,1,1419,1623,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr4= RTLNRF(typres0.id, (EIF_POINTER) __A905_213_1, (EIF_POINTER) _A905_213_1, 0, tr1, 0, 1);
		}
		F2485_30959(Current, tr4);
	}
	RTHOOK(13);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
	tr2 = RTOSCF(22346,F1984_22346, (Current));
	tr1 = F1136_9987(RTCW(tr1), tr2);
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		RTHOOK(14);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,1425,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 2, 1);
		}
		tr2 = RTOSCF(22346,F1984_22346, (Current));
		ti4_1 = F2485_30967(Current, tr2);
		((EIF_TYPED_VALUE *)tr1+1)->it_i4 = ti4_1;
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1493,0xFFF9,1,1419,1623,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr4= RTLNRF(typres0.id, (EIF_POINTER) __A905_214_1, (EIF_POINTER) _A905_214_1, 0, tr1, 0, 1);
		}
		F2485_30959(Current, tr4);
	}
	RTHOOK(15);
	RTLE;
	RTEE;
}

/* {GB_EV_GAUGE}.generate_code */
EIF_REFERENCE F2486_30983 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(10);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,tr2);
	RTLR(6,arg2);
	RTLR(7,loc2);
	RTLR(8,loc3);
	RTLR(9,tr3);
	RTLIU(10);
	
	RTEAA("generate_code", 2485, Current, 3, 2, 36670);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {1146,1504,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 1146, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F1147_10111(RTCW(Result), ((EIF_INTEGER_32) 4L));
	RTHOOK(2);
	tr1 = F2263_26039(Current, arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) tr1;
	RTHOOK(3);
	tr1 = RTOSCF(22347,F1984_22347, (Current));
	if (F2485_30977(Current, tr1)) {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
		tr2 = RTOSCF(22348,F1984_22348, (Current));
		loc1 = F1136_9987(RTCW(tr1), tr2);
		
		RTHOOK(6);
		tr1 = RTOSCF(22348,F1984_22348, (Current));
		if (F2485_30966(Current, tr1)) {
			RTHOOK(7);
			tr1 = RTOSCF(22347,F1984_22347, (Current));
			if (F2485_30966(Current, tr1)) {
				RTHOOK(8);
				tr1 = RTOSCF(21856,F1951_21856, (Current));
				tr2 = RTMS_EX_H(".extend (agent (",16,1237066792);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				tr2 = F2021_22824(RTCW(arg2));
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				tr2 = RTMS_EX_H("value_range).adapt (\?))",23,368115241);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7993[Dtype(RTCW(Result))-878])(Result, tr1);
				RTHOOK(9);
				tr1 = RTOSCF(21857,F1951_21857, (Current));
				tr2 = RTMS_EX_H(".extend (agent ",15,1581887776);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				tr2 = RTOSCF(22348,F1984_22348, (Current));
				tr2 = F2485_30969(Current, tr2);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				tr2 = RTMS_EX_H(")",1,41);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7993[Dtype(RTCW(Result))-878])(Result, tr1);
				RTHOOK(10);
				tr1 = RTOSCF(21857,F1951_21857, (Current));
				tr2 = RTMS_EX_H(".extend (agent ",15,1581887776);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				tr2 = RTOSCF(22347,F1984_22347, (Current));
				tr2 = F2485_30969(Current, tr2);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				tr2 = RTMS_EX_H(")",1,41);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7993[Dtype(RTCW(Result))-878])(Result, tr1);
			} else {
				RTHOOK(11);
				tr1 = RTOSCF(21856,F1951_21856, (Current));
				tr2 = RTMS_EX_H(".extend (agent (",16,1237066792);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				tr2 = F2021_22824(RTCW(arg2));
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				tr2 = RTMS_EX_H("value_range).adapt (\?))",23,368115241);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7993[Dtype(RTCW(Result))-878])(Result, tr1);
				RTHOOK(12);
				tr1 = RTOSCF(21857,F1951_21857, (Current));
				tr2 = RTMS_EX_H(".extend (agent ",15,1581887776);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				tr2 = RTOSCF(22348,F1984_22348, (Current));
				tr2 = F2485_30969(Current, tr2);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				tr2 = RTMS_EX_H(")",1,41);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7993[Dtype(RTCW(Result))-878])(Result, tr1);
				RTHOOK(13);
				tr1 = RTOSCF(21857,F1951_21857, (Current));
				tr2 = RTMS_EX_H(".extend (agent ",15,1581887776);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				tr2 = RTMS_EX_H("integer_from_integer (",22,442501928);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				tr2 = RTOSCF(22347,F1984_22347, (Current));
				tr2 = F2485_30969(Current, tr2);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				tr2 = RTMS_EX_H("))",2,10537);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7993[Dtype(RTCW(Result))-878])(Result, tr1);
			}
		} else {
			RTHOOK(14);
			tr1 = RTOSCF(22347,F1984_22347, (Current));
			if (F2485_30966(Current, tr1)) {
				RTHOOK(15);
				tr1 = RTOSCF(21856,F1951_21856, (Current));
				tr2 = RTMS_EX_H(".extend (agent (",16,1237066792);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				tr2 = F2021_22824(RTCW(arg2));
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				tr2 = RTMS_EX_H("value_range).adapt (\?))",23,368115241);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7993[Dtype(RTCW(Result))-878])(Result, tr1);
				RTHOOK(16);
				tr1 = RTOSCF(21857,F1951_21857, (Current));
				tr2 = RTMS_EX_H(".extend (agent ",15,1581887776);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				tr2 = RTMS_EX_H("integer_from_integer (",22,442501928);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				tr2 = RTOSCF(22347,F1984_22347, (Current));
				tr2 = F2485_30969(Current, tr2);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				tr2 = RTMS_EX_H("))",2,10537);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7993[Dtype(RTCW(Result))-878])(Result, tr1);
				RTHOOK(17);
				tr1 = RTOSCF(21857,F1951_21857, (Current));
				tr2 = RTMS_EX_H(".extend (agent ",15,1581887776);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				tr2 = RTOSCF(22347,F1984_22347, (Current));
				tr2 = F2485_30969(Current, tr2);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				tr2 = RTMS_EX_H(")",1,41);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7993[Dtype(RTCW(Result))-878])(Result, tr1);
			} else {
				RTHOOK(18);
				tr1 = RTOSCF(22348,F1984_22348, (Current));
				loc2 = F2485_30969(Current, tr1);
				RTHOOK(19);
				tr1 = RTOSCF(22347,F1984_22347, (Current));
				loc3 = F2485_30969(Current, tr1);
				RTHOOK(20);
				tr1 = F2021_22824(RTCW(arg2));
				tr2 = RTMS_EX_H("value_range.adapt (create {INTEGER_INTERVAL}.make (",51,1834735144);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, loc2);
				tr2 = RTMS_EX_H(", ",2,11296);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, loc3);
				tr2 = RTMS_EX_H("))",2,10537);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(RTCW(tr1))-1503])(tr1, tr2);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7993[Dtype(RTCW(Result))-878])(Result, tr1);
			}
		}
	}
	RTHOOK(21);
	tr1 = RTOSCF(22344,F1984_22344, (Current));
	if (F2485_30977(Current, tr1)) {
		RTHOOK(22);
		tr1 = RTOSCF(22344,F1984_22344, (Current));
		tr2 = F2021_22824(RTCW(arg2));
		tr3 = RTMS_EX_H("set_value (",11,830088744);
		tr1 = F2485_30980(Current, tr1, tr2, tr3);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8029[Dtype(RTCW(Result))-989])(Result, tr1);
	}
	RTHOOK(23);
	tr1 = RTOSCF(22345,F1984_22345, (Current));
	if (F2485_30977(Current, tr1)) {
		RTHOOK(24);
		tr1 = RTOSCF(22345,F1984_22345, (Current));
		tr2 = F2021_22824(RTCW(arg2));
		tr3 = RTMS_EX_H("set_step (",10,1171547688);
		tr1 = F2485_30980(Current, tr1, tr2, tr3);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8029[Dtype(RTCW(Result))-989])(Result, tr1);
	}
	RTHOOK(25);
	tr1 = RTOSCF(22346,F1984_22346, (Current));
	if (F2485_30977(Current, tr1)) {
		RTHOOK(26);
		tr1 = RTOSCF(22346,F1984_22346, (Current));
		tr2 = F2021_22824(RTCW(arg2));
		tr3 = RTMS_EX_H("set_leap (",10,1090561064);
		tr1 = F2485_30980(Current, tr1, tr2, tr3);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8029[Dtype(RTCW(Result))-989])(Result, tr1);
	}
	RTHOOK(27);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit1664 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
