#include "epoly11.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4708[1996])();
void R4708_init () {
	R4708[0] = (char *(*)()) F303_4837;
	R4708[1995] = (char *(*)()) F305_4849;
}

char *(*R4709[1996])();
void R4709_init () {
	R4709[0] = (char *(*)()) F303_4838;
	R4709[1995] = (char *(*)()) F305_4850;
}

char *(*R4710[1996])();
void R4710_init () {
	R4710[0] = (char *(*)()) F303_4839;
	R4710[1995] = (char *(*)()) F305_4851;
}

char *(*R4711[1996])();
void R4711_init () {
	R4711[0] = (char *(*)()) F303_4840;
	R4711[1995] = (char *(*)()) F305_4852;
}

char *(*R4712[1996])();
void R4712_init () {
	R4712[0] = (char *(*)()) F303_4841;
	R4712[1995] = (char *(*)()) F305_4853;
}

char *(*R4728[6])();
void R4728_init () {
	R4728[0] = (char *(*)()) F307_4865;
	R4728[1] = (char *(*)()) F308_4865_4728_1;
	{long i; for (i = 2; i < 4; i++) R4728[i] = (char *(*)()) F307_4865;}
	R4728[4] = (char *(*)()) F308_4865_4728_1;
	R4728[5] = (char *(*)()) F307_4865;
}
static EIF_REFERENCE F308_4865_4728_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F308_4865(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1455, 0x00).id, 1455, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R4730[6])();
void R4730_init () {
	R4730[0] = (char *(*)()) F307_4867;
	R4730[1] = (char *(*)()) F308_4867_4730_4;
	{long i; for (i = 2; i < 4; i++) R4730[i] = (char *(*)()) F307_4867;}
	R4730[4] = (char *(*)()) F308_4867_4730_4;
	R4730[5] = (char *(*)()) F307_4867;
}
static void F308_4867_4730_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F308_4867(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4731[6])();
void R4731_init () {
	R4731[0] = (char *(*)()) F307_4868;
	R4731[1] = (char *(*)()) F308_4868_4731_4;
	{long i; for (i = 2; i < 4; i++) R4731[i] = (char *(*)()) F307_4868;}
	R4731[4] = (char *(*)()) F308_4868_4731_4;
	R4731[5] = (char *(*)()) F307_4868;
}
static void F308_4868_4731_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F308_4868(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4738[3])();
void R4738_init () {
	R4738[0] = (char *(*)()) F310_4874;
	R4738[1] = (char *(*)()) F311_4874;
	R4738[2] = (char *(*)()) F312_4877;
}


#ifdef __cplusplus
}
#endif
