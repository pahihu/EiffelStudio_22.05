#include "epoly4.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R146[3])();
void R146_init () {
	R146[0] = (char *(*)()) F17_143;
	R146[1] = (char *(*)()) F18_143_146_3;
	R146[2] = (char *(*)()) F19_143_146_3;
}
static EIF_BOOLEAN F18_143_146_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F18_143(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F19_143_146_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F19_143(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_CHARACTER_32 *)arg2);
}

char *(*R797[5])();
void R797_init () {
	R797[0] = (char *(*)()) F57_792;
	R797[1] = (char *(*)()) F58_792;
	R797[2] = (char *(*)()) F59_792;
	R797[3] = (char *(*)()) F60_792;
	R797[4] = (char *(*)()) F61_792;
}

char *(*R802[5])();
void R802_init () {
	R802[0] = (char *(*)()) F57_797;
	R802[1] = (char *(*)()) F58_797_802_85;
	R802[2] = (char *(*)()) F59_797_802_85;
	R802[3] = (char *(*)()) F60_797_802_85;
	R802[4] = (char *(*)()) F61_797_802_85;
}
static void F58_797_802_85 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F58_797(Current, arg1, *(EIF_NATURAL_32 *)arg2, arg3);
}
static void F59_797_802_85 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F59_797(Current, arg1, *(EIF_BOOLEAN *)arg2, arg3);
}
static void F60_797_802_85 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F60_797(Current, arg1, *(EIF_CHARACTER_8 *)arg2, arg3);
}
static void F61_797_802_85 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F61_797(Current, arg1, *(EIF_INTEGER_32 *)arg2, arg3);
}

char *(*R805[5])();
void R805_init () {
	R805[0] = (char *(*)()) F57_800;
	R805[1] = (char *(*)()) F58_800;
	R805[2] = (char *(*)()) F59_800;
	R805[3] = (char *(*)()) F60_800;
	R805[4] = (char *(*)()) F61_800;
}

static EIF_TYPE_INDEX Y1757_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1757_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1757_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1757_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1757_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1757_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1757_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1757_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1757_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1757_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1757_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1757_pgtype11[] = {0xFFF8,2,0xFFFF};
EIF_TYPE_INDEX *Y1757_gen_type [2034];
EIF_TYPE_INDEX Y1757 [2034];
void Y1757_init (void)
{
	egc_routines_types [1757] = Y1757;
	egc_routines_gen_types [1757] = Y1757_gen_type;
	egc_routines_offset [1757] = 126;
	Y1757_gen_type [0] = Y1757_pgtype0;
	Y1757_gen_type [1] = Y1757_pgtype1;
	Y1757_gen_type [1985] = Y1757_pgtype2;
	Y1757_gen_type [1986] = Y1757_pgtype3;
	Y1757_gen_type [2001] = Y1757_pgtype4;
	Y1757_gen_type [2002] = Y1757_pgtype5;
	Y1757_gen_type [2028] = Y1757_pgtype6;
	Y1757_gen_type [2029] = Y1757_pgtype7;
	Y1757_gen_type [2030] = Y1757_pgtype8;
	Y1757_gen_type [2031] = Y1757_pgtype9;
	Y1757_gen_type [2032] = Y1757_pgtype10;
	Y1757_gen_type [2033] = Y1757_pgtype11;
}

char *(*R2214[4])();
void R2214_init () {
	R2214[0] = (char *(*)()) F155_2227;
	R2214[1] = (char *(*)()) F156_2227_2214_1;
	R2214[2] = (char *(*)()) F155_2227;
	R2214[3] = (char *(*)()) F156_2227_2214_1;
}
static EIF_REFERENCE F156_2227_2214_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F156_2227(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1455, 0x00).id, 1455, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R2274[2032])();
void R2274_init () {
	R2274[0] = (char *(*)()) F235_4117;
	R2274[1] = (char *(*)()) F236_4121;
	R2274[2] = (char *(*)()) F237_4125;
	R2274[3] = (char *(*)()) F238_4128;
	R2274[4] = (char *(*)()) F239_4131;
	R2274[5] = (char *(*)()) F240_4134;
	{long i; for (i = 377; i < 379; i++) R2274[i] = (char *(*)()) F167_2286;}
	R2274[398] = (char *(*)()) F633_8646;
	R2274[1729] = (char *(*)()) F1964_22098;
	R2274[1730] = (char *(*)()) F167_2286;
	R2274[1731] = (char *(*)()) F1966_22109;
	{long i; for (i = 1741; i < 1743; i++) R2274[i] = (char *(*)()) F167_2286;}
	R2274[1743] = (char *(*)()) F1978_22246;
	R2274[1744] = (char *(*)()) F1979_22251;
	R2274[1745] = (char *(*)()) F167_2286;
	R2274[1943] = (char *(*)()) F2178_24696;
	R2274[1956] = (char *(*)()) F167_2286;
	R2274[1959] = (char *(*)()) F2194_24988;
	R2274[1961] = (char *(*)()) F2196_25045;
	R2274[1962] = (char *(*)()) F2197_25051;
	R2274[2030] = (char *(*)()) F2265_26060;
	R2274[2031] = (char *(*)()) F2266_26063;
}

char *(*R2275[2032])();
void R2275_init () {
	R2275[0] = (char *(*)()) F235_4118;
	R2275[1] = (char *(*)()) F236_4122;
	R2275[2] = (char *(*)()) F237_4126;
	R2275[3] = (char *(*)()) F238_4129;
	R2275[4] = (char *(*)()) F239_4132;
	R2275[5] = (char *(*)()) F240_4135;
	R2275[377] = (char *(*)()) F612_7897;
	R2275[378] = (char *(*)()) F613_7900;
	R2275[398] = (char *(*)()) F633_8647;
	R2275[1729] = (char *(*)()) F1964_22099;
	R2275[1730] = (char *(*)()) F234_4114;
	R2275[1731] = (char *(*)()) F1966_22111;
	{long i; for (i = 1741; i < 1746; i++) R2275[i] = (char *(*)()) F1975_22235;}
	R2275[1943] = (char *(*)()) F2178_24697;
	R2275[1956] = (char *(*)()) F2191_24977;
	R2275[1959] = (char *(*)()) F2194_24989;
	R2275[1961] = (char *(*)()) F2196_25047;
	R2275[1962] = (char *(*)()) F2197_25054;
	R2275[2030] = (char *(*)()) F2265_26061;
	R2275[2031] = (char *(*)()) F2266_26067;
}

char *(*R2282[2032])();
void R2282_init () {
	{long i; for (i = 0; i < 6; i++) R2282[i] = (char *(*)()) F234_4103;}
	{long i; for (i = 377; i < 379; i++) R2282[i] = (char *(*)()) F234_4103;}
	R2282[398] = (char *(*)()) F234_4103;
	{long i; for (i = 1729; i < 1732; i++) R2282[i] = (char *(*)()) F234_4103;}
	R2282[1741] = (char *(*)()) F1976_22237;
	R2282[1742] = (char *(*)()) F1977_22241;
	R2282[1743] = (char *(*)()) F1978_22247;
	R2282[1744] = (char *(*)()) F1979_22252;
	R2282[1745] = (char *(*)()) F1980_22256;
	R2282[1943] = (char *(*)()) F234_4103;
	R2282[1956] = (char *(*)()) F2191_24975;
	R2282[1959] = (char *(*)()) F234_4103;
	{long i; for (i = 1961; i < 1963; i++) R2282[i] = (char *(*)()) F234_4103;}
	{long i; for (i = 2030; i < 2032; i++) R2282[i] = (char *(*)()) F234_4103;}
}

char *(*R2348[3])();
void R2348_init () {
	R2348[0] = (char *(*)()) F2295_27261;
	R2348[2] = (char *(*)()) F2294_27133;
}

char *(*R2352[3])();
void R2352_init () {
	R2352[0] = (char *(*)()) F2295_27342;
	R2352[2] = (char *(*)()) F2297_28738;
}

char *(*R2355[3])();
void R2355_init () {
	R2355[0] = (char *(*)()) F2038_23233;
	R2355[2] = (char *(*)()) F2297_28769;
}

char *(*R2356[3])();
void R2356_init () {
	R2356[0] = (char *(*)()) F2036_23089;
	R2356[2] = (char *(*)()) F2297_28768;
}

char *(*R2430[2])();
void R2430_init () {
	R2430[0] = (char *(*)()) F654_8930_2430_15;
	R2430[1] = (char *(*)()) F655_8959_2430_15;
}
static EIF_REFERENCE F654_8930_2430_15 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F654_8930(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1455, 0x00).id, 1455, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F655_8959_2430_15 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F655_8959(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1455, 0x00).id, 1455, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R2431[2])();
void R2431_init () {
	R2431[0] = (char *(*)()) F654_8938;
	R2431[1] = (char *(*)()) F655_8963;
}

char *(*R2432[2])();
void R2432_init () {
	R2432[0] = (char *(*)()) F654_8942_2432_185;
	R2432[1] = (char *(*)()) F655_8965_2432_185;
}
static void F654_8942_2432_185 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F654_8942(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F655_8965_2432_185 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F655_8965(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}

char *(*R2433[2])();
void R2433_init () {
	R2433[0] = (char *(*)()) F654_8951;
	R2433[1] = (char *(*)()) F655_8970;
}

char *(*R2434[2])();
void R2434_init () {
	R2434[0] = (char *(*)()) F654_8953;
	R2434[1] = (char *(*)()) F655_8971;
}

char *(*R2436[2])();
void R2436_init () {
	R2436[0] = (char *(*)()) F654_8955;
	R2436[1] = (char *(*)()) F655_8973;
}

char *(*R2440[2])();
void R2440_init () {
	R2440[0] = (char *(*)()) F654_8931;
	R2440[1] = (char *(*)()) F189_2455;
}

char *(*R2441[2])();
void R2441_init () {
	R2441[0] = (char *(*)()) F654_8932;
	R2441[1] = (char *(*)()) F189_2456;
}

char *(*R2442[2])();
void R2442_init () {
	R2442[0] = (char *(*)()) F654_8933;
	R2442[1] = (char *(*)()) F655_8960;
}

char *(*R2443[2])();
void R2443_init () {
	R2443[0] = (char *(*)()) F654_8934;
	R2443[1] = (char *(*)()) F655_8961;
}

char *(*R2444[2])();
void R2444_init () {
	R2444[0] = (char *(*)()) F654_8935;
	R2444[1] = (char *(*)()) F655_8962;
}

char *(*R2447[2])();
void R2447_init () {
	R2447[0] = (char *(*)()) F189_2462;
	R2447[1] = (char *(*)()) F655_8964;
}

char *(*R2448[2])();
void R2448_init () {
	R2448[0] = (char *(*)()) F654_8939;
	R2448[1] = (char *(*)()) F189_2463;
}

char *(*R2451[2])();
void R2451_init () {
	R2451[0] = (char *(*)()) F654_8946;
	R2451[1] = (char *(*)()) F655_8968;
}

char *(*R2453[2])();
void R2453_init () {
	R2453[0] = (char *(*)()) F654_8949;
	R2453[1] = (char *(*)()) F655_8969;
}

char *(*R2505[3])();
void R2505_init () {
	{long i; for (i = 0; i < 2; i++) R2505[i] = (char *(*)()) F1910_20869;}
	R2505[2] = (char *(*)()) F1912_20879;
}

char *(*R2542[1728])();
void R2542_init () {
	R2542[0] = (char *(*)()) F207_2567;
	R2542[1727] = (char *(*)()) F1934_21369;
}

char *(*R2545[597])();
void R2545_init () {
	R2545[0] = (char *(*)()) F1946_21511;
	R2545[1] = (char *(*)()) F1947_21519;
	R2545[2] = (char *(*)()) F1948_21524;
	R2545[4] = (char *(*)()) F1950_21537;
	{long i; for (i = 124; i < 129; i++) R2545[i] = (char *(*)()) F2069_23671;}
	{long i; for (i = 595; i < 597; i++) R2545[i] = (char *(*)()) F2541_31594;}
}


#ifdef __cplusplus
}
#endif
