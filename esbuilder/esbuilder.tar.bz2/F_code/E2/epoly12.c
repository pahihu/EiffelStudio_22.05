#include "epoly12.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4739[3])();
void R4739_init () {
	R4739[0] = (char *(*)()) F310_4875;
	R4739[1] = (char *(*)()) F311_4875;
	R4739[2] = (char *(*)()) F310_4875;
}

char *(*R4799[142])();
void R4799_init () {
	R4799[0] = (char *(*)()) F1927_21270;
	R4799[6] = (char *(*)()) F1933_21340;
	R4799[8] = (char *(*)()) F1935_21379;
	{long i; for (i = 137; i < 142; i++) R4799[i] = (char *(*)()) F2063_23636;}
}

char *(*R4802[142])();
void R4802_init () {
	R4802[0] = (char *(*)()) F317_4939;
	R4802[6] = (char *(*)()) F317_4939;
	R4802[8] = (char *(*)()) F317_4939;
	R4802[134] = (char *(*)()) F286_4674;
	{long i; for (i = 137; i < 142; i++) R4802[i] = (char *(*)()) F286_4674;}
}

char *(*R4805[142])();
void R4805_init () {
	R4805[0] = (char *(*)()) F1927_21269;
	R4805[6] = (char *(*)()) F1933_21345;
	R4805[8] = (char *(*)()) F1935_21373;
	{long i; for (i = 137; i < 142; i++) R4805[i] = (char *(*)()) F1341_12271;}
}

char *(*R4807[142])();
void R4807_init () {
	R4807[0] = (char *(*)()) F1927_21264;
	R4807[6] = (char *(*)()) F1933_21346;
	R4807[8] = (char *(*)()) F1935_21375;
	{long i; for (i = 137; i < 142; i++) R4807[i] = (char *(*)()) F2062_23602;}
}

char *(*R4808[142])();
void R4808_init () {
	R4808[0] = (char *(*)()) F1927_21265_4808_1;
	R4808[6] = (char *(*)()) F1933_21347_4808_1;
	R4808[8] = (char *(*)()) F1935_21376_4808_1;
	R4808[137] = (char *(*)()) F2064_23653_4808_1;
	{long i; for (i = 138; i < 142; i++) R4808[i] = (char *(*)()) F2065_23659_4808_1;}
}
static EIF_REFERENCE F1927_21265_4808_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1927_21265(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1455, 0x00).id, 1455, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1933_21347_4808_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1933_21347(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1455, 0x00).id, 1455, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1935_21376_4808_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1935_21376(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1455, 0x00).id, 1455, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F2064_23653_4808_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F2064_23653(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1455, 0x00).id, 1455, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F2065_23659_4808_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F2065_23659(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1455, 0x00).id, 1455, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R4809[142])();
void R4809_init () {
	R4809[0] = (char *(*)()) F317_4946;
	R4809[6] = (char *(*)()) F317_4946;
	R4809[8] = (char *(*)()) F317_4946;
	{long i; for (i = 137; i < 142; i++) R4809[i] = (char *(*)()) F2063_23642;}
}

char *(*R4813[1636])();
void R4813_init () {
	R4813[0] = (char *(*)()) F319_5109;
	{long i; for (i = 1; i < 3; i++) R4813[i] = (char *(*)()) F320_5272;}
	R4813[926] = (char *(*)()) F319_5109;
	R4813[1635] = (char *(*)()) F320_5272;
}

char *(*R4814[1636])();
void R4814_init () {
	R4814[0] = (char *(*)()) F319_5110;
	{long i; for (i = 1; i < 3; i++) R4814[i] = (char *(*)()) F320_5273;}
	R4814[926] = (char *(*)()) F319_5110;
	R4814[1635] = (char *(*)()) F320_5273;
}

char *(*R4815[1636])();
void R4815_init () {
	R4815[0] = (char *(*)()) F319_5111;
	{long i; for (i = 1; i < 3; i++) R4815[i] = (char *(*)()) F320_5274;}
	R4815[926] = (char *(*)()) F319_5111;
	R4815[1635] = (char *(*)()) F320_5274;
}

char *(*R4816[1636])();
void R4816_init () {
	R4816[0] = (char *(*)()) F319_5112;
	{long i; for (i = 1; i < 3; i++) R4816[i] = (char *(*)()) F320_5275;}
	R4816[926] = (char *(*)()) F319_5112;
	R4816[1635] = (char *(*)()) F320_5275;
}

char *(*R4817[1636])();
void R4817_init () {
	R4817[0] = (char *(*)()) F319_5113;
	{long i; for (i = 1; i < 3; i++) R4817[i] = (char *(*)()) F320_5276;}
	R4817[926] = (char *(*)()) F319_5113;
	R4817[1635] = (char *(*)()) F320_5276;
}

char *(*R4818[1636])();
void R4818_init () {
	R4818[0] = (char *(*)()) F319_5114;
	{long i; for (i = 1; i < 3; i++) R4818[i] = (char *(*)()) F320_5277;}
	R4818[926] = (char *(*)()) F319_5114;
	R4818[1635] = (char *(*)()) F320_5277;
}


#ifdef __cplusplus
}
#endif
