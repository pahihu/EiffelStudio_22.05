#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O2902[1650];
void O2902_init () {
	O2902[0] = 0;
	O2902[1619] = 0;
	O2902[1620] =  + _REFACS_2_;
	O2902[1621] = 0;
	O2902[1622] =  + _REFACS_2_;
	O2902[1646] = 0;
	O2902[1647] =  + _REFACS_2_;
	O2902[1648] = 0;
	O2902[1649] =  + _REFACS_2_;
}

long O2903[1650];
void O2903_init () {
	O2903[0] =  + _REFACS_1_;
	O2903[1619] =  + _REFACS_1_;
	O2903[1620] =  + _REFACS_3_;
	O2903[1621] =  + _REFACS_1_;
	O2903[1622] =  + _REFACS_3_;
	O2903[1646] =  + _REFACS_1_;
	O2903[1647] =  + _REFACS_3_;
	O2903[1648] =  + _REFACS_1_;
	O2903[1649] =  + _REFACS_3_;
}

long O4011[1699];
void O4011_init () {
	O4011[0] = 0;
	{long i; for (i = 1497; i < 1499; i++) O4011[i] = 0;}
	{long i; for (i = 1549; i < 1558; i++) O4011[i] = 0;}
	{long i; for (i = 1558; i < 1562; i++) O4011[i] =  + _REFACS_1_;}
	{long i; for (i = 1562; i < 1568; i++) O4011[i] = 0;}
	O4011[1568] =  + _REFACS_1_;
	O4011[1569] = 0;
	{long i; for (i = 1570; i < 1591; i++) O4011[i] =  + _REFACS_1_;}
	O4011[1591] = 0;
	O4011[1592] =  + _REFACS_5_;
	O4011[1593] =  + _REFACS_4_;
	O4011[1594] = 0;
	O4011[1595] =  + _REFACS_1_;
	O4011[1596] = 0;
	O4011[1597] =  + _REFACS_2_;
	{long i; for (i = 1598; i < 1600; i++) O4011[i] =  + _REFACS_1_;}
	O4011[1600] =  + _REFACS_4_;
	{long i; for (i = 1601; i < 1603; i++) O4011[i] =  + _REFACS_2_;}
	{long i; for (i = 1603; i < 1610; i++) O4011[i] = 0;}
	O4011[1610] =  + _REFACS_2_;
	O4011[1611] =  + _REFACS_6_;
	O4011[1612] =  + _REFACS_2_;
	O4011[1613] =  + _REFACS_4_;
	O4011[1614] =  + _REFACS_1_;
	O4011[1615] =  + _REFACS_3_;
	{long i; for (i = 1616; i < 1625; i++) O4011[i] =  + _REFACS_1_;}
	O4011[1625] = 0;
	O4011[1626] =  + _REFACS_5_;
	O4011[1627] =  + _REFACS_4_;
	O4011[1628] = 0;
	O4011[1629] =  + _REFACS_1_;
	O4011[1630] = 0;
	O4011[1631] =  + _REFACS_2_;
	{long i; for (i = 1632; i < 1634; i++) O4011[i] =  + _REFACS_1_;}
	O4011[1634] =  + _REFACS_4_;
	{long i; for (i = 1635; i < 1638; i++) O4011[i] =  + _REFACS_2_;}
	O4011[1638] =  + _REFACS_6_;
	O4011[1639] =  + _REFACS_2_;
	O4011[1640] =  + _REFACS_4_;
	{long i; for (i = 1641; i < 1648; i++) O4011[i] = 0;}
	O4011[1648] =  + _REFACS_1_;
	O4011[1649] =  + _REFACS_3_;
	{long i; for (i = 1650; i < 1659; i++) O4011[i] =  + _REFACS_1_;}
	{long i; for (i = 1683; i < 1689; i++) O4011[i] =  + _REFACS_2_;}
	O4011[1691] = 0;
	O4011[1693] = 0;
	O4011[1696] = 0;
	O4011[1698] = 0;
}

long O4012[1699];
void O4012_init () {
	O4012[0] =  + _REFACS_1_;
	{long i; for (i = 1497; i < 1499; i++) O4012[i] =  + _REFACS_1_;}
	{long i; for (i = 1549; i < 1558; i++) O4012[i] =  + _REFACS_1_;}
	{long i; for (i = 1558; i < 1562; i++) O4012[i] =  + _REFACS_2_;}
	{long i; for (i = 1562; i < 1568; i++) O4012[i] =  + _REFACS_1_;}
	O4012[1568] =  + _REFACS_2_;
	O4012[1569] =  + _REFACS_1_;
	{long i; for (i = 1570; i < 1591; i++) O4012[i] =  + _REFACS_2_;}
	O4012[1591] =  + _REFACS_1_;
	O4012[1592] =  + _REFACS_6_;
	O4012[1593] =  + _REFACS_5_;
	O4012[1594] =  + _REFACS_1_;
	O4012[1595] =  + _REFACS_2_;
	O4012[1596] =  + _REFACS_1_;
	O4012[1597] =  + _REFACS_3_;
	{long i; for (i = 1598; i < 1600; i++) O4012[i] =  + _REFACS_2_;}
	O4012[1600] =  + _REFACS_5_;
	{long i; for (i = 1601; i < 1603; i++) O4012[i] =  + _REFACS_3_;}
	{long i; for (i = 1603; i < 1610; i++) O4012[i] =  + _REFACS_1_;}
	O4012[1610] =  + _REFACS_3_;
	O4012[1611] =  + _REFACS_7_;
	O4012[1612] =  + _REFACS_3_;
	O4012[1613] =  + _REFACS_5_;
	O4012[1614] =  + _REFACS_2_;
	O4012[1615] =  + _REFACS_4_;
	{long i; for (i = 1616; i < 1625; i++) O4012[i] =  + _REFACS_2_;}
	O4012[1625] =  + _REFACS_1_;
	O4012[1626] =  + _REFACS_6_;
	O4012[1627] =  + _REFACS_5_;
	O4012[1628] =  + _REFACS_1_;
	O4012[1629] =  + _REFACS_2_;
	O4012[1630] =  + _REFACS_1_;
	O4012[1631] =  + _REFACS_3_;
	{long i; for (i = 1632; i < 1634; i++) O4012[i] =  + _REFACS_2_;}
	O4012[1634] =  + _REFACS_5_;
	{long i; for (i = 1635; i < 1638; i++) O4012[i] =  + _REFACS_3_;}
	O4012[1638] =  + _REFACS_7_;
	O4012[1639] =  + _REFACS_3_;
	O4012[1640] =  + _REFACS_5_;
	{long i; for (i = 1641; i < 1648; i++) O4012[i] =  + _REFACS_1_;}
	O4012[1648] =  + _REFACS_2_;
	O4012[1649] =  + _REFACS_4_;
	{long i; for (i = 1650; i < 1659; i++) O4012[i] =  + _REFACS_2_;}
	{long i; for (i = 1683; i < 1689; i++) O4012[i] =  + _REFACS_3_;}
	O4012[1691] =  + _REFACS_1_;
	O4012[1693] =  + _REFACS_1_;
	O4012[1696] =  + _REFACS_1_;
	O4012[1698] =  + _REFACS_1_;
}

long O4029[1684];
void O4029_init () {
	O4029[0] = 0;
	{long i; for (i = 1654; i < 1657; i++) O4029[i] = 0;}
	{long i; for (i = 1657; i < 1659; i++) O4029[i] =  + _REFACS_2_;}
	O4029[1659] = 0;
	{long i; for (i = 1660; i < 1664; i++) O4029[i] =  + _REFACS_4_;}
	{long i; for (i = 1664; i < 1669; i++) O4029[i] = 0;}
	O4029[1669] =  + _REFACS_1_;
	{long i; for (i = 1670; i < 1674; i++) O4029[i] = 0;}
	O4029[1674] =  + _REFACS_1_;
	O4029[1675] = 0;
	{long i; for (i = 1676; i < 1678; i++) O4029[i] =  + _REFACS_2_;}
	{long i; for (i = 1678; i < 1684; i++) O4029[i] =  + _REFACS_4_;}
}

long O4031[1684];
void O4031_init () {
	O4031[0] =  + _REFACS_1_;
	{long i; for (i = 1654; i < 1657; i++) O4031[i] =  + _REFACS_1_;}
	{long i; for (i = 1657; i < 1659; i++) O4031[i] =  + _REFACS_3_;}
	O4031[1659] =  + _REFACS_1_;
	{long i; for (i = 1660; i < 1664; i++) O4031[i] =  + _REFACS_5_;}
	{long i; for (i = 1664; i < 1669; i++) O4031[i] =  + _REFACS_1_;}
	O4031[1669] =  + _REFACS_2_;
	{long i; for (i = 1670; i < 1674; i++) O4031[i] =  + _REFACS_1_;}
	O4031[1674] =  + _REFACS_2_;
	O4031[1675] =  + _REFACS_1_;
	{long i; for (i = 1676; i < 1678; i++) O4031[i] =  + _REFACS_3_;}
	{long i; for (i = 1678; i < 1684; i++) O4031[i] =  + _REFACS_5_;}
}


#ifdef __cplusplus
}
#endif
