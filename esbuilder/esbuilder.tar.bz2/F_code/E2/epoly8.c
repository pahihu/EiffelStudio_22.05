#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O4176[1561];
void O4176_init () {
	O4176[0] =  + _REFACS_1_;
	{long i; for (i = 1548; i < 1550; i++) O4176[i] =  + _REFACS_9_;}
	{long i; for (i = 1550; i < 1552; i++) O4176[i] =  + _REFACS_12_;}
	{long i; for (i = 1557; i < 1559; i++) O4176[i] =  + _REFACS_9_;}
	{long i; for (i = 1559; i < 1561; i++) O4176[i] =  + _REFACS_12_;}
}

long O4178[1561];
void O4178_init () {
	O4178[0] =  + _REFACS_2_;
	{long i; for (i = 1548; i < 1550; i++) O4178[i] =  + _REFACS_10_;}
	{long i; for (i = 1550; i < 1552; i++) O4178[i] =  + _REFACS_13_;}
	{long i; for (i = 1557; i < 1559; i++) O4178[i] =  + _REFACS_10_;}
	{long i; for (i = 1559; i < 1561; i++) O4178[i] =  + _REFACS_13_;}
}

long O4180[1561];
void O4180_init () {
	O4180[0] =  + _REFACS_3_;
	{long i; for (i = 1548; i < 1550; i++) O4180[i] =  + _REFACS_11_;}
	{long i; for (i = 1550; i < 1552; i++) O4180[i] =  + _REFACS_14_;}
	{long i; for (i = 1557; i < 1559; i++) O4180[i] =  + _REFACS_11_;}
	{long i; for (i = 1559; i < 1561; i++) O4180[i] =  + _REFACS_14_;}
}

long O4182[1650];
void O4182_init () {
	O4182[0] = 0;
	{long i; for (i = 1640; i < 1643; i++) O4182[i] =  + _REFACS_7_;}
	O4182[1643] =  + _REFACS_8_;
	{long i; for (i = 1644; i < 1648; i++) O4182[i] =  + _REFACS_7_;}
	O4182[1648] =  + _REFACS_8_;
	O4182[1649] =  + _REFACS_7_;
}

long O4456[1953];
void O4456_init () {
	O4456[0] = + _R64OFF_0_0_0_1_0_0_0_0_;
	{long i; for (i = 1946; i < 1948; i++) O4456[i] = + _R64OFF_0_0_0_1_0_0_0_0_;}
	O4456[1950] = + _R64OFF_0_0_0_2_0_0_0_0_;
	O4456[1951] = + _R64OFF_5_1_0_8_0_0_0_0_;
	O4456[1952] = + _R64OFF_2_0_0_2_0_0_0_0_;
}

long O4457[1953];
void O4457_init () {
	O4457[0] = + _LNGOFF_0_0_0_0_;
	{long i; for (i = 1946; i < 1948; i++) O4457[i] = + _LNGOFF_0_0_0_0_;}
	O4457[1950] = + _LNGOFF_0_0_0_0_;
	O4457[1951] = + _LNGOFF_5_1_0_0_;
	O4457[1952] = + _LNGOFF_2_0_0_0_;
}


#ifdef __cplusplus
}
#endif
