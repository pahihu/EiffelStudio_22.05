#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O4033[1684];
void O4033_init () {
	O4033[0] =  + _REFACS_2_;
	{long i; for (i = 1654; i < 1657; i++) O4033[i] =  + _REFACS_2_;}
	{long i; for (i = 1657; i < 1659; i++) O4033[i] =  + _REFACS_4_;}
	O4033[1659] =  + _REFACS_2_;
	{long i; for (i = 1660; i < 1664; i++) O4033[i] =  + _REFACS_6_;}
	{long i; for (i = 1664; i < 1669; i++) O4033[i] =  + _REFACS_2_;}
	O4033[1669] =  + _REFACS_3_;
	{long i; for (i = 1670; i < 1674; i++) O4033[i] =  + _REFACS_2_;}
	O4033[1674] =  + _REFACS_3_;
	O4033[1675] =  + _REFACS_2_;
	{long i; for (i = 1676; i < 1678; i++) O4033[i] =  + _REFACS_4_;}
	{long i; for (i = 1678; i < 1684; i++) O4033[i] =  + _REFACS_6_;}
}

static EIF_TYPE_INDEX Y4047_pgtype0[] = {1146,1570,0xFFFF};
static EIF_TYPE_INDEX Y4047_pgtype1[] = {1146,1570,0xFFFF};
static EIF_TYPE_INDEX Y4047_pgtype2[] = {1146,1571,0xFFFF};
static EIF_TYPE_INDEX Y4047_pgtype3[] = {1146,1570,0xFFFF};
static EIF_TYPE_INDEX Y4047_pgtype4[] = {1146,1570,0xFFFF};
static EIF_TYPE_INDEX Y4047_pgtype5[] = {1146,1570,0xFFFF};
static EIF_TYPE_INDEX Y4047_pgtype6[] = {1146,1570,0xFFFF};
static EIF_TYPE_INDEX Y4047_pgtype7[] = {1146,1570,0xFFFF};
static EIF_TYPE_INDEX Y4047_pgtype8[] = {1146,1570,0xFFFF};
static EIF_TYPE_INDEX Y4047_pgtype9[] = {1146,1570,0xFFFF};
static EIF_TYPE_INDEX Y4047_pgtype10[] = {1146,1570,0xFFFF};
static EIF_TYPE_INDEX Y4047_pgtype11[] = {1146,1570,0xFFFF};
static EIF_TYPE_INDEX Y4047_pgtype12[] = {1146,1570,0xFFFF};
static EIF_TYPE_INDEX Y4047_pgtype13[] = {1146,1570,0xFFFF};
static EIF_TYPE_INDEX Y4047_pgtype14[] = {1146,1570,0xFFFF};
static EIF_TYPE_INDEX Y4047_pgtype15[] = {1146,1570,0xFFFF};
static EIF_TYPE_INDEX Y4047_pgtype16[] = {1146,1571,0xFFFF};
static EIF_TYPE_INDEX Y4047_pgtype17[] = {1146,1571,0xFFFF};
static EIF_TYPE_INDEX Y4047_pgtype18[] = {1146,1571,0xFFFF};
static EIF_TYPE_INDEX Y4047_pgtype19[] = {1146,1571,0xFFFF};
static EIF_TYPE_INDEX Y4047_pgtype20[] = {1146,1571,0xFFFF};
static EIF_TYPE_INDEX Y4047_pgtype21[] = {1146,1571,0xFFFF};
static EIF_TYPE_INDEX Y4047_pgtype22[] = {1146,1570,0xFFFF};
static EIF_TYPE_INDEX Y4047_pgtype23[] = {1146,1571,0xFFFF};
static EIF_TYPE_INDEX Y4047_pgtype24[] = {1146,1570,0xFFFF};
static EIF_TYPE_INDEX Y4047_pgtype25[] = {1146,1570,0xFFFF};
static EIF_TYPE_INDEX Y4047_pgtype26[] = {1146,1570,0xFFFF};
static EIF_TYPE_INDEX Y4047_pgtype27[] = {1146,1570,0xFFFF};
static EIF_TYPE_INDEX Y4047_pgtype28[] = {1146,1570,0xFFFF};
EIF_TYPE_INDEX *Y4047_gen_type [2036];
EIF_TYPE_INDEX Y4047 [2036];
void Y4047_init (void)
{
	egc_routines_types [4047] = Y4047;
	egc_routines_gen_types [4047] = Y4047_gen_type;
	egc_routines_offset [4047] = 230;
	Y4047_gen_type [0] = Y4047_pgtype0;
	Y4047_gen_type [1] = Y4047_pgtype1;
	Y4047_gen_type [2] = Y4047_pgtype2;
	Y4047_gen_type [3] = Y4047_pgtype3;
	Y4047_gen_type [4] = Y4047_pgtype4;
	Y4047_gen_type [5] = Y4047_pgtype5;
	Y4047_gen_type [6] = Y4047_pgtype6;
	Y4047_gen_type [7] = Y4047_pgtype7;
	Y4047_gen_type [8] = Y4047_pgtype8;
	Y4047_gen_type [9] = Y4047_pgtype9;
	Y4047_gen_type [381] = Y4047_pgtype10;
	Y4047_gen_type [382] = Y4047_pgtype11;
	Y4047_gen_type [402] = Y4047_pgtype12;
	Y4047_gen_type [1733] = Y4047_pgtype13;
	Y4047_gen_type [1734] = Y4047_pgtype14;
	Y4047_gen_type [1735] = Y4047_pgtype15;
	Y4047_gen_type [1744] = Y4047_pgtype16;
	Y4047_gen_type [1745] = Y4047_pgtype17;
	Y4047_gen_type [1746] = Y4047_pgtype18;
	Y4047_gen_type [1747] = Y4047_pgtype19;
	Y4047_gen_type [1748] = Y4047_pgtype20;
	Y4047_gen_type [1749] = Y4047_pgtype21;
	Y4047_gen_type [1947] = Y4047_pgtype22;
	Y4047_gen_type [1960] = Y4047_pgtype23;
	Y4047_gen_type [1963] = Y4047_pgtype24;
	Y4047_gen_type [1965] = Y4047_pgtype25;
	Y4047_gen_type [1966] = Y4047_pgtype26;
	Y4047_gen_type [2034] = Y4047_pgtype27;
	Y4047_gen_type [2035] = Y4047_pgtype28;
	{long i; for (i = 0; i < 10; i++) Y4047[i] = 1146;};
	{long i; for (i = 381; i < 383; i++) Y4047[i] = 1146;};
	Y4047[402] = 1146;
	{long i; for (i = 1733; i < 1736; i++) Y4047[i] = 1146;};
	{long i; for (i = 1744; i < 1750; i++) Y4047[i] = 1146;};
	Y4047[1947] = 1146;
	Y4047[1960] = 1146;
	Y4047[1963] = 1146;
	{long i; for (i = 1965; i < 1967; i++) Y4047[i] = 1146;};
	{long i; for (i = 2034; i < 2036; i++) Y4047[i] = 1146;};
}

long O4095[1678];
void O4095_init () {
	O4095[0] = 0;
	{long i; for (i = 1526; i < 1528; i++) O4095[i] = 0;}
	{long i; for (i = 1528; i < 1530; i++) O4095[i] =  + _REFACS_2_;}
	{long i; for (i = 1530; i < 1537; i++) O4095[i] =  + _REFACS_3_;}
	{long i; for (i = 1537; i < 1541; i++) O4095[i] =  + _REFACS_4_;}
	{long i; for (i = 1541; i < 1547; i++) O4095[i] =  + _REFACS_3_;}
	O4095[1547] =  + _REFACS_4_;
	O4095[1548] =  + _REFACS_3_;
	{long i; for (i = 1549; i < 1570; i++) O4095[i] =  + _REFACS_4_;}
	O4095[1570] =  + _REFACS_2_;
	O4095[1571] =  + _REFACS_7_;
	O4095[1572] =  + _REFACS_6_;
	O4095[1573] =  + _REFACS_2_;
	O4095[1574] =  + _REFACS_3_;
	O4095[1575] =  + _REFACS_2_;
	O4095[1576] =  + _REFACS_4_;
	{long i; for (i = 1577; i < 1579; i++) O4095[i] =  + _REFACS_3_;}
	O4095[1579] =  + _REFACS_6_;
	{long i; for (i = 1580; i < 1582; i++) O4095[i] =  + _REFACS_4_;}
	{long i; for (i = 1582; i < 1585; i++) O4095[i] =  + _REFACS_2_;}
	{long i; for (i = 1585; i < 1589; i++) O4095[i] =  + _REFACS_3_;}
	O4095[1589] =  + _REFACS_4_;
	O4095[1590] =  + _REFACS_8_;
	O4095[1591] =  + _REFACS_4_;
	O4095[1592] =  + _REFACS_6_;
	O4095[1593] =  + _REFACS_3_;
	O4095[1594] =  + _REFACS_5_;
	{long i; for (i = 1595; i < 1604; i++) O4095[i] =  + _REFACS_3_;}
	O4095[1604] =  + _REFACS_2_;
	O4095[1605] =  + _REFACS_7_;
	O4095[1606] =  + _REFACS_6_;
	O4095[1607] =  + _REFACS_2_;
	O4095[1608] =  + _REFACS_3_;
	O4095[1609] =  + _REFACS_2_;
	O4095[1610] =  + _REFACS_4_;
	{long i; for (i = 1611; i < 1613; i++) O4095[i] =  + _REFACS_3_;}
	O4095[1613] =  + _REFACS_6_;
	{long i; for (i = 1614; i < 1617; i++) O4095[i] =  + _REFACS_4_;}
	O4095[1617] =  + _REFACS_8_;
	O4095[1618] =  + _REFACS_4_;
	O4095[1619] =  + _REFACS_6_;
	{long i; for (i = 1620; i < 1623; i++) O4095[i] =  + _REFACS_2_;}
	{long i; for (i = 1623; i < 1628; i++) O4095[i] =  + _REFACS_3_;}
	O4095[1628] =  + _REFACS_5_;
	{long i; for (i = 1629; i < 1641; i++) O4095[i] =  + _REFACS_3_;}
	{long i; for (i = 1641; i < 1643; i++) O4095[i] =  + _REFACS_5_;}
	O4095[1643] =  + _REFACS_3_;
	{long i; for (i = 1644; i < 1648; i++) O4095[i] =  + _REFACS_7_;}
	{long i; for (i = 1648; i < 1653; i++) O4095[i] =  + _REFACS_3_;}
	O4095[1653] =  + _REFACS_4_;
	{long i; for (i = 1654; i < 1658; i++) O4095[i] =  + _REFACS_3_;}
	O4095[1658] =  + _REFACS_4_;
	O4095[1659] =  + _REFACS_3_;
	{long i; for (i = 1660; i < 1662; i++) O4095[i] =  + _REFACS_5_;}
	{long i; for (i = 1662; i < 1668; i++) O4095[i] =  + _REFACS_7_;}
	O4095[1670] =  + _REFACS_2_;
	O4095[1672] =  + _REFACS_2_;
	O4095[1675] =  + _REFACS_2_;
	O4095[1677] =  + _REFACS_2_;
}

long O4097[1678];
void O4097_init () {
	O4097[0] =  + _REFACS_1_;
	{long i; for (i = 1526; i < 1528; i++) O4097[i] =  + _REFACS_1_;}
	{long i; for (i = 1528; i < 1530; i++) O4097[i] =  + _REFACS_3_;}
	{long i; for (i = 1530; i < 1537; i++) O4097[i] =  + _REFACS_4_;}
	{long i; for (i = 1537; i < 1541; i++) O4097[i] =  + _REFACS_5_;}
	{long i; for (i = 1541; i < 1547; i++) O4097[i] =  + _REFACS_4_;}
	O4097[1547] =  + _REFACS_5_;
	O4097[1548] =  + _REFACS_4_;
	{long i; for (i = 1549; i < 1570; i++) O4097[i] =  + _REFACS_5_;}
	O4097[1570] =  + _REFACS_3_;
	O4097[1571] =  + _REFACS_8_;
	O4097[1572] =  + _REFACS_7_;
	O4097[1573] =  + _REFACS_3_;
	O4097[1574] =  + _REFACS_4_;
	O4097[1575] =  + _REFACS_3_;
	O4097[1576] =  + _REFACS_5_;
	{long i; for (i = 1577; i < 1579; i++) O4097[i] =  + _REFACS_4_;}
	O4097[1579] =  + _REFACS_7_;
	{long i; for (i = 1580; i < 1582; i++) O4097[i] =  + _REFACS_5_;}
	{long i; for (i = 1582; i < 1585; i++) O4097[i] =  + _REFACS_3_;}
	{long i; for (i = 1585; i < 1589; i++) O4097[i] =  + _REFACS_4_;}
	O4097[1589] =  + _REFACS_5_;
	O4097[1590] =  + _REFACS_9_;
	O4097[1591] =  + _REFACS_5_;
	O4097[1592] =  + _REFACS_7_;
	O4097[1593] =  + _REFACS_4_;
	O4097[1594] =  + _REFACS_6_;
	{long i; for (i = 1595; i < 1604; i++) O4097[i] =  + _REFACS_4_;}
	O4097[1604] =  + _REFACS_3_;
	O4097[1605] =  + _REFACS_8_;
	O4097[1606] =  + _REFACS_7_;
	O4097[1607] =  + _REFACS_3_;
	O4097[1608] =  + _REFACS_4_;
	O4097[1609] =  + _REFACS_3_;
	O4097[1610] =  + _REFACS_5_;
	{long i; for (i = 1611; i < 1613; i++) O4097[i] =  + _REFACS_4_;}
	O4097[1613] =  + _REFACS_7_;
	{long i; for (i = 1614; i < 1617; i++) O4097[i] =  + _REFACS_5_;}
	O4097[1617] =  + _REFACS_9_;
	O4097[1618] =  + _REFACS_5_;
	O4097[1619] =  + _REFACS_7_;
	{long i; for (i = 1620; i < 1623; i++) O4097[i] =  + _REFACS_3_;}
	{long i; for (i = 1623; i < 1628; i++) O4097[i] =  + _REFACS_4_;}
	O4097[1628] =  + _REFACS_6_;
	{long i; for (i = 1629; i < 1641; i++) O4097[i] =  + _REFACS_4_;}
	{long i; for (i = 1641; i < 1643; i++) O4097[i] =  + _REFACS_6_;}
	O4097[1643] =  + _REFACS_4_;
	{long i; for (i = 1644; i < 1648; i++) O4097[i] =  + _REFACS_8_;}
	{long i; for (i = 1648; i < 1653; i++) O4097[i] =  + _REFACS_4_;}
	O4097[1653] =  + _REFACS_5_;
	{long i; for (i = 1654; i < 1658; i++) O4097[i] =  + _REFACS_4_;}
	O4097[1658] =  + _REFACS_5_;
	O4097[1659] =  + _REFACS_4_;
	{long i; for (i = 1660; i < 1662; i++) O4097[i] =  + _REFACS_6_;}
	{long i; for (i = 1662; i < 1668; i++) O4097[i] =  + _REFACS_8_;}
	O4097[1670] =  + _REFACS_3_;
	O4097[1672] =  + _REFACS_3_;
	O4097[1675] =  + _REFACS_3_;
	O4097[1677] =  + _REFACS_3_;
}

long O4101[1678];
void O4101_init () {
	O4101[0] =  + _REFACS_3_;
	{long i; for (i = 1526; i < 1528; i++) O4101[i] =  + _REFACS_3_;}
	{long i; for (i = 1528; i < 1530; i++) O4101[i] =  + _REFACS_5_;}
	{long i; for (i = 1530; i < 1537; i++) O4101[i] =  + _REFACS_6_;}
	{long i; for (i = 1537; i < 1541; i++) O4101[i] =  + _REFACS_7_;}
	{long i; for (i = 1541; i < 1547; i++) O4101[i] =  + _REFACS_6_;}
	O4101[1547] =  + _REFACS_7_;
	O4101[1548] =  + _REFACS_6_;
	{long i; for (i = 1549; i < 1570; i++) O4101[i] =  + _REFACS_7_;}
	O4101[1570] =  + _REFACS_5_;
	O4101[1571] =  + _REFACS_10_;
	O4101[1572] =  + _REFACS_9_;
	O4101[1573] =  + _REFACS_5_;
	O4101[1574] =  + _REFACS_6_;
	O4101[1575] =  + _REFACS_5_;
	O4101[1576] =  + _REFACS_7_;
	{long i; for (i = 1577; i < 1579; i++) O4101[i] =  + _REFACS_6_;}
	O4101[1579] =  + _REFACS_9_;
	{long i; for (i = 1580; i < 1582; i++) O4101[i] =  + _REFACS_7_;}
	{long i; for (i = 1582; i < 1585; i++) O4101[i] =  + _REFACS_5_;}
	{long i; for (i = 1585; i < 1589; i++) O4101[i] =  + _REFACS_6_;}
	O4101[1589] =  + _REFACS_7_;
	O4101[1590] =  + _REFACS_11_;
	O4101[1591] =  + _REFACS_7_;
	O4101[1592] =  + _REFACS_9_;
	O4101[1593] =  + _REFACS_6_;
	O4101[1594] =  + _REFACS_8_;
	{long i; for (i = 1595; i < 1604; i++) O4101[i] =  + _REFACS_6_;}
	O4101[1604] =  + _REFACS_5_;
	O4101[1605] =  + _REFACS_10_;
	O4101[1606] =  + _REFACS_9_;
	O4101[1607] =  + _REFACS_5_;
	O4101[1608] =  + _REFACS_6_;
	O4101[1609] =  + _REFACS_5_;
	O4101[1610] =  + _REFACS_7_;
	{long i; for (i = 1611; i < 1613; i++) O4101[i] =  + _REFACS_6_;}
	O4101[1613] =  + _REFACS_9_;
	{long i; for (i = 1614; i < 1617; i++) O4101[i] =  + _REFACS_7_;}
	O4101[1617] =  + _REFACS_11_;
	O4101[1618] =  + _REFACS_7_;
	O4101[1619] =  + _REFACS_9_;
	{long i; for (i = 1620; i < 1623; i++) O4101[i] =  + _REFACS_5_;}
	{long i; for (i = 1623; i < 1628; i++) O4101[i] =  + _REFACS_6_;}
	O4101[1628] =  + _REFACS_8_;
	{long i; for (i = 1629; i < 1641; i++) O4101[i] =  + _REFACS_6_;}
	{long i; for (i = 1641; i < 1643; i++) O4101[i] =  + _REFACS_8_;}
	O4101[1643] =  + _REFACS_6_;
	{long i; for (i = 1644; i < 1648; i++) O4101[i] =  + _REFACS_10_;}
	{long i; for (i = 1648; i < 1653; i++) O4101[i] =  + _REFACS_6_;}
	O4101[1653] =  + _REFACS_7_;
	{long i; for (i = 1654; i < 1658; i++) O4101[i] =  + _REFACS_6_;}
	O4101[1658] =  + _REFACS_7_;
	O4101[1659] =  + _REFACS_6_;
	{long i; for (i = 1660; i < 1662; i++) O4101[i] =  + _REFACS_8_;}
	{long i; for (i = 1662; i < 1668; i++) O4101[i] =  + _REFACS_10_;}
	O4101[1670] =  + _REFACS_5_;
	O4101[1672] =  + _REFACS_5_;
	O4101[1675] =  + _REFACS_5_;
	O4101[1677] =  + _REFACS_5_;
}

long O4174[1561];
void O4174_init () {
	O4174[0] = 0;
	{long i; for (i = 1548; i < 1550; i++) O4174[i] =  + _REFACS_8_;}
	{long i; for (i = 1550; i < 1552; i++) O4174[i] =  + _REFACS_11_;}
	{long i; for (i = 1557; i < 1559; i++) O4174[i] =  + _REFACS_8_;}
	{long i; for (i = 1559; i < 1561; i++) O4174[i] =  + _REFACS_11_;}
}


#ifdef __cplusplus
}
#endif
