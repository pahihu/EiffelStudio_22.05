#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O2501[1680];
void O2501_init () {
	O2501[0] = 0;
	{long i; for (i = 1628; i < 1630; i++) O2501[i] = 0;}
	O2501[1630] =  + _REFACS_3_;
	{long i; for (i = 1631; i < 1633; i++) O2501[i] =  + _REFACS_1_;}
	O2501[1641] =  + _REFACS_1_;
	O2501[1645] =  + _REFACS_2_;
	{long i; for (i = 1662; i < 1664; i++) O2501[i] = 0;}
	O2501[1664] =  + _REFACS_3_;
	{long i; for (i = 1665; i < 1667; i++) O2501[i] =  + _REFACS_1_;}
	O2501[1668] =  + _REFACS_1_;
	O2501[1679] =  + _REFACS_2_;
}

long O2836[1989];
void O2836_init () {
	O2836[0] = + _LNGOFF_1_4_0_0_;
	O2836[1988] = + _LNGOFF_1_8_0_0_;
}

long O2838[1989];
void O2838_init () {
	O2838[0] = + _LNGOFF_1_4_0_1_;
	O2838[1988] = + _LNGOFF_1_8_0_1_;
}

long O2839[1989];
void O2839_init () {
	O2839[0] = + _CHROFF_1_2_;
	O2839[1988] = + _CHROFF_1_3_;
}

long O2840[1989];
void O2840_init () {
	O2840[0] = + _LNGOFF_1_4_0_2_;
	O2840[1988] = + _LNGOFF_1_8_0_2_;
}

long O2842[1989];
void O2842_init () {
	O2842[0] = + _CHROFF_1_3_;
	O2842[1988] = + _CHROFF_1_4_;
}


#ifdef __cplusplus
}
#endif
