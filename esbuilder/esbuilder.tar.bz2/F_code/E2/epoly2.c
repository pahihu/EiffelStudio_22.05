#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

EIF_TYPE_INDEX *Y1754_gen_type [2];
EIF_TYPE_INDEX Y1754 [2];
void Y1754_init (void)
{
	egc_routines_types [1754] = Y1754;
	egc_routines_gen_types [1754] = Y1754_gen_type;
	egc_routines_offset [1754] = 124;
	Y1754[0] = 280;
	Y1754[1] = 281;
}

long O1923[4];
void O1923_init () {
	O1923[0] = 0;
	O1923[3] =  + _REFACS_3_;
}

long O1924[4];
void O1924_init () {
	O1924[0] =  + _REFACS_1_;
	O1924[3] =  + _REFACS_4_;
}

long O1925[4];
void O1925_init () {
	O1925[0] =  + _REFACS_2_;
	O1925[3] =  + _REFACS_5_;
}

long O1926[4];
void O1926_init () {
	O1926[0] =  + _REFACS_3_;
	O1926[3] =  + _REFACS_6_;
}

long O1927[4];
void O1927_init () {
	O1927[0] =  + _REFACS_4_;
	O1927[3] =  + _REFACS_7_;
}

long O1928[4];
void O1928_init () {
	O1928[0] =  + _REFACS_5_;
	O1928[3] =  + _REFACS_8_;
}

long O1929[4];
void O1929_init () {
	O1929[0] =  + _REFACS_6_;
	O1929[3] =  + _REFACS_9_;
}

long O1930[4];
void O1930_init () {
	O1930[0] =  + _REFACS_7_;
	O1930[3] =  + _REFACS_10_;
}

long O1931[4];
void O1931_init () {
	O1931[0] =  + _REFACS_8_;
	O1931[3] =  + _REFACS_11_;
}

long O1932[4];
void O1932_init () {
	O1932[0] =  + _REFACS_9_;
	O1932[3] =  + _REFACS_12_;
}

long O1933[4];
void O1933_init () {
	O1933[0] =  + _REFACS_10_;
	O1933[3] =  + _REFACS_13_;
}

long O1934[4];
void O1934_init () {
	O1934[0] =  + _REFACS_11_;
	O1934[3] =  + _REFACS_14_;
}

long O1935[4];
void O1935_init () {
	O1935[0] =  + _REFACS_12_;
	O1935[3] =  + _REFACS_15_;
}

long O1963[3];
void O1963_init () {
	O1963[0] = 0;
	O1963[2] =  + _REFACS_16_;
}

long O1964[3];
void O1964_init () {
	O1964[0] = + _LNGOFF_12_0_0_0_;
	O1964[2] = + _LNGOFF_35_0_0_0_;
}

long O1968[3];
void O1968_init () {
	O1968[0] =  + _REFACS_1_;
	O1968[2] =  + _REFACS_17_;
}

long O1969[3];
void O1969_init () {
	O1969[0] = + _LNGOFF_12_0_0_1_;
	O1969[2] = + _LNGOFF_35_0_0_1_;
}

long O1970[3];
void O1970_init () {
	O1970[0] =  + _REFACS_2_;
	O1970[2] =  + _REFACS_18_;
}

long O1971[3];
void O1971_init () {
	O1971[0] =  + _REFACS_3_;
	O1971[2] =  + _REFACS_19_;
}

long O1972[3];
void O1972_init () {
	O1972[0] =  + _REFACS_4_;
	O1972[2] =  + _REFACS_20_;
}

long O1973[3];
void O1973_init () {
	O1973[0] =  + _REFACS_5_;
	O1973[2] =  + _REFACS_21_;
}

long O1974[3];
void O1974_init () {
	O1974[0] =  + _REFACS_6_;
	O1974[2] =  + _REFACS_22_;
}

long O1975[3];
void O1975_init () {
	O1975[0] =  + _REFACS_7_;
	O1975[2] =  + _REFACS_23_;
}

long O1976[3];
void O1976_init () {
	O1976[0] = + _LNGOFF_12_0_0_2_;
	O1976[2] = + _LNGOFF_35_0_0_2_;
}

long O1980[3];
void O1980_init () {
	O1980[0] =  + _REFACS_8_;
	O1980[2] =  + _REFACS_24_;
}

long O1981[3];
void O1981_init () {
	O1981[0] = + _LNGOFF_12_0_0_3_;
	O1981[2] = + _LNGOFF_35_0_0_3_;
}

long O1982[3];
void O1982_init () {
	O1982[0] =  + _REFACS_9_;
	O1982[2] =  + _REFACS_25_;
}

long O1983[3];
void O1983_init () {
	O1983[0] =  + _REFACS_10_;
	O1983[2] =  + _REFACS_26_;
}

long O1984[3];
void O1984_init () {
	O1984[0] =  + _REFACS_11_;
	O1984[2] =  + _REFACS_27_;
}

long O2011[2];
void O2011_init () {
	O2011[0] = 0;
	O2011[1] =  + _REFACS_28_;
}

long O2012[2];
void O2012_init () {
	O2012[0] = + _LNGOFF_6_0_0_0_;
	O2012[1] = + _LNGOFF_35_0_0_4_;
}

long O2013[2];
void O2013_init () {
	O2013[0] =  + _REFACS_1_;
	O2013[1] =  + _REFACS_29_;
}

long O2014[2];
void O2014_init () {
	O2014[0] =  + _REFACS_2_;
	O2014[1] =  + _REFACS_30_;
}

long O2015[2];
void O2015_init () {
	O2015[0] =  + _REFACS_3_;
	O2015[1] =  + _REFACS_31_;
}

long O2016[2];
void O2016_init () {
	O2016[0] =  + _REFACS_4_;
	O2016[1] =  + _REFACS_32_;
}

long O2017[2];
void O2017_init () {
	O2017[0] =  + _REFACS_5_;
	O2017[1] =  + _REFACS_33_;
}

long O2081[2330];
void O2081_init () {
	{long i; for (i = 0; i < 3; i++) O2081[i] = + _LNGOFF_1_0_0_0_;}
	O2081[2171] = + _LNGOFF_2_0_0_0_;
	{long i; for (i = 2189; i < 2193; i++) O2081[i] = + _LNGOFF_3_1_0_0_;}
	O2081[2205] = + _LNGOFF_2_0_0_0_;
	O2081[2215] = + _LNGOFF_4_0_0_0_;
	O2081[2261] = + _LNGOFF_2_0_0_0_;
	O2081[2267] = + _LNGOFF_2_3_0_0_;
	O2081[2272] = + _LNGOFF_5_0_0_0_;
	{long i; for (i = 2283; i < 2285; i++) O2081[i] = + _LNGOFF_4_1_0_0_;}
	O2081[2285] = + _LNGOFF_5_1_0_0_;
	{long i; for (i = 2286; i < 2288; i++) O2081[i] = + _LNGOFF_2_0_0_0_;}
	O2081[2288] = + _LNGOFF_3_0_0_0_;
	{long i; for (i = 2289; i < 2292; i++) O2081[i] = + _LNGOFF_2_0_0_0_;}
	O2081[2295] = + _LNGOFF_4_1_0_0_;
	{long i; for (i = 2305; i < 2310; i++) O2081[i] = + _LNGOFF_3_0_0_0_;}
	O2081[2310] = + _LNGOFF_4_0_0_0_;
	{long i; for (i = 2311; i < 2330; i++) O2081[i] = + _LNGOFF_3_0_0_0_;}
}

long O2214[4];
void O2214_init () {
	O2214[0] = 0;
	O2214[1] = + _CHROFF_0_0_;
	O2214[2] = 0;
	O2214[3] = + _CHROFF_1_0_;
}

long O2279[2098];
void O2279_init () {
	O2279[0] = + _CHROFF_1_0_;
	O2279[1] = + _CHROFF_2_0_;
	O2279[62] = + _CHROFF_5_0_;
	O2279[63] = + _CHROFF_6_0_;
	O2279[64] = + _CHROFF_7_0_;
	{long i; for (i = 65; i < 72; i++) O2279[i] = + _CHROFF_14_0_;}
	{long i; for (i = 443; i < 445; i++) O2279[i] = + _CHROFF_14_0_;}
	O2279[464] = + _CHROFF_14_0_;
	O2279[1795] = + _CHROFF_15_0_;
	{long i; for (i = 1796; i < 1798; i++) O2279[i] = + _CHROFF_14_0_;}
	{long i; for (i = 1806; i < 1812; i++) O2279[i] = + _CHROFF_7_0_;}
	O2279[2009] = + _CHROFF_14_0_;
	O2279[2022] = + _CHROFF_7_0_;
	O2279[2025] = + _CHROFF_14_0_;
	{long i; for (i = 2027; i < 2029; i++) O2279[i] = + _CHROFF_15_0_;}
	O2279[2096] = + _CHROFF_14_0_;
	O2279[2097] = + _CHROFF_15_0_;
}

static EIF_TYPE_INDEX Y2284_pgtype0[] = {1146,1679,0xFFFF};
static EIF_TYPE_INDEX Y2284_pgtype1[] = {1146,1679,0xFFFF};
static EIF_TYPE_INDEX Y2284_pgtype2[] = {1146,1680,0xFFFF};
static EIF_TYPE_INDEX Y2284_pgtype3[] = {1146,1679,0xFFFF};
static EIF_TYPE_INDEX Y2284_pgtype4[] = {1146,1679,0xFFFF};
static EIF_TYPE_INDEX Y2284_pgtype5[] = {1146,1679,0xFFFF};
static EIF_TYPE_INDEX Y2284_pgtype6[] = {1146,1679,0xFFFF};
static EIF_TYPE_INDEX Y2284_pgtype7[] = {1146,1679,0xFFFF};
static EIF_TYPE_INDEX Y2284_pgtype8[] = {1146,1679,0xFFFF};
static EIF_TYPE_INDEX Y2284_pgtype9[] = {1146,1679,0xFFFF};
static EIF_TYPE_INDEX Y2284_pgtype10[] = {1146,1679,0xFFFF};
static EIF_TYPE_INDEX Y2284_pgtype11[] = {1146,1679,0xFFFF};
static EIF_TYPE_INDEX Y2284_pgtype12[] = {1146,1679,0xFFFF};
static EIF_TYPE_INDEX Y2284_pgtype13[] = {1146,1679,0xFFFF};
static EIF_TYPE_INDEX Y2284_pgtype14[] = {1146,1679,0xFFFF};
static EIF_TYPE_INDEX Y2284_pgtype15[] = {1146,1679,0xFFFF};
static EIF_TYPE_INDEX Y2284_pgtype16[] = {1146,1680,0xFFFF};
static EIF_TYPE_INDEX Y2284_pgtype17[] = {1146,1680,0xFFFF};
static EIF_TYPE_INDEX Y2284_pgtype18[] = {1146,1680,0xFFFF};
static EIF_TYPE_INDEX Y2284_pgtype19[] = {1146,1680,0xFFFF};
static EIF_TYPE_INDEX Y2284_pgtype20[] = {1146,1680,0xFFFF};
static EIF_TYPE_INDEX Y2284_pgtype21[] = {1146,1680,0xFFFF};
static EIF_TYPE_INDEX Y2284_pgtype22[] = {1146,1679,0xFFFF};
static EIF_TYPE_INDEX Y2284_pgtype23[] = {1146,1680,0xFFFF};
static EIF_TYPE_INDEX Y2284_pgtype24[] = {1146,1679,0xFFFF};
static EIF_TYPE_INDEX Y2284_pgtype25[] = {1146,1679,0xFFFF};
static EIF_TYPE_INDEX Y2284_pgtype26[] = {1146,1679,0xFFFF};
static EIF_TYPE_INDEX Y2284_pgtype27[] = {1146,1679,0xFFFF};
static EIF_TYPE_INDEX Y2284_pgtype28[] = {1146,1679,0xFFFF};
EIF_TYPE_INDEX *Y2284_gen_type [2097];
EIF_TYPE_INDEX Y2284 [2097];
void Y2284_init (void)
{
	egc_routines_types [2284] = Y2284;
	egc_routines_gen_types [2284] = Y2284_gen_type;
	egc_routines_offset [2284] = 169;
	Y2284_gen_type [0] = Y2284_pgtype0;
	Y2284_gen_type [62] = Y2284_pgtype1;
	Y2284_gen_type [63] = Y2284_pgtype2;
	Y2284_gen_type [64] = Y2284_pgtype3;
	Y2284_gen_type [65] = Y2284_pgtype4;
	Y2284_gen_type [66] = Y2284_pgtype5;
	Y2284_gen_type [67] = Y2284_pgtype6;
	Y2284_gen_type [68] = Y2284_pgtype7;
	Y2284_gen_type [69] = Y2284_pgtype8;
	Y2284_gen_type [70] = Y2284_pgtype9;
	Y2284_gen_type [442] = Y2284_pgtype10;
	Y2284_gen_type [443] = Y2284_pgtype11;
	Y2284_gen_type [463] = Y2284_pgtype12;
	Y2284_gen_type [1794] = Y2284_pgtype13;
	Y2284_gen_type [1795] = Y2284_pgtype14;
	Y2284_gen_type [1796] = Y2284_pgtype15;
	Y2284_gen_type [1805] = Y2284_pgtype16;
	Y2284_gen_type [1806] = Y2284_pgtype17;
	Y2284_gen_type [1807] = Y2284_pgtype18;
	Y2284_gen_type [1808] = Y2284_pgtype19;
	Y2284_gen_type [1809] = Y2284_pgtype20;
	Y2284_gen_type [1810] = Y2284_pgtype21;
	Y2284_gen_type [2008] = Y2284_pgtype22;
	Y2284_gen_type [2021] = Y2284_pgtype23;
	Y2284_gen_type [2024] = Y2284_pgtype24;
	Y2284_gen_type [2026] = Y2284_pgtype25;
	Y2284_gen_type [2027] = Y2284_pgtype26;
	Y2284_gen_type [2095] = Y2284_pgtype27;
	Y2284_gen_type [2096] = Y2284_pgtype28;
	Y2284[0] = 1146;
	{long i; for (i = 62; i < 71; i++) Y2284[i] = 1146;};
	{long i; for (i = 442; i < 444; i++) Y2284[i] = 1146;};
	Y2284[463] = 1146;
	{long i; for (i = 1794; i < 1797; i++) Y2284[i] = 1146;};
	{long i; for (i = 1805; i < 1811; i++) Y2284[i] = 1146;};
	Y2284[2008] = 1146;
	Y2284[2021] = 1146;
	Y2284[2024] = 1146;
	{long i; for (i = 2026; i < 2028; i++) Y2284[i] = 1146;};
	{long i; for (i = 2095; i < 2097; i++) Y2284[i] = 1146;};
}

long O2470[2261];
void O2470_init () {
	O2470[0] = + _LNGOFF_0_0_3_1_;
	O2470[2181] = + _LNGOFF_0_0_3_1_;
	O2470[2182] = + _LNGOFF_1_0_3_1_;
	O2470[2183] = + _LNGOFF_0_0_3_1_;
	{long i; for (i = 2184; i < 2186; i++) O2470[i] = + _LNGOFF_1_0_3_1_;}
	O2470[2186] = + _LNGOFF_0_0_3_1_;
	O2470[2187] = + _LNGOFF_1_0_3_1_;
	O2470[2188] = + _LNGOFF_0_0_3_1_;
	O2470[2209] = + _LNGOFF_1_0_3_1_;
	{long i; for (i = 2230; i < 2233; i++) O2470[i] = + _LNGOFF_0_0_3_1_;}
	O2470[2250] = + _LNGOFF_1_2_3_1_;
	O2470[2252] = + _LNGOFF_0_1_3_1_;
	O2470[2253] = + _LNGOFF_2_0_3_1_;
	O2470[2254] = + _LNGOFF_0_0_3_1_;
	O2470[2255] = + _LNGOFF_0_1_3_2_;
	O2470[2256] = + _LNGOFF_1_1_3_2_;
	{long i; for (i = 2257; i < 2259; i++) O2470[i] = + _LNGOFF_0_0_3_1_;}
	O2470[2259] = + _LNGOFF_2_2_3_1_;
	O2470[2260] = + _LNGOFF_3_3_3_1_;
}

long O2475[2261];
void O2475_init () {
	O2475[0] = + _LNGOFF_0_0_3_2_;
	O2475[2181] = + _LNGOFF_0_0_3_2_;
	O2475[2182] = + _LNGOFF_1_0_3_2_;
	O2475[2183] = + _LNGOFF_0_0_3_2_;
	{long i; for (i = 2184; i < 2186; i++) O2475[i] = + _LNGOFF_1_0_3_2_;}
	O2475[2186] = + _LNGOFF_0_0_3_2_;
	O2475[2187] = + _LNGOFF_1_0_3_2_;
	O2475[2188] = + _LNGOFF_0_0_3_2_;
	O2475[2209] = + _LNGOFF_1_0_3_2_;
	{long i; for (i = 2230; i < 2233; i++) O2475[i] = + _LNGOFF_0_0_3_2_;}
	O2475[2250] = + _LNGOFF_1_2_3_2_;
	O2475[2252] = + _LNGOFF_0_1_3_2_;
	O2475[2253] = + _LNGOFF_2_0_3_2_;
	O2475[2254] = + _LNGOFF_0_0_3_2_;
	O2475[2255] = + _LNGOFF_0_1_3_3_;
	O2475[2256] = + _LNGOFF_1_1_3_3_;
	{long i; for (i = 2257; i < 2259; i++) O2475[i] = + _LNGOFF_0_0_3_2_;}
	O2475[2259] = + _LNGOFF_2_2_3_2_;
	O2475[2260] = + _LNGOFF_3_3_3_2_;
}


#ifdef __cplusplus
}
#endif
