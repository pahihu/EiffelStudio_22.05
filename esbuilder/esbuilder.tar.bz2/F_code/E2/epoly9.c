#include "epoly9.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R2547[597])();
void R2547_init () {
	R2547[0] = (char *(*)()) F1946_21510;
	R2547[1] = (char *(*)()) F1947_21518;
	R2547[2] = (char *(*)()) F1948_21526;
	R2547[4] = (char *(*)()) F1950_21536;
	{long i; for (i = 124; i < 129; i++) R2547[i] = (char *(*)()) F2069_23670;}
	{long i; for (i = 595; i < 597; i++) R2547[i] = (char *(*)()) F2541_31638;}
}

static EIF_TYPE_INDEX Y2833_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2833_pgtype1[] = {0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y2833_gen_type [2];
EIF_TYPE_INDEX Y2833 [2];
void Y2833_init (void)
{
	egc_routines_types [2833] = Y2833;
	egc_routines_gen_types [2833] = Y2833_gen_type;
	egc_routines_offset [2833] = 210;
	Y2833_gen_type [0] = Y2833_pgtype0;
	Y2833_gen_type [1] = Y2833_pgtype1;
}

char *(*R4036[2032])();
void R4036_init () {
	{long i; for (i = 0; i < 6; i++) R4036[i] = (char *(*)()) F234_4099;}
	{long i; for (i = 377; i < 379; i++) R4036[i] = (char *(*)()) F234_4099;}
	R4036[398] = (char *(*)()) F234_4099;
	{long i; for (i = 1729; i < 1732; i++) R4036[i] = (char *(*)()) F234_4099;}
	R4036[1741] = (char *(*)()) F1976_22238;
	R4036[1742] = (char *(*)()) F1977_22242;
	R4036[1743] = (char *(*)()) F1978_22248;
	R4036[1744] = (char *(*)()) F1979_22253;
	R4036[1745] = (char *(*)()) F1980_22257;
	R4036[1943] = (char *(*)()) F234_4099;
	R4036[1956] = (char *(*)()) F2191_24976;
	R4036[1959] = (char *(*)()) F234_4099;
	{long i; for (i = 1961; i < 1963; i++) R4036[i] = (char *(*)()) F234_4099;}
	{long i; for (i = 2030; i < 2032; i++) R4036[i] = (char *(*)()) F234_4099;}
}

char *(*R4039[2032])();
void R4039_init () {
	{long i; for (i = 0; i < 6; i++) R4039[i] = (char *(*)()) F234_4101;}
	{long i; for (i = 377; i < 379; i++) R4039[i] = (char *(*)()) F234_4101;}
	R4039[398] = (char *(*)()) F234_4101;
	{long i; for (i = 1729; i < 1732; i++) R4039[i] = (char *(*)()) F234_4101;}
	{long i; for (i = 1741; i < 1746; i++) R4039[i] = (char *(*)()) F233_4081;}
	R4039[1943] = (char *(*)()) F234_4101;
	R4039[1956] = (char *(*)()) F233_4081;
	R4039[1959] = (char *(*)()) F234_4101;
	{long i; for (i = 1961; i < 1963; i++) R4039[i] = (char *(*)()) F234_4101;}
	{long i; for (i = 2030; i < 2032; i++) R4039[i] = (char *(*)()) F234_4101;}
}

char *(*R4100[136])();
void R4100_init () {
	R4100[0] = (char *(*)()) F245_4164;
	{long i; for (i = 2; i < 4; i++) R4100[i] = (char *(*)()) F245_4164;}
	{long i; for (i = 5; i < 7; i++) R4100[i] = (char *(*)()) F245_4164;}
	{long i; for (i = 8; i < 10; i++) R4100[i] = (char *(*)()) F245_4164;}
	R4100[19] = (char *(*)()) F245_4164;
	R4100[20] = (char *(*)()) F1798_19043;
	{long i; for (i = 21; i < 28; i++) R4100[i] = (char *(*)()) F245_4164;}
	{long i; for (i = 63; i < 69; i++) R4100[i] = (char *(*)()) F245_4164;}
	{long i; for (i = 70; i < 74; i++) R4100[i] = (char *(*)()) F245_4164;}
	{long i; for (i = 75; i < 78; i++) R4100[i] = (char *(*)()) F245_4164;}
	{long i; for (i = 79; i < 85; i++) R4100[i] = (char *(*)()) F245_4164;}
	R4100[86] = (char *(*)()) F245_4164;
	{long i; for (i = 88; i < 90; i++) R4100[i] = (char *(*)()) F245_4164;}
	{long i; for (i = 91; i < 93; i++) R4100[i] = (char *(*)()) F245_4164;}
	{long i; for (i = 94; i < 96; i++) R4100[i] = (char *(*)()) F245_4164;}
	R4100[98] = (char *(*)()) F245_4164;
	R4100[100] = (char *(*)()) F245_4164;
	R4100[103] = (char *(*)()) F245_4164;
	R4100[105] = (char *(*)()) F245_4164;
	R4100[107] = (char *(*)()) F245_4164;
	{long i; for (i = 113; i < 118; i++) R4100[i] = (char *(*)()) F245_4164;}
	R4100[119] = (char *(*)()) F245_4164;
	{long i; for (i = 123; i < 126; i++) R4100[i] = (char *(*)()) F245_4164;}
	R4100[133] = (char *(*)()) F245_4164;
	R4100[135] = (char *(*)()) F245_4164;
}

char *(*R4351[2])();
void R4351_init () {
	R4351[0] = (char *(*)()) F267_4418;
	R4351[1] = (char *(*)()) F268_4429;
}

char *(*R4352[2])();
void R4352_init () {
	R4352[0] = (char *(*)()) F267_4419;
	R4352[1] = (char *(*)()) F268_4430;
}

char *(*R4358[2])();
void R4358_init () {
	R4358[0] = (char *(*)()) F267_4425;
	R4358[1] = (char *(*)()) F268_4436;
}

char *(*R4361[2])();
void R4361_init () {
	R4361[0] = (char *(*)()) F267_4428;
	R4361[1] = (char *(*)()) F268_4439;
}

char *(*R4449[1953])();
void R4449_init () {
	R4449[0] = (char *(*)()) F274_4536;
	R4449[226] = (char *(*)()) F500_6910;
	{long i; for (i = 1946; i < 1948; i++) R4449[i] = (char *(*)()) F274_4536;}
	{long i; for (i = 1950; i < 1952; i++) R4449[i] = (char *(*)()) F274_4536;}
	R4449[1952] = (char *(*)()) F276_4573;
}

char *(*R4479[1726])();
void R4479_init () {
	R4479[0] = (char *(*)()) F501_6937;
	R4479[1725] = (char *(*)()) F2226_25681;
}

char *(*R4480[1726])();
void R4480_init () {
	R4480[0] = (char *(*)()) F501_6938;
	R4480[1725] = (char *(*)()) F2226_25682;
}


#ifdef __cplusplus
}
#endif
