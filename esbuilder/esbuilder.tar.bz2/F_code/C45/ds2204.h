
#ifndef _C45_ds2204_
#define _C45_ds2204_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F2149_24273(EIF_REFERENCE);
extern EIF_INTEGER_32 F2149_24276(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit2204(void);

#ifdef __cplusplus
}
#endif

#endif
