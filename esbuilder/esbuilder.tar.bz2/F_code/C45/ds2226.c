/*
 * Code for class DS_LINKED_QUEUE [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds2226.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_LINKED_QUEUE}.make */
void F2144_24216 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make", 2143, Current, 0, 0, 29738);
	RTGC;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {DS_LINKED_QUEUE}.item */
EIF_REFERENCE F2144_24221 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("item", 2143, Current, 1, 0, 29743);
	RTGC;
	RTHOOK(1);
	RTCT0("not_empty", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(2);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4728[Dtype(loc1)-306])(loc1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {DS_LINKED_QUEUE}.count */
EIF_INTEGER_32 F2144_24222 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_);
}


/* {DS_LINKED_QUEUE}.copy */
void F2144_24224 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,loc1);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,loc2);
	RTLIU(7);
	
	RTEAA("copy", 2143, Current, 3, 1, 29746);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		RTHOOK(2);
		eif_builtin_ANY_standard_copy__o_ (Current, arg1);
		RTHOOK(3);
		loc3 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		RTHOOK(4);
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			RTHOOK(5);
			{
				static EIF_TYPE_INDEX typarr0[] = {309,0,0,0xFFFF};
				EIF_TYPE typres0;
				{
					EIF_TYPE l_type;
					l_type = eif_final_id(Y18490,Y18490_gen_type,dftype,2108);
					typarr0[1] = l_type.annotations | 0xFF00;
					typarr0[2] = l_type.id;
				}
				
				typres0 = eif_compound_id(dftype, typarr0);
				loc1 = RTLNSMART(typres0.id);
			}
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4728[Dtype(RTCW(loc3))-306])(loc3);
			tr2 = RTCCL(tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4731[Dtype(RTCW(loc1))-306])(loc1, tr2);
			RTHOOK(6);
			RTAR(Current, loc1);
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc1;
			RTHOOK(7);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + O4737[Dtype(loc3)-309]);
			loc3 = (EIF_REFERENCE) tr1;
			for (;;) {
				RTHOOK(8);
				if ((EIF_BOOLEAN)(loc3 == NULL)) break;
				RTHOOK(9);
				{
					static EIF_TYPE_INDEX typarr0[] = {309,0,0,0xFFFF};
					EIF_TYPE typres0;
					{
						EIF_TYPE l_type;
						l_type = eif_final_id(Y18490,Y18490_gen_type,dftype,2108);
						typarr0[1] = l_type.annotations | 0xFF00;
						typarr0[2] = l_type.id;
					}
					
					typres0 = eif_compound_id(dftype, typarr0);
					loc2 = RTLNSMART(typres0.id);
				}
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4728[Dtype(RTCW(loc3))-306])(loc3);
				tr2 = RTCCL(tr1);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4731[Dtype(RTCW(loc2))-306])(loc2, tr2);
				RTHOOK(10);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4738[Dtype(RTCW(loc1))-309])(loc1, loc2);
				RTHOOK(11);
				loc1 = (EIF_REFERENCE) loc2;
				RTHOOK(12);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + O4737[Dtype(loc3)-309]);
				loc3 = (EIF_REFERENCE) tr1;
			}
			RTHOOK(13);
			RTAR(Current, loc1);
			*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
		}
	}
	RTHOOK(14);
	RTLE;
	RTEE;
}

/* {DS_LINKED_QUEUE}.is_equal */
EIF_BOOLEAN F2144_24225 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTEAA("is_equal", 2143, Current, 2, 1, 29747);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(Current == arg1)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		RTHOOK(4);
		tb1 = '\0';
		tr1 = RTOSCF(12111,F1329_12111, (Current));
		tb2 = F35_463(RTCW(tr1), Current, arg1);
		if (tb2) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_0_0_0_);
			tb1 = (EIF_BOOLEAN)(ti4_1 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_));
		}
		if (tb1) {
			RTHOOK(5);
			loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			RTHOOK(6);
			loc2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
			RTHOOK(7);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			for (;;) {
				RTHOOK(8);
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == NULL) || (EIF_BOOLEAN)(loc2 == NULL))) break;
				RTHOOK(9);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4728[Dtype(RTCW(loc1))-306])(loc1);
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4728[Dtype(RTCW(loc2))-306])(loc2);
				if (!RTCEQ(tr1, tr2)) {
					RTHOOK(10);
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					RTHOOK(11);
					loc1 = (EIF_REFERENCE) NULL;
				} else {
					RTHOOK(12);
					tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O4737[Dtype(loc1)-309]);
					loc1 = (EIF_REFERENCE) tr1;
					RTHOOK(13);
					tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + O4737[Dtype(loc2)-309]);
					loc2 = (EIF_REFERENCE) tr1;
				}
			}
		}
	}
	RTHOOK(14);
	RTLE;
	RTEE;
	return Result;
}

/* {DS_LINKED_QUEUE}.force */
void F2144_24227 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTEAA("force", 2143, Current, 2, 1, 29749);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {309,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y18490,Y18490_gen_type,dftype,2108);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		
		typres0 = eif_compound_id(dftype, typarr0);
		loc1 = RTLNSMART(typres0.id);
	}
	tr1 = RTCCL(arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4731[Dtype(RTCW(loc1))-306])(loc1, tr1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTHOOK(3);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4738[Dtype(loc2)-309])(loc2, loc1);
		RTHOOK(4);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
		RTHOOK(5);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_))++;
	} else {
		RTHOOK(6);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc1;
		RTHOOK(7);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
		RTHOOK(8);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {DS_LINKED_QUEUE}.remove */
void F2144_24230 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("remove", 2143, Current, 1, 0, 29752);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(2);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R18483[Dtype(Current)-2135])(Current);
	} else {
		RTHOOK(3);
		RTCT0("not_empty", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			RTCK0;
		} else {
			RTCF0;
		}
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(loc1 + O4737[Dtype(loc1)-309]);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		RTHOOK(5);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_))--;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {DS_LINKED_QUEUE}.wipe_out */
void F2144_24233 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("wipe_out", 2143, Current, 0, 0, 29755);
	RTGC;
	RTHOOK(1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
	RTHOOK(2);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) NULL;
	RTHOOK(3);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTHOOK(4);
	RTLE;
	RTEE;
}

void EIF_Minit2226 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
