/*
 * Code for class EV_GRID_ARRAYED_LIST [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev2206.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GRID_ARRAYED_LIST}.default_create */
void F1160_10177 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("default_create", 1159, Current, 0, 0, 13924);
	RTHOOK(1);
	F558_7454(Current, ((EIF_INTEGER_32) 0L));
	RTHOOK(2);
	RTEE;
}

/* {EV_GRID_ARRAYED_LIST}.shift_items */
void F1160_10178 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("shift_items", 1159, Current, 5, 3, 13925);
	RTGC;
	RTHOOK(1);
	loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
	RTHOOK(2);
	loc2 = F1151_10132(Current);
	RTHOOK(3);
	loc5 = (EIF_INTEGER_32) arg3;
	RTHOOK(4);
	loc1 = RTLNSMART(Dftype(Current));
	F1151_10111(RTCW(loc1), arg3);
	RTHOOK(5);
	loc4 = (EIF_INTEGER_32) arg1;
	for (;;) {
		RTHOOK(7);
		if ((EIF_BOOLEAN) (loc5 <= ((EIF_INTEGER_32) 0L))) break;
		RTHOOK(8);
		ti4_1 = F1151_10117(Current, loc4);
		F1151_10152(RTCW(loc1), ti4_1);
		RTHOOK(9);
		loc4++;
		RTHOOK(10);
		loc5--;
	}
	RTHOOK(11);
	tr1 = F1151_10115(Current);
	/* INLINED CODE (SPECIAL.overlapping_move) */
	memmove((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L))),(EIF_INTEGER_32 *)RTCW(tr1) + (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)) + arg3), (rt_uint_ptr)sizeof(EIF_INTEGER_32) * (rt_uint_ptr)(EIF_INTEGER_32) (loc2 - (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)) + arg3)));
	RT_SPECIAL_COUNT(tr1) = eif_max_int32(RT_SPECIAL_COUNT(tr1), (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)) + (EIF_INTEGER_32) (loc2 - (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)) + arg3)));
	/* END INLINED CODE */
	;
	RTHOOK(12);
	loc2 -= arg3;
	RTHOOK(13);
	tr1 = F1151_10115(Current);
	ti4_1 = F1151_10134(Current);
	F1262_11874(RTCW(tr1), loc2, (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
	RTHOOK(14);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L));
	RTHOOK(15);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) < loc2)) {
		RTHOOK(16);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
		ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
		ti4_3 = F1151_10132(RTCW(loc1));
		F1160_10181(Current, Current, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)), loc2, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_2 + ti4_3) + ((EIF_INTEGER_32) 1L)));
	}
	RTHOOK(17);
	ti4_1 = F1151_10132(RTCW(loc1));
	ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
	F1160_10181(Current, loc1, ((EIF_INTEGER_32) 1L), ti4_1, (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
	RTHOOK(18);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) loc3;
	RTHOOK(19);
	RTLE;
	RTEE;
}

/* {EV_GRID_ARRAYED_LIST}.move_items */
void F1160_10179 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("move_items", 1159, Current, 5, 3, 13926);
	RTGC;
	RTHOOK(1);
	loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
	RTHOOK(2);
	loc2 = F1151_10132(Current);
	RTHOOK(3);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) arg1;
	RTHOOK(4);
	loc5 = (EIF_INTEGER_32) arg3;
	RTHOOK(5);
	loc1 = RTLNSMART(Dftype(Current));
	F1151_10111(RTCW(loc1), arg3);
	RTHOOK(6);
	loc4 = (EIF_INTEGER_32) arg1;
	for (;;) {
		RTHOOK(8);
		if ((EIF_BOOLEAN) (loc5 <= ((EIF_INTEGER_32) 0L))) break;
		RTHOOK(9);
		ti4_1 = F1151_10117(Current, loc4);
		F1151_10152(RTCW(loc1), ti4_1);
		RTHOOK(10);
		loc4++;
		RTHOOK(11);
		loc5--;
	}
	RTHOOK(12);
	tr1 = F1151_10115(Current);
	/* INLINED CODE (SPECIAL.overlapping_move) */
	memmove((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L))),(EIF_INTEGER_32 *)RTCW(tr1) + (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)) + arg3), (rt_uint_ptr)sizeof(EIF_INTEGER_32) * (rt_uint_ptr)(EIF_INTEGER_32) (loc2 - (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)) + arg3)));
	RT_SPECIAL_COUNT(tr1) = eif_max_int32(RT_SPECIAL_COUNT(tr1), (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)) + (EIF_INTEGER_32) (loc2 - (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)) + arg3)));
	/* END INLINED CODE */
	;
	RTHOOK(13);
	loc2 -= arg3;
	RTHOOK(14);
	tr1 = F1151_10115(Current);
	ti4_1 = F1151_10134(Current);
	F1262_11874(RTCW(tr1), loc2, (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
	RTHOOK(15);
	if ((EIF_BOOLEAN) (arg2 > (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 + arg3) - ((EIF_INTEGER_32) 1L)))) {
		RTHOOK(16);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg2 - arg3) - ((EIF_INTEGER_32) 1L));
	} else {
		RTHOOK(17);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L));
	}
	RTHOOK(18);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) < loc2)) {
		RTHOOK(19);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
		ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
		ti4_3 = F1151_10132(RTCW(loc1));
		F1160_10181(Current, Current, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)), loc2, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_2 + ti4_3) + ((EIF_INTEGER_32) 1L)));
	}
	RTHOOK(20);
	ti4_1 = F1151_10132(RTCW(loc1));
	ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
	F1160_10181(Current, loc1, ((EIF_INTEGER_32) 1L), ti4_1, (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
	RTHOOK(21);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) loc3;
	RTHOOK(22);
	RTLE;
	RTEE;
}

/* {EV_GRID_ARRAYED_LIST}.resize */
void F1160_10180 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("resize", 1159, Current, 1, 1, 13927);
	RTGC;
	RTHOOK(1);
	loc1 = F1151_10134(Current);
	RTHOOK(2);
	if ((EIF_BOOLEAN) (arg1 > F1151_10134(Current))) {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = RTLNTY2(eif_final_id(Y6497,Y6497_gen_type,Dftype(Current),553), 0x00);
		ti4_1 = F1398_12909(tr2);
		tr1 = F1262_11887(RTCW(tr1), ti4_1, arg1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(4);
	tr1 = F1151_10115(Current);
	F1262_11880(RTCW(tr1), arg1);
	RTHOOK(5);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_);
	ti4_1 = eif_min_int32 (ti4_1,(EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_GRID_ARRAYED_LIST}.subcopy */
void F1160_10181 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_INTEGER_32 ti4_5;
	EIF_INTEGER_32 ti4_6;
	EIF_INTEGER_32 ti4_7;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("subcopy", 1159, Current, 0, 4, 13928);
	RTGC;
	RTHOOK(1);
	tr1 = F1151_10115(Current);
	tr2 = F1151_10115(RTCW(arg1));
	ti4_1 = ((EIF_INTEGER_32) 1L);
	/* INLINED CODE (SPECIAL.copy_data) */
	memmove((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (arg4 - ((EIF_INTEGER_32) 1L))),(EIF_INTEGER_32 *)tr2 + (EIF_INTEGER_32) (arg2 - ti4_1), (rt_uint_ptr)sizeof(EIF_INTEGER_32) * (rt_uint_ptr)(EIF_INTEGER_32) ((EIF_INTEGER_32) (arg3 - arg2) + ((EIF_INTEGER_32) 1L)));
	RT_SPECIAL_COUNT(tr1) = eif_max_int32(RT_SPECIAL_COUNT(tr1), (EIF_INTEGER_32) (arg4 - ((EIF_INTEGER_32) 1L)) + (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg3 - arg2) + ((EIF_INTEGER_32) 1L)));
	/* END INLINED CODE */
	;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit2206 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
