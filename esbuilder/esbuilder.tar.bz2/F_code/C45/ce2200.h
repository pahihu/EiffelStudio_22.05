
#ifndef _C45_ce2200_
#define _C45_ce2200_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_64 F364_5874(EIF_REFERENCE);
extern void F364_5875(EIF_REFERENCE, EIF_NATURAL_64);
extern void F364_5876(EIF_REFERENCE, EIF_NATURAL_64);
extern void EIF_Minit2200(void);

#ifdef __cplusplus
}
#endif

#endif
