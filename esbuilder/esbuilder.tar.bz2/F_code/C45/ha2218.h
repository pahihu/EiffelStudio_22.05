
#ifndef _C45_ha2218_
#define _C45_ha2218_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1068_9805(EIF_REFERENCE);
extern EIF_REFERENCE F1068_9806(EIF_REFERENCE);
extern EIF_BOOLEAN F1068_9808(EIF_REFERENCE);
extern void F1068_9809(EIF_REFERENCE);
extern EIF_REFERENCE F1068_9810(EIF_REFERENCE);
extern void EIF_Minit2218(void);
extern EIF_BOOLEAN F1058_9797(EIF_REFERENCE);
extern char *(*R8395[])();
extern char *(*R8396[])();
extern char *(*R8042[])();
extern char *(*R9796[])();

#ifdef __cplusplus
}
#endif

#endif
