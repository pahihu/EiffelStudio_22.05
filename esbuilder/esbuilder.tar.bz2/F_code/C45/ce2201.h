
#ifndef _C45_ce2201_
#define _C45_ce2201_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F365_5874(EIF_REFERENCE);
extern void F365_5875(EIF_REFERENCE, EIF_BOOLEAN);
extern void F365_5876(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit2201(void);
extern long O5375[];

#ifdef __cplusplus
}
#endif

#endif
