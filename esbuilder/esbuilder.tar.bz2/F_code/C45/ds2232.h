
#ifndef _C45_ds2232_
#define _C45_ds2232_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F2122_23902(EIF_REFERENCE);
extern void F2122_23907(EIF_REFERENCE);
extern void F2122_23908(EIF_REFERENCE);
extern void EIF_Minit2232(void);

#ifdef __cplusplus
}
#endif

#endif
