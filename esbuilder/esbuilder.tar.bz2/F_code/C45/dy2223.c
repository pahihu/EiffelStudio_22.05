/*
 * Code for class DYNAMIC_TABLE [BOOLEAN, G#2]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "dy2223.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DYNAMIC_TABLE}.prunable */
EIF_BOOLEAN F779_9256 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("prunable", 778, Current, 0, 0, 9474);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

void EIF_Minit2223 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
