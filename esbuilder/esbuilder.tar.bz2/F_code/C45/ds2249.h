
#ifndef _C45_ds2249_
#define _C45_ds2249_

#ifdef __cplusplus
extern "C" {
#endif

extern void F2153_24390(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F2153_24391(EIF_REFERENCE);
extern EIF_INTEGER_32 F2153_24395(EIF_REFERENCE);
extern EIF_INTEGER_32 F2153_24396(EIF_REFERENCE);
extern EIF_BOOLEAN F2153_24399(EIF_REFERENCE);
extern void F2153_24409(EIF_REFERENCE);
extern void F2153_24410(EIF_REFERENCE, EIF_REFERENCE);
extern void F2153_24413(EIF_REFERENCE);
extern void F2153_24414(EIF_REFERENCE, EIF_INTEGER_32);
extern void F2153_24423(EIF_REFERENCE, EIF_REFERENCE);
extern void F2153_24460(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F2153_24461(EIF_REFERENCE);
extern void F2153_24462(EIF_REFERENCE);
extern EIF_REFERENCE F2153_24466(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F2153_24467(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F2153_24468(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F2153_24469(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F2153_24470(EIF_REFERENCE, EIF_REFERENCE);
extern void F2153_24471(EIF_REFERENCE, EIF_REFERENCE);
extern void F2153_24472(EIF_REFERENCE, EIF_REFERENCE);
extern void F2153_24473(EIF_REFERENCE, EIF_REFERENCE);
extern void F2153_24476(EIF_REFERENCE, EIF_REFERENCE);
extern void F2153_24477(EIF_REFERENCE, EIF_REFERENCE);
extern void F2153_24478(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F2153_24479(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F2153_24480(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit2249(void);
extern char *(*R18764[])();
extern char *(*R18389[])();
extern char *(*R18415[])();
extern char *(*R18731[])();
extern char *(*R18733[])();
extern char *(*R18734[])();
extern char *(*R18735[])();
extern char *(*R18736[])();
extern char *(*R18738[])();
extern char *(*R18740[])();
extern char *(*R18741[])();
extern char *(*R18742[])();
extern char *(*R18750[])();
extern char *(*R18744[])();
extern char *(*R18745[])();
extern char *(*R18746[])();
extern char *(*R18747[])();
extern char *(*R18748[])();
extern char *(*R18749[])();
extern char *(*R5389[])();
extern char *(*R18513[])();
extern char *(*R18516[])();
extern char *(*R18518[])();
extern char *(*R18751[])();
extern char *(*R18752[])();
extern char *(*R18753[])();
extern char *(*R18754[])();
extern char *(*R18482[])();
extern char *(*R18716[])();
extern char *(*R18521[])();
extern char *(*R18524[])();
extern char *(*R18525[])();
extern char *(*R18721[])();
extern char *(*R18723[])();
extern char *(*R18724[])();
extern char *(*R18768[])();
extern char *(*R18729[])();
extern char *(*R18416[])();
extern char *(*R18417[])();
extern long O18755[];
extern long O18756[];
extern long O18757[];
extern long O18758[];
extern long O18759[];
extern long O18760[];
extern long O18720[];
extern long O18770[];
extern long O18771[];

#ifdef __cplusplus
}
#endif

#endif
