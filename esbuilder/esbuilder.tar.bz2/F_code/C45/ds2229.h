
#ifndef _C45_ds2229_
#define _C45_ds2229_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_8 F308_4865(EIF_REFERENCE);
extern void F308_4867(EIF_REFERENCE, EIF_CHARACTER_8);
extern void F308_4868(EIF_REFERENCE, EIF_CHARACTER_8);
extern void EIF_Minit2229(void);
extern long O4728[];

#ifdef __cplusplus
}
#endif

#endif
