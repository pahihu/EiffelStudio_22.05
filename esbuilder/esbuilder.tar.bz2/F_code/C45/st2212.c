/*
 * Code for class STRING_TABLE [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "st2212.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {STRING_TABLE}.make_caseless */
void F1144_10092 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make_caseless", 1143, Current, 0, 1, 13089);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_5_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTHOOK(2);
	F1138_9980(Current, arg1);
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {STRING_TABLE}.hash_code_of */
EIF_INTEGER_32 F1144_10094 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("hash_code_of", 1143, Current, 0, 1, 13091);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_3_)) {
		RTHOOK(2);
		ti4_1 = F1500_14165(RTCW(arg1));
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ti4_1;
	} else {
		RTHOOK(4);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10517[Dtype(RTCW(arg1))-1382])(arg1);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ti4_1;
	}/* NOTREACHED */
	
}

/* {STRING_TABLE}.same_keys */
EIF_BOOLEAN F1144_10096 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTEAA("same_keys", 1143, Current, 0, 2, 13093);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_3_)) {
		RTHOOK(2);
		tb1 = F1500_14197(RTCW(arg1), arg2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) tb1;
	} else {
		RTHOOK(4);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11492[Dtype(RTCW(arg1))-1503])(arg1, arg2);
		RTHOOK(5);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) tb1;
	}/* NOTREACHED */
	
}

/* {STRING_TABLE}.is_equal */
EIF_BOOLEAN F1144_10097 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("is_equal", 1143, Current, 0, 1, 13094);
	RTGC;
	RTHOOK(1);
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_5_3_);
	if ((EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current+ _CHROFF_5_3_) == tb1)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) F1138_10003(Current, arg1);
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) 0;
}

/* {STRING_TABLE}.empty_duplicate */
EIF_REFERENCE F1144_10098 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTEAA("empty_duplicate", 1143, Current, 0, 1, 13095);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_3_)) {
		RTHOOK(2);
		Result = RTLNSMART(dftype);
		F1144_10092(RTCW(Result), arg1);
	} else {
		RTHOOK(3);
		Result = RTLNSMART(dftype);
		F1138_9980(RTCW(Result), arg1);
	}
	RTHOOK(4);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_)) {
		RTHOOK(5);
		F682_9061(RTCW(Result));
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit2212 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
