
#ifndef _C45_ds2228_
#define _C45_ds2228_

#ifdef __cplusplus
extern "C" {
#endif

extern void F311_4874(EIF_REFERENCE, EIF_REFERENCE);
extern void F311_4875(EIF_REFERENCE);
extern void EIF_Minit2228(void);

#ifdef __cplusplus
}
#endif

#endif
