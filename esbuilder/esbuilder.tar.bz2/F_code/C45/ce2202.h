
#ifndef _C45_ce2202_
#define _C45_ce2202_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_32 F366_5874(EIF_REFERENCE);
extern void F366_5875(EIF_REFERENCE, EIF_CHARACTER_32);
extern void F366_5876(EIF_REFERENCE, EIF_CHARACTER_32);
extern void EIF_Minit2202(void);

#ifdef __cplusplus
}
#endif

#endif
