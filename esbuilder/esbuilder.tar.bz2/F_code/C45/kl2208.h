
#ifndef _C45_kl2208_
#define _C45_kl2208_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_8 F156_2227(EIF_REFERENCE);
extern void EIF_Minit2208(void);
extern long O2214[];

#ifdef __cplusplus
}
#endif

#endif
