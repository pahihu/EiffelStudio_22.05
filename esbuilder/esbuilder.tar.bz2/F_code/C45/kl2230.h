
#ifndef _C45_kl2230_
#define _C45_kl2230_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F372_5889(EIF_REFERENCE, EIF_CHARACTER_8, EIF_CHARACTER_8);
extern void EIF_Minit2230(void);

#ifdef __cplusplus
}
#endif

#endif
