
#ifndef _C45_ha2225_
#define _C45_ha2225_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1069_9805(EIF_REFERENCE);
extern EIF_REFERENCE F1069_9806(EIF_REFERENCE);
extern EIF_BOOLEAN F1069_9808(EIF_REFERENCE);
extern void F1069_9809(EIF_REFERENCE);
extern EIF_REFERENCE F1069_9810(EIF_REFERENCE);
extern void EIF_Minit2225(void);
extern EIF_INTEGER_32 F1139_10025(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F1139_10024(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F1061_9797(EIF_REFERENCE);
extern char *(*R8042[])();
extern char *(*R9796[])();

#ifdef __cplusplus
}
#endif

#endif
