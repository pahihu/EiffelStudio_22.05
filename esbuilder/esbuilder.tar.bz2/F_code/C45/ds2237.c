/*
 * Code for class DS_SEARCHABLE [CHARACTER_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds2237.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_SEARCHABLE}.same_equality_tester */
EIF_BOOLEAN F2119_23895 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("same_equality_tester", 2118, Current, 0, 1, 29441);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
	Result = (EIF_BOOLEAN) RTEQ(tr1, tr2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {DS_SEARCHABLE}.set_equality_tester */
void F2119_23899 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_equality_tester", 2118, Current, 0, 1, 29444);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

void EIF_Minit2237 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
