/*
 * Code for class DS_ARRAYED_LIST [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds2203.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_ARRAYED_LIST}.item */
EIF_REFERENCE F2151_24283 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("item", 2150, Current, 0, 1, 29905);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R8042[Dtype(RTCW(tr1))-919])(tr1, (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {DS_ARRAYED_LIST}.first */
EIF_REFERENCE F2151_24284 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("first", 2150, Current, 0, 0, 29906);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R8042[Dtype(RTCW(tr1))-919])(tr1, ((EIF_INTEGER_32) 0L));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {DS_ARRAYED_LIST}.last */
EIF_REFERENCE F2151_24285 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("last", 2150, Current, 0, 0, 29907);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R8042[Dtype(RTCW(tr1))-919])(tr1, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) - ((EIF_INTEGER_32) 1L)));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {DS_ARRAYED_LIST}.new_cursor */
EIF_REFERENCE F2151_24286 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("new_cursor", 2150, Current, 0, 0, 29908);
	RTGC;
	RTHOOK(1);
	{
		static EIF_TYPE_INDEX typarr0[] = {2103,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y18490,Y18490_gen_type,Dftype(Current),2108);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		tr1 = RTLNS(typres0.id, 2103, _OBJSIZ_2_0_0_1_0_0_0_0_);
	}
	F2104_23789(RTCW(tr1), Current);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {DS_ARRAYED_LIST}.count */
EIF_INTEGER_32 F2151_24287 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
}


/* {DS_ARRAYED_LIST}.capacity */
EIF_INTEGER_32 F2151_24288 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_);
}


/* {DS_ARRAYED_LIST}.extendible */
EIF_BOOLEAN F2151_24291 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("extendible", 2150, Current, 0, 1, 29831);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_) >= (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) + arg1));
}

/* {DS_ARRAYED_LIST}.copy */
void F2151_24292 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("copy", 2150, Current, 1, 1, 29832);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		RTHOOK(2);
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		RTHOOK(3);
		F2151_24337(Current);
		RTHOOK(4);
		eif_builtin_ANY_standard_copy__o_ (Current, arg1);
		RTHOOK(5);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tb1 = F2115_23882(Current, loc1);
		}
		if (tb1) {
			RTHOOK(6);
			F2151_24335(Current, loc1);
		} else {
			RTHOOK(7);
			tr1 = F2151_24286(Current);
			F2151_24335(Current, tr1);
		}
		RTHOOK(8);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9797[Dtype(RTCW(tr2))-1257])(tr2);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R9825[Dtype(RTCW(tr1))-1257])(tr1, ti4_1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {DS_ARRAYED_LIST}.is_equal */
EIF_BOOLEAN F2151_24293 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTEAA("is_equal", 2150, Current, 3, 1, 29833);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(Current == arg1)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		RTHOOK(4);
		tb1 = '\0';
		tr1 = RTOSCF(12111,F1329_12111, (Current));
		tb2 = F35_463(RTCW(tr1), Current, arg1);
		if (tb2) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_0_0_1_);
			tb1 = (EIF_BOOLEAN)(ti4_1 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_));
		}
		if (tb1) {
			RTHOOK(5);
			loc3 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
			RTHOOK(6);
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			RTHOOK(7);
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
			RTHOOK(8);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			for (;;) {
				RTHOOK(9);
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc1 > loc2))) break;
				RTHOOK(10);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R8042[Dtype(RTCW(tr1))-919])(tr1, loc1);
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R8042[Dtype(RTCW(loc3))-919])(loc3, loc1);
				Result = (EIF_BOOLEAN) RTCEQ(tr1, tr2);
				RTHOOK(11);
				loc1++;
			}
		}
	}
	RTHOOK(12);
	RTLE;
	RTEE;
	return Result;
}

/* {DS_ARRAYED_LIST}.put_last */
void F2151_24296 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTEAA("put_last", 2150, Current, 0, 1, 29836);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr3 = RTCCL(arg1);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R802[Dtype(RTCW(tr1))-56])(tr1, tr2, tr3, ti4_1);
	RTHOOK(2);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_))++;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {DS_ARRAYED_LIST}.put */
void F2151_24297 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("put", 2150, Current, 0, 2, 29837);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg2 == (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) + ((EIF_INTEGER_32) 1L)))) {
		RTHOOK(2);
		tr1 = RTCCL(arg1);
		F2151_24296(Current, tr1);
	} else {
		RTHOOK(3);
		F2151_24332(Current, arg2, ((EIF_INTEGER_32) 1L));
		RTHOOK(4);
		F2151_24340(Current, arg2, ((EIF_INTEGER_32) 1L));
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = RTCCL(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R9810[Dtype(RTCW(tr1))-1257])(tr1, tr2, (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)));
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {DS_ARRAYED_LIST}.force_first */
void F2151_24300 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("force_first", 2150, Current, 0, 1, 29840);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !F2151_24291(Current, ((EIF_INTEGER_32) 1L))) {
		RTHOOK(2);
		ti4_1 = F2149_24276(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) + ((EIF_INTEGER_32) 1L)));
		F2151_24330(Current, ti4_1);
	}
	RTHOOK(3);
	tr1 = RTCCL(arg1);
	F2151_24297(Current, tr1, ((EIF_INTEGER_32) 1L));
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {DS_ARRAYED_LIST}.force_last */
void F2151_24301 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTEAA("force_last", 2150, Current, 0, 1, 29841);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !F2151_24291(Current, ((EIF_INTEGER_32) 1L))) {
		RTHOOK(2);
		ti4_1 = F2149_24276(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) + ((EIF_INTEGER_32) 1L)));
		F2151_24330(Current, ti4_1);
	}
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr3 = RTCCL(arg1);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R802[Dtype(RTCW(tr1))-56])(tr1, tr2, tr3, ti4_1);
	RTHOOK(4);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_))++;
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {DS_ARRAYED_LIST}.remove_last */
void F2151_24316 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("remove_last", 2150, Current, 0, 0, 29856);
	RTGC;
	RTHOOK(1);
	F2151_24338(Current);
	RTHOOK(2);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_))--;
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R9821[Dtype(RTCW(tr1))-1257])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_));
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {DS_ARRAYED_LIST}.remove */
void F2151_24317 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("remove", 2150, Current, 0, 1, 29857);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_))) {
		RTHOOK(2);
		F2151_24316(Current);
	} else {
		RTHOOK(3);
		F2151_24339(Current, (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)));
		RTHOOK(4);
		F2151_24333(Current, (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)), ((EIF_INTEGER_32) 1L));
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R9821[Dtype(RTCW(tr1))-1257])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_));
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {DS_ARRAYED_LIST}.remove_at_cursor */
void F2151_24318 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("remove_at_cursor", 2150, Current, 0, 1, 29858);
	RTGC;
	RTHOOK(1);
	ti4_1 = F2103_23771(RTCW(arg1));
	F2151_24317(Current, ti4_1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {DS_ARRAYED_LIST}.resize */
void F2151_24330 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("resize", 2150, Current, 0, 1, 29870);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R805[Dtype(RTCW(tr1))-56])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_1_), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {DS_ARRAYED_LIST}.move_right */
void F2151_24332 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTEAA("move_right", 2150, Current, 2, 2, 29872);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg1 <= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_))) {
		RTHOOK(2);
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
		RTHOOK(3);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 + arg2) - ((EIF_INTEGER_32) 2L));
		for (;;) {
			RTHOOK(4);
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			RTHOOK(5);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R8042[Dtype(RTCW(tr3))-919])(tr3, (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)));
			tr4 = RTCCL(tr3);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R802[Dtype(RTCW(tr1))-56])(tr1, tr2, tr4, loc1);
			RTHOOK(6);
			loc1++;
		}
		RTHOOK(7);
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 + arg2) - ((EIF_INTEGER_32) 1L));
		for (;;) {
			RTHOOK(8);
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			RTHOOK(9);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R8042[Dtype(RTCW(tr3))-919])(tr3, (EIF_INTEGER_32) (loc1 - arg2));
			tr4 = RTCCL(tr3);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R802[Dtype(RTCW(tr1))-56])(tr1, tr2, tr4, loc1);
			RTHOOK(10);
			loc1++;
		}
		RTHOOK(11);
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
		RTHOOK(12);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 + arg2) - ((EIF_INTEGER_32) 1L));
		for (;;) {
			RTHOOK(13);
			if ((EIF_BOOLEAN) (loc1 < loc2)) break;
			RTHOOK(14);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R8042[Dtype(RTCW(tr2))-919])(tr2, (EIF_INTEGER_32) (loc1 - arg2));
			tr3 = RTCCL(tr2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R9810[Dtype(RTCW(tr1))-1257])(tr1, tr3, loc1);
			RTHOOK(15);
			loc1--;
		}
		RTHOOK(16);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_)) += arg2;
	}
	RTHOOK(18);
	RTLE;
	RTEE;
}

/* {DS_ARRAYED_LIST}.move_left */
void F2151_24333 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEAA("move_left", 2150, Current, 2, 2, 29873);
	RTGC;
	RTHOOK(1);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L));
	RTHOOK(2);
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
	for (;;) {
		RTHOOK(3);
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R8042[Dtype(RTCW(tr2))-919])(tr2, loc1);
		tr3 = RTCCL(tr2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R9810[Dtype(RTCW(tr1))-1257])(tr1, tr3, (EIF_INTEGER_32) (loc1 - arg2));
		RTHOOK(5);
		loc1++;
	}
	RTHOOK(6);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_)) -= arg2;
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {DS_ARRAYED_LIST}.set_internal_cursor */
void F2151_24335 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_internal_cursor", 2150, Current, 0, 1, 29875);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {DS_ARRAYED_LIST}.internal_cursor */
EIF_REFERENCE F2151_24336 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {DS_ARRAYED_LIST}.move_all_cursors_after */
void F2151_24337 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTEAA("move_all_cursors_after", 2150, Current, 2, 0, 29877);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	for (;;) {
		RTHOOK(2);
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		RTHOOK(3);
		F2104_23796(RTCW(loc1));
		RTHOOK(4);
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
		RTHOOK(5);
		F2076_23705(RTCW(loc1), NULL);
		RTHOOK(6);
		loc1 = (EIF_REFERENCE) loc2;
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {DS_ARRAYED_LIST}.move_last_cursors_after */
void F2151_24338 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTEAA("move_last_cursors_after", 2150, Current, 4, 0, 29878);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
	RTHOOK(2);
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	RTHOOK(3);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_2_0_0_0_);
	if ((EIF_BOOLEAN)(ti4_1 == loc1)) {
		RTHOOK(4);
		F2104_23796(RTCW(loc2));
	}
	RTHOOK(5);
	loc4 = (EIF_REFERENCE) loc2;
	RTHOOK(6);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
	loc2 = (EIF_REFERENCE) tr1;
	for (;;) {
		RTHOOK(7);
		if ((EIF_BOOLEAN)(loc2 == NULL)) break;
		RTHOOK(8);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_2_0_0_0_);
		if ((EIF_BOOLEAN)(ti4_1 == loc1)) {
			RTHOOK(9);
			F2104_23796(RTCW(loc2));
			RTHOOK(10);
			loc3 = *(EIF_REFERENCE *)(RTCW(loc2));
			RTHOOK(11);
			F2076_23705(RTCW(loc4), loc3);
			RTHOOK(12);
			F2076_23705(RTCW(loc2), NULL);
			RTHOOK(13);
			loc2 = (EIF_REFERENCE) loc3;
		} else {
			RTHOOK(14);
			loc4 = (EIF_REFERENCE) loc2;
			RTHOOK(15);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
			loc2 = (EIF_REFERENCE) tr1;
		}
	}
	RTHOOK(16);
	RTLE;
	RTEE;
}

/* {DS_ARRAYED_LIST}.move_cursors_left */
void F2151_24339 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("move_cursors_left", 2150, Current, 2, 1, 29879);
	RTGC;
	RTHOOK(1);
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	for (;;) {
		RTHOOK(2);
		if ((EIF_BOOLEAN)(loc2 == NULL)) break;
		RTHOOK(3);
		loc1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_2_0_0_0_);
		RTHOOK(4);
		if ((EIF_BOOLEAN) (loc1 >= (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)))) {
			RTHOOK(5);
			F2104_23795(RTCW(loc2), (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
		}
		RTHOOK(6);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
		loc2 = (EIF_REFERENCE) tr1;
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {DS_ARRAYED_LIST}.move_cursors_right */
void F2151_24340 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("move_cursors_right", 2150, Current, 2, 2, 29880);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	for (;;) {
		RTHOOK(2);
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		RTHOOK(3);
		loc2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_2_0_0_0_);
		RTHOOK(4);
		if ((EIF_BOOLEAN) (loc2 >= (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)))) {
			RTHOOK(5);
			F2104_23795(RTCW(loc1), (EIF_INTEGER_32) (loc2 + arg2));
		}
		RTHOOK(6);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		loc1 = (EIF_REFERENCE) tr1;
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {DS_ARRAYED_LIST}.cursor_item */
EIF_REFERENCE F2151_24341 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("cursor_item", 2150, Current, 0, 1, 29881);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R8042[Dtype(RTCW(tr1))-919])(tr1, ti4_1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {DS_ARRAYED_LIST}.cursor_index */
EIF_INTEGER_32 F2151_24342 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("cursor_index", 2150, Current, 0, 1, 29882);
	RTGC;
	RTHOOK(1);
	Result = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	RTHOOK(2);
	ti4_1 = ((EIF_INTEGER_32) -2L);
	if ((EIF_BOOLEAN)(Result == ti4_1)) {
		RTHOOK(3);
		Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
	}
	RTHOOK(4);
	RTHOOK(5);
	RTLE;
	RTEE;
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 1L));
}

/* {DS_ARRAYED_LIST}.cursor_is_first */
EIF_BOOLEAN F2151_24343 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("cursor_is_first", 2150, Current, 0, 1, 29883);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	if ((EIF_BOOLEAN) !F2109_23847(Current)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
		Result = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {DS_ARRAYED_LIST}.cursor_is_last */
EIF_BOOLEAN F2151_24344 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("cursor_is_last", 2150, Current, 0, 1, 29884);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	if ((EIF_BOOLEAN) !F2109_23847(Current)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
		Result = (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) - ((EIF_INTEGER_32) 1L)));
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {DS_ARRAYED_LIST}.cursor_same_position */
EIF_BOOLEAN F2151_24345 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("cursor_same_position", 2150, Current, 0, 2, 29885);
	RTGC;
	RTHOOK(1);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_2_0_0_0_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {DS_ARRAYED_LIST}.cursor_start */
void F2151_24346 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("cursor_start", 2150, Current, 1, 1, 29886);
	RTGC;
	RTHOOK(1);
	loc1 = F2086_23726(RTCW(arg1));
	RTHOOK(2);
	if (F2109_23847(Current)) {
		RTHOOK(3);
		F2104_23796(RTCW(arg1));
	} else {
		RTHOOK(4);
		F2104_23795(RTCW(arg1), ((EIF_INTEGER_32) 0L));
		RTHOOK(5);
		if (loc1) {
			RTHOOK(6);
			F2115_23890(Current, arg1);
		}
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {DS_ARRAYED_LIST}.cursor_finish */
void F2151_24347 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("cursor_finish", 2150, Current, 1, 1, 29887);
	RTGC;
	RTHOOK(1);
	loc1 = F2086_23726(RTCW(arg1));
	RTHOOK(2);
	F2104_23795(RTCW(arg1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) - ((EIF_INTEGER_32) 1L)));
	RTHOOK(3);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) != ((EIF_INTEGER_32) 0L)) && loc1)) {
		RTHOOK(4);
		F2115_23890(Current, arg1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {DS_ARRAYED_LIST}.cursor_forth */
void F2151_24348 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("cursor_forth", 2150, Current, 2, 1, 29888);
	RTGC;
	RTHOOK(1);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	RTHOOK(2);
	loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) -1L));
	RTHOOK(3);
	loc2++;
	RTHOOK(4);
	if ((EIF_BOOLEAN) (loc2 >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_))) {
		RTHOOK(5);
		loc2 = ((EIF_INTEGER_32) -2L);
		RTHOOK(6);
		if ((EIF_BOOLEAN) !loc1) {
			RTHOOK(7);
			F2115_23891(Current, arg1);
		}
	} else {
		RTHOOK(8);
		if (loc1) {
			RTHOOK(9);
			F2115_23890(Current, arg1);
		}
	}
	RTHOOK(10);
	F2104_23795(RTCW(arg1), loc2);
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {DS_ARRAYED_LIST}.cursor_back */
void F2151_24349 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("cursor_back", 2150, Current, 2, 1, 29889);
	RTGC;
	RTHOOK(1);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	RTHOOK(2);
	ti4_1 = ((EIF_INTEGER_32) -2L);
	if ((EIF_BOOLEAN)(loc2 == ti4_1)) {
		RTHOOK(3);
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(4);
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
	} else {
		RTHOOK(5);
		loc2--;
	}
	RTHOOK(6);
	F2104_23795(RTCW(arg1), loc2);
	RTHOOK(7);
	if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) -1L))) {
		RTHOOK(8);
		if ((EIF_BOOLEAN) !loc1) {
			RTHOOK(9);
			F2115_23891(Current, arg1);
		}
	} else {
		RTHOOK(10);
		if (loc1) {
			RTHOOK(11);
			F2115_23890(Current, arg1);
		}
	}
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {DS_ARRAYED_LIST}.cursor_go_after */
void F2151_24352 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("cursor_go_after", 2150, Current, 1, 1, 29892);
	RTGC;
	RTHOOK(1);
	loc1 = F2086_23726(RTCW(arg1));
	RTHOOK(2);
	F2104_23796(RTCW(arg1));
	RTHOOK(3);
	if ((EIF_BOOLEAN) !loc1) {
		RTHOOK(4);
		F2115_23891(Current, arg1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {DS_ARRAYED_LIST}.cursor_go_before */
void F2151_24353 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("cursor_go_before", 2150, Current, 1, 1, 29893);
	RTGC;
	RTHOOK(1);
	loc1 = F2086_23726(RTCW(arg1));
	RTHOOK(2);
	F2104_23795(RTCW(arg1), ((EIF_INTEGER_32) -1L));
	RTHOOK(3);
	if ((EIF_BOOLEAN) !loc1) {
		RTHOOK(4);
		F2115_23891(Current, arg1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {DS_ARRAYED_LIST}.cursor_go_to */
void F2151_24354 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("cursor_go_to", 2150, Current, 1, 2, 29894);
	RTGC;
	RTHOOK(1);
	loc1 = F2086_23726(RTCW(arg1));
	RTHOOK(2);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_2_0_0_0_);
	F2104_23795(RTCW(arg1), ti4_1);
	RTHOOK(3);
	tb1 = F2086_23726(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb1) {
		RTHOOK(4);
		if (loc1) {
			RTHOOK(5);
			F2115_23890(Current, arg1);
		}
	} else {
		RTHOOK(6);
		if ((EIF_BOOLEAN) !loc1) {
			RTHOOK(7);
			F2115_23891(Current, arg1);
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {DS_ARRAYED_LIST}.cursor_go_i_th */
void F2151_24355 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("cursor_go_i_th", 2150, Current, 1, 2, 29895);
	RTGC;
	RTHOOK(1);
	loc1 = F2086_23726(RTCW(arg1));
	RTHOOK(2);
	if ((EIF_BOOLEAN) (arg2 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_))) {
		RTHOOK(3);
		F2104_23796(RTCW(arg1));
		RTHOOK(4);
		if ((EIF_BOOLEAN) !loc1) {
			RTHOOK(5);
			F2115_23891(Current, arg1);
		}
	} else {
		RTHOOK(6);
		F2104_23795(RTCW(arg1), (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)));
		RTHOOK(7);
		if ((EIF_BOOLEAN)(arg2 == ((EIF_INTEGER_32) 0L))) {
			RTHOOK(8);
			if ((EIF_BOOLEAN) !loc1) {
				RTHOOK(9);
				F2115_23891(Current, arg1);
			}
		} else {
			RTHOOK(10);
			if (loc1) {
				RTHOOK(11);
				F2115_23890(Current, arg1);
			}
		}
	}
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {DS_ARRAYED_LIST}.correct_mismatch */
void F2151_24356 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("correct_mismatch", 2150, Current, 2, 0, 29896);
	RTGC;
	RTHOOK(1);
	tb1 = '\01';
	tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(9929,F1133_9929, (Current))) + _REFACS_7_);
	loc2 = tr1;
	if (!((EIF_BOOLEAN) !EIF_TEST(loc2))) {
		tb2 = F1504_14354(loc2);
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(2);
		F2151_24357(Current);
	} else {
		RTHOOK(3);
		tb1 = F1500_14186(loc2);
		if (tb1) {
			RTHOOK(4);
			loc1 = F1500_14220(loc2);
			RTHOOK(5);
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 20130823L))) {
				RTHOOK(6);
				F2151_24357(Current);
			} else {
				RTHOOK(7);
				F1133_9928(Current);
			}
		} else {
			RTHOOK(8);
			F1133_9928(Current);
		}
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {DS_ARRAYED_LIST}.correct_mismatch_20130823 */
void F2151_24357 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("correct_mismatch_20130823", 2150, Current, 0, 0, 29897);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R9818[Dtype(RTCW(tr1))-1257])(tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 0L), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_));
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R9821[Dtype(RTCW(tr1))-1257])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_));
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9797[Dtype(RTCW(tr1))-1257])(tr1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(4);
	RTLE;
	RTEE;
}

void EIF_Minit2203 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
