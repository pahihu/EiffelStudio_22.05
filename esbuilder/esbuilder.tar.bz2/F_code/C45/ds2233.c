/*
 * Code for class DS_LINEAR_CURSOR [CHARACTER_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds2233.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_LINEAR_CURSOR}.new_iterator */
EIF_REFERENCE F2083_23712 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("new_iterator", 2082, Current, 0, 0, 29225);
	RTGC;
	RTHOOK(1);
	Result = (RTNA((RTCV((RTNA((Current)), ((EIF_REFERENCE) 0))))), ((EIF_REFERENCE) 0));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {DS_LINEAR_CURSOR}.is_first */
EIF_BOOLEAN F2083_23713 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("is_first", 2082, Current, 0, 0, 29226);
	RTGC;
	RTHOOK(1);
	tr1 = (RTNA((Current)), ((EIF_REFERENCE) 0));
	Result = (RTNA((RTCW(tr1), Current)), ((EIF_BOOLEAN) 0));
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {DS_LINEAR_CURSOR}.start */
void F2083_23716 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("start", 2082, Current, 0, 0, 29220);
	RTGC;
	RTHOOK(1);
	tr1 = (RTNA((Current)), ((EIF_REFERENCE) 0));
	(RTNA((RTCW(tr1), Current)));
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {DS_LINEAR_CURSOR}.forth */
void F2083_23717 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("forth", 2082, Current, 0, 0, 29221);
	RTGC;
	RTHOOK(1);
	tr1 = (RTNA((Current)), ((EIF_REFERENCE) 0));
	(RTNA((RTCW(tr1), Current)));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {DS_LINEAR_CURSOR}.go_after */
void F2083_23719 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("go_after", 2082, Current, 0, 0, 29223);
	RTGC;
	RTHOOK(1);
	tr1 = (RTNA((Current)), ((EIF_REFERENCE) 0));
	(RTNA((RTCW(tr1), Current)));
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit2233 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
