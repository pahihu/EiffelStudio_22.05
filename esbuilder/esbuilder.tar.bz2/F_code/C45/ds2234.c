/*
 * Code for class DS_CURSOR [CHARACTER_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds2234.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_CURSOR}.item */
EIF_CHARACTER_8 F2077_23696 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("item", 2076, Current, 0, 0, 29193);
	RTGC;
	RTHOOK(1);
	tr1 = (RTNA((Current)), ((EIF_REFERENCE) 0));
	Result = (RTNA((RTCW(tr1), Current)), ((EIF_CHARACTER_8) 0));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {DS_CURSOR}.same_position */
EIF_BOOLEAN F2077_23699 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("same_position", 2076, Current, 0, 1, 29194);
	RTGC;
	RTHOOK(1);
	tr1 = (RTNA((Current)), ((EIF_REFERENCE) 0));
	Result = (RTNA((RTCW(tr1), Current, arg1)), ((EIF_BOOLEAN) 0));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {DS_CURSOR}.go_to */
void F2077_23701 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("go_to", 2076, Current, 0, 1, 29196);
	RTGC;
	RTHOOK(1);
	tr1 = (RTNA((Current)), ((EIF_REFERENCE) 0));
	(RTNA((RTCW(tr1), Current, arg1)));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {DS_CURSOR}.copy */
void F2077_23702 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("copy", 2076, Current, 0, 1, 29197);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if ((EIF_BOOLEAN)((RTNA((Current)), ((EIF_REFERENCE) 0)) != NULL)) {
		tb1 = (EIF_BOOLEAN) !(RTNA((Current)), ((EIF_BOOLEAN) 0));
	}
	if (tb1) {
		RTHOOK(2);
		tr1 = (RTNA((Current)), ((EIF_REFERENCE) 0));
		(RTNA((RTCW(tr1), Current)));
	}
	RTHOOK(3);
	(RTNA((Current, arg1)));
	RTHOOK(4);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) NULL;
	RTHOOK(5);
	if ((EIF_BOOLEAN) !(RTNA((Current)), ((EIF_BOOLEAN) 0))) {
		RTHOOK(6);
		tr1 = (RTNA((Current)), ((EIF_REFERENCE) 0));
		(RTNA((RTCW(tr1), Current)));
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {DS_CURSOR}.is_equal */
EIF_BOOLEAN F2077_23703 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("is_equal", 2076, Current, 0, 1, 29198);
	RTGC;
	RTHOOK(1);
	tr1 = (RTNA((Current)), ((EIF_REFERENCE) 0));
	tb1 = F35_463(RTCW(tr1), Current, arg1);
	if (tb1) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) (RTNA((Current, arg1)), ((EIF_BOOLEAN) 0));
	}
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) 0;
}

/* {DS_CURSOR}.set_next_cursor */
void F2077_23705 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_next_cursor", 2076, Current, 0, 1, 29200);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

void EIF_Minit2234 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
