
#ifndef _C45_ds2237_
#define _C45_ds2237_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F2119_23895(EIF_REFERENCE, EIF_REFERENCE);
extern void F2119_23899(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2237(void);

#ifdef __cplusplus
}
#endif

#endif
