/*
 * Code for class KL_ARRAY_ROUTINES [CHARACTER_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl2238.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_ARRAY_ROUTINES}.cloned_array */
EIF_REFERENCE F1336_12217 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	
	
	RTEAA("cloned_array", 1335, Current, 0, 1, 17186);
	RTHOOK(1);
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (arg1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) tr1;
}

/* {KL_ARRAY_ROUTINES}.subcopy */
void F1336_12218 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("subcopy", 1335, Current, 1, 5, 17187);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) (arg3 <= arg4)) {
		RTHOOK(2);
		F930_9435(RTCW(arg1), arg2, arg3, arg4, arg5);
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

void EIF_Minit2238 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
