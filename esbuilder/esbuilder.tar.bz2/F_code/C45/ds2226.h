
#ifndef _C45_ds2226_
#define _C45_ds2226_

#ifdef __cplusplus
extern "C" {
#endif

extern void F2144_24216(EIF_REFERENCE);
extern EIF_REFERENCE F2144_24221(EIF_REFERENCE);
extern EIF_INTEGER_32 F2144_24222(EIF_REFERENCE);
extern void F2144_24224(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F2144_24225(EIF_REFERENCE, EIF_REFERENCE);
extern void F2144_24227(EIF_REFERENCE, EIF_REFERENCE);
extern void F2144_24230(EIF_REFERENCE);
extern void F2144_24233(EIF_REFERENCE);
extern void EIF_Minit2226(void);
extern EIF_BOOLEAN F35_463(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1329_12111(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,12111)
extern char *(*R4728[])();
extern char *(*R18483[])();
extern char *(*R4731[])();
extern char *(*R4738[])();
extern long O4737[];
extern EIF_TYPE_INDEX Y18490[];
extern EIF_TYPE_INDEX *Y18490_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
