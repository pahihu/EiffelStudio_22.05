/*
 * Code for class CELL [BOOLEAN]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ce2201.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CELL}.item */
EIF_BOOLEAN F365_5874 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current + O5375[Dtype(Current)-361]);
}


/* {CELL}.put */
void F365_5875 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("put", 364, Current, 0, 1, 5704);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O5375[Dtype(Current)-361]) = (EIF_BOOLEAN) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CELL}.replace */
void F365_5876 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("replace", 364, Current, 0, 1, 5705);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current + O5375[Dtype(Current)-361]) = (EIF_BOOLEAN) arg1;
	RTHOOK(3);
	RTEE;
}

void EIF_Minit2201 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
