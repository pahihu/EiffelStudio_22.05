/*
 * Code for class DS_TRAVERSABLE [CHARACTER_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds2235.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_TRAVERSABLE}.item_for_iteration */
EIF_CHARACTER_8 F2116_23878 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("item_for_iteration", 2115, Current, 0, 0, 29417);
	RTGC;
	RTHOOK(1);
	Result = (RTNA((Current, (RTNA((Current)), ((EIF_REFERENCE) 0)))), ((EIF_CHARACTER_8) 0));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {DS_TRAVERSABLE}.off */
EIF_BOOLEAN F2116_23880 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("off", 2115, Current, 0, 0, 29418);
	RTGC;
	RTHOOK(1);
	Result = (RTNA((Current, (RTNA((Current)), ((EIF_REFERENCE) 0)))), ((EIF_BOOLEAN) 0));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {DS_TRAVERSABLE}.valid_cursor */
EIF_BOOLEAN F2116_23882 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("valid_cursor", 2115, Current, 0, 1, 29420);
	RTGC;
	RTHOOK(1);
	tr1 = (RTNA((RTCW(arg1))), ((EIF_REFERENCE) 0));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 == Current);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {DS_TRAVERSABLE}.go_to */
void F2116_23883 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("go_to", 2115, Current, 0, 1, 29421);
	RTGC;
	RTHOOK(1);
	(RTNA((Current, (RTNA((Current)), ((EIF_REFERENCE) 0)), arg1)));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {DS_TRAVERSABLE}.cursor_off */
EIF_BOOLEAN F2116_23887 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	
	
	RTEAA("cursor_off", 2115, Current, 0, 1, 29422);
	RTHOOK(1);
	tb1 = (RTNA((RTCW(arg1))), ((EIF_BOOLEAN) 0));
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) tb1;
}

/* {DS_TRAVERSABLE}.add_traversing_cursor */
void F2116_23890 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("add_traversing_cursor", 2115, Current, 0, 1, 29423);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != (RTNA((Current)), ((EIF_REFERENCE) 0)))) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(RTCV((RTNA((Current)), ((EIF_REFERENCE) 0))));
		(RTNA((RTCW(arg1), tr1)));
		RTHOOK(3);
		tr1 = (RTNA((Current)), ((EIF_REFERENCE) 0));
		(RTNA((RTCW(tr1), arg1)));
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {DS_TRAVERSABLE}.remove_traversing_cursor */
void F2116_23891 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,loc2);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,Current);
	RTLIU(5);
	
	RTEAA("remove_traversing_cursor", 2115, Current, 2, 1, 29424);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != (RTNA((Current)), ((EIF_REFERENCE) 0)))) {
		RTHOOK(2);
		loc2 = (RTNA((Current)), ((EIF_REFERENCE) 0));
		RTHOOK(3);
		loc1 = *(EIF_REFERENCE *)(RTCW(loc2));
		for (;;) {
			RTHOOK(4);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == arg1) || (EIF_BOOLEAN)(loc1 == NULL))) break;
			RTHOOK(5);
			loc2 = (EIF_REFERENCE) loc1;
			RTHOOK(6);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			loc1 = (EIF_REFERENCE) tr1;
		}
		RTHOOK(7);
		if ((EIF_BOOLEAN)(loc1 == arg1)) {
			RTHOOK(8);
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			(RTNA((RTCW(loc2), tr1)));
			RTHOOK(9);
			(RTNA((RTCW(arg1), NULL)));
		}
	}
	RTHOOK(10);
	RTLE;
	RTEE;
}

void EIF_Minit2235 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
