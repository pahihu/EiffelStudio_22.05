
#ifndef _C45_ds2247_
#define _C45_ds2247_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F2094_23757(EIF_REFERENCE);
extern void EIF_Minit2247(void);

#ifdef __cplusplus
}
#endif

#endif
