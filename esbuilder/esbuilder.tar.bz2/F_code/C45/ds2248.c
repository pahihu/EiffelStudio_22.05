/*
 * Code for class DS_SPARSE_CONTAINER_CURSOR [G#1, G#2]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds2248.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_SPARSE_CONTAINER_CURSOR}.make */
void F2092_23742 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("make", 2091, Current, 0, 1, 29279);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -2L);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {DS_SPARSE_CONTAINER_CURSOR}.container */
EIF_REFERENCE F2092_23743 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


/* {DS_SPARSE_CONTAINER_CURSOR}.after */
EIF_BOOLEAN F2092_23744 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("after", 2091, Current, 0, 0, 29281);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) == ((EIF_INTEGER_32) -3L));
}

/* {DS_SPARSE_CONTAINER_CURSOR}.before */
EIF_BOOLEAN F2092_23745 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("before", 2091, Current, 0, 0, 29282);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) == ((EIF_INTEGER_32) -2L));
}

/* {DS_SPARSE_CONTAINER_CURSOR}.off */
EIF_BOOLEAN F2092_23746 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("off", 2091, Current, 0, 0, 29268);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) < ((EIF_INTEGER_32) 0L));
}

/* {DS_SPARSE_CONTAINER_CURSOR}.set_position */
void F2092_23748 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_position", 2091, Current, 0, 1, 29270);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) = (EIF_INTEGER_32) arg1;
	RTHOOK(3);
	RTEE;
}

/* {DS_SPARSE_CONTAINER_CURSOR}.set_after */
void F2092_23749 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_after", 2091, Current, 0, 0, 29271);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -3L);
	RTHOOK(3);
	RTEE;
}

/* {DS_SPARSE_CONTAINER_CURSOR}.set_before */
void F2092_23750 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_before", 2091, Current, 0, 0, 29272);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -2L);
	RTHOOK(3);
	RTEE;
}

/* {DS_SPARSE_CONTAINER_CURSOR}.correct_mismatch */
void F2092_23755 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("correct_mismatch", 2091, Current, 2, 0, 29277);
	RTGC;
	RTHOOK(1);
	tb1 = '\01';
	tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(9929,F1133_9929, (Current))) + _REFACS_7_);
	loc2 = tr1;
	if (!((EIF_BOOLEAN) !EIF_TEST(loc2))) {
		tb2 = F1504_14354(loc2);
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(2);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R18421[dtype-2091])(Current);
	} else {
		RTHOOK(3);
		tb1 = F1500_14186(loc2);
		if (tb1) {
			RTHOOK(4);
			loc1 = F1500_14220(loc2);
			RTHOOK(5);
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 20130823L))) {
				RTHOOK(6);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R18421[dtype-2091])(Current);
			} else {
				RTHOOK(7);
				F1133_9928(Current);
			}
		} else {
			RTHOOK(8);
			F1133_9928(Current);
		}
	}
	RTHOOK(9);
	RTLE;
	RTEE;
}

/* {DS_SPARSE_CONTAINER_CURSOR}.correct_mismatch_20130823 */
void F2092_23756 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("correct_mismatch_20130823", 2091, Current, 0, 0, 29278);
	RTHOOK(1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_))--;
	RTHOOK(2);
	RTEE;
}

void EIF_Minit2248 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
