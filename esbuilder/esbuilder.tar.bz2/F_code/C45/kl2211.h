
#ifndef _C45_kl2211_
#define _C45_kl2211_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F155_2227(EIF_REFERENCE);
extern void EIF_Minit2211(void);
extern long O2214[];

#ifdef __cplusplus
}
#endif

#endif
