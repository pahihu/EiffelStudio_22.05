/*
 * Code for class DS_LINKABLE [CHARACTER_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds2228.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_LINKABLE}.put_right */
void F311_4874 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("put_right", 310, Current, 0, 1, 4868);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {DS_LINKABLE}.forget_right */
void F311_4875 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("forget_right", 310, Current, 0, 0, 4869);
	RTHOOK(1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) NULL;
	RTHOOK(3);
	RTEE;
}

void EIF_Minit2228 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
