/*
 * Code for class DS_SPARSE_SET [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds2246.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_SPARSE_SET}.make_equal */
void F2161_24565 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make_equal", 2160, Current, 0, 1, 30273);
	RTGC;
	RTHOOK(1);
	F2153_24390(Current, arg1);
	RTHOOK(2);
	tr1 = RTLNSMART(eif_final_id(Y18532,Y18532_gen_type,Dftype(Current),2117).id);
	F1_29(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {DS_SPARSE_SET}.make_default */
void F2161_24566 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make_default", 2160, Current, 0, 0, 30240);
	RTGC;
	RTHOOK(1);
	ti4_1 = F2149_24273(Current);
	F2153_24390(Current, ti4_1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {DS_SPARSE_SET}.item */
EIF_REFERENCE F2161_24568 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("item", 2160, Current, 0, 1, 30242);
	RTGC;
	RTHOOK(1);
	tr1 = RTCCL(arg1);
	F2153_24423(Current, tr1);
	
	RTHOOK(3);
	RTHOOK(4);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) F2162_24600(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_));
}

/* {DS_SPARSE_SET}.has */
EIF_BOOLEAN F2161_24570 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("has", 2160, Current, 0, 1, 30244);
	RTGC;
	RTHOOK(1);
	tr1 = RTCCL(arg1);
	F2153_24423(Current, tr1);
	RTHOOK(2);
	RTHOOK(3);
	RTLE;
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_) != ((EIF_INTEGER_32) -1L));
}

/* {DS_SPARSE_SET}.search */
void F2161_24574 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("search", 2160, Current, 0, 1, 30248);
	RTGC;
	RTHOOK(1);
	tr1 = RTCCL(arg1);
	F2153_24423(Current, tr1);
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_6_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_);
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {DS_SPARSE_SET}.is_equal */
EIF_BOOLEAN F2161_24575 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("is_equal", 2160, Current, 2, 1, 30249);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(Current == arg1)) {
		RTHOOK(2);
		RTHOOK(3);
		RTLE;
		RTEE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		RTHOOK(4);
		tb1 = '\0';
		tb2 = '\0';
		tr1 = RTOSCF(12111,F1329_12111, (Current));
		tb3 = F35_463(RTCW(tr1), Current, arg1);
		if (tb3) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_7_0_0_8_);
			tb2 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_) == ti4_1);
		}
		if (tb2) {
			tb1 = F2118_23895(Current, arg1);
		}
		if (tb1) {
			RTHOOK(5);
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_);
			RTHOOK(6);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			for (;;) {
				RTHOOK(7);
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 0L)))) break;
				RTHOOK(8);
				if ((EIF_BOOLEAN) (F2162_24601(Current, loc2) > ((EIF_INTEGER_32) -2L))) {
					RTHOOK(9);
					loc1 = F2162_24600(Current, loc2);
					RTHOOK(10);
					tr1 = RTCCL(loc1);
					Result = F2161_24570(RTCW(arg1), tr1);
				}
				RTHOOK(11);
				loc2--;
			}
		}
	}
	RTHOOK(12);
	RTLE;
	RTEE;
	return Result;
}

/* {DS_SPARSE_SET}.force */
void F2161_24579 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("force", 2160, Current, 2, 1, 30253);
	RTGC;
	RTHOOK(1);
	F2153_24409(Current);
	RTHOOK(2);
	tr1 = RTCCL(arg1);
	F2153_24423(Current, tr1);
	RTHOOK(3);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_) != ((EIF_INTEGER_32) -1L))) {
		RTHOOK(4);
		tr1 = RTCCL(arg1);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_);
		F2162_24604(Current, tr1, ti4_1);
	} else {
		RTHOOK(5);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_7_))) {
			RTHOOK(6);
			ti4_1 = F2153_24479(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_) + ((EIF_INTEGER_32) 1L)));
			F2153_24414(Current, ti4_1);
			RTHOOK(7);
			tr1 = RTCCL(arg1);
			loc2 = F2163_24628(Current, tr1);
		} else {
			RTHOOK(8);
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_4_);
		}
		RTHOOK(9);
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_2_);
		RTHOOK(10);
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) {
			RTHOOK(11);
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_))++;
			RTHOOK(12);
			loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_);
		} else {
			RTHOOK(13);
			ti4_1 = F2162_24601(Current, loc1);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_2_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) -3L) - ti4_1);
		}
		RTHOOK(14);
		ti4_1 = F2162_24617(Current, loc2);
		F2162_24611(Current, ti4_1, loc1);
		RTHOOK(15);
		F2162_24618(Current, loc1, loc2);
		RTHOOK(16);
		tr1 = RTCCL(arg1);
		F2162_24604(Current, tr1, loc1);
		RTHOOK(17);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_))++;
	}
	RTHOOK(18);
	RTLE;
	RTEE;
}

/* {DS_SPARSE_SET}.force_new */
void F2161_24580 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("force_new", 2160, Current, 2, 1, 30254);
	RTGC;
	RTHOOK(1);
	F2153_24409(Current);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_7_))) {
		RTHOOK(3);
		ti4_1 = F2153_24479(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_) + ((EIF_INTEGER_32) 1L)));
		F2153_24414(Current, ti4_1);
	}
	RTHOOK(4);
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_2_);
	RTHOOK(5);
	if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) {
		RTHOOK(6);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_))++;
		RTHOOK(7);
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_);
	} else {
		RTHOOK(8);
		ti4_1 = F2162_24601(Current, loc1);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_2_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) -3L) - ti4_1);
	}
	RTHOOK(9);
	tr1 = RTCCL(arg1);
	loc2 = F2163_24628(Current, tr1);
	RTHOOK(10);
	ti4_1 = F2162_24617(Current, loc2);
	F2162_24611(Current, ti4_1, loc1);
	RTHOOK(11);
	F2162_24618(Current, loc1, loc2);
	RTHOOK(12);
	tr1 = RTCCL(arg1);
	F2162_24604(Current, tr1, loc1);
	RTHOOK(13);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_))++;
	RTHOOK(14);
	RTLE;
	RTEE;
}

/* {DS_SPARSE_SET}.force_last */
void F2161_24581 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("force_last", 2160, Current, 2, 1, 30255);
	RTGC;
	RTHOOK(1);
	F2153_24409(Current);
	RTHOOK(2);
	tr1 = RTCCL(arg1);
	F2153_24423(Current, tr1);
	RTHOOK(3);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_) != ((EIF_INTEGER_32) -1L))) {
		RTHOOK(4);
		tr1 = RTCCL(arg1);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_);
		F2162_24604(Current, tr1, ti4_1);
	} else {
		RTHOOK(5);
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
		RTHOOK(6);
		if ((EIF_BOOLEAN) (loc1 >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_7_))) {
			RTHOOK(7);
			ti4_1 = F2153_24479(Current, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
			F2153_24414(Current, ti4_1);
			RTHOOK(8);
			tr1 = RTCCL(arg1);
			loc2 = F2163_24628(Current, tr1);
		} else {
			RTHOOK(9);
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_4_);
		}
		RTHOOK(10);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_) = (EIF_INTEGER_32) loc1;
		RTHOOK(11);
		ti4_1 = F2162_24617(Current, loc2);
		F2162_24611(Current, ti4_1, loc1);
		RTHOOK(12);
		F2162_24618(Current, loc1, loc2);
		RTHOOK(13);
		tr1 = RTCCL(arg1);
		F2162_24604(Current, tr1, loc1);
		RTHOOK(14);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_))++;
	}
	RTHOOK(16);
	RTLE;
	RTEE;
}

/* {DS_SPARSE_SET}.key_storage_item */
EIF_REFERENCE F2161_24590 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("key_storage_item", 2160, Current, 0, 1, 30264);
	RTGC;
	RTHOOK(1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) F2162_24600(Current, arg1);
}

/* {DS_SPARSE_SET}.key_equality_tester */
EIF_REFERENCE F2161_24591 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("key_equality_tester", 2160, Current, 0, 0, 30265);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current);
}

/* {DS_SPARSE_SET}.make_key_storage */
void F2161_24593 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("make_key_storage", 2160, Current, 0, 1, 30267);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {DS_SPARSE_SET}.clone_key_storage */
void F2161_24595 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("clone_key_storage", 2160, Current, 0, 0, 30269);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {DS_SPARSE_SET}.key_storage_resize */
void F2161_24596 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("key_storage_resize", 2160, Current, 0, 1, 30270);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

/* {DS_SPARSE_SET}.key_storage_wipe_out */
void F2161_24597 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("key_storage_wipe_out", 2160, Current, 0, 0, 30271);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

void EIF_Minit2246 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
