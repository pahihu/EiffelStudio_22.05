
#ifndef _C45_ds2233_
#define _C45_ds2233_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F2083_23712(EIF_REFERENCE);
extern EIF_BOOLEAN F2083_23713(EIF_REFERENCE);
extern void F2083_23716(EIF_REFERENCE);
extern void F2083_23717(EIF_REFERENCE);
extern void F2083_23719(EIF_REFERENCE);
extern void EIF_Minit2233(void);

#ifdef __cplusplus
}
#endif

#endif
