/*
 * Code for class KL_CELL [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl2211.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_CELL}.item */
EIF_REFERENCE F155_2227 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O2214[Dtype(Current)-154]);
}


void EIF_Minit2211 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
