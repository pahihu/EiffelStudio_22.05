/*
 * Code for class CELL [NATURAL_64]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ce2200.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CELL}.item */
EIF_NATURAL_64 F364_5874 (EIF_REFERENCE Current)
{
	return *(EIF_NATURAL_64 *)(Current+ _I64OFF_0_0_0_0_0_0_0_);
}


/* {CELL}.put */
void F364_5875 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("put", 363, Current, 0, 1, 5701);
	RTHOOK(1);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_0_0_0_0_0_0_0_) = (EIF_NATURAL_64) arg1;
	RTHOOK(3);
	RTEE;
}

/* {CELL}.replace */
void F364_5876 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("replace", 363, Current, 0, 1, 5702);
	RTHOOK(1);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_0_0_0_0_0_0_0_) = (EIF_NATURAL_64) arg1;
	RTHOOK(3);
	RTEE;
}

void EIF_Minit2200 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
