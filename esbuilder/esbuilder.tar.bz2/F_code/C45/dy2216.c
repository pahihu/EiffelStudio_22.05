/*
 * Code for class DYNAMIC_TABLE [INTEGER_32, G#2]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "dy2216.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DYNAMIC_TABLE}.prunable */
EIF_BOOLEAN F777_9256 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("prunable", 776, Current, 0, 0, 9473);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

void EIF_Minit2216 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
