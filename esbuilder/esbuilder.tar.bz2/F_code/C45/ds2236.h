
#ifndef _C45_ds2236_
#define _C45_ds2236_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F2110_23847(EIF_REFERENCE);
extern void EIF_Minit2236(void);

#ifdef __cplusplus
}
#endif

#endif
