/*
 * Code for class DS_RESIZABLE [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds2204.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_RESIZABLE}.default_capacity */
EIF_INTEGER_32 F2149_24273 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("default_capacity", 2148, Current, 0, 0, 29819);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
}

/* {DS_RESIZABLE}.new_capacity */
EIF_INTEGER_32 F2149_24276 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("new_capacity", 2148, Current, 0, 1, 29821);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)) * ((EIF_INTEGER_32) 3L)) / ((EIF_INTEGER_32) 2L));
}

void EIF_Minit2204 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
