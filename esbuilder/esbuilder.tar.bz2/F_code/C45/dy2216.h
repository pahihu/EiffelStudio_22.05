
#ifndef _C45_dy2216_
#define _C45_dy2216_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F777_9256(EIF_REFERENCE);
extern void EIF_Minit2216(void);

#ifdef __cplusplus
}
#endif

#endif
