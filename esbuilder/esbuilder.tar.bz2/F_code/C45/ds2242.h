
#ifndef _C45_ds2242_
#define _C45_ds2242_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F2163_24625(EIF_REFERENCE);
extern EIF_INTEGER_32 F2163_24628(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit2242(void);
extern void F2092_23742(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R10517[])();
extern EIF_TYPE_INDEX Y18490[];
extern EIF_TYPE_INDEX *Y18490_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
