/*
 * Code for class DS_LINEAR [CHARACTER_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds2232.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_LINEAR}.new_iterator */
EIF_REFERENCE F2122_23902 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("new_iterator", 2121, Current, 0, 0, 29462);
	RTGC;
	RTHOOK(1);
	Result = (RTNA((Current)), ((EIF_REFERENCE) 0));
	RTHOOK(2);
	(RTNA((RTCW(Result))));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {DS_LINEAR}.start */
void F2122_23907 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("start", 2121, Current, 0, 0, 29467);
	RTGC;
	RTHOOK(1);
	(RTNA((Current, (RTNA((Current)), ((EIF_REFERENCE) 0)))));
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {DS_LINEAR}.forth */
void F2122_23908 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("forth", 2121, Current, 0, 0, 29468);
	RTGC;
	RTHOOK(1);
	(RTNA((Current, (RTNA((Current)), ((EIF_REFERENCE) 0)))));
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit2232 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
