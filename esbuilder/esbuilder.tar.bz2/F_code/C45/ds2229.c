/*
 * Code for class DS_CELL [CHARACTER_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds2229.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_CELL}.item */
EIF_CHARACTER_8 F308_4865 (EIF_REFERENCE Current)
{
	return *(EIF_CHARACTER_8 *)(Current + O4728[Dtype(Current)-306]);
}


/* {DS_CELL}.put */
void F308_4867 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("put", 307, Current, 0, 1, 4856);
	RTHOOK(1);
	*(EIF_CHARACTER_8 *)(Current + O4728[Dtype(Current)-306]) = (EIF_CHARACTER_8) arg1;
	RTHOOK(3);
	RTEE;
}

/* {DS_CELL}.make */
void F308_4868 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("make", 307, Current, 0, 1, 4857);
	RTHOOK(1);
	*(EIF_CHARACTER_8 *)(Current + O4728[Dtype(Current)-306]) = (EIF_CHARACTER_8) arg1;
	RTHOOK(3);
	RTEE;
}

void EIF_Minit2229 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
