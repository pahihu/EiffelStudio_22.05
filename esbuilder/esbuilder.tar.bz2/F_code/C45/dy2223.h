
#ifndef _C45_dy2223_
#define _C45_dy2223_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F779_9256(EIF_REFERENCE);
extern void EIF_Minit2223(void);

#ifdef __cplusplus
}
#endif

#endif
