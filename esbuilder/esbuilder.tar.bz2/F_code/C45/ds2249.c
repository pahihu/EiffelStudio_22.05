/*
 * Code for class DS_SPARSE_CONTAINER [G#1, G#2]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds2249.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_SPARSE_CONTAINER}.make */
void F2153_24390 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("make", 2152, Current, 0, 1, 29973);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O18770[dtype-2152]) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R18733[dtype-2158])(Current, arg1);
	RTHOOK(3);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R18738[dtype-2158])(Current, arg1);
	RTHOOK(4);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R18744[dtype-2158])(Current, arg1);
	RTHOOK(5);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R18768[dtype-2158])(Current, arg1);
	*(EIF_INTEGER_32 *)(Current + O18755[dtype-2152]) = (EIF_INTEGER_32) ti4_1;
	RTHOOK(6);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R18749[dtype-2158])(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O18755[dtype-2152]) + ((EIF_INTEGER_32) 1L)));
	RTHOOK(7);
	*(EIF_INTEGER_32 *)(Current + O18720[dtype-2152]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTHOOK(8);
	*(EIF_INTEGER_32 *)(Current + O18756[dtype-2152]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTHOOK(9);
	*(EIF_INTEGER_32 *)(Current + O18757[dtype-2152]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTHOOK(10);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R18716[dtype-2158])(Current);
	RTHOOK(11);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R18513[dtype-2125])(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R18518[dtype-2125])(Current, tr1);
	RTHOOK(15);
	RTLE;
	RTEE;
}

/* {DS_SPARSE_CONTAINER}.found_item */
EIF_REFERENCE F2153_24391 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("found_item", 2152, Current, 0, 0, 29974);
	RTGC;
	RTHOOK(1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return (EIF_REFERENCE) (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R18721[dtype-2158])(Current, *(EIF_INTEGER_32 *)(Current + O18760[dtype-2152]));
}

/* {DS_SPARSE_CONTAINER}.count */
EIF_INTEGER_32 F2153_24395 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O18771[Dtype(Current)-2152]);
}


/* {DS_SPARSE_CONTAINER}.capacity */
EIF_INTEGER_32 F2153_24396 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O18770[Dtype(Current)-2152]);
}


/* {DS_SPARSE_CONTAINER}.found */
EIF_BOOLEAN F2153_24399 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("found", 2152, Current, 0, 0, 29982);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O18760[Dtype(Current)-2152]) != ((EIF_INTEGER_32) -1L));
}

/* {DS_SPARSE_CONTAINER}.unset_found_item */
void F2153_24409 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("unset_found_item", 2152, Current, 0, 0, 29992);
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O18760[Dtype(Current)-2152]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTHOOK(4);
	RTEE;
}

/* {DS_SPARSE_CONTAINER}.copy */
void F2153_24410 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("copy", 2152, Current, 1, 1, 29993);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		RTHOOK(2);
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		RTHOOK(3);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R18764[dtype-2158])(Current);
		RTHOOK(4);
		eif_builtin_ANY_standard_copy__o_ (Current, arg1);
		RTHOOK(5);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R18516[dtype-2125])(Current, loc1);
		}
		if (tb1) {
			RTHOOK(6);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R18518[dtype-2125])(Current, loc1);
		} else {
			RTHOOK(7);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R18513[dtype-2125])(Current);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R18518[dtype-2125])(Current, tr1);
		}
		RTHOOK(8);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R18716[dtype-2158])(Current);
		RTHOOK(9);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R18734[dtype-2158])(Current);
		RTHOOK(10);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R18740[dtype-2158])(Current);
		RTHOOK(11);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R18752[dtype-2158])(Current);
		RTHOOK(12);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R18746[dtype-2158])(Current);
	}
	RTHOOK(13);
	RTLE;
	RTEE;
}

/* {DS_SPARSE_CONTAINER}.wipe_out */
void F2153_24413 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("wipe_out", 2152, Current, 0, 0, 29996);
	RTGC;
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R18764[dtype-2158])(Current);
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R18716[dtype-2158])(Current);
	RTHOOK(3);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O18771[dtype-2152]) > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(4);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R18736[dtype-2158])(Current);
		RTHOOK(5);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R18742[dtype-2158])(Current);
		RTHOOK(6);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R18748[dtype-2158])(Current);
		RTHOOK(7);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R18754[dtype-2158])(Current);
		RTHOOK(8);
		*(EIF_INTEGER_32 *)(Current + O18720[dtype-2152]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		RTHOOK(9);
		*(EIF_INTEGER_32 *)(Current + O18756[dtype-2152]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		RTHOOK(10);
		*(EIF_INTEGER_32 *)(Current + O18771[dtype-2152]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	}
	RTHOOK(11);
	*(EIF_INTEGER_32 *)(Current + O18757[dtype-2152]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {DS_SPARSE_CONTAINER}.resize */
void F2153_24414 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("resize", 2152, Current, 3, 1, 29997);
	RTGC;
	RTHOOK(1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R18716[dtype-2158])(Current);
	RTHOOK(2);
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R18768[dtype-2158])(Current, arg1);
	RTHOOK(3);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R18753[dtype-2158])(Current, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
	RTHOOK(4);
	loc2 = *(EIF_INTEGER_32 *)(Current + O18755[dtype-2152]);
	for (;;) {
		RTHOOK(5);
		if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 0L))) break;
		RTHOOK(6);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R18751[dtype-2158])(Current, ((EIF_INTEGER_32) -1L), loc2);
		RTHOOK(7);
		loc2--;
	}
	RTHOOK(8);
	*(EIF_INTEGER_32 *)(Current + O18755[dtype-2152]) = (EIF_INTEGER_32) loc1;
	RTHOOK(9);
	loc2 = *(EIF_INTEGER_32 *)(Current + O18720[dtype-2152]);
	for (;;) {
		RTHOOK(10);
		if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 0L))) break;
		RTHOOK(11);
		if ((EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R18724[dtype-2158])(Current, loc2) > ((EIF_INTEGER_32) -2L))) {
			RTHOOK(12);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R18723[dtype-2158])(Current, loc2);
			tr2 = RTCCL(tr1);
			loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R18731[dtype-2158])(Current, tr2);
			RTHOOK(13);
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R18750[dtype-2158])(Current, loc3);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R18745[dtype-2158])(Current, ti4_1, loc2);
			RTHOOK(14);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R18751[dtype-2158])(Current, loc2, loc3);
		}
		RTHOOK(15);
		loc2--;
	}
	RTHOOK(16);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R18735[dtype-2158])(Current, arg1);
	RTHOOK(17);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R18741[dtype-2158])(Current, arg1);
	RTHOOK(18);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R18747[dtype-2158])(Current, arg1);
	RTHOOK(19);
	*(EIF_INTEGER_32 *)(Current + O18770[dtype-2152]) = (EIF_INTEGER_32) arg1;
	RTHOOK(20);
	*(EIF_INTEGER_32 *)(Current + O18757[dtype-2152]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTHOOK(21);
	RTLE;
	RTEE;
}

/* {DS_SPARSE_CONTAINER}.search_position */
void F2153_24423 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc5);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTEAA("search_position", 2152, Current, 5, 1, 30002);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		RTHOOK(2);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R18750[dtype-2158])(Current, *(EIF_INTEGER_32 *)(Current + O18755[dtype-2152]));
		*(EIF_INTEGER_32 *)(Current + O18757[dtype-2152]) = (EIF_INTEGER_32) ti4_1;
		RTHOOK(3);
		*(EIF_INTEGER_32 *)(Current + O18758[dtype-2152]) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current + O18755[dtype-2152]);
		RTHOOK(4);
		*(EIF_INTEGER_32 *)(Current + O18759[dtype-2152]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	} else {
		RTHOOK(5);
		loc3 = *(EIF_INTEGER_32 *)(Current + O18757[dtype-2152]);
		RTHOOK(6);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R18729[dtype-2158])(Current);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			RTHOOK(7);
			loc4 = *(EIF_INTEGER_32 *)(Current + O18758[dtype-2152]);
			RTHOOK(8);
			loc2 = *(EIF_INTEGER_32 *)(Current + O18759[dtype-2152]);
			RTHOOK(9);
			tb1 = '\01';
			tb2 = '\01';
			if (!(EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) -1L))) {
				tb2 = (EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R18724[dtype-2158])(Current, loc3) <= ((EIF_INTEGER_32) -2L));
			}
			if (!tb2) {
				tr1 = RTCCL(arg1);
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R18723[dtype-2158])(Current, loc3);
				tr3 = RTCCL(tr2);
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5389[Dtype(loc5)-370])(loc5, tr1, tr3);
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				RTHOOK(10);
				tr1 = RTCCL(arg1);
				loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R18731[dtype-2158])(Current, tr1);
				RTHOOK(11);
				loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R18750[dtype-2158])(Current, loc4);
				RTHOOK(12);
				loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				RTHOOK(13);
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				for (;;) {
					RTHOOK(14);
					if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) break;
					RTHOOK(15);
					tr1 = RTCCL(arg1);
					tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R18723[dtype-2158])(Current, loc1);
					tr3 = RTCCL(tr2);
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5389[Dtype(loc5)-370])(loc5, tr1, tr3);
					if (tb1) {
						RTHOOK(16);
						loc3 = (EIF_INTEGER_32) loc1;
						RTHOOK(17);
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						RTHOOK(18);
						loc2 = (EIF_INTEGER_32) loc1;
						RTHOOK(19);
						ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R18724[dtype-2158])(Current, loc1);
						loc1 = (EIF_INTEGER_32) ti4_1;
					}
				}
			}
			RTHOOK(20);
			*(EIF_INTEGER_32 *)(Current + O18757[dtype-2152]) = (EIF_INTEGER_32) loc3;
			RTHOOK(21);
			*(EIF_INTEGER_32 *)(Current + O18758[dtype-2152]) = (EIF_INTEGER_32) loc4;
			RTHOOK(22);
			*(EIF_INTEGER_32 *)(Current + O18759[dtype-2152]) = (EIF_INTEGER_32) loc2;
		} else {
			RTHOOK(23);
			tb1 = '\01';
			tb2 = '\01';
			if (!(EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) -1L))) {
				tb2 = (EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R18724[dtype-2158])(Current, loc3) <= ((EIF_INTEGER_32) -2L));
			}
			if (!tb2) {
				tb1 = !RTCEQ(arg1, (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R18723[dtype-2158])(Current, loc3));
			}
			if (tb1) {
				RTHOOK(24);
				tr1 = RTCCL(arg1);
				loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R18731[dtype-2158])(Current, tr1);
				RTHOOK(25);
				loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R18750[dtype-2158])(Current, loc4);
				RTHOOK(26);
				loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				RTHOOK(27);
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				for (;;) {
					RTHOOK(28);
					if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) break;
					RTHOOK(29);
					if (RTCEQ(arg1, (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R18723[dtype-2158])(Current, loc1))) {
						RTHOOK(30);
						loc3 = (EIF_INTEGER_32) loc1;
						RTHOOK(31);
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						RTHOOK(32);
						loc2 = (EIF_INTEGER_32) loc1;
						RTHOOK(33);
						ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R18724[dtype-2158])(Current, loc1);
						loc1 = (EIF_INTEGER_32) ti4_1;
					}
				}
				RTHOOK(34);
				*(EIF_INTEGER_32 *)(Current + O18757[dtype-2152]) = (EIF_INTEGER_32) loc3;
				RTHOOK(35);
				*(EIF_INTEGER_32 *)(Current + O18758[dtype-2152]) = (EIF_INTEGER_32) loc4;
				RTHOOK(36);
				*(EIF_INTEGER_32 *)(Current + O18759[dtype-2152]) = (EIF_INTEGER_32) loc2;
			}
		}
	}
	RTHOOK(40);
	RTLE;
	RTEE;
}

/* {DS_SPARSE_CONTAINER}.set_internal_cursor */
void F2153_24460 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_internal_cursor", 2152, Current, 0, 1, 29951);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

/* {DS_SPARSE_CONTAINER}.internal_cursor */
EIF_REFERENCE F2153_24461 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


/* {DS_SPARSE_CONTAINER}.move_all_cursors_after */
void F2153_24462 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTEAA("move_all_cursors_after", 2152, Current, 2, 0, 29953);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	for (;;) {
		RTHOOK(2);
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		RTHOOK(3);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R18416[Dtype(RTCW(loc1))-2091])(loc1);
		RTHOOK(4);
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
		RTHOOK(5);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R18389[Dtype(RTCW(loc1))-2087])(loc1, NULL);
		RTHOOK(6);
		loc1 = (EIF_REFERENCE) loc2;
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {DS_SPARSE_CONTAINER}.cursor_item */
EIF_REFERENCE F2153_24466 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("cursor_item", 2152, Current, 0, 1, 29957);
	RTGC;
	RTHOOK(1);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R18721[Dtype(Current)-2158])(Current, ti4_1);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {DS_SPARSE_CONTAINER}.cursor_is_first */
EIF_BOOLEAN F2153_24467 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("cursor_is_first", 2152, Current, 1, 1, 29958);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R18482[dtype-2125])(Current)) {
		RTHOOK(2);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		for (;;) {
			RTHOOK(3);
			if ((EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R18724[dtype-2158])(Current, loc1) > ((EIF_INTEGER_32) -2L))) break;
			RTHOOK(4);
			loc1++;
		}
		RTHOOK(5);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == loc1);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {DS_SPARSE_CONTAINER}.cursor_is_last */
EIF_BOOLEAN F2153_24468 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("cursor_is_last", 2152, Current, 1, 1, 29959);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R18482[dtype-2125])(Current)) {
		RTHOOK(2);
		loc1 = *(EIF_INTEGER_32 *)(Current + O18720[dtype-2152]);
		for (;;) {
			RTHOOK(3);
			if ((EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R18724[dtype-2158])(Current, loc1) > ((EIF_INTEGER_32) -2L))) break;
			RTHOOK(4);
			loc1--;
		}
		RTHOOK(5);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == loc1);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {DS_SPARSE_CONTAINER}.cursor_same_position */
EIF_BOOLEAN F2153_24469 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("cursor_same_position", 2152, Current, 0, 2, 29960);
	RTGC;
	RTHOOK(1);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_2_0_0_0_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {DS_SPARSE_CONTAINER}.cursor_start */
void F2153_24470 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("cursor_start", 2152, Current, 3, 1, 29961);
	RTGC;
	RTHOOK(1);
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R18482[dtype-2125])(Current)) {
		RTHOOK(2);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R18416[Dtype(RTCW(arg1))-2091])(arg1);
	} else {
		RTHOOK(3);
		loc3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R18521[dtype-2125])(Current, arg1);
		RTHOOK(4);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		RTHOOK(5);
		loc2 = *(EIF_INTEGER_32 *)(Current + O18720[dtype-2152]);
		for (;;) {
			RTHOOK(6);
			tb1 = '\01';
			if (!(EIF_BOOLEAN) (loc1 > loc2)) {
				tb1 = (EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R18724[dtype-2158])(Current, loc1) > ((EIF_INTEGER_32) -2L));
			}
			if (tb1) break;
			RTHOOK(7);
			loc1++;
		}
		RTHOOK(8);
		if ((EIF_BOOLEAN) (loc1 > loc2)) {
			RTHOOK(9);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R18416[Dtype(RTCW(arg1))-2091])(arg1);
			RTHOOK(10);
			if ((EIF_BOOLEAN) !loc3) {
				RTHOOK(11);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R18525[dtype-2125])(Current, arg1);
			}
		} else {
			RTHOOK(12);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R18415[Dtype(RTCW(arg1))-2091])(arg1, loc1);
			RTHOOK(13);
			if (loc3) {
				RTHOOK(14);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R18524[dtype-2125])(Current, arg1);
			}
		}
	}
	RTHOOK(15);
	RTLE;
	RTEE;
}

/* {DS_SPARSE_CONTAINER}.cursor_finish */
void F2153_24471 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("cursor_finish", 2152, Current, 2, 1, 29962);
	RTGC;
	RTHOOK(1);
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R18482[dtype-2125])(Current)) {
		RTHOOK(2);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R18417[Dtype(RTCW(arg1))-2091])(arg1);
	} else {
		RTHOOK(3);
		loc2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R18521[dtype-2125])(Current, arg1);
		RTHOOK(4);
		loc1 = *(EIF_INTEGER_32 *)(Current + O18720[dtype-2152]);
		for (;;) {
			RTHOOK(5);
			tb1 = '\01';
			if (!(EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) {
				tb1 = (EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R18724[dtype-2158])(Current, loc1) > ((EIF_INTEGER_32) -2L));
			}
			if (tb1) break;
			RTHOOK(6);
			loc1--;
		}
		RTHOOK(7);
		if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) {
			RTHOOK(8);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R18417[Dtype(RTCW(arg1))-2091])(arg1);
			RTHOOK(9);
			if ((EIF_BOOLEAN) !loc2) {
				RTHOOK(10);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R18525[dtype-2125])(Current, arg1);
			}
		} else {
			RTHOOK(11);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R18415[Dtype(RTCW(arg1))-2091])(arg1, loc1);
			RTHOOK(12);
			if (loc2) {
				RTHOOK(13);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R18524[dtype-2125])(Current, arg1);
			}
		}
	}
	RTHOOK(14);
	RTLE;
	RTEE;
}

/* {DS_SPARSE_CONTAINER}.cursor_forth */
void F2153_24472 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("cursor_forth", 2152, Current, 4, 1, 29963);
	RTGC;
	RTHOOK(1);
	loc4 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	RTHOOK(2);
	ti4_1 = ((EIF_INTEGER_32) -2L);
	if ((EIF_BOOLEAN)(loc4 == ti4_1)) {
		RTHOOK(3);
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(4);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		RTHOOK(5);
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		RTHOOK(6);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L));
	}
	RTHOOK(7);
	loc2 = *(EIF_INTEGER_32 *)(Current + O18720[dtype-2152]);
	for (;;) {
		RTHOOK(8);
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (loc1 > loc2)) {
			tb1 = (EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R18724[dtype-2158])(Current, loc1) > ((EIF_INTEGER_32) -2L));
		}
		if (tb1) break;
		RTHOOK(9);
		loc1++;
	}
	RTHOOK(10);
	if ((EIF_BOOLEAN) (loc1 > loc2)) {
		RTHOOK(11);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R18416[Dtype(RTCW(arg1))-2091])(arg1);
		RTHOOK(12);
		if ((EIF_BOOLEAN) !loc3) {
			RTHOOK(13);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R18525[dtype-2125])(Current, arg1);
		}
	} else {
		RTHOOK(14);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R18415[Dtype(RTCW(arg1))-2091])(arg1, loc1);
		RTHOOK(15);
		if (loc3) {
			RTHOOK(16);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R18524[dtype-2125])(Current, arg1);
		}
	}
	RTHOOK(17);
	RTLE;
	RTEE;
}

/* {DS_SPARSE_CONTAINER}.cursor_back */
void F2153_24473 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("cursor_back", 2152, Current, 3, 1, 29964);
	RTGC;
	RTHOOK(1);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	RTHOOK(2);
	ti4_1 = ((EIF_INTEGER_32) -3L);
	if ((EIF_BOOLEAN)(loc3 == ti4_1)) {
		RTHOOK(3);
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTHOOK(4);
		loc1 = *(EIF_INTEGER_32 *)(Current + O18720[dtype-2152]);
	} else {
		RTHOOK(5);
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		RTHOOK(6);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L));
	}
	for (;;) {
		RTHOOK(7);
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) {
			tb1 = (EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R18724[dtype-2158])(Current, loc1) > ((EIF_INTEGER_32) -2L));
		}
		if (tb1) break;
		RTHOOK(8);
		loc1--;
	}
	RTHOOK(9);
	if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) {
		RTHOOK(10);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R18417[Dtype(RTCW(arg1))-2091])(arg1);
		RTHOOK(11);
		if ((EIF_BOOLEAN) !loc2) {
			RTHOOK(12);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R18525[dtype-2125])(Current, arg1);
		}
	} else {
		RTHOOK(13);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R18415[Dtype(RTCW(arg1))-2091])(arg1, loc1);
		RTHOOK(14);
		if (loc2) {
			RTHOOK(15);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R18524[dtype-2125])(Current, arg1);
		}
	}
	RTHOOK(16);
	RTLE;
	RTEE;
}

/* {DS_SPARSE_CONTAINER}.cursor_go_after */
void F2153_24476 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("cursor_go_after", 2152, Current, 1, 1, 29967);
	RTGC;
	RTHOOK(1);
	loc1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R18521[dtype-2125])(Current, arg1);
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R18416[Dtype(RTCW(arg1))-2091])(arg1);
	RTHOOK(3);
	if ((EIF_BOOLEAN) !loc1) {
		RTHOOK(4);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R18525[dtype-2125])(Current, arg1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {DS_SPARSE_CONTAINER}.cursor_go_before */
void F2153_24477 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("cursor_go_before", 2152, Current, 1, 1, 29968);
	RTGC;
	RTHOOK(1);
	loc1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R18521[dtype-2125])(Current, arg1);
	RTHOOK(2);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R18417[Dtype(RTCW(arg1))-2091])(arg1);
	RTHOOK(3);
	if ((EIF_BOOLEAN) !loc1) {
		RTHOOK(4);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R18525[dtype-2125])(Current, arg1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {DS_SPARSE_CONTAINER}.cursor_go_to */
void F2153_24478 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTEAA("cursor_go_to", 2152, Current, 1, 2, 29969);
	RTGC;
	RTHOOK(1);
	loc1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R18521[dtype-2125])(Current, arg1);
	RTHOOK(2);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_2_0_0_0_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R18415[Dtype(RTCW(arg1))-2091])(arg1, ti4_1);
	RTHOOK(3);
	if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R18521[dtype-2125])(Current, arg1)) {
		RTHOOK(4);
		if (loc1) {
			RTHOOK(5);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R18524[dtype-2125])(Current, arg1);
		}
	} else {
		RTHOOK(6);
		if ((EIF_BOOLEAN) !loc1) {
			RTHOOK(7);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R18525[dtype-2125])(Current, arg1);
		}
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {DS_SPARSE_CONTAINER}.new_capacity */
EIF_INTEGER_32 F2153_24479 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("new_capacity", 2152, Current, 0, 1, 29970);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * arg1);
}

/* {DS_SPARSE_CONTAINER}.new_modulus */
EIF_INTEGER_32 F2153_24480 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("new_modulus", 2152, Current, 0, 1, 29971);
	RTHOOK(1);
	RTHOOK(2);
	RTEE;
	return (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)) * ((EIF_INTEGER_32) 3L)) / ((EIF_INTEGER_32) 2L));
}

void EIF_Minit2249 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
