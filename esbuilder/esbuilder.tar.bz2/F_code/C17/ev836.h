
#ifndef _C17_ev836_
#define _C17_ev836_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1555_15036(EIF_REFERENCE);
extern EIF_REFERENCE F1555_15037(EIF_REFERENCE);
extern EIF_REFERENCE F1555_15038(EIF_REFERENCE);
extern void EIF_Minit836(void);
extern EIF_REFERENCE F229_4054(EIF_REFERENCE);
extern EIF_REFERENCE F229_4052(EIF_REFERENCE);
extern EIF_REFERENCE F229_4050(EIF_REFERENCE);
extern char *(*R12093[])();

#ifdef __cplusplus
}
#endif

#endif
