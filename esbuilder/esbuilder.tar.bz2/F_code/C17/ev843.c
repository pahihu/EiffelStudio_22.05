/*
 * Code for class EV_TREE_NODE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev843.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TREE_NODE}.parent */
EIF_REFERENCE F1562_15100 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("parent", 1561, Current, 0, 0, 21291);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = F1889_20635(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_TREE_NODE}.parent_tree */
EIF_REFERENCE F1562_15101 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("parent_tree", 1561, Current, 0, 0, 21292);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = F1889_20636(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_TREE_NODE}.default_identifier_name */
EIF_REFERENCE F1562_15102 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("default_identifier_name", 1561, Current, 1, 0, 21293);
	RTGC;
	RTHOOK(1);
	tr1 = F1562_15100(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		Result = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1508_14451(RTCW(Result), ((EIF_INTEGER_32) 5L));
		RTHOOK(3);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '#';
		F1510_14579(RTCW(Result), tw1);
		RTHOOK(4);
		ti4_1 = F1376_12680(loc1, Current, ((EIF_INTEGER_32) 1L));
		F1510_14569(RTCW(Result), ti4_1);
	} else {
		RTHOOK(5);
		Result = F1357_12491(Current);
		RTHOOK(6);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) Result;
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_TREE_NODE}.is_expanded */
EIF_BOOLEAN F1562_15103 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("is_expanded", 1561, Current, 0, 0, 21294);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr1 = F1889_20637(RTCW(tr1));
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		Result = F1890_20649(RTCW(tr1));
	}
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_TREE_NODE}.expand */
void F1562_15104 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("expand", 1561, Current, 0, 0, 21295);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1890_20660(RTCW(tr1), (EIF_BOOLEAN) 1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_TREE_NODE}.collapse */
void F1562_15105 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("collapse", 1561, Current, 0, 0, 21296);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1890_20660(RTCW(tr1), (EIF_BOOLEAN) 0);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit843 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
