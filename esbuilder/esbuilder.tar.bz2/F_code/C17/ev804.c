/*
 * Code for class EV_GRID_CHOICE_ITEM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev804.h"
#include "eif_built_in.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GRID_CHOICE_ITEM}.initialize */
void F1523_14870 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("initialize", 1522, Current, 0, 0, 21084);
	RTGC;
	RTHOOK(1);
	F1521_14795(Current);
	RTHOOK(2);
	F1519_14779(Current, (EIF_BOOLEAN) 1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_GRID_CHOICE_ITEM}.set_item_strings */
void F1523_14871 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("set_item_strings", 1522, Current, 1, 1, 21085);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb2 = F1345_12289(loc1);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(3);
		F1523_14877(Current);
	}
	RTHOOK(4);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8044[Dtype(RTCW(arg1))-919])(arg1);
	ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8043[Dtype(RTCW(arg1))-919])(arg1);
	if ((EIF_BOOLEAN) (ti4_1 > ti4_2)) {
		RTHOOK(5);
		tr1 = RTOSCF(14886,F1523_14886, (Current));
		F1521_14799(Current, tr1);
	} else {
		RTHOOK(6);
		F1521_14800(Current);
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EV_GRID_CHOICE_ITEM}.required_width */
EIF_INTEGER_32 F1523_14873 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("required_width", 1522, Current, 0, 0, 21087);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_5_) == NULL)) {
		RTHOOK(2);
		tr1 = RTOSCF(14886,F1523_14886, (Current));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R14800[Dtype(RTCW(tr1))-1754])(tr1);
		RTHOOK(4);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) NULL;
	} else {
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R14800[Dtype(RTCW(tr1))-1754])(tr1);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_CHOICE_ITEM}.deactivate */
void F1523_14874 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("deactivate", 1522, Current, 2, 0, 21088);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tb2 = F1345_12289(loc2);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(2);
		tr1 = F1574_15172(loc2);
		F1169_10229(RTCW(tr1));
		RTHOOK(3);
		tr1 = F1574_15168(loc2);
		F1169_10229(RTCW(tr1));
		RTHOOK(4);
		tr1 = F1515_14691(loc2);
		F1169_10229(RTCW(tr1));
		RTHOOK(5);
		tr1 = F1515_14693(loc2);
		F1169_10229(RTCW(tr1));
		RTHOOK(6);
		tr1 = F1574_15161(loc2);
		F1169_10229(RTCW(tr1));
		RTHOOK(7);
		tb1 = '\0';
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_0_)) {
			tb2 = F1594_15738(loc2);
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(8);
			tr1 = F1594_15588(loc2);
			tr1 = F1147_10119(RTCW(tr1));
			loc1 = F1514_14635(RTCW(tr1), ((EIF_INTEGER_32) 1L));
			loc1 = RTRV(eif_new_type(1520, 0x00), loc1);
			RTHOOK(9);
			if ((EIF_BOOLEAN)(loc1 != NULL)) {
				RTHOOK(10);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_3_);
				F1521_14796(Current, tr1);
			}
		}
		RTHOOK(11);
		*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) NULL;
	}
	RTHOOK(12);
	F1519_14781(Current);
	RTHOOK(13);
	RTLE;
	RTEE;
}

/* {EV_GRID_CHOICE_ITEM}.set_strings */
void F1523_14877 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc7);
	RTLR(1,Current);
	RTLR(2,loc5);
	RTLR(3,loc9);
	RTLR(4,tr1);
	RTLR(5,loc10);
	RTLR(6,loc4);
	RTLR(7,loc3);
	RTLR(8,loc1);
	RTLR(9,loc6);
	RTLIU(10);
	
	RTEAA("set_strings", 1522, Current, 10, 0, 21091);
	RTGC;
	RTHOOK(1);
	loc7 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	RTHOOK(2);
	RTCT0("l_choice_list /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc7 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(3);
	F1594_15680(RTCW(loc7), ((EIF_INTEGER_32) 1L));
	RTHOOK(4);
	F1594_15679(RTCW(loc7), ((EIF_INTEGER_32) 1L));
	RTHOOK(5);
	F1594_15752(RTCW(loc7), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 1L), NULL);
	RTHOOK(6);
	loc5 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	RTHOOK(7);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	loc9 = tr1;
	if (EIF_TEST(loc9)) {
		RTHOOK(8);
		loc10 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7815[Dtype(loc9)-668])(loc9);
		RTHOOK(9);
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		RTHOOK(10);
		loc4 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8184[Dtype(loc10)-1011])(loc10);
			if (tb1) break;
			RTHOOK(11);
			loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8183[Dtype(loc10)-1011])(loc10);
			RTHOOK(12);
			loc1 = RTLNS(eif_new_type(1520, 0x00).id, 1520, _OBJSIZ_7_1_0_5_0_0_0_0_);
			F1521_14794(RTCW(loc1), loc3);
			RTHOOK(13);
			F1594_15752(RTCW(loc7), ((EIF_INTEGER_32) 1L), loc2, loc1);
			RTHOOK(14);
			loc2++;
			RTHOOK(15);
			tb2 = '\0';
			if ((EIF_BOOLEAN)(loc6 == NULL)) {
				tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11492[Dtype(RTCW(loc3))-1503])(loc3, loc4);
				tb2 = tb3;
			}
			if (tb2) {
				RTHOOK(16);
				if ((EIF_BOOLEAN)(loc5 != NULL)) {
					RTHOOK(17);
					loc6 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc5);
				} else {
					RTHOOK(18);
					loc6 = RTLNS(eif_new_type(1351, 0x00).id, 1351, _OBJSIZ_2_0_0_0_0_0_0_0_);
					F1345_12285(RTCW(loc6));
				}
				RTHOOK(19);
				F1352_12412(RTCW(loc6), ((EIF_INTEGER_32) 8L));
				RTHOOK(20);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11897[Dtype(RTCW(loc1))-1520])(loc1, loc6);
				RTHOOK(21);
				F1365_12553(RTCW(loc1));
			} else {
				RTHOOK(22);
				if ((EIF_BOOLEAN)(loc5 != NULL)) {
					RTHOOK(23);
					ti4_1 = F1352_12405(RTCW(loc5));
					if ((EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 7L))) {
						RTHOOK(24);
						tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc5);
						loc5 = (EIF_REFERENCE) tr1;
						RTHOOK(25);
						F1352_12412(RTCW(loc5), ((EIF_INTEGER_32) 7L));
					}
					RTHOOK(26);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11897[Dtype(RTCW(loc1))-1520])(loc1, loc5);
				}
			}
			RTHOOK(27);
			F1521_14801(RTCW(loc1), ((EIF_INTEGER_32) 2L));
			RTHOOK(28);
			F1521_14802(RTCW(loc1), ((EIF_INTEGER_32) 2L));
			RTHOOK(29);
			F1523_14878(Current, loc1);
			RTHOOK(30);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R8185[Dtype(loc10)-1011])(loc10);
		}
	} else {
		RTHOOK(31);
		loc1 = RTLNS(eif_new_type(1520, 0x00).id, 1520, _OBJSIZ_7_1_0_5_0_0_0_0_);
		F1521_14794(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
		RTHOOK(32);
		if ((EIF_BOOLEAN)(loc5 != NULL)) {
			RTHOOK(33);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11897[Dtype(RTCW(loc1))-1520])(loc1, loc5);
		}
		RTHOOK(34);
		F1521_14801(RTCW(loc1), ((EIF_INTEGER_32) 2L));
		RTHOOK(35);
		F1521_14802(RTCW(loc1), ((EIF_INTEGER_32) 2L));
		RTHOOK(36);
		F1523_14878(Current, loc1);
		RTHOOK(37);
		F1594_15752(RTCW(loc7), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 1L), loc1);
	}
	RTHOOK(38);
	RTLE;
	RTEE;
}

/* {EV_GRID_CHOICE_ITEM}.set_alignment */
void F1523_14878 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("set_alignment", 1522, Current, 0, 1, 21092);
	RTGC;
	RTHOOK(1);
	if (F1521_14825(Current)) {
		RTHOOK(2);
		F1521_14808(RTCW(arg1));
	} else {
		RTHOOK(3);
		if (F1521_14827(Current)) {
			RTHOOK(4);
			F1521_14807(RTCW(arg1));
		} else {
			RTHOOK(5);
			F1521_14806(RTCW(arg1));
		}
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_GRID_CHOICE_ITEM}.activate_action */
void F1523_14880 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc13 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc14 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc15 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(13);
	RTLR(0,loc11);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,loc18);
	RTLR(5,loc17);
	RTLR(6,loc4);
	RTLR(7,loc12);
	RTLR(8,loc16);
	RTLR(9,loc19);
	RTLR(10,arg1);
	RTLR(11,tr2);
	RTLR(12,tr3);
	RTLIU(13);
	
	RTEAA("activate_action", 1522, Current, 19, 1, 21075);
	RTGC;
	RTHOOK(1);
	loc11 = F1519_14761(Current);
	RTHOOK(2);
	RTCT0("l_parent /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc11 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(3);
	tr1 = RTLNS(eif_new_type(1373, 0x00).id, 1373, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1345_12285(RTCW(tr1));
	loc3 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	loc3 = RTRV(eif_new_type(1920, 0x00), loc3);
	RTHOOK(4);
	RTCT0("l_screen_not_void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(5);
	loc18 = F1921_21132(RTCW(loc3));
	RTHOOK(6);
	ti4_1 = F1254_11740(RTCW(loc18));
	ti4_2 = F1254_11742(RTCW(loc18));
	loc17 = F1921_21139(RTCW(loc3), ti4_1, ti4_2);
	RTHOOK(7);
	loc4 = RTLNS(eif_new_type(1593, 0x00).id, 1593, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1345_12285(RTCW(loc4));
	RTHOOK(8);
	RTAR(Current, loc4);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) loc4;
	RTHOOK(9);
	F1594_15660(RTCW(loc4));
	RTHOOK(10);
	F1594_15709(RTCW(loc4));
	RTHOOK(11);
	loc12 = RTLNS(eif_new_type(1589, 0x00).id, 1589, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1345_12285(RTCW(loc12));
	RTHOOK(12);
	tr1 = RTLNS(eif_new_type(625, 0x00).id, 625, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = RTOSCF(8280,F626_8280, (RTCW(tr1)));
	F1360_12514(RTCW(loc12), tr1);
	RTHOOK(13);
	loc13 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTHOOK(14);
	F1587_15482(RTCW(loc12), loc13);
	RTHOOK(15);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_2_0_4_) >= ((EIF_INTEGER_32) 0L))) {
		RTHOOK(16);
		loc14 = F1521_14815(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_2_0_0_);
		loc14 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) + loc14) + ti4_1);
	} else {
		RTHOOK(17);
		loc14 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_2_0_0_);
		loc14 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) + loc14);
	}
	RTHOOK(18);
	loc15 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_2_0_1_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_2_0_2_);
	loc15 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) + loc15) + ti4_1);
	RTHOOK(19);
	F1376_12694(RTCW(loc12), loc4);
	RTHOOK(20);
	F1523_14877(Current);
	RTHOOK(21);
	ti4_1 = F1519_14767(Current);
	ti4_2 = F1519_14768(Current);
	loc16 = F1523_14887(Current, ti4_1, ti4_2);
	RTHOOK(22);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc19 = tr1;
	if (EIF_TEST(loc19)) {
		RTHOOK(23);
		(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(loc19+ _PTROFF_4_2_0_3_0_0_))(
			*(EIF_POINTER *)(loc19+ _PTROFF_4_2_0_3_0_1_),
			*(EIF_REFERENCE *)(loc19 + _REFACS_1_), Current, loc16);
	}
	RTHOOK(24);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_2_0_4_) >= ((EIF_INTEGER_32) 0L))) {
		RTHOOK(25);
		loc5 = F1362_12526(RTCW(arg1));
		ti4_1 = F1521_14815(Current);
		loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 + ti4_1);
	} else {
		RTHOOK(26);
		loc5 = F1362_12526(RTCW(arg1));
	}
	RTHOOK(27);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc17)+ _LNGOFF_0_0_0_0_);
	loc7 = eif_max_int32 ((EIF_INTEGER_32) (ti4_1 - loc5),((EIF_INTEGER_32) 0L));
	RTHOOK(28);
	loc5 += loc7;
	RTHOOK(29);
	loc6 = F1362_12527(RTCW(arg1));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc16)+ _LNGOFF_0_1_0_5_);
	loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc6 + ti4_1) - ((EIF_INTEGER_32) 2L));
	RTHOOK(30);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc17)+ _LNGOFF_0_0_0_1_);
	loc8 = eif_max_int32 ((EIF_INTEGER_32) (ti4_1 - loc6),((EIF_INTEGER_32) 0L));
	RTHOOK(31);
	loc6 += loc8;
	RTHOOK(32);
	loc1 = F1362_12530(RTCW(arg1));
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 - loc7) - loc14);
	RTHOOK(33);
	loc2 = F1362_12531(RTCW(arg1));
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 - loc8) - loc15);
	RTHOOK(34);
	tb1 = '\0';
	ti4_1 = F1594_15759(RTCW(loc4));
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		ti4_1 = F1594_15761(RTCW(loc4));
		tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		RTHOOK(35);
		loc2 = F1594_15615(RTCW(loc4));
		RTHOOK(36);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc17)+ _LNGOFF_0_0_0_3_);
		if ((EIF_BOOLEAN) (loc2 >= ti4_1)) {
			RTHOOK(37);
			tr1 = F1594_15593(RTCW(loc4));
			loc9 = F1362_12530(RTCW(tr1));
		}
		RTHOOK(38);
		tr1 = F1594_15581(RTCW(loc4), ((EIF_INTEGER_32) 1L));
		ti4_1 = F1594_15761(RTCW(loc4));
		loc10 = F1517_14727(RTCW(tr1), ((EIF_INTEGER_32) 1L), ti4_1);
		loc10 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc9 + loc10);
		RTHOOK(39);
		ti4_1 = eif_max_int32 (loc1,loc10);
		loc1 = (EIF_INTEGER_32) ti4_1;
		RTHOOK(40);
		loc7 = F1255_11759(RTCW(loc17));
		loc7 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc5 + loc1) - loc7);
		RTHOOK(41);
		if ((EIF_BOOLEAN) (loc7 > ((EIF_INTEGER_32) 0L))) {
			RTHOOK(42);
			if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 - loc7) > loc10)) {
				RTHOOK(43);
				loc1 -= loc7;
			} else {
				RTHOOK(44);
				loc1 = (EIF_INTEGER_32) loc10;
				RTHOOK(45);
				loc5 = F1255_11759(RTCW(loc17));
				loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 - loc10);
				RTHOOK(46);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc17)+ _LNGOFF_0_0_0_0_);
				if ((EIF_BOOLEAN) (loc5 < ti4_1)) {
					RTHOOK(47);
					loc1 = *(EIF_INTEGER_32 *)(RTCW(loc17)+ _LNGOFF_0_0_0_2_);
					RTHOOK(48);
					loc5 = *(EIF_INTEGER_32 *)(RTCW(loc17)+ _LNGOFF_0_0_0_0_);
				}
			}
		}
		RTHOOK(49);
		loc8 = F1255_11760(RTCW(loc17));
		loc8 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc6 + loc2) - loc8);
		RTHOOK(50);
		if ((EIF_BOOLEAN) (loc8 > ((EIF_INTEGER_32) 0L))) {
			RTHOOK(51);
			loc6 -= loc8;
			RTHOOK(52);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc17)+ _LNGOFF_0_0_0_1_);
			if ((EIF_BOOLEAN) (loc6 < ti4_1)) {
				RTHOOK(53);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc17)+ _LNGOFF_0_0_0_1_);
				loc2 -= (EIF_INTEGER_32) (ti4_1 - loc6);
				RTHOOK(54);
				loc6 = *(EIF_INTEGER_32 *)(RTCW(loc17)+ _LNGOFF_0_0_0_1_);
			}
		}
		RTHOOK(55);
		F1575_15201(RTCW(loc4), loc2);
		RTHOOK(56);
		tr1 = F1594_15581(RTCW(loc4), ((EIF_INTEGER_32) 1L));
		F1517_14735(RTCW(tr1), (EIF_INTEGER_32) (loc1 - loc9));
		RTHOOK(57);
		F1575_15200(RTCW(loc4), loc1);
	}
	RTHOOK(58);
	F1363_12536(RTCW(arg1), loc5);
	RTHOOK(59);
	F1363_12537(RTCW(arg1), loc6);
	RTHOOK(60);
	F1363_12540(RTCW(arg1), (EIF_INTEGER_32) (loc2 + (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * loc13)));
	RTHOOK(61);
	F1363_12539(RTCW(arg1), (EIF_INTEGER_32) (loc1 + (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * loc13)));
	RTHOOK(62);
	F1594_15650(RTCW(loc4));
	RTHOOK(63);
	F1594_15648(RTCW(loc4));
	RTHOOK(64);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = F1755_18442(RTCW(tr1));
	F1360_12514(RTCW(loc4), tr1);
	RTHOOK(65);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = F1755_18442(RTCW(tr1));
	F1360_12514(RTCW(arg1), tr1);
	RTHOOK(66);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = F1755_18443(RTCW(tr1));
	F1360_12513(RTCW(loc4), tr1);
	RTHOOK(67);
	tr1 = F1594_15627(RTCW(loc11));
	F1594_15697(RTCW(loc4), tr1);
	RTHOOK(68);
	tr1 = F1594_15629(RTCW(loc11));
	F1594_15699(RTCW(loc4), tr1);
	RTHOOK(69);
	F1576_15217(RTCW(arg1), loc12);
	RTHOOK(70);
	tr1 = F1638_16077(RTCW(arg1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1493,0xFFF9,0,1419,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A804_153, (EIF_POINTER) _A804_153, (EIF_POINTER)(F1523_14881),tr2, 1, 0);
	}
	F1169_10217(RTCW(tr1), tr3);
	RTHOOK(71);
	RTLE;
	RTEE;
}

/* {EV_GRID_CHOICE_ITEM}.initialize_actions */
void F1523_14881 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLIU(7);
	
	RTEAA("initialize_actions", 1522, Current, 1, 0, 21076);
	RTGC;
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_10_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(2);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb2 = F1345_12289(loc1);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(3);
		tb1 = '\0';
		tb2 = F1575_15185(loc1);
		if (tb2) {
			tb2 = F1377_12721(loc1);
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(4);
			F1575_15190(loc1);
		}
		RTHOOK(5);
		tr1 = RTLNS(eif_new_type(1373, 0x00).id, 1373, _OBJSIZ_2_0_0_0_0_0_0_0_);
		F1345_12285(RTCW(tr1));
		tr1 = F1374_12652(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
		RTHOOK(6);
		tr1 = F1574_15172(loc1);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr2 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
		RTAR(tr2,Current);
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1493,0xFFF9,0,1419,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3= RTLNRF(typres0.id, (EIF_POINTER) __A804_146, (EIF_POINTER) _A804_146, (EIF_POINTER)(F1523_14874),tr2, 1, 0);
		}
		F1169_10217(RTCW(tr1), tr3);
		RTHOOK(7);
		tr1 = F1515_14691(loc1);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr2 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
		RTAR(tr2,Current);
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1493,0xFFF9,4,1419,1425,1425,1425,1518,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr5= RTLNRF(typres0.id, (EIF_POINTER) __A804_155_2_3_4_5, (EIF_POINTER) _A804_155_2_3_4_5, (EIF_POINTER)(F1523_14883),tr2, 1, 4);
		}
		F1169_10217(RTCW(tr1), tr5);
		RTHOOK(8);
		tr1 = F1515_14693(loc1);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr2 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
		RTAR(tr2,Current);
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1493,0xFFF9,4,1419,1425,1425,1425,1518,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr5= RTLNRF(typres0.id, (EIF_POINTER) __A804_156_2_3_4_5, (EIF_POINTER) _A804_156_2_3_4_5, (EIF_POINTER)(F1523_14884),tr2, 1, 4);
		}
		F1169_10217(RTCW(tr1), tr5);
		RTHOOK(9);
		tr1 = F1574_15161(loc1);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr2 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
		RTAR(tr2,Current);
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1493,0xFFF9,7,1419,1425,1425,1449,1449,1449,1425,1425,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr5= RTLNRF(typres0.id, (EIF_POINTER) __A804_154_2_3_4_5_6_7_8, (EIF_POINTER) _A804_154_2_3_4_5_6_7_8, (EIF_POINTER)(F1523_14882),tr2, 1, 7);
		}
		F1169_10217(RTCW(tr1), tr5);
		RTHOOK(10);
		tr1 = F1574_15168(loc1);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr2 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
		RTAR(tr2,Current);
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1493,0xFFF9,1,1419,2025,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr5= RTLNRF(typres0.id, (EIF_POINTER) __A804_157_2, (EIF_POINTER) _A804_157_2, (EIF_POINTER)(F1523_14885),tr2, 1, 1);
		}
		F1169_10217(RTCW(tr1), tr5);
	} else {
		RTHOOK(11);
		tb1 = '\0';
		if ((EIF_BOOLEAN) !F1345_12289(Current)) {
			tb1 = F1519_14783(Current);
		}
		if (tb1) {
			RTHOOK(12);
			F1523_14874(Current);
		}
	}
	RTHOOK(13);
	RTLE;
	RTEE;
}

/* {EV_GRID_CHOICE_ITEM}.on_mouse_move */
void F1523_14882 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc4);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTEAA("on_mouse_move", 1522, Current, 4, 7, 21077);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTHOOK(2);
		tb1 = '\01';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		loc4 = tr1;
		if (!((EIF_BOOLEAN) !EIF_TEST(loc4))) {
			tb2 = '\0';
			ti4_1 = F1254_11740(loc4);
			ti4_2 = F1362_12528(loc3);
			if ((EIF_BOOLEAN)(ti4_1 != (EIF_INTEGER_32) (ti4_2 + arg1))) {
				ti4_1 = F1254_11742(loc4);
				ti4_2 = F1362_12529(loc3);
				tb2 = (EIF_BOOLEAN)(ti4_1 != (EIF_INTEGER_32) (ti4_2 + arg2));
			}
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(3);
			*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) NULL;
			RTHOOK(4);
			ti4_1 = F1594_15610(loc3);
			ti4_2 = F1594_15611(loc3);
			loc1 = F1594_15584(loc3, (EIF_INTEGER_32) (ti4_1 + arg1), (EIF_INTEGER_32) (ti4_2 + arg2));
			RTHOOK(5);
			if ((EIF_BOOLEAN)(loc1 != NULL)) {
				RTHOOK(6);
				loc2 = F1594_15589(loc3);
				RTHOOK(7);
				tb1 = '\0';
				tb2 = F827_9290(RTCW(loc2));
				if ((EIF_BOOLEAN) !tb2) {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8130[Dtype(RTCW(loc2))-989])(loc2);
					tb1 = (EIF_BOOLEAN)(tr1 != loc1);
				}
				if (tb1) {
					RTHOOK(8);
					F1594_15590(loc3);
					RTHOOK(9);
					F1365_12553(RTCW(loc1));
				}
				RTHOOK(10);
				*(EIF_BOOLEAN *)(Current+ _CHROFF_10_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		}
	} else {
		
	}
	RTHOOK(12);
	RTLE;
	RTEE;
}

/* {EV_GRID_CHOICE_ITEM}.on_mouse_press */
void F1523_14883 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_REFERENCE arg4)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTEAA("on_mouse_press", 1522, Current, 3, 4, 21078);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(arg3 == ((EIF_INTEGER_32) 1L))) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			RTHOOK(3);
			ti4_1 = F1594_15610(loc3);
			ti4_2 = F1594_15611(loc3);
			loc1 = F1594_15584(loc3, (EIF_INTEGER_32) (ti4_1 + arg1), (EIF_INTEGER_32) (ti4_2 + arg2));
			RTHOOK(4);
			if ((EIF_BOOLEAN)(loc1 != NULL)) {
				RTHOOK(5);
				loc2 = F1594_15589(loc3);
				RTHOOK(6);
				tb1 = '\0';
				tb2 = F827_9290(RTCW(loc2));
				if ((EIF_BOOLEAN) !tb2) {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8130[Dtype(RTCW(loc2))-989])(loc2);
					tb1 = (EIF_BOOLEAN)(tr1 != loc1);
				}
				if (tb1) {
					RTHOOK(7);
					F1594_15590(loc3);
					RTHOOK(8);
					F1365_12553(RTCW(loc1));
				}
				RTHOOK(9);
				*(EIF_BOOLEAN *)(Current+ _CHROFF_10_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		} else {
			
		}
	}
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {EV_GRID_CHOICE_ITEM}.on_mouse_release */
void F1523_14884 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_REFERENCE arg4)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("on_mouse_release", 1522, Current, 0, 4, 21079);
	RTGC;
	RTHOOK(1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_0_)) {
		RTHOOK(2);
		F1523_14874(Current);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_GRID_CHOICE_ITEM}.on_key */
void F1523_14885 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,loc4);
	RTLIU(5);
	
	RTEAA("on_key", 1522, Current, 4, 1, 21080);
	RTGC;
	RTHOOK(1);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
	switch (ti4_1) {
		case 41L:
		case 43L:
			RTHOOK(2);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_10_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 41L));
			RTHOOK(3);
			loc1 = '\0';
			tr1 = F1519_14761(Current);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				tb1 = F1594_15726(loc3);
				loc1 = tb1;
			}
			RTHOOK(4);
			loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			break;
		case 42L:
			RTHOOK(5);
			loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			break;
	}
	RTHOOK(6);
	tb1 = '\0';
	if (loc2) {
		tr1 = F1519_14761(Current);
		loc4 = tr1;
		tb1 = EIF_TEST(loc4);
	}
	if (tb1) {
		RTHOOK(7);
		if (loc1) {
			RTHOOK(8);
			tr1 = RTLNS(eif_new_type(2025, 0x00).id, 2025, _OBJSIZ_0_0_0_1_0_0_0_0_);
			F2026_22953(RTCW(tr1), ((EIF_INTEGER_32) 43L));
			F1594_15764(loc4, tr1);
		}
		RTHOOK(9);
		tr1 = F1594_15583(loc4);
		if ((EIF_BOOLEAN)(tr1 == Current)) {
			RTHOOK(10);
			F1523_14874(Current);
		}
	}
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {EV_GRID_CHOICE_ITEM}.drop_down_pixmap */
static EIF_REFERENCE F1523_14886_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("drop_down_pixmap", 1522, Current, 1, 0, 21081);
	RTGC;
	RTOSP (14886);
#define Result RTOSR(14886)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1685, 0x00).id, 1685, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1686_17074(RTCW(tr1), ((EIF_INTEGER_32) 9L), ((EIF_INTEGER_32) 7L));
	Result = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	F1372_12615(RTCW(Result), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 2L), ((EIF_INTEGER_32) 7L), ((EIF_INTEGER_32) 2L));
	RTHOOK(3);
	F1372_12615(RTCW(Result), ((EIF_INTEGER_32) 2L), ((EIF_INTEGER_32) 3L), ((EIF_INTEGER_32) 6L), ((EIF_INTEGER_32) 3L));
	RTHOOK(4);
	F1372_12615(RTCW(Result), ((EIF_INTEGER_32) 3L), ((EIF_INTEGER_32) 4L), ((EIF_INTEGER_32) 5L), ((EIF_INTEGER_32) 4L));
	RTHOOK(5);
	F1372_12615(RTCW(Result), ((EIF_INTEGER_32) 4L), ((EIF_INTEGER_32) 5L), ((EIF_INTEGER_32) 4L), ((EIF_INTEGER_32) 5L));
	RTHOOK(6);
	loc1 = RTLNS(eif_new_type(1372, 0x00).id, 1372, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1373_12637(RTCW(loc1), ((EIF_INTEGER_32) 9L), ((EIF_INTEGER_32) 7L));
	RTHOOK(7);
	F1372_12608(RTCW(loc1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 9L), ((EIF_INTEGER_32) 7L));
	RTHOOK(8);
	F1372_12615(RTCW(loc1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 8L), ((EIF_INTEGER_32) 1L));
	RTHOOK(9);
	F1372_12615(RTCW(loc1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 2L), ((EIF_INTEGER_32) 8L), ((EIF_INTEGER_32) 2L));
	RTHOOK(10);
	F1372_12615(RTCW(loc1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 3L), ((EIF_INTEGER_32) 7L), ((EIF_INTEGER_32) 3L));
	RTHOOK(11);
	F1372_12615(RTCW(loc1), ((EIF_INTEGER_32) 2L), ((EIF_INTEGER_32) 4L), ((EIF_INTEGER_32) 6L), ((EIF_INTEGER_32) 4L));
	RTHOOK(12);
	F1372_12615(RTCW(loc1), ((EIF_INTEGER_32) 3L), ((EIF_INTEGER_32) 5L), ((EIF_INTEGER_32) 5L), ((EIF_INTEGER_32) 5L));
	RTHOOK(13);
	F1372_12615(RTCW(loc1), ((EIF_INTEGER_32) 4L), ((EIF_INTEGER_32) 6L), ((EIF_INTEGER_32) 4L), ((EIF_INTEGER_32) 6L));
	RTHOOK(14);
	F1686_17091(RTCW(Result), loc1);
	RTOSE (14886);
	RTHOOK(16);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1523_14886 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14886,F1523_14886_body,(Current));
}

/* {EV_GRID_CHOICE_ITEM}.computed_initial_grid_label_item_layout */
EIF_REFERENCE F1523_14887 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("computed_initial_grid_label_item_layout", 1522, Current, 1, 2, 21082);
	RTGC;
	RTHOOK(1);
	Result = F1521_14840(Current, arg1, arg2);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_0_1_0_4_);
		ti4_2 = F1362_12530(loc1);
		ti4_3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_2_0_3_);
		F25_389(RTCW(Result), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - ti4_2) - ti4_3));
		RTHOOK(4);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_0_1_0_4_);
		ti4_2 = F1519_14767(Current);
		ti4_3 = F1362_12530(loc1);
		ti4_4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_2_0_0_);
		ti4_1 = eif_max_int32 (ti4_1,(EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_2 - ti4_3) - ti4_4) - ((EIF_INTEGER_32) 2L)));
		F25_387(RTCW(Result), ti4_1);
		RTHOOK(5);
		F25_394(RTCW(Result), (EIF_BOOLEAN) 0);
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit804 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
