
#ifndef _C17_ev823_
#define _C17_ev823_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1542_14981(EIF_REFERENCE);
extern void EIF_Minit823(void);
extern EIF_REFERENCE F195_2518(EIF_REFERENCE);
extern char *(*R12047[])();

#ifdef __cplusplus
}
#endif

#endif
