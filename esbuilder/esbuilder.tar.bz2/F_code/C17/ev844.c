/*
 * Code for class EV_TREE_ITEM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev844.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TREE_ITEM}.is_expandable */
EIF_BOOLEAN F1563_15110 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("is_expandable", 1562, Current, 0, 0, 21300);
	RTGC;
	RTHOOK(1);
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr1 = F1889_20637(RTCW(tr1));
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		Result = (EIF_BOOLEAN) (F1376_12683(Current) > ((EIF_INTEGER_32) 0L));
	}
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_TREE_ITEM}.implementation */
EIF_REFERENCE F1563_15112 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {EV_TREE_ITEM}.create_implementation */
void F1563_15113 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1562, Current, 0, 0, 21303);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1891, 0x00).id, 1891, _OBJSIZ_25_6_6_3_0_1_0_0_);
	F1890_20647(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit844 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
