
#ifndef _C17_ev835_
#define _C17_ev835_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1554_15034(EIF_REFERENCE);
extern void EIF_Minit835(void);
extern EIF_REFERENCE F228_4047(EIF_REFERENCE);
extern char *(*R12091[])();

#ifdef __cplusplus
}
#endif

#endif
