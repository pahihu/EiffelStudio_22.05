/*
 * Code for class EV_GRID_HEADER_ITEM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev842.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GRID_HEADER_ITEM}.set_column */
void F1561_15098 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_column", 1560, Current, 0, 1, 21288);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	RTEE;
}

void EIF_Minit842 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
