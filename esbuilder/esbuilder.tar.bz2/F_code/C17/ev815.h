
#ifndef _C17_ev815_
#define _C17_ev815_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1534_14934(EIF_REFERENCE);
extern void F1534_14935(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1534_14936(EIF_REFERENCE);
extern void F1534_14937(EIF_REFERENCE);
extern void EIF_Minit815(void);
extern void F1767_18539(EIF_REFERENCE);
extern EIF_REFERENCE F1767_18540(EIF_REFERENCE);
extern void F1767_18541(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
