
#ifndef _C17_ev849_
#define _C17_ev849_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1568_15135(EIF_REFERENCE);
extern EIF_REFERENCE F1568_15143(EIF_REFERENCE);
extern void F1568_15144(EIF_REFERENCE);
extern void EIF_Minit849(void);
extern void F1910_20851(EIF_REFERENCE);
extern EIF_REFERENCE F1566_15132(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
