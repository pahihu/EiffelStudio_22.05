/*
 * Code for class EV_DIRECTORY_DIALOG
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev816.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DIRECTORY_DIALOG}.directory */
EIF_REFERENCE F1535_14938 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("directory", 1534, Current, 0, 0, 21144);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = F1386_12871(RTCV(F1535_14939(Current)));
	F1508_14453(RTCW(Result), tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_DIRECTORY_DIALOG}.path */
EIF_REFERENCE F1535_14939 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("path", 1534, Current, 0, 0, 21145);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1768_18546(RTCW(tr1));
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_DIRECTORY_DIALOG}.set_start_directory */
void F1535_14942 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEAA("set_start_directory", 1534, Current, 0, 1, 21140);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1385, 0x00).id, 1385, _OBJSIZ_2_1_0_0_0_0_0_0_);
	F1386_12832(RTCW(tr1), arg1);
	F1535_14943(Current, tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_DIRECTORY_DIALOG}.set_start_path */
void F1535_14943 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("set_start_path", 1534, Current, 0, 1, 21141);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1768_18548(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_DIRECTORY_DIALOG}.implementation */
EIF_REFERENCE F1535_14944 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


/* {EV_DIRECTORY_DIALOG}.create_implementation */
void F1535_14945 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1534, Current, 0, 0, 21143);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1767, 0x00).id, 1767, _OBJSIZ_9_5_0_1_0_1_0_0_);
	F1768_18545(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit816 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
