
#ifndef _C17_ev837_
#define _C17_ev837_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1556_15043(EIF_REFERENCE);
extern void EIF_Minit837(void);
extern void F1221_11202(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F827_9290(EIF_REFERENCE);
extern char *(*R4100[])();
extern char *(*R12097[])();

#ifdef __cplusplus
}
#endif

#endif
