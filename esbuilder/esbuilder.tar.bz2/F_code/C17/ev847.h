
#ifndef _C17_ev847_
#define _C17_ev847_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1566_15132(EIF_REFERENCE);
extern void EIF_Minit847(void);
extern EIF_REFERENCE F1558_15073(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
