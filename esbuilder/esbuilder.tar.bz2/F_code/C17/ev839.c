/*
 * Code for class EV_ITEM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev839.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_ITEM}.parent */
EIF_REFERENCE F1558_15073 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("parent", 1557, Current, 0, 0, 21264);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O10182[Dtype(Current)-1344]);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R16094[Dtype(RTCW(tr1))-1884])(tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit839 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
