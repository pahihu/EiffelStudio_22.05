
#ifndef _C17_sh806_
#define _C17_sh806_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1525_14898(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit806(void);

#ifdef __cplusplus
}
#endif

#endif
