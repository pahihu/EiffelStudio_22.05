
#ifndef _C17_ev848_
#define _C17_ev848_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1567_15133(EIF_REFERENCE);
extern void F1567_15134(EIF_REFERENCE);
extern void EIF_Minit848(void);
extern void F1894_20717(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
