
#ifndef _C17_ev838_
#define _C17_ev838_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1557_15052(EIF_REFERENCE);
extern void F1557_15053(EIF_REFERENCE, EIF_REFERENCE);
extern void F1557_15054(EIF_REFERENCE);
extern void F1557_15055(EIF_REFERENCE, EIF_REFERENCE);
extern void F1557_15062(EIF_REFERENCE, EIF_REFERENCE);
extern void F1557_15063(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit838(void);
extern void F1771_18587(EIF_REFERENCE);
extern char *(*R14915[])();
extern char *(*R14916[])();
extern char *(*R14926[])();
extern char *(*R14927[])();
extern long O10182[];
extern long O14908[];

#ifdef __cplusplus
}
#endif

#endif
