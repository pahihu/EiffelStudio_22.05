/*
 * Code for class EV_DOCKABLE_SOURCE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev828.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DOCKABLE_SOURCE}.real_source */
EIF_REFERENCE F1547_14997 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("real_source", 1546, Current, 0, 0, 21201);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O10182[Dtype(Current)-1344]);
	Result = *(EIF_REFERENCE *)(RTCW(tr1) + O14373[Dtype(tr1)-1720]);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_DOCKABLE_SOURCE}.enable_dockable */
void F1547_15000 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("enable_dockable", 1546, Current, 0, 0, 21204);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O10182[Dtype(Current)-1344]);
	F1721_17882(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_DOCKABLE_SOURCE}.disable_dockable */
void F1547_15001 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("disable_dockable", 1546, Current, 0, 0, 21205);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O10182[Dtype(Current)-1344]);
	F1721_17884(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_DOCKABLE_SOURCE}.set_real_source */
void F1547_15002 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("set_real_source", 1546, Current, 0, 1, 21206);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O10182[Dtype(Current)-1344]);
	F1721_17886(RTCW(tr1), arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit828 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
