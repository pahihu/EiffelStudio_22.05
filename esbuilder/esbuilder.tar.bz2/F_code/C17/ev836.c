/*
 * Code for class EV_ITEM_ACTION_SEQUENCES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev836.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_ITEM_ACTION_SEQUENCES}.pointer_motion_actions */
EIF_REFERENCE F1555_15036 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("pointer_motion_actions", 1554, Current, 0, 0, 21228);
	RTGC;
	RTHOOK(1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R12093[Dtype(Current)-1558])(Current);
	Result = F229_4050(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_ITEM_ACTION_SEQUENCES}.pointer_button_press_actions */
EIF_REFERENCE F1555_15037 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("pointer_button_press_actions", 1554, Current, 0, 0, 21229);
	RTGC;
	RTHOOK(1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R12093[Dtype(Current)-1558])(Current);
	Result = F229_4052(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_ITEM_ACTION_SEQUENCES}.pointer_double_press_actions */
EIF_REFERENCE F1555_15038 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("pointer_double_press_actions", 1554, Current, 0, 0, 21230);
	RTGC;
	RTHOOK(1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R12093[Dtype(Current)-1558])(Current);
	Result = F229_4054(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit836 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
