
#ifndef _C17_ev814_
#define _C17_ev814_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1533_14930(EIF_REFERENCE);
extern void F1533_14931(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1533_14932(EIF_REFERENCE);
extern void F1533_14933(EIF_REFERENCE);
extern void EIF_Minit814(void);
extern void F1766_18536(EIF_REFERENCE, EIF_REFERENCE);
extern void F1766_18534(EIF_REFERENCE);
extern EIF_REFERENCE F1766_18535(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
