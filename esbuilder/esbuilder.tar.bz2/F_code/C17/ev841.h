
#ifndef _C17_ev841_
#define _C17_ev841_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1560_15089(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1560_15092(EIF_REFERENCE);
extern EIF_REFERENCE F1560_15096(EIF_REFERENCE);
extern void F1560_15097(EIF_REFERENCE);
extern void EIF_Minit841(void);
extern void F1885_20545(EIF_REFERENCE);
extern void F1885_20559(EIF_REFERENCE);
extern void F1885_20558(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
