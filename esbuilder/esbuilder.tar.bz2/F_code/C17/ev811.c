/*
 * Code for class EV_CHECKABLE_LIST_ACTION_SEQUENCES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev811.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_CHECKABLE_LIST_ACTION_SEQUENCES}.check_actions */
EIF_REFERENCE F1530_14915 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("check_actions", 1529, Current, 0, 0, 21117);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O10182[Dtype(Current)-1344]);
	Result = F164_2263(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_CHECKABLE_LIST_ACTION_SEQUENCES}.uncheck_actions */
EIF_REFERENCE F1530_14916 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("uncheck_actions", 1529, Current, 0, 0, 21118);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O10182[Dtype(Current)-1344]);
	Result = F164_2265(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit811 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
