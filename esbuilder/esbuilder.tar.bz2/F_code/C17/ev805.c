/*
 * Code for class EV_GRID_EDITABLE_ITEM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev805.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GRID_EDITABLE_ITEM}.initialize */
void F1524_14888 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("initialize", 1523, Current, 0, 0, 21094);
	RTGC;
	RTHOOK(1);
	F1521_14795(Current);
	RTHOOK(2);
	F1519_14779(Current, (EIF_BOOLEAN) 1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_GRID_EDITABLE_ITEM}.set_text_validation_agent */
void F1524_14889 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_text_validation_agent", 1523, Current, 0, 1, 21095);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {EV_GRID_EDITABLE_ITEM}.deactivate */
void F1524_14892 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTEAA("deactivate", 1523, Current, 2, 0, 21098);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb2 = F1345_12299(loc1);
		tb1 = tb2;
	}
	if (tb1) {
		RTHOOK(2);
		tr1 = F1574_15172(loc1);
		F1169_10229(RTCW(tr1));
		RTHOOK(3);
		tb1 = '\0';
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_9_0_)) {
			tb2 = '\01';
			if (!(EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_7_) == NULL)) {
				tb3 = '\0';
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				loc2 = tr1;
				if (EIF_TEST(loc2)) {
					tr1 = F1369_12571(loc1);
					tb4 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(loc2+ _PTROFF_4_3_0_3_0_0_))(
						*(EIF_POINTER *)(loc2+ _PTROFF_4_3_0_3_0_1_),
						*(EIF_REFERENCE *)(loc2 + _REFACS_1_), tr1);
					tb4 = tb4;
					tb3 = tb4;
				}
				tb2 = tb3;
			}
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(4);
			tr1 = F1369_12571(loc1);
			F1521_14796(Current, tr1);
		}
		RTHOOK(5);
		F1345_12288(loc1);
		RTHOOK(6);
		*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) NULL;
		RTHOOK(7);
		F1519_14781(Current);
	}
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EV_GRID_EDITABLE_ITEM}.update_popup_dimensions */
void F1524_14893 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc5);
	RTLR(1,arg1);
	RTLR(2,loc6);
	RTLR(3,Current);
	RTLR(4,loc8);
	RTLR(5,tr1);
	RTLR(6,loc7);
	RTLR(7,loc9);
	RTLIU(8);
	
	RTEAA("update_popup_dimensions", 1523, Current, 9, 1, 21099);
	RTGC;
	RTHOOK(1);
	loc5 = F1576_15208(RTCW(arg1));
	RTHOOK(2);
	loc6 = F1519_14761(Current);
	RTHOOK(3);
	RTCT0("l_parent /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc6 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTHOOK(4);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_4_) >= ((EIF_INTEGER_32) 0L))) {
		RTHOOK(5);
		loc1 = F1521_14815(Current);
	}
	RTHOOK(6);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc8 = tr1;
	if (EIF_TEST(loc8)) {
		RTHOOK(7);
		ti4_1 = F1362_12530(loc8);
		ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_3_);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + ti4_1) + ti4_2);
	}
	RTHOOK(8);
	loc2 = F1519_14764(Current);
	ti4_1 = F1594_15610(RTCW(loc6));
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 + loc1) - ti4_1);
	RTHOOK(9);
	ti4_1 = eif_max_int32 (loc2,((EIF_INTEGER_32) 0L));
	ti4_1 = eif_min_int32 (ti4_1,loc1);
	loc2 = (EIF_INTEGER_32) ti4_1;
	RTHOOK(10);
	loc3 = F1362_12530(RTCW(arg1));
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_2_0_0_);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc3 - loc2) - ti4_1);
	RTHOOK(11);
	loc4 = F1362_12533(RTCW(loc5));
	ti4_1 = F1521_14821(Current);
	loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc4 - ti4_1) / ((EIF_INTEGER_32) 2L));
	RTHOOK(12);
	F1575_15200(RTCW(loc5), ((EIF_INTEGER_32) 0L));
	RTHOOK(13);
	ti4_1 = F1362_12526(RTCW(arg1));
	F1363_12536(RTCW(arg1), (EIF_INTEGER_32) (ti4_1 + loc2));
	RTHOOK(14);
	F1363_12539(RTCW(arg1), loc3);
	RTHOOK(15);
	ti4_1 = F1519_14767(Current);
	ti4_2 = F1519_14768(Current);
	loc7 = F1521_14840(Current, ti4_1, ti4_2);
	RTHOOK(16);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc9 = tr1;
	if (EIF_TEST(loc9)) {
		RTHOOK(17);
		(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(loc9+ _PTROFF_4_2_0_3_0_0_))(
			*(EIF_POINTER *)(loc9+ _PTROFF_4_2_0_3_0_1_),
			*(EIF_REFERENCE *)(loc9 + _REFACS_1_), Current, loc7);
	}
	RTHOOK(18);
	ti4_1 = F1362_12527(RTCW(arg1));
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc7)+ _LNGOFF_0_1_0_5_);
	F1363_12537(RTCW(arg1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + ti4_2) - loc4));
	RTHOOK(19);
	ti4_1 = F1521_14821(Current);
	F1363_12540(RTCW(arg1), ti4_1);
	RTHOOK(20);
	RTLE;
	RTEE;
}

/* {EV_GRID_EDITABLE_ITEM}.handle_key */
void F1524_14894 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,loc4);
	RTLIU(5);
	
	RTEAA("handle_key", 1523, Current, 4, 1, 21100);
	RTGC;
	RTHOOK(1);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
	switch (ti4_1) {
		case 42L:
			RTHOOK(2);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_9_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			RTHOOK(3);
			loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			break;
		case 41L:
		case 43L:
			RTHOOK(4);
			loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			RTHOOK(5);
			loc2 = '\0';
			tr1 = F1519_14761(Current);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				tb1 = F1594_15726(loc3);
				loc2 = tb1;
			}
			break;
	}
	RTHOOK(6);
	tb1 = '\0';
	if (loc1) {
		tr1 = F1519_14761(Current);
		loc4 = tr1;
		tb1 = EIF_TEST(loc4);
	}
	if (tb1) {
		RTHOOK(7);
		if (loc2) {
			RTHOOK(8);
			tr1 = RTLNS(eif_new_type(2025, 0x00).id, 2025, _OBJSIZ_0_0_0_1_0_0_0_0_);
			F2026_22953(RTCW(tr1), ((EIF_INTEGER_32) 43L));
			F1594_15764(loc4, tr1);
		}
		RTHOOK(9);
		tr1 = F1594_15583(loc4);
		if ((EIF_BOOLEAN)(tr1 == Current)) {
			RTHOOK(10);
			F1524_14892(Current);
		}
	}
	RTHOOK(11);
	RTLE;
	RTEE;
}

/* {EV_GRID_EDITABLE_ITEM}.activate_action */
void F1524_14896 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,arg1);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLIU(8);
	
	RTEAA("activate_action", 1523, Current, 3, 1, 21102);
	RTGC;
	RTHOOK(1);
	loc1 = RTLNSMART(eif_new_type(1610, 0).id);
	F1345_12285(RTCW(loc1));
	RTHOOK(2);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) loc1;
	RTHOOK(3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTHOOK(4);
		F1371_12585(RTCW(loc1), loc3);
	}
	RTHOOK(5);
	F1369_12572(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
	RTHOOK(6);
	if (F1521_14827(Current)) {
		RTHOOK(7);
		F1370_12581(RTCW(loc1));
	} else {
		RTHOOK(8);
		if (F1521_14826(Current)) {
			RTHOOK(9);
			F1370_12580(RTCW(loc1));
		}
	}
	RTHOOK(10);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_3_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R15881[Dtype(RTCW(tr1))-1858])(tr1);
	RTHOOK(11);
	ti4_1 = F1519_14768(Current);
	F1575_15201(RTCW(loc1), ti4_1);
	RTHOOK(12);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = F1755_18442(RTCW(tr1));
	RTHOOK(13);
	F1360_12514(RTCW(loc1), loc2);
	RTHOOK(14);
	F1360_12514(RTCW(arg1), loc2);
	RTHOOK(15);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = F1755_18443(RTCW(tr1));
	F1360_12513(RTCW(loc1), tr1);
	RTHOOK(16);
	F1576_15217(RTCW(arg1), loc1);
	RTHOOK(17);
	F1524_14893(Current, arg1);
	RTHOOK(18);
	tr1 = F1638_16077(RTCW(arg1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1493,0xFFF9,0,1419,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A805_156, (EIF_POINTER) _A805_156, (EIF_POINTER)(F1524_14897),tr2, 1, 0);
	}
	F1169_10217(RTCW(tr1), tr3);
	RTHOOK(19);
	RTLE;
	RTEE;
}

/* {EV_GRID_EDITABLE_ITEM}.initialize_actions */
void F1524_14897 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLIU(7);
	
	RTEAA("initialize_actions", 1523, Current, 1, 0, 21103);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		tr1 = F1574_15172(loc1);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1419,1682,1493,0xFFF9,0,1419,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNTS(typres0.id, 3, 0);
		}
		tr3 = F636_8700(Current);
		((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
		RTAR(tr2,tr3);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr3 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr3+1)->it_r = Current;
		RTAR(tr3,Current);
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1493,0xFFF9,0,1419,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr4= RTLNRF(typres0.id, (EIF_POINTER) __A805_151, (EIF_POINTER) _A805_151, (EIF_POINTER)(F1524_14892),tr3, 1, 0);
		}
		((EIF_TYPED_VALUE *)tr2+2)->it_r = tr4;
		RTAR(tr2,tr4);
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1493,0xFFF9,0,1419,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3= RTLNRF(typres0.id, (EIF_POINTER) __A964_94, (EIF_POINTER) _A964_94, (EIF_POINTER)(F1683_17050),tr2, 1, 0);
		}
		F1169_10217(RTCW(tr1), tr3);
		RTHOOK(3);
		F1575_15190(loc1);
		RTHOOK(4);
		ti4_1 = F1608_15874(loc1);
		F1608_15886(loc1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
		RTHOOK(5);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_9_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		RTHOOK(6);
		tr1 = F1574_15168(loc1);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr2 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
		RTAR(tr2,Current);
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1493,0xFFF9,1,1419,2025,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr5= RTLNRF(typres0.id, (EIF_POINTER) __A805_153_2, (EIF_POINTER) _A805_153_2, (EIF_POINTER)(R11974[Dtype((((EIF_TYPED_VALUE *)tr2)[1].it_r)) - 1523]),tr2, 1, 1);
		}
		F1169_10217(RTCW(tr1), tr5);
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

void EIF_Minit805 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
