
#ifndef _C17_ev818_
#define _C17_ev818_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1537_14969(EIF_REFERENCE);
extern void F1537_14970(EIF_REFERENCE);
extern void EIF_Minit818(void);
extern void F1770_18566(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
