/*
 * Code for class SHORTCUT_PREFERENCE_GRID_EDITABLE_ITEM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sh806.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SHORTCUT_PREFERENCE_GRID_EDITABLE_ITEM}.handle_key */
void F1525_14898 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("handle_key", 1524, Current, 0, 1, 21105);
	RTGC;
	RTHOOK(1);
	RTLE;
	RTEE;
}

void EIF_Minit806 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
