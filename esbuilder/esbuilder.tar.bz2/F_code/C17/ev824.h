
#ifndef _C17_ev824_
#define _C17_ev824_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1543_14984(EIF_REFERENCE);
extern EIF_REFERENCE F1543_14985(EIF_REFERENCE);
extern void EIF_Minit824(void);
extern EIF_REFERENCE F214_2920(EIF_REFERENCE);
extern EIF_REFERENCE F214_2918(EIF_REFERENCE);
extern long O10182[];

#ifdef __cplusplus
}
#endif

#endif
