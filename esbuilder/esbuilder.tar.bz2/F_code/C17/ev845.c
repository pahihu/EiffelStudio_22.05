/*
 * Code for class EV_LIST_ITEM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev845.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_LIST_ITEM}.default_identifier_name */
EIF_REFERENCE F1564_15114 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("default_identifier_name", 1563, Current, 1, 0, 21304);
	RTGC;
	RTHOOK(1);
	tr1 = F1558_15073(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		Result = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1508_14451(RTCW(Result), ((EIF_INTEGER_32) 5L));
		RTHOOK(3);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '#';
		F1510_14579(RTCW(Result), tw1);
		RTHOOK(4);
		ti4_1 = F1376_12680(loc1, Current, ((EIF_INTEGER_32) 1L));
		F1510_14569(RTCW(Result), ti4_1);
	} else {
		RTHOOK(5);
		Result = F1357_12491(Current);
		RTHOOK(6);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) Result;
	}
	RTHOOK(7);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_LIST_ITEM}.implementation */
EIF_REFERENCE F1564_15119 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {EV_LIST_ITEM}.create_implementation */
void F1564_15120 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1563, Current, 0, 0, 21310);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1886, 0x00).id, 1886, _OBJSIZ_23_5_6_0_0_0_0_0_);
	F1887_20593(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit845 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
