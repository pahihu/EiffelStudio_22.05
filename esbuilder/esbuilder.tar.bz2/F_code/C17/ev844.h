
#ifndef _C17_ev844_
#define _C17_ev844_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1563_15110(EIF_REFERENCE);
extern EIF_REFERENCE F1563_15112(EIF_REFERENCE);
extern void F1563_15113(EIF_REFERENCE);
extern void EIF_Minit844(void);
extern EIF_REFERENCE F1889_20637(EIF_REFERENCE);
extern void F1890_20647(EIF_REFERENCE);
extern EIF_INTEGER_32 F1376_12683(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
