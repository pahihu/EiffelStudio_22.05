/*
 * Code for class EV_PICK_AND_DROPABLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev838.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PICK_AND_DROPABLE}.configurable_target_menu_handler */
EIF_REFERENCE F1557_15052 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("configurable_target_menu_handler", 1556, Current, 0, 0, 21235);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O10182[Dtype(Current)-1344]);
	Result = *(EIF_REFERENCE *)(RTCW(tr1) + O14908[Dtype(tr1)-1770]);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_PICK_AND_DROPABLE}.set_pebble */
void F1557_15053 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEAA("set_pebble", 1556, Current, 0, 1, 21236);
	RTGC;
	
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + O10182[Dtype(Current)-1344]);
	tr2 = RTCCL(arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R14915[Dtype(RTCW(tr1))-1786])(tr1, tr2);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_PICK_AND_DROPABLE}.remove_pebble */
void F1557_15054 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("remove_pebble", 1556, Current, 0, 0, 21237);
	RTGC;
	
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + O10182[Dtype(Current)-1344]);
	F1771_18587(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_PICK_AND_DROPABLE}.set_pebble_function */
void F1557_15055 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("set_pebble_function", 1556, Current, 0, 1, 21238);
	RTGC;
	
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + O10182[Dtype(Current)-1344]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R14916[Dtype(RTCW(tr1))-1786])(tr1, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_PICK_AND_DROPABLE}.set_accept_cursor */
void F1557_15062 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("set_accept_cursor", 1556, Current, 0, 1, 21245);
	RTGC;
	
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + O10182[Dtype(Current)-1344]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R14926[Dtype(RTCW(tr1))-1786])(tr1, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_PICK_AND_DROPABLE}.set_deny_cursor */
void F1557_15063 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("set_deny_cursor", 1556, Current, 0, 1, 21246);
	RTGC;
	
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + O10182[Dtype(Current)-1344]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R14927[Dtype(RTCW(tr1))-1786])(tr1, arg1);
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit838 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
