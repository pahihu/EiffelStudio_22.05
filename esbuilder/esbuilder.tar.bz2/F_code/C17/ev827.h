
#ifndef _C17_ev827_
#define _C17_ev827_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1546_14994(EIF_REFERENCE);
extern EIF_REFERENCE F1546_14995(EIF_REFERENCE);
extern void EIF_Minit827(void);
extern EIF_REFERENCE F224_4031(EIF_REFERENCE);
extern EIF_REFERENCE F224_4032(EIF_REFERENCE);
extern char *(*R12060[])();

#ifdef __cplusplus
}
#endif

#endif
