
#ifndef _C17_ev811_
#define _C17_ev811_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1530_14915(EIF_REFERENCE);
extern EIF_REFERENCE F1530_14916(EIF_REFERENCE);
extern void EIF_Minit811(void);
extern EIF_REFERENCE F164_2263(EIF_REFERENCE);
extern EIF_REFERENCE F164_2265(EIF_REFERENCE);
extern long O10182[];

#ifdef __cplusplus
}
#endif

#endif
