
#ifndef _C17_ev834_
#define _C17_ev834_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1553_15029(EIF_REFERENCE);
extern EIF_REFERENCE F1553_15031(EIF_REFERENCE);
extern EIF_REFERENCE F1553_15032(EIF_REFERENCE);
extern void EIF_Minit834(void);
extern EIF_REFERENCE F227_4045(EIF_REFERENCE);
extern EIF_REFERENCE F227_4039(EIF_REFERENCE);
extern EIF_REFERENCE F227_4043(EIF_REFERENCE);
extern char *(*R12086[])();

#ifdef __cplusplus
}
#endif

#endif
