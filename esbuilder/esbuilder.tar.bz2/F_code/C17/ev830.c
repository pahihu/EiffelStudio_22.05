/*
 * Code for class EV_DOCKABLE_TARGET
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev830.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DOCKABLE_TARGET}.veto_dock_function */
EIF_REFERENCE F1549_15014 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("veto_dock_function", 1548, Current, 0, 0, 21209);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O10182[Dtype(Current)-1344]);
	Result = *(EIF_REFERENCE *)(RTCW(tr1) + O14599[Dtype(tr1)-1734]);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_DOCKABLE_TARGET}.is_docking_enabled */
EIF_BOOLEAN F1549_15015 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("is_docking_enabled", 1548, Current, 0, 0, 21210);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O10182[Dtype(Current)-1344]);
	Result = *(EIF_BOOLEAN *)(RTCW(tr1) + O14600[Dtype(tr1)-1734]);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_DOCKABLE_TARGET}.enable_docking */
void F1549_15016 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("enable_docking", 1548, Current, 0, 0, 21211);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + O10182[Dtype(Current)-1344]);
	F1735_18152(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

void EIF_Minit830 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
