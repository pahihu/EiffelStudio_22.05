/*
 * Code for class EV_COLOR_DIALOG
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev815.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_COLOR_DIALOG}.color */
EIF_REFERENCE F1534_14934 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("color", 1533, Current, 0, 0, 21136);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1767_18540(RTCW(tr1));
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_COLOR_DIALOG}.set_color */
void F1534_14935 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTEAA("set_color", 1533, Current, 0, 1, 21137);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1767_18541(RTCW(tr1), arg1);
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_COLOR_DIALOG}.implementation */
EIF_REFERENCE F1534_14936 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


/* {EV_COLOR_DIALOG}.create_implementation */
void F1534_14937 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1533, Current, 0, 0, 21139);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1766, 0x00).id, 1766, _OBJSIZ_9_5_0_1_0_1_0_0_);
	F1767_18539(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit815 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
