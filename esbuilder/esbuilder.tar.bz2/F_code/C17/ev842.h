
#ifndef _C17_ev842_
#define _C17_ev842_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1561_15098(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit842(void);

#ifdef __cplusplus
}
#endif

#endif
