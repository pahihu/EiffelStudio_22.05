/*
 * Code for class EV_GRID_LABEL_ITEM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev802.h"
#include "eif_helpers.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GRID_LABEL_ITEM}.make_with_text */
void F1521_14794 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("make_with_text", 1520, Current, 0, 1, 21002);
	RTGC;
	RTHOOK(1);
	F1345_12285(Current);
	RTHOOK(2);
	F1521_14796(Current, arg1);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_GRID_LABEL_ITEM}.initialize */
void F1521_14795 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("initialize", 1520, Current, 0, 0, 21003);
	RTGC;
	RTHOOK(1);
	tr1 = RTMS32_EX_H("",0,0);
	F1521_14796(Current, tr1);
	RTHOOK(2);
	*(EIF_INTEGER_32 *)(Current + O11933[Dtype(Current)-1520]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTHOOK(3);
	F1521_14805(Current, ((EIF_INTEGER_32) 2L));
	RTHOOK(4);
	F1521_14808(Current);
	RTHOOK(5);
	F1521_14809(Current);
	RTHOOK(6);
	F1521_14813(Current);
	RTHOOK(7);
	F1345_12294(Current);
	RTHOOK(8);
	RTLE;
	RTEE;
}

/* {EV_GRID_LABEL_ITEM}.set_text */
void F1521_14796 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("set_text", 1520, Current, 1, 1, 21004);
	RTGC;
	RTHOOK(1);
	tr1 = F1500_14214(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1757_18460(RTCW(tr1));
	RTHOOK(3);
	loc1 = F1519_14761(Current);
	RTHOOK(4);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tb2 = F1345_12289(RTCW(loc1));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_3_);
		F1798_19277(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_));
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_GRID_LABEL_ITEM}.set_font */
void F1521_14798 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEAA("set_font", 1520, Current, 1, 1, 21006);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1757_18460(RTCW(tr1));
	RTHOOK(3);
	tr1 = F1519_14761(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(4);
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_3_);
		F1798_19277(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_));
	}
	RTHOOK(6);
	RTLE;
	RTEE;
}

/* {EV_GRID_LABEL_ITEM}.set_pixmap */
void F1521_14799 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("set_pixmap", 1520, Current, 1, 1, 21007);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	tr1 = F1519_14761(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_3_);
		F1798_19277(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_));
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_GRID_LABEL_ITEM}.remove_pixmap */
void F1521_14800 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("remove_pixmap", 1520, Current, 1, 0, 21008);
	RTGC;
	RTHOOK(1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) NULL;
	RTHOOK(2);
	tr1 = F1519_14761(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_3_);
		F1798_19277(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_));
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_GRID_LABEL_ITEM}.set_left_border */
void F1521_14801 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_left_border", 1520, Current, 1, 1, 21009);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O11933[Dtype(Current)-1520]) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	tr1 = F1519_14761(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_3_);
		F1798_19277(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_));
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_GRID_LABEL_ITEM}.set_right_border */
void F1521_14802 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_right_border", 1520, Current, 1, 1, 21010);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O11915[Dtype(Current)-1520]) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	tr1 = F1519_14761(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_3_);
		F1798_19277(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_));
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_GRID_LABEL_ITEM}.set_spacing */
void F1521_14805 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_spacing", 1520, Current, 1, 1, 21013);
	RTGC;
	RTHOOK(1);
	*(EIF_INTEGER_32 *)(Current + O11918[Dtype(Current)-1520]) = (EIF_INTEGER_32) arg1;
	RTHOOK(2);
	tr1 = F1519_14761(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_3_);
		F1798_19277(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_));
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_GRID_LABEL_ITEM}.align_text_center */
void F1521_14806 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_8 ti1_1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("align_text_center", 1520, Current, 1, 0, 21014);
	RTGC;
	RTHOOK(1);
	ti1_1 = *(EIF_INTEGER_8 *)(Current + O11932[dtype-1520]);
	ti1_1 = eif_set_bit(EIF_INTEGER_8,ti1_1,(EIF_BOOLEAN) 0,((EIF_INTEGER_32) 1L));
	*(EIF_INTEGER_8 *)(Current + O11932[dtype-1520]) = (EIF_INTEGER_8) ti1_1;
	RTHOOK(2);
	ti1_1 = *(EIF_INTEGER_8 *)(Current + O11932[dtype-1520]);
	ti1_1 = eif_set_bit(EIF_INTEGER_8,ti1_1,(EIF_BOOLEAN) 1,((EIF_INTEGER_32) 2L));
	*(EIF_INTEGER_8 *)(Current + O11932[dtype-1520]) = (EIF_INTEGER_8) ti1_1;
	RTHOOK(3);
	ti1_1 = *(EIF_INTEGER_8 *)(Current + O11932[dtype-1520]);
	ti1_1 = eif_set_bit(EIF_INTEGER_8,ti1_1,(EIF_BOOLEAN) 0,((EIF_INTEGER_32) 3L));
	*(EIF_INTEGER_8 *)(Current + O11932[dtype-1520]) = (EIF_INTEGER_8) ti1_1;
	RTHOOK(4);
	tr1 = F1519_14761(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_3_);
		F1798_19277(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_));
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_GRID_LABEL_ITEM}.align_text_right */
void F1521_14807 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_8 ti1_1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("align_text_right", 1520, Current, 1, 0, 21015);
	RTGC;
	RTHOOK(1);
	ti1_1 = *(EIF_INTEGER_8 *)(Current + O11932[dtype-1520]);
	ti1_1 = eif_set_bit(EIF_INTEGER_8,ti1_1,(EIF_BOOLEAN) 0,((EIF_INTEGER_32) 1L));
	*(EIF_INTEGER_8 *)(Current + O11932[dtype-1520]) = (EIF_INTEGER_8) ti1_1;
	RTHOOK(2);
	ti1_1 = *(EIF_INTEGER_8 *)(Current + O11932[dtype-1520]);
	ti1_1 = eif_set_bit(EIF_INTEGER_8,ti1_1,(EIF_BOOLEAN) 0,((EIF_INTEGER_32) 2L));
	*(EIF_INTEGER_8 *)(Current + O11932[dtype-1520]) = (EIF_INTEGER_8) ti1_1;
	RTHOOK(3);
	ti1_1 = *(EIF_INTEGER_8 *)(Current + O11932[dtype-1520]);
	ti1_1 = eif_set_bit(EIF_INTEGER_8,ti1_1,(EIF_BOOLEAN) 1,((EIF_INTEGER_32) 3L));
	*(EIF_INTEGER_8 *)(Current + O11932[dtype-1520]) = (EIF_INTEGER_8) ti1_1;
	RTHOOK(4);
	tr1 = F1519_14761(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_3_);
		F1798_19277(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_));
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_GRID_LABEL_ITEM}.align_text_left */
void F1521_14808 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_8 ti1_1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("align_text_left", 1520, Current, 1, 0, 21016);
	RTGC;
	RTHOOK(1);
	ti1_1 = *(EIF_INTEGER_8 *)(Current + O11932[dtype-1520]);
	ti1_1 = eif_set_bit(EIF_INTEGER_8,ti1_1,(EIF_BOOLEAN) 1,((EIF_INTEGER_32) 1L));
	*(EIF_INTEGER_8 *)(Current + O11932[dtype-1520]) = (EIF_INTEGER_8) ti1_1;
	RTHOOK(2);
	ti1_1 = *(EIF_INTEGER_8 *)(Current + O11932[dtype-1520]);
	ti1_1 = eif_set_bit(EIF_INTEGER_8,ti1_1,(EIF_BOOLEAN) 0,((EIF_INTEGER_32) 2L));
	*(EIF_INTEGER_8 *)(Current + O11932[dtype-1520]) = (EIF_INTEGER_8) ti1_1;
	RTHOOK(3);
	ti1_1 = *(EIF_INTEGER_8 *)(Current + O11932[dtype-1520]);
	ti1_1 = eif_set_bit(EIF_INTEGER_8,ti1_1,(EIF_BOOLEAN) 0,((EIF_INTEGER_32) 3L));
	*(EIF_INTEGER_8 *)(Current + O11932[dtype-1520]) = (EIF_INTEGER_8) ti1_1;
	RTHOOK(4);
	tr1 = F1519_14761(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_3_);
		F1798_19277(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_));
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_GRID_LABEL_ITEM}.align_text_vertically_center */
void F1521_14809 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_8 ti1_1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("align_text_vertically_center", 1520, Current, 1, 0, 21017);
	RTGC;
	RTHOOK(1);
	ti1_1 = *(EIF_INTEGER_8 *)(Current + O11932[dtype-1520]);
	ti1_1 = eif_set_bit(EIF_INTEGER_8,ti1_1,(EIF_BOOLEAN) 0,((EIF_INTEGER_32) 4L));
	*(EIF_INTEGER_8 *)(Current + O11932[dtype-1520]) = (EIF_INTEGER_8) ti1_1;
	RTHOOK(2);
	ti1_1 = *(EIF_INTEGER_8 *)(Current + O11932[dtype-1520]);
	ti1_1 = eif_set_bit(EIF_INTEGER_8,ti1_1,(EIF_BOOLEAN) 1,((EIF_INTEGER_32) 5L));
	*(EIF_INTEGER_8 *)(Current + O11932[dtype-1520]) = (EIF_INTEGER_8) ti1_1;
	RTHOOK(3);
	ti1_1 = *(EIF_INTEGER_8 *)(Current + O11932[dtype-1520]);
	ti1_1 = eif_set_bit(EIF_INTEGER_8,ti1_1,(EIF_BOOLEAN) 0,((EIF_INTEGER_32) 6L));
	*(EIF_INTEGER_8 *)(Current + O11932[dtype-1520]) = (EIF_INTEGER_8) ti1_1;
	RTHOOK(4);
	tr1 = F1519_14761(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(5);
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_3_);
		F1798_19277(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_));
	}
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_GRID_LABEL_ITEM}.enable_full_select */
void F1521_14813 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_8 ti1_1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("enable_full_select", 1520, Current, 1, 0, 21021);
	RTGC;
	RTHOOK(1);
	ti1_1 = *(EIF_INTEGER_8 *)(Current + O11932[dtype-1520]);
	ti1_1 = eif_set_bit(EIF_INTEGER_8,ti1_1,(EIF_BOOLEAN) 1,((EIF_INTEGER_32) 7L));
	*(EIF_INTEGER_8 *)(Current + O11932[dtype-1520]) = (EIF_INTEGER_8) ti1_1;
	RTHOOK(2);
	tr1 = F1519_14761(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_3_);
		F1798_19277(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_));
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

/* {EV_GRID_LABEL_ITEM}.left_border */
EIF_INTEGER_32 F1521_14815 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("left_border", 1520, Current, 0, 0, 21023);
	RTGC;
	RTHOOK(1);
	Result = *(EIF_INTEGER_32 *)(Current + O11933[Dtype(Current)-1520]);
	RTHOOK(2);
	if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) -1L))) {
		RTHOOK(3);
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_LABEL_ITEM}.text_width */
EIF_INTEGER_32 F1521_14820 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("text_width", 1520, Current, 0, 0, 21028);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1757_18458(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_LABEL_ITEM}.text_height */
EIF_INTEGER_32 F1521_14821 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("text_height", 1520, Current, 0, 0, 21029);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1757_18459(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_LABEL_ITEM}.is_left_aligned */
EIF_BOOLEAN F1521_14825 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 ti1_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_left_aligned", 1520, Current, 0, 0, 21033);
	RTGC;
	RTHOOK(1);
	ti1_1 = *(EIF_INTEGER_8 *)(Current + O11932[Dtype(Current)-1520]);
	Result = eif_bit_test(EIF_INTEGER_8,ti1_1,((EIF_INTEGER_32) 1L));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_LABEL_ITEM}.is_center_aligned */
EIF_BOOLEAN F1521_14826 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 ti1_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_center_aligned", 1520, Current, 0, 0, 21034);
	RTGC;
	RTHOOK(1);
	ti1_1 = *(EIF_INTEGER_8 *)(Current + O11932[Dtype(Current)-1520]);
	Result = eif_bit_test(EIF_INTEGER_8,ti1_1,((EIF_INTEGER_32) 2L));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_LABEL_ITEM}.is_right_aligned */
EIF_BOOLEAN F1521_14827 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 ti1_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_right_aligned", 1520, Current, 0, 0, 21035);
	RTGC;
	RTHOOK(1);
	ti1_1 = *(EIF_INTEGER_8 *)(Current + O11932[Dtype(Current)-1520]);
	Result = eif_bit_test(EIF_INTEGER_8,ti1_1,((EIF_INTEGER_32) 3L));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_LABEL_ITEM}.is_top_aligned */
EIF_BOOLEAN F1521_14828 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 ti1_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_top_aligned", 1520, Current, 0, 0, 21036);
	RTGC;
	RTHOOK(1);
	ti1_1 = *(EIF_INTEGER_8 *)(Current + O11932[Dtype(Current)-1520]);
	Result = eif_bit_test(EIF_INTEGER_8,ti1_1,((EIF_INTEGER_32) 4L));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_LABEL_ITEM}.is_bottom_aligned */
EIF_BOOLEAN F1521_14830 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 ti1_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_bottom_aligned", 1520, Current, 0, 0, 21038);
	RTGC;
	RTHOOK(1);
	ti1_1 = *(EIF_INTEGER_8 *)(Current + O11932[Dtype(Current)-1520]);
	Result = eif_bit_test(EIF_INTEGER_8,ti1_1,((EIF_INTEGER_32) 6L));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_LABEL_ITEM}.is_full_select_enabled */
EIF_BOOLEAN F1521_14832 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_8 ti1_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("is_full_select_enabled", 1520, Current, 0, 0, 21040);
	RTGC;
	RTHOOK(1);
	ti1_1 = *(EIF_INTEGER_8 *)(Current + O11932[Dtype(Current)-1520]);
	Result = eif_bit_test(EIF_INTEGER_8,ti1_1,((EIF_INTEGER_32) 7L));
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_LABEL_ITEM}.implementation */
EIF_REFERENCE F1521_14834 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


/* {EV_GRID_LABEL_ITEM}.create_implementation */
void F1521_14836 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1520, Current, 0, 0, 21044);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1756, 0x00).id, 1756, _OBJSIZ_21_4_0_3_0_0_0_0_);
	F1757_18456(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_GRID_LABEL_ITEM}.create_interface_objects */
void F1521_14837 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_interface_objects", 1520, Current, 0, 0, 21045);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNSMART(eif_new_type(1509, 0).id);
	F1500_14155(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_GRID_LABEL_ITEM}.grid_label_item_layout */
static EIF_REFERENCE F1521_14839_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("grid_label_item_layout", 1520, Current, 0, 0, 20999);
	RTGC;
	RTOSP (14839);
#define Result RTOSR(14839)
	RTOC_NEW(Result);
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(24, 0x00).id, 24, _OBJSIZ_0_1_0_7_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (14839);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1521_14839 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14839,F1521_14839_body,(Current));
}

/* {EV_GRID_LABEL_ITEM}.computed_initial_grid_label_item_layout */
EIF_REFERENCE F1521_14840 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc12 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc13 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("computed_initial_grid_label_item_layout", 1520, Current, 13, 2, 21000);
	RTGC;
	RTHOOK(1);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	RTHOOK(2);
	loc8 = F1521_14815(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O11915[dtype-1520]);
	loc8 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 - loc8) - ti4_1);
	RTHOOK(3);
	loc9 = *(EIF_INTEGER_32 *)(Current + O11916[dtype-1520]);
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O11917[dtype-1520]);
	loc9 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg2 - loc9) - ti4_1);
	RTHOOK(4);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTHOOK(5);
		loc2 = F1362_12530(RTCW(loc1));
		RTHOOK(6);
		loc3 = F1362_12531(RTCW(loc1));
		RTHOOK(7);
		loc4 = *(EIF_INTEGER_32 *)(Current + O11918[dtype-1520]);
	}
	RTHOOK(8);
	loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc8 - loc2) - loc4);
	RTHOOK(9);
	if ((EIF_BOOLEAN) (loc5 > ((EIF_INTEGER_32) 0L))) {
		RTHOOK(10);
		if (F1521_14825(Current)) {
		} else {
			RTHOOK(11);
			if (F1521_14827(Current)) {
				RTHOOK(12);
				loc6 = F1521_14820(Current);
				loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 - loc6);
			} else {
				RTHOOK(13);
				loc6 = F1521_14820(Current);
				loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc5 - loc6) / ((EIF_INTEGER_32) 2L));
			}
		}
	}
	RTHOOK(14);
	ti4_1 = eif_max_int32 (loc6,((EIF_INTEGER_32) 1L));
	loc6 = (EIF_INTEGER_32) ti4_1;
	RTHOOK(15);
	if (F1521_14828(Current)) {
	} else {
		RTHOOK(16);
		if (F1521_14830(Current)) {
			RTHOOK(17);
			loc7 = F1521_14821(Current);
			loc7 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc9 - loc7);
		} else {
			RTHOOK(18);
			loc7 = F1521_14821(Current);
			loc7 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc9 - loc7) / ((EIF_INTEGER_32) 2L));
		}
	}
	RTHOOK(19);
	ti4_1 = eif_max_int32 (loc7,((EIF_INTEGER_32) 0L));
	loc7 = (EIF_INTEGER_32) ti4_1;
	RTHOOK(20);
	loc12 = F1521_14815(Current);
	RTHOOK(21);
	loc10 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc12 + loc2) + loc4) + loc6);
	RTHOOK(22);
	loc11 = *(EIF_INTEGER_32 *)(Current + O11916[dtype-1520]);
	loc11 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc11 + loc7);
	RTHOOK(23);
	loc13 = F1521_14821(Current);
	loc13 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc11 + (EIF_INTEGER_32) (loc13 / ((EIF_INTEGER_32) 2L))) - (EIF_INTEGER_32) (loc3 / ((EIF_INTEGER_32) 2L)));
	RTHOOK(24);
	if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc13 + loc3) > (EIF_INTEGER_32) (arg2 - *(EIF_INTEGER_32 *)(Current + O11917[dtype-1520])))) {
		RTHOOK(25);
		loc13 = *(EIF_INTEGER_32 *)(Current + O11917[dtype-1520]);
		loc13 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg2 - loc13) - loc3);
	}
	RTHOOK(26);
	ti4_1 = eif_max_int32 (loc13,*(EIF_INTEGER_32 *)(Current + O11916[dtype-1520]));
	loc13 = (EIF_INTEGER_32) ti4_1;
	RTHOOK(27);
	Result = RTOSCF(14839,F1521_14839, (Current));
	RTHOOK(28);
	F25_387(RTCW(Result), loc12);
	RTHOOK(29);
	F25_388(RTCW(Result), loc13);
	RTHOOK(30);
	F25_389(RTCW(Result), loc10);
	RTHOOK(31);
	F25_390(RTCW(Result), loc11);
	RTHOOK(32);
	ti4_1 = eif_max_int32 (loc5,((EIF_INTEGER_32) 0L));
	F25_391(RTCW(Result), ti4_1);
	RTHOOK(33);
	F25_394(RTCW(Result), (EIF_BOOLEAN) 1);
	RTHOOK(34);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit802 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
