
#ifndef _C17_ev825_
#define _C17_ev825_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1544_14987(EIF_REFERENCE);
extern void EIF_Minit825(void);
extern EIF_REFERENCE F215_2922(EIF_REFERENCE);
extern char *(*R12053[])();

#ifdef __cplusplus
}
#endif

#endif
