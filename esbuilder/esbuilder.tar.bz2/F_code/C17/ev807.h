
#ifndef _C17_ev807_
#define _C17_ev807_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1526_14900(EIF_REFERENCE);
extern void EIF_Minit807(void);
extern EIF_REFERENCE F159_2233(EIF_REFERENCE);
extern char *(*R11977[])();

#ifdef __cplusplus
}
#endif

#endif
