
#ifndef _C17_ev829_
#define _C17_ev829_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1548_15013(EIF_REFERENCE);
extern void EIF_Minit829(void);
extern EIF_REFERENCE F223_4029(EIF_REFERENCE);
extern char *(*R12077[])();

#ifdef __cplusplus
}
#endif

#endif
