/*
 * Code for class EV_GAUGE_ACTION_SEQUENCES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev807.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GAUGE_ACTION_SEQUENCES}.change_actions */
EIF_REFERENCE F1526_14900 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("change_actions", 1525, Current, 0, 0, 21106);
	RTGC;
	RTHOOK(1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11977[Dtype(Current)-1624])(Current);
	Result = F159_2233(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit807 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
