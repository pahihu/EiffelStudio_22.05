/*
 * Code for class GB_RADIO_GROUP_LINK
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gb846.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GB_RADIO_GROUP_LINK}.make_with_components */
void F1565_15122 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("make_with_components", 1564, Current, 0, 1, 21316);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	F1345_12285(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {GB_RADIO_GROUP_LINK}.set_object */
void F1565_15125 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("set_object", 1564, Current, 0, 1, 21319);
	RTGC;
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) arg1;
	RTHOOK(2);
	F1565_15127(Current);
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {GB_RADIO_GROUP_LINK}.set_gb_ev_container */
void F1565_15126 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	
	
	RTEAA("set_gb_ev_container", 1564, Current, 0, 1, 21320);
	RTHOOK(1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) arg1;
	RTHOOK(3);
	RTEE;
}

/* {GB_RADIO_GROUP_LINK}.update_displayed_text */
void F1565_15127 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEAA("update_displayed_text", 1564, Current, 0, 0, 21321);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_5_);
	tb1 = F834_9290(RTCW(tr1));
	if (tb1) {
		RTHOOK(2);
		tr1 = RTMS_EX_H("unnamed ",8,1609669664);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr2 = F2516_31194(RTCW(tr2));
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11599[Dtype(tr1)-1503])(tr1, tr2);
		F1369_12572(Current, tr1);
	} else {
		RTHOOK(3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_5_);
		F1369_12572(Current, tr1);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
}

void EIF_Minit846 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
