/*
 * Code for class EV_TOOL_BAR_BUTTON
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev849.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TOOL_BAR_BUTTON}.parent */
EIF_REFERENCE F1568_15135 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("parent", 1567, Current, 0, 0, 21325);
	RTGC;
	RTHOOK(1);
	Result = F1566_15132(Current);
	RTHOOK(2);
	RTLE;
	RTEE;
	return RTRV(eif_new_type(1606, 0x00), Result);
}

/* {EV_TOOL_BAR_BUTTON}.implementation */
EIF_REFERENCE F1568_15143 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {EV_TOOL_BAR_BUTTON}.create_implementation */
void F1568_15144 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1567, Current, 0, 0, 21334);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1909, 0x00).id, 1909, _OBJSIZ_29_14_8_2_0_2_0_0_);
	F1910_20851(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

void EIF_Minit849 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
