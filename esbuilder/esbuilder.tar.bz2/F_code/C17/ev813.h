
#ifndef _C17_ev813_
#define _C17_ev813_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1532_14923(EIF_REFERENCE);
extern void F1532_14926(EIF_REFERENCE, EIF_REFERENCE);
extern void F1532_14927(EIF_REFERENCE, EIF_REFERENCE);
extern void F1532_14928(EIF_REFERENCE);
extern void EIF_Minit813(void);
extern EIF_REFERENCE F1500_14212(EIF_REFERENCE);
extern void F1765_18521(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R14867[])();
extern long O14897[];

#ifdef __cplusplus
}
#endif

#endif
