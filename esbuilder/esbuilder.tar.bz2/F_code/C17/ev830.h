
#ifndef _C17_ev830_
#define _C17_ev830_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1549_15014(EIF_REFERENCE);
extern EIF_BOOLEAN F1549_15015(EIF_REFERENCE);
extern void F1549_15016(EIF_REFERENCE);
extern void EIF_Minit830(void);
extern void F1735_18152(EIF_REFERENCE);
extern long O10182[];
extern long O14600[];
extern long O14599[];

#ifdef __cplusplus
}
#endif

#endif
