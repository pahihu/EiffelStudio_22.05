
#ifndef _C17_ev822_
#define _C17_ev822_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1541_14979(EIF_REFERENCE);
extern void EIF_Minit822(void);
extern EIF_REFERENCE F194_2516(EIF_REFERENCE);
extern char *(*R12045[])();

#ifdef __cplusplus
}
#endif

#endif
