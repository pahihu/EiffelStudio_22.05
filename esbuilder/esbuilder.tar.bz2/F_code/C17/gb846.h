
#ifndef _C17_gb846_
#define _C17_gb846_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1565_15122(EIF_REFERENCE, EIF_REFERENCE);
extern void F1565_15125(EIF_REFERENCE, EIF_REFERENCE);
extern void F1565_15126(EIF_REFERENCE, EIF_REFERENCE);
extern void F1565_15127(EIF_REFERENCE);
extern void EIF_Minit846(void);
extern EIF_BOOLEAN F834_9290(EIF_REFERENCE);
extern EIF_REFERENCE F2516_31194(EIF_REFERENCE);
extern void F1345_12285(EIF_REFERENCE);
extern void F1369_12572(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R11599[])();

#ifdef __cplusplus
}
#endif

#endif
