/*
 * Code for class EV_LIST_ITEM_LIST_ACTION_SEQUENCES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev825.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_LIST_ITEM_LIST_ACTION_SEQUENCES}.select_actions */
EIF_REFERENCE F1544_14987 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("select_actions", 1543, Current, 0, 0, 21184);
	RTGC;
	RTHOOK(1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R12053[Dtype(Current)-1613])(Current);
	Result = F215_2922(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit825 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
