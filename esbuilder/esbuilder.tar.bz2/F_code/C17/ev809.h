
#ifndef _C17_ev809_
#define _C17_ev809_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1528_14906(EIF_REFERENCE);
extern EIF_REFERENCE F1528_14907(EIF_REFERENCE);
extern EIF_REFERENCE F1528_14908(EIF_REFERENCE);
extern void EIF_Minit809(void);
extern EIF_REFERENCE F162_2253(EIF_REFERENCE);
extern EIF_REFERENCE F162_2251(EIF_REFERENCE);
extern EIF_REFERENCE F162_2255(EIF_REFERENCE);
extern long O10182[];

#ifdef __cplusplus
}
#endif

#endif
