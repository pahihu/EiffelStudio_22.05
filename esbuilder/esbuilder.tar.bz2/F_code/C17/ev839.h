
#ifndef _C17_ev839_
#define _C17_ev839_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1558_15073(EIF_REFERENCE);
extern void EIF_Minit839(void);
extern char *(*R16094[])();
extern long O10182[];

#ifdef __cplusplus
}
#endif

#endif
