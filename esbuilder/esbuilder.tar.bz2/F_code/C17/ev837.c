/*
 * Code for class EV_PICK_AND_DROPABLE_ACTION_SEQUENCES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev837.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PICK_AND_DROPABLE_ACTION_SEQUENCES}.drop_actions */
EIF_REFERENCE F1556_15043 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("drop_actions", 1555, Current, 0, 0, 21234);
	RTGC;
	RTHOOK(1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R12097[Dtype(Current)-1558])(Current);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4100[Dtype(RTCW(tr1))-1786])(tr1);
	RTHOOK(2);
	tb1 = F827_9290(RTCW(Result));
	if (tb1) {
		RTHOOK(3);
		F1221_11202(Current, Result);
	}
	RTHOOK(5);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit837 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
