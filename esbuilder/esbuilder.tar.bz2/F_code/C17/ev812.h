
#ifndef _C17_ev812_
#define _C17_ev812_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1531_14918(EIF_REFERENCE);
extern EIF_REFERENCE F1531_14919(EIF_REFERENCE);
extern void EIF_Minit812(void);
extern EIF_REFERENCE F166_2284(EIF_REFERENCE);
extern EIF_REFERENCE F166_2282(EIF_REFERENCE);
extern char *(*R11995[])();

#ifdef __cplusplus
}
#endif

#endif
