/*
 * Code for class EV_FILE_DIALOG
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev817.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_FILE_DIALOG}.file_name */
EIF_REFERENCE F1536_14946 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("file_name", 1535, Current, 0, 0, 21148);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = F1386_12871(RTCV(F1536_14947(Current)));
	F1508_14453(RTCW(Result), tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_FILE_DIALOG}.full_file_path */
EIF_REFERENCE F1536_14947 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("full_file_path", 1535, Current, 0, 0, 21149);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1770_18568(RTCW(tr1));
	RTHOOK(4);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_FILE_DIALOG}.filters */
EIF_REFERENCE F1536_14949 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("filters", 1535, Current, 0, 0, 21151);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_7_);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_FILE_DIALOG}.file_title */
EIF_REFERENCE F1536_14952 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTEAA("file_title", 1535, Current, 1, 0, 21154);
	RTGC;
	RTHOOK(1);
	tr1 = F1386_12848(RTCV(F1536_14947(Current)));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTHOOK(2);
		Result = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
		tr1 = F1386_12871(loc1);
		F1508_14453(RTCW(Result), tr1);
	} else {
		RTHOOK(3);
		Result = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1500_14155(RTCW(Result));
		RTHOOK(4);
		RTLE;
		RTEE;
		return (EIF_REFERENCE) Result;
	}
	RTHOOK(6);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_FILE_DIALOG}.file_path */
EIF_REFERENCE F1536_14953 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("file_path", 1535, Current, 0, 0, 21155);
	RTGC;
	RTHOOK(1);
	Result = RTLNS(eif_new_type(1509, 0x00).id, 1509, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = F1386_12847(RTCV(F1536_14947(Current)));
	tr1 = F1386_12871(RTCW(tr1));
	F1508_14453(RTCW(Result), tr1);
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit817 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
