
#ifndef _C17_ev801_
#define _C17_ev801_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1520_14791(EIF_REFERENCE);
extern EIF_REFERENCE F1520_14792(EIF_REFERENCE);
extern void F1520_14793(EIF_REFERENCE);
extern void EIF_Minit801(void);
extern EIF_REFERENCE F1756_18452(EIF_REFERENCE);
extern void F1755_18398(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
