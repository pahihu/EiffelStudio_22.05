/*
 * Code for class EV_BUTTON_ACTION_SEQUENCES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev835.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_BUTTON_ACTION_SEQUENCES}.select_actions */
EIF_REFERENCE F1554_15034 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("select_actions", 1553, Current, 0, 0, 21227);
	RTGC;
	RTHOOK(1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R12091[Dtype(Current)-1619])(Current);
	Result = F228_4047(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit835 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
