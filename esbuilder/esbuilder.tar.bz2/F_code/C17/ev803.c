/*
 * Code for class EV_GRID_CHECKABLE_LABEL_ITEM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev803.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GRID_CHECKABLE_LABEL_ITEM}.initialize */
void F1522_14842 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,tr5);
	RTLIU(6);
	
	RTEAA("initialize", 1521, Current, 0, 0, 21047);
	RTGC;
	RTHOOK(1);
	F1521_14795(Current);
	RTHOOK(2);
	tr1 = F1518_14747(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1493,0xFFF9,8,1419,1425,1425,1425,1449,1449,1449,1425,1425,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A803_163_2_3_4_5_6_7_8_9, (EIF_POINTER) _A803_163_2_3_4_5_6_7_8_9, (EIF_POINTER)(F1522_14863),tr2, 1, 8);
	}
	F1169_10217(RTCW(tr1), tr5);
	RTHOOK(3);
	tr1 = F1518_14752(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1493,0xFFF9,1,1419,2025,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A803_164_2, (EIF_POINTER) _A803_164_2, (EIF_POINTER)(F1522_14864),tr2, 1, 1);
	}
	F1169_10217(RTCW(tr1), tr5);
	RTHOOK(4);
	tr1 = F1518_14754(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1493,0xFFF9,1,1419,2025,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A803_165_2, (EIF_POINTER) _A803_165_2, (EIF_POINTER)(F1522_14865),tr2, 1, 1);
	}
	F1169_10217(RTCW(tr1), tr5);
	RTHOOK(5);
	tr1 = F1518_14756(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1419,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1493,0xFFF9,0,1419,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A803_156, (EIF_POINTER) _A803_156, (EIF_POINTER)(F1522_14856),tr2, 1, 0);
	}
	F1169_10217(RTCW(tr1), tr3);
	RTHOOK(6);
	F1519_14779(Current, (EIF_BOOLEAN) 1);
	RTHOOK(7);
	RTLE;
	RTEE;
}

/* {EV_GRID_CHECKABLE_LABEL_ITEM}.is_checked */
EIF_BOOLEAN F1522_14843 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("is_checked", 1521, Current, 0, 0, 21048);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_22_4_);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_CHECKABLE_LABEL_ITEM}.toggle_is_checked */
void F1522_14848 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("toggle_is_checked", 1521, Current, 0, 0, 21053);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1758_18481(RTCW(tr1));
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_GRID_CHECKABLE_LABEL_ITEM}.set_is_checked */
void F1522_14849 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("set_is_checked", 1521, Current, 0, 1, 21054);
	RTGC;
	RTHOOK(1);
	if ((EIF_BOOLEAN)(F1522_14843(Current) != arg1)) {
		RTHOOK(2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F1758_18480(RTCW(tr1), arg1);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_GRID_CHECKABLE_LABEL_ITEM}.is_sensitive */
EIF_BOOLEAN F1522_14851 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("is_sensitive", 1521, Current, 0, 0, 21056);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_22_3_);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_CHECKABLE_LABEL_ITEM}.set_font */
void F1522_14852 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEAA("set_font", 1521, Current, 0, 1, 21057);
	RTGC;
	RTHOOK(1);
	F1521_14798(Current, arg1);
	RTHOOK(2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1758_18477(RTCW(tr1));
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_GRID_CHECKABLE_LABEL_ITEM}.disable_key_processing */
void F1522_14856 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
	
	RTEAA("disable_key_processing", 1521, Current, 0, 0, 21061);
	RTHOOK(1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_7_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTHOOK(2);
	RTEE;
}

/* {EV_GRID_CHECKABLE_LABEL_ITEM}.deactivate */
void F1522_14858 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEAA("deactivate", 1521, Current, 0, 0, 21063);
	RTGC;
	RTHOOK(1);
	F1522_14856(Current);
	RTHOOK(2);
	F1519_14781(Current);
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_GRID_CHECKABLE_LABEL_ITEM}.checked_changed_actions */
EIF_REFERENCE F1522_14859 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTEAA("checked_changed_actions", 1521, Current, 0, 0, 21064);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_21_);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_CHECKABLE_LABEL_ITEM}.implementation */
EIF_REFERENCE F1522_14861 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


/* {EV_GRID_CHECKABLE_LABEL_ITEM}.create_implementation */
void F1522_14862 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("create_implementation", 1521, Current, 0, 0, 21067);
	RTGC;
	RTHOOK(1);
	tr1 = RTLNS(eif_new_type(1757, 0x00).id, 1757, _OBJSIZ_22_6_0_4_0_0_0_0_);
	F1758_18471(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTHOOK(2);
	RTLE;
	RTEE;
}

/* {EV_GRID_CHECKABLE_LABEL_ITEM}.checkbox_handled */
void F1522_14863 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("checkbox_handled", 1521, Current, 3, 8, 21068);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg3 == ((EIF_INTEGER_32) 1L))) {
		tb1 = F1522_14851(Current);
	}
	if (tb1) {
		RTHOOK(2);
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_4_) >= ((EIF_INTEGER_32) 0L))) {
			RTHOOK(3);
			loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_4_);
		} else {
			RTHOOK(4);
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		}
		RTHOOK(5);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_7_0_)) {
			RTHOOK(6);
			tb1 = '\0';
			tb2 = '\0';
			tb3 = '\0';
			if ((EIF_BOOLEAN) (arg1 >= loc1)) {
				tb3 = (EIF_BOOLEAN) (arg1 <= (EIF_INTEGER_32) (F1519_14767(Current) - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_0_)));
			}
			if (tb3) {
				tb2 = (EIF_BOOLEAN) (arg2 >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_1_));
			}
			if (tb2) {
				tb1 = (EIF_BOOLEAN) (arg2 <= (EIF_INTEGER_32) (F1519_14768(Current) - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_2_)));
			}
			if (tb1) {
				RTHOOK(7);
				F1522_14848(Current);
			}
		} else {
			RTHOOK(8);
			ti4_1 = F1519_14767(Current);
			ti4_2 = F1519_14768(Current);
			loc2 = F1522_14869(Current, ti4_1, ti4_2);
			RTHOOK(9);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				RTHOOK(10);
				(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(loc3+ _PTROFF_4_2_0_3_0_0_))(
					*(EIF_POINTER *)(loc3+ _PTROFF_4_2_0_3_0_1_),
					*(EIF_REFERENCE *)(loc3 + _REFACS_1_), Current, loc2);
			}
			RTHOOK(11);
			tb1 = '\0';
			tb2 = '\0';
			tb3 = '\0';
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_0_1_0_2_);
			if ((EIF_BOOLEAN) (arg1 >= ti4_1)) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_0_1_0_2_);
				tb3 = (EIF_BOOLEAN) (arg1 <= (EIF_INTEGER_32) (ti4_1 + F1522_14867(Current)));
			}
			if (tb3) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_0_1_0_3_);
				tb2 = (EIF_BOOLEAN) (arg2 >= ti4_1);
			}
			if (tb2) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_0_1_0_3_);
				tb1 = (EIF_BOOLEAN) (arg2 <= (EIF_INTEGER_32) (ti4_1 + F1522_14867(Current)));
			}
			if (tb1) {
				RTHOOK(12);
				F1522_14848(Current);
			}
		}
	}
	RTHOOK(13);
	RTLE;
	RTEE;
}

/* {EV_GRID_CHECKABLE_LABEL_ITEM}.on_key_pressed */
void F1522_14864 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("on_key_pressed", 1521, Current, 1, 1, 21069);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_7_2_)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
		tb1 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 41L));
	}
	if (tb1) {
		RTHOOK(2);
		tb1 = '\0';
		tr1 = F1519_14761(Current);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			tb2 = F1594_15726(loc1);
			tb1 = tb2;
		}
		if (tb1) {
			RTHOOK(3);
			tr1 = RTLNS(eif_new_type(2025, 0x00).id, 2025, _OBJSIZ_0_0_0_1_0_0_0_0_);
			F2026_22953(RTCW(tr1), ((EIF_INTEGER_32) 43L));
			F1594_15764(loc1, tr1);
		}
	}
	RTHOOK(4);
	RTLE;
	RTEE;
}

/* {EV_GRID_CHECKABLE_LABEL_ITEM}.on_key_released */
void F1522_14865 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTEAA("on_key_released", 1521, Current, 0, 1, 21070);
	RTGC;
	RTHOOK(1);
	tb1 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_7_2_)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
		tb1 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 39L));
	}
	if (tb1) {
		RTHOOK(2);
		F1522_14848(Current);
	}
	RTHOOK(3);
	RTLE;
	RTEE;
}

/* {EV_GRID_CHECKABLE_LABEL_ITEM}.check_figure_size */
EIF_INTEGER_32 F1522_14867 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEAA("check_figure_size", 1521, Current, 0, 0, 21072);
	RTGC;
	RTHOOK(1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_22_6_0_3_);
	RTHOOK(2);
	RTLE;
	RTEE;
	return Result;
}

/* {EV_GRID_CHECKABLE_LABEL_ITEM}.computed_initial_grid_label_item_layout */
EIF_REFERENCE F1522_14869 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTEAA("computed_initial_grid_label_item_layout", 1521, Current, 3, 2, 21074);
	RTGC;
	RTHOOK(1);
	Result = F1521_14840(Current, arg1, arg2);
	RTHOOK(2);
	loc2 = F1522_14867(Current);
	RTHOOK(3);
	ti4_1 = F1521_14815(Current);
	F25_392(RTCW(Result), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
	RTHOOK(4);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_0_1_0_5_);
	ti4_2 = F1521_14821(Current);
	F25_393(RTCW(Result), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + (EIF_INTEGER_32) (ti4_2 / ((EIF_INTEGER_32) 2L))) - (EIF_INTEGER_32) (loc2 / ((EIF_INTEGER_32) 2L))));
	RTHOOK(5);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_0_1_0_2_);
	F25_387(RTCW(Result), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + loc2) + *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_3_)));
	RTHOOK(6);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTHOOK(7);
		loc1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_0_1_0_0_);
		ti4_1 = F1362_12530(loc3);
		ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_3_);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + ti4_1) + ti4_2);
	} else {
		RTHOOK(8);
		loc1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_0_1_0_0_);
	}
	RTHOOK(9);
	if (F1521_14827(Current)) {
		RTHOOK(10);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_0_1_0_4_);
		ti4_1 = eif_max_int32 (ti4_1,loc1);
		F25_389(RTCW(Result), ti4_1);
	} else {
		RTHOOK(11);
		if (F1521_14825(Current)) {
			RTHOOK(12);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_0_1_0_4_);
			F25_389(RTCW(Result), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + loc2) + *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_3_)));
		} else {
			RTHOOK(13);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_0_1_0_4_);
			ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_3_);
			ti4_1 = eif_max_int32 ((EIF_INTEGER_32) (ti4_1 + (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 + ti4_2) / ((EIF_INTEGER_32) 2L))),loc1);
			F25_389(RTCW(Result), ti4_1);
		}
	}
	RTHOOK(14);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_0_1_0_6_);
	ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_4_0_3_);
	ti4_1 = eif_max_int32 ((EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - loc2) - ti4_2),((EIF_INTEGER_32) 0L));
	F25_391(RTCW(Result), ti4_1);
	RTHOOK(15);
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit803 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
