
#ifndef _C17_ev821_
#define _C17_ev821_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1540_14977(EIF_REFERENCE);
extern void EIF_Minit821(void);
extern EIF_REFERENCE F1859_20305(EIF_REFERENCE);
extern char *(*R12043[])();

#ifdef __cplusplus
}
#endif

#endif
