
#ifndef _C17_ev828_
#define _C17_ev828_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1547_14997(EIF_REFERENCE);
extern void F1547_15000(EIF_REFERENCE);
extern void F1547_15001(EIF_REFERENCE);
extern void F1547_15002(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit828(void);
extern void F1721_17882(EIF_REFERENCE);
extern void F1721_17886(EIF_REFERENCE, EIF_REFERENCE);
extern void F1721_17884(EIF_REFERENCE);
extern long O10182[];
extern long O14373[];

#ifdef __cplusplus
}
#endif

#endif
