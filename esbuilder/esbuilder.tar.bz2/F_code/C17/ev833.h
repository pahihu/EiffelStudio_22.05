
#ifndef _C17_ev833_
#define _C17_ev833_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1552_15024(EIF_REFERENCE);
extern EIF_REFERENCE F1552_15025(EIF_REFERENCE);
extern void F1552_15026(EIF_REFERENCE);
extern void F1552_15027(EIF_REFERENCE);
extern void EIF_Minit833(void);
extern EIF_REFERENCE F1727_17986(EIF_REFERENCE);
extern void F1727_17976(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
