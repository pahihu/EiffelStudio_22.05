/*
 * Code for class EV_GTK_EVENT_STRINGS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev28.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GTK_EVENT_STRINGS}.set_focus_event_name */

EIF_REFERENCE F28_746 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (746,RTMS_EX_H("set-focus",9,577130099));
}

/* {EV_GTK_EVENT_STRINGS}.configure_event_name */

EIF_REFERENCE F28_747 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (747,RTMS_EX_H("configure-event",15,1205453684));
}

/* {EV_GTK_EVENT_STRINGS}.map_event_name */

EIF_REFERENCE F28_750 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (750,RTMS_EX_H("map-event",9,474090100));
}

/* {EV_GTK_EVENT_STRINGS}.unmap_event_name */

EIF_REFERENCE F28_751 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (751,RTMS_EX_H("unmap-event",11,77806708));
}

/* {EV_GTK_EVENT_STRINGS}.hide_signal_name */

EIF_REFERENCE F28_752 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (752,RTMS_EX_H("hide",4,1751737445));
}

/* {EV_GTK_EVENT_STRINGS}.size_allocate_event_name */

EIF_REFERENCE F28_756 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (756,RTMS_EX_H("size-allocate",13,769151077));
}

/* {EV_GTK_EVENT_STRINGS}.clicked_event_name */

EIF_REFERENCE F28_759 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (759,RTMS_EX_H("clicked",7,169941860));
}

/* {EV_GTK_EVENT_STRINGS}.draw_event_name */

EIF_REFERENCE F28_761 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (761,RTMS_EX_H("draw",4,1685217655));
}

/* {EV_GTK_EVENT_STRINGS}.commit_event_name */

EIF_REFERENCE F28_762 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (762,RTMS_EX_H("commit",6,2031381364));
}

/* {EV_GTK_EVENT_STRINGS}.changed_event_name */

EIF_REFERENCE F28_763 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (763,RTMS_EX_H("changed",7,346303332));
}

/* {EV_GTK_EVENT_STRINGS}.response_event_name */

EIF_REFERENCE F28_767 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (767,RTMS_EX_H("response",8,1418183525));
}

/* {EV_GTK_EVENT_STRINGS}.scroll_event_name */

EIF_REFERENCE F28_773 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (773,RTMS_EX_H("scroll-event",12,2102824820));
}

/* {EV_GTK_EVENT_STRINGS}.commit_event_string */
static EIF_REFERENCE F28_792_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (792);
#define Result RTOSR(792)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(910, 0x00).id, 910, _OBJSIZ_0_1_0_1_0_1_0_0_);
	tr2 = RTOSCF(762,F28_762, (Current));
	F911_6705(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (792);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F28_792 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(792,F28_792_body,(Current));
}

void EIF_Minit28 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
