
#ifndef _C1_fi43_
#define _C1_fi43_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F43_1032(EIF_REFERENCE, EIF_REFERENCE);
extern void F43_1037(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit43(void);
extern void F914_6738(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F932_7674(EIF_REFERENCE);
extern void F914_6743(EIF_REFERENCE);
extern EIF_BOOLEAN F914_6763(EIF_REFERENCE);
extern void F914_6740(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
