
#ifndef _C1_gt16_
#define _C1_gt16_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F16_417(EIF_REFERENCE);
extern EIF_BOOLEAN F16_418(EIF_REFERENCE, EIF_POINTER, EIF_POINTER, EIF_INTEGER_32, EIF_POINTER*);
extern void EIF_Minit16(void);

#ifdef __cplusplus
}
#endif

#endif
