
#ifndef _C1_gt29_
#define _C1_gt29_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_8 F29_793(EIF_REFERENCE);
extern EIF_NATURAL_8 F29_794(EIF_REFERENCE);
extern void EIF_Minit29(void);

#ifdef __cplusplus
}
#endif

#endif
