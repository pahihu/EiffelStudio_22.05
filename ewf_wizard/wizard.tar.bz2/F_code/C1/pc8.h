
#ifndef _C1_pc8_
#define _C1_pc8_

#ifdef __cplusplus
extern "C" {
#endif

extern void F8_104(EIF_REFERENCE);
extern void F8_105(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F8_107(EIF_REFERENCE, EIF_INTEGER_32);
extern void F8_108(EIF_REFERENCE, EIF_REFERENCE);
extern void F8_109(EIF_REFERENCE, EIF_INTEGER_32);
extern void F8_110(EIF_REFERENCE, EIF_REFERENCE);
extern void F8_111(EIF_REFERENCE, EIF_REFERENCE);
extern void F8_112(EIF_REFERENCE);
extern void EIF_Minit8(void);
extern EIF_INTEGER_32 F1054_9369(EIF_REFERENCE, EIF_INTEGER_32);
extern void F841_6405(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
