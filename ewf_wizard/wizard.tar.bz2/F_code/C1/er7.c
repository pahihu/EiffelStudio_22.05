/*
 * Code for class ERROR_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "er7.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ERROR_CONSTANTS}.err_msg_0 */

EIF_REFERENCE F7_66 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (66,RTMS_EX_H("compilation successfully",24,297046137));
}

/* {ERROR_CONSTANTS}.err_msg_1 */

EIF_REFERENCE F7_67 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (67,RTMS_EX_H("\\ at end of pattern",19,1082148462));
}

/* {ERROR_CONSTANTS}.err_msg_2 */

EIF_REFERENCE F7_68 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (68,RTMS_EX_H("\\c at end of pattern",20,586514030));
}

/* {ERROR_CONSTANTS}.err_msg_3 */

EIF_REFERENCE F7_69 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (69,RTMS_EX_H("unrecognized character follows \\",32,1794949212));
}

/* {ERROR_CONSTANTS}.err_msg_4 */

EIF_REFERENCE F7_70 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (70,RTMS_EX_H("numbers out of order in {} quantifier",37,1764177010));
}

/* {ERROR_CONSTANTS}.err_msg_5 */

EIF_REFERENCE F7_71 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (71,RTMS_EX_H("number too big in {} quantifier",31,236715890));
}

/* {ERROR_CONSTANTS}.err_msg_6 */

EIF_REFERENCE F7_72 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (72,RTMS_EX_H("missing terminating ] for character class",41,461852531));
}

/* {ERROR_CONSTANTS}.err_msg_7 */

EIF_REFERENCE F7_73 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (73,RTMS_EX_H("invalid escape sequence in character class",42,267449459));
}

/* {ERROR_CONSTANTS}.err_msg_8 */

EIF_REFERENCE F7_74 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (74,RTMS_EX_H("range out of order in character class",37,652901747));
}

/* {ERROR_CONSTANTS}.err_msg_9 */

EIF_REFERENCE F7_75 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (75,RTMS_EX_H("nothing to repeat",17,825052276));
}

/* {ERROR_CONSTANTS}.err_msg_11 */

EIF_REFERENCE F7_77 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (77,RTMS_EX_H("internal error: unexpected repeat",33,1855335540));
}

/* {ERROR_CONSTANTS}.err_msg_12 */

EIF_REFERENCE F7_78 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (78,RTMS_EX_H("unrecognized character after (\?",31,636561471));
}

/* {ERROR_CONSTANTS}.err_msg_13 */

EIF_REFERENCE F7_79 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (79,RTMS_EX_H("too many capturing parenthesized sub-patterns",45,1757158771));
}

/* {ERROR_CONSTANTS}.err_msg_14 */

EIF_REFERENCE F7_80 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (80,RTMS_EX_H("missing )",9,1989432361));
}

/* {ERROR_CONSTANTS}.err_msg_15 */

EIF_REFERENCE F7_81 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (81,RTMS_EX_H("back reference to non-existent subpattern",41,1930188142));
}

/* {ERROR_CONSTANTS}.err_msg_18 */

EIF_REFERENCE F7_84 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (84,RTMS_EX_H("missing ) after comment",23,1848893300));
}

/* {ERROR_CONSTANTS}.err_msg_22 */

EIF_REFERENCE F7_88 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (88,RTMS_EX_H("unmatched parentheses",21,366512243));
}

/* {ERROR_CONSTANTS}.err_msg_24 */

EIF_REFERENCE F7_90 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (90,RTMS_EX_H("unrecognized character after (\?<",32,1898751036));
}

/* {ERROR_CONSTANTS}.err_msg_25 */

EIF_REFERENCE F7_91 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (91,RTMS_EX_H("lookbehind assertion is not fixed length",40,831850344));
}

/* {ERROR_CONSTANTS}.err_msg_26 */

EIF_REFERENCE F7_92 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (92,RTMS_EX_H("malformed number after (\?(",26,217491240));
}

/* {ERROR_CONSTANTS}.err_msg_27 */

EIF_REFERENCE F7_93 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (93,RTMS_EX_H("conditional group contains more than two branches",49,572996467));
}

/* {ERROR_CONSTANTS}.err_msg_28 */

EIF_REFERENCE F7_94 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (94,RTMS_EX_H("assertion expected after (\?(",28,1018686248));
}

/* {ERROR_CONSTANTS}.err_msg_30 */

EIF_REFERENCE F7_96 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (96,RTMS_EX_H("unknown POSIX class name",24,1984937317));
}

/* {ERROR_CONSTANTS}.err_msg_31 */

EIF_REFERENCE F7_97 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (97,RTMS_EX_H("POSIX collating elements are not supported",42,1477603940));
}

/* {ERROR_CONSTANTS}.err_msg_35 */

EIF_REFERENCE F7_101 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (101,RTMS_EX_H("invalid condition (\?(0)",23,1170936617));
}

/* {ERROR_CONSTANTS}.err_msg_99 */

EIF_REFERENCE F7_103 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (103,RTMS_EX_H("no pattern compiled",19,1370646116));
}

void EIF_Minit7 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
