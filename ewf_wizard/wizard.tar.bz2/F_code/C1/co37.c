/*
 * Code for class CODE_PAGE_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co37.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CODE_PAGE_CONSTANTS}.utf7 */

EIF_REFERENCE F37_944 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (944,RTMS_EX_H("UTF-7",5,1414538039));
}

/* {CODE_PAGE_CONSTANTS}.utf8 */

EIF_REFERENCE F37_945 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (945,RTMS_EX_H("UTF-8",5,1414538040));
}

/* {CODE_PAGE_CONSTANTS}.utf16 */

EIF_REFERENCE F37_946 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (946,RTMS_EX_H("UTF-16",6,1345128758));
}

/* {CODE_PAGE_CONSTANTS}.utf32 */

EIF_REFERENCE F37_947 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (947,RTMS_EX_H("UTF-32",6,1345129266));
}

/* {CODE_PAGE_CONSTANTS}.utf16_le */

EIF_REFERENCE F37_948 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (948,RTMS_EX_H("UTF-16LE",8,312185413));
}

/* {CODE_PAGE_CONSTANTS}.utf32_le */

EIF_REFERENCE F37_949 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (949,RTMS_EX_H("UTF-32LE",8,345477701));
}

/* {CODE_PAGE_CONSTANTS}.utf16_be */

EIF_REFERENCE F37_950 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (950,RTMS_EX_H("UTF-16BE",8,312182853));
}

/* {CODE_PAGE_CONSTANTS}.utf32_be */

EIF_REFERENCE F37_951 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (951,RTMS_EX_H("UTF-32BE",8,345475141));
}

void EIF_Minit37 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
