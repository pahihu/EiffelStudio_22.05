
#ifndef _C1_gd17_
#define _C1_gd17_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F17_427(EIF_REFERENCE);
extern void EIF_Minit17(void);

#ifdef __cplusplus
}
#endif

#endif
