
#ifndef _C1_ca9_
#define _C1_ca9_

#ifdef __cplusplus
extern "C" {
#endif

extern void F9_114(EIF_REFERENCE);
extern void F9_115(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F9_116(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F9_118(EIF_REFERENCE, EIF_INTEGER_32);
extern void F9_119(EIF_REFERENCE);
extern void F9_120(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit9(void);
extern void F836_6405(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_CHARACTER_8 F1054_9365(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
