/*
 * Code for class GTK_ORIENTATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gt29.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F29_793
static EIF_NATURAL_8 inline_F29_793 (void)
{
	return GTK_ORIENTATION_HORIZONTAL
	;
}
#define INLINE_F29_793
#endif
#ifndef INLINE_F29_794
static EIF_NATURAL_8 inline_F29_794 (void)
{
	return GTK_ORIENTATION_VERTICAL
	;
}
#define INLINE_F29_794
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GTK_ORIENTATION}.gtk_orientation_horizontal */
EIF_NATURAL_8 F29_793 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	
	
	Result = inline_F29_793 ();
	return Result;
}

/* {GTK_ORIENTATION}.gtk_orientation_vertical */
EIF_NATURAL_8 F29_794 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	
	
	Result = inline_F29_794 ();
	return Result;
}

void EIF_Minit29 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
