
#ifndef _C11_ev513_
#define _C11_ev513_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1153_10565(EIF_REFERENCE);
extern void F1153_10566(EIF_REFERENCE);
extern EIF_REFERENCE F1153_10568(EIF_REFERENCE);
extern void F1153_10569(EIF_REFERENCE);
extern void EIF_Minit513(void);
extern void F1320_13089(EIF_REFERENCE);
extern void F1320_13085(EIF_REFERENCE);
extern void F1320_13088(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
