
#ifndef _C11_ev527_
#define _C11_ev527_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1167_10702(EIF_REFERENCE);
extern void F1167_10703(EIF_REFERENCE);
extern void EIF_Minit527(void);
extern void F1341_13516(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
