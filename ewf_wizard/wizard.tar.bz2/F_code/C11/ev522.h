
#ifndef _C11_ev522_
#define _C11_ev522_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1162_10678(EIF_REFERENCE);
extern void F1162_10679(EIF_REFERENCE);
extern void EIF_Minit522(void);
extern void F1331_13380(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
