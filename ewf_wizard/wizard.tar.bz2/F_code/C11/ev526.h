
#ifndef _C11_ev526_
#define _C11_ev526_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1166_10701(EIF_REFERENCE);
extern void EIF_Minit526(void);
extern EIF_REFERENCE F1163_10680(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
