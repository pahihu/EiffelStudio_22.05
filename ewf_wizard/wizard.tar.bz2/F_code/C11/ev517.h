
#ifndef _C11_ev517_
#define _C11_ev517_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1157_10619(EIF_REFERENCE);
extern EIF_REFERENCE F1157_10629(EIF_REFERENCE);
extern void F1157_10630(EIF_REFERENCE);
extern void EIF_Minit517(void);
extern void F1326_13261(EIF_REFERENCE);
extern void F1326_13225(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
