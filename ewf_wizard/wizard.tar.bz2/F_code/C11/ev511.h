
#ifndef _C11_ev511_
#define _C11_ev511_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1151_10538(EIF_REFERENCE);
extern void F1151_10539(EIF_REFERENCE);
extern void EIF_Minit511(void);
extern void F1364_13865(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
