/*
 * Code for class EV_WINDOW
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev500.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_WINDOW}.initialize */
void F1140_10392 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,tr5);
	RTLIU(6);
	
	RTGC;
	F1083_9575(Current);
	tr1 = *(EIF_REFERENCE *)(RTCV(F1140_10400(Current)) + _REFACS_3_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,966,0xFF01,1289,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	tr3 = *(EIF_REFERENCE *)(Current + O7891[dtype-1082]);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1094,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A645_263_2, (EIF_POINTER) _A645_263_2, (EIF_POINTER)(F1294_12633),tr2, 1, 1);
	}
	F672_5806(RTCW(tr1), tr5);
	tr1 = *(EIF_REFERENCE *)(RTCV(F1140_10400(Current)) + _REFACS_4_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,966,0xFF01,1289,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	tr3 = *(EIF_REFERENCE *)(Current + O7891[dtype-1082]);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1094,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A645_264_2, (EIF_POINTER) _A645_264_2, (EIF_POINTER)(F1294_12634),tr2, 1, 1);
	}
	F672_5806(RTCW(tr1), tr5);
	RTLE;
}

/* {EV_WINDOW}.title */
EIF_REFERENCE F1140_10397 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7891[Dtype(Current)-1082]);
	Result = F1294_12614(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_WINDOW}.accelerators */
EIF_REFERENCE F1140_10400 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7891[Dtype(Current)-1082]);
	Result = F1290_12543(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_WINDOW}.has */
EIF_BOOLEAN F1140_10401 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7891[Dtype(Current)-1082]);
	Result = F1290_12540(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {EV_WINDOW}.destroy */
void F1140_10404 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1083_9569(Current);
	tr1 = F1093_9769(RTCV(RTOSCF(3974,F242_3974, (Current))));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1099_9868(loc1, Current);
	}
	RTLE;
}

/* {EV_WINDOW}.disable_user_resize */
void F1140_10407 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7891[Dtype(Current)-1082]);
	F1294_12621(RTCW(tr1));
	RTLE;
}

/* {EV_WINDOW}.set_title */
void F1140_10413 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	loc1 = arg1;
	if ((EIF_TRUE)) {
		tr1 = *(EIF_REFERENCE *)(Current + O7891[dtype-1082]);
		F1294_12630(RTCW(tr1), loc1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + O7891[dtype-1082]);
		tr2 = RTLNS(eif_new_type(1050, 0x01).id, 1050, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1049_9127(RTCW(tr2), arg1);
		F1294_12630(RTCW(tr1), tr2);
	}
	RTLE;
}

/* {EV_WINDOW}.unlock_update */
void F1140_10418 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7891[Dtype(Current)-1082]);
	F1290_12557(RTCW(tr1));
	RTLE;
}

/* {EV_WINDOW}.show */
void F1140_10419 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1127_10204(Current);
	tr1 = F1093_9769(RTCV(RTOSCF(3974,F242_3974, (Current))));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1099_9867(loc1, Current);
	}
	RTLE;
}

/* {EV_WINDOW}.implementation */
EIF_REFERENCE F1140_10422 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O7891[Dtype(Current)-1082]);
}


/* {EV_WINDOW}.create_implementation */
void F1140_10426 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1293, 0x01).id, 1293, _OBJSIZ_59_21_10_11_0_4_0_0_);
	F1294_12610(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O7891[Dtype(Current)-1082]) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit500 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
