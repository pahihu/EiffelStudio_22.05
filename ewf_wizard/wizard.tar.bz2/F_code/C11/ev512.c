/*
 * Code for class EV_PIXMAP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev512.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PIXMAP}.make_with_size */
void F1152_10540 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1083_9566(Current);
	F1152_10554(Current, arg1, arg2);
	RTLE;
}

/* {EV_PIXMAP}.make_with_pixel_buffer */
void F1152_10542 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	F1083_9566(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1366_13918(RTCW(tr1), arg1);
	RTLE;
}

/* {EV_PIXMAP}.is_equal */
EIF_BOOLEAN F1152_10544 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		ti4_1 = F1104_9912(Current);
		ti4_2 = F1104_9913(RTCW(arg1));
		ti4_3 = F1104_9912(RTCW(arg1));
		ti4_4 = F1104_9913(Current);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN)((EIF_INTEGER_32) (ti4_1 * ti4_2) == (EIF_INTEGER_32) (ti4_3 * ti4_4));
	}
	RTLE;
	return Result;
}

/* {EV_PIXMAP}.set_size */
void F1152_10554 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1366_13929(RTCW(tr1), arg1, arg2);
	RTLE;
}

/* {EV_PIXMAP}.copy */
void F1152_10560 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_3_) == NULL)) {
		F1083_9566(Current);
	}
	tb1 = F1083_9570(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1366_13936(RTCW(tr1), arg1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
		ti4_1 = F1366_13923(RTCW(tr2));
		tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
		ti4_2 = F1366_13924(RTCW(tr2));
		F1366_13929(RTCW(tr1), ti4_1, ti4_2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1366_13949(RTCW(tr1));
	}
	RTLE;
}

/* {EV_PIXMAP}.implementation */
EIF_REFERENCE F1152_10561 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {EV_PIXMAP}.create_implementation */
void F1152_10562 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1365, 0x01).id, 1365, _OBJSIZ_48_18_10_9_0_4_0_1_);
	F1366_13916(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit512 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
