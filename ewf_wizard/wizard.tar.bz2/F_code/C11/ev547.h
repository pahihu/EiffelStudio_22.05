
#ifndef _C11_ev547_
#define _C11_ev547_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1188_10857(EIF_REFERENCE, EIF_REFERENCE);
extern void F1188_10860(EIF_REFERENCE);
extern EIF_BOOLEAN F1188_10862(EIF_REFERENCE);
extern EIF_REFERENCE F1188_10863(EIF_REFERENCE);
extern void F1188_10872(EIF_REFERENCE, EIF_INTEGER_8, EIF_BOOLEAN);
extern EIF_BOOLEAN F1188_10873(EIF_REFERENCE, EIF_INTEGER_8);
extern EIF_BOOLEAN F1188_10876(EIF_REFERENCE);
extern void F1188_10877(EIF_REFERENCE, EIF_BOOLEAN);
extern void F1188_10878(EIF_REFERENCE, EIF_BOOLEAN);
extern void F1188_10879(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit547(void);
extern char *(*R8823[])();
extern long O8826[];
extern long O8827[];

#ifdef __cplusplus
}
#endif

#endif
