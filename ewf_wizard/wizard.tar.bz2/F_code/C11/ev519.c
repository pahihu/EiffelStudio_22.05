/*
 * Code for class EV_BUTTON
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev519.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_BUTTON}.make_with_text_and_action */
void F1159_10664 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	F1083_9566(Current);
	F1112_9960(Current, arg1);
	tr1 = F1075_9509(Current);
	F672_5806(RTCW(tr1), arg2);
	RTLE;
}

/* {EV_BUTTON}.default_identifier_name */
EIF_REFERENCE F1159_10665 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	tb1 = F491_5233(RTCV(F1112_9959(Current)));
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) F1096_9813(Current);
	} else {
		Result = F1051_9269(RTCV(F1112_9959(Current)));
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '.';
		F1051_9260(RTCW(Result), tw1);
	}
	RTLE;
	return Result;
}

/* {EV_BUTTON}.is_default_push_button */
EIF_BOOLEAN F1159_10666 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_46_11_);
	RTLE;
	return Result;
}

/* {EV_BUTTON}.enable_default_push_button */
void F1159_10667 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1328_13355(RTCW(tr1));
	RTLE;
}

/* {EV_BUTTON}.disable_default_push_button */
void F1159_10668 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1328_13356(RTCW(tr1));
	RTLE;
}

/* {EV_BUTTON}.implementation */
EIF_REFERENCE F1159_10670 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {EV_BUTTON}.create_implementation */
void F1159_10671 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1327, 0x01).id, 1327, _OBJSIZ_46_14_10_6_0_3_0_0_);
	F1328_13346(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit519 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
