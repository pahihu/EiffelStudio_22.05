
#ifndef _C11_ev506_
#define _C11_ev506_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1146_10472(EIF_REFERENCE, EIF_REFERENCE);
extern void F1146_10473(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1146_10474(EIF_REFERENCE);
extern void EIF_Minit506(void);

#ifdef __cplusplus
}
#endif

#endif
