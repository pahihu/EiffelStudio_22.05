
#ifndef _C11_gr503_
#define _C11_gr503_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1143_10450(EIF_REFERENCE);
extern void F1143_10451(EIF_REFERENCE);
extern void EIF_Minit503(void);
extern void F311_4891(EIF_REFERENCE);
extern void F311_4892(EIF_REFERENCE, EIF_REFERENCE);
extern void F1142_10435(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
