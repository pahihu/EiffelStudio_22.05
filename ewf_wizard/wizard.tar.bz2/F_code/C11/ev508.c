/*
 * Code for class EV_INFORMATION_DIALOG
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev508.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_INFORMATION_DIALOG}.initialize */
void F1148_10509 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	F1147_10478(Current);
	tr1 = F155_3450(Current);
	F1140_10413(Current, tr1);
	tr1 = RTOSCF(1006,F42_1006, (RTCV(RTOSCF(7618,F928_7618, (Current)))));
	F1147_10486(Current, tr1);
	tr1 = RTOSCF(1006,F42_1006, (RTCV(RTOSCF(7618,F928_7618, (Current)))));
	F1142_10447(Current, tr1);
	{
		static EIF_TYPE_INDEX typarr0[] = {834,0xFF01,1053,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 1L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F155_3438(Current);
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F835_6413)(tr2);
	F1147_10490(Current, tr1);
	tr1 = F155_3438(Current);
	tr1 = F1147_10493(Current, tr1);
	F1145_10460(Current, tr1);
	tr1 = F155_3438(Current);
	tr1 = F1147_10493(Current, tr1);
	F1145_10462(Current, tr1);
	RTLE;
}

void EIF_Minit508 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
