/*
 * Code for class GRAPHICAL_WIZARD_WINDOW
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gr503.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GRAPHICAL_WIZARD_WINDOW}.create_interface_objects */
void F1143_10450 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F311_4891(Current);
}

/* {GRAPHICAL_WIZARD_WINDOW}.initialize */
void F1143_10451 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1142_10435(Current);
	F311_4892(Current, Current);
	RTLE;
}

void EIF_Minit503 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
