#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O1690[1235];
void O1690_init () {
	O1690[0] = 0;
	O1690[1213] = 0;
	O1690[1214] =  + _REFACS_1_;
	O1690[1215] =  + _REFACS_5_;
	O1690[1216] = 0;
	O1690[1217] =  + _REFACS_3_;
	O1690[1230] = 0;
	O1690[1231] =  + _REFACS_1_;
	O1690[1232] =  + _REFACS_5_;
	O1690[1233] = 0;
	O1690[1234] =  + _REFACS_3_;
}

long O1694[1263];
void O1694_init () {
	O1694[0] = 0;
	O1694[1237] = 0;
	{long i; for (i = 1238; i < 1240; i++) O1694[i] =  + _REFACS_2_;}
	O1694[1240] = 0;
	{long i; for (i = 1241; i < 1245; i++) O1694[i] =  + _REFACS_4_;}
	{long i; for (i = 1245; i < 1251; i++) O1694[i] = 0;}
	O1694[1251] =  + _REFACS_1_;
	{long i; for (i = 1252; i < 1256; i++) O1694[i] = 0;}
	O1694[1256] =  + _REFACS_1_;
	{long i; for (i = 1257; i < 1263; i++) O1694[i] =  + _REFACS_2_;}
}

long O1696[1263];
void O1696_init () {
	O1696[0] =  + _REFACS_1_;
	O1696[1237] =  + _REFACS_1_;
	{long i; for (i = 1238; i < 1240; i++) O1696[i] =  + _REFACS_3_;}
	O1696[1240] =  + _REFACS_1_;
	{long i; for (i = 1241; i < 1245; i++) O1696[i] =  + _REFACS_5_;}
	{long i; for (i = 1245; i < 1251; i++) O1696[i] =  + _REFACS_1_;}
	O1696[1251] =  + _REFACS_2_;
	{long i; for (i = 1252; i < 1256; i++) O1696[i] =  + _REFACS_1_;}
	O1696[1256] =  + _REFACS_2_;
	{long i; for (i = 1257; i < 1263; i++) O1696[i] =  + _REFACS_3_;}
}

long O1698[1263];
void O1698_init () {
	O1698[0] =  + _REFACS_2_;
	O1698[1237] =  + _REFACS_2_;
	{long i; for (i = 1238; i < 1240; i++) O1698[i] =  + _REFACS_4_;}
	O1698[1240] =  + _REFACS_2_;
	{long i; for (i = 1241; i < 1245; i++) O1698[i] =  + _REFACS_6_;}
	{long i; for (i = 1245; i < 1251; i++) O1698[i] =  + _REFACS_2_;}
	O1698[1251] =  + _REFACS_3_;
	{long i; for (i = 1252; i < 1256; i++) O1698[i] =  + _REFACS_2_;}
	O1698[1256] =  + _REFACS_3_;
	{long i; for (i = 1257; i < 1263; i++) O1698[i] =  + _REFACS_4_;}
}

long O1773[1266];
void O1773_init () {
	O1773[0] = 0;
	{long i; for (i = 1127; i < 1129; i++) O1773[i] = 0;}
	{long i; for (i = 1165; i < 1170; i++) O1773[i] = 0;}
	O1773[1170] =  + _REFACS_1_;
	{long i; for (i = 1171; i < 1173; i++) O1773[i] = 0;}
	O1773[1173] =  + _REFACS_1_;
	O1773[1174] = 0;
	{long i; for (i = 1175; i < 1197; i++) O1773[i] =  + _REFACS_1_;}
	O1773[1197] = 0;
	O1773[1198] =  + _REFACS_1_;
	O1773[1199] =  + _REFACS_2_;
	O1773[1200] =  + _REFACS_4_;
	O1773[1201] =  + _REFACS_1_;
	O1773[1202] = 0;
	{long i; for (i = 1203; i < 1205; i++) O1773[i] =  + _REFACS_2_;}
	O1773[1205] =  + _REFACS_1_;
	O1773[1206] =  + _REFACS_2_;
	O1773[1207] =  + _REFACS_6_;
	O1773[1208] =  + _REFACS_1_;
	O1773[1209] =  + _REFACS_4_;
	{long i; for (i = 1210; i < 1215; i++) O1773[i] = 0;}
	O1773[1215] =  + _REFACS_1_;
	O1773[1216] =  + _REFACS_2_;
	O1773[1217] =  + _REFACS_4_;
	O1773[1218] =  + _REFACS_1_;
	O1773[1219] = 0;
	{long i; for (i = 1220; i < 1222; i++) O1773[i] =  + _REFACS_2_;}
	O1773[1222] =  + _REFACS_1_;
	O1773[1223] =  + _REFACS_2_;
	O1773[1224] =  + _REFACS_6_;
	O1773[1225] =  + _REFACS_1_;
	O1773[1226] =  + _REFACS_4_;
	{long i; for (i = 1227; i < 1231; i++) O1773[i] = 0;}
	{long i; for (i = 1253; i < 1257; i++) O1773[i] =  + _REFACS_5_;}
	O1773[1258] = 0;
	O1773[1260] = 0;
	O1773[1263] = 0;
	O1773[1265] = 0;
}

long O1774[1266];
void O1774_init () {
	O1774[0] =  + _REFACS_1_;
	{long i; for (i = 1127; i < 1129; i++) O1774[i] =  + _REFACS_1_;}
	{long i; for (i = 1165; i < 1170; i++) O1774[i] =  + _REFACS_1_;}
	O1774[1170] =  + _REFACS_2_;
	{long i; for (i = 1171; i < 1173; i++) O1774[i] =  + _REFACS_1_;}
	O1774[1173] =  + _REFACS_2_;
	O1774[1174] =  + _REFACS_1_;
	{long i; for (i = 1175; i < 1197; i++) O1774[i] =  + _REFACS_2_;}
	O1774[1197] =  + _REFACS_1_;
	O1774[1198] =  + _REFACS_2_;
	O1774[1199] =  + _REFACS_3_;
	O1774[1200] =  + _REFACS_5_;
	O1774[1201] =  + _REFACS_2_;
	O1774[1202] =  + _REFACS_1_;
	{long i; for (i = 1203; i < 1205; i++) O1774[i] =  + _REFACS_3_;}
	O1774[1205] =  + _REFACS_2_;
	O1774[1206] =  + _REFACS_3_;
	O1774[1207] =  + _REFACS_7_;
	O1774[1208] =  + _REFACS_2_;
	O1774[1209] =  + _REFACS_5_;
	{long i; for (i = 1210; i < 1215; i++) O1774[i] =  + _REFACS_1_;}
	O1774[1215] =  + _REFACS_2_;
	O1774[1216] =  + _REFACS_3_;
	O1774[1217] =  + _REFACS_5_;
	O1774[1218] =  + _REFACS_2_;
	O1774[1219] =  + _REFACS_1_;
	{long i; for (i = 1220; i < 1222; i++) O1774[i] =  + _REFACS_3_;}
	O1774[1222] =  + _REFACS_2_;
	O1774[1223] =  + _REFACS_3_;
	O1774[1224] =  + _REFACS_7_;
	O1774[1225] =  + _REFACS_2_;
	O1774[1226] =  + _REFACS_5_;
	{long i; for (i = 1227; i < 1231; i++) O1774[i] =  + _REFACS_1_;}
	{long i; for (i = 1253; i < 1257; i++) O1774[i] =  + _REFACS_6_;}
	O1774[1258] =  + _REFACS_1_;
	O1774[1260] =  + _REFACS_1_;
	O1774[1263] =  + _REFACS_1_;
	O1774[1265] =  + _REFACS_1_;
}

long O2875[1243];
void O2875_init () {
	O2875[0] = 0;
	{long i; for (i = 1233; i < 1237; i++) O2875[i] =  + _REFACS_3_;}
	O2875[1237] =  + _REFACS_4_;
	{long i; for (i = 1238; i < 1242; i++) O2875[i] =  + _REFACS_3_;}
	O2875[1242] =  + _REFACS_4_;
}

long O2964[1178];
void O2964_init () {
	O2964[0] = 0;
	{long i; for (i = 1170; i < 1172; i++) O2964[i] =  + _REFACS_4_;}
	{long i; for (i = 1172; i < 1174; i++) O2964[i] =  + _REFACS_7_;}
	{long i; for (i = 1174; i < 1176; i++) O2964[i] =  + _REFACS_4_;}
	{long i; for (i = 1176; i < 1178; i++) O2964[i] =  + _REFACS_7_;}
}

long O2966[1178];
void O2966_init () {
	O2966[0] =  + _REFACS_1_;
	{long i; for (i = 1170; i < 1172; i++) O2966[i] =  + _REFACS_5_;}
	{long i; for (i = 1172; i < 1174; i++) O2966[i] =  + _REFACS_8_;}
	{long i; for (i = 1174; i < 1176; i++) O2966[i] =  + _REFACS_5_;}
	{long i; for (i = 1176; i < 1178; i++) O2966[i] =  + _REFACS_8_;}
}


#ifdef __cplusplus
}
#endif
