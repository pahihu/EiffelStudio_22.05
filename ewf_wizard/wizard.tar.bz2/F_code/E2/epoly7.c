#include "epoly7.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4940[548])();
void R4940_init () {
	R4940[0] = (char *(*)()) F429_5199;
	R4940[1] = (char *(*)()) F431_5199;
	R4940[2] = (char *(*)()) F437_5199;
	{long i; for (i = 3; i < 5; i++) R4940[i] = (char *(*)()) F429_5199;}
	R4940[5] = (char *(*)()) F437_5199;
	R4940[6] = (char *(*)()) F431_5199;
	R4940[9] = (char *(*)()) F428_5199;
	R4940[10] = (char *(*)()) F430_5199;
	R4940[11] = (char *(*)()) F429_5199;
	R4940[12] = (char *(*)()) F431_5199;
	R4940[13] = (char *(*)()) F436_5199;
	R4940[14] = (char *(*)()) F438_5199;
	R4940[15] = (char *(*)()) F428_5199;
	R4940[16] = (char *(*)()) F430_5199;
	R4940[17] = (char *(*)()) F428_5199;
	R4940[412] = (char *(*)()) F440_5199;
	R4940[415] = (char *(*)()) F441_5199;
	{long i; for (i = 494; i < 497; i++) R4940[i] = (char *(*)()) F429_5199;}
	{long i; for (i = 497; i < 499; i++) R4940[i] = (char *(*)()) F1136_10350;}
	{long i; for (i = 500; i < 502; i++) R4940[i] = (char *(*)()) F1136_10350;}
	{long i; for (i = 505; i < 508; i++) R4940[i] = (char *(*)()) F1136_10350;}
	R4940[509] = (char *(*)()) F1136_10350;
	R4940[537] = (char *(*)()) F429_5199;
	R4940[547] = (char *(*)()) F429_5199;
}

char *(*R4942[29])();
void R4942_init () {
	R4942[0] = (char *(*)()) F643_5548;
	R4942[1] = (char *(*)()) F644_5548_4942_4;
	R4942[2] = (char *(*)()) F645_5548_4942_4;
	R4942[26] = (char *(*)()) F669_5791;
	R4942[27] = (char *(*)()) F670_5791_4942_4;
	R4942[28] = (char *(*)()) F671_5791_4942_4;
}
static void F644_5548_4942_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F644_5548(Current, *(EIF_BOOLEAN *)arg1);
}
static void F645_5548_4942_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F645_5548(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F670_5791_4942_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F670_5791(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F671_5791_4942_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F671_5791(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R4943[735])();
void R4943_init () {
	R4943[0] = (char *(*)()) F639_5506;
	R4943[1] = (char *(*)()) F640_5506_4943_4;
	R4943[2] = (char *(*)()) F641_5506_4943_4;
	R4943[3] = (char *(*)()) F642_5529;
	R4943[4] = (char *(*)()) F643_5547;
	R4943[5] = (char *(*)()) F644_5547_4943_4;
	R4943[6] = (char *(*)()) F645_5547_4943_4;
	R4943[18] = (char *(*)()) F657_5764;
	R4943[19] = (char *(*)()) F658_5764_4943_4;
	R4943[20] = (char *(*)()) F659_5764_4943_4;
	R4943[21] = (char *(*)()) F660_5764_4943_4;
	R4943[22] = (char *(*)()) F661_5764_4943_4;
	R4943[23] = (char *(*)()) F662_5764_4943_4;
	R4943[24] = (char *(*)()) F663_5764_4943_4;
	R4943[25] = (char *(*)()) F664_5764_4943_4;
	R4943[26] = (char *(*)()) F665_5764_4943_4;
	R4943[27] = (char *(*)()) F666_5764_4943_4;
	R4943[28] = (char *(*)()) F667_5764_4943_4;
	R4943[29] = (char *(*)()) F668_5764_4943_4;
	R4943[30] = (char *(*)()) F669_5790;
	R4943[31] = (char *(*)()) F670_5790_4943_4;
	R4943[32] = (char *(*)()) F671_5790_4943_4;
	R4943[37] = (char *(*)()) F672_5806;
	R4943[38] = (char *(*)()) F673_5806_4943_4;
	{long i; for (i = 39; i < 43; i++) R4943[i] = (char *(*)()) F672_5806;}
	R4943[47] = (char *(*)()) F672_5806;
	R4943[49] = (char *(*)()) F672_5806;
	R4943[51] = (char *(*)()) F672_5806;
	R4943[55] = (char *(*)()) F672_5806;
	{long i; for (i = 57; i < 61; i++) R4943[i] = (char *(*)()) F672_5806;}
	{long i; for (i = 281; i < 283; i++) R4943[i] = (char *(*)()) F919_7183_4943_4;}
	R4943[412] = (char *(*)()) F1051_9248_4943_4;
	R4943[415] = (char *(*)()) F1054_9413_4943_4;
	{long i; for (i = 494; i < 499; i++) R4943[i] = (char *(*)()) F1128_10255;}
	{long i; for (i = 500; i < 502; i++) R4943[i] = (char *(*)()) F1128_10255;}
	{long i; for (i = 505; i < 508; i++) R4943[i] = (char *(*)()) F1128_10255;}
	R4943[509] = (char *(*)()) F1128_10255;
	R4943[537] = (char *(*)()) F1125_10174;
	R4943[547] = (char *(*)()) F1125_10174;
	R4943[734] = (char *(*)()) F919_7183_4943_4;
}
static void F640_5506_4943_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F640_5506(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F641_5506_4943_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F641_5506(Current, *(EIF_BOOLEAN *)arg1);
}
static void F644_5547_4943_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F644_5547(Current, *(EIF_BOOLEAN *)arg1);
}
static void F645_5547_4943_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F645_5547(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F658_5764_4943_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F658_5764(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F659_5764_4943_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F659_5764(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F660_5764_4943_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F660_5764(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F661_5764_4943_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F661_5764(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F662_5764_4943_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F662_5764(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F663_5764_4943_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F663_5764(Current, *(EIF_BOOLEAN *)arg1);
}
static void F664_5764_4943_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F664_5764(Current, *(EIF_POINTER *)arg1);
}
static void F665_5764_4943_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F665_5764(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F666_5764_4943_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F666_5764(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F667_5764_4943_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F667_5764(Current, *(EIF_REAL_32 *)arg1);
}
static void F668_5764_4943_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F668_5764(Current, *(EIF_REAL_64 *)arg1);
}
static void F670_5790_4943_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F670_5790(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F671_5790_4943_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F671_5790(Current, *(EIF_BOOLEAN *)arg1);
}
static void F673_5806_4943_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F673_5806(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F919_7183_4943_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F919_7183(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1051_9248_4943_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1051_9248(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1054_9413_4943_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1054_9413(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4944[548])();
void R4944_init () {
	R4944[0] = (char *(*)()) F591_5449;
	R4944[1] = (char *(*)()) F592_5449;
	R4944[2] = (char *(*)()) F597_5449;
	R4944[4] = (char *(*)()) F537_5293;
	R4944[5] = (char *(*)()) F539_5293;
	R4944[6] = (char *(*)()) F538_5293;
	R4944[18] = (char *(*)()) F591_5449;
	R4944[19] = (char *(*)()) F592_5449;
	R4944[20] = (char *(*)()) F593_5449;
	R4944[21] = (char *(*)()) F594_5449;
	R4944[22] = (char *(*)()) F595_5449;
	R4944[23] = (char *(*)()) F596_5449;
	R4944[24] = (char *(*)()) F597_5449;
	R4944[25] = (char *(*)()) F598_5449;
	R4944[26] = (char *(*)()) F599_5449;
	R4944[27] = (char *(*)()) F600_5449;
	R4944[28] = (char *(*)()) F601_5449;
	R4944[29] = (char *(*)()) F602_5449;
	R4944[30] = (char *(*)()) F537_5293;
	R4944[31] = (char *(*)()) F538_5293;
	R4944[32] = (char *(*)()) F539_5293;
	R4944[37] = (char *(*)()) F591_5449;
	R4944[38] = (char *(*)()) F592_5449;
	{long i; for (i = 39; i < 43; i++) R4944[i] = (char *(*)()) F591_5449;}
	R4944[47] = (char *(*)()) F591_5449;
	R4944[49] = (char *(*)()) F591_5449;
	R4944[51] = (char *(*)()) F591_5449;
	R4944[55] = (char *(*)()) F591_5449;
	{long i; for (i = 57; i < 61; i++) R4944[i] = (char *(*)()) F591_5449;}
	{long i; for (i = 494; i < 497; i++) R4944[i] = (char *(*)()) F591_5449;}
	R4944[537] = (char *(*)()) F591_5449;
	R4944[547] = (char *(*)()) F591_5449;
}

char *(*R4945[798])();
void R4945_init () {
	R4945[0] = (char *(*)()) F576_5335_4945_4;
	R4945[2] = (char *(*)()) F578_5404;
	R4945[3] = (char *(*)()) F579_5404_4945_4;
	R4945[4] = (char *(*)()) F580_5404_4945_4;
	R4945[5] = (char *(*)()) F581_5404_4945_4;
	R4945[6] = (char *(*)()) F582_5404_4945_4;
	R4945[7] = (char *(*)()) F583_5404_4945_4;
	R4945[8] = (char *(*)()) F584_5404_4945_4;
	R4945[9] = (char *(*)()) F585_5404_4945_4;
	R4945[10] = (char *(*)()) F586_5404_4945_4;
	R4945[11] = (char *(*)()) F587_5404_4945_4;
	R4945[12] = (char *(*)()) F588_5404_4945_4;
	R4945[13] = (char *(*)()) F589_5404_4945_4;
	R4945[63] = (char *(*)()) F603_5459;
	R4945[64] = (char *(*)()) F604_5459_4945_4;
	R4945[65] = (char *(*)()) F609_5459_4945_4;
	R4945[66] = (char *(*)()) F642_5534;
	R4945[67] = (char *(*)()) F603_5459;
	R4945[68] = (char *(*)()) F609_5459_4945_4;
	R4945[69] = (char *(*)()) F604_5459_4945_4;
	R4945[72] = (char *(*)()) F648_5645;
	R4945[73] = (char *(*)()) F649_5645_4945_4;
	R4945[74] = (char *(*)()) F650_5645;
	R4945[75] = (char *(*)()) F651_5645_4945_4;
	R4945[76] = (char *(*)()) F652_5645_4945_4;
	R4945[77] = (char *(*)()) F653_5645_4945_4;
	R4945[78] = (char *(*)()) F648_5645;
	R4945[79] = (char *(*)()) F649_5645_4945_4;
	R4945[80] = (char *(*)()) F648_5645;
	R4945[81] = (char *(*)()) F657_5776;
	R4945[82] = (char *(*)()) F658_5776_4945_4;
	R4945[83] = (char *(*)()) F659_5776_4945_4;
	R4945[84] = (char *(*)()) F660_5776_4945_4;
	R4945[85] = (char *(*)()) F661_5776_4945_4;
	R4945[86] = (char *(*)()) F662_5776_4945_4;
	R4945[87] = (char *(*)()) F663_5776_4945_4;
	R4945[88] = (char *(*)()) F664_5776_4945_4;
	R4945[89] = (char *(*)()) F665_5776_4945_4;
	R4945[90] = (char *(*)()) F666_5776_4945_4;
	R4945[91] = (char *(*)()) F667_5776_4945_4;
	R4945[92] = (char *(*)()) F668_5776_4945_4;
	R4945[93] = (char *(*)()) F657_5776;
	R4945[94] = (char *(*)()) F658_5776_4945_4;
	R4945[95] = (char *(*)()) F663_5776_4945_4;
	R4945[100] = (char *(*)()) F657_5776;
	R4945[101] = (char *(*)()) F658_5776_4945_4;
	R4945[102] = (char *(*)()) F657_5776;
	{long i; for (i = 103; i < 106; i++) R4945[i] = (char *(*)()) F679_5857;}
	R4945[110] = (char *(*)()) F679_5857;
	R4945[112] = (char *(*)()) F679_5857;
	R4945[114] = (char *(*)()) F679_5857;
	R4945[118] = (char *(*)()) F679_5857;
	{long i; for (i = 120; i < 124; i++) R4945[i] = (char *(*)()) F679_5857;}
	R4945[146] = (char *(*)()) F482_5227_4945_4;
	R4945[151] = (char *(*)()) F482_5227_4945_4;
	{long i; for (i = 344; i < 346; i++) R4945[i] = (char *(*)()) F919_7304_4945_4;}
	R4945[475] = (char *(*)()) F1051_9259_4945_4;
	R4945[478] = (char *(*)()) F1054_9424_4945_4;
	{long i; for (i = 557; i < 562; i++) R4945[i] = (char *(*)()) F1128_10256;}
	{long i; for (i = 563; i < 565; i++) R4945[i] = (char *(*)()) F1128_10256;}
	{long i; for (i = 568; i < 571; i++) R4945[i] = (char *(*)()) F1128_10256;}
	R4945[572] = (char *(*)()) F1128_10256;
	R4945[600] = (char *(*)()) F603_5459;
	R4945[610] = (char *(*)()) F603_5459;
	R4945[797] = (char *(*)()) F919_7304_4945_4;
}
static void F576_5335_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F576_5335(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F579_5404_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F579_5404(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F580_5404_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F580_5404(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F581_5404_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F581_5404(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F582_5404_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F582_5404(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F583_5404_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F583_5404(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F584_5404_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F584_5404(Current, *(EIF_BOOLEAN *)arg1);
}
static void F585_5404_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F585_5404(Current, *(EIF_POINTER *)arg1);
}
static void F586_5404_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F586_5404(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F587_5404_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F587_5404(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F588_5404_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F588_5404(Current, *(EIF_REAL_32 *)arg1);
}
static void F589_5404_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F589_5404(Current, *(EIF_REAL_64 *)arg1);
}
static void F604_5459_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F604_5459(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F609_5459_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F609_5459(Current, *(EIF_BOOLEAN *)arg1);
}
static void F649_5645_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F649_5645(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F651_5645_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F651_5645(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F652_5645_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F652_5645(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F653_5645_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F653_5645(Current, *(EIF_POINTER *)arg1);
}
static void F658_5776_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F658_5776(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F659_5776_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F659_5776(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F660_5776_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F660_5776(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F661_5776_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F661_5776(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F662_5776_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F662_5776(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F663_5776_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F663_5776(Current, *(EIF_BOOLEAN *)arg1);
}
static void F664_5776_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F664_5776(Current, *(EIF_POINTER *)arg1);
}
static void F665_5776_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F665_5776(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F666_5776_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F666_5776(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F667_5776_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F667_5776(Current, *(EIF_REAL_32 *)arg1);
}
static void F668_5776_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F668_5776(Current, *(EIF_REAL_64 *)arg1);
}
static void F482_5227_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F482_5227(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F919_7304_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F919_7304(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1051_9259_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1051_9259(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F1054_9424_4945_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1054_9424(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4946[611])();
void R4946_init () {
	R4946[0] = (char *(*)()) F388_5184_4946_4;
	R4946[2] = (char *(*)()) F387_5184;
	R4946[3] = (char *(*)()) F388_5184_4946_4;
	R4946[4] = (char *(*)()) F389_5184_4946_4;
	R4946[5] = (char *(*)()) F390_5184_4946_4;
	R4946[6] = (char *(*)()) F391_5184_4946_4;
	R4946[7] = (char *(*)()) F392_5184_4946_4;
	R4946[8] = (char *(*)()) F393_5184_4946_4;
	R4946[9] = (char *(*)()) F394_5184_4946_4;
	R4946[10] = (char *(*)()) F395_5184_4946_4;
	R4946[11] = (char *(*)()) F396_5184_4946_4;
	R4946[12] = (char *(*)()) F397_5184_4946_4;
	R4946[13] = (char *(*)()) F398_5184_4946_4;
	R4946[63] = (char *(*)()) F603_5460;
	R4946[64] = (char *(*)()) F604_5460_4946_4;
	R4946[65] = (char *(*)()) F609_5460_4946_4;
	R4946[66] = (char *(*)()) F642_5535;
	R4946[67] = (char *(*)()) F387_5184;
	R4946[68] = (char *(*)()) F393_5184_4946_4;
	R4946[69] = (char *(*)()) F388_5184_4946_4;
	R4946[72] = (char *(*)()) F387_5184;
	R4946[73] = (char *(*)()) F388_5184_4946_4;
	R4946[74] = (char *(*)()) F387_5184;
	{long i; for (i = 75; i < 77; i++) R4946[i] = (char *(*)()) F388_5184_4946_4;}
	R4946[77] = (char *(*)()) F394_5184_4946_4;
	R4946[78] = (char *(*)()) F387_5184;
	R4946[79] = (char *(*)()) F388_5184_4946_4;
	R4946[80] = (char *(*)()) F387_5184;
	R4946[100] = (char *(*)()) F672_5816;
	R4946[101] = (char *(*)()) F673_5816_4946_4;
	{long i; for (i = 102; i < 106; i++) R4946[i] = (char *(*)()) F672_5816;}
	R4946[110] = (char *(*)()) F672_5816;
	R4946[112] = (char *(*)()) F672_5816;
	R4946[114] = (char *(*)()) F672_5816;
	R4946[118] = (char *(*)()) F672_5816;
	{long i; for (i = 120; i < 124; i++) R4946[i] = (char *(*)()) F672_5816;}
	R4946[146] = (char *(*)()) F388_5184_4946_4;
	R4946[151] = (char *(*)()) F388_5184_4946_4;
	R4946[475] = (char *(*)()) F1051_9260_4946_4;
	{long i; for (i = 557; i < 560; i++) R4946[i] = (char *(*)()) F603_5460;}
	{long i; for (i = 560; i < 562; i++) R4946[i] = (char *(*)()) F387_5184;}
	{long i; for (i = 563; i < 565; i++) R4946[i] = (char *(*)()) F387_5184;}
	{long i; for (i = 568; i < 571; i++) R4946[i] = (char *(*)()) F387_5184;}
	R4946[572] = (char *(*)()) F387_5184;
	R4946[600] = (char *(*)()) F603_5460;
	R4946[610] = (char *(*)()) F603_5460;
}
static void F388_5184_4946_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F388_5184(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F389_5184_4946_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F389_5184(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F390_5184_4946_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F390_5184(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F391_5184_4946_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F391_5184(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F392_5184_4946_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F392_5184(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F393_5184_4946_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F393_5184(Current, *(EIF_BOOLEAN *)arg1);
}
static void F394_5184_4946_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F394_5184(Current, *(EIF_POINTER *)arg1);
}
static void F395_5184_4946_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F395_5184(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F396_5184_4946_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F396_5184(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F397_5184_4946_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F397_5184(Current, *(EIF_REAL_32 *)arg1);
}
static void F398_5184_4946_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F398_5184(Current, *(EIF_REAL_64 *)arg1);
}
static void F604_5460_4946_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F604_5460(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F609_5460_4946_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F609_5460(Current, *(EIF_BOOLEAN *)arg1);
}
static void F673_5816_4946_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F673_5816(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1051_9260_4946_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1051_9260(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R4947[539])();
void R4947_init () {
	R4947[0] = (char *(*)()) F648_5646;
	R4947[1] = (char *(*)()) F649_5646;
	R4947[2] = (char *(*)()) F650_5646;
	R4947[3] = (char *(*)()) F651_5646;
	R4947[4] = (char *(*)()) F652_5646;
	R4947[5] = (char *(*)()) F653_5646;
	R4947[6] = (char *(*)()) F648_5646;
	R4947[7] = (char *(*)()) F649_5646;
	R4947[8] = (char *(*)()) F648_5646;
	R4947[9] = (char *(*)()) F657_5782;
	R4947[10] = (char *(*)()) F658_5782;
	R4947[11] = (char *(*)()) F659_5782;
	R4947[12] = (char *(*)()) F660_5782;
	R4947[13] = (char *(*)()) F661_5782;
	R4947[14] = (char *(*)()) F662_5782;
	R4947[15] = (char *(*)()) F663_5782;
	R4947[16] = (char *(*)()) F664_5782;
	R4947[17] = (char *(*)()) F665_5782;
	R4947[18] = (char *(*)()) F666_5782;
	R4947[19] = (char *(*)()) F667_5782;
	R4947[20] = (char *(*)()) F668_5782;
	R4947[21] = (char *(*)()) F657_5782;
	R4947[22] = (char *(*)()) F658_5782;
	R4947[23] = (char *(*)()) F663_5782;
	R4947[28] = (char *(*)()) F672_5818;
	R4947[29] = (char *(*)()) F673_5818;
	{long i; for (i = 30; i < 34; i++) R4947[i] = (char *(*)()) F672_5818;}
	R4947[38] = (char *(*)()) F672_5818;
	R4947[40] = (char *(*)()) F672_5818;
	R4947[42] = (char *(*)()) F672_5818;
	R4947[46] = (char *(*)()) F672_5818;
	{long i; for (i = 48; i < 52; i++) R4947[i] = (char *(*)()) F672_5818;}
	R4947[403] = (char *(*)()) F1051_9263;
	R4947[406] = (char *(*)()) F1054_9428;
	{long i; for (i = 485; i < 488; i++) R4947[i] = (char *(*)()) F1125_10169;}
	{long i; for (i = 488; i < 490; i++) R4947[i] = (char *(*)()) F1136_10355;}
	{long i; for (i = 491; i < 493; i++) R4947[i] = (char *(*)()) F1136_10355;}
	{long i; for (i = 496; i < 499; i++) R4947[i] = (char *(*)()) F1136_10355;}
	R4947[500] = (char *(*)()) F1136_10355;
	R4947[528] = (char *(*)()) F1125_10169;
	R4947[538] = (char *(*)()) F1125_10169;
}

char *(*R4950[611])();
void R4950_init () {
	R4950[0] = (char *(*)()) F576_5306_4950_5;
	R4950[2] = (char *(*)()) F578_5354_4950_5;
	R4950[3] = (char *(*)()) F579_5354_4950_5;
	R4950[4] = (char *(*)()) F580_5354_4950_5;
	R4950[5] = (char *(*)()) F581_5354_4950_5;
	R4950[6] = (char *(*)()) F582_5354_4950_5;
	R4950[7] = (char *(*)()) F583_5354_4950_5;
	R4950[8] = (char *(*)()) F584_5354_4950_5;
	R4950[9] = (char *(*)()) F585_5354_4950_5;
	R4950[10] = (char *(*)()) F586_5354_4950_5;
	R4950[11] = (char *(*)()) F587_5354_4950_5;
	R4950[12] = (char *(*)()) F588_5354_4950_5;
	R4950[13] = (char *(*)()) F589_5354_4950_5;
	R4950[63] = (char *(*)()) F591_5433_4950_5;
	R4950[64] = (char *(*)()) F592_5433_4950_5;
	R4950[65] = (char *(*)()) F597_5433_4950_5;
	{long i; for (i = 66; i < 68; i++) R4950[i] = (char *(*)()) F591_5433_4950_5;}
	R4950[68] = (char *(*)()) F597_5433_4950_5;
	R4950[69] = (char *(*)()) F592_5433_4950_5;
	R4950[72] = (char *(*)()) F648_5597;
	R4950[73] = (char *(*)()) F649_5597_4950_5;
	R4950[74] = (char *(*)()) F650_5597_4950_5;
	R4950[75] = (char *(*)()) F651_5597_4950_5;
	R4950[76] = (char *(*)()) F652_5597_4950_5;
	R4950[77] = (char *(*)()) F653_5597_4950_5;
	R4950[78] = (char *(*)()) F648_5597;
	R4950[79] = (char *(*)()) F649_5597_4950_5;
	R4950[80] = (char *(*)()) F648_5597;
	R4950[81] = (char *(*)()) F657_5729_4950_5;
	R4950[82] = (char *(*)()) F658_5729_4950_5;
	R4950[83] = (char *(*)()) F659_5729_4950_5;
	R4950[84] = (char *(*)()) F660_5729_4950_5;
	R4950[85] = (char *(*)()) F661_5729_4950_5;
	R4950[86] = (char *(*)()) F662_5729_4950_5;
	R4950[87] = (char *(*)()) F663_5729_4950_5;
	R4950[88] = (char *(*)()) F664_5729_4950_5;
	R4950[89] = (char *(*)()) F665_5729_4950_5;
	R4950[90] = (char *(*)()) F666_5729_4950_5;
	R4950[91] = (char *(*)()) F667_5729_4950_5;
	R4950[92] = (char *(*)()) F668_5729_4950_5;
	R4950[93] = (char *(*)()) F657_5729_4950_5;
	R4950[94] = (char *(*)()) F658_5729_4950_5;
	R4950[95] = (char *(*)()) F663_5729_4950_5;
	R4950[100] = (char *(*)()) F657_5729_4950_5;
	R4950[101] = (char *(*)()) F658_5729_4950_5;
	{long i; for (i = 102; i < 106; i++) R4950[i] = (char *(*)()) F657_5729_4950_5;}
	R4950[110] = (char *(*)()) F657_5729_4950_5;
	R4950[112] = (char *(*)()) F657_5729_4950_5;
	R4950[114] = (char *(*)()) F657_5729_4950_5;
	R4950[118] = (char *(*)()) F657_5729_4950_5;
	{long i; for (i = 120; i < 124; i++) R4950[i] = (char *(*)()) F657_5729_4950_5;}
	R4950[475] = (char *(*)()) F1051_9201_4950_5;
	R4950[478] = (char *(*)()) F1054_9365_4950_5;
	{long i; for (i = 557; i < 560; i++) R4950[i] = (char *(*)()) F1125_10141_4950_5;}
	R4950[600] = (char *(*)()) F1125_10141_4950_5;
	R4950[610] = (char *(*)()) F1125_10141_4950_5;
}
static EIF_REFERENCE F576_5306_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F576_5306(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F578_5354_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F578_5354(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F579_5354_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F579_5354(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F580_5354_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F580_5354(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(999, 0x00).id, 999, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F581_5354_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F581_5354(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(993, 0x00).id, 993, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F582_5354_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F582_5354(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F583_5354_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F583_5354(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F584_5354_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F584_5354(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F585_5354_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F585_5354(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F586_5354_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F586_5354(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F587_5354_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F587_5354(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F588_5354_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F588_5354(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F589_5354_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F589_5354(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F591_5433_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F591_5433(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F592_5433_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F592_5433(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F597_5433_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F597_5433(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F649_5597_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F649_5597(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F650_5597_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F650_5597(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F651_5597_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F651_5597(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F652_5597_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F652_5597(Current, *(EIF_NATURAL_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F653_5597_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F653_5597(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F657_5729_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F657_5729(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F658_5729_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F658_5729(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F659_5729_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F659_5729(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(999, 0x00).id, 999, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F660_5729_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F660_5729(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(993, 0x00).id, 993, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F661_5729_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F661_5729(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F662_5729_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F662_5729(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F663_5729_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F663_5729(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_5729_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F664_5729(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F665_5729_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F665_5729(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_5729_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F666_5729(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_5729_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F667_5729(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_5729_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F668_5729(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1051_9201_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1051_9201(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1054_9365_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1054_9365(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1125_10141_4950_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1125_10141(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4951[609])();
void R4951_init () {
	R4951[0] = (char *(*)()) F578_5355_4951_5;
	R4951[1] = (char *(*)()) F579_5355_4951_5;
	R4951[2] = (char *(*)()) F580_5355_4951_5;
	R4951[3] = (char *(*)()) F581_5355_4951_5;
	R4951[4] = (char *(*)()) F582_5355_4951_5;
	R4951[5] = (char *(*)()) F583_5355_4951_5;
	R4951[6] = (char *(*)()) F584_5355_4951_5;
	R4951[7] = (char *(*)()) F585_5355_4951_5;
	R4951[8] = (char *(*)()) F586_5355_4951_5;
	R4951[9] = (char *(*)()) F587_5355_4951_5;
	R4951[10] = (char *(*)()) F588_5355_4951_5;
	R4951[11] = (char *(*)()) F589_5355_4951_5;
	R4951[61] = (char *(*)()) F591_5434_4951_5;
	R4951[62] = (char *(*)()) F592_5434_4951_5;
	R4951[63] = (char *(*)()) F597_5434_4951_5;
	{long i; for (i = 64; i < 66; i++) R4951[i] = (char *(*)()) F591_5434_4951_5;}
	R4951[66] = (char *(*)()) F597_5434_4951_5;
	R4951[67] = (char *(*)()) F592_5434_4951_5;
	R4951[70] = (char *(*)()) F648_5597;
	R4951[71] = (char *(*)()) F649_5597_4951_5;
	R4951[72] = (char *(*)()) F650_5597_4951_5;
	R4951[73] = (char *(*)()) F651_5597_4951_5;
	R4951[74] = (char *(*)()) F652_5597_4951_5;
	R4951[75] = (char *(*)()) F653_5597_4951_5;
	R4951[76] = (char *(*)()) F648_5597;
	R4951[77] = (char *(*)()) F649_5597_4951_5;
	R4951[78] = (char *(*)()) F648_5597;
	R4951[79] = (char *(*)()) F657_5730_4951_5;
	R4951[80] = (char *(*)()) F658_5730_4951_5;
	R4951[81] = (char *(*)()) F659_5730_4951_5;
	R4951[82] = (char *(*)()) F660_5730_4951_5;
	R4951[83] = (char *(*)()) F661_5730_4951_5;
	R4951[84] = (char *(*)()) F662_5730_4951_5;
	R4951[85] = (char *(*)()) F663_5730_4951_5;
	R4951[86] = (char *(*)()) F664_5730_4951_5;
	R4951[87] = (char *(*)()) F665_5730_4951_5;
	R4951[88] = (char *(*)()) F666_5730_4951_5;
	R4951[89] = (char *(*)()) F667_5730_4951_5;
	R4951[90] = (char *(*)()) F668_5730_4951_5;
	R4951[91] = (char *(*)()) F657_5730_4951_5;
	R4951[92] = (char *(*)()) F658_5730_4951_5;
	R4951[93] = (char *(*)()) F663_5730_4951_5;
	R4951[98] = (char *(*)()) F657_5730_4951_5;
	R4951[99] = (char *(*)()) F658_5730_4951_5;
	{long i; for (i = 100; i < 104; i++) R4951[i] = (char *(*)()) F657_5730_4951_5;}
	R4951[108] = (char *(*)()) F657_5730_4951_5;
	R4951[110] = (char *(*)()) F657_5730_4951_5;
	R4951[112] = (char *(*)()) F657_5730_4951_5;
	R4951[116] = (char *(*)()) F657_5730_4951_5;
	{long i; for (i = 118; i < 122; i++) R4951[i] = (char *(*)()) F657_5730_4951_5;}
	R4951[473] = (char *(*)()) F1051_9202_4951_5;
	{long i; for (i = 555; i < 558; i++) R4951[i] = (char *(*)()) F591_5434_4951_5;}
	R4951[598] = (char *(*)()) F591_5434_4951_5;
	R4951[608] = (char *(*)()) F591_5434_4951_5;
}
static EIF_REFERENCE F578_5355_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F578_5355(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F579_5355_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F579_5355(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F580_5355_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F580_5355(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(999, 0x00).id, 999, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F581_5355_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F581_5355(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(993, 0x00).id, 993, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F582_5355_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F582_5355(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F583_5355_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F583_5355(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F584_5355_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F584_5355(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F585_5355_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F585_5355(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F586_5355_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F586_5355(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F587_5355_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F587_5355(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F588_5355_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F588_5355(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F589_5355_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F589_5355(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F591_5434_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F591_5434(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F592_5434_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F592_5434(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F597_5434_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F597_5434(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F649_5597_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F649_5597(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F650_5597_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F650_5597(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F651_5597_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F651_5597(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F652_5597_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F652_5597(Current, *(EIF_NATURAL_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F653_5597_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F653_5597(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F657_5730_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F657_5730(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F658_5730_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F658_5730(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F659_5730_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F659_5730(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(999, 0x00).id, 999, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F660_5730_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F660_5730(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(993, 0x00).id, 993, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F661_5730_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F661_5730(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F662_5730_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F662_5730(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F663_5730_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F663_5730(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_5730_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F664_5730(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F665_5730_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F665_5730(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_5730_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F666_5730(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_5730_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F667_5730(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_5730_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F668_5730(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1051_9202_4951_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1051_9202(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}

char *(*R4952[611])();
void R4952_init () {
	R4952[0] = (char *(*)()) F576_5309_4952_2;
	R4952[2] = (char *(*)()) F578_5369_4952_2;
	R4952[3] = (char *(*)()) F579_5369_4952_2;
	R4952[4] = (char *(*)()) F580_5369_4952_2;
	R4952[5] = (char *(*)()) F581_5369_4952_2;
	R4952[6] = (char *(*)()) F582_5369_4952_2;
	R4952[7] = (char *(*)()) F583_5369_4952_2;
	R4952[8] = (char *(*)()) F584_5369_4952_2;
	R4952[9] = (char *(*)()) F585_5369_4952_2;
	R4952[10] = (char *(*)()) F586_5369_4952_2;
	R4952[11] = (char *(*)()) F587_5369_4952_2;
	R4952[12] = (char *(*)()) F588_5369_4952_2;
	R4952[13] = (char *(*)()) F589_5369_4952_2;
	R4952[63] = (char *(*)()) F591_5441_4952_2;
	R4952[64] = (char *(*)()) F592_5441_4952_2;
	R4952[65] = (char *(*)()) F597_5441_4952_2;
	{long i; for (i = 66; i < 68; i++) R4952[i] = (char *(*)()) F591_5441_4952_2;}
	R4952[68] = (char *(*)()) F597_5441_4952_2;
	R4952[69] = (char *(*)()) F592_5441_4952_2;
	R4952[72] = (char *(*)()) F648_5600;
	R4952[73] = (char *(*)()) F649_5600;
	R4952[74] = (char *(*)()) F650_5600_4952_2;
	R4952[75] = (char *(*)()) F651_5600_4952_2;
	R4952[76] = (char *(*)()) F652_5600_4952_2;
	R4952[77] = (char *(*)()) F653_5600;
	R4952[78] = (char *(*)()) F648_5600;
	R4952[79] = (char *(*)()) F649_5600;
	R4952[80] = (char *(*)()) F648_5600;
	R4952[81] = (char *(*)()) F657_5750_4952_2;
	R4952[82] = (char *(*)()) F658_5750_4952_2;
	R4952[83] = (char *(*)()) F659_5750_4952_2;
	R4952[84] = (char *(*)()) F660_5750_4952_2;
	R4952[85] = (char *(*)()) F661_5750_4952_2;
	R4952[86] = (char *(*)()) F662_5750_4952_2;
	R4952[87] = (char *(*)()) F663_5750_4952_2;
	R4952[88] = (char *(*)()) F664_5750_4952_2;
	R4952[89] = (char *(*)()) F665_5750_4952_2;
	R4952[90] = (char *(*)()) F666_5750_4952_2;
	R4952[91] = (char *(*)()) F667_5750_4952_2;
	R4952[92] = (char *(*)()) F668_5750_4952_2;
	R4952[93] = (char *(*)()) F657_5750_4952_2;
	R4952[94] = (char *(*)()) F658_5750_4952_2;
	R4952[95] = (char *(*)()) F663_5750_4952_2;
	R4952[100] = (char *(*)()) F657_5750_4952_2;
	R4952[101] = (char *(*)()) F658_5750_4952_2;
	{long i; for (i = 102; i < 106; i++) R4952[i] = (char *(*)()) F657_5750_4952_2;}
	R4952[110] = (char *(*)()) F657_5750_4952_2;
	R4952[112] = (char *(*)()) F657_5750_4952_2;
	R4952[114] = (char *(*)()) F657_5750_4952_2;
	R4952[118] = (char *(*)()) F657_5750_4952_2;
	{long i; for (i = 120; i < 124; i++) R4952[i] = (char *(*)()) F657_5750_4952_2;}
	R4952[475] = (char *(*)()) F1046_9001_4952_2;
	R4952[478] = (char *(*)()) F1046_9001_4952_2;
	{long i; for (i = 557; i < 560; i++) R4952[i] = (char *(*)()) F591_5441_4952_2;}
	R4952[600] = (char *(*)()) F591_5441_4952_2;
	R4952[610] = (char *(*)()) F591_5441_4952_2;
}
static EIF_BOOLEAN F576_5309_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F576_5309(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F578_5369_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F578_5369(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F579_5369_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F579_5369(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F580_5369_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F580_5369(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F581_5369_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F581_5369(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F582_5369_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F582_5369(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F583_5369_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F583_5369(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F584_5369_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F584_5369(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F585_5369_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F585_5369(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F586_5369_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F586_5369(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F587_5369_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F587_5369(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F588_5369_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F588_5369(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F589_5369_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F589_5369(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F591_5441_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F591_5441(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F592_5441_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F592_5441(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F597_5441_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F597_5441(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F650_5600_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F650_5600(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F651_5600_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F651_5600(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F652_5600_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F652_5600(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F657_5750_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F657_5750(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F658_5750_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F658_5750(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F659_5750_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F659_5750(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F660_5750_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F660_5750(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F661_5750_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F661_5750(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F662_5750_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F662_5750(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F663_5750_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F663_5750(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F664_5750_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F664_5750(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F665_5750_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F665_5750(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F666_5750_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F666_5750(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F667_5750_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F667_5750(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F668_5750_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F668_5750(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1046_9001_4952_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1046_9001(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4953[477])();
void R4953_init () {
	R4953[0] = (char *(*)()) F578_5373_4953_15;
	R4953[1] = (char *(*)()) F579_5373_4953_15;
	R4953[2] = (char *(*)()) F580_5373_4953_15;
	R4953[3] = (char *(*)()) F581_5373_4953_15;
	R4953[4] = (char *(*)()) F582_5373_4953_15;
	R4953[5] = (char *(*)()) F583_5373_4953_15;
	R4953[6] = (char *(*)()) F584_5373_4953_15;
	R4953[7] = (char *(*)()) F585_5373_4953_15;
	R4953[8] = (char *(*)()) F586_5373_4953_15;
	R4953[9] = (char *(*)()) F587_5373_4953_15;
	R4953[10] = (char *(*)()) F588_5373_4953_15;
	R4953[11] = (char *(*)()) F589_5373_4953_15;
	R4953[70] = (char *(*)()) F648_5638;
	R4953[71] = (char *(*)()) F649_5638_4953_15;
	R4953[72] = (char *(*)()) F650_5638_4953_15;
	R4953[73] = (char *(*)()) F651_5638_4953_15;
	R4953[74] = (char *(*)()) F652_5638_4953_15;
	R4953[75] = (char *(*)()) F653_5638_4953_15;
	R4953[76] = (char *(*)()) F648_5638;
	R4953[77] = (char *(*)()) F649_5638_4953_15;
	R4953[78] = (char *(*)()) F648_5638;
	R4953[79] = (char *(*)()) F657_5762_4953_15;
	R4953[80] = (char *(*)()) F658_5762_4953_15;
	R4953[81] = (char *(*)()) F659_5762_4953_15;
	R4953[82] = (char *(*)()) F660_5762_4953_15;
	R4953[83] = (char *(*)()) F661_5762_4953_15;
	R4953[84] = (char *(*)()) F662_5762_4953_15;
	R4953[85] = (char *(*)()) F663_5762_4953_15;
	R4953[86] = (char *(*)()) F664_5762_4953_15;
	R4953[87] = (char *(*)()) F665_5762_4953_15;
	R4953[88] = (char *(*)()) F666_5762_4953_15;
	R4953[89] = (char *(*)()) F667_5762_4953_15;
	R4953[90] = (char *(*)()) F668_5762_4953_15;
	R4953[91] = (char *(*)()) F657_5762_4953_15;
	R4953[92] = (char *(*)()) F658_5762_4953_15;
	R4953[93] = (char *(*)()) F663_5762_4953_15;
	R4953[98] = (char *(*)()) F672_5810_4953_15;
	R4953[99] = (char *(*)()) F673_5810_4953_15;
	{long i; for (i = 100; i < 104; i++) R4953[i] = (char *(*)()) F672_5810_4953_15;}
	R4953[108] = (char *(*)()) F672_5810_4953_15;
	R4953[110] = (char *(*)()) F672_5810_4953_15;
	R4953[112] = (char *(*)()) F672_5810_4953_15;
	R4953[116] = (char *(*)()) F672_5810_4953_15;
	{long i; for (i = 118; i < 122; i++) R4953[i] = (char *(*)()) F672_5810_4953_15;}
	R4953[473] = (char *(*)()) F1051_9221_4953_15;
	R4953[476] = (char *(*)()) F1054_9386_4953_15;
}
static void F578_5373_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F578_5373(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F579_5373_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F579_5373(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F580_5373_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F580_5373(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F581_5373_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F581_5373(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F582_5373_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F582_5373(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F583_5373_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F583_5373(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F584_5373_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F584_5373(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F585_5373_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F585_5373(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F586_5373_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F586_5373(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F587_5373_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F587_5373(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F588_5373_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F588_5373(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F589_5373_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F589_5373(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F649_5638_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F649_5638(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F650_5638_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F650_5638(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F651_5638_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F651_5638(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F652_5638_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F652_5638(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_NATURAL_32 *)arg2);
}
static void F653_5638_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F653_5638(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F657_5762_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F657_5762(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F658_5762_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F658_5762(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F659_5762_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F659_5762(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F660_5762_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F660_5762(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F661_5762_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F661_5762(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F662_5762_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F662_5762(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F663_5762_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F663_5762(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F664_5762_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F664_5762(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F665_5762_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F665_5762(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F666_5762_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F666_5762(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F667_5762_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F667_5762(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F668_5762_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F668_5762(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F672_5810_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F672_5810(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F673_5810_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F673_5810(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1051_9221_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1051_9221(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1054_9386_4953_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1054_9386(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R4954[477])();
void R4954_init () {
	R4954[0] = (char *(*)()) F578_5373_4954_15;
	R4954[1] = (char *(*)()) F579_5373_4954_15;
	R4954[2] = (char *(*)()) F580_5373_4954_15;
	R4954[3] = (char *(*)()) F581_5373_4954_15;
	R4954[4] = (char *(*)()) F582_5373_4954_15;
	R4954[5] = (char *(*)()) F583_5373_4954_15;
	R4954[6] = (char *(*)()) F584_5373_4954_15;
	R4954[7] = (char *(*)()) F585_5373_4954_15;
	R4954[8] = (char *(*)()) F586_5373_4954_15;
	R4954[9] = (char *(*)()) F587_5373_4954_15;
	R4954[10] = (char *(*)()) F588_5373_4954_15;
	R4954[11] = (char *(*)()) F589_5373_4954_15;
	R4954[70] = (char *(*)()) F648_5639;
	R4954[71] = (char *(*)()) F649_5639_4954_15;
	R4954[72] = (char *(*)()) F650_5639_4954_15;
	R4954[73] = (char *(*)()) F651_5639_4954_15;
	R4954[74] = (char *(*)()) F652_5639_4954_15;
	R4954[75] = (char *(*)()) F653_5639_4954_15;
	R4954[76] = (char *(*)()) F648_5639;
	R4954[77] = (char *(*)()) F649_5639_4954_15;
	R4954[78] = (char *(*)()) F648_5639;
	R4954[79] = (char *(*)()) F657_5762_4954_15;
	R4954[80] = (char *(*)()) F658_5762_4954_15;
	R4954[81] = (char *(*)()) F659_5762_4954_15;
	R4954[82] = (char *(*)()) F660_5762_4954_15;
	R4954[83] = (char *(*)()) F661_5762_4954_15;
	R4954[84] = (char *(*)()) F662_5762_4954_15;
	R4954[85] = (char *(*)()) F663_5762_4954_15;
	R4954[86] = (char *(*)()) F664_5762_4954_15;
	R4954[87] = (char *(*)()) F665_5762_4954_15;
	R4954[88] = (char *(*)()) F666_5762_4954_15;
	R4954[89] = (char *(*)()) F667_5762_4954_15;
	R4954[90] = (char *(*)()) F668_5762_4954_15;
	R4954[91] = (char *(*)()) F657_5762_4954_15;
	R4954[92] = (char *(*)()) F658_5762_4954_15;
	R4954[93] = (char *(*)()) F663_5762_4954_15;
	R4954[98] = (char *(*)()) F672_5810_4954_15;
	R4954[99] = (char *(*)()) F673_5810_4954_15;
	{long i; for (i = 100; i < 104; i++) R4954[i] = (char *(*)()) F672_5810_4954_15;}
	R4954[108] = (char *(*)()) F672_5810_4954_15;
	R4954[110] = (char *(*)()) F672_5810_4954_15;
	R4954[112] = (char *(*)()) F672_5810_4954_15;
	R4954[116] = (char *(*)()) F672_5810_4954_15;
	{long i; for (i = 118; i < 122; i++) R4954[i] = (char *(*)()) F672_5810_4954_15;}
	R4954[473] = (char *(*)()) F1051_9221_4954_15;
	R4954[476] = (char *(*)()) F1054_9386_4954_15;
}
static void F578_5373_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F578_5373(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F579_5373_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F579_5373(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F580_5373_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F580_5373(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F581_5373_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F581_5373(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F582_5373_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F582_5373(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F583_5373_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F583_5373(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F584_5373_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F584_5373(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F585_5373_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F585_5373(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F586_5373_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F586_5373(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F587_5373_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F587_5373(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F588_5373_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F588_5373(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F589_5373_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F589_5373(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F649_5639_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F649_5639(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F650_5639_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F650_5639(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F651_5639_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F651_5639(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F652_5639_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F652_5639(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_NATURAL_32 *)arg2);
}
static void F653_5639_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F653_5639(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F657_5762_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F657_5762(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F658_5762_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F658_5762(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F659_5762_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F659_5762(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F660_5762_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F660_5762(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F661_5762_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F661_5762(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F662_5762_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F662_5762(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F663_5762_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F663_5762(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F664_5762_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F664_5762(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F665_5762_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F665_5762(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F666_5762_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F666_5762(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F667_5762_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F667_5762(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F668_5762_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F668_5762(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F672_5810_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F672_5810(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F673_5810_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F673_5810(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1051_9221_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1051_9221(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1054_9386_4954_15 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1054_9386(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

static EIF_TYPE_INDEX Y4955_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype30[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype31[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype32[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype33[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype34[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype35[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype36[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype37[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype38[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype39[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype40[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype41[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype42[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype43[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype44[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype45[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype46[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype47[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype48[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype49[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype50[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype51[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype52[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype53[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype54[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype55[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype56[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype57[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype58[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype59[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype60[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype61[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype62[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype63[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype64[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype65[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype66[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype67[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype68[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype69[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype70[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype71[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype72[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype73[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype74[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype75[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype76[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype77[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype78[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype79[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype80[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype81[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype82[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype83[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype84[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype85[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype86[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype87[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype88[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype89[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype90[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype91[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype92[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype93[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype94[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype95[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype96[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype97[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype98[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype99[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype100[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype101[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype102[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype103[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype104[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype105[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype106[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype107[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype108[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype109[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype110[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype111[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype112[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype113[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype114[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype115[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype116[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype117[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype118[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype119[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype120[] = {0xFF01,1045,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype121[] = {0xFF01,1045,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype122[] = {0xFF01,1053,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype123[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype124[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype125[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype126[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype127[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype128[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype129[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype130[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype131[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype132[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype133[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype134[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype135[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype136[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype137[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype138[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype139[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype140[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype141[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype142[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype143[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype144[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype145[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype146[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype147[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype148[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype149[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype150[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype151[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype152[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype153[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype154[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype155[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype156[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype157[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype158[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype159[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype160[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype161[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype162[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype163[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype164[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype165[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype166[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype167[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype168[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype169[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype170[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype171[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype172[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype173[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype174[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype175[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype176[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype177[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype178[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype179[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype180[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype181[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype182[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype183[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype184[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype185[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype186[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype187[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype188[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype189[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4955_pgtype190[] = {984,0xFFFF};
EIF_TYPE_INDEX *Y4955_gen_type [775];
EIF_TYPE_INDEX Y4955 [775];
void Y4955_init (void)
{
	egc_routines_types [4955] = Y4955;
	egc_routines_gen_types [4955] = Y4955_gen_type;
	egc_routines_offset [4955] = 411;
	Y4955_gen_type [0] = Y4955_pgtype0;
	Y4955_gen_type [1] = Y4955_pgtype1;
	Y4955_gen_type [2] = Y4955_pgtype2;
	Y4955_gen_type [3] = Y4955_pgtype3;
	Y4955_gen_type [4] = Y4955_pgtype4;
	Y4955_gen_type [5] = Y4955_pgtype5;
	Y4955_gen_type [6] = Y4955_pgtype6;
	Y4955_gen_type [7] = Y4955_pgtype7;
	Y4955_gen_type [8] = Y4955_pgtype8;
	Y4955_gen_type [9] = Y4955_pgtype9;
	Y4955_gen_type [10] = Y4955_pgtype10;
	Y4955_gen_type [11] = Y4955_pgtype11;
	Y4955_gen_type [12] = Y4955_pgtype12;
	Y4955_gen_type [13] = Y4955_pgtype13;
	Y4955_gen_type [14] = Y4955_pgtype14;
	Y4955_gen_type [15] = Y4955_pgtype15;
	Y4955_gen_type [16] = Y4955_pgtype16;
	Y4955_gen_type [17] = Y4955_pgtype17;
	Y4955_gen_type [18] = Y4955_pgtype18;
	Y4955_gen_type [19] = Y4955_pgtype19;
	Y4955_gen_type [20] = Y4955_pgtype20;
	Y4955_gen_type [21] = Y4955_pgtype21;
	Y4955_gen_type [22] = Y4955_pgtype22;
	Y4955_gen_type [23] = Y4955_pgtype23;
	Y4955_gen_type [24] = Y4955_pgtype24;
	Y4955_gen_type [25] = Y4955_pgtype25;
	Y4955_gen_type [26] = Y4955_pgtype26;
	Y4955_gen_type [27] = Y4955_pgtype27;
	Y4955_gen_type [28] = Y4955_pgtype28;
	Y4955_gen_type [29] = Y4955_pgtype29;
	Y4955_gen_type [30] = Y4955_pgtype30;
	Y4955_gen_type [31] = Y4955_pgtype31;
	Y4955_gen_type [152] = Y4955_pgtype32;
	Y4955_gen_type [153] = Y4955_pgtype33;
	Y4955_gen_type [154] = Y4955_pgtype34;
	Y4955_gen_type [155] = Y4955_pgtype35;
	Y4955_gen_type [156] = Y4955_pgtype36;
	Y4955_gen_type [157] = Y4955_pgtype37;
	Y4955_gen_type [158] = Y4955_pgtype38;
	Y4955_gen_type [159] = Y4955_pgtype39;
	Y4955_gen_type [160] = Y4955_pgtype40;
	Y4955_gen_type [161] = Y4955_pgtype41;
	Y4955_gen_type [162] = Y4955_pgtype42;
	Y4955_gen_type [163] = Y4955_pgtype43;
	Y4955_gen_type [164] = Y4955_pgtype44;
	Y4955_gen_type [165] = Y4955_pgtype45;
	Y4955_gen_type [166] = Y4955_pgtype46;
	Y4955_gen_type [167] = Y4955_pgtype47;
	Y4955_gen_type [168] = Y4955_pgtype48;
	Y4955_gen_type [169] = Y4955_pgtype49;
	Y4955_gen_type [170] = Y4955_pgtype50;
	Y4955_gen_type [171] = Y4955_pgtype51;
	Y4955_gen_type [172] = Y4955_pgtype52;
	Y4955_gen_type [173] = Y4955_pgtype53;
	Y4955_gen_type [174] = Y4955_pgtype54;
	Y4955_gen_type [175] = Y4955_pgtype55;
	Y4955_gen_type [176] = Y4955_pgtype56;
	Y4955_gen_type [177] = Y4955_pgtype57;
	Y4955_gen_type [178] = Y4955_pgtype58;
	Y4955_gen_type [179] = Y4955_pgtype59;
	Y4955_gen_type [180] = Y4955_pgtype60;
	Y4955_gen_type [181] = Y4955_pgtype61;
	Y4955_gen_type [182] = Y4955_pgtype62;
	Y4955_gen_type [183] = Y4955_pgtype63;
	Y4955_gen_type [184] = Y4955_pgtype64;
	Y4955_gen_type [185] = Y4955_pgtype65;
	Y4955_gen_type [186] = Y4955_pgtype66;
	Y4955_gen_type [187] = Y4955_pgtype67;
	Y4955_gen_type [188] = Y4955_pgtype68;
	Y4955_gen_type [189] = Y4955_pgtype69;
	Y4955_gen_type [190] = Y4955_pgtype70;
	Y4955_gen_type [191] = Y4955_pgtype71;
	Y4955_gen_type [192] = Y4955_pgtype72;
	Y4955_gen_type [193] = Y4955_pgtype73;
	Y4955_gen_type [194] = Y4955_pgtype74;
	Y4955_gen_type [195] = Y4955_pgtype75;
	Y4955_gen_type [196] = Y4955_pgtype76;
	Y4955_gen_type [197] = Y4955_pgtype77;
	Y4955_gen_type [198] = Y4955_pgtype78;
	Y4955_gen_type [199] = Y4955_pgtype79;
	Y4955_gen_type [200] = Y4955_pgtype80;
	Y4955_gen_type [201] = Y4955_pgtype81;
	Y4955_gen_type [202] = Y4955_pgtype82;
	Y4955_gen_type [203] = Y4955_pgtype83;
	Y4955_gen_type [204] = Y4955_pgtype84;
	Y4955_gen_type [205] = Y4955_pgtype85;
	Y4955_gen_type [206] = Y4955_pgtype86;
	Y4955_gen_type [207] = Y4955_pgtype87;
	Y4955_gen_type [208] = Y4955_pgtype88;
	Y4955_gen_type [209] = Y4955_pgtype89;
	Y4955_gen_type [210] = Y4955_pgtype90;
	Y4955_gen_type [211] = Y4955_pgtype91;
	Y4955_gen_type [212] = Y4955_pgtype92;
	Y4955_gen_type [213] = Y4955_pgtype93;
	Y4955_gen_type [214] = Y4955_pgtype94;
	Y4955_gen_type [215] = Y4955_pgtype95;
	Y4955_gen_type [216] = Y4955_pgtype96;
	Y4955_gen_type [217] = Y4955_pgtype97;
	Y4955_gen_type [218] = Y4955_pgtype98;
	Y4955_gen_type [219] = Y4955_pgtype99;
	Y4955_gen_type [220] = Y4955_pgtype100;
	Y4955_gen_type [221] = Y4955_pgtype101;
	Y4955_gen_type [222] = Y4955_pgtype102;
	Y4955_gen_type [223] = Y4955_pgtype103;
	Y4955_gen_type [224] = Y4955_pgtype104;
	Y4955_gen_type [225] = Y4955_pgtype105;
	Y4955_gen_type [226] = Y4955_pgtype106;
	Y4955_gen_type [227] = Y4955_pgtype107;
	Y4955_gen_type [228] = Y4955_pgtype108;
	Y4955_gen_type [229] = Y4955_pgtype109;
	Y4955_gen_type [230] = Y4955_pgtype110;
	Y4955_gen_type [231] = Y4955_pgtype111;
	Y4955_gen_type [232] = Y4955_pgtype112;
	Y4955_gen_type [233] = Y4955_pgtype113;
	Y4955_gen_type [236] = Y4955_pgtype114;
	Y4955_gen_type [237] = Y4955_pgtype115;
	Y4955_gen_type [238] = Y4955_pgtype116;
	Y4955_gen_type [239] = Y4955_pgtype117;
	Y4955_gen_type [240] = Y4955_pgtype118;
	Y4955_gen_type [241] = Y4955_pgtype119;
	Y4955_gen_type [242] = Y4955_pgtype120;
	Y4955_gen_type [243] = Y4955_pgtype121;
	Y4955_gen_type [244] = Y4955_pgtype122;
	Y4955_gen_type [245] = Y4955_pgtype123;
	Y4955_gen_type [246] = Y4955_pgtype124;
	Y4955_gen_type [247] = Y4955_pgtype125;
	Y4955_gen_type [248] = Y4955_pgtype126;
	Y4955_gen_type [249] = Y4955_pgtype127;
	Y4955_gen_type [250] = Y4955_pgtype128;
	Y4955_gen_type [251] = Y4955_pgtype129;
	Y4955_gen_type [252] = Y4955_pgtype130;
	Y4955_gen_type [253] = Y4955_pgtype131;
	Y4955_gen_type [254] = Y4955_pgtype132;
	Y4955_gen_type [255] = Y4955_pgtype133;
	Y4955_gen_type [256] = Y4955_pgtype134;
	Y4955_gen_type [257] = Y4955_pgtype135;
	Y4955_gen_type [258] = Y4955_pgtype136;
	Y4955_gen_type [259] = Y4955_pgtype137;
	Y4955_gen_type [260] = Y4955_pgtype138;
	Y4955_gen_type [261] = Y4955_pgtype139;
	Y4955_gen_type [262] = Y4955_pgtype140;
	Y4955_gen_type [263] = Y4955_pgtype141;
	Y4955_gen_type [264] = Y4955_pgtype142;
	Y4955_gen_type [265] = Y4955_pgtype143;
	Y4955_gen_type [266] = Y4955_pgtype144;
	Y4955_gen_type [267] = Y4955_pgtype145;
	Y4955_gen_type [268] = Y4955_pgtype146;
	Y4955_gen_type [269] = Y4955_pgtype147;
	Y4955_gen_type [270] = Y4955_pgtype148;
	Y4955_gen_type [271] = Y4955_pgtype149;
	Y4955_gen_type [272] = Y4955_pgtype150;
	Y4955_gen_type [273] = Y4955_pgtype151;
	Y4955_gen_type [274] = Y4955_pgtype152;
	Y4955_gen_type [275] = Y4955_pgtype153;
	Y4955_gen_type [276] = Y4955_pgtype154;
	Y4955_gen_type [277] = Y4955_pgtype155;
	Y4955_gen_type [278] = Y4955_pgtype156;
	Y4955_gen_type [279] = Y4955_pgtype157;
	Y4955_gen_type [280] = Y4955_pgtype158;
	Y4955_gen_type [281] = Y4955_pgtype159;
	Y4955_gen_type [282] = Y4955_pgtype160;
	Y4955_gen_type [283] = Y4955_pgtype161;
	Y4955_gen_type [284] = Y4955_pgtype162;
	Y4955_gen_type [285] = Y4955_pgtype163;
	Y4955_gen_type [286] = Y4955_pgtype164;
	Y4955_gen_type [287] = Y4955_pgtype165;
	Y4955_gen_type [639] = Y4955_pgtype166;
	Y4955_gen_type [642] = Y4955_pgtype167;
	Y4955_gen_type [643] = Y4955_pgtype168;
	Y4955_gen_type [713] = Y4955_pgtype169;
	Y4955_gen_type [717] = Y4955_pgtype170;
	Y4955_gen_type [718] = Y4955_pgtype171;
	Y4955_gen_type [719] = Y4955_pgtype172;
	Y4955_gen_type [720] = Y4955_pgtype173;
	Y4955_gen_type [721] = Y4955_pgtype174;
	Y4955_gen_type [722] = Y4955_pgtype175;
	Y4955_gen_type [723] = Y4955_pgtype176;
	Y4955_gen_type [753] = Y4955_pgtype177;
	Y4955_gen_type [762] = Y4955_pgtype178;
	Y4955_gen_type [763] = Y4955_pgtype179;
	Y4955_gen_type [764] = Y4955_pgtype180;
	Y4955_gen_type [765] = Y4955_pgtype181;
	Y4955_gen_type [766] = Y4955_pgtype182;
	Y4955_gen_type [767] = Y4955_pgtype183;
	Y4955_gen_type [768] = Y4955_pgtype184;
	Y4955_gen_type [769] = Y4955_pgtype185;
	Y4955_gen_type [770] = Y4955_pgtype186;
	Y4955_gen_type [771] = Y4955_pgtype187;
	Y4955_gen_type [772] = Y4955_pgtype188;
	Y4955_gen_type [773] = Y4955_pgtype189;
	Y4955_gen_type [774] = Y4955_pgtype190;
	{long i; for (i = 152; i < 234; i++) Y4955[i] = 984;};
	{long i; for (i = 242; i < 244; i++) Y4955[i] = 1045;};
	Y4955[244] = 1053;
	{long i; for (i = 245; i < 288; i++) Y4955[i] = 984;};
	Y4955[639] = 984;
	{long i; for (i = 642; i < 644; i++) Y4955[i] = 984;};
	Y4955[713] = 984;
	{long i; for (i = 717; i < 724; i++) Y4955[i] = 984;};
	Y4955[753] = 984;
	{long i; for (i = 762; i < 775; i++) Y4955[i] = 984;};
}

char *(*R4956[407])();
void R4956_init () {
	R4956[0] = (char *(*)()) F648_5644;
	R4956[1] = (char *(*)()) F649_5644;
	R4956[2] = (char *(*)()) F650_5644_4956_4;
	R4956[3] = (char *(*)()) F651_5644_4956_4;
	R4956[4] = (char *(*)()) F652_5644_4956_4;
	R4956[5] = (char *(*)()) F653_5644;
	R4956[6] = (char *(*)()) F648_5644;
	R4956[7] = (char *(*)()) F649_5644;
	R4956[8] = (char *(*)()) F648_5644;
	R4956[403] = (char *(*)()) F1051_9255_4956_4;
	R4956[406] = (char *(*)()) F1054_9420_4956_4;
}
static void F650_5644_4956_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F650_5644(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F651_5644_4956_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F651_5644(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F652_5644_4956_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F652_5644(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F1051_9255_4956_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1051_9255(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1054_9420_4956_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1054_9420(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4957[735])();
void R4957_init () {
	R4957[0] = (char *(*)()) F639_5481;
	R4957[1] = (char *(*)()) F640_5481_4957_1;
	R4957[2] = (char *(*)()) F641_5481_4957_1;
	R4957[3] = (char *(*)()) F642_5527;
	R4957[4] = (char *(*)()) F643_5545;
	R4957[5] = (char *(*)()) F644_5545_4957_1;
	R4957[6] = (char *(*)()) F645_5545_4957_1;
	R4957[18] = (char *(*)()) F657_5728;
	R4957[19] = (char *(*)()) F658_5728_4957_1;
	R4957[20] = (char *(*)()) F659_5728_4957_1;
	R4957[21] = (char *(*)()) F660_5728_4957_1;
	R4957[22] = (char *(*)()) F661_5728_4957_1;
	R4957[23] = (char *(*)()) F662_5728_4957_1;
	R4957[24] = (char *(*)()) F663_5728_4957_1;
	R4957[25] = (char *(*)()) F664_5728_4957_1;
	R4957[26] = (char *(*)()) F665_5728_4957_1;
	R4957[27] = (char *(*)()) F666_5728_4957_1;
	R4957[28] = (char *(*)()) F667_5728_4957_1;
	R4957[29] = (char *(*)()) F668_5728_4957_1;
	R4957[30] = (char *(*)()) F657_5728;
	R4957[31] = (char *(*)()) F658_5728_4957_1;
	R4957[32] = (char *(*)()) F663_5728_4957_1;
	R4957[37] = (char *(*)()) F657_5728;
	R4957[38] = (char *(*)()) F658_5728_4957_1;
	{long i; for (i = 39; i < 43; i++) R4957[i] = (char *(*)()) F657_5728;}
	R4957[47] = (char *(*)()) F657_5728;
	R4957[49] = (char *(*)()) F657_5728;
	R4957[51] = (char *(*)()) F657_5728;
	R4957[55] = (char *(*)()) F657_5728;
	{long i; for (i = 57; i < 61; i++) R4957[i] = (char *(*)()) F657_5728;}
	R4957[83] = (char *(*)()) F482_5215_4957_1;
	R4957[88] = (char *(*)()) F482_5215_4957_1;
	{long i; for (i = 281; i < 283; i++) R4957[i] = (char *(*)()) F919_7098_4957_1;}
	{long i; for (i = 494; i < 497; i++) R4957[i] = (char *(*)()) F1125_10138;}
	R4957[537] = (char *(*)()) F1125_10138;
	R4957[547] = (char *(*)()) F1125_10138;
	R4957[734] = (char *(*)()) F919_7098_4957_1;
}
static EIF_REFERENCE F640_5481_4957_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F640_5481(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F641_5481_4957_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F641_5481(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F644_5545_4957_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F644_5545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F645_5545_4957_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F645_5545(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F658_5728_4957_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F658_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F659_5728_4957_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F659_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(999, 0x00).id, 999, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F660_5728_4957_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F660_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(993, 0x00).id, 993, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F661_5728_4957_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F661_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F662_5728_4957_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F662_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F663_5728_4957_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F663_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_5728_4957_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F664_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F665_5728_4957_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F665_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_5728_4957_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F666_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_5728_4957_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F667_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_5728_4957_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F668_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F482_5215_4957_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F482_5215(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F919_7098_4957_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F919_7098(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y4957_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype123[] = {0xFF01,1094,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype124[] = {0xFF01,1040,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype125[] = {0xFF01,1040,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype126[] = {0xFF01,1040,0xFFF9,1,966,0xFF01,0,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype127[] = {0xFF01,1040,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype128[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,984,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype129[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,984,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype130[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1164,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype131[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1169,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype132[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype133[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1101,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype134[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,927,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype135[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1371,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype136[] = {0xFF01,1040,0xFF01,0xFFF9,5,966,996,984,984,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype137[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1050,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype138[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,984,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype139[] = {0xFF01,1040,0xFF01,0xFFF9,4,966,984,984,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype140[] = {0xFF01,1040,0xFF01,0xFFF9,2,966,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype141[] = {0xFF01,1040,0xFF01,0xFFF9,7,966,984,984,969,969,969,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype142[] = {0xFF01,1040,0xFF01,0xFFF9,3,966,984,984,927,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype143[] = {0xFF01,1040,0xFF01,0xFFF9,8,966,984,984,984,969,969,969,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype144[] = {0xFF01,1040,0xFF01,0xFFF9,0,966,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype145[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype146[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype147[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype148[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype149[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype150[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype151[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype152[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype153[] = {0xFF01,1050,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype154[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype155[] = {0xFF01,1164,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype156[] = {0xFF01,1165,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype157[] = {0xFF01,1163,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype158[] = {0xFF01,1163,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype159[] = {0xFF01,1163,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype160[] = {0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype161[] = {0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype162[] = {0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype163[] = {0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype164[] = {0xFF01,1169,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype165[] = {0xFF01,1169,0xFFFF};
static EIF_TYPE_INDEX Y4957_pgtype166[] = {0xFF01,1169,0xFFFF};
EIF_TYPE_INDEX *Y4957_gen_type [930];
EIF_TYPE_INDEX Y4957 [930];
void Y4957_init (void)
{
	egc_routines_types [4957] = Y4957;
	egc_routines_gen_types [4957] = Y4957_gen_type;
	egc_routines_offset [4957] = 443;
	Y4957_gen_type [0] = Y4957_pgtype0;
	Y4957_gen_type [1] = Y4957_pgtype1;
	Y4957_gen_type [2] = Y4957_pgtype2;
	Y4957_gen_type [3] = Y4957_pgtype3;
	Y4957_gen_type [4] = Y4957_pgtype4;
	Y4957_gen_type [5] = Y4957_pgtype5;
	Y4957_gen_type [6] = Y4957_pgtype6;
	Y4957_gen_type [7] = Y4957_pgtype7;
	Y4957_gen_type [8] = Y4957_pgtype8;
	Y4957_gen_type [9] = Y4957_pgtype9;
	Y4957_gen_type [10] = Y4957_pgtype10;
	Y4957_gen_type [11] = Y4957_pgtype11;
	Y4957_gen_type [12] = Y4957_pgtype12;
	Y4957_gen_type [13] = Y4957_pgtype13;
	Y4957_gen_type [14] = Y4957_pgtype14;
	Y4957_gen_type [15] = Y4957_pgtype15;
	Y4957_gen_type [16] = Y4957_pgtype16;
	Y4957_gen_type [17] = Y4957_pgtype17;
	Y4957_gen_type [18] = Y4957_pgtype18;
	Y4957_gen_type [19] = Y4957_pgtype19;
	Y4957_gen_type [20] = Y4957_pgtype20;
	Y4957_gen_type [21] = Y4957_pgtype21;
	Y4957_gen_type [22] = Y4957_pgtype22;
	Y4957_gen_type [23] = Y4957_pgtype23;
	Y4957_gen_type [38] = Y4957_pgtype24;
	Y4957_gen_type [75] = Y4957_pgtype25;
	Y4957_gen_type [76] = Y4957_pgtype26;
	Y4957_gen_type [77] = Y4957_pgtype27;
	Y4957_gen_type [78] = Y4957_pgtype28;
	Y4957_gen_type [79] = Y4957_pgtype29;
	Y4957_gen_type [80] = Y4957_pgtype30;
	Y4957_gen_type [81] = Y4957_pgtype31;
	Y4957_gen_type [82] = Y4957_pgtype32;
	Y4957_gen_type [83] = Y4957_pgtype33;
	Y4957_gen_type [84] = Y4957_pgtype34;
	Y4957_gen_type [85] = Y4957_pgtype35;
	Y4957_gen_type [86] = Y4957_pgtype36;
	Y4957_gen_type [87] = Y4957_pgtype37;
	Y4957_gen_type [88] = Y4957_pgtype38;
	Y4957_gen_type [89] = Y4957_pgtype39;
	Y4957_gen_type [90] = Y4957_pgtype40;
	Y4957_gen_type [91] = Y4957_pgtype41;
	Y4957_gen_type [92] = Y4957_pgtype42;
	Y4957_gen_type [93] = Y4957_pgtype43;
	Y4957_gen_type [94] = Y4957_pgtype44;
	Y4957_gen_type [95] = Y4957_pgtype45;
	Y4957_gen_type [147] = Y4957_pgtype46;
	Y4957_gen_type [148] = Y4957_pgtype47;
	Y4957_gen_type [149] = Y4957_pgtype48;
	Y4957_gen_type [150] = Y4957_pgtype49;
	Y4957_gen_type [151] = Y4957_pgtype50;
	Y4957_gen_type [152] = Y4957_pgtype51;
	Y4957_gen_type [153] = Y4957_pgtype52;
	Y4957_gen_type [154] = Y4957_pgtype53;
	Y4957_gen_type [155] = Y4957_pgtype54;
	Y4957_gen_type [156] = Y4957_pgtype55;
	Y4957_gen_type [157] = Y4957_pgtype56;
	Y4957_gen_type [158] = Y4957_pgtype57;
	Y4957_gen_type [159] = Y4957_pgtype58;
	Y4957_gen_type [160] = Y4957_pgtype59;
	Y4957_gen_type [161] = Y4957_pgtype60;
	Y4957_gen_type [162] = Y4957_pgtype61;
	Y4957_gen_type [163] = Y4957_pgtype62;
	Y4957_gen_type [164] = Y4957_pgtype63;
	Y4957_gen_type [165] = Y4957_pgtype64;
	Y4957_gen_type [166] = Y4957_pgtype65;
	Y4957_gen_type [167] = Y4957_pgtype66;
	Y4957_gen_type [168] = Y4957_pgtype67;
	Y4957_gen_type [169] = Y4957_pgtype68;
	Y4957_gen_type [170] = Y4957_pgtype69;
	Y4957_gen_type [171] = Y4957_pgtype70;
	Y4957_gen_type [172] = Y4957_pgtype71;
	Y4957_gen_type [173] = Y4957_pgtype72;
	Y4957_gen_type [174] = Y4957_pgtype73;
	Y4957_gen_type [175] = Y4957_pgtype74;
	Y4957_gen_type [176] = Y4957_pgtype75;
	Y4957_gen_type [177] = Y4957_pgtype76;
	Y4957_gen_type [178] = Y4957_pgtype77;
	Y4957_gen_type [179] = Y4957_pgtype78;
	Y4957_gen_type [180] = Y4957_pgtype79;
	Y4957_gen_type [181] = Y4957_pgtype80;
	Y4957_gen_type [182] = Y4957_pgtype81;
	Y4957_gen_type [183] = Y4957_pgtype82;
	Y4957_gen_type [184] = Y4957_pgtype83;
	Y4957_gen_type [185] = Y4957_pgtype84;
	Y4957_gen_type [186] = Y4957_pgtype85;
	Y4957_gen_type [187] = Y4957_pgtype86;
	Y4957_gen_type [188] = Y4957_pgtype87;
	Y4957_gen_type [189] = Y4957_pgtype88;
	Y4957_gen_type [190] = Y4957_pgtype89;
	Y4957_gen_type [191] = Y4957_pgtype90;
	Y4957_gen_type [192] = Y4957_pgtype91;
	Y4957_gen_type [193] = Y4957_pgtype92;
	Y4957_gen_type [194] = Y4957_pgtype93;
	Y4957_gen_type [195] = Y4957_pgtype94;
	Y4957_gen_type [196] = Y4957_pgtype95;
	Y4957_gen_type [197] = Y4957_pgtype96;
	Y4957_gen_type [198] = Y4957_pgtype97;
	Y4957_gen_type [199] = Y4957_pgtype98;
	Y4957_gen_type [200] = Y4957_pgtype99;
	Y4957_gen_type [201] = Y4957_pgtype100;
	Y4957_gen_type [203] = Y4957_pgtype101;
	Y4957_gen_type [213] = Y4957_pgtype102;
	Y4957_gen_type [214] = Y4957_pgtype103;
	Y4957_gen_type [215] = Y4957_pgtype104;
	Y4957_gen_type [216] = Y4957_pgtype105;
	Y4957_gen_type [217] = Y4957_pgtype106;
	Y4957_gen_type [218] = Y4957_pgtype107;
	Y4957_gen_type [219] = Y4957_pgtype108;
	Y4957_gen_type [220] = Y4957_pgtype109;
	Y4957_gen_type [221] = Y4957_pgtype110;
	Y4957_gen_type [222] = Y4957_pgtype111;
	Y4957_gen_type [223] = Y4957_pgtype112;
	Y4957_gen_type [224] = Y4957_pgtype113;
	Y4957_gen_type [225] = Y4957_pgtype114;
	Y4957_gen_type [226] = Y4957_pgtype115;
	Y4957_gen_type [227] = Y4957_pgtype116;
	Y4957_gen_type [228] = Y4957_pgtype117;
	Y4957_gen_type [229] = Y4957_pgtype118;
	Y4957_gen_type [230] = Y4957_pgtype119;
	Y4957_gen_type [231] = Y4957_pgtype120;
	Y4957_gen_type [232] = Y4957_pgtype121;
	Y4957_gen_type [233] = Y4957_pgtype122;
	Y4957_gen_type [234] = Y4957_pgtype123;
	Y4957_gen_type [235] = Y4957_pgtype124;
	Y4957_gen_type [236] = Y4957_pgtype125;
	Y4957_gen_type [237] = Y4957_pgtype126;
	Y4957_gen_type [238] = Y4957_pgtype127;
	Y4957_gen_type [239] = Y4957_pgtype128;
	Y4957_gen_type [240] = Y4957_pgtype129;
	Y4957_gen_type [241] = Y4957_pgtype130;
	Y4957_gen_type [242] = Y4957_pgtype131;
	Y4957_gen_type [243] = Y4957_pgtype132;
	Y4957_gen_type [244] = Y4957_pgtype133;
	Y4957_gen_type [245] = Y4957_pgtype134;
	Y4957_gen_type [246] = Y4957_pgtype135;
	Y4957_gen_type [247] = Y4957_pgtype136;
	Y4957_gen_type [248] = Y4957_pgtype137;
	Y4957_gen_type [249] = Y4957_pgtype138;
	Y4957_gen_type [250] = Y4957_pgtype139;
	Y4957_gen_type [251] = Y4957_pgtype140;
	Y4957_gen_type [252] = Y4957_pgtype141;
	Y4957_gen_type [253] = Y4957_pgtype142;
	Y4957_gen_type [254] = Y4957_pgtype143;
	Y4957_gen_type [255] = Y4957_pgtype144;
	Y4957_gen_type [681] = Y4957_pgtype145;
	Y4957_gen_type [685] = Y4957_pgtype146;
	Y4957_gen_type [686] = Y4957_pgtype147;
	Y4957_gen_type [687] = Y4957_pgtype148;
	Y4957_gen_type [688] = Y4957_pgtype149;
	Y4957_gen_type [689] = Y4957_pgtype150;
	Y4957_gen_type [690] = Y4957_pgtype151;
	Y4957_gen_type [691] = Y4957_pgtype152;
	Y4957_gen_type [721] = Y4957_pgtype153;
	Y4957_gen_type [730] = Y4957_pgtype154;
	Y4957_gen_type [731] = Y4957_pgtype155;
	Y4957_gen_type [732] = Y4957_pgtype156;
	Y4957_gen_type [733] = Y4957_pgtype157;
	Y4957_gen_type [734] = Y4957_pgtype158;
	Y4957_gen_type [735] = Y4957_pgtype159;
	Y4957_gen_type [736] = Y4957_pgtype160;
	Y4957_gen_type [737] = Y4957_pgtype161;
	Y4957_gen_type [738] = Y4957_pgtype162;
	Y4957_gen_type [739] = Y4957_pgtype163;
	Y4957_gen_type [740] = Y4957_pgtype164;
	Y4957_gen_type [741] = Y4957_pgtype165;
	Y4957_gen_type [742] = Y4957_pgtype166;
	Y4957[234] = 1094;
	{long i; for (i = 235; i < 256; i++) Y4957[i] = 1040;};
	Y4957[278] = 984;
	Y4957[283] = 984;
	{long i; for (i = 475; i < 478; i++) Y4957[i] = 975;};
	{long i; for (i = 685; i < 692; i++) Y4957[i] = 1126;};
	Y4957[721] = 1050;
	Y4957[731] = 1164;
	Y4957[732] = 1165;
	{long i; for (i = 733; i < 736; i++) Y4957[i] = 1163;};
	{long i; for (i = 736; i < 740; i++) Y4957[i] = 1181;};
	{long i; for (i = 740; i < 743; i++) Y4957[i] = 1169;};
	Y4957[929] = 975;
}

char *(*R4961[548])();
void R4961_init () {
	R4961[0] = (char *(*)()) F639_5509;
	R4961[1] = (char *(*)()) F640_5509_4961_4;
	R4961[2] = (char *(*)()) F641_5509_4961_4;
	{long i; for (i = 3; i < 5; i++) R4961[i] = (char *(*)()) F639_5509;}
	R4961[5] = (char *(*)()) F641_5509_4961_4;
	R4961[6] = (char *(*)()) F640_5509_4961_4;
	R4961[18] = (char *(*)()) F657_5767;
	R4961[19] = (char *(*)()) F658_5767_4961_4;
	R4961[20] = (char *(*)()) F659_5767_4961_4;
	R4961[21] = (char *(*)()) F660_5767_4961_4;
	R4961[22] = (char *(*)()) F661_5767_4961_4;
	R4961[23] = (char *(*)()) F662_5767_4961_4;
	R4961[24] = (char *(*)()) F663_5767_4961_4;
	R4961[25] = (char *(*)()) F664_5767_4961_4;
	R4961[26] = (char *(*)()) F665_5767_4961_4;
	R4961[27] = (char *(*)()) F666_5767_4961_4;
	R4961[28] = (char *(*)()) F667_5767_4961_4;
	R4961[29] = (char *(*)()) F668_5767_4961_4;
	R4961[30] = (char *(*)()) F657_5767;
	R4961[31] = (char *(*)()) F658_5767_4961_4;
	R4961[32] = (char *(*)()) F663_5767_4961_4;
	R4961[37] = (char *(*)()) F672_5811;
	R4961[38] = (char *(*)()) F673_5811_4961_4;
	{long i; for (i = 39; i < 43; i++) R4961[i] = (char *(*)()) F672_5811;}
	R4961[47] = (char *(*)()) F672_5811;
	R4961[49] = (char *(*)()) F672_5811;
	R4961[51] = (char *(*)()) F672_5811;
	R4961[55] = (char *(*)()) F672_5811;
	{long i; for (i = 57; i < 61; i++) R4961[i] = (char *(*)()) F672_5811;}
	{long i; for (i = 494; i < 497; i++) R4961[i] = (char *(*)()) F1125_10175;}
	R4961[537] = (char *(*)()) F1125_10175;
	R4961[547] = (char *(*)()) F1125_10175;
}
static void F640_5509_4961_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F640_5509(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F641_5509_4961_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F641_5509(Current, *(EIF_BOOLEAN *)arg1);
}
static void F658_5767_4961_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F658_5767(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F659_5767_4961_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F659_5767(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F660_5767_4961_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F660_5767(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F661_5767_4961_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F661_5767(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F662_5767_4961_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F662_5767(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F663_5767_4961_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F663_5767(Current, *(EIF_BOOLEAN *)arg1);
}
static void F664_5767_4961_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F664_5767(Current, *(EIF_POINTER *)arg1);
}
static void F665_5767_4961_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F665_5767(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F666_5767_4961_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F666_5767(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F667_5767_4961_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F667_5767(Current, *(EIF_REAL_32 *)arg1);
}
static void F668_5767_4961_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F668_5767(Current, *(EIF_REAL_64 *)arg1);
}
static void F673_5811_4961_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F673_5811(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4962[548])();
void R4962_init () {
	R4962[0] = (char *(*)()) F639_5512;
	R4962[1] = (char *(*)()) F640_5512;
	R4962[2] = (char *(*)()) F641_5512;
	R4962[3] = (char *(*)()) F639_5513;
	R4962[4] = (char *(*)()) F643_5549;
	R4962[5] = (char *(*)()) F644_5549;
	R4962[6] = (char *(*)()) F645_5549;
	R4962[18] = (char *(*)()) F657_5777;
	R4962[19] = (char *(*)()) F658_5777;
	R4962[20] = (char *(*)()) F659_5777;
	R4962[21] = (char *(*)()) F660_5777;
	R4962[22] = (char *(*)()) F661_5777;
	R4962[23] = (char *(*)()) F662_5777;
	R4962[24] = (char *(*)()) F663_5777;
	R4962[25] = (char *(*)()) F664_5777;
	R4962[26] = (char *(*)()) F665_5777;
	R4962[27] = (char *(*)()) F666_5777;
	R4962[28] = (char *(*)()) F667_5777;
	R4962[29] = (char *(*)()) F668_5777;
	R4962[30] = (char *(*)()) F669_5793;
	R4962[31] = (char *(*)()) F670_5793;
	R4962[32] = (char *(*)()) F671_5793;
	R4962[37] = (char *(*)()) F672_5812;
	R4962[38] = (char *(*)()) F673_5812;
	{long i; for (i = 39; i < 43; i++) R4962[i] = (char *(*)()) F672_5812;}
	R4962[47] = (char *(*)()) F672_5812;
	R4962[49] = (char *(*)()) F672_5812;
	R4962[51] = (char *(*)()) F672_5812;
	R4962[55] = (char *(*)()) F672_5812;
	{long i; for (i = 57; i < 61; i++) R4962[i] = (char *(*)()) F672_5812;}
	{long i; for (i = 494; i < 497; i++) R4962[i] = (char *(*)()) F1125_10166;}
	R4962[537] = (char *(*)()) F1125_10166;
	R4962[547] = (char *(*)()) F1125_10166;
}


#ifdef __cplusplus
}
#endif
