#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O4814[1038];
void O4814_init () {
	{long i; for (i = 0; i < 12; i++) O4814[i] = + _CHROFF_0_0_;}
	O4814[12] = + _CHROFF_1_0_;
	{long i; for (i = 13; i < 15; i++) O4814[i] = + _CHROFF_4_0_;}
	{long i; for (i = 15; i < 199; i++) O4814[i] = + _CHROFF_0_0_;}
	O4814[199] = + _CHROFF_1_0_;
	{long i; for (i = 200; i < 216; i++) O4814[i] = + _CHROFF_0_0_;}
	{long i; for (i = 228; i < 241; i++) O4814[i] = + _CHROFF_0_0_;}
	{long i; for (i = 241; i < 254; i++) O4814[i] = + _CHROFF_1_0_;}
	O4814[254] = + _CHROFF_2_0_;
	{long i; for (i = 255; i < 303; i++) O4814[i] = + _CHROFF_0_0_;}
	{long i; for (i = 303; i < 310; i++) O4814[i] = + _CHROFF_2_0_;}
	O4814[311] = + _CHROFF_1_0_;
	O4814[312] = + _CHROFF_7_0_;
	O4814[313] = + _CHROFF_5_0_;
	O4814[314] = + _CHROFF_6_0_;
	{long i; for (i = 315; i < 317; i++) O4814[i] = + _CHROFF_4_0_;}
	O4814[317] = + _CHROFF_5_0_;
	O4814[318] = + _CHROFF_7_0_;
	O4814[319] = + _CHROFF_5_0_;
	O4814[320] = + _CHROFF_9_0_;
	{long i; for (i = 321; i < 338; i++) O4814[i] = + _CHROFF_1_0_;}
	{long i; for (i = 338; i < 340; i++) O4814[i] = + _CHROFF_3_0_;}
	{long i; for (i = 340; i < 343; i++) O4814[i] = + _CHROFF_5_0_;}
	{long i; for (i = 343; i < 345; i++) O4814[i] = + _CHROFF_9_0_;}
	O4814[345] = + _CHROFF_10_0_;
	{long i; for (i = 346; i < 364; i++) O4814[i] = + _CHROFF_9_0_;}
	O4814[386] = + _CHROFF_0_0_;
	O4814[389] = + _CHROFF_2_0_;
	O4814[391] = + _CHROFF_0_0_;
	O4814[583] = + _CHROFF_3_2_;
	O4814[584] = + _CHROFF_4_2_;
	O4814[585] = + _CHROFF_5_2_;
	O4814[715] = + _CHROFF_1_0_;
	{long i; for (i = 718; i < 720; i++) O4814[i] = + _CHROFF_1_0_;}
	O4814[789] = + _CHROFF_3_0_;
	{long i; for (i = 792; i < 799; i++) O4814[i] = + _CHROFF_6_0_;}
	O4814[799] = + _CHROFF_10_0_;
	{long i; for (i = 800; i < 807; i++) O4814[i] = + _CHROFF_6_0_;}
	{long i; for (i = 807; i < 809; i++) O4814[i] = + _CHROFF_12_0_;}
	O4814[809] = + _CHROFF_6_0_;
	O4814[810] = + _CHROFF_7_0_;
	{long i; for (i = 811; i < 813; i++) O4814[i] = + _CHROFF_14_0_;}
	O4814[829] = + _CHROFF_7_0_;
	O4814[838] = + _CHROFF_3_0_;
	{long i; for (i = 839; i < 844; i++) O4814[i] = + _CHROFF_5_0_;}
	O4814[844] = + _CHROFF_3_0_;
	O4814[845] = + _CHROFF_5_0_;
	{long i; for (i = 846; i < 848; i++) O4814[i] = + _CHROFF_6_0_;}
	{long i; for (i = 848; i < 850; i++) O4814[i] = + _CHROFF_3_0_;}
	O4814[850] = + _CHROFF_6_0_;
	O4814[1037] = + _CHROFF_5_2_;
}

static EIF_TYPE_INDEX Y4882_pgtype0[] = {348,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4882_pgtype1[] = {349,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y4882_gen_type [2];
EIF_TYPE_INDEX Y4882 [2];
void Y4882_init (void)
{
	egc_routines_types [4882] = Y4882;
	egc_routines_gen_types [4882] = Y4882_gen_type;
	egc_routines_offset [4882] = 348;
	Y4882_gen_type [0] = Y4882_pgtype0;
	Y4882_gen_type [1] = Y4882_pgtype1;
	Y4882[0] = 348;
	Y4882[1] = 349;
}

EIF_TYPE_INDEX *Y5129_gen_type [1];
EIF_TYPE_INDEX Y5129 [1];
void Y5129_init (void)
{
	egc_routines_types [5129] = Y5129;
	egc_routines_gen_types [5129] = Y5129_gen_type;
	egc_routines_offset [5129] = 646;
	Y5129[0] = 984;
}

long O5134[9];
void O5134_init () {
	O5134[0] = 0;
	O5134[1] = + _LNGOFF_5_3_0_0_;
	O5134[2] = 0;
	O5134[3] = + _LNGOFF_4_3_0_0_;
	O5134[4] = + _LNGOFF_4_3_0_1_;
	O5134[5] = + _PTROFF_5_3_0_7_0_0_;
	O5134[6] = 0;
	O5134[7] = + _LNGOFF_5_4_0_0_;
	O5134[8] = 0;
}

long O5143[9];
void O5143_init () {
	O5143[0] = + _LNGOFF_7_3_0_0_;
	O5143[1] = + _LNGOFF_5_3_0_1_;
	O5143[2] = + _LNGOFF_6_3_0_0_;
	O5143[3] = + _LNGOFF_4_3_0_1_;
	O5143[4] = + _LNGOFF_4_3_0_2_;
	O5143[5] = + _LNGOFF_5_3_0_0_;
	O5143[6] = + _LNGOFF_7_4_0_0_;
	O5143[7] = + _LNGOFF_5_4_0_1_;
	O5143[8] = + _LNGOFF_9_3_0_0_;
}

long O5170[9];
void O5170_init () {
	O5170[0] =  + _REFACS_1_;
	O5170[1] = 0;
	O5170[2] =  + _REFACS_1_;
	{long i; for (i = 3; i < 6; i++) O5170[i] = 0;}
	O5170[6] =  + _REFACS_1_;
	O5170[7] = 0;
	O5170[8] =  + _REFACS_1_;
}

static EIF_TYPE_INDEX Y5170_pgtype0[] = {0xFF01,834,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5170_pgtype1[] = {0xFF01,835,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5170_pgtype2[] = {0xFF01,834,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5170_pgtype3[] = {0xFF01,835,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5170_pgtype4[] = {0xFF01,835,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5170_pgtype5[] = {0xFF01,841,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5170_pgtype6[] = {0xFF01,834,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5170_pgtype7[] = {0xFF01,835,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5170_pgtype8[] = {0xFF01,834,0,0xFFFF};
EIF_TYPE_INDEX *Y5170_gen_type [9];
EIF_TYPE_INDEX Y5170 [9];
void Y5170_init (void)
{
	egc_routines_types [5170] = Y5170;
	egc_routines_gen_types [5170] = Y5170_gen_type;
	egc_routines_offset [5170] = 647;
	Y5170_gen_type [0] = Y5170_pgtype0;
	Y5170_gen_type [1] = Y5170_pgtype1;
	Y5170_gen_type [2] = Y5170_pgtype2;
	Y5170_gen_type [3] = Y5170_pgtype3;
	Y5170_gen_type [4] = Y5170_pgtype4;
	Y5170_gen_type [5] = Y5170_pgtype5;
	Y5170_gen_type [6] = Y5170_pgtype6;
	Y5170_gen_type [7] = Y5170_pgtype7;
	Y5170_gen_type [8] = Y5170_pgtype8;
	Y5170[0] = 834;
	Y5170[1] = 835;
	Y5170[2] = 834;
	{long i; for (i = 3; i < 5; i++) Y5170[i] = 835;};
	Y5170[5] = 841;
	Y5170[6] = 834;
	Y5170[7] = 835;
	Y5170[8] = 834;
}

long O5171[9];
void O5171_init () {
	O5171[0] =  + _REFACS_2_;
	O5171[1] =  + _REFACS_1_;
	O5171[2] =  + _REFACS_2_;
	{long i; for (i = 3; i < 6; i++) O5171[i] =  + _REFACS_1_;}
	O5171[6] =  + _REFACS_2_;
	O5171[7] =  + _REFACS_1_;
	O5171[8] =  + _REFACS_2_;
}

static EIF_TYPE_INDEX Y5171_pgtype0[] = {0xFF01,834,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5171_pgtype1[] = {0xFF01,834,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5171_pgtype2[] = {0xFF01,835,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5171_pgtype3[] = {0xFF01,835,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5171_pgtype4[] = {0xFF01,839,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5171_pgtype5[] = {0xFF01,834,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5171_pgtype6[] = {0xFF01,834,0xFF01,1045,0xFFFF};
static EIF_TYPE_INDEX Y5171_pgtype7[] = {0xFF01,834,0xFF01,1045,0xFFFF};
static EIF_TYPE_INDEX Y5171_pgtype8[] = {0xFF01,834,0xFF01,1053,0xFFFF};
EIF_TYPE_INDEX *Y5171_gen_type [9];
EIF_TYPE_INDEX Y5171 [9];
void Y5171_init (void)
{
	egc_routines_types [5171] = Y5171;
	egc_routines_gen_types [5171] = Y5171_gen_type;
	egc_routines_offset [5171] = 647;
	Y5171_gen_type [0] = Y5171_pgtype0;
	Y5171_gen_type [1] = Y5171_pgtype1;
	Y5171_gen_type [2] = Y5171_pgtype2;
	Y5171_gen_type [3] = Y5171_pgtype3;
	Y5171_gen_type [4] = Y5171_pgtype4;
	Y5171_gen_type [5] = Y5171_pgtype5;
	Y5171_gen_type [6] = Y5171_pgtype6;
	Y5171_gen_type [7] = Y5171_pgtype7;
	Y5171_gen_type [8] = Y5171_pgtype8;
	{long i; for (i = 0; i < 2; i++) Y5171[i] = 834;};
	{long i; for (i = 2; i < 4; i++) Y5171[i] = 835;};
	Y5171[4] = 839;
	{long i; for (i = 5; i < 9; i++) Y5171[i] = 834;};
}

long O5172[9];
void O5172_init () {
	O5172[0] =  + _REFACS_3_;
	O5172[1] =  + _REFACS_2_;
	O5172[2] =  + _REFACS_3_;
	{long i; for (i = 3; i < 6; i++) O5172[i] =  + _REFACS_2_;}
	O5172[6] =  + _REFACS_3_;
	O5172[7] =  + _REFACS_2_;
	O5172[8] =  + _REFACS_3_;
}

long O5173[9];
void O5173_init () {
	O5173[0] =  + _REFACS_4_;
	O5173[1] =  + _REFACS_3_;
	O5173[2] =  + _REFACS_4_;
	{long i; for (i = 3; i < 6; i++) O5173[i] =  + _REFACS_3_;}
	O5173[6] =  + _REFACS_4_;
	O5173[7] =  + _REFACS_3_;
	O5173[8] =  + _REFACS_4_;
}

long O5174[9];
void O5174_init () {
	O5174[0] = + _LNGOFF_7_3_0_1_;
	O5174[1] = + _LNGOFF_5_3_0_2_;
	O5174[2] = + _LNGOFF_6_3_0_1_;
	O5174[3] = + _LNGOFF_4_3_0_2_;
	O5174[4] = + _LNGOFF_4_3_0_3_;
	O5174[5] = + _LNGOFF_5_3_0_1_;
	O5174[6] = + _LNGOFF_7_4_0_1_;
	O5174[7] = + _LNGOFF_5_4_0_2_;
	O5174[8] = + _LNGOFF_9_3_0_1_;
}

long O5175[9];
void O5175_init () {
	O5175[0] = + _CHROFF_7_2_;
	O5175[1] = + _CHROFF_5_2_;
	O5175[2] = + _CHROFF_6_2_;
	{long i; for (i = 3; i < 5; i++) O5175[i] = + _CHROFF_4_2_;}
	O5175[5] = + _CHROFF_5_2_;
	O5175[6] = + _CHROFF_7_2_;
	O5175[7] = + _CHROFF_5_2_;
	O5175[8] = + _CHROFF_9_2_;
}

long O5176[9];
void O5176_init () {
	O5176[0] = + _LNGOFF_7_3_0_2_;
	O5176[1] = + _LNGOFF_5_3_0_3_;
	O5176[2] = + _LNGOFF_6_3_0_2_;
	O5176[3] = + _LNGOFF_4_3_0_3_;
	O5176[4] = + _LNGOFF_4_3_0_4_;
	O5176[5] = + _LNGOFF_5_3_0_2_;
	O5176[6] = + _LNGOFF_7_4_0_2_;
	O5176[7] = + _LNGOFF_5_4_0_3_;
	O5176[8] = + _LNGOFF_9_3_0_2_;
}

long O5179[9];
void O5179_init () {
	O5179[0] = + _LNGOFF_7_3_0_3_;
	O5179[1] = + _LNGOFF_5_3_0_4_;
	O5179[2] = + _LNGOFF_6_3_0_3_;
	O5179[3] = + _LNGOFF_4_3_0_4_;
	O5179[4] = + _LNGOFF_4_3_0_5_;
	O5179[5] = + _LNGOFF_5_3_0_3_;
	O5179[6] = + _LNGOFF_7_4_0_3_;
	O5179[7] = + _LNGOFF_5_4_0_4_;
	O5179[8] = + _LNGOFF_9_3_0_3_;
}

long O5180[9];
void O5180_init () {
	O5180[0] = + _LNGOFF_7_3_0_4_;
	O5180[1] = + _LNGOFF_5_3_0_5_;
	O5180[2] = + _LNGOFF_6_3_0_4_;
	O5180[3] = + _LNGOFF_4_3_0_5_;
	O5180[4] = + _LNGOFF_4_3_0_6_;
	O5180[5] = + _LNGOFF_5_3_0_4_;
	O5180[6] = + _LNGOFF_7_4_0_4_;
	O5180[7] = + _LNGOFF_5_4_0_5_;
	O5180[8] = + _LNGOFF_9_3_0_4_;
}

long O5184[9];
void O5184_init () {
	O5184[0] = + _LNGOFF_7_3_0_5_;
	O5184[1] = + _LNGOFF_5_3_0_6_;
	O5184[2] = + _LNGOFF_6_3_0_5_;
	O5184[3] = + _LNGOFF_4_3_0_6_;
	O5184[4] = + _LNGOFF_4_3_0_7_;
	O5184[5] = + _LNGOFF_5_3_0_5_;
	O5184[6] = + _LNGOFF_7_4_0_5_;
	O5184[7] = + _LNGOFF_5_4_0_6_;
	O5184[8] = + _LNGOFF_9_3_0_5_;
}

long O5185[9];
void O5185_init () {
	O5185[0] =  + _REFACS_5_;
	O5185[1] = + _LNGOFF_5_3_0_7_;
	O5185[2] =  + _REFACS_5_;
	O5185[3] = + _LNGOFF_4_3_0_7_;
	O5185[4] = + _LNGOFF_4_3_0_8_;
	O5185[5] = + _PTROFF_5_3_0_7_0_1_;
	O5185[6] =  + _REFACS_5_;
	O5185[7] = + _LNGOFF_5_4_0_7_;
	O5185[8] =  + _REFACS_5_;
}

long O5186[9];
void O5186_init () {
	O5186[0] =  + _REFACS_6_;
	O5186[1] =  + _REFACS_4_;
	O5186[2] = + _LNGOFF_6_3_0_6_;
	O5186[3] = + _LNGOFF_4_3_0_8_;
	O5186[4] = + _LNGOFF_4_3_0_0_;
	O5186[5] =  + _REFACS_4_;
	O5186[6] =  + _REFACS_6_;
	O5186[7] =  + _REFACS_4_;
	O5186[8] =  + _REFACS_6_;
}

long O5220[9];
void O5220_init () {
	O5220[0] = + _LNGOFF_7_3_0_6_;
	O5220[1] = + _LNGOFF_5_3_0_8_;
	O5220[2] = + _LNGOFF_6_3_0_7_;
	{long i; for (i = 3; i < 5; i++) O5220[i] = + _LNGOFF_4_3_0_9_;}
	O5220[5] = + _LNGOFF_5_3_0_6_;
	O5220[6] = + _LNGOFF_7_4_0_6_;
	O5220[7] = + _LNGOFF_5_4_0_8_;
	O5220[8] = + _LNGOFF_9_3_0_6_;
}

long O5223[2];
void O5223_init () {
	O5223[0] = + _CHROFF_7_3_;
	O5223[1] = + _CHROFF_5_3_;
}

long O5248[509];
void O5248_init () {
	{long i; for (i = 0; i < 15; i++) O5248[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 15; i < 17; i++) O5248[i] = + _LNGOFF_1_2_0_0_;}
	{long i; for (i = 17; i < 19; i++) O5248[i] = + _LNGOFF_3_2_0_0_;}
	{long i; for (i = 19; i < 22; i++) O5248[i] = + _LNGOFF_5_2_0_0_;}
	{long i; for (i = 22; i < 24; i++) O5248[i] = + _LNGOFF_9_2_0_0_;}
	O5248[24] = + _LNGOFF_10_2_0_0_;
	{long i; for (i = 25; i < 43; i++) O5248[i] = + _LNGOFF_9_2_0_0_;}
	O5248[508] = + _LNGOFF_7_2_0_0_;
}

long O5256[494];
void O5256_init () {
	{long i; for (i = 0; i < 2; i++) O5256[i] = + _CHROFF_1_1_;}
	{long i; for (i = 2; i < 4; i++) O5256[i] = + _CHROFF_3_1_;}
	{long i; for (i = 4; i < 7; i++) O5256[i] = + _CHROFF_5_1_;}
	{long i; for (i = 7; i < 9; i++) O5256[i] = + _CHROFF_9_1_;}
	O5256[9] = + _CHROFF_10_1_;
	{long i; for (i = 10; i < 28; i++) O5256[i] = + _CHROFF_9_1_;}
	O5256[493] = + _CHROFF_7_1_;
}

static EIF_TYPE_INDEX Y5259_pgtype0[] = {0xFF01,678,0xFF01,0xFFF9,1,966,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5259_pgtype1[] = {0xFF01,678,0xFF01,0xFFF9,1,966,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5259_pgtype2[] = {0xFF01,678,0xFF01,0xFFF9,1,966,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5259_pgtype3[] = {0xFF01,678,0xFF01,0xFFF9,1,966,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5259_pgtype4[] = {0xFF01,678,0xFF01,0xFFF9,1,966,0xFF01,1094,0xFFFF};
EIF_TYPE_INDEX *Y5259_gen_type [5];
EIF_TYPE_INDEX Y5259 [5];
void Y5259_init (void)
{
	egc_routines_types [5259] = Y5259;
	egc_routines_gen_types [5259] = Y5259_gen_type;
	egc_routines_offset [5259] = 673;
	Y5259_gen_type [0] = Y5259_pgtype0;
	Y5259_gen_type [1] = Y5259_pgtype1;
	Y5259_gen_type [2] = Y5259_pgtype2;
	Y5259_gen_type [3] = Y5259_pgtype3;
	Y5259_gen_type [4] = Y5259_pgtype4;
	{long i; for (i = 0; i < 5; i++) Y5259[i] = 678;};
}

static EIF_TYPE_INDEX Y5260_pgtype0[] = {0xFF01,678,0xFF01,0xFFF9,1,966,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5260_pgtype1[] = {0xFF01,678,0xFF01,0xFFF9,1,966,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5260_pgtype2[] = {0xFF01,678,0xFF01,0xFFF9,1,966,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5260_pgtype3[] = {0xFF01,678,0xFF01,0xFFF9,1,966,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5260_pgtype4[] = {0xFF01,678,0xFF01,0xFFF9,1,966,0xFF01,1094,0xFFFF};
EIF_TYPE_INDEX *Y5260_gen_type [5];
EIF_TYPE_INDEX Y5260 [5];
void Y5260_init (void)
{
	egc_routines_types [5260] = Y5260;
	egc_routines_gen_types [5260] = Y5260_gen_type;
	egc_routines_offset [5260] = 673;
	Y5260_gen_type [0] = Y5260_pgtype0;
	Y5260_gen_type [1] = Y5260_pgtype1;
	Y5260_gen_type [2] = Y5260_pgtype2;
	Y5260_gen_type [3] = Y5260_pgtype3;
	Y5260_gen_type [4] = Y5260_pgtype4;
	{long i; for (i = 0; i < 5; i++) Y5260[i] = 678;};
}

static EIF_TYPE_INDEX Y5261_pgtype0[] = {0xFF01,679,0xFF01,0xFFF9,1,966,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5261_pgtype1[] = {0xFF01,679,0xFF01,0xFFF9,1,966,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5261_pgtype2[] = {0xFF01,679,0xFF01,0xFFF9,1,966,0xFF01,1094,0xFFFF};
EIF_TYPE_INDEX *Y5261_gen_type [3];
EIF_TYPE_INDEX Y5261 [3];
void Y5261_init (void)
{
	egc_routines_types [5261] = Y5261;
	egc_routines_gen_types [5261] = Y5261_gen_type;
	egc_routines_offset [5261] = 675;
	Y5261_gen_type [0] = Y5261_pgtype0;
	Y5261_gen_type [1] = Y5261_pgtype1;
	Y5261_gen_type [2] = Y5261_pgtype2;
	{long i; for (i = 0; i < 3; i++) Y5261[i] = 679;};
}

static EIF_TYPE_INDEX Y5262_pgtype0[] = {0xFF01,679,0xFF01,0xFFF9,1,966,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5262_pgtype1[] = {0xFF01,679,0xFF01,0xFFF9,1,966,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5262_pgtype2[] = {0xFF01,679,0xFF01,0xFFF9,1,966,0xFF01,1094,0xFFFF};
EIF_TYPE_INDEX *Y5262_gen_type [3];
EIF_TYPE_INDEX Y5262 [3];
void Y5262_init (void)
{
	egc_routines_types [5262] = Y5262;
	egc_routines_gen_types [5262] = Y5262_gen_type;
	egc_routines_offset [5262] = 675;
	Y5262_gen_type [0] = Y5262_pgtype0;
	Y5262_gen_type [1] = Y5262_pgtype1;
	Y5262_gen_type [2] = Y5262_pgtype2;
	{long i; for (i = 0; i < 3; i++) Y5262[i] = 679;};
}

long O5275[21];
void O5275_init () {
	{long i; for (i = 0; i < 2; i++) O5275[i] = + _LNGOFF_9_2_0_1_;}
	O5275[2] = + _LNGOFF_10_2_0_1_;
	{long i; for (i = 3; i < 21; i++) O5275[i] = + _LNGOFF_9_2_0_1_;}
}

long O5417[510];
void O5417_init () {
	{long i; for (i = 0; i < 4; i++) O5417[i] = + _LNGOFF_0_0_0_0_;}
	O5417[4] = + _LNGOFF_13_16_0_4_;
	O5417[219] = + _LNGOFF_15_11_0_0_;
	O5417[221] = + _LNGOFF_1_0_0_0_;
	O5417[504] = + _LNGOFF_1_1_0_0_;
	O5417[509] = + _LNGOFF_49_16_0_2_;
}

long O5527[21];
void O5527_init () {
	{long i; for (i = 0; i < 12; i++) O5527[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 12; i < 15; i++) O5527[i] = + _LNGOFF_2_1_0_0_;}
	{long i; for (i = 15; i < 21; i++) O5527[i] = + _LNGOFF_1_1_0_0_;}
}

long O5531[21];
void O5531_init () {
	{long i; for (i = 0; i < 12; i++) O5531[i] = + _CHROFF_1_0_;}
	{long i; for (i = 12; i < 15; i++) O5531[i] = + _CHROFF_2_0_;}
	{long i; for (i = 15; i < 21; i++) O5531[i] = + _CHROFF_1_0_;}
}

long O5532[21];
void O5532_init () {
	{long i; for (i = 0; i < 12; i++) O5532[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 12; i < 15; i++) O5532[i] = + _LNGOFF_2_1_0_1_;}
	{long i; for (i = 15; i < 21; i++) O5532[i] = + _LNGOFF_1_1_0_1_;}
}

long O5533[21];
void O5533_init () {
	{long i; for (i = 0; i < 12; i++) O5533[i] = + _LNGOFF_1_1_0_2_;}
	{long i; for (i = 12; i < 15; i++) O5533[i] = + _LNGOFF_2_1_0_2_;}
	{long i; for (i = 15; i < 21; i++) O5533[i] = + _LNGOFF_1_1_0_2_;}
}

long O5534[21];
void O5534_init () {
	{long i; for (i = 0; i < 12; i++) O5534[i] = + _LNGOFF_1_1_0_3_;}
	{long i; for (i = 12; i < 15; i++) O5534[i] = + _LNGOFF_2_1_0_3_;}
	{long i; for (i = 15; i < 21; i++) O5534[i] = + _LNGOFF_1_1_0_3_;}
}

long O5535[21];
void O5535_init () {
	{long i; for (i = 0; i < 12; i++) O5535[i] = + _LNGOFF_1_1_0_4_;}
	{long i; for (i = 12; i < 15; i++) O5535[i] = + _LNGOFF_2_1_0_4_;}
	{long i; for (i = 15; i < 21; i++) O5535[i] = + _LNGOFF_1_1_0_4_;}
}

long O5538[50];
void O5538_init () {
	{long i; for (i = 0; i < 12; i++) O5538[i] = + _LNGOFF_1_0_0_0_;}
	{long i; for (i = 12; i < 38; i++) O5538[i] = + _LNGOFF_2_0_0_0_;}
	{long i; for (i = 38; i < 50; i++) O5538[i] = + _LNGOFF_1_0_0_0_;}
}

long O5540[50];
void O5540_init () {
	{long i; for (i = 0; i < 12; i++) O5540[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 12; i < 38; i++) O5540[i] = + _LNGOFF_2_0_0_1_;}
	{long i; for (i = 38; i < 50; i++) O5540[i] = + _LNGOFF_1_0_0_1_;}
}

long O5720[10];
void O5720_init () {
	O5720[0] = + _CHROFF_8_0_;
	O5720[1] = + _CHROFF_10_0_;
	{long i; for (i = 2; i < 10; i++) O5720[i] = + _CHROFF_9_0_;}
}

long O5721[10];
void O5721_init () {
	O5721[0] = + _CHROFF_8_1_;
	O5721[1] = + _CHROFF_10_1_;
	{long i; for (i = 2; i < 10; i++) O5721[i] = + _CHROFF_9_1_;}
}

long O6101[457];
void O6101_init () {
	O6101[0] = + _CHROFF_1_0_;
	O6101[1] = + _CHROFF_2_0_;
	O6101[2] = + _CHROFF_3_0_;
	O6101[3] = + _CHROFF_4_0_;
	O6101[4] = + _CHROFF_5_0_;
	O6101[456] = + _CHROFF_5_0_;
}

long O6218[455];
void O6218_init () {
	O6218[0] = + _PTROFF_3_6_2_4_1_0_;
	O6218[1] = + _PTROFF_4_6_2_4_1_0_;
	O6218[2] = + _PTROFF_5_7_2_4_1_0_;
	O6218[454] = + _PTROFF_5_7_2_4_1_0_;
}

long O6357[455];
void O6357_init () {
	O6357[0] = + _LNGOFF_3_6_2_3_;
	O6357[1] = + _LNGOFF_4_6_2_3_;
	O6357[2] = + _LNGOFF_5_7_2_3_;
	O6357[454] = + _LNGOFF_5_7_2_3_;
}

long O6366[455];
void O6366_init () {
	O6366[0] = + _CHROFF_3_3_;
	O6366[1] = + _CHROFF_4_3_;
	O6366[2] = + _CHROFF_5_3_;
	O6366[454] = + _CHROFF_5_3_;
}

long O6506[443];
void O6506_init () {
	O6506[0] = + _LNGOFF_0_0_0_0_;
	O6506[1] = + _LNGOFF_1_0_0_1_;
	{long i; for (i = 2; i < 4; i++) O6506[i] = + _LNGOFF_0_0_0_0_;}
	O6506[4] = + _LNGOFF_2_0_0_0_;
	O6506[5] = + _LNGOFF_0_1_0_0_;
	O6506[182] = + _LNGOFF_2_0_0_0_;
	O6506[199] = + _LNGOFF_4_0_0_0_;
	O6506[203] = + _LNGOFF_5_2_0_0_;
	{long i; for (i = 204; i < 211; i++) O6506[i] = + _LNGOFF_6_3_0_0_;}
	O6506[211] = + _LNGOFF_10_3_0_0_;
	{long i; for (i = 212; i < 217; i++) O6506[i] = + _LNGOFF_6_3_0_0_;}
	O6506[217] = + _LNGOFF_6_4_0_0_;
	O6506[218] = + _LNGOFF_6_3_0_0_;
	{long i; for (i = 219; i < 221; i++) O6506[i] = + _LNGOFF_12_3_0_0_;}
	O6506[221] = + _LNGOFF_6_3_0_0_;
	O6506[222] = + _LNGOFF_7_4_0_0_;
	{long i; for (i = 223; i < 225; i++) O6506[i] = + _LNGOFF_14_3_0_0_;}
	{long i; for (i = 225; i < 228; i++) O6506[i] = + _LNGOFF_5_2_0_0_;}
	O6506[228] = + _LNGOFF_6_3_0_0_;
	O6506[229] = + _LNGOFF_5_2_0_0_;
	O6506[230] = + _LNGOFF_6_2_0_0_;
	{long i; for (i = 231; i < 235; i++) O6506[i] = + _LNGOFF_5_2_0_0_;}
	{long i; for (i = 235; i < 239; i++) O6506[i] = + _LNGOFF_6_2_0_0_;}
	{long i; for (i = 239; i < 241; i++) O6506[i] = + _LNGOFF_6_0_0_0_;}
	O6506[241] = + _LNGOFF_7_2_0_1_;
	{long i; for (i = 242; i < 250; i++) O6506[i] = + _LNGOFF_6_0_0_0_;}
	{long i; for (i = 251; i < 256; i++) O6506[i] = + _LNGOFF_5_3_0_0_;}
	O6506[257] = + _LNGOFF_5_3_0_0_;
	{long i; for (i = 258; i < 260; i++) O6506[i] = + _LNGOFF_6_1_0_0_;}
	O6506[262] = + _LNGOFF_6_1_0_0_;
	O6506[266] = + _LNGOFF_2_4_0_0_;
	O6506[270] = + _LNGOFF_2_2_0_1_;
	O6506[289] = + _LNGOFF_49_16_0_3_;
	O6506[290] = + _LNGOFF_2_3_0_0_;
	O6506[291] = + _LNGOFF_4_3_0_0_;
	O6506[292] = + _LNGOFF_5_5_0_0_;
	O6506[293] = + _LNGOFF_10_10_0_0_;
	O6506[308] = + _LNGOFF_6_3_0_0_;
	O6506[332] = + _LNGOFF_8_5_0_0_;
	O6506[333] = + _LNGOFF_9_5_0_0_;
	O6506[337] = + _LNGOFF_11_5_0_0_;
	O6506[338] = + _LNGOFF_11_6_0_0_;
	O6506[339] = + _LNGOFF_11_5_0_0_;
	O6506[341] = + _LNGOFF_16_7_6_0_;
	O6506[343] = + _LNGOFF_42_12_10_0_;
	O6506[345] = + _LNGOFF_46_12_10_0_;
	O6506[349] = + _LNGOFF_47_12_10_0_;
	O6506[350] = + _LNGOFF_49_12_10_0_;
	O6506[351] = + _LNGOFF_47_12_10_0_;
	{long i; for (i = 355; i < 358; i++) O6506[i] = + _LNGOFF_49_13_10_0_;}
	O6506[362] = + _LNGOFF_49_13_10_0_;
	O6506[363] = + _LNGOFF_51_13_10_0_;
	{long i; for (i = 364; i < 366; i++) O6506[i] = + _LNGOFF_49_14_10_0_;}
	O6506[370] = + _LNGOFF_59_21_10_0_;
	O6506[371] = + _LNGOFF_59_23_10_0_;
	O6506[372] = + _LNGOFF_65_25_10_0_;
	O6506[373] = + _LNGOFF_68_26_10_0_;
	O6506[391] = + _LNGOFF_42_13_10_0_;
	O6506[392] = + _LNGOFF_44_13_10_0_;
	O6506[393] = + _LNGOFF_51_13_10_0_;
	O6506[394] = + _LNGOFF_58_14_10_0_;
	O6506[395] = + _LNGOFF_45_16_10_0_;
	O6506[396] = + _LNGOFF_44_13_10_0_;
	O6506[397] = + _LNGOFF_50_13_10_0_;
	O6506[398] = + _LNGOFF_51_14_10_0_;
	O6506[399] = + _LNGOFF_43_13_10_0_;
	O6506[400] = + _LNGOFF_46_14_10_0_;
	O6506[401] = + _LNGOFF_59_16_10_0_;
	O6506[402] = + _LNGOFF_44_15_10_0_;
	O6506[403] = + _LNGOFF_51_18_10_0_;
	{long i; for (i = 404; i < 408; i++) O6506[i] = + _LNGOFF_46_14_10_0_;}
	{long i; for (i = 416; i < 418; i++) O6506[i] = + _LNGOFF_21_7_6_0_;}
	O6506[423] = + _LNGOFF_23_8_6_0_;
	{long i; for (i = 424; i < 426; i++) O6506[i] = + _LNGOFF_23_9_6_0_;}
	O6506[426] = + _LNGOFF_24_9_6_0_;
	O6506[427] = + _LNGOFF_26_8_6_0_;
	{long i; for (i = 432; i < 434; i++) O6506[i] = + _LNGOFF_29_14_8_0_;}
	O6506[440] = + _LNGOFF_48_19_10_0_;
	O6506[442] = + _LNGOFF_48_18_10_0_;
}

long O6566[259];
void O6566_init () {
	O6566[0] =  + _REFACS_1_;
	O6566[195] =  + _REFACS_1_;
	{long i; for (i = 199; i < 215; i++) O6566[i] =  + _REFACS_1_;}
	{long i; for (i = 215; i < 217; i++) O6566[i] =  + _REFACS_7_;}
	{long i; for (i = 217; i < 237; i++) O6566[i] =  + _REFACS_1_;}
	O6566[237] =  + _REFACS_2_;
	{long i; for (i = 238; i < 246; i++) O6566[i] =  + _REFACS_1_;}
	{long i; for (i = 247; i < 252; i++) O6566[i] =  + _REFACS_1_;}
	{long i; for (i = 253; i < 256; i++) O6566[i] =  + _REFACS_1_;}
	O6566[258] =  + _REFACS_1_;
}

long O7454[6];
void O7454_init () {
	{long i; for (i = 0; i < 2; i++) O7454[i] = + _CHROFF_4_0_;}
	O7454[2] = + _CHROFF_5_0_;
	{long i; for (i = 3; i < 6; i++) O7454[i] = + _CHROFF_4_0_;}
}

long O7455[6];
void O7455_init () {
	{long i; for (i = 0; i < 2; i++) O7455[i] = + _LNGOFF_4_2_0_0_;}
	O7455[2] = + _LNGOFF_5_2_0_0_;
	O7455[3] = + _LNGOFF_4_3_0_0_;
	O7455[4] = + _LNGOFF_4_2_0_0_;
	O7455[5] = + _LNGOFF_4_3_0_0_;
}

long O7463[6];
void O7463_init () {
	{long i; for (i = 0; i < 2; i++) O7463[i] = + _PTROFF_4_2_0_3_0_0_;}
	O7463[2] = + _PTROFF_5_2_0_3_0_0_;
	O7463[3] = + _PTROFF_4_3_0_3_0_0_;
	O7463[4] = + _PTROFF_4_2_0_3_0_0_;
	O7463[5] = + _PTROFF_4_3_0_3_0_0_;
}

long O7464[6];
void O7464_init () {
	{long i; for (i = 0; i < 2; i++) O7464[i] = + _PTROFF_4_2_0_3_0_1_;}
	O7464[2] = + _PTROFF_5_2_0_3_0_1_;
	O7464[3] = + _PTROFF_4_3_0_3_0_1_;
	O7464[4] = + _PTROFF_4_2_0_3_0_1_;
	O7464[5] = + _PTROFF_4_3_0_3_0_1_;
}

long O7466[6];
void O7466_init () {
	{long i; for (i = 0; i < 2; i++) O7466[i] = + _PTROFF_4_2_0_3_0_2_;}
	O7466[2] = + _PTROFF_5_2_0_3_0_2_;
	O7466[3] = + _PTROFF_4_3_0_3_0_2_;
	O7466[4] = + _PTROFF_4_2_0_3_0_2_;
	O7466[5] = + _PTROFF_4_3_0_3_0_2_;
}

long O7467[6];
void O7467_init () {
	{long i; for (i = 0; i < 2; i++) O7467[i] = + _LNGOFF_4_2_0_1_;}
	O7467[2] = + _LNGOFF_5_2_0_1_;
	O7467[3] = + _LNGOFF_4_3_0_1_;
	O7467[4] = + _LNGOFF_4_2_0_1_;
	O7467[5] = + _LNGOFF_4_3_0_1_;
}

long O7468[6];
void O7468_init () {
	{long i; for (i = 0; i < 2; i++) O7468[i] = + _CHROFF_4_1_;}
	O7468[2] = + _CHROFF_5_1_;
	{long i; for (i = 3; i < 6; i++) O7468[i] = + _CHROFF_4_1_;}
}

long O7469[6];
void O7469_init () {
	{long i; for (i = 0; i < 2; i++) O7469[i] = + _LNGOFF_4_2_0_2_;}
	O7469[2] = + _LNGOFF_5_2_0_2_;
	O7469[3] = + _LNGOFF_4_3_0_2_;
	O7469[4] = + _LNGOFF_4_2_0_2_;
	O7469[5] = + _LNGOFF_4_3_0_2_;
}

long O7482[4];
void O7482_init () {
	O7482[0] =  + _REFACS_4_;
	O7482[1] = + _CHROFF_4_2_;
	O7482[2] = + _PTROFF_4_2_0_3_0_3_;
	O7482[3] = + _CHROFF_4_2_;
}

long O7581[10];
void O7581_init () {
	{long i; for (i = 0; i < 3; i++) O7581[i] = + _LNGOFF_0_0_0_0_;}
	{long i; for (i = 3; i < 5; i++) O7581[i] = + _LNGOFF_1_0_0_0_;}
	O7581[5] = + _LNGOFF_1_1_0_0_;
	{long i; for (i = 6; i < 8; i++) O7581[i] = + _LNGOFF_1_0_0_0_;}
	{long i; for (i = 8; i < 10; i++) O7581[i] = + _LNGOFF_1_1_0_0_;}
}

long O7582[10];
void O7582_init () {
	{long i; for (i = 0; i < 3; i++) O7582[i] = + _LNGOFF_0_0_0_1_;}
	{long i; for (i = 3; i < 5; i++) O7582[i] = + _LNGOFF_1_0_0_1_;}
	O7582[5] = + _LNGOFF_1_1_0_1_;
	{long i; for (i = 6; i < 8; i++) O7582[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 8; i < 10; i++) O7582[i] = + _LNGOFF_1_1_0_1_;}
}

long O7647[3];
void O7647_init () {
	{long i; for (i = 0; i < 2; i++) O7647[i] = + _LNGOFF_1_0_0_2_;}
	O7647[2] = + _LNGOFF_1_1_0_2_;
}

long O7727[4];
void O7727_init () {
	{long i; for (i = 0; i < 2; i++) O7727[i] = + _LNGOFF_1_0_0_2_;}
	{long i; for (i = 2; i < 4; i++) O7727[i] = + _LNGOFF_1_1_0_2_;}
}

long O7887[105];
void O7887_init () {
	{long i; for (i = 0; i < 40; i++) O7887[i] = 0;}
	O7887[40] =  + _REFACS_2_;
	{long i; for (i = 41; i < 44; i++) O7887[i] = 0;}
	{long i; for (i = 44; i < 60; i++) O7887[i] =  + _REFACS_2_;}
	{long i; for (i = 60; i < 62; i++) O7887[i] =  + _REFACS_8_;}
	{long i; for (i = 62; i < 82; i++) O7887[i] =  + _REFACS_2_;}
	O7887[82] =  + _REFACS_3_;
	{long i; for (i = 83; i < 91; i++) O7887[i] =  + _REFACS_2_;}
	O7887[91] = 0;
	{long i; for (i = 92; i < 97; i++) O7887[i] =  + _REFACS_2_;}
	O7887[97] = 0;
	{long i; for (i = 98; i < 101; i++) O7887[i] =  + _REFACS_2_;}
	{long i; for (i = 101; i < 103; i++) O7887[i] = 0;}
	O7887[103] =  + _REFACS_2_;
	O7887[104] = 0;
}

long O7891[105];
void O7891_init () {
	{long i; for (i = 0; i < 40; i++) O7891[i] =  + _REFACS_1_;}
	O7891[40] =  + _REFACS_3_;
	{long i; for (i = 41; i < 44; i++) O7891[i] =  + _REFACS_1_;}
	{long i; for (i = 44; i < 60; i++) O7891[i] =  + _REFACS_3_;}
	{long i; for (i = 60; i < 62; i++) O7891[i] =  + _REFACS_9_;}
	{long i; for (i = 62; i < 82; i++) O7891[i] =  + _REFACS_3_;}
	O7891[82] =  + _REFACS_4_;
	{long i; for (i = 83; i < 91; i++) O7891[i] =  + _REFACS_3_;}
	O7891[91] =  + _REFACS_1_;
	{long i; for (i = 92; i < 97; i++) O7891[i] =  + _REFACS_3_;}
	O7891[97] =  + _REFACS_1_;
	{long i; for (i = 98; i < 101; i++) O7891[i] =  + _REFACS_3_;}
	{long i; for (i = 101; i < 103; i++) O7891[i] =  + _REFACS_1_;}
	O7891[103] =  + _REFACS_3_;
	O7891[104] =  + _REFACS_1_;
}

long O8082[91];
void O8082_init () {
	O8082[0] =  + _REFACS_2_;
	{long i; for (i = 28; i < 31; i++) O8082[i] =  + _REFACS_2_;}
	{long i; for (i = 31; i < 47; i++) O8082[i] =  + _REFACS_4_;}
	{long i; for (i = 47; i < 49; i++) O8082[i] =  + _REFACS_10_;}
	{long i; for (i = 49; i < 69; i++) O8082[i] =  + _REFACS_4_;}
	O8082[69] =  + _REFACS_5_;
	{long i; for (i = 70; i < 78; i++) O8082[i] =  + _REFACS_4_;}
	O8082[78] =  + _REFACS_2_;
	{long i; for (i = 79; i < 84; i++) O8082[i] =  + _REFACS_4_;}
	O8082[84] =  + _REFACS_2_;
	{long i; for (i = 85; i < 88; i++) O8082[i] =  + _REFACS_4_;}
	{long i; for (i = 88; i < 90; i++) O8082[i] =  + _REFACS_2_;}
	O8082[90] =  + _REFACS_4_;
}

long O8366[55];
void O8366_init () {
	O8366[0] = + _CHROFF_5_0_;
	{long i; for (i = 1; i < 8; i++) O8366[i] = + _CHROFF_6_1_;}
	O8366[8] = + _CHROFF_10_1_;
	{long i; for (i = 9; i < 16; i++) O8366[i] = + _CHROFF_6_1_;}
	{long i; for (i = 16; i < 18; i++) O8366[i] = + _CHROFF_12_1_;}
	O8366[18] = + _CHROFF_6_1_;
	O8366[19] = + _CHROFF_7_1_;
	{long i; for (i = 20; i < 22; i++) O8366[i] = + _CHROFF_14_1_;}
	{long i; for (i = 22; i < 25; i++) O8366[i] = + _CHROFF_5_0_;}
	O8366[25] = + _CHROFF_6_0_;
	O8366[26] = + _CHROFF_5_0_;
	O8366[27] = + _CHROFF_6_0_;
	{long i; for (i = 28; i < 32; i++) O8366[i] = + _CHROFF_5_0_;}
	{long i; for (i = 32; i < 36; i++) O8366[i] = + _CHROFF_6_0_;}
	{long i; for (i = 48; i < 53; i++) O8366[i] = + _CHROFF_5_1_;}
	O8366[54] = + _CHROFF_5_1_;
}

long O8367[55];
void O8367_init () {
	O8367[0] = + _CHROFF_5_1_;
	{long i; for (i = 1; i < 8; i++) O8367[i] = + _CHROFF_6_2_;}
	O8367[8] = + _CHROFF_10_2_;
	{long i; for (i = 9; i < 16; i++) O8367[i] = + _CHROFF_6_2_;}
	{long i; for (i = 16; i < 18; i++) O8367[i] = + _CHROFF_12_2_;}
	O8367[18] = + _CHROFF_6_2_;
	O8367[19] = + _CHROFF_7_2_;
	{long i; for (i = 20; i < 22; i++) O8367[i] = + _CHROFF_14_2_;}
	{long i; for (i = 22; i < 25; i++) O8367[i] = + _CHROFF_5_1_;}
	O8367[25] = + _CHROFF_6_1_;
	O8367[26] = + _CHROFF_5_1_;
	O8367[27] = + _CHROFF_6_1_;
	{long i; for (i = 28; i < 32; i++) O8367[i] = + _CHROFF_5_1_;}
	{long i; for (i = 32; i < 36; i++) O8367[i] = + _CHROFF_6_1_;}
	{long i; for (i = 48; i < 53; i++) O8367[i] = + _CHROFF_5_2_;}
	O8367[54] = + _CHROFF_5_2_;
}

long O8826[182];
void O8826_init () {
	{long i; for (i = 0; i < 24; i++) O8826[i] = 0;}
	O8826[24] =  + _REFACS_22_;
	O8826[25] =  + _REFACS_23_;
	{long i; for (i = 26; i < 35; i++) O8826[i] = 0;}
	O8826[35] =  + _REFACS_1_;
	O8826[36] = 0;
	O8826[37] =  + _REFACS_1_;
	{long i; for (i = 38; i < 40; i++) O8826[i] = 0;}
	{long i; for (i = 40; i < 42; i++) O8826[i] =  + _REFACS_5_;}
	O8826[42] = 0;
	{long i; for (i = 43; i < 45; i++) O8826[i] =  + _REFACS_1_;}
	{long i; for (i = 45; i < 49; i++) O8826[i] = 0;}
	{long i; for (i = 49; i < 51; i++) O8826[i] =  + _REFACS_1_;}
	{long i; for (i = 51; i < 66; i++) O8826[i] = 0;}
	{long i; for (i = 66; i < 76; i++) O8826[i] =  + _REFACS_2_;}
	{long i; for (i = 76; i < 78; i++) O8826[i] =  + _REFACS_7_;}
	{long i; for (i = 78; i < 80; i++) O8826[i] =  + _REFACS_24_;}
	{long i; for (i = 80; i < 83; i++) O8826[i] =  + _REFACS_25_;}
	O8826[83] =  + _REFACS_26_;
	{long i; for (i = 84; i < 86; i++) O8826[i] =  + _REFACS_25_;}
	O8826[86] =  + _REFACS_26_;
	O8826[87] =  + _REFACS_25_;
	{long i; for (i = 88; i < 102; i++) O8826[i] =  + _REFACS_26_;}
	{long i; for (i = 102; i < 104; i++) O8826[i] =  + _REFACS_30_;}
	{long i; for (i = 104; i < 106; i++) O8826[i] =  + _REFACS_33_;}
	{long i; for (i = 106; i < 108; i++) O8826[i] =  + _REFACS_30_;}
	{long i; for (i = 108; i < 110; i++) O8826[i] =  + _REFACS_33_;}
	O8826[110] =  + _REFACS_24_;
	O8826[111] =  + _REFACS_25_;
	O8826[112] =  + _REFACS_26_;
	O8826[113] =  + _REFACS_28_;
	O8826[114] =  + _REFACS_25_;
	O8826[115] =  + _REFACS_24_;
	{long i; for (i = 116; i < 118; i++) O8826[i] =  + _REFACS_26_;}
	O8826[118] =  + _REFACS_25_;
	O8826[119] =  + _REFACS_26_;
	O8826[120] =  + _REFACS_30_;
	O8826[121] =  + _REFACS_25_;
	O8826[122] =  + _REFACS_28_;
	{long i; for (i = 123; i < 127; i++) O8826[i] =  + _REFACS_25_;}
	O8826[127] =  + _REFACS_24_;
	O8826[128] =  + _REFACS_25_;
	O8826[129] =  + _REFACS_26_;
	O8826[130] =  + _REFACS_28_;
	O8826[131] =  + _REFACS_25_;
	O8826[132] =  + _REFACS_24_;
	{long i; for (i = 133; i < 135; i++) O8826[i] =  + _REFACS_26_;}
	O8826[135] =  + _REFACS_25_;
	O8826[136] =  + _REFACS_26_;
	O8826[137] =  + _REFACS_30_;
	O8826[138] =  + _REFACS_25_;
	O8826[139] =  + _REFACS_28_;
	{long i; for (i = 140; i < 144; i++) O8826[i] =  + _REFACS_25_;}
	O8826[144] =  + _REFACS_10_;
	{long i; for (i = 145; i < 147; i++) O8826[i] =  + _REFACS_12_;}
	O8826[147] =  + _REFACS_10_;
	{long i; for (i = 148; i < 152; i++) O8826[i] =  + _REFACS_14_;}
	{long i; for (i = 152; i < 154; i++) O8826[i] =  + _REFACS_10_;}
	{long i; for (i = 154; i < 158; i++) O8826[i] =  + _REFACS_11_;}
	O8826[158] =  + _REFACS_12_;
	{long i; for (i = 159; i < 163; i++) O8826[i] =  + _REFACS_11_;}
	{long i; for (i = 163; i < 166; i++) O8826[i] =  + _REFACS_12_;}
	{long i; for (i = 166; i < 170; i++) O8826[i] =  + _REFACS_14_;}
	O8826[170] = 0;
	O8826[171] =  + _REFACS_25_;
	O8826[172] = 0;
	O8826[173] =  + _REFACS_25_;
	{long i; for (i = 174; i < 176; i++) O8826[i] = 0;}
	O8826[176] =  + _REFACS_25_;
	O8826[177] = 0;
	O8826[178] =  + _REFACS_25_;
	{long i; for (i = 179; i < 182; i++) O8826[i] = 0;}
}

static EIF_TYPE_INDEX Y8826_pgtype0[] = {1124,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8826_pgtype1[] = {1124,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8826_pgtype2[] = {1173,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8826_pgtype3[] = {1173,0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y8826_pgtype4[] = {1173,0xFF01,1169,0xFFFF};
static EIF_TYPE_INDEX Y8826_pgtype5[] = {1173,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y8826_gen_type [182];
EIF_TYPE_INDEX Y8826 [182];
void Y8826_init (void)
{
	egc_routines_types [8826] = Y8826;
	egc_routines_gen_types [8826] = Y8826_gen_type;
	egc_routines_offset [8826] = 1187;
	Y8826_gen_type [31] = Y8826_pgtype0;
	Y8826_gen_type [32] = Y8826_pgtype1;
	Y8826_gen_type [33] = Y8826_pgtype2;
	Y8826_gen_type [34] = Y8826_pgtype3;
	Y8826_gen_type [35] = Y8826_pgtype4;
	Y8826_gen_type [36] = Y8826_pgtype5;
	Y8826[0] = 1082;
	{long i; for (i = 1; i < 3; i++) Y8826[i] = 1083;};
	{long i; for (i = 3; i < 5; i++) Y8826[i] = 1084;};
	{long i; for (i = 5; i < 7; i++) Y8826[i] = 1085;};
	Y8826[7] = 1086;
	{long i; for (i = 8; i < 10; i++) Y8826[i] = 1087;};
	{long i; for (i = 10; i < 12; i++) Y8826[i] = 1088;};
	{long i; for (i = 12; i < 14; i++) Y8826[i] = 1089;};
	Y8826[14] = 1097;
	{long i; for (i = 15; i < 17; i++) Y8826[i] = 1090;};
	{long i; for (i = 17; i < 19; i++) Y8826[i] = 1091;};
	{long i; for (i = 19; i < 21; i++) Y8826[i] = 1092;};
	Y8826[21] = 1093;
	{long i; for (i = 22; i < 24; i++) Y8826[i] = 1094;};
	{long i; for (i = 24; i < 26; i++) Y8826[i] = 1098;};
	{long i; for (i = 26; i < 29; i++) Y8826[i] = 1082;};
	Y8826[29] = 1086;
	Y8826[30] = 1096;
	{long i; for (i = 31; i < 33; i++) Y8826[i] = 1124;};
	{long i; for (i = 33; i < 37; i++) Y8826[i] = 1173;};
	Y8826[37] = 1183;
	{long i; for (i = 38; i < 40; i++) Y8826[i] = 1100;};
	{long i; for (i = 40; i < 42; i++) Y8826[i] = 1101;};
	Y8826[42] = 1103;
	{long i; for (i = 43; i < 45; i++) Y8826[i] = 1184;};
	Y8826[45] = 1104;
	Y8826[46] = 1106;
	{long i; for (i = 47; i < 49; i++) Y8826[i] = 1102;};
	{long i; for (i = 49; i < 51; i++) Y8826[i] = 1105;};
	{long i; for (i = 51; i < 53; i++) Y8826[i] = 1125;};
	Y8826[53] = 1109;
	Y8826[54] = 1110;
	Y8826[55] = 1122;
	{long i; for (i = 56; i < 58; i++) Y8826[i] = 1108;};
	{long i; for (i = 58; i < 60; i++) Y8826[i] = 1107;};
	{long i; for (i = 60; i < 62; i++) Y8826[i] = 1113;};
	{long i; for (i = 62; i < 65; i++) Y8826[i] = 1111;};
	Y8826[65] = 1093;
	{long i; for (i = 66; i < 69; i++) Y8826[i] = 1117;};
	Y8826[69] = 1118;
	{long i; for (i = 70; i < 73; i++) Y8826[i] = 1117;};
	Y8826[73] = 1119;
	Y8826[74] = 1120;
	Y8826[75] = 1121;
	{long i; for (i = 76; i < 78; i++) Y8826[i] = 1122;};
	{long i; for (i = 78; i < 80; i++) Y8826[i] = 1126;};
	{long i; for (i = 80; i < 82; i++) Y8826[i] = 1127;};
	Y8826[82] = 1128;
	Y8826[83] = 1129;
	Y8826[84] = 1130;
	Y8826[85] = 1128;
	Y8826[86] = 1129;
	Y8826[87] = 1130;
	Y8826[88] = 1131;
	Y8826[89] = 1133;
	Y8826[90] = 1132;
	Y8826[91] = 1131;
	Y8826[92] = 1133;
	Y8826[93] = 1132;
	Y8826[94] = 1135;
	Y8826[95] = 1136;
	{long i; for (i = 96; i < 99; i++) Y8826[i] = 1135;};
	Y8826[99] = 1136;
	Y8826[100] = 1137;
	Y8826[101] = 1138;
	Y8826[102] = 1139;
	Y8826[103] = 1140;
	Y8826[104] = 1141;
	Y8826[105] = 1144;
	Y8826[106] = 1139;
	Y8826[107] = 1140;
	Y8826[108] = 1141;
	Y8826[109] = 1144;
	Y8826[110] = 1148;
	Y8826[111] = 1149;
	Y8826[112] = 1180;
	Y8826[113] = 1174;
	Y8826[114] = 1175;
	Y8826[115] = 1152;
	Y8826[116] = 1176;
	Y8826[117] = 1177;
	Y8826[118] = 1154;
	Y8826[119] = 1155;
	Y8826[120] = 1178;
	Y8826[121] = 1156;
	Y8826[122] = 1157;
	Y8826[123] = 1158;
	Y8826[124] = 1159;
	Y8826[125] = 1160;
	Y8826[126] = 1161;
	Y8826[127] = 1148;
	Y8826[128] = 1149;
	Y8826[129] = 1180;
	Y8826[130] = 1174;
	Y8826[131] = 1175;
	Y8826[132] = 1152;
	Y8826[133] = 1176;
	Y8826[134] = 1177;
	Y8826[135] = 1154;
	Y8826[136] = 1155;
	Y8826[137] = 1178;
	Y8826[138] = 1156;
	Y8826[139] = 1157;
	Y8826[140] = 1158;
	Y8826[141] = 1159;
	Y8826[142] = 1160;
	Y8826[143] = 1161;
	Y8826[144] = 1162;
	{long i; for (i = 145; i < 147; i++) Y8826[i] = 1163;};
	Y8826[147] = 1162;
	Y8826[148] = 1181;
	Y8826[149] = 1182;
	Y8826[150] = 1181;
	Y8826[151] = 1182;
	Y8826[152] = 1162;
	Y8826[153] = 1166;
	Y8826[154] = 1169;
	Y8826[155] = 1170;
	Y8826[156] = 1171;
	Y8826[157] = 1169;
	Y8826[158] = 1185;
	Y8826[159] = 1169;
	Y8826[160] = 1170;
	Y8826[161] = 1171;
	Y8826[162] = 1172;
	Y8826[163] = 1185;
	{long i; for (i = 164; i < 166; i++) Y8826[i] = 1164;};
	Y8826[166] = 1167;
	Y8826[167] = 1168;
	Y8826[168] = 1167;
	Y8826[169] = 1168;
	Y8826[170] = 1114;
	Y8826[171] = 1150;
	Y8826[172] = 1115;
	Y8826[173] = 1151;
	Y8826[174] = 1116;
	Y8826[175] = 1114;
	Y8826[176] = 1150;
	Y8826[177] = 1115;
	Y8826[178] = 1151;
	Y8826[179] = 1116;
	{long i; for (i = 180; i < 182; i++) Y8826[i] = 1186;};
}

long O8827[182];
void O8827_init () {
	{long i; for (i = 0; i < 2; i++) O8827[i] = + _CHROFF_1_0_;}
	O8827[2] = + _CHROFF_2_3_;
	{long i; for (i = 3; i < 5; i++) O8827[i] = + _CHROFF_1_0_;}
	O8827[5] = + _CHROFF_1_1_;
	O8827[6] = + _CHROFF_2_1_;
	{long i; for (i = 7; i < 10; i++) O8827[i] = + _CHROFF_1_0_;}
	O8827[10] = + _CHROFF_2_1_;
	O8827[11] = + _CHROFF_4_1_;
	O8827[12] = + _CHROFF_1_0_;
	{long i; for (i = 13; i < 15; i++) O8827[i] = + _CHROFF_2_0_;}
	{long i; for (i = 15; i < 17; i++) O8827[i] = + _CHROFF_1_0_;}
	O8827[17] = + _CHROFF_2_0_;
	O8827[18] = + _CHROFF_3_1_;
	{long i; for (i = 19; i < 22; i++) O8827[i] = + _CHROFF_1_0_;}
	O8827[22] = + _CHROFF_2_1_;
	O8827[23] = + _CHROFF_3_4_;
	O8827[24] = + _CHROFF_40_8_;
	O8827[25] = + _CHROFF_49_15_;
	O8827[26] = + _CHROFF_2_2_;
	O8827[27] = + _CHROFF_4_2_;
	O8827[28] = + _CHROFF_5_4_;
	O8827[29] = + _CHROFF_10_9_;
	{long i; for (i = 30; i < 32; i++) O8827[i] = + _CHROFF_1_0_;}
	O8827[32] = + _CHROFF_2_0_;
	{long i; for (i = 33; i < 35; i++) O8827[i] = + _CHROFF_1_0_;}
	{long i; for (i = 35; i < 37; i++) O8827[i] = + _CHROFF_2_0_;}
	O8827[37] = + _CHROFF_4_0_;
	O8827[38] = + _CHROFF_1_0_;
	O8827[39] = + _CHROFF_3_0_;
	O8827[40] = + _CHROFF_7_4_;
	O8827[41] = + _CHROFF_8_5_;
	O8827[42] = + _CHROFF_1_0_;
	O8827[43] = + _CHROFF_2_0_;
	O8827[44] = + _CHROFF_6_2_;
	{long i; for (i = 45; i < 49; i++) O8827[i] = + _CHROFF_1_0_;}
	{long i; for (i = 49; i < 51; i++) O8827[i] = + _CHROFF_3_1_;}
	{long i; for (i = 51; i < 53; i++) O8827[i] = + _CHROFF_1_1_;}
	{long i; for (i = 53; i < 59; i++) O8827[i] = + _CHROFF_1_0_;}
	O8827[59] = + _CHROFF_2_0_;
	O8827[60] = + _CHROFF_1_0_;
	O8827[61] = + _CHROFF_2_0_;
	O8827[62] = + _CHROFF_1_0_;
	O8827[63] = + _CHROFF_2_0_;
	{long i; for (i = 64; i < 66; i++) O8827[i] = + _CHROFF_1_0_;}
	{long i; for (i = 66; i < 68; i++) O8827[i] = + _CHROFF_3_0_;}
	O8827[68] = + _CHROFF_8_4_;
	O8827[69] = + _CHROFF_9_4_;
	{long i; for (i = 70; i < 73; i++) O8827[i] = + _CHROFF_4_0_;}
	O8827[73] = + _CHROFF_11_4_;
	O8827[74] = + _CHROFF_11_5_;
	O8827[75] = + _CHROFF_11_4_;
	O8827[76] = + _CHROFF_13_3_;
	O8827[77] = + _CHROFF_16_5_;
	O8827[78] = + _CHROFF_35_7_;
	O8827[79] = + _CHROFF_42_10_;
	O8827[80] = + _CHROFF_37_7_;
	O8827[81] = + _CHROFF_46_10_;
	O8827[82] = + _CHROFF_37_7_;
	O8827[83] = + _CHROFF_38_7_;
	O8827[84] = + _CHROFF_37_7_;
	O8827[85] = + _CHROFF_47_10_;
	O8827[86] = + _CHROFF_49_10_;
	O8827[87] = + _CHROFF_47_10_;
	{long i; for (i = 88; i < 91; i++) O8827[i] = + _CHROFF_39_8_;}
	{long i; for (i = 91; i < 94; i++) O8827[i] = + _CHROFF_49_11_;}
	{long i; for (i = 94; i < 98; i++) O8827[i] = + _CHROFF_39_8_;}
	O8827[98] = + _CHROFF_49_11_;
	O8827[99] = + _CHROFF_51_11_;
	{long i; for (i = 100; i < 102; i++) O8827[i] = + _CHROFF_49_12_;}
	O8827[102] = + _CHROFF_47_10_;
	O8827[103] = + _CHROFF_47_12_;
	O8827[104] = + _CHROFF_50_11_;
	O8827[105] = + _CHROFF_53_11_;
	O8827[106] = + _CHROFF_59_19_;
	O8827[107] = + _CHROFF_59_21_;
	O8827[108] = + _CHROFF_65_23_;
	O8827[109] = + _CHROFF_68_24_;
	O8827[110] = + _CHROFF_35_7_;
	{long i; for (i = 111; i < 113; i++) O8827[i] = + _CHROFF_37_7_;}
	O8827[113] = + _CHROFF_43_7_;
	O8827[114] = + _CHROFF_37_8_;
	O8827[115] = + _CHROFF_35_7_;
	O8827[116] = + _CHROFF_37_7_;
	O8827[117] = + _CHROFF_37_8_;
	O8827[118] = + _CHROFF_36_7_;
	O8827[119] = + _CHROFF_37_7_;
	O8827[120] = + _CHROFF_41_7_;
	O8827[121] = + _CHROFF_36_7_;
	O8827[122] = + _CHROFF_40_10_;
	{long i; for (i = 123; i < 127; i++) O8827[i] = + _CHROFF_36_7_;}
	O8827[127] = + _CHROFF_42_11_;
	O8827[128] = + _CHROFF_44_11_;
	O8827[129] = + _CHROFF_51_11_;
	O8827[130] = + _CHROFF_58_12_;
	O8827[131] = + _CHROFF_45_14_;
	O8827[132] = + _CHROFF_44_11_;
	O8827[133] = + _CHROFF_50_11_;
	O8827[134] = + _CHROFF_51_12_;
	O8827[135] = + _CHROFF_43_11_;
	O8827[136] = + _CHROFF_46_12_;
	O8827[137] = + _CHROFF_59_14_;
	O8827[138] = + _CHROFF_44_13_;
	O8827[139] = + _CHROFF_51_16_;
	{long i; for (i = 140; i < 144; i++) O8827[i] = + _CHROFF_46_12_;}
	O8827[144] = + _CHROFF_16_3_;
	O8827[145] = + _CHROFF_18_3_;
	O8827[146] = + _CHROFF_23_3_;
	O8827[147] = + _CHROFF_16_3_;
	{long i; for (i = 148; i < 150; i++) O8827[i] = + _CHROFF_20_3_;}
	{long i; for (i = 150; i < 152; i++) O8827[i] = + _CHROFF_25_4_;}
	{long i; for (i = 152; i < 154; i++) O8827[i] = + _CHROFF_21_5_;}
	{long i; for (i = 154; i < 158; i++) O8827[i] = + _CHROFF_17_4_;}
	O8827[158] = + _CHROFF_18_4_;
	O8827[159] = + _CHROFF_23_6_;
	{long i; for (i = 160; i < 162; i++) O8827[i] = + _CHROFF_23_7_;}
	O8827[162] = + _CHROFF_24_7_;
	O8827[163] = + _CHROFF_26_6_;
	O8827[164] = + _CHROFF_19_3_;
	O8827[165] = + _CHROFF_22_3_;
	{long i; for (i = 166; i < 168; i++) O8827[i] = + _CHROFF_21_8_;}
	{long i; for (i = 168; i < 170; i++) O8827[i] = + _CHROFF_29_12_;}
	O8827[170] = + _CHROFF_1_0_;
	O8827[171] = + _CHROFF_36_8_;
	O8827[172] = + _CHROFF_1_0_;
	O8827[173] = + _CHROFF_36_7_;
	O8827[174] = + _CHROFF_1_0_;
	O8827[175] = + _CHROFF_6_2_;
	O8827[176] = + _CHROFF_48_15_;
	O8827[177] = + _CHROFF_6_2_;
	O8827[178] = + _CHROFF_48_14_;
	O8827[179] = + _CHROFF_6_4_;
	{long i; for (i = 180; i < 182; i++) O8827[i] = + _CHROFF_3_0_;}
}

long O9000[165];
void O9000_init () {
	O9000[0] =  + _REFACS_1_;
	{long i; for (i = 64; i < 66; i++) O9000[i] =  + _REFACS_25_;}
	{long i; for (i = 66; i < 69; i++) O9000[i] =  + _REFACS_26_;}
	O9000[69] =  + _REFACS_27_;
	{long i; for (i = 70; i < 72; i++) O9000[i] =  + _REFACS_26_;}
	O9000[72] =  + _REFACS_27_;
	O9000[73] =  + _REFACS_26_;
	{long i; for (i = 74; i < 88; i++) O9000[i] =  + _REFACS_27_;}
	{long i; for (i = 88; i < 90; i++) O9000[i] =  + _REFACS_31_;}
	{long i; for (i = 90; i < 92; i++) O9000[i] =  + _REFACS_34_;}
	{long i; for (i = 92; i < 94; i++) O9000[i] =  + _REFACS_31_;}
	{long i; for (i = 94; i < 96; i++) O9000[i] =  + _REFACS_34_;}
	O9000[96] =  + _REFACS_25_;
	O9000[97] =  + _REFACS_26_;
	O9000[98] =  + _REFACS_27_;
	O9000[99] =  + _REFACS_29_;
	O9000[100] =  + _REFACS_26_;
	O9000[101] =  + _REFACS_25_;
	{long i; for (i = 102; i < 104; i++) O9000[i] =  + _REFACS_27_;}
	O9000[104] =  + _REFACS_26_;
	O9000[105] =  + _REFACS_27_;
	O9000[106] =  + _REFACS_31_;
	O9000[107] =  + _REFACS_26_;
	O9000[108] =  + _REFACS_29_;
	{long i; for (i = 109; i < 113; i++) O9000[i] =  + _REFACS_26_;}
	O9000[113] =  + _REFACS_25_;
	O9000[114] =  + _REFACS_26_;
	O9000[115] =  + _REFACS_27_;
	O9000[116] =  + _REFACS_29_;
	O9000[117] =  + _REFACS_26_;
	O9000[118] =  + _REFACS_25_;
	{long i; for (i = 119; i < 121; i++) O9000[i] =  + _REFACS_27_;}
	O9000[121] =  + _REFACS_26_;
	O9000[122] =  + _REFACS_27_;
	O9000[123] =  + _REFACS_31_;
	O9000[124] =  + _REFACS_26_;
	O9000[125] =  + _REFACS_29_;
	{long i; for (i = 126; i < 130; i++) O9000[i] =  + _REFACS_26_;}
	O9000[157] =  + _REFACS_26_;
	O9000[159] =  + _REFACS_26_;
	O9000[162] =  + _REFACS_26_;
	O9000[164] =  + _REFACS_26_;
}

long O9352[153];
void O9352_init () {
	O9352[0] = + _PTROFF_2_3_0_1_0_0_;
	O9352[1] = + _PTROFF_4_3_0_1_0_0_;
	O9352[2] = + _PTROFF_5_5_0_1_0_0_;
	O9352[3] = + _PTROFF_10_10_0_9_0_0_;
	O9352[18] = + _PTROFF_6_3_0_2_0_0_;
	O9352[42] = + _PTROFF_8_5_0_1_0_0_;
	O9352[43] = + _PTROFF_9_5_0_1_0_0_;
	O9352[47] = + _PTROFF_11_5_0_1_0_0_;
	O9352[48] = + _PTROFF_11_6_0_1_0_0_;
	O9352[49] = + _PTROFF_11_5_0_1_0_0_;
	O9352[51] = + _PTROFF_16_7_6_1_0_0_;
	O9352[53] = + _PTROFF_42_12_10_6_0_0_;
	O9352[55] = + _PTROFF_46_12_10_6_0_0_;
	O9352[59] = + _PTROFF_47_12_10_7_0_0_;
	O9352[60] = + _PTROFF_49_12_10_10_0_0_;
	O9352[61] = + _PTROFF_47_12_10_7_0_0_;
	{long i; for (i = 65; i < 68; i++) O9352[i] = + _PTROFF_49_13_10_7_0_0_;}
	O9352[72] = + _PTROFF_49_13_10_6_0_0_;
	O9352[73] = + _PTROFF_51_13_10_8_0_0_;
	O9352[74] = + _PTROFF_49_14_10_8_0_0_;
	O9352[75] = + _PTROFF_49_14_10_10_0_0_;
	O9352[80] = + _PTROFF_59_21_10_11_0_0_;
	O9352[81] = + _PTROFF_59_23_10_11_0_0_;
	O9352[82] = + _PTROFF_65_25_10_11_0_0_;
	O9352[83] = + _PTROFF_68_26_10_11_0_0_;
	O9352[101] = + _PTROFF_42_13_10_6_0_0_;
	O9352[102] = + _PTROFF_44_13_10_7_0_0_;
	O9352[103] = + _PTROFF_51_13_10_9_0_0_;
	O9352[104] = + _PTROFF_58_14_10_9_0_0_;
	O9352[105] = + _PTROFF_45_16_10_7_0_0_;
	O9352[106] = + _PTROFF_44_13_10_6_1_0_;
	O9352[107] = + _PTROFF_50_13_10_9_0_0_;
	O9352[108] = + _PTROFF_51_14_10_9_0_0_;
	O9352[109] = + _PTROFF_43_13_10_6_0_0_;
	O9352[110] = + _PTROFF_46_14_10_7_0_0_;
	O9352[111] = + _PTROFF_59_16_10_12_0_0_;
	O9352[112] = + _PTROFF_44_15_10_6_0_0_;
	O9352[113] = + _PTROFF_51_18_10_10_0_0_;
	{long i; for (i = 114; i < 118; i++) O9352[i] = + _PTROFF_46_14_10_6_0_0_;}
	{long i; for (i = 126; i < 128; i++) O9352[i] = + _PTROFF_21_7_6_1_0_0_;}
	O9352[133] = + _PTROFF_23_8_6_1_0_0_;
	{long i; for (i = 134; i < 136; i++) O9352[i] = + _PTROFF_23_9_6_1_0_0_;}
	O9352[136] = + _PTROFF_24_9_6_1_0_0_;
	O9352[137] = + _PTROFF_26_8_6_2_0_0_;
	{long i; for (i = 142; i < 144; i++) O9352[i] = + _PTROFF_29_14_8_2_0_0_;}
	O9352[150] = + _PTROFF_48_19_10_9_0_0_;
	O9352[152] = + _PTROFF_48_18_10_9_0_0_;
}

long O9353[153];
void O9353_init () {
	O9353[0] = + _CHROFF_2_0_;
	O9353[1] = + _CHROFF_4_0_;
	O9353[2] = + _CHROFF_5_0_;
	O9353[3] = + _CHROFF_10_0_;
	O9353[18] = + _CHROFF_6_0_;
	O9353[42] = + _CHROFF_8_0_;
	O9353[43] = + _CHROFF_9_0_;
	{long i; for (i = 47; i < 50; i++) O9353[i] = + _CHROFF_11_0_;}
	O9353[51] = + _CHROFF_16_1_;
	O9353[53] = + _CHROFF_42_1_;
	O9353[55] = + _CHROFF_46_1_;
	O9353[59] = + _CHROFF_47_1_;
	O9353[60] = + _CHROFF_49_1_;
	O9353[61] = + _CHROFF_47_1_;
	{long i; for (i = 65; i < 68; i++) O9353[i] = + _CHROFF_49_1_;}
	O9353[72] = + _CHROFF_49_1_;
	O9353[73] = + _CHROFF_51_1_;
	{long i; for (i = 74; i < 76; i++) O9353[i] = + _CHROFF_49_1_;}
	{long i; for (i = 80; i < 82; i++) O9353[i] = + _CHROFF_59_1_;}
	O9353[82] = + _CHROFF_65_1_;
	O9353[83] = + _CHROFF_68_1_;
	O9353[101] = + _CHROFF_42_1_;
	O9353[102] = + _CHROFF_44_1_;
	O9353[103] = + _CHROFF_51_1_;
	O9353[104] = + _CHROFF_58_1_;
	O9353[105] = + _CHROFF_45_1_;
	O9353[106] = + _CHROFF_44_1_;
	O9353[107] = + _CHROFF_50_1_;
	O9353[108] = + _CHROFF_51_1_;
	O9353[109] = + _CHROFF_43_1_;
	O9353[110] = + _CHROFF_46_1_;
	O9353[111] = + _CHROFF_59_1_;
	O9353[112] = + _CHROFF_44_1_;
	O9353[113] = + _CHROFF_51_1_;
	{long i; for (i = 114; i < 118; i++) O9353[i] = + _CHROFF_46_1_;}
	{long i; for (i = 126; i < 128; i++) O9353[i] = + _CHROFF_21_1_;}
	{long i; for (i = 133; i < 136; i++) O9353[i] = + _CHROFF_23_1_;}
	O9353[136] = + _CHROFF_24_1_;
	O9353[137] = + _CHROFF_26_1_;
	{long i; for (i = 142; i < 144; i++) O9353[i] = + _CHROFF_29_1_;}
	O9353[150] = + _CHROFF_48_1_;
	O9353[152] = + _CHROFF_48_1_;
}

long O9364[153];
void O9364_init () {
	{long i; for (i = 0; i < 4; i++) O9364[i] =  + _REFACS_1_;}
	O9364[18] =  + _REFACS_2_;
	{long i; for (i = 42; i < 44; i++) O9364[i] =  + _REFACS_3_;}
	{long i; for (i = 47; i < 50; i++) O9364[i] =  + _REFACS_3_;}
	O9364[51] =  + _REFACS_8_;
	O9364[53] =  + _REFACS_26_;
	O9364[55] =  + _REFACS_27_;
	O9364[59] =  + _REFACS_27_;
	O9364[60] =  + _REFACS_28_;
	O9364[61] =  + _REFACS_27_;
	{long i; for (i = 65; i < 68; i++) O9364[i] =  + _REFACS_28_;}
	{long i; for (i = 72; i < 76; i++) O9364[i] =  + _REFACS_28_;}
	{long i; for (i = 80; i < 82; i++) O9364[i] =  + _REFACS_32_;}
	{long i; for (i = 82; i < 84; i++) O9364[i] =  + _REFACS_35_;}
	O9364[101] =  + _REFACS_26_;
	O9364[102] =  + _REFACS_27_;
	O9364[103] =  + _REFACS_28_;
	O9364[104] =  + _REFACS_30_;
	O9364[105] =  + _REFACS_27_;
	O9364[106] =  + _REFACS_26_;
	{long i; for (i = 107; i < 109; i++) O9364[i] =  + _REFACS_28_;}
	O9364[109] =  + _REFACS_27_;
	O9364[110] =  + _REFACS_28_;
	O9364[111] =  + _REFACS_32_;
	O9364[112] =  + _REFACS_27_;
	O9364[113] =  + _REFACS_30_;
	{long i; for (i = 114; i < 118; i++) O9364[i] =  + _REFACS_27_;}
	{long i; for (i = 126; i < 128; i++) O9364[i] =  + _REFACS_11_;}
	{long i; for (i = 133; i < 137; i++) O9364[i] =  + _REFACS_12_;}
	O9364[137] =  + _REFACS_13_;
	{long i; for (i = 142; i < 144; i++) O9364[i] =  + _REFACS_15_;}
	O9364[150] =  + _REFACS_27_;
	O9364[152] =  + _REFACS_27_;
}

long O9366[153];
void O9366_init () {
	O9366[0] = + _CHROFF_2_1_;
	O9366[1] = + _CHROFF_4_1_;
	O9366[2] = + _CHROFF_5_1_;
	O9366[3] = + _CHROFF_10_1_;
	O9366[18] = + _CHROFF_6_1_;
	O9366[42] = + _CHROFF_8_1_;
	O9366[43] = + _CHROFF_9_1_;
	{long i; for (i = 47; i < 50; i++) O9366[i] = + _CHROFF_11_1_;}
	O9366[51] = + _CHROFF_16_2_;
	O9366[53] = + _CHROFF_42_2_;
	O9366[55] = + _CHROFF_46_2_;
	O9366[59] = + _CHROFF_47_2_;
	O9366[60] = + _CHROFF_49_2_;
	O9366[61] = + _CHROFF_47_2_;
	{long i; for (i = 65; i < 68; i++) O9366[i] = + _CHROFF_49_2_;}
	O9366[72] = + _CHROFF_49_2_;
	O9366[73] = + _CHROFF_51_2_;
	{long i; for (i = 74; i < 76; i++) O9366[i] = + _CHROFF_49_2_;}
	{long i; for (i = 80; i < 82; i++) O9366[i] = + _CHROFF_59_2_;}
	O9366[82] = + _CHROFF_65_2_;
	O9366[83] = + _CHROFF_68_2_;
	O9366[101] = + _CHROFF_42_2_;
	O9366[102] = + _CHROFF_44_2_;
	O9366[103] = + _CHROFF_51_2_;
	O9366[104] = + _CHROFF_58_2_;
	O9366[105] = + _CHROFF_45_2_;
	O9366[106] = + _CHROFF_44_2_;
	O9366[107] = + _CHROFF_50_2_;
	O9366[108] = + _CHROFF_51_2_;
	O9366[109] = + _CHROFF_43_2_;
	O9366[110] = + _CHROFF_46_2_;
	O9366[111] = + _CHROFF_59_2_;
	O9366[112] = + _CHROFF_44_2_;
	O9366[113] = + _CHROFF_51_2_;
	{long i; for (i = 114; i < 118; i++) O9366[i] = + _CHROFF_46_2_;}
	{long i; for (i = 126; i < 128; i++) O9366[i] = + _CHROFF_21_2_;}
	{long i; for (i = 133; i < 136; i++) O9366[i] = + _CHROFF_23_2_;}
	O9366[136] = + _CHROFF_24_2_;
	O9366[137] = + _CHROFF_26_2_;
	{long i; for (i = 142; i < 144; i++) O9366[i] = + _CHROFF_29_2_;}
	O9366[150] = + _CHROFF_48_2_;
	O9366[152] = + _CHROFF_48_2_;
}

long O9398[152];
void O9398_init () {
	{long i; for (i = 0; i < 3; i++) O9398[i] =  + _REFACS_2_;}
	{long i; for (i = 41; i < 43; i++) O9398[i] =  + _REFACS_4_;}
	{long i; for (i = 46; i < 49; i++) O9398[i] =  + _REFACS_4_;}
	O9398[50] =  + _REFACS_9_;
	O9398[52] =  + _REFACS_27_;
	O9398[54] =  + _REFACS_28_;
	O9398[58] =  + _REFACS_28_;
	O9398[59] =  + _REFACS_29_;
	O9398[60] =  + _REFACS_28_;
	{long i; for (i = 64; i < 67; i++) O9398[i] =  + _REFACS_29_;}
	{long i; for (i = 71; i < 75; i++) O9398[i] =  + _REFACS_29_;}
	{long i; for (i = 79; i < 81; i++) O9398[i] =  + _REFACS_33_;}
	{long i; for (i = 81; i < 83; i++) O9398[i] =  + _REFACS_36_;}
	O9398[100] =  + _REFACS_27_;
	O9398[101] =  + _REFACS_28_;
	O9398[102] =  + _REFACS_29_;
	O9398[103] =  + _REFACS_31_;
	O9398[104] =  + _REFACS_28_;
	O9398[105] =  + _REFACS_27_;
	{long i; for (i = 106; i < 108; i++) O9398[i] =  + _REFACS_29_;}
	O9398[108] =  + _REFACS_28_;
	O9398[109] =  + _REFACS_29_;
	O9398[110] =  + _REFACS_33_;
	O9398[111] =  + _REFACS_28_;
	O9398[112] =  + _REFACS_31_;
	{long i; for (i = 113; i < 117; i++) O9398[i] =  + _REFACS_28_;}
	{long i; for (i = 125; i < 127; i++) O9398[i] =  + _REFACS_12_;}
	{long i; for (i = 132; i < 136; i++) O9398[i] =  + _REFACS_13_;}
	O9398[136] =  + _REFACS_14_;
	{long i; for (i = 141; i < 143; i++) O9398[i] =  + _REFACS_16_;}
	O9398[149] =  + _REFACS_28_;
	O9398[151] =  + _REFACS_28_;
}

long O9399[152];
void O9399_init () {
	{long i; for (i = 0; i < 3; i++) O9399[i] =  + _REFACS_3_;}
	{long i; for (i = 41; i < 43; i++) O9399[i] =  + _REFACS_5_;}
	{long i; for (i = 46; i < 49; i++) O9399[i] =  + _REFACS_5_;}
	O9399[50] =  + _REFACS_10_;
	O9399[52] =  + _REFACS_28_;
	O9399[54] =  + _REFACS_29_;
	O9399[58] =  + _REFACS_29_;
	O9399[59] =  + _REFACS_30_;
	O9399[60] =  + _REFACS_29_;
	{long i; for (i = 64; i < 67; i++) O9399[i] =  + _REFACS_30_;}
	{long i; for (i = 71; i < 75; i++) O9399[i] =  + _REFACS_30_;}
	{long i; for (i = 79; i < 81; i++) O9399[i] =  + _REFACS_34_;}
	{long i; for (i = 81; i < 83; i++) O9399[i] =  + _REFACS_37_;}
	O9399[100] =  + _REFACS_28_;
	O9399[101] =  + _REFACS_29_;
	O9399[102] =  + _REFACS_30_;
	O9399[103] =  + _REFACS_32_;
	O9399[104] =  + _REFACS_29_;
	O9399[105] =  + _REFACS_28_;
	{long i; for (i = 106; i < 108; i++) O9399[i] =  + _REFACS_30_;}
	O9399[108] =  + _REFACS_29_;
	O9399[109] =  + _REFACS_30_;
	O9399[110] =  + _REFACS_34_;
	O9399[111] =  + _REFACS_29_;
	O9399[112] =  + _REFACS_32_;
	{long i; for (i = 113; i < 117; i++) O9399[i] =  + _REFACS_29_;}
	{long i; for (i = 125; i < 127; i++) O9399[i] =  + _REFACS_13_;}
	{long i; for (i = 132; i < 136; i++) O9399[i] =  + _REFACS_14_;}
	O9399[136] =  + _REFACS_15_;
	{long i; for (i = 141; i < 143; i++) O9399[i] =  + _REFACS_17_;}
	O9399[149] =  + _REFACS_29_;
	O9399[151] =  + _REFACS_29_;
}

long O9419[82];
void O9419_init () {
	{long i; for (i = 0; i < 2; i++) O9419[i] =  + _REFACS_4_;}
	{long i; for (i = 40; i < 42; i++) O9419[i] =  + _REFACS_6_;}
	{long i; for (i = 45; i < 48; i++) O9419[i] =  + _REFACS_6_;}
	{long i; for (i = 78; i < 80; i++) O9419[i] =  + _REFACS_35_;}
	{long i; for (i = 80; i < 82; i++) O9419[i] =  + _REFACS_38_;}
}

long O9426[82];
void O9426_init () {
	O9426[0] = + _CHROFF_5_2_;
	O9426[1] = + _CHROFF_10_2_;
	O9426[40] = + _CHROFF_8_2_;
	O9426[41] = + _CHROFF_9_2_;
	{long i; for (i = 45; i < 48; i++) O9426[i] = + _CHROFF_11_2_;}
	{long i; for (i = 78; i < 80; i++) O9426[i] = + _CHROFF_59_3_;}
	O9426[80] = + _CHROFF_65_3_;
	O9426[81] = + _CHROFF_68_3_;
}

long O9432[82];
void O9432_init () {
	O9432[0] = + _CHROFF_5_3_;
	O9432[1] = + _CHROFF_10_3_;
	O9432[40] = + _CHROFF_8_3_;
	O9432[41] = + _CHROFF_9_3_;
	{long i; for (i = 45; i < 48; i++) O9432[i] = + _CHROFF_11_3_;}
	{long i; for (i = 78; i < 80; i++) O9432[i] = + _CHROFF_59_4_;}
	O9432[80] = + _CHROFF_65_4_;
	O9432[81] = + _CHROFF_68_4_;
}

long O9482[133];
void O9482_init () {
	O9482[0] = + _LNGOFF_1_1_0_0_;
	O9482[1] = + _LNGOFF_2_1_0_0_;
	{long i; for (i = 2; i < 4; i++) O9482[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 4; i < 6; i++) O9482[i] = + _LNGOFF_2_1_0_0_;}
	O9482[6] = + _LNGOFF_4_1_0_0_;
	O9482[12] = + _LNGOFF_2_1_0_0_;
	O9482[13] = + _LNGOFF_6_3_0_1_;
	O9482[51] = + _LNGOFF_37_9_6_0_;
	O9482[52] = + _LNGOFF_38_9_6_0_;
	O9482[53] = + _LNGOFF_37_9_6_0_;
	O9482[54] = + _LNGOFF_47_12_10_1_;
	O9482[55] = + _LNGOFF_49_12_10_1_;
	O9482[56] = + _LNGOFF_47_12_10_1_;
	{long i; for (i = 57; i < 60; i++) O9482[i] = + _LNGOFF_39_10_6_0_;}
	{long i; for (i = 60; i < 63; i++) O9482[i] = + _LNGOFF_49_13_10_1_;}
	O9482[81] = + _LNGOFF_37_9_6_0_;
	O9482[82] = + _LNGOFF_43_9_6_0_;
	O9482[83] = + _LNGOFF_37_10_6_0_;
	O9482[85] = + _LNGOFF_37_9_6_0_;
	O9482[86] = + _LNGOFF_37_10_6_0_;
	O9482[89] = + _LNGOFF_41_9_6_0_;
	O9482[98] = + _LNGOFF_51_13_10_1_;
	O9482[99] = + _LNGOFF_58_14_10_1_;
	O9482[100] = + _LNGOFF_45_16_10_1_;
	O9482[102] = + _LNGOFF_50_13_10_1_;
	O9482[103] = + _LNGOFF_51_14_10_1_;
	O9482[106] = + _LNGOFF_59_16_10_1_;
	{long i; for (i = 117; i < 119; i++) O9482[i] = + _LNGOFF_20_5_6_0_;}
	{long i; for (i = 119; i < 121; i++) O9482[i] = + _LNGOFF_25_6_6_0_;}
	O9482[127] = + _LNGOFF_18_6_6_0_;
	O9482[132] = + _LNGOFF_26_8_6_1_;
}

long O9516[132];
void O9516_init () {
	O9516[0] =  + _REFACS_1_;
	O9516[4] =  + _REFACS_1_;
	O9516[5] =  + _REFACS_2_;
	O9516[12] =  + _REFACS_3_;
	O9516[53] =  + _REFACS_30_;
	O9516[54] =  + _REFACS_31_;
	O9516[55] =  + _REFACS_30_;
	{long i; for (i = 59; i < 62; i++) O9516[i] =  + _REFACS_31_;}
	O9516[97] =  + _REFACS_31_;
	O9516[98] =  + _REFACS_33_;
	O9516[99] =  + _REFACS_30_;
	{long i; for (i = 101; i < 103; i++) O9516[i] =  + _REFACS_31_;}
	O9516[105] =  + _REFACS_35_;
	{long i; for (i = 118; i < 120; i++) O9516[i] =  + _REFACS_15_;}
	O9516[131] =  + _REFACS_16_;
}

static EIF_TYPE_INDEX Y9516_pgtype0[] = {0xFF01,656,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y9516_pgtype1[] = {0xFF01,656,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y9516_pgtype2[] = {0xFF01,656,0xFF01,1169,0xFFFF};
static EIF_TYPE_INDEX Y9516_pgtype3[] = {0xFF01,656,0xFF01,1169,0xFFFF};
static EIF_TYPE_INDEX Y9516_pgtype4[] = {0xFF01,656,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y9516_pgtype5[] = {0xFF01,656,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y9516_pgtype6[] = {0xFF01,656,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y9516_pgtype7[] = {0xFF01,656,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y9516_pgtype8[] = {0xFF01,656,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y9516_pgtype9[] = {0xFF01,656,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y9516_pgtype10[] = {0xFF01,656,0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y9516_pgtype11[] = {0xFF01,656,0xFF01,1164,0xFFFF};
static EIF_TYPE_INDEX Y9516_pgtype12[] = {0xFF01,656,0xFF01,1165,0xFFFF};
static EIF_TYPE_INDEX Y9516_pgtype13[] = {0xFF01,656,0xFF01,1163,0xFFFF};
static EIF_TYPE_INDEX Y9516_pgtype14[] = {0xFF01,656,0xFF01,1163,0xFFFF};
static EIF_TYPE_INDEX Y9516_pgtype15[] = {0xFF01,656,0xFF01,1163,0xFFFF};
static EIF_TYPE_INDEX Y9516_pgtype16[] = {0xFF01,656,0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y9516_pgtype17[] = {0xFF01,656,0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y9516_pgtype18[] = {0xFF01,656,0xFF01,1169,0xFFFF};
EIF_TYPE_INDEX *Y9516_gen_type [132];
EIF_TYPE_INDEX Y9516 [132];
void Y9516_init (void)
{
	egc_routines_types [9516] = Y9516;
	egc_routines_gen_types [9516] = Y9516_gen_type;
	egc_routines_offset [9516] = 1219;
	Y9516_gen_type [0] = Y9516_pgtype0;
	Y9516_gen_type [4] = Y9516_pgtype1;
	Y9516_gen_type [5] = Y9516_pgtype2;
	Y9516_gen_type [12] = Y9516_pgtype3;
	Y9516_gen_type [53] = Y9516_pgtype4;
	Y9516_gen_type [54] = Y9516_pgtype5;
	Y9516_gen_type [55] = Y9516_pgtype6;
	Y9516_gen_type [59] = Y9516_pgtype7;
	Y9516_gen_type [60] = Y9516_pgtype8;
	Y9516_gen_type [61] = Y9516_pgtype9;
	Y9516_gen_type [97] = Y9516_pgtype10;
	Y9516_gen_type [98] = Y9516_pgtype11;
	Y9516_gen_type [99] = Y9516_pgtype12;
	Y9516_gen_type [101] = Y9516_pgtype13;
	Y9516_gen_type [102] = Y9516_pgtype14;
	Y9516_gen_type [105] = Y9516_pgtype15;
	Y9516_gen_type [118] = Y9516_pgtype16;
	Y9516_gen_type [119] = Y9516_pgtype17;
	Y9516_gen_type [131] = Y9516_pgtype18;
	Y9516[0] = 656;
	{long i; for (i = 4; i < 6; i++) Y9516[i] = 656;};
	Y9516[12] = 656;
	{long i; for (i = 53; i < 56; i++) Y9516[i] = 656;};
	{long i; for (i = 59; i < 62; i++) Y9516[i] = 656;};
	{long i; for (i = 97; i < 100; i++) Y9516[i] = 656;};
	{long i; for (i = 101; i < 103; i++) Y9516[i] = 656;};
	Y9516[105] = 656;
	{long i; for (i = 118; i < 120; i++) Y9516[i] = 656;};
	Y9516[131] = 656;
}

long O9553[140];
void O9553_init () {
	O9553[0] =  + _REFACS_1_;
	O9553[40] =  + _REFACS_29_;
	O9553[42] =  + _REFACS_30_;
	O9553[46] =  + _REFACS_31_;
	O9553[47] =  + _REFACS_32_;
	O9553[48] =  + _REFACS_31_;
	{long i; for (i = 52; i < 55; i++) O9553[i] =  + _REFACS_32_;}
	{long i; for (i = 59; i < 63; i++) O9553[i] =  + _REFACS_31_;}
	{long i; for (i = 67; i < 69; i++) O9553[i] =  + _REFACS_36_;}
	{long i; for (i = 69; i < 71; i++) O9553[i] =  + _REFACS_39_;}
	O9553[88] =  + _REFACS_29_;
	O9553[89] =  + _REFACS_30_;
	O9553[90] =  + _REFACS_32_;
	O9553[91] =  + _REFACS_34_;
	O9553[92] =  + _REFACS_31_;
	O9553[93] =  + _REFACS_29_;
	{long i; for (i = 94; i < 96; i++) O9553[i] =  + _REFACS_32_;}
	O9553[96] =  + _REFACS_30_;
	O9553[97] =  + _REFACS_31_;
	O9553[98] =  + _REFACS_36_;
	O9553[99] =  + _REFACS_30_;
	O9553[100] =  + _REFACS_33_;
	{long i; for (i = 101; i < 105; i++) O9553[i] =  + _REFACS_30_;}
	O9553[137] =  + _REFACS_30_;
	O9553[139] =  + _REFACS_30_;
}

long O9554[140];
void O9554_init () {
	O9554[0] =  + _REFACS_2_;
	O9554[40] =  + _REFACS_30_;
	O9554[42] =  + _REFACS_31_;
	O9554[46] =  + _REFACS_32_;
	O9554[47] =  + _REFACS_33_;
	O9554[48] =  + _REFACS_32_;
	{long i; for (i = 52; i < 55; i++) O9554[i] =  + _REFACS_33_;}
	{long i; for (i = 59; i < 63; i++) O9554[i] =  + _REFACS_32_;}
	{long i; for (i = 67; i < 69; i++) O9554[i] =  + _REFACS_37_;}
	{long i; for (i = 69; i < 71; i++) O9554[i] =  + _REFACS_40_;}
	O9554[88] =  + _REFACS_30_;
	O9554[89] =  + _REFACS_31_;
	O9554[90] =  + _REFACS_33_;
	O9554[91] =  + _REFACS_35_;
	O9554[92] =  + _REFACS_32_;
	O9554[93] =  + _REFACS_30_;
	{long i; for (i = 94; i < 96; i++) O9554[i] =  + _REFACS_33_;}
	O9554[96] =  + _REFACS_31_;
	O9554[97] =  + _REFACS_32_;
	O9554[98] =  + _REFACS_37_;
	O9554[99] =  + _REFACS_31_;
	O9554[100] =  + _REFACS_34_;
	{long i; for (i = 101; i < 105; i++) O9554[i] =  + _REFACS_31_;}
	O9554[137] =  + _REFACS_31_;
	O9554[139] =  + _REFACS_31_;
}

long O9562[139];
void O9562_init () {
	{long i; for (i = 0; i < 2; i++) O9562[i] =  + _REFACS_6_;}
	O9562[38] =  + _REFACS_26_;
	O9562[39] =  + _REFACS_31_;
	O9562[40] =  + _REFACS_27_;
	O9562[41] =  + _REFACS_32_;
	O9562[42] =  + _REFACS_27_;
	O9562[43] =  + _REFACS_28_;
	O9562[44] =  + _REFACS_27_;
	O9562[45] =  + _REFACS_33_;
	O9562[46] =  + _REFACS_34_;
	O9562[47] =  + _REFACS_33_;
	{long i; for (i = 48; i < 51; i++) O9562[i] =  + _REFACS_28_;}
	{long i; for (i = 51; i < 54; i++) O9562[i] =  + _REFACS_34_;}
	{long i; for (i = 54; i < 58; i++) O9562[i] =  + _REFACS_28_;}
	{long i; for (i = 58; i < 62; i++) O9562[i] =  + _REFACS_33_;}
	{long i; for (i = 62; i < 64; i++) O9562[i] =  + _REFACS_32_;}
	{long i; for (i = 64; i < 66; i++) O9562[i] =  + _REFACS_35_;}
	{long i; for (i = 66; i < 68; i++) O9562[i] =  + _REFACS_38_;}
	{long i; for (i = 68; i < 70; i++) O9562[i] =  + _REFACS_41_;}
	O9562[70] =  + _REFACS_26_;
	O9562[71] =  + _REFACS_27_;
	O9562[72] =  + _REFACS_28_;
	O9562[73] =  + _REFACS_30_;
	O9562[74] =  + _REFACS_27_;
	O9562[75] =  + _REFACS_26_;
	{long i; for (i = 76; i < 78; i++) O9562[i] =  + _REFACS_28_;}
	O9562[78] =  + _REFACS_27_;
	O9562[79] =  + _REFACS_28_;
	O9562[80] =  + _REFACS_32_;
	O9562[81] =  + _REFACS_27_;
	O9562[82] =  + _REFACS_30_;
	{long i; for (i = 83; i < 87; i++) O9562[i] =  + _REFACS_27_;}
	O9562[87] =  + _REFACS_31_;
	O9562[88] =  + _REFACS_32_;
	O9562[89] =  + _REFACS_34_;
	O9562[90] =  + _REFACS_36_;
	O9562[91] =  + _REFACS_33_;
	O9562[92] =  + _REFACS_31_;
	{long i; for (i = 93; i < 95; i++) O9562[i] =  + _REFACS_34_;}
	O9562[95] =  + _REFACS_32_;
	O9562[96] =  + _REFACS_33_;
	O9562[97] =  + _REFACS_38_;
	O9562[98] =  + _REFACS_32_;
	O9562[99] =  + _REFACS_35_;
	{long i; for (i = 100; i < 104; i++) O9562[i] =  + _REFACS_32_;}
	{long i; for (i = 126; i < 128; i++) O9562[i] =  + _REFACS_15_;}
	{long i; for (i = 128; i < 130; i++) O9562[i] =  + _REFACS_18_;}
	O9562[131] =  + _REFACS_27_;
	O9562[133] =  + _REFACS_27_;
	O9562[136] =  + _REFACS_32_;
	O9562[138] =  + _REFACS_32_;
}

long O9563[139];
void O9563_init () {
	O9563[0] = + _CHROFF_7_1_;
	O9563[1] = + _CHROFF_8_1_;
	O9563[38] = + _CHROFF_35_1_;
	O9563[39] = + _CHROFF_42_3_;
	O9563[40] = + _CHROFF_37_1_;
	O9563[41] = + _CHROFF_46_3_;
	O9563[42] = + _CHROFF_37_1_;
	O9563[43] = + _CHROFF_38_1_;
	O9563[44] = + _CHROFF_37_1_;
	O9563[45] = + _CHROFF_47_3_;
	O9563[46] = + _CHROFF_49_3_;
	O9563[47] = + _CHROFF_47_3_;
	{long i; for (i = 48; i < 51; i++) O9563[i] = + _CHROFF_39_1_;}
	{long i; for (i = 51; i < 54; i++) O9563[i] = + _CHROFF_49_3_;}
	{long i; for (i = 54; i < 58; i++) O9563[i] = + _CHROFF_39_1_;}
	O9563[58] = + _CHROFF_49_3_;
	O9563[59] = + _CHROFF_51_3_;
	{long i; for (i = 60; i < 62; i++) O9563[i] = + _CHROFF_49_3_;}
	{long i; for (i = 62; i < 64; i++) O9563[i] = + _CHROFF_47_1_;}
	O9563[64] = + _CHROFF_50_1_;
	O9563[65] = + _CHROFF_53_1_;
	{long i; for (i = 66; i < 68; i++) O9563[i] = + _CHROFF_59_5_;}
	O9563[68] = + _CHROFF_65_5_;
	O9563[69] = + _CHROFF_68_5_;
	O9563[70] = + _CHROFF_35_1_;
	{long i; for (i = 71; i < 73; i++) O9563[i] = + _CHROFF_37_1_;}
	O9563[73] = + _CHROFF_43_1_;
	O9563[74] = + _CHROFF_37_1_;
	O9563[75] = + _CHROFF_35_1_;
	{long i; for (i = 76; i < 78; i++) O9563[i] = + _CHROFF_37_1_;}
	O9563[78] = + _CHROFF_36_1_;
	O9563[79] = + _CHROFF_37_1_;
	O9563[80] = + _CHROFF_41_1_;
	O9563[81] = + _CHROFF_36_1_;
	O9563[82] = + _CHROFF_40_1_;
	{long i; for (i = 83; i < 87; i++) O9563[i] = + _CHROFF_36_1_;}
	O9563[87] = + _CHROFF_42_3_;
	O9563[88] = + _CHROFF_44_3_;
	O9563[89] = + _CHROFF_51_3_;
	O9563[90] = + _CHROFF_58_3_;
	O9563[91] = + _CHROFF_45_3_;
	O9563[92] = + _CHROFF_44_3_;
	O9563[93] = + _CHROFF_50_3_;
	O9563[94] = + _CHROFF_51_3_;
	O9563[95] = + _CHROFF_43_3_;
	O9563[96] = + _CHROFF_46_3_;
	O9563[97] = + _CHROFF_59_3_;
	O9563[98] = + _CHROFF_44_3_;
	O9563[99] = + _CHROFF_51_3_;
	{long i; for (i = 100; i < 104; i++) O9563[i] = + _CHROFF_46_3_;}
	{long i; for (i = 126; i < 128; i++) O9563[i] = + _CHROFF_21_1_;}
	{long i; for (i = 128; i < 130; i++) O9563[i] = + _CHROFF_29_3_;}
	O9563[131] = + _CHROFF_36_1_;
	O9563[133] = + _CHROFF_36_1_;
	O9563[136] = + _CHROFF_48_3_;
	O9563[138] = + _CHROFF_48_3_;
}

long O9564[139];
void O9564_init () {
	O9564[0] = + _CHROFF_7_2_;
	O9564[1] = + _CHROFF_8_2_;
	O9564[38] = + _CHROFF_35_2_;
	O9564[39] = + _CHROFF_42_4_;
	O9564[40] = + _CHROFF_37_2_;
	O9564[41] = + _CHROFF_46_4_;
	O9564[42] = + _CHROFF_37_2_;
	O9564[43] = + _CHROFF_38_2_;
	O9564[44] = + _CHROFF_37_2_;
	O9564[45] = + _CHROFF_47_4_;
	O9564[46] = + _CHROFF_49_4_;
	O9564[47] = + _CHROFF_47_4_;
	{long i; for (i = 48; i < 51; i++) O9564[i] = + _CHROFF_39_2_;}
	{long i; for (i = 51; i < 54; i++) O9564[i] = + _CHROFF_49_4_;}
	{long i; for (i = 54; i < 58; i++) O9564[i] = + _CHROFF_39_2_;}
	O9564[58] = + _CHROFF_49_4_;
	O9564[59] = + _CHROFF_51_4_;
	{long i; for (i = 60; i < 62; i++) O9564[i] = + _CHROFF_49_4_;}
	{long i; for (i = 62; i < 64; i++) O9564[i] = + _CHROFF_47_2_;}
	O9564[64] = + _CHROFF_50_2_;
	O9564[65] = + _CHROFF_53_2_;
	{long i; for (i = 66; i < 68; i++) O9564[i] = + _CHROFF_59_6_;}
	O9564[68] = + _CHROFF_65_6_;
	O9564[69] = + _CHROFF_68_6_;
	O9564[70] = + _CHROFF_35_2_;
	{long i; for (i = 71; i < 73; i++) O9564[i] = + _CHROFF_37_2_;}
	O9564[73] = + _CHROFF_43_2_;
	O9564[74] = + _CHROFF_37_2_;
	O9564[75] = + _CHROFF_35_2_;
	{long i; for (i = 76; i < 78; i++) O9564[i] = + _CHROFF_37_2_;}
	O9564[78] = + _CHROFF_36_2_;
	O9564[79] = + _CHROFF_37_2_;
	O9564[80] = + _CHROFF_41_2_;
	O9564[81] = + _CHROFF_36_2_;
	O9564[82] = + _CHROFF_40_2_;
	{long i; for (i = 83; i < 87; i++) O9564[i] = + _CHROFF_36_2_;}
	O9564[87] = + _CHROFF_42_4_;
	O9564[88] = + _CHROFF_44_4_;
	O9564[89] = + _CHROFF_51_4_;
	O9564[90] = + _CHROFF_58_4_;
	O9564[91] = + _CHROFF_45_4_;
	O9564[92] = + _CHROFF_44_4_;
	O9564[93] = + _CHROFF_50_4_;
	O9564[94] = + _CHROFF_51_4_;
	O9564[95] = + _CHROFF_43_4_;
	O9564[96] = + _CHROFF_46_4_;
	O9564[97] = + _CHROFF_59_4_;
	O9564[98] = + _CHROFF_44_4_;
	O9564[99] = + _CHROFF_51_4_;
	{long i; for (i = 100; i < 104; i++) O9564[i] = + _CHROFF_46_4_;}
	{long i; for (i = 126; i < 128; i++) O9564[i] = + _CHROFF_21_2_;}
	{long i; for (i = 128; i < 130; i++) O9564[i] = + _CHROFF_29_4_;}
	O9564[131] = + _CHROFF_36_2_;
	O9564[133] = + _CHROFF_36_2_;
	O9564[136] = + _CHROFF_48_4_;
	O9564[138] = + _CHROFF_48_4_;
}

long O9566[139];
void O9566_init () {
	O9566[0] = + _CHROFF_7_3_;
	O9566[1] = + _CHROFF_8_3_;
	O9566[38] = + _CHROFF_35_3_;
	O9566[39] = + _CHROFF_42_5_;
	O9566[40] = + _CHROFF_37_3_;
	O9566[41] = + _CHROFF_46_5_;
	O9566[42] = + _CHROFF_37_3_;
	O9566[43] = + _CHROFF_38_3_;
	O9566[44] = + _CHROFF_37_3_;
	O9566[45] = + _CHROFF_47_5_;
	O9566[46] = + _CHROFF_49_5_;
	O9566[47] = + _CHROFF_47_5_;
	{long i; for (i = 48; i < 51; i++) O9566[i] = + _CHROFF_39_3_;}
	{long i; for (i = 51; i < 54; i++) O9566[i] = + _CHROFF_49_5_;}
	{long i; for (i = 54; i < 58; i++) O9566[i] = + _CHROFF_39_3_;}
	O9566[58] = + _CHROFF_49_5_;
	O9566[59] = + _CHROFF_51_5_;
	{long i; for (i = 60; i < 62; i++) O9566[i] = + _CHROFF_49_5_;}
	{long i; for (i = 62; i < 64; i++) O9566[i] = + _CHROFF_47_3_;}
	O9566[64] = + _CHROFF_50_3_;
	O9566[65] = + _CHROFF_53_3_;
	{long i; for (i = 66; i < 68; i++) O9566[i] = + _CHROFF_59_7_;}
	O9566[68] = + _CHROFF_65_7_;
	O9566[69] = + _CHROFF_68_7_;
	O9566[70] = + _CHROFF_35_3_;
	{long i; for (i = 71; i < 73; i++) O9566[i] = + _CHROFF_37_3_;}
	O9566[73] = + _CHROFF_43_3_;
	O9566[74] = + _CHROFF_37_3_;
	O9566[75] = + _CHROFF_35_3_;
	{long i; for (i = 76; i < 78; i++) O9566[i] = + _CHROFF_37_3_;}
	O9566[78] = + _CHROFF_36_3_;
	O9566[79] = + _CHROFF_37_3_;
	O9566[80] = + _CHROFF_41_3_;
	O9566[81] = + _CHROFF_36_3_;
	O9566[82] = + _CHROFF_40_3_;
	{long i; for (i = 83; i < 87; i++) O9566[i] = + _CHROFF_36_3_;}
	O9566[87] = + _CHROFF_42_5_;
	O9566[88] = + _CHROFF_44_5_;
	O9566[89] = + _CHROFF_51_5_;
	O9566[90] = + _CHROFF_58_5_;
	O9566[91] = + _CHROFF_45_5_;
	O9566[92] = + _CHROFF_44_5_;
	O9566[93] = + _CHROFF_50_5_;
	O9566[94] = + _CHROFF_51_5_;
	O9566[95] = + _CHROFF_43_5_;
	O9566[96] = + _CHROFF_46_5_;
	O9566[97] = + _CHROFF_59_5_;
	O9566[98] = + _CHROFF_44_5_;
	O9566[99] = + _CHROFF_51_5_;
	{long i; for (i = 100; i < 104; i++) O9566[i] = + _CHROFF_46_5_;}
	{long i; for (i = 126; i < 128; i++) O9566[i] = + _CHROFF_21_3_;}
	{long i; for (i = 128; i < 130; i++) O9566[i] = + _CHROFF_29_5_;}
	O9566[131] = + _CHROFF_36_3_;
	O9566[133] = + _CHROFF_36_3_;
	O9566[136] = + _CHROFF_48_5_;
	O9566[138] = + _CHROFF_48_5_;
}

long O9595[138];
void O9595_init () {
	O9595[0] = + _CHROFF_8_4_;
	O9595[38] = + _CHROFF_42_6_;
	O9595[40] = + _CHROFF_46_6_;
	O9595[44] = + _CHROFF_47_6_;
	O9595[45] = + _CHROFF_49_6_;
	O9595[46] = + _CHROFF_47_6_;
	{long i; for (i = 50; i < 53; i++) O9595[i] = + _CHROFF_49_6_;}
	O9595[57] = + _CHROFF_49_6_;
	O9595[58] = + _CHROFF_51_6_;
	{long i; for (i = 59; i < 61; i++) O9595[i] = + _CHROFF_49_6_;}
	{long i; for (i = 65; i < 67; i++) O9595[i] = + _CHROFF_59_8_;}
	O9595[67] = + _CHROFF_65_8_;
	O9595[68] = + _CHROFF_68_8_;
	O9595[86] = + _CHROFF_42_6_;
	O9595[87] = + _CHROFF_44_6_;
	O9595[88] = + _CHROFF_51_6_;
	O9595[89] = + _CHROFF_58_6_;
	O9595[90] = + _CHROFF_45_6_;
	O9595[91] = + _CHROFF_44_6_;
	O9595[92] = + _CHROFF_50_6_;
	O9595[93] = + _CHROFF_51_6_;
	O9595[94] = + _CHROFF_43_6_;
	O9595[95] = + _CHROFF_46_6_;
	O9595[96] = + _CHROFF_59_6_;
	O9595[97] = + _CHROFF_44_6_;
	O9595[98] = + _CHROFF_51_6_;
	{long i; for (i = 99; i < 103; i++) O9595[i] = + _CHROFF_46_6_;}
	{long i; for (i = 127; i < 129; i++) O9595[i] = + _CHROFF_29_6_;}
	O9595[135] = + _CHROFF_48_6_;
	O9595[137] = + _CHROFF_48_6_;
}

long O9596[138];
void O9596_init () {
	O9596[0] = + _I16OFF_8_6_4_;
	O9596[38] = + _I16OFF_42_12_4_;
	O9596[40] = + _I16OFF_46_12_4_;
	O9596[44] = + _I16OFF_47_12_4_;
	O9596[45] = + _I16OFF_49_12_4_;
	O9596[46] = + _I16OFF_47_12_4_;
	{long i; for (i = 50; i < 53; i++) O9596[i] = + _I16OFF_49_13_4_;}
	O9596[57] = + _I16OFF_49_13_4_;
	O9596[58] = + _I16OFF_51_13_4_;
	{long i; for (i = 59; i < 61; i++) O9596[i] = + _I16OFF_49_14_4_;}
	O9596[65] = + _I16OFF_59_21_4_;
	O9596[66] = + _I16OFF_59_23_4_;
	O9596[67] = + _I16OFF_65_25_4_;
	O9596[68] = + _I16OFF_68_26_4_;
	O9596[86] = + _I16OFF_42_13_4_;
	O9596[87] = + _I16OFF_44_13_4_;
	O9596[88] = + _I16OFF_51_13_4_;
	O9596[89] = + _I16OFF_58_14_4_;
	O9596[90] = + _I16OFF_45_16_4_;
	O9596[91] = + _I16OFF_44_13_4_;
	O9596[92] = + _I16OFF_50_13_4_;
	O9596[93] = + _I16OFF_51_14_4_;
	O9596[94] = + _I16OFF_43_13_4_;
	O9596[95] = + _I16OFF_46_14_4_;
	O9596[96] = + _I16OFF_59_16_4_;
	O9596[97] = + _I16OFF_44_15_4_;
	O9596[98] = + _I16OFF_51_18_4_;
	{long i; for (i = 99; i < 103; i++) O9596[i] = + _I16OFF_46_14_4_;}
	{long i; for (i = 127; i < 129; i++) O9596[i] = + _I16OFF_29_14_4_;}
	O9596[135] = + _I16OFF_48_19_4_;
	O9596[137] = + _I16OFF_48_18_4_;
}

long O9597[138];
void O9597_init () {
	O9597[0] = + _I16OFF_8_6_5_;
	O9597[38] = + _I16OFF_42_12_5_;
	O9597[40] = + _I16OFF_46_12_5_;
	O9597[44] = + _I16OFF_47_12_5_;
	O9597[45] = + _I16OFF_49_12_5_;
	O9597[46] = + _I16OFF_47_12_5_;
	{long i; for (i = 50; i < 53; i++) O9597[i] = + _I16OFF_49_13_5_;}
	O9597[57] = + _I16OFF_49_13_5_;
	O9597[58] = + _I16OFF_51_13_5_;
	{long i; for (i = 59; i < 61; i++) O9597[i] = + _I16OFF_49_14_5_;}
	O9597[65] = + _I16OFF_59_21_5_;
	O9597[66] = + _I16OFF_59_23_5_;
	O9597[67] = + _I16OFF_65_25_5_;
	O9597[68] = + _I16OFF_68_26_5_;
	O9597[86] = + _I16OFF_42_13_5_;
	O9597[87] = + _I16OFF_44_13_5_;
	O9597[88] = + _I16OFF_51_13_5_;
	O9597[89] = + _I16OFF_58_14_5_;
	O9597[90] = + _I16OFF_45_16_5_;
	O9597[91] = + _I16OFF_44_13_5_;
	O9597[92] = + _I16OFF_50_13_5_;
	O9597[93] = + _I16OFF_51_14_5_;
	O9597[94] = + _I16OFF_43_13_5_;
	O9597[95] = + _I16OFF_46_14_5_;
	O9597[96] = + _I16OFF_59_16_5_;
	O9597[97] = + _I16OFF_44_15_5_;
	O9597[98] = + _I16OFF_51_18_5_;
	{long i; for (i = 99; i < 103; i++) O9597[i] = + _I16OFF_46_14_5_;}
	{long i; for (i = 127; i < 129; i++) O9597[i] = + _I16OFF_29_14_5_;}
	O9597[135] = + _I16OFF_48_19_5_;
	O9597[137] = + _I16OFF_48_18_5_;
}

long O9602[138];
void O9602_init () {
	O9602[0] =  + _REFACS_7_;
	O9602[38] =  + _REFACS_32_;
	O9602[40] =  + _REFACS_33_;
	O9602[44] =  + _REFACS_34_;
	O9602[45] =  + _REFACS_35_;
	O9602[46] =  + _REFACS_34_;
	{long i; for (i = 50; i < 53; i++) O9602[i] =  + _REFACS_35_;}
	{long i; for (i = 57; i < 61; i++) O9602[i] =  + _REFACS_34_;}
	{long i; for (i = 65; i < 67; i++) O9602[i] =  + _REFACS_39_;}
	{long i; for (i = 67; i < 69; i++) O9602[i] =  + _REFACS_42_;}
	O9602[86] =  + _REFACS_32_;
	O9602[87] =  + _REFACS_33_;
	O9602[88] =  + _REFACS_35_;
	O9602[89] =  + _REFACS_37_;
	O9602[90] =  + _REFACS_34_;
	O9602[91] =  + _REFACS_32_;
	{long i; for (i = 92; i < 94; i++) O9602[i] =  + _REFACS_35_;}
	O9602[94] =  + _REFACS_33_;
	O9602[95] =  + _REFACS_34_;
	O9602[96] =  + _REFACS_39_;
	O9602[97] =  + _REFACS_33_;
	O9602[98] =  + _REFACS_36_;
	{long i; for (i = 99; i < 103; i++) O9602[i] =  + _REFACS_33_;}
	{long i; for (i = 127; i < 129; i++) O9602[i] =  + _REFACS_19_;}
	O9602[135] =  + _REFACS_33_;
	O9602[137] =  + _REFACS_33_;
}

long O9646[83];
void O9646_init () {
	{long i; for (i = 0; i < 2; i++) O9646[i] =  + _REFACS_2_;}
	{long i; for (i = 39; i < 42; i++) O9646[i] =  + _REFACS_29_;}
	{long i; for (i = 42; i < 45; i++) O9646[i] =  + _REFACS_36_;}
	{long i; for (i = 45; i < 49; i++) O9646[i] =  + _REFACS_29_;}
	{long i; for (i = 49; i < 53; i++) O9646[i] =  + _REFACS_35_;}
	{long i; for (i = 53; i < 55; i++) O9646[i] =  + _REFACS_33_;}
	{long i; for (i = 55; i < 57; i++) O9646[i] =  + _REFACS_36_;}
	{long i; for (i = 57; i < 59; i++) O9646[i] =  + _REFACS_40_;}
	{long i; for (i = 59; i < 61; i++) O9646[i] =  + _REFACS_43_;}
	O9646[65] =  + _REFACS_28_;
	O9646[82] =  + _REFACS_35_;
}

long O9647[83];
void O9647_init () {
	{long i; for (i = 0; i < 2; i++) O9647[i] = + _CHROFF_3_0_;}
	{long i; for (i = 39; i < 42; i++) O9647[i] = + _CHROFF_39_4_;}
	{long i; for (i = 42; i < 45; i++) O9647[i] = + _CHROFF_49_7_;}
	{long i; for (i = 45; i < 49; i++) O9647[i] = + _CHROFF_39_4_;}
	O9647[49] = + _CHROFF_49_7_;
	O9647[50] = + _CHROFF_51_7_;
	{long i; for (i = 51; i < 53; i++) O9647[i] = + _CHROFF_49_7_;}
	{long i; for (i = 53; i < 55; i++) O9647[i] = + _CHROFF_47_4_;}
	O9647[55] = + _CHROFF_50_4_;
	O9647[56] = + _CHROFF_53_4_;
	{long i; for (i = 57; i < 59; i++) O9647[i] = + _CHROFF_59_9_;}
	O9647[59] = + _CHROFF_65_9_;
	O9647[60] = + _CHROFF_68_9_;
	O9647[65] = + _CHROFF_37_4_;
	O9647[82] = + _CHROFF_45_7_;
}

long O9652[128];
void O9652_init () {
	{long i; for (i = 0; i < 2; i++) O9652[i] = + _CHROFF_1_0_;}
	O9652[27] = + _CHROFF_35_4_;
	O9652[28] = + _CHROFF_42_7_;
	O9652[29] = + _CHROFF_37_4_;
	O9652[30] = + _CHROFF_46_7_;
	O9652[31] = + _CHROFF_37_4_;
	O9652[32] = + _CHROFF_38_4_;
	O9652[33] = + _CHROFF_37_4_;
	O9652[34] = + _CHROFF_47_7_;
	O9652[35] = + _CHROFF_49_7_;
	O9652[36] = + _CHROFF_47_7_;
	{long i; for (i = 37; i < 40; i++) O9652[i] = + _CHROFF_39_5_;}
	{long i; for (i = 40; i < 43; i++) O9652[i] = + _CHROFF_49_8_;}
	{long i; for (i = 43; i < 47; i++) O9652[i] = + _CHROFF_39_5_;}
	O9652[47] = + _CHROFF_49_8_;
	O9652[48] = + _CHROFF_51_8_;
	{long i; for (i = 49; i < 51; i++) O9652[i] = + _CHROFF_49_8_;}
	{long i; for (i = 51; i < 53; i++) O9652[i] = + _CHROFF_47_5_;}
	O9652[53] = + _CHROFF_50_5_;
	O9652[54] = + _CHROFF_53_5_;
	{long i; for (i = 55; i < 57; i++) O9652[i] = + _CHROFF_59_10_;}
	O9652[57] = + _CHROFF_65_10_;
	O9652[58] = + _CHROFF_68_10_;
	O9652[59] = + _CHROFF_35_4_;
	{long i; for (i = 60; i < 62; i++) O9652[i] = + _CHROFF_37_4_;}
	O9652[62] = + _CHROFF_43_4_;
	O9652[63] = + _CHROFF_37_5_;
	O9652[64] = + _CHROFF_35_4_;
	{long i; for (i = 65; i < 67; i++) O9652[i] = + _CHROFF_37_4_;}
	O9652[67] = + _CHROFF_36_4_;
	O9652[68] = + _CHROFF_37_4_;
	O9652[69] = + _CHROFF_41_4_;
	O9652[70] = + _CHROFF_36_4_;
	O9652[71] = + _CHROFF_40_4_;
	{long i; for (i = 72; i < 76; i++) O9652[i] = + _CHROFF_36_4_;}
	O9652[76] = + _CHROFF_42_7_;
	O9652[77] = + _CHROFF_44_7_;
	O9652[78] = + _CHROFF_51_7_;
	O9652[79] = + _CHROFF_58_7_;
	O9652[80] = + _CHROFF_45_8_;
	O9652[81] = + _CHROFF_44_7_;
	O9652[82] = + _CHROFF_50_7_;
	O9652[83] = + _CHROFF_51_7_;
	O9652[84] = + _CHROFF_43_7_;
	O9652[85] = + _CHROFF_46_7_;
	O9652[86] = + _CHROFF_59_7_;
	O9652[87] = + _CHROFF_44_7_;
	O9652[88] = + _CHROFF_51_7_;
	{long i; for (i = 89; i < 93; i++) O9652[i] = + _CHROFF_46_7_;}
	{long i; for (i = 103; i < 107; i++) O9652[i] = + _CHROFF_17_1_;}
	O9652[107] = + _CHROFF_18_1_;
	{long i; for (i = 108; i < 111; i++) O9652[i] = + _CHROFF_23_3_;}
	O9652[111] = + _CHROFF_24_3_;
	O9652[112] = + _CHROFF_26_3_;
	{long i; for (i = 115; i < 117; i++) O9652[i] = + _CHROFF_21_4_;}
	{long i; for (i = 117; i < 119; i++) O9652[i] = + _CHROFF_29_7_;}
	O9652[120] = + _CHROFF_36_4_;
	O9652[122] = + _CHROFF_36_4_;
	O9652[125] = + _CHROFF_48_7_;
	O9652[127] = + _CHROFF_48_7_;
}

long O9679[111];
void O9679_init () {
	O9679[0] =  + _REFACS_1_;
	{long i; for (i = 81; i < 85; i++) O9679[i] =  + _REFACS_34_;}
	{long i; for (i = 93; i < 95; i++) O9679[i] =  + _REFACS_14_;}
	{long i; for (i = 100; i < 104; i++) O9679[i] =  + _REFACS_15_;}
	O9679[104] =  + _REFACS_18_;
	{long i; for (i = 109; i < 111; i++) O9679[i] =  + _REFACS_20_;}
}


#ifdef __cplusplus
}
#endif
