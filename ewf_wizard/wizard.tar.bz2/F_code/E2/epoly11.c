#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O9681[111];
void O9681_init () {
	O9681[0] = + _PTROFF_2_1_0_0_0_0_;
	{long i; for (i = 81; i < 85; i++) O9681[i] = + _PTROFF_46_14_10_6_0_1_;}
	{long i; for (i = 93; i < 95; i++) O9681[i] = + _PTROFF_21_7_6_1_0_1_;}
	O9681[100] = + _PTROFF_23_8_6_1_0_1_;
	{long i; for (i = 101; i < 103; i++) O9681[i] = + _PTROFF_23_9_6_1_0_1_;}
	O9681[103] = + _PTROFF_24_9_6_1_0_1_;
	O9681[104] = + _PTROFF_26_8_6_2_0_1_;
	{long i; for (i = 109; i < 111; i++) O9681[i] = + _PTROFF_29_14_8_2_0_1_;}
}

long O9686[83];
void O9686_init () {
	O9686[0] =  + _REFACS_1_;
	O9686[25] =  + _REFACS_36_;
	O9686[38] =  + _REFACS_36_;
	O9686[71] =  + _REFACS_33_;
	O9686[75] =  + _REFACS_35_;
	O9686[76] =  + _REFACS_40_;
	O9686[77] =  + _REFACS_34_;
	O9686[78] =  + _REFACS_37_;
	{long i; for (i = 79; i < 83; i++) O9686[i] =  + _REFACS_35_;}
}

long O9695[101];
void O9695_init () {
	O9695[0] = + _PTROFF_2_1_0_0_0_0_;
	O9695[69] = + _PTROFF_44_13_10_6_1_1_;
	{long i; for (i = 77; i < 81; i++) O9695[i] = + _PTROFF_46_14_10_6_0_2_;}
	O9695[96] = + _PTROFF_23_8_6_1_0_2_;
	{long i; for (i = 97; i < 99; i++) O9695[i] = + _PTROFF_23_9_6_1_0_2_;}
	O9695[99] = + _PTROFF_24_9_6_1_0_2_;
	O9695[100] = + _PTROFF_26_8_6_2_0_2_;
}

long O9697[101];
void O9697_init () {
	O9697[0] =  + _REFACS_1_;
	O9697[69] =  + _REFACS_34_;
	{long i; for (i = 77; i < 81; i++) O9697[i] =  + _REFACS_36_;}
	{long i; for (i = 96; i < 100; i++) O9697[i] =  + _REFACS_16_;}
	O9697[100] =  + _REFACS_19_;
}

long O9743[103];
void O9743_init () {
	O9743[0] =  + _REFACS_8_;
	O9743[1] =  + _REFACS_11_;
	O9743[2] =  + _REFACS_27_;
	O9743[3] =  + _REFACS_33_;
	O9743[4] =  + _REFACS_28_;
	O9743[5] =  + _REFACS_34_;
	O9743[6] =  + _REFACS_28_;
	O9743[7] =  + _REFACS_29_;
	O9743[8] =  + _REFACS_28_;
	O9743[9] =  + _REFACS_35_;
	O9743[10] =  + _REFACS_37_;
	O9743[11] =  + _REFACS_35_;
	{long i; for (i = 12; i < 15; i++) O9743[i] =  + _REFACS_30_;}
	{long i; for (i = 15; i < 18; i++) O9743[i] =  + _REFACS_37_;}
	{long i; for (i = 18; i < 22; i++) O9743[i] =  + _REFACS_30_;}
	O9743[22] =  + _REFACS_36_;
	O9743[23] =  + _REFACS_37_;
	{long i; for (i = 24; i < 26; i++) O9743[i] =  + _REFACS_36_;}
	{long i; for (i = 26; i < 28; i++) O9743[i] =  + _REFACS_34_;}
	{long i; for (i = 28; i < 30; i++) O9743[i] =  + _REFACS_37_;}
	{long i; for (i = 30; i < 32; i++) O9743[i] =  + _REFACS_41_;}
	{long i; for (i = 32; i < 34; i++) O9743[i] =  + _REFACS_44_;}
	O9743[34] =  + _REFACS_27_;
	O9743[35] =  + _REFACS_28_;
	O9743[36] =  + _REFACS_29_;
	O9743[37] =  + _REFACS_31_;
	O9743[38] =  + _REFACS_29_;
	O9743[39] =  + _REFACS_27_;
	{long i; for (i = 40; i < 42; i++) O9743[i] =  + _REFACS_29_;}
	O9743[42] =  + _REFACS_28_;
	O9743[43] =  + _REFACS_29_;
	O9743[44] =  + _REFACS_33_;
	O9743[45] =  + _REFACS_28_;
	O9743[46] =  + _REFACS_31_;
	{long i; for (i = 47; i < 51; i++) O9743[i] =  + _REFACS_28_;}
	O9743[51] =  + _REFACS_33_;
	O9743[52] =  + _REFACS_34_;
	O9743[53] =  + _REFACS_36_;
	O9743[54] =  + _REFACS_38_;
	O9743[55] =  + _REFACS_36_;
	O9743[56] =  + _REFACS_35_;
	{long i; for (i = 57; i < 59; i++) O9743[i] =  + _REFACS_36_;}
	O9743[59] =  + _REFACS_34_;
	O9743[60] =  + _REFACS_36_;
	O9743[61] =  + _REFACS_41_;
	O9743[62] =  + _REFACS_35_;
	O9743[63] =  + _REFACS_38_;
	{long i; for (i = 64; i < 68; i++) O9743[i] =  + _REFACS_37_;}
	O9743[68] =  + _REFACS_11_;
	{long i; for (i = 69; i < 71; i++) O9743[i] =  + _REFACS_13_;}
	O9743[71] =  + _REFACS_11_;
	{long i; for (i = 72; i < 74; i++) O9743[i] =  + _REFACS_15_;}
	{long i; for (i = 74; i < 76; i++) O9743[i] =  + _REFACS_16_;}
	{long i; for (i = 76; i < 78; i++) O9743[i] =  + _REFACS_15_;}
	{long i; for (i = 78; i < 82; i++) O9743[i] =  + _REFACS_12_;}
	O9743[82] =  + _REFACS_13_;
	{long i; for (i = 83; i < 87; i++) O9743[i] =  + _REFACS_17_;}
	O9743[87] =  + _REFACS_20_;
	{long i; for (i = 88; i < 90; i++) O9743[i] =  + _REFACS_13_;}
	{long i; for (i = 90; i < 92; i++) O9743[i] =  + _REFACS_16_;}
	{long i; for (i = 92; i < 94; i++) O9743[i] =  + _REFACS_21_;}
	O9743[95] =  + _REFACS_28_;
	O9743[97] =  + _REFACS_28_;
	O9743[100] =  + _REFACS_34_;
	O9743[102] =  + _REFACS_34_;
}

long O9744[103];
void O9744_init () {
	O9744[0] =  + _REFACS_9_;
	O9744[1] =  + _REFACS_12_;
	O9744[2] =  + _REFACS_28_;
	O9744[3] =  + _REFACS_34_;
	O9744[4] =  + _REFACS_29_;
	O9744[5] =  + _REFACS_35_;
	O9744[6] =  + _REFACS_29_;
	O9744[7] =  + _REFACS_30_;
	O9744[8] =  + _REFACS_29_;
	O9744[9] =  + _REFACS_36_;
	O9744[10] =  + _REFACS_38_;
	O9744[11] =  + _REFACS_36_;
	{long i; for (i = 12; i < 15; i++) O9744[i] =  + _REFACS_31_;}
	{long i; for (i = 15; i < 18; i++) O9744[i] =  + _REFACS_38_;}
	{long i; for (i = 18; i < 22; i++) O9744[i] =  + _REFACS_31_;}
	O9744[22] =  + _REFACS_37_;
	O9744[23] =  + _REFACS_38_;
	{long i; for (i = 24; i < 26; i++) O9744[i] =  + _REFACS_37_;}
	{long i; for (i = 26; i < 28; i++) O9744[i] =  + _REFACS_35_;}
	{long i; for (i = 28; i < 30; i++) O9744[i] =  + _REFACS_38_;}
	{long i; for (i = 30; i < 32; i++) O9744[i] =  + _REFACS_42_;}
	{long i; for (i = 32; i < 34; i++) O9744[i] =  + _REFACS_45_;}
	O9744[34] =  + _REFACS_28_;
	O9744[35] =  + _REFACS_29_;
	O9744[36] =  + _REFACS_30_;
	O9744[37] =  + _REFACS_32_;
	O9744[38] =  + _REFACS_30_;
	O9744[39] =  + _REFACS_28_;
	{long i; for (i = 40; i < 42; i++) O9744[i] =  + _REFACS_30_;}
	O9744[42] =  + _REFACS_29_;
	O9744[43] =  + _REFACS_30_;
	O9744[44] =  + _REFACS_34_;
	O9744[45] =  + _REFACS_29_;
	O9744[46] =  + _REFACS_32_;
	{long i; for (i = 47; i < 51; i++) O9744[i] =  + _REFACS_29_;}
	O9744[51] =  + _REFACS_34_;
	O9744[52] =  + _REFACS_35_;
	O9744[53] =  + _REFACS_37_;
	O9744[54] =  + _REFACS_39_;
	O9744[55] =  + _REFACS_37_;
	O9744[56] =  + _REFACS_36_;
	{long i; for (i = 57; i < 59; i++) O9744[i] =  + _REFACS_37_;}
	O9744[59] =  + _REFACS_35_;
	O9744[60] =  + _REFACS_37_;
	O9744[61] =  + _REFACS_42_;
	O9744[62] =  + _REFACS_36_;
	O9744[63] =  + _REFACS_39_;
	{long i; for (i = 64; i < 68; i++) O9744[i] =  + _REFACS_38_;}
	O9744[68] =  + _REFACS_12_;
	{long i; for (i = 69; i < 71; i++) O9744[i] =  + _REFACS_14_;}
	O9744[71] =  + _REFACS_12_;
	{long i; for (i = 72; i < 74; i++) O9744[i] =  + _REFACS_16_;}
	{long i; for (i = 74; i < 76; i++) O9744[i] =  + _REFACS_17_;}
	{long i; for (i = 76; i < 78; i++) O9744[i] =  + _REFACS_16_;}
	{long i; for (i = 78; i < 82; i++) O9744[i] =  + _REFACS_13_;}
	O9744[82] =  + _REFACS_14_;
	{long i; for (i = 83; i < 87; i++) O9744[i] =  + _REFACS_18_;}
	O9744[87] =  + _REFACS_21_;
	{long i; for (i = 88; i < 90; i++) O9744[i] =  + _REFACS_14_;}
	{long i; for (i = 90; i < 92; i++) O9744[i] =  + _REFACS_17_;}
	{long i; for (i = 92; i < 94; i++) O9744[i] =  + _REFACS_22_;}
	O9744[95] =  + _REFACS_29_;
	O9744[97] =  + _REFACS_29_;
	O9744[100] =  + _REFACS_35_;
	O9744[102] =  + _REFACS_35_;
}

long O9746[103];
void O9746_init () {
	O9746[0] =  + _REFACS_10_;
	O9746[1] =  + _REFACS_13_;
	O9746[2] =  + _REFACS_29_;
	O9746[3] =  + _REFACS_35_;
	O9746[4] =  + _REFACS_30_;
	O9746[5] =  + _REFACS_36_;
	O9746[6] =  + _REFACS_30_;
	O9746[7] =  + _REFACS_31_;
	O9746[8] =  + _REFACS_30_;
	O9746[9] =  + _REFACS_37_;
	O9746[10] =  + _REFACS_39_;
	O9746[11] =  + _REFACS_37_;
	{long i; for (i = 12; i < 15; i++) O9746[i] =  + _REFACS_32_;}
	{long i; for (i = 15; i < 18; i++) O9746[i] =  + _REFACS_39_;}
	{long i; for (i = 18; i < 22; i++) O9746[i] =  + _REFACS_32_;}
	O9746[22] =  + _REFACS_38_;
	O9746[23] =  + _REFACS_39_;
	{long i; for (i = 24; i < 26; i++) O9746[i] =  + _REFACS_38_;}
	{long i; for (i = 26; i < 28; i++) O9746[i] =  + _REFACS_36_;}
	{long i; for (i = 28; i < 30; i++) O9746[i] =  + _REFACS_39_;}
	{long i; for (i = 30; i < 32; i++) O9746[i] =  + _REFACS_43_;}
	{long i; for (i = 32; i < 34; i++) O9746[i] =  + _REFACS_46_;}
	O9746[34] =  + _REFACS_29_;
	O9746[35] =  + _REFACS_30_;
	O9746[36] =  + _REFACS_31_;
	O9746[37] =  + _REFACS_33_;
	O9746[38] =  + _REFACS_31_;
	O9746[39] =  + _REFACS_29_;
	{long i; for (i = 40; i < 42; i++) O9746[i] =  + _REFACS_31_;}
	O9746[42] =  + _REFACS_30_;
	O9746[43] =  + _REFACS_31_;
	O9746[44] =  + _REFACS_35_;
	O9746[45] =  + _REFACS_30_;
	O9746[46] =  + _REFACS_33_;
	{long i; for (i = 47; i < 51; i++) O9746[i] =  + _REFACS_30_;}
	O9746[51] =  + _REFACS_35_;
	O9746[52] =  + _REFACS_36_;
	O9746[53] =  + _REFACS_38_;
	O9746[54] =  + _REFACS_40_;
	O9746[55] =  + _REFACS_38_;
	O9746[56] =  + _REFACS_37_;
	{long i; for (i = 57; i < 59; i++) O9746[i] =  + _REFACS_38_;}
	O9746[59] =  + _REFACS_36_;
	O9746[60] =  + _REFACS_38_;
	O9746[61] =  + _REFACS_43_;
	O9746[62] =  + _REFACS_37_;
	O9746[63] =  + _REFACS_40_;
	{long i; for (i = 64; i < 68; i++) O9746[i] =  + _REFACS_39_;}
	O9746[68] =  + _REFACS_13_;
	{long i; for (i = 69; i < 71; i++) O9746[i] =  + _REFACS_15_;}
	O9746[71] =  + _REFACS_13_;
	{long i; for (i = 72; i < 74; i++) O9746[i] =  + _REFACS_17_;}
	{long i; for (i = 74; i < 76; i++) O9746[i] =  + _REFACS_18_;}
	{long i; for (i = 76; i < 78; i++) O9746[i] =  + _REFACS_17_;}
	{long i; for (i = 78; i < 82; i++) O9746[i] =  + _REFACS_14_;}
	O9746[82] =  + _REFACS_15_;
	{long i; for (i = 83; i < 87; i++) O9746[i] =  + _REFACS_19_;}
	O9746[87] =  + _REFACS_22_;
	{long i; for (i = 88; i < 90; i++) O9746[i] =  + _REFACS_15_;}
	{long i; for (i = 90; i < 92; i++) O9746[i] =  + _REFACS_18_;}
	{long i; for (i = 92; i < 94; i++) O9746[i] =  + _REFACS_23_;}
	O9746[95] =  + _REFACS_30_;
	O9746[97] =  + _REFACS_30_;
	O9746[100] =  + _REFACS_36_;
	O9746[102] =  + _REFACS_36_;
}

long O9747[103];
void O9747_init () {
	O9747[0] =  + _REFACS_11_;
	O9747[1] =  + _REFACS_14_;
	O9747[2] =  + _REFACS_30_;
	O9747[3] =  + _REFACS_36_;
	O9747[4] =  + _REFACS_31_;
	O9747[5] =  + _REFACS_37_;
	O9747[6] =  + _REFACS_31_;
	O9747[7] =  + _REFACS_32_;
	O9747[8] =  + _REFACS_31_;
	O9747[9] =  + _REFACS_38_;
	O9747[10] =  + _REFACS_40_;
	O9747[11] =  + _REFACS_38_;
	{long i; for (i = 12; i < 15; i++) O9747[i] =  + _REFACS_33_;}
	{long i; for (i = 15; i < 18; i++) O9747[i] =  + _REFACS_40_;}
	{long i; for (i = 18; i < 22; i++) O9747[i] =  + _REFACS_33_;}
	O9747[22] =  + _REFACS_39_;
	O9747[23] =  + _REFACS_40_;
	{long i; for (i = 24; i < 26; i++) O9747[i] =  + _REFACS_39_;}
	{long i; for (i = 26; i < 28; i++) O9747[i] =  + _REFACS_37_;}
	{long i; for (i = 28; i < 30; i++) O9747[i] =  + _REFACS_40_;}
	{long i; for (i = 30; i < 32; i++) O9747[i] =  + _REFACS_44_;}
	{long i; for (i = 32; i < 34; i++) O9747[i] =  + _REFACS_47_;}
	O9747[34] =  + _REFACS_30_;
	O9747[35] =  + _REFACS_31_;
	O9747[36] =  + _REFACS_32_;
	O9747[37] =  + _REFACS_34_;
	O9747[38] =  + _REFACS_32_;
	O9747[39] =  + _REFACS_30_;
	{long i; for (i = 40; i < 42; i++) O9747[i] =  + _REFACS_32_;}
	O9747[42] =  + _REFACS_31_;
	O9747[43] =  + _REFACS_32_;
	O9747[44] =  + _REFACS_36_;
	O9747[45] =  + _REFACS_31_;
	O9747[46] =  + _REFACS_34_;
	{long i; for (i = 47; i < 51; i++) O9747[i] =  + _REFACS_31_;}
	O9747[51] =  + _REFACS_36_;
	O9747[52] =  + _REFACS_37_;
	O9747[53] =  + _REFACS_39_;
	O9747[54] =  + _REFACS_41_;
	O9747[55] =  + _REFACS_39_;
	O9747[56] =  + _REFACS_38_;
	{long i; for (i = 57; i < 59; i++) O9747[i] =  + _REFACS_39_;}
	O9747[59] =  + _REFACS_37_;
	O9747[60] =  + _REFACS_39_;
	O9747[61] =  + _REFACS_44_;
	O9747[62] =  + _REFACS_38_;
	O9747[63] =  + _REFACS_41_;
	{long i; for (i = 64; i < 68; i++) O9747[i] =  + _REFACS_40_;}
	O9747[68] =  + _REFACS_14_;
	{long i; for (i = 69; i < 71; i++) O9747[i] =  + _REFACS_16_;}
	O9747[71] =  + _REFACS_14_;
	{long i; for (i = 72; i < 74; i++) O9747[i] =  + _REFACS_18_;}
	{long i; for (i = 74; i < 76; i++) O9747[i] =  + _REFACS_19_;}
	{long i; for (i = 76; i < 78; i++) O9747[i] =  + _REFACS_18_;}
	{long i; for (i = 78; i < 82; i++) O9747[i] =  + _REFACS_15_;}
	O9747[82] =  + _REFACS_16_;
	{long i; for (i = 83; i < 87; i++) O9747[i] =  + _REFACS_20_;}
	O9747[87] =  + _REFACS_23_;
	{long i; for (i = 88; i < 90; i++) O9747[i] =  + _REFACS_16_;}
	{long i; for (i = 90; i < 92; i++) O9747[i] =  + _REFACS_19_;}
	{long i; for (i = 92; i < 94; i++) O9747[i] =  + _REFACS_24_;}
	O9747[95] =  + _REFACS_31_;
	O9747[97] =  + _REFACS_31_;
	O9747[100] =  + _REFACS_37_;
	O9747[102] =  + _REFACS_37_;
}

long O9748[103];
void O9748_init () {
	O9748[0] =  + _REFACS_12_;
	O9748[1] =  + _REFACS_15_;
	O9748[2] =  + _REFACS_31_;
	O9748[3] =  + _REFACS_37_;
	O9748[4] =  + _REFACS_32_;
	O9748[5] =  + _REFACS_38_;
	O9748[6] =  + _REFACS_32_;
	O9748[7] =  + _REFACS_33_;
	O9748[8] =  + _REFACS_32_;
	O9748[9] =  + _REFACS_39_;
	O9748[10] =  + _REFACS_41_;
	O9748[11] =  + _REFACS_39_;
	{long i; for (i = 12; i < 15; i++) O9748[i] =  + _REFACS_34_;}
	{long i; for (i = 15; i < 18; i++) O9748[i] =  + _REFACS_41_;}
	{long i; for (i = 18; i < 22; i++) O9748[i] =  + _REFACS_34_;}
	O9748[22] =  + _REFACS_40_;
	O9748[23] =  + _REFACS_41_;
	{long i; for (i = 24; i < 26; i++) O9748[i] =  + _REFACS_40_;}
	{long i; for (i = 26; i < 28; i++) O9748[i] =  + _REFACS_38_;}
	{long i; for (i = 28; i < 30; i++) O9748[i] =  + _REFACS_41_;}
	{long i; for (i = 30; i < 32; i++) O9748[i] =  + _REFACS_45_;}
	{long i; for (i = 32; i < 34; i++) O9748[i] =  + _REFACS_48_;}
	O9748[34] =  + _REFACS_31_;
	O9748[35] =  + _REFACS_32_;
	O9748[36] =  + _REFACS_33_;
	O9748[37] =  + _REFACS_35_;
	O9748[38] =  + _REFACS_33_;
	O9748[39] =  + _REFACS_31_;
	{long i; for (i = 40; i < 42; i++) O9748[i] =  + _REFACS_33_;}
	O9748[42] =  + _REFACS_32_;
	O9748[43] =  + _REFACS_33_;
	O9748[44] =  + _REFACS_37_;
	O9748[45] =  + _REFACS_32_;
	O9748[46] =  + _REFACS_35_;
	{long i; for (i = 47; i < 51; i++) O9748[i] =  + _REFACS_32_;}
	O9748[51] =  + _REFACS_37_;
	O9748[52] =  + _REFACS_38_;
	O9748[53] =  + _REFACS_40_;
	O9748[54] =  + _REFACS_42_;
	O9748[55] =  + _REFACS_40_;
	O9748[56] =  + _REFACS_39_;
	{long i; for (i = 57; i < 59; i++) O9748[i] =  + _REFACS_40_;}
	O9748[59] =  + _REFACS_38_;
	O9748[60] =  + _REFACS_40_;
	O9748[61] =  + _REFACS_45_;
	O9748[62] =  + _REFACS_39_;
	O9748[63] =  + _REFACS_42_;
	{long i; for (i = 64; i < 68; i++) O9748[i] =  + _REFACS_41_;}
	O9748[68] =  + _REFACS_15_;
	{long i; for (i = 69; i < 71; i++) O9748[i] =  + _REFACS_17_;}
	O9748[71] =  + _REFACS_15_;
	{long i; for (i = 72; i < 74; i++) O9748[i] =  + _REFACS_19_;}
	{long i; for (i = 74; i < 76; i++) O9748[i] =  + _REFACS_20_;}
	{long i; for (i = 76; i < 78; i++) O9748[i] =  + _REFACS_19_;}
	{long i; for (i = 78; i < 82; i++) O9748[i] =  + _REFACS_16_;}
	O9748[82] =  + _REFACS_17_;
	{long i; for (i = 83; i < 87; i++) O9748[i] =  + _REFACS_21_;}
	O9748[87] =  + _REFACS_24_;
	{long i; for (i = 88; i < 90; i++) O9748[i] =  + _REFACS_17_;}
	{long i; for (i = 90; i < 92; i++) O9748[i] =  + _REFACS_20_;}
	{long i; for (i = 92; i < 94; i++) O9748[i] =  + _REFACS_25_;}
	O9748[95] =  + _REFACS_32_;
	O9748[97] =  + _REFACS_32_;
	O9748[100] =  + _REFACS_38_;
	O9748[102] =  + _REFACS_38_;
}

long O9768[103];
void O9768_init () {
	O9768[0] = + _CHROFF_13_1_;
	O9768[1] = + _CHROFF_16_3_;
	O9768[2] = + _CHROFF_35_5_;
	O9768[3] = + _CHROFF_42_8_;
	O9768[4] = + _CHROFF_37_5_;
	O9768[5] = + _CHROFF_46_8_;
	O9768[6] = + _CHROFF_37_5_;
	O9768[7] = + _CHROFF_38_5_;
	O9768[8] = + _CHROFF_37_5_;
	O9768[9] = + _CHROFF_47_8_;
	O9768[10] = + _CHROFF_49_8_;
	O9768[11] = + _CHROFF_47_8_;
	{long i; for (i = 12; i < 15; i++) O9768[i] = + _CHROFF_39_6_;}
	{long i; for (i = 15; i < 18; i++) O9768[i] = + _CHROFF_49_9_;}
	{long i; for (i = 18; i < 22; i++) O9768[i] = + _CHROFF_39_6_;}
	O9768[22] = + _CHROFF_49_9_;
	O9768[23] = + _CHROFF_51_9_;
	{long i; for (i = 24; i < 26; i++) O9768[i] = + _CHROFF_49_9_;}
	{long i; for (i = 26; i < 28; i++) O9768[i] = + _CHROFF_47_6_;}
	O9768[28] = + _CHROFF_50_6_;
	O9768[29] = + _CHROFF_53_6_;
	{long i; for (i = 30; i < 32; i++) O9768[i] = + _CHROFF_59_11_;}
	O9768[32] = + _CHROFF_65_11_;
	O9768[33] = + _CHROFF_68_11_;
	O9768[34] = + _CHROFF_35_5_;
	{long i; for (i = 35; i < 37; i++) O9768[i] = + _CHROFF_37_5_;}
	O9768[37] = + _CHROFF_43_5_;
	O9768[38] = + _CHROFF_37_6_;
	O9768[39] = + _CHROFF_35_5_;
	{long i; for (i = 40; i < 42; i++) O9768[i] = + _CHROFF_37_5_;}
	O9768[42] = + _CHROFF_36_5_;
	O9768[43] = + _CHROFF_37_5_;
	O9768[44] = + _CHROFF_41_5_;
	O9768[45] = + _CHROFF_36_5_;
	O9768[46] = + _CHROFF_40_5_;
	{long i; for (i = 47; i < 51; i++) O9768[i] = + _CHROFF_36_5_;}
	O9768[51] = + _CHROFF_42_8_;
	O9768[52] = + _CHROFF_44_8_;
	O9768[53] = + _CHROFF_51_8_;
	O9768[54] = + _CHROFF_58_8_;
	O9768[55] = + _CHROFF_45_9_;
	O9768[56] = + _CHROFF_44_8_;
	O9768[57] = + _CHROFF_50_8_;
	O9768[58] = + _CHROFF_51_8_;
	O9768[59] = + _CHROFF_43_8_;
	O9768[60] = + _CHROFF_46_8_;
	O9768[61] = + _CHROFF_59_8_;
	O9768[62] = + _CHROFF_44_8_;
	O9768[63] = + _CHROFF_51_8_;
	{long i; for (i = 64; i < 68; i++) O9768[i] = + _CHROFF_46_8_;}
	O9768[68] = + _CHROFF_16_1_;
	O9768[69] = + _CHROFF_18_1_;
	O9768[70] = + _CHROFF_23_1_;
	O9768[71] = + _CHROFF_16_1_;
	{long i; for (i = 72; i < 74; i++) O9768[i] = + _CHROFF_20_1_;}
	{long i; for (i = 74; i < 76; i++) O9768[i] = + _CHROFF_25_1_;}
	{long i; for (i = 76; i < 78; i++) O9768[i] = + _CHROFF_21_3_;}
	{long i; for (i = 78; i < 82; i++) O9768[i] = + _CHROFF_17_2_;}
	O9768[82] = + _CHROFF_18_2_;
	{long i; for (i = 83; i < 86; i++) O9768[i] = + _CHROFF_23_4_;}
	O9768[86] = + _CHROFF_24_4_;
	O9768[87] = + _CHROFF_26_4_;
	O9768[88] = + _CHROFF_19_1_;
	O9768[89] = + _CHROFF_22_1_;
	{long i; for (i = 90; i < 92; i++) O9768[i] = + _CHROFF_21_5_;}
	{long i; for (i = 92; i < 94; i++) O9768[i] = + _CHROFF_29_8_;}
	O9768[95] = + _CHROFF_36_5_;
	O9768[97] = + _CHROFF_36_5_;
	O9768[100] = + _CHROFF_48_8_;
	O9768[102] = + _CHROFF_48_8_;
}

long O9773[103];
void O9773_init () {
	O9773[0] = + _I16OFF_13_5_4_;
	O9773[1] = + _I16OFF_16_7_4_;
	O9773[2] = + _I16OFF_35_9_4_;
	O9773[3] = + _I16OFF_42_12_6_;
	O9773[4] = + _I16OFF_37_9_4_;
	O9773[5] = + _I16OFF_46_12_6_;
	O9773[6] = + _I16OFF_37_9_4_;
	O9773[7] = + _I16OFF_38_9_4_;
	O9773[8] = + _I16OFF_37_9_4_;
	O9773[9] = + _I16OFF_47_12_6_;
	O9773[10] = + _I16OFF_49_12_6_;
	O9773[11] = + _I16OFF_47_12_6_;
	{long i; for (i = 12; i < 15; i++) O9773[i] = + _I16OFF_39_10_4_;}
	{long i; for (i = 15; i < 18; i++) O9773[i] = + _I16OFF_49_13_6_;}
	{long i; for (i = 18; i < 22; i++) O9773[i] = + _I16OFF_39_10_4_;}
	O9773[22] = + _I16OFF_49_13_6_;
	O9773[23] = + _I16OFF_51_13_6_;
	{long i; for (i = 24; i < 26; i++) O9773[i] = + _I16OFF_49_14_6_;}
	O9773[26] = + _I16OFF_47_12_4_;
	O9773[27] = + _I16OFF_47_14_4_;
	O9773[28] = + _I16OFF_50_13_4_;
	O9773[29] = + _I16OFF_53_13_4_;
	O9773[30] = + _I16OFF_59_21_6_;
	O9773[31] = + _I16OFF_59_23_6_;
	O9773[32] = + _I16OFF_65_25_6_;
	O9773[33] = + _I16OFF_68_26_6_;
	O9773[34] = + _I16OFF_35_9_4_;
	{long i; for (i = 35; i < 37; i++) O9773[i] = + _I16OFF_37_9_4_;}
	O9773[37] = + _I16OFF_43_9_4_;
	O9773[38] = + _I16OFF_37_10_4_;
	O9773[39] = + _I16OFF_35_9_4_;
	O9773[40] = + _I16OFF_37_9_4_;
	O9773[41] = + _I16OFF_37_10_4_;
	O9773[42] = + _I16OFF_36_9_4_;
	O9773[43] = + _I16OFF_37_9_4_;
	O9773[44] = + _I16OFF_41_9_4_;
	O9773[45] = + _I16OFF_36_9_4_;
	O9773[46] = + _I16OFF_40_12_4_;
	{long i; for (i = 47; i < 51; i++) O9773[i] = + _I16OFF_36_9_4_;}
	O9773[51] = + _I16OFF_42_13_6_;
	O9773[52] = + _I16OFF_44_13_6_;
	O9773[53] = + _I16OFF_51_13_6_;
	O9773[54] = + _I16OFF_58_14_6_;
	O9773[55] = + _I16OFF_45_16_6_;
	O9773[56] = + _I16OFF_44_13_6_;
	O9773[57] = + _I16OFF_50_13_6_;
	O9773[58] = + _I16OFF_51_14_6_;
	O9773[59] = + _I16OFF_43_13_6_;
	O9773[60] = + _I16OFF_46_14_6_;
	O9773[61] = + _I16OFF_59_16_6_;
	O9773[62] = + _I16OFF_44_15_6_;
	O9773[63] = + _I16OFF_51_18_6_;
	{long i; for (i = 64; i < 68; i++) O9773[i] = + _I16OFF_46_14_6_;}
	O9773[68] = + _I16OFF_16_5_4_;
	O9773[69] = + _I16OFF_18_5_4_;
	O9773[70] = + _I16OFF_23_5_4_;
	O9773[71] = + _I16OFF_16_5_4_;
	{long i; for (i = 72; i < 74; i++) O9773[i] = + _I16OFF_20_5_4_;}
	{long i; for (i = 74; i < 76; i++) O9773[i] = + _I16OFF_25_6_4_;}
	{long i; for (i = 76; i < 78; i++) O9773[i] = + _I16OFF_21_7_4_;}
	{long i; for (i = 78; i < 82; i++) O9773[i] = + _I16OFF_17_6_4_;}
	O9773[82] = + _I16OFF_18_6_4_;
	O9773[83] = + _I16OFF_23_8_4_;
	{long i; for (i = 84; i < 86; i++) O9773[i] = + _I16OFF_23_9_4_;}
	O9773[86] = + _I16OFF_24_9_4_;
	O9773[87] = + _I16OFF_26_8_4_;
	O9773[88] = + _I16OFF_19_5_4_;
	O9773[89] = + _I16OFF_22_5_4_;
	{long i; for (i = 90; i < 92; i++) O9773[i] = + _I16OFF_21_10_4_;}
	{long i; for (i = 92; i < 94; i++) O9773[i] = + _I16OFF_29_14_6_;}
	O9773[95] = + _I16OFF_36_10_4_;
	O9773[97] = + _I16OFF_36_9_4_;
	O9773[100] = + _I16OFF_48_19_6_;
	O9773[102] = + _I16OFF_48_18_6_;
}

long O9774[103];
void O9774_init () {
	O9774[0] = + _I16OFF_13_5_5_;
	O9774[1] = + _I16OFF_16_7_5_;
	O9774[2] = + _I16OFF_35_9_5_;
	O9774[3] = + _I16OFF_42_12_7_;
	O9774[4] = + _I16OFF_37_9_5_;
	O9774[5] = + _I16OFF_46_12_7_;
	O9774[6] = + _I16OFF_37_9_5_;
	O9774[7] = + _I16OFF_38_9_5_;
	O9774[8] = + _I16OFF_37_9_5_;
	O9774[9] = + _I16OFF_47_12_7_;
	O9774[10] = + _I16OFF_49_12_7_;
	O9774[11] = + _I16OFF_47_12_7_;
	{long i; for (i = 12; i < 15; i++) O9774[i] = + _I16OFF_39_10_5_;}
	{long i; for (i = 15; i < 18; i++) O9774[i] = + _I16OFF_49_13_7_;}
	{long i; for (i = 18; i < 22; i++) O9774[i] = + _I16OFF_39_10_5_;}
	O9774[22] = + _I16OFF_49_13_7_;
	O9774[23] = + _I16OFF_51_13_7_;
	{long i; for (i = 24; i < 26; i++) O9774[i] = + _I16OFF_49_14_7_;}
	O9774[26] = + _I16OFF_47_12_5_;
	O9774[27] = + _I16OFF_47_14_5_;
	O9774[28] = + _I16OFF_50_13_5_;
	O9774[29] = + _I16OFF_53_13_5_;
	O9774[30] = + _I16OFF_59_21_7_;
	O9774[31] = + _I16OFF_59_23_7_;
	O9774[32] = + _I16OFF_65_25_7_;
	O9774[33] = + _I16OFF_68_26_7_;
	O9774[34] = + _I16OFF_35_9_5_;
	{long i; for (i = 35; i < 37; i++) O9774[i] = + _I16OFF_37_9_5_;}
	O9774[37] = + _I16OFF_43_9_5_;
	O9774[38] = + _I16OFF_37_10_5_;
	O9774[39] = + _I16OFF_35_9_5_;
	O9774[40] = + _I16OFF_37_9_5_;
	O9774[41] = + _I16OFF_37_10_5_;
	O9774[42] = + _I16OFF_36_9_5_;
	O9774[43] = + _I16OFF_37_9_5_;
	O9774[44] = + _I16OFF_41_9_5_;
	O9774[45] = + _I16OFF_36_9_5_;
	O9774[46] = + _I16OFF_40_12_5_;
	{long i; for (i = 47; i < 51; i++) O9774[i] = + _I16OFF_36_9_5_;}
	O9774[51] = + _I16OFF_42_13_7_;
	O9774[52] = + _I16OFF_44_13_7_;
	O9774[53] = + _I16OFF_51_13_7_;
	O9774[54] = + _I16OFF_58_14_7_;
	O9774[55] = + _I16OFF_45_16_7_;
	O9774[56] = + _I16OFF_44_13_7_;
	O9774[57] = + _I16OFF_50_13_7_;
	O9774[58] = + _I16OFF_51_14_7_;
	O9774[59] = + _I16OFF_43_13_7_;
	O9774[60] = + _I16OFF_46_14_7_;
	O9774[61] = + _I16OFF_59_16_7_;
	O9774[62] = + _I16OFF_44_15_7_;
	O9774[63] = + _I16OFF_51_18_7_;
	{long i; for (i = 64; i < 68; i++) O9774[i] = + _I16OFF_46_14_7_;}
	O9774[68] = + _I16OFF_16_5_5_;
	O9774[69] = + _I16OFF_18_5_5_;
	O9774[70] = + _I16OFF_23_5_5_;
	O9774[71] = + _I16OFF_16_5_5_;
	{long i; for (i = 72; i < 74; i++) O9774[i] = + _I16OFF_20_5_5_;}
	{long i; for (i = 74; i < 76; i++) O9774[i] = + _I16OFF_25_6_5_;}
	{long i; for (i = 76; i < 78; i++) O9774[i] = + _I16OFF_21_7_5_;}
	{long i; for (i = 78; i < 82; i++) O9774[i] = + _I16OFF_17_6_5_;}
	O9774[82] = + _I16OFF_18_6_5_;
	O9774[83] = + _I16OFF_23_8_5_;
	{long i; for (i = 84; i < 86; i++) O9774[i] = + _I16OFF_23_9_5_;}
	O9774[86] = + _I16OFF_24_9_5_;
	O9774[87] = + _I16OFF_26_8_5_;
	O9774[88] = + _I16OFF_19_5_5_;
	O9774[89] = + _I16OFF_22_5_5_;
	{long i; for (i = 90; i < 92; i++) O9774[i] = + _I16OFF_21_10_5_;}
	{long i; for (i = 92; i < 94; i++) O9774[i] = + _I16OFF_29_14_7_;}
	O9774[95] = + _I16OFF_36_10_5_;
	O9774[97] = + _I16OFF_36_9_5_;
	O9774[100] = + _I16OFF_48_19_7_;
	O9774[102] = + _I16OFF_48_18_7_;
}

long O9776[103];
void O9776_init () {
	O9776[0] = + _CHROFF_13_4_;
	O9776[1] = + _CHROFF_16_6_;
	O9776[2] = + _CHROFF_35_8_;
	O9776[3] = + _CHROFF_42_11_;
	O9776[4] = + _CHROFF_37_8_;
	O9776[5] = + _CHROFF_46_11_;
	O9776[6] = + _CHROFF_37_8_;
	O9776[7] = + _CHROFF_38_8_;
	O9776[8] = + _CHROFF_37_8_;
	O9776[9] = + _CHROFF_47_11_;
	O9776[10] = + _CHROFF_49_11_;
	O9776[11] = + _CHROFF_47_11_;
	{long i; for (i = 12; i < 15; i++) O9776[i] = + _CHROFF_39_9_;}
	{long i; for (i = 15; i < 18; i++) O9776[i] = + _CHROFF_49_12_;}
	{long i; for (i = 18; i < 22; i++) O9776[i] = + _CHROFF_39_9_;}
	O9776[22] = + _CHROFF_49_12_;
	O9776[23] = + _CHROFF_51_12_;
	{long i; for (i = 24; i < 26; i++) O9776[i] = + _CHROFF_49_13_;}
	O9776[26] = + _CHROFF_47_11_;
	O9776[27] = + _CHROFF_47_13_;
	O9776[28] = + _CHROFF_50_12_;
	O9776[29] = + _CHROFF_53_12_;
	O9776[30] = + _CHROFF_59_20_;
	O9776[31] = + _CHROFF_59_22_;
	O9776[32] = + _CHROFF_65_24_;
	O9776[33] = + _CHROFF_68_25_;
	O9776[34] = + _CHROFF_35_8_;
	{long i; for (i = 35; i < 37; i++) O9776[i] = + _CHROFF_37_8_;}
	O9776[37] = + _CHROFF_43_8_;
	O9776[38] = + _CHROFF_37_9_;
	O9776[39] = + _CHROFF_35_8_;
	O9776[40] = + _CHROFF_37_8_;
	O9776[41] = + _CHROFF_37_9_;
	O9776[42] = + _CHROFF_36_8_;
	O9776[43] = + _CHROFF_37_8_;
	O9776[44] = + _CHROFF_41_8_;
	O9776[45] = + _CHROFF_36_8_;
	O9776[46] = + _CHROFF_40_11_;
	{long i; for (i = 47; i < 51; i++) O9776[i] = + _CHROFF_36_8_;}
	O9776[51] = + _CHROFF_42_12_;
	O9776[52] = + _CHROFF_44_12_;
	O9776[53] = + _CHROFF_51_12_;
	O9776[54] = + _CHROFF_58_13_;
	O9776[55] = + _CHROFF_45_15_;
	O9776[56] = + _CHROFF_44_12_;
	O9776[57] = + _CHROFF_50_12_;
	O9776[58] = + _CHROFF_51_13_;
	O9776[59] = + _CHROFF_43_12_;
	O9776[60] = + _CHROFF_46_13_;
	O9776[61] = + _CHROFF_59_15_;
	O9776[62] = + _CHROFF_44_14_;
	O9776[63] = + _CHROFF_51_17_;
	{long i; for (i = 64; i < 68; i++) O9776[i] = + _CHROFF_46_13_;}
	O9776[68] = + _CHROFF_16_4_;
	O9776[69] = + _CHROFF_18_4_;
	O9776[70] = + _CHROFF_23_4_;
	O9776[71] = + _CHROFF_16_4_;
	{long i; for (i = 72; i < 74; i++) O9776[i] = + _CHROFF_20_4_;}
	{long i; for (i = 74; i < 76; i++) O9776[i] = + _CHROFF_25_5_;}
	{long i; for (i = 76; i < 78; i++) O9776[i] = + _CHROFF_21_6_;}
	{long i; for (i = 78; i < 82; i++) O9776[i] = + _CHROFF_17_5_;}
	O9776[82] = + _CHROFF_18_5_;
	O9776[83] = + _CHROFF_23_7_;
	{long i; for (i = 84; i < 86; i++) O9776[i] = + _CHROFF_23_8_;}
	O9776[86] = + _CHROFF_24_8_;
	O9776[87] = + _CHROFF_26_7_;
	O9776[88] = + _CHROFF_19_4_;
	O9776[89] = + _CHROFF_22_4_;
	{long i; for (i = 90; i < 92; i++) O9776[i] = + _CHROFF_21_9_;}
	{long i; for (i = 92; i < 94; i++) O9776[i] = + _CHROFF_29_13_;}
	O9776[95] = + _CHROFF_36_9_;
	O9776[97] = + _CHROFF_36_8_;
	O9776[100] = + _CHROFF_48_16_;
	O9776[102] = + _CHROFF_48_15_;
}

long O9820[101];
void O9820_init () {
	O9820[0] =  + _REFACS_32_;
	O9820[1] =  + _REFACS_38_;
	O9820[2] =  + _REFACS_33_;
	O9820[3] =  + _REFACS_39_;
	O9820[4] =  + _REFACS_33_;
	O9820[5] =  + _REFACS_34_;
	O9820[6] =  + _REFACS_33_;
	O9820[7] =  + _REFACS_40_;
	O9820[8] =  + _REFACS_42_;
	O9820[9] =  + _REFACS_40_;
	{long i; for (i = 10; i < 13; i++) O9820[i] =  + _REFACS_35_;}
	{long i; for (i = 13; i < 16; i++) O9820[i] =  + _REFACS_42_;}
	{long i; for (i = 16; i < 20; i++) O9820[i] =  + _REFACS_35_;}
	O9820[20] =  + _REFACS_41_;
	O9820[21] =  + _REFACS_42_;
	{long i; for (i = 22; i < 24; i++) O9820[i] =  + _REFACS_41_;}
	{long i; for (i = 24; i < 26; i++) O9820[i] =  + _REFACS_39_;}
	{long i; for (i = 26; i < 28; i++) O9820[i] =  + _REFACS_42_;}
	{long i; for (i = 28; i < 30; i++) O9820[i] =  + _REFACS_46_;}
	{long i; for (i = 30; i < 32; i++) O9820[i] =  + _REFACS_49_;}
	O9820[32] =  + _REFACS_32_;
	O9820[33] =  + _REFACS_33_;
	O9820[34] =  + _REFACS_34_;
	O9820[35] =  + _REFACS_36_;
	O9820[36] =  + _REFACS_34_;
	O9820[37] =  + _REFACS_32_;
	{long i; for (i = 38; i < 40; i++) O9820[i] =  + _REFACS_34_;}
	O9820[40] =  + _REFACS_33_;
	O9820[41] =  + _REFACS_34_;
	O9820[42] =  + _REFACS_38_;
	O9820[43] =  + _REFACS_33_;
	O9820[44] =  + _REFACS_36_;
	{long i; for (i = 45; i < 49; i++) O9820[i] =  + _REFACS_33_;}
	O9820[49] =  + _REFACS_38_;
	O9820[50] =  + _REFACS_39_;
	O9820[51] =  + _REFACS_41_;
	O9820[52] =  + _REFACS_43_;
	O9820[53] =  + _REFACS_41_;
	O9820[54] =  + _REFACS_40_;
	{long i; for (i = 55; i < 57; i++) O9820[i] =  + _REFACS_41_;}
	O9820[57] =  + _REFACS_39_;
	O9820[58] =  + _REFACS_41_;
	O9820[59] =  + _REFACS_46_;
	O9820[60] =  + _REFACS_40_;
	O9820[61] =  + _REFACS_43_;
	{long i; for (i = 62; i < 66; i++) O9820[i] =  + _REFACS_42_;}
	O9820[93] =  + _REFACS_33_;
	O9820[95] =  + _REFACS_33_;
	O9820[98] =  + _REFACS_39_;
	O9820[100] =  + _REFACS_39_;
}

long O9821[101];
void O9821_init () {
	O9821[0] =  + _REFACS_33_;
	O9821[1] =  + _REFACS_39_;
	O9821[2] =  + _REFACS_34_;
	O9821[3] =  + _REFACS_40_;
	O9821[4] =  + _REFACS_34_;
	O9821[5] =  + _REFACS_35_;
	O9821[6] =  + _REFACS_34_;
	O9821[7] =  + _REFACS_41_;
	O9821[8] =  + _REFACS_43_;
	O9821[9] =  + _REFACS_41_;
	{long i; for (i = 10; i < 13; i++) O9821[i] =  + _REFACS_36_;}
	{long i; for (i = 13; i < 16; i++) O9821[i] =  + _REFACS_43_;}
	{long i; for (i = 16; i < 20; i++) O9821[i] =  + _REFACS_36_;}
	O9821[20] =  + _REFACS_42_;
	O9821[21] =  + _REFACS_43_;
	{long i; for (i = 22; i < 24; i++) O9821[i] =  + _REFACS_42_;}
	{long i; for (i = 24; i < 26; i++) O9821[i] =  + _REFACS_40_;}
	{long i; for (i = 26; i < 28; i++) O9821[i] =  + _REFACS_43_;}
	{long i; for (i = 28; i < 30; i++) O9821[i] =  + _REFACS_47_;}
	{long i; for (i = 30; i < 32; i++) O9821[i] =  + _REFACS_50_;}
	O9821[32] =  + _REFACS_33_;
	O9821[33] =  + _REFACS_34_;
	O9821[34] =  + _REFACS_35_;
	O9821[35] =  + _REFACS_37_;
	O9821[36] =  + _REFACS_35_;
	O9821[37] =  + _REFACS_33_;
	{long i; for (i = 38; i < 40; i++) O9821[i] =  + _REFACS_35_;}
	O9821[40] =  + _REFACS_34_;
	O9821[41] =  + _REFACS_35_;
	O9821[42] =  + _REFACS_39_;
	O9821[43] =  + _REFACS_34_;
	O9821[44] =  + _REFACS_37_;
	{long i; for (i = 45; i < 49; i++) O9821[i] =  + _REFACS_34_;}
	O9821[49] =  + _REFACS_39_;
	O9821[50] =  + _REFACS_40_;
	O9821[51] =  + _REFACS_42_;
	O9821[52] =  + _REFACS_44_;
	O9821[53] =  + _REFACS_42_;
	O9821[54] =  + _REFACS_41_;
	{long i; for (i = 55; i < 57; i++) O9821[i] =  + _REFACS_42_;}
	O9821[57] =  + _REFACS_40_;
	O9821[58] =  + _REFACS_42_;
	O9821[59] =  + _REFACS_47_;
	O9821[60] =  + _REFACS_41_;
	O9821[61] =  + _REFACS_44_;
	{long i; for (i = 62; i < 66; i++) O9821[i] =  + _REFACS_43_;}
	O9821[93] =  + _REFACS_34_;
	O9821[95] =  + _REFACS_34_;
	O9821[98] =  + _REFACS_40_;
	O9821[100] =  + _REFACS_40_;
}

long O9822[101];
void O9822_init () {
	O9822[0] =  + _REFACS_34_;
	O9822[1] =  + _REFACS_40_;
	O9822[2] =  + _REFACS_35_;
	O9822[3] =  + _REFACS_41_;
	O9822[4] =  + _REFACS_35_;
	O9822[5] =  + _REFACS_36_;
	O9822[6] =  + _REFACS_35_;
	O9822[7] =  + _REFACS_42_;
	O9822[8] =  + _REFACS_44_;
	O9822[9] =  + _REFACS_42_;
	{long i; for (i = 10; i < 13; i++) O9822[i] =  + _REFACS_37_;}
	{long i; for (i = 13; i < 16; i++) O9822[i] =  + _REFACS_44_;}
	{long i; for (i = 16; i < 20; i++) O9822[i] =  + _REFACS_37_;}
	O9822[20] =  + _REFACS_43_;
	O9822[21] =  + _REFACS_44_;
	{long i; for (i = 22; i < 24; i++) O9822[i] =  + _REFACS_43_;}
	{long i; for (i = 24; i < 26; i++) O9822[i] =  + _REFACS_41_;}
	{long i; for (i = 26; i < 28; i++) O9822[i] =  + _REFACS_44_;}
	{long i; for (i = 28; i < 30; i++) O9822[i] =  + _REFACS_48_;}
	{long i; for (i = 30; i < 32; i++) O9822[i] =  + _REFACS_51_;}
	O9822[32] =  + _REFACS_34_;
	O9822[33] =  + _REFACS_35_;
	O9822[34] =  + _REFACS_36_;
	O9822[35] =  + _REFACS_38_;
	O9822[36] =  + _REFACS_36_;
	O9822[37] =  + _REFACS_34_;
	{long i; for (i = 38; i < 40; i++) O9822[i] =  + _REFACS_36_;}
	O9822[40] =  + _REFACS_35_;
	O9822[41] =  + _REFACS_36_;
	O9822[42] =  + _REFACS_40_;
	O9822[43] =  + _REFACS_35_;
	O9822[44] =  + _REFACS_38_;
	{long i; for (i = 45; i < 49; i++) O9822[i] =  + _REFACS_35_;}
	O9822[49] =  + _REFACS_40_;
	O9822[50] =  + _REFACS_41_;
	O9822[51] =  + _REFACS_43_;
	O9822[52] =  + _REFACS_45_;
	O9822[53] =  + _REFACS_43_;
	O9822[54] =  + _REFACS_42_;
	{long i; for (i = 55; i < 57; i++) O9822[i] =  + _REFACS_43_;}
	O9822[57] =  + _REFACS_41_;
	O9822[58] =  + _REFACS_43_;
	O9822[59] =  + _REFACS_48_;
	O9822[60] =  + _REFACS_42_;
	O9822[61] =  + _REFACS_45_;
	{long i; for (i = 62; i < 66; i++) O9822[i] =  + _REFACS_44_;}
	O9822[93] =  + _REFACS_35_;
	O9822[95] =  + _REFACS_35_;
	O9822[98] =  + _REFACS_41_;
	O9822[100] =  + _REFACS_41_;
}

long O9852[100];
void O9852_init () {
	O9852[0] = + _LNGOFF_42_12_10_2_;
	O9852[2] = + _LNGOFF_46_12_10_2_;
	O9852[6] = + _LNGOFF_47_12_10_3_;
	O9852[7] = + _LNGOFF_49_12_10_5_;
	O9852[8] = + _LNGOFF_47_12_10_3_;
	{long i; for (i = 12; i < 15; i++) O9852[i] = + _LNGOFF_49_13_10_3_;}
	O9852[19] = + _LNGOFF_49_13_10_2_;
	O9852[20] = + _LNGOFF_51_13_10_2_;
	{long i; for (i = 21; i < 23; i++) O9852[i] = + _LNGOFF_49_14_10_2_;}
	O9852[27] = + _LNGOFF_59_21_10_2_;
	O9852[28] = + _LNGOFF_59_23_10_2_;
	O9852[29] = + _LNGOFF_65_25_10_2_;
	O9852[30] = + _LNGOFF_68_26_10_2_;
	O9852[48] = + _LNGOFF_42_13_10_2_;
	O9852[49] = + _LNGOFF_44_13_10_2_;
	O9852[50] = + _LNGOFF_51_13_10_5_;
	O9852[51] = + _LNGOFF_58_14_10_5_;
	O9852[52] = + _LNGOFF_45_16_10_3_;
	O9852[53] = + _LNGOFF_44_13_10_2_;
	O9852[54] = + _LNGOFF_50_13_10_5_;
	O9852[55] = + _LNGOFF_51_14_10_5_;
	O9852[56] = + _LNGOFF_43_13_10_2_;
	O9852[57] = + _LNGOFF_46_14_10_2_;
	O9852[58] = + _LNGOFF_59_16_10_5_;
	O9852[59] = + _LNGOFF_44_15_10_2_;
	O9852[60] = + _LNGOFF_51_18_10_2_;
	{long i; for (i = 61; i < 65; i++) O9852[i] = + _LNGOFF_46_14_10_2_;}
	O9852[97] = + _LNGOFF_48_19_10_2_;
	O9852[99] = + _LNGOFF_48_18_10_2_;
}

long O9853[100];
void O9853_init () {
	O9853[0] = + _LNGOFF_42_12_10_3_;
	O9853[2] = + _LNGOFF_46_12_10_3_;
	O9853[6] = + _LNGOFF_47_12_10_4_;
	O9853[7] = + _LNGOFF_49_12_10_6_;
	O9853[8] = + _LNGOFF_47_12_10_4_;
	{long i; for (i = 12; i < 15; i++) O9853[i] = + _LNGOFF_49_13_10_4_;}
	O9853[19] = + _LNGOFF_49_13_10_3_;
	O9853[20] = + _LNGOFF_51_13_10_3_;
	{long i; for (i = 21; i < 23; i++) O9853[i] = + _LNGOFF_49_14_10_3_;}
	O9853[27] = + _LNGOFF_59_21_10_3_;
	O9853[28] = + _LNGOFF_59_23_10_3_;
	O9853[29] = + _LNGOFF_65_25_10_3_;
	O9853[30] = + _LNGOFF_68_26_10_3_;
	O9853[48] = + _LNGOFF_42_13_10_3_;
	O9853[49] = + _LNGOFF_44_13_10_3_;
	O9853[50] = + _LNGOFF_51_13_10_6_;
	O9853[51] = + _LNGOFF_58_14_10_6_;
	O9853[52] = + _LNGOFF_45_16_10_4_;
	O9853[53] = + _LNGOFF_44_13_10_3_;
	O9853[54] = + _LNGOFF_50_13_10_6_;
	O9853[55] = + _LNGOFF_51_14_10_6_;
	O9853[56] = + _LNGOFF_43_13_10_3_;
	O9853[57] = + _LNGOFF_46_14_10_3_;
	O9853[58] = + _LNGOFF_59_16_10_6_;
	O9853[59] = + _LNGOFF_44_15_10_3_;
	O9853[60] = + _LNGOFF_51_18_10_3_;
	{long i; for (i = 61; i < 65; i++) O9853[i] = + _LNGOFF_46_14_10_3_;}
	O9853[97] = + _LNGOFF_48_19_10_3_;
	O9853[99] = + _LNGOFF_48_18_10_3_;
}

long O9854[100];
void O9854_init () {
	O9854[0] = + _LNGOFF_42_12_10_4_;
	O9854[2] = + _LNGOFF_46_12_10_4_;
	O9854[6] = + _LNGOFF_47_12_10_5_;
	O9854[7] = + _LNGOFF_49_12_10_7_;
	O9854[8] = + _LNGOFF_47_12_10_5_;
	{long i; for (i = 12; i < 15; i++) O9854[i] = + _LNGOFF_49_13_10_5_;}
	O9854[19] = + _LNGOFF_49_13_10_4_;
	O9854[20] = + _LNGOFF_51_13_10_4_;
	{long i; for (i = 21; i < 23; i++) O9854[i] = + _LNGOFF_49_14_10_4_;}
	O9854[27] = + _LNGOFF_59_21_10_4_;
	O9854[28] = + _LNGOFF_59_23_10_4_;
	O9854[29] = + _LNGOFF_65_25_10_4_;
	O9854[30] = + _LNGOFF_68_26_10_4_;
	O9854[48] = + _LNGOFF_42_13_10_4_;
	O9854[49] = + _LNGOFF_44_13_10_4_;
	O9854[50] = + _LNGOFF_51_13_10_7_;
	O9854[51] = + _LNGOFF_58_14_10_7_;
	O9854[52] = + _LNGOFF_45_16_10_5_;
	O9854[53] = + _LNGOFF_44_13_10_4_;
	O9854[54] = + _LNGOFF_50_13_10_7_;
	O9854[55] = + _LNGOFF_51_14_10_7_;
	O9854[56] = + _LNGOFF_43_13_10_4_;
	O9854[57] = + _LNGOFF_46_14_10_4_;
	O9854[58] = + _LNGOFF_59_16_10_7_;
	O9854[59] = + _LNGOFF_44_15_10_4_;
	O9854[60] = + _LNGOFF_51_18_10_4_;
	{long i; for (i = 61; i < 65; i++) O9854[i] = + _LNGOFF_46_14_10_4_;}
	O9854[97] = + _LNGOFF_48_19_10_4_;
	O9854[99] = + _LNGOFF_48_18_10_4_;
}

long O9855[100];
void O9855_init () {
	O9855[0] = + _LNGOFF_42_12_10_5_;
	O9855[2] = + _LNGOFF_46_12_10_5_;
	O9855[6] = + _LNGOFF_47_12_10_6_;
	O9855[7] = + _LNGOFF_49_12_10_8_;
	O9855[8] = + _LNGOFF_47_12_10_6_;
	{long i; for (i = 12; i < 15; i++) O9855[i] = + _LNGOFF_49_13_10_6_;}
	O9855[19] = + _LNGOFF_49_13_10_5_;
	O9855[20] = + _LNGOFF_51_13_10_5_;
	{long i; for (i = 21; i < 23; i++) O9855[i] = + _LNGOFF_49_14_10_5_;}
	O9855[27] = + _LNGOFF_59_21_10_5_;
	O9855[28] = + _LNGOFF_59_23_10_5_;
	O9855[29] = + _LNGOFF_65_25_10_5_;
	O9855[30] = + _LNGOFF_68_26_10_5_;
	O9855[48] = + _LNGOFF_42_13_10_5_;
	O9855[49] = + _LNGOFF_44_13_10_5_;
	O9855[50] = + _LNGOFF_51_13_10_8_;
	O9855[51] = + _LNGOFF_58_14_10_8_;
	O9855[52] = + _LNGOFF_45_16_10_6_;
	O9855[53] = + _LNGOFF_44_13_10_5_;
	O9855[54] = + _LNGOFF_50_13_10_8_;
	O9855[55] = + _LNGOFF_51_14_10_8_;
	O9855[56] = + _LNGOFF_43_13_10_5_;
	O9855[57] = + _LNGOFF_46_14_10_5_;
	O9855[58] = + _LNGOFF_59_16_10_8_;
	O9855[59] = + _LNGOFF_44_15_10_5_;
	O9855[60] = + _LNGOFF_51_18_10_5_;
	{long i; for (i = 61; i < 65; i++) O9855[i] = + _LNGOFF_46_14_10_5_;}
	O9855[97] = + _LNGOFF_48_19_10_5_;
	O9855[99] = + _LNGOFF_48_18_10_5_;
}

long O9860[100];
void O9860_init () {
	O9860[0] =  + _REFACS_41_;
	O9860[2] =  + _REFACS_42_;
	O9860[6] =  + _REFACS_43_;
	O9860[7] =  + _REFACS_45_;
	O9860[8] =  + _REFACS_43_;
	{long i; for (i = 12; i < 15; i++) O9860[i] =  + _REFACS_45_;}
	O9860[19] =  + _REFACS_44_;
	O9860[20] =  + _REFACS_45_;
	{long i; for (i = 21; i < 23; i++) O9860[i] =  + _REFACS_44_;}
	{long i; for (i = 27; i < 29; i++) O9860[i] =  + _REFACS_49_;}
	{long i; for (i = 29; i < 31; i++) O9860[i] =  + _REFACS_52_;}
	O9860[48] =  + _REFACS_41_;
	O9860[49] =  + _REFACS_42_;
	O9860[50] =  + _REFACS_44_;
	O9860[51] =  + _REFACS_46_;
	O9860[52] =  + _REFACS_44_;
	O9860[53] =  + _REFACS_43_;
	{long i; for (i = 54; i < 56; i++) O9860[i] =  + _REFACS_44_;}
	O9860[56] =  + _REFACS_42_;
	O9860[57] =  + _REFACS_44_;
	O9860[58] =  + _REFACS_49_;
	O9860[59] =  + _REFACS_43_;
	O9860[60] =  + _REFACS_46_;
	{long i; for (i = 61; i < 65; i++) O9860[i] =  + _REFACS_45_;}
	O9860[97] =  + _REFACS_42_;
	O9860[99] =  + _REFACS_42_;
}

long O9869[100];
void O9869_init () {
	O9869[0] = + _I16OFF_42_12_8_;
	O9869[2] = + _I16OFF_46_12_8_;
	O9869[6] = + _I16OFF_47_12_8_;
	O9869[7] = + _I16OFF_49_12_8_;
	O9869[8] = + _I16OFF_47_12_8_;
	{long i; for (i = 12; i < 15; i++) O9869[i] = + _I16OFF_49_13_8_;}
	O9869[19] = + _I16OFF_49_13_8_;
	O9869[20] = + _I16OFF_51_13_8_;
	{long i; for (i = 21; i < 23; i++) O9869[i] = + _I16OFF_49_14_8_;}
	O9869[27] = + _I16OFF_59_21_8_;
	O9869[28] = + _I16OFF_59_23_8_;
	O9869[29] = + _I16OFF_65_25_8_;
	O9869[30] = + _I16OFF_68_26_8_;
	O9869[48] = + _I16OFF_42_13_8_;
	O9869[49] = + _I16OFF_44_13_8_;
	O9869[50] = + _I16OFF_51_13_8_;
	O9869[51] = + _I16OFF_58_14_8_;
	O9869[52] = + _I16OFF_45_16_8_;
	O9869[53] = + _I16OFF_44_13_8_;
	O9869[54] = + _I16OFF_50_13_8_;
	O9869[55] = + _I16OFF_51_14_8_;
	O9869[56] = + _I16OFF_43_13_8_;
	O9869[57] = + _I16OFF_46_14_8_;
	O9869[58] = + _I16OFF_59_16_8_;
	O9869[59] = + _I16OFF_44_15_8_;
	O9869[60] = + _I16OFF_51_18_8_;
	{long i; for (i = 61; i < 65; i++) O9869[i] = + _I16OFF_46_14_8_;}
	O9869[97] = + _I16OFF_48_19_8_;
	O9869[99] = + _I16OFF_48_18_8_;
}

long O9870[100];
void O9870_init () {
	O9870[0] = + _I16OFF_42_12_9_;
	O9870[2] = + _I16OFF_46_12_9_;
	O9870[6] = + _I16OFF_47_12_9_;
	O9870[7] = + _I16OFF_49_12_9_;
	O9870[8] = + _I16OFF_47_12_9_;
	{long i; for (i = 12; i < 15; i++) O9870[i] = + _I16OFF_49_13_9_;}
	O9870[19] = + _I16OFF_49_13_9_;
	O9870[20] = + _I16OFF_51_13_9_;
	{long i; for (i = 21; i < 23; i++) O9870[i] = + _I16OFF_49_14_9_;}
	O9870[27] = + _I16OFF_59_21_9_;
	O9870[28] = + _I16OFF_59_23_9_;
	O9870[29] = + _I16OFF_65_25_9_;
	O9870[30] = + _I16OFF_68_26_9_;
	O9870[48] = + _I16OFF_42_13_9_;
	O9870[49] = + _I16OFF_44_13_9_;
	O9870[50] = + _I16OFF_51_13_9_;
	O9870[51] = + _I16OFF_58_14_9_;
	O9870[52] = + _I16OFF_45_16_9_;
	O9870[53] = + _I16OFF_44_13_9_;
	O9870[54] = + _I16OFF_50_13_9_;
	O9870[55] = + _I16OFF_51_14_9_;
	O9870[56] = + _I16OFF_43_13_9_;
	O9870[57] = + _I16OFF_46_14_9_;
	O9870[58] = + _I16OFF_59_16_9_;
	O9870[59] = + _I16OFF_44_15_9_;
	O9870[60] = + _I16OFF_51_18_9_;
	{long i; for (i = 61; i < 65; i++) O9870[i] = + _I16OFF_46_14_9_;}
	O9870[97] = + _I16OFF_48_19_9_;
	O9870[99] = + _I16OFF_48_18_9_;
}

long O9898[29];
void O9898_init () {
	O9898[0] =  + _REFACS_44_;
	O9898[4] =  + _REFACS_45_;
	O9898[5] =  + _REFACS_47_;
	O9898[6] =  + _REFACS_45_;
	{long i; for (i = 10; i < 13; i++) O9898[i] =  + _REFACS_47_;}
	O9898[17] =  + _REFACS_46_;
	O9898[18] =  + _REFACS_47_;
	{long i; for (i = 19; i < 21; i++) O9898[i] =  + _REFACS_46_;}
	{long i; for (i = 25; i < 27; i++) O9898[i] =  + _REFACS_51_;}
	{long i; for (i = 27; i < 29; i++) O9898[i] =  + _REFACS_54_;}
}

long O9912[29];
void O9912_init () {
	O9912[0] =  + _REFACS_45_;
	O9912[4] =  + _REFACS_46_;
	O9912[5] =  + _REFACS_48_;
	O9912[6] =  + _REFACS_46_;
	{long i; for (i = 10; i < 13; i++) O9912[i] =  + _REFACS_48_;}
	O9912[17] =  + _REFACS_47_;
	O9912[18] =  + _REFACS_48_;
	{long i; for (i = 19; i < 21; i++) O9912[i] =  + _REFACS_47_;}
	{long i; for (i = 25; i < 27; i++) O9912[i] =  + _REFACS_52_;}
	{long i; for (i = 27; i < 29; i++) O9912[i] =  + _REFACS_55_;}
}

long O9983[12];
void O9983_init () {
	O9983[0] =  + _REFACS_48_;
	O9983[1] =  + _REFACS_49_;
	{long i; for (i = 2; i < 4; i++) O9983[i] =  + _REFACS_48_;}
	{long i; for (i = 8; i < 10; i++) O9983[i] =  + _REFACS_53_;}
	{long i; for (i = 10; i < 12; i++) O9983[i] =  + _REFACS_56_;}
}

long O10006[8];
void O10006_init () {
	{long i; for (i = 0; i < 2; i++) O10006[i] =  + _REFACS_43_;}
	{long i; for (i = 2; i < 4; i++) O10006[i] =  + _REFACS_46_;}
	{long i; for (i = 4; i < 6; i++) O10006[i] =  + _REFACS_54_;}
	{long i; for (i = 6; i < 8; i++) O10006[i] =  + _REFACS_57_;}
}

long O10007[8];
void O10007_init () {
	{long i; for (i = 0; i < 2; i++) O10007[i] =  + _REFACS_44_;}
	{long i; for (i = 2; i < 4; i++) O10007[i] =  + _REFACS_47_;}
	{long i; for (i = 4; i < 6; i++) O10007[i] =  + _REFACS_55_;}
	{long i; for (i = 6; i < 8; i++) O10007[i] =  + _REFACS_58_;}
}

long O10013[8];
void O10013_init () {
	{long i; for (i = 0; i < 2; i++) O10013[i] = + _CHROFF_47_8_;}
	O10013[2] = + _CHROFF_50_8_;
	O10013[3] = + _CHROFF_53_8_;
	{long i; for (i = 4; i < 6; i++) O10013[i] = + _CHROFF_59_13_;}
	O10013[6] = + _CHROFF_65_13_;
	O10013[7] = + _CHROFF_68_13_;
}

long O10034[8];
void O10034_init () {
	{long i; for (i = 0; i < 2; i++) O10034[i] =  + _REFACS_45_;}
	{long i; for (i = 2; i < 4; i++) O10034[i] =  + _REFACS_48_;}
	{long i; for (i = 4; i < 6; i++) O10034[i] =  + _REFACS_56_;}
	{long i; for (i = 6; i < 8; i++) O10034[i] =  + _REFACS_59_;}
}

long O10037[8];
void O10037_init () {
	{long i; for (i = 0; i < 2; i++) O10037[i] = + _CHROFF_47_9_;}
	O10037[2] = + _CHROFF_50_9_;
	O10037[3] = + _CHROFF_53_9_;
	{long i; for (i = 4; i < 6; i++) O10037[i] = + _CHROFF_59_14_;}
	O10037[6] = + _CHROFF_65_14_;
	O10037[7] = + _CHROFF_68_14_;
}

long O10038[8];
void O10038_init () {
	{long i; for (i = 0; i < 2; i++) O10038[i] =  + _REFACS_46_;}
	{long i; for (i = 2; i < 4; i++) O10038[i] =  + _REFACS_49_;}
	{long i; for (i = 4; i < 6; i++) O10038[i] =  + _REFACS_57_;}
	{long i; for (i = 6; i < 8; i++) O10038[i] =  + _REFACS_60_;}
}

long O10078[4];
void O10078_init () {
	O10078[0] = + _CHROFF_59_15_;
	O10078[1] = + _CHROFF_59_17_;
	O10078[2] = + _CHROFF_65_16_;
	O10078[3] = + _CHROFF_68_16_;
}

long O10079[4];
void O10079_init () {
	O10079[0] = + _CHROFF_59_16_;
	O10079[1] = + _CHROFF_59_18_;
	O10079[2] = + _CHROFF_65_17_;
	O10079[3] = + _CHROFF_68_17_;
}

long O10080[4];
void O10080_init () {
	O10080[0] = + _CHROFF_59_17_;
	O10080[1] = + _CHROFF_59_19_;
	O10080[2] = + _CHROFF_65_18_;
	O10080[3] = + _CHROFF_68_18_;
}

long O10082[4];
void O10082_init () {
	O10082[0] = + _CHROFF_59_18_;
	O10082[1] = + _CHROFF_59_20_;
	O10082[2] = + _CHROFF_65_19_;
	O10082[3] = + _CHROFF_68_19_;
}

long O10084[4];
void O10084_init () {
	O10084[0] = + _PTROFF_59_21_10_11_0_1_;
	O10084[1] = + _PTROFF_59_23_10_11_0_1_;
	O10084[2] = + _PTROFF_65_25_10_11_0_1_;
	O10084[3] = + _PTROFF_68_26_10_11_0_1_;
}

long O10086[4];
void O10086_init () {
	O10086[0] = + _LNGOFF_59_21_10_6_;
	O10086[1] = + _LNGOFF_59_23_10_6_;
	O10086[2] = + _LNGOFF_65_25_10_6_;
	O10086[3] = + _LNGOFF_68_26_10_6_;
}

long O10087[4];
void O10087_init () {
	O10087[0] = + _LNGOFF_59_21_10_7_;
	O10087[1] = + _LNGOFF_59_23_10_7_;
	O10087[2] = + _LNGOFF_65_25_10_7_;
	O10087[3] = + _LNGOFF_68_26_10_7_;
}

long O10092[4];
void O10092_init () {
	O10092[0] = + _LNGOFF_59_21_10_8_;
	O10092[1] = + _LNGOFF_59_23_10_8_;
	O10092[2] = + _LNGOFF_65_25_10_8_;
	O10092[3] = + _LNGOFF_68_26_10_8_;
}

long O10107[4];
void O10107_init () {
	O10107[0] = + _PTROFF_59_21_10_11_0_2_;
	O10107[1] = + _PTROFF_59_23_10_11_0_2_;
	O10107[2] = + _PTROFF_65_25_10_11_0_2_;
	O10107[3] = + _PTROFF_68_26_10_11_0_2_;
}

long O10108[4];
void O10108_init () {
	O10108[0] = + _PTROFF_59_21_10_11_0_3_;
	O10108[1] = + _PTROFF_59_23_10_11_0_3_;
	O10108[2] = + _PTROFF_65_25_10_11_0_3_;
	O10108[3] = + _PTROFF_68_26_10_11_0_3_;
}

long O10110[4];
void O10110_init () {
	O10110[0] = + _LNGOFF_59_21_10_9_;
	O10110[1] = + _LNGOFF_59_23_10_9_;
	O10110[2] = + _LNGOFF_65_25_10_9_;
	O10110[3] = + _LNGOFF_68_26_10_9_;
}

long O10111[4];
void O10111_init () {
	O10111[0] = + _LNGOFF_59_21_10_10_;
	O10111[1] = + _LNGOFF_59_23_10_10_;
	O10111[2] = + _LNGOFF_65_25_10_10_;
	O10111[3] = + _LNGOFF_68_26_10_10_;
}

long O10117[2];
void O10117_init () {
	O10117[0] = + _CHROFF_65_20_;
	O10117[1] = + _CHROFF_68_20_;
}

long O10118[2];
void O10118_init () {
	O10118[0] =  + _REFACS_62_;
	O10118[1] =  + _REFACS_65_;
}

long O10121[2];
void O10121_init () {
	O10121[0] = + _CHROFF_65_21_;
	O10121[1] = + _CHROFF_68_21_;
}

long O10122[2];
void O10122_init () {
	O10122[0] = + _CHROFF_65_22_;
	O10122[1] = + _CHROFF_68_22_;
}

long O10295[52];
void O10295_init () {
	O10295[0] = + _CHROFF_42_10_;
	O10295[1] = + _CHROFF_44_10_;
	O10295[2] = + _CHROFF_51_10_;
	O10295[3] = + _CHROFF_58_10_;
	O10295[4] = + _CHROFF_45_11_;
	O10295[5] = + _CHROFF_44_10_;
	O10295[6] = + _CHROFF_50_10_;
	O10295[7] = + _CHROFF_51_11_;
	O10295[8] = + _CHROFF_43_10_;
	O10295[9] = + _CHROFF_46_10_;
	O10295[10] = + _CHROFF_59_10_;
	O10295[11] = + _CHROFF_44_10_;
	O10295[12] = + _CHROFF_51_13_;
	{long i; for (i = 13; i < 17; i++) O10295[i] = + _CHROFF_46_10_;}
	O10295[49] = + _CHROFF_48_10_;
	O10295[51] = + _CHROFF_48_10_;
}

long O10483[18];
void O10483_init () {
	{long i; for (i = 0; i < 2; i++) O10483[i] =  + _REFACS_20_;}
	{long i; for (i = 7; i < 11; i++) O10483[i] =  + _REFACS_22_;}
	O10483[11] =  + _REFACS_25_;
	{long i; for (i = 16; i < 18; i++) O10483[i] =  + _REFACS_26_;}
}

long O10489[5];
void O10489_init () {
	O10489[0] = + _PTROFF_23_8_6_1_0_3_;
	{long i; for (i = 1; i < 3; i++) O10489[i] = + _PTROFF_23_9_6_1_0_3_;}
	O10489[3] = + _PTROFF_24_9_6_1_0_3_;
	O10489[4] = + _PTROFF_26_8_6_2_0_3_;
}

long O10551[10];
void O10551_init () {
	O10551[0] = + _LNGOFF_1_1_0_0_;
	O10551[1] = + _LNGOFF_36_10_6_1_;
	O10551[2] = + _LNGOFF_1_1_0_0_;
	O10551[3] = + _LNGOFF_36_9_6_1_;
	O10551[4] = + _LNGOFF_1_1_0_0_;
	O10551[5] = + _LNGOFF_6_5_0_0_;
	O10551[6] = + _LNGOFF_48_19_10_6_;
	O10551[7] = + _LNGOFF_6_5_0_0_;
	O10551[8] = + _LNGOFF_48_18_10_6_;
	O10551[9] = + _LNGOFF_6_7_0_0_;
}

long O10627[5];
void O10627_init () {
	O10627[0] = + _PTROFF_6_5_0_3_0_0_;
	O10627[1] = + _PTROFF_48_19_10_9_0_1_;
	O10627[2] = + _PTROFF_6_5_0_3_0_0_;
	O10627[3] = + _PTROFF_48_18_10_9_0_1_;
	O10627[4] = + _PTROFF_6_7_0_5_0_0_;
}

long O10635[5];
void O10635_init () {
	O10635[0] = + _CHROFF_6_3_;
	O10635[1] = + _CHROFF_48_17_;
	O10635[2] = + _CHROFF_6_3_;
	O10635[3] = + _CHROFF_48_16_;
	O10635[4] = + _CHROFF_6_5_;
}

long O10636[5];
void O10636_init () {
	O10636[0] = + _CHROFF_6_4_;
	O10636[1] = + _CHROFF_48_18_;
	O10636[2] = + _CHROFF_6_4_;
	O10636[3] = + _CHROFF_48_17_;
	O10636[4] = + _CHROFF_6_6_;
}

long O10640[5];
void O10640_init () {
	O10640[0] = + _CHROFF_6_0_;
	O10640[1] = + _CHROFF_48_12_;
	O10640[2] = + _CHROFF_6_0_;
	O10640[3] = + _CHROFF_48_11_;
	O10640[4] = + _CHROFF_6_0_;
}

long O10641[5];
void O10641_init () {
	O10641[0] = + _R64OFF_6_5_0_3_0_1_0_0_;
	O10641[1] = + _R64OFF_48_19_10_9_0_3_0_0_;
	O10641[2] = + _R64OFF_6_5_0_3_0_2_0_0_;
	O10641[3] = + _R64OFF_48_18_10_9_0_4_0_0_;
	O10641[4] = + _R64OFF_6_7_0_5_0_5_0_0_;
}

long O10660[5];
void O10660_init () {
	O10660[0] =  + _REFACS_2_;
	O10660[1] =  + _REFACS_44_;
	O10660[2] =  + _REFACS_2_;
	O10660[3] =  + _REFACS_44_;
	O10660[4] =  + _REFACS_2_;
}

long O10661[5];
void O10661_init () {
	O10661[0] =  + _REFACS_3_;
	O10661[1] =  + _REFACS_45_;
	O10661[2] =  + _REFACS_3_;
	O10661[3] =  + _REFACS_45_;
	O10661[4] =  + _REFACS_3_;
}

long O10665[5];
void O10665_init () {
	O10665[0] =  + _REFACS_4_;
	O10665[1] =  + _REFACS_46_;
	O10665[2] =  + _REFACS_4_;
	O10665[3] =  + _REFACS_46_;
	O10665[4] =  + _REFACS_4_;
}

long O10666[5];
void O10666_init () {
	O10666[0] = + _CHROFF_6_1_;
	O10666[1] = + _CHROFF_48_13_;
	O10666[2] = + _CHROFF_6_1_;
	O10666[3] = + _CHROFF_48_12_;
	O10666[4] = + _CHROFF_6_1_;
}

long O10667[5];
void O10667_init () {
	O10667[0] =  + _REFACS_5_;
	O10667[1] =  + _REFACS_47_;
	O10667[2] =  + _REFACS_5_;
	O10667[3] =  + _REFACS_47_;
	O10667[4] =  + _REFACS_5_;
}

long O10668[5];
void O10668_init () {
	O10668[0] = + _LNGOFF_6_5_0_1_;
	O10668[1] = + _LNGOFF_48_19_10_7_;
	O10668[2] = + _LNGOFF_6_5_0_1_;
	O10668[3] = + _LNGOFF_48_18_10_7_;
	O10668[4] = + _LNGOFF_6_7_0_1_;
}

long O10669[5];
void O10669_init () {
	O10669[0] = + _LNGOFF_6_5_0_2_;
	O10669[1] = + _LNGOFF_48_19_10_8_;
	O10669[2] = + _LNGOFF_6_5_0_2_;
	O10669[3] = + _LNGOFF_48_18_10_8_;
	O10669[4] = + _LNGOFF_6_7_0_2_;
}


#ifdef __cplusplus
}
#endif
