#include "epoly5.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R28[1383])();
void R28_init () {
	{long i; for (i = 0; i < 5; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 6; i < 9; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 10; i < 25; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 26; i < 29; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 31; i < 33; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 34; i < 39; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 41; i < 43; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 45; i < 48; i++) R28[i] = (char *(*)()) F1_25;}
	R28[60] = (char *(*)()) F1_25;
	{long i; for (i = 97; i < 102; i++) R28[i] = (char *(*)()) F1_25;}
	R28[104] = (char *(*)()) F1_25;
	R28[120] = (char *(*)()) F1_25;
	R28[124] = (char *(*)()) F1_25;
	R28[126] = (char *(*)()) F1_25;
	R28[128] = (char *(*)()) F1_25;
	{long i; for (i = 131; i < 133; i++) R28[i] = (char *(*)()) F1_25;}
	R28[140] = (char *(*)()) F1_25;
	R28[142] = (char *(*)()) F1_25;
	R28[150] = (char *(*)()) F1_25;
	{long i; for (i = 152; i < 154; i++) R28[i] = (char *(*)()) F1_25;}
	R28[155] = (char *(*)()) F1_25;
	{long i; for (i = 157; i < 159; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 160; i < 162; i++) R28[i] = (char *(*)()) F1_25;}
	R28[164] = (char *(*)()) F1_25;
	{long i; for (i = 170; i < 174; i++) R28[i] = (char *(*)()) F1_25;}
	R28[175] = (char *(*)()) F1_25;
	{long i; for (i = 177; i < 186; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 188; i < 190; i++) R28[i] = (char *(*)()) F1_25;}
	R28[192] = (char *(*)()) F1_25;
	R28[194] = (char *(*)()) F1_25;
	{long i; for (i = 195; i < 198; i++) R28[i] = (char *(*)()) F201_3867;}
	R28[200] = (char *(*)()) F201_3867;
	{long i; for (i = 202; i < 205; i++) R28[i] = (char *(*)()) F201_3867;}
	{long i; for (i = 206; i < 209; i++) R28[i] = (char *(*)()) F201_3867;}
	{long i; for (i = 210; i < 212; i++) R28[i] = (char *(*)()) F201_3867;}
	{long i; for (i = 214; i < 216; i++) R28[i] = (char *(*)()) F201_3867;}
	{long i; for (i = 217; i < 220; i++) R28[i] = (char *(*)()) F201_3867;}
	{long i; for (i = 221; i < 225; i++) R28[i] = (char *(*)()) F201_3867;}
	{long i; for (i = 226; i < 228; i++) R28[i] = (char *(*)()) F201_3867;}
	{long i; for (i = 229; i < 235; i++) R28[i] = (char *(*)()) F201_3867;}
	{long i; for (i = 237; i < 239; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 240; i < 248; i++) R28[i] = (char *(*)()) F1_25;}
	R28[250] = (char *(*)()) F1_25;
	R28[252] = (char *(*)()) F1_25;
	R28[255] = (char *(*)()) F1_25;
	R28[257] = (char *(*)()) F1_25;
	R28[260] = (char *(*)()) F1_25;
	{long i; for (i = 262; i < 264; i++) R28[i] = (char *(*)()) F1_25;}
	R28[267] = (char *(*)()) F1_25;
	{long i; for (i = 276; i < 280; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 283; i < 287; i++) R28[i] = (char *(*)()) F1_25;}
	R28[300] = (char *(*)()) F1_25;
	{long i; for (i = 307; i < 309; i++) R28[i] = (char *(*)()) F1_25;}
	R28[322] = (char *(*)()) F1_25;
	R28[329] = (char *(*)()) F1_25;
	R28[344] = (char *(*)()) F1_25;
	R28[570] = (char *(*)()) F1_25;
	{long i; for (i = 572; i < 584; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 633; i < 640; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 642; i < 650; i++) R28[i] = (char *(*)()) F1_25;}
	R28[650] = (char *(*)()) F656_5718;
	{long i; for (i = 651; i < 666; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 670; i < 676; i++) R28[i] = (char *(*)()) F1_25;}
	R28[680] = (char *(*)()) F1_25;
	R28[682] = (char *(*)()) F1_25;
	R28[684] = (char *(*)()) F1_25;
	R28[688] = (char *(*)()) F1_25;
	{long i; for (i = 690; i < 694; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 695; i < 697; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 698; i < 700; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 715; i < 717; i++) R28[i] = (char *(*)()) F1_25;}
	R28[721] = (char *(*)()) F1_25;
	{long i; for (i = 752; i < 773; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 785; i < 823; i++) R28[i] = (char *(*)()) F1_25;}
	R28[824] = (char *(*)()) F830_6313;
	{long i; for (i = 825; i < 827; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 829; i < 843; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 844; i < 851; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 852; i < 854; i++) R28[i] = (char *(*)()) F1_25;}
	R28[902] = (char *(*)()) F1_25;
	{long i; for (i = 904; i < 910; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 914; i < 916; i++) R28[i] = (char *(*)()) F1_25;}
	R28[918] = (char *(*)()) F1_25;
	R28[920] = (char *(*)()) F1_25;
	R28[923] = (char *(*)()) F1_25;
	R28[925] = (char *(*)()) F931_7656;
	R28[926] = (char *(*)()) F932_7703;
	R28[927] = (char *(*)()) F933_7744;
	R28[928] = (char *(*)()) F934_7744;
	R28[929] = (char *(*)()) F935_7744;
	R28[930] = (char *(*)()) F936_7744;
	R28[931] = (char *(*)()) F937_7744;
	R28[932] = (char *(*)()) F938_7744;
	R28[933] = (char *(*)()) F939_7744;
	R28[934] = (char *(*)()) F940_7744;
	R28[935] = (char *(*)()) F941_7744;
	R28[936] = (char *(*)()) F942_7744;
	R28[937] = (char *(*)()) F943_7744;
	R28[938] = (char *(*)()) F944_7744;
	R28[939] = (char *(*)()) F945_7744;
	R28[940] = (char *(*)()) F946_7744;
	R28[941] = (char *(*)()) F947_7744;
	R28[942] = (char *(*)()) F948_7744;
	R28[943] = (char *(*)()) F949_7744;
	R28[944] = (char *(*)()) F950_7744;
	R28[945] = (char *(*)()) F951_7744;
	R28[946] = (char *(*)()) F952_7744;
	R28[947] = (char *(*)()) F953_7744;
	R28[948] = (char *(*)()) F954_7744;
	R28[949] = (char *(*)()) F955_7744;
	R28[950] = (char *(*)()) F956_7744;
	R28[951] = (char *(*)()) F957_7744;
	R28[952] = (char *(*)()) F958_7744;
	R28[953] = (char *(*)()) F959_7744;
	R28[954] = (char *(*)()) F960_7744;
	R28[955] = (char *(*)()) F961_7744;
	R28[956] = (char *(*)()) F962_7744;
	R28[957] = (char *(*)()) F963_7744;
	R28[958] = (char *(*)()) F964_7744;
	R28[959] = (char *(*)()) F965_7744;
	R28[960] = (char *(*)()) F966_7744;
	R28[961] = (char *(*)()) F1_25;
	R28[963] = (char *(*)()) F969_7953;
	R28[964] = (char *(*)()) F970_7953;
	{long i; for (i = 966; i < 968; i++) R28[i] = (char *(*)()) F971_7969;}
	{long i; for (i = 969; i < 971; i++) R28[i] = (char *(*)()) F974_8009;}
	{long i; for (i = 972; i < 974; i++) R28[i] = (char *(*)()) F977_8057;}
	{long i; for (i = 975; i < 977; i++) R28[i] = (char *(*)()) F980_8133;}
	{long i; for (i = 978; i < 980; i++) R28[i] = (char *(*)()) F983_8232;}
	{long i; for (i = 981; i < 983; i++) R28[i] = (char *(*)()) F986_8331;}
	{long i; for (i = 984; i < 986; i++) R28[i] = (char *(*)()) F989_8430;}
	{long i; for (i = 987; i < 989; i++) R28[i] = (char *(*)()) F992_8526;}
	{long i; for (i = 990; i < 992; i++) R28[i] = (char *(*)()) F995_8620;}
	{long i; for (i = 993; i < 995; i++) R28[i] = (char *(*)()) F998_8715;}
	{long i; for (i = 996; i < 998; i++) R28[i] = (char *(*)()) F1001_8810;}
	R28[999] = (char *(*)()) F1005_8903;
	R28[1000] = (char *(*)()) F1006_8903;
	{long i; for (i = 1001; i < 1032; i++) R28[i] = (char *(*)()) F1007_8922;}
	R28[1032] = (char *(*)()) F1038_8935;
	R28[1033] = (char *(*)()) F1039_8935;
	{long i; for (i = 1035; i < 1040; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1044; i < 1046; i++) R28[i] = (char *(*)()) F1049_9163;}
	{long i; for (i = 1047; i < 1049; i++) R28[i] = (char *(*)()) F1052_9331;}
	{long i; for (i = 1080; i < 1082; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1083] = (char *(*)()) F1_25;
	R28[1084] = (char *(*)()) F1090_9713;
	{long i; for (i = 1085; i < 1088; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1089] = (char *(*)()) F1095_9806;
	R28[1094] = (char *(*)()) F1_25;
	R28[1111] = (char *(*)()) F1_25;
	R28[1113] = (char *(*)()) F1_25;
	{long i; for (i = 1127; i < 1132; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1133; i < 1135; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1138; i < 1141; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1142] = (char *(*)()) F1_25;
	{long i; for (i = 1145; i < 1148; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1150; i < 1152; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1153] = (char *(*)()) F1_25;
	R28[1156] = (char *(*)()) F1_25;
	R28[1161] = (char *(*)()) F1_25;
	R28[1164] = (char *(*)()) F1_25;
	R28[1170] = (char *(*)()) F1_25;
	R28[1180] = (char *(*)()) F1_25;
	R28[1188] = (char *(*)()) F1_25;
	R28[1193] = (char *(*)()) F1_25;
	R28[1195] = (char *(*)()) F1_25;
	R28[1198] = (char *(*)()) F1_25;
	R28[1200] = (char *(*)()) F1_25;
	R28[1202] = (char *(*)()) F1_25;
	R28[1205] = (char *(*)()) F1_25;
	R28[1207] = (char *(*)()) F1_25;
	R28[1211] = (char *(*)()) F1_25;
	R28[1251] = (char *(*)()) F1_25;
	{long i; for (i = 1274; i < 1276; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1280; i < 1282; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1283] = (char *(*)()) F1_25;
	R28[1288] = (char *(*)()) F1_25;
	{long i; for (i = 1290; i < 1292; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1313; i < 1315; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1318] = (char *(*)()) F1_25;
	R28[1320] = (char *(*)()) F1_25;
	R28[1322] = (char *(*)()) F1_25;
	R28[1325] = (char *(*)()) F1_25;
	R28[1335] = (char *(*)()) F1_25;
	R28[1341] = (char *(*)()) F1_25;
	R28[1345] = (char *(*)()) F1_25;
	R28[1358] = (char *(*)()) F1_25;
	{long i; for (i = 1360; i < 1362; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1366] = (char *(*)()) F1372_14081;
	R28[1367] = (char *(*)()) F1_25;
	{long i; for (i = 1369; i < 1371; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1373] = (char *(*)()) F1_25;
	R28[1375] = (char *(*)()) F1_25;
	R28[1380] = (char *(*)()) F1_25;
	R28[1382] = (char *(*)()) F1_25;
}

char *(*R3431[2])();
void R3431_init () {
	R3431[0] = (char *(*)()) F158_3456;
	R3431[1] = (char *(*)()) F159_3466;
}

char *(*R3507[2])();
void R3507_init () {
	R3507[0] = (char *(*)()) F166_3539;
	R3507[1] = (char *(*)()) F167_3540;
}

char *(*R3586[2])();
void R3586_init () {
	R3586[0] = (char *(*)()) F176_3627;
	R3586[1] = (char *(*)()) F177_3631;
}

char *(*R3588[2])();
void R3588_init () {
	R3588[0] = (char *(*)()) F176_3628;
	R3588[1] = (char *(*)()) F177_3632;
}

char *(*R3693[167])();
void R3693_init () {
	R3693[0] = (char *(*)()) F184_3756;
	R3693[1] = (char *(*)()) F185_3756_3693_1;
	R3693[2] = (char *(*)()) F186_3756_3693_1;
	R3693[3] = (char *(*)()) F187_3756_3693_1;
	R3693[4] = (char *(*)()) F188_3756_3693_1;
	R3693[5] = (char *(*)()) F184_3756;
	R3693[6] = (char *(*)()) F185_3756_3693_1;
	R3693[7] = (char *(*)()) F188_3756_3693_1;
	R3693[166] = (char *(*)()) F184_3756;
}
static EIF_REFERENCE F185_3756_3693_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F185_3756(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F186_3756_3693_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F186_3756(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(993, 0x00).id, 993, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F187_3756_3693_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F187_3756(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F188_3756_3693_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F188_3756(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}

char *(*R3694[167])();
void R3694_init () {
	R3694[0] = (char *(*)()) F184_3757;
	R3694[1] = (char *(*)()) F185_3757_3694_4;
	R3694[2] = (char *(*)()) F186_3757_3694_4;
	R3694[3] = (char *(*)()) F187_3757_3694_4;
	R3694[4] = (char *(*)()) F188_3757_3694_4;
	R3694[5] = (char *(*)()) F184_3757;
	R3694[6] = (char *(*)()) F185_3757_3694_4;
	R3694[7] = (char *(*)()) F188_3757_3694_4;
	R3694[166] = (char *(*)()) F184_3757;
}
static void F185_3757_3694_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F185_3757(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F186_3757_3694_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F186_3757(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F187_3757_3694_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F187_3757(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F188_3757_3694_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F188_3757(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R3698[3])();
void R3698_init () {
	R3698[0] = (char *(*)()) F189_3760;
	R3698[1] = (char *(*)()) F190_3760;
	R3698[2] = (char *(*)()) F191_3760;
}

char *(*R3699[3])();
void R3699_init () {
	R3699[0] = (char *(*)()) F189_3761;
	R3699[1] = (char *(*)()) F190_3761;
	R3699[2] = (char *(*)()) F191_3761;
}

char *(*R3700[861])();
void R3700_init () {
	R3700[0] = (char *(*)()) F194_3777;
	R3700[737] = (char *(*)()) F931_7654;
	R3700[738] = (char *(*)()) F932_7698;
	R3700[775] = (char *(*)()) F969_7930_3700_2;
	R3700[776] = (char *(*)()) F970_7930_3700_2;
	{long i; for (i = 778; i < 780; i++) R3700[i] = (char *(*)()) F971_7961;}
	{long i; for (i = 781; i < 783; i++) R3700[i] = (char *(*)()) F974_8001;}
	R3700[787] = (char *(*)()) F981_8135_3700_2;
	R3700[788] = (char *(*)()) F982_8135_3700_2;
	R3700[790] = (char *(*)()) F984_8234_3700_2;
	R3700[791] = (char *(*)()) F985_8234_3700_2;
	R3700[793] = (char *(*)()) F987_8333_3700_2;
	R3700[794] = (char *(*)()) F988_8333_3700_2;
	R3700[796] = (char *(*)()) F990_8432_3700_2;
	R3700[797] = (char *(*)()) F991_8432_3700_2;
	R3700[799] = (char *(*)()) F993_8527_3700_2;
	R3700[800] = (char *(*)()) F994_8527_3700_2;
	R3700[802] = (char *(*)()) F996_8621_3700_2;
	R3700[803] = (char *(*)()) F997_8621_3700_2;
	R3700[805] = (char *(*)()) F999_8716_3700_2;
	R3700[806] = (char *(*)()) F1000_8716_3700_2;
	R3700[808] = (char *(*)()) F1002_8811_3700_2;
	R3700[809] = (char *(*)()) F1003_8811_3700_2;
	R3700[811] = (char *(*)()) F1005_8880_3700_2;
	R3700[812] = (char *(*)()) F1006_8880_3700_2;
	{long i; for (i = 856; i < 858; i++) R3700[i] = (char *(*)()) F1049_9148;}
	{long i; for (i = 859; i < 861; i++) R3700[i] = (char *(*)()) F1052_9316;}
}
static EIF_BOOLEAN F969_7930_3700_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F969_7930(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F970_7930_3700_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F970_7930(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F981_8135_3700_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F981_8135(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F982_8135_3700_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F982_8135(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F984_8234_3700_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F984_8234(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F985_8234_3700_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F985_8234(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F987_8333_3700_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F987_8333(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F988_8333_3700_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F988_8333(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F990_8432_3700_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F990_8432(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F991_8432_3700_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F991_8432(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F993_8527_3700_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F993_8527(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F994_8527_3700_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F994_8527(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F996_8621_3700_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F996_8621(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F997_8621_3700_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F997_8621(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F999_8716_3700_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F999_8716(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F1000_8716_3700_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1000_8716(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F1002_8811_3700_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1002_8811(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F1003_8811_3700_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1003_8811(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F1005_8880_3700_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1005_8880(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F1006_8880_3700_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1006_8880(Current, *(EIF_REAL_32 *)arg1);
}

char *(*R3786[40])();
void R3786_init () {
	R3786[0] = (char *(*)()) F201_3854;
	{long i; for (i = 1; i < 3; i++) R3786[i] = (char *(*)()) F202_3878;}
	R3786[5] = (char *(*)()) F206_3881;
	R3786[7] = (char *(*)()) F208_3883;
	R3786[8] = (char *(*)()) F209_3887;
	R3786[9] = (char *(*)()) F210_3893;
	R3786[11] = (char *(*)()) F212_3910;
	R3786[12] = (char *(*)()) F213_3912;
	R3786[13] = (char *(*)()) F214_3914;
	R3786[15] = (char *(*)()) F216_3916;
	R3786[16] = (char *(*)()) F217_3920;
	R3786[19] = (char *(*)()) F220_3922;
	R3786[20] = (char *(*)()) F221_3924;
	R3786[22] = (char *(*)()) F223_3928;
	R3786[23] = (char *(*)()) F224_3934;
	R3786[24] = (char *(*)()) F225_3936;
	R3786[26] = (char *(*)()) F227_3938;
	R3786[27] = (char *(*)()) F228_3940;
	R3786[28] = (char *(*)()) F229_3944;
	R3786[29] = (char *(*)()) F230_3948;
	R3786[31] = (char *(*)()) F232_3950;
	R3786[32] = (char *(*)()) F233_3952;
	R3786[34] = (char *(*)()) F235_3954;
	R3786[35] = (char *(*)()) F236_3956;
	R3786[36] = (char *(*)()) F237_3958;
	R3786[37] = (char *(*)()) F238_3960;
	R3786[38] = (char *(*)()) F239_3964;
	R3786[39] = (char *(*)()) F240_3966;
}

char *(*R4126[3])();
void R4126_init () {
	R4126[0] = (char *(*)()) F247_4248;
	R4126[1] = (char *(*)()) F248_4248;
	R4126[2] = (char *(*)()) F249_4248;
}

char *(*R4199[655])();
void R4199_init () {
	R4199[0] = (char *(*)()) F256_4327;
	R4199[654] = (char *(*)()) F910_6689;
}

char *(*R4499[13])();
void R4499_init () {
	R4499[0] = (char *(*)()) F273_4644;
	R4499[9] = (char *(*)()) F282_4684;
	R4499[10] = (char *(*)()) F283_4692;
	R4499[11] = (char *(*)()) F284_4700;
	R4499[12] = (char *(*)()) F285_4708;
}

char *(*R4511[11])();
void R4511_init () {
	R4511[0] = (char *(*)()) F282_4683;
	R4511[1] = (char *(*)()) F283_4691;
	R4511[2] = (char *(*)()) F284_4699;
	R4511[3] = (char *(*)()) F285_4707;
	R4511[7] = (char *(*)()) F280_4676;
	R4511[8] = (char *(*)()) F277_4663;
	R4511[9] = (char *(*)()) F278_4668;
	R4511[10] = (char *(*)()) F292_4737;
}

char *(*R4517[11])();
void R4517_init () {
	R4517[0] = (char *(*)()) F282_4686;
	R4517[1] = (char *(*)()) F283_4695;
	R4517[2] = (char *(*)()) F284_4703;
	R4517[3] = (char *(*)()) F285_4711;
	R4517[7] = (char *(*)()) F289_4722;
	R4517[8] = (char *(*)()) F290_4727;
	R4517[9] = (char *(*)()) F291_4732;
	R4517[10] = (char *(*)()) F292_4738;
}

char *(*R4518[11])();
void R4518_init () {
	R4518[0] = (char *(*)()) F282_4689;
	R4518[1] = (char *(*)()) F283_4697;
	R4518[2] = (char *(*)()) F284_4705;
	R4518[3] = (char *(*)()) F285_4713;
	R4518[7] = (char *(*)()) F289_4725;
	R4518[8] = (char *(*)()) F290_4730;
	R4518[9] = (char *(*)()) F291_4735;
	R4518[10] = (char *(*)()) F292_4741;
}

char *(*R4529[10])();
void R4529_init () {
	R4529[0] = (char *(*)()) F282_4687;
	R4529[9] = (char *(*)()) F291_4733;
}

char *(*R4532[10])();
void R4532_init () {
	R4532[0] = (char *(*)()) F282_4690;
	R4532[9] = (char *(*)()) F291_4736;
}

char *(*R4535[7])();
void R4535_init () {
	R4535[0] = (char *(*)()) F283_4696;
	R4535[6] = (char *(*)()) F289_4723;
}

char *(*R4538[7])();
void R4538_init () {
	R4538[0] = (char *(*)()) F283_4698;
	R4538[6] = (char *(*)()) F289_4726;
}

char *(*R4562[477])();
void R4562_init () {
	R4562[0] = (char *(*)()) F293_4743;
	R4562[1] = (char *(*)()) F294_4743;
	R4562[2] = (char *(*)()) F295_4743;
	R4562[3] = (char *(*)()) F296_4743;
	R4562[4] = (char *(*)()) F297_4743;
	R4562[5] = (char *(*)()) F298_4743;
	R4562[6] = (char *(*)()) F299_4743;
	R4562[7] = (char *(*)()) F300_4743;
	R4562[8] = (char *(*)()) F301_4743;
	R4562[9] = (char *(*)()) F302_4743;
	R4562[10] = (char *(*)()) F303_4743;
	R4562[11] = (char *(*)()) F304_4743;
	R4562[79] = (char *(*)()) F293_4743;
	R4562[80] = (char *(*)()) F294_4743;
	R4562[81] = (char *(*)()) F295_4743;
	R4562[82] = (char *(*)()) F296_4743;
	R4562[83] = (char *(*)()) F297_4743;
	R4562[84] = (char *(*)()) F298_4743;
	R4562[85] = (char *(*)()) F299_4743;
	R4562[86] = (char *(*)()) F300_4743;
	R4562[87] = (char *(*)()) F301_4743;
	R4562[88] = (char *(*)()) F302_4743;
	R4562[89] = (char *(*)()) F303_4743;
	R4562[90] = (char *(*)()) F304_4743;
	R4562[91] = (char *(*)()) F293_4743;
	R4562[92] = (char *(*)()) F294_4743;
	R4562[93] = (char *(*)()) F299_4743;
	R4562[98] = (char *(*)()) F293_4743;
	R4562[99] = (char *(*)()) F294_4743;
	{long i; for (i = 100; i < 104; i++) R4562[i] = (char *(*)()) F293_4743;}
	R4562[108] = (char *(*)()) F293_4743;
	R4562[110] = (char *(*)()) F293_4743;
	R4562[112] = (char *(*)()) F293_4743;
	R4562[116] = (char *(*)()) F293_4743;
	{long i; for (i = 118; i < 122; i++) R4562[i] = (char *(*)()) F293_4743;}
	R4562[124] = (char *(*)()) F297_4743;
	R4562[473] = (char *(*)()) F301_4743;
	R4562[476] = (char *(*)()) F302_4743;
}

char *(*R4563[477])();
void R4563_init () {
	R4563[0] = (char *(*)()) F293_4744;
	R4563[1] = (char *(*)()) F294_4744_4563_250;
	R4563[2] = (char *(*)()) F295_4744_4563_250;
	R4563[3] = (char *(*)()) F296_4744_4563_250;
	R4563[4] = (char *(*)()) F297_4744_4563_250;
	R4563[5] = (char *(*)()) F298_4744_4563_250;
	R4563[6] = (char *(*)()) F299_4744_4563_250;
	R4563[7] = (char *(*)()) F300_4744_4563_250;
	R4563[8] = (char *(*)()) F301_4744_4563_250;
	R4563[9] = (char *(*)()) F302_4744_4563_250;
	R4563[10] = (char *(*)()) F303_4744_4563_250;
	R4563[11] = (char *(*)()) F304_4744_4563_250;
	R4563[79] = (char *(*)()) F293_4744;
	R4563[80] = (char *(*)()) F294_4744_4563_250;
	R4563[81] = (char *(*)()) F295_4744_4563_250;
	R4563[82] = (char *(*)()) F296_4744_4563_250;
	R4563[83] = (char *(*)()) F297_4744_4563_250;
	R4563[84] = (char *(*)()) F298_4744_4563_250;
	R4563[85] = (char *(*)()) F299_4744_4563_250;
	R4563[86] = (char *(*)()) F300_4744_4563_250;
	R4563[87] = (char *(*)()) F301_4744_4563_250;
	R4563[88] = (char *(*)()) F302_4744_4563_250;
	R4563[89] = (char *(*)()) F303_4744_4563_250;
	R4563[90] = (char *(*)()) F304_4744_4563_250;
	R4563[91] = (char *(*)()) F293_4744;
	R4563[92] = (char *(*)()) F294_4744_4563_250;
	R4563[93] = (char *(*)()) F299_4744_4563_250;
	R4563[98] = (char *(*)()) F293_4744;
	R4563[99] = (char *(*)()) F294_4744_4563_250;
	{long i; for (i = 100; i < 104; i++) R4563[i] = (char *(*)()) F293_4744;}
	R4563[108] = (char *(*)()) F293_4744;
	R4563[110] = (char *(*)()) F293_4744;
	R4563[112] = (char *(*)()) F293_4744;
	R4563[116] = (char *(*)()) F293_4744;
	{long i; for (i = 118; i < 122; i++) R4563[i] = (char *(*)()) F293_4744;}
	R4563[124] = (char *(*)()) F297_4744_4563_250;
	R4563[473] = (char *(*)()) F301_4744_4563_250;
	R4563[476] = (char *(*)()) F302_4744_4563_250;
}
static void F294_4744_4563_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F294_4744(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F295_4744_4563_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F295_4744(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F296_4744_4563_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F296_4744(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F297_4744_4563_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F297_4744(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F298_4744_4563_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F298_4744(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F299_4744_4563_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F299_4744(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F300_4744_4563_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F300_4744(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F301_4744_4563_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F301_4744(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F302_4744_4563_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F302_4744(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F303_4744_4563_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F303_4744(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F304_4744_4563_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F304_4744(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R4569[477])();
void R4569_init () {
	R4569[0] = (char *(*)()) F293_4750;
	R4569[1] = (char *(*)()) F294_4750;
	R4569[2] = (char *(*)()) F295_4750;
	R4569[3] = (char *(*)()) F296_4750;
	R4569[4] = (char *(*)()) F297_4750;
	R4569[5] = (char *(*)()) F298_4750;
	R4569[6] = (char *(*)()) F299_4750;
	R4569[7] = (char *(*)()) F300_4750;
	R4569[8] = (char *(*)()) F301_4750;
	R4569[9] = (char *(*)()) F302_4750;
	R4569[10] = (char *(*)()) F303_4750;
	R4569[11] = (char *(*)()) F304_4750;
	R4569[79] = (char *(*)()) F293_4750;
	R4569[80] = (char *(*)()) F294_4750;
	R4569[81] = (char *(*)()) F295_4750;
	R4569[82] = (char *(*)()) F296_4750;
	R4569[83] = (char *(*)()) F297_4750;
	R4569[84] = (char *(*)()) F298_4750;
	R4569[85] = (char *(*)()) F299_4750;
	R4569[86] = (char *(*)()) F300_4750;
	R4569[87] = (char *(*)()) F301_4750;
	R4569[88] = (char *(*)()) F302_4750;
	R4569[89] = (char *(*)()) F303_4750;
	R4569[90] = (char *(*)()) F304_4750;
	R4569[91] = (char *(*)()) F293_4750;
	R4569[92] = (char *(*)()) F294_4750;
	R4569[93] = (char *(*)()) F299_4750;
	R4569[98] = (char *(*)()) F293_4750;
	R4569[99] = (char *(*)()) F294_4750;
	{long i; for (i = 100; i < 104; i++) R4569[i] = (char *(*)()) F293_4750;}
	R4569[108] = (char *(*)()) F293_4750;
	R4569[110] = (char *(*)()) F293_4750;
	R4569[112] = (char *(*)()) F293_4750;
	R4569[116] = (char *(*)()) F293_4750;
	{long i; for (i = 118; i < 122; i++) R4569[i] = (char *(*)()) F293_4750;}
	R4569[124] = (char *(*)()) F297_4750;
	R4569[473] = (char *(*)()) F301_4750;
	R4569[476] = (char *(*)()) F302_4750;
}

static EIF_TYPE_INDEX Y4570_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype24[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype46[] = {0xFF01,1094,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype47[] = {0xFF01,1040,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype48[] = {0xFF01,1040,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype49[] = {0xFF01,1040,0xFFF9,1,966,0xFF01,0,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype50[] = {0xFF01,1040,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype51[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,984,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype52[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,984,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype53[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1164,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype54[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1169,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype55[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype56[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1101,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype57[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,927,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype58[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1371,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype59[] = {0xFF01,1040,0xFF01,0xFFF9,5,966,996,984,984,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype60[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1050,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype61[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,984,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype62[] = {0xFF01,1040,0xFF01,0xFFF9,4,966,984,984,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype63[] = {0xFF01,1040,0xFF01,0xFFF9,2,966,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype64[] = {0xFF01,1040,0xFF01,0xFFF9,7,966,984,984,969,969,969,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype65[] = {0xFF01,1040,0xFF01,0xFFF9,3,966,984,984,927,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype66[] = {0xFF01,1040,0xFF01,0xFFF9,8,966,984,984,984,969,969,969,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype67[] = {0xFF01,1040,0xFF01,0xFFF9,0,966,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype68[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype69[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype70[] = {972,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype71[] = {975,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype72[] = {975,0xFFFF};
static EIF_TYPE_INDEX Y4570_pgtype73[] = {0xFF01,1050,0xFFFF};
EIF_TYPE_INDEX *Y4570_gen_type [873];
EIF_TYPE_INDEX Y4570 [873];
void Y4570_init (void)
{
	egc_routines_types [4570] = Y4570;
	egc_routines_gen_types [4570] = Y4570_gen_type;
	egc_routines_offset [4570] = 292;
	Y4570_gen_type [0] = Y4570_pgtype0;
	Y4570_gen_type [1] = Y4570_pgtype1;
	Y4570_gen_type [2] = Y4570_pgtype2;
	Y4570_gen_type [3] = Y4570_pgtype3;
	Y4570_gen_type [4] = Y4570_pgtype4;
	Y4570_gen_type [5] = Y4570_pgtype5;
	Y4570_gen_type [6] = Y4570_pgtype6;
	Y4570_gen_type [7] = Y4570_pgtype7;
	Y4570_gen_type [8] = Y4570_pgtype8;
	Y4570_gen_type [9] = Y4570_pgtype9;
	Y4570_gen_type [10] = Y4570_pgtype10;
	Y4570_gen_type [11] = Y4570_pgtype11;
	Y4570_gen_type [285] = Y4570_pgtype12;
	Y4570_gen_type [286] = Y4570_pgtype13;
	Y4570_gen_type [287] = Y4570_pgtype14;
	Y4570_gen_type [288] = Y4570_pgtype15;
	Y4570_gen_type [289] = Y4570_pgtype16;
	Y4570_gen_type [290] = Y4570_pgtype17;
	Y4570_gen_type [291] = Y4570_pgtype18;
	Y4570_gen_type [292] = Y4570_pgtype19;
	Y4570_gen_type [293] = Y4570_pgtype20;
	Y4570_gen_type [294] = Y4570_pgtype21;
	Y4570_gen_type [295] = Y4570_pgtype22;
	Y4570_gen_type [296] = Y4570_pgtype23;
	Y4570_gen_type [297] = Y4570_pgtype24;
	Y4570_gen_type [364] = Y4570_pgtype25;
	Y4570_gen_type [365] = Y4570_pgtype26;
	Y4570_gen_type [366] = Y4570_pgtype27;
	Y4570_gen_type [367] = Y4570_pgtype28;
	Y4570_gen_type [368] = Y4570_pgtype29;
	Y4570_gen_type [369] = Y4570_pgtype30;
	Y4570_gen_type [370] = Y4570_pgtype31;
	Y4570_gen_type [371] = Y4570_pgtype32;
	Y4570_gen_type [372] = Y4570_pgtype33;
	Y4570_gen_type [373] = Y4570_pgtype34;
	Y4570_gen_type [374] = Y4570_pgtype35;
	Y4570_gen_type [375] = Y4570_pgtype36;
	Y4570_gen_type [376] = Y4570_pgtype37;
	Y4570_gen_type [377] = Y4570_pgtype38;
	Y4570_gen_type [378] = Y4570_pgtype39;
	Y4570_gen_type [379] = Y4570_pgtype40;
	Y4570_gen_type [380] = Y4570_pgtype41;
	Y4570_gen_type [381] = Y4570_pgtype42;
	Y4570_gen_type [382] = Y4570_pgtype43;
	Y4570_gen_type [383] = Y4570_pgtype44;
	Y4570_gen_type [384] = Y4570_pgtype45;
	Y4570_gen_type [385] = Y4570_pgtype46;
	Y4570_gen_type [386] = Y4570_pgtype47;
	Y4570_gen_type [387] = Y4570_pgtype48;
	Y4570_gen_type [388] = Y4570_pgtype49;
	Y4570_gen_type [389] = Y4570_pgtype50;
	Y4570_gen_type [390] = Y4570_pgtype51;
	Y4570_gen_type [391] = Y4570_pgtype52;
	Y4570_gen_type [392] = Y4570_pgtype53;
	Y4570_gen_type [393] = Y4570_pgtype54;
	Y4570_gen_type [394] = Y4570_pgtype55;
	Y4570_gen_type [395] = Y4570_pgtype56;
	Y4570_gen_type [396] = Y4570_pgtype57;
	Y4570_gen_type [397] = Y4570_pgtype58;
	Y4570_gen_type [398] = Y4570_pgtype59;
	Y4570_gen_type [399] = Y4570_pgtype60;
	Y4570_gen_type [400] = Y4570_pgtype61;
	Y4570_gen_type [401] = Y4570_pgtype62;
	Y4570_gen_type [402] = Y4570_pgtype63;
	Y4570_gen_type [403] = Y4570_pgtype64;
	Y4570_gen_type [404] = Y4570_pgtype65;
	Y4570_gen_type [405] = Y4570_pgtype66;
	Y4570_gen_type [406] = Y4570_pgtype67;
	Y4570_gen_type [409] = Y4570_pgtype68;
	Y4570_gen_type [410] = Y4570_pgtype69;
	Y4570_gen_type [758] = Y4570_pgtype70;
	Y4570_gen_type [761] = Y4570_pgtype71;
	Y4570_gen_type [762] = Y4570_pgtype72;
	Y4570_gen_type [872] = Y4570_pgtype73;
	Y4570[297] = 1002;
	Y4570[385] = 1094;
	{long i; for (i = 386; i < 407; i++) Y4570[i] = 1040;};
	{long i; for (i = 409; i < 411; i++) Y4570[i] = 1002;};
	Y4570[758] = 972;
	{long i; for (i = 761; i < 763; i++) Y4570[i] = 975;};
	Y4570[872] = 1050;
}

char *(*R4687[236])();
void R4687_init () {
	R4687[0] = (char *(*)()) F1144_10452;
	R4687[235] = (char *(*)()) F1379_14208;
}

char *(*R4699[236])();
void R4699_init () {
	R4699[0] = (char *(*)()) F311_4896;
	R4699[235] = (char *(*)()) F1378_14195;
}

char *(*R4700[236])();
void R4700_init () {
	R4700[0] = (char *(*)()) F311_4898;
	R4700[235] = (char *(*)()) F1378_14196;
}

char *(*R4702[236])();
void R4702_init () {
	R4702[0] = (char *(*)()) F310_4884;
	R4702[235] = (char *(*)()) F1378_14200;
}

char *(*R4706[236])();
void R4706_init () {
	R4706[0] = (char *(*)()) F311_4903;
	R4706[235] = (char *(*)()) F310_4888;
}

char *(*R4759[1046])();
void R4759_init () {
	R4759[0] = (char *(*)()) F328_4974;
	R4759[7] = (char *(*)()) F335_4996;
	R4759[22] = (char *(*)()) F348_5040;
	R4759[248] = (char *(*)()) F553_5295;
	R4759[250] = (char *(*)()) F578_5358;
	R4759[251] = (char *(*)()) F579_5358;
	R4759[252] = (char *(*)()) F580_5358;
	R4759[253] = (char *(*)()) F581_5358;
	R4759[254] = (char *(*)()) F582_5358;
	R4759[255] = (char *(*)()) F583_5358;
	R4759[256] = (char *(*)()) F584_5358;
	R4759[257] = (char *(*)()) F585_5358;
	R4759[258] = (char *(*)()) F586_5358;
	R4759[259] = (char *(*)()) F587_5358;
	R4759[260] = (char *(*)()) F588_5358;
	R4759[261] = (char *(*)()) F589_5358;
	R4759[311] = (char *(*)()) F639_5486;
	R4759[312] = (char *(*)()) F640_5486;
	R4759[313] = (char *(*)()) F641_5486;
	{long i; for (i = 314; i < 316; i++) R4759[i] = (char *(*)()) F639_5486;}
	R4759[316] = (char *(*)()) F641_5486;
	R4759[317] = (char *(*)()) F640_5486;
	R4759[320] = (char *(*)()) F648_5607;
	R4759[321] = (char *(*)()) F649_5607;
	R4759[322] = (char *(*)()) F650_5607;
	R4759[323] = (char *(*)()) F651_5607;
	R4759[324] = (char *(*)()) F652_5607;
	R4759[325] = (char *(*)()) F653_5607;
	R4759[326] = (char *(*)()) F648_5607;
	R4759[327] = (char *(*)()) F649_5607;
	R4759[328] = (char *(*)()) F648_5607;
	R4759[329] = (char *(*)()) F657_5737;
	R4759[330] = (char *(*)()) F658_5737;
	R4759[331] = (char *(*)()) F659_5737;
	R4759[332] = (char *(*)()) F660_5737;
	R4759[333] = (char *(*)()) F661_5737;
	R4759[334] = (char *(*)()) F662_5737;
	R4759[335] = (char *(*)()) F663_5737;
	R4759[336] = (char *(*)()) F664_5737;
	R4759[337] = (char *(*)()) F665_5737;
	R4759[338] = (char *(*)()) F666_5737;
	R4759[339] = (char *(*)()) F667_5737;
	R4759[340] = (char *(*)()) F668_5737;
	R4759[341] = (char *(*)()) F657_5737;
	R4759[342] = (char *(*)()) F658_5737;
	R4759[343] = (char *(*)()) F663_5737;
	R4759[348] = (char *(*)()) F657_5737;
	R4759[349] = (char *(*)()) F658_5737;
	{long i; for (i = 350; i < 354; i++) R4759[i] = (char *(*)()) F657_5737;}
	R4759[358] = (char *(*)()) F657_5737;
	R4759[360] = (char *(*)()) F657_5737;
	R4759[362] = (char *(*)()) F657_5737;
	R4759[366] = (char *(*)()) F657_5737;
	{long i; for (i = 368; i < 372; i++) R4759[i] = (char *(*)()) F657_5737;}
	R4759[394] = (char *(*)()) F722_6103;
	R4759[399] = (char *(*)()) F727_6164;
	R4759[430] = (char *(*)()) F758_6197;
	R4759[431] = (char *(*)()) F759_6197;
	R4759[432] = (char *(*)()) F760_6197;
	R4759[433] = (char *(*)()) F761_6197;
	R4759[434] = (char *(*)()) F762_6197;
	R4759[435] = (char *(*)()) F763_6197;
	R4759[436] = (char *(*)()) F764_6197;
	R4759[437] = (char *(*)()) F765_6197;
	R4759[438] = (char *(*)()) F766_6197;
	R4759[439] = (char *(*)()) F767_6197;
	R4759[440] = (char *(*)()) F768_6197;
	R4759[441] = (char *(*)()) F769_6197;
	R4759[442] = (char *(*)()) F758_6197;
	R4759[443] = (char *(*)()) F759_6197;
	R4759[444] = (char *(*)()) F765_6197;
	R4759[445] = (char *(*)()) F758_6197;
	R4759[446] = (char *(*)()) F759_6197;
	R4759[447] = (char *(*)()) F758_6197;
	{long i; for (i = 448; i < 450; i++) R4759[i] = (char *(*)()) F759_6197;}
	R4759[450] = (char *(*)()) F766_6197;
	R4759[463] = (char *(*)()) F791_6247;
	R4759[464] = (char *(*)()) F792_6247;
	R4759[465] = (char *(*)()) F793_6247;
	R4759[466] = (char *(*)()) F794_6247;
	R4759[467] = (char *(*)()) F795_6247;
	R4759[468] = (char *(*)()) F796_6247;
	R4759[469] = (char *(*)()) F797_6247;
	R4759[470] = (char *(*)()) F798_6247;
	R4759[471] = (char *(*)()) F799_6247;
	R4759[472] = (char *(*)()) F800_6247;
	R4759[473] = (char *(*)()) F801_6247;
	R4759[474] = (char *(*)()) F802_6247;
	R4759[475] = (char *(*)()) F803_6253;
	R4759[476] = (char *(*)()) F804_6259;
	R4759[477] = (char *(*)()) F805_6265;
	R4759[478] = (char *(*)()) F806_6265;
	R4759[479] = (char *(*)()) F807_6265;
	R4759[480] = (char *(*)()) F808_6265;
	R4759[481] = (char *(*)()) F809_6265;
	R4759[482] = (char *(*)()) F810_6265;
	R4759[483] = (char *(*)()) F811_6265;
	R4759[484] = (char *(*)()) F812_6265;
	R4759[485] = (char *(*)()) F813_6265;
	R4759[486] = (char *(*)()) F814_6265;
	R4759[487] = (char *(*)()) F815_6265;
	R4759[488] = (char *(*)()) F816_6265;
	R4759[489] = (char *(*)()) F817_6271;
	R4759[490] = (char *(*)()) F818_6271;
	R4759[491] = (char *(*)()) F819_6271;
	R4759[492] = (char *(*)()) F820_6271;
	R4759[493] = (char *(*)()) F821_6271;
	R4759[494] = (char *(*)()) F822_6271;
	R4759[495] = (char *(*)()) F823_6271;
	R4759[496] = (char *(*)()) F824_6271;
	R4759[497] = (char *(*)()) F825_6271;
	R4759[498] = (char *(*)()) F826_6271;
	R4759[499] = (char *(*)()) F827_6271;
	R4759[500] = (char *(*)()) F828_6271;
	R4759[504] = (char *(*)()) F832_6338;
	R4759[507] = (char *(*)()) F835_6414;
	R4759[508] = (char *(*)()) F836_6414;
	R4759[509] = (char *(*)()) F837_6414;
	R4759[510] = (char *(*)()) F838_6414;
	R4759[511] = (char *(*)()) F839_6414;
	R4759[512] = (char *(*)()) F840_6414;
	R4759[513] = (char *(*)()) F841_6414;
	R4759[514] = (char *(*)()) F842_6414;
	R4759[515] = (char *(*)()) F843_6414;
	R4759[516] = (char *(*)()) F844_6414;
	R4759[517] = (char *(*)()) F845_6414;
	R4759[518] = (char *(*)()) F846_6414;
	{long i; for (i = 592; i < 594; i++) R4759[i] = (char *(*)()) F919_7182;}
	R4759[639] = (char *(*)()) F552_5295;
	{long i; for (i = 722; i < 724; i++) R4759[i] = (char *(*)()) F1049_9138;}
	{long i; for (i = 725; i < 727; i++) R4759[i] = (char *(*)()) F1052_9306;}
	{long i; for (i = 805; i < 808; i++) R4759[i] = (char *(*)()) F552_5295;}
	{long i; for (i = 808; i < 810; i++) R4759[i] = (char *(*)()) F1128_10236;}
	{long i; for (i = 811; i < 813; i++) R4759[i] = (char *(*)()) F1128_10236;}
	{long i; for (i = 816; i < 819; i++) R4759[i] = (char *(*)()) F1128_10236;}
	R4759[820] = (char *(*)()) F1128_10236;
	R4759[848] = (char *(*)()) F552_5295;
	R4759[858] = (char *(*)()) F552_5295;
	R4759[1045] = (char *(*)()) F1373_14092;
}

static EIF_TYPE_INDEX Y4760_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype12[] = {0xFF01,1053,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype13[] = {0xFF01,1049,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype20[] = {0xFF01,831,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype123[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype124[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype125[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype126[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype127[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype128[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype129[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype130[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype131[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype132[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype133[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype134[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype135[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype136[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype137[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype138[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype139[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype140[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype141[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype142[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype143[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype144[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype145[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype146[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype147[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype148[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype149[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype150[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype151[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype152[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype153[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype154[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype155[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype156[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype157[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype158[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype159[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype160[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype161[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype162[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype163[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype164[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype165[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype166[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype167[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype168[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype169[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype170[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype171[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype172[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype173[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype174[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype175[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype176[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype177[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype178[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype179[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype180[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype181[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype182[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype183[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype184[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype185[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype186[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype187[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype188[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype189[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype190[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype191[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype192[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype193[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype194[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype195[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype196[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype197[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype198[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype199[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype200[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype201[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype202[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype203[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype204[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype205[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype206[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype207[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype208[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype209[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype210[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype211[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype212[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype213[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype214[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype215[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype216[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype217[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype218[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype219[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype220[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype221[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype222[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype223[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype224[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype225[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype226[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype227[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype228[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype229[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype230[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype231[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype232[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype233[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype234[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype235[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype236[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype237[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype238[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype239[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype240[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype241[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype242[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype243[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype244[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype245[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype246[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype247[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype248[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype249[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype250[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype251[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype252[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype253[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype254[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype255[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype256[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype257[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype258[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype259[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype260[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype261[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype262[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype263[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype264[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype265[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype266[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype267[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype268[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype269[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype270[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype271[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype272[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype273[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype274[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype275[] = {1002,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype276[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype277[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype278[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype279[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype280[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype281[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype282[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype283[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype284[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype285[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype286[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype287[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype288[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype289[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype290[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype291[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype292[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype293[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype294[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype295[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype296[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype297[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype298[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype299[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype300[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype301[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype302[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype303[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype304[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype305[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype306[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype307[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype308[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype309[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype310[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype311[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype312[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype313[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype314[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype315[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype316[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype317[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype318[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype319[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype320[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype321[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype322[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype323[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype324[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype325[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype326[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype327[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype328[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype329[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype330[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype331[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype332[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype333[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype334[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype335[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype336[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype337[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype338[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype339[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype340[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype341[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype342[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype343[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype344[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype345[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype346[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype347[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype348[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype349[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype350[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype351[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype352[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype353[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype354[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype355[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype356[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype357[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype358[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype359[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype360[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype361[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype362[] = {0xFF01,1094,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype363[] = {0xFF01,1040,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype364[] = {0xFF01,1040,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype365[] = {0xFF01,1040,0xFFF9,1,966,0xFF01,0,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype366[] = {0xFF01,1040,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype367[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,984,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype368[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,984,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype369[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1164,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype370[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1169,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype371[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype372[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1101,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype373[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,927,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype374[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1371,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype375[] = {0xFF01,1040,0xFF01,0xFFF9,5,966,996,984,984,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype376[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1050,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype377[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,984,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype378[] = {0xFF01,1040,0xFF01,0xFFF9,4,966,984,984,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype379[] = {0xFF01,1040,0xFF01,0xFFF9,2,966,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype380[] = {0xFF01,1040,0xFF01,0xFFF9,7,966,984,984,969,969,969,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype381[] = {0xFF01,1040,0xFF01,0xFFF9,3,966,984,984,927,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype382[] = {0xFF01,1040,0xFF01,0xFFF9,8,966,984,984,984,969,969,969,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype383[] = {0xFF01,1040,0xFF01,0xFFF9,0,966,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype384[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype385[] = {0xFF01,30,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype386[] = {972,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype387[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype388[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype389[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype390[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype391[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype392[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype393[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype394[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype395[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype396[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype397[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype398[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype399[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype400[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype401[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype402[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype403[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype404[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype405[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype406[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype407[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype408[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype409[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype410[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype411[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype412[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype413[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype414[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype415[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype416[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype417[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype418[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype419[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype420[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype421[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype422[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype423[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype424[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype425[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype426[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype427[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype428[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype429[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype430[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype431[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype432[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype433[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype434[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype435[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype436[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype437[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype438[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype439[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype440[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype441[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype442[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype443[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype444[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype445[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype446[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype447[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype448[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype449[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype450[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype451[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype452[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype453[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype454[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype455[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype456[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype457[] = {972,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype458[] = {975,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype459[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype460[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype461[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype462[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype463[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype464[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype465[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype466[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype467[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype468[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype469[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype470[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype471[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype472[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype473[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype474[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype475[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype476[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype477[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype478[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype479[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype480[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype481[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype482[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype483[] = {0xFF01,1048,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype484[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype485[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype486[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype487[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype488[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype489[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype490[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype491[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype492[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype493[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype494[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype495[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype496[] = {975,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype497[] = {975,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype498[] = {975,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype499[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype500[] = {972,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype501[] = {972,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype502[] = {972,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype503[] = {975,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype504[] = {975,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype505[] = {975,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype506[] = {975,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype507[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype508[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype509[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype510[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype511[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype512[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype513[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype514[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype515[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype516[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype517[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype518[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype519[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype520[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype521[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype522[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype523[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype524[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype525[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype526[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype527[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype528[] = {0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype529[] = {0xFF01,1050,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype530[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype531[] = {0xFF01,1164,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype532[] = {0xFF01,1165,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype533[] = {0xFF01,1163,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype534[] = {0xFF01,1163,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype535[] = {0xFF01,1163,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype536[] = {0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype537[] = {0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype538[] = {0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype539[] = {0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype540[] = {0xFF01,1169,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype541[] = {0xFF01,1169,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype542[] = {0xFF01,1169,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype543[] = {975,0xFFFF};
EIF_TYPE_INDEX *Y4760_gen_type [1059];
EIF_TYPE_INDEX Y4760 [1059];
void Y4760_init (void)
{
	egc_routines_types [4760] = Y4760;
	egc_routines_gen_types [4760] = Y4760_gen_type;
	egc_routines_offset [4760] = 314;
	Y4760_gen_type [0] = Y4760_pgtype0;
	Y4760_gen_type [1] = Y4760_pgtype1;
	Y4760_gen_type [2] = Y4760_pgtype2;
	Y4760_gen_type [3] = Y4760_pgtype3;
	Y4760_gen_type [4] = Y4760_pgtype4;
	Y4760_gen_type [5] = Y4760_pgtype5;
	Y4760_gen_type [6] = Y4760_pgtype6;
	Y4760_gen_type [7] = Y4760_pgtype7;
	Y4760_gen_type [8] = Y4760_pgtype8;
	Y4760_gen_type [9] = Y4760_pgtype9;
	Y4760_gen_type [10] = Y4760_pgtype10;
	Y4760_gen_type [11] = Y4760_pgtype11;
	Y4760_gen_type [12] = Y4760_pgtype12;
	Y4760_gen_type [13] = Y4760_pgtype13;
	Y4760_gen_type [14] = Y4760_pgtype14;
	Y4760_gen_type [15] = Y4760_pgtype15;
	Y4760_gen_type [16] = Y4760_pgtype16;
	Y4760_gen_type [17] = Y4760_pgtype17;
	Y4760_gen_type [18] = Y4760_pgtype18;
	Y4760_gen_type [19] = Y4760_pgtype19;
	Y4760_gen_type [20] = Y4760_pgtype20;
	Y4760_gen_type [21] = Y4760_pgtype21;
	Y4760_gen_type [22] = Y4760_pgtype22;
	Y4760_gen_type [23] = Y4760_pgtype23;
	Y4760_gen_type [24] = Y4760_pgtype24;
	Y4760_gen_type [25] = Y4760_pgtype25;
	Y4760_gen_type [26] = Y4760_pgtype26;
	Y4760_gen_type [27] = Y4760_pgtype27;
	Y4760_gen_type [28] = Y4760_pgtype28;
	Y4760_gen_type [29] = Y4760_pgtype29;
	Y4760_gen_type [30] = Y4760_pgtype30;
	Y4760_gen_type [31] = Y4760_pgtype31;
	Y4760_gen_type [32] = Y4760_pgtype32;
	Y4760_gen_type [33] = Y4760_pgtype33;
	Y4760_gen_type [34] = Y4760_pgtype34;
	Y4760_gen_type [35] = Y4760_pgtype35;
	Y4760_gen_type [36] = Y4760_pgtype36;
	Y4760_gen_type [37] = Y4760_pgtype37;
	Y4760_gen_type [38] = Y4760_pgtype38;
	Y4760_gen_type [39] = Y4760_pgtype39;
	Y4760_gen_type [40] = Y4760_pgtype40;
	Y4760_gen_type [41] = Y4760_pgtype41;
	Y4760_gen_type [42] = Y4760_pgtype42;
	Y4760_gen_type [43] = Y4760_pgtype43;
	Y4760_gen_type [44] = Y4760_pgtype44;
	Y4760_gen_type [45] = Y4760_pgtype45;
	Y4760_gen_type [46] = Y4760_pgtype46;
	Y4760_gen_type [47] = Y4760_pgtype47;
	Y4760_gen_type [48] = Y4760_pgtype48;
	Y4760_gen_type [49] = Y4760_pgtype49;
	Y4760_gen_type [50] = Y4760_pgtype50;
	Y4760_gen_type [51] = Y4760_pgtype51;
	Y4760_gen_type [52] = Y4760_pgtype52;
	Y4760_gen_type [53] = Y4760_pgtype53;
	Y4760_gen_type [54] = Y4760_pgtype54;
	Y4760_gen_type [55] = Y4760_pgtype55;
	Y4760_gen_type [56] = Y4760_pgtype56;
	Y4760_gen_type [57] = Y4760_pgtype57;
	Y4760_gen_type [58] = Y4760_pgtype58;
	Y4760_gen_type [59] = Y4760_pgtype59;
	Y4760_gen_type [60] = Y4760_pgtype60;
	Y4760_gen_type [61] = Y4760_pgtype61;
	Y4760_gen_type [62] = Y4760_pgtype62;
	Y4760_gen_type [63] = Y4760_pgtype63;
	Y4760_gen_type [64] = Y4760_pgtype64;
	Y4760_gen_type [65] = Y4760_pgtype65;
	Y4760_gen_type [66] = Y4760_pgtype66;
	Y4760_gen_type [67] = Y4760_pgtype67;
	Y4760_gen_type [68] = Y4760_pgtype68;
	Y4760_gen_type [69] = Y4760_pgtype69;
	Y4760_gen_type [70] = Y4760_pgtype70;
	Y4760_gen_type [71] = Y4760_pgtype71;
	Y4760_gen_type [72] = Y4760_pgtype72;
	Y4760_gen_type [73] = Y4760_pgtype73;
	Y4760_gen_type [74] = Y4760_pgtype74;
	Y4760_gen_type [75] = Y4760_pgtype75;
	Y4760_gen_type [76] = Y4760_pgtype76;
	Y4760_gen_type [77] = Y4760_pgtype77;
	Y4760_gen_type [78] = Y4760_pgtype78;
	Y4760_gen_type [79] = Y4760_pgtype79;
	Y4760_gen_type [80] = Y4760_pgtype80;
	Y4760_gen_type [81] = Y4760_pgtype81;
	Y4760_gen_type [82] = Y4760_pgtype82;
	Y4760_gen_type [83] = Y4760_pgtype83;
	Y4760_gen_type [84] = Y4760_pgtype84;
	Y4760_gen_type [85] = Y4760_pgtype85;
	Y4760_gen_type [86] = Y4760_pgtype86;
	Y4760_gen_type [87] = Y4760_pgtype87;
	Y4760_gen_type [88] = Y4760_pgtype88;
	Y4760_gen_type [89] = Y4760_pgtype89;
	Y4760_gen_type [90] = Y4760_pgtype90;
	Y4760_gen_type [91] = Y4760_pgtype91;
	Y4760_gen_type [92] = Y4760_pgtype92;
	Y4760_gen_type [93] = Y4760_pgtype93;
	Y4760_gen_type [94] = Y4760_pgtype94;
	Y4760_gen_type [95] = Y4760_pgtype95;
	Y4760_gen_type [96] = Y4760_pgtype96;
	Y4760_gen_type [97] = Y4760_pgtype97;
	Y4760_gen_type [98] = Y4760_pgtype98;
	Y4760_gen_type [99] = Y4760_pgtype99;
	Y4760_gen_type [100] = Y4760_pgtype100;
	Y4760_gen_type [101] = Y4760_pgtype101;
	Y4760_gen_type [102] = Y4760_pgtype102;
	Y4760_gen_type [103] = Y4760_pgtype103;
	Y4760_gen_type [104] = Y4760_pgtype104;
	Y4760_gen_type [105] = Y4760_pgtype105;
	Y4760_gen_type [106] = Y4760_pgtype106;
	Y4760_gen_type [107] = Y4760_pgtype107;
	Y4760_gen_type [108] = Y4760_pgtype108;
	Y4760_gen_type [109] = Y4760_pgtype109;
	Y4760_gen_type [110] = Y4760_pgtype110;
	Y4760_gen_type [111] = Y4760_pgtype111;
	Y4760_gen_type [112] = Y4760_pgtype112;
	Y4760_gen_type [113] = Y4760_pgtype113;
	Y4760_gen_type [114] = Y4760_pgtype114;
	Y4760_gen_type [115] = Y4760_pgtype115;
	Y4760_gen_type [116] = Y4760_pgtype116;
	Y4760_gen_type [117] = Y4760_pgtype117;
	Y4760_gen_type [118] = Y4760_pgtype118;
	Y4760_gen_type [119] = Y4760_pgtype119;
	Y4760_gen_type [120] = Y4760_pgtype120;
	Y4760_gen_type [121] = Y4760_pgtype121;
	Y4760_gen_type [122] = Y4760_pgtype122;
	Y4760_gen_type [123] = Y4760_pgtype123;
	Y4760_gen_type [124] = Y4760_pgtype124;
	Y4760_gen_type [125] = Y4760_pgtype125;
	Y4760_gen_type [126] = Y4760_pgtype126;
	Y4760_gen_type [127] = Y4760_pgtype127;
	Y4760_gen_type [128] = Y4760_pgtype128;
	Y4760_gen_type [129] = Y4760_pgtype129;
	Y4760_gen_type [130] = Y4760_pgtype130;
	Y4760_gen_type [131] = Y4760_pgtype131;
	Y4760_gen_type [132] = Y4760_pgtype132;
	Y4760_gen_type [133] = Y4760_pgtype133;
	Y4760_gen_type [134] = Y4760_pgtype134;
	Y4760_gen_type [135] = Y4760_pgtype135;
	Y4760_gen_type [136] = Y4760_pgtype136;
	Y4760_gen_type [137] = Y4760_pgtype137;
	Y4760_gen_type [138] = Y4760_pgtype138;
	Y4760_gen_type [139] = Y4760_pgtype139;
	Y4760_gen_type [140] = Y4760_pgtype140;
	Y4760_gen_type [141] = Y4760_pgtype141;
	Y4760_gen_type [142] = Y4760_pgtype142;
	Y4760_gen_type [143] = Y4760_pgtype143;
	Y4760_gen_type [144] = Y4760_pgtype144;
	Y4760_gen_type [145] = Y4760_pgtype145;
	Y4760_gen_type [146] = Y4760_pgtype146;
	Y4760_gen_type [147] = Y4760_pgtype147;
	Y4760_gen_type [148] = Y4760_pgtype148;
	Y4760_gen_type [149] = Y4760_pgtype149;
	Y4760_gen_type [150] = Y4760_pgtype150;
	Y4760_gen_type [151] = Y4760_pgtype151;
	Y4760_gen_type [152] = Y4760_pgtype152;
	Y4760_gen_type [153] = Y4760_pgtype153;
	Y4760_gen_type [154] = Y4760_pgtype154;
	Y4760_gen_type [155] = Y4760_pgtype155;
	Y4760_gen_type [156] = Y4760_pgtype156;
	Y4760_gen_type [157] = Y4760_pgtype157;
	Y4760_gen_type [158] = Y4760_pgtype158;
	Y4760_gen_type [159] = Y4760_pgtype159;
	Y4760_gen_type [160] = Y4760_pgtype160;
	Y4760_gen_type [161] = Y4760_pgtype161;
	Y4760_gen_type [162] = Y4760_pgtype162;
	Y4760_gen_type [163] = Y4760_pgtype163;
	Y4760_gen_type [164] = Y4760_pgtype164;
	Y4760_gen_type [165] = Y4760_pgtype165;
	Y4760_gen_type [166] = Y4760_pgtype166;
	Y4760_gen_type [167] = Y4760_pgtype167;
	Y4760_gen_type [168] = Y4760_pgtype168;
	Y4760_gen_type [169] = Y4760_pgtype169;
	Y4760_gen_type [170] = Y4760_pgtype170;
	Y4760_gen_type [171] = Y4760_pgtype171;
	Y4760_gen_type [172] = Y4760_pgtype172;
	Y4760_gen_type [173] = Y4760_pgtype173;
	Y4760_gen_type [174] = Y4760_pgtype174;
	Y4760_gen_type [175] = Y4760_pgtype175;
	Y4760_gen_type [176] = Y4760_pgtype176;
	Y4760_gen_type [177] = Y4760_pgtype177;
	Y4760_gen_type [178] = Y4760_pgtype178;
	Y4760_gen_type [179] = Y4760_pgtype179;
	Y4760_gen_type [180] = Y4760_pgtype180;
	Y4760_gen_type [181] = Y4760_pgtype181;
	Y4760_gen_type [182] = Y4760_pgtype182;
	Y4760_gen_type [183] = Y4760_pgtype183;
	Y4760_gen_type [184] = Y4760_pgtype184;
	Y4760_gen_type [185] = Y4760_pgtype185;
	Y4760_gen_type [186] = Y4760_pgtype186;
	Y4760_gen_type [187] = Y4760_pgtype187;
	Y4760_gen_type [188] = Y4760_pgtype188;
	Y4760_gen_type [189] = Y4760_pgtype189;
	Y4760_gen_type [190] = Y4760_pgtype190;
	Y4760_gen_type [191] = Y4760_pgtype191;
	Y4760_gen_type [192] = Y4760_pgtype192;
	Y4760_gen_type [193] = Y4760_pgtype193;
	Y4760_gen_type [194] = Y4760_pgtype194;
	Y4760_gen_type [195] = Y4760_pgtype195;
	Y4760_gen_type [196] = Y4760_pgtype196;
	Y4760_gen_type [197] = Y4760_pgtype197;
	Y4760_gen_type [198] = Y4760_pgtype198;
	Y4760_gen_type [199] = Y4760_pgtype199;
	Y4760_gen_type [200] = Y4760_pgtype200;
	Y4760_gen_type [201] = Y4760_pgtype201;
	Y4760_gen_type [202] = Y4760_pgtype202;
	Y4760_gen_type [203] = Y4760_pgtype203;
	Y4760_gen_type [204] = Y4760_pgtype204;
	Y4760_gen_type [205] = Y4760_pgtype205;
	Y4760_gen_type [206] = Y4760_pgtype206;
	Y4760_gen_type [207] = Y4760_pgtype207;
	Y4760_gen_type [208] = Y4760_pgtype208;
	Y4760_gen_type [209] = Y4760_pgtype209;
	Y4760_gen_type [210] = Y4760_pgtype210;
	Y4760_gen_type [211] = Y4760_pgtype211;
	Y4760_gen_type [212] = Y4760_pgtype212;
	Y4760_gen_type [213] = Y4760_pgtype213;
	Y4760_gen_type [214] = Y4760_pgtype214;
	Y4760_gen_type [215] = Y4760_pgtype215;
	Y4760_gen_type [216] = Y4760_pgtype216;
	Y4760_gen_type [217] = Y4760_pgtype217;
	Y4760_gen_type [218] = Y4760_pgtype218;
	Y4760_gen_type [219] = Y4760_pgtype219;
	Y4760_gen_type [220] = Y4760_pgtype220;
	Y4760_gen_type [221] = Y4760_pgtype221;
	Y4760_gen_type [222] = Y4760_pgtype222;
	Y4760_gen_type [223] = Y4760_pgtype223;
	Y4760_gen_type [224] = Y4760_pgtype224;
	Y4760_gen_type [225] = Y4760_pgtype225;
	Y4760_gen_type [226] = Y4760_pgtype226;
	Y4760_gen_type [227] = Y4760_pgtype227;
	Y4760_gen_type [228] = Y4760_pgtype228;
	Y4760_gen_type [229] = Y4760_pgtype229;
	Y4760_gen_type [230] = Y4760_pgtype230;
	Y4760_gen_type [231] = Y4760_pgtype231;
	Y4760_gen_type [232] = Y4760_pgtype232;
	Y4760_gen_type [233] = Y4760_pgtype233;
	Y4760_gen_type [234] = Y4760_pgtype234;
	Y4760_gen_type [235] = Y4760_pgtype235;
	Y4760_gen_type [236] = Y4760_pgtype236;
	Y4760_gen_type [237] = Y4760_pgtype237;
	Y4760_gen_type [238] = Y4760_pgtype238;
	Y4760_gen_type [239] = Y4760_pgtype239;
	Y4760_gen_type [240] = Y4760_pgtype240;
	Y4760_gen_type [241] = Y4760_pgtype241;
	Y4760_gen_type [242] = Y4760_pgtype242;
	Y4760_gen_type [243] = Y4760_pgtype243;
	Y4760_gen_type [244] = Y4760_pgtype244;
	Y4760_gen_type [245] = Y4760_pgtype245;
	Y4760_gen_type [246] = Y4760_pgtype246;
	Y4760_gen_type [247] = Y4760_pgtype247;
	Y4760_gen_type [248] = Y4760_pgtype248;
	Y4760_gen_type [249] = Y4760_pgtype249;
	Y4760_gen_type [250] = Y4760_pgtype250;
	Y4760_gen_type [251] = Y4760_pgtype251;
	Y4760_gen_type [252] = Y4760_pgtype252;
	Y4760_gen_type [253] = Y4760_pgtype253;
	Y4760_gen_type [254] = Y4760_pgtype254;
	Y4760_gen_type [255] = Y4760_pgtype255;
	Y4760_gen_type [256] = Y4760_pgtype256;
	Y4760_gen_type [257] = Y4760_pgtype257;
	Y4760_gen_type [258] = Y4760_pgtype258;
	Y4760_gen_type [259] = Y4760_pgtype259;
	Y4760_gen_type [260] = Y4760_pgtype260;
	Y4760_gen_type [261] = Y4760_pgtype261;
	Y4760_gen_type [262] = Y4760_pgtype262;
	Y4760_gen_type [263] = Y4760_pgtype263;
	Y4760_gen_type [264] = Y4760_pgtype264;
	Y4760_gen_type [265] = Y4760_pgtype265;
	Y4760_gen_type [266] = Y4760_pgtype266;
	Y4760_gen_type [267] = Y4760_pgtype267;
	Y4760_gen_type [268] = Y4760_pgtype268;
	Y4760_gen_type [269] = Y4760_pgtype269;
	Y4760_gen_type [270] = Y4760_pgtype270;
	Y4760_gen_type [271] = Y4760_pgtype271;
	Y4760_gen_type [272] = Y4760_pgtype272;
	Y4760_gen_type [273] = Y4760_pgtype273;
	Y4760_gen_type [274] = Y4760_pgtype274;
	Y4760_gen_type [275] = Y4760_pgtype275;
	Y4760_gen_type [276] = Y4760_pgtype276;
	Y4760_gen_type [277] = Y4760_pgtype277;
	Y4760_gen_type [278] = Y4760_pgtype278;
	Y4760_gen_type [279] = Y4760_pgtype279;
	Y4760_gen_type [280] = Y4760_pgtype280;
	Y4760_gen_type [281] = Y4760_pgtype281;
	Y4760_gen_type [282] = Y4760_pgtype282;
	Y4760_gen_type [283] = Y4760_pgtype283;
	Y4760_gen_type [284] = Y4760_pgtype284;
	Y4760_gen_type [285] = Y4760_pgtype285;
	Y4760_gen_type [286] = Y4760_pgtype286;
	Y4760_gen_type [287] = Y4760_pgtype287;
	Y4760_gen_type [288] = Y4760_pgtype288;
	Y4760_gen_type [289] = Y4760_pgtype289;
	Y4760_gen_type [290] = Y4760_pgtype290;
	Y4760_gen_type [291] = Y4760_pgtype291;
	Y4760_gen_type [292] = Y4760_pgtype292;
	Y4760_gen_type [293] = Y4760_pgtype293;
	Y4760_gen_type [294] = Y4760_pgtype294;
	Y4760_gen_type [295] = Y4760_pgtype295;
	Y4760_gen_type [296] = Y4760_pgtype296;
	Y4760_gen_type [297] = Y4760_pgtype297;
	Y4760_gen_type [298] = Y4760_pgtype298;
	Y4760_gen_type [299] = Y4760_pgtype299;
	Y4760_gen_type [300] = Y4760_pgtype300;
	Y4760_gen_type [301] = Y4760_pgtype301;
	Y4760_gen_type [302] = Y4760_pgtype302;
	Y4760_gen_type [303] = Y4760_pgtype303;
	Y4760_gen_type [304] = Y4760_pgtype304;
	Y4760_gen_type [305] = Y4760_pgtype305;
	Y4760_gen_type [306] = Y4760_pgtype306;
	Y4760_gen_type [307] = Y4760_pgtype307;
	Y4760_gen_type [308] = Y4760_pgtype308;
	Y4760_gen_type [309] = Y4760_pgtype309;
	Y4760_gen_type [310] = Y4760_pgtype310;
	Y4760_gen_type [311] = Y4760_pgtype311;
	Y4760_gen_type [312] = Y4760_pgtype312;
	Y4760_gen_type [313] = Y4760_pgtype313;
	Y4760_gen_type [314] = Y4760_pgtype314;
	Y4760_gen_type [315] = Y4760_pgtype315;
	Y4760_gen_type [316] = Y4760_pgtype316;
	Y4760_gen_type [317] = Y4760_pgtype317;
	Y4760_gen_type [318] = Y4760_pgtype318;
	Y4760_gen_type [319] = Y4760_pgtype319;
	Y4760_gen_type [320] = Y4760_pgtype320;
	Y4760_gen_type [321] = Y4760_pgtype321;
	Y4760_gen_type [322] = Y4760_pgtype322;
	Y4760_gen_type [323] = Y4760_pgtype323;
	Y4760_gen_type [324] = Y4760_pgtype324;
	Y4760_gen_type [325] = Y4760_pgtype325;
	Y4760_gen_type [326] = Y4760_pgtype326;
	Y4760_gen_type [327] = Y4760_pgtype327;
	Y4760_gen_type [328] = Y4760_pgtype328;
	Y4760_gen_type [329] = Y4760_pgtype329;
	Y4760_gen_type [330] = Y4760_pgtype330;
	Y4760_gen_type [332] = Y4760_pgtype331;
	Y4760_gen_type [333] = Y4760_pgtype332;
	Y4760_gen_type [334] = Y4760_pgtype333;
	Y4760_gen_type [335] = Y4760_pgtype334;
	Y4760_gen_type [336] = Y4760_pgtype335;
	Y4760_gen_type [337] = Y4760_pgtype336;
	Y4760_gen_type [338] = Y4760_pgtype337;
	Y4760_gen_type [339] = Y4760_pgtype338;
	Y4760_gen_type [340] = Y4760_pgtype339;
	Y4760_gen_type [341] = Y4760_pgtype340;
	Y4760_gen_type [342] = Y4760_pgtype341;
	Y4760_gen_type [343] = Y4760_pgtype342;
	Y4760_gen_type [344] = Y4760_pgtype343;
	Y4760_gen_type [345] = Y4760_pgtype344;
	Y4760_gen_type [346] = Y4760_pgtype345;
	Y4760_gen_type [347] = Y4760_pgtype346;
	Y4760_gen_type [348] = Y4760_pgtype347;
	Y4760_gen_type [349] = Y4760_pgtype348;
	Y4760_gen_type [350] = Y4760_pgtype349;
	Y4760_gen_type [351] = Y4760_pgtype350;
	Y4760_gen_type [352] = Y4760_pgtype351;
	Y4760_gen_type [353] = Y4760_pgtype352;
	Y4760_gen_type [354] = Y4760_pgtype353;
	Y4760_gen_type [355] = Y4760_pgtype354;
	Y4760_gen_type [356] = Y4760_pgtype355;
	Y4760_gen_type [357] = Y4760_pgtype356;
	Y4760_gen_type [358] = Y4760_pgtype357;
	Y4760_gen_type [359] = Y4760_pgtype358;
	Y4760_gen_type [360] = Y4760_pgtype359;
	Y4760_gen_type [361] = Y4760_pgtype360;
	Y4760_gen_type [362] = Y4760_pgtype361;
	Y4760_gen_type [363] = Y4760_pgtype362;
	Y4760_gen_type [364] = Y4760_pgtype363;
	Y4760_gen_type [365] = Y4760_pgtype364;
	Y4760_gen_type [366] = Y4760_pgtype365;
	Y4760_gen_type [367] = Y4760_pgtype366;
	Y4760_gen_type [368] = Y4760_pgtype367;
	Y4760_gen_type [369] = Y4760_pgtype368;
	Y4760_gen_type [370] = Y4760_pgtype369;
	Y4760_gen_type [371] = Y4760_pgtype370;
	Y4760_gen_type [372] = Y4760_pgtype371;
	Y4760_gen_type [373] = Y4760_pgtype372;
	Y4760_gen_type [374] = Y4760_pgtype373;
	Y4760_gen_type [375] = Y4760_pgtype374;
	Y4760_gen_type [376] = Y4760_pgtype375;
	Y4760_gen_type [377] = Y4760_pgtype376;
	Y4760_gen_type [378] = Y4760_pgtype377;
	Y4760_gen_type [379] = Y4760_pgtype378;
	Y4760_gen_type [380] = Y4760_pgtype379;
	Y4760_gen_type [381] = Y4760_pgtype380;
	Y4760_gen_type [382] = Y4760_pgtype381;
	Y4760_gen_type [383] = Y4760_pgtype382;
	Y4760_gen_type [384] = Y4760_pgtype383;
	Y4760_gen_type [407] = Y4760_pgtype384;
	Y4760_gen_type [410] = Y4760_pgtype385;
	Y4760_gen_type [411] = Y4760_pgtype386;
	Y4760_gen_type [412] = Y4760_pgtype387;
	Y4760_gen_type [419] = Y4760_pgtype388;
	Y4760_gen_type [420] = Y4760_pgtype389;
	Y4760_gen_type [421] = Y4760_pgtype390;
	Y4760_gen_type [422] = Y4760_pgtype391;
	Y4760_gen_type [423] = Y4760_pgtype392;
	Y4760_gen_type [424] = Y4760_pgtype393;
	Y4760_gen_type [425] = Y4760_pgtype394;
	Y4760_gen_type [426] = Y4760_pgtype395;
	Y4760_gen_type [427] = Y4760_pgtype396;
	Y4760_gen_type [428] = Y4760_pgtype397;
	Y4760_gen_type [429] = Y4760_pgtype398;
	Y4760_gen_type [430] = Y4760_pgtype399;
	Y4760_gen_type [431] = Y4760_pgtype400;
	Y4760_gen_type [432] = Y4760_pgtype401;
	Y4760_gen_type [433] = Y4760_pgtype402;
	Y4760_gen_type [434] = Y4760_pgtype403;
	Y4760_gen_type [435] = Y4760_pgtype404;
	Y4760_gen_type [436] = Y4760_pgtype405;
	Y4760_gen_type [437] = Y4760_pgtype406;
	Y4760_gen_type [438] = Y4760_pgtype407;
	Y4760_gen_type [439] = Y4760_pgtype408;
	Y4760_gen_type [440] = Y4760_pgtype409;
	Y4760_gen_type [441] = Y4760_pgtype410;
	Y4760_gen_type [442] = Y4760_pgtype411;
	Y4760_gen_type [443] = Y4760_pgtype412;
	Y4760_gen_type [444] = Y4760_pgtype413;
	Y4760_gen_type [445] = Y4760_pgtype414;
	Y4760_gen_type [446] = Y4760_pgtype415;
	Y4760_gen_type [447] = Y4760_pgtype416;
	Y4760_gen_type [448] = Y4760_pgtype417;
	Y4760_gen_type [449] = Y4760_pgtype418;
	Y4760_gen_type [450] = Y4760_pgtype419;
	Y4760_gen_type [451] = Y4760_pgtype420;
	Y4760_gen_type [452] = Y4760_pgtype421;
	Y4760_gen_type [453] = Y4760_pgtype422;
	Y4760_gen_type [454] = Y4760_pgtype423;
	Y4760_gen_type [455] = Y4760_pgtype424;
	Y4760_gen_type [456] = Y4760_pgtype425;
	Y4760_gen_type [457] = Y4760_pgtype426;
	Y4760_gen_type [458] = Y4760_pgtype427;
	Y4760_gen_type [459] = Y4760_pgtype428;
	Y4760_gen_type [460] = Y4760_pgtype429;
	Y4760_gen_type [461] = Y4760_pgtype430;
	Y4760_gen_type [462] = Y4760_pgtype431;
	Y4760_gen_type [463] = Y4760_pgtype432;
	Y4760_gen_type [464] = Y4760_pgtype433;
	Y4760_gen_type [465] = Y4760_pgtype434;
	Y4760_gen_type [466] = Y4760_pgtype435;
	Y4760_gen_type [467] = Y4760_pgtype436;
	Y4760_gen_type [468] = Y4760_pgtype437;
	Y4760_gen_type [469] = Y4760_pgtype438;
	Y4760_gen_type [470] = Y4760_pgtype439;
	Y4760_gen_type [471] = Y4760_pgtype440;
	Y4760_gen_type [472] = Y4760_pgtype441;
	Y4760_gen_type [473] = Y4760_pgtype442;
	Y4760_gen_type [474] = Y4760_pgtype443;
	Y4760_gen_type [475] = Y4760_pgtype444;
	Y4760_gen_type [476] = Y4760_pgtype445;
	Y4760_gen_type [477] = Y4760_pgtype446;
	Y4760_gen_type [478] = Y4760_pgtype447;
	Y4760_gen_type [479] = Y4760_pgtype448;
	Y4760_gen_type [480] = Y4760_pgtype449;
	Y4760_gen_type [481] = Y4760_pgtype450;
	Y4760_gen_type [482] = Y4760_pgtype451;
	Y4760_gen_type [483] = Y4760_pgtype452;
	Y4760_gen_type [484] = Y4760_pgtype453;
	Y4760_gen_type [485] = Y4760_pgtype454;
	Y4760_gen_type [486] = Y4760_pgtype455;
	Y4760_gen_type [487] = Y4760_pgtype456;
	Y4760_gen_type [488] = Y4760_pgtype457;
	Y4760_gen_type [489] = Y4760_pgtype458;
	Y4760_gen_type [490] = Y4760_pgtype459;
	Y4760_gen_type [491] = Y4760_pgtype460;
	Y4760_gen_type [492] = Y4760_pgtype461;
	Y4760_gen_type [493] = Y4760_pgtype462;
	Y4760_gen_type [494] = Y4760_pgtype463;
	Y4760_gen_type [495] = Y4760_pgtype464;
	Y4760_gen_type [496] = Y4760_pgtype465;
	Y4760_gen_type [497] = Y4760_pgtype466;
	Y4760_gen_type [498] = Y4760_pgtype467;
	Y4760_gen_type [499] = Y4760_pgtype468;
	Y4760_gen_type [500] = Y4760_pgtype469;
	Y4760_gen_type [501] = Y4760_pgtype470;
	Y4760_gen_type [502] = Y4760_pgtype471;
	Y4760_gen_type [503] = Y4760_pgtype472;
	Y4760_gen_type [504] = Y4760_pgtype473;
	Y4760_gen_type [505] = Y4760_pgtype474;
	Y4760_gen_type [506] = Y4760_pgtype475;
	Y4760_gen_type [507] = Y4760_pgtype476;
	Y4760_gen_type [508] = Y4760_pgtype477;
	Y4760_gen_type [509] = Y4760_pgtype478;
	Y4760_gen_type [510] = Y4760_pgtype479;
	Y4760_gen_type [511] = Y4760_pgtype480;
	Y4760_gen_type [512] = Y4760_pgtype481;
	Y4760_gen_type [513] = Y4760_pgtype482;
	Y4760_gen_type [517] = Y4760_pgtype483;
	Y4760_gen_type [520] = Y4760_pgtype484;
	Y4760_gen_type [521] = Y4760_pgtype485;
	Y4760_gen_type [522] = Y4760_pgtype486;
	Y4760_gen_type [523] = Y4760_pgtype487;
	Y4760_gen_type [524] = Y4760_pgtype488;
	Y4760_gen_type [525] = Y4760_pgtype489;
	Y4760_gen_type [526] = Y4760_pgtype490;
	Y4760_gen_type [527] = Y4760_pgtype491;
	Y4760_gen_type [528] = Y4760_pgtype492;
	Y4760_gen_type [529] = Y4760_pgtype493;
	Y4760_gen_type [530] = Y4760_pgtype494;
	Y4760_gen_type [531] = Y4760_pgtype495;
	Y4760_gen_type [604] = Y4760_pgtype496;
	Y4760_gen_type [605] = Y4760_pgtype497;
	Y4760_gen_type [606] = Y4760_pgtype498;
	Y4760_gen_type [652] = Y4760_pgtype499;
	Y4760_gen_type [734] = Y4760_pgtype500;
	Y4760_gen_type [735] = Y4760_pgtype501;
	Y4760_gen_type [736] = Y4760_pgtype502;
	Y4760_gen_type [737] = Y4760_pgtype503;
	Y4760_gen_type [738] = Y4760_pgtype504;
	Y4760_gen_type [739] = Y4760_pgtype505;
	Y4760_gen_type [740] = Y4760_pgtype506;
	Y4760_gen_type [810] = Y4760_pgtype507;
	Y4760_gen_type [813] = Y4760_pgtype508;
	Y4760_gen_type [814] = Y4760_pgtype509;
	Y4760_gen_type [815] = Y4760_pgtype510;
	Y4760_gen_type [816] = Y4760_pgtype511;
	Y4760_gen_type [817] = Y4760_pgtype512;
	Y4760_gen_type [818] = Y4760_pgtype513;
	Y4760_gen_type [819] = Y4760_pgtype514;
	Y4760_gen_type [820] = Y4760_pgtype515;
	Y4760_gen_type [821] = Y4760_pgtype516;
	Y4760_gen_type [822] = Y4760_pgtype517;
	Y4760_gen_type [823] = Y4760_pgtype518;
	Y4760_gen_type [824] = Y4760_pgtype519;
	Y4760_gen_type [825] = Y4760_pgtype520;
	Y4760_gen_type [826] = Y4760_pgtype521;
	Y4760_gen_type [827] = Y4760_pgtype522;
	Y4760_gen_type [828] = Y4760_pgtype523;
	Y4760_gen_type [829] = Y4760_pgtype524;
	Y4760_gen_type [830] = Y4760_pgtype525;
	Y4760_gen_type [831] = Y4760_pgtype526;
	Y4760_gen_type [832] = Y4760_pgtype527;
	Y4760_gen_type [833] = Y4760_pgtype528;
	Y4760_gen_type [850] = Y4760_pgtype529;
	Y4760_gen_type [859] = Y4760_pgtype530;
	Y4760_gen_type [860] = Y4760_pgtype531;
	Y4760_gen_type [861] = Y4760_pgtype532;
	Y4760_gen_type [862] = Y4760_pgtype533;
	Y4760_gen_type [863] = Y4760_pgtype534;
	Y4760_gen_type [864] = Y4760_pgtype535;
	Y4760_gen_type [865] = Y4760_pgtype536;
	Y4760_gen_type [866] = Y4760_pgtype537;
	Y4760_gen_type [867] = Y4760_pgtype538;
	Y4760_gen_type [868] = Y4760_pgtype539;
	Y4760_gen_type [869] = Y4760_pgtype540;
	Y4760_gen_type [870] = Y4760_pgtype541;
	Y4760_gen_type [871] = Y4760_pgtype542;
	Y4760_gen_type [1058] = Y4760_pgtype543;
	Y4760[12] = 1053;
	Y4760[13] = 1049;
	Y4760[20] = 831;
	{long i; for (i = 261; i < 263; i++) Y4760[i] = 984;};
	Y4760[275] = 1002;
	Y4760[341] = 0;
	Y4760[363] = 1094;
	{long i; for (i = 364; i < 385; i++) Y4760[i] = 1040;};
	Y4760[407] = 984;
	Y4760[410] = 30;
	Y4760[411] = 972;
	Y4760[412] = 984;
	Y4760[488] = 972;
	Y4760[489] = 975;
	Y4760[517] = 1048;
	{long i; for (i = 604; i < 607; i++) Y4760[i] = 975;};
	Y4760[652] = 0;
	{long i; for (i = 734; i < 737; i++) Y4760[i] = 972;};
	{long i; for (i = 737; i < 741; i++) Y4760[i] = 975;};
	{long i; for (i = 813; i < 834; i++) Y4760[i] = 1126;};
	Y4760[850] = 1050;
	Y4760[860] = 1164;
	Y4760[861] = 1165;
	{long i; for (i = 862; i < 865; i++) Y4760[i] = 1163;};
	{long i; for (i = 865; i < 869; i++) Y4760[i] = 1181;};
	{long i; for (i = 869; i < 872; i++) Y4760[i] = 1169;};
	Y4760[1058] = 975;
}

char *(*R4811[798])();
void R4811_init () {
	R4811[0] = (char *(*)()) F576_5308_4811_2;
	R4811[2] = (char *(*)()) F578_5357;
	R4811[3] = (char *(*)()) F579_5357_4811_2;
	R4811[4] = (char *(*)()) F580_5357_4811_2;
	R4811[5] = (char *(*)()) F581_5357_4811_2;
	R4811[6] = (char *(*)()) F582_5357_4811_2;
	R4811[7] = (char *(*)()) F583_5357_4811_2;
	R4811[8] = (char *(*)()) F584_5357_4811_2;
	R4811[9] = (char *(*)()) F585_5357_4811_2;
	R4811[10] = (char *(*)()) F586_5357_4811_2;
	R4811[11] = (char *(*)()) F587_5357_4811_2;
	R4811[12] = (char *(*)()) F588_5357_4811_2;
	R4811[13] = (char *(*)()) F589_5357_4811_2;
	R4811[63] = (char *(*)()) F591_5431;
	R4811[64] = (char *(*)()) F592_5431_4811_2;
	R4811[65] = (char *(*)()) F597_5431_4811_2;
	{long i; for (i = 66; i < 68; i++) R4811[i] = (char *(*)()) F591_5431;}
	R4811[68] = (char *(*)()) F597_5431_4811_2;
	R4811[69] = (char *(*)()) F592_5431_4811_2;
	R4811[72] = (char *(*)()) F648_5602;
	R4811[73] = (char *(*)()) F649_5602_4811_2;
	R4811[74] = (char *(*)()) F650_5602;
	R4811[75] = (char *(*)()) F651_5602_4811_2;
	R4811[76] = (char *(*)()) F652_5602_4811_2;
	R4811[77] = (char *(*)()) F653_5602_4811_2;
	R4811[78] = (char *(*)()) F648_5602;
	R4811[79] = (char *(*)()) F649_5602_4811_2;
	R4811[80] = (char *(*)()) F648_5602;
	R4811[81] = (char *(*)()) F657_5735;
	R4811[82] = (char *(*)()) F658_5735_4811_2;
	R4811[83] = (char *(*)()) F659_5735_4811_2;
	R4811[84] = (char *(*)()) F660_5735_4811_2;
	R4811[85] = (char *(*)()) F661_5735_4811_2;
	R4811[86] = (char *(*)()) F662_5735_4811_2;
	R4811[87] = (char *(*)()) F663_5735_4811_2;
	R4811[88] = (char *(*)()) F664_5735_4811_2;
	R4811[89] = (char *(*)()) F665_5735_4811_2;
	R4811[90] = (char *(*)()) F666_5735_4811_2;
	R4811[91] = (char *(*)()) F667_5735_4811_2;
	R4811[92] = (char *(*)()) F668_5735_4811_2;
	R4811[93] = (char *(*)()) F657_5735;
	R4811[94] = (char *(*)()) F658_5735_4811_2;
	R4811[95] = (char *(*)()) F663_5735_4811_2;
	R4811[100] = (char *(*)()) F657_5735;
	R4811[101] = (char *(*)()) F658_5735_4811_2;
	{long i; for (i = 102; i < 106; i++) R4811[i] = (char *(*)()) F657_5735;}
	R4811[110] = (char *(*)()) F657_5735;
	R4811[112] = (char *(*)()) F657_5735;
	R4811[114] = (char *(*)()) F657_5735;
	R4811[118] = (char *(*)()) F657_5735;
	{long i; for (i = 120; i < 124; i++) R4811[i] = (char *(*)()) F657_5735;}
	R4811[146] = (char *(*)()) F722_6097_4811_2;
	R4811[151] = (char *(*)()) F727_6162_4811_2;
	{long i; for (i = 344; i < 346; i++) R4811[i] = (char *(*)()) F372_5157_4811_2;}
	R4811[475] = (char *(*)()) F1049_9153_4811_2;
	R4811[478] = (char *(*)()) F1052_9321_4811_2;
	{long i; for (i = 557; i < 560; i++) R4811[i] = (char *(*)()) F591_5431;}
	{long i; for (i = 560; i < 562; i++) R4811[i] = (char *(*)()) F1136_10346;}
	R4811[563] = (char *(*)()) F1136_10346;
	R4811[564] = (char *(*)()) F1140_10401;
	{long i; for (i = 568; i < 571; i++) R4811[i] = (char *(*)()) F1140_10401;}
	R4811[572] = (char *(*)()) F1140_10401;
	R4811[600] = (char *(*)()) F591_5431;
	R4811[610] = (char *(*)()) F591_5431;
	R4811[797] = (char *(*)()) F372_5157_4811_2;
}
static EIF_BOOLEAN F576_5308_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F576_5308(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F579_5357_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F579_5357(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F580_5357_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F580_5357(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F581_5357_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F581_5357(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F582_5357_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F582_5357(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F583_5357_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F583_5357(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F584_5357_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F584_5357(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F585_5357_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F585_5357(Current, *(EIF_POINTER *)arg1);
}
static EIF_BOOLEAN F586_5357_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F586_5357(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F587_5357_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F587_5357(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F588_5357_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F588_5357(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F589_5357_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F589_5357(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F592_5431_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F592_5431(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F597_5431_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F597_5431(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F649_5602_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F649_5602(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F651_5602_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F651_5602(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F652_5602_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F652_5602(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F653_5602_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F653_5602(Current, *(EIF_POINTER *)arg1);
}
static EIF_BOOLEAN F658_5735_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F658_5735(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F659_5735_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F659_5735(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F660_5735_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F660_5735(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F661_5735_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F661_5735(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F662_5735_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F662_5735(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F663_5735_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F663_5735(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F664_5735_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F664_5735(Current, *(EIF_POINTER *)arg1);
}
static EIF_BOOLEAN F665_5735_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F665_5735(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F666_5735_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F666_5735(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F667_5735_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F667_5735(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F668_5735_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F668_5735(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F722_6097_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F722_6097(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F727_6162_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F727_6162(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F372_5157_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F372_5157(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F1049_9153_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1049_9153(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F1052_9321_4811_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1052_9321(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4812[1024])();
void R4812_init () {
	R4812[0] = (char *(*)()) F348_5032;
	R4812[226] = (char *(*)()) F484_5233;
	R4812[228] = (char *(*)()) F483_5233;
	R4812[229] = (char *(*)()) F484_5233;
	R4812[230] = (char *(*)()) F485_5233;
	R4812[231] = (char *(*)()) F486_5233;
	R4812[232] = (char *(*)()) F487_5233;
	R4812[233] = (char *(*)()) F488_5233;
	R4812[234] = (char *(*)()) F489_5233;
	R4812[235] = (char *(*)()) F490_5233;
	R4812[236] = (char *(*)()) F491_5233;
	R4812[237] = (char *(*)()) F492_5233;
	R4812[238] = (char *(*)()) F493_5233;
	R4812[239] = (char *(*)()) F494_5233;
	R4812[289] = (char *(*)()) F483_5233;
	R4812[290] = (char *(*)()) F484_5233;
	R4812[291] = (char *(*)()) F489_5233;
	{long i; for (i = 292; i < 294; i++) R4812[i] = (char *(*)()) F483_5233;}
	R4812[294] = (char *(*)()) F489_5233;
	R4812[295] = (char *(*)()) F484_5233;
	R4812[298] = (char *(*)()) F483_5233;
	R4812[299] = (char *(*)()) F484_5233;
	R4812[300] = (char *(*)()) F483_5233;
	{long i; for (i = 301; i < 303; i++) R4812[i] = (char *(*)()) F484_5233;}
	R4812[303] = (char *(*)()) F490_5233;
	R4812[304] = (char *(*)()) F483_5233;
	R4812[305] = (char *(*)()) F484_5233;
	{long i; for (i = 306; i < 308; i++) R4812[i] = (char *(*)()) F483_5233;}
	R4812[308] = (char *(*)()) F484_5233;
	R4812[309] = (char *(*)()) F485_5233;
	R4812[310] = (char *(*)()) F486_5233;
	R4812[311] = (char *(*)()) F487_5233;
	R4812[312] = (char *(*)()) F488_5233;
	R4812[313] = (char *(*)()) F489_5233;
	R4812[314] = (char *(*)()) F490_5233;
	R4812[315] = (char *(*)()) F491_5233;
	R4812[316] = (char *(*)()) F492_5233;
	R4812[317] = (char *(*)()) F493_5233;
	R4812[318] = (char *(*)()) F494_5233;
	R4812[319] = (char *(*)()) F483_5233;
	R4812[320] = (char *(*)()) F484_5233;
	R4812[321] = (char *(*)()) F489_5233;
	R4812[326] = (char *(*)()) F483_5233;
	R4812[327] = (char *(*)()) F484_5233;
	{long i; for (i = 328; i < 332; i++) R4812[i] = (char *(*)()) F483_5233;}
	R4812[336] = (char *(*)()) F483_5233;
	R4812[338] = (char *(*)()) F483_5233;
	R4812[340] = (char *(*)()) F483_5233;
	R4812[344] = (char *(*)()) F483_5233;
	{long i; for (i = 346; i < 350; i++) R4812[i] = (char *(*)()) F483_5233;}
	R4812[372] = (char *(*)()) F480_5211;
	R4812[377] = (char *(*)()) F480_5211;
	{long i; for (i = 570; i < 572; i++) R4812[i] = (char *(*)()) F492_5233;}
	R4812[701] = (char *(*)()) F491_5233;
	R4812[704] = (char *(*)()) F492_5233;
	{long i; for (i = 783; i < 786; i++) R4812[i] = (char *(*)()) F483_5233;}
	{long i; for (i = 786; i < 788; i++) R4812[i] = (char *(*)()) F1136_10347;}
	{long i; for (i = 789; i < 791; i++) R4812[i] = (char *(*)()) F1136_10347;}
	{long i; for (i = 794; i < 797; i++) R4812[i] = (char *(*)()) F1136_10347;}
	R4812[798] = (char *(*)()) F1136_10347;
	R4812[826] = (char *(*)()) F483_5233;
	R4812[836] = (char *(*)()) F483_5233;
	R4812[1023] = (char *(*)()) F1373_14121;
}


#ifdef __cplusplus
}
#endif
