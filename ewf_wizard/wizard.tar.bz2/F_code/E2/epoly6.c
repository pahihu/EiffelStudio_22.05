#include "epoly6.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4816[1024])();
void R4816_init () {
	R4816[0] = (char *(*)()) F336_5004;
	R4816[226] = (char *(*)()) F337_5004;
	R4816[228] = (char *(*)()) F336_5004;
	R4816[229] = (char *(*)()) F337_5004;
	R4816[230] = (char *(*)()) F338_5004;
	R4816[231] = (char *(*)()) F339_5004;
	R4816[232] = (char *(*)()) F340_5004;
	R4816[233] = (char *(*)()) F341_5004;
	R4816[234] = (char *(*)()) F342_5004;
	R4816[235] = (char *(*)()) F343_5004;
	R4816[236] = (char *(*)()) F344_5004;
	R4816[237] = (char *(*)()) F345_5004;
	R4816[238] = (char *(*)()) F346_5004;
	R4816[239] = (char *(*)()) F347_5004;
	R4816[289] = (char *(*)()) F336_5004;
	R4816[290] = (char *(*)()) F337_5004;
	R4816[291] = (char *(*)()) F342_5004;
	{long i; for (i = 292; i < 294; i++) R4816[i] = (char *(*)()) F336_5004;}
	R4816[294] = (char *(*)()) F342_5004;
	R4816[295] = (char *(*)()) F337_5004;
	R4816[298] = (char *(*)()) F336_5004;
	R4816[299] = (char *(*)()) F337_5004;
	R4816[300] = (char *(*)()) F336_5004;
	{long i; for (i = 301; i < 303; i++) R4816[i] = (char *(*)()) F337_5004;}
	R4816[303] = (char *(*)()) F343_5004;
	R4816[304] = (char *(*)()) F336_5004;
	R4816[305] = (char *(*)()) F337_5004;
	{long i; for (i = 306; i < 308; i++) R4816[i] = (char *(*)()) F336_5004;}
	R4816[308] = (char *(*)()) F337_5004;
	R4816[309] = (char *(*)()) F338_5004;
	R4816[310] = (char *(*)()) F339_5004;
	R4816[311] = (char *(*)()) F340_5004;
	R4816[312] = (char *(*)()) F341_5004;
	R4816[313] = (char *(*)()) F342_5004;
	R4816[314] = (char *(*)()) F343_5004;
	R4816[315] = (char *(*)()) F344_5004;
	R4816[316] = (char *(*)()) F345_5004;
	R4816[317] = (char *(*)()) F346_5004;
	R4816[318] = (char *(*)()) F347_5004;
	R4816[319] = (char *(*)()) F336_5004;
	R4816[320] = (char *(*)()) F337_5004;
	R4816[321] = (char *(*)()) F342_5004;
	R4816[326] = (char *(*)()) F336_5004;
	R4816[327] = (char *(*)()) F337_5004;
	{long i; for (i = 328; i < 332; i++) R4816[i] = (char *(*)()) F336_5004;}
	R4816[336] = (char *(*)()) F336_5004;
	R4816[338] = (char *(*)()) F336_5004;
	R4816[340] = (char *(*)()) F336_5004;
	R4816[344] = (char *(*)()) F336_5004;
	{long i; for (i = 346; i < 350; i++) R4816[i] = (char *(*)()) F336_5004;}
	R4816[372] = (char *(*)()) F337_5004;
	R4816[377] = (char *(*)()) F337_5004;
	{long i; for (i = 570; i < 572; i++) R4816[i] = (char *(*)()) F345_5004;}
	R4816[701] = (char *(*)()) F344_5004;
	R4816[704] = (char *(*)()) F345_5004;
	{long i; for (i = 783; i < 788; i++) R4816[i] = (char *(*)()) F336_5004;}
	{long i; for (i = 789; i < 791; i++) R4816[i] = (char *(*)()) F336_5004;}
	{long i; for (i = 794; i < 797; i++) R4816[i] = (char *(*)()) F336_5004;}
	R4816[798] = (char *(*)()) F336_5004;
	R4816[826] = (char *(*)()) F336_5004;
	R4816[836] = (char *(*)()) F336_5004;
	R4816[1023] = (char *(*)()) F345_5004;
}

char *(*R4818[1024])();
void R4818_init () {
	R4818[0] = (char *(*)()) F348_5059;
	R4818[226] = (char *(*)()) F576_5327;
	R4818[228] = (char *(*)()) F578_5401;
	R4818[229] = (char *(*)()) F579_5401;
	R4818[230] = (char *(*)()) F580_5401;
	R4818[231] = (char *(*)()) F581_5401;
	R4818[232] = (char *(*)()) F582_5401;
	R4818[233] = (char *(*)()) F583_5401;
	R4818[234] = (char *(*)()) F584_5401;
	R4818[235] = (char *(*)()) F585_5401;
	R4818[236] = (char *(*)()) F586_5401;
	R4818[237] = (char *(*)()) F587_5401;
	R4818[238] = (char *(*)()) F588_5401;
	R4818[239] = (char *(*)()) F589_5401;
	R4818[289] = (char *(*)()) F363_5172;
	R4818[290] = (char *(*)()) F364_5172;
	R4818[291] = (char *(*)()) F369_5172;
	R4818[292] = (char *(*)()) F642_5531;
	R4818[293] = (char *(*)()) F643_5550;
	R4818[294] = (char *(*)()) F644_5550;
	R4818[295] = (char *(*)()) F645_5550;
	R4818[298] = (char *(*)()) F648_5648;
	R4818[299] = (char *(*)()) F649_5648;
	R4818[300] = (char *(*)()) F650_5648;
	R4818[301] = (char *(*)()) F651_5648;
	R4818[302] = (char *(*)()) F652_5648;
	R4818[303] = (char *(*)()) F653_5648;
	R4818[304] = (char *(*)()) F648_5648;
	R4818[305] = (char *(*)()) F649_5648;
	R4818[306] = (char *(*)()) F648_5648;
	R4818[307] = (char *(*)()) F363_5172;
	R4818[308] = (char *(*)()) F364_5172;
	R4818[309] = (char *(*)()) F365_5172;
	R4818[310] = (char *(*)()) F366_5172;
	R4818[311] = (char *(*)()) F367_5172;
	R4818[312] = (char *(*)()) F368_5172;
	R4818[313] = (char *(*)()) F369_5172;
	R4818[314] = (char *(*)()) F370_5172;
	R4818[315] = (char *(*)()) F371_5172;
	R4818[316] = (char *(*)()) F372_5172;
	R4818[317] = (char *(*)()) F373_5172;
	R4818[318] = (char *(*)()) F374_5172;
	R4818[319] = (char *(*)()) F669_5794;
	R4818[320] = (char *(*)()) F670_5794;
	R4818[321] = (char *(*)()) F671_5794;
	R4818[326] = (char *(*)()) F363_5172;
	R4818[327] = (char *(*)()) F364_5172;
	{long i; for (i = 328; i < 332; i++) R4818[i] = (char *(*)()) F363_5172;}
	R4818[336] = (char *(*)()) F363_5172;
	R4818[338] = (char *(*)()) F363_5172;
	R4818[340] = (char *(*)()) F363_5172;
	R4818[344] = (char *(*)()) F363_5172;
	{long i; for (i = 346; i < 350; i++) R4818[i] = (char *(*)()) F363_5172;}
	R4818[372] = (char *(*)()) F482_5226;
	R4818[377] = (char *(*)()) F482_5226;
	{long i; for (i = 570; i < 572; i++) R4818[i] = (char *(*)()) F372_5172;}
	R4818[701] = (char *(*)()) F1051_9277;
	R4818[704] = (char *(*)()) F1054_9442;
	{long i; for (i = 783; i < 786; i++) R4818[i] = (char *(*)()) F363_5172;}
	{long i; for (i = 786; i < 788; i++) R4818[i] = (char *(*)()) F1136_10356;}
	{long i; for (i = 789; i < 791; i++) R4818[i] = (char *(*)()) F1136_10356;}
	{long i; for (i = 794; i < 797; i++) R4818[i] = (char *(*)()) F1136_10356;}
	R4818[798] = (char *(*)()) F1136_10356;
	R4818[826] = (char *(*)()) F363_5172;
	R4818[836] = (char *(*)()) F363_5172;
	R4818[1023] = (char *(*)()) F372_5172;
}

EIF_TYPE_INDEX *Y4825_gen_type [3];
EIF_TYPE_INDEX Y4825 [3];
void Y4825_init (void)
{
	egc_routines_types [4825] = Y4825;
	egc_routines_gen_types [4825] = Y4825_gen_type;
	egc_routines_offset [4825] = 347;
	{long i; for (i = 0; i < 3; i++) Y4825[i] = 984;};
}

char *(*R4921[735])();
void R4921_init () {
	R4921[0] = (char *(*)()) F639_5481;
	R4921[1] = (char *(*)()) F640_5481_4921_1;
	R4921[2] = (char *(*)()) F641_5481_4921_1;
	{long i; for (i = 3; i < 5; i++) R4921[i] = (char *(*)()) F639_5481;}
	R4921[5] = (char *(*)()) F641_5481_4921_1;
	R4921[6] = (char *(*)()) F640_5481_4921_1;
	R4921[18] = (char *(*)()) F657_5728;
	R4921[19] = (char *(*)()) F658_5728_4921_1;
	R4921[20] = (char *(*)()) F659_5728_4921_1;
	R4921[21] = (char *(*)()) F660_5728_4921_1;
	R4921[22] = (char *(*)()) F661_5728_4921_1;
	R4921[23] = (char *(*)()) F662_5728_4921_1;
	R4921[24] = (char *(*)()) F663_5728_4921_1;
	R4921[25] = (char *(*)()) F664_5728_4921_1;
	R4921[26] = (char *(*)()) F665_5728_4921_1;
	R4921[27] = (char *(*)()) F666_5728_4921_1;
	R4921[28] = (char *(*)()) F667_5728_4921_1;
	R4921[29] = (char *(*)()) F668_5728_4921_1;
	R4921[30] = (char *(*)()) F657_5728;
	R4921[31] = (char *(*)()) F658_5728_4921_1;
	R4921[32] = (char *(*)()) F663_5728_4921_1;
	R4921[37] = (char *(*)()) F657_5728;
	R4921[38] = (char *(*)()) F658_5728_4921_1;
	{long i; for (i = 39; i < 43; i++) R4921[i] = (char *(*)()) F657_5728;}
	R4921[47] = (char *(*)()) F657_5728;
	R4921[49] = (char *(*)()) F657_5728;
	R4921[51] = (char *(*)()) F657_5728;
	R4921[55] = (char *(*)()) F657_5728;
	{long i; for (i = 57; i < 61; i++) R4921[i] = (char *(*)()) F657_5728;}
	R4921[83] = (char *(*)()) F482_5215_4921_1;
	R4921[88] = (char *(*)()) F482_5215_4921_1;
	{long i; for (i = 281; i < 283; i++) R4921[i] = (char *(*)()) F919_7098_4921_1;}
	{long i; for (i = 494; i < 497; i++) R4921[i] = (char *(*)()) F1125_10138;}
	R4921[537] = (char *(*)()) F1125_10138;
	R4921[547] = (char *(*)()) F1125_10138;
	R4921[734] = (char *(*)()) F919_7098_4921_1;
}
static EIF_REFERENCE F640_5481_4921_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F640_5481(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F641_5481_4921_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F641_5481(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F658_5728_4921_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F658_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F659_5728_4921_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F659_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(999, 0x00).id, 999, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F660_5728_4921_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F660_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(993, 0x00).id, 993, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F661_5728_4921_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F661_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F662_5728_4921_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F662_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F663_5728_4921_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F663_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_5728_4921_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F664_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F665_5728_4921_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F665_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_5728_4921_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F666_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_5728_4921_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F667_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_5728_4921_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F668_5728(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F482_5215_4921_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F482_5215(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F919_7098_4921_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F919_7098(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R4922[735])();
void R4922_init () {
	R4922[0] = (char *(*)()) F639_5492;
	R4922[1] = (char *(*)()) F640_5492;
	R4922[2] = (char *(*)()) F641_5492;
	{long i; for (i = 3; i < 5; i++) R4922[i] = (char *(*)()) F639_5492;}
	R4922[5] = (char *(*)()) F641_5492;
	R4922[6] = (char *(*)()) F640_5492;
	R4922[18] = (char *(*)()) F591_5444;
	R4922[19] = (char *(*)()) F592_5444;
	R4922[20] = (char *(*)()) F593_5444;
	R4922[21] = (char *(*)()) F594_5444;
	R4922[22] = (char *(*)()) F595_5444;
	R4922[23] = (char *(*)()) F596_5444;
	R4922[24] = (char *(*)()) F597_5444;
	R4922[25] = (char *(*)()) F598_5444;
	R4922[26] = (char *(*)()) F599_5444;
	R4922[27] = (char *(*)()) F600_5444;
	R4922[28] = (char *(*)()) F601_5444;
	R4922[29] = (char *(*)()) F602_5444;
	R4922[30] = (char *(*)()) F591_5444;
	R4922[31] = (char *(*)()) F592_5444;
	R4922[32] = (char *(*)()) F597_5444;
	R4922[37] = (char *(*)()) F591_5444;
	R4922[38] = (char *(*)()) F592_5444;
	{long i; for (i = 39; i < 43; i++) R4922[i] = (char *(*)()) F591_5444;}
	R4922[47] = (char *(*)()) F591_5444;
	R4922[49] = (char *(*)()) F591_5444;
	R4922[51] = (char *(*)()) F591_5444;
	R4922[55] = (char *(*)()) F591_5444;
	{long i; for (i = 57; i < 61; i++) R4922[i] = (char *(*)()) F591_5444;}
	R4922[83] = (char *(*)()) F364_5165;
	R4922[88] = (char *(*)()) F364_5165;
	{long i; for (i = 281; i < 283; i++) R4922[i] = (char *(*)()) F919_7119;}
	{long i; for (i = 494; i < 497; i++) R4922[i] = (char *(*)()) F591_5444;}
	R4922[537] = (char *(*)()) F591_5444;
	R4922[547] = (char *(*)()) F591_5444;
	R4922[734] = (char *(*)()) F919_7119;
}

char *(*R4923[735])();
void R4923_init () {
	R4923[0] = (char *(*)()) F639_5498;
	R4923[1] = (char *(*)()) F640_5498;
	R4923[2] = (char *(*)()) F641_5498;
	{long i; for (i = 3; i < 5; i++) R4923[i] = (char *(*)()) F639_5498;}
	R4923[5] = (char *(*)()) F641_5498;
	R4923[6] = (char *(*)()) F640_5498;
	R4923[18] = (char *(*)()) F657_5754;
	R4923[19] = (char *(*)()) F658_5754;
	R4923[20] = (char *(*)()) F659_5754;
	R4923[21] = (char *(*)()) F660_5754;
	R4923[22] = (char *(*)()) F661_5754;
	R4923[23] = (char *(*)()) F662_5754;
	R4923[24] = (char *(*)()) F663_5754;
	R4923[25] = (char *(*)()) F664_5754;
	R4923[26] = (char *(*)()) F665_5754;
	R4923[27] = (char *(*)()) F666_5754;
	R4923[28] = (char *(*)()) F667_5754;
	R4923[29] = (char *(*)()) F668_5754;
	R4923[30] = (char *(*)()) F657_5754;
	R4923[31] = (char *(*)()) F658_5754;
	R4923[32] = (char *(*)()) F663_5754;
	R4923[37] = (char *(*)()) F657_5754;
	R4923[38] = (char *(*)()) F658_5754;
	{long i; for (i = 39; i < 43; i++) R4923[i] = (char *(*)()) F657_5754;}
	R4923[47] = (char *(*)()) F657_5754;
	R4923[49] = (char *(*)()) F657_5754;
	R4923[51] = (char *(*)()) F657_5754;
	R4923[55] = (char *(*)()) F657_5754;
	{long i; for (i = 57; i < 61; i++) R4923[i] = (char *(*)()) F657_5754;}
	R4923[83] = (char *(*)()) F482_5223;
	R4923[88] = (char *(*)()) F482_5223;
	{long i; for (i = 281; i < 283; i++) R4923[i] = (char *(*)()) F919_7174;}
	{long i; for (i = 494; i < 497; i++) R4923[i] = (char *(*)()) F1125_10148;}
	R4923[537] = (char *(*)()) F1125_10148;
	R4923[547] = (char *(*)()) F1125_10148;
	R4923[734] = (char *(*)()) F919_7174;
}

char *(*R4929[735])();
void R4929_init () {
	R4929[0] = (char *(*)()) F375_5176;
	R4929[1] = (char *(*)()) F376_5176_4929_4;
	R4929[2] = (char *(*)()) F381_5176_4929_4;
	{long i; for (i = 3; i < 5; i++) R4929[i] = (char *(*)()) F375_5176;}
	R4929[5] = (char *(*)()) F381_5176_4929_4;
	R4929[6] = (char *(*)()) F376_5176_4929_4;
	R4929[18] = (char *(*)()) F657_5760;
	R4929[19] = (char *(*)()) F658_5760_4929_4;
	R4929[20] = (char *(*)()) F659_5760_4929_4;
	R4929[21] = (char *(*)()) F660_5760_4929_4;
	R4929[22] = (char *(*)()) F661_5760_4929_4;
	R4929[23] = (char *(*)()) F662_5760_4929_4;
	R4929[24] = (char *(*)()) F663_5760_4929_4;
	R4929[25] = (char *(*)()) F664_5760_4929_4;
	R4929[26] = (char *(*)()) F665_5760_4929_4;
	R4929[27] = (char *(*)()) F666_5760_4929_4;
	R4929[28] = (char *(*)()) F667_5760_4929_4;
	R4929[29] = (char *(*)()) F668_5760_4929_4;
	R4929[30] = (char *(*)()) F657_5760;
	R4929[31] = (char *(*)()) F658_5760_4929_4;
	R4929[32] = (char *(*)()) F663_5760_4929_4;
	R4929[37] = (char *(*)()) F657_5760;
	R4929[38] = (char *(*)()) F658_5760_4929_4;
	{long i; for (i = 39; i < 43; i++) R4929[i] = (char *(*)()) F657_5760;}
	R4929[47] = (char *(*)()) F657_5760;
	R4929[49] = (char *(*)()) F657_5760;
	R4929[51] = (char *(*)()) F657_5760;
	R4929[55] = (char *(*)()) F657_5760;
	{long i; for (i = 57; i < 61; i++) R4929[i] = (char *(*)()) F657_5760;}
	R4929[83] = (char *(*)()) F364_5159_4929_4;
	R4929[88] = (char *(*)()) F364_5159_4929_4;
	{long i; for (i = 281; i < 283; i++) R4929[i] = (char *(*)()) F384_5176_4929_4;}
	{long i; for (i = 494; i < 497; i++) R4929[i] = (char *(*)()) F375_5176;}
	R4929[537] = (char *(*)()) F375_5176;
	R4929[547] = (char *(*)()) F375_5176;
	R4929[734] = (char *(*)()) F384_5176_4929_4;
}
static void F376_5176_4929_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F376_5176(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F381_5176_4929_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F381_5176(Current, *(EIF_BOOLEAN *)arg1);
}
static void F658_5760_4929_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F658_5760(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F659_5760_4929_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F659_5760(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F660_5760_4929_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F660_5760(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F661_5760_4929_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F661_5760(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F662_5760_4929_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F662_5760(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F663_5760_4929_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F663_5760(Current, *(EIF_BOOLEAN *)arg1);
}
static void F664_5760_4929_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F664_5760(Current, *(EIF_POINTER *)arg1);
}
static void F665_5760_4929_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F665_5760(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F666_5760_4929_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F666_5760(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F667_5760_4929_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F667_5760(Current, *(EIF_REAL_32 *)arg1);
}
static void F668_5760_4929_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F668_5760(Current, *(EIF_REAL_64 *)arg1);
}
static void F364_5159_4929_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F364_5159(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F384_5176_4929_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F384_5176(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4930[735])();
void R4930_init () {
	R4930[0] = (char *(*)()) F639_5484;
	R4930[1] = (char *(*)()) F640_5484;
	R4930[2] = (char *(*)()) F641_5484;
	{long i; for (i = 3; i < 5; i++) R4930[i] = (char *(*)()) F639_5484;}
	R4930[5] = (char *(*)()) F641_5484;
	R4930[6] = (char *(*)()) F640_5484;
	R4930[18] = (char *(*)()) F657_5733;
	R4930[19] = (char *(*)()) F658_5733;
	R4930[20] = (char *(*)()) F659_5733;
	R4930[21] = (char *(*)()) F660_5733;
	R4930[22] = (char *(*)()) F661_5733;
	R4930[23] = (char *(*)()) F662_5733;
	R4930[24] = (char *(*)()) F663_5733;
	R4930[25] = (char *(*)()) F664_5733;
	R4930[26] = (char *(*)()) F665_5733;
	R4930[27] = (char *(*)()) F666_5733;
	R4930[28] = (char *(*)()) F667_5733;
	R4930[29] = (char *(*)()) F668_5733;
	R4930[30] = (char *(*)()) F657_5733;
	R4930[31] = (char *(*)()) F658_5733;
	R4930[32] = (char *(*)()) F663_5733;
	R4930[37] = (char *(*)()) F657_5733;
	R4930[38] = (char *(*)()) F658_5733;
	{long i; for (i = 39; i < 43; i++) R4930[i] = (char *(*)()) F657_5733;}
	R4930[47] = (char *(*)()) F657_5733;
	R4930[49] = (char *(*)()) F657_5733;
	R4930[51] = (char *(*)()) F657_5733;
	R4930[55] = (char *(*)()) F657_5733;
	{long i; for (i = 57; i < 61; i++) R4930[i] = (char *(*)()) F657_5733;}
	R4930[83] = (char *(*)()) F482_5214;
	R4930[88] = (char *(*)()) F482_5214;
	{long i; for (i = 281; i < 283; i++) R4930[i] = (char *(*)()) F919_7099;}
	{long i; for (i = 494; i < 497; i++) R4930[i] = (char *(*)()) F1125_10139;}
	R4930[537] = (char *(*)()) F1125_10139;
	R4930[547] = (char *(*)()) F1125_10139;
	R4930[734] = (char *(*)()) F919_7099;
}

char *(*R4933[735])();
void R4933_init () {
	R4933[0] = (char *(*)()) F363_5163;
	R4933[1] = (char *(*)()) F364_5163;
	R4933[2] = (char *(*)()) F369_5163;
	{long i; for (i = 3; i < 5; i++) R4933[i] = (char *(*)()) F363_5163;}
	R4933[5] = (char *(*)()) F369_5163;
	R4933[6] = (char *(*)()) F364_5163;
	R4933[18] = (char *(*)()) F363_5163;
	R4933[19] = (char *(*)()) F364_5163;
	R4933[20] = (char *(*)()) F365_5163;
	R4933[21] = (char *(*)()) F366_5163;
	R4933[22] = (char *(*)()) F367_5163;
	R4933[23] = (char *(*)()) F368_5163;
	R4933[24] = (char *(*)()) F369_5163;
	R4933[25] = (char *(*)()) F370_5163;
	R4933[26] = (char *(*)()) F371_5163;
	R4933[27] = (char *(*)()) F372_5163;
	R4933[28] = (char *(*)()) F373_5163;
	R4933[29] = (char *(*)()) F374_5163;
	R4933[30] = (char *(*)()) F363_5163;
	R4933[31] = (char *(*)()) F364_5163;
	R4933[32] = (char *(*)()) F369_5163;
	R4933[37] = (char *(*)()) F363_5163;
	R4933[38] = (char *(*)()) F364_5163;
	{long i; for (i = 39; i < 43; i++) R4933[i] = (char *(*)()) F363_5163;}
	R4933[47] = (char *(*)()) F363_5163;
	R4933[49] = (char *(*)()) F363_5163;
	R4933[51] = (char *(*)()) F363_5163;
	R4933[55] = (char *(*)()) F363_5163;
	{long i; for (i = 57; i < 61; i++) R4933[i] = (char *(*)()) F363_5163;}
	R4933[83] = (char *(*)()) F364_5163;
	R4933[88] = (char *(*)()) F364_5163;
	{long i; for (i = 281; i < 283; i++) R4933[i] = (char *(*)()) F372_5163;}
	{long i; for (i = 494; i < 497; i++) R4933[i] = (char *(*)()) F363_5163;}
	R4933[537] = (char *(*)()) F363_5163;
	R4933[547] = (char *(*)()) F363_5163;
	R4933[734] = (char *(*)()) F372_5163;
}

char *(*R4934[735])();
void R4934_init () {
	R4934[0] = (char *(*)()) F639_5490;
	R4934[1] = (char *(*)()) F640_5490;
	R4934[2] = (char *(*)()) F641_5490;
	{long i; for (i = 3; i < 5; i++) R4934[i] = (char *(*)()) F639_5490;}
	R4934[5] = (char *(*)()) F641_5490;
	R4934[6] = (char *(*)()) F640_5490;
	R4934[18] = (char *(*)()) F615_5468;
	R4934[19] = (char *(*)()) F616_5468;
	R4934[20] = (char *(*)()) F617_5468;
	R4934[21] = (char *(*)()) F618_5468;
	R4934[22] = (char *(*)()) F619_5468;
	R4934[23] = (char *(*)()) F620_5468;
	R4934[24] = (char *(*)()) F621_5468;
	R4934[25] = (char *(*)()) F622_5468;
	R4934[26] = (char *(*)()) F623_5468;
	R4934[27] = (char *(*)()) F624_5468;
	R4934[28] = (char *(*)()) F625_5468;
	R4934[29] = (char *(*)()) F626_5468;
	R4934[30] = (char *(*)()) F615_5468;
	R4934[31] = (char *(*)()) F616_5468;
	R4934[32] = (char *(*)()) F621_5468;
	R4934[37] = (char *(*)()) F615_5468;
	R4934[38] = (char *(*)()) F616_5468;
	{long i; for (i = 39; i < 43; i++) R4934[i] = (char *(*)()) F615_5468;}
	R4934[47] = (char *(*)()) F615_5468;
	R4934[49] = (char *(*)()) F615_5468;
	R4934[51] = (char *(*)()) F615_5468;
	R4934[55] = (char *(*)()) F615_5468;
	{long i; for (i = 57; i < 61; i++) R4934[i] = (char *(*)()) F615_5468;}
	R4934[83] = (char *(*)()) F482_5216;
	R4934[88] = (char *(*)()) F482_5216;
	{long i; for (i = 281; i < 283; i++) R4934[i] = (char *(*)()) F919_7117;}
	{long i; for (i = 494; i < 497; i++) R4934[i] = (char *(*)()) F615_5468;}
	R4934[537] = (char *(*)()) F615_5468;
	R4934[547] = (char *(*)()) F615_5468;
	R4934[734] = (char *(*)()) F919_7117;
}

char *(*R4935[548])();
void R4935_init () {
	R4935[0] = (char *(*)()) F639_5499;
	R4935[1] = (char *(*)()) F640_5499;
	R4935[2] = (char *(*)()) F641_5499;
	{long i; for (i = 3; i < 5; i++) R4935[i] = (char *(*)()) F639_5499;}
	R4935[5] = (char *(*)()) F641_5499;
	R4935[6] = (char *(*)()) F640_5499;
	R4935[18] = (char *(*)()) F657_5755;
	R4935[19] = (char *(*)()) F658_5755;
	R4935[20] = (char *(*)()) F659_5755;
	R4935[21] = (char *(*)()) F660_5755;
	R4935[22] = (char *(*)()) F661_5755;
	R4935[23] = (char *(*)()) F662_5755;
	R4935[24] = (char *(*)()) F663_5755;
	R4935[25] = (char *(*)()) F664_5755;
	R4935[26] = (char *(*)()) F665_5755;
	R4935[27] = (char *(*)()) F666_5755;
	R4935[28] = (char *(*)()) F667_5755;
	R4935[29] = (char *(*)()) F668_5755;
	R4935[30] = (char *(*)()) F657_5755;
	R4935[31] = (char *(*)()) F658_5755;
	R4935[32] = (char *(*)()) F663_5755;
	R4935[37] = (char *(*)()) F657_5755;
	R4935[38] = (char *(*)()) F658_5755;
	{long i; for (i = 39; i < 43; i++) R4935[i] = (char *(*)()) F657_5755;}
	R4935[47] = (char *(*)()) F657_5755;
	R4935[49] = (char *(*)()) F657_5755;
	R4935[51] = (char *(*)()) F657_5755;
	R4935[55] = (char *(*)()) F657_5755;
	{long i; for (i = 57; i < 61; i++) R4935[i] = (char *(*)()) F657_5755;}
	{long i; for (i = 494; i < 497; i++) R4935[i] = (char *(*)()) F591_5438;}
	R4935[537] = (char *(*)()) F591_5438;
	R4935[547] = (char *(*)()) F591_5438;
}

char *(*R4936[735])();
void R4936_init () {
	R4936[0] = (char *(*)()) F639_5500;
	R4936[1] = (char *(*)()) F640_5500;
	R4936[2] = (char *(*)()) F641_5500;
	{long i; for (i = 3; i < 5; i++) R4936[i] = (char *(*)()) F639_5500;}
	R4936[5] = (char *(*)()) F641_5500;
	R4936[6] = (char *(*)()) F640_5500;
	R4936[18] = (char *(*)()) F657_5756;
	R4936[19] = (char *(*)()) F658_5756;
	R4936[20] = (char *(*)()) F659_5756;
	R4936[21] = (char *(*)()) F660_5756;
	R4936[22] = (char *(*)()) F661_5756;
	R4936[23] = (char *(*)()) F662_5756;
	R4936[24] = (char *(*)()) F663_5756;
	R4936[25] = (char *(*)()) F664_5756;
	R4936[26] = (char *(*)()) F665_5756;
	R4936[27] = (char *(*)()) F666_5756;
	R4936[28] = (char *(*)()) F667_5756;
	R4936[29] = (char *(*)()) F668_5756;
	R4936[30] = (char *(*)()) F657_5756;
	R4936[31] = (char *(*)()) F658_5756;
	R4936[32] = (char *(*)()) F663_5756;
	R4936[37] = (char *(*)()) F657_5756;
	R4936[38] = (char *(*)()) F658_5756;
	{long i; for (i = 39; i < 43; i++) R4936[i] = (char *(*)()) F657_5756;}
	R4936[47] = (char *(*)()) F657_5756;
	R4936[49] = (char *(*)()) F657_5756;
	R4936[51] = (char *(*)()) F657_5756;
	R4936[55] = (char *(*)()) F657_5756;
	{long i; for (i = 57; i < 61; i++) R4936[i] = (char *(*)()) F657_5756;}
	R4936[83] = (char *(*)()) F482_5222;
	R4936[88] = (char *(*)()) F482_5222;
	{long i; for (i = 281; i < 283; i++) R4936[i] = (char *(*)()) F919_7176;}
	{long i; for (i = 494; i < 497; i++) R4936[i] = (char *(*)()) F1125_10150;}
	R4936[537] = (char *(*)()) F1125_10150;
	R4936[547] = (char *(*)()) F1125_10150;
	R4936[734] = (char *(*)()) F919_7176;
}

char *(*R4937[735])();
void R4937_init () {
	R4937[0] = (char *(*)()) F639_5491;
	R4937[1] = (char *(*)()) F640_5491;
	R4937[2] = (char *(*)()) F641_5491;
	{long i; for (i = 3; i < 5; i++) R4937[i] = (char *(*)()) F639_5491;}
	R4937[5] = (char *(*)()) F641_5491;
	R4937[6] = (char *(*)()) F640_5491;
	R4937[18] = (char *(*)()) F615_5469;
	R4937[19] = (char *(*)()) F616_5469;
	R4937[20] = (char *(*)()) F617_5469;
	R4937[21] = (char *(*)()) F618_5469;
	R4937[22] = (char *(*)()) F619_5469;
	R4937[23] = (char *(*)()) F620_5469;
	R4937[24] = (char *(*)()) F621_5469;
	R4937[25] = (char *(*)()) F622_5469;
	R4937[26] = (char *(*)()) F623_5469;
	R4937[27] = (char *(*)()) F624_5469;
	R4937[28] = (char *(*)()) F625_5469;
	R4937[29] = (char *(*)()) F626_5469;
	R4937[30] = (char *(*)()) F615_5469;
	R4937[31] = (char *(*)()) F616_5469;
	R4937[32] = (char *(*)()) F621_5469;
	R4937[37] = (char *(*)()) F615_5469;
	R4937[38] = (char *(*)()) F616_5469;
	{long i; for (i = 39; i < 43; i++) R4937[i] = (char *(*)()) F615_5469;}
	R4937[47] = (char *(*)()) F615_5469;
	R4937[49] = (char *(*)()) F615_5469;
	R4937[51] = (char *(*)()) F615_5469;
	R4937[55] = (char *(*)()) F615_5469;
	{long i; for (i = 57; i < 61; i++) R4937[i] = (char *(*)()) F615_5469;}
	{long i; for (i = 281; i < 283; i++) R4937[i] = (char *(*)()) F919_7118;}
	{long i; for (i = 494; i < 497; i++) R4937[i] = (char *(*)()) F615_5469;}
	R4937[537] = (char *(*)()) F615_5469;
	R4937[547] = (char *(*)()) F615_5469;
	R4937[734] = (char *(*)()) F919_7118;
}

char *(*R4938[717])();
void R4938_init () {
	R4938[0] = (char *(*)()) F657_5757;
	R4938[1] = (char *(*)()) F658_5757;
	R4938[2] = (char *(*)()) F659_5757;
	R4938[3] = (char *(*)()) F660_5757;
	R4938[4] = (char *(*)()) F661_5757;
	R4938[5] = (char *(*)()) F662_5757;
	R4938[6] = (char *(*)()) F663_5757;
	R4938[7] = (char *(*)()) F664_5757;
	R4938[8] = (char *(*)()) F665_5757;
	R4938[9] = (char *(*)()) F666_5757;
	R4938[10] = (char *(*)()) F667_5757;
	R4938[11] = (char *(*)()) F668_5757;
	R4938[12] = (char *(*)()) F657_5757;
	R4938[13] = (char *(*)()) F658_5757;
	R4938[14] = (char *(*)()) F663_5757;
	R4938[19] = (char *(*)()) F657_5757;
	R4938[20] = (char *(*)()) F658_5757;
	{long i; for (i = 21; i < 25; i++) R4938[i] = (char *(*)()) F657_5757;}
	R4938[29] = (char *(*)()) F657_5757;
	R4938[31] = (char *(*)()) F657_5757;
	R4938[33] = (char *(*)()) F657_5757;
	R4938[37] = (char *(*)()) F657_5757;
	{long i; for (i = 39; i < 43; i++) R4938[i] = (char *(*)()) F657_5757;}
	{long i; for (i = 263; i < 265; i++) R4938[i] = (char *(*)()) F919_7177;}
	{long i; for (i = 476; i < 479; i++) R4938[i] = (char *(*)()) F1125_10149;}
	R4938[519] = (char *(*)()) F1125_10149;
	R4938[529] = (char *(*)()) F1125_10149;
	R4938[716] = (char *(*)()) F1373_14091;
}

char *(*R4939[548])();
void R4939_init () {
	R4939[0] = (char *(*)()) F603_5453;
	R4939[1] = (char *(*)()) F604_5453;
	R4939[2] = (char *(*)()) F609_5453;
	{long i; for (i = 3; i < 5; i++) R4939[i] = (char *(*)()) F603_5453;}
	R4939[5] = (char *(*)()) F609_5453;
	R4939[6] = (char *(*)()) F604_5453;
	R4939[18] = (char *(*)()) F603_5453;
	R4939[19] = (char *(*)()) F604_5453;
	R4939[20] = (char *(*)()) F605_5453;
	R4939[21] = (char *(*)()) F606_5453;
	R4939[22] = (char *(*)()) F607_5453;
	R4939[23] = (char *(*)()) F608_5453;
	R4939[24] = (char *(*)()) F609_5453;
	R4939[25] = (char *(*)()) F610_5453;
	R4939[26] = (char *(*)()) F611_5453;
	R4939[27] = (char *(*)()) F612_5453;
	R4939[28] = (char *(*)()) F613_5453;
	R4939[29] = (char *(*)()) F614_5453;
	R4939[30] = (char *(*)()) F603_5453;
	R4939[31] = (char *(*)()) F604_5453;
	R4939[32] = (char *(*)()) F609_5453;
	R4939[37] = (char *(*)()) F603_5453;
	R4939[38] = (char *(*)()) F604_5453;
	{long i; for (i = 39; i < 43; i++) R4939[i] = (char *(*)()) F603_5453;}
	R4939[47] = (char *(*)()) F603_5453;
	R4939[49] = (char *(*)()) F603_5453;
	R4939[51] = (char *(*)()) F603_5453;
	R4939[55] = (char *(*)()) F603_5453;
	{long i; for (i = 57; i < 61; i++) R4939[i] = (char *(*)()) F603_5453;}
	{long i; for (i = 494; i < 497; i++) R4939[i] = (char *(*)()) F603_5453;}
	R4939[537] = (char *(*)()) F603_5453;
	R4939[547] = (char *(*)()) F603_5453;
}


#ifdef __cplusplus
}
#endif
