#include "epoly8.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4963[548])();
void R4963_init () {
	R4963[0] = (char *(*)()) F639_5485;
	R4963[1] = (char *(*)()) F640_5485;
	R4963[2] = (char *(*)()) F641_5485;
	{long i; for (i = 3; i < 5; i++) R4963[i] = (char *(*)()) F639_5485;}
	R4963[5] = (char *(*)()) F641_5485;
	R4963[6] = (char *(*)()) F640_5485;
	R4963[18] = (char *(*)()) F657_5734;
	R4963[19] = (char *(*)()) F658_5734;
	R4963[20] = (char *(*)()) F659_5734;
	R4963[21] = (char *(*)()) F660_5734;
	R4963[22] = (char *(*)()) F661_5734;
	R4963[23] = (char *(*)()) F662_5734;
	R4963[24] = (char *(*)()) F663_5734;
	R4963[25] = (char *(*)()) F664_5734;
	R4963[26] = (char *(*)()) F665_5734;
	R4963[27] = (char *(*)()) F666_5734;
	R4963[28] = (char *(*)()) F667_5734;
	R4963[29] = (char *(*)()) F668_5734;
	R4963[30] = (char *(*)()) F657_5734;
	R4963[31] = (char *(*)()) F658_5734;
	R4963[32] = (char *(*)()) F663_5734;
	R4963[37] = (char *(*)()) F657_5734;
	R4963[38] = (char *(*)()) F658_5734;
	{long i; for (i = 39; i < 43; i++) R4963[i] = (char *(*)()) F657_5734;}
	R4963[47] = (char *(*)()) F657_5734;
	R4963[49] = (char *(*)()) F657_5734;
	R4963[51] = (char *(*)()) F657_5734;
	R4963[55] = (char *(*)()) F657_5734;
	{long i; for (i = 57; i < 61; i++) R4963[i] = (char *(*)()) F657_5734;}
	{long i; for (i = 494; i < 497; i++) R4963[i] = (char *(*)()) F1125_10140;}
	R4963[537] = (char *(*)()) F1125_10140;
	R4963[547] = (char *(*)()) F1125_10140;
}

static EIF_TYPE_INDEX Y4963_pgtype0[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype1[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype2[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype3[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype4[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype5[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype6[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype7[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype8[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype9[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype10[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype11[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype12[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype13[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype14[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype15[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype16[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype17[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype18[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype19[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype20[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype21[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype22[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype23[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype24[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype25[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype26[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype27[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype28[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype29[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype30[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype31[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype32[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype33[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype34[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype35[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype36[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype37[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype38[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype39[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype40[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype41[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype42[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype43[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype44[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype45[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype46[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype47[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype48[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype49[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype50[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype51[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype52[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype53[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype54[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype55[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype56[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype57[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype58[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype59[] = {0xFF01,244,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype60[] = {0xFF01,246,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype61[] = {0xFF01,247,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype62[] = {0xFF01,248,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype63[] = {0xFF01,246,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype64[] = {0xFF01,246,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype65[] = {0xFF01,248,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype66[] = {0xFF01,247,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype67[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype68[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype69[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype70[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype71[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype72[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype73[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype74[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype75[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype76[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype77[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype78[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype79[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype80[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype81[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype82[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype83[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype84[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype85[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype86[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype87[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype88[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype89[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype90[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype91[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype92[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype93[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype94[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype95[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype96[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype97[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype98[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype99[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype100[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype101[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype102[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype103[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype104[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype105[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype106[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype107[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype108[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype109[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype110[] = {0xFF01,245,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype111[] = {0xFF01,245,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype112[] = {0xFF01,245,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype113[] = {0xFF01,245,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype114[] = {0xFF01,245,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype115[] = {0xFF01,245,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype116[] = {0xFF01,245,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype117[] = {0xFF01,245,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype118[] = {0xFF01,250,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype119[] = {0xFF01,245,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype120[] = {0xFF01,245,0xFF01,1164,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype121[] = {0xFF01,245,0xFF01,1165,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype122[] = {0xFF01,245,0xFF01,1163,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype123[] = {0xFF01,245,0xFF01,1163,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype124[] = {0xFF01,245,0xFF01,1163,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype125[] = {0xFF01,245,0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype126[] = {0xFF01,245,0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype127[] = {0xFF01,245,0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype128[] = {0xFF01,245,0xFF01,1181,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype129[] = {0xFF01,245,0xFF01,1169,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype130[] = {0xFF01,245,0xFF01,1169,0xFFFF};
static EIF_TYPE_INDEX Y4963_pgtype131[] = {0xFF01,245,0xFF01,1169,0xFFFF};
EIF_TYPE_INDEX *Y4963_gen_type [731];
EIF_TYPE_INDEX Y4963 [731];
void Y4963_init (void)
{
	egc_routines_types [4963] = Y4963;
	egc_routines_gen_types [4963] = Y4963_gen_type;
	egc_routines_offset [4963] = 455;
	Y4963_gen_type [0] = Y4963_pgtype0;
	Y4963_gen_type [1] = Y4963_pgtype1;
	Y4963_gen_type [2] = Y4963_pgtype2;
	Y4963_gen_type [3] = Y4963_pgtype3;
	Y4963_gen_type [4] = Y4963_pgtype4;
	Y4963_gen_type [5] = Y4963_pgtype5;
	Y4963_gen_type [6] = Y4963_pgtype6;
	Y4963_gen_type [7] = Y4963_pgtype7;
	Y4963_gen_type [8] = Y4963_pgtype8;
	Y4963_gen_type [9] = Y4963_pgtype9;
	Y4963_gen_type [10] = Y4963_pgtype10;
	Y4963_gen_type [11] = Y4963_pgtype11;
	Y4963_gen_type [135] = Y4963_pgtype12;
	Y4963_gen_type [136] = Y4963_pgtype13;
	Y4963_gen_type [137] = Y4963_pgtype14;
	Y4963_gen_type [138] = Y4963_pgtype15;
	Y4963_gen_type [139] = Y4963_pgtype16;
	Y4963_gen_type [140] = Y4963_pgtype17;
	Y4963_gen_type [141] = Y4963_pgtype18;
	Y4963_gen_type [142] = Y4963_pgtype19;
	Y4963_gen_type [143] = Y4963_pgtype20;
	Y4963_gen_type [144] = Y4963_pgtype21;
	Y4963_gen_type [145] = Y4963_pgtype22;
	Y4963_gen_type [146] = Y4963_pgtype23;
	Y4963_gen_type [147] = Y4963_pgtype24;
	Y4963_gen_type [148] = Y4963_pgtype25;
	Y4963_gen_type [149] = Y4963_pgtype26;
	Y4963_gen_type [150] = Y4963_pgtype27;
	Y4963_gen_type [151] = Y4963_pgtype28;
	Y4963_gen_type [152] = Y4963_pgtype29;
	Y4963_gen_type [153] = Y4963_pgtype30;
	Y4963_gen_type [154] = Y4963_pgtype31;
	Y4963_gen_type [155] = Y4963_pgtype32;
	Y4963_gen_type [156] = Y4963_pgtype33;
	Y4963_gen_type [157] = Y4963_pgtype34;
	Y4963_gen_type [158] = Y4963_pgtype35;
	Y4963_gen_type [159] = Y4963_pgtype36;
	Y4963_gen_type [160] = Y4963_pgtype37;
	Y4963_gen_type [161] = Y4963_pgtype38;
	Y4963_gen_type [162] = Y4963_pgtype39;
	Y4963_gen_type [163] = Y4963_pgtype40;
	Y4963_gen_type [164] = Y4963_pgtype41;
	Y4963_gen_type [165] = Y4963_pgtype42;
	Y4963_gen_type [166] = Y4963_pgtype43;
	Y4963_gen_type [167] = Y4963_pgtype44;
	Y4963_gen_type [168] = Y4963_pgtype45;
	Y4963_gen_type [169] = Y4963_pgtype46;
	Y4963_gen_type [170] = Y4963_pgtype47;
	Y4963_gen_type [171] = Y4963_pgtype48;
	Y4963_gen_type [172] = Y4963_pgtype49;
	Y4963_gen_type [173] = Y4963_pgtype50;
	Y4963_gen_type [174] = Y4963_pgtype51;
	Y4963_gen_type [175] = Y4963_pgtype52;
	Y4963_gen_type [176] = Y4963_pgtype53;
	Y4963_gen_type [177] = Y4963_pgtype54;
	Y4963_gen_type [178] = Y4963_pgtype55;
	Y4963_gen_type [179] = Y4963_pgtype56;
	Y4963_gen_type [180] = Y4963_pgtype57;
	Y4963_gen_type [181] = Y4963_pgtype58;
	Y4963_gen_type [182] = Y4963_pgtype59;
	Y4963_gen_type [183] = Y4963_pgtype60;
	Y4963_gen_type [184] = Y4963_pgtype61;
	Y4963_gen_type [185] = Y4963_pgtype62;
	Y4963_gen_type [186] = Y4963_pgtype63;
	Y4963_gen_type [187] = Y4963_pgtype64;
	Y4963_gen_type [188] = Y4963_pgtype65;
	Y4963_gen_type [189] = Y4963_pgtype66;
	Y4963_gen_type [201] = Y4963_pgtype67;
	Y4963_gen_type [202] = Y4963_pgtype68;
	Y4963_gen_type [203] = Y4963_pgtype69;
	Y4963_gen_type [204] = Y4963_pgtype70;
	Y4963_gen_type [205] = Y4963_pgtype71;
	Y4963_gen_type [206] = Y4963_pgtype72;
	Y4963_gen_type [207] = Y4963_pgtype73;
	Y4963_gen_type [208] = Y4963_pgtype74;
	Y4963_gen_type [209] = Y4963_pgtype75;
	Y4963_gen_type [210] = Y4963_pgtype76;
	Y4963_gen_type [211] = Y4963_pgtype77;
	Y4963_gen_type [212] = Y4963_pgtype78;
	Y4963_gen_type [213] = Y4963_pgtype79;
	Y4963_gen_type [214] = Y4963_pgtype80;
	Y4963_gen_type [215] = Y4963_pgtype81;
	Y4963_gen_type [216] = Y4963_pgtype82;
	Y4963_gen_type [217] = Y4963_pgtype83;
	Y4963_gen_type [218] = Y4963_pgtype84;
	Y4963_gen_type [219] = Y4963_pgtype85;
	Y4963_gen_type [220] = Y4963_pgtype86;
	Y4963_gen_type [221] = Y4963_pgtype87;
	Y4963_gen_type [222] = Y4963_pgtype88;
	Y4963_gen_type [223] = Y4963_pgtype89;
	Y4963_gen_type [224] = Y4963_pgtype90;
	Y4963_gen_type [225] = Y4963_pgtype91;
	Y4963_gen_type [226] = Y4963_pgtype92;
	Y4963_gen_type [227] = Y4963_pgtype93;
	Y4963_gen_type [228] = Y4963_pgtype94;
	Y4963_gen_type [229] = Y4963_pgtype95;
	Y4963_gen_type [230] = Y4963_pgtype96;
	Y4963_gen_type [231] = Y4963_pgtype97;
	Y4963_gen_type [232] = Y4963_pgtype98;
	Y4963_gen_type [233] = Y4963_pgtype99;
	Y4963_gen_type [234] = Y4963_pgtype100;
	Y4963_gen_type [235] = Y4963_pgtype101;
	Y4963_gen_type [236] = Y4963_pgtype102;
	Y4963_gen_type [237] = Y4963_pgtype103;
	Y4963_gen_type [238] = Y4963_pgtype104;
	Y4963_gen_type [239] = Y4963_pgtype105;
	Y4963_gen_type [240] = Y4963_pgtype106;
	Y4963_gen_type [241] = Y4963_pgtype107;
	Y4963_gen_type [242] = Y4963_pgtype108;
	Y4963_gen_type [243] = Y4963_pgtype109;
	Y4963_gen_type [669] = Y4963_pgtype110;
	Y4963_gen_type [673] = Y4963_pgtype111;
	Y4963_gen_type [674] = Y4963_pgtype112;
	Y4963_gen_type [675] = Y4963_pgtype113;
	Y4963_gen_type [676] = Y4963_pgtype114;
	Y4963_gen_type [677] = Y4963_pgtype115;
	Y4963_gen_type [678] = Y4963_pgtype116;
	Y4963_gen_type [679] = Y4963_pgtype117;
	Y4963_gen_type [709] = Y4963_pgtype118;
	Y4963_gen_type [718] = Y4963_pgtype119;
	Y4963_gen_type [719] = Y4963_pgtype120;
	Y4963_gen_type [720] = Y4963_pgtype121;
	Y4963_gen_type [721] = Y4963_pgtype122;
	Y4963_gen_type [722] = Y4963_pgtype123;
	Y4963_gen_type [723] = Y4963_pgtype124;
	Y4963_gen_type [724] = Y4963_pgtype125;
	Y4963_gen_type [725] = Y4963_pgtype126;
	Y4963_gen_type [726] = Y4963_pgtype127;
	Y4963_gen_type [727] = Y4963_pgtype128;
	Y4963_gen_type [728] = Y4963_pgtype129;
	Y4963_gen_type [729] = Y4963_pgtype130;
	Y4963_gen_type [730] = Y4963_pgtype131;
	{long i; for (i = 0; i < 12; i++) Y4963[i] = 244;};
	{long i; for (i = 135; i < 183; i++) Y4963[i] = 244;};
	Y4963[183] = 246;
	Y4963[184] = 247;
	Y4963[185] = 248;
	{long i; for (i = 186; i < 188; i++) Y4963[i] = 246;};
	Y4963[188] = 248;
	Y4963[189] = 247;
	{long i; for (i = 201; i < 244; i++) Y4963[i] = 250;};
	Y4963[669] = 245;
	{long i; for (i = 673; i < 680; i++) Y4963[i] = 245;};
	Y4963[709] = 250;
	{long i; for (i = 718; i < 731; i++) Y4963[i] = 245;};
}

char *(*R4965[548])();
void R4965_init () {
	R4965[0] = (char *(*)()) F639_5504;
	R4965[1] = (char *(*)()) F640_5504;
	R4965[2] = (char *(*)()) F641_5504;
	{long i; for (i = 3; i < 5; i++) R4965[i] = (char *(*)()) F639_5504;}
	R4965[5] = (char *(*)()) F641_5504;
	R4965[6] = (char *(*)()) F640_5504;
	R4965[18] = (char *(*)()) F657_5759;
	R4965[19] = (char *(*)()) F658_5759;
	R4965[20] = (char *(*)()) F659_5759;
	R4965[21] = (char *(*)()) F660_5759;
	R4965[22] = (char *(*)()) F661_5759;
	R4965[23] = (char *(*)()) F662_5759;
	R4965[24] = (char *(*)()) F663_5759;
	R4965[25] = (char *(*)()) F664_5759;
	R4965[26] = (char *(*)()) F665_5759;
	R4965[27] = (char *(*)()) F666_5759;
	R4965[28] = (char *(*)()) F667_5759;
	R4965[29] = (char *(*)()) F668_5759;
	R4965[30] = (char *(*)()) F657_5759;
	R4965[31] = (char *(*)()) F658_5759;
	R4965[32] = (char *(*)()) F663_5759;
	R4965[37] = (char *(*)()) F657_5759;
	R4965[38] = (char *(*)()) F658_5759;
	{long i; for (i = 39; i < 43; i++) R4965[i] = (char *(*)()) F657_5759;}
	R4965[47] = (char *(*)()) F657_5759;
	R4965[49] = (char *(*)()) F657_5759;
	R4965[51] = (char *(*)()) F657_5759;
	R4965[55] = (char *(*)()) F657_5759;
	{long i; for (i = 57; i < 61; i++) R4965[i] = (char *(*)()) F657_5759;}
	{long i; for (i = 494; i < 497; i++) R4965[i] = (char *(*)()) F1125_10152;}
	R4965[537] = (char *(*)()) F1125_10152;
	R4965[547] = (char *(*)()) F1125_10152;
}

char *(*R4967[6])();
void R4967_init () {
	R4967[0] = (char *(*)()) F722_6098;
	R4967[5] = (char *(*)()) F727_6163;
}

char *(*R4969[798])();
void R4969_init () {
	R4969[0] = (char *(*)()) F576_5312;
	R4969[2] = (char *(*)()) F578_5361;
	R4969[3] = (char *(*)()) F579_5361;
	R4969[4] = (char *(*)()) F580_5361;
	R4969[5] = (char *(*)()) F581_5361;
	R4969[6] = (char *(*)()) F582_5361;
	R4969[7] = (char *(*)()) F583_5361;
	R4969[8] = (char *(*)()) F584_5361;
	R4969[9] = (char *(*)()) F585_5361;
	R4969[10] = (char *(*)()) F586_5361;
	R4969[11] = (char *(*)()) F587_5361;
	R4969[12] = (char *(*)()) F588_5361;
	R4969[13] = (char *(*)()) F589_5361;
	R4969[63] = (char *(*)()) F639_5488;
	R4969[64] = (char *(*)()) F640_5488;
	R4969[65] = (char *(*)()) F641_5488;
	{long i; for (i = 66; i < 68; i++) R4969[i] = (char *(*)()) F639_5488;}
	R4969[68] = (char *(*)()) F641_5488;
	R4969[69] = (char *(*)()) F640_5488;
	R4969[72] = (char *(*)()) F648_5610;
	R4969[73] = (char *(*)()) F649_5610;
	R4969[74] = (char *(*)()) F650_5610;
	R4969[75] = (char *(*)()) F651_5610;
	R4969[76] = (char *(*)()) F652_5610;
	R4969[77] = (char *(*)()) F653_5610;
	R4969[78] = (char *(*)()) F648_5610;
	R4969[79] = (char *(*)()) F649_5610;
	R4969[80] = (char *(*)()) F648_5610;
	R4969[81] = (char *(*)()) F657_5744;
	R4969[82] = (char *(*)()) F658_5744;
	R4969[83] = (char *(*)()) F659_5744;
	R4969[84] = (char *(*)()) F660_5744;
	R4969[85] = (char *(*)()) F661_5744;
	R4969[86] = (char *(*)()) F662_5744;
	R4969[87] = (char *(*)()) F663_5744;
	R4969[88] = (char *(*)()) F664_5744;
	R4969[89] = (char *(*)()) F665_5744;
	R4969[90] = (char *(*)()) F666_5744;
	R4969[91] = (char *(*)()) F667_5744;
	R4969[92] = (char *(*)()) F668_5744;
	R4969[93] = (char *(*)()) F657_5744;
	R4969[94] = (char *(*)()) F658_5744;
	R4969[95] = (char *(*)()) F663_5744;
	R4969[100] = (char *(*)()) F657_5744;
	R4969[101] = (char *(*)()) F658_5744;
	{long i; for (i = 102; i < 106; i++) R4969[i] = (char *(*)()) F657_5744;}
	R4969[110] = (char *(*)()) F657_5744;
	R4969[112] = (char *(*)()) F657_5744;
	R4969[114] = (char *(*)()) F657_5744;
	R4969[118] = (char *(*)()) F657_5744;
	{long i; for (i = 120; i < 124; i++) R4969[i] = (char *(*)()) F657_5744;}
	{long i; for (i = 344; i < 346; i++) R4969[i] = (char *(*)()) F919_7116;}
	R4969[475] = (char *(*)()) F1049_9140;
	R4969[478] = (char *(*)()) F1052_9308;
	{long i; for (i = 557; i < 560; i++) R4969[i] = (char *(*)()) F1125_10145;}
	R4969[600] = (char *(*)()) F1125_10145;
	R4969[610] = (char *(*)()) F1125_10145;
	R4969[797] = (char *(*)()) F1373_14089;
}

char *(*R4970[479])();
void R4970_init () {
	R4970[0] = (char *(*)()) F576_5311;
	R4970[2] = (char *(*)()) F578_5362;
	R4970[3] = (char *(*)()) F579_5362;
	R4970[4] = (char *(*)()) F580_5362;
	R4970[5] = (char *(*)()) F581_5362;
	R4970[6] = (char *(*)()) F582_5362;
	R4970[7] = (char *(*)()) F583_5362;
	R4970[8] = (char *(*)()) F584_5362;
	R4970[9] = (char *(*)()) F585_5362;
	R4970[10] = (char *(*)()) F586_5362;
	R4970[11] = (char *(*)()) F587_5362;
	R4970[12] = (char *(*)()) F588_5362;
	R4970[13] = (char *(*)()) F589_5362;
	R4970[81] = (char *(*)()) F657_5745;
	R4970[82] = (char *(*)()) F658_5745;
	R4970[83] = (char *(*)()) F659_5745;
	R4970[84] = (char *(*)()) F660_5745;
	R4970[85] = (char *(*)()) F661_5745;
	R4970[86] = (char *(*)()) F662_5745;
	R4970[87] = (char *(*)()) F663_5745;
	R4970[88] = (char *(*)()) F664_5745;
	R4970[89] = (char *(*)()) F665_5745;
	R4970[90] = (char *(*)()) F666_5745;
	R4970[91] = (char *(*)()) F667_5745;
	R4970[92] = (char *(*)()) F668_5745;
	R4970[93] = (char *(*)()) F657_5745;
	R4970[94] = (char *(*)()) F658_5745;
	R4970[95] = (char *(*)()) F663_5745;
	R4970[100] = (char *(*)()) F657_5745;
	R4970[101] = (char *(*)()) F658_5745;
	{long i; for (i = 102; i < 106; i++) R4970[i] = (char *(*)()) F657_5745;}
	R4970[110] = (char *(*)()) F657_5745;
	R4970[112] = (char *(*)()) F657_5745;
	R4970[114] = (char *(*)()) F657_5745;
	R4970[118] = (char *(*)()) F657_5745;
	{long i; for (i = 120; i < 124; i++) R4970[i] = (char *(*)()) F657_5745;}
	R4970[475] = (char *(*)()) F1049_9139;
	R4970[478] = (char *(*)()) F1052_9307;
}

char *(*R4974[479])();
void R4974_init () {
	R4974[0] = (char *(*)()) F508_5239;
	R4974[2] = (char *(*)()) F507_5239;
	R4974[3] = (char *(*)()) F508_5239;
	R4974[4] = (char *(*)()) F509_5239;
	R4974[5] = (char *(*)()) F510_5239;
	R4974[6] = (char *(*)()) F511_5239;
	R4974[7] = (char *(*)()) F512_5239;
	R4974[8] = (char *(*)()) F513_5239;
	R4974[9] = (char *(*)()) F514_5239;
	R4974[10] = (char *(*)()) F515_5239;
	R4974[11] = (char *(*)()) F516_5239;
	R4974[12] = (char *(*)()) F517_5239;
	R4974[13] = (char *(*)()) F518_5239;
	R4974[81] = (char *(*)()) F507_5239;
	R4974[82] = (char *(*)()) F508_5239;
	R4974[83] = (char *(*)()) F509_5239;
	R4974[84] = (char *(*)()) F510_5239;
	R4974[85] = (char *(*)()) F511_5239;
	R4974[86] = (char *(*)()) F512_5239;
	R4974[87] = (char *(*)()) F513_5239;
	R4974[88] = (char *(*)()) F514_5239;
	R4974[89] = (char *(*)()) F515_5239;
	R4974[90] = (char *(*)()) F516_5239;
	R4974[91] = (char *(*)()) F517_5239;
	R4974[92] = (char *(*)()) F518_5239;
	R4974[93] = (char *(*)()) F507_5239;
	R4974[94] = (char *(*)()) F508_5239;
	R4974[95] = (char *(*)()) F513_5239;
	R4974[100] = (char *(*)()) F507_5239;
	R4974[101] = (char *(*)()) F508_5239;
	{long i; for (i = 102; i < 106; i++) R4974[i] = (char *(*)()) F507_5239;}
	R4974[110] = (char *(*)()) F507_5239;
	R4974[112] = (char *(*)()) F507_5239;
	R4974[114] = (char *(*)()) F507_5239;
	R4974[118] = (char *(*)()) F507_5239;
	{long i; for (i = 120; i < 124; i++) R4974[i] = (char *(*)()) F507_5239;}
	R4974[475] = (char *(*)()) F515_5239;
	R4974[478] = (char *(*)()) F516_5239;
}

char *(*R4976[479])();
void R4976_init () {
	R4976[0] = (char *(*)()) F576_5322;
	R4976[2] = (char *(*)()) F578_5392;
	R4976[3] = (char *(*)()) F579_5392;
	R4976[4] = (char *(*)()) F580_5392;
	R4976[5] = (char *(*)()) F581_5392;
	R4976[6] = (char *(*)()) F582_5392;
	R4976[7] = (char *(*)()) F583_5392;
	R4976[8] = (char *(*)()) F584_5392;
	R4976[9] = (char *(*)()) F585_5392;
	R4976[10] = (char *(*)()) F586_5392;
	R4976[11] = (char *(*)()) F587_5392;
	R4976[12] = (char *(*)()) F588_5392;
	R4976[13] = (char *(*)()) F589_5392;
	R4976[81] = (char *(*)()) F657_5771;
	R4976[82] = (char *(*)()) F658_5771;
	R4976[83] = (char *(*)()) F659_5771;
	R4976[84] = (char *(*)()) F660_5771;
	R4976[85] = (char *(*)()) F661_5771;
	R4976[86] = (char *(*)()) F662_5771;
	R4976[87] = (char *(*)()) F663_5771;
	R4976[88] = (char *(*)()) F664_5771;
	R4976[89] = (char *(*)()) F665_5771;
	R4976[90] = (char *(*)()) F666_5771;
	R4976[91] = (char *(*)()) F667_5771;
	R4976[92] = (char *(*)()) F668_5771;
	R4976[93] = (char *(*)()) F657_5771;
	R4976[94] = (char *(*)()) F658_5771;
	R4976[95] = (char *(*)()) F663_5771;
	R4976[100] = (char *(*)()) F657_5771;
	R4976[101] = (char *(*)()) F658_5771;
	{long i; for (i = 102; i < 106; i++) R4976[i] = (char *(*)()) F657_5771;}
	R4976[110] = (char *(*)()) F657_5771;
	R4976[112] = (char *(*)()) F657_5771;
	R4976[114] = (char *(*)()) F657_5771;
	R4976[118] = (char *(*)()) F657_5771;
	{long i; for (i = 120; i < 124; i++) R4976[i] = (char *(*)()) F657_5771;}
	R4976[475] = (char *(*)()) F1051_9267;
	R4976[478] = (char *(*)()) F1054_9432;
}

char *(*R4978[735])();
void R4978_init () {
	R4978[0] = (char *(*)()) F519_5246;
	R4978[1] = (char *(*)()) F520_5246_4978_4;
	R4978[2] = (char *(*)()) F525_5246_4978_4;
	R4978[3] = (char *(*)()) F642_5530;
	R4978[4] = (char *(*)()) F643_5546;
	R4978[5] = (char *(*)()) F644_5546_4978_4;
	R4978[6] = (char *(*)()) F645_5546_4978_4;
	R4978[18] = (char *(*)()) F657_5763;
	R4978[19] = (char *(*)()) F658_5763_4978_4;
	R4978[20] = (char *(*)()) F659_5763_4978_4;
	R4978[21] = (char *(*)()) F660_5763_4978_4;
	R4978[22] = (char *(*)()) F661_5763_4978_4;
	R4978[23] = (char *(*)()) F662_5763_4978_4;
	R4978[24] = (char *(*)()) F663_5763_4978_4;
	R4978[25] = (char *(*)()) F664_5763_4978_4;
	R4978[26] = (char *(*)()) F665_5763_4978_4;
	R4978[27] = (char *(*)()) F666_5763_4978_4;
	R4978[28] = (char *(*)()) F667_5763_4978_4;
	R4978[29] = (char *(*)()) F668_5763_4978_4;
	R4978[30] = (char *(*)()) F657_5763;
	R4978[31] = (char *(*)()) F658_5763_4978_4;
	R4978[32] = (char *(*)()) F663_5763_4978_4;
	R4978[37] = (char *(*)()) F657_5763;
	R4978[38] = (char *(*)()) F658_5763_4978_4;
	{long i; for (i = 39; i < 43; i++) R4978[i] = (char *(*)()) F657_5763;}
	R4978[47] = (char *(*)()) F657_5763;
	R4978[49] = (char *(*)()) F657_5763;
	R4978[51] = (char *(*)()) F657_5763;
	R4978[55] = (char *(*)()) F657_5763;
	{long i; for (i = 57; i < 61; i++) R4978[i] = (char *(*)()) F657_5763;}
	{long i; for (i = 281; i < 283; i++) R4978[i] = (char *(*)()) F528_5246_4978_4;}
	{long i; for (i = 494; i < 497; i++) R4978[i] = (char *(*)()) F519_5246;}
	R4978[537] = (char *(*)()) F519_5246;
	R4978[547] = (char *(*)()) F519_5246;
	R4978[734] = (char *(*)()) F528_5246_4978_4;
}
static void F520_5246_4978_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F520_5246(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F525_5246_4978_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F525_5246(Current, *(EIF_BOOLEAN *)arg1);
}
static void F644_5546_4978_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F644_5546(Current, *(EIF_BOOLEAN *)arg1);
}
static void F645_5546_4978_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F645_5546(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F658_5763_4978_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F658_5763(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F659_5763_4978_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F659_5763(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F660_5763_4978_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F660_5763(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F661_5763_4978_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F661_5763(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F662_5763_4978_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F662_5763(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F663_5763_4978_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F663_5763(Current, *(EIF_BOOLEAN *)arg1);
}
static void F664_5763_4978_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F664_5763(Current, *(EIF_POINTER *)arg1);
}
static void F665_5763_4978_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F665_5763(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F666_5763_4978_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F666_5763(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F667_5763_4978_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F667_5763(Current, *(EIF_REAL_32 *)arg1);
}
static void F668_5763_4978_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F668_5763(Current, *(EIF_REAL_64 *)arg1);
}
static void F528_5246_4978_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F528_5246(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4992[611])();
void R4992_init () {
	R4992[0] = (char *(*)()) F576_5306_4992_20;
	R4992[2] = (char *(*)()) F578_5354;
	R4992[3] = (char *(*)()) F579_5354_4992_20;
	R4992[4] = (char *(*)()) F580_5354_4992_20;
	R4992[5] = (char *(*)()) F581_5354_4992_20;
	R4992[6] = (char *(*)()) F582_5354_4992_20;
	R4992[7] = (char *(*)()) F583_5354_4992_20;
	R4992[8] = (char *(*)()) F584_5354_4992_20;
	R4992[9] = (char *(*)()) F585_5354_4992_20;
	R4992[10] = (char *(*)()) F586_5354_4992_20;
	R4992[11] = (char *(*)()) F587_5354_4992_20;
	R4992[12] = (char *(*)()) F588_5354_4992_20;
	R4992[13] = (char *(*)()) F589_5354_4992_20;
	R4992[63] = (char *(*)()) F591_5433;
	R4992[64] = (char *(*)()) F592_5433_4992_20;
	R4992[65] = (char *(*)()) F597_5433_4992_20;
	{long i; for (i = 66; i < 68; i++) R4992[i] = (char *(*)()) F591_5433;}
	R4992[68] = (char *(*)()) F597_5433_4992_20;
	R4992[69] = (char *(*)()) F592_5433_4992_20;
	R4992[72] = (char *(*)()) F648_5608;
	R4992[73] = (char *(*)()) F649_5608_4992_20;
	R4992[74] = (char *(*)()) F650_5608;
	R4992[75] = (char *(*)()) F651_5608_4992_20;
	R4992[76] = (char *(*)()) F652_5608_4992_20;
	R4992[77] = (char *(*)()) F653_5608_4992_20;
	R4992[78] = (char *(*)()) F648_5608;
	R4992[79] = (char *(*)()) F649_5608_4992_20;
	R4992[80] = (char *(*)()) F648_5608;
	R4992[81] = (char *(*)()) F657_5729;
	R4992[82] = (char *(*)()) F658_5729_4992_20;
	R4992[83] = (char *(*)()) F659_5729_4992_20;
	R4992[84] = (char *(*)()) F660_5729_4992_20;
	R4992[85] = (char *(*)()) F661_5729_4992_20;
	R4992[86] = (char *(*)()) F662_5729_4992_20;
	R4992[87] = (char *(*)()) F663_5729_4992_20;
	R4992[88] = (char *(*)()) F664_5729_4992_20;
	R4992[89] = (char *(*)()) F665_5729_4992_20;
	R4992[90] = (char *(*)()) F666_5729_4992_20;
	R4992[91] = (char *(*)()) F667_5729_4992_20;
	R4992[92] = (char *(*)()) F668_5729_4992_20;
	R4992[93] = (char *(*)()) F657_5729;
	R4992[94] = (char *(*)()) F658_5729_4992_20;
	R4992[95] = (char *(*)()) F663_5729_4992_20;
	R4992[100] = (char *(*)()) F657_5729;
	R4992[101] = (char *(*)()) F658_5729_4992_20;
	{long i; for (i = 102; i < 106; i++) R4992[i] = (char *(*)()) F657_5729;}
	R4992[110] = (char *(*)()) F657_5729;
	R4992[112] = (char *(*)()) F657_5729;
	R4992[114] = (char *(*)()) F657_5729;
	R4992[118] = (char *(*)()) F657_5729;
	{long i; for (i = 120; i < 124; i++) R4992[i] = (char *(*)()) F657_5729;}
	R4992[259] = (char *(*)()) F835_6407;
	R4992[260] = (char *(*)()) F836_6407_4992_20;
	R4992[261] = (char *(*)()) F837_6407_4992_20;
	R4992[262] = (char *(*)()) F838_6407_4992_20;
	R4992[263] = (char *(*)()) F839_6407_4992_20;
	R4992[264] = (char *(*)()) F840_6407_4992_20;
	R4992[265] = (char *(*)()) F841_6407_4992_20;
	R4992[266] = (char *(*)()) F842_6407_4992_20;
	R4992[267] = (char *(*)()) F843_6407_4992_20;
	R4992[268] = (char *(*)()) F844_6407_4992_20;
	R4992[269] = (char *(*)()) F845_6407_4992_20;
	R4992[270] = (char *(*)()) F846_6407_4992_20;
	R4992[391] = (char *(*)()) F967_7756;
	R4992[474] = (char *(*)()) F1050_9178_4992_20;
	R4992[475] = (char *(*)()) F1051_9201_4992_20;
	R4992[477] = (char *(*)()) F1053_9343_4992_20;
	R4992[478] = (char *(*)()) F1054_9365_4992_20;
	{long i; for (i = 557; i < 560; i++) R4992[i] = (char *(*)()) F1125_10141;}
	R4992[600] = (char *(*)()) F1125_10141;
	R4992[610] = (char *(*)()) F1125_10141;
}
static EIF_REFERENCE F576_5306_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F576_5306(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F579_5354_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F579_5354(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F580_5354_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F580_5354(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(999, 0x00).id, 999, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F581_5354_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F581_5354(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(993, 0x00).id, 993, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F582_5354_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F582_5354(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F583_5354_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F583_5354(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F584_5354_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F584_5354(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F585_5354_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F585_5354(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F586_5354_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F586_5354(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F587_5354_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F587_5354(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F588_5354_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F588_5354(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F589_5354_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F589_5354(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F592_5433_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F592_5433(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F597_5433_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F597_5433(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F649_5608_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F649_5608(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F651_5608_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F651_5608(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F652_5608_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F652_5608(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F653_5608_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F653_5608(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F658_5729_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F658_5729(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F659_5729_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F659_5729(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(999, 0x00).id, 999, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F660_5729_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F660_5729(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(993, 0x00).id, 993, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F661_5729_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F661_5729(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F662_5729_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F662_5729(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F663_5729_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F663_5729(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_5729_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F664_5729(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F665_5729_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F665_5729(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_5729_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F666_5729(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_5729_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F667_5729(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_5729_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F668_5729(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F836_6407_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F836_6407(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F837_6407_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F837_6407(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(999, 0x00).id, 999, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F838_6407_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F838_6407(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(993, 0x00).id, 993, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F839_6407_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F839_6407(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F840_6407_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F840_6407(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F841_6407_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F841_6407(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F842_6407_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F842_6407(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F843_6407_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F843_6407(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F844_6407_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F844_6407(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F845_6407_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F845_6407(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F846_6407_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F846_6407(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1050_9178_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1050_9178(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1051_9201_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1051_9201(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1053_9343_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1053_9343(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1054_9365_4992_20 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1054_9365(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R4993[611])();
void R4993_init () {
	R4993[0] = (char *(*)()) F576_5303;
	R4993[2] = (char *(*)()) F578_5359;
	R4993[3] = (char *(*)()) F579_5359;
	R4993[4] = (char *(*)()) F580_5359;
	R4993[5] = (char *(*)()) F581_5359;
	R4993[6] = (char *(*)()) F582_5359;
	R4993[7] = (char *(*)()) F583_5359;
	R4993[8] = (char *(*)()) F584_5359;
	R4993[9] = (char *(*)()) F585_5359;
	R4993[10] = (char *(*)()) F586_5359;
	R4993[11] = (char *(*)()) F587_5359;
	R4993[12] = (char *(*)()) F588_5359;
	R4993[13] = (char *(*)()) F589_5359;
	R4993[63] = (char *(*)()) F591_5436;
	R4993[64] = (char *(*)()) F592_5436;
	R4993[65] = (char *(*)()) F597_5436;
	{long i; for (i = 66; i < 68; i++) R4993[i] = (char *(*)()) F591_5436;}
	R4993[68] = (char *(*)()) F597_5436;
	R4993[69] = (char *(*)()) F592_5436;
	R4993[72] = (char *(*)()) F648_5613;
	R4993[73] = (char *(*)()) F649_5613;
	R4993[74] = (char *(*)()) F650_5613;
	R4993[75] = (char *(*)()) F651_5613;
	R4993[76] = (char *(*)()) F652_5613;
	R4993[77] = (char *(*)()) F653_5613;
	R4993[78] = (char *(*)()) F648_5613;
	R4993[79] = (char *(*)()) F649_5613;
	R4993[80] = (char *(*)()) F648_5613;
	R4993[81] = (char *(*)()) F591_5436;
	R4993[82] = (char *(*)()) F592_5436;
	R4993[83] = (char *(*)()) F593_5436;
	R4993[84] = (char *(*)()) F594_5436;
	R4993[85] = (char *(*)()) F595_5436;
	R4993[86] = (char *(*)()) F596_5436;
	R4993[87] = (char *(*)()) F597_5436;
	R4993[88] = (char *(*)()) F598_5436;
	R4993[89] = (char *(*)()) F599_5436;
	R4993[90] = (char *(*)()) F600_5436;
	R4993[91] = (char *(*)()) F601_5436;
	R4993[92] = (char *(*)()) F602_5436;
	R4993[93] = (char *(*)()) F591_5436;
	R4993[94] = (char *(*)()) F592_5436;
	R4993[95] = (char *(*)()) F597_5436;
	R4993[100] = (char *(*)()) F591_5436;
	R4993[101] = (char *(*)()) F592_5436;
	{long i; for (i = 102; i < 106; i++) R4993[i] = (char *(*)()) F591_5436;}
	R4993[110] = (char *(*)()) F591_5436;
	R4993[112] = (char *(*)()) F591_5436;
	R4993[114] = (char *(*)()) F591_5436;
	R4993[118] = (char *(*)()) F591_5436;
	{long i; for (i = 120; i < 124; i++) R4993[i] = (char *(*)()) F591_5436;}
	R4993[259] = (char *(*)()) F835_6415;
	R4993[260] = (char *(*)()) F836_6415;
	R4993[261] = (char *(*)()) F837_6415;
	R4993[262] = (char *(*)()) F838_6415;
	R4993[263] = (char *(*)()) F839_6415;
	R4993[264] = (char *(*)()) F840_6415;
	R4993[265] = (char *(*)()) F841_6415;
	R4993[266] = (char *(*)()) F842_6415;
	R4993[267] = (char *(*)()) F843_6415;
	R4993[268] = (char *(*)()) F844_6415;
	R4993[269] = (char *(*)()) F845_6415;
	R4993[270] = (char *(*)()) F846_6415;
	R4993[391] = (char *(*)()) F967_7786;
	{long i; for (i = 474; i < 476; i++) R4993[i] = (char *(*)()) F1049_9142;}
	{long i; for (i = 477; i < 479; i++) R4993[i] = (char *(*)()) F1052_9310;}
	{long i; for (i = 557; i < 560; i++) R4993[i] = (char *(*)()) F591_5436;}
	R4993[600] = (char *(*)()) F591_5436;
	R4993[610] = (char *(*)()) F591_5436;
}

EIF_TYPE_INDEX *Y4993_gen_type [635];
EIF_TYPE_INDEX Y4993 [635];
void Y4993_init (void)
{
	egc_routines_types [4993] = Y4993;
	egc_routines_gen_types [4993] = Y4993_gen_type;
	egc_routines_offset [4993] = 551;
	{long i; for (i = 0; i < 94; i++) Y4993[i] = 984;};
	{long i; for (i = 96; i < 148; i++) Y4993[i] = 984;};
	{long i; for (i = 283; i < 295; i++) Y4993[i] = 984;};
	Y4993[415] = 984;
	{long i; for (i = 497; i < 504; i++) Y4993[i] = 984;};
	Y4993[573] = 984;
	{long i; for (i = 577; i < 584; i++) Y4993[i] = 984;};
	Y4993[613] = 984;
	{long i; for (i = 622; i < 635; i++) Y4993[i] = 984;};
}

char *(*R4994[611])();
void R4994_init () {
	R4994[0] = (char *(*)()) F576_5305;
	R4994[2] = (char *(*)()) F578_5360;
	R4994[3] = (char *(*)()) F579_5360;
	R4994[4] = (char *(*)()) F580_5360;
	R4994[5] = (char *(*)()) F581_5360;
	R4994[6] = (char *(*)()) F582_5360;
	R4994[7] = (char *(*)()) F583_5360;
	R4994[8] = (char *(*)()) F584_5360;
	R4994[9] = (char *(*)()) F585_5360;
	R4994[10] = (char *(*)()) F586_5360;
	R4994[11] = (char *(*)()) F587_5360;
	R4994[12] = (char *(*)()) F588_5360;
	R4994[13] = (char *(*)()) F589_5360;
	R4994[63] = (char *(*)()) F639_5488;
	R4994[64] = (char *(*)()) F640_5488;
	R4994[65] = (char *(*)()) F641_5488;
	{long i; for (i = 66; i < 68; i++) R4994[i] = (char *(*)()) F639_5488;}
	R4994[68] = (char *(*)()) F641_5488;
	R4994[69] = (char *(*)()) F640_5488;
	R4994[72] = (char *(*)()) F648_5614;
	R4994[73] = (char *(*)()) F649_5614;
	R4994[74] = (char *(*)()) F650_5614;
	R4994[75] = (char *(*)()) F651_5614;
	R4994[76] = (char *(*)()) F652_5614;
	R4994[77] = (char *(*)()) F653_5614;
	R4994[78] = (char *(*)()) F648_5614;
	R4994[79] = (char *(*)()) F649_5614;
	R4994[80] = (char *(*)()) F648_5614;
	R4994[81] = (char *(*)()) F657_5744;
	R4994[82] = (char *(*)()) F658_5744;
	R4994[83] = (char *(*)()) F659_5744;
	R4994[84] = (char *(*)()) F660_5744;
	R4994[85] = (char *(*)()) F661_5744;
	R4994[86] = (char *(*)()) F662_5744;
	R4994[87] = (char *(*)()) F663_5744;
	R4994[88] = (char *(*)()) F664_5744;
	R4994[89] = (char *(*)()) F665_5744;
	R4994[90] = (char *(*)()) F666_5744;
	R4994[91] = (char *(*)()) F667_5744;
	R4994[92] = (char *(*)()) F668_5744;
	R4994[93] = (char *(*)()) F657_5744;
	R4994[94] = (char *(*)()) F658_5744;
	R4994[95] = (char *(*)()) F663_5744;
	R4994[100] = (char *(*)()) F657_5744;
	R4994[101] = (char *(*)()) F658_5744;
	{long i; for (i = 102; i < 106; i++) R4994[i] = (char *(*)()) F657_5744;}
	R4994[110] = (char *(*)()) F657_5744;
	R4994[112] = (char *(*)()) F657_5744;
	R4994[114] = (char *(*)()) F657_5744;
	R4994[118] = (char *(*)()) F657_5744;
	{long i; for (i = 120; i < 124; i++) R4994[i] = (char *(*)()) F657_5744;}
	R4994[259] = (char *(*)()) F835_6416;
	R4994[260] = (char *(*)()) F836_6416;
	R4994[261] = (char *(*)()) F837_6416;
	R4994[262] = (char *(*)()) F838_6416;
	R4994[263] = (char *(*)()) F839_6416;
	R4994[264] = (char *(*)()) F840_6416;
	R4994[265] = (char *(*)()) F841_6416;
	R4994[266] = (char *(*)()) F842_6416;
	R4994[267] = (char *(*)()) F843_6416;
	R4994[268] = (char *(*)()) F844_6416;
	R4994[269] = (char *(*)()) F845_6416;
	R4994[270] = (char *(*)()) F846_6416;
	R4994[391] = (char *(*)()) F967_7785;
	{long i; for (i = 474; i < 476; i++) R4994[i] = (char *(*)()) F1049_9140;}
	{long i; for (i = 477; i < 479; i++) R4994[i] = (char *(*)()) F1052_9308;}
	{long i; for (i = 557; i < 560; i++) R4994[i] = (char *(*)()) F1125_10145;}
	R4994[600] = (char *(*)()) F1125_10145;
	R4994[610] = (char *(*)()) F1125_10145;
}

char *(*R4996[611])();
void R4996_init () {
	R4996[0] = (char *(*)()) F576_5309;
	R4996[2] = (char *(*)()) F578_5369;
	R4996[3] = (char *(*)()) F579_5369;
	R4996[4] = (char *(*)()) F580_5369;
	R4996[5] = (char *(*)()) F581_5369;
	R4996[6] = (char *(*)()) F582_5369;
	R4996[7] = (char *(*)()) F583_5369;
	R4996[8] = (char *(*)()) F584_5369;
	R4996[9] = (char *(*)()) F585_5369;
	R4996[10] = (char *(*)()) F586_5369;
	R4996[11] = (char *(*)()) F587_5369;
	R4996[12] = (char *(*)()) F588_5369;
	R4996[13] = (char *(*)()) F589_5369;
	R4996[63] = (char *(*)()) F591_5441;
	R4996[64] = (char *(*)()) F592_5441;
	R4996[65] = (char *(*)()) F597_5441;
	{long i; for (i = 66; i < 68; i++) R4996[i] = (char *(*)()) F591_5441;}
	R4996[68] = (char *(*)()) F597_5441;
	R4996[69] = (char *(*)()) F592_5441;
	R4996[72] = (char *(*)()) F648_5630;
	R4996[73] = (char *(*)()) F649_5630;
	R4996[74] = (char *(*)()) F650_5630;
	R4996[75] = (char *(*)()) F651_5630;
	R4996[76] = (char *(*)()) F652_5630;
	R4996[77] = (char *(*)()) F653_5630;
	R4996[78] = (char *(*)()) F648_5630;
	R4996[79] = (char *(*)()) F649_5630;
	R4996[80] = (char *(*)()) F648_5630;
	R4996[81] = (char *(*)()) F657_5750;
	R4996[82] = (char *(*)()) F658_5750;
	R4996[83] = (char *(*)()) F659_5750;
	R4996[84] = (char *(*)()) F660_5750;
	R4996[85] = (char *(*)()) F661_5750;
	R4996[86] = (char *(*)()) F662_5750;
	R4996[87] = (char *(*)()) F663_5750;
	R4996[88] = (char *(*)()) F664_5750;
	R4996[89] = (char *(*)()) F665_5750;
	R4996[90] = (char *(*)()) F666_5750;
	R4996[91] = (char *(*)()) F667_5750;
	R4996[92] = (char *(*)()) F668_5750;
	R4996[93] = (char *(*)()) F657_5750;
	R4996[94] = (char *(*)()) F658_5750;
	R4996[95] = (char *(*)()) F663_5750;
	R4996[100] = (char *(*)()) F657_5750;
	R4996[101] = (char *(*)()) F658_5750;
	{long i; for (i = 102; i < 106; i++) R4996[i] = (char *(*)()) F657_5750;}
	R4996[110] = (char *(*)()) F657_5750;
	R4996[112] = (char *(*)()) F657_5750;
	R4996[114] = (char *(*)()) F657_5750;
	R4996[118] = (char *(*)()) F657_5750;
	{long i; for (i = 120; i < 124; i++) R4996[i] = (char *(*)()) F657_5750;}
	R4996[259] = (char *(*)()) F835_6421;
	R4996[260] = (char *(*)()) F836_6421;
	R4996[261] = (char *(*)()) F837_6421;
	R4996[262] = (char *(*)()) F838_6421;
	R4996[263] = (char *(*)()) F839_6421;
	R4996[264] = (char *(*)()) F840_6421;
	R4996[265] = (char *(*)()) F841_6421;
	R4996[266] = (char *(*)()) F842_6421;
	R4996[267] = (char *(*)()) F843_6421;
	R4996[268] = (char *(*)()) F844_6421;
	R4996[269] = (char *(*)()) F845_6421;
	R4996[270] = (char *(*)()) F846_6421;
	R4996[391] = (char *(*)()) F967_7783;
	{long i; for (i = 474; i < 476; i++) R4996[i] = (char *(*)()) F1046_9001;}
	{long i; for (i = 477; i < 479; i++) R4996[i] = (char *(*)()) F1046_9001;}
	{long i; for (i = 557; i < 560; i++) R4996[i] = (char *(*)()) F591_5441;}
	R4996[600] = (char *(*)()) F591_5441;
	R4996[610] = (char *(*)()) F591_5441;
}

char *(*R5023[12])();
void R5023_init () {
	R5023[0] = (char *(*)()) F578_5352;
	R5023[1] = (char *(*)()) F579_5352;
	R5023[2] = (char *(*)()) F580_5352;
	R5023[3] = (char *(*)()) F581_5352;
	R5023[4] = (char *(*)()) F582_5352;
	R5023[5] = (char *(*)()) F583_5352;
	R5023[6] = (char *(*)()) F584_5352;
	R5023[7] = (char *(*)()) F585_5352;
	R5023[8] = (char *(*)()) F586_5352;
	R5023[9] = (char *(*)()) F587_5352;
	R5023[10] = (char *(*)()) F588_5352;
	R5023[11] = (char *(*)()) F589_5352;
}

char *(*R5047[12])();
void R5047_init () {
	R5047[0] = (char *(*)()) F578_5394;
	R5047[1] = (char *(*)()) F579_5394_5047_268;
	R5047[2] = (char *(*)()) F580_5394_5047_268;
	R5047[3] = (char *(*)()) F581_5394_5047_268;
	R5047[4] = (char *(*)()) F582_5394_5047_268;
	R5047[5] = (char *(*)()) F583_5394_5047_268;
	R5047[6] = (char *(*)()) F584_5394_5047_268;
	R5047[7] = (char *(*)()) F585_5394_5047_268;
	R5047[8] = (char *(*)()) F586_5394_5047_268;
	R5047[9] = (char *(*)()) F587_5394_5047_268;
	R5047[10] = (char *(*)()) F588_5394_5047_268;
	R5047[11] = (char *(*)()) F589_5394_5047_268;
}
static void F579_5394_5047_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F579_5394(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F580_5394_5047_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F580_5394(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F581_5394_5047_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F581_5394(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F582_5394_5047_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F582_5394(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F583_5394_5047_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F583_5394(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F584_5394_5047_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F584_5394(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F585_5394_5047_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F585_5394(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F586_5394_5047_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F586_5394(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F587_5394_5047_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F587_5394(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F588_5394_5047_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F588_5394(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F589_5394_5047_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F589_5394(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R5054[12])();
void R5054_init () {
	R5054[0] = (char *(*)()) F578_5406;
	R5054[1] = (char *(*)()) F579_5406;
	R5054[2] = (char *(*)()) F580_5406;
	R5054[3] = (char *(*)()) F581_5406;
	R5054[4] = (char *(*)()) F582_5406;
	R5054[5] = (char *(*)()) F583_5406;
	R5054[6] = (char *(*)()) F584_5406;
	R5054[7] = (char *(*)()) F585_5406;
	R5054[8] = (char *(*)()) F586_5406;
	R5054[9] = (char *(*)()) F587_5406;
	R5054[10] = (char *(*)()) F588_5406;
	R5054[11] = (char *(*)()) F589_5406;
}

char *(*R5079[548])();
void R5079_init () {
	R5079[0] = (char *(*)()) F639_5482;
	R5079[1] = (char *(*)()) F640_5482_5079_1;
	R5079[2] = (char *(*)()) F641_5482_5079_1;
	{long i; for (i = 3; i < 5; i++) R5079[i] = (char *(*)()) F639_5482;}
	R5079[5] = (char *(*)()) F641_5482_5079_1;
	R5079[6] = (char *(*)()) F640_5482_5079_1;
	R5079[18] = (char *(*)()) F657_5731;
	R5079[19] = (char *(*)()) F658_5731_5079_1;
	R5079[20] = (char *(*)()) F659_5731_5079_1;
	R5079[21] = (char *(*)()) F660_5731_5079_1;
	R5079[22] = (char *(*)()) F661_5731_5079_1;
	R5079[23] = (char *(*)()) F662_5731_5079_1;
	R5079[24] = (char *(*)()) F663_5731_5079_1;
	R5079[25] = (char *(*)()) F664_5731_5079_1;
	R5079[26] = (char *(*)()) F665_5731_5079_1;
	R5079[27] = (char *(*)()) F666_5731_5079_1;
	R5079[28] = (char *(*)()) F667_5731_5079_1;
	R5079[29] = (char *(*)()) F668_5731_5079_1;
	R5079[30] = (char *(*)()) F657_5731;
	R5079[31] = (char *(*)()) F658_5731_5079_1;
	R5079[32] = (char *(*)()) F663_5731_5079_1;
	R5079[37] = (char *(*)()) F657_5731;
	R5079[38] = (char *(*)()) F658_5731_5079_1;
	{long i; for (i = 39; i < 43; i++) R5079[i] = (char *(*)()) F657_5731;}
	R5079[47] = (char *(*)()) F657_5731;
	R5079[49] = (char *(*)()) F657_5731;
	R5079[51] = (char *(*)()) F657_5731;
	R5079[55] = (char *(*)()) F657_5731;
	{long i; for (i = 57; i < 61; i++) R5079[i] = (char *(*)()) F657_5731;}
	{long i; for (i = 494; i < 497; i++) R5079[i] = (char *(*)()) F591_5429;}
	R5079[537] = (char *(*)()) F591_5429;
	R5079[547] = (char *(*)()) F591_5429;
}
static EIF_REFERENCE F640_5482_5079_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F640_5482(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F641_5482_5079_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F641_5482(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F658_5731_5079_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F658_5731(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F659_5731_5079_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F659_5731(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(999, 0x00).id, 999, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F660_5731_5079_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F660_5731(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(993, 0x00).id, 993, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F661_5731_5079_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F661_5731(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F662_5731_5079_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F662_5731(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F663_5731_5079_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F663_5731(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_5731_5079_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F664_5731(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F665_5731_5079_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F665_5731(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_5731_5079_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F666_5731(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_5731_5079_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F667_5731(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_5731_5079_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F668_5731(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R5080[548])();
void R5080_init () {
	R5080[0] = (char *(*)()) F639_5483;
	R5080[1] = (char *(*)()) F640_5483_5080_1;
	R5080[2] = (char *(*)()) F641_5483_5080_1;
	{long i; for (i = 3; i < 5; i++) R5080[i] = (char *(*)()) F639_5483;}
	R5080[5] = (char *(*)()) F641_5483_5080_1;
	R5080[6] = (char *(*)()) F640_5483_5080_1;
	R5080[18] = (char *(*)()) F657_5732;
	R5080[19] = (char *(*)()) F658_5732_5080_1;
	R5080[20] = (char *(*)()) F659_5732_5080_1;
	R5080[21] = (char *(*)()) F660_5732_5080_1;
	R5080[22] = (char *(*)()) F661_5732_5080_1;
	R5080[23] = (char *(*)()) F662_5732_5080_1;
	R5080[24] = (char *(*)()) F663_5732_5080_1;
	R5080[25] = (char *(*)()) F664_5732_5080_1;
	R5080[26] = (char *(*)()) F665_5732_5080_1;
	R5080[27] = (char *(*)()) F666_5732_5080_1;
	R5080[28] = (char *(*)()) F667_5732_5080_1;
	R5080[29] = (char *(*)()) F668_5732_5080_1;
	R5080[30] = (char *(*)()) F657_5732;
	R5080[31] = (char *(*)()) F658_5732_5080_1;
	R5080[32] = (char *(*)()) F663_5732_5080_1;
	R5080[37] = (char *(*)()) F657_5732;
	R5080[38] = (char *(*)()) F658_5732_5080_1;
	{long i; for (i = 39; i < 43; i++) R5080[i] = (char *(*)()) F657_5732;}
	R5080[47] = (char *(*)()) F657_5732;
	R5080[49] = (char *(*)()) F657_5732;
	R5080[51] = (char *(*)()) F657_5732;
	R5080[55] = (char *(*)()) F657_5732;
	{long i; for (i = 57; i < 61; i++) R5080[i] = (char *(*)()) F657_5732;}
	{long i; for (i = 494; i < 497; i++) R5080[i] = (char *(*)()) F591_5430;}
	R5080[537] = (char *(*)()) F591_5430;
	R5080[547] = (char *(*)()) F591_5430;
}
static EIF_REFERENCE F640_5483_5080_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F640_5483(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F641_5483_5080_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F641_5483(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F658_5732_5080_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F658_5732(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F659_5732_5080_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F659_5732(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(999, 0x00).id, 999, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F660_5732_5080_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F660_5732(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(993, 0x00).id, 993, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F661_5732_5080_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F661_5732(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F662_5732_5080_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F662_5732(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F663_5732_5080_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F663_5732(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F664_5732_5080_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F664_5732(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F665_5732_5080_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F665_5732(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F666_5732_5080_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F666_5732(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F667_5732_5080_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F667_5732(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F668_5732_5080_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F668_5732(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R5081[7])();
void R5081_init () {
	R5081[0] = (char *(*)()) F639_5502;
	R5081[1] = (char *(*)()) F640_5502;
	R5081[2] = (char *(*)()) F641_5502;
	{long i; for (i = 3; i < 5; i++) R5081[i] = (char *(*)()) F639_5502;}
	R5081[5] = (char *(*)()) F641_5502;
	R5081[6] = (char *(*)()) F640_5502;
}

char *(*R5082[548])();
void R5082_init () {
	R5082[0] = (char *(*)()) F639_5503;
	R5082[1] = (char *(*)()) F640_5503;
	R5082[2] = (char *(*)()) F641_5503;
	{long i; for (i = 3; i < 5; i++) R5082[i] = (char *(*)()) F639_5503;}
	R5082[5] = (char *(*)()) F641_5503;
	R5082[6] = (char *(*)()) F640_5503;
	R5082[18] = (char *(*)()) F657_5758;
	R5082[19] = (char *(*)()) F658_5758;
	R5082[20] = (char *(*)()) F659_5758;
	R5082[21] = (char *(*)()) F660_5758;
	R5082[22] = (char *(*)()) F661_5758;
	R5082[23] = (char *(*)()) F662_5758;
	R5082[24] = (char *(*)()) F663_5758;
	R5082[25] = (char *(*)()) F664_5758;
	R5082[26] = (char *(*)()) F665_5758;
	R5082[27] = (char *(*)()) F666_5758;
	R5082[28] = (char *(*)()) F667_5758;
	R5082[29] = (char *(*)()) F668_5758;
	R5082[30] = (char *(*)()) F657_5758;
	R5082[31] = (char *(*)()) F658_5758;
	R5082[32] = (char *(*)()) F663_5758;
	R5082[37] = (char *(*)()) F657_5758;
	R5082[38] = (char *(*)()) F658_5758;
	{long i; for (i = 39; i < 43; i++) R5082[i] = (char *(*)()) F657_5758;}
	R5082[47] = (char *(*)()) F657_5758;
	R5082[49] = (char *(*)()) F657_5758;
	R5082[51] = (char *(*)()) F657_5758;
	R5082[55] = (char *(*)()) F657_5758;
	{long i; for (i = 57; i < 61; i++) R5082[i] = (char *(*)()) F657_5758;}
	{long i; for (i = 494; i < 497; i++) R5082[i] = (char *(*)()) F1125_10151;}
	R5082[537] = (char *(*)()) F1125_10151;
	R5082[547] = (char *(*)()) F1125_10151;
}

char *(*R5083[548])();
void R5083_init () {
	R5083[0] = (char *(*)()) F639_5493;
	R5083[1] = (char *(*)()) F640_5493;
	R5083[2] = (char *(*)()) F641_5493;
	{long i; for (i = 3; i < 5; i++) R5083[i] = (char *(*)()) F639_5493;}
	R5083[5] = (char *(*)()) F641_5493;
	R5083[6] = (char *(*)()) F640_5493;
	R5083[18] = (char *(*)()) F591_5442;
	R5083[19] = (char *(*)()) F592_5442;
	R5083[20] = (char *(*)()) F593_5442;
	R5083[21] = (char *(*)()) F594_5442;
	R5083[22] = (char *(*)()) F595_5442;
	R5083[23] = (char *(*)()) F596_5442;
	R5083[24] = (char *(*)()) F597_5442;
	R5083[25] = (char *(*)()) F598_5442;
	R5083[26] = (char *(*)()) F599_5442;
	R5083[27] = (char *(*)()) F600_5442;
	R5083[28] = (char *(*)()) F601_5442;
	R5083[29] = (char *(*)()) F602_5442;
	R5083[30] = (char *(*)()) F591_5442;
	R5083[31] = (char *(*)()) F592_5442;
	R5083[32] = (char *(*)()) F597_5442;
	R5083[37] = (char *(*)()) F591_5442;
	R5083[38] = (char *(*)()) F592_5442;
	{long i; for (i = 39; i < 43; i++) R5083[i] = (char *(*)()) F591_5442;}
	R5083[47] = (char *(*)()) F591_5442;
	R5083[49] = (char *(*)()) F591_5442;
	R5083[51] = (char *(*)()) F591_5442;
	R5083[55] = (char *(*)()) F591_5442;
	{long i; for (i = 57; i < 61; i++) R5083[i] = (char *(*)()) F591_5442;}
	{long i; for (i = 494; i < 497; i++) R5083[i] = (char *(*)()) F591_5442;}
	R5083[537] = (char *(*)()) F591_5442;
	R5083[547] = (char *(*)()) F591_5442;
}


#ifdef __cplusplus
}
#endif
