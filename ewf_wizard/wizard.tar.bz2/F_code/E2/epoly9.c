#include "epoly9.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R5084[7])();
void R5084_init () {
	R5084[0] = (char *(*)()) F639_5494;
	R5084[1] = (char *(*)()) F640_5494;
	R5084[2] = (char *(*)()) F641_5494;
	{long i; for (i = 3; i < 5; i++) R5084[i] = (char *(*)()) F639_5494;}
	R5084[5] = (char *(*)()) F641_5494;
	R5084[6] = (char *(*)()) F640_5494;
}

char *(*R5089[7])();
void R5089_init () {
	R5089[0] = (char *(*)()) F639_5505;
	R5089[1] = (char *(*)()) F640_5505_5089_4;
	R5089[2] = (char *(*)()) F641_5505_5089_4;
	{long i; for (i = 3; i < 5; i++) R5089[i] = (char *(*)()) F639_5505;}
	R5089[5] = (char *(*)()) F641_5505_5089_4;
	R5089[6] = (char *(*)()) F640_5505_5089_4;
}
static void F640_5505_5089_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F640_5505(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F641_5505_5089_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F641_5505(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R5090[43])();
void R5090_init () {
	R5090[0] = (char *(*)()) F657_5765;
	R5090[1] = (char *(*)()) F658_5765_5090_4;
	R5090[2] = (char *(*)()) F659_5765_5090_4;
	R5090[3] = (char *(*)()) F660_5765_5090_4;
	R5090[4] = (char *(*)()) F661_5765_5090_4;
	R5090[5] = (char *(*)()) F662_5765_5090_4;
	R5090[6] = (char *(*)()) F663_5765_5090_4;
	R5090[7] = (char *(*)()) F664_5765_5090_4;
	R5090[8] = (char *(*)()) F665_5765_5090_4;
	R5090[9] = (char *(*)()) F666_5765_5090_4;
	R5090[10] = (char *(*)()) F667_5765_5090_4;
	R5090[11] = (char *(*)()) F668_5765_5090_4;
	R5090[12] = (char *(*)()) F657_5765;
	R5090[13] = (char *(*)()) F658_5765_5090_4;
	R5090[14] = (char *(*)()) F663_5765_5090_4;
	R5090[19] = (char *(*)()) F672_5808;
	R5090[20] = (char *(*)()) F673_5808_5090_4;
	{long i; for (i = 21; i < 25; i++) R5090[i] = (char *(*)()) F672_5808;}
	R5090[29] = (char *(*)()) F672_5808;
	R5090[31] = (char *(*)()) F672_5808;
	R5090[33] = (char *(*)()) F672_5808;
	R5090[37] = (char *(*)()) F672_5808;
	{long i; for (i = 39; i < 43; i++) R5090[i] = (char *(*)()) F672_5808;}
}
static void F658_5765_5090_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F658_5765(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F659_5765_5090_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F659_5765(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F660_5765_5090_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F660_5765(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F661_5765_5090_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F661_5765(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F662_5765_5090_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F662_5765(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F663_5765_5090_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F663_5765(Current, *(EIF_BOOLEAN *)arg1);
}
static void F664_5765_5090_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F664_5765(Current, *(EIF_POINTER *)arg1);
}
static void F665_5765_5090_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F665_5765(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F666_5765_5090_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F666_5765(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F667_5765_5090_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F667_5765(Current, *(EIF_REAL_32 *)arg1);
}
static void F668_5765_5090_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F668_5765(Current, *(EIF_REAL_64 *)arg1);
}
static void F673_5808_5090_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F673_5808(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5095[7])();
void R5095_init () {
	R5095[0] = (char *(*)()) F639_5514;
	R5095[1] = (char *(*)()) F640_5514;
	R5095[2] = (char *(*)()) F641_5514;
	{long i; for (i = 3; i < 5; i++) R5095[i] = (char *(*)()) F639_5514;}
	R5095[5] = (char *(*)()) F641_5514;
	R5095[6] = (char *(*)()) F640_5514;
}

char *(*R5100[7])();
void R5100_init () {
	R5100[0] = (char *(*)()) F639_5518;
	R5100[1] = (char *(*)()) F640_5518_5100_5;
	R5100[2] = (char *(*)()) F641_5518_5100_5;
	{long i; for (i = 3; i < 5; i++) R5100[i] = (char *(*)()) F639_5518;}
	R5100[5] = (char *(*)()) F641_5518_5100_5;
	R5100[6] = (char *(*)()) F640_5518_5100_5;
}
static EIF_REFERENCE F640_5518_5100_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F640_5518(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F641_5518_5100_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F641_5518(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R5101[7])();
void R5101_init () {
	R5101[0] = (char *(*)()) F639_5519;
	R5101[1] = (char *(*)()) F640_5519;
	R5101[2] = (char *(*)()) F641_5519;
	{long i; for (i = 3; i < 5; i++) R5101[i] = (char *(*)()) F639_5519;}
	R5101[5] = (char *(*)()) F641_5519;
	R5101[6] = (char *(*)()) F640_5519;
}

char *(*R5104[7])();
void R5104_init () {
	R5104[0] = (char *(*)()) F639_5522;
	R5104[1] = (char *(*)()) F640_5522;
	R5104[2] = (char *(*)()) F641_5522;
	{long i; for (i = 3; i < 5; i++) R5104[i] = (char *(*)()) F639_5522;}
	R5104[5] = (char *(*)()) F641_5522;
	R5104[6] = (char *(*)()) F640_5522;
}

char *(*R5105[7])();
void R5105_init () {
	R5105[0] = (char *(*)()) F639_5523;
	R5105[1] = (char *(*)()) F640_5523;
	R5105[2] = (char *(*)()) F641_5523;
	{long i; for (i = 3; i < 5; i++) R5105[i] = (char *(*)()) F639_5523;}
	R5105[5] = (char *(*)()) F641_5523;
	R5105[6] = (char *(*)()) F640_5523;
}

char *(*R5106[7])();
void R5106_init () {
	R5106[0] = (char *(*)()) F639_5524;
	R5106[1] = (char *(*)()) F640_5524;
	R5106[2] = (char *(*)()) F641_5524;
	{long i; for (i = 3; i < 5; i++) R5106[i] = (char *(*)()) F639_5524;}
	R5106[5] = (char *(*)()) F641_5524;
	R5106[6] = (char *(*)()) F640_5524;
}

char *(*R5116[3])();
void R5116_init () {
	R5116[0] = (char *(*)()) F639_5481;
	R5116[1] = (char *(*)()) F641_5481_5116_1;
	R5116[2] = (char *(*)()) F640_5481_5116_1;
}
static EIF_REFERENCE F641_5481_5116_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F641_5481(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F640_5481_5116_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F640_5481(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5117[3])();
void R5117_init () {
	R5117[0] = (char *(*)()) F639_5512;
	R5117[1] = (char *(*)()) F641_5512;
	R5117[2] = (char *(*)()) F640_5512;
}

char *(*R5118[407])();
void R5118_init () {
	R5118[0] = (char *(*)()) F648_5651;
	R5118[1] = (char *(*)()) F649_5651;
	R5118[2] = (char *(*)()) F650_5651;
	R5118[3] = (char *(*)()) F651_5651;
	R5118[4] = (char *(*)()) F652_5651;
	R5118[5] = (char *(*)()) F653_5651;
	R5118[6] = (char *(*)()) F648_5651;
	R5118[7] = (char *(*)()) F649_5651;
	R5118[8] = (char *(*)()) F648_5651;
	R5118[9] = (char *(*)()) F657_5784;
	R5118[10] = (char *(*)()) F658_5784;
	R5118[11] = (char *(*)()) F659_5784;
	R5118[12] = (char *(*)()) F660_5784;
	R5118[13] = (char *(*)()) F661_5784;
	R5118[14] = (char *(*)()) F662_5784;
	R5118[15] = (char *(*)()) F663_5784;
	R5118[16] = (char *(*)()) F664_5784;
	R5118[17] = (char *(*)()) F665_5784;
	R5118[18] = (char *(*)()) F666_5784;
	R5118[19] = (char *(*)()) F667_5784;
	R5118[20] = (char *(*)()) F668_5784;
	R5118[21] = (char *(*)()) F657_5784;
	R5118[22] = (char *(*)()) F658_5784;
	R5118[23] = (char *(*)()) F663_5784;
	R5118[28] = (char *(*)()) F657_5784;
	R5118[29] = (char *(*)()) F658_5784;
	{long i; for (i = 30; i < 34; i++) R5118[i] = (char *(*)()) F657_5784;}
	R5118[38] = (char *(*)()) F657_5784;
	R5118[40] = (char *(*)()) F657_5784;
	R5118[42] = (char *(*)()) F657_5784;
	R5118[46] = (char *(*)()) F657_5784;
	{long i; for (i = 48; i < 52; i++) R5118[i] = (char *(*)()) F657_5784;}
	R5118[319] = (char *(*)()) F967_7864;
	{long i; for (i = 393; i < 398; i++) R5118[i] = (char *(*)()) F1040_8955;}
	R5118[402] = (char *(*)()) F1050_9194;
	R5118[403] = (char *(*)()) F1051_9285;
	R5118[406] = (char *(*)()) F1054_9449;
}

char *(*R5130[9])();
void R5130_init () {
	R5130[0] = (char *(*)()) F648_5592;
	R5130[1] = (char *(*)()) F649_5592;
	R5130[2] = (char *(*)()) F650_5592;
	R5130[3] = (char *(*)()) F651_5592;
	R5130[4] = (char *(*)()) F652_5592;
	R5130[5] = (char *(*)()) F653_5592;
	R5130[6] = (char *(*)()) F648_5592;
	R5130[7] = (char *(*)()) F649_5592;
	R5130[8] = (char *(*)()) F648_5592;
}

char *(*R5133[9])();
void R5133_init () {
	R5133[0] = (char *(*)()) F648_5595;
	R5133[1] = (char *(*)()) F649_5595;
	R5133[2] = (char *(*)()) F650_5595;
	R5133[3] = (char *(*)()) F651_5595;
	R5133[4] = (char *(*)()) F652_5595;
	R5133[5] = (char *(*)()) F653_5595;
	R5133[6] = (char *(*)()) F648_5595;
	R5133[7] = (char *(*)()) F649_5595;
	R5133[8] = (char *(*)()) F648_5595;
}

char *(*R5134[9])();
void R5134_init () {
	R5134[0] = (char *(*)()) F648_5596;
	R5134[1] = (char *(*)()) F649_5596_5134_1;
	R5134[2] = (char *(*)()) F650_5596;
	R5134[3] = (char *(*)()) F651_5596_5134_1;
	R5134[4] = (char *(*)()) F652_5596_5134_1;
	R5134[5] = (char *(*)()) F653_5596_5134_1;
	R5134[6] = (char *(*)()) F648_5596;
	R5134[7] = (char *(*)()) F649_5596_5134_1;
	R5134[8] = (char *(*)()) F648_5596;
}
static EIF_REFERENCE F649_5596_5134_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F649_5596(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F651_5596_5134_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F651_5596(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F652_5596_5134_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F652_5596(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F653_5596_5134_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F653_5596(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R5135[9])();
void R5135_init () {
	R5135[0] = (char *(*)()) F648_5598;
	R5135[1] = (char *(*)()) F649_5598_5135_5;
	R5135[2] = (char *(*)()) F650_5598_5135_5;
	R5135[3] = (char *(*)()) F651_5598_5135_5;
	R5135[4] = (char *(*)()) F652_5598_5135_5;
	R5135[5] = (char *(*)()) F653_5598_5135_5;
	R5135[6] = (char *(*)()) F648_5598;
	R5135[7] = (char *(*)()) F649_5598_5135_5;
	R5135[8] = (char *(*)()) F648_5598;
}
static EIF_REFERENCE F649_5598_5135_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F649_5598(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F650_5598_5135_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F650_5598(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F651_5598_5135_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F651_5598(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F652_5598_5135_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F652_5598(Current, *(EIF_NATURAL_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F653_5598_5135_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F653_5598(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R5137[9])();
void R5137_init () {
	R5137[0] = (char *(*)()) F648_5601;
	R5137[1] = (char *(*)()) F649_5601;
	R5137[2] = (char *(*)()) F650_5601_5137_2;
	R5137[3] = (char *(*)()) F651_5601_5137_2;
	R5137[4] = (char *(*)()) F652_5601_5137_2;
	R5137[5] = (char *(*)()) F653_5601;
	R5137[6] = (char *(*)()) F648_5601;
	R5137[7] = (char *(*)()) F649_5601;
	R5137[8] = (char *(*)()) F648_5601;
}
static EIF_BOOLEAN F650_5601_5137_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F650_5601(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F651_5601_5137_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F651_5601(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F652_5601_5137_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F652_5601(Current, *(EIF_NATURAL_32 *)arg1);
}

char *(*R5139[9])();
void R5139_init () {
	R5139[0] = (char *(*)()) F648_5604;
	R5139[1] = (char *(*)()) F649_5604_5139_1;
	R5139[2] = (char *(*)()) F650_5604;
	R5139[3] = (char *(*)()) F651_5604_5139_1;
	R5139[4] = (char *(*)()) F652_5604_5139_1;
	R5139[5] = (char *(*)()) F653_5604_5139_1;
	R5139[6] = (char *(*)()) F648_5604;
	R5139[7] = (char *(*)()) F649_5604_5139_1;
	R5139[8] = (char *(*)()) F648_5604;
}
static EIF_REFERENCE F649_5604_5139_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F649_5604(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F651_5604_5139_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F651_5604(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F652_5604_5139_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F652_5604(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F653_5604_5139_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F653_5604(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R5140[9])();
void R5140_init () {
	R5140[0] = (char *(*)()) F648_5605;
	R5140[1] = (char *(*)()) F649_5605;
	R5140[2] = (char *(*)()) F650_5605_5140_1;
	R5140[3] = (char *(*)()) F651_5605_5140_1;
	R5140[4] = (char *(*)()) F652_5605_5140_1;
	R5140[5] = (char *(*)()) F653_5605;
	R5140[6] = (char *(*)()) F648_5605;
	R5140[7] = (char *(*)()) F649_5605;
	R5140[8] = (char *(*)()) F648_5605;
}
static EIF_REFERENCE F650_5605_5140_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F650_5605(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F651_5605_5140_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F651_5605(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F652_5605_5140_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F652_5605(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}

char *(*R5142[9])();
void R5142_init () {
	R5142[0] = (char *(*)()) F648_5609;
	R5142[1] = (char *(*)()) F649_5609;
	R5142[2] = (char *(*)()) F650_5609_5142_73;
	R5142[3] = (char *(*)()) F651_5609_5142_73;
	R5142[4] = (char *(*)()) F652_5609_5142_73;
	R5142[5] = (char *(*)()) F653_5609;
	R5142[6] = (char *(*)()) F654_5706;
	R5142[7] = (char *(*)()) F655_5706;
	R5142[8] = (char *(*)()) F648_5609;
}
static EIF_INTEGER_32 F650_5609_5142_73 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F650_5609(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F651_5609_5142_73 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F651_5609(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F652_5609_5142_73 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F652_5609(Current, *(EIF_NATURAL_32 *)arg1);
}

char *(*R5144[9])();
void R5144_init () {
	R5144[0] = (char *(*)()) F648_5616;
	R5144[1] = (char *(*)()) F649_5616;
	R5144[2] = (char *(*)()) F650_5616_5144_3;
	R5144[3] = (char *(*)()) F651_5616_5144_3;
	R5144[4] = (char *(*)()) F652_5616_5144_3;
	R5144[5] = (char *(*)()) F653_5616;
	R5144[6] = (char *(*)()) F654_5708;
	R5144[7] = (char *(*)()) F655_5708;
	R5144[8] = (char *(*)()) F648_5616;
}
static EIF_BOOLEAN F650_5616_5144_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F650_5616(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F651_5616_5144_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F651_5616(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F652_5616_5144_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F652_5616(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_NATURAL_32 *)arg2);
}

char *(*R5150[9])();
void R5150_init () {
	R5150[0] = (char *(*)()) F648_5624;
	R5150[1] = (char *(*)()) F649_5624;
	R5150[2] = (char *(*)()) F650_5624;
	R5150[3] = (char *(*)()) F651_5624;
	R5150[4] = (char *(*)()) F652_5624;
	R5150[5] = (char *(*)()) F653_5624;
	R5150[6] = (char *(*)()) F648_5624;
	R5150[7] = (char *(*)()) F649_5624;
	R5150[8] = (char *(*)()) F648_5624;
}

char *(*R5151[9])();
void R5151_init () {
	R5151[0] = (char *(*)()) F648_5625;
	R5151[1] = (char *(*)()) F649_5625;
	R5151[2] = (char *(*)()) F650_5625;
	R5151[3] = (char *(*)()) F651_5625;
	R5151[4] = (char *(*)()) F652_5625;
	R5151[5] = (char *(*)()) F653_5625;
	R5151[6] = (char *(*)()) F648_5625;
	R5151[7] = (char *(*)()) F649_5625;
	R5151[8] = (char *(*)()) F648_5625;
}

char *(*R5152[9])();
void R5152_init () {
	R5152[0] = (char *(*)()) F648_5626;
	R5152[1] = (char *(*)()) F649_5626;
	R5152[2] = (char *(*)()) F650_5626;
	R5152[3] = (char *(*)()) F651_5626;
	R5152[4] = (char *(*)()) F652_5626;
	R5152[5] = (char *(*)()) F653_5626;
	R5152[6] = (char *(*)()) F648_5626;
	R5152[7] = (char *(*)()) F649_5626;
	R5152[8] = (char *(*)()) F648_5626;
}

char *(*R5153[9])();
void R5153_init () {
	R5153[0] = (char *(*)()) F648_5627;
	R5153[1] = (char *(*)()) F649_5627;
	R5153[2] = (char *(*)()) F650_5627;
	R5153[3] = (char *(*)()) F651_5627;
	R5153[4] = (char *(*)()) F652_5627;
	R5153[5] = (char *(*)()) F653_5627;
	R5153[6] = (char *(*)()) F648_5627;
	R5153[7] = (char *(*)()) F649_5627;
	R5153[8] = (char *(*)()) F648_5627;
}

char *(*R5156[9])();
void R5156_init () {
	R5156[0] = (char *(*)()) F648_5631;
	R5156[1] = (char *(*)()) F649_5631;
	R5156[2] = (char *(*)()) F650_5631;
	R5156[3] = (char *(*)()) F651_5631;
	R5156[4] = (char *(*)()) F652_5631;
	R5156[5] = (char *(*)()) F653_5631;
	R5156[6] = (char *(*)()) F648_5631;
	R5156[7] = (char *(*)()) F649_5631;
	R5156[8] = (char *(*)()) F648_5631;
}

char *(*R5157[9])();
void R5157_init () {
	R5157[0] = (char *(*)()) F648_5632;
	R5157[1] = (char *(*)()) F649_5632;
	R5157[2] = (char *(*)()) F650_5632;
	R5157[3] = (char *(*)()) F651_5632;
	R5157[4] = (char *(*)()) F652_5632;
	R5157[5] = (char *(*)()) F653_5632;
	R5157[6] = (char *(*)()) F648_5632;
	R5157[7] = (char *(*)()) F649_5632;
	R5157[8] = (char *(*)()) F648_5632;
}

char *(*R5159[9])();
void R5159_init () {
	R5159[0] = (char *(*)()) F648_5634;
	R5159[1] = (char *(*)()) F649_5634;
	R5159[2] = (char *(*)()) F650_5634_5159_4;
	R5159[3] = (char *(*)()) F651_5634_5159_4;
	R5159[4] = (char *(*)()) F652_5634_5159_4;
	R5159[5] = (char *(*)()) F653_5634;
	R5159[6] = (char *(*)()) F648_5634;
	R5159[7] = (char *(*)()) F649_5634;
	R5159[8] = (char *(*)()) F648_5634;
}
static void F650_5634_5159_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F650_5634(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F651_5634_5159_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F651_5634(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F652_5634_5159_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F652_5634(Current, *(EIF_NATURAL_32 *)arg1);
}

char *(*R5161[9])();
void R5161_init () {
	R5161[0] = (char *(*)()) F648_5636;
	R5161[1] = (char *(*)()) F649_5636;
	R5161[2] = (char *(*)()) F650_5636;
	R5161[3] = (char *(*)()) F651_5636;
	R5161[4] = (char *(*)()) F652_5636;
	R5161[5] = (char *(*)()) F653_5636;
	R5161[6] = (char *(*)()) F648_5636;
	R5161[7] = (char *(*)()) F649_5636;
	R5161[8] = (char *(*)()) F648_5636;
}

char *(*R5162[9])();
void R5162_init () {
	R5162[0] = (char *(*)()) F648_5637;
	R5162[1] = (char *(*)()) F649_5637;
	R5162[2] = (char *(*)()) F650_5637;
	R5162[3] = (char *(*)()) F651_5637;
	R5162[4] = (char *(*)()) F652_5637;
	R5162[5] = (char *(*)()) F653_5637;
	R5162[6] = (char *(*)()) F648_5637;
	R5162[7] = (char *(*)()) F649_5637;
	R5162[8] = (char *(*)()) F648_5637;
}

char *(*R5168[9])();
void R5168_init () {
	R5168[0] = (char *(*)()) F648_5650;
	R5168[1] = (char *(*)()) F649_5650;
	R5168[2] = (char *(*)()) F650_5650;
	R5168[3] = (char *(*)()) F651_5650;
	R5168[4] = (char *(*)()) F652_5650;
	R5168[5] = (char *(*)()) F653_5650;
	R5168[6] = (char *(*)()) F654_5710;
	R5168[7] = (char *(*)()) F655_5710;
	R5168[8] = (char *(*)()) F648_5650;
}

char *(*R5177[9])();
void R5177_init () {
	R5177[0] = (char *(*)()) F648_5660;
	R5177[1] = (char *(*)()) F649_5660;
	R5177[2] = (char *(*)()) F650_5660;
	R5177[3] = (char *(*)()) F651_5660;
	R5177[4] = (char *(*)()) F652_5660;
	R5177[5] = (char *(*)()) F653_5660;
	R5177[6] = (char *(*)()) F648_5660;
	R5177[7] = (char *(*)()) F649_5660;
	R5177[8] = (char *(*)()) F648_5660;
}

char *(*R5178[9])();
void R5178_init () {
	R5178[0] = (char *(*)()) F648_5661;
	R5178[1] = (char *(*)()) F649_5661;
	R5178[2] = (char *(*)()) F650_5661;
	R5178[3] = (char *(*)()) F651_5661;
	R5178[4] = (char *(*)()) F652_5661;
	R5178[5] = (char *(*)()) F653_5661;
	R5178[6] = (char *(*)()) F648_5661;
	R5178[7] = (char *(*)()) F649_5661;
	R5178[8] = (char *(*)()) F648_5661;
}

char *(*R5185[9])();
void R5185_init () {
	R5185[0] = (char *(*)()) F648_5668;
	R5185[1] = (char *(*)()) F649_5668_5185_1;
	R5185[2] = (char *(*)()) F650_5668;
	R5185[3] = (char *(*)()) F651_5668_5185_1;
	R5185[4] = (char *(*)()) F652_5668_5185_1;
	R5185[5] = (char *(*)()) F653_5668_5185_1;
	R5185[6] = (char *(*)()) F648_5668;
	R5185[7] = (char *(*)()) F649_5668_5185_1;
	R5185[8] = (char *(*)()) F648_5668;
}
static EIF_REFERENCE F649_5668_5185_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F649_5668(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F651_5668_5185_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F651_5668(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F652_5668_5185_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F652_5668(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F653_5668_5185_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F653_5668(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R5186[9])();
void R5186_init () {
	R5186[0] = (char *(*)()) F648_5669;
	R5186[1] = (char *(*)()) F649_5669;
	R5186[2] = (char *(*)()) F650_5669_5186_1;
	R5186[3] = (char *(*)()) F651_5669_5186_1;
	R5186[4] = (char *(*)()) F652_5669_5186_1;
	R5186[5] = (char *(*)()) F653_5669;
	R5186[6] = (char *(*)()) F648_5669;
	R5186[7] = (char *(*)()) F649_5669;
	R5186[8] = (char *(*)()) F648_5669;
}
static EIF_REFERENCE F650_5669_5186_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F650_5669(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F651_5669_5186_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F651_5669(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F652_5669_5186_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F652_5669(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}

char *(*R5187[9])();
void R5187_init () {
	R5187[0] = (char *(*)()) F648_5670;
	R5187[1] = (char *(*)()) F649_5670;
	R5187[2] = (char *(*)()) F650_5670;
	R5187[3] = (char *(*)()) F651_5670;
	R5187[4] = (char *(*)()) F652_5670;
	R5187[5] = (char *(*)()) F653_5670;
	R5187[6] = (char *(*)()) F648_5670;
	R5187[7] = (char *(*)()) F649_5670;
	R5187[8] = (char *(*)()) F648_5670;
}

char *(*R5188[9])();
void R5188_init () {
	R5188[0] = (char *(*)()) F648_5671;
	R5188[1] = (char *(*)()) F649_5671;
	R5188[2] = (char *(*)()) F650_5671;
	R5188[3] = (char *(*)()) F651_5671;
	R5188[4] = (char *(*)()) F652_5671;
	R5188[5] = (char *(*)()) F653_5671;
	R5188[6] = (char *(*)()) F648_5671;
	R5188[7] = (char *(*)()) F649_5671;
	R5188[8] = (char *(*)()) F648_5671;
}

char *(*R5189[9])();
void R5189_init () {
	R5189[0] = (char *(*)()) F648_5672;
	R5189[1] = (char *(*)()) F649_5672;
	R5189[2] = (char *(*)()) F650_5672;
	R5189[3] = (char *(*)()) F651_5672;
	R5189[4] = (char *(*)()) F652_5672;
	R5189[5] = (char *(*)()) F653_5672;
	R5189[6] = (char *(*)()) F648_5672;
	R5189[7] = (char *(*)()) F649_5672;
	R5189[8] = (char *(*)()) F648_5672;
}

char *(*R5190[9])();
void R5190_init () {
	R5190[0] = (char *(*)()) F648_5673;
	R5190[1] = (char *(*)()) F649_5673;
	R5190[2] = (char *(*)()) F650_5673;
	R5190[3] = (char *(*)()) F651_5673;
	R5190[4] = (char *(*)()) F652_5673;
	R5190[5] = (char *(*)()) F653_5673;
	R5190[6] = (char *(*)()) F648_5673;
	R5190[7] = (char *(*)()) F649_5673;
	R5190[8] = (char *(*)()) F648_5673;
}

char *(*R5191[9])();
void R5191_init () {
	R5191[0] = (char *(*)()) F648_5674;
	R5191[1] = (char *(*)()) F649_5674;
	R5191[2] = (char *(*)()) F650_5674;
	R5191[3] = (char *(*)()) F651_5674;
	R5191[4] = (char *(*)()) F652_5674;
	R5191[5] = (char *(*)()) F653_5674;
	R5191[6] = (char *(*)()) F648_5674;
	R5191[7] = (char *(*)()) F649_5674;
	R5191[8] = (char *(*)()) F648_5674;
}

char *(*R5193[9])();
void R5193_init () {
	R5193[0] = (char *(*)()) F648_5676;
	R5193[1] = (char *(*)()) F649_5676;
	R5193[2] = (char *(*)()) F650_5676;
	R5193[3] = (char *(*)()) F651_5676;
	R5193[4] = (char *(*)()) F652_5676;
	R5193[5] = (char *(*)()) F653_5676;
	R5193[6] = (char *(*)()) F648_5676;
	R5193[7] = (char *(*)()) F649_5676;
	R5193[8] = (char *(*)()) F648_5676;
}

char *(*R5194[9])();
void R5194_init () {
	R5194[0] = (char *(*)()) F648_5677;
	R5194[1] = (char *(*)()) F649_5677;
	R5194[2] = (char *(*)()) F650_5677;
	R5194[3] = (char *(*)()) F651_5677;
	R5194[4] = (char *(*)()) F652_5677;
	R5194[5] = (char *(*)()) F653_5677;
	R5194[6] = (char *(*)()) F648_5677;
	R5194[7] = (char *(*)()) F649_5677;
	R5194[8] = (char *(*)()) F648_5677;
}

char *(*R5195[9])();
void R5195_init () {
	R5195[0] = (char *(*)()) F648_5678;
	R5195[1] = (char *(*)()) F649_5678;
	R5195[2] = (char *(*)()) F650_5678;
	R5195[3] = (char *(*)()) F651_5678;
	R5195[4] = (char *(*)()) F652_5678;
	R5195[5] = (char *(*)()) F653_5678;
	R5195[6] = (char *(*)()) F648_5678;
	R5195[7] = (char *(*)()) F649_5678;
	R5195[8] = (char *(*)()) F648_5678;
}

char *(*R5199[9])();
void R5199_init () {
	R5199[0] = (char *(*)()) F648_5682;
	R5199[1] = (char *(*)()) F649_5682;
	R5199[2] = (char *(*)()) F650_5682_5199_4;
	R5199[3] = (char *(*)()) F651_5682_5199_4;
	R5199[4] = (char *(*)()) F652_5682_5199_4;
	R5199[5] = (char *(*)()) F653_5682;
	R5199[6] = (char *(*)()) F648_5682;
	R5199[7] = (char *(*)()) F649_5682;
	R5199[8] = (char *(*)()) F648_5682;
}
static void F650_5682_5199_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F650_5682(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F651_5682_5199_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F651_5682(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F652_5682_5199_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F652_5682(Current, *(EIF_NATURAL_32 *)arg1);
}

char *(*R5205[9])();
void R5205_init () {
	R5205[0] = (char *(*)()) F648_5688;
	R5205[1] = (char *(*)()) F649_5688;
	R5205[2] = (char *(*)()) F650_5688;
	R5205[3] = (char *(*)()) F651_5688;
	R5205[4] = (char *(*)()) F652_5688;
	R5205[5] = (char *(*)()) F653_5688;
	R5205[6] = (char *(*)()) F648_5688;
	R5205[7] = (char *(*)()) F649_5688;
	R5205[8] = (char *(*)()) F648_5688;
}

char *(*R5218[9])();
void R5218_init () {
	R5218[0] = (char *(*)()) F648_5701;
	R5218[1] = (char *(*)()) F649_5701;
	R5218[2] = (char *(*)()) F650_5701;
	R5218[3] = (char *(*)()) F651_5701;
	R5218[4] = (char *(*)()) F652_5701;
	R5218[5] = (char *(*)()) F653_5701;
	R5218[6] = (char *(*)()) F648_5701;
	R5218[7] = (char *(*)()) F649_5701;
	R5218[8] = (char *(*)()) F648_5701;
}

char *(*R5221[2])();
void R5221_init () {
	R5221[0] = (char *(*)()) F654_5704;
	R5221[1] = (char *(*)()) F655_5704;
}

char *(*R5234[43])();
void R5234_init () {
	R5234[0] = (char *(*)()) F657_5723;
	R5234[1] = (char *(*)()) F658_5723;
	R5234[2] = (char *(*)()) F659_5723;
	R5234[3] = (char *(*)()) F660_5723;
	R5234[4] = (char *(*)()) F661_5723;
	R5234[5] = (char *(*)()) F662_5723;
	R5234[6] = (char *(*)()) F663_5723;
	R5234[7] = (char *(*)()) F664_5723;
	R5234[8] = (char *(*)()) F665_5723;
	R5234[9] = (char *(*)()) F666_5723;
	R5234[10] = (char *(*)()) F667_5723;
	R5234[11] = (char *(*)()) F668_5723;
	R5234[12] = (char *(*)()) F657_5723;
	R5234[13] = (char *(*)()) F658_5723;
	R5234[14] = (char *(*)()) F663_5723;
	R5234[19] = (char *(*)()) F657_5723;
	R5234[20] = (char *(*)()) F658_5723;
	{long i; for (i = 21; i < 25; i++) R5234[i] = (char *(*)()) F657_5723;}
	R5234[29] = (char *(*)()) F657_5723;
	R5234[31] = (char *(*)()) F657_5723;
	R5234[33] = (char *(*)()) F657_5723;
	R5234[37] = (char *(*)()) F657_5723;
	{long i; for (i = 39; i < 43; i++) R5234[i] = (char *(*)()) F657_5723;}
}

char *(*R5238[43])();
void R5238_init () {
	R5238[0] = (char *(*)()) F657_5727;
	R5238[1] = (char *(*)()) F658_5727;
	R5238[2] = (char *(*)()) F659_5727;
	R5238[3] = (char *(*)()) F660_5727;
	R5238[4] = (char *(*)()) F661_5727;
	R5238[5] = (char *(*)()) F662_5727;
	R5238[6] = (char *(*)()) F663_5727;
	R5238[7] = (char *(*)()) F664_5727;
	R5238[8] = (char *(*)()) F665_5727;
	R5238[9] = (char *(*)()) F666_5727;
	R5238[10] = (char *(*)()) F667_5727;
	R5238[11] = (char *(*)()) F668_5727;
	R5238[12] = (char *(*)()) F657_5727;
	R5238[13] = (char *(*)()) F658_5727;
	R5238[14] = (char *(*)()) F663_5727;
	R5238[19] = (char *(*)()) F657_5727;
	R5238[20] = (char *(*)()) F658_5727;
	{long i; for (i = 21; i < 25; i++) R5238[i] = (char *(*)()) F657_5727;}
	R5238[29] = (char *(*)()) F657_5727;
	R5238[31] = (char *(*)()) F657_5727;
	R5238[33] = (char *(*)()) F657_5727;
	R5238[37] = (char *(*)()) F657_5727;
	{long i; for (i = 39; i < 43; i++) R5238[i] = (char *(*)()) F657_5727;}
}

char *(*R5242[43])();
void R5242_init () {
	R5242[0] = (char *(*)()) F657_5746;
	R5242[1] = (char *(*)()) F658_5746;
	R5242[2] = (char *(*)()) F659_5746;
	R5242[3] = (char *(*)()) F660_5746;
	R5242[4] = (char *(*)()) F661_5746;
	R5242[5] = (char *(*)()) F662_5746;
	R5242[6] = (char *(*)()) F663_5746;
	R5242[7] = (char *(*)()) F664_5746;
	R5242[8] = (char *(*)()) F665_5746;
	R5242[9] = (char *(*)()) F666_5746;
	R5242[10] = (char *(*)()) F667_5746;
	R5242[11] = (char *(*)()) F668_5746;
	R5242[12] = (char *(*)()) F657_5746;
	R5242[13] = (char *(*)()) F658_5746;
	R5242[14] = (char *(*)()) F663_5746;
	R5242[19] = (char *(*)()) F657_5746;
	R5242[20] = (char *(*)()) F658_5746;
	{long i; for (i = 21; i < 25; i++) R5242[i] = (char *(*)()) F657_5746;}
	R5242[29] = (char *(*)()) F657_5746;
	R5242[31] = (char *(*)()) F657_5746;
	R5242[33] = (char *(*)()) F657_5746;
	R5242[37] = (char *(*)()) F657_5746;
	{long i; for (i = 39; i < 43; i++) R5242[i] = (char *(*)()) F657_5746;}
}

char *(*R5246[43])();
void R5246_init () {
	R5246[0] = (char *(*)()) F657_5787;
	R5246[1] = (char *(*)()) F658_5787_5246_250;
	R5246[2] = (char *(*)()) F659_5787_5246_250;
	R5246[3] = (char *(*)()) F660_5787_5246_250;
	R5246[4] = (char *(*)()) F661_5787_5246_250;
	R5246[5] = (char *(*)()) F662_5787_5246_250;
	R5246[6] = (char *(*)()) F663_5787_5246_250;
	R5246[7] = (char *(*)()) F664_5787_5246_250;
	R5246[8] = (char *(*)()) F665_5787_5246_250;
	R5246[9] = (char *(*)()) F666_5787_5246_250;
	R5246[10] = (char *(*)()) F667_5787_5246_250;
	R5246[11] = (char *(*)()) F668_5787_5246_250;
	R5246[12] = (char *(*)()) F657_5787;
	R5246[13] = (char *(*)()) F658_5787_5246_250;
	R5246[14] = (char *(*)()) F663_5787_5246_250;
	R5246[19] = (char *(*)()) F657_5787;
	R5246[20] = (char *(*)()) F658_5787_5246_250;
	{long i; for (i = 21; i < 25; i++) R5246[i] = (char *(*)()) F657_5787;}
	R5246[29] = (char *(*)()) F657_5787;
	R5246[31] = (char *(*)()) F657_5787;
	R5246[33] = (char *(*)()) F657_5787;
	R5246[37] = (char *(*)()) F657_5787;
	{long i; for (i = 39; i < 43; i++) R5246[i] = (char *(*)()) F657_5787;}
}
static void F658_5787_5246_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F658_5787(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F659_5787_5246_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F659_5787(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F660_5787_5246_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F660_5787(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F661_5787_5246_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F661_5787(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F662_5787_5246_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F662_5787(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F663_5787_5246_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F663_5787(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F664_5787_5246_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F664_5787(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F665_5787_5246_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F665_5787(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F666_5787_5246_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F666_5787(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F667_5787_5246_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F667_5787(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F668_5787_5246_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F668_5787(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R5250[3])();
void R5250_init () {
	R5250[0] = (char *(*)()) F657_5764;
	R5250[1] = (char *(*)()) F658_5764_5250_4;
	R5250[2] = (char *(*)()) F663_5764_5250_4;
}
static void F658_5764_5250_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F658_5764(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F663_5764_5250_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F663_5764(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R5251[3])();
void R5251_init () {
	R5251[0] = (char *(*)()) F657_5777;
	R5251[1] = (char *(*)()) F658_5777;
	R5251[2] = (char *(*)()) F663_5777;
}

char *(*R5252[24])();
void R5252_init () {
	R5252[0] = (char *(*)()) F676_5832;
	R5252[1] = (char *(*)()) F677_5832_5252_250;
	R5252[2] = (char *(*)()) F676_5832;
	{long i; for (i = 3; i < 6; i++) R5252[i] = (char *(*)()) F679_5841;}
	R5252[10] = (char *(*)()) F679_5841;
	R5252[12] = (char *(*)()) F679_5841;
	R5252[14] = (char *(*)()) F679_5841;
	R5252[18] = (char *(*)()) F679_5841;
	{long i; for (i = 20; i < 24; i++) R5252[i] = (char *(*)()) F679_5841;}
}
static void F677_5832_5252_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F677_5832(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R5253[24])();
void R5253_init () {
	R5253[0] = (char *(*)()) F676_5833;
	R5253[1] = (char *(*)()) F677_5833_5253_250;
	R5253[2] = (char *(*)()) F676_5833;
	{long i; for (i = 3; i < 6; i++) R5253[i] = (char *(*)()) F679_5842;}
	R5253[10] = (char *(*)()) F679_5842;
	R5253[12] = (char *(*)()) F679_5842;
	R5253[14] = (char *(*)()) F679_5842;
	R5253[18] = (char *(*)()) F679_5842;
	{long i; for (i = 20; i < 24; i++) R5253[i] = (char *(*)()) F679_5842;}
}
static void F677_5833_5253_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F677_5833(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R5257[24])();
void R5257_init () {
	R5257[0] = (char *(*)()) F672_5821;
	R5257[1] = (char *(*)()) F673_5821_5257_250;
	{long i; for (i = 2; i < 6; i++) R5257[i] = (char *(*)()) F672_5821;}
	R5257[10] = (char *(*)()) F672_5821;
	R5257[12] = (char *(*)()) F672_5821;
	R5257[14] = (char *(*)()) F672_5821;
	R5257[18] = (char *(*)()) F672_5821;
	{long i; for (i = 20; i < 24; i++) R5257[i] = (char *(*)()) F672_5821;}
}
static void F673_5821_5257_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F673_5821(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R5258[24])();
void R5258_init () {
	R5258[0] = (char *(*)()) F672_5822;
	R5258[1] = (char *(*)()) F673_5822_5258_250;
	{long i; for (i = 2; i < 6; i++) R5258[i] = (char *(*)()) F672_5822;}
	R5258[10] = (char *(*)()) F672_5822;
	R5258[12] = (char *(*)()) F672_5822;
	R5258[14] = (char *(*)()) F672_5822;
	R5258[18] = (char *(*)()) F672_5822;
	{long i; for (i = 20; i < 24; i++) R5258[i] = (char *(*)()) F672_5822;}
}
static void F673_5822_5258_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F673_5822(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R5266[21])();
void R5266_init () {
	R5266[0] = (char *(*)()) F679_5843;
	R5266[1] = (char *(*)()) F680_5877;
	R5266[2] = (char *(*)()) F681_5878;
	R5266[7] = (char *(*)()) F680_5877;
	R5266[9] = (char *(*)()) F680_5877;
	R5266[11] = (char *(*)()) F680_5877;
	R5266[15] = (char *(*)()) F680_5877;
	{long i; for (i = 17; i < 21; i++) R5266[i] = (char *(*)()) F680_5877;}
}

static EIF_TYPE_INDEX Y5298_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5298_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5298_pgtype2[] = {0xFFF9,1,966,0xFF01,0,0xFFFF};
static EIF_TYPE_INDEX Y5298_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5298_pgtype4[] = {0xFF01,0xFFF9,1,966,984,0xFFFF};
static EIF_TYPE_INDEX Y5298_pgtype5[] = {0xFF01,0xFFF9,1,966,984,0xFFFF};
static EIF_TYPE_INDEX Y5298_pgtype6[] = {0xFF01,0xFFF9,1,966,0xFF01,1164,0xFFFF};
static EIF_TYPE_INDEX Y5298_pgtype7[] = {0xFF01,0xFFF9,1,966,0xFF01,1169,0xFFFF};
static EIF_TYPE_INDEX Y5298_pgtype8[] = {0xFF01,0xFFF9,1,966,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y5298_pgtype9[] = {0xFF01,0xFFF9,1,966,0xFF01,1101,0xFFFF};
static EIF_TYPE_INDEX Y5298_pgtype10[] = {0xFF01,0xFFF9,1,966,927,0xFFFF};
static EIF_TYPE_INDEX Y5298_pgtype11[] = {0xFF01,0xFFF9,1,966,0xFF01,1371,0xFFFF};
static EIF_TYPE_INDEX Y5298_pgtype12[] = {0xFF01,0xFFF9,5,966,996,984,984,984,984,0xFFFF};
static EIF_TYPE_INDEX Y5298_pgtype13[] = {0xFF01,0xFFF9,1,966,0xFF01,1050,0xFFFF};
static EIF_TYPE_INDEX Y5298_pgtype14[] = {0xFF01,0xFFF9,1,966,984,0xFFFF};
static EIF_TYPE_INDEX Y5298_pgtype15[] = {0xFF01,0xFFF9,4,966,984,984,984,984,0xFFFF};
static EIF_TYPE_INDEX Y5298_pgtype16[] = {0xFF01,0xFFF9,2,966,984,984,0xFFFF};
static EIF_TYPE_INDEX Y5298_pgtype17[] = {0xFF01,0xFFF9,7,966,984,984,969,969,969,984,984,0xFFFF};
static EIF_TYPE_INDEX Y5298_pgtype18[] = {0xFF01,0xFFF9,3,966,984,984,927,0xFFFF};
static EIF_TYPE_INDEX Y5298_pgtype19[] = {0xFF01,0xFFF9,8,966,984,984,984,969,969,969,984,984,0xFFFF};
static EIF_TYPE_INDEX Y5298_pgtype20[] = {0xFF01,0xFFF9,0,966,0xFFFF};
EIF_TYPE_INDEX *Y5298_gen_type [21];
EIF_TYPE_INDEX Y5298 [21];
void Y5298_init (void)
{
	egc_routines_types [5298] = Y5298;
	egc_routines_gen_types [5298] = Y5298_gen_type;
	egc_routines_offset [5298] = 678;
	Y5298_gen_type [0] = Y5298_pgtype0;
	Y5298_gen_type [1] = Y5298_pgtype1;
	Y5298_gen_type [2] = Y5298_pgtype2;
	Y5298_gen_type [3] = Y5298_pgtype3;
	Y5298_gen_type [4] = Y5298_pgtype4;
	Y5298_gen_type [5] = Y5298_pgtype5;
	Y5298_gen_type [6] = Y5298_pgtype6;
	Y5298_gen_type [7] = Y5298_pgtype7;
	Y5298_gen_type [8] = Y5298_pgtype8;
	Y5298_gen_type [9] = Y5298_pgtype9;
	Y5298_gen_type [10] = Y5298_pgtype10;
	Y5298_gen_type [11] = Y5298_pgtype11;
	Y5298_gen_type [12] = Y5298_pgtype12;
	Y5298_gen_type [13] = Y5298_pgtype13;
	Y5298_gen_type [14] = Y5298_pgtype14;
	Y5298_gen_type [15] = Y5298_pgtype15;
	Y5298_gen_type [16] = Y5298_pgtype16;
	Y5298_gen_type [17] = Y5298_pgtype17;
	Y5298_gen_type [18] = Y5298_pgtype18;
	Y5298_gen_type [19] = Y5298_pgtype19;
	Y5298_gen_type [20] = Y5298_pgtype20;
	Y5298[2] = 966;
	{long i; for (i = 4; i < 21; i++) Y5298[i] = 966;};
}

char *(*R5448[192])();
void R5448_init () {
	R5448[0] = (char *(*)()) F721_6084;
	R5448[1] = (char *(*)()) F482_5215_5448_1;
	R5448[6] = (char *(*)()) F482_5215_5448_1;
	R5448[37] = (char *(*)()) F746_6185;
	R5448[38] = (char *(*)()) F747_6185_5448_1;
	R5448[39] = (char *(*)()) F748_6185_5448_1;
	R5448[40] = (char *(*)()) F749_6185_5448_1;
	R5448[41] = (char *(*)()) F750_6185_5448_1;
	R5448[42] = (char *(*)()) F751_6185_5448_1;
	R5448[43] = (char *(*)()) F752_6185_5448_1;
	R5448[44] = (char *(*)()) F753_6185_5448_1;
	R5448[45] = (char *(*)()) F754_6185_5448_1;
	R5448[46] = (char *(*)()) F755_6185_5448_1;
	R5448[47] = (char *(*)()) F756_6185_5448_1;
	R5448[48] = (char *(*)()) F757_6185_5448_1;
	R5448[49] = (char *(*)()) F770_6213;
	R5448[50] = (char *(*)()) F771_6213_5448_1;
	R5448[51] = (char *(*)()) F772_6213_5448_1;
	R5448[52] = (char *(*)()) F773_6219;
	R5448[53] = (char *(*)()) F774_6219_5448_1;
	R5448[54] = (char *(*)()) F775_6219;
	R5448[55] = (char *(*)()) F776_6219_5448_1;
	R5448[56] = (char *(*)()) F777_6219_5448_1;
	R5448[57] = (char *(*)()) F778_6219_5448_1;
	R5448[70] = (char *(*)()) F779_6225;
	R5448[71] = (char *(*)()) F780_6225_5448_1;
	R5448[72] = (char *(*)()) F781_6225_5448_1;
	R5448[73] = (char *(*)()) F782_6225_5448_1;
	R5448[74] = (char *(*)()) F783_6225_5448_1;
	R5448[75] = (char *(*)()) F784_6225_5448_1;
	R5448[76] = (char *(*)()) F785_6225_5448_1;
	R5448[77] = (char *(*)()) F786_6225_5448_1;
	R5448[78] = (char *(*)()) F787_6225_5448_1;
	R5448[79] = (char *(*)()) F788_6225_5448_1;
	R5448[80] = (char *(*)()) F789_6225_5448_1;
	R5448[81] = (char *(*)()) F790_6225_5448_1;
	R5448[82] = (char *(*)()) F787_6225_5448_1;
	R5448[83] = (char *(*)()) F788_6225_5448_1;
	R5448[84] = (char *(*)()) F779_6225;
	R5448[85] = (char *(*)()) F780_6225_5448_1;
	R5448[86] = (char *(*)()) F781_6225_5448_1;
	R5448[87] = (char *(*)()) F782_6225_5448_1;
	R5448[88] = (char *(*)()) F783_6225_5448_1;
	R5448[89] = (char *(*)()) F784_6225_5448_1;
	R5448[90] = (char *(*)()) F785_6225_5448_1;
	R5448[91] = (char *(*)()) F786_6225_5448_1;
	R5448[92] = (char *(*)()) F787_6225_5448_1;
	R5448[93] = (char *(*)()) F788_6225_5448_1;
	R5448[94] = (char *(*)()) F789_6225_5448_1;
	R5448[95] = (char *(*)()) F790_6225_5448_1;
	R5448[96] = (char *(*)()) F779_6225;
	R5448[97] = (char *(*)()) F780_6225_5448_1;
	R5448[98] = (char *(*)()) F781_6225_5448_1;
	R5448[99] = (char *(*)()) F782_6225_5448_1;
	R5448[100] = (char *(*)()) F783_6225_5448_1;
	R5448[101] = (char *(*)()) F784_6225_5448_1;
	R5448[102] = (char *(*)()) F785_6225_5448_1;
	R5448[103] = (char *(*)()) F786_6225_5448_1;
	R5448[104] = (char *(*)()) F787_6225_5448_1;
	R5448[105] = (char *(*)()) F788_6225_5448_1;
	R5448[106] = (char *(*)()) F789_6225_5448_1;
	R5448[107] = (char *(*)()) F790_6225_5448_1;
	R5448[191] = (char *(*)()) F912_6716_5448_1;
}
static EIF_REFERENCE F482_5215_5448_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F482_5215(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F747_6185_5448_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F747_6185(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F748_6185_5448_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F748_6185(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(999, 0x00).id, 999, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F749_6185_5448_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F749_6185(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(993, 0x00).id, 993, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F750_6185_5448_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F750_6185(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F751_6185_5448_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F751_6185(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F752_6185_5448_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F752_6185(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F753_6185_5448_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F753_6185(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F754_6185_5448_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F754_6185(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F755_6185_5448_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F755_6185(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F756_6185_5448_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F756_6185(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F757_6185_5448_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F757_6185(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F771_6213_5448_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F771_6213(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F772_6213_5448_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F772_6213(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F774_6219_5448_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F774_6219(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F776_6219_5448_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F776_6219(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F777_6219_5448_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F777_6219(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F778_6219_5448_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F778_6219(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F780_6225_5448_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F780_6225(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F781_6225_5448_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F781_6225(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(999, 0x00).id, 999, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F782_6225_5448_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F782_6225(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(993, 0x00).id, 993, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F783_6225_5448_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F783_6225(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F784_6225_5448_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F784_6225(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F785_6225_5448_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F785_6225(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F786_6225_5448_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F786_6225(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F787_6225_5448_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F787_6225(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F788_6225_5448_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F788_6225(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F789_6225_5448_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F789_6225(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F790_6225_5448_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F790_6225(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F912_6716_5448_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F912_6716(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R5449[192])();
void R5449_init () {
	R5449[0] = (char *(*)()) F721_6085;
	R5449[1] = (char *(*)()) F482_5216;
	R5449[6] = (char *(*)()) F482_5216;
	R5449[37] = (char *(*)()) F758_6203;
	R5449[38] = (char *(*)()) F759_6203;
	R5449[39] = (char *(*)()) F760_6203;
	R5449[40] = (char *(*)()) F761_6203;
	R5449[41] = (char *(*)()) F762_6203;
	R5449[42] = (char *(*)()) F763_6203;
	R5449[43] = (char *(*)()) F764_6203;
	R5449[44] = (char *(*)()) F765_6203;
	R5449[45] = (char *(*)()) F766_6203;
	R5449[46] = (char *(*)()) F767_6203;
	R5449[47] = (char *(*)()) F768_6203;
	R5449[48] = (char *(*)()) F769_6203;
	R5449[49] = (char *(*)()) F770_6214;
	R5449[50] = (char *(*)()) F771_6214;
	R5449[51] = (char *(*)()) F772_6214;
	R5449[52] = (char *(*)()) F773_6222;
	R5449[53] = (char *(*)()) F774_6222;
	R5449[54] = (char *(*)()) F775_6222;
	R5449[55] = (char *(*)()) F776_6222;
	R5449[56] = (char *(*)()) F777_6222;
	R5449[57] = (char *(*)()) F778_6222;
	R5449[70] = (char *(*)()) F779_6234;
	R5449[71] = (char *(*)()) F780_6234;
	R5449[72] = (char *(*)()) F781_6234;
	R5449[73] = (char *(*)()) F782_6234;
	R5449[74] = (char *(*)()) F783_6234;
	R5449[75] = (char *(*)()) F784_6234;
	R5449[76] = (char *(*)()) F785_6234;
	R5449[77] = (char *(*)()) F786_6234;
	R5449[78] = (char *(*)()) F787_6234;
	R5449[79] = (char *(*)()) F788_6234;
	R5449[80] = (char *(*)()) F789_6234;
	R5449[81] = (char *(*)()) F790_6234;
	R5449[82] = (char *(*)()) F787_6234;
	R5449[83] = (char *(*)()) F788_6234;
	R5449[84] = (char *(*)()) F779_6234;
	R5449[85] = (char *(*)()) F780_6234;
	R5449[86] = (char *(*)()) F781_6234;
	R5449[87] = (char *(*)()) F782_6234;
	R5449[88] = (char *(*)()) F783_6234;
	R5449[89] = (char *(*)()) F784_6234;
	R5449[90] = (char *(*)()) F785_6234;
	R5449[91] = (char *(*)()) F786_6234;
	R5449[92] = (char *(*)()) F787_6234;
	R5449[93] = (char *(*)()) F788_6234;
	R5449[94] = (char *(*)()) F789_6234;
	R5449[95] = (char *(*)()) F790_6234;
	R5449[96] = (char *(*)()) F779_6234;
	R5449[97] = (char *(*)()) F780_6234;
	R5449[98] = (char *(*)()) F781_6234;
	R5449[99] = (char *(*)()) F782_6234;
	R5449[100] = (char *(*)()) F783_6234;
	R5449[101] = (char *(*)()) F784_6234;
	R5449[102] = (char *(*)()) F785_6234;
	R5449[103] = (char *(*)()) F786_6234;
	R5449[104] = (char *(*)()) F787_6234;
	R5449[105] = (char *(*)()) F788_6234;
	R5449[106] = (char *(*)()) F789_6234;
	R5449[107] = (char *(*)()) F790_6234;
	R5449[191] = (char *(*)()) F912_6718;
}

char *(*R5450[192])();
void R5450_init () {
	R5450[0] = (char *(*)()) F721_6086;
	R5450[1] = (char *(*)()) F482_5222;
	R5450[6] = (char *(*)()) F482_5222;
	R5450[37] = (char *(*)()) F758_6211;
	R5450[38] = (char *(*)()) F759_6211;
	R5450[39] = (char *(*)()) F760_6211;
	R5450[40] = (char *(*)()) F761_6211;
	R5450[41] = (char *(*)()) F762_6211;
	R5450[42] = (char *(*)()) F763_6211;
	R5450[43] = (char *(*)()) F764_6211;
	R5450[44] = (char *(*)()) F765_6211;
	R5450[45] = (char *(*)()) F766_6211;
	R5450[46] = (char *(*)()) F767_6211;
	R5450[47] = (char *(*)()) F768_6211;
	R5450[48] = (char *(*)()) F769_6211;
	R5450[49] = (char *(*)()) F770_6216;
	R5450[50] = (char *(*)()) F771_6216;
	R5450[51] = (char *(*)()) F772_6216;
	R5450[52] = (char *(*)()) F773_6223;
	R5450[53] = (char *(*)()) F774_6223;
	R5450[54] = (char *(*)()) F775_6223;
	R5450[55] = (char *(*)()) F776_6223;
	R5450[56] = (char *(*)()) F777_6223;
	R5450[57] = (char *(*)()) F778_6223;
	R5450[70] = (char *(*)()) F779_6240;
	R5450[71] = (char *(*)()) F780_6240;
	R5450[72] = (char *(*)()) F781_6240;
	R5450[73] = (char *(*)()) F782_6240;
	R5450[74] = (char *(*)()) F783_6240;
	R5450[75] = (char *(*)()) F784_6240;
	R5450[76] = (char *(*)()) F785_6240;
	R5450[77] = (char *(*)()) F786_6240;
	R5450[78] = (char *(*)()) F787_6240;
	R5450[79] = (char *(*)()) F788_6240;
	R5450[80] = (char *(*)()) F789_6240;
	R5450[81] = (char *(*)()) F790_6240;
	R5450[82] = (char *(*)()) F787_6240;
	R5450[83] = (char *(*)()) F788_6240;
	R5450[84] = (char *(*)()) F779_6240;
	R5450[85] = (char *(*)()) F780_6240;
	R5450[86] = (char *(*)()) F781_6240;
	R5450[87] = (char *(*)()) F782_6240;
	R5450[88] = (char *(*)()) F783_6240;
	R5450[89] = (char *(*)()) F784_6240;
	R5450[90] = (char *(*)()) F785_6240;
	R5450[91] = (char *(*)()) F786_6240;
	R5450[92] = (char *(*)()) F787_6240;
	R5450[93] = (char *(*)()) F788_6240;
	R5450[94] = (char *(*)()) F789_6240;
	R5450[95] = (char *(*)()) F790_6240;
	R5450[96] = (char *(*)()) F779_6240;
	R5450[97] = (char *(*)()) F780_6240;
	R5450[98] = (char *(*)()) F781_6240;
	R5450[99] = (char *(*)()) F782_6240;
	R5450[100] = (char *(*)()) F783_6240;
	R5450[101] = (char *(*)()) F784_6240;
	R5450[102] = (char *(*)()) F785_6240;
	R5450[103] = (char *(*)()) F786_6240;
	R5450[104] = (char *(*)()) F787_6240;
	R5450[105] = (char *(*)()) F788_6240;
	R5450[106] = (char *(*)()) F789_6240;
	R5450[107] = (char *(*)()) F790_6240;
	R5450[191] = (char *(*)()) F912_6719;
}

static EIF_TYPE_INDEX Y5451_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype13[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype16[] = {0xFF01,30,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype17[] = {972,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype18[] = {984,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype94[] = {972,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype95[] = {975,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5451_pgtype120[] = {975,0xFFFF};
EIF_TYPE_INDEX *Y5451_gen_type [204];
EIF_TYPE_INDEX Y5451 [204];
void Y5451_init (void)
{
	egc_routines_types [5451] = Y5451;
	egc_routines_gen_types [5451] = Y5451_gen_type;
	egc_routines_offset [5451] = 708;
	Y5451_gen_type [0] = Y5451_pgtype0;
	Y5451_gen_type [1] = Y5451_pgtype1;
	Y5451_gen_type [2] = Y5451_pgtype2;
	Y5451_gen_type [3] = Y5451_pgtype3;
	Y5451_gen_type [4] = Y5451_pgtype4;
	Y5451_gen_type [5] = Y5451_pgtype5;
	Y5451_gen_type [6] = Y5451_pgtype6;
	Y5451_gen_type [7] = Y5451_pgtype7;
	Y5451_gen_type [8] = Y5451_pgtype8;
	Y5451_gen_type [9] = Y5451_pgtype9;
	Y5451_gen_type [10] = Y5451_pgtype10;
	Y5451_gen_type [11] = Y5451_pgtype11;
	Y5451_gen_type [12] = Y5451_pgtype12;
	Y5451_gen_type [13] = Y5451_pgtype13;
	Y5451_gen_type [14] = Y5451_pgtype14;
	Y5451_gen_type [15] = Y5451_pgtype15;
	Y5451_gen_type [16] = Y5451_pgtype16;
	Y5451_gen_type [17] = Y5451_pgtype17;
	Y5451_gen_type [18] = Y5451_pgtype18;
	Y5451_gen_type [19] = Y5451_pgtype19;
	Y5451_gen_type [20] = Y5451_pgtype20;
	Y5451_gen_type [21] = Y5451_pgtype21;
	Y5451_gen_type [22] = Y5451_pgtype22;
	Y5451_gen_type [23] = Y5451_pgtype23;
	Y5451_gen_type [24] = Y5451_pgtype24;
	Y5451_gen_type [25] = Y5451_pgtype25;
	Y5451_gen_type [26] = Y5451_pgtype26;
	Y5451_gen_type [27] = Y5451_pgtype27;
	Y5451_gen_type [28] = Y5451_pgtype28;
	Y5451_gen_type [29] = Y5451_pgtype29;
	Y5451_gen_type [30] = Y5451_pgtype30;
	Y5451_gen_type [31] = Y5451_pgtype31;
	Y5451_gen_type [32] = Y5451_pgtype32;
	Y5451_gen_type [33] = Y5451_pgtype33;
	Y5451_gen_type [34] = Y5451_pgtype34;
	Y5451_gen_type [35] = Y5451_pgtype35;
	Y5451_gen_type [36] = Y5451_pgtype36;
	Y5451_gen_type [37] = Y5451_pgtype37;
	Y5451_gen_type [38] = Y5451_pgtype38;
	Y5451_gen_type [39] = Y5451_pgtype39;
	Y5451_gen_type [40] = Y5451_pgtype40;
	Y5451_gen_type [41] = Y5451_pgtype41;
	Y5451_gen_type [42] = Y5451_pgtype42;
	Y5451_gen_type [43] = Y5451_pgtype43;
	Y5451_gen_type [44] = Y5451_pgtype44;
	Y5451_gen_type [45] = Y5451_pgtype45;
	Y5451_gen_type [46] = Y5451_pgtype46;
	Y5451_gen_type [47] = Y5451_pgtype47;
	Y5451_gen_type [48] = Y5451_pgtype48;
	Y5451_gen_type [49] = Y5451_pgtype49;
	Y5451_gen_type [50] = Y5451_pgtype50;
	Y5451_gen_type [51] = Y5451_pgtype51;
	Y5451_gen_type [52] = Y5451_pgtype52;
	Y5451_gen_type [53] = Y5451_pgtype53;
	Y5451_gen_type [54] = Y5451_pgtype54;
	Y5451_gen_type [55] = Y5451_pgtype55;
	Y5451_gen_type [56] = Y5451_pgtype56;
	Y5451_gen_type [57] = Y5451_pgtype57;
	Y5451_gen_type [58] = Y5451_pgtype58;
	Y5451_gen_type [59] = Y5451_pgtype59;
	Y5451_gen_type [60] = Y5451_pgtype60;
	Y5451_gen_type [61] = Y5451_pgtype61;
	Y5451_gen_type [62] = Y5451_pgtype62;
	Y5451_gen_type [63] = Y5451_pgtype63;
	Y5451_gen_type [64] = Y5451_pgtype64;
	Y5451_gen_type [65] = Y5451_pgtype65;
	Y5451_gen_type [66] = Y5451_pgtype66;
	Y5451_gen_type [67] = Y5451_pgtype67;
	Y5451_gen_type [68] = Y5451_pgtype68;
	Y5451_gen_type [69] = Y5451_pgtype69;
	Y5451_gen_type [70] = Y5451_pgtype70;
	Y5451_gen_type [71] = Y5451_pgtype71;
	Y5451_gen_type [72] = Y5451_pgtype72;
	Y5451_gen_type [73] = Y5451_pgtype73;
	Y5451_gen_type [74] = Y5451_pgtype74;
	Y5451_gen_type [75] = Y5451_pgtype75;
	Y5451_gen_type [76] = Y5451_pgtype76;
	Y5451_gen_type [77] = Y5451_pgtype77;
	Y5451_gen_type [78] = Y5451_pgtype78;
	Y5451_gen_type [79] = Y5451_pgtype79;
	Y5451_gen_type [80] = Y5451_pgtype80;
	Y5451_gen_type [81] = Y5451_pgtype81;
	Y5451_gen_type [82] = Y5451_pgtype82;
	Y5451_gen_type [83] = Y5451_pgtype83;
	Y5451_gen_type [84] = Y5451_pgtype84;
	Y5451_gen_type [85] = Y5451_pgtype85;
	Y5451_gen_type [86] = Y5451_pgtype86;
	Y5451_gen_type [87] = Y5451_pgtype87;
	Y5451_gen_type [88] = Y5451_pgtype88;
	Y5451_gen_type [89] = Y5451_pgtype89;
	Y5451_gen_type [90] = Y5451_pgtype90;
	Y5451_gen_type [91] = Y5451_pgtype91;
	Y5451_gen_type [92] = Y5451_pgtype92;
	Y5451_gen_type [93] = Y5451_pgtype93;
	Y5451_gen_type [94] = Y5451_pgtype94;
	Y5451_gen_type [95] = Y5451_pgtype95;
	Y5451_gen_type [96] = Y5451_pgtype96;
	Y5451_gen_type [97] = Y5451_pgtype97;
	Y5451_gen_type [98] = Y5451_pgtype98;
	Y5451_gen_type [99] = Y5451_pgtype99;
	Y5451_gen_type [100] = Y5451_pgtype100;
	Y5451_gen_type [101] = Y5451_pgtype101;
	Y5451_gen_type [102] = Y5451_pgtype102;
	Y5451_gen_type [103] = Y5451_pgtype103;
	Y5451_gen_type [104] = Y5451_pgtype104;
	Y5451_gen_type [105] = Y5451_pgtype105;
	Y5451_gen_type [106] = Y5451_pgtype106;
	Y5451_gen_type [107] = Y5451_pgtype107;
	Y5451_gen_type [108] = Y5451_pgtype108;
	Y5451_gen_type [109] = Y5451_pgtype109;
	Y5451_gen_type [110] = Y5451_pgtype110;
	Y5451_gen_type [111] = Y5451_pgtype111;
	Y5451_gen_type [112] = Y5451_pgtype112;
	Y5451_gen_type [113] = Y5451_pgtype113;
	Y5451_gen_type [114] = Y5451_pgtype114;
	Y5451_gen_type [115] = Y5451_pgtype115;
	Y5451_gen_type [116] = Y5451_pgtype116;
	Y5451_gen_type [117] = Y5451_pgtype117;
	Y5451_gen_type [118] = Y5451_pgtype118;
	Y5451_gen_type [119] = Y5451_pgtype119;
	Y5451_gen_type [203] = Y5451_pgtype120;
	Y5451[13] = 984;
	Y5451[16] = 30;
	Y5451[17] = 972;
	Y5451[18] = 984;
	Y5451[94] = 972;
	Y5451[95] = 975;
	Y5451[203] = 975;
}

char *(*R5508[6])();
void R5508_init () {
	R5508[0] = (char *(*)()) F773_6220;
	R5508[1] = (char *(*)()) F774_6220;
	R5508[2] = (char *(*)()) F775_6220_5508_1;
	R5508[3] = (char *(*)()) F776_6220_5508_1;
	R5508[4] = (char *(*)()) F777_6220_5508_1;
	R5508[5] = (char *(*)()) F778_6220;
}
static EIF_REFERENCE F775_6220_5508_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F775_6220(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F776_6220_5508_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F776_6220(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F777_6220_5508_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F777_6220(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}

char *(*R5511[71])();
void R5511_init () {
	R5511[0] = (char *(*)()) F758_6193;
	R5511[1] = (char *(*)()) F759_6193;
	R5511[2] = (char *(*)()) F760_6193;
	R5511[3] = (char *(*)()) F761_6193;
	R5511[4] = (char *(*)()) F762_6193;
	R5511[5] = (char *(*)()) F763_6193;
	R5511[6] = (char *(*)()) F764_6193;
	R5511[7] = (char *(*)()) F765_6193;
	R5511[8] = (char *(*)()) F766_6193;
	R5511[9] = (char *(*)()) F767_6193;
	R5511[10] = (char *(*)()) F768_6193;
	R5511[11] = (char *(*)()) F769_6193;
	R5511[12] = (char *(*)()) F758_6193;
	R5511[13] = (char *(*)()) F759_6193;
	R5511[14] = (char *(*)()) F765_6193;
	R5511[15] = (char *(*)()) F758_6193;
	R5511[16] = (char *(*)()) F759_6193;
	R5511[17] = (char *(*)()) F758_6193;
	{long i; for (i = 18; i < 20; i++) R5511[i] = (char *(*)()) F759_6193;}
	R5511[20] = (char *(*)()) F766_6193;
	R5511[33] = (char *(*)()) F779_6227;
	R5511[34] = (char *(*)()) F780_6227;
	R5511[35] = (char *(*)()) F781_6227;
	R5511[36] = (char *(*)()) F782_6227;
	R5511[37] = (char *(*)()) F783_6227;
	R5511[38] = (char *(*)()) F784_6227;
	R5511[39] = (char *(*)()) F785_6227;
	R5511[40] = (char *(*)()) F786_6227;
	R5511[41] = (char *(*)()) F787_6227;
	R5511[42] = (char *(*)()) F788_6227;
	R5511[43] = (char *(*)()) F789_6227;
	R5511[44] = (char *(*)()) F790_6227;
	R5511[45] = (char *(*)()) F787_6227;
	R5511[46] = (char *(*)()) F788_6227;
	R5511[47] = (char *(*)()) F779_6227;
	R5511[48] = (char *(*)()) F780_6227;
	R5511[49] = (char *(*)()) F781_6227;
	R5511[50] = (char *(*)()) F782_6227;
	R5511[51] = (char *(*)()) F783_6227;
	R5511[52] = (char *(*)()) F784_6227;
	R5511[53] = (char *(*)()) F785_6227;
	R5511[54] = (char *(*)()) F786_6227;
	R5511[55] = (char *(*)()) F787_6227;
	R5511[56] = (char *(*)()) F788_6227;
	R5511[57] = (char *(*)()) F789_6227;
	R5511[58] = (char *(*)()) F790_6227;
	R5511[59] = (char *(*)()) F779_6227;
	R5511[60] = (char *(*)()) F780_6227;
	R5511[61] = (char *(*)()) F781_6227;
	R5511[62] = (char *(*)()) F782_6227;
	R5511[63] = (char *(*)()) F783_6227;
	R5511[64] = (char *(*)()) F784_6227;
	R5511[65] = (char *(*)()) F785_6227;
	R5511[66] = (char *(*)()) F786_6227;
	R5511[67] = (char *(*)()) F787_6227;
	R5511[68] = (char *(*)()) F788_6227;
	R5511[69] = (char *(*)()) F789_6227;
	R5511[70] = (char *(*)()) F790_6227;
}

char *(*R5512[71])();
void R5512_init () {
	R5512[0] = (char *(*)()) F758_6194;
	R5512[1] = (char *(*)()) F759_6194;
	R5512[2] = (char *(*)()) F760_6194;
	R5512[3] = (char *(*)()) F761_6194;
	R5512[4] = (char *(*)()) F762_6194;
	R5512[5] = (char *(*)()) F763_6194;
	R5512[6] = (char *(*)()) F764_6194;
	R5512[7] = (char *(*)()) F765_6194;
	R5512[8] = (char *(*)()) F766_6194;
	R5512[9] = (char *(*)()) F767_6194;
	R5512[10] = (char *(*)()) F768_6194;
	R5512[11] = (char *(*)()) F769_6194;
	R5512[12] = (char *(*)()) F758_6194;
	R5512[13] = (char *(*)()) F759_6194;
	R5512[14] = (char *(*)()) F765_6194;
	R5512[15] = (char *(*)()) F758_6194;
	R5512[16] = (char *(*)()) F759_6194;
	R5512[17] = (char *(*)()) F758_6194;
	{long i; for (i = 18; i < 20; i++) R5512[i] = (char *(*)()) F759_6194;}
	R5512[20] = (char *(*)()) F766_6194;
	R5512[33] = (char *(*)()) F791_6246;
	R5512[34] = (char *(*)()) F792_6246;
	R5512[35] = (char *(*)()) F793_6246;
	R5512[36] = (char *(*)()) F794_6246;
	R5512[37] = (char *(*)()) F795_6246;
	R5512[38] = (char *(*)()) F796_6246;
	R5512[39] = (char *(*)()) F797_6246;
	R5512[40] = (char *(*)()) F798_6246;
	R5512[41] = (char *(*)()) F799_6246;
	R5512[42] = (char *(*)()) F800_6246;
	R5512[43] = (char *(*)()) F801_6246;
	R5512[44] = (char *(*)()) F802_6246;
	R5512[45] = (char *(*)()) F803_6252;
	R5512[46] = (char *(*)()) F804_6258;
	R5512[47] = (char *(*)()) F805_6264;
	R5512[48] = (char *(*)()) F806_6264;
	R5512[49] = (char *(*)()) F807_6264;
	R5512[50] = (char *(*)()) F808_6264;
	R5512[51] = (char *(*)()) F809_6264;
	R5512[52] = (char *(*)()) F810_6264;
	R5512[53] = (char *(*)()) F811_6264;
	R5512[54] = (char *(*)()) F812_6264;
	R5512[55] = (char *(*)()) F813_6264;
	R5512[56] = (char *(*)()) F814_6264;
	R5512[57] = (char *(*)()) F815_6264;
	R5512[58] = (char *(*)()) F816_6264;
	R5512[59] = (char *(*)()) F817_6270;
	R5512[60] = (char *(*)()) F818_6270;
	R5512[61] = (char *(*)()) F819_6270;
	R5512[62] = (char *(*)()) F820_6270;
	R5512[63] = (char *(*)()) F821_6270;
	R5512[64] = (char *(*)()) F822_6270;
	R5512[65] = (char *(*)()) F823_6270;
	R5512[66] = (char *(*)()) F824_6270;
	R5512[67] = (char *(*)()) F825_6270;
	R5512[68] = (char *(*)()) F826_6270;
	R5512[69] = (char *(*)()) F827_6270;
	R5512[70] = (char *(*)()) F828_6270;
}

char *(*R5520[21])();
void R5520_init () {
	R5520[0] = (char *(*)()) F758_6205;
	R5520[1] = (char *(*)()) F759_6205;
	R5520[2] = (char *(*)()) F760_6205;
	R5520[3] = (char *(*)()) F761_6205;
	R5520[4] = (char *(*)()) F762_6205;
	R5520[5] = (char *(*)()) F763_6205;
	R5520[6] = (char *(*)()) F764_6205;
	R5520[7] = (char *(*)()) F765_6205;
	R5520[8] = (char *(*)()) F766_6205;
	R5520[9] = (char *(*)()) F767_6205;
	R5520[10] = (char *(*)()) F768_6205;
	R5520[11] = (char *(*)()) F769_6205;
	R5520[12] = (char *(*)()) F758_6205;
	R5520[13] = (char *(*)()) F759_6205;
	R5520[14] = (char *(*)()) F765_6205;
	R5520[15] = (char *(*)()) F758_6205;
	R5520[16] = (char *(*)()) F759_6205;
	R5520[17] = (char *(*)()) F758_6205;
	{long i; for (i = 18; i < 20; i++) R5520[i] = (char *(*)()) F759_6205;}
	R5520[20] = (char *(*)()) F766_6205;
}

char *(*R5523[71])();
void R5523_init () {
	R5523[0] = (char *(*)()) F758_6210;
	R5523[1] = (char *(*)()) F759_6210;
	R5523[2] = (char *(*)()) F760_6210;
	R5523[3] = (char *(*)()) F761_6210;
	R5523[4] = (char *(*)()) F762_6210;
	R5523[5] = (char *(*)()) F763_6210;
	R5523[6] = (char *(*)()) F764_6210;
	R5523[7] = (char *(*)()) F765_6210;
	R5523[8] = (char *(*)()) F766_6210;
	R5523[9] = (char *(*)()) F767_6210;
	R5523[10] = (char *(*)()) F768_6210;
	R5523[11] = (char *(*)()) F769_6210;
	R5523[12] = (char *(*)()) F770_6215;
	R5523[13] = (char *(*)()) F771_6215;
	R5523[14] = (char *(*)()) F772_6215;
	R5523[15] = (char *(*)()) F758_6210;
	R5523[16] = (char *(*)()) F759_6210;
	R5523[17] = (char *(*)()) F758_6210;
	{long i; for (i = 18; i < 20; i++) R5523[i] = (char *(*)()) F759_6210;}
	R5523[20] = (char *(*)()) F766_6210;
	R5523[33] = (char *(*)()) F779_6239;
	R5523[34] = (char *(*)()) F780_6239;
	R5523[35] = (char *(*)()) F781_6239;
	R5523[36] = (char *(*)()) F782_6239;
	R5523[37] = (char *(*)()) F783_6239;
	R5523[38] = (char *(*)()) F784_6239;
	R5523[39] = (char *(*)()) F785_6239;
	R5523[40] = (char *(*)()) F786_6239;
	R5523[41] = (char *(*)()) F787_6239;
	R5523[42] = (char *(*)()) F788_6239;
	R5523[43] = (char *(*)()) F789_6239;
	R5523[44] = (char *(*)()) F790_6239;
	R5523[45] = (char *(*)()) F787_6239;
	R5523[46] = (char *(*)()) F788_6239;
	R5523[47] = (char *(*)()) F779_6239;
	R5523[48] = (char *(*)()) F780_6239;
	R5523[49] = (char *(*)()) F781_6239;
	R5523[50] = (char *(*)()) F782_6239;
	R5523[51] = (char *(*)()) F783_6239;
	R5523[52] = (char *(*)()) F784_6239;
	R5523[53] = (char *(*)()) F785_6239;
	R5523[54] = (char *(*)()) F786_6239;
	R5523[55] = (char *(*)()) F787_6239;
	R5523[56] = (char *(*)()) F788_6239;
	R5523[57] = (char *(*)()) F789_6239;
	R5523[58] = (char *(*)()) F790_6239;
	R5523[59] = (char *(*)()) F779_6239;
	R5523[60] = (char *(*)()) F780_6239;
	R5523[61] = (char *(*)()) F781_6239;
	R5523[62] = (char *(*)()) F782_6239;
	R5523[63] = (char *(*)()) F783_6239;
	R5523[64] = (char *(*)()) F784_6239;
	R5523[65] = (char *(*)()) F785_6239;
	R5523[66] = (char *(*)()) F786_6239;
	R5523[67] = (char *(*)()) F787_6239;
	R5523[68] = (char *(*)()) F788_6239;
	R5523[69] = (char *(*)()) F789_6239;
	R5523[70] = (char *(*)()) F790_6239;
}

char *(*R5524[71])();
void R5524_init () {
	R5524[0] = (char *(*)()) F758_6212;
	R5524[1] = (char *(*)()) F759_6212;
	R5524[2] = (char *(*)()) F760_6212;
	R5524[3] = (char *(*)()) F761_6212;
	R5524[4] = (char *(*)()) F762_6212;
	R5524[5] = (char *(*)()) F763_6212;
	R5524[6] = (char *(*)()) F764_6212;
	R5524[7] = (char *(*)()) F765_6212;
	R5524[8] = (char *(*)()) F766_6212;
	R5524[9] = (char *(*)()) F767_6212;
	R5524[10] = (char *(*)()) F768_6212;
	R5524[11] = (char *(*)()) F769_6212;
	R5524[12] = (char *(*)()) F770_6217;
	R5524[13] = (char *(*)()) F771_6217;
	R5524[14] = (char *(*)()) F772_6217;
	R5524[15] = (char *(*)()) F773_6224;
	R5524[16] = (char *(*)()) F774_6224;
	R5524[17] = (char *(*)()) F775_6224;
	R5524[18] = (char *(*)()) F776_6224;
	R5524[19] = (char *(*)()) F777_6224;
	R5524[20] = (char *(*)()) F778_6224;
	R5524[33] = (char *(*)()) F791_6249;
	R5524[34] = (char *(*)()) F792_6249;
	R5524[35] = (char *(*)()) F793_6249;
	R5524[36] = (char *(*)()) F794_6249;
	R5524[37] = (char *(*)()) F795_6249;
	R5524[38] = (char *(*)()) F796_6249;
	R5524[39] = (char *(*)()) F797_6249;
	R5524[40] = (char *(*)()) F798_6249;
	R5524[41] = (char *(*)()) F799_6249;
	R5524[42] = (char *(*)()) F800_6249;
	R5524[43] = (char *(*)()) F801_6249;
	R5524[44] = (char *(*)()) F802_6249;
	R5524[45] = (char *(*)()) F803_6255;
	R5524[46] = (char *(*)()) F804_6261;
	R5524[47] = (char *(*)()) F805_6267;
	R5524[48] = (char *(*)()) F806_6267;
	R5524[49] = (char *(*)()) F807_6267;
	R5524[50] = (char *(*)()) F808_6267;
	R5524[51] = (char *(*)()) F809_6267;
	R5524[52] = (char *(*)()) F810_6267;
	R5524[53] = (char *(*)()) F811_6267;
	R5524[54] = (char *(*)()) F812_6267;
	R5524[55] = (char *(*)()) F813_6267;
	R5524[56] = (char *(*)()) F814_6267;
	R5524[57] = (char *(*)()) F815_6267;
	R5524[58] = (char *(*)()) F816_6267;
	R5524[59] = (char *(*)()) F779_6241;
	R5524[60] = (char *(*)()) F780_6241;
	R5524[61] = (char *(*)()) F781_6241;
	R5524[62] = (char *(*)()) F782_6241;
	R5524[63] = (char *(*)()) F783_6241;
	R5524[64] = (char *(*)()) F784_6241;
	R5524[65] = (char *(*)()) F785_6241;
	R5524[66] = (char *(*)()) F786_6241;
	R5524[67] = (char *(*)()) F787_6241;
	R5524[68] = (char *(*)()) F788_6241;
	R5524[69] = (char *(*)()) F789_6241;
	R5524[70] = (char *(*)()) F790_6241;
}

char *(*R5526[21])();
void R5526_init () {
	R5526[0] = (char *(*)()) F758_6191;
	R5526[1] = (char *(*)()) F759_6191;
	R5526[2] = (char *(*)()) F760_6191;
	R5526[3] = (char *(*)()) F761_6191;
	R5526[4] = (char *(*)()) F762_6191;
	R5526[5] = (char *(*)()) F763_6191;
	R5526[6] = (char *(*)()) F764_6191;
	R5526[7] = (char *(*)()) F765_6191;
	R5526[8] = (char *(*)()) F766_6191;
	R5526[9] = (char *(*)()) F767_6191;
	R5526[10] = (char *(*)()) F768_6191;
	R5526[11] = (char *(*)()) F769_6191;
	R5526[12] = (char *(*)()) F758_6191;
	R5526[13] = (char *(*)()) F759_6191;
	R5526[14] = (char *(*)()) F765_6191;
	R5526[15] = (char *(*)()) F758_6191;
	R5526[16] = (char *(*)()) F759_6191;
	R5526[17] = (char *(*)()) F758_6191;
	{long i; for (i = 18; i < 20; i++) R5526[i] = (char *(*)()) F759_6191;}
	R5526[20] = (char *(*)()) F766_6191;
}

char *(*R5539[38])();
void R5539_init () {
	R5539[0] = (char *(*)()) F791_6250;
	R5539[1] = (char *(*)()) F792_6250;
	R5539[2] = (char *(*)()) F793_6250;
	R5539[3] = (char *(*)()) F794_6250;
	R5539[4] = (char *(*)()) F795_6250;
	R5539[5] = (char *(*)()) F796_6250;
	R5539[6] = (char *(*)()) F797_6250;
	R5539[7] = (char *(*)()) F798_6250;
	R5539[8] = (char *(*)()) F799_6250;
	R5539[9] = (char *(*)()) F800_6250;
	R5539[10] = (char *(*)()) F801_6250;
	R5539[11] = (char *(*)()) F802_6250;
	R5539[12] = (char *(*)()) F803_6256;
	R5539[13] = (char *(*)()) F804_6262;
	R5539[14] = (char *(*)()) F805_6268;
	R5539[15] = (char *(*)()) F806_6268;
	R5539[16] = (char *(*)()) F807_6268;
	R5539[17] = (char *(*)()) F808_6268;
	R5539[18] = (char *(*)()) F809_6268;
	R5539[19] = (char *(*)()) F810_6268;
	R5539[20] = (char *(*)()) F811_6268;
	R5539[21] = (char *(*)()) F812_6268;
	R5539[22] = (char *(*)()) F813_6268;
	R5539[23] = (char *(*)()) F814_6268;
	R5539[24] = (char *(*)()) F815_6268;
	R5539[25] = (char *(*)()) F816_6268;
	R5539[26] = (char *(*)()) F817_6272;
	R5539[27] = (char *(*)()) F818_6272;
	R5539[28] = (char *(*)()) F819_6272;
	R5539[29] = (char *(*)()) F820_6272;
	R5539[30] = (char *(*)()) F821_6272;
	R5539[31] = (char *(*)()) F822_6272;
	R5539[32] = (char *(*)()) F823_6272;
	R5539[33] = (char *(*)()) F824_6272;
	R5539[34] = (char *(*)()) F825_6272;
	R5539[35] = (char *(*)()) F826_6272;
	R5539[36] = (char *(*)()) F827_6272;
	R5539[37] = (char *(*)()) F828_6272;
}

char *(*R5541[12])();
void R5541_init () {
	R5541[0] = (char *(*)()) F791_6245;
	R5541[1] = (char *(*)()) F792_6245;
	R5541[2] = (char *(*)()) F793_6245;
	R5541[3] = (char *(*)()) F794_6245;
	R5541[4] = (char *(*)()) F795_6245;
	R5541[5] = (char *(*)()) F796_6245;
	R5541[6] = (char *(*)()) F797_6245;
	R5541[7] = (char *(*)()) F798_6245;
	R5541[8] = (char *(*)()) F799_6245;
	R5541[9] = (char *(*)()) F800_6245;
	R5541[10] = (char *(*)()) F801_6245;
	R5541[11] = (char *(*)()) F802_6245;
}

char *(*R5549[12])();
void R5549_init () {
	R5549[0] = (char *(*)()) F805_6263;
	R5549[1] = (char *(*)()) F806_6263;
	R5549[2] = (char *(*)()) F807_6263;
	R5549[3] = (char *(*)()) F808_6263;
	R5549[4] = (char *(*)()) F809_6263;
	R5549[5] = (char *(*)()) F810_6263;
	R5549[6] = (char *(*)()) F811_6263;
	R5549[7] = (char *(*)()) F812_6263;
	R5549[8] = (char *(*)()) F813_6263;
	R5549[9] = (char *(*)()) F814_6263;
	R5549[10] = (char *(*)()) F815_6263;
	R5549[11] = (char *(*)()) F816_6263;
}

char *(*R5552[12])();
void R5552_init () {
	R5552[0] = (char *(*)()) F817_6269;
	R5552[1] = (char *(*)()) F818_6269;
	R5552[2] = (char *(*)()) F819_6269;
	R5552[3] = (char *(*)()) F820_6269;
	R5552[4] = (char *(*)()) F821_6269;
	R5552[5] = (char *(*)()) F822_6269;
	R5552[6] = (char *(*)()) F823_6269;
	R5552[7] = (char *(*)()) F824_6269;
	R5552[8] = (char *(*)()) F825_6269;
	R5552[9] = (char *(*)()) F826_6269;
	R5552[10] = (char *(*)()) F827_6269;
	R5552[11] = (char *(*)()) F828_6269;
}

char *(*R5674[12])();
void R5674_init () {
	R5674[0] = (char *(*)()) F835_6417;
	R5674[1] = (char *(*)()) F836_6417;
	R5674[2] = (char *(*)()) F837_6417;
	R5674[3] = (char *(*)()) F838_6417;
	R5674[4] = (char *(*)()) F839_6417;
	R5674[5] = (char *(*)()) F840_6417;
	R5674[6] = (char *(*)()) F841_6417;
	R5674[7] = (char *(*)()) F842_6417;
	R5674[8] = (char *(*)()) F843_6417;
	R5674[9] = (char *(*)()) F844_6417;
	R5674[10] = (char *(*)()) F845_6417;
	R5674[11] = (char *(*)()) F846_6417;
}

char *(*R5675[12])();
void R5675_init () {
	R5675[0] = (char *(*)()) F835_6418;
	R5675[1] = (char *(*)()) F836_6418;
	R5675[2] = (char *(*)()) F837_6418;
	R5675[3] = (char *(*)()) F838_6418;
	R5675[4] = (char *(*)()) F839_6418;
	R5675[5] = (char *(*)()) F840_6418;
	R5675[6] = (char *(*)()) F841_6418;
	R5675[7] = (char *(*)()) F842_6418;
	R5675[8] = (char *(*)()) F843_6418;
	R5675[9] = (char *(*)()) F844_6418;
	R5675[10] = (char *(*)()) F845_6418;
	R5675[11] = (char *(*)()) F846_6418;
}

char *(*R5677[12])();
void R5677_init () {
	R5677[0] = (char *(*)()) F835_6404;
	R5677[1] = (char *(*)()) F836_6404;
	R5677[2] = (char *(*)()) F837_6404;
	R5677[3] = (char *(*)()) F838_6404;
	R5677[4] = (char *(*)()) F839_6404;
	R5677[5] = (char *(*)()) F840_6404;
	R5677[6] = (char *(*)()) F841_6404;
	R5677[7] = (char *(*)()) F842_6404;
	R5677[8] = (char *(*)()) F843_6404;
	R5677[9] = (char *(*)()) F844_6404;
	R5677[10] = (char *(*)()) F845_6404;
	R5677[11] = (char *(*)()) F846_6404;
}

char *(*R5678[12])();
void R5678_init () {
	R5678[0] = (char *(*)()) F835_6405;
	R5678[1] = (char *(*)()) F836_6405_5678_250;
	R5678[2] = (char *(*)()) F837_6405_5678_250;
	R5678[3] = (char *(*)()) F838_6405_5678_250;
	R5678[4] = (char *(*)()) F839_6405_5678_250;
	R5678[5] = (char *(*)()) F840_6405_5678_250;
	R5678[6] = (char *(*)()) F841_6405_5678_250;
	R5678[7] = (char *(*)()) F842_6405_5678_250;
	R5678[8] = (char *(*)()) F843_6405_5678_250;
	R5678[9] = (char *(*)()) F844_6405_5678_250;
	R5678[10] = (char *(*)()) F845_6405_5678_250;
	R5678[11] = (char *(*)()) F846_6405_5678_250;
}
static void F836_6405_5678_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F836_6405(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F837_6405_5678_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F837_6405(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F838_6405_5678_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F838_6405(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F839_6405_5678_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F839_6405(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F840_6405_5678_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F840_6405(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F841_6405_5678_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F841_6405(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F842_6405_5678_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F842_6405(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F843_6405_5678_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F843_6405(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F844_6405_5678_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F844_6405(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F845_6405_5678_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F845_6405(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F846_6405_5678_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F846_6405(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R5687[12])();
void R5687_init () {
	R5687[0] = (char *(*)()) F835_6420;
	R5687[1] = (char *(*)()) F836_6420;
	R5687[2] = (char *(*)()) F837_6420;
	R5687[3] = (char *(*)()) F838_6420;
	R5687[4] = (char *(*)()) F839_6420;
	R5687[5] = (char *(*)()) F840_6420;
	R5687[6] = (char *(*)()) F841_6420;
	R5687[7] = (char *(*)()) F842_6420;
	R5687[8] = (char *(*)()) F843_6420;
	R5687[9] = (char *(*)()) F844_6420;
	R5687[10] = (char *(*)()) F845_6420;
	R5687[11] = (char *(*)()) F846_6420;
}

char *(*R5688[12])();
void R5688_init () {
	R5688[0] = (char *(*)()) F835_6422;
	R5688[1] = (char *(*)()) F836_6422_5688_250;
	R5688[2] = (char *(*)()) F837_6422_5688_250;
	R5688[3] = (char *(*)()) F838_6422_5688_250;
	R5688[4] = (char *(*)()) F839_6422_5688_250;
	R5688[5] = (char *(*)()) F840_6422_5688_250;
	R5688[6] = (char *(*)()) F841_6422_5688_250;
	R5688[7] = (char *(*)()) F842_6422_5688_250;
	R5688[8] = (char *(*)()) F843_6422_5688_250;
	R5688[9] = (char *(*)()) F844_6422_5688_250;
	R5688[10] = (char *(*)()) F845_6422_5688_250;
	R5688[11] = (char *(*)()) F846_6422_5688_250;
}
static void F836_6422_5688_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F836_6422(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F837_6422_5688_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F837_6422(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F838_6422_5688_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F838_6422(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F839_6422_5688_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F839_6422(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F840_6422_5688_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F840_6422(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F841_6422_5688_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F841_6422(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F842_6422_5688_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F842_6422(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F843_6422_5688_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F843_6422(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F844_6422_5688_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F844_6422(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F845_6422_5688_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F845_6422(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F846_6422_5688_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F846_6422(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R5689[12])();
void R5689_init () {
	R5689[0] = (char *(*)()) F835_6423;
	R5689[1] = (char *(*)()) F836_6423_5689_250;
	R5689[2] = (char *(*)()) F837_6423_5689_250;
	R5689[3] = (char *(*)()) F838_6423_5689_250;
	R5689[4] = (char *(*)()) F839_6423_5689_250;
	R5689[5] = (char *(*)()) F840_6423_5689_250;
	R5689[6] = (char *(*)()) F841_6423_5689_250;
	R5689[7] = (char *(*)()) F842_6423_5689_250;
	R5689[8] = (char *(*)()) F843_6423_5689_250;
	R5689[9] = (char *(*)()) F844_6423_5689_250;
	R5689[10] = (char *(*)()) F845_6423_5689_250;
	R5689[11] = (char *(*)()) F846_6423_5689_250;
}
static void F836_6423_5689_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F836_6423(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F837_6423_5689_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F837_6423(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F838_6423_5689_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F838_6423(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F839_6423_5689_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F839_6423(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F840_6423_5689_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F840_6423(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F841_6423_5689_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F841_6423(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F842_6423_5689_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F842_6423(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F843_6423_5689_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F843_6423(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F844_6423_5689_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F844_6423(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F845_6423_5689_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F845_6423(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F846_6423_5689_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F846_6423(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R5690[12])();
void R5690_init () {
	R5690[0] = (char *(*)()) F835_6424;
	R5690[1] = (char *(*)()) F836_6424_5690_4;
	R5690[2] = (char *(*)()) F837_6424_5690_4;
	R5690[3] = (char *(*)()) F838_6424_5690_4;
	R5690[4] = (char *(*)()) F839_6424_5690_4;
	R5690[5] = (char *(*)()) F840_6424_5690_4;
	R5690[6] = (char *(*)()) F841_6424_5690_4;
	R5690[7] = (char *(*)()) F842_6424_5690_4;
	R5690[8] = (char *(*)()) F843_6424_5690_4;
	R5690[9] = (char *(*)()) F844_6424_5690_4;
	R5690[10] = (char *(*)()) F845_6424_5690_4;
	R5690[11] = (char *(*)()) F846_6424_5690_4;
}
static void F836_6424_5690_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F836_6424(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F837_6424_5690_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F837_6424(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F838_6424_5690_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F838_6424(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F839_6424_5690_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F839_6424(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F840_6424_5690_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F840_6424(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F841_6424_5690_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F841_6424(Current, *(EIF_BOOLEAN *)arg1);
}
static void F842_6424_5690_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F842_6424(Current, *(EIF_POINTER *)arg1);
}
static void F843_6424_5690_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F843_6424(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F844_6424_5690_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F844_6424(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F845_6424_5690_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F845_6424(Current, *(EIF_REAL_32 *)arg1);
}
static void F846_6424_5690_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F846_6424(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R5692[12])();
void R5692_init () {
	R5692[0] = (char *(*)()) F835_6426;
	R5692[1] = (char *(*)()) F836_6426_5692_268;
	R5692[2] = (char *(*)()) F837_6426_5692_268;
	R5692[3] = (char *(*)()) F838_6426_5692_268;
	R5692[4] = (char *(*)()) F839_6426_5692_268;
	R5692[5] = (char *(*)()) F840_6426_5692_268;
	R5692[6] = (char *(*)()) F841_6426_5692_268;
	R5692[7] = (char *(*)()) F842_6426_5692_268;
	R5692[8] = (char *(*)()) F843_6426_5692_268;
	R5692[9] = (char *(*)()) F844_6426_5692_268;
	R5692[10] = (char *(*)()) F845_6426_5692_268;
	R5692[11] = (char *(*)()) F846_6426_5692_268;
}
static void F836_6426_5692_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F836_6426(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F837_6426_5692_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F837_6426(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F838_6426_5692_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F838_6426(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F839_6426_5692_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F839_6426(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F840_6426_5692_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F840_6426(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F841_6426_5692_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F841_6426(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F842_6426_5692_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F842_6426(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F843_6426_5692_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F843_6426(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F844_6426_5692_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F844_6426(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F845_6426_5692_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F845_6426(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F846_6426_5692_268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F846_6426(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R5695[12])();
void R5695_init () {
	R5695[0] = (char *(*)()) F835_6429;
	R5695[1] = (char *(*)()) F836_6429;
	R5695[2] = (char *(*)()) F837_6429;
	R5695[3] = (char *(*)()) F838_6429;
	R5695[4] = (char *(*)()) F839_6429;
	R5695[5] = (char *(*)()) F840_6429;
	R5695[6] = (char *(*)()) F841_6429;
	R5695[7] = (char *(*)()) F842_6429;
	R5695[8] = (char *(*)()) F843_6429;
	R5695[9] = (char *(*)()) F844_6429;
	R5695[10] = (char *(*)()) F845_6429;
	R5695[11] = (char *(*)()) F846_6429;
}

char *(*R5696[12])();
void R5696_init () {
	R5696[0] = (char *(*)()) F835_6430;
	R5696[1] = (char *(*)()) F836_6430;
	R5696[2] = (char *(*)()) F837_6430;
	R5696[3] = (char *(*)()) F838_6430;
	R5696[4] = (char *(*)()) F839_6430;
	R5696[5] = (char *(*)()) F840_6430;
	R5696[6] = (char *(*)()) F841_6430;
	R5696[7] = (char *(*)()) F842_6430;
	R5696[8] = (char *(*)()) F843_6430;
	R5696[9] = (char *(*)()) F844_6430;
	R5696[10] = (char *(*)()) F845_6430;
	R5696[11] = (char *(*)()) F846_6430;
}

char *(*R5697[12])();
void R5697_init () {
	R5697[0] = (char *(*)()) F835_6431;
	R5697[1] = (char *(*)()) F836_6431;
	R5697[2] = (char *(*)()) F837_6431;
	R5697[3] = (char *(*)()) F838_6431;
	R5697[4] = (char *(*)()) F839_6431;
	R5697[5] = (char *(*)()) F840_6431;
	R5697[6] = (char *(*)()) F841_6431;
	R5697[7] = (char *(*)()) F842_6431;
	R5697[8] = (char *(*)()) F843_6431;
	R5697[9] = (char *(*)()) F844_6431;
	R5697[10] = (char *(*)()) F845_6431;
	R5697[11] = (char *(*)()) F846_6431;
}

char *(*R5698[12])();
void R5698_init () {
	R5698[0] = (char *(*)()) F835_6432;
	R5698[1] = (char *(*)()) F836_6432;
	R5698[2] = (char *(*)()) F837_6432;
	R5698[3] = (char *(*)()) F838_6432;
	R5698[4] = (char *(*)()) F839_6432;
	R5698[5] = (char *(*)()) F840_6432;
	R5698[6] = (char *(*)()) F841_6432;
	R5698[7] = (char *(*)()) F842_6432;
	R5698[8] = (char *(*)()) F843_6432;
	R5698[9] = (char *(*)()) F844_6432;
	R5698[10] = (char *(*)()) F845_6432;
	R5698[11] = (char *(*)()) F846_6432;
}

char *(*R5699[12])();
void R5699_init () {
	R5699[0] = (char *(*)()) F835_6433;
	R5699[1] = (char *(*)()) F836_6433;
	R5699[2] = (char *(*)()) F837_6433;
	R5699[3] = (char *(*)()) F838_6433;
	R5699[4] = (char *(*)()) F839_6433;
	R5699[5] = (char *(*)()) F840_6433;
	R5699[6] = (char *(*)()) F841_6433;
	R5699[7] = (char *(*)()) F842_6433;
	R5699[8] = (char *(*)()) F843_6433;
	R5699[9] = (char *(*)()) F844_6433;
	R5699[10] = (char *(*)()) F845_6433;
	R5699[11] = (char *(*)()) F846_6433;
}

char *(*R5702[12])();
void R5702_init () {
	R5702[0] = (char *(*)()) F835_6436;
	R5702[1] = (char *(*)()) F836_6436;
	R5702[2] = (char *(*)()) F837_6436;
	R5702[3] = (char *(*)()) F838_6436;
	R5702[4] = (char *(*)()) F839_6436;
	R5702[5] = (char *(*)()) F840_6436;
	R5702[6] = (char *(*)()) F841_6436;
	R5702[7] = (char *(*)()) F842_6436;
	R5702[8] = (char *(*)()) F843_6436;
	R5702[9] = (char *(*)()) F844_6436;
	R5702[10] = (char *(*)()) F845_6436;
	R5702[11] = (char *(*)()) F846_6436;
}

char *(*R5705[12])();
void R5705_init () {
	R5705[0] = (char *(*)()) F835_6439;
	R5705[1] = (char *(*)()) F836_6439;
	R5705[2] = (char *(*)()) F837_6439;
	R5705[3] = (char *(*)()) F838_6439;
	R5705[4] = (char *(*)()) F839_6439;
	R5705[5] = (char *(*)()) F840_6439;
	R5705[6] = (char *(*)()) F841_6439;
	R5705[7] = (char *(*)()) F842_6439;
	R5705[8] = (char *(*)()) F843_6439;
	R5705[9] = (char *(*)()) F844_6439;
	R5705[10] = (char *(*)()) F845_6439;
	R5705[11] = (char *(*)()) F846_6439;
}

char *(*R5706[12])();
void R5706_init () {
	R5706[0] = (char *(*)()) F835_6440;
	R5706[1] = (char *(*)()) F836_6440_5706_150;
	R5706[2] = (char *(*)()) F837_6440_5706_150;
	R5706[3] = (char *(*)()) F838_6440_5706_150;
	R5706[4] = (char *(*)()) F839_6440_5706_150;
	R5706[5] = (char *(*)()) F840_6440_5706_150;
	R5706[6] = (char *(*)()) F841_6440_5706_150;
	R5706[7] = (char *(*)()) F842_6440_5706_150;
	R5706[8] = (char *(*)()) F843_6440_5706_150;
	R5706[9] = (char *(*)()) F844_6440_5706_150;
	R5706[10] = (char *(*)()) F845_6440_5706_150;
	R5706[11] = (char *(*)()) F846_6440_5706_150;
}
static EIF_REFERENCE F836_6440_5706_150 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F836_6440(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static EIF_REFERENCE F837_6440_5706_150 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F837_6440(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static EIF_REFERENCE F838_6440_5706_150 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F838_6440(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static EIF_REFERENCE F839_6440_5706_150 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F839_6440(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static EIF_REFERENCE F840_6440_5706_150 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F840_6440(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F841_6440_5706_150 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F841_6440(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static EIF_REFERENCE F842_6440_5706_150 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F842_6440(Current, *(EIF_POINTER *)arg1, arg2);
}
static EIF_REFERENCE F843_6440_5706_150 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F843_6440(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static EIF_REFERENCE F844_6440_5706_150 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F844_6440(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static EIF_REFERENCE F845_6440_5706_150 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F845_6440(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F846_6440_5706_150 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F846_6440(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R5708[12])();
void R5708_init () {
	R5708[0] = (char *(*)()) F835_6442;
	R5708[1] = (char *(*)()) F836_6442;
	R5708[2] = (char *(*)()) F837_6442;
	R5708[3] = (char *(*)()) F838_6442;
	R5708[4] = (char *(*)()) F839_6442;
	R5708[5] = (char *(*)()) F840_6442;
	R5708[6] = (char *(*)()) F841_6442;
	R5708[7] = (char *(*)()) F842_6442;
	R5708[8] = (char *(*)()) F843_6442;
	R5708[9] = (char *(*)()) F844_6442;
	R5708[10] = (char *(*)()) F845_6442;
	R5708[11] = (char *(*)()) F846_6442;
}

char *(*R5717[12])();
void R5717_init () {
	R5717[0] = (char *(*)()) F835_6452;
	R5717[1] = (char *(*)()) F836_6452;
	R5717[2] = (char *(*)()) F837_6452;
	R5717[3] = (char *(*)()) F838_6452;
	R5717[4] = (char *(*)()) F839_6452;
	R5717[5] = (char *(*)()) F840_6452;
	R5717[6] = (char *(*)()) F841_6452;
	R5717[7] = (char *(*)()) F842_6452;
	R5717[8] = (char *(*)()) F843_6452;
	R5717[9] = (char *(*)()) F844_6452;
	R5717[10] = (char *(*)()) F845_6452;
	R5717[11] = (char *(*)()) F846_6452;
}

char *(*R5738[10])();
void R5738_init () {
	{long i; for (i = 0; i < 2; i++) R5738[i] = (char *(*)()) F847_6474;}
	R5738[3] = (char *(*)()) F850_6505;
	R5738[4] = (char *(*)()) F851_6507;
	R5738[5] = (char *(*)()) F852_6515;
	R5738[6] = (char *(*)()) F853_6519;
	R5738[7] = (char *(*)()) F854_6521;
	R5738[8] = (char *(*)()) F855_6524;
	R5738[9] = (char *(*)()) F856_6526;
}

char *(*R5740[10])();
void R5740_init () {
	R5740[0] = (char *(*)()) F847_6476;
	R5740[1] = (char *(*)()) F848_6489;
	{long i; for (i = 3; i < 9; i++) R5740[i] = (char *(*)()) F849_6498;}
	R5740[9] = (char *(*)()) F856_6527;
}

char *(*R5741[10])();
void R5741_init () {
	{long i; for (i = 0; i < 2; i++) R5741[i] = (char *(*)()) F847_6477;}
	{long i; for (i = 3; i < 5; i++) R5741[i] = (char *(*)()) F849_6501;}
	R5741[5] = (char *(*)()) F852_6516;
	{long i; for (i = 6; i < 10; i++) R5741[i] = (char *(*)()) F849_6501;}
}

char *(*R5756[7])();
void R5756_init () {
	{long i; for (i = 0; i < 4; i++) R5756[i] = (char *(*)()) F849_6497;}
	R5756[4] = (char *(*)()) F854_6522;
	{long i; for (i = 5; i < 7; i++) R5756[i] = (char *(*)()) F849_6497;}
}

char *(*R5813[2])();
void R5813_init () {
	R5813[0] = (char *(*)()) F858_6587;
	R5813[1] = (char *(*)()) F859_6595;
}

char *(*R5814[2])();
void R5814_init () {
	R5814[0] = (char *(*)()) F858_6588;
	R5814[1] = (char *(*)()) F859_6596;
}

char *(*R5815[2])();
void R5815_init () {
	R5815[0] = (char *(*)()) F858_6589;
	R5815[1] = (char *(*)()) F859_6597;
}

char *(*R5816[2])();
void R5816_init () {
	R5816[0] = (char *(*)()) F858_6590;
	R5816[1] = (char *(*)()) F859_6598;
}

char *(*R5820[2])();
void R5820_init () {
	R5820[0] = (char *(*)()) F858_6586;
	R5820[1] = (char *(*)()) F859_6594;
}

char *(*R5878[38])();
void R5878_init () {
	R5878[0] = (char *(*)()) F969_7945_5878_1;
	R5878[1] = (char *(*)()) F970_7945_5878_1;
	R5878[12] = (char *(*)()) F981_8141_5878_1;
	R5878[13] = (char *(*)()) F982_8141_5878_1;
	R5878[15] = (char *(*)()) F984_8240_5878_1;
	R5878[16] = (char *(*)()) F985_8240_5878_1;
	R5878[18] = (char *(*)()) F987_8339_5878_1;
	R5878[19] = (char *(*)()) F988_8339_5878_1;
	R5878[21] = (char *(*)()) F990_8438_5878_1;
	R5878[22] = (char *(*)()) F991_8438_5878_1;
	R5878[36] = (char *(*)()) F1005_8895_5878_1;
	R5878[37] = (char *(*)()) F1006_8895_5878_1;
}
static EIF_REFERENCE F969_7945_5878_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F969_7945(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F970_7945_5878_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F970_7945(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F981_8141_5878_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F981_8141(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(981, 0x00).id, 981, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F982_8141_5878_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F982_8141(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(981, 0x00).id, 981, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F984_8240_5878_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F984_8240(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F985_8240_5878_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F985_8240(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F987_8339_5878_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F987_8339(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(987, 0x00).id, 987, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F988_8339_5878_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F988_8339(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(987, 0x00).id, 987, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F990_8438_5878_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F990_8438(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(990, 0x00).id, 990, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F991_8438_5878_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F991_8438(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(990, 0x00).id, 990, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1005_8895_5878_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1005_8895(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1006_8895_5878_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F1006_8895(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}

char *(*R6118[454])();
void R6118_init () {
	{long i; for (i = 0; i < 2; i++) R6118[i] = (char *(*)()) F919_7121;}
	R6118[453] = (char *(*)()) F1373_14088;
}

char *(*R6129[454])();
void R6129_init () {
	{long i; for (i = 0; i < 2; i++) R6129[i] = (char *(*)()) F919_7200;}
	R6129[453] = (char *(*)()) F1373_14119;
}

char *(*R6131[454])();
void R6131_init () {
	{long i; for (i = 0; i < 2; i++) R6131[i] = (char *(*)()) F919_7195;}
	R6131[453] = (char *(*)()) F1373_14111;
}

char *(*R6133[454])();
void R6133_init () {
	{long i; for (i = 0; i < 2; i++) R6133[i] = (char *(*)()) F919_7198;}
	R6133[453] = (char *(*)()) F1373_14109;
}

char *(*R6161[454])();
void R6161_init () {
	{long i; for (i = 0; i < 2; i++) R6161[i] = (char *(*)()) F919_7228;}
	R6161[453] = (char *(*)()) F1373_14106;
}

char *(*R6174[454])();
void R6174_init () {
	{long i; for (i = 0; i < 2; i++) R6174[i] = (char *(*)()) F919_7235;}
	R6174[453] = (char *(*)()) F1373_14100;
}

char *(*R6177[454])();
void R6177_init () {
	{long i; for (i = 0; i < 2; i++) R6177[i] = (char *(*)()) F919_7232;}
	R6177[453] = (char *(*)()) F1373_14097;
}

char *(*R6230[454])();
void R6230_init () {
	{long i; for (i = 0; i < 2; i++) R6230[i] = (char *(*)()) F919_7120;}
	R6230[453] = (char *(*)()) F1373_14087;
}

char *(*R6299[454])();
void R6299_init () {
	R6299[0] = (char *(*)()) F920_7361;
	R6299[1] = (char *(*)()) F919_7244;
	R6299[453] = (char *(*)()) F919_7244;
}

char *(*R6300[454])();
void R6300_init () {
	{long i; for (i = 0; i < 2; i++) R6300[i] = (char *(*)()) F919_7245;}
	R6300[453] = (char *(*)()) F1373_14143;
}

char *(*R6383[453])();
void R6383_init () {
	R6383[0] = (char *(*)()) F921_7413;
	R6383[452] = (char *(*)()) F1373_14085;
}

char *(*R6606[160])();
void R6606_init () {
	R6606[0] = (char *(*)()) F931_7651;
	R6606[1] = (char *(*)()) F932_7688;
	R6606[2] = (char *(*)()) F933_7730;
	R6606[3] = (char *(*)()) F934_7730;
	R6606[4] = (char *(*)()) F935_7730;
	R6606[5] = (char *(*)()) F936_7730;
	R6606[6] = (char *(*)()) F937_7730;
	R6606[7] = (char *(*)()) F938_7730;
	R6606[8] = (char *(*)()) F939_7730;
	R6606[9] = (char *(*)()) F940_7730;
	R6606[10] = (char *(*)()) F941_7730;
	R6606[11] = (char *(*)()) F942_7730;
	R6606[12] = (char *(*)()) F943_7730;
	R6606[13] = (char *(*)()) F944_7730;
	R6606[14] = (char *(*)()) F945_7730;
	R6606[15] = (char *(*)()) F946_7730;
	R6606[16] = (char *(*)()) F947_7730;
	R6606[17] = (char *(*)()) F948_7730;
	R6606[18] = (char *(*)()) F949_7730;
	R6606[19] = (char *(*)()) F950_7730;
	R6606[20] = (char *(*)()) F951_7730;
	R6606[21] = (char *(*)()) F952_7730;
	R6606[22] = (char *(*)()) F953_7730;
	R6606[23] = (char *(*)()) F954_7730;
	R6606[24] = (char *(*)()) F955_7730;
	R6606[25] = (char *(*)()) F956_7730;
	R6606[26] = (char *(*)()) F957_7730;
	R6606[27] = (char *(*)()) F958_7730;
	R6606[28] = (char *(*)()) F959_7730;
	R6606[29] = (char *(*)()) F960_7730;
	R6606[30] = (char *(*)()) F961_7730;
	R6606[31] = (char *(*)()) F962_7730;
	R6606[32] = (char *(*)()) F963_7730;
	R6606[33] = (char *(*)()) F964_7730;
	R6606[34] = (char *(*)()) F965_7730;
	R6606[35] = (char *(*)()) F966_7730;
	R6606[36] = (char *(*)()) F967_7782;
	{long i; for (i = 38; i < 40; i++) R6606[i] = (char *(*)()) F968_7889;}
	{long i; for (i = 41; i < 43; i++) R6606[i] = (char *(*)()) F971_7956;}
	{long i; for (i = 44; i < 46; i++) R6606[i] = (char *(*)()) F974_7997;}
	{long i; for (i = 47; i < 49; i++) R6606[i] = (char *(*)()) F977_8045;}
	{long i; for (i = 50; i < 52; i++) R6606[i] = (char *(*)()) F980_8066;}
	{long i; for (i = 53; i < 55; i++) R6606[i] = (char *(*)()) F983_8164;}
	{long i; for (i = 56; i < 58; i++) R6606[i] = (char *(*)()) F986_8263;}
	{long i; for (i = 59; i < 61; i++) R6606[i] = (char *(*)()) F989_8362;}
	{long i; for (i = 62; i < 64; i++) R6606[i] = (char *(*)()) F992_8461;}
	{long i; for (i = 65; i < 67; i++) R6606[i] = (char *(*)()) F995_8555;}
	{long i; for (i = 68; i < 70; i++) R6606[i] = (char *(*)()) F998_8649;}
	{long i; for (i = 71; i < 73; i++) R6606[i] = (char *(*)()) F1001_8744;}
	{long i; for (i = 74; i < 76; i++) R6606[i] = (char *(*)()) F1004_8839;}
	{long i; for (i = 76; i < 107; i++) R6606[i] = (char *(*)()) F1007_8905;}
	R6606[107] = (char *(*)()) F1038_8931;
	R6606[108] = (char *(*)()) F1039_8931;
	{long i; for (i = 110; i < 115; i++) R6606[i] = (char *(*)()) F1040_8939;}
	{long i; for (i = 119; i < 121; i++) R6606[i] = (char *(*)()) F1046_8998;}
	{long i; for (i = 122; i < 124; i++) R6606[i] = (char *(*)()) F1046_8998;}
	R6606[159] = (char *(*)()) F1090_9716;
}

char *(*R6681[34])();
void R6681_init () {
	R6681[0] = (char *(*)()) F933_7726;
	R6681[1] = (char *(*)()) F934_7726;
	R6681[2] = (char *(*)()) F935_7726;
	R6681[3] = (char *(*)()) F936_7726;
	R6681[4] = (char *(*)()) F937_7726;
	R6681[5] = (char *(*)()) F938_7726;
	R6681[6] = (char *(*)()) F939_7726;
	R6681[7] = (char *(*)()) F940_7726;
	R6681[8] = (char *(*)()) F941_7726;
	R6681[9] = (char *(*)()) F942_7726;
	R6681[10] = (char *(*)()) F943_7726;
	R6681[11] = (char *(*)()) F944_7726;
	R6681[12] = (char *(*)()) F945_7726;
	R6681[13] = (char *(*)()) F946_7726;
	R6681[14] = (char *(*)()) F947_7726;
	R6681[15] = (char *(*)()) F948_7726;
	R6681[16] = (char *(*)()) F949_7726;
	R6681[17] = (char *(*)()) F950_7726;
	R6681[18] = (char *(*)()) F951_7726;
	R6681[19] = (char *(*)()) F952_7726;
	R6681[20] = (char *(*)()) F953_7726;
	R6681[21] = (char *(*)()) F954_7726;
	R6681[22] = (char *(*)()) F955_7726;
	R6681[23] = (char *(*)()) F956_7726;
	R6681[24] = (char *(*)()) F957_7726;
	R6681[25] = (char *(*)()) F958_7726;
	R6681[26] = (char *(*)()) F959_7726;
	R6681[27] = (char *(*)()) F960_7726;
	R6681[28] = (char *(*)()) F961_7726;
	R6681[29] = (char *(*)()) F962_7726;
	R6681[30] = (char *(*)()) F963_7726;
	R6681[31] = (char *(*)()) F964_7726;
	R6681[32] = (char *(*)()) F965_7726;
	R6681[33] = (char *(*)()) F966_7726;
}

char *(*R6682[34])();
void R6682_init () {
	R6682[0] = (char *(*)()) F933_7727;
	R6682[1] = (char *(*)()) F934_7727;
	R6682[2] = (char *(*)()) F935_7727;
	R6682[3] = (char *(*)()) F936_7727;
	R6682[4] = (char *(*)()) F937_7727;
	R6682[5] = (char *(*)()) F938_7727;
	R6682[6] = (char *(*)()) F939_7727;
	R6682[7] = (char *(*)()) F940_7727;
	R6682[8] = (char *(*)()) F941_7727;
	R6682[9] = (char *(*)()) F942_7727;
	R6682[10] = (char *(*)()) F943_7727;
	R6682[11] = (char *(*)()) F944_7727;
	R6682[12] = (char *(*)()) F945_7727;
	R6682[13] = (char *(*)()) F946_7727;
	R6682[14] = (char *(*)()) F947_7727;
	R6682[15] = (char *(*)()) F948_7727;
	R6682[16] = (char *(*)()) F949_7727;
	R6682[17] = (char *(*)()) F950_7727;
	R6682[18] = (char *(*)()) F951_7727;
	R6682[19] = (char *(*)()) F952_7727;
	R6682[20] = (char *(*)()) F953_7727;
	R6682[21] = (char *(*)()) F954_7727;
	R6682[22] = (char *(*)()) F955_7727;
	R6682[23] = (char *(*)()) F956_7727;
	R6682[24] = (char *(*)()) F957_7727;
	R6682[25] = (char *(*)()) F958_7727;
	R6682[26] = (char *(*)()) F959_7727;
	R6682[27] = (char *(*)()) F960_7727;
	R6682[28] = (char *(*)()) F961_7727;
	R6682[29] = (char *(*)()) F962_7727;
	R6682[30] = (char *(*)()) F963_7727;
	R6682[31] = (char *(*)()) F964_7727;
	R6682[32] = (char *(*)()) F965_7727;
	R6682[33] = (char *(*)()) F966_7727;
}

char *(*R6683[34])();
void R6683_init () {
	R6683[0] = (char *(*)()) F933_7728;
	R6683[1] = (char *(*)()) F934_7728;
	R6683[2] = (char *(*)()) F935_7728;
	R6683[3] = (char *(*)()) F936_7728;
	R6683[4] = (char *(*)()) F937_7728;
	R6683[5] = (char *(*)()) F938_7728;
	R6683[6] = (char *(*)()) F939_7728;
	R6683[7] = (char *(*)()) F940_7728;
	R6683[8] = (char *(*)()) F941_7728;
	R6683[9] = (char *(*)()) F942_7728;
	R6683[10] = (char *(*)()) F943_7728;
	R6683[11] = (char *(*)()) F944_7728;
	R6683[12] = (char *(*)()) F945_7728;
	R6683[13] = (char *(*)()) F946_7728;
	R6683[14] = (char *(*)()) F947_7728;
	R6683[15] = (char *(*)()) F948_7728;
	R6683[16] = (char *(*)()) F949_7728;
	R6683[17] = (char *(*)()) F950_7728;
	R6683[18] = (char *(*)()) F951_7728;
	R6683[19] = (char *(*)()) F952_7728;
	R6683[20] = (char *(*)()) F953_7728;
	R6683[21] = (char *(*)()) F954_7728;
	R6683[22] = (char *(*)()) F955_7728;
	R6683[23] = (char *(*)()) F956_7728;
	R6683[24] = (char *(*)()) F957_7728;
	R6683[25] = (char *(*)()) F958_7728;
	R6683[26] = (char *(*)()) F959_7728;
	R6683[27] = (char *(*)()) F960_7728;
	R6683[28] = (char *(*)()) F961_7728;
	R6683[29] = (char *(*)()) F962_7728;
	R6683[30] = (char *(*)()) F963_7728;
	R6683[31] = (char *(*)()) F964_7728;
	R6683[32] = (char *(*)()) F965_7728;
	R6683[33] = (char *(*)()) F966_7728;
}

char *(*R6684[34])();
void R6684_init () {
	R6684[0] = (char *(*)()) F933_7729;
	R6684[1] = (char *(*)()) F934_7729;
	R6684[2] = (char *(*)()) F935_7729;
	R6684[3] = (char *(*)()) F936_7729;
	R6684[4] = (char *(*)()) F937_7729;
	R6684[5] = (char *(*)()) F938_7729;
	R6684[6] = (char *(*)()) F939_7729;
	R6684[7] = (char *(*)()) F940_7729;
	R6684[8] = (char *(*)()) F941_7729;
	R6684[9] = (char *(*)()) F942_7729;
	R6684[10] = (char *(*)()) F943_7729;
	R6684[11] = (char *(*)()) F944_7729;
	R6684[12] = (char *(*)()) F945_7729;
	R6684[13] = (char *(*)()) F946_7729;
	R6684[14] = (char *(*)()) F947_7729;
	R6684[15] = (char *(*)()) F948_7729;
	R6684[16] = (char *(*)()) F949_7729;
	R6684[17] = (char *(*)()) F950_7729;
	R6684[18] = (char *(*)()) F951_7729;
	R6684[19] = (char *(*)()) F952_7729;
	R6684[20] = (char *(*)()) F953_7729;
	R6684[21] = (char *(*)()) F954_7729;
	R6684[22] = (char *(*)()) F955_7729;
	R6684[23] = (char *(*)()) F956_7729;
	R6684[24] = (char *(*)()) F957_7729;
	R6684[25] = (char *(*)()) F958_7729;
	R6684[26] = (char *(*)()) F959_7729;
	R6684[27] = (char *(*)()) F960_7729;
	R6684[28] = (char *(*)()) F961_7729;
	R6684[29] = (char *(*)()) F962_7729;
	R6684[30] = (char *(*)()) F963_7729;
	R6684[31] = (char *(*)()) F964_7729;
	R6684[32] = (char *(*)()) F965_7729;
	R6684[33] = (char *(*)()) F966_7729;
}

char *(*R6689[34])();
void R6689_init () {
	R6689[0] = (char *(*)()) F933_7735;
	R6689[1] = (char *(*)()) F934_7735;
	R6689[2] = (char *(*)()) F935_7735;
	R6689[3] = (char *(*)()) F936_7735;
	R6689[4] = (char *(*)()) F937_7735;
	R6689[5] = (char *(*)()) F938_7735;
	R6689[6] = (char *(*)()) F939_7735;
	R6689[7] = (char *(*)()) F940_7735;
	R6689[8] = (char *(*)()) F941_7735;
	R6689[9] = (char *(*)()) F942_7735;
	R6689[10] = (char *(*)()) F943_7735;
	R6689[11] = (char *(*)()) F944_7735;
	R6689[12] = (char *(*)()) F945_7735;
	R6689[13] = (char *(*)()) F946_7735;
	R6689[14] = (char *(*)()) F947_7735;
	R6689[15] = (char *(*)()) F948_7735;
	R6689[16] = (char *(*)()) F949_7735;
	R6689[17] = (char *(*)()) F950_7735;
	R6689[18] = (char *(*)()) F951_7735;
	R6689[19] = (char *(*)()) F952_7735;
	R6689[20] = (char *(*)()) F953_7735;
	R6689[21] = (char *(*)()) F954_7735;
	R6689[22] = (char *(*)()) F955_7735;
	R6689[23] = (char *(*)()) F956_7735;
	R6689[24] = (char *(*)()) F957_7735;
	R6689[25] = (char *(*)()) F958_7735;
	R6689[26] = (char *(*)()) F959_7735;
	R6689[27] = (char *(*)()) F960_7735;
	R6689[28] = (char *(*)()) F961_7735;
	R6689[29] = (char *(*)()) F962_7735;
	R6689[30] = (char *(*)()) F963_7735;
	R6689[31] = (char *(*)()) F964_7735;
	R6689[32] = (char *(*)()) F965_7735;
	R6689[33] = (char *(*)()) F966_7735;
}

char *(*R6694[34])();
void R6694_init () {
	R6694[0] = (char *(*)()) F933_7743;
	R6694[1] = (char *(*)()) F934_7743_6694_1;
	R6694[2] = (char *(*)()) F935_7743_6694_1;
	R6694[3] = (char *(*)()) F936_7743_6694_1;
	R6694[4] = (char *(*)()) F937_7743_6694_1;
	R6694[5] = (char *(*)()) F938_7743_6694_1;
	R6694[6] = (char *(*)()) F939_7743_6694_1;
	R6694[7] = (char *(*)()) F940_7743_6694_1;
	R6694[8] = (char *(*)()) F941_7743_6694_1;
	R6694[9] = (char *(*)()) F942_7743_6694_1;
	R6694[10] = (char *(*)()) F943_7743_6694_1;
	R6694[11] = (char *(*)()) F944_7743_6694_1;
	R6694[12] = (char *(*)()) F945_7743_6694_1;
	R6694[13] = (char *(*)()) F946_7743_6694_1;
	R6694[14] = (char *(*)()) F947_7743_6694_1;
	R6694[15] = (char *(*)()) F948_7743_6694_1;
	R6694[16] = (char *(*)()) F949_7743;
	R6694[17] = (char *(*)()) F950_7743;
	R6694[18] = (char *(*)()) F951_7743;
	R6694[19] = (char *(*)()) F952_7743;
	R6694[20] = (char *(*)()) F953_7743_6694_1;
	R6694[21] = (char *(*)()) F954_7743_6694_1;
	R6694[22] = (char *(*)()) F955_7743_6694_1;
	R6694[23] = (char *(*)()) F956_7743_6694_1;
	R6694[24] = (char *(*)()) F957_7743_6694_1;
	R6694[25] = (char *(*)()) F958_7743_6694_1;
	R6694[26] = (char *(*)()) F959_7743_6694_1;
	R6694[27] = (char *(*)()) F960_7743_6694_1;
	R6694[28] = (char *(*)()) F961_7743_6694_1;
	R6694[29] = (char *(*)()) F962_7743_6694_1;
	R6694[30] = (char *(*)()) F963_7743_6694_1;
	R6694[31] = (char *(*)()) F964_7743_6694_1;
	R6694[32] = (char *(*)()) F965_7743_6694_1;
	R6694[33] = (char *(*)()) F966_7743_6694_1;
}
static EIF_REFERENCE F934_7743_6694_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F934_7743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F935_7743_6694_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REFERENCE* r = F935_7743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1008,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1008, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REFERENCE* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F936_7743_6694_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F936_7743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F937_7743_6694_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F937_7743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(1005, 0x00).id, 1005, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F938_7743_6694_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F938_7743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1002, 0x00).id, 1002, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F939_7743_6694_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F939_7743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(999, 0x00).id, 999, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F940_7743_6694_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F940_7743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(996, 0x00).id, 996, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F941_7743_6694_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F941_7743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(993, 0x00).id, 993, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F942_7743_6694_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F942_7743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(990, 0x00).id, 990, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F943_7743_6694_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F943_7743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(987, 0x00).id, 987, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F944_7743_6694_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F944_7743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(984, 0x00).id, 984, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F945_7743_6694_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F945_7743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(981, 0x00).id, 981, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F946_7743_6694_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F946_7743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(975, 0x00).id, 975, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F947_7743_6694_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F947_7743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F948_7743_6694_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F948_7743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F953_7743_6694_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16* r = F953_7743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1010,987,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1010, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F954_7743_6694_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER* r = F954_7743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1012,1038,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1012, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_POINTER* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F955_7743_6694_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8* r = F955_7743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1014,1002,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1014, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F956_7743_6694_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32* r = F956_7743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1016,1005,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1016, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F957_7743_6694_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64* r = F957_7743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1018,969,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1018, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F958_7743_6694_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN* r = F958_7743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1020,978,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1020, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_BOOLEAN* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F959_7743_6694_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64* r = F959_7743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1022,993,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1022, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F960_7743_6694_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32* r = F960_7743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1024,996,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1024, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F961_7743_6694_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16* r = F961_7743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1026,999,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1026, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F962_7743_6694_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8* r = F962_7743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1028,975,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1028, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F963_7743_6694_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8* r = F963_7743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1030,990,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1030, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F964_7743_6694_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32* r = F964_7743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1032,984,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1032, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F965_7743_6694_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64* r = F965_7743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1034,981,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1034, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F966_7743_6694_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32* r = F966_7743(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {1036,972,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 1036, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_32* *)Result = r;
		return Result;
	}
}

char *(*R6704[34])();
void R6704_init () {
	R6704[0] = (char *(*)()) F933_7755;
	R6704[1] = (char *(*)()) F934_7755;
	R6704[2] = (char *(*)()) F935_7755;
	R6704[3] = (char *(*)()) F936_7755;
	R6704[4] = (char *(*)()) F937_7755;
	R6704[5] = (char *(*)()) F938_7755;
	R6704[6] = (char *(*)()) F939_7755;
	R6704[7] = (char *(*)()) F940_7755;
	R6704[8] = (char *(*)()) F941_7755;
	R6704[9] = (char *(*)()) F942_7755;
	R6704[10] = (char *(*)()) F943_7755;
	R6704[11] = (char *(*)()) F944_7755;
	R6704[12] = (char *(*)()) F945_7755;
	R6704[13] = (char *(*)()) F946_7755;
	R6704[14] = (char *(*)()) F947_7755;
	R6704[15] = (char *(*)()) F948_7755;
	R6704[16] = (char *(*)()) F949_7755;
	R6704[17] = (char *(*)()) F950_7755;
	R6704[18] = (char *(*)()) F951_7755;
	R6704[19] = (char *(*)()) F952_7755;
	R6704[20] = (char *(*)()) F953_7755;
	R6704[21] = (char *(*)()) F954_7755;
	R6704[22] = (char *(*)()) F955_7755;
	R6704[23] = (char *(*)()) F956_7755;
	R6704[24] = (char *(*)()) F957_7755;
	R6704[25] = (char *(*)()) F958_7755;
	R6704[26] = (char *(*)()) F959_7755;
	R6704[27] = (char *(*)()) F960_7755;
	R6704[28] = (char *(*)()) F961_7755;
	R6704[29] = (char *(*)()) F962_7755;
	R6704[30] = (char *(*)()) F963_7755;
	R6704[31] = (char *(*)()) F964_7755;
	R6704[32] = (char *(*)()) F965_7755;
	R6704[33] = (char *(*)()) F966_7755;
}

char *(*R6846[2])();
void R6846_init () {
	R6846[0] = (char *(*)()) F969_7934;
	R6846[1] = (char *(*)()) F970_7934;
}

char *(*R6853[2])();
void R6853_init () {
	R6853[0] = (char *(*)()) F969_7938;
	R6853[1] = (char *(*)()) F970_7938;
}

char *(*R6867[2])();
void R6867_init () {
	R6867[0] = (char *(*)()) F972_7992;
	R6867[1] = (char *(*)()) F973_7992;
}

char *(*R6973[2])();
void R6973_init () {
	R6973[0] = (char *(*)()) F981_8148;
	R6973[1] = (char *(*)()) F982_8148;
}

char *(*R6976[2])();
void R6976_init () {
	R6976[0] = (char *(*)()) F981_8151;
	R6976[1] = (char *(*)()) F982_8151;
}

char *(*R7028[2])();
void R7028_init () {
	R7028[0] = (char *(*)()) F984_8246;
	R7028[1] = (char *(*)()) F985_8246;
}

char *(*R7029[2])();
void R7029_init () {
	R7029[0] = (char *(*)()) F984_8247;
	R7029[1] = (char *(*)()) F985_8247;
}

char *(*R7031[2])();
void R7031_init () {
	R7031[0] = (char *(*)()) F984_8249;
	R7031[1] = (char *(*)()) F985_8249;
}

char *(*R7033[2])();
void R7033_init () {
	R7033[0] = (char *(*)()) F984_8251;
	R7033[1] = (char *(*)()) F985_8251;
}

char *(*R7085[2])();
void R7085_init () {
	R7085[0] = (char *(*)()) F987_8346;
	R7085[1] = (char *(*)()) F988_8346;
}

char *(*R7088[2])();
void R7088_init () {
	R7088[0] = (char *(*)()) F987_8349;
	R7088[1] = (char *(*)()) F988_8349;
}

char *(*R7138[2])();
void R7138_init () {
	R7138[0] = (char *(*)()) F990_8442;
	R7138[1] = (char *(*)()) F991_8442;
}

char *(*R7141[2])();
void R7141_init () {
	R7141[0] = (char *(*)()) F990_8445;
	R7141[1] = (char *(*)()) F991_8445;
}

char *(*R7144[2])();
void R7144_init () {
	R7144[0] = (char *(*)()) F990_8448;
	R7144[1] = (char *(*)()) F991_8448;
}

char *(*R7198[2])();
void R7198_init () {
	R7198[0] = (char *(*)()) F993_8542;
	R7198[1] = (char *(*)()) F994_8542;
}

char *(*R7244[2])();
void R7244_init () {
	R7244[0] = (char *(*)()) F996_8630;
	R7244[1] = (char *(*)()) F997_8630;
}

char *(*R7245[2])();
void R7245_init () {
	R7245[0] = (char *(*)()) F996_8631;
	R7245[1] = (char *(*)()) F997_8631;
}

char *(*R7247[2])();
void R7247_init () {
	R7247[0] = (char *(*)()) F996_8633;
	R7247[1] = (char *(*)()) F997_8633;
}

char *(*R7250[2])();
void R7250_init () {
	R7250[0] = (char *(*)()) F996_8636;
	R7250[1] = (char *(*)()) F997_8636;
}

char *(*R7251[2])();
void R7251_init () {
	R7251[0] = (char *(*)()) F996_8637;
	R7251[1] = (char *(*)()) F997_8637;
}

char *(*R7299[2])();
void R7299_init () {
	R7299[0] = (char *(*)()) F999_8727;
	R7299[1] = (char *(*)()) F1000_8727;
}

char *(*R7300[2])();
void R7300_init () {
	R7300[0] = (char *(*)()) F999_8728;
	R7300[1] = (char *(*)()) F1000_8728;
}

char *(*R7303[2])();
void R7303_init () {
	R7303[0] = (char *(*)()) F999_8731;
	R7303[1] = (char *(*)()) F1000_8731;
}

char *(*R7351[2])();
void R7351_init () {
	R7351[0] = (char *(*)()) F1002_8821;
	R7351[1] = (char *(*)()) F1003_8821;
}

char *(*R7352[2])();
void R7352_init () {
	R7352[0] = (char *(*)()) F1002_8822;
	R7352[1] = (char *(*)()) F1003_8822;
}

char *(*R7353[2])();
void R7353_init () {
	R7353[0] = (char *(*)()) F1002_8823;
	R7353[1] = (char *(*)()) F1003_8823;
}

char *(*R7354[2])();
void R7354_init () {
	R7354[0] = (char *(*)()) F1002_8824;
	R7354[1] = (char *(*)()) F1003_8824;
}

char *(*R7356[2])();
void R7356_init () {
	R7356[0] = (char *(*)()) F1002_8826;
	R7356[1] = (char *(*)()) F1003_8826;
}

char *(*R7402[2])();
void R7402_init () {
	R7402[0] = (char *(*)()) F1005_8884;
	R7402[1] = (char *(*)()) F1006_8884;
}

char *(*R7409[2])();
void R7409_init () {
	R7409[0] = (char *(*)()) F1005_8888;
	R7409[1] = (char *(*)()) F1006_8888;
}

char *(*R7458[5])();
void R7458_init () {
	R7458[0] = (char *(*)()) F1041_8976;
	R7458[1] = (char *(*)()) F1042_8979;
	R7458[2] = (char *(*)()) F1043_8979;
	R7458[3] = (char *(*)()) F1044_8979;
	R7458[4] = (char *(*)()) F1043_8979;
}

char *(*R7482[4])();
void R7482_init () {
	R7482[0] = (char *(*)()) F1042_8978;
	R7482[1] = (char *(*)()) F1043_8978_7482_1;
	R7482[2] = (char *(*)()) F1044_8978_7482_1;
	R7482[3] = (char *(*)()) F1043_8978_7482_1;
}
static EIF_REFERENCE F1043_8978_7482_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1043_8978(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1044_8978_7482_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1044_8978(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R7483[4])();
void R7483_init () {
	R7483[0] = (char *(*)()) F1042_8980;
	R7483[1] = (char *(*)()) F1043_8980_7483_5;
	R7483[2] = (char *(*)()) F1044_8980_7483_5;
	R7483[3] = (char *(*)()) F1043_8980_7483_5;
}
static EIF_REFERENCE F1043_8980_7483_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1043_8980(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1044_8980_7483_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1044_8980(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R7487[4])();
void R7487_init () {
	R7487[0] = (char *(*)()) F1042_8987;
	R7487[1] = (char *(*)()) F1043_8987_7487_611;
	R7487[2] = (char *(*)()) F1044_8987_7487_611;
	R7487[3] = (char *(*)()) F1043_8987_7487_611;
}
static EIF_REFERENCE F1043_8987_7487_611 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1043_8987(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(978, 0x00).id, 978, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1044_8987_7487_611 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F1044_8987(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y7488_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7488_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7488_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y7488_pgtype3[] = {978,0xFFFF};
EIF_TYPE_INDEX *Y7488_gen_type [4];
EIF_TYPE_INDEX Y7488 [4];
void Y7488_init (void)
{
	egc_routines_types [7488] = Y7488;
	egc_routines_gen_types [7488] = Y7488_gen_type;
	egc_routines_offset [7488] = 1041;
	Y7488_gen_type [0] = Y7488_pgtype0;
	Y7488_gen_type [1] = Y7488_pgtype1;
	Y7488_gen_type [2] = Y7488_pgtype2;
	Y7488_gen_type [3] = Y7488_pgtype3;
	Y7488[3] = 978;
}

char *(*R7489[5])();
void R7489_init () {
	{long i; for (i = 0; i < 2; i++) R7489[i] = (char *(*)()) F1049_9119;}
	{long i; for (i = 3; i < 5; i++) R7489[i] = (char *(*)()) F1052_9286;}
}

char *(*R7491[5])();
void R7491_init () {
	R7491[0] = (char *(*)()) F1050_9180;
	R7491[1] = (char *(*)()) F1051_9203;
	R7491[3] = (char *(*)()) F1053_9346;
	R7491[4] = (char *(*)()) F1054_9368;
}

char *(*R7492[5])();
void R7492_init () {
	R7492[0] = (char *(*)()) F1050_9178;
	R7492[1] = (char *(*)()) F1051_9201;
	R7492[3] = (char *(*)()) F1053_9345;
	R7492[4] = (char *(*)()) F1054_9367;
}

char *(*R7493[5])();
void R7493_init () {
	{long i; for (i = 0; i < 2; i++) R7493[i] = (char *(*)()) F1049_9131;}
	{long i; for (i = 3; i < 5; i++) R7493[i] = (char *(*)()) F1046_8992;}
}

char *(*R7503[5])();
void R7503_init () {
	{long i; for (i = 0; i < 2; i++) R7503[i] = (char *(*)()) F1049_9149;}
	{long i; for (i = 3; i < 5; i++) R7503[i] = (char *(*)()) F1052_9317;}
}

char *(*R7505[5])();
void R7505_init () {
	{long i; for (i = 0; i < 2; i++) R7505[i] = (char *(*)()) F1049_9151;}
	{long i; for (i = 3; i < 5; i++) R7505[i] = (char *(*)()) F1052_9319;}
}

char *(*R7506[5])();
void R7506_init () {
	R7506[0] = (char *(*)()) F1050_9190;
	R7506[1] = (char *(*)()) F491_5233;
	R7506[3] = (char *(*)()) F1053_9355;
	R7506[4] = (char *(*)()) F492_5233;
}

char *(*R7508[5])();
void R7508_init () {
	{long i; for (i = 0; i < 2; i++) R7508[i] = (char *(*)()) F1049_9152;}
	{long i; for (i = 3; i < 5; i++) R7508[i] = (char *(*)()) F1052_9320;}
}

char *(*R7509[5])();
void R7509_init () {
	{long i; for (i = 0; i < 2; i++) R7509[i] = (char *(*)()) F1049_9153;}
	{long i; for (i = 3; i < 5; i++) R7509[i] = (char *(*)()) F1046_9009;}
}

char *(*R7528[5])();
void R7528_init () {
	{long i; for (i = 0; i < 2; i++) R7528[i] = (char *(*)()) F1049_9140;}
	{long i; for (i = 3; i < 5; i++) R7528[i] = (char *(*)()) F1052_9308;}
}

char *(*R7529[5])();
void R7529_init () {
	{long i; for (i = 0; i < 2; i++) R7529[i] = (char *(*)()) F1049_9139;}
	{long i; for (i = 3; i < 5; i++) R7529[i] = (char *(*)()) F1052_9307;}
}

char *(*R7539[5])();
void R7539_init () {
	{long i; for (i = 0; i < 2; i++) R7539[i] = (char *(*)()) F1049_9136;}
	{long i; for (i = 3; i < 5; i++) R7539[i] = (char *(*)()) F1052_9304;}
}

char *(*R7550[5])();
void R7550_init () {
	R7550[0] = (char *(*)()) F1050_9185;
	R7550[1] = (char *(*)()) F1051_9269;
	R7550[4] = (char *(*)()) F1054_9434;
}

char *(*R7551[2])();
void R7551_init () {
	R7551[0] = (char *(*)()) F1050_9186;
	R7551[1] = (char *(*)()) F1051_9270;
}

char *(*R7569[5])();
void R7569_init () {
	R7569[0] = (char *(*)()) F1050_9187;
	R7569[1] = (char *(*)()) F1051_9281;
	R7569[3] = (char *(*)()) F1053_9353;
	R7569[4] = (char *(*)()) F1054_9446;
}

char *(*R7573[5])();
void R7573_init () {
	R7573[0] = (char *(*)()) F1050_9191;
	R7573[1] = (char *(*)()) F1051_9284;
	R7573[3] = (char *(*)()) F1053_9357;
	R7573[4] = (char *(*)()) F1054_9450;
}

char *(*R7584[4])();
void R7584_init () {
	R7584[0] = (char *(*)()) F1051_9283;
	R7584[3] = (char *(*)()) F1054_9448;
}

char *(*R7587[4])();
void R7587_init () {
	R7587[0] = (char *(*)()) F1051_9222;
	R7587[3] = (char *(*)()) F1054_9387;
}

char *(*R7599[4])();
void R7599_init () {
	R7599[0] = (char *(*)()) F1051_9233;
	R7599[3] = (char *(*)()) F1054_9398;
}

char *(*R7617[4])();
void R7617_init () {
	R7617[0] = (char *(*)()) F1051_9266;
	R7617[3] = (char *(*)()) F1054_9431;
}

char *(*R7645[2])();
void R7645_init () {
	R7645[0] = (char *(*)()) F1050_9193;
	R7645[1] = (char *(*)()) F1049_9170;
}

char *(*R7717[2])();
void R7717_init () {
	R7717[0] = (char *(*)()) F1053_9348;
	R7717[1] = (char *(*)()) F1054_9418;
}

char *(*R7725[2])();
void R7725_init () {
	R7725[0] = (char *(*)()) F1053_9359;
	R7725[1] = (char *(*)()) F1052_9338;
}

char *(*R7816[2])();
void R7816_init () {
	R7816[0] = (char *(*)()) F1156_10608;
	R7816[1] = (char *(*)()) F1157_10629;
}

char *(*R7827[44])();
void R7827_init () {
	R7827[0] = (char *(*)()) F1133_10305;
	{long i; for (i = 1; i < 3; i++) R7827[i] = (char *(*)()) F1134_10307;}
	R7827[3] = (char *(*)()) F1136_10357;
	R7827[4] = (char *(*)()) F1137_10365;
	R7827[6] = (char *(*)()) F1139_10389;
	R7827[7] = (char *(*)()) F1140_10422;
	R7827[11] = (char *(*)()) F1142_10448;
	{long i; for (i = 12; i < 14; i++) R7827[i] = (char *(*)()) F1145_10467;}
	R7827[15] = (char *(*)()) F1145_10467;
	R7827[43] = (char *(*)()) F1176_10783;
}

char *(*R7829[4])();
void R7829_init () {
	R7829[0] = (char *(*)()) F1159_10670;
	R7829[3] = (char *(*)()) F1162_10678;
}

char *(*R7831[54])();
void R7831_init () {
	R7831[0] = (char *(*)()) F1133_10305;
	{long i; for (i = 1; i < 3; i++) R7831[i] = (char *(*)()) F1134_10307;}
	R7831[3] = (char *(*)()) F1136_10357;
	R7831[4] = (char *(*)()) F1137_10365;
	R7831[6] = (char *(*)()) F1139_10389;
	R7831[7] = (char *(*)()) F1140_10422;
	R7831[11] = (char *(*)()) F1142_10448;
	{long i; for (i = 12; i < 14; i++) R7831[i] = (char *(*)()) F1145_10467;}
	R7831[15] = (char *(*)()) F1145_10467;
	R7831[18] = (char *(*)()) F1151_10538;
	R7831[19] = (char *(*)()) F1152_10561;
	R7831[20] = (char *(*)()) F1153_10568;
	R7831[23] = (char *(*)()) F1156_10608;
	R7831[24] = (char *(*)()) F1157_10629;
	R7831[26] = (char *(*)()) F1159_10670;
	R7831[29] = (char *(*)()) F1162_10678;
	R7831[34] = (char *(*)()) F1167_10702;
	R7831[37] = (char *(*)()) F1170_10723;
	R7831[43] = (char *(*)()) F1176_10783;
	R7831[53] = (char *(*)()) F1186_10847;
}

char *(*R7837[17])();
void R7837_init () {
	R7837[0] = (char *(*)()) F1170_10723;
	R7837[16] = (char *(*)()) F1186_10847;
}

char *(*R7843[9])();
void R7843_init () {
	R7843[0] = (char *(*)()) F1140_10422;
	R7843[4] = (char *(*)()) F1142_10448;
	{long i; for (i = 5; i < 7; i++) R7843[i] = (char *(*)()) F1145_10467;}
	R7843[8] = (char *(*)()) F1145_10467;
}

char *(*R7848[44])();
void R7848_init () {
	R7848[0] = (char *(*)()) F1133_10305;
	{long i; for (i = 1; i < 3; i++) R7848[i] = (char *(*)()) F1134_10307;}
	R7848[3] = (char *(*)()) F1136_10357;
	R7848[4] = (char *(*)()) F1137_10365;
	R7848[6] = (char *(*)()) F1139_10389;
	R7848[7] = (char *(*)()) F1140_10422;
	R7848[11] = (char *(*)()) F1142_10448;
	{long i; for (i = 12; i < 14; i++) R7848[i] = (char *(*)()) F1145_10467;}
	R7848[15] = (char *(*)()) F1145_10467;
	R7848[18] = (char *(*)()) F1151_10538;
	R7848[19] = (char *(*)()) F1152_10561;
	R7848[20] = (char *(*)()) F1153_10568;
	R7848[23] = (char *(*)()) F1156_10608;
	R7848[24] = (char *(*)()) F1157_10629;
	R7848[26] = (char *(*)()) F1159_10670;
	R7848[29] = (char *(*)()) F1162_10678;
	R7848[43] = (char *(*)()) F1176_10783;
}

char *(*R7891[101])();
void R7891_init () {
	R7891[0] = (char *(*)()) F1086_9634;
	R7891[1] = (char *(*)()) F1087_9640;
	R7891[3] = (char *(*)()) F1089_9680;
	R7891[4] = (char *(*)()) F1090_9721;
	R7891[5] = (char *(*)()) F1091_9737;
	R7891[6] = (char *(*)()) F1092_9766;
	R7891[7] = (char *(*)()) F1093_9779;
	R7891[9] = (char *(*)()) F1095_9807;
	R7891[14] = (char *(*)()) F1099_9870;
	R7891[31] = (char *(*)()) F1117_10060;
	R7891[33] = (char *(*)()) F1119_10079;
	R7891[47] = (char *(*)()) F1133_10305;
	{long i; for (i = 48; i < 50; i++) R7891[i] = (char *(*)()) F1134_10307;}
	R7891[50] = (char *(*)()) F1136_10357;
	R7891[51] = (char *(*)()) F1137_10365;
	R7891[53] = (char *(*)()) F1139_10389;
	R7891[54] = (char *(*)()) F1140_10422;
	R7891[58] = (char *(*)()) F1142_10448;
	{long i; for (i = 59; i < 61; i++) R7891[i] = (char *(*)()) F1145_10467;}
	R7891[62] = (char *(*)()) F1145_10467;
	R7891[65] = (char *(*)()) F1151_10538;
	R7891[66] = (char *(*)()) F1152_10561;
	R7891[67] = (char *(*)()) F1153_10568;
	R7891[70] = (char *(*)()) F1156_10608;
	R7891[71] = (char *(*)()) F1157_10629;
	R7891[73] = (char *(*)()) F1159_10670;
	R7891[76] = (char *(*)()) F1162_10678;
	R7891[81] = (char *(*)()) F1167_10702;
	R7891[84] = (char *(*)()) F1170_10723;
	R7891[90] = (char *(*)()) F1176_10783;
	R7891[100] = (char *(*)()) F1186_10847;
}

char *(*R7893[101])();
void R7893_init () {
	R7893[0] = (char *(*)()) F1086_9636;
	R7893[1] = (char *(*)()) F1087_9641;
	R7893[3] = (char *(*)()) F1089_9679;
	R7893[4] = (char *(*)()) F1090_9723;
	R7893[5] = (char *(*)()) F1091_9736;
	R7893[6] = (char *(*)()) F1092_9768;
	R7893[7] = (char *(*)()) F1093_9782;
	R7893[9] = (char *(*)()) F1095_9809;
	R7893[14] = (char *(*)()) F1099_9872;
	R7893[31] = (char *(*)()) F1117_10062;
	R7893[33] = (char *(*)()) F1119_10080;
	R7893[47] = (char *(*)()) F1133_10306;
	{long i; for (i = 48; i < 50; i++) R7893[i] = (char *(*)()) F1134_10308;}
	R7893[50] = (char *(*)()) F1136_10358;
	R7893[51] = (char *(*)()) F1137_10366;
	R7893[53] = (char *(*)()) F1139_10390;
	R7893[54] = (char *(*)()) F1140_10426;
	R7893[58] = (char *(*)()) F1142_10449;
	{long i; for (i = 59; i < 61; i++) R7893[i] = (char *(*)()) F1145_10468;}
	R7893[62] = (char *(*)()) F1145_10468;
	R7893[65] = (char *(*)()) F1151_10539;
	R7893[66] = (char *(*)()) F1152_10562;
	R7893[67] = (char *(*)()) F1153_10569;
	R7893[70] = (char *(*)()) F1156_10609;
	R7893[71] = (char *(*)()) F1157_10630;
	R7893[73] = (char *(*)()) F1159_10671;
	R7893[76] = (char *(*)()) F1162_10679;
	R7893[81] = (char *(*)()) F1167_10703;
	R7893[84] = (char *(*)()) F1170_10724;
	R7893[90] = (char *(*)()) F1176_10773;
	R7893[100] = (char *(*)()) F1186_10848;
}

char *(*R7894[101])();
void R7894_init () {
	R7894[0] = (char *(*)()) F1086_9635;
	R7894[1] = (char *(*)()) F1087_9642;
	R7894[3] = (char *(*)()) F1089_9678;
	R7894[4] = (char *(*)()) F1090_9722;
	R7894[5] = (char *(*)()) F1091_9735;
	R7894[6] = (char *(*)()) F1092_9767;
	R7894[7] = (char *(*)()) F1093_9781;
	R7894[9] = (char *(*)()) F1095_9808;
	R7894[14] = (char *(*)()) F1099_9871;
	R7894[31] = (char *(*)()) F1117_10061;
	R7894[33] = (char *(*)()) F1118_10071;
	{long i; for (i = 47; i < 52; i++) R7894[i] = (char *(*)()) F928_7616;}
	{long i; for (i = 53; i < 55; i++) R7894[i] = (char *(*)()) F928_7616;}
	R7894[58] = (char *(*)()) F1143_10450;
	{long i; for (i = 59; i < 61; i++) R7894[i] = (char *(*)()) F928_7616;}
	R7894[62] = (char *(*)()) F1147_10477;
	{long i; for (i = 65; i < 68; i++) R7894[i] = (char *(*)()) F928_7616;}
	{long i; for (i = 70; i < 72; i++) R7894[i] = (char *(*)()) F928_7616;}
	R7894[73] = (char *(*)()) F928_7616;
	R7894[76] = (char *(*)()) F928_7616;
	R7894[81] = (char *(*)()) F928_7616;
	R7894[84] = (char *(*)()) F928_7616;
	R7894[90] = (char *(*)()) F928_7616;
	R7894[100] = (char *(*)()) F928_7616;
}

char *(*R7895[101])();
void R7895_init () {
	{long i; for (i = 0; i < 2; i++) R7895[i] = (char *(*)()) F1083_9575;}
	{long i; for (i = 3; i < 8; i++) R7895[i] = (char *(*)()) F1083_9575;}
	R7895[9] = (char *(*)()) F1083_9575;
	R7895[14] = (char *(*)()) F1099_9833;
	R7895[31] = (char *(*)()) F1083_9575;
	R7895[33] = (char *(*)()) F1083_9575;
	{long i; for (i = 47; i < 52; i++) R7895[i] = (char *(*)()) F1083_9575;}
	R7895[53] = (char *(*)()) F1083_9575;
	R7895[54] = (char *(*)()) F1140_10392;
	R7895[58] = (char *(*)()) F1143_10451;
	{long i; for (i = 59; i < 61; i++) R7895[i] = (char *(*)()) F1145_10454;}
	R7895[62] = (char *(*)()) F1148_10509;
	{long i; for (i = 65; i < 68; i++) R7895[i] = (char *(*)()) F1083_9575;}
	{long i; for (i = 70; i < 72; i++) R7895[i] = (char *(*)()) F1083_9575;}
	R7895[73] = (char *(*)()) F1083_9575;
	R7895[76] = (char *(*)()) F1083_9575;
	R7895[81] = (char *(*)()) F1083_9575;
	R7895[84] = (char *(*)()) F1083_9575;
	R7895[90] = (char *(*)()) F1083_9575;
	R7895[100] = (char *(*)()) F1083_9575;
}

char *(*R8074[54])();
void R8074_init () {
	{long i; for (i = 0; i < 5; i++) R8074[i] = (char *(*)()) F1127_10191;}
	{long i; for (i = 6; i < 8; i++) R8074[i] = (char *(*)()) F1127_10191;}
	{long i; for (i = 11; i < 14; i++) R8074[i] = (char *(*)()) F1127_10191;}
	R8074[15] = (char *(*)()) F1127_10191;
	{long i; for (i = 18; i < 21; i++) R8074[i] = (char *(*)()) F1127_10191;}
	{long i; for (i = 23; i < 25; i++) R8074[i] = (char *(*)()) F1127_10191;}
	R8074[26] = (char *(*)()) F1127_10191;
	R8074[29] = (char *(*)()) F1127_10191;
	R8074[34] = (char *(*)()) F1166_10701;
	R8074[37] = (char *(*)()) F1163_10680;
	R8074[43] = (char *(*)()) F1127_10191;
	R8074[53] = (char *(*)()) F1186_10842;
}

char *(*R8076[54])();
void R8076_init () {
	{long i; for (i = 0; i < 4; i++) R8076[i] = (char *(*)()) F1096_9813;}
	R8076[4] = (char *(*)()) F1137_10360;
	{long i; for (i = 6; i < 8; i++) R8076[i] = (char *(*)()) F1096_9813;}
	{long i; for (i = 11; i < 14; i++) R8076[i] = (char *(*)()) F1096_9813;}
	R8076[15] = (char *(*)()) F1147_10483;
	{long i; for (i = 18; i < 21; i++) R8076[i] = (char *(*)()) F1096_9813;}
	{long i; for (i = 23; i < 25; i++) R8076[i] = (char *(*)()) F1096_9813;}
	R8076[26] = (char *(*)()) F1159_10665;
	R8076[29] = (char *(*)()) F1159_10665;
	R8076[34] = (char *(*)()) F1096_9813;
	R8076[37] = (char *(*)()) F1170_10718;
	R8076[43] = (char *(*)()) F1096_9813;
	R8076[53] = (char *(*)()) F1170_10718;
}

char *(*R8133[60])();
void R8133_init () {
	R8133[0] = (char *(*)()) F1101_9877;
	{long i; for (i = 16; i < 21; i++) R8133[i] = (char *(*)()) F1101_9877;}
	{long i; for (i = 22; i < 24; i++) R8133[i] = (char *(*)()) F1101_9877;}
	{long i; for (i = 27; i < 30; i++) R8133[i] = (char *(*)()) F1101_9877;}
	R8133[31] = (char *(*)()) F1147_10481;
	{long i; for (i = 34; i < 37; i++) R8133[i] = (char *(*)()) F1101_9877;}
	{long i; for (i = 39; i < 41; i++) R8133[i] = (char *(*)()) F1101_9877;}
	R8133[42] = (char *(*)()) F1101_9877;
	R8133[45] = (char *(*)()) F1101_9877;
	R8133[59] = (char *(*)()) F1101_9877;
}

char *(*R8134[60])();
void R8134_init () {
	R8134[0] = (char *(*)()) F1101_9878;
	{long i; for (i = 16; i < 21; i++) R8134[i] = (char *(*)()) F1101_9878;}
	{long i; for (i = 22; i < 24; i++) R8134[i] = (char *(*)()) F1101_9878;}
	{long i; for (i = 27; i < 30; i++) R8134[i] = (char *(*)()) F1101_9878;}
	R8134[31] = (char *(*)()) F1147_10482;
	{long i; for (i = 34; i < 37; i++) R8134[i] = (char *(*)()) F1101_9878;}
	{long i; for (i = 39; i < 41; i++) R8134[i] = (char *(*)()) F1101_9878;}
	R8134[42] = (char *(*)()) F1101_9878;
	R8134[45] = (char *(*)()) F1101_9878;
	R8134[59] = (char *(*)()) F1101_9878;
}

char *(*R8135[60])();
void R8135_init () {
	R8135[0] = (char *(*)()) F1101_9879;
	{long i; for (i = 16; i < 21; i++) R8135[i] = (char *(*)()) F1101_9879;}
	{long i; for (i = 22; i < 24; i++) R8135[i] = (char *(*)()) F1101_9879;}
	{long i; for (i = 27; i < 30; i++) R8135[i] = (char *(*)()) F1101_9879;}
	R8135[31] = (char *(*)()) F1147_10485;
	{long i; for (i = 34; i < 37; i++) R8135[i] = (char *(*)()) F1101_9879;}
	{long i; for (i = 39; i < 41; i++) R8135[i] = (char *(*)()) F1101_9879;}
	R8135[42] = (char *(*)()) F1101_9879;
	R8135[45] = (char *(*)()) F1101_9879;
	R8135[59] = (char *(*)()) F1101_9879;
}

char *(*R8136[60])();
void R8136_init () {
	R8136[0] = (char *(*)()) F1101_9880;
	{long i; for (i = 16; i < 21; i++) R8136[i] = (char *(*)()) F1101_9880;}
	{long i; for (i = 22; i < 24; i++) R8136[i] = (char *(*)()) F1101_9880;}
	{long i; for (i = 27; i < 30; i++) R8136[i] = (char *(*)()) F1101_9880;}
	R8136[31] = (char *(*)()) F1147_10484;
	{long i; for (i = 34; i < 37; i++) R8136[i] = (char *(*)()) F1101_9880;}
	{long i; for (i = 39; i < 41; i++) R8136[i] = (char *(*)()) F1101_9880;}
	R8136[42] = (char *(*)()) F1101_9880;
	R8136[45] = (char *(*)()) F1101_9880;
	R8136[59] = (char *(*)()) F1101_9880;
}

char *(*R8398[16])();
void R8398_init () {
	{long i; for (i = 0; i < 3; i++) R8398[i] = (char *(*)()) F1125_10156;}
	{long i; for (i = 3; i < 5; i++) R8398[i] = (char *(*)()) F1128_10232;}
	{long i; for (i = 6; i < 8; i++) R8398[i] = (char *(*)()) F1128_10232;}
	{long i; for (i = 11; i < 14; i++) R8398[i] = (char *(*)()) F1128_10232;}
	R8398[15] = (char *(*)()) F1128_10232;
}

char *(*R8401[16])();
void R8401_init () {
	{long i; for (i = 0; i < 3; i++) R8401[i] = (char *(*)()) F1125_10165;}
	{long i; for (i = 3; i < 5; i++) R8401[i] = (char *(*)()) F1136_10354;}
	{long i; for (i = 6; i < 8; i++) R8401[i] = (char *(*)()) F1136_10354;}
	{long i; for (i = 11; i < 14; i++) R8401[i] = (char *(*)()) F1136_10354;}
	R8401[15] = (char *(*)()) F1136_10354;
}

char *(*R8823[174])();
void R8823_init () {
	R8823[0] = (char *(*)()) F1194_10990;
	R8823[5] = (char *(*)()) F1199_11066;
	R8823[7] = (char *(*)()) F1201_11122;
	R8823[10] = (char *(*)()) F1204_11149;
	R8823[12] = (char *(*)()) F1206_11244;
	R8823[14] = (char *(*)()) F1207_11262;
	R8823[17] = (char *(*)()) F1211_11309;
	R8823[19] = (char *(*)()) F1213_11514;
	R8823[23] = (char *(*)()) F1214_11566;
	R8823[63] = (char *(*)()) F1214_11566;
	{long i; for (i = 86; i < 88; i++) R8823[i] = (char *(*)()) F1269_12302;}
	{long i; for (i = 92; i < 94; i++) R8823[i] = (char *(*)()) F1269_12302;}
	R8823[95] = (char *(*)()) F1269_12302;
	R8823[100] = (char *(*)()) F1294_12635;
	{long i; for (i = 102; i < 104; i++) R8823[i] = (char *(*)()) F1294_12635;}
	{long i; for (i = 125; i < 127; i++) R8823[i] = (char *(*)()) F1267_12243;}
	R8823[130] = (char *(*)()) F1267_12243;
	R8823[132] = (char *(*)()) F1267_12243;
	R8823[134] = (char *(*)()) F1267_12243;
	R8823[137] = (char *(*)()) F1267_12243;
	R8823[147] = (char *(*)()) F1340_13508;
	R8823[153] = (char *(*)()) F1340_13508;
	R8823[157] = (char *(*)()) F1351_13581;
	R8823[170] = (char *(*)()) F1364_13866;
	R8823[172] = (char *(*)()) F1366_13949;
	R8823[173] = (char *(*)()) F1367_14035;
}

char *(*R9365[150])();
void R9365_init () {
	R9365[0] = (char *(*)()) F1214_11575;
	R9365[40] = (char *(*)()) F1214_11575;
	{long i; for (i = 63; i < 65; i++) R9365[i] = (char *(*)()) F1279_12414;}
	R9365[69] = (char *(*)()) F1214_11575;
	R9365[70] = (char *(*)()) F1287_12458;
	R9365[72] = (char *(*)()) F1289_12502;
	R9365[77] = (char *(*)()) F1214_11575;
	{long i; for (i = 79; i < 81; i++) R9365[i] = (char *(*)()) F1214_11575;}
	R9365[102] = (char *(*)()) F1319_13065;
	R9365[103] = (char *(*)()) F1320_13092;
	R9365[107] = (char *(*)()) F1324_13158;
	R9365[109] = (char *(*)()) F1214_11575;
	R9365[111] = (char *(*)()) F1328_13350;
	R9365[114] = (char *(*)()) F1328_13350;
	R9365[124] = (char *(*)()) F1341_13513;
	R9365[130] = (char *(*)()) F1347_13529;
	R9365[134] = (char *(*)()) F1347_13529;
	R9365[147] = (char *(*)()) F1214_11575;
	R9365[149] = (char *(*)()) F1214_11575;
}

char *(*R9367[150])();
void R9367_init () {
	R9367[0] = (char *(*)()) F1214_11578;
	R9367[40] = (char *(*)()) F1214_11578;
	{long i; for (i = 63; i < 65; i++) R9367[i] = (char *(*)()) F1214_11578;}
	{long i; for (i = 69; i < 71; i++) R9367[i] = (char *(*)()) F1214_11578;}
	R9367[72] = (char *(*)()) F1214_11578;
	R9367[77] = (char *(*)()) F1214_11578;
	{long i; for (i = 79; i < 81; i++) R9367[i] = (char *(*)()) F1214_11578;}
	{long i; for (i = 102; i < 104; i++) R9367[i] = (char *(*)()) F1214_11578;}
	R9367[107] = (char *(*)()) F1214_11578;
	R9367[109] = (char *(*)()) F1326_13263;
	R9367[111] = (char *(*)()) F1214_11578;
	R9367[114] = (char *(*)()) F1214_11578;
	R9367[124] = (char *(*)()) F1214_11578;
	R9367[130] = (char *(*)()) F1214_11578;
	R9367[134] = (char *(*)()) F1214_11578;
	R9367[147] = (char *(*)()) F1364_13867;
	R9367[149] = (char *(*)()) F1366_13950;
}

char *(*R9368[150])();
void R9368_init () {
	R9368[0] = (char *(*)()) F1214_11579;
	R9368[40] = (char *(*)()) F1214_11579;
	{long i; for (i = 63; i < 65; i++) R9368[i] = (char *(*)()) F1214_11579;}
	{long i; for (i = 69; i < 71; i++) R9368[i] = (char *(*)()) F1214_11579;}
	R9368[72] = (char *(*)()) F1214_11579;
	R9368[77] = (char *(*)()) F1214_11579;
	{long i; for (i = 79; i < 81; i++) R9368[i] = (char *(*)()) F1214_11579;}
	{long i; for (i = 102; i < 104; i++) R9368[i] = (char *(*)()) F1214_11579;}
	R9368[107] = (char *(*)()) F1214_11579;
	R9368[109] = (char *(*)()) F1214_11579;
	R9368[111] = (char *(*)()) F1214_11579;
	R9368[114] = (char *(*)()) F1214_11579;
	R9368[124] = (char *(*)()) F1214_11579;
	R9368[130] = (char *(*)()) F1214_11579;
	R9368[134] = (char *(*)()) F1214_11579;
	R9368[147] = (char *(*)()) F1364_13880;
	R9368[149] = (char *(*)()) F1366_13934;
}

char *(*R9370[150])();
void R9370_init () {
	R9370[0] = (char *(*)()) F1214_11581;
	R9370[40] = (char *(*)()) F1214_11581;
	{long i; for (i = 63; i < 65; i++) R9370[i] = (char *(*)()) F1214_11581;}
	{long i; for (i = 69; i < 71; i++) R9370[i] = (char *(*)()) F1214_11581;}
	R9370[72] = (char *(*)()) F1214_11581;
	R9370[77] = (char *(*)()) F1214_11581;
	{long i; for (i = 79; i < 81; i++) R9370[i] = (char *(*)()) F1214_11581;}
	{long i; for (i = 102; i < 104; i++) R9370[i] = (char *(*)()) F1214_11581;}
	R9370[107] = (char *(*)()) F1214_11581;
	R9370[109] = (char *(*)()) F1214_11581;
	R9370[111] = (char *(*)()) F1214_11581;
	R9370[114] = (char *(*)()) F1214_11581;
	R9370[124] = (char *(*)()) F1214_11581;
	R9370[130] = (char *(*)()) F1214_11581;
	R9370[134] = (char *(*)()) F1214_11581;
	R9370[147] = (char *(*)()) F1364_13881;
	R9370[149] = (char *(*)()) F1214_11581;
}

char *(*R9373[150])();
void R9373_init () {
	R9373[0] = (char *(*)()) F1214_11584;
	R9373[40] = (char *(*)()) F1214_11584;
	{long i; for (i = 63; i < 65; i++) R9373[i] = (char *(*)()) F1214_11584;}
	{long i; for (i = 69; i < 71; i++) R9373[i] = (char *(*)()) F1214_11584;}
	R9373[72] = (char *(*)()) F1214_11584;
	R9373[77] = (char *(*)()) F1214_11584;
	{long i; for (i = 79; i < 81; i++) R9373[i] = (char *(*)()) F1214_11584;}
	{long i; for (i = 102; i < 104; i++) R9373[i] = (char *(*)()) F1214_11584;}
	R9373[107] = (char *(*)()) F1214_11584;
	R9373[109] = (char *(*)()) F1214_11584;
	R9373[111] = (char *(*)()) F1214_11584;
	R9373[114] = (char *(*)()) F1214_11584;
	R9373[124] = (char *(*)()) F1214_11584;
	R9373[130] = (char *(*)()) F1214_11584;
	R9373[134] = (char *(*)()) F1214_11584;
	R9373[147] = (char *(*)()) F1364_13882;
	R9373[149] = (char *(*)()) F1214_11584;
}


#ifdef __cplusplus
}
#endif
