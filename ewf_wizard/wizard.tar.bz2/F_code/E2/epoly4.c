#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O3386[1215];
void O3386_init () {
	O3386[0] =  + _REFACS_13_;
	{long i; for (i = 1114; i < 1116; i++) O3386[i] =  + _REFACS_19_;}
	{long i; for (i = 1116; i < 1119; i++) O3386[i] =  + _REFACS_20_;}
	O3386[1119] =  + _REFACS_21_;
	{long i; for (i = 1120; i < 1122; i++) O3386[i] =  + _REFACS_20_;}
	O3386[1122] =  + _REFACS_21_;
	O3386[1123] =  + _REFACS_20_;
	{long i; for (i = 1124; i < 1138; i++) O3386[i] =  + _REFACS_21_;}
	{long i; for (i = 1138; i < 1140; i++) O3386[i] =  + _REFACS_25_;}
	{long i; for (i = 1140; i < 1142; i++) O3386[i] =  + _REFACS_28_;}
	{long i; for (i = 1142; i < 1144; i++) O3386[i] =  + _REFACS_25_;}
	{long i; for (i = 1144; i < 1146; i++) O3386[i] =  + _REFACS_28_;}
	O3386[1146] =  + _REFACS_19_;
	O3386[1147] =  + _REFACS_20_;
	O3386[1148] =  + _REFACS_21_;
	O3386[1149] =  + _REFACS_23_;
	O3386[1150] =  + _REFACS_20_;
	O3386[1151] =  + _REFACS_19_;
	{long i; for (i = 1152; i < 1154; i++) O3386[i] =  + _REFACS_21_;}
	O3386[1154] =  + _REFACS_20_;
	O3386[1155] =  + _REFACS_21_;
	O3386[1156] =  + _REFACS_25_;
	O3386[1157] =  + _REFACS_20_;
	O3386[1158] =  + _REFACS_23_;
	{long i; for (i = 1159; i < 1163; i++) O3386[i] =  + _REFACS_20_;}
	O3386[1163] =  + _REFACS_19_;
	O3386[1164] =  + _REFACS_20_;
	O3386[1165] =  + _REFACS_21_;
	O3386[1166] =  + _REFACS_23_;
	O3386[1167] =  + _REFACS_20_;
	O3386[1168] =  + _REFACS_19_;
	{long i; for (i = 1169; i < 1171; i++) O3386[i] =  + _REFACS_21_;}
	O3386[1171] =  + _REFACS_20_;
	O3386[1172] =  + _REFACS_21_;
	O3386[1173] =  + _REFACS_25_;
	O3386[1174] =  + _REFACS_20_;
	O3386[1175] =  + _REFACS_23_;
	{long i; for (i = 1176; i < 1180; i++) O3386[i] =  + _REFACS_20_;}
	O3386[1207] =  + _REFACS_20_;
	O3386[1209] =  + _REFACS_20_;
	O3386[1212] =  + _REFACS_20_;
	O3386[1214] =  + _REFACS_20_;
}

long O3395[1214];
void O3395_init () {
	O3395[0] = 0;
	{long i; for (i = 1075; i < 1077; i++) O3395[i] =  + _REFACS_2_;}
	{long i; for (i = 1111; i < 1113; i++) O3395[i] =  + _REFACS_4_;}
	{long i; for (i = 1113; i < 1115; i++) O3395[i] =  + _REFACS_21_;}
	{long i; for (i = 1115; i < 1118; i++) O3395[i] =  + _REFACS_22_;}
	O3395[1118] =  + _REFACS_23_;
	{long i; for (i = 1119; i < 1121; i++) O3395[i] =  + _REFACS_22_;}
	O3395[1121] =  + _REFACS_23_;
	O3395[1122] =  + _REFACS_22_;
	{long i; for (i = 1123; i < 1137; i++) O3395[i] =  + _REFACS_23_;}
	{long i; for (i = 1137; i < 1139; i++) O3395[i] =  + _REFACS_27_;}
	{long i; for (i = 1139; i < 1141; i++) O3395[i] =  + _REFACS_30_;}
	{long i; for (i = 1141; i < 1143; i++) O3395[i] =  + _REFACS_27_;}
	{long i; for (i = 1143; i < 1145; i++) O3395[i] =  + _REFACS_30_;}
	O3395[1145] =  + _REFACS_21_;
	O3395[1146] =  + _REFACS_22_;
	O3395[1147] =  + _REFACS_23_;
	O3395[1148] =  + _REFACS_25_;
	O3395[1149] =  + _REFACS_22_;
	O3395[1150] =  + _REFACS_21_;
	{long i; for (i = 1151; i < 1153; i++) O3395[i] =  + _REFACS_23_;}
	O3395[1153] =  + _REFACS_22_;
	O3395[1154] =  + _REFACS_23_;
	O3395[1155] =  + _REFACS_27_;
	O3395[1156] =  + _REFACS_22_;
	O3395[1157] =  + _REFACS_25_;
	{long i; for (i = 1158; i < 1162; i++) O3395[i] =  + _REFACS_22_;}
	O3395[1162] =  + _REFACS_21_;
	O3395[1163] =  + _REFACS_22_;
	O3395[1164] =  + _REFACS_23_;
	O3395[1165] =  + _REFACS_25_;
	O3395[1166] =  + _REFACS_22_;
	O3395[1167] =  + _REFACS_21_;
	{long i; for (i = 1168; i < 1170; i++) O3395[i] =  + _REFACS_23_;}
	O3395[1170] =  + _REFACS_22_;
	O3395[1171] =  + _REFACS_23_;
	O3395[1172] =  + _REFACS_27_;
	O3395[1173] =  + _REFACS_22_;
	O3395[1174] =  + _REFACS_25_;
	{long i; for (i = 1175; i < 1179; i++) O3395[i] =  + _REFACS_22_;}
	O3395[1179] =  + _REFACS_7_;
	{long i; for (i = 1180; i < 1182; i++) O3395[i] =  + _REFACS_9_;}
	O3395[1182] =  + _REFACS_7_;
	{long i; for (i = 1183; i < 1187; i++) O3395[i] =  + _REFACS_11_;}
	{long i; for (i = 1187; i < 1189; i++) O3395[i] =  + _REFACS_7_;}
	{long i; for (i = 1189; i < 1193; i++) O3395[i] =  + _REFACS_8_;}
	O3395[1193] =  + _REFACS_9_;
	{long i; for (i = 1194; i < 1198; i++) O3395[i] =  + _REFACS_8_;}
	{long i; for (i = 1198; i < 1201; i++) O3395[i] =  + _REFACS_9_;}
	{long i; for (i = 1201; i < 1205; i++) O3395[i] =  + _REFACS_11_;}
	O3395[1206] =  + _REFACS_22_;
	O3395[1208] =  + _REFACS_22_;
	O3395[1211] =  + _REFACS_22_;
	O3395[1213] =  + _REFACS_22_;
}

long O3396[1214];
void O3396_init () {
	O3396[0] =  + _REFACS_1_;
	{long i; for (i = 1075; i < 1077; i++) O3396[i] =  + _REFACS_3_;}
	{long i; for (i = 1111; i < 1113; i++) O3396[i] =  + _REFACS_5_;}
	{long i; for (i = 1113; i < 1115; i++) O3396[i] =  + _REFACS_22_;}
	{long i; for (i = 1115; i < 1118; i++) O3396[i] =  + _REFACS_23_;}
	O3396[1118] =  + _REFACS_24_;
	{long i; for (i = 1119; i < 1121; i++) O3396[i] =  + _REFACS_23_;}
	O3396[1121] =  + _REFACS_24_;
	O3396[1122] =  + _REFACS_23_;
	{long i; for (i = 1123; i < 1137; i++) O3396[i] =  + _REFACS_24_;}
	{long i; for (i = 1137; i < 1139; i++) O3396[i] =  + _REFACS_28_;}
	{long i; for (i = 1139; i < 1141; i++) O3396[i] =  + _REFACS_31_;}
	{long i; for (i = 1141; i < 1143; i++) O3396[i] =  + _REFACS_28_;}
	{long i; for (i = 1143; i < 1145; i++) O3396[i] =  + _REFACS_31_;}
	O3396[1145] =  + _REFACS_22_;
	O3396[1146] =  + _REFACS_23_;
	O3396[1147] =  + _REFACS_24_;
	O3396[1148] =  + _REFACS_26_;
	O3396[1149] =  + _REFACS_23_;
	O3396[1150] =  + _REFACS_22_;
	{long i; for (i = 1151; i < 1153; i++) O3396[i] =  + _REFACS_24_;}
	O3396[1153] =  + _REFACS_23_;
	O3396[1154] =  + _REFACS_24_;
	O3396[1155] =  + _REFACS_28_;
	O3396[1156] =  + _REFACS_23_;
	O3396[1157] =  + _REFACS_26_;
	{long i; for (i = 1158; i < 1162; i++) O3396[i] =  + _REFACS_23_;}
	O3396[1162] =  + _REFACS_22_;
	O3396[1163] =  + _REFACS_23_;
	O3396[1164] =  + _REFACS_24_;
	O3396[1165] =  + _REFACS_26_;
	O3396[1166] =  + _REFACS_23_;
	O3396[1167] =  + _REFACS_22_;
	{long i; for (i = 1168; i < 1170; i++) O3396[i] =  + _REFACS_24_;}
	O3396[1170] =  + _REFACS_23_;
	O3396[1171] =  + _REFACS_24_;
	O3396[1172] =  + _REFACS_28_;
	O3396[1173] =  + _REFACS_23_;
	O3396[1174] =  + _REFACS_26_;
	{long i; for (i = 1175; i < 1179; i++) O3396[i] =  + _REFACS_23_;}
	O3396[1179] =  + _REFACS_8_;
	{long i; for (i = 1180; i < 1182; i++) O3396[i] =  + _REFACS_10_;}
	O3396[1182] =  + _REFACS_8_;
	{long i; for (i = 1183; i < 1187; i++) O3396[i] =  + _REFACS_12_;}
	{long i; for (i = 1187; i < 1189; i++) O3396[i] =  + _REFACS_8_;}
	{long i; for (i = 1189; i < 1193; i++) O3396[i] =  + _REFACS_9_;}
	O3396[1193] =  + _REFACS_10_;
	{long i; for (i = 1194; i < 1198; i++) O3396[i] =  + _REFACS_9_;}
	{long i; for (i = 1198; i < 1201; i++) O3396[i] =  + _REFACS_10_;}
	{long i; for (i = 1201; i < 1205; i++) O3396[i] =  + _REFACS_12_;}
	O3396[1206] =  + _REFACS_23_;
	O3396[1208] =  + _REFACS_23_;
	O3396[1211] =  + _REFACS_23_;
	O3396[1213] =  + _REFACS_23_;
}

long O3397[1214];
void O3397_init () {
	O3397[0] = + _I16OFF_3_1_0_;
	O3397[1075] = + _I16OFF_7_5_0_;
	O3397[1076] = + _I16OFF_8_6_0_;
	O3397[1111] = + _I16OFF_13_5_0_;
	O3397[1112] = + _I16OFF_16_7_0_;
	O3397[1113] = + _I16OFF_35_9_0_;
	O3397[1114] = + _I16OFF_42_12_0_;
	O3397[1115] = + _I16OFF_37_9_0_;
	O3397[1116] = + _I16OFF_46_12_0_;
	O3397[1117] = + _I16OFF_37_9_0_;
	O3397[1118] = + _I16OFF_38_9_0_;
	O3397[1119] = + _I16OFF_37_9_0_;
	O3397[1120] = + _I16OFF_47_12_0_;
	O3397[1121] = + _I16OFF_49_12_0_;
	O3397[1122] = + _I16OFF_47_12_0_;
	{long i; for (i = 1123; i < 1126; i++) O3397[i] = + _I16OFF_39_10_0_;}
	{long i; for (i = 1126; i < 1129; i++) O3397[i] = + _I16OFF_49_13_0_;}
	{long i; for (i = 1129; i < 1133; i++) O3397[i] = + _I16OFF_39_10_0_;}
	O3397[1133] = + _I16OFF_49_13_0_;
	O3397[1134] = + _I16OFF_51_13_0_;
	{long i; for (i = 1135; i < 1137; i++) O3397[i] = + _I16OFF_49_14_0_;}
	O3397[1137] = + _I16OFF_47_12_0_;
	O3397[1138] = + _I16OFF_47_14_0_;
	O3397[1139] = + _I16OFF_50_13_0_;
	O3397[1140] = + _I16OFF_53_13_0_;
	O3397[1141] = + _I16OFF_59_21_0_;
	O3397[1142] = + _I16OFF_59_23_0_;
	O3397[1143] = + _I16OFF_65_25_0_;
	O3397[1144] = + _I16OFF_68_26_0_;
	O3397[1145] = + _I16OFF_35_9_0_;
	{long i; for (i = 1146; i < 1148; i++) O3397[i] = + _I16OFF_37_9_0_;}
	O3397[1148] = + _I16OFF_43_9_0_;
	O3397[1149] = + _I16OFF_37_10_0_;
	O3397[1150] = + _I16OFF_35_9_0_;
	O3397[1151] = + _I16OFF_37_9_0_;
	O3397[1152] = + _I16OFF_37_10_0_;
	O3397[1153] = + _I16OFF_36_9_0_;
	O3397[1154] = + _I16OFF_37_9_0_;
	O3397[1155] = + _I16OFF_41_9_0_;
	O3397[1156] = + _I16OFF_36_9_0_;
	O3397[1157] = + _I16OFF_40_12_0_;
	{long i; for (i = 1158; i < 1162; i++) O3397[i] = + _I16OFF_36_9_0_;}
	O3397[1162] = + _I16OFF_42_13_0_;
	O3397[1163] = + _I16OFF_44_13_0_;
	O3397[1164] = + _I16OFF_51_13_0_;
	O3397[1165] = + _I16OFF_58_14_0_;
	O3397[1166] = + _I16OFF_45_16_0_;
	O3397[1167] = + _I16OFF_44_13_0_;
	O3397[1168] = + _I16OFF_50_13_0_;
	O3397[1169] = + _I16OFF_51_14_0_;
	O3397[1170] = + _I16OFF_43_13_0_;
	O3397[1171] = + _I16OFF_46_14_0_;
	O3397[1172] = + _I16OFF_59_16_0_;
	O3397[1173] = + _I16OFF_44_15_0_;
	O3397[1174] = + _I16OFF_51_18_0_;
	{long i; for (i = 1175; i < 1179; i++) O3397[i] = + _I16OFF_46_14_0_;}
	O3397[1179] = + _I16OFF_16_5_0_;
	O3397[1180] = + _I16OFF_18_5_0_;
	O3397[1181] = + _I16OFF_23_5_0_;
	O3397[1182] = + _I16OFF_16_5_0_;
	{long i; for (i = 1183; i < 1185; i++) O3397[i] = + _I16OFF_20_5_0_;}
	{long i; for (i = 1185; i < 1187; i++) O3397[i] = + _I16OFF_25_6_0_;}
	{long i; for (i = 1187; i < 1189; i++) O3397[i] = + _I16OFF_21_7_0_;}
	{long i; for (i = 1189; i < 1193; i++) O3397[i] = + _I16OFF_17_6_0_;}
	O3397[1193] = + _I16OFF_18_6_0_;
	O3397[1194] = + _I16OFF_23_8_0_;
	{long i; for (i = 1195; i < 1197; i++) O3397[i] = + _I16OFF_23_9_0_;}
	O3397[1197] = + _I16OFF_24_9_0_;
	O3397[1198] = + _I16OFF_26_8_0_;
	O3397[1199] = + _I16OFF_19_5_0_;
	O3397[1200] = + _I16OFF_22_5_0_;
	{long i; for (i = 1201; i < 1203; i++) O3397[i] = + _I16OFF_21_10_0_;}
	{long i; for (i = 1203; i < 1205; i++) O3397[i] = + _I16OFF_29_14_0_;}
	O3397[1206] = + _I16OFF_36_10_0_;
	O3397[1208] = + _I16OFF_36_9_0_;
	O3397[1211] = + _I16OFF_48_19_0_;
	O3397[1213] = + _I16OFF_48_18_0_;
}

long O3398[1214];
void O3398_init () {
	O3398[0] = + _I16OFF_3_1_1_;
	O3398[1075] = + _I16OFF_7_5_1_;
	O3398[1076] = + _I16OFF_8_6_1_;
	O3398[1111] = + _I16OFF_13_5_1_;
	O3398[1112] = + _I16OFF_16_7_1_;
	O3398[1113] = + _I16OFF_35_9_1_;
	O3398[1114] = + _I16OFF_42_12_1_;
	O3398[1115] = + _I16OFF_37_9_1_;
	O3398[1116] = + _I16OFF_46_12_1_;
	O3398[1117] = + _I16OFF_37_9_1_;
	O3398[1118] = + _I16OFF_38_9_1_;
	O3398[1119] = + _I16OFF_37_9_1_;
	O3398[1120] = + _I16OFF_47_12_1_;
	O3398[1121] = + _I16OFF_49_12_1_;
	O3398[1122] = + _I16OFF_47_12_1_;
	{long i; for (i = 1123; i < 1126; i++) O3398[i] = + _I16OFF_39_10_1_;}
	{long i; for (i = 1126; i < 1129; i++) O3398[i] = + _I16OFF_49_13_1_;}
	{long i; for (i = 1129; i < 1133; i++) O3398[i] = + _I16OFF_39_10_1_;}
	O3398[1133] = + _I16OFF_49_13_1_;
	O3398[1134] = + _I16OFF_51_13_1_;
	{long i; for (i = 1135; i < 1137; i++) O3398[i] = + _I16OFF_49_14_1_;}
	O3398[1137] = + _I16OFF_47_12_1_;
	O3398[1138] = + _I16OFF_47_14_1_;
	O3398[1139] = + _I16OFF_50_13_1_;
	O3398[1140] = + _I16OFF_53_13_1_;
	O3398[1141] = + _I16OFF_59_21_1_;
	O3398[1142] = + _I16OFF_59_23_1_;
	O3398[1143] = + _I16OFF_65_25_1_;
	O3398[1144] = + _I16OFF_68_26_1_;
	O3398[1145] = + _I16OFF_35_9_1_;
	{long i; for (i = 1146; i < 1148; i++) O3398[i] = + _I16OFF_37_9_1_;}
	O3398[1148] = + _I16OFF_43_9_1_;
	O3398[1149] = + _I16OFF_37_10_1_;
	O3398[1150] = + _I16OFF_35_9_1_;
	O3398[1151] = + _I16OFF_37_9_1_;
	O3398[1152] = + _I16OFF_37_10_1_;
	O3398[1153] = + _I16OFF_36_9_1_;
	O3398[1154] = + _I16OFF_37_9_1_;
	O3398[1155] = + _I16OFF_41_9_1_;
	O3398[1156] = + _I16OFF_36_9_1_;
	O3398[1157] = + _I16OFF_40_12_1_;
	{long i; for (i = 1158; i < 1162; i++) O3398[i] = + _I16OFF_36_9_1_;}
	O3398[1162] = + _I16OFF_42_13_1_;
	O3398[1163] = + _I16OFF_44_13_1_;
	O3398[1164] = + _I16OFF_51_13_1_;
	O3398[1165] = + _I16OFF_58_14_1_;
	O3398[1166] = + _I16OFF_45_16_1_;
	O3398[1167] = + _I16OFF_44_13_1_;
	O3398[1168] = + _I16OFF_50_13_1_;
	O3398[1169] = + _I16OFF_51_14_1_;
	O3398[1170] = + _I16OFF_43_13_1_;
	O3398[1171] = + _I16OFF_46_14_1_;
	O3398[1172] = + _I16OFF_59_16_1_;
	O3398[1173] = + _I16OFF_44_15_1_;
	O3398[1174] = + _I16OFF_51_18_1_;
	{long i; for (i = 1175; i < 1179; i++) O3398[i] = + _I16OFF_46_14_1_;}
	O3398[1179] = + _I16OFF_16_5_1_;
	O3398[1180] = + _I16OFF_18_5_1_;
	O3398[1181] = + _I16OFF_23_5_1_;
	O3398[1182] = + _I16OFF_16_5_1_;
	{long i; for (i = 1183; i < 1185; i++) O3398[i] = + _I16OFF_20_5_1_;}
	{long i; for (i = 1185; i < 1187; i++) O3398[i] = + _I16OFF_25_6_1_;}
	{long i; for (i = 1187; i < 1189; i++) O3398[i] = + _I16OFF_21_7_1_;}
	{long i; for (i = 1189; i < 1193; i++) O3398[i] = + _I16OFF_17_6_1_;}
	O3398[1193] = + _I16OFF_18_6_1_;
	O3398[1194] = + _I16OFF_23_8_1_;
	{long i; for (i = 1195; i < 1197; i++) O3398[i] = + _I16OFF_23_9_1_;}
	O3398[1197] = + _I16OFF_24_9_1_;
	O3398[1198] = + _I16OFF_26_8_1_;
	O3398[1199] = + _I16OFF_19_5_1_;
	O3398[1200] = + _I16OFF_22_5_1_;
	{long i; for (i = 1201; i < 1203; i++) O3398[i] = + _I16OFF_21_10_1_;}
	{long i; for (i = 1203; i < 1205; i++) O3398[i] = + _I16OFF_29_14_1_;}
	O3398[1206] = + _I16OFF_36_10_1_;
	O3398[1208] = + _I16OFF_36_9_1_;
	O3398[1211] = + _I16OFF_48_19_1_;
	O3398[1213] = + _I16OFF_48_18_1_;
}

long O3406[1214];
void O3406_init () {
	O3406[0] =  + _REFACS_2_;
	{long i; for (i = 1075; i < 1077; i++) O3406[i] =  + _REFACS_4_;}
	{long i; for (i = 1111; i < 1113; i++) O3406[i] =  + _REFACS_6_;}
	{long i; for (i = 1113; i < 1115; i++) O3406[i] =  + _REFACS_23_;}
	{long i; for (i = 1115; i < 1118; i++) O3406[i] =  + _REFACS_24_;}
	O3406[1118] =  + _REFACS_25_;
	{long i; for (i = 1119; i < 1121; i++) O3406[i] =  + _REFACS_24_;}
	O3406[1121] =  + _REFACS_25_;
	O3406[1122] =  + _REFACS_24_;
	{long i; for (i = 1123; i < 1137; i++) O3406[i] =  + _REFACS_25_;}
	{long i; for (i = 1137; i < 1139; i++) O3406[i] =  + _REFACS_29_;}
	{long i; for (i = 1139; i < 1141; i++) O3406[i] =  + _REFACS_32_;}
	{long i; for (i = 1141; i < 1143; i++) O3406[i] =  + _REFACS_29_;}
	{long i; for (i = 1143; i < 1145; i++) O3406[i] =  + _REFACS_32_;}
	O3406[1145] =  + _REFACS_23_;
	O3406[1146] =  + _REFACS_24_;
	O3406[1147] =  + _REFACS_25_;
	O3406[1148] =  + _REFACS_27_;
	O3406[1149] =  + _REFACS_24_;
	O3406[1150] =  + _REFACS_23_;
	{long i; for (i = 1151; i < 1153; i++) O3406[i] =  + _REFACS_25_;}
	O3406[1153] =  + _REFACS_24_;
	O3406[1154] =  + _REFACS_25_;
	O3406[1155] =  + _REFACS_29_;
	O3406[1156] =  + _REFACS_24_;
	O3406[1157] =  + _REFACS_27_;
	{long i; for (i = 1158; i < 1162; i++) O3406[i] =  + _REFACS_24_;}
	O3406[1162] =  + _REFACS_23_;
	O3406[1163] =  + _REFACS_24_;
	O3406[1164] =  + _REFACS_25_;
	O3406[1165] =  + _REFACS_27_;
	O3406[1166] =  + _REFACS_24_;
	O3406[1167] =  + _REFACS_23_;
	{long i; for (i = 1168; i < 1170; i++) O3406[i] =  + _REFACS_25_;}
	O3406[1170] =  + _REFACS_24_;
	O3406[1171] =  + _REFACS_25_;
	O3406[1172] =  + _REFACS_29_;
	O3406[1173] =  + _REFACS_24_;
	O3406[1174] =  + _REFACS_27_;
	{long i; for (i = 1175; i < 1179; i++) O3406[i] =  + _REFACS_24_;}
	O3406[1179] =  + _REFACS_9_;
	{long i; for (i = 1180; i < 1182; i++) O3406[i] =  + _REFACS_11_;}
	O3406[1182] =  + _REFACS_9_;
	{long i; for (i = 1183; i < 1187; i++) O3406[i] =  + _REFACS_13_;}
	{long i; for (i = 1187; i < 1189; i++) O3406[i] =  + _REFACS_9_;}
	{long i; for (i = 1189; i < 1193; i++) O3406[i] =  + _REFACS_10_;}
	O3406[1193] =  + _REFACS_11_;
	{long i; for (i = 1194; i < 1198; i++) O3406[i] =  + _REFACS_10_;}
	{long i; for (i = 1198; i < 1201; i++) O3406[i] =  + _REFACS_11_;}
	{long i; for (i = 1201; i < 1205; i++) O3406[i] =  + _REFACS_13_;}
	O3406[1206] =  + _REFACS_24_;
	O3406[1208] =  + _REFACS_24_;
	O3406[1211] =  + _REFACS_24_;
	O3406[1213] =  + _REFACS_24_;
}

long O3408[1214];
void O3408_init () {
	O3408[0] = + _I16OFF_3_1_2_;
	O3408[1075] = + _I16OFF_7_5_2_;
	O3408[1076] = + _I16OFF_8_6_2_;
	O3408[1111] = + _I16OFF_13_5_2_;
	O3408[1112] = + _I16OFF_16_7_2_;
	O3408[1113] = + _I16OFF_35_9_2_;
	O3408[1114] = + _I16OFF_42_12_2_;
	O3408[1115] = + _I16OFF_37_9_2_;
	O3408[1116] = + _I16OFF_46_12_2_;
	O3408[1117] = + _I16OFF_37_9_2_;
	O3408[1118] = + _I16OFF_38_9_2_;
	O3408[1119] = + _I16OFF_37_9_2_;
	O3408[1120] = + _I16OFF_47_12_2_;
	O3408[1121] = + _I16OFF_49_12_2_;
	O3408[1122] = + _I16OFF_47_12_2_;
	{long i; for (i = 1123; i < 1126; i++) O3408[i] = + _I16OFF_39_10_2_;}
	{long i; for (i = 1126; i < 1129; i++) O3408[i] = + _I16OFF_49_13_2_;}
	{long i; for (i = 1129; i < 1133; i++) O3408[i] = + _I16OFF_39_10_2_;}
	O3408[1133] = + _I16OFF_49_13_2_;
	O3408[1134] = + _I16OFF_51_13_2_;
	{long i; for (i = 1135; i < 1137; i++) O3408[i] = + _I16OFF_49_14_2_;}
	O3408[1137] = + _I16OFF_47_12_2_;
	O3408[1138] = + _I16OFF_47_14_2_;
	O3408[1139] = + _I16OFF_50_13_2_;
	O3408[1140] = + _I16OFF_53_13_2_;
	O3408[1141] = + _I16OFF_59_21_2_;
	O3408[1142] = + _I16OFF_59_23_2_;
	O3408[1143] = + _I16OFF_65_25_2_;
	O3408[1144] = + _I16OFF_68_26_2_;
	O3408[1145] = + _I16OFF_35_9_2_;
	{long i; for (i = 1146; i < 1148; i++) O3408[i] = + _I16OFF_37_9_2_;}
	O3408[1148] = + _I16OFF_43_9_2_;
	O3408[1149] = + _I16OFF_37_10_2_;
	O3408[1150] = + _I16OFF_35_9_2_;
	O3408[1151] = + _I16OFF_37_9_2_;
	O3408[1152] = + _I16OFF_37_10_2_;
	O3408[1153] = + _I16OFF_36_9_2_;
	O3408[1154] = + _I16OFF_37_9_2_;
	O3408[1155] = + _I16OFF_41_9_2_;
	O3408[1156] = + _I16OFF_36_9_2_;
	O3408[1157] = + _I16OFF_40_12_2_;
	{long i; for (i = 1158; i < 1162; i++) O3408[i] = + _I16OFF_36_9_2_;}
	O3408[1162] = + _I16OFF_42_13_2_;
	O3408[1163] = + _I16OFF_44_13_2_;
	O3408[1164] = + _I16OFF_51_13_2_;
	O3408[1165] = + _I16OFF_58_14_2_;
	O3408[1166] = + _I16OFF_45_16_2_;
	O3408[1167] = + _I16OFF_44_13_2_;
	O3408[1168] = + _I16OFF_50_13_2_;
	O3408[1169] = + _I16OFF_51_14_2_;
	O3408[1170] = + _I16OFF_43_13_2_;
	O3408[1171] = + _I16OFF_46_14_2_;
	O3408[1172] = + _I16OFF_59_16_2_;
	O3408[1173] = + _I16OFF_44_15_2_;
	O3408[1174] = + _I16OFF_51_18_2_;
	{long i; for (i = 1175; i < 1179; i++) O3408[i] = + _I16OFF_46_14_2_;}
	O3408[1179] = + _I16OFF_16_5_2_;
	O3408[1180] = + _I16OFF_18_5_2_;
	O3408[1181] = + _I16OFF_23_5_2_;
	O3408[1182] = + _I16OFF_16_5_2_;
	{long i; for (i = 1183; i < 1185; i++) O3408[i] = + _I16OFF_20_5_2_;}
	{long i; for (i = 1185; i < 1187; i++) O3408[i] = + _I16OFF_25_6_2_;}
	{long i; for (i = 1187; i < 1189; i++) O3408[i] = + _I16OFF_21_7_2_;}
	{long i; for (i = 1189; i < 1193; i++) O3408[i] = + _I16OFF_17_6_2_;}
	O3408[1193] = + _I16OFF_18_6_2_;
	O3408[1194] = + _I16OFF_23_8_2_;
	{long i; for (i = 1195; i < 1197; i++) O3408[i] = + _I16OFF_23_9_2_;}
	O3408[1197] = + _I16OFF_24_9_2_;
	O3408[1198] = + _I16OFF_26_8_2_;
	O3408[1199] = + _I16OFF_19_5_2_;
	O3408[1200] = + _I16OFF_22_5_2_;
	{long i; for (i = 1201; i < 1203; i++) O3408[i] = + _I16OFF_21_10_2_;}
	{long i; for (i = 1203; i < 1205; i++) O3408[i] = + _I16OFF_29_14_2_;}
	O3408[1206] = + _I16OFF_36_10_2_;
	O3408[1208] = + _I16OFF_36_9_2_;
	O3408[1211] = + _I16OFF_48_19_2_;
	O3408[1213] = + _I16OFF_48_18_2_;
}

long O3409[1214];
void O3409_init () {
	O3409[0] = + _I16OFF_3_1_3_;
	O3409[1075] = + _I16OFF_7_5_3_;
	O3409[1076] = + _I16OFF_8_6_3_;
	O3409[1111] = + _I16OFF_13_5_3_;
	O3409[1112] = + _I16OFF_16_7_3_;
	O3409[1113] = + _I16OFF_35_9_3_;
	O3409[1114] = + _I16OFF_42_12_3_;
	O3409[1115] = + _I16OFF_37_9_3_;
	O3409[1116] = + _I16OFF_46_12_3_;
	O3409[1117] = + _I16OFF_37_9_3_;
	O3409[1118] = + _I16OFF_38_9_3_;
	O3409[1119] = + _I16OFF_37_9_3_;
	O3409[1120] = + _I16OFF_47_12_3_;
	O3409[1121] = + _I16OFF_49_12_3_;
	O3409[1122] = + _I16OFF_47_12_3_;
	{long i; for (i = 1123; i < 1126; i++) O3409[i] = + _I16OFF_39_10_3_;}
	{long i; for (i = 1126; i < 1129; i++) O3409[i] = + _I16OFF_49_13_3_;}
	{long i; for (i = 1129; i < 1133; i++) O3409[i] = + _I16OFF_39_10_3_;}
	O3409[1133] = + _I16OFF_49_13_3_;
	O3409[1134] = + _I16OFF_51_13_3_;
	{long i; for (i = 1135; i < 1137; i++) O3409[i] = + _I16OFF_49_14_3_;}
	O3409[1137] = + _I16OFF_47_12_3_;
	O3409[1138] = + _I16OFF_47_14_3_;
	O3409[1139] = + _I16OFF_50_13_3_;
	O3409[1140] = + _I16OFF_53_13_3_;
	O3409[1141] = + _I16OFF_59_21_3_;
	O3409[1142] = + _I16OFF_59_23_3_;
	O3409[1143] = + _I16OFF_65_25_3_;
	O3409[1144] = + _I16OFF_68_26_3_;
	O3409[1145] = + _I16OFF_35_9_3_;
	{long i; for (i = 1146; i < 1148; i++) O3409[i] = + _I16OFF_37_9_3_;}
	O3409[1148] = + _I16OFF_43_9_3_;
	O3409[1149] = + _I16OFF_37_10_3_;
	O3409[1150] = + _I16OFF_35_9_3_;
	O3409[1151] = + _I16OFF_37_9_3_;
	O3409[1152] = + _I16OFF_37_10_3_;
	O3409[1153] = + _I16OFF_36_9_3_;
	O3409[1154] = + _I16OFF_37_9_3_;
	O3409[1155] = + _I16OFF_41_9_3_;
	O3409[1156] = + _I16OFF_36_9_3_;
	O3409[1157] = + _I16OFF_40_12_3_;
	{long i; for (i = 1158; i < 1162; i++) O3409[i] = + _I16OFF_36_9_3_;}
	O3409[1162] = + _I16OFF_42_13_3_;
	O3409[1163] = + _I16OFF_44_13_3_;
	O3409[1164] = + _I16OFF_51_13_3_;
	O3409[1165] = + _I16OFF_58_14_3_;
	O3409[1166] = + _I16OFF_45_16_3_;
	O3409[1167] = + _I16OFF_44_13_3_;
	O3409[1168] = + _I16OFF_50_13_3_;
	O3409[1169] = + _I16OFF_51_14_3_;
	O3409[1170] = + _I16OFF_43_13_3_;
	O3409[1171] = + _I16OFF_46_14_3_;
	O3409[1172] = + _I16OFF_59_16_3_;
	O3409[1173] = + _I16OFF_44_15_3_;
	O3409[1174] = + _I16OFF_51_18_3_;
	{long i; for (i = 1175; i < 1179; i++) O3409[i] = + _I16OFF_46_14_3_;}
	O3409[1179] = + _I16OFF_16_5_3_;
	O3409[1180] = + _I16OFF_18_5_3_;
	O3409[1181] = + _I16OFF_23_5_3_;
	O3409[1182] = + _I16OFF_16_5_3_;
	{long i; for (i = 1183; i < 1185; i++) O3409[i] = + _I16OFF_20_5_3_;}
	{long i; for (i = 1185; i < 1187; i++) O3409[i] = + _I16OFF_25_6_3_;}
	{long i; for (i = 1187; i < 1189; i++) O3409[i] = + _I16OFF_21_7_3_;}
	{long i; for (i = 1189; i < 1193; i++) O3409[i] = + _I16OFF_17_6_3_;}
	O3409[1193] = + _I16OFF_18_6_3_;
	O3409[1194] = + _I16OFF_23_8_3_;
	{long i; for (i = 1195; i < 1197; i++) O3409[i] = + _I16OFF_23_9_3_;}
	O3409[1197] = + _I16OFF_24_9_3_;
	O3409[1198] = + _I16OFF_26_8_3_;
	O3409[1199] = + _I16OFF_19_5_3_;
	O3409[1200] = + _I16OFF_22_5_3_;
	{long i; for (i = 1201; i < 1203; i++) O3409[i] = + _I16OFF_21_10_3_;}
	{long i; for (i = 1203; i < 1205; i++) O3409[i] = + _I16OFF_29_14_3_;}
	O3409[1206] = + _I16OFF_36_10_3_;
	O3409[1208] = + _I16OFF_36_9_3_;
	O3409[1211] = + _I16OFF_48_19_3_;
	O3409[1213] = + _I16OFF_48_18_3_;
}

long O3624[4];
void O3624_init () {
	O3624[0] = + _CHROFF_2_0_;
	O3624[1] = + _CHROFF_2_1_;
	{long i; for (i = 2; i < 4; i++) O3624[i] = + _CHROFF_2_0_;}
}

long O3625[4];
void O3625_init () {
	O3625[0] = + _CHROFF_2_1_;
	O3625[1] = + _CHROFF_2_2_;
	{long i; for (i = 2; i < 4; i++) O3625[i] = + _CHROFF_2_1_;}
}

long O3693[167];
void O3693_init () {
	O3693[0] = 0;
	O3693[1] = + _LNGOFF_0_0_0_0_;
	O3693[2] = + _I64OFF_0_0_0_0_0_0_0_;
	O3693[3] = + _LNGOFF_0_0_0_0_;
	O3693[4] = + _CHROFF_0_0_;
	O3693[5] = 0;
	O3693[6] = + _LNGOFF_1_0_0_0_;
	O3693[7] = + _CHROFF_1_0_;
	{long i; for (i = 165; i < 167; i++) O3693[i] = 0;}
}

long O3697[3];
void O3697_init () {
	O3697[0] =  + _REFACS_1_;
	{long i; for (i = 1; i < 3; i++) O3697[i] = 0;}
}

static EIF_TYPE_INDEX Y4564_pgtype0[] = {0xFF01,834,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype1[] = {0xFF01,835,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype2[] = {0xFF01,836,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype3[] = {0xFF01,837,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype4[] = {0xFF01,838,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype5[] = {0xFF01,839,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype6[] = {0xFF01,840,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype7[] = {0xFF01,841,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype8[] = {0xFF01,842,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype9[] = {0xFF01,843,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype10[] = {0xFF01,844,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype11[] = {0xFF01,845,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype12[] = {0xFF01,834,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype13[] = {0xFF01,835,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype14[] = {0xFF01,836,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype15[] = {0xFF01,837,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype16[] = {0xFF01,838,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype17[] = {0xFF01,839,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype18[] = {0xFF01,840,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype19[] = {0xFF01,841,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype20[] = {0xFF01,842,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype21[] = {0xFF01,843,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype22[] = {0xFF01,844,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype23[] = {0xFF01,845,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype24[] = {0xFF01,838,1002,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype25[] = {0xFF01,834,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype26[] = {0xFF01,835,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype27[] = {0xFF01,836,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype28[] = {0xFF01,837,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype29[] = {0xFF01,838,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype30[] = {0xFF01,839,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype31[] = {0xFF01,840,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype32[] = {0xFF01,841,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype33[] = {0xFF01,842,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype34[] = {0xFF01,843,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype35[] = {0xFF01,844,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype36[] = {0xFF01,845,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype37[] = {0xFF01,834,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype38[] = {0xFF01,835,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype39[] = {0xFF01,840,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype40[] = {0xFF01,834,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype41[] = {0xFF01,835,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype42[] = {0xFF01,834,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype43[] = {0xFF01,835,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype44[] = {0xFF01,834,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype45[] = {0xFF01,835,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype46[] = {0xFF01,834,0xFF01,1094,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype47[] = {0xFF01,834,0xFF01,1040,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype48[] = {0xFF01,834,0xFF01,1040,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype49[] = {0xFF01,834,0xFF01,1040,0xFFF9,1,966,0xFF01,0,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype50[] = {0xFF01,834,0xFF01,1040,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype51[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,1,966,984,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype52[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,1,966,984,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype53[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1164,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype54[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1169,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype55[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1126,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype56[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1101,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype57[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,1,966,927,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype58[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1371,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype59[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,5,966,996,984,984,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype60[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,1050,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype61[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,1,966,984,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype62[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,4,966,984,984,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype63[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,2,966,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype64[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,7,966,984,984,969,969,969,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype65[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,3,966,984,984,927,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype66[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,8,966,984,984,984,969,969,969,984,984,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype67[] = {0xFF01,834,0xFF01,1040,0xFF01,0xFFF9,0,966,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype68[] = {0xFF01,838,1002,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype69[] = {0xFF01,838,1002,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype70[] = {0xFF01,842,972,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype71[] = {0xFF01,843,975,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype72[] = {0xFF01,843,975,0xFFFF};
static EIF_TYPE_INDEX Y4564_pgtype73[] = {0xFF01,834,0xFF01,1050,0xFFFF};
EIF_TYPE_INDEX *Y4564_gen_type [873];
EIF_TYPE_INDEX Y4564 [873];
void Y4564_init (void)
{
	egc_routines_types [4564] = Y4564;
	egc_routines_gen_types [4564] = Y4564_gen_type;
	egc_routines_offset [4564] = 292;
	Y4564_gen_type [0] = Y4564_pgtype0;
	Y4564_gen_type [1] = Y4564_pgtype1;
	Y4564_gen_type [2] = Y4564_pgtype2;
	Y4564_gen_type [3] = Y4564_pgtype3;
	Y4564_gen_type [4] = Y4564_pgtype4;
	Y4564_gen_type [5] = Y4564_pgtype5;
	Y4564_gen_type [6] = Y4564_pgtype6;
	Y4564_gen_type [7] = Y4564_pgtype7;
	Y4564_gen_type [8] = Y4564_pgtype8;
	Y4564_gen_type [9] = Y4564_pgtype9;
	Y4564_gen_type [10] = Y4564_pgtype10;
	Y4564_gen_type [11] = Y4564_pgtype11;
	Y4564_gen_type [285] = Y4564_pgtype12;
	Y4564_gen_type [286] = Y4564_pgtype13;
	Y4564_gen_type [287] = Y4564_pgtype14;
	Y4564_gen_type [288] = Y4564_pgtype15;
	Y4564_gen_type [289] = Y4564_pgtype16;
	Y4564_gen_type [290] = Y4564_pgtype17;
	Y4564_gen_type [291] = Y4564_pgtype18;
	Y4564_gen_type [292] = Y4564_pgtype19;
	Y4564_gen_type [293] = Y4564_pgtype20;
	Y4564_gen_type [294] = Y4564_pgtype21;
	Y4564_gen_type [295] = Y4564_pgtype22;
	Y4564_gen_type [296] = Y4564_pgtype23;
	Y4564_gen_type [297] = Y4564_pgtype24;
	Y4564_gen_type [364] = Y4564_pgtype25;
	Y4564_gen_type [365] = Y4564_pgtype26;
	Y4564_gen_type [366] = Y4564_pgtype27;
	Y4564_gen_type [367] = Y4564_pgtype28;
	Y4564_gen_type [368] = Y4564_pgtype29;
	Y4564_gen_type [369] = Y4564_pgtype30;
	Y4564_gen_type [370] = Y4564_pgtype31;
	Y4564_gen_type [371] = Y4564_pgtype32;
	Y4564_gen_type [372] = Y4564_pgtype33;
	Y4564_gen_type [373] = Y4564_pgtype34;
	Y4564_gen_type [374] = Y4564_pgtype35;
	Y4564_gen_type [375] = Y4564_pgtype36;
	Y4564_gen_type [376] = Y4564_pgtype37;
	Y4564_gen_type [377] = Y4564_pgtype38;
	Y4564_gen_type [378] = Y4564_pgtype39;
	Y4564_gen_type [379] = Y4564_pgtype40;
	Y4564_gen_type [380] = Y4564_pgtype41;
	Y4564_gen_type [381] = Y4564_pgtype42;
	Y4564_gen_type [382] = Y4564_pgtype43;
	Y4564_gen_type [383] = Y4564_pgtype44;
	Y4564_gen_type [384] = Y4564_pgtype45;
	Y4564_gen_type [385] = Y4564_pgtype46;
	Y4564_gen_type [386] = Y4564_pgtype47;
	Y4564_gen_type [387] = Y4564_pgtype48;
	Y4564_gen_type [388] = Y4564_pgtype49;
	Y4564_gen_type [389] = Y4564_pgtype50;
	Y4564_gen_type [390] = Y4564_pgtype51;
	Y4564_gen_type [391] = Y4564_pgtype52;
	Y4564_gen_type [392] = Y4564_pgtype53;
	Y4564_gen_type [393] = Y4564_pgtype54;
	Y4564_gen_type [394] = Y4564_pgtype55;
	Y4564_gen_type [395] = Y4564_pgtype56;
	Y4564_gen_type [396] = Y4564_pgtype57;
	Y4564_gen_type [397] = Y4564_pgtype58;
	Y4564_gen_type [398] = Y4564_pgtype59;
	Y4564_gen_type [399] = Y4564_pgtype60;
	Y4564_gen_type [400] = Y4564_pgtype61;
	Y4564_gen_type [401] = Y4564_pgtype62;
	Y4564_gen_type [402] = Y4564_pgtype63;
	Y4564_gen_type [403] = Y4564_pgtype64;
	Y4564_gen_type [404] = Y4564_pgtype65;
	Y4564_gen_type [405] = Y4564_pgtype66;
	Y4564_gen_type [406] = Y4564_pgtype67;
	Y4564_gen_type [409] = Y4564_pgtype68;
	Y4564_gen_type [410] = Y4564_pgtype69;
	Y4564_gen_type [758] = Y4564_pgtype70;
	Y4564_gen_type [761] = Y4564_pgtype71;
	Y4564_gen_type [762] = Y4564_pgtype72;
	Y4564_gen_type [872] = Y4564_pgtype73;
	Y4564[0] = 834;
	Y4564[1] = 835;
	Y4564[2] = 836;
	Y4564[3] = 837;
	Y4564[4] = 838;
	Y4564[5] = 839;
	Y4564[6] = 840;
	Y4564[7] = 841;
	Y4564[8] = 842;
	Y4564[9] = 843;
	Y4564[10] = 844;
	Y4564[11] = 845;
	Y4564[285] = 834;
	Y4564[286] = 835;
	Y4564[287] = 836;
	Y4564[288] = 837;
	Y4564[289] = 838;
	Y4564[290] = 839;
	Y4564[291] = 840;
	Y4564[292] = 841;
	Y4564[293] = 842;
	Y4564[294] = 843;
	Y4564[295] = 844;
	Y4564[296] = 845;
	Y4564[297] = 838;
	Y4564[364] = 834;
	Y4564[365] = 835;
	Y4564[366] = 836;
	Y4564[367] = 837;
	Y4564[368] = 838;
	Y4564[369] = 839;
	Y4564[370] = 840;
	Y4564[371] = 841;
	Y4564[372] = 842;
	Y4564[373] = 843;
	Y4564[374] = 844;
	Y4564[375] = 845;
	Y4564[376] = 834;
	Y4564[377] = 835;
	Y4564[378] = 840;
	Y4564[379] = 834;
	Y4564[380] = 835;
	Y4564[381] = 834;
	Y4564[382] = 835;
	Y4564[383] = 834;
	Y4564[384] = 835;
	{long i; for (i = 385; i < 407; i++) Y4564[i] = 834;};
	{long i; for (i = 409; i < 411; i++) Y4564[i] = 838;};
	Y4564[758] = 842;
	{long i; for (i = 761; i < 763; i++) Y4564[i] = 843;};
	Y4564[872] = 834;
}


#ifdef __cplusplus
}
#endif
