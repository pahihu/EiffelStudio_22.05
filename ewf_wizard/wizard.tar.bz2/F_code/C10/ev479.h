
#ifndef _C10_ev479_
#define _C10_ev479_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1118_10069(EIF_REFERENCE, EIF_REFERENCE);
extern void F1118_10070(EIF_REFERENCE, EIF_REFERENCE);
extern void F1118_10071(EIF_REFERENCE);
extern void EIF_Minit479(void);
extern void F1256_12027(EIF_REFERENCE, EIF_REFERENCE);
extern void F1256_12028(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
