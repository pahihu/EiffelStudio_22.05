/*
 * Code for class EV_POSITIONABLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev466.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_POSITIONABLE}.set_x_position */
void F1105_9918 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7891[Dtype(Current)-1082]);
	F1216_11637(RTCW(tr1), arg1);
	RTLE;
}

/* {EV_POSITIONABLE}.set_y_position */
void F1105_9919 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7891[Dtype(Current)-1082]);
	F1216_11638(RTCW(tr1), arg1);
	RTLE;
}

/* {EV_POSITIONABLE}.set_size */
void F1105_9923 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7891[Dtype(Current)-1082]);
	F1216_11634(RTCW(tr1), arg1, arg2);
	RTLE;
}

void EIF_Minit466 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
