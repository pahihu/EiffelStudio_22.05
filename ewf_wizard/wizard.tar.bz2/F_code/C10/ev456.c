/*
 * Code for class EV_ACCELERATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev456.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_ACCELERATOR}.make_with_key_combination */
void F1095_9790 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN arg3, EIF_BOOLEAN arg4)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	F1083_9566(Current);
	F1095_9797(Current, arg1);
	if (arg2) {
		F1095_9802(Current);
	}
	if (arg3) {
		F1095_9800(Current);
	}
	if (arg4) {
		F1095_9798(Current);
	}
	RTLE;
}

/* {EV_ACCELERATOR}.actions */
EIF_REFERENCE F1095_9791 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1210_11283(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_ACCELERATOR}.key */
EIF_REFERENCE F1095_9793 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	RTLE;
	return Result;
}

/* {EV_ACCELERATOR}.shift_required */
EIF_BOOLEAN F1095_9794 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_3_);
	RTLE;
	return Result;
}

/* {EV_ACCELERATOR}.alt_required */
EIF_BOOLEAN F1095_9795 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_2_);
	RTLE;
	return Result;
}

/* {EV_ACCELERATOR}.control_required */
EIF_BOOLEAN F1095_9796 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_1_);
	RTLE;
	return Result;
}

/* {EV_ACCELERATOR}.set_key */
void F1095_9797 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1211_11301(RTCW(tr1), arg1);
	RTLE;
}

/* {EV_ACCELERATOR}.enable_shift_required */
void F1095_9798 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1211_11302(RTCW(tr1));
	RTLE;
}

/* {EV_ACCELERATOR}.enable_alt_required */
void F1095_9800 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1211_11304(RTCW(tr1));
	RTLE;
}

/* {EV_ACCELERATOR}.enable_control_required */
void F1095_9802 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1211_11306(RTCW(tr1));
	RTLE;
}

/* {EV_ACCELERATOR}.is_equal */
EIF_BOOLEAN F1095_9804 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	tb2 = '\0';
	tr1 = F1095_9793(Current);
	tr2 = F1095_9793(RTCW(arg1));
	tb3 = (EIF_BOOLEAN) eif_builtin_ANY_is_equal__o_b (tr1, tr2);
	if (tb3) {
		tb3 = F1095_9795(RTCW(arg1));
		tb2 = (EIF_BOOLEAN)(F1095_9795(Current) == tb3);
	}
	if (tb2) {
		tb2 = F1095_9794(RTCW(arg1));
		tb1 = (EIF_BOOLEAN)(F1095_9794(Current) == tb2);
	}
	if (tb1) {
		tb1 = F1095_9796(RTCW(arg1));
		Result = (EIF_BOOLEAN)(F1095_9796(Current) == tb1);
	}
	RTLE;
	return Result;
}

/* {EV_ACCELERATOR}.text */
EIF_REFERENCE F1095_9805 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(1050, 0x01).id, 1050, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1049_9119(RTCW(Result), ((EIF_INTEGER_32) 0L));
	if (F1095_9796(Current)) {
		tr1 = F1046_9048(RTMS_EX_H("Ctrl+",5,1954170411));
		F1051_9234(RTCW(Result), tr1);
	}
	if (F1095_9795(Current)) {
		tr1 = F1046_9048(RTMS_EX_H("Alt+",4,1097626667));
		F1051_9234(RTCW(Result), tr1);
	}
	if (F1095_9794(Current)) {
		tr1 = F1046_9048(RTMS_EX_H("Shift+",6,1932305451));
		F1051_9234(RTCW(Result), tr1);
	}
	loc1 = F1372_14080(RTCV(F1095_9793(Current)));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
		F1051_9276(RTCW(loc1));
	}
	F1051_9234(RTCW(Result), loc1);
	RTLE;
	return Result;
}

/* {EV_ACCELERATOR}.out */
EIF_REFERENCE F1095_9806 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = F1046_9043(RTCV(F1095_9805(Current)));
	RTLE;
	return Result;
}

/* {EV_ACCELERATOR}.implementation */
EIF_REFERENCE F1095_9807 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


/* {EV_ACCELERATOR}.create_interface_objects */
void F1095_9808 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {EV_ACCELERATOR}.create_implementation */
void F1095_9809 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1210, 0x01).id, 1210, _OBJSIZ_3_5_0_0_0_0_0_0_);
	F1211_11296(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit456 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
