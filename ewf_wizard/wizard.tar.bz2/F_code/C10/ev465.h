
#ifndef _C10_ev465_
#define _C10_ev465_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1104_9910(EIF_REFERENCE);
extern EIF_INTEGER_32 F1104_9911(EIF_REFERENCE);
extern EIF_INTEGER_32 F1104_9912(EIF_REFERENCE);
extern EIF_INTEGER_32 F1104_9913(EIF_REFERENCE);
extern EIF_INTEGER_32 F1104_9914(EIF_REFERENCE);
extern void EIF_Minit465(void);
extern EIF_INTEGER_32 F1215_11596(EIF_REFERENCE);
extern char *(*R9613[])();
extern char *(*R9614[])();
extern char *(*R9615[])();
extern char *(*R9616[])();
extern long O7891[];

#ifdef __cplusplus
}
#endif

#endif
