/*
 * Code for class EV_PATH_FIELD
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev495.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PATH_FIELD}.make */
void F1135_10309 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1135_10310(Current, NULL);
}

/* {EV_PATH_FIELD}.make_with_text */
void F1135_10310 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(931, 1).id);
	F932_7664(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	F1083_9566(Current);
	F1135_10332(Current, arg1);
	RTLE;
}

/* {EV_PATH_FIELD}.parent_window */
EIF_REFERENCE F1135_10314 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		loc1 = F1135_10344(Current, Current);
	}
	RTCT0("l_result /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTLE;
	return (EIF_REFERENCE) loc1;
}

/* {EV_PATH_FIELD}.file_path */
EIF_REFERENCE F1135_10319 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	RTCT0("l_field /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = RTLNS(eif_new_type(931, 0x01).id, 931, _OBJSIZ_2_1_0_0_0_0_0_0_);
	tr1 = F1112_9959(RTCW(loc1));
	F932_7666(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {EV_PATH_FIELD}.set_file_path */
void F1135_10323 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	RTCT0("l_field /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = F932_7705(RTCW(arg1));
	F1112_9960(RTCW(loc1), tr1);
	RTLE;
}

/* {EV_PATH_FIELD}.set_browse_for_directory */
void F1135_10327 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	RTCT0("l_browse_button /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = F1075_9509(RTCW(loc1));
	F672_5818(RTCW(tr1));
	tr1 = F1075_9509(RTCW(loc1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,966,0xFF01,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1040,0xFF01,0xFFF9,0,966,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A495_345, (EIF_POINTER) _A495_345, (EIF_POINTER)(F1135_10334),tr2, 1, 0);
	}
	F672_5806(RTCW(tr1), tr3);
	RTLE;
}

/* {EV_PATH_FIELD}.build_widget */
void F1135_10332 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLR(5,loc3);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,loc4);
	RTLIU(9);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		loc1 = RTLNS(eif_new_type(1152, 0x01).id, 1152, _OBJSIZ_5_2_0_1_0_0_0_0_);
		F1112_9958(RTCW(loc1), arg1);
		F1113_9970(RTCW(loc1));
		F1125_10156(Current, loc1);
		F1132_10302(Current, loc1);
	}
	loc2 = RTLNS(eif_new_type(1132, 0x01).id, 1132, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1083_9566(RTCW(loc2));
	tr1 = RTLNS(eif_new_type(109, 0x01).id, 109, _OBJSIZ_0_0_0_0_0_0_0_0_);
	ti4_1 = RTOSCF(2878,F110_2878, (RTCW(tr1)));
	F1132_10300(RTCW(loc2), ti4_1);
	tr1 = RTLNSMART(eif_new_type(1155, 0).id);
	F1083_9566(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	loc3 = RTLNSMART(eif_new_type(1158, 0).id);
	tr1 = RTOSCF(10339,F1135_10339, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,966,0xFF01,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1040,0xFF01,0xFFF9,0,966,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A495_345, (EIF_POINTER) _A495_345, (EIF_POINTER)(F1135_10334),tr2, 1, 0);
	}
	F1159_10664(RTCW(loc3), tr1, tr3);
	RTAR(Current, loc3);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) loc3;
	loc4 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	RTCT0("l_field /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc4 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	F1125_10156(RTCW(loc2), loc4);
	F1125_10156(RTCW(loc2), loc3);
	F1132_10302(RTCW(loc2), loc3);
	F1125_10156(Current, loc2);
	RTLE;
}

/* {EV_PATH_FIELD}.browse_for_directory */
void F1135_10334 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1118, 0x01).id, 1118, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1083_9566(RTCW(loc1));
	tr1 = RTOSCF(10340,F1135_10340, (Current));
	F1118_10070(RTCW(loc1), tr1);
	loc2 = F1135_10338(Current);
	tb1 = '\0';
	tb2 = F932_7674(RTCW(loc2));
	if ((EIF_BOOLEAN) !tb2) {
		tr1 = RTLNS(eif_new_type(913, 0x01).id, 913, _OBJSIZ_3_0_0_1_0_2_0_0_);
		F914_6740(RTCW(tr1), loc2);
		tb2 = F914_6763(RTCW(tr1));
		tb1 = tb2;
	}
	if (tb1) {
		F1119_10078(RTCW(loc1), loc2);
	}
	tr1 = F1135_10314(Current);
	F1118_10069(RTCW(loc1), tr1);
	tb1 = '\0';
	tb2 = '\0';
	tr1 = F1119_10074(RTCW(loc1));
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		tr1 = F1119_10074(RTCW(loc1));
		tb3 = F932_7674(RTCW(tr1));
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		loc3 = tr1;
		tb1 = EIF_TEST(loc3);
	}
	if (tb1) {
		tr1 = F1119_10074(RTCW(loc1));
		tr1 = F932_7705(RTCW(tr1));
		F1112_9960(loc3, tr1);
	}
	RTLE;
}

/* {EV_PATH_FIELD}.start_path */
EIF_REFERENCE F1135_10338 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	RTCT0("l_field /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = RTLNS(eif_new_type(931, 0x01).id, 931, _OBJSIZ_2_1_0_0_0_0_0_0_);
	tr1 = F1112_9959(RTCW(loc1));
	F932_7666(RTCW(Result), tr1);
	tb1 = F932_7674(RTCW(Result));
	if (tb1) {
		Result = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {EV_PATH_FIELD}.label_browse */

EIF_REFERENCE F1135_10339 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (10339,RTMS_EX_H("Browse...",9,1590170670));
}

/* {EV_PATH_FIELD}.label_select_directory */

EIF_REFERENCE F1135_10340 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (10340,RTMS_EX_H("Select a directory",18,1011494265));
}

/* {EV_PATH_FIELD}.parent_window_of */
EIF_REFERENCE F1135_10344 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		loc1 = arg1;
		loc1 = RTRV(eif_new_type(1139, 0x01),loc1);
		if (EIF_TEST(loc1)) {
			RTLE;
			return (EIF_REFERENCE) loc1;
		} else {
			tr1 = F1127_10191(RTCW(arg1));
			Result = F1135_10344(Current, tr1);
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit495 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
