/*
 * Code for class EV_IDENTIFIABLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev457.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_IDENTIFIABLE}.identifier_name */
EIF_REFERENCE F1096_9812 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8082[dtype-1095]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1_14(loc1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTLE;
		return (EIF_REFERENCE) (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8076[dtype-1132])(Current);
	}/* NOTREACHED */
	
}

/* {EV_IDENTIFIABLE}.default_identifier_name */
EIF_REFERENCE F1096_9813 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = RTMS32_EX_H("{\000\000\000",1,123);
	tr2 = F933_7726(RTCV(F1_5(Current)));
	tr1 = F1051_9253(tr1, tr2);
	tr2 = F1046_9048(RTMS_EX_H("}",1,125));
	Result = F1051_9253(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {EV_IDENTIFIABLE}.debug_output */
EIF_REFERENCE F1096_9815 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1050, 0x01).id, 1050, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1049_9119(RTCW(Result), ((EIF_INTEGER_32) 10L));
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '<';
	F1051_9247(RTCW(Result), tw1);
	tr1 = eif_out__p_s1(Current);
	tr1 = F1046_9048(RTCW(tr1));
	F1051_9234(RTCW(Result), tr1);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '>';
	F1051_9247(RTCW(Result), tw1);
	if (F1096_9817(Current)) {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
		F1051_9247(RTCW(Result), tw1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
		F1051_9247(RTCW(Result), tw1);
		tr1 = F1096_9812(Current);
		F1051_9234(RTCW(Result), tr1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
		F1051_9247(RTCW(Result), tw1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
		F1051_9247(RTCW(Result), tw1);
	}
	tr1 = F933_7726(RTCV(F1_5(Current)));
	F1051_9234(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {EV_IDENTIFIABLE}.has_identifier_name_set */
EIF_BOOLEAN F1096_9817 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O8082[Dtype(Current)-1095]) != NULL);
}

void EIF_Minit457 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
