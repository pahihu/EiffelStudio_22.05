
#ifndef _C10_ev486_
#define _C10_ev486_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1126_10183(EIF_REFERENCE);
extern void F1126_10186(EIF_REFERENCE);
extern void EIF_Minit486(void);
extern EIF_BOOLEAN F1239_11924(EIF_REFERENCE);
extern void F1239_11927(EIF_REFERENCE);
extern long O7891[];

#ifdef __cplusplus
}
#endif

#endif
