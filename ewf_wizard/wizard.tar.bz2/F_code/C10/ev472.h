
#ifndef _C10_ev472_
#define _C10_ev472_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1111_9954(EIF_REFERENCE);
extern void EIF_Minit472(void);
extern void F1330_13375(EIF_REFERENCE);
extern long O7891[];

#ifdef __cplusplus
}
#endif

#endif
