
#ifndef _C10_ev480_
#define _C10_ev480_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1119_10074(EIF_REFERENCE);
extern void F1119_10078(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1119_10079(EIF_REFERENCE);
extern void F1119_10080(EIF_REFERENCE);
extern void EIF_Minit480(void);
extern void F1257_12044(EIF_REFERENCE, EIF_REFERENCE);
extern void F1257_12041(EIF_REFERENCE);
extern EIF_REFERENCE F1257_12042(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
