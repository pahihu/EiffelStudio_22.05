
#ifndef _C10_ev488_
#define _C10_ev488_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1128_10223(EIF_REFERENCE);
extern void F1128_10232(EIF_REFERENCE, EIF_REFERENCE);
extern void F1128_10233(EIF_REFERENCE, EIF_REFERENCE);
extern void F1128_10234(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1128_10236(EIF_REFERENCE);
extern EIF_INTEGER_32 F1128_10237(EIF_REFERENCE);
extern EIF_INTEGER_32 F1128_10238(EIF_REFERENCE);
extern void F1128_10239(EIF_REFERENCE);
extern void F1128_10240(EIF_REFERENCE);
extern void F1128_10255(EIF_REFERENCE, EIF_REFERENCE);
extern void F1128_10256(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit488(void);
extern void F1269_12301(EIF_REFERENCE);
extern void F1269_12300(EIF_REFERENCE);
extern char *(*R8398[])();
extern char *(*R4759[])();
extern char *(*R9871[])();
extern char *(*R9875[])();
extern char *(*R9876[])();
extern char *(*R9878[])();
extern char *(*R9879[])();
extern char *(*R8401[])();
extern char *(*R4818[])();
extern long O7891[];

#ifdef __cplusplus
}
#endif

#endif
