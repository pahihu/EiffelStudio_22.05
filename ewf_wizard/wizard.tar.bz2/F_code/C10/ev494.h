
#ifndef _C10_ev494_
#define _C10_ev494_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1134_10307(EIF_REFERENCE);
extern void F1134_10308(EIF_REFERENCE);
extern void EIF_Minit494(void);
extern void F1280_12419(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
