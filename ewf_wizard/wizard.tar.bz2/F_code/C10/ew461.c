/*
 * Code for class EWF_GRAPHICAL_WIZARD
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew461.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EWF_GRAPHICAL_WIZARD}.make_and_launch */
void F1100_9875 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,loc1);
	RTLIU(6);
	
	RTGC;
	F1083_9566(Current);
	tb1 = '\01';
	tr1 = RTOSCF(4751,F305_4751, (Current));
	tr2 = RTMS_EX_H("ISE_PROJECTS",12,53375059);
	tr1 = F704_6024(RTCW(tr1), tr2);
	loc2 = tr1;
	if (!((EIF_BOOLEAN) !EIF_TEST(loc2))) {
		tb2 = F1046_9007(loc2);
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = RTOSCF(4751,F305_4751, (Current));
		tr2 = RTLNS(eif_new_type(1387, 0x01).id, 1387, _OBJSIZ_0_3_0_0_0_0_0_0_);
		tr2 = RTOSCF(14620,F1387_14620, (RTCW(tr2)));
		tr2 = F932_7705(RTCW(tr2));
		tr3 = RTMS_EX_H("ISE_PROJECTS",12,53375059);
		F704_6037(RTCW(tr1), tr2, tr3);
	}
	tr1 = RTOSCF(6018,F704_6018, (RTCV(RTOSCF(4751,F305_4751, (Current)))));
	tr2 = RTMS_EX_H("-console",8,454945893);
	ti4_1 = F328_4975(RTCW(tr1), tr2);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		tr1 = RTLNS(eif_new_type(1378, 0x01).id, 1378, _OBJSIZ_5_0_0_0_0_0_0_0_);
		F1379_14207(RTCW(tr1));
		{
			/* INLINED CODE (ANY.do_nothing) */
			tr2 = tr1;
			(void) RTCW(tr2);
			/* END INLINED CODE */
		}
		;
	} else {
		loc1 = RTLNSMART(eif_new_type(1143, 0).id);
		F1083_9566(RTCW(loc1));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) loc1;
		F1140_10419(RTCW(loc1));
		F1099_9844(Current);
	}
	RTLE;
}

void EIF_Minit461 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
