
#ifndef _C10_ev466_
#define _C10_ev466_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1105_9918(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1105_9919(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1105_9923(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit466(void);
extern void F1216_11638(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1216_11634(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1216_11637(EIF_REFERENCE, EIF_INTEGER_32);
extern long O7891[];

#ifdef __cplusplus
}
#endif

#endif
