
#ifndef _C10_ev473_
#define _C10_ev473_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1112_9958(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1112_9959(EIF_REFERENCE);
extern void F1112_9960(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit473(void);
extern void F1083_9566(EIF_REFERENCE);
extern void F1049_9127(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R9687[])();
extern char *(*R9688[])();
extern long O7891[];

#ifdef __cplusplus
}
#endif

#endif
