
#ifndef _C10_ev476_
#define _C10_ev476_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1115_9975(EIF_REFERENCE);
extern void F1115_9983(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1115_9991(EIF_REFERENCE);
extern void F1115_9993(EIF_REFERENCE);
extern void F1115_9994(EIF_REFERENCE);
extern void F1115_9995(EIF_REFERENCE);
extern void F1115_9997(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1115_10003(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1115_10010(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1115_10013(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1115_10014(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1115_10019(EIF_REFERENCE);
extern void EIF_Minit476(void);
extern void F1363_13817(EIF_REFERENCE);
extern char *(*R10563[])();
extern char *(*R10570[])();
extern char *(*R10573[])();
extern char *(*R10574[])();
extern char *(*R10539[])();
extern char *(*R10540[])();
extern char *(*R10546[])();
extern char *(*R10552[])();
extern char *(*R10553[])();
extern char *(*R10557[])();
extern long O7891[];
extern long O10669[];

#ifdef __cplusplus
}
#endif

#endif
