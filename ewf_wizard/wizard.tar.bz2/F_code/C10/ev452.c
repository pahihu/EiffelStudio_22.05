/*
 * Code for class EV_POINTER_STYLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev452.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_POINTER_STYLE}.make_predefined */
void F1091_9724 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1083_9566(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1204_11145(RTCW(tr1), arg1);
	RTLE;
}

/* {EV_POINTER_STYLE}.set_x_hotspot */
void F1091_9727 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1204_11147(RTCW(tr1), arg1);
	RTLE;
}

/* {EV_POINTER_STYLE}.set_y_hotspot */
void F1091_9728 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1204_11148(RTCW(tr1), arg1);
	RTLE;
}

/* {EV_POINTER_STYLE}.x_hotspot */
EIF_INTEGER_32 F1091_9729 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	RTLE;
	return Result;
}

/* {EV_POINTER_STYLE}.y_hotspot */
EIF_INTEGER_32 F1091_9730 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_1_);
	RTLE;
	return Result;
}

/* {EV_POINTER_STYLE}.width */
EIF_INTEGER_32 F1091_9731 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1204_11150(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_POINTER_STYLE}.height */
EIF_INTEGER_32 F1091_9732 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1204_11151(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_POINTER_STYLE}.copy */
void F1091_9733 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) == NULL)) {
		F1083_9566(Current);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1204_11160(RTCW(tr1), arg1);
	ti4_1 = F1091_9729(RTCW(arg1));
	F1091_9727(Current, ti4_1);
	ti4_1 = F1091_9730(RTCW(arg1));
	F1091_9728(Current, ti4_1);
	RTLE;
}

/* {EV_POINTER_STYLE}.is_equal */
EIF_BOOLEAN F1091_9734 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		Result = '\0';
		ti4_1 = F1091_9732(RTCW(arg1));
		ti4_2 = F1091_9731(RTCW(arg1));
		if ((EIF_BOOLEAN)((EIF_INTEGER_32) (F1091_9731(Current) * ti4_1) == (EIF_INTEGER_32) (ti4_2 * F1091_9732(Current)))) {
			tb1 = '\0';
			ti4_1 = F1091_9729(RTCW(arg1));
			if ((EIF_BOOLEAN)(ti4_1 == F1091_9729(Current))) {
				ti4_1 = F1091_9730(RTCW(arg1));
				tb1 = (EIF_BOOLEAN)(ti4_1 == F1091_9730(Current));
			}
			Result = tb1;
		}
	}
	RTLE;
	return Result;
}

/* {EV_POINTER_STYLE}.create_interface_objects */
void F1091_9735 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {EV_POINTER_STYLE}.create_implementation */
void F1091_9736 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1203, 0x01).id, 1203, _OBJSIZ_1_1_0_3_0_1_0_0_);
	F1204_11143(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {EV_POINTER_STYLE}.implementation */
EIF_REFERENCE F1091_9737 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


void EIF_Minit452 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
