
#ifndef _C10_ev474_
#define _C10_ev474_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1113_9968(EIF_REFERENCE);
extern void F1113_9970(EIF_REFERENCE);
extern void EIF_Minit474(void);
extern char *(*R9700[])();
extern char *(*R9701[])();
extern long O7891[];

#ifdef __cplusplus
}
#endif

#endif
