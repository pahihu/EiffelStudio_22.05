
#ifndef _C10_ev499_
#define _C10_ev499_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1139_10384(EIF_REFERENCE);
extern void F1139_10386(EIF_REFERENCE);
extern void F1139_10387(EIF_REFERENCE);
extern EIF_REFERENCE F1139_10389(EIF_REFERENCE);
extern void F1139_10390(EIF_REFERENCE);
extern void EIF_Minit499(void);
extern void F1289_12513(EIF_REFERENCE);
extern void F1289_12501(EIF_REFERENCE);
extern void F1289_12516(EIF_REFERENCE);
extern void F1289_12515(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
