/*
 * Code for class EV_SELECTABLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev471.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_SELECTABLE}.is_selected */
EIF_BOOLEAN F1110_9950 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if (F1110_9951(Current)) {
		tr1 = *(EIF_REFERENCE *)(Current + O7891[Dtype(Current)-1082]);
		Result = F1330_13376(RTCW(tr1));
	}
	RTLE;
	return Result;
}

/* {EV_SELECTABLE}.is_selectable */
EIF_BOOLEAN F1110_9951 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7891[Dtype(Current)-1082]);
	Result = F1241_11942(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_SELECTABLE}.enable_select */
void F1110_9952 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7891[Dtype(Current)-1082]);
	F1330_13374(RTCW(tr1));
	RTLE;
}

void EIF_Minit471 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
