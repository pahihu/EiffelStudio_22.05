
#ifndef _C17_ce806_
#define _C17_ce806_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F184_3756(EIF_REFERENCE);
extern void F184_3757(EIF_REFERENCE, EIF_REFERENCE);
extern void F184_3758(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit806(void);
extern long O3693[];

#ifdef __cplusplus
}
#endif

#endif
