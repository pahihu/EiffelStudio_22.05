/*
 * Code for class ACTION_SEQUENCE [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ac812.h"
#include "eif_built_in.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ACTION_SEQUENCE}.default_create */
void F679_5840 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F657_5723(Current, ((EIF_INTEGER_32) 0L));
	*(EIF_INTEGER_32 *)(Current + O5275[Dtype(Current)-678]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTLE;
}

/* {ACTION_SEQUENCE}.on_item_added_at */
void F679_5841 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(F657_5744(Current) == ((EIF_INTEGER_32) 1L))) {
		tb1 = (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_7_) != NULL);
	}
	if (tb1) {
		tr1 = F679_5860(Current);
		F679_5864(Current, tr1);
	}
	RTLE;
}

/* {ACTION_SEQUENCE}.on_item_removed_at */
void F679_5842 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(F657_5744(Current) == ((EIF_INTEGER_32) 0L))) {
		tb1 = (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_8_) != NULL);
	}
	if (tb1) {
		tr1 = F679_5861(Current);
		F679_5864(Current, tr1);
	}
	RTLE;
}

/* {ACTION_SEQUENCE}.call */
void F679_5843 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_INTEGER_32 ti4_5;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc4);
	RTLR(5,loc3);
	RTLR(6,loc5);
	RTLR(7,loc7);
	RTLR(8,arg1);
	RTLIU(9);
	
	RTGC;
	if ((EIF_BOOLEAN) (F657_5744(Current) > ((EIF_INTEGER_32) 0L))) {
		ti4_1 = F657_5744(Current);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,834,0,0,0xFFFF};
			EIF_TYPE typres0;
			{
				EIF_TYPE l_type;
				l_type = eif_final_id(Y4957,Y4957_gen_type,dftype,443);
				typarr0[2] = l_type.annotations | 0xFF00;
				typarr0[3] = l_type.id;
			}
			
			typres0 = eif_compound_id(dftype, typarr0);
			loc1 = RTLNSP2(typres0.id,EO_REF,ti4_1,sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(loc1) = 0;
		}
		tr1 = F657_5727(Current);
		ti4_2 = F657_5744(Current);
		/* INLINED CODE (SPECIAL.copy_data) */
		sp_copy_data(RTCW(loc1),tr1,((EIF_INTEGER_32) 0L),((EIF_INTEGER_32) 0L),ti4_2);
		RT_SPECIAL_COUNT(loc1) = eif_max_int32(RT_SPECIAL_COUNT(loc1), ((EIF_INTEGER_32) 0L) + ti4_2);
		/* END INLINED CODE */
		;
		loc4 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			tb2 = F483_5233(RTCW(loc4));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			loc3 = F657_5727(RTCW(loc4));
			loc2 = F657_5744(RTCW(loc4));
			loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			for (;;) {
				if ((EIF_BOOLEAN)(loc6 == loc2)) break;
				/* INLINED CODE (SPECIAL.item) */
				tr2 = *((EIF_REFERENCE *)RTCW(loc3) + (loc6));
				/* END INLINED CODE */
				tr1 = tr2;
				F672_5816(Current, tr1);
				loc6++;
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R4947[Dtype(RTCW(loc4))-647])(loc4);
		}
		switch (*(EIF_INTEGER_32 *)(Current + O5275[Dtype(Current)-678])) {
			case 1L:
				loc5 = F679_5865(Current);
				F644_5547(RTCW(loc5), (EIF_BOOLEAN) 0);
				loc2 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc1);
				loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				for (;;) {
					tb1 = '\01';
					if (!(EIF_BOOLEAN)(loc6 == loc2)) {
						tb2 = F644_5545(RTCW(loc5));
						tb1 = tb2;
					}
					if (tb1) break;
					/* INLINED CODE (SPECIAL.item) */
					tr2 = *((EIF_REFERENCE *)RTCW(loc1) + (loc6));
					/* END INLINED CODE */
					tr1 = tr2;
					loc7 = tr1;
					if ((EIF_TRUE)) {
						(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(loc7+ _PTROFF_4_2_0_3_0_2_))(
							*(EIF_POINTER *)(loc7+ _PTROFF_4_2_0_3_0_1_),
							*(EIF_REFERENCE *)(loc7 + _REFACS_1_), arg1);
					}
					loc6++;
				}
				F644_5549(RTCW(loc5));
				break;
			case 2L:
				tr1 = F679_5867(Current);
				F642_5529(RTCW(tr1), arg1);
				break;
			case 3L:
				break;
			default:
				RTEC(EN_WHEN);
		}
	}
	RTLE;
}

/* {ACTION_SEQUENCE}.extend_kamikaze */
void F679_5844 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F672_5806(Current, arg1);
	F679_5858(Current, arg1);
	RTLE;
}

/* {ACTION_SEQUENCE}.block */
void F679_5848 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O5275[Dtype(Current)-678]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
}

/* {ACTION_SEQUENCE}.resume */
void F679_5850 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current + O5275[dtype-678]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc1 = F679_5867(Current);
	for (;;) {
		tb1 = F483_5233(RTCW(loc1));
		if (tb1) break;
		tr1 = F642_5527(RTCW(loc1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5266[dtype-678])(Current, tr1);
		F639_5513(RTCW(loc1));
	}
	RTLE;
}

/* {ACTION_SEQUENCE}.prune */
void F679_5857 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	F657_5776(Current, arg1);
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		if (*(EIF_BOOLEAN *)(Current + O4814[Dtype(Current)-335])) {
			loc1 = *(EIF_BOOLEAN *)(RTCW(loc2) + O4814[Dtype(loc2)-335]);
			F336_5004(RTCW(loc2));
			F657_5754(RTCW(loc2));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4945[Dtype(RTCW(loc2))-575])(loc2, arg1);
			if ((EIF_BOOLEAN) !loc1) {
				F336_5005(RTCW(loc2));
			}
		} else {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4945[Dtype(RTCW(loc2))-575])(loc2, arg1);
		}
	}
	RTLE;
}

/* {ACTION_SEQUENCE}.prune_when_called */
void F679_5858 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = F679_5872(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4943[Dtype(RTCW(tr1))-638])(tr1, arg1);
	RTLE;
}

/* {ACTION_SEQUENCE}.not_empty_actions */
EIF_REFERENCE F679_5860 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,656,0xFF01,1040,0xFF01,0xFFF9,0,966,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 656, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F657_5723(RTCW(Result), ((EIF_INTEGER_32) 0L));
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {ACTION_SEQUENCE}.empty_actions */
EIF_REFERENCE F679_5861 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,656,0xFF01,1040,0xFF01,0xFFF9,0,966,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 656, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F657_5723(RTCW(Result), ((EIF_INTEGER_32) 0L));
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {ACTION_SEQUENCE}.call_action_list */
void F679_5864 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tb1 = F483_5233(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = F1_14(arg1);
		loc1 = F657_5737(RTCW(tr1));
		for (;;) {
			tb1 = F779_6234(loc1);
			if (tb1) break;
			tr1 = F779_6225(loc1);
			(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE)) *(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_4_2_0_3_0_0_))(
				*(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_4_2_0_3_0_1_),
				*(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_));
			F779_6240(loc1);
		}
	}
	RTLE;
}

/* {ACTION_SEQUENCE}.is_aborted_stack */
EIF_REFERENCE F679_5865 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,643,978,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 643, _OBJSIZ_2_3_0_1_0_0_0_0_);
		}
		F641_5479(RTCW(Result));
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {ACTION_SEQUENCE}.call_buffer */
EIF_REFERENCE F679_5867 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,641,0xFF02,0,0,0xFFFF};
			EIF_TYPE typres0;
			{
				EIF_TYPE l_type;
				l_type = eif_final_id(Y5298,Y5298_gen_type,Dftype(Current),678);
				typarr0[3] = l_type.annotations | 0xFF00;
				typarr0[4] = l_type.id;
			}
			
			typres0 = eif_compound_id(Dftype(Current), typarr0);
			Result = RTLNS(typres0.id, 641, _OBJSIZ_2_3_0_1_0_0_0_0_);
		}
		F642_5525(RTCW(Result));
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {ACTION_SEQUENCE}.kamikazes */
EIF_REFERENCE F679_5872 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,656,0,0,0xFFFF};
			EIF_TYPE typres0;
			{
				EIF_TYPE l_type;
				l_type = eif_final_id(Y4957,Y4957_gen_type,Dftype(Current),443);
				typarr0[2] = l_type.annotations | 0xFF00;
				typarr0[3] = l_type.id;
			}
			
			typres0 = eif_compound_id(Dftype(Current), typarr0);
			Result = RTLNS(typres0.id, 656, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F657_5723(RTCW(Result), ((EIF_INTEGER_32) 0L));
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

void EIF_Minit812 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
