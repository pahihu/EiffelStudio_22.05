
#ifndef _C17_co821_
#define _C17_co821_

#ifdef __cplusplus
extern "C" {
#endif

extern void F337_5004(EIF_REFERENCE);
extern void F337_5005(EIF_REFERENCE);
extern void EIF_Minit821(void);
extern long O4814[];

#ifdef __cplusplus
}
#endif

#endif
