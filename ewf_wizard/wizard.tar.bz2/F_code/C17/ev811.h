
#ifndef _C17_ev811_
#define _C17_ev811_

#ifdef __cplusplus
extern "C" {
#endif

extern void F680_5877(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit811(void);
extern void F679_5843(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F657_5744(EIF_REFERENCE);
extern EIF_REFERENCE F242_3974(EIF_REFERENCE);
extern EIF_REFERENCE F1207_11248(EIF_REFERENCE);
extern void F1212_11365(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,3974)

#ifdef __cplusplus
}
#endif

#endif
