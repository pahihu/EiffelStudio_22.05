
#ifndef _C17_li804_
#define _C17_li804_

#ifdef __cplusplus
extern "C" {
#endif

extern void F639_5479(EIF_REFERENCE);
extern EIF_REFERENCE F639_5481(EIF_REFERENCE);
extern EIF_REFERENCE F639_5482(EIF_REFERENCE);
extern EIF_REFERENCE F639_5483(EIF_REFERENCE);
extern EIF_INTEGER_32 F639_5484(EIF_REFERENCE);
extern EIF_REFERENCE F639_5485(EIF_REFERENCE);
extern EIF_REFERENCE F639_5486(EIF_REFERENCE);
extern EIF_INTEGER_32 F639_5488(EIF_REFERENCE);
extern EIF_BOOLEAN F639_5490(EIF_REFERENCE);
extern EIF_BOOLEAN F639_5491(EIF_REFERENCE);
extern EIF_BOOLEAN F639_5492(EIF_REFERENCE);
extern EIF_BOOLEAN F639_5493(EIF_REFERENCE);
extern EIF_BOOLEAN F639_5494(EIF_REFERENCE);
extern void F639_5498(EIF_REFERENCE);
extern void F639_5499(EIF_REFERENCE);
extern void F639_5500(EIF_REFERENCE);
extern void F639_5502(EIF_REFERENCE, EIF_INTEGER_32);
extern void F639_5503(EIF_REFERENCE, EIF_INTEGER_32);
extern void F639_5504(EIF_REFERENCE, EIF_REFERENCE);
extern void F639_5505(EIF_REFERENCE, EIF_REFERENCE);
extern void F639_5506(EIF_REFERENCE, EIF_REFERENCE);
extern void F639_5509(EIF_REFERENCE, EIF_REFERENCE);
extern void F639_5512(EIF_REFERENCE);
extern void F639_5513(EIF_REFERENCE);
extern void F639_5514(EIF_REFERENCE);
extern void F639_5516(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F639_5518(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F639_5519(EIF_REFERENCE);
extern EIF_REFERENCE F639_5522(EIF_REFERENCE);
extern void F639_5523(EIF_REFERENCE, EIF_REFERENCE);
extern void F639_5524(EIF_REFERENCE);
extern void EIF_Minit804(void);
extern char *(*R4126[])();
extern char *(*R5084[])();
extern char *(*R5523[])();
extern char *(*R5526[])();
extern char *(*R5100[])();
extern char *(*R5101[])();
extern char *(*R4957[])();
extern char *(*R5104[])();
extern char *(*R5105[])();
extern char *(*R5106[])();
extern char *(*R4963[])();
extern char *(*R4922[])();
extern char *(*R4923[])();
extern char *(*R4943[])();
extern char *(*R5081[])();
extern char *(*R5083[])();
extern char *(*R3693[])();
extern char *(*R3694[])();
extern char *(*R4812[])();
extern char *(*R4930[])();
extern char *(*R3698[])();
extern char *(*R3699[])();
extern char *(*R4965[])();
extern char *(*R4935[])();
extern char *(*R4936[])();
extern char *(*R5095[])();
extern long O3697[];
extern EIF_TYPE_INDEX Y4963[];
extern EIF_TYPE_INDEX *Y4963_gen_type [];
extern EIF_TYPE_INDEX Y4957[];
extern EIF_TYPE_INDEX *Y4957_gen_type [];
extern EIF_TYPE_INDEX Y4760[];
extern EIF_TYPE_INDEX *Y4760_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
