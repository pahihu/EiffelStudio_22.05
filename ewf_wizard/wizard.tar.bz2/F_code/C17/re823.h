
#ifndef _C17_re823_
#define _C17_re823_

#ifdef __cplusplus
extern "C" {
#endif

extern void F759_6191(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F759_6193(EIF_REFERENCE);
extern EIF_INTEGER_32 F759_6194(EIF_REFERENCE);
extern EIF_INTEGER_32 F759_6195(EIF_REFERENCE);
extern EIF_INTEGER_32 F759_6196(EIF_REFERENCE);
extern EIF_REFERENCE F759_6197(EIF_REFERENCE);
extern EIF_BOOLEAN F759_6203(EIF_REFERENCE);
extern EIF_BOOLEAN F759_6204(EIF_REFERENCE);
extern EIF_BOOLEAN F759_6205(EIF_REFERENCE);
extern void F759_6210(EIF_REFERENCE);
extern void F759_6211(EIF_REFERENCE);
extern EIF_REFERENCE F759_6212(EIF_REFERENCE);
extern void EIF_Minit823(void);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern char *(*R5523[])();
extern char *(*R4993[])();
extern char *(*R4994[])();
extern char *(*R4996[])();
extern long O5527[];
extern long O5531[];
extern long O5532[];
extern long O5533[];
extern long O5534[];
extern long O5535[];

#ifdef __cplusplus
}
#endif

#endif
