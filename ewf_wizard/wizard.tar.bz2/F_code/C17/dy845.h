
#ifndef _C17_dy845_
#define _C17_dy845_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F604_5453(EIF_REFERENCE);
extern void F604_5459(EIF_REFERENCE, EIF_INTEGER_32);
extern void F604_5460(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit845(void);
extern EIF_BOOLEAN F364_5163(EIF_REFERENCE);
extern char *(*R4962[])();
extern char *(*R4923[])();
extern char *(*R4929[])();

#ifdef __cplusplus
}
#endif

#endif
