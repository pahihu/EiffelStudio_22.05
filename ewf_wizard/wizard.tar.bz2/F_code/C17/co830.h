
#ifndef _C17_co830_
#define _C17_co830_

#ifdef __cplusplus
extern "C" {
#endif

extern void F388_5184(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit830(void);
extern char *(*R4945[])();
extern char *(*R4811[])();

#ifdef __cplusplus
}
#endif

#endif
