
#ifndef _C17_ar840_
#define _C17_ar840_

#ifdef __cplusplus
extern "C" {
#endif

extern void F806_6263(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F806_6264(EIF_REFERENCE);
extern EIF_REFERENCE F806_6265(EIF_REFERENCE);
extern EIF_REFERENCE F806_6267(EIF_REFERENCE);
extern EIF_INTEGER_32 F806_6268(EIF_REFERENCE);
extern void EIF_Minit840(void);
extern EIF_TYPE_INDEX Y5451[];
extern EIF_TYPE_INDEX *Y5451_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
