
#ifndef _C17_ch848_
#define _C17_ch848_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F592_5429(EIF_REFERENCE);
extern EIF_INTEGER_32 F592_5430(EIF_REFERENCE);
extern EIF_BOOLEAN F592_5431(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F592_5433(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F592_5434(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F592_5436(EIF_REFERENCE);
extern void F592_5438(EIF_REFERENCE);
extern EIF_BOOLEAN F592_5441(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F592_5442(EIF_REFERENCE);
extern EIF_BOOLEAN F592_5444(EIF_REFERENCE);
extern void F592_5449(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit848(void);
extern EIF_BOOLEAN F364_5157(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F484_5233(EIF_REFERENCE);
extern EIF_BOOLEAN F604_5453(EIF_REFERENCE);
extern char *(*R4943[])();
extern char *(*R4957[])();
extern char *(*R4922[])();
extern char *(*R4963[])();
extern char *(*R4921[])();
extern char *(*R4965[])();
extern char *(*R4923[])();
extern char *(*R4969[])();
extern char *(*R5082[])();
extern char *(*R4930[])();
extern char *(*R4818[])();
extern char *(*R4935[])();
extern char *(*R4936[])();

#ifdef __cplusplus
}
#endif

#endif
