
#ifndef _C17_ge833_
#define _C17_ge833_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F780_6225(EIF_REFERENCE);
extern EIF_INTEGER_32 F780_6227(EIF_REFERENCE);
extern EIF_BOOLEAN F780_6234(EIF_REFERENCE);
extern void F780_6239(EIF_REFERENCE);
extern void F780_6240(EIF_REFERENCE);
extern EIF_REFERENCE F780_6241(EIF_REFERENCE);
extern void EIF_Minit833(void);
extern char *(*R5539[])();
extern char *(*R5512[])();
extern long O5538[];
extern long O5540[];

#ifdef __cplusplus
}
#endif

#endif
