
#ifndef _C17_re822_
#define _C17_re822_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F553_5295(EIF_REFERENCE);
extern void EIF_Minit822(void);
extern void F759_6191(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5523[])();
extern EIF_TYPE_INDEX Y4760[];
extern EIF_TYPE_INDEX *Y4760_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
