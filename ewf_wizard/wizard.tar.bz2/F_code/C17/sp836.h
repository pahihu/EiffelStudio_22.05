
#ifndef _C17_sp836_
#define _C17_sp836_

#ifdef __cplusplus
extern "C" {
#endif

extern void F818_6269(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F818_6270(EIF_REFERENCE);
extern EIF_REFERENCE F818_6271(EIF_REFERENCE);
extern EIF_INTEGER_32 F818_6272(EIF_REFERENCE);
extern void EIF_Minit836(void);
extern EIF_INTEGER_32 F836_6416(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y5451[];
extern EIF_TYPE_INDEX *Y5451_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
