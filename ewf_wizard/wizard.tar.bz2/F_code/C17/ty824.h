
#ifndef _C17_ty824_
#define _C17_ty824_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F747_6185(EIF_REFERENCE);
extern void EIF_Minit824(void);
extern char *(*R5524[])();
extern char *(*R4992[])();
extern char *(*R5511[])();

#ifdef __cplusplus
}
#endif

#endif
