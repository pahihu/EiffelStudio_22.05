
#ifndef _C17_to841_
#define _C17_to841_

#ifdef __cplusplus
extern "C" {
#endif

extern void F294_4743(EIF_REFERENCE, EIF_INTEGER_32);
extern void F294_4744(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F294_4750(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit841(void);
extern void F836_6405(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y4564[];
extern EIF_TYPE_INDEX *Y4564_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
