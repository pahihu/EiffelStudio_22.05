
#ifndef _C17_bi843_
#define _C17_bi843_

#ifdef __cplusplus
extern "C" {
#endif

extern void F376_5176(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit843(void);
extern EIF_BOOLEAN F484_5233(EIF_REFERENCE);
extern void F364_5159(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R4936[])();
extern char *(*R4937[])();

#ifdef __cplusplus
}
#endif

#endif
