
#ifndef _C17_li808_
#define _C17_li808_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F770_6213(EIF_REFERENCE);
extern EIF_BOOLEAN F770_6214(EIF_REFERENCE);
extern void F770_6215(EIF_REFERENCE);
extern void F770_6216(EIF_REFERENCE);
extern EIF_REFERENCE F770_6217(EIF_REFERENCE);
extern void EIF_Minit808(void);
extern EIF_REFERENCE F746_6185(EIF_REFERENCE);
extern EIF_BOOLEAN F758_6203(EIF_REFERENCE);
extern void F758_6211(EIF_REFERENCE);
extern void F758_6210(EIF_REFERENCE);
extern char *(*R5520[])();
extern char *(*R3693[])();
extern long O3697[];

#ifdef __cplusplus
}
#endif

#endif
