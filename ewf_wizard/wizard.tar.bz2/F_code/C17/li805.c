/*
 * Code for class LINKABLE [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li805.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LINKABLE}.put_right */
void F189_3760 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O3697[Dtype(Current)-188]) = (EIF_REFERENCE) arg1;
}

/* {LINKABLE}.forget_right */
void F189_3761 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_REFERENCE *)(Current + O3697[Dtype(Current)-188]) = (EIF_REFERENCE) NULL;
}

void EIF_Minit805 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
