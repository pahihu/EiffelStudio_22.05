
#ifndef _C17_li849_
#define _C17_li849_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F616_5467(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F616_5468(EIF_REFERENCE);
extern EIF_BOOLEAN F616_5469(EIF_REFERENCE);
extern void EIF_Minit849(void);
extern EIF_BOOLEAN F484_5233(EIF_REFERENCE);
extern char *(*R4957[])();
extern char *(*R4963[])();
extern char *(*R4965[])();
extern char *(*R4923[])();
extern char *(*R4969[])();
extern char *(*R4930[])();
extern char *(*R4934[])();
extern char *(*R4936[])();
extern long O4814[];

#ifdef __cplusplus
}
#endif

#endif
