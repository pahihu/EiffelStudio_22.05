
#ifndef _C17_li805_
#define _C17_li805_

#ifdef __cplusplus
extern "C" {
#endif

extern void F189_3760(EIF_REFERENCE, EIF_REFERENCE);
extern void F189_3761(EIF_REFERENCE);
extern void EIF_Minit805(void);
extern long O3697[];

#ifdef __cplusplus
}
#endif

#endif
