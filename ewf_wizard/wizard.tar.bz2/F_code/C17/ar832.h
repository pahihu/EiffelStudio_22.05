
#ifndef _C17_ar832_
#define _C17_ar832_

#ifdef __cplusplus
extern "C" {
#endif

extern void F792_6245(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F792_6246(EIF_REFERENCE);
extern EIF_REFERENCE F792_6247(EIF_REFERENCE);
extern EIF_REFERENCE F792_6249(EIF_REFERENCE);
extern EIF_INTEGER_32 F792_6250(EIF_REFERENCE);
extern void EIF_Minit832(void);
extern EIF_INTEGER_32 F658_5746(EIF_REFERENCE);
extern EIF_REFERENCE F658_5727(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y5451[];
extern EIF_TYPE_INDEX *Y5451_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
