
#ifndef _C17_dy801_
#define _C17_dy801_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F429_5199(EIF_REFERENCE);
extern void EIF_Minit801(void);

#ifdef __cplusplus
}
#endif

#endif
