
#ifndef _C17_li819_
#define _C17_li819_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F364_5157(EIF_REFERENCE, EIF_INTEGER_32);
extern void F364_5159(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F364_5163(EIF_REFERENCE);
extern EIF_BOOLEAN F364_5165(EIF_REFERENCE);
extern EIF_REFERENCE F364_5172(EIF_REFERENCE);
extern void EIF_Minit819(void);
extern char *(*R4921[])();
extern char *(*R4922[])();
extern char *(*R4923[])();
extern char *(*R4929[])();
extern char *(*R4812[])();
extern char *(*R4934[])();
extern char *(*R4936[])();
extern long O4814[];

#ifdef __cplusplus
}
#endif

#endif
