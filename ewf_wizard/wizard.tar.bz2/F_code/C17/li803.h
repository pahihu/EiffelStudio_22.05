
#ifndef _C17_li803_
#define _C17_li803_

#ifdef __cplusplus
extern "C" {
#endif

extern void F642_5525(EIF_REFERENCE);
extern EIF_REFERENCE F642_5527(EIF_REFERENCE);
extern void F642_5529(EIF_REFERENCE, EIF_REFERENCE);
extern void F642_5530(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F642_5531(EIF_REFERENCE);
extern void F642_5533(EIF_REFERENCE, EIF_REFERENCE);
extern void F642_5534(EIF_REFERENCE, EIF_REFERENCE);
extern void F642_5535(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit803(void);
extern EIF_REFERENCE F639_5485(EIF_REFERENCE);
extern void F639_5506(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F639_5481(EIF_REFERENCE);
extern void F639_5504(EIF_REFERENCE, EIF_REFERENCE);
extern void F639_5498(EIF_REFERENCE);
extern EIF_BOOLEAN F639_5492(EIF_REFERENCE);
extern EIF_BOOLEAN F483_5233(EIF_REFERENCE);
extern void F639_5500(EIF_REFERENCE);
extern void F639_5524(EIF_REFERENCE);
extern void F639_5505(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R4943[])();
extern char *(*R4957[])();
extern char *(*R5234[])();
extern char *(*R3693[])();
extern char *(*R4935[])();
extern char *(*R4937[])();
extern char *(*R4938[])();
extern EIF_TYPE_INDEX Y4760[];
extern EIF_TYPE_INDEX *Y4760_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
