
#ifndef _C17_in813_
#define _C17_in813_

#ifdef __cplusplus
extern "C" {
#endif

extern void F672_5801(EIF_REFERENCE);
extern void F672_5806(EIF_REFERENCE, EIF_REFERENCE);
extern void F672_5807(EIF_REFERENCE, EIF_REFERENCE);
extern void F672_5808(EIF_REFERENCE, EIF_REFERENCE);
extern void F672_5810(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F672_5811(EIF_REFERENCE, EIF_REFERENCE);
extern void F672_5812(EIF_REFERENCE);
extern void F672_5816(EIF_REFERENCE, EIF_REFERENCE);
extern void F672_5818(EIF_REFERENCE);
extern void F672_5821(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F672_5822(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit813(void);
extern void F657_5767(EIF_REFERENCE, EIF_REFERENCE);
extern void F657_5764(EIF_REFERENCE, EIF_REFERENCE);
extern void F657_5765(EIF_REFERENCE, EIF_REFERENCE);
extern void F657_5777(EIF_REFERENCE);
extern void F657_5782(EIF_REFERENCE);
extern void F657_5762(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern char *(*R4943[])();
extern char *(*R5448[])();
extern char *(*R5449[])();
extern char *(*R5252[])();
extern char *(*R5253[])();
extern char *(*R5257[])();
extern char *(*R5258[])();
extern char *(*R4759[])();
extern char *(*R4992[])();
extern char *(*R4950[])();
extern char *(*R4957[])();
extern char *(*R5688[])();
extern char *(*R5450[])();
extern char *(*R4969[])();
extern char *(*R5234[])();
extern char *(*R5238[])();
extern char *(*R4970[])();
extern char *(*R5702[])();
extern char *(*R4976[])();
extern long O4814[];
extern long O5248[];
extern long O5256[];

#ifdef __cplusplus
}
#endif

#endif
