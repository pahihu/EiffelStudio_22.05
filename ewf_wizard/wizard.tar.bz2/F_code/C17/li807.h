
#ifndef _C17_li807_
#define _C17_li807_

#ifdef __cplusplus
extern "C" {
#endif

extern void F247_4248(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_BOOLEAN);
extern void EIF_Minit807(void);

#ifdef __cplusplus
}
#endif

#endif
