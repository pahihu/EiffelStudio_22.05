/*
 * Code for class EV_DRAWABLE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev718.h"
#include <cairo.h>
#include <ev_gtk.h>
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F18_511
static void inline_F18_511 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	double len = 2.0;
if (arg2) {
	cairo_set_dash ((cairo_t *) arg1, &len, 1, 0.0);
} else {
	cairo_set_dash ((cairo_t *) arg1, NULL, 0, 0.0);
}
	;
}
#define INLINE_F18_511
#endif
#ifndef INLINE_F18_462
static EIF_NATURAL_32 inline_F18_462 (EIF_POINTER arg1)
{
	return (EIF_NATURAL_32) (cairo_get_reference_count((cairo_t*) arg1))
	;
}
#define INLINE_F18_462
#endif
#ifndef INLINE_F104_2020
static EIF_POINTER inline_F104_2020 (EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	return gdk_pixbuf_new ((GdkColorspace) arg1, (gboolean) arg2, (int) arg3, (int) arg4, (int) arg5);
	;
}
#define INLINE_F104_2020
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DRAWABLE_IMP}.init_default_values */
void F1363_13776 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R10547[dtype-1363])(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R10539[dtype-1363])(Current, ((EIF_INTEGER_32) 1L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R10540[dtype-1363])(Current, ((EIF_INTEGER_32) 0L));
	loc1 = *(EIF_POINTER *)(Current + O10627[dtype-1362]);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc1 != tp1)) {
		cairo_set_antialias((cairo_t*) loc1, (cairo_antialias_t) ((EIF_INTEGER_8) 1L));
		cairo_set_line_cap((cairo_t*) loc1, (cairo_line_cap_t) ((EIF_INTEGER_8) 0L));
	}
	*(EIF_INTEGER_8 *)(Current + O10635[dtype-1362]) = (EIF_INTEGER_8) ((EIF_INTEGER_8) 1L);
	*(EIF_INTEGER_8 *)(Current + O10636[dtype-1362]) = (EIF_INTEGER_8) ((EIF_INTEGER_8) 0L);
	RTLE;
}

/* {EV_DRAWABLE_IMP}.get_new_cairo_context */
void F1363_13781 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1363_13847(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R10630[Dtype(Current)-1363])(Current);
	RTLE;
}

/* {EV_DRAWABLE_IMP}.foreground_color_internal */
EIF_REFERENCE F1363_13790 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O10660[Dtype(Current)-1362]);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		loc1 = F1090_9700(loc4);
		loc2 = F1090_9701(loc4);
		loc3 = F1090_9702(loc4);
	}
	tr1 = RTLNS(eif_new_type(1089, 0x01).id, 1089, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1090_9683(RTCW(tr1), loc1, loc2, loc3);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {EV_DRAWABLE_IMP}.background_color_internal */
EIF_REFERENCE F1363_13791 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O10661[Dtype(Current)-1362]);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		loc1 = F1090_9700(loc4);
		loc2 = F1090_9701(loc4);
		loc3 = F1090_9702(loc4);
	} else {
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 255L);
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 255L);
		loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 255L);
	}
	tr1 = RTLNS(eif_new_type(1089, 0x01).id, 1089, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1090_9683(RTCW(tr1), loc1, loc2, loc3);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {EV_DRAWABLE_IMP}.line_width */
EIF_INTEGER_32 F1363_13792 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O10669[Dtype(Current)-1362]);
}


/* {EV_DRAWABLE_IMP}.drawing_mode */
EIF_INTEGER_32 F1363_13793 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O10668[Dtype(Current)-1362]);
}


/* {EV_DRAWABLE_IMP}.tile */
EIF_REFERENCE F1363_13797 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O10667[Dtype(Current)-1362]);
}


/* {EV_DRAWABLE_IMP}.dashed_line_style */
EIF_BOOLEAN F1363_13798 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current + O10666[Dtype(Current)-1362]);
}


/* {EV_DRAWABLE_IMP}.set_font */
void F1363_13799 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1205, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + O10665[Dtype(Current)-1362]) = (EIF_REFERENCE) loc1;
	} else {
	}
	RTLE;
}

/* {EV_DRAWABLE_IMP}.set_background_color */
void F1363_13800 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O10661[dtype-1362]);
	loc1 = tr1;
	if ((EIF_BOOLEAN) !EIF_TEST(loc1)) {
		tr1 = RTLNSMART(eif_new_type(1089, 0).id);
		ti4_1 = F1090_9700(RTCW(arg1));
		ti4_2 = F1090_9701(RTCW(arg1));
		ti4_3 = F1090_9702(RTCW(arg1));
		F1090_9683(RTCW(tr1), ti4_1, ti4_2, ti4_3);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O10661[dtype-1362]) = (EIF_REFERENCE) tr1;
	} else {
		tb1 = F1090_9714(loc1, arg1);
		if ((EIF_BOOLEAN) !tb1) {
			ti4_1 = F1090_9700(RTCW(arg1));
			F1090_9703(loc1, ti4_1);
			ti4_1 = F1090_9701(RTCW(arg1));
			F1090_9704(loc1, ti4_1);
			ti4_1 = F1090_9702(RTCW(arg1));
			F1090_9705(loc1, ti4_1);
		}
	}
	tr4_1 = F1090_9685(RTCW(arg1));
	tr8_1 = (EIF_REAL_64) (tr4_1);
	tr4_1 = F1090_9686(RTCW(arg1));
	tr8_2 = (EIF_REAL_64) (tr4_1);
	tr4_1 = F1090_9687(RTCW(arg1));
	tr8_3 = (EIF_REAL_64) (tr4_1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_BOOLEAN, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64)) R10657[dtype-1363])(Current, (EIF_BOOLEAN) 0, tr8_1, tr8_2, tr8_3);
	RTLE;
}

/* {EV_DRAWABLE_IMP}.set_foreground_color */
void F1363_13801 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O10660[dtype-1362]);
	loc1 = tr1;
	if ((EIF_BOOLEAN) !EIF_TEST(loc1)) {
		tr1 = RTLNSMART(eif_new_type(1089, 0).id);
		ti4_1 = F1090_9700(RTCW(arg1));
		ti4_2 = F1090_9701(RTCW(arg1));
		ti4_3 = F1090_9702(RTCW(arg1));
		F1090_9683(RTCW(tr1), ti4_1, ti4_2, ti4_3);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O10660[dtype-1362]) = (EIF_REFERENCE) tr1;
	} else {
		tb1 = F1090_9714(loc1, arg1);
		if ((EIF_BOOLEAN) !tb1) {
			ti4_1 = F1090_9700(RTCW(arg1));
			F1090_9703(loc1, ti4_1);
			ti4_1 = F1090_9701(RTCW(arg1));
			F1090_9704(loc1, ti4_1);
			ti4_1 = F1090_9702(RTCW(arg1));
			F1090_9705(loc1, ti4_1);
		}
	}
	tr4_1 = F1090_9685(RTCW(arg1));
	tr8_1 = (EIF_REAL_64) (tr4_1);
	tr4_1 = F1090_9686(RTCW(arg1));
	tr8_2 = (EIF_REAL_64) (tr4_1);
	tr4_1 = F1090_9687(RTCW(arg1));
	tr8_3 = (EIF_REAL_64) (tr4_1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_BOOLEAN, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64)) R10657[dtype-1363])(Current, (EIF_BOOLEAN) 1, tr8_1, tr8_2, tr8_3);
	RTLE;
}

/* {EV_DRAWABLE_IMP}.set_line_width */
void F1363_13802 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REAL_64 tr8_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current + O10627[dtype-1362]) != tp1)) {
		tp1 = *(EIF_POINTER *)(Current + O10627[dtype-1362]);
		tr8_1 = (EIF_REAL_64) (arg1);
		cairo_set_line_width((cairo_t*) tp1, (double) tr8_1);
	}
	*(EIF_INTEGER_32 *)(Current + O10669[dtype-1362]) = (EIF_INTEGER_32) arg1;
	RTLE;
}

/* {EV_DRAWABLE_IMP}.set_drawing_mode */
void F1363_13803 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_8 ti1_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current + O10627[dtype-1362]) != tp1)) {
		tp1 = *(EIF_POINTER *)(Current + O10627[dtype-1362]);
		ti1_1 = F1363_13804(Current, arg1);
		cairo_set_operator((cairo_t*) tp1, (cairo_operator_t) ti1_1);
	}
	*(EIF_INTEGER_32 *)(Current + O10668[dtype-1362]) = (EIF_INTEGER_32) arg1;
	RTLE;
}

/* {EV_DRAWABLE_IMP}.cairo_drawing_mode */
EIF_INTEGER_8 F1363_13804 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	
	
	RTGC;
	switch (arg1) {
		case 0L:
			Result = (EIF_INTEGER_8) CAIRO_OPERATOR_OVER;
			break;
		case 3L:
			Result = (EIF_INTEGER_8) CAIRO_OPERATOR_MULTIPLY;
			break;
		case 1L:
			Result = (EIF_INTEGER_8) CAIRO_OPERATOR_DIFFERENCE;
			break;
		case 2L:
			Result = (EIF_INTEGER_8) CAIRO_OPERATOR_EXCLUSION;
			break;
		case 4L:
			Result = (EIF_INTEGER_8) CAIRO_OPERATOR_ATOP;
			break;
		default:
			break;
	}
	return Result;
}

/* {EV_DRAWABLE_IMP}.enable_dashed_line_style */
void F1363_13810 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O10666[dtype-1362]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current + O10627[dtype-1362]) != tp1)) {
		tp1 = *(EIF_POINTER *)(Current + O10627[dtype-1362]);
		inline_F18_511(tp1, (EIF_BOOLEAN) 1);
	}
	RTLE;
}

/* {EV_DRAWABLE_IMP}.disable_dashed_line_style */
void F1363_13811 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O10666[dtype-1362]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current + O10627[dtype-1362]) != tp1)) {
		tp1 = *(EIF_POINTER *)(Current + O10627[dtype-1362]);
		inline_F18_511(tp1, (EIF_BOOLEAN) 0);
	}
	RTLE;
}

/* {EV_DRAWABLE_IMP}.set_background_transparency */
void F1363_13813 (EIF_REFERENCE Current, EIF_REAL_64 arg1)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O10640[dtype-1362]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_REAL_64 *)(Current + O10641[dtype-1362]) = (EIF_REAL_64) arg1;
	RTLE;
}

/* {EV_DRAWABLE_IMP}.clear */
void F1363_13817 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10531[dtype-1363])(Current);
	ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10532[dtype-1363])(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R10556[dtype-1363])(Current, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ti4_1, ti4_2);
	RTLE;
}

/* {EV_DRAWABLE_IMP}.clear_rectangle */
void F1363_13818 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_REAL_64 tr8_4;
	EIF_REAL_32 tr4_1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (arg3 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (arg4 > ((EIF_INTEGER_32) 0L)))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R10632[dtype-1363])(Current);
		loc1 = *(EIF_POINTER *)(Current + O10627[dtype-1362]);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(loc1 != tp1)) {
			loc2 = F1226_11773(Current);
			tr1 = *(EIF_REFERENCE *)(Current + O10661[dtype-1362]);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				if (*(EIF_BOOLEAN *)(Current + O10640[dtype-1362])) {
					tr4_1 = F1090_9685(loc3);
					tr8_1 = (EIF_REAL_64) (tr4_1);
					tr4_1 = F1090_9686(loc3);
					tr8_2 = (EIF_REAL_64) (tr4_1);
					tr4_1 = F1090_9687(loc3);
					tr8_3 = (EIF_REAL_64) (tr4_1);
					tr8_4 = *(EIF_REAL_64 *)(Current + O10641[dtype-1362]);
					cairo_set_source_rgba((cairo_t*) loc1, (double) tr8_1, (double) tr8_2, (double) tr8_3, (double) tr8_4);
				} else {
					tr4_1 = F1090_9685(loc3);
					tr8_1 = (EIF_REAL_64) (tr4_1);
					tr4_1 = F1090_9686(loc3);
					tr8_2 = (EIF_REAL_64) (tr4_1);
					tr4_1 = F1090_9687(loc3);
					tr8_3 = (EIF_REAL_64) (tr4_1);
					cairo_set_source_rgb((cairo_t*) loc1, (double) tr8_1, (double) tr8_2, (double) tr8_3);
				}
			} else {
				if (*(EIF_BOOLEAN *)(Current + O10640[dtype-1362])) {
					tr8_1 = *(EIF_REAL_64 *)(Current + O10641[dtype-1362]);
					cairo_set_source_rgba((cairo_t*) loc1, (double) (EIF_REAL_64) 1.0, (double) (EIF_REAL_64) 1.0, (double) (EIF_REAL_64) 1.0, (double) tr8_1);
				} else {
					cairo_set_source_rgb((cairo_t*) loc1, (double) (EIF_REAL_64) 1.0, (double) (EIF_REAL_64) 1.0, (double) (EIF_REAL_64) 1.0);
				}
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R10573[dtype-1363])(Current, arg1, arg2, arg3, arg4);
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				tr4_1 = F1090_9685(RTCW(loc2));
				tr8_1 = (EIF_REAL_64) (tr4_1);
				tr4_1 = F1090_9686(RTCW(loc2));
				tr8_2 = (EIF_REAL_64) (tr4_1);
				tr4_1 = F1090_9687(RTCW(loc2));
				tr8_3 = (EIF_REAL_64) (tr4_1);
				cairo_set_source_rgb((cairo_t*) loc1, (double) tr8_1, (double) tr8_2, (double) tr8_3);
			}
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R10633[dtype-1363])(Current);
	}
	RTLE;
}

/* {EV_DRAWABLE_IMP}.draw_point */
void F1363_13819 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R10563[Dtype(Current)-1363])(Current, arg1, arg2, (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L)));
}

/* {EV_DRAWABLE_IMP}.draw_segment */
void F1363_13827 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R10632[dtype-1363])(Current);
	loc1 = *(EIF_POINTER *)(Current + O10627[dtype-1362]);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc1 != tp1)) {
		tr8_1 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg1 + (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10655[dtype-1363])(Current)));
		tr8_2 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg2 + (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10656[dtype-1363])(Current)));
		cairo_move_to((cairo_t*) loc1, (double) (EIF_REAL_64) (tr8_1 + (EIF_REAL_64) 0.5), (double) (EIF_REAL_64) (tr8_2 + (EIF_REAL_64) 0.5));
		tr8_1 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg3 + (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10655[dtype-1363])(Current)));
		tr8_2 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg4 + (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10656[dtype-1363])(Current)));
		cairo_line_to((cairo_t*) loc1, (double) (EIF_REAL_64) (tr8_1 + (EIF_REAL_64) 0.5), (double) (EIF_REAL_64) (tr8_2 + (EIF_REAL_64) 0.5));
		cairo_stroke((cairo_t*) loc1);
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R10633[dtype-1363])(Current);
	RTLE;
}

/* {EV_DRAWABLE_IMP}.draw_ellipse */
void F1363_13836 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
	tr8_2 = (EIF_REAL_64) (((EIF_INTEGER_32) 2L));
	F1363_13837(Current, arg1, arg2, arg3, arg4, tr8_1, (EIF_REAL_64) (tr8_2 * 3.1415926535897931), (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
	RTLE;
}

/* {EV_DRAWABLE_IMP}.draw_ellipse_internal */
void F1363_13837 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_BOOLEAN arg7, EIF_BOOLEAN arg8)
{
	GTCX
	EIF_REAL_64 loc1 = (EIF_REAL_64) 0;
	EIF_REAL_64 loc2 = (EIF_REAL_64) 0;
	EIF_REAL_64 loc3 = (EIF_REAL_64) 0;
	EIF_REAL_64 loc4 = (EIF_REAL_64) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_POINTER loc6 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (arg3 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (arg4 > ((EIF_INTEGER_32) 0L)))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R10632[dtype-1363])(Current);
		loc6 = *(EIF_POINTER *)(Current + O10627[dtype-1362]);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(loc6 != tp1)) {
			loc5 = '\0';
			if (arg7) {
				tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 2L));
				loc5 = (EIF_BOOLEAN) !eif_is_equal_real_64 (arg6, (EIF_REAL_64) (tr8_1 * 3.1415926535897931));
			}
			loc1 = (EIF_REAL_64) (arg1);
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10655[dtype-1363])(Current);
			tr8_1 = (EIF_REAL_64) (ti4_1);
			loc1 = (EIF_REAL_64) (EIF_REAL_64) ((EIF_REAL_64) (loc1 + (EIF_REAL_64) ((EIF_REAL_64) (arg3) /  (EIF_REAL_64) (((EIF_INTEGER_32) 2L)))) + tr8_1);
			loc2 = (EIF_REAL_64) (arg2);
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10656[dtype-1363])(Current);
			tr8_1 = (EIF_REAL_64) (ti4_1);
			loc2 = (EIF_REAL_64) (EIF_REAL_64) ((EIF_REAL_64) (loc2 + (EIF_REAL_64) ((EIF_REAL_64) (arg4) /  (EIF_REAL_64) (((EIF_INTEGER_32) 2L)))) + tr8_1);
			loc3 = (EIF_REAL_64) (EIF_REAL_64) ((EIF_REAL_64) (arg3) /  (EIF_REAL_64) (((EIF_INTEGER_32) 2L)));
			if ((EIF_BOOLEAN)(arg3 != arg4)) {
				loc4 = (EIF_REAL_64) (EIF_REAL_64) ((EIF_REAL_64) (arg4) /  (EIF_REAL_64) (arg3));
				cairo_scale((cairo_t*) loc6, (double) (EIF_REAL_64) 1.0, (double) loc4);
				ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10656[dtype-1363])(Current);
				tr8_1 = (EIF_REAL_64) (ti4_1);
				ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10656[dtype-1363])(Current);
				tr8_2 = (EIF_REAL_64) (ti4_1);
				loc2 = (EIF_REAL_64) (EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) (loc2 - tr8_1)) /  (EIF_REAL_64) (loc4)) + tr8_2);
			}
			if (loc5) {
				cairo_move_to((cairo_t*) loc6, (double) loc1, (double) loc2);
			}
			cairo_arc_negative((cairo_t*) loc6, (double) loc1, (double) loc2, (double) loc3, (double) (EIF_REAL_64) -arg5, (double) (EIF_REAL_64) -(EIF_REAL_64) (arg5 + arg6));
			if (arg8) {
				cairo_stroke_preserve((cairo_t*) loc6);
				tr1 = RTLNS(eif_new_type(17, 0x01).id, 17, _OBJSIZ_0_0_0_0_0_0_0_0_);
				F18_514(RTCW(tr1), loc6);
			}
			if (loc5) {
				cairo_close_path((cairo_t*) loc6);
			}
			cairo_stroke((cairo_t*) loc6);
			if ((EIF_BOOLEAN)(arg3 != arg4)) {
				cairo_scale((cairo_t*) loc6, (double) (EIF_REAL_64) 1.0, (double) (EIF_REAL_64) 1.0);
			}
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R10633[dtype-1363])(Current);
	}
	RTLE;
}

/* {EV_DRAWABLE_IMP}.fill_rectangle */
void F1363_13841 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	
	
	F1363_13842(Current, arg1, arg2, arg3, arg4, (EIF_BOOLEAN) 1);
}

/* {EV_DRAWABLE_IMP}.draw_rectangle_internal */
void F1363_13842 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_BOOLEAN arg5)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_REAL_64 tr8_4;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (arg3 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (arg4 > ((EIF_INTEGER_32) 0L)))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R10632[dtype-1363])(Current);
		loc1 = *(EIF_POINTER *)(Current + O10627[dtype-1362]);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(loc1 != tp1)) {
			tr8_1 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg1 + (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10655[dtype-1363])(Current)));
			tr8_2 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg2 + (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10656[dtype-1363])(Current)));
			tr8_3 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg3 - *(EIF_INTEGER_32 *)(Current + O10669[dtype-1362])));
			tr8_4 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg4 - *(EIF_INTEGER_32 *)(Current + O10669[dtype-1362])));
			cairo_rectangle((cairo_t*) loc1, (double) (EIF_REAL_64) (tr8_1 + (EIF_REAL_64) 0.5), (double) (EIF_REAL_64) (tr8_2 + (EIF_REAL_64) 0.5), (double) tr8_3, (double) tr8_4);
			if (arg5) {
				cairo_stroke_preserve((cairo_t*) loc1);
				tr1 = RTLNS(eif_new_type(17, 0x01).id, 17, _OBJSIZ_0_0_0_0_0_0_0_0_);
				F18_514(RTCW(tr1), loc1);
			}
			cairo_stroke((cairo_t*) loc1);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R10633[dtype-1363])(Current);
	}
	RTLE;
}

/* {EV_DRAWABLE_IMP}.fill_ellipse */
void F1363_13843 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
	tr8_2 = (EIF_REAL_64) (((EIF_INTEGER_32) 2L));
	F1363_13837(Current, arg1, arg2, arg3, arg4, tr8_1, (EIF_REAL_64) (tr8_2 * 3.1415926535897931), (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_DRAWABLE_IMP}.release_cairo_context */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F1363_13846 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTED;
	EIF_BOOLEAN EIF_VOLATILE loc1 = (EIF_BOOLEAN) 0;
	EIF_NATURAL_32 EIF_VOLATILE loc2 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_BOOLEAN  EIF_VOLATILE tb2;
	RTLD;
	RTXD;
	
	RTLI(1);
	RTLR(0,saved_except);
	RTLIU(1);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	tb1 = '\0';
	if ((EIF_BOOLEAN) !loc1) {
		tb2 = !arg1;
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		loc2 = inline_F18_462(arg1);
		if ((EIF_BOOLEAN) (loc2 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L))) {
			if ((EIF_BOOLEAN) (loc2 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 10000L))) {
			}
			cairo_destroy((cairo_t*) arg1);
		} else {
		}
	}
	RTE_E
	RTXSC;
	loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {EV_DRAWABLE_IMP}.clear_cairo_context */
void F1363_13847 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_NATURAL_32 loc2 = (EIF_NATURAL_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = *(EIF_POINTER *)(Current + O10627[dtype-1362]);
	tb1 = !loc1;
	if ((EIF_BOOLEAN) !tb1) {
		loc2 = inline_F18_462(loc1);
		F1363_13846(Current, loc1);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current + O10627[dtype-1362]) = (EIF_POINTER) tp2;
		if ((EIF_BOOLEAN) (loc2 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L))) {
		}
	}
	RTLE;
}

/* {EV_DRAWABLE_IMP}.pixbuf_from_drawable */
EIF_POINTER F1363_13849 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10531[dtype-1363])(Current);
	ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10532[dtype-1363])(Current);
	Result = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R10653[dtype-1363])(Current, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ti4_1, ti4_2);
	RTLE;
	return Result;
}

/* {EV_DRAWABLE_IMP}.pixbuf_from_drawable_at_position */
EIF_POINTER F1363_13850 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6)
{
	GTCX
	
	
	return (EIF_POINTER) inline_F104_2020(((EIF_INTEGER_32) 0L), (EIF_BOOLEAN) 1, ((EIF_INTEGER_32) 8L), arg5, arg6);
}

/* {EV_DRAWABLE_IMP}.device_x_offset */
EIF_INTEGER_32 F1363_13852 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_INTEGER_32) 0;
}

/* {EV_DRAWABLE_IMP}.device_y_offset */
EIF_INTEGER_32 F1363_13853 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_INTEGER_32) 0;
}

/* {EV_DRAWABLE_IMP}.internal_set_color */
void F1363_13854 (EIF_REFERENCE Current, EIF_BOOLEAN arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4)
{
	GTCX
	EIF_POINTER tp1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tb1 = '\0';
	tp1 = *(EIF_POINTER *)(Current + O10627[dtype-1362]);
	tb2 = !tp1;
	if ((EIF_BOOLEAN) !tb2) {
		tb1 = arg1;
	}
	if (tb1) {
		tp1 = *(EIF_POINTER *)(Current + O10627[dtype-1362]);
		cairo_set_source_rgb((cairo_t*) tp1, (double) arg2, (double) arg3, (double) arg4);
	}
	RTLE;
}

void EIF_Minit718 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
