
#ifndef _C15_ew734_
#define _C15_ew734_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1379_14207(EIF_REFERENCE);
extern EIF_REFERENCE F1379_14208(EIF_REFERENCE);
extern void EIF_Minit734(void);
extern void F310_4868(EIF_REFERENCE);
extern void F1378_14197(EIF_REFERENCE);
extern void F129_3062(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
