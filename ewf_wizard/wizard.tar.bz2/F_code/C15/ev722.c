/*
 * Code for class EV_SCREEN_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev722.h"
#include <ev_gtk.h>
#include "ev_any_imp.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F104_2029
static EIF_POINTER inline_F104_2029 (void)
{
	return gdk_screen_get_default()
	;
}
#define INLINE_F104_2029
#endif
#ifndef INLINE_F104_2031
static EIF_POINTER inline_F104_2031 (EIF_POINTER arg1)
{
	return gdk_screen_get_root_window ((GdkScreen *)arg1);;
	;
}
#define INLINE_F104_2031
#endif
#ifndef INLINE_F103_1780
static EIF_POINTER inline_F103_1780 (EIF_POINTER arg1)
{
	#ifdef GDK_WINDOWING_X11 
		/* Declarations */
	GC gc;									/* handle of newly created GC.  */
	unsigned long valuemask = 0;			/* which values in 'values' to  */
	Window win =  gdk_x11_window_get_xid ((GdkWindow *)arg1);
	Display* display = GDK_SCREEN_XDISPLAY(gdk_window_get_screen ((GdkWindow *)arg1));
		/* Define properties/values for the GC.  */
	XGCValues values;						/* initial values for the GC.   */
	unsigned int line_width = 1;			/* line width for the GC.       */
	int line_style = LineSolid;				/* style for lines drawing and  */
	int cap_style = CapButt;				/* style of the line's edje and */
	int join_style = JoinBevel;				/* joined lines.		*/
	values.function = GXcopy;               /* src */
	values.subwindow_mode = ClipByChildren; /* GCSubwindowMode */
	values.line_width = line_width;
	values.fill_style = FillSolid;
	values.arc_mode = ArcPieSlice;
	values.graphics_exposures = False;
	valuemask = GCFunction | GCFillStyle | GCArcMode | GCSubwindowMode | GCGraphicsExposures;
		/* Create the GC object */
	gc = XCreateGC(display, win, valuemask, &values);
	if (gc < 0) {
		fprintf(stderr, "XCreateGC: \n");
	}
	return gc;
#endif
	;
}
#define INLINE_F103_1780
#endif
#ifndef INLINE_F103_1784
static EIF_POINTER inline_F103_1784 (EIF_POINTER arg1)
{
	#ifdef GDK_WINDOWING_X11 
	return (EIF_POINTER) GDK_SCREEN_XDISPLAY(gdk_window_get_screen ((GdkWindow *)arg1));
#endif
	;
}
#define INLINE_F103_1784
#endif
#ifndef INLINE_F103_1803
static EIF_INTEGER_32 inline_F103_1803 (void)
{
	#ifdef GDK_WINDOWING_X11 
return IncludeInferiors;
#endif
	;
}
#define INLINE_F103_1803
#endif
#ifndef INLINE_F103_1787
static void inline_F103_1787 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	#ifdef GDK_WINDOWING_X11 
XSetSubwindowMode((Display *)arg1, (GC)arg2, (int)arg3);
#endif
	;
}
#define INLINE_F103_1787
#endif
#ifndef INLINE_F104_2024
static EIF_INTEGER_32 inline_F104_2024 (EIF_POINTER arg1)
{
	return gdk_screen_get_resolution ((GdkScreen*)arg1);
	;
}
#define INLINE_F104_2024
#endif
#ifndef INLINE_F103_1827
static void inline_F103_1827 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_BOOLEAN arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8)
{
	#ifdef GDK_WINDOWING_X11 
					Window win = (Window) arg1;
					if (arg7 < 0 || arg8 < 0)
					{
						gint real_width;
						gint real_height;
						
						XWindowAttributes wa;
						XGetWindowAttributes((Display*) arg2, win, &wa);
						real_width = wa.width;
						real_height = wa.height;
					   
					   	if (arg7 < 0)
							arg7 = real_width;
						if (arg8 < 0)
							arg8 = real_height;
					}

					if (arg4)
					    XFillRectangle ((Display*) arg2, win, arg3, arg5, arg6, arg7, arg8);
					else
					    XDrawRectangle ((Display*) arg2, win, arg3, arg5, arg6, arg7, arg8);

				#endif
	;
}
#define INLINE_F103_1827
#endif
#ifndef INLINE_F103_1824
static void inline_F103_1824 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7)
{
	#ifdef GDK_WINDOWING_X11 
	Window win = (Window) arg1;
	/*
	 * TODO check Gdkgc-x11 _gdk_x11_gc_flush implementation 
	 * that's used before
	 * for example gdk_x11_draw_segments the usage of
	 * GDK_GC_GET_XGC (gc),
	 * https://github.com/coapp-packages/gtk/blob/master/gdk/x11/gdkdrawable-x11.c
	 */
						
	XDrawLine((Display*) arg2, win, arg3, arg4, arg5, arg6, arg7);
	
#endif
	;
}
#define INLINE_F103_1824
#endif
#ifndef INLINE_F103_1826
static void inline_F103_1826 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_BOOLEAN arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_INTEGER_32 arg10)
{
	#ifdef GDK_WINDOWING_X11 
					Window win = (Window) arg1;
					if (arg7 < 0 || arg8 < 0)
					{
						gint real_width;
						gint real_height;
						XWindowAttributes wa;
						XGetWindowAttributes((Display*) arg2, win, &wa);
						real_width = wa.width;
						real_height = wa.height;

						if (arg7 < 0)
							arg7 = real_width;
						if (arg8 < 0)
							arg8 = real_height;
					}

					if (arg4)
					    XFillArc ((Display*) arg2, win, arg3, arg5, arg6, arg7, arg8, arg9, arg10);
					else
					    XDrawArc ((Display*) arg2, win, arg3, arg5, arg6, arg7, arg8, arg9, arg10);	
	
				#endif
	;
}
#define INLINE_F103_1826
#endif
#ifndef INLINE_F103_1825
static void inline_F103_1825 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	#ifdef GDK_WINDOWING_X11 
	XDrawPoint ((Display*) arg2, (Drawable) arg1, arg3, arg4, arg5);
#endif
	;
}
#define INLINE_F103_1825
#endif
#ifndef INLINE_F103_1794
static EIF_INTEGER_32 inline_F103_1794 (void)
{
	#ifdef GDK_WINDOWING_X11
return FillTiled;
#endif
	;
}
#define INLINE_F103_1794
#endif
#ifndef INLINE_F103_1790
static void inline_F103_1790 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	#ifdef GDK_WINDOWING_X11 
XSetFillStyle((Display*)arg1, (GC) arg2, (int)arg3);	
#endif
	;
}
#define INLINE_F103_1790
#endif
#ifndef INLINE_F103_1793
static EIF_INTEGER_32 inline_F103_1793 (void)
{
	#ifdef GDK_WINDOWING_X11
return FillSolid;
#endif
	;
}
#define INLINE_F103_1793
#endif
#ifndef INLINE_F103_1792
static void inline_F103_1792 (EIF_POINTER arg1)
{
	#ifdef GDK_WINDOWING_X11 
	XFlush((Display*) arg1);
#endif
	;
}
#define INLINE_F103_1792
#endif
#ifndef INLINE_F103_1785
static EIF_POINTER inline_F103_1785 (EIF_POINTER arg1)
{
	#ifdef GDK_WINDOWING_X11 
	return (EIF_POINTER) gdk_x11_window_get_xid ((GdkWindow *) arg1);
#endif
	;
}
#define INLINE_F103_1785
#endif
#ifndef INLINE_F103_1811
static EIF_INTEGER_32 inline_F103_1811 (void)
{
	#ifdef GDK_WINDOWING_X11
return GXcopy;
#endif
	;
}
#define INLINE_F103_1811
#endif
#ifndef INLINE_F103_1786
static void inline_F103_1786 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	#ifdef GDK_WINDOWING_X11 
XSetFunction((Display*) arg1, (GC) arg2, (int) arg3);
#endif
	;
}
#define INLINE_F103_1786
#endif
#ifndef INLINE_F103_1809
static EIF_INTEGER_32 inline_F103_1809 (void)
{
	#ifdef GDK_WINDOWING_X11
return GXand;
#endif
	;
}
#define INLINE_F103_1809
#endif
#ifndef INLINE_F103_1814
static EIF_INTEGER_32 inline_F103_1814 (void)
{
	#ifdef GDK_WINDOWING_X11
return GXxor;
#endif
	;
}
#define INLINE_F103_1814
#endif
#ifndef INLINE_F103_1818
static EIF_INTEGER_32 inline_F103_1818 (void)
{
	#ifdef GDK_WINDOWING_X11
return GXinvert;
#endif
	;
}
#define INLINE_F103_1818
#endif
#ifndef INLINE_F103_1815
static EIF_INTEGER_32 inline_F103_1815 (void)
{
	#ifdef GDK_WINDOWING_X11
return GXor;
#endif
	;
}
#define INLINE_F103_1815
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_SCREEN_IMP}.make */
void F1367_13955 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_16 ti2_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		/* INLINED CODE (ANY.do_nothing) */
		tr1 = RTOSCF(14034,F1367_14034, (Current));
		(void) RTCW(tr1);
		/* END INLINED CODE */
	}
	;
	tb1 = RTOSCF(11424,F1213_11424, (RTCV(RTOSCF(14034,F1367_14034, (Current)))));
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_) = (EIF_BOOLEAN) tb1;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(14034,F1367_14034, (Current)))+ _LNGOFF_49_16_0_11_);
	ti2_1 = (EIF_INTEGER_16) ti4_1;
	ti4_1 = (EIF_INTEGER_32) (EIF_INTEGER_16) -ti2_1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_4_) = (EIF_INTEGER_32) ti4_1;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(14034,F1367_14034, (Current)))+ _LNGOFF_49_16_0_12_);
	ti2_1 = (EIF_INTEGER_16) ti4_1;
	ti4_1 = (EIF_INTEGER_32) (EIF_INTEGER_16) -ti2_1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_3_) = (EIF_INTEGER_32) ti4_1;
	F1188_10877(Current, (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_SCREEN_IMP}.prepare_drawing */
void F1367_13957 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_6_3_)) {
		F1367_13958(Current);
	}
	RTLE;
}

/* {EV_SCREEN_IMP}.initialize_drawing */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F1367_13958 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_POINTER  EIF_VOLATILE tp1;
	EIF_POINTER  EIF_VOLATILE tp2;
	EIF_INTEGER_32  EIF_VOLATILE ti4_1;
	RTLD;
	RTXD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,saved_except);
	RTLIU(2);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_6_3_)) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_6_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_)) {
			tp1 = inline_F104_2029();
			tp1 = inline_F104_2031(tp1);
			*(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_) = (EIF_POINTER) tp1;
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
			tp1 = inline_F103_1780(tp1);
			*(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_) = (EIF_POINTER) tp1;
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
			tp1 = inline_F103_1784(tp1);
			tp2 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_);
			ti4_1 = inline_F103_1803();
			inline_F103_1787(tp1, tp2, ti4_1);
		}
		F1367_13959(Current);
	}
	RTE_E
	RTXSC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {EV_SCREEN_IMP}.init_default_values */
void F1367_13959 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1367_14029(Current);
	F1367_14027(Current, ((EIF_INTEGER_32) 0L));
	F1367_14028(Current, ((EIF_INTEGER_32) 1L));
	RTLE;
}

/* {EV_SCREEN_IMP}.get_cairo_context */
void F1367_13963 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_0_) = (EIF_POINTER) *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
}

/* {EV_SCREEN_IMP}.pointer_position */
EIF_REFERENCE F1367_13964 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	loc1 = F1213_11530(RTCV(RTOSCF(14034,F1367_14034, (Current))));
	Result = RTLNS(eif_new_type(830, 0x01).id, 830, _OBJSIZ_0_0_0_0_0_0_0_2_);
	ti4_1 = eif_integer_32_item(RTCW(loc1),2);
	ti4_2 = eif_integer_32_item(RTCW(loc1),3);
	F831_6315(RTCW(Result), ti4_1, ti4_2);
	RTLE;
	return Result;
}

/* {EV_SCREEN_IMP}.widget_at_mouse_pointer */
EIF_REFERENCE F1367_13966 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = F1367_13967(Current);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O8826[Dtype(loc1)-1187]);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {EV_SCREEN_IMP}.widget_imp_at_pointer_position */
EIF_REFERENCE F1367_13967 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	loc3 = F1213_11530(RTCV(RTOSCF(14034,F1367_14034, (Current))));
	loc1 = eif_pointer_item(RTCW(loc3),1);
	tb1 = !loc1;
	if ((EIF_BOOLEAN) !tb1) {
		gdk_window_get_user_data((GdkWindow*) loc1, (gpointer*) (EIF_POINTER *) &(loc2));
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(Result != NULL)) {
				tb2 = !loc2;
				tb1 = tb2;
			}
			if (tb1) break;
			tr1 = (EIF_REFERENCE) c_ev_any_imp_get_eif_reference_from_object_id((GtkWidget*) loc2);
			loc4 = tr1;
			loc4 = RTRV(eif_new_type(1266, 0x01),loc4);
			if (EIF_TEST(loc4)) {
				Result = (EIF_REFERENCE) loc4;
			} else {
				tp1 = (EIF_POINTER) gtk_widget_get_parent((GtkWidget*) loc2);
				loc2 = (EIF_POINTER) tp1;
			}
		}
	}
	RTLE;
	return Result;
}

/* {EV_SCREEN_IMP}.horizontal_resolution */
EIF_INTEGER_32 F1367_13981 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	RTGC;
	tp1 = inline_F104_2029();
	Result = inline_F104_2024(tp1);
	if ((EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) -1L))) {
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 96L);
	}
	return Result;
}

/* {EV_SCREEN_IMP}.height */
EIF_INTEGER_32 F1367_13983 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(14034,F1367_14034, (Current)))+ _LNGOFF_49_16_0_16_);
	RTLE;
	return Result;
}

/* {EV_SCREEN_IMP}.width */
EIF_INTEGER_32 F1367_13984 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(14034,F1367_14034, (Current)))+ _LNGOFF_49_16_0_15_);
	RTLE;
	return Result;
}

/* {EV_SCREEN_IMP}.device_x_offset */
EIF_INTEGER_32 F1367_13989 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_4_);
}


/* {EV_SCREEN_IMP}.device_y_offset */
EIF_INTEGER_32 F1367_13990 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_3_);
}


/* {EV_SCREEN_IMP}.update_if_needed */
void F1367_14007 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_16 ti2_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(14034,F1367_14034, (Current)))+ _LNGOFF_49_16_0_11_);
	ti2_1 = (EIF_INTEGER_16) ti4_1;
	ti4_1 = (EIF_INTEGER_32) (EIF_INTEGER_16) -ti2_1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_4_) = (EIF_INTEGER_32) ti4_1;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(14034,F1367_14034, (Current)))+ _LNGOFF_49_16_0_12_);
	ti2_1 = (EIF_INTEGER_16) ti4_1;
	ti4_1 = (EIF_INTEGER_32) (EIF_INTEGER_16) -ti2_1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_3_) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

/* {EV_SCREEN_IMP}.clear_rectangle */
void F1367_14008 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	F1367_14024(Current);
	tb1 = '\0';
	tb2 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_);
		tb3 = !tp1;
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
		tb2 = !tp1;
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp2 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp3 = tp2;
		gdk_window_invalidate_rect((GdkWindow*) tp1, (GdkRectangle*) tp3, (gboolean) (EIF_BOOLEAN) 1);
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		if ((EIF_BOOLEAN)(loc1 == NULL)) {
			loc1 = F1226_11773(Current);
		}
		loc2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		if ((EIF_BOOLEAN)(loc2 == NULL)) {
			loc2 = F1226_11774(Current);
		}
		tr4_1 = F1090_9685(RTCW(loc2));
		tr8_1 = (EIF_REAL_64) (tr4_1);
		tr4_1 = F1090_9686(RTCW(loc2));
		tr8_2 = (EIF_REAL_64) (tr4_1);
		tr4_1 = F1090_9687(RTCW(loc2));
		tr8_3 = (EIF_REAL_64) (tr4_1);
		F1367_14033(Current, (EIF_BOOLEAN) 1, tr8_1, tr8_2, tr8_3);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_);
		tp2 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
		tp3 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_4_);
		ti4_2 = (EIF_INTEGER_32) ((EIF_INTEGER_16) -32768L);
		ti4_1 = eif_max_int32 ((EIF_INTEGER_32) (arg1 + ti4_1),ti4_2);
		ti4_2 = (EIF_INTEGER_32) ((EIF_INTEGER_16) 32767L);
		ti4_1 = eif_min_int32 (ti4_1,ti4_2);
		ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_3_);
		ti4_3 = (EIF_INTEGER_32) ((EIF_INTEGER_16) -32768L);
		ti4_2 = eif_max_int32 ((EIF_INTEGER_32) (arg2 + ti4_2),ti4_3);
		ti4_3 = (EIF_INTEGER_32) ((EIF_INTEGER_16) 32767L);
		ti4_2 = eif_min_int32 (ti4_2,ti4_3);
		inline_F103_1827(tp1, tp2, tp3, (EIF_BOOLEAN) 1, ti4_1, ti4_2, arg3, arg4);
		tr4_1 = F1090_9685(RTCW(loc1));
		tr8_1 = (EIF_REAL_64) (tr4_1);
		tr4_1 = F1090_9686(RTCW(loc1));
		tr8_2 = (EIF_REAL_64) (tr4_1);
		tr4_1 = F1090_9687(RTCW(loc1));
		tr8_3 = (EIF_REAL_64) (tr4_1);
		F1367_14033(Current, (EIF_BOOLEAN) 1, tr8_1, tr8_2, tr8_3);
		F1367_14007(Current);
	}
	{
		/* INLINED CODE (EV_SCREEN_IMP.post_drawing) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {EV_SCREEN_IMP}.draw_segment */
void F1367_14009 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_INTEGER_32 ti4_5;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1367_14024(Current);
	tb1 = '\0';
	tb2 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_);
		tb3 = !tp1;
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
		tb2 = !tp1;
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp2 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp3 = tp2;
		gdk_window_invalidate_rect((GdkWindow*) tp1, (GdkRectangle*) tp3, (gboolean) (EIF_BOOLEAN) 1);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_);
		tp2 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
		tp3 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_4_);
		ti4_2 = (EIF_INTEGER_32) ((EIF_INTEGER_16) -32768L);
		ti4_1 = eif_max_int32 ((EIF_INTEGER_32) (arg1 + ti4_1),ti4_2);
		ti4_2 = (EIF_INTEGER_32) ((EIF_INTEGER_16) 32767L);
		ti4_1 = eif_min_int32 (ti4_1,ti4_2);
		ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_3_);
		ti4_3 = (EIF_INTEGER_32) ((EIF_INTEGER_16) -32768L);
		ti4_2 = eif_max_int32 ((EIF_INTEGER_32) (arg2 + ti4_2),ti4_3);
		ti4_3 = (EIF_INTEGER_32) ((EIF_INTEGER_16) 32767L);
		ti4_2 = eif_min_int32 (ti4_2,ti4_3);
		ti4_3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_4_);
		ti4_4 = (EIF_INTEGER_32) ((EIF_INTEGER_16) -32768L);
		ti4_3 = eif_max_int32 ((EIF_INTEGER_32) (arg3 + ti4_3),ti4_4);
		ti4_4 = (EIF_INTEGER_32) ((EIF_INTEGER_16) 32767L);
		ti4_3 = eif_min_int32 (ti4_3,ti4_4);
		ti4_4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_3_);
		ti4_5 = (EIF_INTEGER_32) ((EIF_INTEGER_16) -32768L);
		ti4_4 = eif_max_int32 ((EIF_INTEGER_32) (arg4 + ti4_4),ti4_5);
		ti4_5 = (EIF_INTEGER_32) ((EIF_INTEGER_16) 32767L);
		ti4_4 = eif_min_int32 (ti4_4,ti4_5);
		inline_F103_1824(tp1, tp2, tp3, ti4_1, ti4_2, ti4_3, ti4_4);
		F1367_14007(Current);
	}
	{
		/* INLINED CODE (EV_SCREEN_IMP.post_drawing) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {EV_SCREEN_IMP}.draw_ellipse */
void F1367_14010 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1367_14024(Current);
	tb1 = '\0';
	tb2 = '\0';
	tb3 = '\0';
	tb4 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_);
		tb5 = !tp1;
		tb4 = (EIF_BOOLEAN) !tb5;
	}
	if (tb4) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
		tb4 = !tp1;
		tb3 = (EIF_BOOLEAN) !tb4;
	}
	if (tb3) {
		tb2 = (EIF_BOOLEAN) (arg3 > ((EIF_INTEGER_32) 0L));
	}
	if (tb2) {
		tb1 = (EIF_BOOLEAN) (arg4 > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp2 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp3 = tp2;
		gdk_window_invalidate_rect((GdkWindow*) tp1, (GdkRectangle*) tp3, (gboolean) (EIF_BOOLEAN) 1);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_);
		tp2 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
		tp3 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_4_);
		ti4_2 = (EIF_INTEGER_32) ((EIF_INTEGER_16) -32768L);
		ti4_1 = eif_max_int32 ((EIF_INTEGER_32) (arg1 + ti4_1),ti4_2);
		ti4_2 = (EIF_INTEGER_32) ((EIF_INTEGER_16) 32767L);
		ti4_1 = eif_min_int32 (ti4_1,ti4_2);
		ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_3_);
		ti4_3 = (EIF_INTEGER_32) ((EIF_INTEGER_16) -32768L);
		ti4_2 = eif_max_int32 ((EIF_INTEGER_32) (arg2 + ti4_2),ti4_3);
		ti4_3 = (EIF_INTEGER_32) ((EIF_INTEGER_16) 32767L);
		ti4_2 = eif_min_int32 (ti4_2,ti4_3);
		inline_F103_1826(tp1, tp2, tp3, (EIF_BOOLEAN) 0, ti4_1, ti4_2, (EIF_INTEGER_32) (arg3 - ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (arg4 - ((EIF_INTEGER_32) 1L)), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 23040L));
		F1367_14007(Current);
	}
	{
		/* INLINED CODE (EV_SCREEN_IMP.post_drawing) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {EV_SCREEN_IMP}.draw_point */
void F1367_14011 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1367_14024(Current);
	tb1 = '\0';
	tb2 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_);
		tb3 = !tp1;
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
		tb2 = !tp1;
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp2 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp3 = tp2;
		gdk_window_invalidate_rect((GdkWindow*) tp1, (GdkRectangle*) tp3, (gboolean) (EIF_BOOLEAN) 1);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_);
		tp2 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
		tp3 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_4_);
		ti4_2 = (EIF_INTEGER_32) ((EIF_INTEGER_16) -32768L);
		ti4_1 = eif_max_int32 ((EIF_INTEGER_32) (arg1 + ti4_1),ti4_2);
		ti4_2 = (EIF_INTEGER_32) ((EIF_INTEGER_16) 32767L);
		ti4_1 = eif_min_int32 (ti4_1,ti4_2);
		ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_3_);
		ti4_3 = (EIF_INTEGER_32) ((EIF_INTEGER_16) -32768L);
		ti4_2 = eif_max_int32 ((EIF_INTEGER_32) (arg2 + ti4_2),ti4_3);
		ti4_3 = (EIF_INTEGER_32) ((EIF_INTEGER_16) 32767L);
		ti4_2 = eif_min_int32 (ti4_2,ti4_3);
		inline_F103_1825(tp1, tp2, tp3, ti4_1, ti4_2);
		F1367_14007(Current);
	}
	{
		/* INLINED CODE (EV_SCREEN_IMP.post_drawing) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {EV_SCREEN_IMP}.fill_rectangle */
void F1367_14015 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1367_14024(Current);
	tb1 = '\0';
	tb2 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_);
		tb3 = !tp1;
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
		tb2 = !tp1;
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp2 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp3 = tp2;
		gdk_window_invalidate_rect((GdkWindow*) tp1, (GdkRectangle*) tp3, (gboolean) (EIF_BOOLEAN) 1);
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_5_) != NULL)) {
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
			tp2 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_);
			ti4_1 = inline_F103_1794();
			inline_F103_1790(tp1, tp2, ti4_1);
		}
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_);
		tp2 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
		tp3 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_4_);
		ti4_2 = (EIF_INTEGER_32) ((EIF_INTEGER_16) -32768L);
		ti4_1 = eif_max_int32 ((EIF_INTEGER_32) (arg1 + ti4_1),ti4_2);
		ti4_2 = (EIF_INTEGER_32) ((EIF_INTEGER_16) 32767L);
		ti4_1 = eif_min_int32 (ti4_1,ti4_2);
		ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_3_);
		ti4_3 = (EIF_INTEGER_32) ((EIF_INTEGER_16) -32768L);
		ti4_2 = eif_max_int32 ((EIF_INTEGER_32) (arg2 + ti4_2),ti4_3);
		ti4_3 = (EIF_INTEGER_32) ((EIF_INTEGER_16) 32767L);
		ti4_2 = eif_min_int32 (ti4_2,ti4_3);
		inline_F103_1827(tp1, tp2, tp3, (EIF_BOOLEAN) 1, ti4_1, ti4_2, arg3, arg4);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
		tp2 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_);
		ti4_1 = inline_F103_1793();
		inline_F103_1790(tp1, tp2, ti4_1);
		F1367_14007(Current);
	}
	{
		/* INLINED CODE (EV_SCREEN_IMP.post_drawing) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {EV_SCREEN_IMP}.fill_ellipse */
void F1367_14016 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1367_14024(Current);
	tb1 = '\0';
	tb2 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_);
		tb3 = !tp1;
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
		tb2 = !tp1;
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp2 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp3 = tp2;
		gdk_window_invalidate_rect((GdkWindow*) tp1, (GdkRectangle*) tp3, (gboolean) (EIF_BOOLEAN) 1);
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_5_) != NULL)) {
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
			tp2 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_);
			ti4_1 = inline_F103_1794();
			inline_F103_1790(tp1, tp2, ti4_1);
		}
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_);
		tp2 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
		tp3 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_4_);
		ti4_2 = (EIF_INTEGER_32) ((EIF_INTEGER_16) -32768L);
		ti4_1 = eif_max_int32 ((EIF_INTEGER_32) (arg1 + ti4_1),ti4_2);
		ti4_2 = (EIF_INTEGER_32) ((EIF_INTEGER_16) 32767L);
		ti4_1 = eif_min_int32 (ti4_1,ti4_2);
		ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_3_);
		ti4_3 = (EIF_INTEGER_32) ((EIF_INTEGER_16) -32768L);
		ti4_2 = eif_max_int32 ((EIF_INTEGER_32) (arg2 + ti4_2),ti4_3);
		ti4_3 = (EIF_INTEGER_32) ((EIF_INTEGER_16) 32767L);
		ti4_2 = eif_min_int32 (ti4_2,ti4_3);
		inline_F103_1826(tp1, tp2, tp3, (EIF_BOOLEAN) 1, ti4_1, ti4_2, arg3, arg4, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 23040L));
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
		tp2 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_);
		ti4_1 = inline_F103_1793();
		inline_F103_1790(tp1, tp2, ti4_1);
		F1367_14007(Current);
	}
	{
		/* INLINED CODE (EV_SCREEN_IMP.post_drawing) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {EV_SCREEN_IMP}.start_drawing_session */
void F1367_14019 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1367_13957(Current);
	F1358_13698(Current);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	*(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_) = (EIF_POINTER) tp2;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	*(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_) = (EIF_POINTER) tp2;
	F1367_14021(Current);
	RTLE;
}

/* {EV_SCREEN_IMP}.end_drawing_session */
void F1367_14020 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1367_13957(Current);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
	tb1 = !tp1;
	if ((EIF_BOOLEAN) !tb1) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
		inline_F103_1792(tp1);
	}
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	*(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_) = (EIF_POINTER) tp2;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	*(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_) = (EIF_POINTER) tp2;
	F1358_13699(Current);
	RTLE;
}

/* {EV_SCREEN_IMP}.get_drawable_x_display_and_window */
void F1367_14021 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tb1 = '\0';
	tb2 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
		tb3 = !tp1;
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tb2 = '\01';
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_);
		tb3 = !tp1;
		if (!tb3) {
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_);
			tb3 = !tp1;
			tb2 = tb3;
		}
		tb1 = tb2;
	}
	if (tb1) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
		tp1 = inline_F103_1785(tp1);
		*(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_3_) = (EIF_POINTER) tp1;
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
		tp1 = inline_F103_1784(tp1);
		*(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_4_) = (EIF_POINTER) tp1;
	}
	RTLE;
}

/* {EV_SCREEN_IMP}.pre_drawing */
void F1367_14024 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1367_13957(Current);
	F1367_14021(Current);
	RTLE;
}

/* {EV_SCREEN_IMP}.post_drawing */
void F1367_14025 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {EV_SCREEN_IMP}.set_drawing_mode */
void F1367_14027 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1367_13957(Current);
	F1363_13803(Current, arg1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_)) {
		loc1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_);
		loc2 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
		tb1 = '\0';
		tb2 = !loc1;
		if ((EIF_BOOLEAN) !tb2) {
			tb2 = !loc2;
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			loc3 = inline_F103_1784(loc2);
			switch (arg1) {
				case 0L:
					ti4_1 = inline_F103_1811();
					inline_F103_1786(loc3, loc1, ti4_1);
					break;
				case 3L:
					ti4_1 = inline_F103_1809();
					inline_F103_1786(loc3, loc1, ti4_1);
					break;
				case 1L:
					ti4_1 = inline_F103_1814();
					inline_F103_1786(loc3, loc1, ti4_1);
					break;
				case 2L:
					ti4_1 = inline_F103_1818();
					inline_F103_1786(loc3, loc1, ti4_1);
					break;
				case 4L:
					ti4_1 = inline_F103_1815();
					inline_F103_1786(loc3, loc1, ti4_1);
					break;
				default:
					ti4_1 = inline_F103_1811();
					inline_F103_1786(loc3, loc1, ti4_1);
					break;
			}
		}
	}
	RTLE;
}

/* {EV_SCREEN_IMP}.set_line_width */
void F1367_14028 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1367_13957(Current);
	F1363_13802(Current, arg1);
	tb1 = '\0';
	tb2 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_);
		tb3 = !tp1;
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
		tb2 = !tp1;
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_)) {
			tr1 = RTLNS(eif_new_type(102, 0x01).id, 102, _OBJSIZ_0_0_0_0_0_0_0_0_);
			F103_1782(RTCW(tr1), *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_), *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_), arg1);
		} else {
			tr1 = RTLNS(eif_new_type(102, 0x01).id, 102, _OBJSIZ_0_0_0_0_0_0_0_0_);
			F103_1781(RTCW(tr1), *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_), *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_), arg1);
		}
	}
	RTLE;
}

/* {EV_SCREEN_IMP}.enable_dashed_line_style */
void F1367_14029 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1367_13957(Current);
	F1363_13810(Current);
	tb1 = '\0';
	tb2 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_);
		tb3 = !tp1;
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
		tb2 = !tp1;
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tr1 = RTLNS(eif_new_type(102, 0x01).id, 102, _OBJSIZ_0_0_0_0_0_0_0_0_);
		F103_1782(RTCW(tr1), *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_), *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_2_));
	}
	RTLE;
}

/* {EV_SCREEN_IMP}.disable_dashed_line_style */
void F1367_14030 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1367_13957(Current);
	F1363_13811(Current);
	tb1 = '\0';
	tb2 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_);
		tb3 = !tp1;
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_);
		tb2 = !tp1;
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tr1 = RTLNS(eif_new_type(102, 0x01).id, 102, _OBJSIZ_0_0_0_0_0_0_0_0_);
		F103_1781(RTCW(tr1), *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_), *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_7_0_2_));
	}
	RTLE;
}

/* {EV_SCREEN_IMP}.internal_set_color */
void F1367_14033 (EIF_REFERENCE Current, EIF_BOOLEAN arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1367_13957(Current);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_)) {
		tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 65535L));
		tr1 = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)tr1 = (EIF_REAL_64) (arg2 * tr8_1);
		loc1 = F968_7916(RTCW(tr1));
		tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 65535L));
		tr1 = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)tr1 = (EIF_REAL_64) (arg3 * tr8_1);
		loc2 = F968_7916(RTCW(tr1));
		tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 65535L));
		tr1 = RTLNS(eif_new_type(969, 0x00).id, 969, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)tr1 = (EIF_REAL_64) (arg4 * tr8_1);
		loc3 = F968_7916(RTCW(tr1));
		if (arg1) {
			tr1 = RTLNS(eif_new_type(102, 0x01).id, 102, _OBJSIZ_0_0_0_0_0_0_0_0_);
			F103_1805(RTCW(tr1), *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_), *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_), loc1, loc2, loc3);
		} else {
			tr1 = RTLNS(eif_new_type(102, 0x01).id, 102, _OBJSIZ_0_0_0_0_0_0_0_0_);
			F103_1804(RTCW(tr1), *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_2_), *(EIF_POINTER *)(Current+ _PTROFF_6_7_0_5_0_1_), loc1, loc2, loc3);
		}
	}
	RTLE;
}

/* {EV_SCREEN_IMP}.app_implementation */
static EIF_REFERENCE F1367_14034_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (14034);
#define Result RTOSR(14034)
	RTOC_NEW(Result);
	RTCT0("attached {EV_APPLICATION_IMP} (create {EV_ENVIRONMENT}).implementation.application_i as l_result", EX_CHECK);
	tr1 = RTLNS(eif_new_type(1092, 0x01).id, 1092, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1083_9566(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	tr1 = F1207_11248(RTCW(tr1));
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1212, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (EIF_REFERENCE) loc1;
	RTOSE (14034);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1367_14034 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14034,F1367_14034_body,(Current));
}

/* {EV_SCREEN_IMP}.destroy */
void F1367_14035 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1188_10878(Current, (EIF_BOOLEAN) 1);
}

void EIF_Minit722 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
