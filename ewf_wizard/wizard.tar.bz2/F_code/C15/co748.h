
#ifndef _C15_co748_
#define _C15_co748_

#ifdef __cplusplus
extern "C" {
#endif

extern void F336_5004(EIF_REFERENCE);
extern void F336_5005(EIF_REFERENCE);
extern void EIF_Minit748(void);
extern long O4814[];

#ifdef __cplusplus
}
#endif

#endif
