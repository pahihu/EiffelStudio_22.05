/*
 * Code for class EIFFEL_ENV
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ei742.h"
#include "eif_built_in.h"
#include "eif_path_name.h"
#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F1387_14567
static int inline_F1387_14567 (void)
{
	return (int) (EIF_IS_WORKBENCH)
	;
}
#define INLINE_F1387_14567
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EIFFEL_ENV}.product_name */
static EIF_REFERENCE F1387_14549_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (14549);
#define Result RTOSR(14549)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("Eiffel",6,1854452588);
	RTOSE (14549);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1387_14549 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14549,F1387_14549_body,(Current));
}

/* {EIFFEL_ENV}.version_name */
static EIF_REFERENCE F1387_14553_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (14553);
#define Result RTOSR(14553)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1053, 0x01).id, 1053, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1052_9286(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(3106,F132_3106, (Current));
	F1054_9401(RTCW(Result), tr1);
	F1054_9412(RTCW(Result), (EIF_CHARACTER_8) '.');
	tr1 = RTOSCF(3107,F132_3107, (Current));
	F1054_9401(RTCW(Result), tr1);
	RTOSE (14553);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1387_14553 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14553,F1387_14553_body,(Current));
}

/* {EIFFEL_ENV}.is_workbench */
EIF_BOOLEAN F1387_14567 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = EIF_TEST(inline_F1387_14567 ());
	return Result;
}

/* {EIFFEL_ENV}.environment */
static EIF_REFERENCE F1387_14571_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (14571);
#define Result RTOSR(14571)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(704, 0x01).id, 704, _OBJSIZ_0_0_0_1_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (14571);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1387_14571 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14571,F1387_14571_body,(Current));
}

/* {EIFFEL_ENV}.versionless_user_files_path */
static EIF_REFERENCE F1387_14611_body (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	

	RTLI(4);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOSP (14611);
#define Result RTOSR(14611)
	RTOC_NEW(Result);
	RTCT0("attached user_directory_name as l_user_directory_name", EX_CHECK);
	tr1 = RTOSCF(14716,F1387_14716, (Current));
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (EIF_REFERENCE) loc3;
	tb1 = '\0';
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
		tb1 = (EIF_BOOLEAN) !(EIF_BOOLEAN) eif_builtin_PLATFORM_is_mac__b;
	}
	if (tb1) {
		tr1 = RTOSCF(14715,F1387_14715, (Current));
		tr1 = F932_7693(RTCW(Result), tr1);
		Result = (EIF_REFERENCE) tr1;
		if (arg1) {
			F1387_14664(Current, Result);
		}
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	loc1 = RTLNS(eif_new_type(1050, 0x01).id, 1050, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1049_9119(RTCW(loc1), ((EIF_INTEGER_32) 30L));
	tb1 = '\0';
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
		tb1 = (EIF_BOOLEAN) !(EIF_BOOLEAN) eif_builtin_PLATFORM_is_mac__b;
	}
	if (tb1) {
		tr1 = F1054_9434(RTCV(RTOSCF(14549,F1387_14549, (Current))));
		F1051_9233(RTCW(loc1), tr1);
		tr1 = RTMS_EX_H("_user_files",11,1637806195);
		F1051_9233(RTCW(loc1), tr1);
	} else {
		tr1 = RTOSCF(14549,F1387_14549, (Current));
		F1051_9233(RTCW(loc1), tr1);
		tr1 = RTMS_EX_H(" User Files",11,1077377395);
		F1051_9233(RTCW(loc1), tr1);
	}
	tb1 = '\0';
	if (EIF_TEST (inline_F1387_14567())) {
		tb1 = loc2;
	}
	if (tb1) {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
		F1051_9247(RTCW(loc1), tw1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '(';
		F1051_9247(RTCW(loc1), tw1);
		tr1 = RTOSCF(14679,F1387_14679, (Current));
		F1051_9233(RTCW(loc1), tr1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ')';
		F1051_9247(RTCW(loc1), tw1);
	}
	tr1 = F932_7693(RTCW(Result), loc1);
	Result = (EIF_REFERENCE) tr1;
	if (arg1) {
		F1387_14664(Current, Result);
	}
	RTOSE (14611);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1387_14611 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	return RTOSCF(14611,F1387_14611_body,(Current,arg1));
}

/* {EIFFEL_ENV}.user_files_path_for_version */
EIF_REFERENCE F1387_14612 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	Result = RTOSCF(14611,F1387_14611, (Current, arg2));
	tr1 = F932_7693(RTCW(Result), arg1);
	Result = (EIF_REFERENCE) tr1;
	if (arg2) {
		F1387_14664(Current, Result);
	}
	RTLE;
	return Result;
}

/* {EIFFEL_ENV}.user_files_path */
static EIF_REFERENCE F1387_14613_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	

	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (14613);
#define Result RTOSR(14613)
	RTOC_NEW(Result);
	tr1 = RTOSCF(3098,F132_3098, (Current));
	loc1 = F1387_14661(Current, tr1);
	tb1 = '\01';
	if (!(EIF_BOOLEAN)(loc1 == NULL)) {
		tb2 = F491_5233(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = RTOSCF(14553,F1387_14553, (Current));
		Result = F1387_14612(Current, tr1, (EIF_BOOLEAN) 1);
	} else {
		tr1 = RTLNS(eif_new_type(931, 0x01).id, 931, _OBJSIZ_2_1_0_0_0_0_0_0_);
		F932_7666(RTCW(tr1), loc1);
		Result = (EIF_REFERENCE) tr1;
	}
	RTOSE (14613);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1387_14613 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14613,F1387_14613_body,(Current));
}

/* {EIFFEL_ENV}.user_projects_path */
static EIF_REFERENCE F1387_14620_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	

	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTEV;
	RTGC;
	RTOSP (14620);
#define Result RTOSR(14620)
	RTOC_NEW(Result);
	tr1 = RTOSCF(3097,F132_3097, (Current));
	loc1 = F1387_14661(Current, tr1);
	tb1 = '\01';
	if (!(EIF_BOOLEAN)(loc1 == NULL)) {
		tb2 = F491_5233(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
			tb1 = (EIF_BOOLEAN) eif_builtin_PLATFORM_is_mac__b;
		}
		if (tb1) {
			tr1 = RTOSCF(14613,F1387_14613, (Current));
			tr2 = RTOSCF(14705,F1387_14705, (Current));
			Result = F932_7693(RTCW(tr1), tr2);
		} else {
			tb1 = '\0';
			tb2 = (EIF_BOOLEAN) EIF_TEST(eif_home_dir_supported());
			if (tb2) {
				tr1 = RTOSCF(6025,F704_6025, (RTCV(RTOSCF(14571,F1387_14571, (Current)))));
				loc2 = tr1;
				tb1 = EIF_TEST(loc2);
			}
			if (tb1) {
				Result = (EIF_REFERENCE) loc2;
			} else {
				tr1 = RTLNS(eif_new_type(931, 0x01).id, 931, _OBJSIZ_2_1_0_0_0_0_0_0_);
				tr2 = RTMS_EX_H("\\Invalid path",13,1573736552);
				F932_7666(RTCW(tr1), tr2);
				Result = (EIF_REFERENCE) tr1;
			}
		}
	} else {
		tr1 = RTLNS(eif_new_type(931, 0x01).id, 931, _OBJSIZ_2_1_0_0_0_0_0_0_);
		F932_7666(RTCW(tr1), loc1);
		Result = (EIF_REFERENCE) tr1;
	}
	RTOSE (14620);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1387_14620 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14620,F1387_14620_body,(Current));
}

/* {EIFFEL_ENV}.get_environment_32 */
EIF_REFERENCE F1387_14661 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = RTOSCF(14571,F1387_14571, (Current));
	tr2 = RTOSCF(14725,F1388_14725, (Current));
	tr3 = RTOSCF(14553,F1387_14553, (Current));
	Result = F705_6056(RTCW(tr1), arg1, tr2, tr3);
	RTLE;
	return Result;
}

/* {EIFFEL_ENV}.safe_create_dir */
void F1387_14664 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	struct eif_ex_41 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(43, 0x00).id);
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F932_7705(RTCW(arg1));
	F44_1037(RTCW(loc1), tr1);
	RTLE;
}

/* {EIFFEL_ENV}.wkbench_suffix */

EIF_REFERENCE F1387_14679 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (14679,RTMS_EX_H("workbench",9,1911020904));
}

/* {EIFFEL_ENV}.projects_name */

EIF_REFERENCE F1387_14705 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (14705,RTMS_EX_H("projects",8,1341994355));
}

/* {EIFFEL_ENV}.hidden_directory_name */
static EIF_REFERENCE F1387_14715_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (14715);
#define Result RTOSR(14715)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1050, 0x01).id, 1050, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr2 = RTMS_EX_H(".es",3,3040627);
	F1051_9195(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	if (EIF_TEST (inline_F1387_14567())) {
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
		F1051_9247(RTCW(Result), tw1);
		tr1 = RTOSCF(14679,F1387_14679, (Current));
		F1051_9233(RTCW(Result), tr1);
	}
	RTOSE (14715);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1387_14715 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14715,F1387_14715_body,(Current));
}

/* {EIFFEL_ENV}.user_directory_name */
static EIF_REFERENCE F1387_14716_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (14716);
#define Result RTOSR(14716)
	RTOC_NEW(Result);
	Result = RTOSCF(6026,F704_6026, (RTCV(RTOSCF(14571,F1387_14571, (Current)))));
	RTOSE (14716);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1387_14716 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14716,F1387_14716_body,(Current));
}

void EIF_Minit742 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
