/*
 * Code for class EV_MENU_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev706.h"
#include <ev_gtk.h>
#include "ev_any_imp.h"
#include "ev_c_util.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F1351_13576
static void inline_F1351_13576 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	g_object_set_data (
    G_OBJECT (arg1),
    "eif_oid",
    (gpointer) (rt_int_ptr) arg2
);
	;
}
#define INLINE_F1351_13576
#endif
#ifndef INLINE_F1351_13577
static void inline_F1351_13577 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_NATURAL_32 arg5)
{
	{
     /* From: https://git.eclipse.org/c/platform/eclipse.platform.swt.git/commit/?id=7714fdbf1ce0110744da9c164486c12254d5bd6f
	 *  GTK Feature: gtk_menu_popup is deprecated as of GTK3.22 and the new method gtk_menu_popup_at_pointer
	 *  requires an event to hook on to. This requires the popup & events related to the menu be handled
	 *  immediately and not as a post event in display, requiring the current event.
	 */
	GdkEvent *event_ptr = gtk_get_current_event();
	if (event_ptr == NULL) {
		GdkEvent *event = gdk_event_new (GDK_BUTTON_PRESS);
		((GdkEventButton*)event)->time = (guint32) arg5;
		((GdkEventButton*)event)->x = (gdouble) arg2;
		((GdkEventButton*)event)->y = (gdouble) arg3;
		((GdkEventButton*)event)->type = GDK_BUTTON_PRESS;
		((GdkEventButton*)event)->button = (guint) arg4;
		gtk_widget_realize (arg1);
		((GdkEventButton*)event)->window = g_object_ref((GdkWindow*) gtk_widget_get_window ((GtkWidget*) arg1));
		((GdkEventButton*)event)->device = (GdkDevice*) gdk_seat_get_pointer ((GdkSeat*) gdk_display_get_default_seat ((GdkDisplay*) gdk_display_get_default ()));
		gtk_menu_popup_at_pointer ((GtkMenu*) arg1, event);
		gdk_event_free (event);
	} else {
		gtk_menu_popup_at_pointer ((GtkMenu*) arg1, event_ptr);
		gdk_event_free (event_ptr);
	}	
}
	;
}
#define INLINE_F1351_13577
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_MENU_IMP}.make */
void F1351_13573 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1347_13527(Current);
	tp1 = (EIF_POINTER) gtk_menu_new();
	*(EIF_POINTER *)(Current+ _PTROFF_26_8_6_2_0_4_) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_26_8_6_2_0_4_);
	gtk_widget_show((GtkWidget*) tp1);
	tp1 = F1347_13533(Current);
	gtk_widget_show((GtkWidget*) tp1);
	tp1 = F1347_13533(Current);
	tp2 = *(EIF_POINTER *)(Current+ _PTROFF_26_8_6_2_0_4_);
	gtk_menu_item_set_submenu((GtkMenuItem*) tp1, (GtkWidget*) tp2);
	F1220_11745(Current);
	F1247_11964(Current);
	F1347_13534(Current);
	RTLE;
}

/* {EV_MENU_IMP}.show_at */
void F1351_13575 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN) (F1220_11747(Current) > ((EIF_INTEGER_32) 0L))) {
		if ((EIF_BOOLEAN)(arg1 != NULL)) {
			loc1 = F1104_9910(RTCW(arg1));
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + arg2);
			loc2 = F1104_9911(RTCW(arg1));
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + arg3);
		} else {
			loc1 = (EIF_INTEGER_32) arg2;
			loc2 = (EIF_INTEGER_32) arg3;
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(11588,F1214_11588, (Current)))+ _LNGOFF_49_16_0_11_);
		loc1 -= ti4_1;
		ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(11588,F1214_11588, (Current)))+ _LNGOFF_49_16_0_12_);
		loc2 -= ti4_1;
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_26_8_6_2_0_4_);
		ti4_1 = F924_7533(Current);
		inline_F1351_13576(tp1, ti4_1);
		tr1 = RTOSCF(11588,F1214_11588, (Current));
		F1213_11438(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_12_));
		tr1 = RTOSCF(11588,F1214_11588, (Current));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,6,966,0xFF01,0,1038,984,984,984,996,0xFFFF};
			EIF_TYPE typres0;
			typarr0[4] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr2 = RTLNTS(typres0.id, 7, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
		RTAR(tr2,Current);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_26_8_6_2_0_4_);
		((EIF_TYPED_VALUE *)tr2+2)->it_p = tp1;
		((EIF_TYPED_VALUE *)tr2+3)->it_i4 = loc1;
		((EIF_TYPED_VALUE *)tr2+4)->it_i4 = loc2;
		((EIF_TYPED_VALUE *)tr2+5)->it_i4 = ((EIF_INTEGER_32) 0L);
		tu4_1 = (EIF_NATURAL_32) gtk_get_current_event_time();
		((EIF_TYPED_VALUE *)tr2+6)->it_n4 = tu4_1;
		
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1040,0xFF01,0xFFF9,0,966,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3= RTLNRF(typres0.id, (EIF_POINTER) __A706_326, (EIF_POINTER) _A706_326, (EIF_POINTER)(F1351_13577),tr2, 1, 0);
		}
		F1212_11363(RTCW(tr1), tr3);
	}
	RTLE;
}

/* {EV_MENU_IMP}.couple_object_id_with_gtk_object */
void F1351_13576 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	inline_F1351_13576 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
}

/* {EV_MENU_IMP}.c_gtk_menu_popup_at_pointer */
void F1351_13577 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_NATURAL_32 arg5)
{
	GTCX
	
	
	inline_F1351_13577 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2, (EIF_INTEGER_32) arg3, (EIF_INTEGER_32) arg4, (EIF_NATURAL_32) arg5);
}

/* {EV_MENU_IMP}.on_activate */
void F1351_13578 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	loc1 = F1340_13507(Current);
	loc1 = RTRV(eif_new_type(1224, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		if ((EIF_BOOLEAN)(tr1 != NULL)) {
			tr1 = F94_1690(RTCW(loc1));
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,966,0xFF01,0,0,0xFFFF};
				EIF_TYPE typres0;
				{
					EIF_TYPE l_type;
					l_type = eif_final_id(Y8826,Y8826_gen_type,Dftype(Current),1187);
					typarr0[5] = l_type.annotations | 0xFF00;
					typarr0[6] = l_type.id;
				}
				
				typres0 = eif_compound_id(Dftype(Current), typarr0);
				tr2 = RTLNTS(typres0.id, 2, 0);
			}
			tr3 = F1188_10863(Current);
			((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
			RTAR(tr2,tr3);
			F680_5877(RTCW(tr1), tr2);
		}
	}
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_4_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F680_5877(RTCW(tr1), NULL);
	}
	RTLE;
}

/* {EV_MENU_IMP}.list_widget */
EIF_POINTER F1351_13580 (EIF_REFERENCE Current)
{
	return *(EIF_POINTER *)(Current+ _PTROFF_26_8_6_2_0_4_);
}


/* {EV_MENU_IMP}.destroy */
void F1351_13581 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1219_11741(Current);
	F1340_13508(Current);
	RTLE;
}

void EIF_Minit706 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
