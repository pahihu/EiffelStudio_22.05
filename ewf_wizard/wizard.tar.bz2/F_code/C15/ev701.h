
#ifndef _C15_ev701_
#define _C15_ev701_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1346_13521(EIF_REFERENCE);
extern void EIF_Minit701(void);
extern EIF_REFERENCE F1340_13507(EIF_REFERENCE);
extern long O8826[];

#ifdef __cplusplus
}
#endif

#endif
