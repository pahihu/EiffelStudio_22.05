
#ifndef _C15_li747_
#define _C15_li747_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F615_5467(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F615_5468(EIF_REFERENCE);
extern EIF_BOOLEAN F615_5469(EIF_REFERENCE);
extern void EIF_Minit747(void);
extern char *(*R4957[])();
extern char *(*R4963[])();
extern char *(*R4965[])();
extern char *(*R4923[])();
extern char *(*R4969[])();
extern char *(*R4812[])();
extern char *(*R4930[])();
extern char *(*R4934[])();
extern char *(*R4936[])();
extern long O4814[];

#ifdef __cplusplus
}
#endif

#endif
