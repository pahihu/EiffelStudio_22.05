/*
 * Code for class EC_EIFFEL_LAYOUT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ec743.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EC_EIFFEL_LAYOUT}.application_name */

EIF_REFERENCE F1388_14725 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (14725,RTMS_EX_H("ec",2,25955));
}

void EIF_Minit743 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
