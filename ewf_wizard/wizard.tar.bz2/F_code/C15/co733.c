/*
 * Code for class CONSOLE_WIZARD_APPLICATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co733.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONSOLE_WIZARD_APPLICATION}.new_page */
EIF_REFERENCE F1378_14195 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(858, 0x01).id, 858, _OBJSIZ_10_0_0_0_0_0_0_0_);
	F857_6533(RTCW(tr1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONSOLE_WIZARD_APPLICATION}.set_page */
void F1378_14196 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F310_4882(Current, arg1);
	F1378_14203(Current, arg1);
	RTLE;
}

/* {CONSOLE_WIZARD_APPLICATION}.on_start */
void F1378_14197 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F310_4883(Current);
	F1378_14202(Current);
	RTLE;
}

/* {CONSOLE_WIZARD_APPLICATION}.on_finish */
void F1378_14198 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F310_4889(Current);
}

/* {CONSOLE_WIZARD_APPLICATION}.on_next */
void F1378_14199 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F310_4886(Current);
	F1378_14202(Current);
	RTLE;
}

/* {CONSOLE_WIZARD_APPLICATION}.on_refresh */
void F1378_14200 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F310_4884(Current);
	F1378_14202(Current);
	RTLE;
}

/* {CONSOLE_WIZARD_APPLICATION}.on_back */
void F1378_14201 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F310_4885(Current);
	F1378_14202(Current);
	RTLE;
}

/* {CONSOLE_WIZARD_APPLICATION}.on_navigation */
void F1378_14202 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,tr5);
	RTLIU(8);
	
	RTGC;
	tr1 = F310_4878(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = RTOSCF(3068,F129_3068, (RTCW(tr1)));
		if ((EIF_BOOLEAN)(loc1 == tr1)) {
			F310_4887(Current);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current);
			tr1 = RTOSCF(3085,F130_3085, (RTCW(tr1)));
			if ((EIF_BOOLEAN)(loc1 == tr1)) {
				F1378_14198(Current);
			} else {
				tr1 = RTMS_EX_H("\012",1,10);
				F1377_14191(Current, tr1);
				tr1 = RTMS_EX_H("Continue",8,2035097445);
				{
					static EIF_TYPE_INDEX typarr0[] = {834,0xFF01,0xFFF9,2,966,0xFF01,1053,0xFF01,1053,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
					RT_SPECIAL_COUNT(tr3) = 4L;
					memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
				}
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,966,0xFF01,1053,0xFF01,1053,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr4 = RTLNTS(typres0.id, 3, 0);
				}
				tr5 = RTMS_EX_H("c",1,99);
				((EIF_TYPED_VALUE *)tr4+1)->it_r = tr5;
				RTAR(tr4,tr5);
				tr5 = RTMS_EX_H("Continue",8,2035097445);
				((EIF_TYPED_VALUE *)tr4+2)->it_r = tr5;
				RTAR(tr4,tr5);
				*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
				RTAR(tr3,tr4);
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,966,0xFF01,1053,0xFF01,1053,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr4 = RTLNTS(typres0.id, 3, 0);
				}
				tr5 = RTMS_EX_H("r",1,114);
				((EIF_TYPED_VALUE *)tr4+1)->it_r = tr5;
				RTAR(tr4,tr5);
				tr5 = RTMS_EX_H("Refresh",7,440963944);
				((EIF_TYPED_VALUE *)tr4+2)->it_r = tr5;
				RTAR(tr4,tr5);
				*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
				RTAR(tr3,tr4);
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,966,0xFF01,1053,0xFF01,1053,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr4 = RTLNTS(typres0.id, 3, 0);
				}
				tr5 = RTMS_EX_H("b",1,98);
				((EIF_TYPED_VALUE *)tr4+1)->it_r = tr5;
				RTAR(tr4,tr5);
				tr5 = RTMS_EX_H("Back",4,1113678699);
				((EIF_TYPED_VALUE *)tr4+2)->it_r = tr5;
				RTAR(tr4,tr5);
				*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
				RTAR(tr3,tr4);
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,966,0xFF01,1053,0xFF01,1053,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr4 = RTLNTS(typres0.id, 3, 0);
				}
				tr5 = RTMS_EX_H("q",1,113);
				((EIF_TYPED_VALUE *)tr4+1)->it_r = tr5;
				RTAR(tr4,tr5);
				tr5 = RTMS_EX_H("Cancel",6,1984480108);
				((EIF_TYPED_VALUE *)tr4+2)->it_r = tr5;
				RTAR(tr4,tr5);
				*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
				RTAR(tr3,tr4);
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F835_6413)(tr3);
				tr4 = RTMS_EX_H("c",1,99);
				tr1 = F1378_14206(Current, tr1, tr2, tr4, (EIF_BOOLEAN) 1);
				loc2 = tr1;
				if (EIF_TEST(loc2)) {
					tr1 = RTMS_EX_H("Cancel",6,1984480108);
					tb1 = F1046_9031(loc2, tr1);
					if (tb1) {
						F310_4887(Current);
					} else {
						tr1 = RTMS_EX_H("Refresh",7,440963944);
						tb1 = F1046_9031(loc2, tr1);
						if (tb1) {
							F1378_14200(Current);
						} else {
							tr1 = RTMS_EX_H("Back",4,1113678699);
							tb1 = F1046_9031(loc2, tr1);
							if (tb1) {
								F1378_14201(Current);
							} else {
								tr1 = RTMS_EX_H("Continue",8,2035097445);
								tb1 = F1046_9031(loc2, tr1);
								if (tb1) {
									F1378_14199(Current);
								} else {
									F1378_14199(Current);
								}
							}
						}
					}
				} else {
					F1378_14199(Current);
				}
			}
		}
	} else {
		F310_4887(Current);
	}
	RTLE;
}

/* {CONSOLE_WIZARD_APPLICATION}.process_page */
void F1378_14203 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,loc5);
	RTLIU(8);
	
	RTGC;
	F857_6576(RTCW(arg1));
	tr1 = RTMS_EX_H("\012",1,10);
	F1377_14191(Current, tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1377_14191(Current, loc1);
		tr1 = RTMS_EX_H("\012",1,10);
		F1377_14191(Current, tr1);
		tr1 = RTLNS(eif_new_type(1053, 0x01).id, 1053, _OBJSIZ_1_1_0_3_0_0_0_0_);
		ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_0_0_2_);
		F1052_9287(RTCW(tr1), (EIF_CHARACTER_8) '=', ti4_1);
		F1377_14191(Current, tr1);
		tr1 = RTMS_EX_H("\012",1,10);
		F1377_14191(Current, tr1);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tr1 = RTMS_EX_H("  -- ",5,540077344);
			F1377_14191(Current, tr1);
			F1377_14191(Current, loc2);
			tr1 = RTMS_EX_H("\012",1,10);
			F1377_14191(Current, tr1);
		}
	}
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_9_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		tb2 = F483_5233(loc3);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		loc4 = F657_5737(loc3);
		for (;;) {
			tb1 = F779_6234(loc4);
			if (tb1) break;
			tr1 = RTMS_EX_H(" : ",3,2112032);
			F1377_14191(Current, tr1);
			tr1 = F779_6225(loc4);
			ti4_1 = eif_integer_32_item(RTCW(tr1),2);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 3L))) {
				tr1 = RTMS_EX_H("Error:",6,2056441402);
				F1377_14191(Current, tr1);
			} else {
				tr1 = F779_6225(loc4);
				ti4_1 = eif_integer_32_item(RTCW(tr1),2);
				if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L))) {
					tr1 = RTMS_EX_H("Warning:",8,1443528762);
					F1377_14191(Current, tr1);
				} else {
					tr1 = RTMS_EX_H("Info:",5,1852767546);
					F1377_14191(Current, tr1);
				}
			}
			tr1 = F779_6225(loc4);
			tr1 = eif_boxed_item(tr1,1);
			F1377_14191(Current, tr1);
			tr1 = RTMS_EX_H("\012",1,10);
			F1377_14191(Current, tr1);
			F779_6240(loc4);
		}
	}
	F857_6577(RTCW(arg1));
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
	loc5 = F657_5737(RTCW(tr1));
	for (;;) {
		tb2 = F779_6234(loc5);
		if (tb2) break;
		tr1 = F779_6225(loc5);
		F1378_14204(Current, tr1);
		F779_6240(loc5);
	}
	RTLE;
}

/* {CONSOLE_WIZARD_APPLICATION}.output_page_item */
void F1378_14204 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(13);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,tr4);
	RTLR(9,tr5);
	RTLR(10,loc4);
	RTLR(11,loc5);
	RTLR(12,loc6);
	RTLIU(13);
	
	RTGC;
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(268, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(loc1);
		F1377_14191(Current, tr1);
		tr1 = RTMS_EX_H("\012",1,10);
		F1377_14191(Current, tr1);
	} else {
		loc2 = arg1;
		loc2 = RTRV(eif_new_type(275, 0x01),loc2);
		if (EIF_TEST(loc2)) {
			tr1 = RTMS_EX_H(" -> ",4,539835936);
			F1377_14191(Current, tr1);
			loc3 = arg1;
			loc3 = RTRV(eif_new_type(277, 0x01),loc3);
			if (EIF_TEST(loc3)) {
				tr1 = *(EIF_REFERENCE *)(loc3 + _REFACS_2_);
				{
					static EIF_TYPE_INDEX typarr0[] = {834,0xFF01,0xFFF9,2,966,0xFF01,1053,978,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
					RT_SPECIAL_COUNT(tr3) = 2L;
					memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
				}
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,966,0xFF01,1053,978,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr4 = RTLNTS(typres0.id, 3, 0);
				}
				tr5 = RTMS_EX_H("y",1,121);
				((EIF_TYPED_VALUE *)tr4+1)->it_r = tr5;
				RTAR(tr4,tr5);
				((EIF_TYPED_VALUE *)tr4+2)->it_b = (EIF_BOOLEAN) 1;
				*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
				RTAR(tr3,tr4);
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,966,0xFF01,1053,978,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr4 = RTLNTS(typres0.id, 3, 0);
				}
				tr5 = RTMS_EX_H("n",1,110);
				((EIF_TYPED_VALUE *)tr4+1)->it_r = tr5;
				RTAR(tr4,tr5);
				((EIF_TYPED_VALUE *)tr4+2)->it_b = (EIF_BOOLEAN) 0;
				*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
				RTAR(tr3,tr4);
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F835_6413)(tr3);
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4529[Dtype(loc3)-281])(loc3);
				tb1 = F1378_14205(Current, tr1, tr2, tb1);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_BOOLEAN)) R4532[Dtype(loc3)-281])(loc3, tb1);
			} else {
				loc4 = arg1;
				loc4 = RTRV(eif_new_type(276, 0x01),loc4);
				if (EIF_TEST(loc4)) {
					tr1 = *(EIF_REFERENCE *)(loc4 + _REFACS_2_);
					tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4517[Dtype(loc4)-281])(loc4);
					tr1 = F1378_14206(Current, tr1, NULL, tr2, (EIF_BOOLEAN) 0);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4518[Dtype(loc4)-281])(loc4, tr1);
				} else {
					loc5 = arg1;
					loc5 = RTRV(eif_new_type(279, 0x01),loc5);
					if (EIF_TEST(loc5)) {
						tr1 = *(EIF_REFERENCE *)(loc5 + _REFACS_2_);
						tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4517[Dtype(loc5)-281])(loc5);
						tr1 = F1378_14206(Current, tr1, NULL, tr2, (EIF_BOOLEAN) 0);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4538[Dtype(loc5)-282])(loc5, tr1);
					} else {
						loc6 = arg1;
						loc6 = RTRV(eif_new_type(278, 0x01),loc6);
						if (EIF_TEST(loc6)) {
							tr1 = *(EIF_REFERENCE *)(loc6 + _REFACS_2_);
							tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4517[Dtype(loc6)-281])(loc6);
							tr1 = F1378_14206(Current, tr1, NULL, tr2, (EIF_BOOLEAN) 0);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4518[Dtype(loc6)-281])(loc6, tr1);
						}
					}
				}
			}
		}
	}
	RTLE;
}

/* {CONSOLE_WIZARD_APPLICATION}.boolean_question */
EIF_BOOLEAN F1378_14205 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(13);
	RTLR(0,loc4);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,loc5);
	RTLR(8,loc2);
	RTLR(9,arg1);
	RTLR(10,loc1);
	RTLR(11,loc6);
	RTLR(12,loc7);
	RTLIU(13);
	
	RTGC;
	if ((EIF_BOOLEAN)(loc4 == NULL)) {
		loc4 = (EIF_REFERENCE) arg2;
	}
	if ((EIF_BOOLEAN)(loc4 == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {834,0xFF01,0xFFF9,2,966,0xFF01,1053,978,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr2) = 2L;
			memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
		}
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,966,0xFF01,1053,978,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNTS(typres0.id, 3, 0);
		}
		tr4 = RTMS_EX_H("y",1,121);
		((EIF_TYPED_VALUE *)tr3+1)->it_r = tr4;
		RTAR(tr3,tr4);
		((EIF_TYPED_VALUE *)tr3+2)->it_b = (EIF_BOOLEAN) 1;
		*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
		RTAR(tr2,tr3);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,966,0xFF01,1053,978,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNTS(typres0.id, 3, 0);
		}
		tr4 = RTMS_EX_H("Y",1,89);
		((EIF_TYPED_VALUE *)tr3+1)->it_r = tr4;
		RTAR(tr3,tr4);
		((EIF_TYPED_VALUE *)tr3+2)->it_b = (EIF_BOOLEAN) 1;
		*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
		RTAR(tr2,tr3);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F835_6413)(tr2);
		loc4 = (EIF_REFERENCE) tr1;
	}
	loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4759[Dtype(RTCW(loc4))-327])(loc4);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5449[Dtype(loc5)-720])(loc5);
		if (tb1) break;
		if ((EIF_BOOLEAN)(loc2 != NULL)) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5448[Dtype(loc5)-720])(loc5);
		tb2 = eif_boolean_item(RTCW(tr1),2);
		if ((EIF_BOOLEAN)(arg3 == tb2)) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5448[Dtype(loc5)-720])(loc5);
			tr1 = eif_boxed_item(tr1,1);
			loc2 = F1046_9048(RTCW(tr1));
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5450[Dtype(loc5)-720])(loc5);
	}
	for (;;) {
		if (loc3) break;
		F1377_14191(Current, arg1);
		tr1 = RTMS_EX_H(" ",1,32);
		F1377_14191(Current, tr1);
		loc1 = RTLNS(eif_new_type(1050, 0x01).id, 1050, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1046_8989(RTCW(loc1));
		loc6 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4759[Dtype(RTCW(loc4))-327])(loc4);
		for (;;) {
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5449[Dtype(loc6)-720])(loc6);
			if (tb2) break;
			tb3 = F491_5233(RTCW(loc1));
			if ((EIF_BOOLEAN) !tb3) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ',';
				F1051_9247(RTCW(loc1), tw1);
			}
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5448[Dtype(loc6)-720])(loc6);
			tr1 = eif_boxed_item(tr1,1);
			F1051_9233(RTCW(loc1), tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5450[Dtype(loc6)-720])(loc6);
		}
		tr1 = RTMS_EX_H(" (",2,8232);
		F1377_14191(Current, tr1);
		F1377_14191(Current, loc1);
		tr1 = RTMS_EX_H(") ",2,10528);
		F1377_14191(Current, tr1);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			tr1 = RTMS_EX_H("[default=",9,414775101);
			F1377_14191(Current, tr1);
			F1377_14191(Current, loc2);
			tr1 = RTMS_EX_H("] ",2,23840);
			F1377_14191(Current, tr1);
		}
		tr1 = RTMS_EX_H("\?",1,63);
		F1377_14191(Current, tr1);
		F66_1453(RTCV(RTOSCF(24,F1_24, (Current))));
		tr1 = F66_1404(RTCV(RTOSCF(24,F1_24, (Current))));
		loc1 = F1046_9048(RTCW(tr1));
		F1051_9218(RTCW(loc1));
		F1051_9219(RTCW(loc1));
		tb3 = '\0';
		tb4 = F491_5233(RTCW(loc1));
		if (tb4) {
			tb3 = (EIF_BOOLEAN)(loc2 != NULL);
		}
		if (tb3) {
			loc1 = RTLNS(eif_new_type(1050, 0x01).id, 1050, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F1051_9195(RTCW(loc1), loc2);
		}
		tb3 = F491_5233(RTCW(loc1));
		if ((EIF_BOOLEAN) !tb3) {
			loc7 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4759[Dtype(RTCW(loc4))-327])(loc4);
			for (;;) {
				tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5449[Dtype(loc7)-720])(loc7);
				if (tb3) break;
				if (loc3) break;
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5448[Dtype(loc7)-720])(loc7);
				tr1 = eif_boxed_item(tr1,1);
				tr2 = F1046_9045(RTCW(loc1));
				tb4 = F1052_9314(RTCW(tr1), tr2);
				if (tb4) {
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5448[Dtype(loc7)-720])(loc7);
					Result = eif_boolean_item(RTCW(tr1),2);
				}
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R5450[Dtype(loc7)-720])(loc7);
			}
			if ((EIF_BOOLEAN) !loc3) {
				loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
		}
	}
	RTLE;
	return Result;
}

/* {CONSOLE_WIZARD_APPLICATION}.string_question */
EIF_REFERENCE F1378_14206 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_BOOLEAN arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN tb6;
	EIF_BOOLEAN tb7;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(14);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg2);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,arg3);
	RTLR(8,loc5);
	RTLR(9,tr2);
	RTLR(10,loc6);
	RTLR(11,Result);
	RTLR(12,loc7);
	RTLR(13,loc8);
	RTLIU(14);
	
	RTGC;
	for (;;) {
		if (loc2) break;
		F1377_14191(Current, arg1);
		tr1 = RTMS_EX_H(" ",1,32);
		F1377_14191(Current, tr1);
		loc1 = RTLNS(eif_new_type(1050, 0x01).id, 1050, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1046_8989(RTCW(loc1));
		if ((EIF_BOOLEAN)(arg2 != NULL)) {
			loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4759[Dtype(RTCW(arg2))-327])(arg2);
			for (;;) {
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5449[Dtype(loc3)-720])(loc3);
				if (tb1) break;
				tb2 = F491_5233(RTCW(loc1));
				if ((EIF_BOOLEAN) !tb2) {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ',';
					F1051_9247(RTCW(loc1), tw1);
				}
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5448[Dtype(loc3)-720])(loc3);
				tr1 = eif_boxed_item(tr1,1);
				F1051_9233(RTCW(loc1), tr1);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5448[Dtype(loc3)-720])(loc3);
				tr1 = eif_boxed_item(tr1,2);
				loc4 = tr1;
				if (EIF_TEST(loc4)) {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '=';
					F1051_9247(RTCW(loc1), tw1);
					F1051_9233(RTCW(loc1), loc4);
				}
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R5450[Dtype(loc3)-720])(loc3);
			}
			tr1 = RTMS_EX_H("(",1,40);
			F1377_14191(Current, tr1);
			F1377_14191(Current, loc1);
			tr1 = RTMS_EX_H(") ",2,10528);
			F1377_14191(Current, tr1);
		}
		if ((EIF_BOOLEAN)(arg3 != NULL)) {
			tr1 = RTMS_EX_H("[default=",9,414775101);
			F1377_14191(Current, tr1);
			F1377_14191(Current, arg3);
			tr1 = RTMS_EX_H("] ",2,23840);
			F1377_14191(Current, tr1);
		}
		tr1 = RTMS_EX_H("\?",1,63);
		F1377_14191(Current, tr1);
		F66_1453(RTCV(RTOSCF(24,F1_24, (Current))));
		loc1 = RTLNS(eif_new_type(1050, 0x01).id, 1050, _OBJSIZ_1_1_0_3_0_0_0_0_);
		tr1 = F66_1404(RTCV(RTOSCF(24,F1_24, (Current))));
		F1051_9195(RTCW(loc1), tr1);
		F1051_9218(RTCW(loc1));
		F1051_9219(RTCW(loc1));
		tb2 = '\0';
		tb3 = F491_5233(RTCW(loc1));
		if (tb3) {
			tb2 = (EIF_BOOLEAN)(arg3 != NULL);
		}
		if (tb2) {
			loc1 = RTLNS(eif_new_type(1050, 0x01).id, 1050, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F1051_9195(RTCW(loc1), arg3);
		}
		tb2 = F491_5233(RTCW(loc1));
		if ((EIF_BOOLEAN) !tb2) {
			if ((EIF_BOOLEAN)(arg2 != NULL)) {
				loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4759[Dtype(RTCW(arg2))-327])(arg2);
				for (;;) {
					tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5449[Dtype(loc5)-720])(loc5);
					if (tb2) break;
					if (loc2) break;
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5448[Dtype(loc5)-720])(loc5);
					tr1 = eif_boxed_item(tr1,1);
					tr2 = F1046_9045(RTCW(loc1));
					tb3 = F1052_9314(RTCW(tr1), tr2);
					if (tb3) {
						loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5448[Dtype(loc5)-720])(loc5);
						tr1 = eif_boxed_item(tr1,2);
						loc6 = tr1;
						if (EIF_TEST(loc6)) {
							Result = RTLNS(eif_new_type(1050, 0x01).id, 1050, _OBJSIZ_1_1_0_3_0_0_0_0_);
							F1051_9195(RTCW(Result), loc6);
						} else {
							Result = (EIF_REFERENCE) NULL;
						}
					}
					(FUNCTION_CAST(void, (EIF_REFERENCE)) R5450[Dtype(loc5)-720])(loc5);
				}
			}
			if ((EIF_BOOLEAN) !loc2) {
				loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				Result = (EIF_REFERENCE) loc1;
				tb3 = '\0';
				if ((EIF_BOOLEAN) (arg4 && (EIF_BOOLEAN)(arg2 != NULL))) {
					loc7 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4759[Dtype(RTCW(arg2))-327])(arg2);
					tb4 = EIF_FALSE;
					for (;;) {
						if (tb4) break;
						tb5 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5449[Dtype(loc7)-720])(loc7);
						if (tb5) break;
						tb6 = '\0';
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5448[Dtype(loc7)-720])(loc7);
						tr1 = eif_boxed_item(tr1,2);
						loc8 = tr1;
						if (EIF_TEST(loc8)) {
							tb7 = F1046_9034(RTCW(Result), loc8);
							tb6 = tb7;
						}
						tb4 = tb6;
						(FUNCTION_CAST(void, (EIF_REFERENCE)) R5450[Dtype(loc7)-720])(loc7);
					}
					tb3 = (EIF_BOOLEAN) !tb4;
				}
				if (tb3) {
					loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					Result = (EIF_REFERENCE) NULL;
				}
			}
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit733 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
