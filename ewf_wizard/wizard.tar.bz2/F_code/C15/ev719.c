/*
 * Code for class EV_DRAWING_AREA_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev719.h"
#include <cairo.h>
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F105_2281
static void inline_F105_2281 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	gtk_widget_set_size_request ((GtkWidget*) arg1, (gint) arg2, (gint) arg3)
	;
}
#define INLINE_F105_2281
#endif
#ifndef INLINE_F18_468
static void inline_F18_468 (EIF_POINTER arg1)
{
	cairo_surface_destroy((cairo_surface_t*) arg1)
	;
}
#define INLINE_F18_468
#endif
#ifndef INLINE_F104_1905
static EIF_POINTER inline_F104_1905 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	return gdk_window_create_similar_surface ((GdkWindow *)arg1,
                                   (cairo_content_t)arg2,
                                   (int)arg3,
                                   (int)arg4);
	;
}
#define INLINE_F104_1905
#endif
#ifndef INLINE_F18_511
static void inline_F18_511 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	double len = 2.0;
if (arg2) {
	cairo_set_dash ((cairo_t *) arg1, &len, 1, 0.0);
} else {
	cairo_set_dash ((cairo_t *) arg1, NULL, 0, 0.0);
}
	;
}
#define INLINE_F18_511
#endif
#ifndef INLINE_F18_526
static void inline_F18_526 (EIF_POINTER arg1)
{
	cairo_paint ((cairo_t*)arg1)
	;
}
#define INLINE_F18_526
#endif
#ifndef INLINE_F107_2661
static void inline_F107_2661 (EIF_POINTER arg1)
{
	gtk_widget_queue_draw ((GtkWidget *)arg1)
	;
}
#define INLINE_F107_2661
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DRAWING_AREA_IMP}.make */
void F1364_13865 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLIU(7);
	
	RTGC;
	loc1 = (EIF_POINTER) gtk_drawing_area_new();
	inline_F105_2281(loc1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 1L));
	F1214_11563(Current, loc1);
	loc2 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_0_);
	gtk_widget_set_redraw_on_allocate((GtkWidget*) loc2, (gboolean) (EIF_BOOLEAN) 0);
	gtk_widget_set_app_paintable((GtkWidget*) loc2, (gboolean) (EIF_BOOLEAN) 1);
	loc3 = RTOSCF(11588,F1214_11588, (Current));
	tr1 = RTOSCF(747,F28_747, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,966,0xFF01,928,1038,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	((EIF_TYPED_VALUE *)tr2+2)->it_p = loc2;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1044,0xFF01,0xFFF9,1,966,1038,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A360_330_3, (EIF_POINTER) _A360_330_3, (EIF_POINTER)(F927_7588),tr2, 1, 1);
	}
	F1214_11567(Current, loc2, tr1, tr5);
	tr1 = RTOSCF(773,F28_773, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,966,0xFF01,928,1038,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	((EIF_TYPED_VALUE *)tr2+2)->it_p = loc1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1044,0xFF01,0xFFF9,1,966,1038,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A360_331_3, (EIF_POINTER) _A360_331_3, (EIF_POINTER)(F927_7589),tr2, 1, 1);
	}
	F1214_11567(Current, loc2, tr1, tr5);
	tr1 = RTOSCF(761,F28_761, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,966,0xFF01,928,1038,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	((EIF_TYPED_VALUE *)tr2+2)->it_p = loc2;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1044,0xFF01,0xFFF9,1,966,1038,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A360_329_3, (EIF_POINTER) _A360_329_3, (EIF_POINTER)(F927_7587),tr2, 1, 1);
	}
	F1214_11568(Current, loc2, tr1, tr5);
	F1363_13776(Current);
	tr1 = F1226_11774(Current);
	F1227_11785(Current, loc2, tr1);
	tb1 = '\0';
	tb2 = '\0';
	loc4 = F1214_11587(Current);
	if ((EIF_TRUE)) {
		tb3 = !loc4;
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tb1 = (EIF_BOOLEAN)(loc4 != loc2);
	}
	if (tb1) {
		tr1 = F1226_11774(Current);
		F1227_11785(Current, loc4, tr1);
	}
	F1315_12914(Current);
	F1315_12920(Current);
	F1315_12922(Current);
	RTLE;
}

/* {EV_DRAWING_AREA_IMP}.destroy */
void F1364_13866 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1363_13847(Current);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_2_);
	tb1 = !tp1;
	if ((EIF_BOOLEAN) !tb1) {
		F1364_13877(Current, *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_2_));
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_2_) = (EIF_POINTER) tp2;
	}
	F1267_12243(Current);
	RTLE;
}

/* {EV_DRAWING_AREA_IMP}.c_object_dispose */
void F1364_13867 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_1_);
	tb1 = !tp1;
	if ((EIF_BOOLEAN) !tb1) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_1_);
		cairo_destroy((cairo_t*) tp1);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_1_) = (EIF_POINTER) tp2;
	}
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_2_);
	tb1 = !tp1;
	if ((EIF_BOOLEAN) !tb1) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_2_);
		inline_F18_468(tp1);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_2_) = (EIF_POINTER) tp2;
	}
	F1214_11578(Current);
	RTLE;
}

/* {EV_DRAWING_AREA_IMP}.start_transparency */
void F1364_13868 (EIF_REFERENCE Current, EIF_REAL_64 arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_INTEGER_8 ti1_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_1_);
	tb1 = !loc1;
	if ((EIF_BOOLEAN) !tb1) {
		F1363_13813(Current, arg1);
		tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 1L));
		tr8_2 = (EIF_REAL_64) (((EIF_INTEGER_32) 1L));
		tr8_3 = (EIF_REAL_64) (((EIF_INTEGER_32) 1L));
		cairo_set_source_rgba((cairo_t*) loc1, (double) tr8_1, (double) tr8_2, (double) tr8_3, (double) arg1);
		ti1_1 = (EIF_INTEGER_8) CAIRO_OPERATOR_SOURCE;
		cairo_set_operator((cairo_t*) loc1, (cairo_operator_t) ti1_1);
	}
	RTLE;
}

/* {EV_DRAWING_AREA_IMP}.stop_transparency */
void F1364_13869 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_INTEGER_8 ti1_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_1_);
	tb1 = !loc1;
	if ((EIF_BOOLEAN) !tb1) {
		ti1_1 = (EIF_INTEGER_8) CAIRO_OPERATOR_OVER;
		cairo_set_operator((cairo_t*) loc1, (cairo_operator_t) ti1_1);
	}
	RTLE;
}

/* {EV_DRAWING_AREA_IMP}.pre_drawing */
void F1364_13870 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1358_13695(Current)) {
		F1364_13876(Current);
		loc1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_1_);
		tb1 = !loc1;
		if ((EIF_BOOLEAN) !tb1) {
			cairo_save((cairo_t*) loc1);
		}
	}
	RTLE;
}

/* {EV_DRAWING_AREA_IMP}.post_drawing */
void F1364_13871 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1358_13695(Current)) {
		loc1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_1_);
		tb1 = !loc1;
		if ((EIF_BOOLEAN) !tb1) {
			cairo_restore((cairo_t*) loc1);
		}
		F1364_13891(Current);
	}
	RTLE;
}

/* {EV_DRAWING_AREA_IMP}.start_drawing_session */
void F1364_13872 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1358_13698(Current);
	if (F1358_13696(Current)) {
		F1363_13781(Current);
	}
	RTLE;
}

/* {EV_DRAWING_AREA_IMP}.end_drawing_session */
void F1364_13873 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (F1358_13696(Current)) {
		F1363_13847(Current);
		F1364_13891(Current);
	}
	F1358_13699(Current);
	RTLE;
}

/* {EV_DRAWING_AREA_IMP}.get_new_cairo_surface */
void F1364_13875 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc2 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_0_);
	loc3 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) loc2);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc3 != tp1)) {
		loc4 = (EIF_INTEGER_32) gtk_widget_get_allocated_width((GtkWidget*) loc2);
		loc5 = (EIF_INTEGER_32) gtk_widget_get_allocated_height((GtkWidget*) loc2);
		ti4_1 = (EIF_INTEGER_32) CAIRO_CONTENT_COLOR_ALPHA;
		loc1 = inline_F104_1905(loc3, ti4_1, loc4, loc5);
		*(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_2_) = (EIF_POINTER) loc1;
	} else {
	}
	RTLE;
}

/* {EV_DRAWING_AREA_IMP}.get_cairo_context */
void F1364_13876 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc2 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_1_);
	tb1 = !loc2;
	if (tb1) {
		loc1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_2_);
		tb1 = !loc1;
		if ((EIF_BOOLEAN) !tb1) {
			loc2 = (EIF_POINTER) cairo_create((cairo_surface_t*) loc1);
			F1364_13878(Current, loc2);
			*(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_1_) = (EIF_POINTER) loc2;
		}
	}
	RTLE;
}

/* {EV_DRAWING_AREA_IMP}.release_cairo_surface */
void F1364_13877 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	
	
	RTGC;
	tb1 = !arg1;
	if ((EIF_BOOLEAN) !tb1) {
		inline_F18_468(arg1);
	}
}

/* {EV_DRAWING_AREA_IMP}.initialize_cairo_context */
void F1364_13878 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_8 ti1_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	ti1_1 = *(EIF_INTEGER_8 *)(Current+ _CHROFF_48_17_);
	cairo_set_antialias((cairo_t*) arg1, (cairo_antialias_t) ti1_1);
	ti1_1 = *(EIF_INTEGER_8 *)(Current+ _CHROFF_48_18_);
	cairo_set_line_cap((cairo_t*) arg1, (cairo_line_cap_t) ti1_1);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_48_19_10_8_);
	tr8_1 = (EIF_REAL_64) (ti4_1);
	cairo_set_line_width((cairo_t*) arg1, (double) tr8_1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr4_1 = F1090_9685(loc1);
		tr8_1 = (EIF_REAL_64) (tr4_1);
		tr4_1 = F1090_9686(loc1);
		tr8_2 = (EIF_REAL_64) (tr4_1);
		tr4_1 = F1090_9687(loc1);
		tr8_3 = (EIF_REAL_64) (tr4_1);
		cairo_set_source_rgb((cairo_t*) arg1, (double) tr8_1, (double) tr8_2, (double) tr8_3);
	} else {
		cairo_set_source_rgb((cairo_t*) arg1, (double) (EIF_REAL_64) 0.0, (double) (EIF_REAL_64) 0.0, (double) (EIF_REAL_64) 0.0);
	}
	ti1_1 = F1363_13804(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_48_19_10_7_));
	cairo_set_operator((cairo_t*) arg1, (cairo_operator_t) ti1_1);
	tb1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_48_13_);
	inline_F18_511(arg1, tb1);
	RTLE;
}

/* {EV_DRAWING_AREA_IMP}.process_draw_event */
EIF_BOOLEAN F1364_13880 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REAL_64 loc1 = (EIF_REAL_64) 0;
	EIF_REAL_64 loc2 = (EIF_REAL_64) 0;
	EIF_REAL_64 loc3 = (EIF_REAL_64) 0;
	EIF_REAL_64 loc4 = (EIF_REAL_64) 0;
	EIF_POINTER loc5 = (EIF_POINTER) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc6);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc5 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_2_);
	tb1 = !loc5;
	if (tb1) {
	} else {
		tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
		tr8_2 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
		cairo_set_source_surface((cairo_t*) arg1, (cairo_surface_t*) loc5, (double) tr8_1, (double) tr8_2);
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			tb2 = F483_5233(loc6);
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_48_14_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			cairo_clip_extents((cairo_t*) arg1, (double*) (EIF_REAL_64 *) &(loc1), (double*) (EIF_REAL_64 *) &(loc2), (double*) (EIF_REAL_64 *) &(loc3), (double*) (EIF_REAL_64 *) &(loc4));
			F1364_13872(Current);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,4,966,984,984,984,984,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
				tr1 = RTLNTS(typres0.id, 5, 1);
			}
			ti4_1 = (EIF_INTEGER_32) loc1;
			((EIF_TYPED_VALUE *)tr1+1)->it_i4 = ti4_1;
			ti4_1 = (EIF_INTEGER_32) loc2;
			((EIF_TYPED_VALUE *)tr1+2)->it_i4 = ti4_1;
			ti4_1 = (EIF_INTEGER_32) loc3;
			((EIF_TYPED_VALUE *)tr1+3)->it_i4 = ti4_1;
			ti4_1 = (EIF_INTEGER_32) loc4;
			((EIF_TYPED_VALUE *)tr1+4)->it_i4 = ti4_1;
			F680_5877(loc6, tr1);
			F1364_13873(Current);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_48_14_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
		inline_F18_526(arg1);
	}
	RTLE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {EV_DRAWING_AREA_IMP}.process_configure_event */
EIF_BOOLEAN F1364_13881 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_16 ti2_1;
	EIF_INTEGER_8 ti1_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tb1 = '\01';
	tb2 = '\01';
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_2_);
	tb3 = !tp1;
	if (!tb3) {
		ti2_1 = *(EIF_INTEGER_16 *)(Current+ _I16OFF_48_19_8_);
		ti4_1 = (EIF_INTEGER_32) ti2_1;
		tb2 = (EIF_BOOLEAN)(arg3 != ti4_1);
	}
	if (!tb2) {
		ti2_1 = *(EIF_INTEGER_16 *)(Current+ _I16OFF_48_19_9_);
		ti4_1 = (EIF_INTEGER_32) ti2_1;
		tb1 = (EIF_BOOLEAN)(arg4 != ti4_1);
	}
	if (tb1) {
		F1363_13847(Current);
		loc1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_2_);
		tb1 = !loc1;
		if ((EIF_BOOLEAN) !tb1) {
			cairo_surface_flush((cairo_surface_t*) loc1);
			{
				/* INLINED CODE (ANY.default_pointer) */
				tp1 = (EIF_POINTER)  0;
				/* END INLINED CODE */
			}
			tp2 = tp1;
			*(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_2_) = (EIF_POINTER) tp2;
			F1364_13875(Current, arg3, arg4);
			loc2 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_2_);
			loc3 = (EIF_POINTER) cairo_create((cairo_surface_t*) loc2);
			tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
			tr8_2 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
			cairo_set_source_surface((cairo_t*) loc3, (cairo_surface_t*) loc1, (double) tr8_1, (double) tr8_2);
			ti1_1 = (EIF_INTEGER_8) CAIRO_OPERATOR_SOURCE;
			cairo_set_operator((cairo_t*) loc3, (cairo_operator_t) ti1_1);
			inline_F18_526(loc3);
			F1363_13846(Current, loc3);
			F1364_13877(Current, loc1);
		}
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_2_);
		tb1 = !tp1;
		if (tb1) {
			F1364_13875(Current, arg3, arg4);
		}
	}
	RTLE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EV_DRAWING_AREA_IMP}.process_button_event */
void F1364_13882 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(11588,F1214_11588, (Current));
	loc3 = tr1;
	if ((EIF_TRUE)) {
		tr8_1 = (EIF_REAL_64) (((GdkEventButton *)arg1)->x_root);
		loc1 = (EIF_INTEGER_32) tr8_1;
		ti4_1 = *(EIF_INTEGER_32 *)(loc3+ _LNGOFF_49_16_0_11_);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ti4_1);
		tr8_1 = (EIF_REAL_64) (((GdkEventButton *)arg1)->y_root);
		loc2 = (EIF_INTEGER_32) tr8_1;
		ti4_1 = *(EIF_INTEGER_32 *)(loc3+ _LNGOFF_49_16_0_12_);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ti4_1);
		ti4_1 = (EIF_INTEGER_32) (((GdkEventButton *)arg1)->type);
		tr8_1 = (EIF_REAL_64) (((GdkEventButton *)arg1)->x);
		ti4_2 = (EIF_INTEGER_32) tr8_1;
		tr8_1 = (EIF_REAL_64) (((GdkEventButton *)arg1)->y);
		ti4_3 = (EIF_INTEGER_32) tr8_1;
		ti4_4 = (EIF_INTEGER_32) (((GdkEventButton *)arg1)->button);
		F1265_12165(Current, ti4_1, ti4_2, ti4_3, ti4_4, (EIF_REAL_64) 0.5, (EIF_REAL_64) 0.5, (EIF_REAL_64) 0.5, loc1, loc2);
	}
	RTLE;
}

/* {EV_DRAWING_AREA_IMP}.process_scroll_event */
EIF_BOOLEAN F1364_13883 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) (((GdkEventScroll *)arg1)->direction) == (EIF_INTEGER_32) GDK_SCROLL_UP)) {
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
	} else {
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
	}
	ti4_1 = (EIF_INTEGER_32) GDK_BUTTON_PRESS;
	F1364_13893(Current, ti4_1, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc1, (EIF_REAL_64) 0.5, (EIF_REAL_64) 0.5, (EIF_REAL_64) 0.5, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	RTLE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EV_DRAWING_AREA_IMP}.button_actions_handled_by_signals */
EIF_BOOLEAN F1364_13884 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EV_DRAWING_AREA_IMP}.on_size_allocate */
void F1364_13885 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	
	
	F1267_12216(Current, arg1, arg2, arg3, arg4);
}

/* {EV_DRAWING_AREA_IMP}.update_if_needed */
void F1364_13891 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_48_14_)) {
		tp1 = F1214_11587(Current);
		inline_F107_2661(tp1);
	}
	RTLE;
}

/* {EV_DRAWING_AREA_IMP}.internal_set_focus */
void F1364_13892 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_0_);
	loc1 = (EIF_BOOLEAN) EIF_TEST(gtk_widget_get_can_focus((GtkWidget*) tp1));
	if ((EIF_BOOLEAN) !loc1) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_0_);
		gtk_widget_set_can_focus((GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 1);
	}
	F1215_11613(Current);
	if ((EIF_BOOLEAN) !loc1) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_0_);
		gtk_widget_set_can_focus((GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 0);
	}
	RTLE;
}

/* {EV_DRAWING_AREA_IMP}.call_button_event_actions */
void F1364_13893 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_REAL_64 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9)
{
	GTCX
	EIF_POINTER tp1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tb1 = '\0';
	tb2 = '\0';
	tb3 = '\0';
	if ((EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_BUTTON_PRESS)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_48_19_10_9_0_0_);
		tb3 = (EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(gtk_widget_has_focus((GtkWidget*) tp1));
	}
	if (tb3) {
		tb2 = (EIF_BOOLEAN) ((EIF_BOOLEAN)(arg4 == ((EIF_INTEGER_32) 1L)) && (EIF_BOOLEAN) (arg4 <= ((EIF_INTEGER_32) 3L)));
	}
	if (tb2) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_48_11_);
	}
	if (tb1) {
		F1215_11612(Current);
	}
	F1267_12219(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
	RTLE;
}

void EIF_Minit719 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
