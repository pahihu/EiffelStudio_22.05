
#ifndef _C21_dy1026_
#define _C21_dy1026_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F436_5199(EIF_REFERENCE);
extern void EIF_Minit1026(void);

#ifdef __cplusplus
}
#endif

#endif
