
#ifndef _C21_ar1022_
#define _C21_ar1022_

#ifdef __cplusplus
extern "C" {
#endif

extern void F810_6263(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F810_6264(EIF_REFERENCE);
extern EIF_REFERENCE F810_6265(EIF_REFERENCE);
extern EIF_REFERENCE F810_6267(EIF_REFERENCE);
extern EIF_INTEGER_32 F810_6268(EIF_REFERENCE);
extern void EIF_Minit1022(void);
extern EIF_TYPE_INDEX Y5451[];
extern EIF_TYPE_INDEX *Y5451_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
