
#ifndef _C21_re1036_
#define _C21_re1036_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F559_5295(EIF_REFERENCE);
extern void EIF_Minit1036(void);
extern void F765_6191(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5523[])();
extern EIF_TYPE_INDEX Y4760[];
extern EIF_TYPE_INDEX *Y4760_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
