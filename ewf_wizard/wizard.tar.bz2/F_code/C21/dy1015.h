
#ifndef _C21_dy1015_
#define _C21_dy1015_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F608_5453(EIF_REFERENCE);
extern void F608_5459(EIF_REFERENCE, EIF_NATURAL_32);
extern void F608_5460(EIF_REFERENCE, EIF_NATURAL_32);
extern void EIF_Minit1015(void);
extern EIF_BOOLEAN F368_5163(EIF_REFERENCE);
extern void F662_5760(EIF_REFERENCE, EIF_NATURAL_32);
extern void F662_5754(EIF_REFERENCE);
extern void F662_5777(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
