
#ifndef _C21_co1035_
#define _C21_co1035_

#ifdef __cplusplus
extern "C" {
#endif

extern void F342_5004(EIF_REFERENCE);
extern void F342_5005(EIF_REFERENCE);
extern void EIF_Minit1035(void);
extern long O4814[];

#ifdef __cplusplus
}
#endif

#endif
