/*
 * Code for class LINEAR [NATURAL_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li1000.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LINEAR}.has */
EIF_BOOLEAN F368_5157 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F662_5754(Current);
	if ((EIF_BOOLEAN) !F596_5444(Current)) {
		F662_5760(Current, arg1);
	}
	Result = F368_5163(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTLE;
	return Result;
}

/* {LINEAR}.search */
void F368_5159 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current + O4814[Dtype(Current)-335])) {
		for (;;) {
			tb1 = '\01';
			if (!F368_5163(Current)) {
				tb1 = (arg1 == F662_5728(Current));
			}
			if (tb1) break;
			F662_5756(Current);
		}
	} else {
		for (;;) {
			tb2 = '\01';
			if (!F368_5163(Current)) {
				tb2 = (EIF_BOOLEAN)(arg1 == F662_5728(Current));
			}
			if (tb2) break;
			F662_5756(Current);
		}
	}
	RTLE;
}

/* {LINEAR}.exhausted */
EIF_BOOLEAN F368_5163 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F596_5444(Current);
}

/* {LINEAR}.off */
EIF_BOOLEAN F368_5165 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	if (!F488_5233(Current)) {
		Result = F620_5468(Current);
	}
	RTLE;
	return Result;
}

/* {LINEAR}.linear_representation */
EIF_REFERENCE F368_5172 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) Current;
}

void EIF_Minit1000 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
