
#ifndef _C21_bi1012_
#define _C21_bi1012_

#ifdef __cplusplus
extern "C" {
#endif

extern void F380_5176(EIF_REFERENCE, EIF_NATURAL_32);
extern void EIF_Minit1012(void);
extern void F368_5159(EIF_REFERENCE, EIF_NATURAL_32);
extern EIF_BOOLEAN F488_5233(EIF_REFERENCE);
extern void F662_5756(EIF_REFERENCE);
extern EIF_BOOLEAN F620_5469(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
