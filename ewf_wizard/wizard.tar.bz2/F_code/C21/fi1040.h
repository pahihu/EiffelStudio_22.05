
#ifndef _C21_fi1040_
#define _C21_fi1040_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F489_5233(EIF_REFERENCE);
extern void EIF_Minit1040(void);
extern char *(*R4969[])();

#ifdef __cplusplus
}
#endif

#endif
