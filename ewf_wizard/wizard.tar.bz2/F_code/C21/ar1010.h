
#ifndef _C21_ar1010_
#define _C21_ar1010_

#ifdef __cplusplus
extern "C" {
#endif

extern void F796_6245(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F796_6246(EIF_REFERENCE);
extern EIF_REFERENCE F796_6247(EIF_REFERENCE);
extern EIF_REFERENCE F796_6249(EIF_REFERENCE);
extern EIF_INTEGER_32 F796_6250(EIF_REFERENCE);
extern void EIF_Minit1010(void);
extern EIF_INTEGER_32 F662_5746(EIF_REFERENCE);
extern EIF_REFERENCE F662_5727(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y5451[];
extern EIF_TYPE_INDEX *Y5451_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
