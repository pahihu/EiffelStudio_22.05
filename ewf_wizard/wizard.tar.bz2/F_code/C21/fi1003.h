
#ifndef _C21_fi1003_
#define _C21_fi1003_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F488_5233(EIF_REFERENCE);
extern void EIF_Minit1003(void);
extern char *(*R4969[])();

#ifdef __cplusplus
}
#endif

#endif
