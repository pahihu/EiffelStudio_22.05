
#ifndef _C21_co1007_
#define _C21_co1007_

#ifdef __cplusplus
extern "C" {
#endif

extern void F392_5184(EIF_REFERENCE, EIF_NATURAL_32);
extern void EIF_Minit1007(void);
extern char *(*R4945[])();
extern char *(*R4811[])();

#ifdef __cplusplus
}
#endif

#endif
