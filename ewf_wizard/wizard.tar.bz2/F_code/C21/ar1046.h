
#ifndef _C21_ar1046_
#define _C21_ar1046_

#ifdef __cplusplus
extern "C" {
#endif

extern void F797_6245(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F797_6246(EIF_REFERENCE);
extern EIF_REFERENCE F797_6247(EIF_REFERENCE);
extern EIF_REFERENCE F797_6249(EIF_REFERENCE);
extern EIF_INTEGER_32 F797_6250(EIF_REFERENCE);
extern void EIF_Minit1046(void);
extern EIF_REFERENCE F663_5727(EIF_REFERENCE);
extern EIF_INTEGER_32 F663_5746(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y5451[];
extern EIF_TYPE_INDEX *Y5451_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
