
#ifndef _C21_re1029_
#define _C21_re1029_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F513_5239(EIF_REFERENCE);
extern void F513_5241(EIF_REFERENCE);
extern void EIF_Minit1029(void);
extern char *(*R4970[])();
extern char *(*R4976[])();

#ifdef __cplusplus
}
#endif

#endif
