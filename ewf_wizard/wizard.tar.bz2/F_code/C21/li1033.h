
#ifndef _C21_li1033_
#define _C21_li1033_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F369_5157(EIF_REFERENCE, EIF_BOOLEAN);
extern void F369_5159(EIF_REFERENCE, EIF_BOOLEAN);
extern EIF_BOOLEAN F369_5163(EIF_REFERENCE);
extern EIF_BOOLEAN F369_5165(EIF_REFERENCE);
extern EIF_REFERENCE F369_5172(EIF_REFERENCE);
extern void EIF_Minit1033(void);
extern EIF_BOOLEAN F489_5233(EIF_REFERENCE);
extern char *(*R4921[])();
extern char *(*R4922[])();
extern char *(*R4923[])();
extern char *(*R4929[])();
extern char *(*R4934[])();
extern char *(*R4936[])();
extern long O4814[];

#ifdef __cplusplus
}
#endif

#endif
