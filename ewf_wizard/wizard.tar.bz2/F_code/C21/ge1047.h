
#ifndef _C21_ge1047_
#define _C21_ge1047_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F785_6225(EIF_REFERENCE);
extern EIF_INTEGER_32 F785_6227(EIF_REFERENCE);
extern EIF_BOOLEAN F785_6234(EIF_REFERENCE);
extern void F785_6239(EIF_REFERENCE);
extern void F785_6240(EIF_REFERENCE);
extern EIF_REFERENCE F785_6241(EIF_REFERENCE);
extern void EIF_Minit1047(void);
extern char *(*R5539[])();
extern char *(*R5512[])();
extern long O5538[];
extern long O5540[];

#ifdef __cplusplus
}
#endif

#endif
