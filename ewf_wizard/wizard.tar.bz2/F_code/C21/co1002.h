
#ifndef _C21_co1002_
#define _C21_co1002_

#ifdef __cplusplus
extern "C" {
#endif

extern void F341_5004(EIF_REFERENCE);
extern void F341_5005(EIF_REFERENCE);
extern void EIF_Minit1002(void);
extern long O4814[];

#ifdef __cplusplus
}
#endif

#endif
