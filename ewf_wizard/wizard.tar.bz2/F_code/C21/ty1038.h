
#ifndef _C21_ty1038_
#define _C21_ty1038_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F753_6185(EIF_REFERENCE);
extern void EIF_Minit1038(void);
extern char *(*R5524[])();
extern char *(*R4992[])();
extern char *(*R5511[])();

#ifdef __cplusplus
}
#endif

#endif
