
#ifndef _C21_to1013_
#define _C21_to1013_

#ifdef __cplusplus
extern "C" {
#endif

extern void F298_4743(EIF_REFERENCE, EIF_INTEGER_32);
extern void F298_4744(EIF_REFERENCE, EIF_NATURAL_32, EIF_INTEGER_32);
extern void F298_4750(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1013(void);
extern void F840_6405(EIF_REFERENCE, EIF_NATURAL_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y4564[];
extern EIF_TYPE_INDEX *Y4564_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
