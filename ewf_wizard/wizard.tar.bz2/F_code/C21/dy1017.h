
#ifndef _C21_dy1017_
#define _C21_dy1017_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F435_5199(EIF_REFERENCE);
extern void EIF_Minit1017(void);

#ifdef __cplusplus
}
#endif

#endif
