
#ifndef _C21_se1011_
#define _C21_se1011_

#ifdef __cplusplus
extern "C" {
#endif

extern void F524_5246(EIF_REFERENCE, EIF_NATURAL_32);
extern void EIF_Minit1011(void);
extern void F662_5764(EIF_REFERENCE, EIF_NATURAL_32);

#ifdef __cplusplus
}
#endif

#endif
