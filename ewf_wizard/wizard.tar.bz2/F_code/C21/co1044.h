
#ifndef _C21_co1044_
#define _C21_co1044_

#ifdef __cplusplus
extern "C" {
#endif

extern void F393_5184(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit1044(void);
extern char *(*R4945[])();
extern char *(*R4811[])();

#ifdef __cplusplus
}
#endif

#endif
