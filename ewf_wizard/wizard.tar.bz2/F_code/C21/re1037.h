
#ifndef _C21_re1037_
#define _C21_re1037_

#ifdef __cplusplus
extern "C" {
#endif

extern void F765_6191(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F765_6193(EIF_REFERENCE);
extern EIF_INTEGER_32 F765_6194(EIF_REFERENCE);
extern EIF_INTEGER_32 F765_6195(EIF_REFERENCE);
extern EIF_INTEGER_32 F765_6196(EIF_REFERENCE);
extern EIF_REFERENCE F765_6197(EIF_REFERENCE);
extern EIF_BOOLEAN F765_6203(EIF_REFERENCE);
extern EIF_BOOLEAN F765_6204(EIF_REFERENCE);
extern EIF_BOOLEAN F765_6205(EIF_REFERENCE);
extern void F765_6210(EIF_REFERENCE);
extern void F765_6211(EIF_REFERENCE);
extern EIF_REFERENCE F765_6212(EIF_REFERENCE);
extern void EIF_Minit1037(void);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern char *(*R5523[])();
extern char *(*R4993[])();
extern char *(*R4994[])();
extern char *(*R4996[])();
extern long O5527[];
extern long O5531[];
extern long O5532[];
extern long O5533[];
extern long O5534[];
extern long O5535[];

#ifdef __cplusplus
}
#endif

#endif
