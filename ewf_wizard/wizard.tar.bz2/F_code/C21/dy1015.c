/*
 * Code for class DYNAMIC_CHAIN [NATURAL_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "dy1015.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DYNAMIC_CHAIN}.extendible */
EIF_BOOLEAN F608_5453 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {DYNAMIC_CHAIN}.prune */
void F608_5459 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F662_5760(Current, arg1);
	if ((EIF_BOOLEAN) !F368_5163(Current)) {
		F662_5777(Current);
	}
	RTLE;
}

/* {DYNAMIC_CHAIN}.prune_all */
void F608_5460 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F662_5754(Current);
	F662_5760(Current, arg1);
	for (;;) {
		if (F368_5163(Current)) break;
		F662_5777(Current);
		F662_5760(Current, arg1);
	}
	RTLE;
}

void EIF_Minit1015 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
