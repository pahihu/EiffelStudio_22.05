
#ifndef _C3_id107_
#define _C3_id107_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F122_2982(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F122_2983(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F122_2984(EIF_REFERENCE);
extern void F122_2986(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit107(void);

#ifdef __cplusplus
}
#endif

#endif
