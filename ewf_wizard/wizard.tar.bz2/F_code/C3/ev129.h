
#ifndef _C3_ev129_
#define _C3_ev129_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F144_3318(EIF_REFERENCE);
extern void F144_3320(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit129(void);
extern void F679_5840(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
