/*
 * Code for class SHARED_TEMPLATE_CONTEXT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sh145.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SHARED_TEMPLATE_CONTEXT}.template_context */
static EIF_REFERENCE F160_3467_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3467);
#define Result RTOSR(3467)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(24, 0x01).id, 24, _OBJSIZ_6_1_0_0_0_0_0_0_);
	F25_697(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3467);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F160_3467 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3467,F160_3467_body,(Current));
}

/* {SHARED_TEMPLATE_CONTEXT}.template_custom_action_by_id */
EIF_REFERENCE F160_3468 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = RTOSCF(3467,F160_3467, (Current));
		Result = F25_717(RTCW(tr1), arg1);
	}
	RTLE;
	return Result;
}

/* {SHARED_TEMPLATE_CONTEXT}.is_valid_template_custom_action_id */
EIF_BOOLEAN F160_3469 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = RTOSCF(3467,F160_3467, (Current));
		tb1 = F25_720(RTCW(tr1), arg1);
		Result = tb1;
	}
	RTLE;
	return Result;
}

void EIF_Minit145 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
