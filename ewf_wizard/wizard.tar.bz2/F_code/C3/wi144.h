
#ifndef _C3_wi144_
#define _C3_wi144_

#ifdef __cplusplus
extern "C" {
#endif

extern void F159_3457(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F159_3466(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit144(void);
extern EIF_REFERENCE F932_7704(EIF_REFERENCE);
extern EIF_REFERENCE F1054_9418(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R6131[])();

#ifdef __cplusplus
}
#endif

#endif
