/*
 * Code for class WIZARD
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "wi114.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WIZARD}.make */
void F129_3062 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {WIZARD}.new_page */
EIF_REFERENCE F129_3066 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4699[Dtype(RTCW(tr1))-1143])(tr1, arg1);
	RTLE;
	return Result;
}

/* {WIZARD}.notfound_page */
static EIF_REFERENCE F129_3068_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (3068);
#define Result RTOSR(3068)
	RTOC_NEW(Result);
	tr1 = RTMS_EX_H("notfound",8,10334052);
	Result = F129_3066(Current, tr1);
	tr1 = RTMS_EX_H("Page Not Found",14,292060516);
	F857_6551(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("Internal error in the wizard state machine.",43,925323566);
	F857_6552(RTCW(Result), tr1);
	RTOSE (3068);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F129_3068 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3068,F129_3068_body,(Current));
}

/* {WIZARD}.formatted_title_value_items */
EIF_REFERENCE F129_3075 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,loc4);
	RTLR(5,loc1);
	RTLIU(6);
	
	RTGC;
	loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4759[Dtype(RTCW(arg1))-327])(arg1);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5449[Dtype(loc3)-720])(loc3);
		if (tb1) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5448[Dtype(loc3)-720])(loc3);
		tr1 = eif_boxed_item(tr1,1);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7528[Dtype(RTCW(tr1))-1049])(tr1);
		ti4_1 = eif_max_int32 (loc2,ti4_1);
		loc2 = (EIF_INTEGER_32) ti4_1;
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5450[Dtype(loc3)-720])(loc3);
	}
	loc2++;
	Result = RTLNS(eif_new_type(1050, 0x01).id, 1050, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1046_8989(RTCW(Result));
	loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4759[Dtype(RTCW(arg1))-327])(arg1);
	for (;;) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5449[Dtype(loc4)-720])(loc4);
		if (tb2) break;
		loc1 = RTLNS(eif_new_type(1050, 0x01).id, 1050, _OBJSIZ_1_1_0_3_0_0_0_0_);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5448[Dtype(loc4)-720])(loc4);
		tr1 = eif_boxed_item(tr1,1);
		F1051_9195(RTCW(loc1), tr1);
		tr1 = RTLNS(eif_new_type(1050, 0x01).id, 1050, _OBJSIZ_1_1_0_3_0_0_0_0_);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		F1049_9120(RTCW(tr1), tw1, (EIF_INTEGER_32) (loc2 - ti4_1));
		F1051_9234(RTCW(loc1), tr1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ':';
		F1051_9247(RTCW(loc1), tw1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
		F1051_9247(RTCW(loc1), tw1);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5448[Dtype(loc4)-720])(loc4);
		tr1 = eif_boxed_item(tr1,2);
		F1051_9233(RTCW(loc1), tr1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
		F1051_9247(RTCW(loc1), tw1);
		F1051_9234(RTCW(Result), loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5450[Dtype(loc4)-720])(loc4);
	}
	RTLE;
	return Result;
}

void EIF_Minit114 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
