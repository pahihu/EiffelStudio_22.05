/*
 * Code for class SYSTEM_ENCODINGS_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sy133.h"
#include "eif_langinfo.h"
#include <locale.h>
#include "string.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F148_3360
static EIF_POINTER inline_F148_3360 (void)
{
	return nl_langinfo (CODESET);
	;
}
#define INLINE_F148_3360
#endif
#ifndef INLINE_F148_3359
static int inline_F148_3359 (void)
{
	setlocale (LC_ALL, "");
return (EIF_BOOLEAN)(strcmp (nl_langinfo (CODESET), "UTF-8") == 0);
	;
}
#define INLINE_F148_3359
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SYSTEM_ENCODINGS_IMP}.system_code_page */
EIF_REFERENCE F148_3356 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	loc1 = inline_F148_3360();
	ti4_1 = (EIF_INTEGER_32) strlen((void *) loc1);
	Result = F147_3346(Current, loc1, ti4_1);
	RTLE;
	return Result;
}

/* {SYSTEM_ENCODINGS_IMP}.console_code_page */
EIF_REFERENCE F148_3357 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if (EIF_TEST (inline_F148_3359())) {
		Result = RTMS_EX_H("UTF-8",5,1414538040);
	} else {
		if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
			Result = RTMS_EX_H("UTF-8",5,1414538040);
		} else {
			Result = F148_3356(Current);
			RTLE;
			return (EIF_REFERENCE) Result;
		}
	}
	RTLE;
	return Result;
}

/* {SYSTEM_ENCODINGS_IMP}.is_utf8_activated */
EIF_BOOLEAN F148_3359 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = EIF_TEST(inline_F148_3359 ());
	return Result;
}

/* {SYSTEM_ENCODINGS_IMP}.c_current_codeset */
EIF_POINTER F148_3360 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F148_3360 ();
	return Result;
}

/* {SYSTEM_ENCODINGS_IMP}.c_strlen */
EIF_INTEGER_32 F148_3361 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) strlen((void *) arg1);
	
	return Result;
}

void EIF_Minit133 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
