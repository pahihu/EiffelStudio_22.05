
#ifndef _C3_th108_
#define _C3_th108_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F123_2987(EIF_REFERENCE);
extern void EIF_Minit108(void);

#ifdef __cplusplus
}
#endif

#endif
