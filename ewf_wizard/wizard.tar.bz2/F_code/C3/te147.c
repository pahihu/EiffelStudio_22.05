/*
 * Code for class TEMPLATE_COMMON
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "te147.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TEMPLATE_COMMON}.string_value */
EIF_REFERENCE F162_3477 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	struct eif_ex_49 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_new_type(51, 0x00).id);
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,loc2);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		loc2 = RTCCL(arg1);
		loc2 = RTRV(eif_new_type(1048, 0x01),loc2);
		if (EIF_TEST(loc2)) {
			tr1 = F52_1212(RTCW(loc1), loc2);
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R28[Dtype(RTCW(arg1))-5])(arg1);
			RTLE;
			return (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {TEMPLATE_COMMON}.resolved_variable_name */
EIF_REFERENCE F162_3478 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4992[Dtype(RTCW(arg1))-575])(arg1, ((EIF_INTEGER_32) 1L)));
	tb1 = tc1 == (EIF_CHARACTER_8) '$';
	if (tb1) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O7727[Dtype(arg1)-1051]);
		Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R7569[Dtype(RTCW(arg1))-1049])(arg1, ((EIF_INTEGER_32) 2L), ti4_1);
	} else {
		Result = F1_14(arg1);
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {TEMPLATE_COMMON}.resolved_formatted_variable */
EIF_REFERENCE F162_3479 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = RTOSCF(3467,F160_3467, (Current));
	loc2 = tr1;
	if ((EIF_TRUE)) {
		loc1 = F162_3478(Current, arg1);
		tr1 = *(EIF_REFERENCE *)(loc2);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R4952[Dtype(RTCW(tr1))-575])(tr1, loc1);
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(loc2);
			Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5135[Dtype(RTCW(tr1))-647])(tr1, loc1);
		} else {
			tr1 = F25_703(loc2);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R4952[Dtype(RTCW(tr1))-575])(tr1, loc1);
			if (tb1) {
				tr1 = F25_703(loc2);
				Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5135[Dtype(RTCW(tr1))-647])(tr1, loc1);
			}
		}
	}
	RTLE;
	return Result;
}

/* {TEMPLATE_COMMON}.resolved_nested_message */
EIF_REFERENCE F162_3480 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLR(5,Result);
	RTLR(6,loc2);
	RTLR(7,tr2);
	RTLR(8,loc3);
	RTLIU(9);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(3467,F160_3467, (Current))) + _REFACS_5_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,966,0,0xFF01,1053,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr1 = RTLNTS(typres0.id, 3, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = arg1;
			RTAR(tr1,arg1);
			((EIF_TYPED_VALUE *)tr1+2)->it_r = arg2;
			RTAR(tr1,arg2);
			Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R7483[Dtype(loc1)-1041])(loc1, tr1);
		}
	} else {
		tr1 = RTOSCF(3481,F162_3481, (Current));
		tr2 = RTCCL(arg1);
		tr1 = F263_4548(RTCW(tr1), tr2, arg2);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3693[Dtype(loc2)-183])(loc2);
		} else {
			tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(3467,F160_3467, (Current))) + _REFACS_5_);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,966,0xFF01,0,0xFF01,1053,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr1 = RTLNTS(typres0.id, 3, 0);
				}
				((EIF_TYPED_VALUE *)tr1+1)->it_r = arg1;
				RTAR(tr1,arg1);
				((EIF_TYPED_VALUE *)tr1+2)->it_r = arg2;
				RTAR(tr1,arg2);
				Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R7483[Dtype(loc3)-1041])(loc3, tr1);
			}
		}
	}
	RTLE;
	return Result;
}

/* {TEMPLATE_COMMON}.template_routines */
static EIF_REFERENCE F162_3481_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3481);
#define Result RTOSR(3481)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(262, 0x01).id, 262, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3481);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F162_3481 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3481,F162_3481_body,(Current));
}

void EIF_Minit147 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
