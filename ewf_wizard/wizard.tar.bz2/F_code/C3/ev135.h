
#ifndef _C3_ev135_
#define _C3_ev135_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F150_3370(EIF_REFERENCE);
extern EIF_POINTER F150_3371(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit135(void);

#ifdef __cplusplus
}
#endif

#endif
