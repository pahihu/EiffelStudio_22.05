/*
 * Code for class EWF_WIZARD_GENERATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew146.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EWF_WIZARD_GENERATOR}.execute */
void F161_3471 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(10);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,loc5);
	RTLR(5,loc2);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,loc3);
	RTLR(9,loc1);
	RTLIU(10);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	tb1 = '\0';
	tr1 = RTMS_EX_H("project:name",12,465008997);
	tr1 = F335_4994(RTCW(arg1), tr1);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		tr1 = RTMS_EX_H("project:location",16,399602286);
		tr1 = F335_4994(RTCW(arg1), tr1);
		loc5 = tr1;
		tb1 = EIF_TEST(loc5);
	}
	if (tb1) {
		loc2 = RTLNS(eif_new_type(931, 0x01).id, 931, _OBJSIZ_2_1_0_0_0_0_0_0_);
		F932_7666(RTCW(loc2), loc5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7550[Dtype(loc4)-1049])(loc4);
		tr3 = RTMS_EX_H("APP_NAME",8,949096517);
		F648_5639(RTCW(tr1), tr2, tr3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7551[Dtype(loc4)-1049])(loc4);
		tr3 = RTMS_EX_H("APP_ROOT",8,1017123412);
		F648_5639(RTCW(tr1), tr2, tr3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = F1046_9048(RTCV(F124_2996(Current)));
		tr3 = RTMS_EX_H("UUID",4,1431652676);
		F648_5639(RTCW(tr1), tr2, tr3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = F1046_9048(RTMS_EX_H("none",4,1852796517));
		tr3 = RTMS_EX_H("CONCURRENCY",11,802402649);
		F648_5639(RTCW(tr1), tr2, tr3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = F1046_9048(RTMS_EX_H("yes",3,7955827));
		tr3 = RTMS_EX_H("WIZ_YES",7,435358803);
		F648_5639(RTCW(tr1), tr2, tr3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = F1046_9048(RTMS_EX_H("no",2,28271));
		tr3 = RTMS_EX_H("WIZ_NO",6,1687805007);
		F648_5639(RTCW(tr1), tr2, tr3);
		loc3 = (EIF_REFERENCE) loc2;
		loc1 = RTLNS(eif_new_type(913, 0x01).id, 913, _OBJSIZ_3_0_0_1_0_2_0_0_);
		F914_6740(RTCW(loc1), loc3);
		tb1 = F914_6763(RTCW(loc1));
		if ((EIF_BOOLEAN) !tb1) {
			F914_6743(RTCW(loc1));
		}
		tr1 = *(EIF_REFERENCE *)(RTCV(F124_2992(Current)) + _REFACS_2_);
		tr1 = F306_4754(RTCW(tr1));
		F124_3001(Current, tr1, loc3);
		tr1 = RTLNS(eif_new_type(158, 0x01).id, 158, _OBJSIZ_2_2_0_0_0_0_0_0_);
		tr2 = F932_7693(RTCW(loc3), loc4);
		tr3 = RTMS_EX_H("ecf",3,6644582);
		tr2 = F932_7696(RTCW(tr2), tr3);
		tr3 = F914_6744(RTCW(loc1));
		F159_3457(RTCW(tr1), tr2, tr3);
		F124_2995(Current, tr1);
	} else {
		tr1 = RTLNS(eif_new_type(157, 0x01).id, 157, _OBJSIZ_0_0_0_0_0_0_0_0_);
		F124_2995(Current, tr1);
	}
	RTLE;
}

/* {EWF_WIZARD_GENERATOR}.smarty_template_extensions */
static EIF_REFERENCE F161_3472_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOSP (3472);
#define Result RTOSR(3472)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {834,0xFF01,1048,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 3L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F1046_9048(RTMS_EX_H("e",1,101));
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1046_9048(RTMS_EX_H("ecf",3,6644582));
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1046_9048(RTMS_EX_H("ini",3,6909545));
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F835_6413)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3472);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F161_3472 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3472,F161_3472_body,(Current));
}

/* {EWF_WIZARD_GENERATOR}.is_smarty_template_file */
EIF_BOOLEAN F161_3473 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,Current);
	RTLIU(5);
	
	RTGC;
	tr1 = F932_7683(RTCW(arg1));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		loc2 = F578_5358(RTCV(RTOSCF(3472,F161_3472, (Current))));
		tb1 = EIF_FALSE;
		for (;;) {
			if (tb1) break;
			tb2 = F779_6234(loc2);
			if (tb2) break;
			tr1 = F779_6225(loc2);
			tb3 = F1046_9031(RTCW(tr1), loc1);
			tb1 = tb3;
			F779_6240(loc2);
		}
		Result = (EIF_BOOLEAN) tb1;
	}
	RTLE;
	return Result;
}

/* {EWF_WIZARD_GENERATOR}.is_template_file */
EIF_BOOLEAN F161_3474 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F161_3473(Current, arg1);
}

/* {EWF_WIZARD_GENERATOR}.copy_template */
void F161_3475 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	if (F161_3473(Current, arg1)) {
		F161_3476(Current, arg1, arg2);
	} else {
		F124_3002(Current, arg1, arg2);
	}
	RTLE;
}

/* {EWF_WIZARD_GENERATOR}.copy_smarty_template */
void F161_3476 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(13);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc5);
	RTLR(5,Current);
	RTLR(6,loc6);
	RTLR(7,tr2);
	RTLR(8,loc4);
	RTLR(9,loc7);
	RTLR(10,loc8);
	RTLR(11,loc3);
	RTLR(12,arg2);
	RTLIU(13);
	
	RTGC;
	loc2 = RTLNS(eif_new_type(920, 0x01).id, 920, _OBJSIZ_5_7_2_4_1_1_2_1_);
	F921_7368(RTCW(loc2), arg1);
	tb1 = '\0';
	tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6118[Dtype(RTCW(loc2))-919])(loc2);
	if (tb2) {
		tb2 = F919_7124(RTCW(loc2));
		tb1 = tb2;
	}
	if (tb1) {
		loc1 = RTLNS(eif_new_type(163, 0x01).id, 163, _OBJSIZ_5_0_0_0_0_0_0_0_);
		tr1 = F919_7096(RTCW(loc2));
		tr1 = F932_7705(RTCW(tr1));
		F164_3516(RTCW(loc1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			tr1 = RTMS_EX_H("WIZ",3,5720410);
			F164_3520(RTCW(loc1), loc5, tr1);
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc6 = F648_5607(RTCW(tr1));
		for (;;) {
			tb1 = F773_6222(loc6);
			if (tb1) break;
			tr1 = F773_6219(loc6);
			tr2 = F773_6220(loc6);
			F164_3520(RTCW(loc1), tr1, tr2);
			F773_6223(loc6);
		}
		tr1 = RTOSCF(3467,F160_3467, (Current));
		tr2 = *(EIF_REFERENCE *)(RTCV(F124_2992(Current)) + _REFACS_2_);
		tr2 = F306_4756(RTCW(tr2));
		F25_709(RTCW(tr1), tr2);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,656,0xFF01,164,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc4 = RTLNS(typres0.id, 656, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F657_5723(RTCW(loc4), ((EIF_INTEGER_32) 2L));
		tr1 = RTLNS(eif_new_type(166, 0x01).id, 166, _OBJSIZ_0_0_0_0_0_0_0_0_);
		tr2 = RTLNTY2(eif_new_type(334, 0x00), 0x00);
		tr2 = F933_7727(tr2);
		F165_3533(RTCW(tr1), tr2);
		F657_5763(RTCW(loc4), tr1);
		tr1 = RTLNS(eif_new_type(165, 0x01).id, 165, _OBJSIZ_0_0_0_0_0_0_0_0_);
		tr2 = RTLNTY2(eif_new_type(831, 0x00), 0x00);
		tr2 = F933_7727(tr2);
		F165_3533(RTCW(tr1), tr2);
		F657_5763(RTCW(loc4), tr1);
		F164_3524(RTCW(loc1));
		F164_3532(RTCW(loc1));
		loc7 = F657_5737(RTCW(loc4));
		for (;;) {
			tb2 = F779_6234(loc7);
			if (tb2) break;
			tr1 = F779_6225(loc7);
			F165_3535(RTCW(tr1));
			F779_6240(loc7);
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_4_);
		loc8 = tr1;
		if (EIF_TEST(loc8)) {
			loc3 = RTLNS(eif_new_type(920, 0x01).id, 920, _OBJSIZ_5_7_2_4_1_1_2_1_);
			F921_7368(RTCW(loc3), arg2);
			tb3 = '\01';
			tb4 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6118[Dtype(RTCW(loc3))-919])(loc3);
			if (!(EIF_BOOLEAN) !tb4) {
				tb4 = F919_7125(RTCW(loc3));
				tb3 = tb4;
			}
			if (tb3) {
				F919_7160(RTCW(loc3));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6131[Dtype(RTCW(loc3))-919])(loc3, loc8);
				F919_7173(RTCW(loc3));
			}
		} else {
			F124_2997(Current, arg1, arg2);
		}
	}
	RTLE;
}

void EIF_Minit146 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
