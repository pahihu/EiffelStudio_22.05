/*
 * Code for class WIZARD_GENERATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "wi109.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WIZARD_GENERATOR}.make */
void F124_2989 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	F124_2990(Current);
	RTLE;
}

/* {WIZARD_GENERATOR}.initialize */
void F124_2990 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,653,0xFF01,1048,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F654_5704(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {WIZARD_GENERATOR}.application */
EIF_REFERENCE F124_2992 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = *(EIF_REFERENCE *)(RTCW(tr1));
	RTLE;
	return Result;
}

/* {WIZARD_GENERATOR}.send_response */
void F124_2995 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = F124_2992(Current);
	F310_4890(RTCW(tr1), arg1);
	RTLE;
}

/* {WIZARD_GENERATOR}.new_uuid */
EIF_REFERENCE F124_2996 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(25, 0x01).id, 25, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = F931_7656(RTCV(F26_727(RTCW(tr1))));
	RTLE;
	return Result;
}

/* {WIZARD_GENERATOR}.copy_file */
void F124_2997 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(919, 0x01).id, 919, _OBJSIZ_4_6_2_4_1_1_2_1_);
	F919_7087(RTCW(loc1), arg1);
	tb1 = '\0';
	tb2 = F919_7121(RTCW(loc1));
	if (tb2) {
		tb2 = F919_7124(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		loc2 = RTLNS(eif_new_type(919, 0x01).id, 919, _OBJSIZ_4_6_2_4_1_1_2_1_);
		F919_7087(RTCW(loc2), arg2);
		tb1 = '\01';
		tb2 = F919_7121(RTCW(loc2));
		if (!(EIF_BOOLEAN) !tb2) {
			tb2 = F919_7125(RTCW(loc2));
			tb1 = tb2;
		}
		if (tb1) {
			F919_7156(RTCW(loc1));
			F919_7157(RTCW(loc2));
			F919_7243(RTCW(loc1), loc2);
			F919_7173(RTCW(loc2));
			F919_7173(RTCW(loc1));
		}
	}
	RTLE;
}

/* {WIZARD_GENERATOR}.recursive_copy_templates */
void F124_3001 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,loc6);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,loc2);
	RTLR(8,loc5);
	RTLR(9,Current);
	RTLIU(10);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(913, 0x01).id, 913, _OBJSIZ_3_0_0_1_0_2_0_0_);
	F914_6740(RTCW(loc1), arg1);
	tb1 = '\0';
	tb2 = F914_6763(RTCW(loc1));
	if (tb2) {
		tb2 = F914_6764(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = RTLNS(eif_new_type(913, 0x01).id, 913, _OBJSIZ_3_0_0_1_0_2_0_0_);
		F914_6740(RTCW(tr1), arg2);
		F914_6743(RTCW(tr1));
		tr1 = F914_6754(RTCW(loc1));
		tr1 = F657_5737(RTCW(tr1));
		loc6 = (EIF_REFERENCE) tr1;
		for (;;) {
			tb1 = F779_6234(loc6);
			if (tb1) break;
			loc3 = F779_6225(loc6);
			tb2 = '\0';
			tb3 = F932_7672(RTCW(loc3));
			if ((EIF_BOOLEAN) !tb3) {
				tb3 = F932_7671(RTCW(loc3));
				tb2 = (EIF_BOOLEAN) !tb3;
			}
			if (tb2) {
				loc4 = F932_7694(RTCW(arg1), loc3);
				loc2 = RTLNS(eif_new_type(913, 0x01).id, 913, _OBJSIZ_3_0_0_1_0_2_0_0_);
				F914_6740(RTCW(loc2), loc4);
				tr1 = F124_3006(Current, loc3);
				loc5 = F932_7694(RTCW(arg2), tr1);
				tb2 = F914_6763(RTCW(loc2));
				if (tb2) {
					F124_3001(Current, loc4, loc5);
				} else {
					if (F161_3474(Current, loc4)) {
						F161_3475(Current, loc4, loc5);
					} else {
						F124_2997(Current, loc4, loc5);
					}
				}
			}
			F779_6240(loc6);
		}
	}
	RTLE;
}

/* {WIZARD_GENERATOR}.copy_template */
void F124_3002 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,arg2);
	RTLR(4,tr1);
	RTLR(5,Current);
	RTLIU(6);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(920, 0x01).id, 920, _OBJSIZ_5_7_2_4_1_1_2_1_);
	F921_7368(RTCW(loc1), arg1);
	tb1 = '\0';
	tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6118[Dtype(RTCW(loc1))-919])(loc1);
	if (tb2) {
		tb2 = F919_7124(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		loc2 = RTLNS(eif_new_type(920, 0x01).id, 920, _OBJSIZ_5_7_2_4_1_1_2_1_);
		F921_7368(RTCW(loc2), arg2);
		tb1 = '\01';
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6118[Dtype(RTCW(loc2))-919])(loc2);
		if (!(EIF_BOOLEAN) !tb2) {
			tb2 = F919_7125(RTCW(loc2));
			tb1 = tb2;
		}
		if (tb1) {
			F919_7156(RTCW(loc1));
			F919_7160(RTCW(loc2));
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R6177[Dtype(RTCW(loc1))-919])(loc1);
			for (;;) {
				tb1 = F372_5163(RTCW(loc1));
				if (tb1) break;
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
				tr1 = F124_3003(Current, tr1);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6131[Dtype(RTCW(loc2))-919])(loc2, tr1);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R6129[Dtype(RTCW(loc2))-919])(loc2);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R6177[Dtype(RTCW(loc1))-919])(loc1);
			}
			F919_7173(RTCW(loc2));
			F919_7173(RTCW(loc1));
		}
	}
	RTLE;
}

/* {WIZARD_GENERATOR}.resolved_string_8 */
EIF_REFERENCE F124_3003 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1053, 0x01).id, 1053, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O7727[Dtype(arg1)-1051]);
	F1052_9286(RTCW(loc1), ti4_1);
	F124_3004(Current, arg1, loc1);
	RTLE;
	return (EIF_REFERENCE) loc1;
}

/* {WIZARD_GENERATOR}.append_resolved_string_to */
void F124_3004 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,loc5);
	RTLR(4,loc6);
	RTLR(5,Current);
	RTLIU(6);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7528[Dtype(RTCW(arg1))-1049])(arg1);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = RTMS_EX_H("${",2,9339);
		loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R7539[Dtype(RTCW(arg1))-1049])(arg1, tr1, loc1);
		tb1 = '\0';
		if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L))) {
			tb2 = '\01';
			if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 1L))) {
				tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R7492[Dtype(RTCW(arg1))-1049])(arg1, (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L)));
				tw2 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '$';
				tb2 = (EIF_BOOLEAN)(tw1 != tw2);
			}
			tb1 = tb2;
		}
		if (tb1) {
			if ((EIF_BOOLEAN) (loc3 > loc1)) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R7569[Dtype(RTCW(arg1))-1049])(arg1, loc1, (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L)));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7599[Dtype(RTCW(arg2))-1050])(arg2, tr1);
			}
			loc1 = (EIF_INTEGER_32) loc3;
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '}';
			loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32)) R7493[Dtype(RTCW(arg1))-1049])(arg1, tw1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)));
			if ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 0L))) {
				loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R7569[Dtype(RTCW(arg1))-1049])(arg1, (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 2L)), (EIF_INTEGER_32) (loc4 - ((EIF_INTEGER_32) 1L)));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tr1 = F648_5598(RTCW(tr1), loc5);
				loc6 = tr1;
				if (EIF_TEST(loc6)) {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7550[Dtype(loc6)-1049])(loc6);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7599[Dtype(RTCW(arg2))-1050])(arg2, tr1);
				} else {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R7569[Dtype(RTCW(arg1))-1049])(arg1, loc3, loc4);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7599[Dtype(RTCW(arg2))-1050])(arg2, tr1);
				}
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L));
			} else {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R7569[Dtype(RTCW(arg1))-1049])(arg1, loc1, loc2);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7599[Dtype(RTCW(arg2))-1050])(arg2, tr1);
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
			}
		} else {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R7569[Dtype(RTCW(arg1))-1049])(arg1, loc1, loc2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7599[Dtype(RTCW(arg2))-1050])(arg2, tr1);
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
		}
	}
	RTLE;
}

/* {WIZARD_GENERATOR}.resolved_string */
EIF_REFERENCE F124_3005 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1050, 0x01).id, 1050, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O7647[Dtype(arg1)-1048]);
	F1049_9119(RTCW(loc1), ti4_1);
	F124_3004(Current, arg1, loc1);
	RTLE;
	return (EIF_REFERENCE) loc1;
}

/* {WIZARD_GENERATOR}.resolved_path_name */
EIF_REFERENCE F124_3006 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	loc1 = F932_7705(RTCW(arg1));
	loc2 = F124_3005(Current, loc1);
	tb1 = F1049_9146(RTCW(loc2), loc1);
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) arg1;
	} else {
		tr1 = RTLNS(eif_new_type(931, 0x01).id, 931, _OBJSIZ_2_1_0_0_0_0_0_0_);
		F932_7666(RTCW(tr1), loc2);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

void EIF_Minit109 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
