/*
 * Code for class ENCODING_HELPER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "en132.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ENCODING_HELPER}.multi_byte_to_pointer */
EIF_REFERENCE F147_3344 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(257, 0x01).id, 257, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F258_4328(RTCW(tr1), arg1);
	Result = *(EIF_REFERENCE *)(RTCW(tr1));
	RTLE;
	return Result;
}

/* {ENCODING_HELPER}.wide_string_to_pointer */
EIF_REFERENCE F147_3345 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_16 tu2_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O7647[Dtype(arg1)-1048]);
	Result = RTLNS(eif_new_type(914, 0x01).id, 914, _OBJSIZ_0_1_0_1_0_1_1_0_);
	F915_6797(RTCW(Result), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)) * ((EIF_INTEGER_32) 2L)));
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == loc2)) break;
		tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R7491[Dtype(RTCW(arg1))-1049])(arg1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
		tu2_1 = (EIF_NATURAL_16) tu4_1;
		F915_6829(RTCW(Result), tu2_1, (EIF_INTEGER_32) (loc1 * ((EIF_INTEGER_32) 2L)));
		loc1++;
	}
	F915_6829(RTCW(Result), (EIF_NATURAL_16) ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (loc1 * ((EIF_INTEGER_32) 2L)));
	RTLE;
	return Result;
}

/* {ENCODING_HELPER}.pointer_to_multi_byte */
EIF_REFERENCE F147_3346 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_8 tu1_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,loc2);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	loc2 = RTLNS(eif_new_type(914, 0x01).id, 914, _OBJSIZ_0_1_0_1_0_1_1_0_);
	F915_6800(RTCW(loc2), arg1, arg2);
	Result = RTLNS(eif_new_type(1053, 0x01).id, 1053, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1052_9286(RTCW(Result), arg2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 >= arg2)) break;
		tu1_1 = F915_6808(RTCW(loc2), loc1);
		tu4_1 = (EIF_NATURAL_32) tu1_1;
		F1048_9089(RTCW(Result), tu4_1);
		loc1++;
	}
	RTLE;
	return Result;
}

/* {ENCODING_HELPER}.pointer_to_wide_string */
EIF_REFERENCE F147_3347 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_16 tu2_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,loc2);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	loc2 = RTLNS(eif_new_type(914, 0x01).id, 914, _OBJSIZ_0_1_0_1_0_1_1_0_);
	F915_6800(RTCW(loc2), arg1, arg2);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L)) / ((EIF_INTEGER_32) 2L));
	Result = RTLNS(eif_new_type(1050, 0x01).id, 1050, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1049_9119(RTCW(Result), loc3);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 >= loc3)) break;
		if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 * ((EIF_INTEGER_32) 2L)) <= arg2)) {
			tu2_1 = F915_6809(RTCW(loc2), (EIF_INTEGER_32) (loc1 * ((EIF_INTEGER_32) 2L)));
			tu4_1 = (EIF_NATURAL_32) tu2_1;
			F1048_9089(RTCW(Result), tu4_1);
		}
		loc1++;
	}
	RTLE;
	return Result;
}

/* {ENCODING_HELPER}.pointer_to_string_32 */
EIF_REFERENCE F147_3348 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 tu4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,loc2);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	loc2 = RTLNS(eif_new_type(914, 0x01).id, 914, _OBJSIZ_0_1_0_1_0_1_1_0_);
	F915_6800(RTCW(loc2), arg1, arg2);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 / ((EIF_INTEGER_32) 4L));
	Result = RTLNS(eif_new_type(1050, 0x01).id, 1050, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1049_9119(RTCW(Result), loc3);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 >= loc3)) break;
		if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 * ((EIF_INTEGER_32) 4L)) <= arg2)) {
			tu4_1 = F915_6810(RTCW(loc2), (EIF_INTEGER_32) (loc1 * ((EIF_INTEGER_32) 4L)));
			F1048_9089(RTCW(Result), tu4_1);
		}
		loc1++;
	}
	RTLE;
	return Result;
}

/* {ENCODING_HELPER}.string_32_to_multi_byte */
EIF_REFERENCE F147_3349 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc2 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_NATURAL_32 tu4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L))) {
		Result = RTLNS(eif_new_type(1053, 0x01).id, 1053, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1052_9286(RTCW(Result), (EIF_INTEGER_32) (loc3 * ((EIF_INTEGER_32) 4L)));
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		loc4 = RTOSCF(3355,F147_3355, (Current));
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc3)) break;
			loc2 = F1051_9203(RTCW(arg1), loc1);
			if (loc4) {
				tu4_1 = eif_bit_and(loc2,(EIF_NATURAL_32) ((EIF_INTEGER_32) 255L));
				F1048_9089(RTCW(Result), tu4_1);
				tu4_1 = eif_bit_and(loc2,(EIF_NATURAL_32) ((EIF_INTEGER_32) 65280L));
				tu4_1 = eif_bit_shift_right(tu4_1,((EIF_INTEGER_32) 8L));
				F1048_9089(RTCW(Result), tu4_1);
				tu4_1 = eif_bit_and(loc2,(EIF_NATURAL_32) ((EIF_INTEGER_32) 16711680L));
				tu4_1 = eif_bit_shift_right(tu4_1,((EIF_INTEGER_32) 16L));
				F1048_9089(RTCW(Result), tu4_1);
				tu4_1 = eif_bit_and(loc2,(EIF_NATURAL_32) ((EIF_INTEGER_64) RTI64C(4278190080)));
				tu4_1 = eif_bit_shift_right(tu4_1,((EIF_INTEGER_32) 24L));
				F1048_9089(RTCW(Result), tu4_1);
			} else {
				tu4_1 = eif_bit_and(loc2,(EIF_NATURAL_32) ((EIF_INTEGER_64) RTI64C(4278190080)));
				tu4_1 = eif_bit_shift_right(tu4_1,((EIF_INTEGER_32) 24L));
				F1048_9089(RTCW(Result), tu4_1);
				tu4_1 = eif_bit_and(loc2,(EIF_NATURAL_32) ((EIF_INTEGER_32) 16711680L));
				tu4_1 = eif_bit_shift_right(tu4_1,((EIF_INTEGER_32) 16L));
				F1048_9089(RTCW(Result), tu4_1);
				tu4_1 = eif_bit_and(loc2,(EIF_NATURAL_32) ((EIF_INTEGER_32) 65280L));
				tu4_1 = eif_bit_shift_right(tu4_1,((EIF_INTEGER_32) 8L));
				F1048_9089(RTCW(Result), tu4_1);
				tu4_1 = eif_bit_and(loc2,(EIF_NATURAL_32) ((EIF_INTEGER_32) 255L));
				F1048_9089(RTCW(Result), tu4_1);
			}
			loc1++;
		}
	} else {
		Result = RTLNS(eif_new_type(1053, 0x01).id, 1053, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1046_8989(RTCW(Result));
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {ENCODING_HELPER}.string_16_to_stream */
EIF_REFERENCE F147_3351 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_8 tu1_1;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	loc1 = F147_3345(Current, arg1);
	Result = RTLNS(eif_new_type(1053, 0x01).id, 1053, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_0_1_0_0_);
	F1052_9286(RTCW(Result), ti4_1);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_0_1_0_0_);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 2L));
	for (;;) {
		if ((EIF_BOOLEAN)(loc2 == loc3)) break;
		tu1_1 = F915_6808(RTCW(loc1), loc2);
		tc1 = (EIF_CHARACTER_8) tu1_1;
		F1054_9412(RTCW(Result), tc1);
		loc2++;
	}
	RTLE;
	return Result;
}

/* {ENCODING_HELPER}.string_general_to_stream */
EIF_REFERENCE F147_3352 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R7503[Dtype(RTCW(arg1))-1049])(arg1);
	if (tb1) {
		tr1 = F1046_9042(RTCW(arg1));
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = F1046_9048(RTCW(arg1));
		Result = F147_3349(Current, tr1);
	}
	RTLE;
	return Result;
}

/* {ENCODING_HELPER}.string_32_switch_endian */
EIF_REFERENCE F147_3353 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_NATURAL_32 tu4_3;
	EIF_NATURAL_32 tu4_4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	loc3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	Result = RTLNS(eif_new_type(1050, 0x01).id, 1050, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1049_9119(RTCW(Result), loc3);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 > loc3)) break;
		loc1 = F1051_9203(RTCW(arg1), loc2);
		tu4_1 = eif_bit_and(loc1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 255L));
		tu4_1 = eif_bit_shift_left(tu4_1,((EIF_INTEGER_32) 24L));
		tu4_1 = eif_bit_and(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_64) RTI64C(4278190080)));
		tu4_2 = eif_bit_and(loc1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 65280L));
		tu4_2 = eif_bit_shift_left(tu4_2,((EIF_INTEGER_32) 8L));
		tu4_3 = eif_bit_and(loc1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 16711680L));
		tu4_3 = eif_bit_shift_right(tu4_3,((EIF_INTEGER_32) 8L));
		tu4_4 = eif_bit_and(loc1,(EIF_NATURAL_32) ((EIF_INTEGER_64) RTI64C(4278190080)));
		tu4_4 = eif_bit_shift_right(tu4_4,((EIF_INTEGER_32) 24L));
		tu4_4 = eif_bit_and(tu4_4,(EIF_NATURAL_32) ((EIF_INTEGER_32) 255L));
		F1048_9089(RTCW(Result), (EIF_NATURAL_32) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (tu4_1 + tu4_2) + tu4_3) + tu4_4));
		loc2++;
	}
	RTLE;
	return Result;
}

/* {ENCODING_HELPER}.string_16_switch_endian */
EIF_REFERENCE F147_3354 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	loc3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	Result = RTLNS(eif_new_type(1050, 0x01).id, 1050, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1049_9119(RTCW(Result), loc3);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 > loc3)) break;
		loc1 = F1051_9203(RTCW(arg1), loc2);
		tu4_1 = eif_bit_and(loc1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 255L));
		tu4_1 = eif_bit_shift_left(tu4_1,((EIF_INTEGER_32) 8L));
		tu4_1 = eif_bit_and(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 65280L));
		tu4_2 = eif_bit_and(loc1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 65280L));
		tu4_2 = eif_bit_shift_right(tu4_2,((EIF_INTEGER_32) 8L));
		tu4_2 = eif_bit_and(tu4_2,(EIF_NATURAL_32) ((EIF_INTEGER_32) 255L));
		F1048_9089(RTCW(Result), (EIF_NATURAL_32) (tu4_1 + tu4_2));
		loc2++;
	}
	RTLE;
	return Result;
}

/* {ENCODING_HELPER}.is_little_endian */
static EIF_BOOLEAN F147_3355_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	

	
	RTEV;
	RTOSP (3355);
#define Result RTOSR(3355)
	tr1 = RTLNS(eif_new_type(251, 0x01).id, 251, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = RTOSCF(4264,F252_4264, (RTCW(tr1)));
	RTOSE (3355);
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F147_3355 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3355,F147_3355_body,(Current));
}

void EIF_Minit132 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
