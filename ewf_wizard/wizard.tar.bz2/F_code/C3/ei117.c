/*
 * Code for class EIFFEL_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ei117.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EIFFEL_CONSTANTS}.ise_projects_env */

EIF_REFERENCE F132_3097 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (3097,RTMS_EX_H("ISE_PROJECTS",12,53375059));
}

/* {EIFFEL_CONSTANTS}.ise_user_files_env */

EIF_REFERENCE F132_3098 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (3098,RTMS_EX_H("ISE_USER_FILES",14,1880819283));
}

/* {EIFFEL_CONSTANTS}.two_digit_minimum_major_version */
static EIF_REFERENCE F132_3106_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3106);
#define Result RTOSR(3106)
	RTOC_NEW(Result);
	ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_16) 22U);
	Result = F132_3108(Current, ti4_1);
	RTOSE (3106);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F132_3106 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3106,F132_3106_body,(Current));
}

/* {EIFFEL_CONSTANTS}.two_digit_minimum_minor_version */
static EIF_REFERENCE F132_3107_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3107);
#define Result RTOSR(3107)
	RTOC_NEW(Result);
	ti4_1 = (EIF_INTEGER_32) ((EIF_NATURAL_16) 5U);
	Result = F132_3108(Current, ti4_1);
	RTOSE (3107);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F132_3107 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3107,F132_3107_body,(Current));
}

/* {EIFFEL_CONSTANTS}.two_digit_minimum_string */
EIF_REFERENCE F132_3108 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	RTGC;
	Result = RTLNS(eif_new_type(1053, 0x01).id, 1053, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1052_9286(RTCW(Result), ((EIF_INTEGER_32) 2L));
	if ((EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 10L))) {
		F1054_9412(RTCW(Result), (EIF_CHARACTER_8) '0');
	}
	F1054_9402(RTCW(Result), arg1);
	RTLE;
	return Result;
}

void EIF_Minit117 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
