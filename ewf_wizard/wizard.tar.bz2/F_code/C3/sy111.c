/*
 * Code for class SYSTEM_ENCODINGS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sy111.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SYSTEM_ENCODINGS}.console_encoding */
static EIF_REFERENCE F126_3013_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (3013);
#define Result RTOSR(3013)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(37, 0x01).id, 37, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr2 = F148_3357(RTCV(RTOSCF(3018,F126_3018, (Current))));
	F38_952(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3013);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F126_3013 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3013,F126_3013_body,(Current));
}

/* {SYSTEM_ENCODINGS}.utf8 */
static EIF_REFERENCE F126_3014_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (3014);
#define Result RTOSR(3014)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(37, 0x01).id, 37, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr2 = RTOSCF(945,F37_945, (Current));
	F38_952(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3014);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F126_3014 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3014,F126_3014_body,(Current));
}

/* {SYSTEM_ENCODINGS}.utf32 */
static EIF_REFERENCE F126_3016_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (3016);
#define Result RTOSR(3016)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(37, 0x01).id, 37, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr2 = RTOSCF(947,F37_947, (Current));
	F38_952(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3016);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F126_3016 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3016,F126_3016_body,(Current));
}

/* {SYSTEM_ENCODINGS}.system_encodings_i */
static EIF_REFERENCE F126_3018_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3018);
#define Result RTOSR(3018)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(147, 0x01).id, 147, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3018);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F126_3018 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3018,F126_3018_body,(Current));
}

void EIF_Minit111 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
