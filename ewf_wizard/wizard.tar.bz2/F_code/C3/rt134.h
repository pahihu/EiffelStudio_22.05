
#ifndef _C3_rt134_
#define _C3_rt134_

#ifdef __cplusplus
extern "C" {
#endif

extern void F149_3363(EIF_REFERENCE);
extern void F149_3364(EIF_REFERENCE, EIF_BOOLEAN);
extern EIF_BOOLEAN F149_3365(EIF_REFERENCE);
extern void EIF_Minit134(void);

#ifdef __cplusplus
}
#endif

#endif
