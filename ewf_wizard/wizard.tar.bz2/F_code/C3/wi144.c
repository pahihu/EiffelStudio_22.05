/*
 * Code for class WIZARD_SUCCEED_RESPONSE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "wi144.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WIZARD_SUCCEED_RESPONSE}.make */
void F159_3457 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg2;
	RTLE;
}

/* {WIZARD_SUCCEED_RESPONSE}.send */
void F159_3466 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTMS_EX_H("Success=\"yes\"\012",14,188627466);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6131[Dtype(RTCW(arg1))-919])(arg1, tr1);
	tr1 = RTMS_EX_H("Ace=\"",5,1668078370);
	tr2 = *(EIF_REFERENCE *)(Current);
	tr2 = F932_7704(RTCW(tr2));
	tr1 = F1054_9418(tr1, tr2);
	tr2 = RTMS_EX_H("\"\012",2,8714);
	tr1 = F1054_9418(RTCW(tr1), tr2);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6131[Dtype(RTCW(arg1))-919])(arg1, tr1);
	tr1 = RTMS_EX_H("Directory=\"",11,1819936290);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr2 = F932_7704(RTCW(tr2));
	tr1 = F1054_9418(tr1, tr2);
	tr2 = RTMS_EX_H("\"\012",2,8714);
	tr1 = F1054_9418(RTCW(tr1), tr2);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6131[Dtype(RTCW(arg1))-919])(arg1, tr1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_)) {
		tr1 = RTMS_EX_H("Compilation=\"yes\"\012",18,1959124490);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6131[Dtype(RTCW(arg1))-919])(arg1, tr1);
	} else {
		tr1 = RTMS_EX_H("Compilation=\"no\"\012",17,931032330);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6131[Dtype(RTCW(arg1))-919])(arg1, tr1);
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
		tr1 = RTMS_EX_H("Compilation_type=\"freeze\"\012",26,224369418);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6131[Dtype(RTCW(arg1))-919])(arg1, tr1);
	} else {
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_)) {
			tr1 = RTMS_EX_H("Compilation_type=\"melt\"\012",24,844802570);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6131[Dtype(RTCW(arg1))-919])(arg1, tr1);
		}
	}
	RTLE;
}

void EIF_Minit144 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
