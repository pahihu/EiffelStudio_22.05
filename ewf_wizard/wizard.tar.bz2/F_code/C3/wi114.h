
#ifndef _C3_wi114_
#define _C3_wi114_

#ifdef __cplusplus
extern "C" {
#endif

extern void F129_3062(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F129_3066(EIF_REFERENCE, EIF_REFERENCE);
RTOSHF (EIF_REFERENCE,3068)
static EIF_REFERENCE F129_3068_body(EIF_REFERENCE);
extern EIF_REFERENCE F129_3068(EIF_REFERENCE);
extern EIF_REFERENCE F129_3075(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit114(void);
extern void F1051_9247(EIF_REFERENCE, EIF_CHARACTER_32);
extern void F1051_9233(EIF_REFERENCE, EIF_REFERENCE);
extern void F857_6552(EIF_REFERENCE, EIF_REFERENCE);
extern void F1051_9234(EIF_REFERENCE, EIF_REFERENCE);
extern void F1046_8989(EIF_REFERENCE);
extern void F1051_9195(EIF_REFERENCE, EIF_REFERENCE);
extern void F1049_9120(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern void F857_6551(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5448[])();
extern char *(*R5449[])();
extern char *(*R4759[])();
extern char *(*R5450[])();
extern char *(*R4699[])();
extern char *(*R7528[])();

#ifdef __cplusplus
}
#endif

#endif
