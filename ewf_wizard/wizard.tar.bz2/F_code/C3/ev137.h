
#ifndef _C3_ev137_
#define _C3_ev137_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F152_3380(EIF_REFERENCE);
extern EIF_REFERENCE F152_3383(EIF_REFERENCE);
static EIF_REFERENCE F152_3384_body(EIF_REFERENCE);
extern EIF_REFERENCE F152_3384(EIF_REFERENCE);
extern EIF_REFERENCE F152_3385(EIF_REFERENCE);
extern EIF_REFERENCE F152_3397(EIF_REFERENCE);
extern void EIF_Minit137(void);
extern void F1267_12212(EIF_REFERENCE, EIF_REFERENCE);
extern void F679_5840(EIF_REFERENCE);
extern long O3358[];
extern long O3361[];
extern long O3363[];
extern long O3375[];

#ifdef __cplusplus
}
#endif

#endif
