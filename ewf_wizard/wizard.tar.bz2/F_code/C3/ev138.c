/*
 * Code for class EV_SHARED_TRANSPORT_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev138.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_SHARED_TRANSPORT_I}.default_accept_cursor */
static EIF_REFERENCE F153_3413_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3413);
#define Result RTOSR(3413)
	RTOC_NEW(Result);
	Result = RTOSCF(1012,F42_1012, (RTCV(RTOSCF(3417,F153_3417, (Current)))));
	RTOSE (3413);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F153_3413 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3413,F153_3413_body,(Current));
}

/* {EV_SHARED_TRANSPORT_I}.default_deny_cursor */
static EIF_REFERENCE F153_3414_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3414);
#define Result RTOSR(3414)
	RTOC_NEW(Result);
	Result = RTOSCF(1016,F42_1016, (RTCV(RTOSCF(3417,F153_3417, (Current)))));
	RTOSE (3414);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F153_3414 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3414,F153_3414_body,(Current));
}

/* {EV_SHARED_TRANSPORT_I}.default_pixmaps */
static EIF_REFERENCE F153_3417_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3417);
#define Result RTOSR(3417)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(41, 0x01).id, 41, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3417);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F153_3417 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3417,F153_3417_body,(Current));
}

/* {EV_SHARED_TRANSPORT_I}.insert_label */
static EIF_REFERENCE F153_3423_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,loc1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (3423);
#define Result RTOSR(3423)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1135, 0x01).id, 1135, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1083_9566(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	F1127_10217(RTCW(Result), ((EIF_INTEGER_32) 10L), ((EIF_INTEGER_32) 10L));
	loc1 = RTLNS(eif_new_type(1151, 0x01).id, 1151, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1083_9566(RTCW(loc1));
	F1152_10554(RTCW(loc1), ((EIF_INTEGER_32) 2L), ((EIF_INTEGER_32) 2L));
	tr1 = RTLNS(eif_new_type(39, 0x01).id, 39, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = F40_998(RTCW(tr1));
	F1101_9879(RTCW(loc1), tr1);
	F1115_9997(RTCW(loc1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	F1115_9997(RTCW(loc1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 1L));
	tr1 = RTLNS(eif_new_type(39, 0x01).id, 39, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = RTOSCF(975,F40_975, (RTCW(tr1)));
	F1101_9879(RTCW(loc1), tr1);
	F1115_9997(RTCW(loc1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L));
	F1115_9997(RTCW(loc1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 0L));
	F1108_9937(RTCW(Result), loc1);
	RTOSE (3423);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F153_3423 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3423,F153_3423_body,(Current));
}

/* {EV_SHARED_TRANSPORT_I}.insert_label_imp */
static EIF_REFERENCE F153_3424_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (3424);
#define Result RTOSR(3424)
	RTOC_NEW(Result);
	tr1 = RTOSCF(3423,F153_3423, (Current));
	Result = *(EIF_REFERENCE *)(RTCW(tr1) + O7891[Dtype(tr1)-1082]);
	RTOSE (3424);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F153_3424 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3424,F153_3424_body,(Current));
}

/* {EV_SHARED_TRANSPORT_I}.remove_insert_label */
void F153_3425 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	tr1 = F1127_10191(RTCV(RTOSCF(3423,F153_3423, (Current))));
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		loc1 = F1127_10191(RTCV(RTOSCF(3423,F153_3423, (Current))));
		loc1 = RTRV(eif_new_type(1135, 0x00), loc1);
		tr1 = RTOSCF(3423,F153_3423, (Current));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8401[Dtype(loc5)-1132])(loc5, tr1);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tr1 = RTOSCF(3423,F153_3423, (Current));
			tb2 = (EIF_BOOLEAN) eif_builtin_ANY_same_type__o_b (loc1, tr1);
			tb1 = tb2;
		}
		if (tb1) {
			loc2 = F1127_10191(RTCW(loc1));
			loc2 = RTRV(eif_new_type(1131, 0x00), loc2);
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				loc3 = F1125_10142(RTCW(loc2), loc1, ((EIF_INTEGER_32) 1L));
				loc4 = F1132_10295(RTCW(loc2), loc1);
				F1125_10165(RTCW(loc2), loc1);
				F1125_10151(RTCW(loc2), loc3);
				F1125_10160(RTCW(loc2), loc1);
				if ((EIF_BOOLEAN) !loc4) {
					F1132_10302(RTCW(loc2), loc1);
				}
			}
		}
	}
	RTLE;
}

/* {EV_SHARED_TRANSPORT_I}.insert_sep */
static EIF_REFERENCE F153_3426_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3426);
#define Result RTOSR(3426)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1166, 0x01).id, 1166, _OBJSIZ_6_0_0_1_0_0_0_0_);
	F1083_9566(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3426);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F153_3426 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3426,F153_3426_body,(Current));
}

/* {EV_SHARED_TRANSPORT_I}.remove_insert_sep */
void F153_3428 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1166_10701(RTCV(RTOSCF(3426,F153_3426, (Current))));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = RTOSCF(3426,F153_3426, (Current));
		F1125_10165(loc1, tr1);
	}
	RTLE;
}

/* {EV_SHARED_TRANSPORT_I}.internal_screen */
static EIF_REFERENCE F153_3430_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3430);
#define Result RTOSR(3430)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1116, 0x01).id, 1116, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1083_9566(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3430);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F153_3430 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3430,F153_3430_body,(Current));
}

void EIF_Minit138 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
