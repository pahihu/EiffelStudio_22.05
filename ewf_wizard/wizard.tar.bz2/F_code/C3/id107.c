/*
 * Code for class IDENTIFIED_ROUTINES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "id107.h"
#include "eif_object_id.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {IDENTIFIED_ROUTINES}.eif_id_object */
EIF_REFERENCE F122_2982 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	Result = (EIF_REFERENCE) eif_id_object(arg1);
	
	RTLE;
	return Result;
}

/* {IDENTIFIED_ROUTINES}.eif_object_id */
EIF_INTEGER_32 F122_2983 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,arg1);
	RTLIU(1);
	
	{
		EIF_OBJECT larg1 = &arg1;Result = (EIF_INTEGER_32) eif_object_id(larg1);
		
	}
	RTLE;
	return Result;
}

/* {IDENTIFIED_ROUTINES}.eif_current_object_id */
EIF_INTEGER_32 F122_2984 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) eif_builtin_IDENTIFIED_ROUTINES_eif_current_object_id__i4 (Current);
	return Result;
}

/* {IDENTIFIED_ROUTINES}.eif_object_id_free */
void F122_2986 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	eif_object_id_free(arg1);
	
}

void EIF_Minit107 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
