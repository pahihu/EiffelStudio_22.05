/*
 * Code for class EWF_WIZARD
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew115.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EWF_WIZARD}.title */

EIF_REFERENCE F130_3076 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (3076,RTMS32_EX_H("W\000\000\000e\000\000\000b\000\000\000 \000\000\000A\000\000\000p\000\000\000p\000\000\000l\000\000\000i\000\000\000c\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000 \000\000\000W\000\000\000i\000\000\000z\000\000\000a\000\000\000r\000\000\000d\000\000\000",22,1878524516));
}

/* {EWF_WIZARD}.default_project_name */

EIF_REFERENCE F130_3077 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (3077,RTMS32_EX_H("n\000\000\000e\000\000\000w\000\000\000_\000\000\000a\000\000\000p\000\000\000p\000\000\000",7,1330047088));
}

/* {EWF_WIZARD}.wizard_generator */
EIF_REFERENCE F130_3078 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(160, 0x01).id, 160, _OBJSIZ_3_0_0_0_0_0_0_0_);
	F124_2989(RTCW(tr1), Current);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {EWF_WIZARD}.first_page */
static EIF_REFERENCE F130_3079_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (3079);
#define Result RTOSR(3079)
	RTOC_NEW(Result);
	tr1 = RTMS_EX_H("first",5,1769891700);
	Result = F129_3066(Current, tr1);
	tr1 = RTMS_EX_H("Web Application Wizard",22,1878524516);
	F857_6551(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("Based on the EiffelWeb framework...",35,883111470);
	F857_6552(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("Create Web server application with EiffelWeb (Framework).",57,307129390);
	F857_6556(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("\011\011\012Using the EiffelWeb Framework (EWF), build server application for any platforms.\012Depending on the connector(s), there are dependencies on third-party httpd server.\012(For instance libfcgi requires to setup apache, ...)\012\012More information at:\012  - http://www.eiffelweb.org/\012  - https://www.eiffel.org/projects/eiffel-web .\012",321,1606642954);
	F857_6557(RTCW(Result), tr1);
	RTOSE (3079);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F130_3079 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3079,F130_3079_body,(Current));
}

/* {EWF_WIZARD}.project_page */
static EIF_REFERENCE F130_3080_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	RTCFDD;
	RTLD;
	
	dftype = Dftype(Current);

	RTLI(8);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,loc2);
	RTLR(6,tr4);
	RTLR(7,tr5);
	RTLIU(8);
	
	RTEV;
	RTGC;
	RTOSP (3080);
#define Result RTOSR(3080)
	RTOC_NEW(Result);
	tr1 = RTMS_EX_H("project",7,399506036);
	Result = F129_3066(Current, tr1);
	tr1 = RTMS_EX_H("Project Name and Project Location",33,2003041390);
	F857_6551(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("You can choose the name of the project and\012the directory where the project will be generated.",93,1036771374);
	F857_6552(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("Please fill in:\012\011The name of the project (without space).\012\011The directory where you want the eiffel classes to be generated.",123,1372568622);
	F857_6557(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("Project name:",13,853875770);
	tr2 = RTMS_EX_H("name",4,1851878757);
	tr3 = RTMS_EX_H("ASCII name, without space",25,481648485);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5813[Dtype(RTCW(Result))-857])(Result, tr1, tr2, tr3);
	F857_6555(RTCW(Result), loc1);
	tr1 = RTMS_EX_H("Project location:",17,271127098);
	tr2 = RTMS_EX_H("location",8,59511406);
	tr3 = RTMS_EX_H("Valid directory path, it will be created if missing",51,1461816167);
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5814[Dtype(RTCW(Result))-857])(Result, tr1, tr2, tr3);
	F857_6555(RTCW(Result), loc2);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_4_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,966,0xFF01,0,0xFF01,278,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	((EIF_TYPED_VALUE *)tr2+2)->it_r = loc2;
	RTAR(tr2,loc2);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,279,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A115_53_2, (EIF_POINTER) _A115_53_2, (EIF_POINTER)(0),tr2, 1, 1);
	}
	F672_5806(RTCW(tr1), tr5);
	tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_8_);
	tr2 = RTOSCF(3077,F130_3077, (Current));
	tr3 = RTMS_EX_H("name",4,1851878757);
	F832_6342(RTCW(tr1), tr2, tr3);
	tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_8_);
	tr2 = *(EIF_REFERENCE *)(Current);
	tr3 = RTOSCF(3077,F130_3077, (Current));
	tr4 = *(EIF_REFERENCE *)(Current);
	tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + _REFACS_2_);
	tr4 = F306_4760(RTCW(tr4));
	tr5 = RTMS_EX_H("eiffelweb",9,1358820450);
	tr4 = F932_7693(RTCW(tr4), tr5);
	tr2 = F310_4874(RTCW(tr2), tr3, tr4);
	tr2 = F932_7705(RTCW(tr2));
	tr3 = RTMS_EX_H("location",8,59511406);
	F832_6342(RTCW(tr1), tr2, tr3);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,966,0xFF01,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr1 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
	RTAR(tr1,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1040,0xFF01,0xFFF9,1,966,0xFF01,856,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A115_54_2, (EIF_POINTER) _A115_54_2, (EIF_POINTER)(0),tr1, 1, 1);
	}
	F857_6554(RTCW(Result), tr4);
	RTOSE (3080);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F130_3080 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3080,F130_3080_body,(Current));
}

/* {EWF_WIZARD}.connectors_page */
static EIF_REFERENCE F130_3081_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOSP (3081);
#define Result RTOSR(3081)
	RTOC_NEW(Result);
	tr1 = RTMS_EX_H("connectors",10,2017083251);
	Result = F129_3066(Current, tr1);
	tr1 = RTMS_EX_H("Connectors selection",20,1782516334);
	F857_6551(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("You can choose one or multiple connectors\012to use as the same time.",66,815452206);
	F857_6552(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("Web application runs on top of connectors \012(i.e layer handling httpd incoming connections)\012\012Select connectors you want to support:",130,740400698);
	F857_6557(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("Standalone",10,1098627941);
	tr2 = RTMS_EX_H("use_standalone",14,413839717);
	tr3 = RTMS_EX_H("Using the standalone Eiffel Web server",38,1567221874);
	F857_6561(RTCW(Result), tr1, tr2, tr3);
	tr1 = RTMS_EX_H("CGI",3,4409161);
	tr2 = RTMS_EX_H("use_cgi",7,585818473);
	tr3 = RTMS_EX_H("Require to setup associated httpd server",40,443749746);
	F857_6561(RTCW(Result), tr1, tr2, tr3);
	tr1 = RTMS_EX_H("libFCGI",7,2057189961);
	tr2 = RTMS_EX_H("use_libfcgi",11,2072232553);
	tr3 = RTMS_EX_H("Require to setup associated httpd server, and have libfcgi dynamic libraries in the path",88,2132189800);
	F857_6561(RTCW(Result), tr1, tr2, tr3);
	tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_8_);
	tr2 = F1046_9048(RTMS_EX_H("yes",3,7955827));
	tr3 = RTMS_EX_H("use_standalone",14,413839717);
	F832_6342(RTCW(tr1), tr2, tr3);
	tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_8_);
	tr2 = F1046_9048(RTMS_EX_H("yes",3,7955827));
	tr3 = RTMS_EX_H("use_cgi",7,585818473);
	F832_6342(RTCW(tr1), tr2, tr3);
	tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_8_);
	tr2 = F1046_9048(RTMS_EX_H("yes",3,7955827));
	tr3 = RTMS_EX_H("use_libfcgi",11,2072232553);
	F832_6342(RTCW(tr1), tr2, tr3);
	RTOSE (3081);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F130_3081 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3081,F130_3081_body,(Current));
}

/* {EWF_WIZARD}.standalone_connector_page */
static EIF_REFERENCE F130_3082_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOSP (3082);
#define Result RTOSR(3082)
	RTOC_NEW(Result);
	tr1 = RTMS_EX_H("standalone_connector",20,694704498);
	Result = F129_3066(Current, tr1);
	tr1 = RTMS_EX_H("Standalone connector",20,933458290);
	F857_6551(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("Set options .",13,1389099822);
	F857_6552(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("Port number",11,702010226);
	tr2 = RTMS_EX_H("port",4,1886351988);
	tr3 = RTMS_EX_H("If port 8080 is already taken, then choose another one.",55,1448570158);
	F857_6562(RTCW(Result), tr1, tr2, tr3);
	tr1 = RTMS_EX_H("Verbose",7,39062117);
	tr2 = RTMS_EX_H("verbose",7,1112830821);
	tr3 = RTMS_EX_H("Verbose output",14,922830964);
	F857_6561(RTCW(Result), tr1, tr2, tr3);
	tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_8_);
	tr2 = F1046_9048(RTMS_EX_H("8080",4,942684208));
	tr3 = RTMS_EX_H("port",4,1886351988);
	F832_6342(RTCW(tr1), tr2, tr3);
	tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_8_);
	tr2 = F1046_9048(RTMS_EX_H("no",2,28271));
	tr3 = RTMS_EX_H("verbose",7,1112830821);
	F832_6342(RTCW(tr1), tr2, tr3);
	RTOSE (3082);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F130_3082 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3082,F130_3082_body,(Current));
}

/* {EWF_WIZARD}.routers_page */
static EIF_REFERENCE F130_3083_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOSP (3083);
#define Result RTOSR(3083)
	RTOC_NEW(Result);
	tr1 = RTMS_EX_H("routers",7,1568062835);
	Result = F129_3066(Current, tr1);
	tr1 = RTMS_EX_H("Use Router (URL dispatching)",28,761014825);
	F857_6551(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("Use the router component to easily map url patterns to handlers.",64,78661934);
	F857_6552(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("Use the router component to easily map URL patterns to handlers:",64,1554334266);
	F857_6557(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("use the router component",24,450045812);
	tr2 = RTMS_EX_H("use_router",10,247347826);
	tr3 = RTMS_EX_H("Check generated code to see how to configure it.",48,1315777326);
	F857_6561(RTCW(Result), tr1, tr2, tr3);
	tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_8_);
	tr2 = F1046_9048(RTMS_EX_H("yes",3,7955827));
	tr3 = RTMS_EX_H("use_router",10,247347826);
	F832_6342(RTCW(tr1), tr2, tr3);
	RTOSE (3083);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F130_3083 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3083,F130_3083_body,(Current));
}

/* {EWF_WIZARD}.filters_page */
static EIF_REFERENCE F130_3084_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOSP (3084);
#define Result RTOSR(3084)
	RTOC_NEW(Result);
	tr1 = RTMS_EX_H("filters",7,1958838899);
	Result = F129_3066(Current, tr1);
	tr1 = RTMS_EX_H("Use Filter (chain filter)",25,201408297);
	F857_6551(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("Use the filter component.",25,1991721518);
	F857_6552(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("Use the filter component:",25,1991721530);
	F857_6557(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("use the filter component",24,835477108);
	tr2 = RTMS_EX_H("use_filter",10,72713842);
	tr3 = RTMS_EX_H("Check generated code to see how to configure it.",48,1315777326);
	F857_6561(RTCW(Result), tr1, tr2, tr3);
	tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_8_);
	tr2 = F1046_9048(RTMS_EX_H("yes",3,7955827));
	tr3 = RTMS_EX_H("use_filter",10,72713842);
	F832_6342(RTCW(tr1), tr2, tr3);
	RTOSE (3084);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F130_3084 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3084,F130_3084_body,(Current));
}

/* {EWF_WIZARD}.final_page */
static EIF_REFERENCE F130_3085_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDD;
	RTLD;
	
	dftype = Dftype(Current);

	RTLI(6);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTEV;
	RTGC;
	RTOSP (3085);
#define Result RTOSR(3085)
	RTOC_NEW(Result);
	tr1 = RTMS_EX_H("final",5,1769624940);
	Result = F129_3066(Current, tr1);
	tr1 = RTMS_EX_H("Completing the New Web Application Wizard",41,1034220900);
	F857_6551(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("You have specified the following settings:\012\012",44,412579594);
	F857_6557(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("...",3,3026478);
	loc1 = F857_6567(RTCW(Result), tr1);
	F857_6555(RTCW(Result), loc1);
	tr1 = RTMS_EX_H("...",3,3026478);
	loc2 = F857_6567(RTCW(Result), tr1);
	F857_6555(RTCW(Result), loc2);
	tr1 = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_5_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,4,966,0xFF01,0,0xFF01,856,0xFF01,268,0xFF01,268,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 5, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	((EIF_TYPED_VALUE *)tr2+2)->it_r = Result;
	RTAR(tr2,Result);
	((EIF_TYPED_VALUE *)tr2+3)->it_r = loc1;
	RTAR(tr2,loc1);
	((EIF_TYPED_VALUE *)tr2+4)->it_r = loc2;
	RTAR(tr2,loc2);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1040,0xFF01,0xFFF9,0,966,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A115_52, (EIF_POINTER) _A115_52, (EIF_POINTER)(0),tr2, 1, 0);
	}
	F672_5806(RTCW(tr1), tr3);
	RTOSE (3085);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F130_3085 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3085,F130_3085_body,(Current));
}

/* {EWF_WIZARD}.next_page */
EIF_REFERENCE F130_3086 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	Result = RTOSCF(3068,F129_3068, (Current));
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		Result = RTOSCF(3079,F130_3079, (Current));
		RTLE;
		return (EIF_REFERENCE) Result;
	} else {
		if ((EIF_BOOLEAN)(arg1 == RTOSCF(3079,F130_3079, (Current)))) {
			Result = RTOSCF(3080,F130_3080, (Current));
		} else {
			if ((EIF_BOOLEAN)(arg1 == RTOSCF(3080,F130_3080, (Current)))) {
				Result = RTOSCF(3081,F130_3081, (Current));
			} else {
				if ((EIF_BOOLEAN)(arg1 == RTOSCF(3081,F130_3081, (Current)))) {
					tr1 = RTOSCF(3081,F130_3081, (Current));
					tr2 = RTMS_EX_H("use_standalone",14,413839717);
					tb1 = F857_6544(RTCW(tr1), tr2);
					if (tb1) {
						Result = RTOSCF(3082,F130_3082, (Current));
					} else {
						Result = RTOSCF(3083,F130_3083, (Current));
					}
				} else {
					if ((EIF_BOOLEAN)(arg1 == RTOSCF(3082,F130_3082, (Current)))) {
						Result = RTOSCF(3083,F130_3083, (Current));
					} else {
						if ((EIF_BOOLEAN)(arg1 == RTOSCF(3083,F130_3083, (Current)))) {
							Result = RTOSCF(3084,F130_3084, (Current));
						} else {
							if ((EIF_BOOLEAN)(arg1 == RTOSCF(3084,F130_3084, (Current)))) {
								Result = RTOSCF(3085,F130_3085, (Current));
								RTLE;
								return (EIF_REFERENCE) Result;
							}
						}
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {EWF_WIZARD}.inline-agent#1 of final_page */
void F130_14737 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc4);
	RTLR(6,arg2);
	RTLR(7,loc1);
	RTLR(8,arg3);
	RTLIU(9);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,656,0xFF01,0xFFF9,2,966,0xFF01,1045,0xFF01,1045,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc2 = RTLNS(typres0.id, 656, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F657_5723(RTCW(loc2), ((EIF_INTEGER_32) 10L));
	tr1 = RTOSCF(3080,F130_3080, (Current));
	tr2 = RTMS_EX_H("name",4,1851878757);
	tr1 = F857_6543(RTCW(tr1), tr2);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,966,0xFF01,1053,0xFF01,1048,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		tr2 = RTMS_EX_H("Project name",12,1823660133);
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		((EIF_TYPED_VALUE *)tr1+2)->it_r = loc3;
		RTAR(tr1,loc3);
		F657_5763(RTCW(loc2), tr1);
	}
	tr1 = RTOSCF(3080,F130_3080, (Current));
	tr2 = RTMS_EX_H("location",8,59511406);
	tr1 = F857_6543(RTCW(tr1), tr2);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,966,0xFF01,1053,0xFF01,1048,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		tr2 = RTMS_EX_H("Location",8,52138606);
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		((EIF_TYPED_VALUE *)tr1+2)->it_r = loc4;
		RTAR(tr1,loc4);
		F657_5763(RTCW(loc2), tr1);
	}
	tr1 = F129_3075(Current, loc2);
	F269_4627(RTCW(arg2), tr1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,656,0xFF01,0xFFF9,2,966,0xFF01,1045,0xFF01,1045,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc2 = RTLNS(typres0.id, 656, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F657_5723(RTCW(loc2), ((EIF_INTEGER_32) 5L));
	loc1 = RTLNS(eif_new_type(1050, 0x01).id, 1050, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1046_8989(RTCW(loc1));
	tr1 = RTOSCF(3081,F130_3081, (Current));
	tr2 = RTMS_EX_H("use_standalone",14,413839717);
	tb1 = F857_6544(RTCW(tr1), tr2);
	if (tb1) {
		tb1 = F491_5233(RTCW(loc1));
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = F1046_9048(RTMS_EX_H(", ",2,11296));
			F1051_9234(RTCW(loc1), tr1);
		}
		tr1 = F1046_9048(RTMS_EX_H("standalone",10,1099491941));
		F1051_9234(RTCW(loc1), tr1);
	}
	tr1 = RTOSCF(3081,F130_3081, (Current));
	tr2 = RTMS_EX_H("use_cgi",7,585818473);
	tb1 = F857_6544(RTCW(tr1), tr2);
	if (tb1) {
		tb1 = F491_5233(RTCW(loc1));
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = F1046_9048(RTMS_EX_H(", ",2,11296));
			F1051_9234(RTCW(loc1), tr1);
		}
		tr1 = F1046_9048(RTMS_EX_H("cgi",3,6514537));
		F1051_9234(RTCW(loc1), tr1);
	}
	tr1 = RTOSCF(3081,F130_3081, (Current));
	tr2 = RTMS_EX_H("use_libfcgi",11,2072232553);
	tb1 = F857_6544(RTCW(tr1), tr2);
	if (tb1) {
		tb1 = F491_5233(RTCW(loc1));
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = F1046_9048(RTMS_EX_H(", ",2,11296));
			F1051_9234(RTCW(loc1), tr1);
		}
		tr1 = F1046_9048(RTMS_EX_H("libfcgi",7,448686441));
		F1051_9234(RTCW(loc1), tr1);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,966,0xFF01,1053,0xFF01,1050,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 3, 0);
	}
	tr2 = RTMS_EX_H("Connectors",10,2016219251);
	((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
	RTAR(tr1,tr2);
	((EIF_TYPED_VALUE *)tr1+2)->it_r = loc1;
	RTAR(tr1,loc1);
	F657_5763(RTCW(loc2), tr1);
	tr1 = RTOSCF(3083,F130_3083, (Current));
	tr2 = RTMS_EX_H("use_router",10,247347826);
	tb1 = F857_6544(RTCW(tr1), tr2);
	if (tb1) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,966,0xFF01,1053,0xFF01,1053,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		tr2 = RTMS_EX_H("Use Router",10,686828146);
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		tr2 = RTMS_EX_H("yes",3,7955827);
		((EIF_TYPED_VALUE *)tr1+2)->it_r = tr2;
		RTAR(tr1,tr2);
		F657_5763(RTCW(loc2), tr1);
	}
	tr1 = RTOSCF(3083,F130_3083, (Current));
	tr2 = RTMS_EX_H("use_filter",10,72713842);
	tb1 = F857_6544(RTCW(tr1), tr2);
	if (tb1) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,966,0xFF01,1053,0xFF01,1053,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 0);
		}
		tr2 = RTMS_EX_H("Use Filter",10,512194162);
		((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
		RTAR(tr1,tr2);
		tr2 = RTMS_EX_H("yes",3,7955827);
		((EIF_TYPED_VALUE *)tr1+2)->it_r = tr2;
		RTAR(tr1,tr2);
		F657_5763(RTCW(loc2), tr1);
	}
	tr1 = F129_3075(Current, loc2);
	F269_4627(RTCW(arg3), tr1);
	RTLE;
}

/* {EWF_WIZARD}.inline-agent#1 of project_page */
void F130_14738 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,loc3);
	RTLR(3,arg2);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,loc1);
	RTLR(7,Current);
	RTLIU(8);
	
	RTGC;
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4535[Dtype(RTCW(arg1))-282])(arg1);
	loc3 = RTLNS(eif_new_type(931, 0x01).id, 931, _OBJSIZ_2_1_0_0_0_0_0_0_);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4517[Dtype(RTCW(arg2))-281])(arg2);
	F932_7666(RTCW(loc3), tr1);
	tb1 = '\01';
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4517[Dtype(RTCW(arg2))-281])(arg2);
	tr2 = RTMS_EX_H("/",1,47);
	tb2 = F1046_9037(RTCW(tr1), tr2);
	if (!tb2) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4517[Dtype(RTCW(arg2))-281])(arg2);
		tr2 = RTMS_EX_H("\\",1,92);
		tb2 = F1046_9037(RTCW(tr1), tr2);
		tb1 = tb2;
	}
	if (tb1) {
	} else {
		tr1 = F932_7681(RTCW(loc3));
		loc3 = (EIF_REFERENCE) tr1;
	}
	if ((EIF_BOOLEAN)(loc2 == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = RTOSCF(3077,F130_3077, (Current));
		tr1 = F310_4874(RTCW(tr1), tr2, loc3);
		loc1 = F932_7705(RTCW(tr1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4518[Dtype(RTCW(arg2))-281])(arg2, loc1);
	} else {
		tb1 = F1046_9007(RTCW(loc2));
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = *(EIF_REFERENCE *)(Current);
			tr1 = F310_4874(RTCW(tr1), loc2, loc3);
			loc1 = F932_7705(RTCW(tr1));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4518[Dtype(RTCW(arg2))-281])(arg2, loc1);
		}
	}
	RTLE;
}

/* {EWF_WIZARD}.inline-agent#2 of project_page */
void F130_14739 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tb1 = '\01';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
	tr2 = RTMS_EX_H("name",4,1851878757);
	tr1 = F832_6333(RTCW(tr1), tr2);
	loc1 = tr1;
	if (!((EIF_BOOLEAN) !EIF_TEST(loc1))) {
		tb2 = F1046_9007(loc1);
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = RTMS_EX_H("Invalid value for `name\'!",25,1415550497);
		F857_6582(RTCW(arg1), tr1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
	tr2 = RTMS_EX_H("location",8,59511406);
	tb1 = F832_6339(RTCW(tr1), tr2);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTMS_EX_H("Missing value for `location\'!",29,57775393);
		F857_6582(RTCW(arg1), tr1);
	}
	RTLE;
}

void EIF_Minit115 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
