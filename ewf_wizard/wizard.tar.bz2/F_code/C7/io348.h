
#ifndef _C7_io348_
#define _C7_io348_

#ifdef __cplusplus
extern "C" {
#endif

extern void F917_6937(EIF_REFERENCE);
extern void EIF_Minit348(void);
extern void F919_7173(EIF_REFERENCE);
extern EIF_BOOLEAN F919_7145(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
