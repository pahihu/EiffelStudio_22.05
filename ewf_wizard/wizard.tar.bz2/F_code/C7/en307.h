
#ifndef _C7_en307_
#define _C7_en307_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F705_6056(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit307(void);
extern EIF_REFERENCE F704_6024(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
