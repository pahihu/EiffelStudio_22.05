/*
 * Code for class EV_GLIB_ERROR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev341.h"
#include "glib.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F910_6689
static EIF_INTEGER_32 inline_F910_6689 (void)
{
	return (EIF_INTEGER_32) (sizeof (GError))
	;
}
#define INLINE_F910_6689
#endif
#ifndef INLINE_F910_6697
static EIF_POINTER inline_F910_6697 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (((GError *) arg1) -> message);
	;
}
#define INLINE_F910_6697
#endif
#ifndef INLINE_F910_6698
static void inline_F910_6698 (EIF_POINTER arg1)
{
	g_error_free ((GError *) arg1);
	;
}
#define INLINE_F910_6698
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GLIB_ERROR}.structure_size */
EIF_INTEGER_32 F910_6689 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F910_6689 ();
	return Result;
}

/* {EV_GLIB_ERROR}.message */
EIF_REFERENCE F910_6692 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tp1 = F254_4321(Current);
	loc1 = inline_F910_6697(tp1);
	tb1 = !loc1;
	if (tb1) {
		tr1 = RTMS32_EX_H("",0,0);
	} else {
		tr2 = RTLNS(eif_new_type(910, 0x01).id, 910, _OBJSIZ_0_1_0_1_0_1_0_0_);
		F911_6707(RTCW(tr2), loc1);
		tr2 = F911_6703(RTCW(tr2));
		tr1 = tr2;
	}
	Result = (EIF_REFERENCE) tr1;
	RTLE;
	return Result;
}

/* {EV_GLIB_ERROR}.dispose */
void F910_6693 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (F254_4322(Current)) {
		F910_6694(Current);
	}
	RTLE;
}

/* {EV_GLIB_ERROR}.free */
void F910_6694 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F254_4321(Current);
	inline_F910_6698(tp1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current+ _PTROFF_1_1_0_0_0_0_) = (EIF_POINTER) tp2;
	} else {
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) NULL;
	}
	RTLE;
}

/* {EV_GLIB_ERROR}.c_message */
EIF_POINTER F910_6697 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F910_6697 ((EIF_POINTER) arg1);
	return Result;
}

/* {EV_GLIB_ERROR}.c_free */
void F910_6698 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	inline_F910_6698 ((EIF_POINTER) arg1);
}

void EIF_Minit341 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
