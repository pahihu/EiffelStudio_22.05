
#ifndef _C7_te330_
#define _C7_te330_

#ifdef __cplusplus
extern "C" {
#endif

extern void F854_6521(EIF_REFERENCE);
extern EIF_BOOLEAN F854_6522(EIF_REFERENCE);
extern void F854_6523(EIF_REFERENCE);
extern void EIF_Minit330(void);
extern void F847_6486(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F849_6503(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
