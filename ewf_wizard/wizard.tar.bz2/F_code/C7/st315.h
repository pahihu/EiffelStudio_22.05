
#ifndef _C7_st315_
#define _C7_st315_

#ifdef __cplusplus
extern "C" {
#endif

extern void F803_6251(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F803_6252(EIF_REFERENCE);
extern EIF_REFERENCE F803_6253(EIF_REFERENCE);
extern EIF_REFERENCE F803_6255(EIF_REFERENCE);
extern EIF_INTEGER_32 F803_6256(EIF_REFERENCE);
extern void EIF_Minit315(void);
extern EIF_INTEGER_32 F1049_9171(EIF_REFERENCE);
extern char *(*R7645[])();

#ifdef __cplusplus
}
#endif

#endif
