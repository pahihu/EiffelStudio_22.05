
#ifndef _C7_ev319_
#define _C7_ev319_

#ifdef __cplusplus
extern "C" {
#endif

extern void F831_6315(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F831_6320(EIF_REFERENCE);
extern EIF_INTEGER_32 F831_6322(EIF_REFERENCE);
extern void EIF_Minit319(void);

#ifdef __cplusplus
}
#endif

#endif
