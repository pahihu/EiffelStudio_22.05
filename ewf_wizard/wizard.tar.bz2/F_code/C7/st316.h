
#ifndef _C7_st316_
#define _C7_st316_

#ifdef __cplusplus
extern "C" {
#endif

extern void F804_6257(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F804_6258(EIF_REFERENCE);
extern EIF_REFERENCE F804_6259(EIF_REFERENCE);
extern EIF_REFERENCE F804_6261(EIF_REFERENCE);
extern EIF_INTEGER_32 F804_6262(EIF_REFERENCE);
extern void EIF_Minit316(void);
extern EIF_INTEGER_32 F1052_9339(EIF_REFERENCE);
extern char *(*R7725[])();

#ifdef __cplusplus
}
#endif

#endif
