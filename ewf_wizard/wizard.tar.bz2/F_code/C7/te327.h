
#ifndef _C7_te327_
#define _C7_te327_

#ifdef __cplusplus
extern "C" {
#endif

extern void F851_6507(EIF_REFERENCE);
extern void F851_6508(EIF_REFERENCE);
extern void EIF_Minit327(void);
extern EIF_REFERENCE F160_3468(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F160_3469(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F849_6504(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN);
extern void F847_6486(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F849_6503(EIF_REFERENCE);
extern char *(*R28[])();

#ifdef __cplusplus
}
#endif

#endif
