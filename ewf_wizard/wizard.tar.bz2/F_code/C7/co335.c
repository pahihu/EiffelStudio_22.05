/*
 * Code for class CONSOLE_WIZARD_PAGE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co335.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONSOLE_WIZARD_PAGE}.reuse */
void F859_6594 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {CONSOLE_WIZARD_PAGE}.new_string_question */
EIF_REFERENCE F859_6595 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg2);
	RTLR(2,arg1);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(288, 0x01).id, 288, _OBJSIZ_7_0_0_0_0_0_0_0_);
	F288_4720(RTCW(tr1), arg2, arg1, arg3);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONSOLE_WIZARD_PAGE}.new_directory_question */
EIF_REFERENCE F859_6596 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg2);
	RTLR(2,arg1);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(291, 0x01).id, 291, _OBJSIZ_6_0_0_0_0_0_0_0_);
	F288_4720(RTCW(tr1), arg2, arg1, arg3);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONSOLE_WIZARD_PAGE}.new_boolean_question */
EIF_REFERENCE F859_6597 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg2);
	RTLR(2,arg1);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(290, 0x01).id, 290, _OBJSIZ_6_1_0_0_0_0_0_0_);
	F288_4720(RTCW(tr1), arg2, arg1, arg3);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {CONSOLE_WIZARD_PAGE}.new_integer_question */
EIF_REFERENCE F859_6598 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,arg2);
	RTLR(2,arg1);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(289, 0x01).id, 289, _OBJSIZ_6_0_0_1_0_0_0_0_);
	F288_4720(RTCW(tr1), arg2, arg1, arg3);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

void EIF_Minit335 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
