
#ifndef _C7_gt339_
#define _C7_gt339_

#ifdef __cplusplus
extern "C" {
#endif

extern void F908_6674(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32);
extern void F908_6677(EIF_REFERENCE);
extern void F908_6679(EIF_REFERENCE);
extern void EIF_Minit339(void);
extern void F105_2457(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
