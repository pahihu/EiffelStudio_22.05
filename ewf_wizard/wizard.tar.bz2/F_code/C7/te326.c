/*
 * Code for class TEMPLATE_STRUCTURE_ACTION_NL2BR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "te326.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TEMPLATE_STRUCTURE_ACTION_NL2BR}.process */
void F850_6505 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	{
		/* INLINED CODE (TEMPLATE_STRUCTURE_ITEM.process) */
		/* END INLINED CODE */
	}
	;
	F850_6506(Current);
	RTLE;
}

/* {TEMPLATE_STRUCTURE_ACTION_NL2BR}.process_nl2br */
void F850_6506 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	tr1 = F849_6503(Current);
	loc1 = F849_6504(Current, tr1, (EIF_BOOLEAN) 0);
	tr1 = RTMS_EX_H("\015\012",2,3338);
	tr2 = RTMS_EX_H("<br/>\012",6,2034416138);
	F1054_9376(RTCW(loc1), tr1, tr2);
	tr1 = RTMS_EX_H("\012",1,10);
	tr2 = RTMS_EX_H("<br/>\012",6,2034416138);
	F1054_9376(RTCW(loc1), tr1, tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr2 = RTOSCF(3335,F145_3335, (Current));
	tb1 = F648_5600(RTCW(tr1), tr2);
	if (tb1) {
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		tr2 = RTOSCF(3335,F145_3335, (Current));
		tr1 = F648_5598(RTCW(tr1), tr2);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tr1 = RTOSCF(3341,F145_3341, (Current));
			tb2 = F1052_9312(loc2, tr1);
			tb1 = tb2;
		}
		if (tb1) {
			tr1 = RTMS_EX_H("\011",1,9);
			tr2 = RTMS_EX_H("&nbsp;&nbsp;&nbsp;&nbsp;",24,1681196603);
			F1054_9376(RTCW(loc1), tr1, tr2);
		}
	}
	F847_6486(Current, loc1);
	RTLE;
}

void EIF_Minit326 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
