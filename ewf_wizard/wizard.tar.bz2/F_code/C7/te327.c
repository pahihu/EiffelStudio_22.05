/*
 * Code for class TEMPLATE_STRUCTURE_ACTION_CUSTOM_ACTION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "te327.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TEMPLATE_STRUCTURE_ACTION_CUSTOM_ACTION}.process */
void F851_6507 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	{
		/* INLINED CODE (TEMPLATE_STRUCTURE_ITEM.process) */
		/* END INLINED CODE */
	}
	;
	if (F160_3469(Current, *(EIF_REFERENCE *)(Current))) {
		F851_6508(Current);
	}
	RTLE;
}

/* {TEMPLATE_STRUCTURE_ACTION_CUSTOM_ACTION}.process_custom_action */
void F851_6508 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTGC;
	tr1 = F160_3468(Current, *(EIF_REFERENCE *)(Current));
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tr1 = F849_6503(Current);
		loc1 = F849_6504(Current, tr1, (EIF_BOOLEAN) 0);
		tr1 = (RTNA((loc2, loc1, *(EIF_REFERENCE *)(Current + _REFACS_8_), Current)), ((EIF_REFERENCE) 0));
		loc3 = RTCCL(tr1);
		if (EIF_TEST(loc3)) {
			loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R28[Dtype(loc3)-5])(loc3);
		} else {
			loc1 = RTMS_EX_H("",0,0);
		}
	} else {
		tr1 = F849_6503(Current);
		loc1 = F849_6504(Current, tr1, (EIF_BOOLEAN) 0);
	}
	F847_6486(Current, loc1);
	RTLE;
}

void EIF_Minit327 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
