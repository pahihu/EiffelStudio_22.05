/*
 * Code for class EV_GTK_C_STRING
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev342.h"
#include <string.h>
#include <ev_gtk.h>
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GTK_C_STRING}.make_from_pointer */
void F911_6699 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = (EIF_INTEGER_32) strlen(((char*) arg1));
	F911_6710(Current, arg1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)), (EIF_BOOLEAN) 0);
	RTLE;
}

/* {EV_GTK_C_STRING}.make_from_path */
void F911_6700 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc3);
	RTLIU(4);
	
	RTGC;
	loc1 = F932_7704(RTCW(arg1));
	loc2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
	tp1 = (EIF_POINTER) g_malloc((gulong) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
	*(EIF_POINTER *)(Current+ _PTROFF_0_1_0_1_0_0_) = (EIF_POINTER) tp1;
	loc3 = F1054_9443(RTCW(loc1));
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_1_0_0_);
	memcpy((void *)tp1, (const void *) loc3, (size_t) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_0_) = (EIF_INTEGER_32) loc2;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_0_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {EV_GTK_C_STRING}.string */
EIF_REFERENCE F911_6703 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_8 loc2 = (EIF_NATURAL_8) 0;
	EIF_NATURAL_32 loc3 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_NATURAL_32 tu4_1;
	EIF_CHARACTER_32 tw1;
	EIF_NATURAL_8 tu1_1;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_0_);
	loc1 = RTOSCF(6708,F911_6708, (Current));
	F915_6802(RTCW(loc1), *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_1_0_0_), loc5);
	Result = RTLNS(eif_new_type(1050, 0x01).id, 1050, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1049_9119(RTCW(Result), loc5);
	F1051_9283(RTCW(Result), loc5);
	for (;;) {
		if ((EIF_BOOLEAN)(loc4 == loc5)) break;
		loc2 = F915_6808(RTCW(loc1), loc4);
		loc6++;
		if ((EIF_BOOLEAN) (loc2 <= (EIF_NATURAL_8) ((EIF_INTEGER_32) 127L))) {
			tc1 = (EIF_CHARACTER_8) loc2;
			tw1 = (EIF_CHARACTER_32) tc1;
			F1051_9221(RTCW(Result), tw1, loc6);
		} else {
			tu1_1 = eif_bit_and(loc2,(EIF_NATURAL_8) ((EIF_INTEGER_32) 224L));
			if ((EIF_BOOLEAN)(tu1_1 == (EIF_NATURAL_8) ((EIF_INTEGER_32) 192L))) {
				tu1_1 = eif_bit_and(loc2,(EIF_NATURAL_8) ((EIF_INTEGER_32) 31L));
				tu4_1 = (EIF_NATURAL_32) tu1_1;
				loc3 = eif_bit_shift_left(tu4_1,((EIF_INTEGER_32) 6L));
				loc4++;
				loc2 = F915_6808(RTCW(loc1), loc4);
				tu1_1 = eif_bit_and(loc2,(EIF_NATURAL_8) ((EIF_INTEGER_32) 63L));
				tu4_1 = (EIF_NATURAL_32) tu1_1;
				tu4_1 = eif_bit_or(loc3,tu4_1);
				loc3 = (EIF_NATURAL_32) tu4_1;
				tw1 = (EIF_CHARACTER_32) loc3;
				F1051_9221(RTCW(Result), tw1, loc6);
			} else {
				tu1_1 = eif_bit_and(loc2,(EIF_NATURAL_8) ((EIF_INTEGER_32) 240L));
				if ((EIF_BOOLEAN)(tu1_1 == (EIF_NATURAL_8) ((EIF_INTEGER_32) 224L))) {
					tu1_1 = eif_bit_and(loc2,(EIF_NATURAL_8) ((EIF_INTEGER_32) 15L));
					tu4_1 = (EIF_NATURAL_32) tu1_1;
					loc3 = eif_bit_shift_left(tu4_1,((EIF_INTEGER_32) 12L));
					loc2 = F915_6808(RTCW(loc1), (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L)));
					tu1_1 = eif_bit_and(loc2,(EIF_NATURAL_8) ((EIF_INTEGER_32) 63L));
					tu4_1 = (EIF_NATURAL_32) tu1_1;
					tu4_1 = eif_bit_shift_left(tu4_1,((EIF_INTEGER_32) 6L));
					tu4_1 = eif_bit_or(loc3,tu4_1);
					loc3 = (EIF_NATURAL_32) tu4_1;
					loc2 = F915_6808(RTCW(loc1), (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 2L)));
					tu1_1 = eif_bit_and(loc2,(EIF_NATURAL_8) ((EIF_INTEGER_32) 63L));
					tu4_1 = (EIF_NATURAL_32) tu1_1;
					tu4_1 = eif_bit_or(loc3,tu4_1);
					loc3 = (EIF_NATURAL_32) tu4_1;
					tw1 = (EIF_CHARACTER_32) loc3;
					F1051_9221(RTCW(Result), tw1, loc6);
					loc4 += ((EIF_INTEGER_32) 2L);
				} else {
					tu1_1 = eif_bit_and(loc2,(EIF_NATURAL_8) ((EIF_INTEGER_32) 248L));
					if ((EIF_BOOLEAN)(tu1_1 == (EIF_NATURAL_8) ((EIF_INTEGER_32) 240L))) {
						tu1_1 = eif_bit_and(loc2,(EIF_NATURAL_8) ((EIF_INTEGER_32) 7L));
						tu4_1 = (EIF_NATURAL_32) tu1_1;
						loc3 = eif_bit_shift_left(tu4_1,((EIF_INTEGER_32) 18L));
						loc2 = F915_6808(RTCW(loc1), (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L)));
						tu1_1 = eif_bit_and(loc2,(EIF_NATURAL_8) ((EIF_INTEGER_32) 63L));
						tu4_1 = (EIF_NATURAL_32) tu1_1;
						tu4_1 = eif_bit_shift_left(tu4_1,((EIF_INTEGER_32) 12L));
						tu4_1 = eif_bit_or(loc3,tu4_1);
						loc3 = (EIF_NATURAL_32) tu4_1;
						loc2 = F915_6808(RTCW(loc1), (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 2L)));
						tu1_1 = eif_bit_and(loc2,(EIF_NATURAL_8) ((EIF_INTEGER_32) 63L));
						tu4_1 = (EIF_NATURAL_32) tu1_1;
						tu4_1 = eif_bit_shift_left(tu4_1,((EIF_INTEGER_32) 6L));
						tu4_1 = eif_bit_or(loc3,tu4_1);
						loc3 = (EIF_NATURAL_32) tu4_1;
						loc2 = F915_6808(RTCW(loc1), (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 3L)));
						tu1_1 = eif_bit_and(loc2,(EIF_NATURAL_8) ((EIF_INTEGER_32) 63L));
						tu4_1 = (EIF_NATURAL_32) tu1_1;
						tu4_1 = eif_bit_or(loc3,tu4_1);
						loc3 = (EIF_NATURAL_32) tu4_1;
						tw1 = (EIF_CHARACTER_32) loc3;
						F1051_9221(RTCW(Result), tw1, loc6);
						loc4 += ((EIF_INTEGER_32) 3L);
					} else {
						tu1_1 = eif_bit_and(loc2,(EIF_NATURAL_8) ((EIF_INTEGER_32) 252L));
						if ((EIF_BOOLEAN)(tu1_1 == (EIF_NATURAL_8) ((EIF_INTEGER_32) 248L))) {
							tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
							F1051_9221(RTCW(Result), tw1, loc6);
							loc4 += ((EIF_INTEGER_32) 4L);
						} else {
							tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
							F1051_9221(RTCW(Result), tw1, loc6);
							loc4 += ((EIF_INTEGER_32) 5L);
						}
					}
				}
			}
		}
		loc4++;
	}
	F1051_9283(RTCW(Result), loc6);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	F915_6802(RTCW(loc1), tp2, ((EIF_INTEGER_32) 0L));
	RTLE;
	return Result;
}

/* {EV_GTK_C_STRING}.set_with_eiffel_string */
void F911_6705 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F911_6709(Current, arg1, (EIF_BOOLEAN) 0);
}

/* {EV_GTK_C_STRING}.share_from_pointer */
void F911_6707 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = (EIF_INTEGER_32) strlen(((char*) arg1));
	F911_6710(Current, arg1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)), (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_GTK_C_STRING}.shared_pointer_helper */
static EIF_REFERENCE F911_6708_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (6708);
#define Result RTOSR(6708)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(914, 0x01).id, 914, _OBJSIZ_0_1_0_1_0_1_1_0_);
	tp1 = F1_33(Current);
	F915_6800(RTCW(tr1), tp1, ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (6708);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F911_6708 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6708,F911_6708_body,(Current));
}

/* {EV_GTK_C_STRING}.internal_set_with_eiffel_string */
void F911_6709 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc4 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc6);
	RTLIU(3);
	
	RTGC;
	loc5 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7528[Dtype(RTCW(arg1))-1049])(arg1);
	loc3 = (EIF_INTEGER_32) loc5;
	for (;;) {
		if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) break;
		loc4 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R7491[Dtype(RTCW(arg1))-1049])(arg1, loc3);
		if ((EIF_BOOLEAN) (loc4 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 127L))) {
			loc2++;
		} else {
			if ((EIF_BOOLEAN) (loc4 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 2047L))) {
				loc2 += ((EIF_INTEGER_32) 2L);
			} else {
				if ((EIF_BOOLEAN) (loc4 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 65535L))) {
					loc2 += ((EIF_INTEGER_32) 3L);
				} else {
					loc2 += ((EIF_INTEGER_32) 4L);
				}
			}
		}
		loc3--;
	}
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	tb1 = '\0';
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current+ _PTROFF_0_1_0_1_0_0_) != tp1)) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_0_0_);
	}
	if (tb1) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_1_0_0_);
		loc1 = (EIF_POINTER) g_realloc((gpointer) tp1, (gulong) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current+ _PTROFF_0_1_0_1_0_0_) = (EIF_POINTER) tp2;
	} else {
		loc1 = (EIF_POINTER) g_malloc((gulong) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
	}
	loc6 = RTOSCF(6708,F911_6708, (Current));
	F915_6802(RTCW(loc6), loc1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc3 > loc5)) break;
		loc4 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R7491[Dtype(RTCW(arg1))-1049])(arg1, loc3);
		if ((EIF_BOOLEAN) (loc4 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 127L))) {
			tu1_1 = (EIF_NATURAL_8) loc4;
			F915_6828(RTCW(loc6), tu1_1, loc2);
			loc2++;
		} else {
			if ((EIF_BOOLEAN) (loc4 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 2047L))) {
				tu4_1 = eif_bit_shift_right(loc4,((EIF_INTEGER_32) 6L));
				tu4_1 = eif_bit_or(((EIF_NATURAL_32) ((EIF_INTEGER_32) 192L)),tu4_1);
				tu1_1 = (EIF_NATURAL_8) tu4_1;
				F915_6828(RTCW(loc6), tu1_1, loc2);
				tu4_1 = eif_bit_and(loc4,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
				tu4_1 = eif_bit_or(((EIF_NATURAL_32) ((EIF_INTEGER_32) 128L)),tu4_1);
				tu1_1 = (EIF_NATURAL_8) tu4_1;
				F915_6828(RTCW(loc6), tu1_1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
				loc2 += ((EIF_INTEGER_32) 2L);
			} else {
				if ((EIF_BOOLEAN) (loc4 <= (EIF_NATURAL_32) ((EIF_INTEGER_32) 65535L))) {
					tu4_1 = eif_bit_shift_right(loc4,((EIF_INTEGER_32) 12L));
					tu4_1 = eif_bit_or(((EIF_NATURAL_32) ((EIF_INTEGER_32) 224L)),tu4_1);
					tu1_1 = (EIF_NATURAL_8) tu4_1;
					F915_6828(RTCW(loc6), tu1_1, loc2);
					tu4_1 = eif_bit_shift_right(loc4,((EIF_INTEGER_32) 6L));
					tu4_1 = eif_bit_and(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
					tu4_1 = eif_bit_or(((EIF_NATURAL_32) ((EIF_INTEGER_32) 128L)),tu4_1);
					tu1_1 = (EIF_NATURAL_8) tu4_1;
					F915_6828(RTCW(loc6), tu1_1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
					tu4_1 = eif_bit_and(loc4,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
					tu4_1 = eif_bit_or(((EIF_NATURAL_32) ((EIF_INTEGER_32) 128L)),tu4_1);
					tu1_1 = (EIF_NATURAL_8) tu4_1;
					F915_6828(RTCW(loc6), tu1_1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)));
					loc2 += ((EIF_INTEGER_32) 3L);
				} else {
					tu4_1 = eif_bit_shift_right(loc4,((EIF_INTEGER_32) 18L));
					tu4_1 = eif_bit_or(((EIF_NATURAL_32) ((EIF_INTEGER_32) 240L)),tu4_1);
					tu1_1 = (EIF_NATURAL_8) tu4_1;
					F915_6828(RTCW(loc6), tu1_1, loc2);
					tu4_1 = eif_bit_shift_right(loc4,((EIF_INTEGER_32) 12L));
					tu4_1 = eif_bit_and(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
					tu4_1 = eif_bit_or(((EIF_NATURAL_32) ((EIF_INTEGER_32) 128L)),tu4_1);
					tu1_1 = (EIF_NATURAL_8) tu4_1;
					F915_6828(RTCW(loc6), tu1_1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
					tu4_1 = eif_bit_shift_right(loc4,((EIF_INTEGER_32) 6L));
					tu4_1 = eif_bit_and(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
					tu4_1 = eif_bit_or(((EIF_NATURAL_32) ((EIF_INTEGER_32) 128L)),tu4_1);
					tu1_1 = (EIF_NATURAL_8) tu4_1;
					F915_6828(RTCW(loc6), tu1_1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)));
					tu4_1 = eif_bit_and(loc4,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
					tu4_1 = eif_bit_or(((EIF_NATURAL_32) ((EIF_INTEGER_32) 128L)),tu4_1);
					tu1_1 = (EIF_NATURAL_8) tu4_1;
					F915_6828(RTCW(loc6), tu1_1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 3L)));
					loc2 += ((EIF_INTEGER_32) 4L);
				}
			}
		}
		loc3++;
	}
	F915_6832(RTCW(loc6), (EIF_INTEGER_8) ((EIF_INTEGER_32) 0L), loc2);
	F911_6710(Current, loc1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)), arg2);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	F915_6802(RTCW(loc6), tp2, ((EIF_INTEGER_32) 0L));
	RTLE;
}

/* {EV_GTK_C_STRING}.set_from_pointer */
void F911_6710 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_BOOLEAN arg3)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F911_6711(Current);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_0_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L));
	*(EIF_POINTER *)(Current+ _PTROFF_0_1_0_1_0_0_) = (EIF_POINTER) arg1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_0_0_) = (EIF_BOOLEAN) arg3;
	RTLE;
}

/* {EV_GTK_C_STRING}.dispose */
void F911_6711 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tb1 = '\0';
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current+ _PTROFF_0_1_0_1_0_0_) != tp1)) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_0_0_);
	}
	if (tb1) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_1_0_0_);
		g_free((gpointer) tp1);
		{
			/* INLINED CODE (ANY.default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current+ _PTROFF_0_1_0_1_0_0_) = (EIF_POINTER) tp2;
	}
	RTLE;
}

/* {EV_GTK_C_STRING}.c_strlen */
EIF_INTEGER_32 F911_6712 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) strlen(((char*) arg1));
	return Result;
}

void EIF_Minit342 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
