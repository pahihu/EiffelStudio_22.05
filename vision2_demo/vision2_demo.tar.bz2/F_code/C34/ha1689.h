
#ifndef _C34_ha1689_
#define _C34_ha1689_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F759_6070(EIF_REFERENCE);
extern EIF_REFERENCE F759_6071(EIF_REFERENCE);
extern EIF_BOOLEAN F759_6073(EIF_REFERENCE);
extern void F759_6074(EIF_REFERENCE);
extern EIF_REFERENCE F759_6075(EIF_REFERENCE);
extern void EIF_Minit1689(void);
extern EIF_INTEGER_32 F660_5360(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F748_6056(EIF_REFERENCE);
extern EIF_INTEGER_32 F660_5361(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R5951[])();
extern char *(*R4485[])();

#ifdef __cplusplus
}
#endif

#endif
