
#ifndef _C34_ha1662_
#define _C34_ha1662_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F754_6070(EIF_REFERENCE);
extern EIF_REFERENCE F754_6071(EIF_REFERENCE);
extern EIF_BOOLEAN F754_6073(EIF_REFERENCE);
extern void F754_6074(EIF_REFERENCE);
extern EIF_REFERENCE F754_6075(EIF_REFERENCE);
extern void EIF_Minit1662(void);
extern char *(*R5951[])();
extern char *(*R4485[])();
extern char *(*R4783[])();
extern char *(*R4784[])();
extern char *(*R5322[])();
extern long O4792[];
extern long O4793[];

#ifdef __cplusplus
}
#endif

#endif
