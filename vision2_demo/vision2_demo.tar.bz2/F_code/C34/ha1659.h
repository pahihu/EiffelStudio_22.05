
#ifndef _C34_ha1659_
#define _C34_ha1659_

#ifdef __cplusplus
extern "C" {
#endif

extern void F655_5316(EIF_REFERENCE, EIF_INTEGER_32);
extern void F655_5319(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F655_5320(EIF_REFERENCE);
extern EIF_REFERENCE F655_5322(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F655_5323(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F655_5324(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F655_5326(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F655_5328(EIF_REFERENCE);
extern EIF_REFERENCE F655_5329(EIF_REFERENCE);
extern EIF_REFERENCE F655_5330(EIF_REFERENCE);
extern EIF_REFERENCE F655_5331(EIF_REFERENCE);
extern EIF_REFERENCE F655_5332(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F655_5333(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F655_5334(EIF_REFERENCE);
extern EIF_INTEGER_32 F655_5337(EIF_REFERENCE);
extern EIF_INTEGER_32 F655_5338(EIF_REFERENCE);
extern EIF_BOOLEAN F655_5339(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F655_5340(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F655_5343(EIF_REFERENCE);
extern EIF_BOOLEAN F655_5348(EIF_REFERENCE);
extern EIF_BOOLEAN F655_5349(EIF_REFERENCE);
extern EIF_BOOLEAN F655_5350(EIF_REFERENCE);
extern EIF_BOOLEAN F655_5351(EIF_REFERENCE);
extern EIF_BOOLEAN F655_5352(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F655_5354(EIF_REFERENCE, EIF_INTEGER_32);
extern void F655_5355(EIF_REFERENCE);
extern void F655_5356(EIF_REFERENCE);
extern void F655_5357(EIF_REFERENCE, EIF_REFERENCE);
extern void F655_5358(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F655_5360(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F655_5361(EIF_REFERENCE, EIF_INTEGER_32);
extern void F655_5362(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F655_5363(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F655_5364(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F655_5368(EIF_REFERENCE, EIF_REFERENCE);
extern void F655_5369(EIF_REFERENCE, EIF_REFERENCE);
extern void F655_5370(EIF_REFERENCE);
extern EIF_REFERENCE F655_5372(EIF_REFERENCE);
extern void F655_5373(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F655_5374(EIF_REFERENCE, EIF_INTEGER_32);
extern void F655_5375(EIF_REFERENCE);
extern EIF_INTEGER_32 F655_5384(EIF_REFERENCE);
extern EIF_BOOLEAN F655_5385(EIF_REFERENCE);
extern EIF_REFERENCE F655_5392(EIF_REFERENCE);
extern EIF_REFERENCE F655_5393(EIF_REFERENCE);
extern EIF_INTEGER_32 F655_5394(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F655_5395(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F655_5396(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F655_5397(EIF_REFERENCE, EIF_INTEGER_32);
extern void F655_5398(EIF_REFERENCE, EIF_REFERENCE);
extern void F655_5400(EIF_REFERENCE, EIF_REFERENCE);
extern void F655_5401(EIF_REFERENCE, EIF_REFERENCE);
extern void F655_5402(EIF_REFERENCE, EIF_REFERENCE);
extern void F655_5406(EIF_REFERENCE, EIF_REFERENCE);
extern void F655_5407(EIF_REFERENCE, EIF_REFERENCE);
extern void F655_5412(EIF_REFERENCE);
extern void F655_5425(EIF_REFERENCE);
extern void F655_5427(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1659(void);
extern void F652_5264(EIF_REFERENCE);
extern void F870_6828(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern EIF_REFERENCE F652_5265(EIF_REFERENCE);
extern void F870_6810(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern EIF_INTEGER_32 F707_5988(EIF_REFERENCE, EIF_INTEGER_32);
extern void F872_6810(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F247_3894(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F870_6821(EIF_REFERENCE);
extern void F872_6831(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F870_6831(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32, EIF_INTEGER_32);
RTOSHF(EIF_REFERENCE,5265)
extern char *(*R5325[])();
extern char *(*R4799[])();
extern char *(*R4761[])();
extern char *(*R5328[])();
extern char *(*R4827[])();
extern char *(*R4762[])();
extern char *(*R4790[])();
extern char *(*R5951[])();
extern char *(*R5251[])();
extern char *(*R5252[])();
extern char *(*R4752[])();
extern char *(*R4755[])();
extern char *(*R4485[])();
extern char *(*R4446[])();
extern char *(*R4309[])();
extern char *(*R6925[])();
extern char *(*R4449[])();
extern char *(*R4856[])();
extern char *(*R4258[])();
extern char *(*R5965[])();
extern char *(*R5966[])();
extern char *(*R4764[])();
extern char *(*R5952[])();
extern char *(*R4766[])();
extern char *(*R4840[])();
extern char *(*R4800[])();
extern char *(*R4436[])();
extern char *(*R4773[])();
extern char *(*R4809[])();
extern char *(*R4772[])();
extern char *(*R4756[])();
extern char *(*R4774[])();
extern char *(*R4775[])();
extern char *(*R5979[])();
extern char *(*R5310[])();
extern char *(*R4779[])();
extern char *(*R4810[])();
extern char *(*R4811[])();
extern char *(*R4812[])();
extern char *(*R4813[])();
extern char *(*R4778[])();
extern char *(*R4815[])();
extern char *(*R4816[])();
extern char *(*R4817[])();
extern char *(*R4781[])();
extern char *(*R5985[])();
extern char *(*R4783[])();
extern char *(*R4784[])();
extern char *(*R5250[])();
extern char *(*R4821[])();
extern char *(*R4822[])();
extern long O4307[];
extern long O4792[];
extern long O4793[];
extern long O4794[];
extern long O4795[];
extern long O4796[];
extern long O4797[];
extern long O4798[];
extern long O4756[];
extern long O4765[];
extern long O4842[];
extern long O4801[];
extern long O4802[];
extern long O4806[];
extern long O4807[];
extern long O4808[];
extern EIF_TYPE_INDEX Y4792[];
extern EIF_TYPE_INDEX *Y4792_gen_type [];
extern EIF_TYPE_INDEX Y4793[];
extern EIF_TYPE_INDEX *Y4793_gen_type [];
extern EIF_TYPE_INDEX Y4448[];
extern EIF_TYPE_INDEX *Y4448_gen_type [];
extern EIF_TYPE_INDEX Y4259[];
extern EIF_TYPE_INDEX *Y4259_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
