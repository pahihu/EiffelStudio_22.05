
#ifndef _C34_ev1694_
#define _C34_ev1694_

#ifdef __cplusplus
extern "C" {
#endif

extern void F686_5559(EIF_REFERENCE);
extern void F686_5561(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F686_5562(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit1694(void);
extern void F688_5569(EIF_REFERENCE);
extern void F684_5552(EIF_REFERENCE);
extern char *(*R4892[])();
extern EIF_TYPE_INDEX Y4887[];
extern EIF_TYPE_INDEX *Y4887_gen_type [];
extern EIF_TYPE_INDEX Y4888[];
extern EIF_TYPE_INDEX *Y4888_gen_type [];
extern EIF_TYPE_INDEX Y4450[];
extern EIF_TYPE_INDEX *Y4450_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
