/*
 * Code for class INTERACTIVE_LIST [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "in1696.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {INTERACTIVE_LIST}.default_create */
void F682_5530 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F671_5447(Current, ((EIF_INTEGER_32) 4L));
}

/* {INTERACTIVE_LIST}.extend */
void F682_5535 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O4882[dtype-680]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	F671_5488(Current, arg1);
	*(EIF_BOOLEAN *)(Current + O4882[dtype-680]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	ti4_1 = F671_5468(Current);
	F682_5550(Current, arg1, ti4_1);
	RTLE;
}

/* {INTERACTIVE_LIST}.append */
void F682_5536 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = F671_5468(Current);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4462[Dtype(RTCW(arg1))-534])(arg1);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ti4_1);
	if ((EIF_BOOLEAN) (loc1 > F671_5469(Current))) {
		F671_5495(Current, loc1);
	}
	if ((EIF_BOOLEAN)(arg1 == Current)) {
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (arg1);
	} else {
		tr1 = arg1;
	}
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4258[Dtype(RTCV(tr1))-575])(tr1);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5251[Dtype(loc2)-701])(loc2);
		if (tb1) break;
		ti4_1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5250[Dtype(loc2)-701])(loc2));
		F682_5535(Current, ti4_1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5252[Dtype(loc2)-701])(loc2);
	}
	RTLE;
}

/* {INTERACTIVE_LIST}.put_left */
void F682_5537 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O4882[dtype-680]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	F671_5489(Current, arg1);
	*(EIF_BOOLEAN *)(Current + O4882[dtype-680]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	F682_5550(Current, arg1, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O4870[dtype-663]) - ((EIF_INTEGER_32) 1L)));
	RTLE;
}

/* {INTERACTIVE_LIST}.put_i_th */
void F682_5539 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = F671_5453(Current, arg2);
	*(EIF_BOOLEAN *)(Current + O4882[dtype-680]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	F671_5486(Current, arg1, arg2);
	*(EIF_BOOLEAN *)(Current + O4882[dtype-680]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	if (EIF_TRUE) {
		F682_5551(Current, loc1, arg2);
	}
	F682_5550(Current, arg1, arg2);
	RTLE;
}

/* {INTERACTIVE_LIST}.replace */
void F682_5540 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current + O4870[dtype-663]);
	loc2 = F671_5452(Current);
	*(EIF_BOOLEAN *)(Current + O4882[dtype-680]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	F671_5491(Current, arg1);
	*(EIF_BOOLEAN *)(Current + O4882[dtype-680]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	F682_5551(Current, loc2, loc1);
	F682_5550(Current, arg1, loc1);
	RTLE;
}

/* {INTERACTIVE_LIST}.remove */
void F682_5541 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current + O4870[dtype-663]);
	loc2 = F671_5452(Current);
	*(EIF_BOOLEAN *)(Current + O4882[dtype-680]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	F671_5501(Current);
	*(EIF_BOOLEAN *)(Current + O4882[dtype-680]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	F682_5551(Current, loc2, loc1);
	RTLE;
}

/* {INTERACTIVE_LIST}.prune_all */
void F682_5545 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,loc7);
	RTLIU(2);
	
	RTGC;
	loc5 = *(EIF_BOOLEAN *)(Current + O4307[dtype-335]);
	loc7 = F671_5451(Current);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	loc2 = F671_5468(Current);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == F671_5468(Current))) break;
		if ((EIF_BOOLEAN) (loc1 < (EIF_INTEGER_32) (loc2 - loc3))) {
			if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L))) {
				/* INLINED CODE (SPECIAL.item) */
				ti4_3 = *((EIF_INTEGER_32 *)RTCW(loc7) + ((EIF_INTEGER_32) (loc1 + loc3)));
				/* END INLINED CODE */
				ti4_1 = ti4_3;
				/* INLINED CODE (SPECIAL.put) */
				*((EIF_INTEGER_32 *)RTCW(loc7) + (loc1)) = ti4_1;
				/* END INLINED CODE */
				;
			}
			/* INLINED CODE (SPECIAL.item) */
			ti4_2 = *((EIF_INTEGER_32 *)RTCW(loc7) + (loc1));
			/* END INLINED CODE */
			loc6 = ti4_2;
			if (loc5) {
				loc4 = (EIF_BOOLEAN) (arg1 == loc6);
			} else {
				loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN)(arg1 == loc6);
			}
			if (loc4) {
				F682_5551(Current, loc6, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
				loc3++;
			} else {
				loc1++;
			}
		} else {
			loc1++;
		}
	}
	F872_6841(RTCW(loc7), loc3);
	ti4_1 = F671_5468(Current);
	*(EIF_INTEGER_32 *)(Current + O4870[dtype-663]) = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L));
	RTLE;
}

/* {INTERACTIVE_LIST}.wipe_out */
void F682_5547 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (F671_5451(Current));
	loc3 = F671_5468(Current);
	F671_5506(Current);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN)(loc2 == loc3)) break;
		/* INLINED CODE (SPECIAL.item) */
		ti4_2 = *((EIF_INTEGER_32 *)RTCW(loc1) + (loc2));
		/* END INLINED CODE */
		ti4_1 = ti4_2;
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R4879[Dtype(Current)-682])(Current, (EIF_REFERENCE) &ti4_1, ((EIF_INTEGER_32) 1L));
		loc2++;
	}
	RTLE;
}

/* {INTERACTIVE_LIST}.added_item */
void F682_5550 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O4882[dtype-680])) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R4878[dtype-682])(Current, (EIF_REFERENCE) &arg1, arg2);
	}
	RTLE;
}

/* {INTERACTIVE_LIST}.removed_item */
void F682_5551 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O4882[dtype-680])) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R4879[dtype-682])(Current, (EIF_REFERENCE) &arg1, arg2);
	}
	RTLE;
}

void EIF_Minit1696 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
