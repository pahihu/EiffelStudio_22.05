
#ifndef _C34_pr1665_
#define _C34_pr1665_

#ifdef __cplusplus
extern "C" {
#endif

extern void F256_4036(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F256_4037(EIF_REFERENCE);
extern EIF_BOOLEAN F256_4039(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1665(void);

#ifdef __cplusplus
}
#endif

#endif
