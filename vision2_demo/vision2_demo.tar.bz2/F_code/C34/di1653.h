
#ifndef _C34_di1653_
#define _C34_di1653_

#ifdef __cplusplus
extern "C" {
#endif

extern void F532_4837(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1653(void);
extern void F537_4876(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
