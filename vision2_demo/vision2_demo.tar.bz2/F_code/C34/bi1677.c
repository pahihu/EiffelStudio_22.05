/*
 * Code for class BINARY_TREE [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "bi1677.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BINARY_TREE}.make */
void F349_4659 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTCCL(arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {BINARY_TREE}.child_index */
EIF_INTEGER_32 F349_4661 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_1_0_0_);
}


/* {BINARY_TREE}.child */
EIF_REFERENCE F349_4668 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	switch (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_1_0_0_)) {
		case 1L:
			Result = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			break;
		case 2L:
			Result = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			break;
		default:
			Result = (EIF_REFERENCE) NULL;
			break;
	}
	RTLE;
	return Result;
}

/* {BINARY_TREE}.child_cursor */
EIF_REFERENCE F349_4669 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(247, 0x00).id, 247, _OBJSIZ_0_0_0_1_0_0_0_0_);
	F248_3896(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_1_0_0_));
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {BINARY_TREE}.child_capacity */
EIF_INTEGER_32 F349_4673 (EIF_REFERENCE Current)
{
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
}

/* {BINARY_TREE}.child_after */
EIF_BOOLEAN F349_4674 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_1_0_0_) >= (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) + ((EIF_INTEGER_32) 1L)));
}

/* {BINARY_TREE}.is_leaf */
EIF_BOOLEAN F349_4675 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_2_) == NULL) && (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_3_) == NULL));
}

/* {BINARY_TREE}.has_left */
EIF_BOOLEAN F349_4677 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_2_) != NULL);
}

/* {BINARY_TREE}.has_right */
EIF_BOOLEAN F349_4678 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_3_) != NULL);
}

/* {BINARY_TREE}.child_go_to */
void F349_4680 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_1_0_0_) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

/* {BINARY_TREE}.child_start */
void F349_4681 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (F349_4677(Current)) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		if (F349_4678(Current)) {
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		} else {
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		}
	}
	RTLE;
}

/* {BINARY_TREE}.child_forth */
void F349_4683 (EIF_REFERENCE Current)
{
	GTCX
	
	
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_1_0_0_))++;
}

/* {BINARY_TREE}.child_go_i_th */
void F349_4685 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_1_0_0_) = (EIF_INTEGER_32) arg1;
}

/* {BINARY_TREE}.put_left_child */
void F349_4686 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_)) {
			F336_4588(RTCW(arg1));
		} else {
			F336_4589(RTCW(arg1));
		}
	}
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		F348_4650(RTCW(loc1), NULL);
	}
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		F348_4650(RTCW(arg1), Current);
	}
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	RTLE;
}

/* {BINARY_TREE}.put_right_child */
void F349_4687 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_)) {
			F336_4588(RTCW(arg1));
		} else {
			F336_4589(RTCW(arg1));
		}
	}
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		F348_4650(RTCW(loc1), NULL);
	}
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		F348_4650(RTCW(arg1), Current);
	}
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
	RTLE;
}

/* {BINARY_TREE}.put_child */
void F349_4690 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_)) {
		F336_4588(RTCW(arg1));
	} else {
		F336_4589(RTCW(arg1));
	}
	F348_4650(RTCW(arg1), NULL);
	tb1 = '\0';
	if ((EIF_BOOLEAN) !F349_4677(Current)) {
		tb1 = (EIF_BOOLEAN) !F349_4678(Current);
	}
	if (tb1) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	switch (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_1_0_0_)) {
		case 1L:
			F349_4686(Current, arg1);
			break;
		case 2L:
			F349_4687(Current, arg1);
			break;
		default:
			RTEC(EN_WHEN);
	}
	RTLE;
}

/* {BINARY_TREE}.fill_list */
void F349_4701 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		tr2 = RTCCL(tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4436[Dtype(RTCW(arg1))-534])(arg1, tr2);
		F349_4701(RTCW(loc1), arg1);
	}
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		tr2 = RTCCL(tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4436[Dtype(RTCW(arg1))-534])(arg1, tr2);
		F349_4701(RTCW(loc1), arg1);
	}
	RTLE;
}

/* {BINARY_TREE}.clone_node */
EIF_REFERENCE F349_4702 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	Result = RTLNSMART(Dftype(Current));
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	tr2 = RTCCL(tr1);
	F349_4659(RTCW(Result), tr2);
	F349_4703(RTCW(Result), arg1);
	RTLE;
	return Result;
}

/* {BINARY_TREE}.copy_node */
void F349_4703 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	eif_builtin_ANY_standard_copy__o_ (Current, arg1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
	RTLE;
}

/* {BINARY_TREE}.subtree_count */
EIF_INTEGER_32 F349_4705 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		Result = F348_4604(RTCW(loc1));
	}
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		ti4_1 = F348_4604(RTCW(loc1));
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	}
	RTLE;
	return Result;
}

void EIF_Minit1677 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
