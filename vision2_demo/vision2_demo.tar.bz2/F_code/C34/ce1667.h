
#ifndef _C34_ce1667_
#define _C34_ce1667_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_32 F184_3357(EIF_REFERENCE);
extern void F184_3358(EIF_REFERENCE, EIF_CHARACTER_32);
extern void F184_3359(EIF_REFERENCE, EIF_CHARACTER_32);
extern void EIF_Minit1667(void);

#ifdef __cplusplus
}
#endif

#endif
