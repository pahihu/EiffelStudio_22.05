
#ifndef _C34_in1699_
#define _C34_in1699_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F480_4795(EIF_REFERENCE);
extern void EIF_Minit1699(void);

#ifdef __cplusplus
}
#endif

#endif
