
#ifndef _C34_he1681_
#define _C34_he1681_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F535_4843(EIF_REFERENCE);
extern EIF_BOOLEAN F535_4844(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F535_4846(EIF_REFERENCE);
extern EIF_INTEGER_32 F535_4847(EIF_REFERENCE);
extern EIF_BOOLEAN F535_4850(EIF_REFERENCE);
extern EIF_BOOLEAN F535_4853(EIF_REFERENCE, EIF_REFERENCE);
extern void F535_4855(EIF_REFERENCE, EIF_REFERENCE);
extern void F535_4856(EIF_REFERENCE, EIF_REFERENCE);
extern void F535_4857(EIF_REFERENCE, EIF_REFERENCE);
extern void F535_4859(EIF_REFERENCE);
extern void F535_4860(EIF_REFERENCE, EIF_REFERENCE);
extern void F535_4861(EIF_REFERENCE);
extern EIF_REFERENCE F535_4864(EIF_REFERENCE);
extern EIF_REFERENCE F535_4867(EIF_REFERENCE, EIF_INTEGER_32);
extern void F535_4868(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F535_4869(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F535_4871(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1681(void);
extern EIF_BOOLEAN F483_4817(EIF_REFERENCE);
extern EIF_BOOLEAN F495_4819(EIF_REFERENCE);
extern char *(*R4436[])();
extern char *(*R5951[])();
extern char *(*R5952[])();
extern char *(*R5252[])();
extern char *(*R4485[])();
extern char *(*R4258[])();
extern char *(*R5965[])();
extern char *(*R5966[])();
extern char *(*R5979[])();
extern char *(*R4462[])();
extern char *(*R4856[])();
extern char *(*R3774[])();
extern char *(*R5985[])();
extern char *(*R5250[])();
extern char *(*R5251[])();
extern EIF_TYPE_INDEX Y4259[];
extern EIF_TYPE_INDEX *Y4259_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
