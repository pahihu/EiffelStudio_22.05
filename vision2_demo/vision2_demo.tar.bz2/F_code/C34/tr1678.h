
#ifndef _C34_tr1678_
#define _C34_tr1678_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F702_5935(EIF_REFERENCE);
extern EIF_BOOLEAN F702_5936(EIF_REFERENCE);
extern void F702_5937(EIF_REFERENCE);
extern void EIF_Minit1678(void);
extern EIF_BOOLEAN F348_4608(EIF_REFERENCE);
extern EIF_REFERENCE F349_4668(EIF_REFERENCE);
extern void F349_4680(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F349_4669(EIF_REFERENCE);
extern void F349_4685(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F489_4817(EIF_REFERENCE);
extern char *(*R4450[])();
extern char *(*R4454[])();
extern char *(*R4455[])();
extern char *(*R4435[])();
extern long O3285[];

#ifdef __cplusplus
}
#endif

#endif
