
#ifndef _C34_dy1663_
#define _C34_dy1663_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F428_4783(EIF_REFERENCE);
extern void EIF_Minit1663(void);

#ifdef __cplusplus
}
#endif

#endif
