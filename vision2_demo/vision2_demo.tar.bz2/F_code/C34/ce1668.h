
#ifndef _C34_ce1668_
#define _C34_ce1668_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F185_3357(EIF_REFERENCE);
extern void F185_3358(EIF_REFERENCE, EIF_BOOLEAN);
extern void F185_3359(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit1668(void);
extern long O3285[];

#ifdef __cplusplus
}
#endif

#endif
