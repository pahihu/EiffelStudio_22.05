/*
 * Code for class FUNCTION [G#1, INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "fu1675.h"
#include "eif_rout_obj.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F1076_9391
static EIF_INTEGER_32 inline_F1076_9391 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	#ifdef WORKBENCH
	EIF_INTEGER_32 result;
	if (arg1 != 0) {
		return (FUNCTION_CAST(EIF_TYPED_VALUE, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE)) arg1)(
			arg2, arg3, arg4).it_i4;
	} else {
		rout_obj_call_function_dynamic (
			arg5,
			arg6,
			arg7,
			arg3,
			arg8,
			arg4,
			arg9,
			arg10, 
			&result);
		return result;
	}
#else
	return (FUNCTION_CAST(EIF_INTEGER_32, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE)) arg1)(
		arg2, arg3, arg4);
#endif
	;
}
#define INLINE_F1076_9391
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {FUNCTION}.last_result */
EIF_INTEGER_32 F1076_9382 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_2_0_3_);
}


/* {FUNCTION}.call */
void F1076_9383 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	ti4_1 = ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(Current+ _PTROFF_4_2_0_4_0_2_))(
		*(EIF_POINTER *)(Current+ _PTROFF_4_2_0_4_0_1_),
		*(EIF_REFERENCE *)(Current + _REFACS_1_), arg1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_2_0_3_) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

/* {FUNCTION}.item */
EIF_INTEGER_32 F1076_9384 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	loc1 = F1071_9361(Current);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_4_2_0_4_0_2_);
	tp2 = *(EIF_POINTER *)(Current+ _PTROFF_4_2_0_4_0_1_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_2_0_1_);
	tb1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_);
	ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_2_0_2_);
	ti4_3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_2_0_0_);
	RTLE;
	return (EIF_INTEGER_32) inline_F1076_9391(tp1, tp2, *(EIF_REFERENCE *)(Current + _REFACS_1_), arg1, ti4_1, tb1, ti4_2, loc1, ti4_3, *(EIF_REFERENCE *)(Current + _REFACS_2_));
}

/* {FUNCTION}.is_equal */
EIF_BOOLEAN F1076_9386 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	Result = '\0';
	if (F1071_9348(Current, arg1)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_2_0_3_);
		Result = (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_2_0_3_) == ti4_1);
	}
	RTLE;
	return Result;
}

/* {FUNCTION}.copy */
void F1076_9387 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		F1071_9355(Current, arg1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_2_0_3_);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_2_0_3_) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

/* {FUNCTION}.flexible_item */
EIF_INTEGER_32 F1076_9390 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,loc3);
	RTLR(4,loc4);
	RTLR(5,tr1);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(arg1 != NULL)) {
		RTLE;
		return (EIF_INTEGER_32) (FUNCTION_CAST(EIF_INTEGER_32, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(Current+ _PTROFF_4_2_0_4_0_2_))(
			*(EIF_POINTER *)(Current+ _PTROFF_4_2_0_4_0_1_),
			*(EIF_REFERENCE *)(Current + _REFACS_1_), loc1);
	} else {
		loc3 = arg1;
		loc3 = RTRV(eif_gen_param(dftype, 1),loc3);
		if (EIF_TEST(loc3)) {
			RTLE;
			return (EIF_INTEGER_32) (FUNCTION_CAST(EIF_INTEGER_32, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(Current+ _PTROFF_4_2_0_4_0_2_))(
				*(EIF_POINTER *)(Current+ _PTROFF_4_2_0_4_0_1_),
				*(EIF_REFERENCE *)(Current + _REFACS_1_), loc3);
		} else {
			RTCT0("from_precondition", EX_CHECK);
			tr1 = RTLNTY2(eif_gen_param(dftype, 1), 0x00);
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7003[Dtype(tr1)-964])(tr1);
			tr1 = (EIF_REFERENCE) eif_builtin_ISE_RUNTIME_new_tuple_instance_of__i4_u (ti4_1);
			loc4 = tr1;
			loc4 = RTRV(eif_gen_param(dftype, 1),loc4);
			if (EIF_TEST(loc4)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tb1 = (EIF_BOOLEAN) eif_builtin_TUPLE_object_comparison__b (arg1);
			if (tb1) {
				F998_8184(loc4);
			}
			loc2 = (EIF_INTEGER_32) eif_builtin_TUPLE_count__i4 (loc4);
			for (;;) {
				if ((EIF_BOOLEAN) (loc2 <= ((EIF_INTEGER_32) 0L))) break;
				tr1 = F998_8160(RTCW(arg1), loc2);
				tr2 = RTCCL(tr1);
				F998_8193(loc4, tr2, loc2);
				loc2--;
			}
			Result = Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(Current+ _PTROFF_4_2_0_4_0_2_))(
				*(EIF_POINTER *)(Current+ _PTROFF_4_2_0_4_0_1_),
				*(EIF_REFERENCE *)(Current + _REFACS_1_), loc4);
		}
	}
	RTLE;
	return Result;
}

/* {FUNCTION}.fast_item */
EIF_INTEGER_32 F1076_9391 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F1076_9391 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_POINTER) arg3, (EIF_POINTER) arg4, (EIF_INTEGER_32) arg5, (EIF_BOOLEAN) arg6, (EIF_INTEGER_32) arg7, (EIF_INTEGER_32) arg8, (EIF_INTEGER_32) arg9, (EIF_POINTER) arg10);
	return Result;
}

void EIF_Minit1675 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
