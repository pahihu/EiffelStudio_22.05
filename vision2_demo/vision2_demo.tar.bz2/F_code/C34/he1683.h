
#ifndef _C34_he1683_
#define _C34_he1683_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F704_5948(EIF_REFERENCE);
extern EIF_BOOLEAN F704_5949(EIF_REFERENCE);
extern void F704_5950(EIF_REFERENCE);
extern void EIF_Minit1683(void);
extern char *(*R4485[])();

#ifdef __cplusplus
}
#endif

#endif
