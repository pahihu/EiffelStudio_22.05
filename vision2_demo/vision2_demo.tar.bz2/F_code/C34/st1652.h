
#ifndef _C34_st1652_
#define _C34_st1652_

#ifdef __cplusplus
extern "C" {
#endif

extern void F537_4876(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1652(void);
extern EIF_BOOLEAN F610_5037(EIF_REFERENCE);
extern void F677_5514(EIF_REFERENCE, EIF_INTEGER_32);
extern void F671_5447(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F671_5452(EIF_REFERENCE);
extern void F677_5517(EIF_REFERENCE);
extern EIF_BOOLEAN F489_4817(EIF_REFERENCE);
extern char *(*R4436[])();
extern char *(*R4414[])();
extern char *(*R4415[])();
extern char *(*R4416[])();
extern char *(*R4429[])();
extern EIF_TYPE_INDEX Y4259[];
extern EIF_TYPE_INDEX *Y4259_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
