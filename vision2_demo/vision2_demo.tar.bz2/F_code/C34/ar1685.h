
#ifndef _C34_ar1685_
#define _C34_ar1685_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F703_5941(EIF_REFERENCE);
extern EIF_BOOLEAN F703_5942(EIF_REFERENCE);
extern void F703_5943(EIF_REFERENCE);
extern void EIF_Minit1685(void);
extern char *(*R5951[])();
extern char *(*R4485[])();

#ifdef __cplusplus
}
#endif

#endif
