
#ifndef _C34_ac1693_
#define _C34_ac1693_

#ifdef __cplusplus
extern "C" {
#endif

extern void F683_5552(EIF_REFERENCE);
extern void F683_5556(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F683_5557(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit1693(void);
extern void F681_5530(EIF_REFERENCE);
extern void F688_5569(EIF_REFERENCE);
extern char *(*R4575[])();
extern char *(*R4892[])();
extern long O4870[];
extern EIF_TYPE_INDEX Y4450[];
extern EIF_TYPE_INDEX *Y4450_gen_type [];
extern EIF_TYPE_INDEX Y4885[];
extern EIF_TYPE_INDEX *Y4885_gen_type [];
extern EIF_TYPE_INDEX Y4886[];
extern EIF_TYPE_INDEX *Y4886_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
