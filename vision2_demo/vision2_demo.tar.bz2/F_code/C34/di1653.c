/*
 * Code for class DISPENSER [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "di1653.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DISPENSER}.append */
void F532_4837 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F537_4876(Current, arg1);
}

void EIF_Minit1653 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
