/*
 * Code for class HEAP_PRIORITY_QUEUE [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "he1681.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {HEAP_PRIORITY_QUEUE}.item */
EIF_REFERENCE F535_4843 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	RTLE;
	return (EIF_REFERENCE) F535_4867(Current, ((EIF_INTEGER_32) 1L));
}

/* {HEAP_PRIORITY_QUEUE}.has */
EIF_BOOLEAN F535_4844 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc3 = *(EIF_REFERENCE *)(Current);
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5951[Dtype(RTCW(loc3))-864])(loc3);
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) && (EIF_BOOLEAN)(arg1 != NULL))) {
		for (;;) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == loc2) || Result)) break;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4485[Dtype(RTCW(loc3))-575])(loc3, loc1);
			Result = (EIF_BOOLEAN) RTEQ(tr1, arg1);
			loc1++;
		}
	} else {
		for (;;) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == loc2) || Result)) break;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4485[Dtype(RTCW(loc3))-575])(loc3, loc1);
			Result = (EIF_BOOLEAN) RTCEQ(tr1, arg1);
			loc1++;
		}
	}
	RTLE;
	return Result;
}

/* {HEAP_PRIORITY_QUEUE}.count */
EIF_INTEGER_32 F535_4846 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5951[Dtype(RTCW(tr1))-864])(tr1);
	RTLE;
	return Result;
}

/* {HEAP_PRIORITY_QUEUE}.capacity */
EIF_INTEGER_32 F535_4847 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5952[Dtype(RTCW(tr1))-864])(tr1);
	RTLE;
	return Result;
}

/* {HEAP_PRIORITY_QUEUE}.extendible */
EIF_BOOLEAN F535_4850 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = F495_4819(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTLE;
	return Result;
}

/* {HEAP_PRIORITY_QUEUE}.is_equal */
EIF_BOOLEAN F535_4853 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == Current)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tb1 = '\0';
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_0_);
		if ((EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) == tb2)) {
			ti4_1 = F535_4846(RTCW(arg1));
			tb1 = (EIF_BOOLEAN)(F535_4846(Current) == ti4_1);
		}
		if (tb1) {
			loc1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (Current);
			loc2 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (arg1);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			for (;;) {
				tb1 = '\01';
				if (!(EIF_BOOLEAN) !Result) {
					tb2 = F483_4817(RTCW(loc1));
					tb1 = tb2;
				}
				if (tb1) break;
				if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
					tr1 = F535_4843(RTCW(loc1));
					tr2 = F535_4843(RTCW(loc2));
					Result = (EIF_BOOLEAN) RTEQ(tr1, tr2);
				} else {
					tr1 = F535_4843(RTCW(loc1));
					tr2 = F535_4843(RTCW(loc2));
					Result = (EIF_BOOLEAN) RTCEQ(tr1, tr2);
				}
				F535_4859(RTCW(loc1));
				F535_4859(RTCW(loc2));
			}
		}
	}
	RTLE;
	return Result;
}

/* {HEAP_PRIORITY_QUEUE}.put */
void F535_4855 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	loc1 = F535_4846(Current);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (loc1 <= ((EIF_INTEGER_32) 1L))) {
			tr1 = F535_4867(Current, (EIF_INTEGER_32) (loc1 / ((EIF_INTEGER_32) 2L)));
			tr2 = RTCCL(tr1);
			tr3 = RTCCL(arg1);
			tb1 = (EIF_BOOLEAN) !F535_4871(Current, tr2, tr3);
		}
		if (tb1) break;
		tr1 = F535_4867(Current, (EIF_INTEGER_32) (loc1 / ((EIF_INTEGER_32) 2L)));
		tr2 = RTCCL(tr1);
		F535_4869(Current, tr2, loc1);
		loc1 /= ((EIF_INTEGER_32) 2L);
	}
	tr1 = RTCCL(arg1);
	F535_4869(Current, tr1, loc1);
	RTLE;
}

/* {HEAP_PRIORITY_QUEUE}.extend */
void F535_4856 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTCCL(arg1);
	F535_4855(Current, tr1);
	RTLE;
}

/* {HEAP_PRIORITY_QUEUE}.copy */
void F535_4857 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		eif_builtin_ANY_standard_copy__o_ (Current, arg1);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {HEAP_PRIORITY_QUEUE}.remove */
void F535_4859 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLIU(6);
	
	RTGC;
	loc4 = F535_4846(Current);
	loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 - ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 0L))) {
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		loc3 = F535_4867(Current, (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L)));
		for (;;) {
			if ((EIF_BOOLEAN) (loc5 || (EIF_BOOLEAN) (loc1 > (EIF_INTEGER_32) (loc4 / ((EIF_INTEGER_32) 2L))))) break;
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * loc1);
			tb1 = '\0';
			if ((EIF_BOOLEAN) (loc2 < loc4)) {
				tr1 = F535_4867(Current, loc2);
				tr2 = RTCCL(tr1);
				tr3 = F535_4867(Current, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
				tr4 = RTCCL(tr3);
				tb1 = F535_4871(Current, tr2, tr4);
			}
			if (tb1) {
				loc2++;
			}
			tr1 = RTCCL(loc3);
			tr2 = F535_4867(Current, loc2);
			tr3 = RTCCL(tr2);
			loc5 = F535_4871(Current, tr1, tr3);
			loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc5;
			if ((EIF_BOOLEAN) !loc5) {
				tr1 = F535_4867(Current, loc2);
				tr2 = RTCCL(tr1);
				F535_4868(Current, tr2, loc1);
				loc1 = (EIF_INTEGER_32) loc2;
			}
		}
		tr1 = RTCCL(loc3);
		F535_4868(Current, tr1, loc1);
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R5979[Dtype(RTCW(tr1))-864])(tr1, ((EIF_INTEGER_32) 1L));
	RTLE;
}

/* {HEAP_PRIORITY_QUEUE}.prune */
void F535_4860 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,loc4);
	RTLR(3,arg1);
	RTLR(4,tr1);
	RTLR(5,loc6);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {663,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y4259,Y4259_gen_type,Dftype(Current),315);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		loc3 = RTLNS(typres0.id, 663, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	ti4_1 = F535_4846(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R4856[Dtype(RTCW(loc3))-663])(loc3, ti4_1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		loc2 = F535_4846(Current);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			loc4 = F535_4867(Current, loc1);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc5 && RTEQ(loc4, arg1))) {
				loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				tr1 = RTCCL(loc4);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4436[Dtype(RTCW(loc3))-534])(loc3, tr1);
			}
			loc1++;
		}
	} else {
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		loc2 = F535_4846(Current);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			loc4 = F535_4867(Current, loc1);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc5 && RTCEQ(loc4, arg1))) {
				loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				tr1 = RTCCL(loc4);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4436[Dtype(RTCW(loc3))-534])(loc3, tr1);
			}
			loc1++;
		}
	}
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4462[Dtype(RTCW(loc3))-534])(loc3);
	if ((EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (F535_4846(Current) - ((EIF_INTEGER_32) 1L)))) {
		F535_4861(Current);
		loc6 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4258[Dtype(RTCW(loc3))-575])(loc3);
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5251[Dtype(loc6)-701])(loc6);
			if (tb1) break;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5250[Dtype(loc6)-701])(loc6);
			tr2 = RTCCL(tr1);
			F535_4855(Current, tr2);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5252[Dtype(loc6)-701])(loc6);
		}
	}
	RTLE;
}

/* {HEAP_PRIORITY_QUEUE}.wipe_out */
void F535_4861 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5985[Dtype(RTCW(tr1))-864])(tr1);
	RTLE;
}

/* {HEAP_PRIORITY_QUEUE}.linear_representation */
EIF_REFERENCE F535_4864 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	loc1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {663,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y4259,Y4259_gen_type,Dftype(Current),315);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		Result = RTLNS(typres0.id, 663, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	ti4_1 = F535_4846(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R4856[Dtype(RTCW(Result))-663])(Result, ti4_1);
	for (;;) {
		tb1 = F483_4817(RTCW(loc1));
		if (tb1) break;
		tr1 = F535_4843(RTCW(loc1));
		tr2 = RTCCL(tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4436[Dtype(RTCW(Result))-534])(Result, tr2);
		F535_4859(RTCW(loc1));
	}
	RTLE;
	return Result;
}

/* {HEAP_PRIORITY_QUEUE}.i_th */
EIF_REFERENCE F535_4867 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4485[Dtype(RTCW(tr1))-575])(tr1, (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)));
	RTLE;
	return Result;
}

/* {HEAP_PRIORITY_QUEUE}.put_i_th */
void F535_4868 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTCCL(arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R5965[Dtype(RTCW(tr1))-864])(tr1, tr2, (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)));
	RTLE;
}

/* {HEAP_PRIORITY_QUEUE}.force_i_th */
void F535_4869 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTCCL(arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R5966[Dtype(RTCW(tr1))-864])(tr1, tr2, (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)));
	RTLE;
}

/* {HEAP_PRIORITY_QUEUE}.safe_less_than */
EIF_BOOLEAN F535_4871 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && (EIF_BOOLEAN)(arg2 != NULL))) {
		tr1 = RTCCL(arg2);
		Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R3774[Dtype(RTCW(arg1))-255])(arg1, tr1);
	} else {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 == NULL) && (EIF_BOOLEAN)(arg2 != NULL))) {
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit1681 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
