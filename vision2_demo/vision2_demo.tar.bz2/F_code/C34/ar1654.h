
#ifndef _C34_ar1654_
#define _C34_ar1654_

#ifdef __cplusplus
extern "C" {
#endif

extern void F677_5514(EIF_REFERENCE, EIF_INTEGER_32);
extern void F677_5515(EIF_REFERENCE, EIF_INTEGER_32);
extern void F677_5517(EIF_REFERENCE);
extern EIF_REFERENCE F677_5518(EIF_REFERENCE);
extern void EIF_Minit1654(void);
extern void F671_5488(EIF_REFERENCE, EIF_INTEGER_32);
extern void F671_5501(EIF_REFERENCE);
extern void F671_5447(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F671_5453(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F671_5468(EIF_REFERENCE);
extern void F671_5479(EIF_REFERENCE);
extern char *(*R4436[])();
extern EIF_TYPE_INDEX Y4259[];
extern EIF_TYPE_INDEX *Y4259_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
