/*
 * Code for class CELL [BOOLEAN]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ce1668.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CELL}.item */
EIF_BOOLEAN F185_3357 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current + O3285[Dtype(Current)-180]);
}


/* {CELL}.put */
void F185_3358 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O3285[Dtype(Current)-180]) = (EIF_BOOLEAN) arg1;
}

/* {CELL}.replace */
void F185_3359 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O3285[Dtype(Current)-180]) = (EIF_BOOLEAN) arg1;
}

void EIF_Minit1668 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
