
#ifndef _C34_li1680_
#define _C34_li1680_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F642_5110(EIF_REFERENCE);
extern void F642_5111(EIF_REFERENCE, EIF_REFERENCE);
extern void F642_5112(EIF_REFERENCE, EIF_REFERENCE);
extern void F642_5113(EIF_REFERENCE, EIF_REFERENCE);
extern void F642_5114(EIF_REFERENCE);
extern EIF_REFERENCE F642_5115(EIF_REFERENCE);
extern void EIF_Minit1680(void);
extern char *(*R4436[])();
extern char *(*R3285[])();
extern char *(*R4604[])();
extern char *(*R4605[])();
extern char *(*R4456[])();
extern char *(*R4458[])();
extern char *(*R4416[])();
extern char *(*R4582[])();
extern char *(*R4856[])();
extern char *(*R4429[])();
extern EIF_TYPE_INDEX Y4259[];
extern EIF_TYPE_INDEX *Y4259_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
