
#ifndef _C34_ac1695_
#define _C34_ac1695_

#ifdef __cplusplus
extern "C" {
#endif

extern void F684_5552(EIF_REFERENCE);
extern void F684_5556(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F684_5557(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit1695(void);
extern void F682_5530(EIF_REFERENCE);
extern void F688_5569(EIF_REFERENCE);
extern void F671_5482(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R4892[])();
extern long O4870[];
extern EIF_TYPE_INDEX Y4450[];
extern EIF_TYPE_INDEX *Y4450_gen_type [];
extern EIF_TYPE_INDEX Y4885[];
extern EIF_TYPE_INDEX *Y4885_gen_type [];
extern EIF_TYPE_INDEX Y4886[];
extern EIF_TYPE_INDEX *Y4886_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
