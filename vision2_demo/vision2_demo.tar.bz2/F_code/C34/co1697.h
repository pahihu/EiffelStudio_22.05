
#ifndef _C34_co1697_
#define _C34_co1697_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F482_4798(EIF_REFERENCE);
extern EIF_INTEGER_32 F482_4799(EIF_REFERENCE);
extern EIF_BOOLEAN F482_4800(EIF_REFERENCE);
extern EIF_BOOLEAN F482_4801(EIF_REFERENCE);
extern void F482_4806(EIF_REFERENCE);
extern void F482_4807(EIF_REFERENCE);
extern void F482_4808(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F482_4810(EIF_REFERENCE);
extern void F482_4811(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit1697(void);
extern void F640_5063(EIF_REFERENCE);
extern char *(*R4460[])();
extern long O4461[];
extern EIF_TYPE_INDEX Y4259[];
extern EIF_TYPE_INDEX *Y4259_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
