
#ifndef _C34_bi1676_
#define _C34_bi1676_

#ifdef __cplusplus
extern "C" {
#endif

extern void F350_4708(EIF_REFERENCE, EIF_REFERENCE);
extern void F350_4720(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F350_4732(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1676(void);
extern void F336_4588(EIF_REFERENCE);
extern void F181_3359(EIF_REFERENCE, EIF_REFERENCE);
extern void F349_4686(EIF_REFERENCE, EIF_REFERENCE);
extern void F349_4687(EIF_REFERENCE, EIF_REFERENCE);
extern void F349_4659(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R3774[])();
extern EIF_TYPE_INDEX Y4375[];
extern EIF_TYPE_INDEX *Y4375_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
