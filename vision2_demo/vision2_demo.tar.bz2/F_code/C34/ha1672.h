
#ifndef _C34_ha1672_
#define _C34_ha1672_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F756_6070(EIF_REFERENCE);
extern EIF_REFERENCE F756_6071(EIF_REFERENCE);
extern EIF_BOOLEAN F756_6073(EIF_REFERENCE);
extern void F756_6074(EIF_REFERENCE);
extern EIF_REFERENCE F756_6075(EIF_REFERENCE);
extern void EIF_Minit1672(void);
extern EIF_BOOLEAN F745_6056(EIF_REFERENCE);
extern char *(*R5951[])();
extern char *(*R4485[])();
extern char *(*R4783[])();
extern char *(*R4784[])();

#ifdef __cplusplus
}
#endif

#endif
