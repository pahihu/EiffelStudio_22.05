/*
 * Code for class ARRAYED_QUEUE_ITERATION_CURSOR [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ar1685.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ARRAYED_QUEUE_ITERATION_CURSOR}.item */
EIF_REFERENCE F703_5941 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R4485[Dtype(RTCW(tr1))-575])(tr1, *(EIF_INTEGER_32 *)(Current + _REFACS_1_));
	RTLE;
	return Result;
}

/* {ARRAYED_QUEUE_ITERATION_CURSOR}.after */
EIF_BOOLEAN F703_5942 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + _REFACS_2_) == ((EIF_INTEGER_32) 0L));
}

/* {ARRAYED_QUEUE_ITERATION_CURSOR}.forth */
void F703_5943 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	(*(EIF_INTEGER_32 *)(Current + _REFACS_1_))++;
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5951[Dtype(RTCW(tr1))-864])(tr1);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + _REFACS_1_) >= ti4_1)) {
		*(EIF_INTEGER_32 *)(Current + _REFACS_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	}
	(*(EIF_INTEGER_32 *)(Current + _REFACS_2_))--;
	RTLE;
}

void EIF_Minit1685 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
