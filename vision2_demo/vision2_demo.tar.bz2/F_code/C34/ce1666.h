
#ifndef _C34_ce1666_
#define _C34_ce1666_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_64 F183_3357(EIF_REFERENCE);
extern void F183_3358(EIF_REFERENCE, EIF_NATURAL_64);
extern void F183_3359(EIF_REFERENCE, EIF_NATURAL_64);
extern void EIF_Minit1666(void);

#ifdef __cplusplus
}
#endif

#endif
