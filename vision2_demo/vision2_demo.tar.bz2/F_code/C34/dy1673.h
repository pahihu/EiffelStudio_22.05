
#ifndef _C34_dy1673_
#define _C34_dy1673_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F436_4783(EIF_REFERENCE);
extern void EIF_Minit1673(void);

#ifdef __cplusplus
}
#endif

#endif
