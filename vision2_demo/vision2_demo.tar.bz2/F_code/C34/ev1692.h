
#ifndef _C34_ev1692_
#define _C34_ev1692_

#ifdef __cplusplus
extern "C" {
#endif

extern void F685_5559(EIF_REFERENCE);
extern void F685_5561(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F685_5562(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit1692(void);
extern void F688_5569(EIF_REFERENCE);
extern void F683_5552(EIF_REFERENCE);
extern char *(*R4892[])();
extern EIF_TYPE_INDEX Y4887[];
extern EIF_TYPE_INDEX *Y4887_gen_type [];
extern EIF_TYPE_INDEX Y4888[];
extern EIF_TYPE_INDEX *Y4888_gen_type [];
extern EIF_TYPE_INDEX Y4450[];
extern EIF_TYPE_INDEX *Y4450_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
