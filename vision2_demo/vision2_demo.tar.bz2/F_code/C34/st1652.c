/*
 * Code for class STACK [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "st1652.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {STACK}.fill */
void F537_4876 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {676,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y4259,Y4259_gen_type,Dftype(Current),315);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		loc1 = RTLNS(typres0.id, 676, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F671_5447(RTCW(loc1), ((EIF_INTEGER_32) 0L));
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4416[Dtype(RTCW(arg1))-638])(arg1);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4415[Dtype(RTCW(arg1))-638])(arg1);
		if (tb1) break;
		ti4_1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4414[Dtype(RTCW(arg1))-638])(arg1));
		F677_5514(RTCW(loc1), ti4_1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R4429[Dtype(RTCW(arg1))-638])(arg1);
	}
	for (;;) {
		tb2 = '\01';
		tb3 = F489_4817(RTCW(loc1));
		if (!tb3) {
			tb2 = (EIF_BOOLEAN) !F610_5037(Current);
		}
		if (tb2) break;
		ti4_1 = F671_5452(RTCW(loc1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4436[Dtype(Current)-534])(Current, (EIF_REFERENCE) &ti4_1);
		F677_5517(RTCW(loc1));
	}
	RTLE;
}

void EIF_Minit1652 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
