
#ifndef _C34_dy1690_
#define _C34_dy1690_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F438_4783(EIF_REFERENCE);
extern void EIF_Minit1690(void);

#ifdef __cplusplus
}
#endif

#endif
