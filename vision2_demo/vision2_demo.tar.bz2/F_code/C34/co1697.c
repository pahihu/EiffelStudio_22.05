/*
 * Code for class COUNTABLE_SEQUENCE [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co1697.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {COUNTABLE_SEQUENCE}.index */
EIF_INTEGER_32 F482_4798 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O4461[Dtype(Current)-481]);
}


/* {COUNTABLE_SEQUENCE}.item */
EIF_INTEGER_32 F482_4799 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	
	
	return (EIF_INTEGER_32) (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4460[dtype-706])(Current, *(EIF_INTEGER_32 *)(Current + O4461[dtype-481]));
}

/* {COUNTABLE_SEQUENCE}.after */
EIF_BOOLEAN F482_4800 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_FALSE;
}

/* {COUNTABLE_SEQUENCE}.extendible */
EIF_BOOLEAN F482_4801 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_FALSE;
}

/* {COUNTABLE_SEQUENCE}.forth */
void F482_4806 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	
	
	(*(EIF_INTEGER_32 *)(Current + O4461[dtype-481]))++;
}

/* {COUNTABLE_SEQUENCE}.start */
void F482_4807 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O4461[Dtype(Current)-481]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
}

/* {COUNTABLE_SEQUENCE}.extend */
void F482_4808 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	RTGC;
}

/* {COUNTABLE_SEQUENCE}.linear_representation */
EIF_REFERENCE F482_4810 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {639,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y4259,Y4259_gen_type,Dftype(Current),315);
			typarr0[1] = l_type.annotations | 0xFF00;
			typarr0[2] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		tr1 = RTLNS(typres0.id, 639, _OBJSIZ_2_3_0_1_0_0_0_0_);
	}
	F640_5063(RTCW(tr1));
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {COUNTABLE_SEQUENCE}.prune */
void F482_4811 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	RTGC;
}

void EIF_Minit1697 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
