
#ifndef _C21_to1040_
#define _C21_to1040_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1686_17602(EIF_REFERENCE);
extern void EIF_Minit1040(void);
extern void F1088_9856(EIF_REFERENCE);
extern void F1120_10306(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1086_9822(EIF_REFERENCE, EIF_REFERENCE);
extern void F1113_10182(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
