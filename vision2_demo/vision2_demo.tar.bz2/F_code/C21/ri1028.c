/*
 * Code for class RICH_TEXT_BUFFERING_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ri1028.h"
#include "eif_built_in.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RICH_TEXT_BUFFERING_TEST}.default_create */
void F1674_17548 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLIU(7);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1204, 0x00).id, 1204, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc1));
	tr1 = RTLNSMART(eif_new_type(1249, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	F1120_10306(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	loc2 = RTLNS(eif_new_type(1203, 0x00).id, 1203, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc2));
	F1120_10306(RTCW(loc1), loc2);
	F1203_11119(RTCW(loc1), loc2);
	tr1 = RTLNSMART(eif_new_type(1250, 0).id);
	tr2 = RTMS_EX_H("Rich text",9,1012130420);
	F1113_10182(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	F1120_10306(RTCW(loc2), *(EIF_REFERENCE *)(Current + _REFACS_4_));
	tr1 = RTLNSMART(eif_new_type(1256, 0).id);
	tr2 = RTMS_EX_H("Buffer Text",11,254185076);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = Current;
	RTAR(tr3,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A1028_41, (EIF_POINTER) _A1028_41, (EIF_POINTER)(F1674_17549),tr3, 1, 0);
	}
	F1257_12150(RTCW(tr1), tr2, tr4);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	F1120_10306(RTCW(loc2), *(EIF_REFERENCE *)(Current + _REFACS_3_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1194_10946(RTCW(tr1), ((EIF_INTEGER_32) 300L), ((EIF_INTEGER_32) 300L));
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
	RTLE;
}

/* {RICH_TEXT_BUFFERING_TEST}.perform_buffering */
void F1674_17549 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc6);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLR(6,tr2);
	RTLR(7,loc5);
	RTLIU(8);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr1 = F1113_10183(RTCW(tr1));
	loc6 = F1078_9449(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc2 = F1115_10196(RTCW(tr1));
	loc3 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc2);
	F1094_9973(RTCW(loc3), ((EIF_INTEGER_32) 8L));
	loc4 = RTLNS(eif_new_type(1092, 0x00).id, 1092, _OBJSIZ_3_1_0_0_0_0_0_0_);
	tr1 = RTLNS(eif_new_type(193, 0x00).id, 193, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = RTOSCF(3388,F194_3388, (RTCW(tr1)));
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = F1104_10124(RTCW(tr2));
	F1093_9943(RTCW(loc4), loc2, tr1, tr2);
	loc5 = RTLNS(eif_new_type(1092, 0x00).id, 1092, _OBJSIZ_3_1_0_0_0_0_0_0_);
	tr1 = RTLNS(eif_new_type(193, 0x00).id, 193, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = RTOSCF(3401,F194_3401, (RTCW(tr1)));
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = F1104_10124(RTCW(tr2));
	F1093_9943(RTCW(loc5), loc3, tr1, tr2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 1000L))) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = eif_out__i4_s1(loc1);
		tr2 = F1086_9822(RTCW(loc6), tr2);
		F1250_12101(RTCW(tr1), tr2, loc4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = eif_out__i4_s1(loc1);
		tr2 = F1086_9822(RTCW(loc6), tr2);
		F1250_12101(RTCW(tr1), tr2, loc5);
		loc1++;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1250_12103(RTCW(tr1));
	RTLE;
}

void EIF_Minit1028 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
