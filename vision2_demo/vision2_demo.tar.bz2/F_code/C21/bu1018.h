
#ifndef _C21_bu1018_
#define _C21_bu1018_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1664_17498(EIF_REFERENCE);
extern void F1664_17499(EIF_REFERENCE);
extern void EIF_Minit1018(void);
extern EIF_REFERENCE __A1018_41();
extern EIF_REFERENCE F1086_9822(EIF_REFERENCE, EIF_REFERENCE);
extern void F681_5535(EIF_REFERENCE, EIF_REFERENCE);
extern void F1113_10182(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE _A1018_41();
extern EIF_REFERENCE F1162_10712(EIF_REFERENCE);
extern void F1664_17499(EIF_REFERENCE);
extern void F1113_10184(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
