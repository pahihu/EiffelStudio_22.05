/*
 * Code for class CHECKABLE_TREE_ADVANCED_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ch1007.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CHECKABLE_TREE_ADVANCED_TEST}.default_create */
void F1653_17467 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc22 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc23 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc24 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc25 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc26 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(32);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLR(6,loc5);
	RTLR(7,loc6);
	RTLR(8,loc7);
	RTLR(9,loc8);
	RTLR(10,loc9);
	RTLR(11,loc10);
	RTLR(12,loc11);
	RTLR(13,loc12);
	RTLR(14,loc13);
	RTLR(15,loc14);
	RTLR(16,loc15);
	RTLR(17,loc16);
	RTLR(18,loc17);
	RTLR(19,loc18);
	RTLR(20,loc19);
	RTLR(21,loc20);
	RTLR(22,loc21);
	RTLR(23,loc22);
	RTLR(24,loc23);
	RTLR(25,loc24);
	RTLR(26,loc25);
	RTLR(27,loc26);
	RTLR(28,tr2);
	RTLR(29,tr3);
	RTLR(30,tr4);
	RTLR(31,tr5);
	RTLIU(32);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1203, 0x00).id, 1203, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc1));
	tr1 = RTLNSMART(eif_new_type(1261, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	loc2 = RTLNS(eif_new_type(1186, 0x00).id, 1186, _OBJSIZ_6_1_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc2));
	loc3 = RTLNS(eif_new_type(1186, 0x00).id, 1186, _OBJSIZ_6_1_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc3));
	loc4 = RTLNS(eif_new_type(1186, 0x00).id, 1186, _OBJSIZ_6_1_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc4));
	loc5 = RTLNS(eif_new_type(1186, 0x00).id, 1186, _OBJSIZ_6_1_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc5));
	loc6 = RTLNS(eif_new_type(1186, 0x00).id, 1186, _OBJSIZ_6_1_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc6));
	loc7 = RTLNS(eif_new_type(1186, 0x00).id, 1186, _OBJSIZ_6_1_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc7));
	loc8 = RTLNS(eif_new_type(1186, 0x00).id, 1186, _OBJSIZ_6_1_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc8));
	loc9 = RTLNS(eif_new_type(1186, 0x00).id, 1186, _OBJSIZ_6_1_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc9));
	loc10 = RTLNS(eif_new_type(1186, 0x00).id, 1186, _OBJSIZ_6_1_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc10));
	loc11 = RTLNS(eif_new_type(1186, 0x00).id, 1186, _OBJSIZ_6_1_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc11));
	loc12 = RTLNS(eif_new_type(1186, 0x00).id, 1186, _OBJSIZ_6_1_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc12));
	loc13 = RTLNS(eif_new_type(1186, 0x00).id, 1186, _OBJSIZ_6_1_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc13));
	loc14 = RTLNS(eif_new_type(1186, 0x00).id, 1186, _OBJSIZ_6_1_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc14));
	loc15 = RTLNS(eif_new_type(1186, 0x00).id, 1186, _OBJSIZ_6_1_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc15));
	loc16 = RTLNS(eif_new_type(1186, 0x00).id, 1186, _OBJSIZ_6_1_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc16));
	loc17 = RTLNS(eif_new_type(1186, 0x00).id, 1186, _OBJSIZ_6_1_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc17));
	loc18 = RTLNS(eif_new_type(1186, 0x00).id, 1186, _OBJSIZ_6_1_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc18));
	loc19 = RTLNS(eif_new_type(1186, 0x00).id, 1186, _OBJSIZ_6_1_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc19));
	loc20 = RTLNS(eif_new_type(1186, 0x00).id, 1186, _OBJSIZ_6_1_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc20));
	loc21 = RTLNS(eif_new_type(1186, 0x00).id, 1186, _OBJSIZ_6_1_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc21));
	loc22 = RTLNS(eif_new_type(1204, 0x00).id, 1204, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc22));
	tr1 = RTLNSMART(eif_new_type(1248, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	loc23 = RTLNS(eif_new_type(1256, 0x00).id, 1256, _OBJSIZ_6_2_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc23));
	loc24 = RTLNS(eif_new_type(1256, 0x00).id, 1256, _OBJSIZ_6_2_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc24));
	loc25 = RTLNS(eif_new_type(1256, 0x00).id, 1256, _OBJSIZ_6_2_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc25));
	loc26 = RTLNS(eif_new_type(1256, 0x00).id, 1256, _OBJSIZ_6_2_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc26));
	F1120_10306(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1120_10306(RTCW(tr1), loc2);
	F1120_10306(RTCW(loc2), loc3);
	F1120_10306(RTCW(loc2), loc4);
	F1120_10306(RTCW(loc2), loc5);
	F1120_10306(RTCW(loc5), loc6);
	F1120_10306(RTCW(loc5), loc7);
	F1120_10306(RTCW(loc5), loc8);
	F1120_10306(RTCW(loc5), loc9);
	F1120_10306(RTCW(loc5), loc10);
	F1120_10306(RTCW(loc2), loc11);
	F1120_10306(RTCW(loc2), loc12);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1120_10306(RTCW(tr1), loc13);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1120_10306(RTCW(tr1), loc14);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1120_10306(RTCW(tr1), loc15);
	F1120_10306(RTCW(loc15), loc16);
	F1120_10306(RTCW(loc15), loc17);
	F1120_10306(RTCW(loc15), loc18);
	F1120_10306(RTCW(loc15), loc19);
	F1120_10306(RTCW(loc15), loc20);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1120_10306(RTCW(tr1), loc21);
	F1120_10306(RTCW(loc1), loc22);
	F1120_10306(RTCW(loc22), *(EIF_REFERENCE *)(Current + _REFACS_3_));
	F1120_10306(RTCW(loc22), loc23);
	F1120_10306(RTCW(loc22), loc24);
	F1120_10306(RTCW(loc22), loc25);
	F1120_10306(RTCW(loc22), loc26);
	F1203_11119(RTCW(loc1), loc22);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1194_10945(RTCW(tr1), ((EIF_INTEGER_32) 250L));
	F1109_10165(RTCW(loc2));
	tr1 = RTMS_EX_H("Item 1",6,1846065201);
	F1113_10184(RTCW(loc2), tr1);
	tr1 = RTMS_EX_H("Item 2",6,1846065202);
	F1113_10184(RTCW(loc3), tr1);
	tr1 = RTMS_EX_H("Item 3",6,1846065203);
	F1113_10184(RTCW(loc4), tr1);
	tr1 = RTMS_EX_H("Item 4",6,1846065204);
	F1113_10184(RTCW(loc5), tr1);
	tr1 = RTMS_EX_H("Item 5",6,1846065205);
	F1113_10184(RTCW(loc6), tr1);
	tr1 = RTMS_EX_H("Item 6",6,1846065206);
	F1113_10184(RTCW(loc7), tr1);
	tr1 = RTMS_EX_H("Item 7",6,1846065207);
	F1113_10184(RTCW(loc8), tr1);
	tr1 = RTMS_EX_H("Item 8",6,1846065208);
	F1113_10184(RTCW(loc9), tr1);
	tr1 = RTMS_EX_H("Item 9",6,1846065209);
	F1113_10184(RTCW(loc10), tr1);
	tr1 = RTMS_EX_H("Item 10",7,147133744);
	F1113_10184(RTCW(loc11), tr1);
	tr1 = RTMS_EX_H("Item 11",7,147133745);
	F1113_10184(RTCW(loc12), tr1);
	tr1 = RTMS_EX_H("Item 12",7,147133746);
	F1113_10184(RTCW(loc13), tr1);
	tr1 = RTMS_EX_H("Item 13",7,147133747);
	F1113_10184(RTCW(loc14), tr1);
	tr1 = RTMS_EX_H("Item 14",7,147133748);
	F1113_10184(RTCW(loc15), tr1);
	tr1 = RTMS_EX_H("Item 15",7,147133749);
	F1113_10184(RTCW(loc16), tr1);
	tr1 = RTMS_EX_H("Item 16",7,147133750);
	F1113_10184(RTCW(loc17), tr1);
	tr1 = RTMS_EX_H("Item 17",7,147133751);
	F1113_10184(RTCW(loc18), tr1);
	tr1 = RTMS_EX_H("Item 18",7,147133752);
	F1113_10184(RTCW(loc19), tr1);
	tr1 = RTMS_EX_H("Item 19",7,147133753);
	F1113_10184(RTCW(loc20), tr1);
	tr1 = RTMS_EX_H("Item 20",7,147134000);
	F1113_10184(RTCW(loc21), tr1);
	F1203_11119(RTCW(loc22), loc23);
	F1203_11119(RTCW(loc22), loc24);
	F1203_11119(RTCW(loc22), loc25);
	F1203_11119(RTCW(loc22), loc26);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1194_10945(RTCW(tr1), ((EIF_INTEGER_32) 100L));
	tr1 = RTMS_EX_H("Check selected iitem",20,843585389);
	F1113_10184(RTCW(loc23), tr1);
	tr1 = RTMS_EX_H("Uncheck selected item",21,1212201837);
	F1113_10184(RTCW(loc24), tr1);
	tr1 = RTMS_EX_H("Is item checked\?",16,1601799743);
	F1113_10184(RTCW(loc25), tr1);
	tr1 = RTMS_EX_H("Display checked items",21,1172646771);
	F1113_10184(RTCW(loc26), tr1);
	tr1 = F1162_10712(RTCW(loc23));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A1007_43, (EIF_POINTER) _A1007_43, (EIF_POINTER)(F1653_17470),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	tr1 = F1162_10712(RTCW(loc24));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A1007_44, (EIF_POINTER) _A1007_44, (EIF_POINTER)(F1653_17471),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	tr1 = F1162_10712(RTCW(loc25));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A1007_45, (EIF_POINTER) _A1007_45, (EIF_POINTER)(F1653_17472),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	tr1 = F1162_10712(RTCW(loc26));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A1007_46, (EIF_POINTER) _A1007_46, (EIF_POINTER)(F1653_17473),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F1140_10588(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1186,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A1007_48_2, (EIF_POINTER) _A1007_48_2, (EIF_POINTER)(F1653_17475),tr2, 1, 1);
	}
	F681_5535(RTCW(tr1), tr5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F1140_10587(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1186,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A1007_47_2, (EIF_POINTER) _A1007_47_2, (EIF_POINTER)(F1653_17474),tr2, 1, 1);
	}
	F681_5535(RTCW(tr1), tr5);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
	tr1 = *(EIF_REFERENCE *)(Current);
	F1194_10946(RTCW(tr1), ((EIF_INTEGER_32) 300L), ((EIF_INTEGER_32) 300L));
	RTLE;
}

/* {CHECKABLE_TREE_ADVANCED_TEST}.check_selected_item */
void F1653_17470 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F1261_12166(RTCW(tr1));
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = F1261_12166(RTCW(tr2));
		F1262_12175(RTCW(tr1), tr2);
	}
	RTLE;
}

/* {CHECKABLE_TREE_ADVANCED_TEST}.uncheck_selected_item */
void F1653_17471 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F1261_12166(RTCW(tr1));
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = F1261_12166(RTCW(tr2));
		F1262_12176(RTCW(tr1), tr2);
	}
	RTLE;
}

/* {CHECKABLE_TREE_ADVANCED_TEST}.is_item_checked */
void F1653_17472 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F1261_12166(RTCW(tr1));
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = F1261_12166(RTCW(tr2));
		tb1 = F1262_12174(RTCW(tr1), tr2);
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tr2 = RTMS_EX_H("Selected item is checked\012",25,947471114);
			F1248_12042(RTCW(tr1), tr2);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tr2 = RTMS_EX_H("Selected item is not checked\012",29,1469601802);
			F1248_12042(RTCW(tr1), tr2);
		}
	}
	RTLE;
}

/* {CHECKABLE_TREE_ADVANCED_TEST}.display_checked_items */
void F1653_17473 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = F1262_12173(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {626,1184,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc1 = RTRV(typres0, loc1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr2 = RTMS_EX_H("The following items are checked :\012",34,643043082);
	F1248_12042(RTCW(tr1), tr2);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4416[Dtype(RTCW(loc1))-638])(loc1);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4415[Dtype(RTCW(loc1))-638])(loc1);
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4450[Dtype(RTCW(loc1))-534])(loc1);
		tr2 = F1113_10183(RTCW(tr2));
		F1248_12042(RTCW(tr1), tr2);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4423[Dtype(RTCW(loc1))-638])(loc1);
		ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4462[Dtype(RTCW(loc1))-534])(loc1);
		if ((EIF_BOOLEAN) (ti4_1 < ti4_2)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tr2 = RTMS_EX_H(", ",2,11296);
			F1248_12042(RTCW(tr1), tr2);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R4429[Dtype(RTCW(loc1))-638])(loc1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr2 = RTMS_EX_H("\012",1,10);
	F1248_12042(RTCW(tr1), tr2);
	RTLE;
}

/* {CHECKABLE_TREE_ADVANCED_TEST}.item_checked */
void F1653_17474 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr2 = F1113_10183(RTCW(arg1));
	tr3 = F1078_9452(RTMS_EX_H(" Checked\012",9,414453770));
	tr2 = F1083_9657(RTCW(tr2), tr3);
	F1248_12042(RTCW(tr1), tr2);
	RTLE;
}

/* {CHECKABLE_TREE_ADVANCED_TEST}.item_unchecked */
void F1653_17475 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr2 = F1113_10183(RTCW(arg1));
	tr3 = F1078_9452(RTMS_EX_H(" UnChecked\012",11,205404170));
	tr2 = F1083_9657(RTCW(tr2), tr3);
	F1248_12042(RTCW(tr1), tr2);
	RTLE;
}

void EIF_Minit1007 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
