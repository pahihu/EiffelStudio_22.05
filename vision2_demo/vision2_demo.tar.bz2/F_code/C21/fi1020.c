/*
 * Code for class FIXED_PIXMAP_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "fi1020.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {FIXED_PIXMAP_TEST}.default_create */
void F1666_17504 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1200, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1194_10946(RTCW(tr1), ((EIF_INTEGER_32) 300L), ((EIF_INTEGER_32) 300L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = F1666_17505(Current);
	F1108_10157(RTCW(tr1), tr2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > (EIF_INTEGER_32) (RTOSCF(17508,F1666_17508, (Current)) * RTOSCF(17508,F1666_17508, (Current))))) break;
		if ((EIF_BOOLEAN)((EIF_INTEGER_32) (loc1 % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L))) {
			loc2 = RTLNS(eif_new_type(1256, 0x00).id, 1256, _OBJSIZ_6_2_0_1_0_0_0_0_);
			tr1 = RTMS_EX_H("A button",8,1088627054);
			F1113_10182(RTCW(loc2), tr1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F1120_10306(RTCW(tr1), loc2);
			F1194_10946(RTCW(loc2), ((EIF_INTEGER_32) 60L), ((EIF_INTEGER_32) 60L));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			ti4_1 = RTOSCF(17508,F1666_17508, (Current));
			ti4_2 = RTOSCF(17508,F1666_17508, (Current));
			F1201_11080(RTCW(tr1), loc2, (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 % ti4_1) * ((EIF_INTEGER_32) 60L)), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 / ti4_2) * ((EIF_INTEGER_32) 60L)));
		}
		loc1++;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {FIXED_PIXMAP_TEST}.background_pixmap */
EIF_REFERENCE F1666_17505 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(1278, 0x00).id, 1278, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(Result));
	tr1 = RTLNS(eif_new_type(193, 0x00).id, 193, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = RTOSCF(3401,F194_3401, (RTCW(tr1)));
	F1104_10125(RTCW(Result), tr1);
	tr1 = RTLNS(eif_new_type(193, 0x00).id, 193, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = RTOSCF(3387,F194_3387, (RTCW(tr1)));
	F1104_10126(RTCW(Result), tr1);
	F1116_10219(RTCW(Result));
	F1194_10946(RTCW(Result), ((EIF_INTEGER_32) 40L), ((EIF_INTEGER_32) 40L));
	F1279_12312(RTCW(Result), ((EIF_INTEGER_32) 40L), ((EIF_INTEGER_32) 40L));
	F1116_10238(RTCW(Result), ((EIF_INTEGER_32) 5L), ((EIF_INTEGER_32) 5L), ((EIF_INTEGER_32) 30L), ((EIF_INTEGER_32) 30L));
	RTLE;
	return Result;
}

/* {FIXED_PIXMAP_TEST}.widgets_fitting */
static EIF_INTEGER_32 F1666_17508_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (17508);
#define Result RTOSR(17508)
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 300L) / ((EIF_INTEGER_32) 60L));
	RTOSE (17508);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F1666_17508 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(17508,F1666_17508_body,(Current));
}

void EIF_Minit1020 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
