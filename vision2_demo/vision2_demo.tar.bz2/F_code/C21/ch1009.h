
#ifndef _C21_ch1009_
#define _C21_ch1009_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1655_17478(EIF_REFERENCE);
extern void EIF_Minit1009(void);
extern void F1262_12175(EIF_REFERENCE, EIF_REFERENCE);
extern void F1088_9856(EIF_REFERENCE);
extern void F1120_10306(EIF_REFERENCE, EIF_REFERENCE);
extern void F1194_10946(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1113_10182(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
