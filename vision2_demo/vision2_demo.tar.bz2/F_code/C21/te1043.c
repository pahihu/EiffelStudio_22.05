/*
 * Code for class TEXT_FIELD_VALIDATE_ENTRY_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "te1043.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TEXT_FIELD_VALIDATE_ENTRY_TEST}.default_create */
void F1689_17608 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1204, 0x00).id, 1204, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc1));
	tr1 = RTLNSMART(eif_new_type(1241, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	F1689_17610(Current);
	F1120_10306(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
	tr1 = RTLNSMART(eif_new_type(1250, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1194_10944(RTCW(tr1), ((EIF_INTEGER_32) 200L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F1160_10707(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A1043_41, (EIF_POINTER) _A1043_41, (EIF_POINTER)(F1689_17609),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	F1120_10306(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
	RTLE;
}

/* {TEXT_FIELD_VALIDATE_ENTRY_TEST}.validate_text_field */
void F1689_17609 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F1113_10183(RTCW(tr1));
	tr2 = F1078_9452(RTMS_EX_H("banana",6,2045299809));
	tb1 = F1081_9547(RTCW(tr1), tr2);
	if (tb1) {
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_))++;
		F1689_17610(Current);
	}
	RTLE;
}

/* {TEXT_FIELD_VALIDATE_ENTRY_TEST}.set_label_text */
void F1689_17610 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr2 = RTMS_EX_H("Correctly entered ",18,1771817760);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_);
	tr3 = eif_out__i4_s1(ti4_1);
	tr2 = F1086_9822(tr2, tr3);
	tr3 = RTMS_EX_H(" times.\012Please enter \"banana\" and press return",46,201109102);
	tr2 = F1086_9822(RTCW(tr2), tr3);
	F1113_10184(RTCW(tr1), tr2);
	RTLE;
}

void EIF_Minit1043 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
