/*
 * Code for class PIXMAP_FIGURE_STRING_SIZE_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pi1031.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PIXMAP_FIGURE_STRING_SIZE_TEST}.default_create */
void F1677_17558 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1204, 0x00).id, 1204, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc1));
	F1194_10946(RTCW(loc1), ((EIF_INTEGER_32) 300L), ((EIF_INTEGER_32) 300L));
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
	tr1 = RTLNSMART(eif_new_type(1278, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1279_12312(RTCW(tr1), ((EIF_INTEGER_32) 300L), ((EIF_INTEGER_32) 300L));
	F1120_10306(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
	tr1 = RTLNSMART(eif_new_type(946, 0).id);
	F947_7906(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1526, 0).id);
	F1527_16638(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_5_), *(EIF_REFERENCE *)(Current + _REFACS_3_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	loc2 = RTLNS(eif_new_type(1203, 0x00).id, 1203, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc2));
	F1120_10306(RTCW(loc1), loc2);
	F1203_11119(RTCW(loc1), loc2);
	tr1 = RTLNSMART(eif_new_type(1248, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = RTMS_EX_H("Default text",12,1179378292);
	F1113_10184(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1151_10676(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A1031_44, (EIF_POINTER) _A1031_44, (EIF_POINTER)(F1677_17562),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	F1120_10306(RTCW(loc2), *(EIF_REFERENCE *)(Current + _REFACS_7_));
	loc1 = RTLNS(eif_new_type(1204, 0x00).id, 1204, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc1));
	F1120_10306(RTCW(loc2), loc1);
	F1203_11119(RTCW(loc2), loc1);
	tr1 = RTLNSMART(eif_new_type(1256, 0).id);
	tr2 = RTMS_EX_H("Select Font",11,561731956);
	F1113_10182(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr1 = F1162_10712(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A1031_41, (EIF_POINTER) _A1031_41, (EIF_POINTER)(F1677_17559),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	F1120_10306(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_8_));
	tr1 = RTLNSMART(eif_new_type(1258, 0).id);
	tr2 = RTMS_EX_H("Show Bounds",11,124990323);
	F1113_10182(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	tr1 = F1162_10712(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A1031_42, (EIF_POINTER) _A1031_42, (EIF_POINTER)(F1677_17560),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	F1120_10306(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_9_));
	tr1 = RTLNSMART(eif_new_type(952, 0).id);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = F1113_10183(RTCW(tr2));
	F953_7969(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(945, 0).id);
	F946_7870(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	tr2 = RTLNS(eif_new_type(938, 0x00).id, 938, _OBJSIZ_3_3_0_5_0_0_0_6_);
	F939_7639(RTCW(tr2), ((EIF_INTEGER_32) 100L), ((EIF_INTEGER_32) 100L));
	F258_4048(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F945_7858(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_11_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	F945_7858(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_6_));
	tr1 = RTLNSMART(eif_new_type(1093, 0).id);
	F1094_9963(RTCW(tr1), ((EIF_INTEGER_32) 2L), ((EIF_INTEGER_32) 7L), ((EIF_INTEGER_32) 10L), ((EIF_INTEGER_32) 24L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F953_7975(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	tr1 = RTLNSMART(eif_new_type(952, 0).id);
	F953_7968(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(952, 0).id);
	F953_7968(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(952, 0).id);
	F953_7968(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(952, 0).id);
	F953_7968(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_15_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1525_16613(RTCW(tr1));
	RTLE;
}

/* {PIXMAP_FIGURE_STRING_SIZE_TEST}.select_font */
void F1677_17559 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1146, 0x00).id, 1146, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1088_9856(RTCW(loc1));
	tr1 = F87_1268(Current, *(EIF_REFERENCE *)(Current + _REFACS_3_));
	F1145_10630(RTCW(loc1), tr1);
	tr1 = F1145_10628(RTCW(loc1));
	tr2 = RTLNS(eif_new_type(124, 0x00).id, 124, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr2 = RTOSCF(2664,F125_2664, (RTCW(tr2)));
	tb1 = F1081_9550(RTCW(tr1), tr2);
	if (tb1) {
		tr1 = F1147_10638(RTCW(loc1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tr2 = F1147_10638(RTCW(loc1));
		F953_7975(RTCW(tr1), tr2);
		F1677_17561(Current);
		F1677_17560(Current);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F1525_16613(RTCW(tr1));
	}
	RTLE;
}

/* {PIXMAP_FIGURE_STRING_SIZE_TEST}.update_bounds_display */
void F1677_17560 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = F1113_10183(RTCW(tr2));
	loc1 = F1094_9987(RTCW(tr1), tr2);
	loc2 = F998_8177(RTCW(loc1), ((EIF_INTEGER_32) 1L));
	loc3 = F998_8177(RTCW(loc1), ((EIF_INTEGER_32) 2L));
	loc4 = F998_8177(RTCW(loc1), ((EIF_INTEGER_32) 3L));
	loc5 = F998_8177(RTCW(loc1), ((EIF_INTEGER_32) 4L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	tb1 = F1109_10163(RTCW(tr1));
	if (tb1) {
		tr1 = RTLNSMART(eif_new_type(959, 0).id);
		tr2 = RTLNS(eif_new_type(938, 0x00).id, 938, _OBJSIZ_3_3_0_5_0_0_0_6_);
		F939_7639(RTCW(tr2), ((EIF_INTEGER_32) 100L), ((EIF_INTEGER_32) 100L));
		tr3 = RTLNS(eif_new_type(938, 0x00).id, 938, _OBJSIZ_3_3_0_5_0_0_0_6_);
		F939_7639(RTCW(tr3), (EIF_INTEGER_32) (((EIF_INTEGER_32) 100L) + loc2), (EIF_INTEGER_32) (((EIF_INTEGER_32) 100L) + loc3));
		F259_4050(RTCW(tr1), tr2, tr3);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
		F945_7858(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_10_));
		tr1 = RTLNSMART(eif_new_type(1531, 0).id);
		tr2 = RTLNS(eif_new_type(938, 0x00).id, 938, _OBJSIZ_3_3_0_5_0_0_0_6_);
		F939_7639(RTCW(tr2), (EIF_INTEGER_32) (((EIF_INTEGER_32) 100L) + loc4), ((EIF_INTEGER_32) 100L));
		tr3 = RTLNS(eif_new_type(938, 0x00).id, 938, _OBJSIZ_3_3_0_5_0_0_0_6_);
		F939_7639(RTCW(tr3), (EIF_INTEGER_32) (((EIF_INTEGER_32) 100L) + loc4), (EIF_INTEGER_32) (((EIF_INTEGER_32) 100L) + loc3));
		F259_4050(RTCW(tr1), tr2, tr3);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
		tr2 = RTLNS(eif_new_type(193, 0x00).id, 193, _OBJSIZ_0_0_0_0_0_0_0_0_);
		tr2 = RTOSCF(3401,F194_3401, (RTCW(tr2)));
		F948_7937(RTCW(tr1), tr2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
		F945_7858(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_12_));
		tr1 = RTLNSMART(eif_new_type(1531, 0).id);
		tr2 = RTLNS(eif_new_type(938, 0x00).id, 938, _OBJSIZ_3_3_0_5_0_0_0_6_);
		F939_7639(RTCW(tr2), (EIF_INTEGER_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 100L) + loc2) + loc5), ((EIF_INTEGER_32) 100L));
		tr3 = RTLNS(eif_new_type(938, 0x00).id, 938, _OBJSIZ_3_3_0_5_0_0_0_6_);
		F939_7639(RTCW(tr3), (EIF_INTEGER_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 100L) + loc2) + loc5), (EIF_INTEGER_32) (((EIF_INTEGER_32) 100L) + loc3));
		F259_4050(RTCW(tr1), tr2, tr3);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
		tr2 = RTLNS(eif_new_type(193, 0x00).id, 193, _OBJSIZ_0_0_0_0_0_0_0_0_);
		tr2 = RTOSCF(3401,F194_3401, (RTCW(tr2)));
		F948_7937(RTCW(tr1), tr2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
		F945_7858(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_13_));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
		tr2 = RTMS_EX_H("Right Offset: ",14,1945224736);
		tr3 = eif_out__i4_s1(loc5);
		tr2 = F1086_9822(tr2, tr3);
		F953_7976(RTCW(tr1), tr2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
		tr2 = RTLNS(eif_new_type(938, 0x00).id, 938, _OBJSIZ_3_3_0_5_0_0_0_6_);
		tr3 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr3)+ _LNGOFF_24_5_0_4_);
		F939_7639(RTCW(tr2), ((EIF_INTEGER_32) 10L), (EIF_INTEGER_32) (((EIF_INTEGER_32) 260L) - ti4_1));
		F258_4048(RTCW(tr1), tr2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
		tr2 = RTMS_EX_H("Left Offset: ",13,290112544);
		tr3 = eif_out__i4_s1(loc4);
		tr2 = F1086_9822(tr2, tr3);
		F953_7976(RTCW(tr1), tr2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
		tr2 = RTLNS(eif_new_type(938, 0x00).id, 938, _OBJSIZ_3_3_0_5_0_0_0_6_);
		tr3 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
		tr3 = F258_4047(RTCW(tr3));
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr3)+ _LNGOFF_3_3_0_2_);
		tr3 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(tr3)+ _LNGOFF_24_5_0_4_);
		F939_7639(RTCW(tr2), ((EIF_INTEGER_32) 10L), (EIF_INTEGER_32) (ti4_1 - ti4_2));
		F258_4048(RTCW(tr1), tr2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
		tr2 = RTMS_EX_H("Height: ",8,1271714848);
		tr3 = eif_out__i4_s1(loc3);
		tr2 = F1086_9822(tr2, tr3);
		F953_7976(RTCW(tr1), tr2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
		tr2 = RTLNS(eif_new_type(938, 0x00).id, 938, _OBJSIZ_3_3_0_5_0_0_0_6_);
		tr3 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
		tr3 = F258_4047(RTCW(tr3));
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr3)+ _LNGOFF_3_3_0_2_);
		tr3 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(tr3)+ _LNGOFF_24_5_0_4_);
		F939_7639(RTCW(tr2), ((EIF_INTEGER_32) 10L), (EIF_INTEGER_32) (ti4_1 - ti4_2));
		F258_4048(RTCW(tr1), tr2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
		tr2 = RTMS_EX_H("Width: ",7,851651872);
		tr3 = eif_out__i4_s1(loc2);
		tr2 = F1086_9822(tr2, tr3);
		F953_7976(RTCW(tr1), tr2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
		tr2 = RTLNS(eif_new_type(938, 0x00).id, 938, _OBJSIZ_3_3_0_5_0_0_0_6_);
		tr3 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
		tr3 = F258_4047(RTCW(tr3));
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr3)+ _LNGOFF_3_3_0_2_);
		tr3 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(tr3)+ _LNGOFF_24_5_0_4_);
		F939_7639(RTCW(tr2), ((EIF_INTEGER_32) 10L), (EIF_INTEGER_32) (ti4_1 - ti4_2));
		F258_4048(RTCW(tr1), tr2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		F945_7858(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_17_));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		F945_7858(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_16_));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		F945_7858(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_14_));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		F945_7858(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_15_));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		F953_7975(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	} else {
		F1677_17561(Current);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1525_16613(RTCW(tr1));
	RTLE;
}

/* {PIXMAP_FIGURE_STRING_SIZE_TEST}.clear_bounds_figures */
void F1677_17561 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1116_10219(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	F945_7862(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_10_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	F945_7862(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_12_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	F945_7862(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_13_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F945_7862(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_14_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F945_7862(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_15_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F945_7862(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_16_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F945_7862(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_17_));
	RTLE;
}

/* {PIXMAP_FIGURE_STRING_SIZE_TEST}.text_changed */
void F1677_17562 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = F1113_10183(RTCW(tr2));
	F953_7976(RTCW(tr1), tr2);
	F1677_17561(Current);
	F1677_17560(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1525_16613(RTCW(tr1));
	RTLE;
}

void EIF_Minit1031 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
