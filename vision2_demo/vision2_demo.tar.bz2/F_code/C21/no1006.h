
#ifndef _C21_no1006_
#define _C21_no1006_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1652_17465(EIF_REFERENCE);
extern void EIF_Minit1006(void);
extern void F1088_9856(EIF_REFERENCE);
extern void F1120_10306(EIF_REFERENCE, EIF_REFERENCE);
extern void F1194_10946(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1113_10182(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1120_10291(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1202_11104(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
