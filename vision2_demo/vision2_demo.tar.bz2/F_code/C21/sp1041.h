
#ifndef _C21_sp1041_
#define _C21_sp1041_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1687_17604(EIF_REFERENCE);
extern void EIF_Minit1041(void);
extern void F1088_9856(EIF_REFERENCE);
extern void F1194_10946(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_REFERENCE F1263_12183(EIF_REFERENCE);
extern void F576_4884(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1113_10184(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R4492[])();

#ifdef __cplusplus
}
#endif

#endif
