/*
 * Code for class CHECKABLE_LIST_BASIC_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ch1035.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CHECKABLE_LIST_BASIC_TEST}.default_create */
void F1681_17589 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1255, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1194_10946(RTCW(tr1), ((EIF_INTEGER_32) 300L), ((EIF_INTEGER_32) 300L));
	loc1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_6_0_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("Item 1",6,1846065201);
	F1113_10182(RTCW(loc1), tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1120_10306(RTCW(tr1), loc1);
	loc1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_6_0_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("Item 2",6,1846065202);
	F1113_10182(RTCW(loc1), tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1120_10306(RTCW(tr1), loc1);
	loc1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_6_0_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("Item 3",6,1846065203);
	F1113_10182(RTCW(loc1), tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1120_10306(RTCW(tr1), loc1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit1035 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
