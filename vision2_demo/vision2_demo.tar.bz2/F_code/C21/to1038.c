/*
 * Code for class TOOL_BAR_RADIO_BUTTON_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "to1038.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TOOL_BAR_RADIO_BUTTON_TEST}.default_create */
void F1684_17598 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1239, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 5L))) break;
		loc2 = RTLNS(eif_new_type(1173, 0x00).id, 1173, _OBJSIZ_6_0_0_1_0_0_0_0_);
		F1088_9856(RTCW(loc2));
		tr1 = F1582_17207(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 % ((EIF_INTEGER_32) 2L)) + ((EIF_INTEGER_32) 1L)));
		F1108_10157(RTCW(loc2), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1120_10306(RTCW(tr1), loc2);
		loc1++;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit1038 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
