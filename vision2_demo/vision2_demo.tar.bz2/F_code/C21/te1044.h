
#ifndef _C21_te1044_
#define _C21_te1044_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1690_17614(EIF_REFERENCE);
extern void EIF_Minit1044(void);
extern void F1194_10944(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1113_10182(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
