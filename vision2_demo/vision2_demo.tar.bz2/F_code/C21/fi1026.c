/*
 * Code for class FIXED_SET_ITEM_POSITION_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "fi1026.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {FIXED_SET_ITEM_POSITION_TEST}.default_create */
void F1672_17542 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1200, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	loc1 = RTLNS(eif_new_type(1256, 0x00).id, 1256, _OBJSIZ_6_2_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("Item 1",6,1846065201);
	F1113_10182(RTCW(loc1), tr1);
	loc2 = RTLNS(eif_new_type(1256, 0x00).id, 1256, _OBJSIZ_6_2_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("Item 2",6,1846065202);
	F1113_10182(RTCW(loc2), tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1120_10306(RTCW(tr1), loc1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1120_10306(RTCW(tr1), loc2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = RTLNS(eif_new_type(1256, 0x00).id, 1256, _OBJSIZ_6_2_0_1_0_0_0_0_);
	tr3 = RTMS_EX_H("Item 3",6,1846065203);
	F1113_10182(RTCW(tr2), tr3);
	F1120_10306(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1194_10946(RTCW(tr1), ((EIF_INTEGER_32) 300L), ((EIF_INTEGER_32) 300L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1201_11080(RTCW(tr1), loc1, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1201_11083(RTCW(tr1), loc1, ((EIF_INTEGER_32) 50L), ((EIF_INTEGER_32) 50L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1201_11080(RTCW(tr1), loc2, ((EIF_INTEGER_32) 50L), ((EIF_INTEGER_32) 50L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1201_11083(RTCW(tr1), loc2, ((EIF_INTEGER_32) 50L), ((EIF_INTEGER_32) 50L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = F1120_10291(RTCW(tr2), ((EIF_INTEGER_32) 3L));
	F1201_11080(RTCW(tr1), tr2, ((EIF_INTEGER_32) 100L), ((EIF_INTEGER_32) 100L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = F1120_10291(RTCW(tr2), ((EIF_INTEGER_32) 3L));
	F1201_11083(RTCW(tr1), tr2, ((EIF_INTEGER_32) 50L), ((EIF_INTEGER_32) 50L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit1026 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
