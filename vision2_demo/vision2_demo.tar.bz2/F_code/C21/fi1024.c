/*
 * Code for class FIXED_INCREASE_ITEM_POSITION_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "fi1024.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {FIXED_INCREASE_ITEM_POSITION_TEST}.default_create */
void F1670_17522 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1200, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1256, 0).id);
	tr2 = RTMS_EX_H("Move right",10,2133910644);
	F1113_10182(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1256, 0).id);
	tr2 = RTMS_EX_H("Move down",9,1418016110);
	F1113_10182(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1256, 0).id);
	tr2 = RTMS_EX_H("Move diagonal",13,1447396716);
	F1113_10182(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1120_10306(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1120_10306(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_4_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1120_10306(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_5_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	ti4_1 = F1106_10142(RTCW(tr3));
	F1201_11080(RTCW(tr1), tr2, ti4_1, ((EIF_INTEGER_32) 0L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	ti4_1 = F1106_10143(RTCW(tr3));
	F1201_11080(RTCW(tr1), tr2, ((EIF_INTEGER_32) 0L), ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	ti4_1 = F1106_10142(RTCW(tr3));
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	ti4_2 = F1106_10143(RTCW(tr3));
	F1201_11080(RTCW(tr1), tr2, ti4_1, ti4_2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr1 = F1162_10712(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,4,997,0,1256,1033,1033,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 5, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	((EIF_TYPED_VALUE *)tr2+2)->it_r = tr3;
	RTAR(tr2,tr3);
	((EIF_TYPED_VALUE *)tr2+3)->it_i4 = ((EIF_INTEGER_32) 10L);
	((EIF_TYPED_VALUE *)tr2+4)->it_i4 = ((EIF_INTEGER_32) 0L);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A1024_41, (EIF_POINTER) _A1024_41, (EIF_POINTER)(F1670_17523),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr1 = F1162_10712(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,4,997,0,1256,1033,1033,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 5, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	((EIF_TYPED_VALUE *)tr2+2)->it_r = tr3;
	RTAR(tr2,tr3);
	((EIF_TYPED_VALUE *)tr2+3)->it_i4 = ((EIF_INTEGER_32) 0L);
	((EIF_TYPED_VALUE *)tr2+4)->it_i4 = ((EIF_INTEGER_32) 10L);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A1024_41, (EIF_POINTER) _A1024_41, (EIF_POINTER)(F1670_17523),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr1 = F1162_10712(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,4,997,0,1256,1033,1033,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 5, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	((EIF_TYPED_VALUE *)tr2+2)->it_r = tr3;
	RTAR(tr2,tr3);
	((EIF_TYPED_VALUE *)tr2+3)->it_i4 = ((EIF_INTEGER_32) 10L);
	((EIF_TYPED_VALUE *)tr2+4)->it_i4 = ((EIF_INTEGER_32) 10L);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A1024_41, (EIF_POINTER) _A1024_41, (EIF_POINTER)(F1670_17523),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {FIXED_INCREASE_ITEM_POSITION_TEST}.move_button */
void F1670_17523 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	ti4_1 = F1106_10138(RTCW(arg1));
	ti4_2 = F1106_10139(RTCW(arg1));
	F1201_11080(RTCW(tr1), arg1, (EIF_INTEGER_32) (ti4_1 + arg2), (EIF_INTEGER_32) (ti4_2 + arg3));
	RTLE;
}

void EIF_Minit1024 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
