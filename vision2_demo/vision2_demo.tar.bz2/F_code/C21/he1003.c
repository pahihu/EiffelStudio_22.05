/*
 * Code for class HEADER_RESIZING_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "he1003.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {HEADER_RESIZING_TEST}.default_create */
void F1649_17453 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLR(7,loc2);
	RTLIU(8);
	
	RTGC;
	loc3 = RTLNS(eif_new_type(1204, 0x00).id, 1204, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc3));
	tr1 = RTLNSMART(eif_new_type(1242, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	F1120_10306(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_3_));
	tr1 = RTLNSMART(eif_new_type(1248, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	F1120_10306(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1194_10945(RTCW(tr1), ((EIF_INTEGER_32) 200L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr1 = F1141_10591(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1168,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A1003_41_2, (EIF_POINTER) _A1003_41_2, (EIF_POINTER)(F1649_17454),tr2, 1, 1);
	}
	F681_5535(RTCW(tr1), tr5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr1 = F1141_10592(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1168,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A1003_42_2, (EIF_POINTER) _A1003_42_2, (EIF_POINTER)(F1649_17455),tr2, 1, 1);
	}
	F681_5535(RTCW(tr1), tr5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr1 = F1141_10593(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1168,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A1003_43_2, (EIF_POINTER) _A1003_43_2, (EIF_POINTER)(F1649_17456),tr2, 1, 1);
	}
	F681_5535(RTCW(tr1), tr5);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 5L))) break;
		loc2 = RTLNS(eif_new_type(1168, 0x00).id, 1168, _OBJSIZ_6_0_0_1_0_0_0_0_);
		tr1 = RTMS_EX_H("Resize Me",9,220819301);
		F1113_10182(RTCW(loc2), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1120_10306(RTCW(tr1), loc2);
		loc1++;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr2 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_5_2_0_1_0_0_0_0_);
	F1088_9856(RTCW(tr2));
	ti4_1 = F1106_10145(RTCW(tr2));
	F1194_10946(RTCW(tr1), ((EIF_INTEGER_32) 300L), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 3L)));
	RTAR(Current, loc3);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc3;
	RTLE;
}

/* {HEADER_RESIZING_TEST}.header_item_started_resizing */
void F1649_17454 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = RTMS_EX_H("Header item ",12,212755232);
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	ti4_1 = F1120_10292(RTCW(tr3), arg1, ((EIF_INTEGER_32) 1L));
	tr3 = eif_out__i4_s1(ti4_1);
	tr2 = F1086_9822(tr2, tr3);
	tr3 = RTMS_EX_H(" start resizing\012",16,1239106058);
	tr2 = F1086_9822(RTCW(tr2), tr3);
	F1248_12042(RTCW(tr1), tr2);
	RTLE;
}

/* {HEADER_RESIZING_TEST}.header_item_resizing */
void F1649_17455 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = RTMS_EX_H("Header item ",12,212755232);
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	ti4_1 = F1120_10292(RTCW(tr3), arg1, ((EIF_INTEGER_32) 1L));
	tr3 = eif_out__i4_s1(ti4_1);
	tr2 = F1086_9822(tr2, tr3);
	tr3 = RTMS_EX_H(" resizing to width : ",21,171057696);
	tr2 = F1086_9822(RTCW(tr2), tr3);
	ti4_1 = F1106_10142(RTCW(arg1));
	tr3 = eif_out__i4_s1(ti4_1);
	tr2 = F1086_9822(RTCW(tr2), tr3);
	tr3 = RTMS_EX_H("\012",1,10);
	tr2 = F1086_9822(RTCW(tr2), tr3);
	F1248_12042(RTCW(tr1), tr2);
	RTLE;
}

/* {HEADER_RESIZING_TEST}.header_item_ended_resizing */
void F1649_17456 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = RTMS_EX_H("Header item ",12,212755232);
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	ti4_1 = F1120_10292(RTCW(tr3), arg1, ((EIF_INTEGER_32) 1L));
	tr3 = eif_out__i4_s1(ti4_1);
	tr2 = F1086_9822(tr2, tr3);
	tr3 = RTMS_EX_H(" end resizing\012",14,1697607946);
	tr2 = F1086_9822(RTCW(tr2), tr3);
	F1248_12042(RTCW(tr1), tr2);
	RTLE;
}

void EIF_Minit1003 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
