/*
 * Code for class HEADER_BASIC_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "he1005.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {HEADER_BASIC_TEST}.default_create */
void F1651_17463 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1242, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 5L))) break;
		loc2 = RTLNS(eif_new_type(1168, 0x00).id, 1168, _OBJSIZ_6_0_0_1_0_0_0_0_);
		tr1 = RTMS_EX_H("Item ",5,1953364768);
		tr2 = eif_out__i4_s1(loc1);
		tr1 = F1086_9822(tr1, tr2);
		F1113_10182(RTCW(loc2), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1120_10306(RTCW(tr1), loc2);
		loc1++;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_5_2_0_1_0_0_0_0_);
	F1088_9856(RTCW(tr2));
	ti4_1 = F1106_10145(RTCW(tr2));
	F1194_10946(RTCW(tr1), ((EIF_INTEGER_32) 300L), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 3L)));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit1005 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
