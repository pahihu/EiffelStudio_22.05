/*
 * Code for class TOOL_BAR_COMBO_BOX_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "to1036.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TOOL_BAR_COMBO_BOX_TEST}.default_create */
void F1682_17591 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,loc4);
	RTLR(4,tr2);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1239, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1239, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1253, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1194_10944(RTCW(tr1), ((EIF_INTEGER_32) 150L));
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 5L))) break;
		loc2 = RTLNS(eif_new_type(1172, 0x00).id, 1172, _OBJSIZ_6_0_0_1_0_0_0_0_);
		F1088_9856(RTCW(loc2));
		tr1 = F1582_17207(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 % ((EIF_INTEGER_32) 2L)) + ((EIF_INTEGER_32) 1L)));
		F1108_10157(RTCW(loc2), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1120_10306(RTCW(tr1), loc2);
		loc2 = RTLNS(eif_new_type(1172, 0x00).id, 1172, _OBJSIZ_6_0_0_1_0_0_0_0_);
		F1088_9856(RTCW(loc2));
		tr1 = F1582_17207(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 % ((EIF_INTEGER_32) 2L)) + ((EIF_INTEGER_32) 1L)));
		F1108_10157(RTCW(loc2), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1120_10306(RTCW(tr1), loc2);
		loc4 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_6_0_0_1_0_0_0_0_);
		tr1 = RTMS_EX_H("Item ",5,1953364768);
		tr2 = eif_out__i4_s1(loc1);
		tr1 = F1086_9822(tr1, tr2);
		F1113_10182(RTCW(loc4), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F1120_10306(RTCW(tr1), loc4);
		loc1++;
	}
	loc3 = RTLNS(eif_new_type(1203, 0x00).id, 1203, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc3));
	F1120_10306(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	F1120_10306(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_4_));
	F1120_10306(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_3_));
	F1203_11119(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	F1203_11119(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_4_));
	RTAR(Current, loc3);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc3;
	RTLE;
}

void EIF_Minit1036 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
