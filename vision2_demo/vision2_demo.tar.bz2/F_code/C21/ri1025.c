/*
 * Code for class RICH_TEXT_FORMATTING_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ri1025.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RICH_TEXT_FORMATTING_TEST}.default_create */
void F1671_17528 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,tr5);
	RTLR(8,loc3);
	RTLIU(9);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1249, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	loc1 = RTLNS(eif_new_type(1204, 0x00).id, 1204, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc1));
	F1120_10306(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	loc2 = RTLNS(eif_new_type(1203, 0x00).id, 1203, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc2));
	F1120_10306(RTCW(loc1), loc2);
	F1203_11119(RTCW(loc1), loc2);
	tr1 = RTLNSMART(eif_new_type(1253, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr1 = F1152_10678(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A1025_43, (EIF_POINTER) _A1025_43, (EIF_POINTER)(F1671_17531),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	tr1 = RTLNSMART(eif_new_type(1258, 0).id);
	tr2 = RTMS_EX_H("Bold",4,1114598500);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = Current;
	RTAR(tr3,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A1025_44, (EIF_POINTER) _A1025_44, (EIF_POINTER)(F1671_17532),tr3, 1, 0);
	}
	F1257_12150(RTCW(tr1), tr2, tr4);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1258, 0).id);
	tr2 = RTMS_EX_H("Italic",6,1778909539);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr3 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = Current;
	RTAR(tr3,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A1025_45, (EIF_POINTER) _A1025_45, (EIF_POINTER)(F1671_17533),tr3, 1, 0);
	}
	F1257_12150(RTCW(tr1), tr2, tr4);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	F1120_10306(RTCW(loc2), *(EIF_REFERENCE *)(Current + _REFACS_5_));
	F1120_10306(RTCW(loc2), *(EIF_REFERENCE *)(Current + _REFACS_3_));
	F1203_11119(RTCW(loc2), *(EIF_REFERENCE *)(Current + _REFACS_3_));
	F1120_10306(RTCW(loc2), *(EIF_REFERENCE *)(Current + _REFACS_4_));
	F1203_11119(RTCW(loc2), *(EIF_REFERENCE *)(Current + _REFACS_4_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1194_10946(RTCW(tr1), ((EIF_INTEGER_32) 300L), ((EIF_INTEGER_32) 300L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = RTMS_EX_H("Select some of this text, and use the two buttons to enable/disable bold and italic formatting.",95,1131371054);
	F1113_10184(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F1157_10694(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A1025_41, (EIF_POINTER) _A1025_41, (EIF_POINTER)(F1671_17529),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F1157_10693(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A1025_42_2, (EIF_POINTER) _A1025_42_2, (EIF_POINTER)(F1671_17530),tr2, 1, 1);
	}
	F681_5535(RTCW(tr1), tr5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = RTOSCF(17536,F1671_17536, (Current));
	F1115_10197(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = RTLNS(eif_new_type(1092, 0x00).id, 1092, _OBJSIZ_3_1_0_0_0_0_0_0_);
	tr3 = RTOSCF(17536,F1671_17536, (Current));
	F1093_9942(RTCW(tr2), tr3);
	F1250_12095(RTCW(tr1), tr2);
	tr1 = RTLNS(eif_new_type(1099, 0x00).id, 1099, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1088_9856(RTCW(tr1));
	loc3 = F1100_10090(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {656,1033,1082,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F657_5316(RTCW(tr1), ((EIF_INTEGER_32) 50L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4416[Dtype(RTCW(loc3))-638])(loc3);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4415[Dtype(RTCW(loc3))-638])(loc3);
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		tr2 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_6_0_0_1_0_0_0_0_);
		tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4414[Dtype(RTCW(loc3))-638])(loc3);
		F1113_10182(RTCW(tr2), tr3);
		F1120_10306(RTCW(tr1), tr2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		ti4_1 = F1120_10295(RTCW(tr2));
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4414[Dtype(RTCW(loc3))-638])(loc3);
		F657_5362(RTCW(tr1), ti4_1, tr2);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R4429[Dtype(RTCW(loc3))-638])(loc3);
	}
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
	RTLE;
}

/* {RICH_TEXT_FORMATTING_TEST}.selection_changed */
void F1671_17529 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1248_12032(RTCW(tr1));
	if (tb1) {
		F1671_17534(Current);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc2 = F1250_12080(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		ti4_1 = F1248_12033(RTCW(tr2));
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		ti4_2 = F1248_12034(RTCW(tr2));
		loc1 = F1250_12085(RTCW(tr1), ti4_1, ti4_2);
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_0_0_);
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			tr3 = F1093_9945(RTCW(loc2));
			tr3 = F1094_9977(RTCW(tr3));
			tr3 = F1081_9567(RTCW(tr3));
			tr3 = F1078_9452(RTCW(tr3));
			ti4_1 = F657_5322(RTCW(tr2), tr3);
			tr1 = F1120_10291(RTCW(tr1), ti4_1);
			F1109_10165(RTCW(tr1));
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			F1113_10185(RTCW(tr1));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			F1253_12123(RTCW(tr1));
		}
		tb1 = '\0';
		tr1 = F1093_9945(RTCW(loc2));
		ti4_1 = F1094_9966(RTCW(tr1));
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 8L))) {
			tb2 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_0_1_);
			tb1 = tb2;
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1109_10165(RTCW(tr1));
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1110_10167(RTCW(tr1));
		}
		tb1 = '\0';
		tr1 = F1093_9945(RTCW(loc2));
		ti4_1 = F1094_9967(RTCW(tr1));
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 11L))) {
			tb2 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_0_2_);
			tb1 = tb2;
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			F1109_10165(RTCW(tr1));
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			F1110_10167(RTCW(tr1));
		}
		F1671_17535(Current);
	}
	RTLE;
}

/* {RICH_TEXT_FORMATTING_TEST}.caret_moved */
void F1671_17530 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	ti4_1 = F1248_12031(RTCW(tr2));
	loc1 = F1250_12079(RTCW(tr1), ti4_1);
	F1671_17534(Current);
	tr1 = F1093_9945(RTCW(loc1));
	ti4_1 = F1094_9966(RTCW(tr1));
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 7L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1110_10167(RTCW(tr1));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1109_10165(RTCW(tr1));
	}
	tr1 = F1093_9945(RTCW(loc1));
	ti4_1 = F1094_9967(RTCW(tr1));
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 10L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F1110_10167(RTCW(tr1));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F1109_10165(RTCW(tr1));
	}
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_6_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tr3 = F1093_9945(RTCW(loc1));
		tr3 = F1094_9977(RTCW(tr3));
		tr3 = F1081_9567(RTCW(tr3));
		tr3 = F1078_9452(RTCW(tr3));
		ti4_1 = F657_5322(RTCW(tr2), tr3);
		tr1 = F1120_10291(RTCW(tr1), ti4_1);
		F1109_10165(RTCW(tr1));
	}
	F1671_17535(Current);
	RTLE;
}

/* {RICH_TEXT_FORMATTING_TEST}.font_selected */
void F1671_17531 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1248_12032(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		ti4_1 = F1248_12033(RTCW(tr2));
		loc1 = F1250_12079(RTCW(tr1), ti4_1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		ti4_1 = F1248_12031(RTCW(tr2));
		loc1 = F1250_12079(RTCW(tr1), ti4_1);
	}
	loc3 = F1093_9945(RTCW(loc1));
	tr1 = F1094_9971(RTCW(loc3));
	F681_5547(RTCW(tr1));
	tr1 = F1094_9971(RTCW(loc3));
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr2 = F1253_12120(RTCW(tr2));
	tr2 = F1113_10183(RTCW(tr2));
	F681_5535(RTCW(tr1), tr2);
	F1093_9949(RTCW(loc1), loc3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1248_12032(RTCW(tr1));
	if (tb1) {
		loc2 = RTLNS(eif_new_type(1517, 0x00).id, 1517, _OBJSIZ_0_9_0_0_0_0_0_0_);
		F1518_16476(RTCW(loc2), ((EIF_INTEGER_32) 1L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		ti4_1 = F1248_12033(RTCW(tr2));
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		ti4_2 = F1248_12034(RTCW(tr2));
		F1250_12098(RTCW(tr1), ti4_1, ti4_2, loc1, loc2);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1250_12095(RTCW(tr1), loc1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1194_10929(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1194_10934(RTCW(tr1));
	}
	RTLE;
}

/* {RICH_TEXT_FORMATTING_TEST}.modify_bold */
void F1671_17532 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1248_12032(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		ti4_1 = F1248_12033(RTCW(tr2));
		loc1 = F1250_12079(RTCW(tr1), ti4_1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		ti4_1 = F1248_12031(RTCW(tr2));
		loc1 = F1250_12079(RTCW(tr1), ti4_1);
	}
	loc3 = F1093_9945(RTCW(loc1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tb1 = F1109_10163(RTCW(tr1));
	if (tb1) {
		F1094_9973(RTCW(loc3), ((EIF_INTEGER_32) 8L));
	} else {
		F1094_9973(RTCW(loc3), ((EIF_INTEGER_32) 7L));
	}
	F1093_9949(RTCW(loc1), loc3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1248_12032(RTCW(tr1));
	if (tb1) {
		loc2 = RTLNS(eif_new_type(1517, 0x00).id, 1517, _OBJSIZ_0_9_0_0_0_0_0_0_);
		F1518_16476(RTCW(loc2), ((EIF_INTEGER_32) 2L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		ti4_1 = F1248_12033(RTCW(tr2));
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		ti4_2 = F1248_12034(RTCW(tr2));
		F1250_12098(RTCW(tr1), ti4_1, ti4_2, loc1, loc2);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1250_12095(RTCW(tr1), loc1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1194_10934(RTCW(tr1));
	RTLE;
}

/* {RICH_TEXT_FORMATTING_TEST}.modify_italic */
void F1671_17533 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1248_12032(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		ti4_1 = F1248_12033(RTCW(tr2));
		loc1 = F1250_12079(RTCW(tr1), ti4_1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		ti4_1 = F1248_12031(RTCW(tr2));
		loc1 = F1250_12079(RTCW(tr1), ti4_1);
	}
	loc3 = F1093_9945(RTCW(loc1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tb1 = F1109_10163(RTCW(tr1));
	if (tb1) {
		F1094_9974(RTCW(loc3), ((EIF_INTEGER_32) 11L));
	} else {
		F1094_9974(RTCW(loc3), ((EIF_INTEGER_32) 10L));
	}
	F1093_9949(RTCW(loc1), loc3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1248_12032(RTCW(tr1));
	if (tb1) {
		loc2 = RTLNS(eif_new_type(1517, 0x00).id, 1517, _OBJSIZ_0_9_0_0_0_0_0_0_);
		F1518_16476(RTCW(loc2), ((EIF_INTEGER_32) 4L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		ti4_1 = F1248_12033(RTCW(tr2));
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		ti4_2 = F1248_12034(RTCW(tr2));
		F1250_12098(RTCW(tr1), ti4_1, ti4_2, loc1, loc2);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1250_12095(RTCW(tr1), loc1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1194_10934(RTCW(tr1));
	RTLE;
}

/* {RICH_TEXT_FORMATTING_TEST}.block_events */
void F1671_17534 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr1 = F1162_10712(RTCW(tr1));
	F688_5577(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr1 = F1162_10712(RTCW(tr1));
	F688_5577(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr1 = F1152_10678(RTCW(tr1));
	F688_5577(RTCW(tr1));
	RTLE;
}

/* {RICH_TEXT_FORMATTING_TEST}.resume_events */
void F1671_17535 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr1 = F1162_10712(RTCW(tr1));
	F688_5579(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr1 = F1162_10712(RTCW(tr1));
	F688_5579(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr1 = F1152_10678(RTCW(tr1));
	F688_5579(RTCW(tr1));
	RTLE;
}

/* {RICH_TEXT_FORMATTING_TEST}.default_font */
static EIF_REFERENCE F1671_17536_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (17536);
#define Result RTOSR(17536)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1093, 0x00).id, 1093, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1088_9856(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	tr1 = F1094_9971(RTCW(Result));
	tr2 = F1078_9452(RTMS_EX_H("Times New Roman",15,694083438));
	F681_5535(RTCW(tr1), tr2);
	tr1 = F1094_9971(RTCW(Result));
	tr2 = F1078_9452(RTMS_EX_H("Courier New",11,1860192631));
	F681_5535(RTCW(tr1), tr2);
	tr1 = F1094_9971(RTCW(Result));
	tr2 = F1078_9452(RTMS_EX_H("Arial",5,1920008044));
	F681_5535(RTCW(tr1), tr2);
	F1094_9975(RTCW(Result), ((EIF_INTEGER_32) 24L));
	RTOSE (17536);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1671_17536 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(17536,F1671_17536_body,(Current));
}

void EIF_Minit1025 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
