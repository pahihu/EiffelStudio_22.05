/*
 * Code for class LABEL_TEXT_ALIGNMENT_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "la1012.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LABEL_TEXT_ALIGNMENT_TEST}.default_create */
void F1658_17485 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLR(6,tr3);
	RTLIU(7);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1241, 0).id);
	tr2 = RTMS_EX_H("A Label",7,53230956);
	F1113_10182(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1194_10946(RTCW(tr1), ((EIF_INTEGER_32) 200L), ((EIF_INTEGER_32) 200L));
	loc1 = RTLNS(eif_new_type(1204, 0x00).id, 1204, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc1));
	F1120_10306(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	loc2 = RTLNS(eif_new_type(1253, 0x00).id, 1253, _OBJSIZ_5_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc2));
	loc3 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_6_0_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("Alignment left",14,1275782516);
	F1113_10182(RTCW(loc3), tr1);
	tr1 = F1189_10885(RTCW(loc3));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,1241,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A600_209, (EIF_POINTER) _A600_209, (EIF_POINTER)(F1114_10194),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	F1120_10306(RTCW(loc2), loc3);
	loc3 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_6_0_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("Alignment center",16,1968152690);
	F1113_10182(RTCW(loc3), tr1);
	tr1 = F1189_10885(RTCW(loc3));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,1241,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A600_207, (EIF_POINTER) _A600_207, (EIF_POINTER)(F1114_10192),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	F1120_10306(RTCW(loc2), loc3);
	loc3 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_6_0_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("Alignment right",15,250610804);
	F1113_10182(RTCW(loc3), tr1);
	tr1 = F1189_10885(RTCW(loc3));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,1241,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A600_208, (EIF_POINTER) _A600_208, (EIF_POINTER)(F1114_10193),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	F1120_10306(RTCW(loc2), loc3);
	F1120_10306(RTCW(loc1), loc2);
	F1203_11119(RTCW(loc1), loc2);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
	RTLE;
}

void EIF_Minit1012 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
