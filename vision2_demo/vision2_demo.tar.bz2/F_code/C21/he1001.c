/*
 * Code for class HEADER_RESIZE_TO_CONTENT_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "he1001.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {HEADER_RESIZE_TO_CONTENT_TEST}.default_create */
void F1647_17447 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLR(7,loc4);
	RTLR(8,loc2);
	RTLIU(9);
	
	RTGC;
	loc3 = RTLNS(eif_new_type(1204, 0x00).id, 1204, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc3));
	tr1 = RTLNSMART(eif_new_type(1242, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F1193_10906(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,8,997,1033,1033,1033,1018,1018,1018,1033,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A1001_41_2_3_4_5_6_7_8_9, (EIF_POINTER) _A1001_41_2_3_4_5_6_7_8_9, (EIF_POINTER)(F1647_17448),tr2, 1, 8);
	}
	F681_5535(RTCW(tr1), tr5);
	F1120_10306(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	loc4 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_5_2_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("Double click dividers to resize items to content",48,909779828);
	F1113_10182(RTCW(loc4), tr1);
	F1120_10306(RTCW(loc3), loc4);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 5L))) break;
		loc2 = RTLNS(eif_new_type(1168, 0x00).id, 1168, _OBJSIZ_6_0_0_1_0_0_0_0_);
		tr1 = RTMS_EX_H("Item ",5,1953364768);
		tr2 = eif_out__i4_s1(loc1);
		tr1 = F1086_9822(tr1, tr2);
		F1113_10182(RTCW(loc2), tr1);
		tr1 = F1582_17207(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 % ((EIF_INTEGER_32) 2L)) + ((EIF_INTEGER_32) 1L)));
		F1108_10157(RTCW(loc2), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1120_10306(RTCW(tr1), loc2);
		loc1++;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F1120_10291(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	F1169_10782(RTCW(tr1), ((EIF_INTEGER_32) 20L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F1120_10291(RTCW(tr1), ((EIF_INTEGER_32) 2L));
	F1169_10782(RTCW(tr1), ((EIF_INTEGER_32) 20L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F1120_10291(RTCW(tr1), ((EIF_INTEGER_32) 3L));
	F1169_10782(RTCW(tr1), ((EIF_INTEGER_32) 200L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F1120_10291(RTCW(tr1), ((EIF_INTEGER_32) 4L));
	F1169_10782(RTCW(tr1), ((EIF_INTEGER_32) 20L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F1120_10291(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	F1169_10782(RTCW(tr1), ((EIF_INTEGER_32) 40L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = F1582_17207(Current, ((EIF_INTEGER_32) 1L));
	ti4_1 = F1106_10145(RTCW(tr2));
	F1194_10946(RTCW(tr1), ((EIF_INTEGER_32) 300L), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 6L)));
	RTAR(Current, loc3);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc3;
	RTLE;
}

/* {HEADER_RESIZE_TO_CONTENT_TEST}.resize_pointed_item */
void F1647_17448 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = F1243_12014(RTCW(tr1));
	if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr1 = F1120_10291(RTCW(tr1), loc1);
		F1169_10785(RTCW(tr1));
	}
	RTLE;
}

void EIF_Minit1001 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
