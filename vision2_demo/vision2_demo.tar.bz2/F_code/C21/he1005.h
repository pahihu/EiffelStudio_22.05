
#ifndef _C21_he1005_
#define _C21_he1005_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1651_17463(EIF_REFERENCE);
extern void EIF_Minit1005(void);
extern void F1088_9856(EIF_REFERENCE);
extern void F1120_10306(EIF_REFERENCE, EIF_REFERENCE);
extern void F1194_10946(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_REFERENCE F1086_9822(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F1106_10145(EIF_REFERENCE);
extern void F1113_10182(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
