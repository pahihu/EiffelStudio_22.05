
#ifndef _C21_ce1021_
#define _C21_ce1021_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1667_17510(EIF_REFERENCE);
extern void EIF_Minit1021(void);
extern void F1088_9856(EIF_REFERENCE);
extern void F1194_10946(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1108_10157(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1582_17207(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
