/*
 * Code for class NOTEBOOK_ITEM_TEXT_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "no1006.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {NOTEBOOK_ITEM_TEXT_TEST}.default_create */
void F1652_17465 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1201, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1194_10946(RTCW(tr1), ((EIF_INTEGER_32) 200L), ((EIF_INTEGER_32) 200L));
	loc1 = RTLNS(eif_new_type(1256, 0x00).id, 1256, _OBJSIZ_6_2_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("Notebook item 1",15,155083057);
	F1113_10182(RTCW(loc1), tr1);
	loc2 = RTLNS(eif_new_type(1256, 0x00).id, 1256, _OBJSIZ_6_2_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("Notebook item 2",15,155083058);
	F1113_10182(RTCW(loc2), tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1120_10306(RTCW(tr1), loc1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1120_10306(RTCW(tr1), loc2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = RTLNS(eif_new_type(1256, 0x00).id, 1256, _OBJSIZ_6_2_0_1_0_0_0_0_);
	tr3 = RTMS_EX_H("Notebook item 3",15,155083059);
	F1113_10182(RTCW(tr2), tr3);
	F1120_10306(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = RTMS_EX_H("First item",10,2078507885);
	F1202_11104(RTCW(tr1), loc1, tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = RTMS_EX_H("Second item",11,1830786669);
	F1202_11104(RTCW(tr1), loc2, tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = F1120_10291(RTCW(tr2), ((EIF_INTEGER_32) 3L));
	tr3 = RTMS_EX_H("Third item",10,275098733);
	F1202_11104(RTCW(tr1), tr2, tr3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit1006 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
