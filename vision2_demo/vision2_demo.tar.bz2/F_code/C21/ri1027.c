/*
 * Code for class RICH_TEXT_TAB_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ri1027.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RICH_TEXT_TAB_TEST}.default_create */
void F1673_17544 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,tr5);
	RTLIU(8);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1249, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	loc1 = RTLNS(eif_new_type(1204, 0x00).id, 1204, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc1));
	F1120_10306(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	tr1 = RTLNSMART(eif_new_type(1263, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	loc2 = RTLNS(eif_new_type(1203, 0x00).id, 1203, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc2));
	F1120_10306(RTCW(loc1), loc2);
	F1203_11119(RTCW(loc1), loc2);
	tr1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_5_2_0_1_0_0_0_0_);
	tr2 = RTMS_EX_H("Tab width : ",12,2139919904);
	F1113_10182(RTCW(tr1), tr2);
	F1120_10306(RTCW(loc2), tr1);
	tr1 = F1120_10291(RTCW(loc2), ((EIF_INTEGER_32) 1L));
	F1203_11119(RTCW(loc2), tr1);
	F1120_10306(RTCW(loc2), *(EIF_REFERENCE *)(Current + _REFACS_3_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1194_10946(RTCW(tr1), ((EIF_INTEGER_32) 300L), ((EIF_INTEGER_32) 300L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = RTMS_EX_H("1,1\0112,1\0113,1\0121,2\0112,2\0113,2\0121,3\0112,3\0112,4",35,633984564);
	F1113_10184(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr1 = F1263_12183(RTCW(tr1));
	tr2 = RTLNS(eif_new_type(575, 0x00).id, 575, _OBJSIZ_0_1_0_2_0_0_0_0_);
	F576_4884(RTCW(tr2), ((EIF_INTEGER_32) 20L), ((EIF_INTEGER_32) 100L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4492[Dtype(RTCW(tr1))-575])(tr1, tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	ti4_1 = F1250_12093(RTCW(tr2));
	F1263_12190(RTCW(tr1), ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr1 = F1136_10577(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A1027_41_2, (EIF_POINTER) _A1027_41_2, (EIF_POINTER)(F1673_17545),tr2, 1, 1);
	}
	F681_5535(RTCW(tr1), tr5);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
	RTLE;
}

/* {RICH_TEXT_TAB_TEST}.update_tabs */
void F1673_17545 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {685,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc2 = RTLNS(typres0.id, 685, _OBJSIZ_5_2_0_1_0_0_0_0_);
	}
	F686_5559(RTCW(loc2));
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 5L))) break;
		F682_5535(RTCW(loc2), arg1);
		loc1++;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F1250_12092(RTCW(tr1));
	F682_5547(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F1250_12092(RTCW(tr1));
	F598_5033(RTCW(tr1), loc2);
	RTLE;
}

void EIF_Minit1027 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
