/*
 * Code for class HORIZONTAL_BOX_PADDING_WIDTH_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ho1000.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {HORIZONTAL_BOX_PADDING_WIDTH_TEST}.default_create */
void F1646_17440 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1203, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1256, 0).id);
	tr2 = RTMS_EX_H("Increase",8,1443559781);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,0,1033,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr3 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = Current;
	RTAR(tr3,Current);
	((EIF_TYPED_VALUE *)tr3+2)->it_i4 = ((EIF_INTEGER_32) 8L);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A1000_41, (EIF_POINTER) _A1000_41, (EIF_POINTER)(F1646_17441),tr3, 1, 0);
	}
	F1257_12150(RTCW(tr1), tr2, tr4);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1256, 0).id);
	tr2 = RTMS_EX_H("Decrease",8,1207519077);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,0,1033,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr3 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr3+1)->it_r = Current;
	RTAR(tr3,Current);
	((EIF_TYPED_VALUE *)tr3+2)->it_i4 = ((EIF_INTEGER_32) -8L);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A1000_41, (EIF_POINTER) _A1000_41, (EIF_POINTER)(F1646_17441),tr3, 1, 0);
	}
	F1257_12150(RTCW(tr1), tr2, tr4);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1241, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1120_10306(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_5_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1120_10306(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1120_10306(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_4_));
	F1646_17441(Current, ((EIF_INTEGER_32) 0L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {HORIZONTAL_BOX_PADDING_WIDTH_TEST}.adjust_padding */
void F1646_17441 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	ti4_1 = F1203_11110(RTCW(tr2));
	F1203_11116(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + arg1));
	if ((EIF_BOOLEAN) (arg1 <= ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		ti4_1 = F1203_11110(RTCW(tr1));
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			F1121_10336(RTCW(tr1));
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tb1 = F1121_10333(RTCW(tr1));
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
				F1121_10335(RTCW(tr1));
			}
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		ti4_1 = F1203_11110(RTCW(tr1));
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 40L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			F1121_10336(RTCW(tr1));
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			tb1 = F1121_10333(RTCW(tr1));
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
				F1121_10335(RTCW(tr1));
			}
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr2 = RTMS_EX_H("Padding width : ",16,1326002464);
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	ti4_1 = F1203_11110(RTCW(tr3));
	tr3 = eif_out__i4_s1(ti4_1);
	tr2 = F1086_9822(tr2, tr3);
	F1113_10184(RTCW(tr1), tr2);
	RTLE;
}

void EIF_Minit1000 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
