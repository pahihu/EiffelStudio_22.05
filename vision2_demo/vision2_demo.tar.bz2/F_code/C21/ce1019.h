
#ifndef _C21_ce1019_
#define _C21_ce1019_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1665_17502(EIF_REFERENCE);
extern void EIF_Minit1019(void);
extern void F1195_10961(EIF_REFERENCE, EIF_REFERENCE);
extern void F1088_9856(EIF_REFERENCE);
extern void F1194_10946(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1113_10182(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
