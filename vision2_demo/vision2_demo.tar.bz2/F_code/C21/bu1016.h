
#ifndef _C21_bu1016_
#define _C21_bu1016_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1662_17495(EIF_REFERENCE);
extern void EIF_Minit1016(void);
extern void F1108_10157(EIF_REFERENCE, EIF_REFERENCE);
extern void F1113_10182(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1582_17207(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
