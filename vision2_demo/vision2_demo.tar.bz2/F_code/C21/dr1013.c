/*
 * Code for class DRAWING_AREA_EXPOSE_ACTIONS_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "dr1013.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DRAWING_AREA_EXPOSE_ACTIONS_TEST}.default_create */
void F1659_17487 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,tr5);
	RTLIU(6);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1277, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1194_10946(RTCW(tr1), ((EIF_INTEGER_32) 300L), ((EIF_INTEGER_32) 300L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F1277_12286(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,4,997,1033,1033,1033,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A1013_42_2_3_4_5, (EIF_POINTER) _A1013_42_2_3_4_5, (EIF_POINTER)(F1659_17489),tr2, 1, 4);
	}
	F681_5535(RTCW(tr1), tr5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {DRAWING_AREA_EXPOSE_ACTIONS_TEST}.redraw_figures */
void F1659_17489 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1116_10219(RTCW(tr1));
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 30L))) break;
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 * ((EIF_INTEGER_32) 10L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1116_10234(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 150L) - (EIF_INTEGER_32) (loc2 / ((EIF_INTEGER_32) 2L))), (EIF_INTEGER_32) (((EIF_INTEGER_32) 150L) - (EIF_INTEGER_32) (loc2 / ((EIF_INTEGER_32) 2L))), loc2, loc2);
		loc1++;
	}
	RTLE;
}

void EIF_Minit1013 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
