
#ifndef _C21_mu1048_
#define _C21_mu1048_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1694_17626(EIF_REFERENCE);
extern void EIF_Minit1048(void);
extern EIF_REFERENCE F865_6818(EIF_REFERENCE);
extern void F1088_9856(EIF_REFERENCE);
extern void F591_5033(EIF_REFERENCE, EIF_REFERENCE);
extern void F1120_10306(EIF_REFERENCE, EIF_REFERENCE);
extern void F1194_10946(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_REFERENCE F1078_9453(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
