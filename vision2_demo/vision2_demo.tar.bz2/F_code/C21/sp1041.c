/*
 * Code for class SPIN_BUTTON_RANGE_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sp1041.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SPIN_BUTTON_RANGE_TEST}.default_create */
void F1687_17604 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1263, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1194_10946(RTCW(tr1), ((EIF_INTEGER_32) 250L), ((EIF_INTEGER_32) 250L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F1263_12183(RTCW(tr1));
	tr2 = RTLNS(eif_new_type(575, 0x00).id, 575, _OBJSIZ_0_1_0_2_0_0_0_0_);
	F576_4884(RTCW(tr2), ((EIF_INTEGER_32) 1000L), ((EIF_INTEGER_32) 2000L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4492[Dtype(RTCW(tr1))-575])(tr1, tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = RTMS_EX_H("Range modified : 1000 - 2000",28,2125449008);
	F1113_10184(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit1041 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
