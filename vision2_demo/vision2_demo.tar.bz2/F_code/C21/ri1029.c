/*
 * Code for class RICH_TEXT_BASIC_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ri1029.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RICH_TEXT_BASIC_TEST}.default_create */
void F1675_17553 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,tr2);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1249, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1194_10946(RTCW(tr1), ((EIF_INTEGER_32) 300L), ((EIF_INTEGER_32) 300L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc2 = F1115_10196(RTCW(tr1));
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 5L))) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = RTOSCF(17555,F1675_17555, (Current));
		F1248_12042(RTCW(tr1), tr2);
		ti4_1 = F1094_9968(RTCW(loc2));
		F1094_9975(RTCW(loc2), (EIF_INTEGER_32) (ti4_1 + loc1));
		loc3 = RTLNS(eif_new_type(1092, 0x00).id, 1092, _OBJSIZ_3_1_0_0_0_0_0_0_);
		F1093_9942(RTCW(loc3), loc2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		ti4_1 = F1248_12028(RTCW(tr2));
		ti4_2 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(17555,F1675_17555, (Current)))+ _LNGOFF_1_1_0_2_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		ti4_3 = F1248_12028(RTCW(tr2));
		F1250_12097(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 - ti4_2), ti4_3, loc3);
		loc1++;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {RICH_TEXT_BASIC_TEST}.sample_text */

EIF_REFERENCE F1675_17555 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (17555,RTMS_EX_H("Rich Text\012",10,1407564810));
}

void EIF_Minit1029 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
