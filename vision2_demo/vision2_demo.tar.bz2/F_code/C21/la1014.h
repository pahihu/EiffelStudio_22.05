
#ifndef _C21_la1014_
#define _C21_la1014_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1660_17490(EIF_REFERENCE);
extern void EIF_Minit1014(void);
extern void F1113_10182(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
