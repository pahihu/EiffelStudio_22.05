/*
 * Code for class TOOL_BAR_TOGGLE_BUTTON_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "to1037.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TOOL_BAR_TOGGLE_BUTTON_TEST}.default_create */
void F1683_17595 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1239, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 5L))) break;
		loc2 = RTLNS(eif_new_type(1174, 0x00).id, 1174, _OBJSIZ_6_0_0_1_0_0_0_0_);
		F1088_9856(RTCW(loc2));
		tr1 = RTMS_EX_H("Not selected",12,1488754276);
		F1113_10184(RTCW(loc2), tr1);
		tr1 = F1161_10709(RTCW(loc2));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,0,1174,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr2 = RTLNTS(typres0.id, 3, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
		RTAR(tr2,Current);
		((EIF_TYPED_VALUE *)tr2+2)->it_r = loc2;
		RTAR(tr2,loc2);
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3= RTLNRF(typres0.id, (EIF_POINTER) __A1037_42, (EIF_POINTER) _A1037_42, (EIF_POINTER)(F1683_17597),tr2, 1, 0);
		}
		F681_5535(RTCW(tr1), tr3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1120_10306(RTCW(tr1), loc2);
		loc1++;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {TOOL_BAR_TOGGLE_BUTTON_TEST}.update_button_text */
void F1683_17597 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tb1 = F1109_10163(RTCW(arg1));
	if (tb1) {
		tr1 = RTMS_EX_H("Selected",8,1196257124);
		F1113_10184(RTCW(arg1), tr1);
	} else {
		tr1 = RTMS_EX_H("Not selected",12,1488754276);
		F1113_10184(RTCW(arg1), tr1);
	}
	RTLE;
}

void EIF_Minit1037 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
