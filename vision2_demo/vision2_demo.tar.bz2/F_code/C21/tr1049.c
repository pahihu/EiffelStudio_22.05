/*
 * Code for class TREE_PIXMAP_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "tr1049.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TREE_PIXMAP_TEST}.default_create */
void F1695_17628 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1260, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1194_10946(RTCW(tr1), ((EIF_INTEGER_32) 280L), ((EIF_INTEGER_32) 280L));
	F1695_17632(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {TREE_PIXMAP_TEST}.build_tree */
void F1695_17632 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1186, 0x00).id, 1186, _OBJSIZ_6_1_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("Root Item",9,2061501805);
	F1113_10182(RTCW(loc1), tr1);
	tr1 = F1582_17207(Current, ((EIF_INTEGER_32) 1L));
	F1108_10157(RTCW(loc1), tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1120_10306(RTCW(tr1), loc1);
	F1695_17633(Current, loc1, ((EIF_INTEGER_32) 4L));
	RTLE;
}

/* {TREE_PIXMAP_TEST}.add_items */
void F1695_17633 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > arg2)) break;
		loc2 = RTLNS(eif_new_type(1186, 0x00).id, 1186, _OBJSIZ_6_1_0_1_0_0_0_0_);
		tr1 = RTMS_EX_H("Item",4,1232364909);
		F1113_10182(RTCW(loc2), tr1);
		if ((EIF_BOOLEAN)((EIF_INTEGER_32) (arg2 % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L))) {
			tr1 = F1582_17207(Current, ((EIF_INTEGER_32) 1L));
			F1108_10157(RTCW(loc2), tr1);
		} else {
			tr1 = F1582_17207(Current, ((EIF_INTEGER_32) 2L));
			F1108_10157(RTCW(loc2), tr1);
		}
		F1120_10306(RTCW(arg1), loc2);
		F1695_17633(Current, loc2, (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)));
		loc1++;
	}
	RTLE;
}

void EIF_Minit1049 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
