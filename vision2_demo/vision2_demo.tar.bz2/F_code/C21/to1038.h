
#ifndef _C21_to1038_
#define _C21_to1038_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1684_17598(EIF_REFERENCE);
extern void EIF_Minit1038(void);
extern void F1088_9856(EIF_REFERENCE);
extern void F1120_10306(EIF_REFERENCE, EIF_REFERENCE);
extern void F1108_10157(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1582_17207(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
