/*
 * Code for class TEXT_SCROLL_TO_LINE_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "te1023.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TEXT_SCROLL_TO_LINE_TEST}.default_create */
void F1669_17519 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc4);
	RTLR(5,loc2);
	RTLR(6,loc3);
	RTLR(7,tr3);
	RTLR(8,tr4);
	RTLR(9,tr5);
	RTLIU(10);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1204, 0x00).id, 1204, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc1));
	F1194_10946(RTCW(loc1), ((EIF_INTEGER_32) 300L), ((EIF_INTEGER_32) 300L));
	tr1 = RTLNSMART(eif_new_type(1248, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1248_12039(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = RTLNS(eif_new_type(193, 0x00).id, 193, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr2 = RTOSCF(3387,F194_3387, (RTCW(tr2)));
	F1104_10126(RTCW(tr1), tr2);
	F1120_10306(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	loc4 = RTLNS(eif_new_type(1203, 0x00).id, 1203, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc4));
	F1120_10306(RTCW(loc1), loc4);
	F1203_11119(RTCW(loc1), loc4);
	loc2 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_5_2_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("Enter a line to scroll to : ",28,1429181216);
	F1113_10182(RTCW(loc2), tr1);
	F1114_10193(RTCW(loc2));
	F1120_10306(RTCW(loc4), loc2);
	loc3 = RTLNS(eif_new_type(1263, 0x00).id, 1263, _OBJSIZ_5_2_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc3));
	tr1 = F1263_12183(RTCW(loc3));
	tr2 = RTLNS(eif_new_type(575, 0x00).id, 575, _OBJSIZ_0_1_0_2_0_0_0_0_);
	F576_4884(RTCW(tr2), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 100L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4492[Dtype(RTCW(tr1))-575])(tr1, tr2);
	F1120_10306(RTCW(loc4), loc3);
	F1203_11119(RTCW(loc4), loc3);
	tr1 = F1136_10577(RTCW(loc3));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A1023_42_2, (EIF_POINTER) _A1023_42_2, (EIF_POINTER)(F1669_17521),tr2, 1, 1);
	}
	F681_5535(RTCW(tr1), tr5);
	loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		tr1 = F1263_12183(RTCW(loc3));
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O4506[Dtype(tr1)-575]);
		if ((EIF_BOOLEAN) (loc5 > ti4_1)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = F1113_10183(RTCW(tr2));
		tr3 = F1078_9452(RTMS_EX_H("This is line ",13,225621792));
		tr2 = F1083_9657(RTCW(tr2), tr3);
		tr3 = eif_out__i4_s1(loc5);
		tr3 = F1078_9452(RTCW(tr3));
		tr2 = F1083_9657(RTCW(tr2), tr3);
		tr3 = F1078_9452(RTMS_EX_H("\012",1,10));
		tr2 = F1083_9657(RTCW(tr2), tr3);
		F1113_10184(RTCW(tr1), tr2);
		loc5++;
	}
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
	RTLE;
}

/* {TEXT_SCROLL_TO_LINE_TEST}.scroll_to_line */
void F1669_17521 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1249_12068(RTCW(tr1), arg1);
	RTLE;
}

void EIF_Minit1023 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
