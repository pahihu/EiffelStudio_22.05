
#ifndef _C21_la1010_
#define _C21_la1010_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1656_17480(EIF_REFERENCE);
extern void EIF_Minit1010(void);
extern void F1113_10182(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
