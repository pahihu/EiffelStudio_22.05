/*
 * Code for class CELL_AS_PADDING_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ce1017.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CELL_AS_PADDING_TEST}.default_create */
void F1663_17497 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1204, 0x00).id, 1204, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc1));
	F1194_10946(RTCW(loc1), ((EIF_INTEGER_32) 300L), ((EIF_INTEGER_32) 300L));
	tr1 = RTLNS(eif_new_type(1209, 0x00).id, 1209, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(tr1));
	F1120_10306(RTCW(loc1), tr1);
	tr1 = RTLNS(eif_new_type(1256, 0x00).id, 1256, _OBJSIZ_6_2_0_1_0_0_0_0_);
	tr2 = RTMS_EX_H("Centered in box",15,462809720);
	F1113_10182(RTCW(tr1), tr2);
	F1120_10306(RTCW(loc1), tr1);
	tr1 = F591_5018(RTCW(loc1), ((EIF_INTEGER_32) 2L));
	F1203_11119(RTCW(loc1), tr1);
	tr1 = RTLNS(eif_new_type(1209, 0x00).id, 1209, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(tr1));
	F1120_10306(RTCW(loc1), tr1);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
	RTLE;
}

void EIF_Minit1017 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
