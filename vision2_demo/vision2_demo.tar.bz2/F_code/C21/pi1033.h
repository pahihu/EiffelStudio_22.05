
#ifndef _C21_pi1033_
#define _C21_pi1033_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1679_17583(EIF_REFERENCE);
extern void EIF_Minit1033(void);
extern void F1194_10946(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_REFERENCE F1582_17207(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
