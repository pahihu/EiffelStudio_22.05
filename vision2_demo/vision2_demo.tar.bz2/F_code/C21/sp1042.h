
#ifndef _C21_sp1042_
#define _C21_sp1042_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1688_17606(EIF_REFERENCE);
extern void EIF_Minit1042(void);
extern void F1088_9856(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
