/*
 * Code for class MULTI_COLUMN_LIST_MULTIPLE_SELECTION_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "mu1045.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {MULTI_COLUMN_LIST_MULTIPLE_SELECTION_TEST}.default_create */
void F1691_17616 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc3);
	RTLR(4,tr3);
	RTLR(5,loc1);
	RTLR(6,tr4);
	RTLIU(7);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1240, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = RTMS_EX_H("Selected\?",9,1299691071);
	F1241_11991(RTCW(tr1), tr2, ((EIF_INTEGER_32) 3L));
	loc3 = RTLNS(eif_new_type(1204, 0x00).id, 1204, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc3));
	F1194_10946(RTCW(loc3), ((EIF_INTEGER_32) 300L), ((EIF_INTEGER_32) 300L));
	tr1 = RTLNSMART(eif_new_type(1259, 0).id);
	tr2 = RTMS_EX_H("Multiple selection\? - Hold \"Ctrl\" while selecting.",50,708654894);
	F1113_10182(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr1 = F1162_10712(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A1045_43, (EIF_POINTER) _A1045_43, (EIF_POINTER)(F1691_17619),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	F1120_10306(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	F1120_10306(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_3_));
	F1203_11119(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_3_));
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 25L))) break;
		loc1 = RTLNS(eif_new_type(1167, 0x00).id, 1167, _OBJSIZ_7_2_0_2_0_0_0_0_);
		F1088_9856(RTCW(loc1));
		{
			static EIF_TYPE_INDEX typarr0[] = {864,1082,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr2) = 3L;
			memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
		}
		tr3 = F1078_9453(RTMS_EX_H("1, ",3,3222560));
		tr4 = eif_out__i4_s1(loc2);
		tr4 = F1078_9453(RTCW(tr4));
		tr3 = F1083_9657(RTCW(tr3), tr4);
		*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
		RTAR(tr2,tr3);
		tr3 = F1078_9453(RTMS_EX_H("2, ",3,3288096));
		tr4 = eif_out__i4_s1(loc2);
		tr4 = F1078_9453(RTCW(tr4));
		tr3 = F1083_9657(RTCW(tr3), tr4);
		*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
		RTAR(tr2,tr3);
		tr3 = F1078_9453(RTMS_EX_H("No",2,20079));
		*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
		RTAR(tr2,tr3);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F865_6818)(tr2);
		F591_5033(RTCW(loc1), tr1);
		tr1 = F1143_10619(RTCW(loc1));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,0,1167,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr2 = RTLNTS(typres0.id, 3, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
		RTAR(tr2,Current);
		((EIF_TYPED_VALUE *)tr2+2)->it_r = loc1;
		RTAR(tr2,loc1);
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3= RTLNRF(typres0.id, (EIF_POINTER) __A1045_44, (EIF_POINTER) _A1045_44, (EIF_POINTER)(F1691_17620),tr2, 1, 0);
		}
		F681_5535(RTCW(tr1), tr3);
		tr1 = F1143_10620(RTCW(loc1));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,0,1167,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr2 = RTLNTS(typres0.id, 3, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
		RTAR(tr2,Current);
		((EIF_TYPED_VALUE *)tr2+2)->it_r = loc1;
		RTAR(tr2,loc1);
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3= RTLNRF(typres0.id, (EIF_POINTER) __A1045_44, (EIF_POINTER) _A1045_44, (EIF_POINTER)(F1691_17620),tr2, 1, 0);
		}
		F681_5535(RTCW(tr1), tr3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1120_10306(RTCW(tr1), loc1);
		loc2++;
	}
	RTAR(Current, loc3);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc3;
	RTLE;
}

/* {MULTI_COLUMN_LIST_MULTIPLE_SELECTION_TEST}.adjust_selection */
void F1691_17619 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tb1 = F1109_10163(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1241_11984(RTCW(tr1));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1241_11985(RTCW(tr1));
	}
	RTLE;
}

/* {MULTI_COLUMN_LIST_MULTIPLE_SELECTION_TEST}.update_selection_on_row */
void F1691_17620 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F664_5482(RTCW(arg1), ((EIF_INTEGER_32) 3L));
	tb1 = F1109_10163(RTCW(arg1));
	if (tb1) {
		tr1 = F1078_9452(RTMS_EX_H("Yes",3,5858675));
		F681_5540(RTCW(arg1), tr1);
	} else {
		tr1 = F1078_9452(RTMS_EX_H("No",2,20079));
		F681_5540(RTCW(arg1), tr1);
	}
	RTLE;
}

void EIF_Minit1045 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
