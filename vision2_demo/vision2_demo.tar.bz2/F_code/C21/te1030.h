
#ifndef _C21_te1030_
#define _C21_te1030_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1676_17556(EIF_REFERENCE);
extern void EIF_Minit1030(void);
extern void F1088_9856(EIF_REFERENCE);
extern void F1194_10946(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
