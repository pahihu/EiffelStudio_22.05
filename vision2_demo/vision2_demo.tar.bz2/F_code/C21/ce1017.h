
#ifndef _C21_ce1017_
#define _C21_ce1017_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1663_17497(EIF_REFERENCE);
extern void EIF_Minit1017(void);
extern void F1088_9856(EIF_REFERENCE);
extern void F1120_10306(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F591_5018(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1194_10946(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1113_10182(EIF_REFERENCE, EIF_REFERENCE);
extern void F1203_11119(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
