/*
 * Code for class FIXED_Z_ORDER_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "fi1022.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {FIXED_Z_ORDER_TEST}.default_create */
void F1668_17512 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1200, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1256, 0).id);
	tr2 = RTMS_EX_H("Click to bring to top",21,1667874160);
	F1113_10182(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1256, 0).id);
	tr2 = RTMS_EX_H("Click to bring to top",21,1667874160);
	F1113_10182(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1256, 0).id);
	tr2 = RTMS_EX_H("Click to bring to top",21,1667874160);
	F1113_10182(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr1 = F1162_10712(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,0,1256,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	((EIF_TYPED_VALUE *)tr2+2)->it_r = tr3;
	RTAR(tr2,tr3);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A1022_42, (EIF_POINTER) _A1022_42, (EIF_POINTER)(F1668_17514),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr1 = F1162_10712(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,0,1256,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	((EIF_TYPED_VALUE *)tr2+2)->it_r = tr3;
	RTAR(tr2,tr3);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A1022_42, (EIF_POINTER) _A1022_42, (EIF_POINTER)(F1668_17514),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr1 = F1162_10712(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,0,1256,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	((EIF_TYPED_VALUE *)tr2+2)->it_r = tr3;
	RTAR(tr2,tr3);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A1022_42, (EIF_POINTER) _A1022_42, (EIF_POINTER)(F1668_17514),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1120_10306(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1120_10306(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_4_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1120_10306(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_5_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1194_10946(RTCW(tr1), ((EIF_INTEGER_32) 300L), ((EIF_INTEGER_32) 300L));
	F1668_17513(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {FIXED_Z_ORDER_TEST}.set_item_positions */
void F1668_17513 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1201_11080(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_3_), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1201_11082(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_3_), ((EIF_INTEGER_32) 75L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1201_11080(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_4_), ((EIF_INTEGER_32) 50L), ((EIF_INTEGER_32) 50L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1201_11082(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_4_), ((EIF_INTEGER_32) 75L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1201_11080(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_5_), ((EIF_INTEGER_32) 100L), ((EIF_INTEGER_32) 100L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1201_11082(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_5_), ((EIF_INTEGER_32) 75L));
	RTLE;
}

/* {FIXED_Z_ORDER_TEST}.raise_button */
void F1668_17514 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1120_10315(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1120_10306(RTCW(tr1), arg1);
	F1668_17513(Current);
	RTLE;
}

void EIF_Minit1022 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
