/*
 * Code for class NOTEBOOK_TAB_POSITION_TEST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "no1004.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {NOTEBOOK_TAB_POSITION_TEST}.default_create */
void F1650_17459 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc4);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,loc5);
	RTLR(6,tr3);
	RTLR(7,loc3);
	RTLIU(8);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1201, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1194_10946(RTCW(tr1), ((EIF_INTEGER_32) 200L), ((EIF_INTEGER_32) 200L));
	loc4 = RTLNS(eif_new_type(1253, 0x00).id, 1253, _OBJSIZ_5_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc4));
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 4L))) break;
		loc2 = RTLNS(eif_new_type(1256, 0x00).id, 1256, _OBJSIZ_6_2_0_1_0_0_0_0_);
		tr1 = RTMS_EX_H("Button : ",9,2104116000);
		tr2 = eif_out__i4_s1(loc1);
		tr1 = F1086_9822(tr1, tr2);
		F1113_10182(RTCW(loc2), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1120_10306(RTCW(tr1), loc2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = eif_out__i4_s1(loc1);
		F1202_11104(RTCW(tr1), loc2, tr2);
		loc5 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_6_0_0_1_0_0_0_0_);
		tr1 = RTOSCF(17460,F1650_17460, (Current));
		tr1 = F578_4939(RTCW(tr1), loc1);
		F1113_10182(RTCW(loc5), tr1);
		F1120_10306(RTCW(loc4), loc5);
		tr1 = F1189_10885(RTCW(loc5));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,1201,1033,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNTS(typres0.id, 3, 0);
		}
		tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
		RTAR(tr2,tr3);
		tr3 = RTOSCF(17461,F1650_17461, (Current));
		ti4_1 = F585_4939(RTCW(tr3), loc1);
		((EIF_TYPED_VALUE *)tr2+2)->it_i4 = ti4_1;
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3= RTLNRF(typres0.id, (EIF_POINTER) __A560_317, (EIF_POINTER) _A560_317, (EIF_POINTER)(F1202_11098),tr2, 1, 0);
		}
		F681_5535(RTCW(tr1), tr3);
		loc1++;
	}
	loc3 = RTLNS(eif_new_type(1204, 0x00).id, 1204, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F1088_9856(RTCW(loc3));
	F1120_10306(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	F1120_10306(RTCW(loc3), loc4);
	F1203_11119(RTCW(loc3), loc4);
	RTAR(Current, loc3);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc3;
	RTLE;
}

/* {NOTEBOOK_TAB_POSITION_TEST}.item_texts */
static EIF_REFERENCE F1650_17460_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDD;
	RTLD;
	
	dftype = Dftype(Current);

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOSP (17460);
#define Result RTOSR(17460)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {577,1085,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNS(typres0.id, 577, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	tr2 = RTMS_EX_H("",0,0);
	F578_4933(RTCW(tr1), tr2, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 4L));
	Result = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {864,1085,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 4L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = RTMS_EX_H("Tab_position_top",16,801914992);
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("Tab_position_bottom",19,206087021);
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("Tab_position_left",17,1144780660);
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("Tab_position_right",18,1073812596);
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F865_6818)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (17460);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1650_17460 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(17460,F1650_17460_body,(Current));
}

/* {NOTEBOOK_TAB_POSITION_TEST}.tab_position_constants */
static EIF_REFERENCE F1650_17461_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (17461);
#define Result RTOSR(17461)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {584,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 584, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F585_4933(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 4L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	ti4_1 = ((EIF_INTEGER_32) 3L);
	F585_4957(RTCW(Result), ti4_1, ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	ti4_1 = ((EIF_INTEGER_32) 4L);
	F585_4957(RTCW(Result), ti4_1, ((EIF_INTEGER_32) 2L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	ti4_1 = ((EIF_INTEGER_32) 1L);
	F585_4957(RTCW(Result), ti4_1, ((EIF_INTEGER_32) 3L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	ti4_1 = ((EIF_INTEGER_32) 2L);
	F585_4957(RTCW(Result), ti4_1, ((EIF_INTEGER_32) 4L));
	RTOSE (17461);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1650_17461 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(17461,F1650_17461_body,(Current));
}

void EIF_Minit1004 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
