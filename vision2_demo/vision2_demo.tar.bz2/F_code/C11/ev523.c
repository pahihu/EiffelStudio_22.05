/*
 * Code for class EV_PICK_AND_DROPABLE_ACTION_SEQUENCES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev523.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PICK_AND_DROPABLE_ACTION_SEQUENCES}.drop_actions */
EIF_REFERENCE F1165_10736 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8792[Dtype(Current)-1167])(Current);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2513[Dtype(RTCW(tr1))-1378])(tr1);
	tb1 = F483_4817(RTCW(Result));
	if (tb1) {
		F943_7769(Current, Result);
	}
	RTLE;
	return Result;
}

void EIF_Minit523 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
