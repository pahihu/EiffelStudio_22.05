/*
 * Code for class EV_TREE_NODE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev543.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TREE_NODE}.parent */
EIF_REFERENCE F1185_10851 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = F1481_15844(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_TREE_NODE}.default_identifier_name */
EIF_REFERENCE F1185_10853 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1185_10851(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		Result = RTLNS(eif_new_type(1082, 0x00).id, 1082, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1081_9523(RTCW(Result), ((EIF_INTEGER_32) 5L));
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '#';
		F1083_9651(RTCW(Result), tw1);
		ti4_1 = F1120_10292(loc1, Current, ((EIF_INTEGER_32) 1L));
		F1083_9641(RTCW(Result), ti4_1);
	} else {
		Result = F1101_10103(Current);
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {EV_TREE_NODE}.is_expanded */
EIF_BOOLEAN F1185_10854 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr1 = F1481_15846(RTCW(tr1));
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		Result = F1482_15858(RTCW(tr1));
	}
	RTLE;
	return Result;
}

/* {EV_TREE_NODE}.expand */
void F1185_10855 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1482_15869(RTCW(tr1), (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_TREE_NODE}.collapse */
void F1185_10856 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1482_15869(RTCW(tr1), (EIF_BOOLEAN) 0);
	RTLE;
}

void EIF_Minit543 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
