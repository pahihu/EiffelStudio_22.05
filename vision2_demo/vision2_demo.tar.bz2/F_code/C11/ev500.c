/*
 * Code for class EV_GRID_ACTION_SEQUENCES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev500.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GRID_ACTION_SEQUENCES}.pointer_motion_item_actions */
EIF_REFERENCE F1142_10606 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8096[Dtype(Current)-1087]);
	Result = F858_6620(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_GRID_ACTION_SEQUENCES}.pointer_button_press_item_actions */
EIF_REFERENCE F1142_10607 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8096[Dtype(Current)-1087]);
	Result = F858_6622(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_GRID_ACTION_SEQUENCES}.pointer_button_release_item_actions */
EIF_REFERENCE F1142_10609 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8096[Dtype(Current)-1087]);
	Result = F858_6624(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_GRID_ACTION_SEQUENCES}.pre_draw_overlay_actions */
EIF_REFERENCE F1142_10614 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8096[Dtype(Current)-1087]);
	Result = F858_6629(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_GRID_ACTION_SEQUENCES}.post_draw_overlay_actions */
EIF_REFERENCE F1142_10615 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8096[Dtype(Current)-1087]);
	Result = F858_6630(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_GRID_ACTION_SEQUENCES}.fill_background_actions */
EIF_REFERENCE F1142_10616 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8096[Dtype(Current)-1087]);
	Result = F858_6631(RTCW(tr1));
	RTLE;
	return Result;
}

void EIF_Minit500 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
