
#ifndef _C11_ev502_
#define _C11_ev502_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1144_10622(EIF_REFERENCE);
extern void EIF_Minit502(void);
extern EIF_REFERENCE F77_1232(EIF_REFERENCE);
extern char *(*R8694[])();

#ifdef __cplusplus
}
#endif

#endif
