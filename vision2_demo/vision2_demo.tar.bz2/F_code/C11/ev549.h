
#ifndef _C11_ev549_
#define _C11_ev549_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1191_10896(EIF_REFERENCE, EIF_REFERENCE);
extern void F1191_10897(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit549(void);

#ifdef __cplusplus
}
#endif

#endif
