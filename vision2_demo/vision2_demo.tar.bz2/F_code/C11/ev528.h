
#ifndef _C11_ev528_
#define _C11_ev528_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1170_10791(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit528(void);

#ifdef __cplusplus
}
#endif

#endif
