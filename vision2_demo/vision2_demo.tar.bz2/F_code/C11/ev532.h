
#ifndef _C11_ev532_
#define _C11_ev532_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1174_10807(EIF_REFERENCE);
extern void F1174_10808(EIF_REFERENCE);
extern void EIF_Minit532(void);
extern void F1502_16060(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
