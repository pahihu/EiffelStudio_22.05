/*
 * Code for class EV_LIST_ITEM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev548.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_LIST_ITEM}.default_identifier_name */
EIF_REFERENCE F1190_10887 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = F1167_10766(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		Result = RTLNS(eif_new_type(1082, 0x00).id, 1082, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1081_9523(RTCW(Result), ((EIF_INTEGER_32) 5L));
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '#';
		F1083_9651(RTCW(Result), tw1);
		ti4_1 = F1120_10292(loc1, Current, ((EIF_INTEGER_32) 1L));
		F1083_9641(RTCW(Result), ti4_1);
	} else {
		Result = F1101_10103(Current);
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {EV_LIST_ITEM}.implementation */
EIF_REFERENCE F1190_10892 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {EV_LIST_ITEM}.create_implementation */
void F1190_10893 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1479, 0x00).id, 1479, _OBJSIZ_23_5_6_0_0_0_0_0_);
	F1480_15802(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit548 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
