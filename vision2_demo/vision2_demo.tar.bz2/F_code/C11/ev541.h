
#ifndef _C11_ev541_
#define _C11_ev541_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1183_10844(EIF_REFERENCE);
extern void EIF_Minit541(void);
extern EIF_REFERENCE F153_3020(EIF_REFERENCE);
extern char *(*R8848[])();

#ifdef __cplusplus
}
#endif

#endif
