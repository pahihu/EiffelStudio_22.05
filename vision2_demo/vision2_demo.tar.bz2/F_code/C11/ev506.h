
#ifndef _C11_ev506_
#define _C11_ev506_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1148_10643(EIF_REFERENCE);
extern EIF_REFERENCE F1148_10648(EIF_REFERENCE);
extern void F1148_10649(EIF_REFERENCE);
extern void EIF_Minit506(void);
extern EIF_REFERENCE F1360_13755(EIF_REFERENCE);
extern void F1360_13754(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
