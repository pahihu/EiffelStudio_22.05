
#ifndef _C11_ev507_
#define _C11_ev507_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1149_10651(EIF_REFERENCE);
extern void EIF_Minit507(void);
extern EIF_REFERENCE F1362_13777(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
