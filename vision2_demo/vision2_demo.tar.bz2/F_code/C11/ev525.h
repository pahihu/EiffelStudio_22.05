
#ifndef _C11_ev525_
#define _C11_ev525_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1167_10766(EIF_REFERENCE);
extern void EIF_Minit525(void);
extern char *(*R12331[])();
extern long O8096[];

#ifdef __cplusplus
}
#endif

#endif
