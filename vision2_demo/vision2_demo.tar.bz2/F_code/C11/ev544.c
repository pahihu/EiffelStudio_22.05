/*
 * Code for class EV_DYNAMIC_TREE_ITEM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev544.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DYNAMIC_TREE_ITEM}.set_subtree_function */
void F1186_10863 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_6_) != NULL)) {
		F1186_10864(Current);
	}
	tr1 = F1184_10849(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A544_257, (EIF_POINTER) _A544_257, (EIF_POINTER)(F1186_10874),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	F1186_10875(Current);
	F1186_10867(Current, ((EIF_INTEGER_32) 1000L));
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg1;
	RTLE;
}

/* {EV_DYNAMIC_TREE_ITEM}.remove_subtree_function */
void F1186_10864 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) NULL;
	F681_5547(RTCV(F1184_10849(Current)));
	F1186_10876(Current);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) NULL;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_8_1_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTLE;
}

/* {EV_DYNAMIC_TREE_ITEM}.set_subtree_function_timeout */
void F1186_10867 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_8_1_0_1_) = (EIF_INTEGER_32) arg1;
}

/* {EV_DYNAMIC_TREE_ITEM}.implementation */
EIF_REFERENCE F1186_10870 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {EV_DYNAMIC_TREE_ITEM}.create_implementation */
void F1186_10871 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1481, 0x00).id, 1481, _OBJSIZ_25_6_6_3_0_1_0_0_);
	F1482_15856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {EV_DYNAMIC_TREE_ITEM}.subtree_function_item */
EIF_REFERENCE F1186_10873 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		if ((EIF_BOOLEAN)(loc1 == NULL)) {
			loc1 = RTLNS(eif_new_type(1559, 0x00).id, 1559, _OBJSIZ_2_0_0_2_0_0_0_1_);
			F1560_17138(RTCW(loc1));
			RTAR(Current, loc1);
			*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) loc1;
			loc2 = (EIF_REFERENCE) loc1;
			loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			loc2 = RTLNS(eif_new_type(1559, 0x00).id, 1559, _OBJSIZ_2_0_0_2_0_0_0_1_);
			F1560_17138(RTCW(loc2));
		}
		tb1 = '\01';
		if (!loc3) {
			tr1 = F1560_17160(RTCW(loc2), loc1);
			tr8_1 = F253_3986(RTCW(tr1));
			tb1 = (EIF_BOOLEAN) eif_is_greater_equal_real_64 (tr8_1, (EIF_REAL_64) ((EIF_REAL_64) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_8_1_0_1_)) /  (EIF_REAL_64) (((EIF_INTEGER_32) 1000L))));
		}
		if (tb1) {
			Result = F1073_9384(loc4, NULL);
			RTAR(Current, loc2);
			*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) loc2;
		}
	}
	RTLE;
	return Result;
}

/* {EV_DYNAMIC_TREE_ITEM}.fill_from_subtree_function */
void F1186_10874 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		ti4_1 = F1308_13070(RTCW(tr1));
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1307_13045(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1307_13061(RTCW(tr1));
	}
	loc1 = F1186_10873(Current);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {455,1184,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc2 = loc1;
			loc2 = RTRV(typres0, loc2);
		}
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4456[Dtype(RTCW(loc2))-638])(loc2);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R4416[Dtype(RTCW(loc1))-638])(loc1);
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4415[Dtype(RTCW(loc1))-638])(loc1);
			if (tb1) break;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4414[Dtype(RTCW(loc1))-638])(loc1);
			F1307_13052(RTCW(tr1), tr2);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R4429[Dtype(RTCW(loc1))-638])(loc1);
		}
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			RTCT0("c /= Void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4458[Dtype(RTCW(loc2))-638])(loc2, loc3);
		}
	}
	F1186_10876(Current);
	RTLE;
}

/* {EV_DYNAMIC_TREE_ITEM}.ensure_expandable */
void F1186_10875 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1482_15892(RTCW(tr1));
	RTLE;
}

/* {EV_DYNAMIC_TREE_ITEM}.remove_expandable */
void F1186_10876 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1482_15893(RTCW(tr1));
	RTLE;
}

void EIF_Minit544 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
