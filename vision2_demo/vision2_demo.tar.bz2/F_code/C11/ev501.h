
#ifndef _C11_ev501_
#define _C11_ev501_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1143_10619(EIF_REFERENCE);
extern EIF_REFERENCE F1143_10620(EIF_REFERENCE);
extern void EIF_Minit501(void);
extern EIF_REFERENCE F76_1228(EIF_REFERENCE);
extern EIF_REFERENCE F76_1230(EIF_REFERENCE);
extern long O8096[];

#ifdef __cplusplus
}
#endif

#endif
