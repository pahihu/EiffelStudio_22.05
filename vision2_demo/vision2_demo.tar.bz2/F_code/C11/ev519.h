
#ifndef _C11_ev519_
#define _C11_ev519_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1161_10709(EIF_REFERENCE);
extern void EIF_Minit519(void);
extern EIF_REFERENCE F91_1284(EIF_REFERENCE);
extern char *(*R8770[])();

#ifdef __cplusplus
}
#endif

#endif
