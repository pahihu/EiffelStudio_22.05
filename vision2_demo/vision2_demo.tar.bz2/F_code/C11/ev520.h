
#ifndef _C11_ev520_
#define _C11_ev520_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1162_10712(EIF_REFERENCE);
extern void EIF_Minit520(void);
extern EIF_REFERENCE F92_1289(EIF_REFERENCE);
extern char *(*R8773[])();

#ifdef __cplusplus
}
#endif

#endif
