
#ifndef _C11_ev514_
#define _C11_ev514_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1156_10691(EIF_REFERENCE);
extern void EIF_Minit514(void);
extern EIF_REFERENCE F84_1258(EIF_REFERENCE);
extern long O8096[];

#ifdef __cplusplus
}
#endif

#endif
