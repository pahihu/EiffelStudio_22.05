
#ifndef _C11_ev530_
#define _C11_ev530_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1172_10794(EIF_REFERENCE);
extern void F1172_10795(EIF_REFERENCE);
extern void EIF_Minit530(void);
extern void F1486_15926(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
