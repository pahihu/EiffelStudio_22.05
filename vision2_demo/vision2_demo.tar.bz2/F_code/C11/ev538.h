
#ifndef _C11_ev538_
#define _C11_ev538_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1180_10833(EIF_REFERENCE);
extern void F1180_10834(EIF_REFERENCE);
extern void EIF_Minit538(void);
extern void F1496_15978(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
