/*
 * Code for class EV_MULTI_COLUMN_LIST_ACTION_SEQUENCES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev516.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_MULTI_COLUMN_LIST_ACTION_SEQUENCES}.select_actions */
EIF_REFERENCE F1158_10697 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8096[Dtype(Current)-1087]);
	Result = F88_1270(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_MULTI_COLUMN_LIST_ACTION_SEQUENCES}.deselect_actions */
EIF_REFERENCE F1158_10698 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8096[Dtype(Current)-1087]);
	Result = F88_1272(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_MULTI_COLUMN_LIST_ACTION_SEQUENCES}.column_title_click_actions */
EIF_REFERENCE F1158_10699 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8096[Dtype(Current)-1087]);
	Result = F88_1274(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_MULTI_COLUMN_LIST_ACTION_SEQUENCES}.column_resized_actions */
EIF_REFERENCE F1158_10700 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8096[Dtype(Current)-1087]);
	Result = F88_1276(RTCW(tr1));
	RTLE;
	return Result;
}

void EIF_Minit516 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
