
#ifndef _C11_ev523_
#define _C11_ev523_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1165_10736(EIF_REFERENCE);
extern void EIF_Minit523(void);
extern void F943_7769(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F483_4817(EIF_REFERENCE);
extern char *(*R8792[])();
extern char *(*R2513[])();

#ifdef __cplusplus
}
#endif

#endif
