
#ifndef _C11_ev511_
#define _C11_ev511_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1153_10681(EIF_REFERENCE);
extern EIF_REFERENCE F1153_10682(EIF_REFERENCE);
extern void EIF_Minit511(void);
extern EIF_REFERENCE F81_1247(EIF_REFERENCE);
extern EIF_REFERENCE F81_1245(EIF_REFERENCE);
extern char *(*R8742[])();

#ifdef __cplusplus
}
#endif

#endif
