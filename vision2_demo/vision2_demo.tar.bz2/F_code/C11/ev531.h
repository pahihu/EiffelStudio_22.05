
#ifndef _C11_ev531_
#define _C11_ev531_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1173_10796(EIF_REFERENCE);
extern EIF_REFERENCE F1173_10804(EIF_REFERENCE);
extern void F1173_10805(EIF_REFERENCE);
extern void EIF_Minit531(void);
extern EIF_REFERENCE F1171_10793(EIF_REFERENCE);
extern void F1502_16060(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
