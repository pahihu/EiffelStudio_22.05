
#ifndef _C11_ev536_
#define _C11_ev536_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1178_10824(EIF_REFERENCE);
extern void F1178_10825(EIF_REFERENCE);
extern void EIF_Minit536(void);
extern void F1494_15958(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
