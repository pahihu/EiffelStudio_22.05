
#ifndef _C11_ev510_
#define _C11_ev510_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1152_10678(EIF_REFERENCE);
extern void EIF_Minit510(void);
extern EIF_REFERENCE F80_1241(EIF_REFERENCE);
extern char *(*R8739[])();

#ifdef __cplusplus
}
#endif

#endif
