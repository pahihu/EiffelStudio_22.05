/*
 * Code for class EV_PICK_AND_DROPABLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev524.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PICK_AND_DROPABLE}.configurable_target_menu_handler */
EIF_REFERENCE F1166_10745 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8096[Dtype(Current)-1087]);
	Result = *(EIF_REFERENCE *)(RTCW(tr1) + O11145[Dtype(tr1)-1362]);
	RTLE;
	return Result;
}

/* {EV_PICK_AND_DROPABLE}.set_pebble_function */
void F1166_10748 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8096[Dtype(Current)-1087]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11153[Dtype(RTCW(tr1))-1378])(tr1, arg1);
	RTLE;
}

/* {EV_PICK_AND_DROPABLE}.set_accept_cursor */
void F1166_10755 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8096[Dtype(Current)-1087]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11163[Dtype(RTCW(tr1))-1378])(tr1, arg1);
	RTLE;
}

/* {EV_PICK_AND_DROPABLE}.set_deny_cursor */
void F1166_10756 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8096[Dtype(Current)-1087]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R11164[Dtype(RTCW(tr1))-1378])(tr1, arg1);
	RTLE;
}

void EIF_Minit524 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
