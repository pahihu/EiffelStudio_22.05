
#ifndef _C11_ev515_
#define _C11_ev515_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1157_10693(EIF_REFERENCE);
extern EIF_REFERENCE F1157_10694(EIF_REFERENCE);
extern void EIF_Minit515(void);
extern EIF_REFERENCE F85_1260(EIF_REFERENCE);
extern EIF_REFERENCE F85_1261(EIF_REFERENCE);
extern long O8096[];

#ifdef __cplusplus
}
#endif

#endif
