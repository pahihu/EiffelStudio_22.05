
#ifndef _C11_ev505_
#define _C11_ev505_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1147_10638(EIF_REFERENCE);
extern void F1147_10639(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1147_10640(EIF_REFERENCE);
extern void F1147_10641(EIF_REFERENCE);
extern void EIF_Minit505(void);
extern EIF_REFERENCE F1359_13750(EIF_REFERENCE);
extern void F1359_13751(EIF_REFERENCE, EIF_REFERENCE);
extern void F1359_13749(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
