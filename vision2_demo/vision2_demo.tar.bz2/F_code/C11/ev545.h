
#ifndef _C11_ev545_
#define _C11_ev545_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1187_10879(EIF_REFERENCE);
extern void F1187_10880(EIF_REFERENCE);
extern void EIF_Minit545(void);
extern void F1482_15856(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
