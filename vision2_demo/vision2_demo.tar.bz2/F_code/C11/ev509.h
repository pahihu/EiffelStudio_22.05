
#ifndef _C11_ev509_
#define _C11_ev509_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1151_10676(EIF_REFERENCE);
extern void EIF_Minit509(void);
extern EIF_REFERENCE F78_1236(EIF_REFERENCE);
extern char *(*R8737[])();

#ifdef __cplusplus
}
#endif

#endif
