
#ifndef _C11_ev503_
#define _C11_ev503_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1145_10628(EIF_REFERENCE);
extern void F1145_10630(EIF_REFERENCE, EIF_REFERENCE);
extern void F1145_10632(EIF_REFERENCE);
extern void EIF_Minit503(void);
extern char *(*R11104[])();
extern long O11134[];

#ifdef __cplusplus
}
#endif

#endif
