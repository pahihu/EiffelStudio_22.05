
#ifndef _C1_ev25_
#define _C1_ev25_

#ifdef __cplusplus
extern "C" {
#endif

extern void F25_535(EIF_REFERENCE);
extern void F25_547(EIF_REFERENCE, EIF_REFERENCE);
extern void F25_548(EIF_REFERENCE, EIF_NATURAL_32, EIF_NATURAL_32);
extern void EIF_Minit25(void);
extern EIF_NATURAL_32 F1287_12442(EIF_REFERENCE, EIF_NATURAL_32, EIF_NATURAL_32);

#ifdef __cplusplus
}
#endif

#endif
