
#ifndef _C1_ev29_
#define _C1_ev29_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F29_585(EIF_REFERENCE);
extern void F29_589(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit29(void);
extern void F1078_9393(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
