/*
 * Code for class GDK_CAIRO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gd13.h"
#include "ev_gtk.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F13_212
static EIF_POINTER inline_F13_212 (void)
{
	return cairo_region_create();
	;
}
#define INLINE_F13_212
#endif
#ifndef INLINE_F13_213
static void inline_F13_213 (EIF_POINTER arg1)
{
	cairo_region_destroy(arg1)
	;
}
#define INLINE_F13_213
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GDK_CAIRO}.set_source_pixbuf */
void F13_209 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4)
{
	GTCX
	
	gdk_cairo_set_source_pixbuf((cairo_t*) arg1, (GdkPixbuf*) arg2, (double) arg3, (double) arg4);
	
}

/* {GDK_CAIRO}.cairo_region_create */
EIF_POINTER F13_212 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F13_212 ();
	return Result;
}

/* {GDK_CAIRO}.cairo_region_destroy */
void F13_213 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	inline_F13_213 ((EIF_POINTER) arg1);
}

void EIF_Minit13 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
