
#ifndef _C1_te33_
#define _C1_te33_

#ifdef __cplusplus
extern "C" {
#endif

extern void F33_610(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit33(void);

#ifdef __cplusplus
}
#endif

#endif
