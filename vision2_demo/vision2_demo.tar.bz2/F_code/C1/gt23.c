/*
 * Code for class GTK_PROPERTIES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gt23.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F23_491
static EIF_POINTER inline_F23_491 (void)
{
	static char *v = "x-offset";
return (EIF_POINTER) v;
	;
}
#define INLINE_F23_491
#endif
#ifndef INLINE_F23_498
static EIF_POINTER inline_F23_498 (void)
{
	static char *v = "foreground";
return (EIF_POINTER) v;
	;
}
#define INLINE_F23_498
#endif
#ifndef INLINE_F23_499
static EIF_POINTER inline_F23_499 (void)
{
	static char *v = "foreground-rgba";
return (EIF_POINTER) v;
	;
}
#define INLINE_F23_499
#endif
#ifndef INLINE_F23_500
static EIF_POINTER inline_F23_500 (void)
{
	static char *v = "background";
return (EIF_POINTER) v;
	;
}
#define INLINE_F23_500
#endif
#ifndef INLINE_F23_501
static EIF_POINTER inline_F23_501 (void)
{
	static char *v = "background-rgba";
return (EIF_POINTER) v;
	;
}
#define INLINE_F23_501
#endif
#ifndef INLINE_F23_502
static EIF_POINTER inline_F23_502 (void)
{
	static char *v = "family";
return (EIF_POINTER) v;
	;
}
#define INLINE_F23_502
#endif
#ifndef INLINE_F23_503
static EIF_POINTER inline_F23_503 (void)
{
	static char *v = "size";
return (EIF_POINTER) v;
	;
}
#define INLINE_F23_503
#endif
#ifndef INLINE_F23_504
static EIF_POINTER inline_F23_504 (void)
{
	static char *v = "style";
return (EIF_POINTER) v;
	;
}
#define INLINE_F23_504
#endif
#ifndef INLINE_F23_505
static EIF_POINTER inline_F23_505 (void)
{
	static char *v = "weight";
return (EIF_POINTER) v;
	;
}
#define INLINE_F23_505
#endif
#ifndef INLINE_F23_506
static EIF_POINTER inline_F23_506 (void)
{
	static char *v = "underline";
return (EIF_POINTER) v;
	;
}
#define INLINE_F23_506
#endif
#ifndef INLINE_F23_507
static EIF_POINTER inline_F23_507 (void)
{
	static char *v = "strikethrough";
return (EIF_POINTER) v;
	;
}
#define INLINE_F23_507
#endif
#ifndef INLINE_F23_508
static EIF_POINTER inline_F23_508 (void)
{
	static char *v = "rise";
return (EIF_POINTER) v;
	;
}
#define INLINE_F23_508
#endif
#ifndef INLINE_F23_509
static EIF_POINTER inline_F23_509 (void)
{
	static char *v = "xalign";
return (EIF_POINTER) v;
	;
}
#define INLINE_F23_509
#endif
#ifndef INLINE_F23_510
static EIF_POINTER inline_F23_510 (void)
{
	static char *v = "justify";
return (EIF_POINTER) v;
	;
}
#define INLINE_F23_510
#endif
#ifndef INLINE_F23_511
static EIF_POINTER inline_F23_511 (void)
{
	static char *v = "justification";
return (EIF_POINTER) v;
	;
}
#define INLINE_F23_511
#endif
#ifndef INLINE_F23_512
static EIF_POINTER inline_F23_512 (void)
{
	static char *v = "left-margin";
return (EIF_POINTER) v;
	;
}
#define INLINE_F23_512
#endif
#ifndef INLINE_F23_513
static EIF_POINTER inline_F23_513 (void)
{
	static char *v = "right-margin";
return (EIF_POINTER) v;
	;
}
#define INLINE_F23_513
#endif
#ifndef INLINE_F23_514
static EIF_POINTER inline_F23_514 (void)
{
	static char *v = "pixels-above-lines";
return (EIF_POINTER) v;
	;
}
#define INLINE_F23_514
#endif
#ifndef INLINE_F23_515
static EIF_POINTER inline_F23_515 (void)
{
	static char *v = "pixels-below-lines";
return (EIF_POINTER) v;
	;
}
#define INLINE_F23_515
#endif
#ifndef INLINE_F23_517
static EIF_POINTER inline_F23_517 (void)
{
	static char *v = "gtk-menu-bar-accel";
return (EIF_POINTER) v;
	;
}
#define INLINE_F23_517
#endif
#ifndef INLINE_F23_518
static EIF_POINTER inline_F23_518 (void)
{
	static char *v = "gtk-menu-images";
return (EIF_POINTER) v;
	;
}
#define INLINE_F23_518
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GTK_PROPERTIES}.x_offset */
EIF_POINTER F23_491 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F23_491 ();
	return Result;
}

/* {GTK_PROPERTIES}.foreground */
EIF_POINTER F23_498 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F23_498 ();
	return Result;
}

/* {GTK_PROPERTIES}.foreground_rgba */
EIF_POINTER F23_499 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F23_499 ();
	return Result;
}

/* {GTK_PROPERTIES}.background */
EIF_POINTER F23_500 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F23_500 ();
	return Result;
}

/* {GTK_PROPERTIES}.background_rgba */
EIF_POINTER F23_501 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F23_501 ();
	return Result;
}

/* {GTK_PROPERTIES}.family */
EIF_POINTER F23_502 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F23_502 ();
	return Result;
}

/* {GTK_PROPERTIES}.size */
EIF_POINTER F23_503 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F23_503 ();
	return Result;
}

/* {GTK_PROPERTIES}.style */
EIF_POINTER F23_504 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F23_504 ();
	return Result;
}

/* {GTK_PROPERTIES}.weight */
EIF_POINTER F23_505 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F23_505 ();
	return Result;
}

/* {GTK_PROPERTIES}.underline */
EIF_POINTER F23_506 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F23_506 ();
	return Result;
}

/* {GTK_PROPERTIES}.strikethrough */
EIF_POINTER F23_507 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F23_507 ();
	return Result;
}

/* {GTK_PROPERTIES}.rise */
EIF_POINTER F23_508 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F23_508 ();
	return Result;
}

/* {GTK_PROPERTIES}.xalign */
EIF_POINTER F23_509 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F23_509 ();
	return Result;
}

/* {GTK_PROPERTIES}.justify */
EIF_POINTER F23_510 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F23_510 ();
	return Result;
}

/* {GTK_PROPERTIES}.justification */
EIF_POINTER F23_511 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F23_511 ();
	return Result;
}

/* {GTK_PROPERTIES}.left_margin */
EIF_POINTER F23_512 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F23_512 ();
	return Result;
}

/* {GTK_PROPERTIES}.right_margin */
EIF_POINTER F23_513 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F23_513 ();
	return Result;
}

/* {GTK_PROPERTIES}.pixels_above_lines */
EIF_POINTER F23_514 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F23_514 ();
	return Result;
}

/* {GTK_PROPERTIES}.pixels_below_lines */
EIF_POINTER F23_515 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F23_515 ();
	return Result;
}

/* {GTK_PROPERTIES}.gtk_menu_bar_accel */
EIF_POINTER F23_517 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F23_517 ();
	return Result;
}

/* {GTK_PROPERTIES}.gtk_menu_icons */
EIF_POINTER F23_518 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F23_518 ();
	return Result;
}

void EIF_Minit23 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
