
#ifndef _C1_gd15_
#define _C1_gd15_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F15_340(EIF_REFERENCE, EIF_INTEGER_32*, EIF_INTEGER_32*);
extern void F15_341(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32*, EIF_INTEGER_32*);
extern EIF_POINTER F15_342(EIF_REFERENCE);
extern EIF_POINTER F15_344(EIF_REFERENCE);
extern EIF_POINTER F15_345(EIF_REFERENCE);
extern EIF_INTEGER_32 F15_346(EIF_REFERENCE);
extern void EIF_Minit15(void);

#ifdef __cplusplus
}
#endif

#endif
