/*
 * Code for class EV_GTK_EVENT_STRINGS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev16.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GTK_EVENT_STRINGS}.set_focus_event_name */

EIF_REFERENCE F16_354 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (354,RTMS_EX_H("set-focus",9,577130099));
}

/* {EV_GTK_EVENT_STRINGS}.configure_event_name */

EIF_REFERENCE F16_355 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (355,RTMS_EX_H("configure-event",15,1205453684));
}

/* {EV_GTK_EVENT_STRINGS}.map_event_name */

EIF_REFERENCE F16_358 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (358,RTMS_EX_H("map-event",9,474090100));
}

/* {EV_GTK_EVENT_STRINGS}.unmap_event_name */

EIF_REFERENCE F16_359 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (359,RTMS_EX_H("unmap-event",11,77806708));
}

/* {EV_GTK_EVENT_STRINGS}.hide_signal_name */

EIF_REFERENCE F16_360 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (360,RTMS_EX_H("hide",4,1751737445));
}

/* {EV_GTK_EVENT_STRINGS}.size_allocate_event_name */

EIF_REFERENCE F16_364 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (364,RTMS_EX_H("size-allocate",13,769151077));
}

/* {EV_GTK_EVENT_STRINGS}.clicked_event_name */

EIF_REFERENCE F16_367 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (367,RTMS_EX_H("clicked",7,169941860));
}

/* {EV_GTK_EVENT_STRINGS}.draw_event_name */

EIF_REFERENCE F16_369 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (369,RTMS_EX_H("draw",4,1685217655));
}

/* {EV_GTK_EVENT_STRINGS}.commit_event_name */

EIF_REFERENCE F16_370 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (370,RTMS_EX_H("commit",6,2031381364));
}

/* {EV_GTK_EVENT_STRINGS}.changed_event_name */

EIF_REFERENCE F16_371 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (371,RTMS_EX_H("changed",7,346303332));
}

/* {EV_GTK_EVENT_STRINGS}.mark_set_event_name */

EIF_REFERENCE F16_372 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (372,RTMS_EX_H("mark_set",8,1281129588));
}

/* {EV_GTK_EVENT_STRINGS}.value_changed_event_name */

EIF_REFERENCE F16_373 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (373,RTMS_EX_H("value-changed",13,1161067364));
}

/* {EV_GTK_EVENT_STRINGS}.realize_event_name */

EIF_REFERENCE F16_374 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (374,RTMS_EX_H("realize",7,1414294885));
}

/* {EV_GTK_EVENT_STRINGS}.response_event_name */

EIF_REFERENCE F16_375 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (375,RTMS_EX_H("response",8,1418183525));
}

/* {EV_GTK_EVENT_STRINGS}.row_collapsed_event_name */

EIF_REFERENCE F16_376 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (376,RTMS_EX_H("row-collapsed",13,409101156));
}

/* {EV_GTK_EVENT_STRINGS}.row_expanded_event_name */

EIF_REFERENCE F16_377 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (377,RTMS_EX_H("row-expanded",12,747253348));
}

/* {EV_GTK_EVENT_STRINGS}.switch_page_event_name */

EIF_REFERENCE F16_378 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (378,RTMS_EX_H("switch-page",11,350618981));
}

/* {EV_GTK_EVENT_STRINGS}.toggled_event_name */

EIF_REFERENCE F16_379 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (379,RTMS_EX_H("toggled",7,209460068));
}

/* {EV_GTK_EVENT_STRINGS}.notify_width_event_name */

EIF_REFERENCE F16_380 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (380,RTMS_EX_H("notify::width",13,1221810280));
}

/* {EV_GTK_EVENT_STRINGS}.scroll_event_name */

EIF_REFERENCE F16_381 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (381,RTMS_EX_H("scroll-event",12,2102824820));
}

/* {EV_GTK_EVENT_STRINGS}.commit_event_string */
static EIF_REFERENCE F16_400_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (400);
#define Result RTOSR(400)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(927, 0x00).id, 927, _OBJSIZ_0_1_0_1_0_1_0_0_);
	tr2 = RTOSCF(370,F16_370, (Current));
	F928_6962(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (400);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F16_400 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(400,F16_400_body,(Current));
}

void EIF_Minit16 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
