/*
 * Code for class GTK_ORIENTATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gt17.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F17_401
static EIF_NATURAL_8 inline_F17_401 (void)
{
	return GTK_ORIENTATION_HORIZONTAL
	;
}
#define INLINE_F17_401
#endif
#ifndef INLINE_F17_402
static EIF_NATURAL_8 inline_F17_402 (void)
{
	return GTK_ORIENTATION_VERTICAL
	;
}
#define INLINE_F17_402
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GTK_ORIENTATION}.gtk_orientation_horizontal */
EIF_NATURAL_8 F17_401 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	
	
	Result = inline_F17_401 ();
	return Result;
}

/* {GTK_ORIENTATION}.gtk_orientation_vertical */
EIF_NATURAL_8 F17_402 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	
	
	Result = inline_F17_402 ();
	return Result;
}

void EIF_Minit17 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
