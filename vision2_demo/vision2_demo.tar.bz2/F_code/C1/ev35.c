/*
 * Code for class EV_STOCK_COLORS_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev35.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F101_1784
static void inline_F101_1784 (EIF_POINTER arg1)
{
	gtk_widget_destroy((GtkWidget*) arg1)
	;
}
#define INLINE_F101_1784
#endif
#ifndef INLINE_F101_1684
static EIF_POINTER inline_F101_1684 (void)
{
	return (EIF_POINTER) (GTK_STYLE_PROPERTY_COLOR)
	;
}
#define INLINE_F101_1684
#endif
#ifndef INLINE_F101_1706
static void inline_F101_1706 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_POINTER arg3, EIF_POINTER arg4)
{
	gtk_style_context_get (arg1, arg2, arg3, arg4, NULL)
	;
}
#define INLINE_F101_1706
#endif
#ifndef INLINE_F101_1683
static EIF_POINTER inline_F101_1683 (void)
{
	return (EIF_POINTER) (GTK_STYLE_PROPERTY_BACKGROUND_COLOR)
	;
}
#define INLINE_F101_1683
#endif
#ifndef INLINE_F101_1685
static EIF_POINTER inline_F101_1685 (void)
{
	return (EIF_POINTER) (GTK_STYLE_PROPERTY_FONT)
	;
}
#define INLINE_F101_1685
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_STOCK_COLORS_IMP}.default_background_color */
EIF_REFERENCE F35_625 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	loc1 = (EIF_POINTER) gtk_dialog_new();
	ti4_1 = (EIF_INTEGER_32) GTK_STATE_NORMAL;
	Result = F35_632(Current, loc1, ((EIF_INTEGER_32) 4L), ti4_1);
	inline_F101_1784(loc1);
	RTLE;
	return Result;
}

/* {EV_STOCK_COLORS_IMP}.default_foreground_color */
EIF_REFERENCE F35_628 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	loc1 = (EIF_POINTER) gtk_dialog_new();
	ti4_1 = (EIF_INTEGER_32) GTK_STATE_NORMAL;
	Result = F35_632(Current, loc1, ((EIF_INTEGER_32) 3L), ti4_1);
	inline_F101_1784(loc1);
	RTLE;
	return Result;
}

/* {EV_STOCK_COLORS_IMP}.color_from_state */
EIF_REFERENCE F35_632 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REAL_32 loc3 = (EIF_REAL_32) 0;
	EIF_REAL_32 loc4 = (EIF_REAL_32) 0;
	EIF_REAL_32 loc5 = (EIF_REAL_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REAL_32 loc7 = (EIF_REAL_32) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc6);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	loc1 = (EIF_POINTER) gtk_widget_get_style_context((GtkWidget*) arg1);
	gtk_style_context_save((GtkStyleContext*) loc1);
	gtk_style_context_set_state((GtkStyleContext*) loc1, (GtkStateFlags) arg3);
	switch (arg2) {
		case 3L:
			ti4_1 = (EIF_INTEGER_32) gtk_style_context_get_state((GtkStyleContext*) loc1);
			tp1 = inline_F101_1684();
			inline_F101_1706(loc1, ti4_1, tp1, (EIF_POINTER *) &(loc2));
			break;
		case 4L:
			ti4_1 = (EIF_INTEGER_32) gtk_style_context_get_state((GtkStyleContext*) loc1);
			tp1 = inline_F101_1683();
			inline_F101_1706(loc1, ti4_1, tp1, (EIF_POINTER *) &(loc2));
			break;
		case 1L:
			ti4_1 = (EIF_INTEGER_32) gtk_style_context_get_state((GtkStyleContext*) loc1);
			tp1 = inline_F101_1685();
			inline_F101_1706(loc1, ti4_1, tp1, (EIF_POINTER *) &(loc2));
			break;
		case 2L:
			loc6 = RTLNS(eif_new_type(927, 0x00).id, 927, _OBJSIZ_0_1_0_1_0_1_0_0_);
			tr1 = RTMS_EX_H("background-color",16,693867890);
			F928_6962(RTCW(loc6), tr1);
			ti4_1 = (EIF_INTEGER_32) gtk_style_context_get_state((GtkStyleContext*) loc1);
			tp1 = *(EIF_POINTER *)(RTCW(loc6)+ _PTROFF_0_1_0_1_0_0_);
			inline_F101_1706(loc1, ti4_1, tp1, (EIF_POINTER *) &(loc2));
			break;
		default:
			RTEC(EN_WHEN);
	}
	gtk_style_context_restore((GtkStyleContext*) loc1);
	tr8_1 = (EIF_REAL_64) (((GdkRGBA *)loc2)->red);
	loc3 = (EIF_REAL_32) (tr8_1);
	tr8_1 = (EIF_REAL_64) (((GdkRGBA *)loc2)->green);
	loc4 = (EIF_REAL_32) (tr8_1);
	tr8_1 = (EIF_REAL_64) (((GdkRGBA *)loc2)->blue);
	loc5 = (EIF_REAL_32) (tr8_1);
	Result = RTLNS(eif_new_type(1096, 0x00).id, 1096, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1097_10019(RTCW(Result), loc3, loc4, loc5);
	gdk_rgba_free((GdkRGBA*) loc2);
	RTLE;
	return Result;
}

void EIF_Minit35 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
