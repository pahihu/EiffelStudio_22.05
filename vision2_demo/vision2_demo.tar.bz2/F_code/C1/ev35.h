
#ifndef _C1_ev35_
#define _C1_ev35_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F35_625(EIF_REFERENCE);
extern EIF_REFERENCE F35_628(EIF_REFERENCE);
extern EIF_REFERENCE F35_632(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit35(void);
extern void F928_6962(EIF_REFERENCE, EIF_REFERENCE);
extern void F1097_10019(EIF_REFERENCE, EIF_REAL_32, EIF_REAL_32, EIF_REAL_32);

#ifdef __cplusplus
}
#endif

#endif
