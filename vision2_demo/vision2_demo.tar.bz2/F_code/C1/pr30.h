
#ifndef _C1_pr30_
#define _C1_pr30_

#ifdef __cplusplus
extern "C" {
#endif
RTOSHF (EIF_REFERENCE, 591)


extern EIF_REFERENCE F30_591(EIF_REFERENCE);
extern void EIF_Minit30(void);

#ifdef __cplusplus
}
#endif

#endif
