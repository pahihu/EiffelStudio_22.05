/*
 * Code for class PRODUCT_NAMES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pr30.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PRODUCT_NAMES}.workbench_name */

EIF_REFERENCE F30_591 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (591,RTMS_EX_H("EiffelStudio",12,1072716399));
}

void EIF_Minit30 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
