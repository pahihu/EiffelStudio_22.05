
#ifndef _C1_gt9_
#define _C1_gt9_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F9_105(EIF_REFERENCE);
extern EIF_BOOLEAN F9_106(EIF_REFERENCE, EIF_POINTER, EIF_POINTER, EIF_INTEGER_32, EIF_POINTER*);
extern void EIF_Minit9(void);

#ifdef __cplusplus
}
#endif

#endif
