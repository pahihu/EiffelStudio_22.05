
#ifndef _C1_ev21_
#define _C1_ev21_

#ifdef __cplusplus
extern "C" {
#endif

extern void F21_475(EIF_REFERENCE);
extern void F21_476(EIF_REFERENCE);
extern void F21_477(EIF_REFERENCE);
extern EIF_BOOLEAN F21_478(EIF_REFERENCE);
extern EIF_BOOLEAN F21_479(EIF_REFERENCE);
extern void EIF_Minit21(void);

#ifdef __cplusplus
}
#endif

#endif
