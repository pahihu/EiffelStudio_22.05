/*
 * Code for class UUID_GENERATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "uu7.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UUID_GENERATOR}.generate_uuid */
EIF_REFERENCE F7_100 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(962, 0x00).id, 962, _OBJSIZ_0_0_3_1_0_0_1_0_);
	tr1 = RTOSCF(103,F7_103, (Current));
	tr2 = RTOSCF(102,F7_102, (Current));
	tr1 = F7_101(Current, tr1, tr2);
	F963_8049(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {UUID_GENERATOR}.segments */
EIF_REFERENCE F7_101 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_8 tu1_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {580,1012,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 580, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F581_4933(RTCW(Result), ((EIF_NATURAL_8) 0U), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 16L));
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O3285[Dtype(arg1)-180]);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 16L))) break;
		if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 2147483647L))) {
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			ti4_1 = F7_104(Current);
			F708_5998(RTCW(arg2), ti4_1);
		} else {
			loc2++;
		}
		ti4_1 = F708_6006(RTCW(arg2), loc2);
		tu1_1 = (EIF_NATURAL_8) ti4_1;
		F581_4957(RTCW(Result), tu1_1, loc1);
		loc1++;
	}
	F182_3358(RTCW(arg1), loc2);
	tu1_1 = F581_4938(RTCW(Result), ((EIF_INTEGER_32) 7L));
	tu1_1 = eif_bit_and(tu1_1,(EIF_NATURAL_8) ((EIF_INTEGER_32) 15L));
	tu1_1 = eif_bit_or(tu1_1,(EIF_NATURAL_8) ((EIF_INTEGER_32) 64L));
	F581_4957(RTCW(Result), tu1_1, ((EIF_INTEGER_32) 7L));
	tu1_1 = F581_4938(RTCW(Result), ((EIF_INTEGER_32) 9L));
	tu1_1 = eif_bit_and(tu1_1,(EIF_NATURAL_8) ((EIF_INTEGER_32) 63L));
	tu1_1 = eif_bit_or(tu1_1,(EIF_NATURAL_8) ((EIF_INTEGER_32) 128L));
	F581_4957(RTCW(Result), tu1_1, ((EIF_INTEGER_32) 9L));
	RTLE;
	return Result;
}

/* {UUID_GENERATOR}.rand */
static EIF_REFERENCE F7_102_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (102);
#define Result RTOSR(102)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(707, 0x00).id, 707, _OBJSIZ_0_1_0_4_0_0_0_0_);
	ti4_1 = F7_104(Current);
	F708_5998(RTCW(tr1), ti4_1);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (102);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F7_102 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(102,F7_102_body,(Current));
}

/* {UUID_GENERATOR}.rand_count */
static EIF_REFERENCE F7_103_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (103);
#define Result RTOSR(103)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {181,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 181, _OBJSIZ_0_0_0_1_0_0_0_0_);
	}
	F182_3358(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (103);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F7_103 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(103,F7_103_body,(Current));
}

/* {UUID_GENERATOR}.seed */
EIF_INTEGER_32 F7_104 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_64 loc1 = (EIF_NATURAL_64) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_NATURAL_64 tu8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,loc2);
	RTLIU(1);
	
	RTGC;
	loc2 = RTLNS(eif_new_type(1, 0x00).id, 1, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F2_35(RTCW(loc2));
	ti4_1 = F2_39(RTCW(loc2));
	loc1 = (EIF_NATURAL_64) (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1970L));
	loc1 = (EIF_NATURAL_64) (EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) (loc1 * (EIF_NATURAL_64) ((EIF_INTEGER_32) 12L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 30L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 24L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 1000L));
	ti4_1 = F2_40(RTCW(loc2));
	tu8_1 = (EIF_NATURAL_64) ti4_1;
	loc1 += (EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) (tu8_1 * (EIF_NATURAL_64) ((EIF_INTEGER_32) 30L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 24L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 1000L));
	ti4_1 = F2_41(RTCW(loc2));
	tu8_1 = (EIF_NATURAL_64) ti4_1;
	loc1 += (EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) (tu8_1 * (EIF_NATURAL_64) ((EIF_INTEGER_32) 24L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 1000L));
	ti4_1 = F2_42(RTCW(loc2));
	tu8_1 = (EIF_NATURAL_64) ti4_1;
	loc1 += (EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) (tu8_1 * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 1000L));
	ti4_1 = F2_43(RTCW(loc2));
	tu8_1 = (EIF_NATURAL_64) ti4_1;
	loc1 += (EIF_NATURAL_64) ((EIF_NATURAL_64) (tu8_1 * (EIF_NATURAL_64) ((EIF_INTEGER_32) 60L)) * (EIF_NATURAL_64) ((EIF_INTEGER_32) 1000L));
	ti4_1 = F2_44(RTCW(loc2));
	tu8_1 = (EIF_NATURAL_64) ti4_1;
	loc1 += (EIF_NATURAL_64) (tu8_1 * (EIF_NATURAL_64) ((EIF_INTEGER_32) 1000L));
	ti4_1 = F2_45(RTCW(loc2));
	tu8_1 = (EIF_NATURAL_64) ti4_1;
	loc1 += tu8_1;
	tu8_1 = eif_bit_shift_right(loc1,((EIF_INTEGER_32) 32L));
	tu8_1 = eif_bit_xor(tu8_1,loc1);
	ti4_1 = (EIF_INTEGER_32) tu8_1;
	Result = eif_bit_and(ti4_1,((EIF_INTEGER_32) 2147483647L));
	RTLE;
	return Result;
}

void EIF_Minit7 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
