
#ifndef _C1_gb4_
#define _C1_gb4_

#ifdef __cplusplus
extern "C" {
#endif

extern void F4_79(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit4(void);

#ifdef __cplusplus
}
#endif

#endif
