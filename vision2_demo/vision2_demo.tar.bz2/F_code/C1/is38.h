
#ifndef _C1_is38_
#define _C1_is38_

#ifdef __cplusplus
extern "C" {
#endif

extern void F38_779(EIF_REFERENCE);
extern EIF_NATURAL_16 F38_781(EIF_REFERENCE, EIF_POINTER);
extern void F38_782(EIF_REFERENCE, EIF_NATURAL_16);
extern void EIF_Minit38(void);

#ifdef __cplusplus
}
#endif

#endif
