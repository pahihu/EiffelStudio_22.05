/*
 * Code for class ORDERED_STRING_HANDLER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "or40.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ORDERED_STRING_HANDLER}.make_with_textable */
void F40_794 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {ORDERED_STRING_HANDLER}.record_string */
void F40_795 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc1);
	RTLR(4,Current);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	tr1 = RTMS_EX_H("\012",1,10);
	tr2 = RTMS_EX_H("   ",3,2105376);
	F1086_9780(RTCW(arg1), tr1, tr2);
	loc1 = RTLNS(eif_new_type(1189, 0x00).id, 1189, _OBJSIZ_6_0_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("<",1,60);
	tr2 = *(EIF_REFERENCE *)(Current);
	ti4_1 = F1120_10295(RTCW(tr2));
	tr2 = eif_out__i4_s1((EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
	tr1 = F1086_9822(tr1, tr2);
	tr2 = RTMS_EX_H("> ",2,15904);
	tr1 = F1086_9822(RTCW(tr1), tr2);
	tr1 = F1086_9822(RTCW(tr1), arg1);
	F1113_10182(RTCW(loc1), tr1);
	tr1 = *(EIF_REFERENCE *)(Current);
	F1120_10306(RTCW(tr1), loc1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tb1 = F1194_10929(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = *(EIF_REFERENCE *)(Current);
		tr3 = *(EIF_REFERENCE *)(Current);
		ti4_1 = F1120_10295(RTCW(tr3));
		tr2 = F1120_10291(RTCW(tr2), ti4_1);
		F1255_12139(RTCW(tr1), tr2);
	}
	RTLE;
}

/* {ORDERED_STRING_HANDLER}.reset */
void F40_796 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	F1120_10319(RTCW(tr1));
	RTLE;
}

void EIF_Minit40 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
