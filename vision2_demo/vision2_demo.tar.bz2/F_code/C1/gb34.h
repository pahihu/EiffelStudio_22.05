
#ifndef _C1_gb34_
#define _C1_gb34_

#ifdef __cplusplus
extern "C" {
#endif

extern void F34_616(EIF_REFERENCE, EIF_REFERENCE);
extern void F34_620(EIF_REFERENCE);
extern void F34_621(EIF_REFERENCE);
extern void EIF_Minit34(void);

#ifdef __cplusplus
}
#endif

#endif
