/*
 * Code for class GTK_ALIGN
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gt10.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F10_110
static EIF_INTEGER_32 inline_F10_110 (void)
{
	return GTK_ALIGN_START
	;
}
#define INLINE_F10_110
#endif
#ifndef INLINE_F10_111
static EIF_INTEGER_32 inline_F10_111 (void)
{
	return GTK_ALIGN_END
	;
}
#define INLINE_F10_111
#endif
#ifndef INLINE_F10_112
static EIF_INTEGER_32 inline_F10_112 (void)
{
	return GTK_ALIGN_CENTER
	;
}
#define INLINE_F10_112
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GTK_ALIGN}.gtk_align_start */
EIF_INTEGER_32 F10_110 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F10_110 ();
	return Result;
}

/* {GTK_ALIGN}.gtk_align_end */
EIF_INTEGER_32 F10_111 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F10_111 ();
	return Result;
}

/* {GTK_ALIGN}.gtk_align_center */
EIF_INTEGER_32 F10_112 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F10_112 ();
	return Result;
}

void EIF_Minit10 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
