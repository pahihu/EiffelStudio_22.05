
#ifndef _C1_ev3_
#define _C1_ev3_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3_71(EIF_REFERENCE, EIF_INTEGER_32);
extern void F3_72(EIF_REFERENCE, EIF_INTEGER_32);
extern void F3_73(EIF_REFERENCE, EIF_INTEGER_32);
extern void F3_74(EIF_REFERENCE, EIF_INTEGER_32);
extern void F3_75(EIF_REFERENCE, EIF_INTEGER_32);
extern void F3_78(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit3(void);

#ifdef __cplusplus
}
#endif

#endif
