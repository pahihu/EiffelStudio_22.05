
#ifndef _C1_gt10_
#define _C1_gt10_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F10_110(EIF_REFERENCE);
extern EIF_INTEGER_32 F10_111(EIF_REFERENCE);
extern EIF_INTEGER_32 F10_112(EIF_REFERENCE);
extern void EIF_Minit10(void);

#ifdef __cplusplus
}
#endif

#endif
