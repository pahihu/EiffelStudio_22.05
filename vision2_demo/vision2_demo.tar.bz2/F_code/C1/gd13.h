
#ifndef _C1_gd13_
#define _C1_gd13_

#ifdef __cplusplus
extern "C" {
#endif

extern void F13_209(EIF_REFERENCE, EIF_POINTER, EIF_POINTER, EIF_REAL_64, EIF_REAL_64);
extern EIF_POINTER F13_212(EIF_REFERENCE);
extern void F13_213(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit13(void);

#ifdef __cplusplus
}
#endif

#endif
