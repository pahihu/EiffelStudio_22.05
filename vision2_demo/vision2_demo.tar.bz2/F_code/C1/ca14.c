/*
 * Code for class CAIRO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ca14.h"
#include <ev_gtk.h>
#include <cairo.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F14_249
static EIF_NATURAL_32 inline_F14_249 (EIF_POINTER arg1)
{
	return (EIF_NATURAL_32) (cairo_get_reference_count((cairo_t*) arg1))
	;
}
#define INLINE_F14_249
#endif
#ifndef INLINE_F14_255
static void inline_F14_255 (EIF_POINTER arg1)
{
	cairo_surface_destroy((cairo_surface_t*) arg1)
	;
}
#define INLINE_F14_255
#endif
#ifndef INLINE_F14_298
static void inline_F14_298 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	double len = 2.0;
if (arg2) {
	cairo_set_dash ((cairo_t *) arg1, &len, 1, 0.0);
} else {
	cairo_set_dash ((cairo_t *) arg1, NULL, 0, 0.0);
}
	;
}
#define INLINE_F14_298
#endif
#ifndef INLINE_F14_309
static int inline_F14_309 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	return  cairo_region_equal ((const cairo_region_t *)arg1, (const cairo_region_t *)arg2);
	;
}
#define INLINE_F14_309
#endif
#ifndef INLINE_F14_310
static EIF_POINTER inline_F14_310 (EIF_POINTER arg1)
{
	return  cairo_region_copy ((const cairo_region_t *)arg1);
	;
}
#define INLINE_F14_310
#endif
#ifndef INLINE_F14_313
static void inline_F14_313 (EIF_POINTER arg1)
{
	cairo_paint ((cairo_t*)arg1)
	;
}
#define INLINE_F14_313
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CAIRO}.operator_source */
EIF_INTEGER_8 F14_232 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	
	
	Result = (EIF_INTEGER_8) CAIRO_OPERATOR_SOURCE;
	return Result;
}

/* {CAIRO}.operator_over */
EIF_INTEGER_8 F14_233 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	
	
	Result = (EIF_INTEGER_8) CAIRO_OPERATOR_OVER;
	return Result;
}

/* {CAIRO}.operator_atop */
EIF_INTEGER_8 F14_238 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	
	
	Result = (EIF_INTEGER_8) CAIRO_OPERATOR_ATOP;
	return Result;
}

/* {CAIRO}.operator_difference */
EIF_INTEGER_8 F14_244 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	
	
	Result = (EIF_INTEGER_8) CAIRO_OPERATOR_DIFFERENCE;
	return Result;
}

/* {CAIRO}.operator_exclusion */
EIF_INTEGER_8 F14_245 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	
	
	Result = (EIF_INTEGER_8) CAIRO_OPERATOR_EXCLUSION;
	return Result;
}

/* {CAIRO}.operator_multiply */
EIF_INTEGER_8 F14_246 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	
	
	Result = (EIF_INTEGER_8) CAIRO_OPERATOR_MULTIPLY;
	return Result;
}

/* {CAIRO}.create_context */
EIF_POINTER F14_247 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) cairo_create((cairo_surface_t*) arg1);
	
	return Result;
}

/* {CAIRO}.get_reference_count */
EIF_NATURAL_32 F14_249 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	
	
	Result = inline_F14_249 ((EIF_POINTER) arg1);
	return Result;
}

/* {CAIRO}.destroy */
void F14_250 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	cairo_destroy((cairo_t*) arg1);
	
}

/* {CAIRO}.set_source_surface */
void F14_254 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4)
{
	GTCX
	
	cairo_set_source_surface((cairo_t*) arg1, (cairo_surface_t*) arg2, (double) arg3, (double) arg4);
	
}

/* {CAIRO}.surface_destroy */
void F14_255 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	inline_F14_255 ((EIF_POINTER) arg1);
}

/* {CAIRO}.surface_flush */
void F14_258 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	cairo_surface_flush((cairo_surface_t*) arg1);
	
}

/* {CAIRO}.image_surface_create */
EIF_POINTER F14_272 (EIF_REFERENCE Current, EIF_INTEGER_8 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) cairo_image_surface_create((cairo_format_t) arg1, (int) arg2, (int) arg3);
	
	return Result;
}

/* {CAIRO}.image_surface_get_width */
EIF_INTEGER_32 F14_276 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) cairo_image_surface_get_width((cairo_surface_t*) arg1);
	
	return Result;
}

/* {CAIRO}.image_surface_get_height */
EIF_INTEGER_32 F14_277 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) cairo_image_surface_get_height((cairo_surface_t*) arg1);
	
	return Result;
}

/* {CAIRO}.clip */
void F14_278 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	cairo_clip((cairo_t*) arg1);
	
}

/* {CAIRO}.reset_clip */
void F14_279 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	cairo_reset_clip((cairo_t*) arg1);
	
}

/* {CAIRO}.clip_extents */
void F14_280 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64* arg2, EIF_REAL_64* arg3, EIF_REAL_64* arg4, EIF_REAL_64* arg5)
{
	GTCX
	
	cairo_clip_extents((cairo_t*) arg1, (double*) arg2, (double*) arg3, (double*) arg4, (double*) arg5);
	
}

/* {CAIRO}.save */
void F14_290 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	cairo_save((cairo_t*) arg1);
	
}

/* {CAIRO}.restore */
void F14_291 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	cairo_restore((cairo_t*) arg1);
	
}

/* {CAIRO}.set_operator */
void F14_296 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_8 arg2)
{
	GTCX
	
	cairo_set_operator((cairo_t*) arg1, (cairo_operator_t) arg2);
	
}

/* {CAIRO}.set_antialias */
void F14_297 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_8 arg2)
{
	GTCX
	
	cairo_set_antialias((cairo_t*) arg1, (cairo_antialias_t) arg2);
	
}

/* {CAIRO}.set_dashed_line_style */
void F14_298 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	
	
	inline_F14_298 ((EIF_POINTER) arg1, (EIF_BOOLEAN) arg2);
}

/* {CAIRO}.fill */
void F14_301 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	cairo_fill((cairo_t*) arg1);
}

/* {CAIRO}.cairo_fill */
void F14_302 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	cairo_fill((cairo_t*) arg1);
	
}

/* {CAIRO}.translate */
void F14_304 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3)
{
	GTCX
	
	cairo_translate((cairo_t*) arg1, (double) arg2, (double) arg3);
	
}

/* {CAIRO}.cairo_equal */
EIF_BOOLEAN F14_309 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = EIF_TEST(inline_F14_309 ((EIF_POINTER) arg1, (EIF_POINTER) arg2));
	return Result;
}

/* {CAIRO}.cairo_copy */
EIF_POINTER F14_310 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F14_310 ((EIF_POINTER) arg1);
	return Result;
}

/* {CAIRO}.scale */
void F14_311 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3)
{
	GTCX
	
	cairo_scale((cairo_t*) arg1, (double) arg2, (double) arg3);
	
}

/* {CAIRO}.rotate */
void F14_312 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2)
{
	GTCX
	
	cairo_rotate((cairo_t*) arg1, (double) arg2);
	
}

/* {CAIRO}.paint */
void F14_313 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	inline_F14_313 ((EIF_POINTER) arg1);
}

/* {CAIRO}.stroke */
void F14_314 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	cairo_stroke((cairo_t*) arg1);
	
}

/* {CAIRO}.stroke_preserve */
void F14_315 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	cairo_stroke_preserve((cairo_t*) arg1);
	
}

/* {CAIRO}.move_to */
void F14_316 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3)
{
	GTCX
	
	cairo_move_to((cairo_t*) arg1, (double) arg2, (double) arg3);
	
}

/* {CAIRO}.line_to */
void F14_317 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3)
{
	GTCX
	
	cairo_line_to((cairo_t*) arg1, (double) arg2, (double) arg3);
	
}

/* {CAIRO}.rectangle */
void F14_318 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5)
{
	GTCX
	
	cairo_rectangle((cairo_t*) arg1, (double) arg2, (double) arg3, (double) arg4, (double) arg5);
	
}

/* {CAIRO}.set_source_rgba */
void F14_319 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5)
{
	GTCX
	
	cairo_set_source_rgba((cairo_t*) arg1, (double) arg2, (double) arg3, (double) arg4, (double) arg5);
	
}

/* {CAIRO}.set_source_rgb */
void F14_320 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4)
{
	GTCX
	
	cairo_set_source_rgb((cairo_t*) arg1, (double) arg2, (double) arg3, (double) arg4);
	
}

/* {CAIRO}.arc_negative */
void F14_323 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6)
{
	GTCX
	
	cairo_arc_negative((cairo_t*) arg1, (double) arg2, (double) arg3, (double) arg4, (double) arg5, (double) arg6);
	
}

/* {CAIRO}.set_line_width */
void F14_324 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REAL_64 arg2)
{
	GTCX
	
	cairo_set_line_width((cairo_t*) arg1, (double) arg2);
	
}

/* {CAIRO}.set_line_cap */
void F14_325 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_8 arg2)
{
	GTCX
	
	cairo_set_line_cap((cairo_t*) arg1, (cairo_line_cap_t) arg2);
	
}

/* {CAIRO}.close_path */
void F14_330 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	cairo_close_path((cairo_t*) arg1);
	
}

/* {CAIRO}.cairo_content_color_alpha */
EIF_INTEGER_32 F14_339 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) CAIRO_CONTENT_COLOR_ALPHA;
	return Result;
}

void EIF_Minit14 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
