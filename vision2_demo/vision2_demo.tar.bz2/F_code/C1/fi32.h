
#ifndef _C1_fi32_
#define _C1_fi32_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F31_597(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F31_598(EIF_REFERENCE, EIF_REFERENCE);
extern void F31_602(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit32(void);
extern EIF_BOOLEAN F931_7020(EIF_REFERENCE);
extern EIF_BOOLEAN F964_8078(EIF_REFERENCE);
extern void F931_7000(EIF_REFERENCE);
extern void F931_6997(EIF_REFERENCE, EIF_REFERENCE);
extern void F931_6995(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R7825[])();

#ifdef __cplusplus
}
#endif

#endif
