/*
 * Code for class GDK_HELPERS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gd15.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F15_340
static EIF_POINTER inline_F15_340 (EIF_INTEGER_32* arg1, EIF_INTEGER_32* arg2)
{
	return (GdkWindow*) gdk_device_get_window_at_position((GdkDevice*) gdk_seat_get_pointer((GdkSeat*) gdk_display_get_default_seat ((GdkDisplay*) gdk_display_get_default())), (gint*) arg1, (gint*) arg2);
	;
}
#define INLINE_F15_340
#endif
#ifndef INLINE_F15_341
static void inline_F15_341 (EIF_POINTER arg1, EIF_INTEGER_32* arg2, EIF_INTEGER_32* arg3)
{
	return gdk_device_get_position ((GdkDevice*) arg1, NULL, (gint*) arg2, (gint*) arg3);
	;
}
#define INLINE_F15_341
#endif
#ifndef INLINE_F15_342
static EIF_POINTER inline_F15_342 (void)
{
	return (GdkDisplay*) gdk_display_get_default();
	;
}
#define INLINE_F15_342
#endif
#ifndef INLINE_F15_344
static EIF_POINTER inline_F15_344 (void)
{
	return (GdkDevice*) gdk_seat_get_pointer((GdkSeat*) gdk_display_get_default_seat ((GdkDisplay*) gdk_display_get_default()));
	;
}
#define INLINE_F15_344
#endif
#ifndef INLINE_F15_345
static EIF_POINTER inline_F15_345 (void)
{
	return (GdkScreen*) gdk_display_get_default_screen ((GdkDisplay*) gdk_display_get_default());
	;
}
#define INLINE_F15_345
#endif
#ifndef INLINE_F15_346
static EIF_INTEGER_32 inline_F15_346 (void)
{
	return gdk_display_get_default_cursor_size ((GdkDisplay*) gdk_display_get_default());
	;
}
#define INLINE_F15_346
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GDK_HELPERS}.window_at */
EIF_POINTER F15_340 (EIF_REFERENCE Current, EIF_INTEGER_32* arg1, EIF_INTEGER_32* arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F15_340 ((EIF_INTEGER_32*) arg1, (EIF_INTEGER_32*) arg2);
	return Result;
}

/* {GDK_HELPERS}.device_get_position */
void F15_341 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32* arg2, EIF_INTEGER_32* arg3)
{
	GTCX
	
	
	inline_F15_341 ((EIF_POINTER) arg1, (EIF_INTEGER_32*) arg2, (EIF_INTEGER_32*) arg3);
}

/* {GDK_HELPERS}.default_display */
EIF_POINTER F15_342 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F15_342 ();
	return Result;
}

/* {GDK_HELPERS}.default_device */
EIF_POINTER F15_344 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F15_344 ();
	return Result;
}

/* {GDK_HELPERS}.default_screen */
EIF_POINTER F15_345 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F15_345 ();
	return Result;
}

/* {GDK_HELPERS}.default_cursor_size */
EIF_INTEGER_32 F15_346 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F15_346 ();
	return Result;
}

void EIF_Minit15 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
