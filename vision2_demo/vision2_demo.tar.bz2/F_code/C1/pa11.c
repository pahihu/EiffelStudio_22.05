/*
 * Code for class PANGO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pa11.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F11_119
static void inline_F11_119 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	(FUNCTION_CAST(void, (PangoLayout*, gint)) arg1)((PangoLayout*) arg2, (gint) arg3);
	;
}
#define INLINE_F11_119
#endif
#ifndef INLINE_F11_169
static EIF_POINTER inline_F11_169 (void)
{
	return pango_attr_list_new();
	;
}
#define INLINE_F11_169
#endif
#ifndef INLINE_F11_172
static EIF_POINTER inline_F11_172 (EIF_POINTER arg1)
{
	return pango_attr_font_desc_new ((const PangoFontDescription *)arg1);
	;
}
#define INLINE_F11_172
#endif
#ifndef INLINE_F11_173
static void inline_F11_173 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	pango_attr_list_insert ((PangoAttrList *)arg1, (PangoAttribute *)arg2);
	;
}
#define INLINE_F11_173
#endif
#ifndef INLINE_F11_174
static void inline_F11_174 (EIF_POINTER arg1)
{
	pango_attr_list_unref ((PangoAttrList *)arg1);
	;
}
#define INLINE_F11_174
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PANGO}.underline_none_enum */
EIF_INTEGER_32 F11_114 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) PANGO_UNDERLINE_NONE;
	return Result;
}

/* {PANGO}.underline_single_enum */
EIF_INTEGER_32 F11_115 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) PANGO_UNDERLINE_SINGLE;
	return Result;
}

/* {PANGO}.scale */
EIF_INTEGER_32 F11_117 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) PANGO_SCALE;
	return Result;
}

/* {PANGO}.layout_set_ellipsize_call */
void F11_119 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	
	inline_F11_119 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_INTEGER_32) arg3);
}

/* {PANGO}.font_description_new */
EIF_POINTER F11_120 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) pango_font_description_new();
	
	return Result;
}

/* {PANGO}.font_description_free */
void F11_121 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	pango_font_description_free((PangoFontDescription*) arg1);
	
}

/* {PANGO}.font_description_set_family */
void F11_124 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	pango_font_description_set_family((PangoFontDescription*) arg1, (char*) arg2);
	
}

/* {PANGO}.font_description_get_family */
EIF_POINTER F11_125 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) pango_font_description_get_family((PangoFontDescription*) arg1);
	
	return Result;
}

/* {PANGO}.font_description_set_style */
void F11_126 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	pango_font_description_set_style((PangoFontDescription*) arg1, (PangoStyle) arg2);
	
}

/* {PANGO}.font_description_get_style */
EIF_INTEGER_32 F11_127 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) pango_font_description_get_style((PangoFontDescription*) arg1);
	
	return Result;
}

/* {PANGO}.font_description_set_weight */
void F11_128 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	pango_font_description_set_weight((PangoFontDescription*) arg1, (PangoWeight) arg2);
	
}

/* {PANGO}.font_description_get_weight */
EIF_INTEGER_32 F11_129 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) pango_font_description_get_weight((PangoFontDescription*) arg1);
	
	return Result;
}

/* {PANGO}.font_description_set_size */
void F11_130 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	pango_font_description_set_size((PangoFontDescription*) arg1, (gint) arg2);
	
}

/* {PANGO}.font_description_get_size */
EIF_INTEGER_32 F11_131 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) pango_font_description_get_size((PangoFontDescription*) arg1);
	
	return Result;
}

/* {PANGO}.layout_set_font_description */
void F11_133 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	pango_layout_set_font_description((PangoLayout*) arg1, (PangoFontDescription*) arg2);
	
}

/* {PANGO}.layout_set_width */
void F11_134 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	pango_layout_set_width((PangoLayout*) arg1, (int) arg2);
	
}

/* {PANGO}.layout_get_pixel_size */
void F11_135 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32* arg2, EIF_INTEGER_32* arg3)
{
	GTCX
	
	pango_layout_get_pixel_size((PangoLayout*) arg1, (gint*) arg2, (gint*) arg3);
	
}

/* {PANGO}.layout_get_iter */
EIF_POINTER F11_136 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) pango_layout_get_iter((PangoLayout*) arg1);
	
	return Result;
}

/* {PANGO}.layout_set_text */
void F11_137 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	pango_layout_set_text((PangoLayout*) arg1, (char*) arg2, (int) arg3);
	
}

/* {PANGO}.layout_iter_get_baseline */
EIF_INTEGER_32 F11_138 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) pango_layout_iter_get_baseline((PangoLayoutIter*) arg1);
	
	return Result;
}

/* {PANGO}.layout_iter_free */
void F11_139 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	pango_layout_iter_free((PangoLayoutIter*) arg1);
	
}

/* {PANGO}.layout_get_pixel_extents */
void F11_141 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	GTCX
	
	pango_layout_get_pixel_extents((PangoLayout*) arg1, (PangoRectangle*) arg2, (PangoRectangle*) arg3);
	
}

/* {PANGO}.cairo_create_layout */
EIF_POINTER F11_148 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) pango_cairo_create_layout((cairo_t*) arg1);
	
	return Result;
}

/* {PANGO}.cairo_show_layout */
void F11_150 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	pango_cairo_show_layout((cairo_t*) arg1, (PangoLayout*) arg2);
	
}

/* {PANGO}.new_rectangle_struct */
EIF_POINTER F11_153 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = (EIF_POINTER) calloc (sizeof(PangoRectangle), 1);
	return Result;
}

/* {PANGO}.rectangle_struct_x */
EIF_INTEGER_32 F11_154 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((PangoRectangle *)arg1)->x);
	
	return Result;
}

/* {PANGO}.rectangle_struct_y */
EIF_INTEGER_32 F11_155 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((PangoRectangle *)arg1)->y);
	
	return Result;
}

/* {PANGO}.rectangle_struct_width */
EIF_INTEGER_32 F11_156 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((PangoRectangle *)arg1)->width);
	
	return Result;
}

/* {PANGO}.rectangle_struct_height */
EIF_INTEGER_32 F11_157 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) (((PangoRectangle *)arg1)->height);
	
	return Result;
}

/* {PANGO}.tab_array_new */
EIF_POINTER F11_158 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) pango_tab_array_new((gint) arg1, (gboolean) arg2);
	
	return Result;
}

/* {PANGO}.tab_array_resize */
void F11_159 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	pango_tab_array_resize((PangoTabArray*) arg1, (gint) arg2);
	
}

/* {PANGO}.tab_array_set_tab */
void F11_160 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	
	pango_tab_array_set_tab((PangoTabArray*) arg1, (gint) arg2, (PangoTabAlign) arg3, (gint) arg4);
	
}

/* {PANGO}.pango_attr_list_new */
EIF_POINTER F11_169 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F11_169 ();
	return Result;
}

/* {PANGO}.pango_attr_font_desc_new */
EIF_POINTER F11_172 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F11_172 ((EIF_POINTER) arg1);
	return Result;
}

/* {PANGO}.pango_attr_list_insert */
void F11_173 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	
	inline_F11_173 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
}

/* {PANGO}.pango_attr_list_unref */
void F11_174 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	inline_F11_174 ((EIF_POINTER) arg1);
}

void EIF_Minit11 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
