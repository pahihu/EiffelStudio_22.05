/*
 * Code for class EV_GRID_LABEL_ITEM_LAYOUT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev3.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GRID_LABEL_ITEM_LAYOUT}.set_pixmap_x */
void F3_71 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_0_) = (EIF_INTEGER_32) arg1;
}

/* {EV_GRID_LABEL_ITEM_LAYOUT}.set_pixmap_y */
void F3_72 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_1_) = (EIF_INTEGER_32) arg1;
}

/* {EV_GRID_LABEL_ITEM_LAYOUT}.set_text_x */
void F3_73 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_4_) = (EIF_INTEGER_32) arg1;
}

/* {EV_GRID_LABEL_ITEM_LAYOUT}.set_text_y */
void F3_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_5_) = (EIF_INTEGER_32) arg1;
}

/* {EV_GRID_LABEL_ITEM_LAYOUT}.set_available_text_width */
void F3_75 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_6_) = (EIF_INTEGER_32) arg1;
}

/* {EV_GRID_LABEL_ITEM_LAYOUT}.set_has_text_pixmap_overlapping */
void F3_78 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_0_0_) = (EIF_BOOLEAN) arg1;
}

void EIF_Minit3 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
