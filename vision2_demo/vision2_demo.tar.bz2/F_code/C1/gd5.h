
#ifndef _C1_gd5_
#define _C1_gd5_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F5_88(EIF_REFERENCE);
extern void EIF_Minit5(void);

#ifdef __cplusplus
}
#endif

#endif
