/*
 * Code for class CODE_PAGE_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co28.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CODE_PAGE_CONSTANTS}.utf7 */

EIF_REFERENCE F28_576 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (576,RTMS_EX_H("UTF-7",5,1414538039));
}

/* {CODE_PAGE_CONSTANTS}.utf8 */

EIF_REFERENCE F28_577 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (577,RTMS_EX_H("UTF-8",5,1414538040));
}

/* {CODE_PAGE_CONSTANTS}.utf16 */

EIF_REFERENCE F28_578 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (578,RTMS_EX_H("UTF-16",6,1345128758));
}

/* {CODE_PAGE_CONSTANTS}.utf32 */

EIF_REFERENCE F28_579 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (579,RTMS_EX_H("UTF-32",6,1345129266));
}

/* {CODE_PAGE_CONSTANTS}.utf16_le */

EIF_REFERENCE F28_580 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (580,RTMS_EX_H("UTF-16LE",8,312185413));
}

/* {CODE_PAGE_CONSTANTS}.utf32_le */

EIF_REFERENCE F28_581 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (581,RTMS_EX_H("UTF-32LE",8,345477701));
}

/* {CODE_PAGE_CONSTANTS}.utf16_be */

EIF_REFERENCE F28_582 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (582,RTMS_EX_H("UTF-16BE",8,312182853));
}

/* {CODE_PAGE_CONSTANTS}.utf32_be */

EIF_REFERENCE F28_583 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (583,RTMS_EX_H("UTF-32BE",8,345475141));
}

void EIF_Minit28 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
