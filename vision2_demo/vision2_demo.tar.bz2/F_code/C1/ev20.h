
#ifndef _C1_ev20_
#define _C1_ev20_

#ifdef __cplusplus
extern "C" {
#endif

extern void F20_467(EIF_REFERENCE);
extern void F20_469(EIF_REFERENCE);
extern void F20_471(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit20(void);

#ifdef __cplusplus
}
#endif

#endif
