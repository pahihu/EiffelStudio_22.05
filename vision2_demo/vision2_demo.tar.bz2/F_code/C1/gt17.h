
#ifndef _C1_gt17_
#define _C1_gt17_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_8 F17_401(EIF_REFERENCE);
extern EIF_NATURAL_8 F17_402(EIF_REFERENCE);
extern void EIF_Minit17(void);

#ifdef __cplusplus
}
#endif

#endif
