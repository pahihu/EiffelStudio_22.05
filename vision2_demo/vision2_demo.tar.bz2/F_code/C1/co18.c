/*
 * Code for class COMPILER_PROFILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co18.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {COMPILER_PROFILE}.initialize_from_arguments */
void F18_403 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	F18_443(Current);
	loc1 = RTLNS(eif_new_type(64, 0x00).id, 64, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = RTOSCF(404,F18_404, (Current));
	ti4_1 = F64_1097(RTCW(loc1), tr1);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		F18_430(Current);
	} else {
		tr1 = RTOSCF(405,F18_405, (Current));
		ti4_1 = F64_1097(RTCW(loc1), tr1);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			F18_431(Current);
		}
	}
	tr1 = RTOSCF(406,F18_406, (Current));
	ti4_1 = F64_1097(RTCW(loc1), tr1);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		F18_432(Current);
	}
	tr1 = RTOSCF(407,F18_407, (Current));
	ti4_1 = F64_1097(RTCW(loc1), tr1);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		F18_433(Current);
	}
	tr1 = RTOSCF(408,F18_408, (Current));
	loc3 = F64_1097(RTCW(loc1), tr1);
	tb1 = '\0';
	if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L))) {
		ti4_1 = F64_1100(RTCW(loc1));
		tb1 = (EIF_BOOLEAN) ((EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)) <= ti4_1);
	}
	if (tb1) {
		loc2 = F64_1095(RTCW(loc1), (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)));
		if (F18_421(Current, loc2)) {
			F18_434(Current, loc2);
		}
	}
	tr1 = RTOSCF(409,F18_409, (Current));
	loc3 = F64_1097(RTCW(loc1), tr1);
	tb1 = '\0';
	if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L))) {
		ti4_1 = F64_1100(RTCW(loc1));
		tb1 = (EIF_BOOLEAN) ((EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)) <= ti4_1);
	}
	if (tb1) {
		loc2 = F64_1095(RTCW(loc1), (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)));
		if (F18_426(Current, loc2)) {
			F18_435(Current, loc2);
		}
	}
	RTLE;
}

/* {COMPILER_PROFILE}.compat_option_name */

EIF_REFERENCE F18_404 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (404,RTMS_EX_H("compat",6,2031575924));
}

/* {COMPILER_PROFILE}.experiment_option_name */

EIF_REFERENCE F18_405 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (405,RTMS_EX_H("experiment",10,207796852));
}

/* {COMPILER_PROFILE}.full_option_name */

EIF_REFERENCE F18_406 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (406,RTMS_EX_H("full",4,1718971500));
}

/* {COMPILER_PROFILE}.safe_option_name */

EIF_REFERENCE F18_407 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (407,RTMS_EX_H("safe",4,1935763045));
}

/* {COMPILER_PROFILE}.platform_option_name */

EIF_REFERENCE F18_408 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (408,RTMS_EX_H("platform",8,459690093));
}

/* {COMPILER_PROFILE}.capabilty_option_name */

EIF_REFERENCE F18_409 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (409,RTMS_EX_H("capability",10,950653049));
}

/* {COMPILER_PROFILE}.is_compatible_mode */
EIF_BOOLEAN F18_414 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_and(tu4_1,((EIF_NATURAL_32) 1U));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 1U));
	RTLE;
	return Result;
}

/* {COMPILER_PROFILE}.is_experimental_mode */
EIF_BOOLEAN F18_416 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_and(tu4_1,((EIF_NATURAL_32) 2U));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 2U));
	RTLE;
	return Result;
}

/* {COMPILER_PROFILE}.is_platform_valid */
EIF_BOOLEAN F18_421 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = '\01';
	tb1 = '\01';
	tb2 = '\01';
	tr1 = RTMS_EX_H("windows",7,1657536371);
	tb3 = F1078_9435(RTCW(arg1), tr1);
	if (!tb3) {
		tr1 = RTMS_EX_H("unix",4,1970170232);
		tb3 = F1078_9435(RTCW(arg1), tr1);
		tb2 = tb3;
	}
	if (!tb2) {
		tr1 = RTMS_EX_H("macintosh",9,458551400);
		tb2 = F1078_9435(RTCW(arg1), tr1);
		tb1 = tb2;
	}
	if (!tb1) {
		tr1 = RTMS_EX_H("vxworks",7,1368523123);
		tb1 = F1078_9435(RTCW(arg1), tr1);
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {COMPILER_PROFILE}.is_capability_valid */
EIF_BOOLEAN F18_426 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\01';
	tb1 = '\01';
	tr1 = RTOSCF(455,F18_455, (Current));
	tb2 = F1078_9438(RTCW(arg1), tr1);
	if (!tb2) {
		tr1 = RTOSCF(456,F18_456, (Current));
		tb2 = F1078_9438(RTCW(arg1), tr1);
		tb1 = tb2;
	}
	if (!tb1) {
		tr1 = RTOSCF(457,F18_457, (Current));
		tb1 = F1078_9438(RTCW(arg1), tr1);
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {COMPILER_PROFILE}.set_compatible_mode */
void F18_430 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 1U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.set_experimental_mode */
void F18_431 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 2U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.set_full_class_checking_mode */
void F18_432 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 4U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.set_safe_mode */
void F18_433 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 8U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.set_platform */
void F18_434 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("windows",7,1657536371);
	tb1 = F1078_9435(RTCW(arg1), tr1);
	if (tb1) {
		F18_436(Current);
	} else {
		tr1 = RTMS_EX_H("unix",4,1970170232);
		tb1 = F1078_9435(RTCW(arg1), tr1);
		if (tb1) {
			F18_437(Current);
		} else {
			tr1 = RTMS_EX_H("macintosh",9,458551400);
			tb1 = F1078_9435(RTCW(arg1), tr1);
			if (tb1) {
				F18_438(Current);
			} else {
				tr1 = RTMS_EX_H("vxworks",7,1368523123);
				tb1 = F1078_9435(RTCW(arg1), tr1);
				if (tb1) {
					F18_439(Current);
				}
			}
		}
	}
	RTLE;
}

/* {COMPILER_PROFILE}.set_capability */
void F18_435 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(455,F18_455, (Current));
	tb1 = F1078_9438(RTCW(arg1), tr1);
	if (tb1) {
		F18_440(Current);
	} else {
		tr1 = RTOSCF(456,F18_456, (Current));
		tb1 = F1078_9438(RTCW(arg1), tr1);
		if (tb1) {
			F18_441(Current);
		} else {
			tr1 = RTOSCF(457,F18_457, (Current));
			tb1 = F1078_9438(RTCW(arg1), tr1);
			if (tb1) {
				F18_442(Current);
			}
		}
	}
	RTLE;
}

/* {COMPILER_PROFILE}.set_is_windows_platform */
void F18_436 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_2 = eif_bit_not(((EIF_NATURAL_32) 240U));
	tu4_1 = eif_bit_and(tu4_1,tu4_2);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 32U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.set_is_unix_platform */
void F18_437 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_2 = eif_bit_not(((EIF_NATURAL_32) 240U));
	tu4_1 = eif_bit_and(tu4_1,tu4_2);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 16U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.set_is_mac_platform */
void F18_438 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_2 = eif_bit_not(((EIF_NATURAL_32) 240U));
	tu4_1 = eif_bit_and(tu4_1,tu4_2);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 48U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.set_is_vxworks_platform */
void F18_439 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_2 = eif_bit_not(((EIF_NATURAL_32) 240U));
	tu4_1 = eif_bit_and(tu4_1,tu4_2);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 64U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.set_capability_warning */
void F18_440 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_2 = eif_bit_not(((EIF_NATURAL_32) 512U));
	tu4_1 = eif_bit_and(tu4_1,tu4_2);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 256U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.set_capability_error */
void F18_441 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_2 = eif_bit_not(((EIF_NATURAL_32) 256U));
	tu4_1 = eif_bit_and(tu4_1,tu4_2);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 512U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.set_capability_strict */
void F18_442 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 1024U));
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) tu4_1;
	RTLE;
}

/* {COMPILER_PROFILE}.reset */
void F18_443 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
}

/* {COMPILER_PROFILE}.capability_value_warning */

EIF_REFERENCE F18_455 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (455,RTMS_EX_H("warning",7,1809215079));
}

/* {COMPILER_PROFILE}.capability_value_error */

EIF_REFERENCE F18_456 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (456,RTMS_EX_H("error",5,1920877938));
}

/* {COMPILER_PROFILE}.capability_value_strict */

EIF_REFERENCE F18_457 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (457,RTMS_EX_H("strict",6,2146499444));
}

void EIF_Minit18 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
