/*
 * Code for class GB_EV_NOTEBOOK_EDITOR_CONSTRUCTOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gb334.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GB_EV_NOTEBOOK_EDITOR_CONSTRUCTOR}.ev_type */
EIF_REFERENCE F847_6406 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_13_);
}


/* {GB_EV_NOTEBOOK_EDITOR_CONSTRUCTOR}.attribute_editor */
EIF_REFERENCE F847_6408 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_REFERENCE tr6 = NULL;
	EIF_REFERENCE tr7 = NULL;
	EIF_REFERENCE tr8 = NULL;
	EIF_REFERENCE tr9 = NULL;
	EIF_REFERENCE tr10 = NULL;
	EIF_REFERENCE tr11 = NULL;
	EIF_REFERENCE tr12 = NULL;
	EIF_REFERENCE tr13 = NULL;
	EIF_REFERENCE tr14 = NULL;
	EIF_REFERENCE tr15 = NULL;
	EIF_REFERENCE tr16 = NULL;
	EIF_REFERENCE tr17 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(20);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,tr5);
	RTLR(8,tr6);
	RTLR(9,tr7);
	RTLR(10,tr8);
	RTLR(11,tr9);
	RTLR(12,tr10);
	RTLR(13,tr11);
	RTLR(14,tr12);
	RTLR(15,tr13);
	RTLR(16,tr14);
	RTLR(17,tr15);
	RTLR(18,tr16);
	RTLR(19,tr17);
	RTLIU(20);
	
	RTGC;
	Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_7_3_0_1_0_0_0_0_);
	F1209_11188(RTCW(Result), *(EIF_REFERENCE *)(Current));
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.initialize_attribute_editor) */
		/* END INLINED CODE */
	}
	;
	loc1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_5_2_0_1_0_0_0_0_);
	tr1 = RTOSCF(5866,F689_5866, (Current));
	F1113_10182(RTCW(loc1), tr1);
	tr1 = RTOSCF(5867,F689_5867, (Current));
	F1112_10176(RTCW(loc1), tr1);
	F1120_10306(RTCW(Result), loc1);
	tr1 = RTLNSMART(eif_new_type(1253, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	tr2 = RTOSCF(5867,F689_5867, (Current));
	F1112_10176(RTCW(tr1), tr2);
	F1120_10306(RTCW(Result), *(EIF_REFERENCE *)(Current + _REFACS_6_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1248_12039(RTCW(tr1));
	tr1 = RTLNSMART(eif_new_type(1189, 0).id);
	tr2 = RTOSCF(6426,F847_6426, (Current));
	F1113_10182(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1120_10306(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_7_));
	tr1 = RTLNSMART(eif_new_type(1189, 0).id);
	tr2 = RTOSCF(6427,F847_6427, (Current));
	F1113_10182(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1120_10306(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_8_));
	tr1 = RTLNSMART(eif_new_type(1189, 0).id);
	tr2 = RTOSCF(6425,F847_6425, (Current));
	F1113_10182(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1120_10306(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_10_));
	tr1 = RTLNSMART(eif_new_type(1189, 0).id);
	tr2 = RTOSCF(6424,F847_6424, (Current));
	F1113_10182(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1120_10306(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_9_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	tr1 = F1152_10678(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A334_511, (EIF_POINTER) _A334_511, (EIF_POINTER)(F847_6414),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	tr1 = F1152_10678(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A334_543, (EIF_POINTER) _A334_543, (EIF_POINTER)(F1563_17201),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	tb1 = F483_4817(RTCV(F1563_17188(Current)));
	if ((EIF_BOOLEAN) !tb1) {
		loc1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_5_2_0_1_0_0_0_0_);
		tr1 = RTMS_EX_H("Item texts:",11,418327098);
		F1113_10182(RTCW(loc1), tr1);
		F1120_10306(RTCW(Result), loc1);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {663,1206,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F664_5447(RTCW(tr1), ((EIF_INTEGER_32) 4L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	F1120_10298(RTCV(F1563_17188(Current)));
	for (;;) {
		tb1 = F591_5028(RTCV(F1563_17188(Current)));
		if (tb1) break;
		tr1 = RTLNSMART(eif_new_type(1206, 0).id);
		tr2 = RTOSCF(5712,F689_5712, (Current));
		ti4_1 = F1120_10289(RTCV(F1563_17188(Current)));
		tr3 = eif_out__i4_s1(ti4_1);
		tr2 = F1086_9822(RTCW(tr2), tr3);
		tr3 = RTOSCF(5847,F689_5847, (Current));
		ti4_1 = F1120_10289(RTCV(F1563_17188(Current)));
		tr4 = eif_out__i4_s1(ti4_1);
		tr3 = F1086_9822(RTCW(tr3), tr4);
		tr4 = RTOSCF(5848,F689_5848, (Current));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,0,1033,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr5 = RTLNTS(typres0.id, 3, 0);
		}
		((EIF_TYPED_VALUE *)tr5+1)->it_r = Current;
		RTAR(tr5,Current);
		ti4_1 = F1120_10289(RTCV(F1563_17188(Current)));
		((EIF_TYPED_VALUE *)tr5+2)->it_i4 = ti4_1;
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1085,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr8= RTLNRF(typres0.id, (EIF_POINTER) __A334_512_2, (EIF_POINTER) _A334_512_2, (EIF_POINTER)(F847_6415),tr5, 1, 1);
		}
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr9 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr9+1)->it_r = Current;
		RTAR(tr9,Current);
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1076,0xFFF9,1,997,1085,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr12= RTLNRF(typres0.id, (EIF_POINTER) __A334_499_2, (EIF_POINTER) _A334_499_2, (EIF_POINTER)(F838_6263),tr9, 1, 1);
		}
		tr13 = *(EIF_REFERENCE *)(Current);
		F1207_11155(RTCW(tr1), Current, Result, tr2, tr3, tr4, tr8, tr12, EIF_FALSE, tr13);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
		F1207_11158(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4436[Dtype(RTCW(tr1))-534])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_11_));
		F1120_10300(RTCV(F1563_17188(Current)));
	}
	tb2 = F483_4817(RTCV(F1563_17188(Current)));
	if ((EIF_BOOLEAN) !tb2) {
		loc1 = RTLNS(eif_new_type(1241, 0x00).id, 1241, _OBJSIZ_5_2_0_1_0_0_0_0_);
		tr1 = RTMS_EX_H("Item pixmaps:",13,323854906);
		F1113_10182(RTCW(loc1), tr1);
		F1120_10306(RTCW(Result), loc1);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {663,1205,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F664_5447(RTCW(tr1), ((EIF_INTEGER_32) 4L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	F1120_10298(RTCV(F1563_17188(Current)));
	for (;;) {
		tb2 = F591_5028(RTCV(F1563_17188(Current)));
		if (tb2) break;
		tr1 = RTLNSMART(eif_new_type(1205, 0).id);
		tr2 = RTOSCF(5713,F689_5713, (Current));
		ti4_1 = F1120_10289(RTCV(F1563_17188(Current)));
		tr3 = eif_out__i4_s1(ti4_1);
		tr2 = F1086_9822(RTCW(tr2), tr3);
		tr3 = RTMS_EX_H("",0,0);
		tr4 = RTMS_EX_H("Pixmap",6,31047280);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,0,1033,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr5 = RTLNTS(typres0.id, 3, 0);
		}
		((EIF_TYPED_VALUE *)tr5+1)->it_r = Current;
		RTAR(tr5,Current);
		ti4_1 = F1120_10289(RTCV(F1563_17188(Current)));
		((EIF_TYPED_VALUE *)tr5+2)->it_i4 = ti4_1;
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,2,997,1278,963,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr8= RTLNRF(typres0.id, (EIF_POINTER) __A334_514_2_3, (EIF_POINTER) _A334_514_2_3, (EIF_POINTER)(F847_6417),tr5, 1, 2);
		}
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr9 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr9+1)->it_r = Current;
		RTAR(tr9,Current);
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1076,0xFFF9,2,997,1278,963,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr12= RTLNRF(typres0.id, (EIF_POINTER) __A334_508_2_3, (EIF_POINTER) _A334_508_2_3, (EIF_POINTER)(F847_6411),tr9, 1, 2);
		}
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,0,1033,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr13 = RTLNTS(typres0.id, 3, 0);
		}
		((EIF_TYPED_VALUE *)tr13+1)->it_r = Current;
		RTAR(tr13,Current);
		ti4_1 = F1120_10289(RTCV(F1563_17188(Current)));
		((EIF_TYPED_VALUE *)tr13+2)->it_i4 = ti4_1;
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1072,0xFFF9,0,997,1278,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr14= RTLNRF(typres0.id, (EIF_POINTER) __A334_509, (EIF_POINTER) _A334_509, (EIF_POINTER)(F847_6412),tr13, 1, 0);
		}
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,0,1033,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr15 = RTLNTS(typres0.id, 3, 0);
		}
		((EIF_TYPED_VALUE *)tr15+1)->it_r = Current;
		RTAR(tr15,Current);
		ti4_1 = F1120_10289(RTCV(F1563_17188(Current)));
		((EIF_TYPED_VALUE *)tr15+2)->it_i4 = ti4_1;
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1072,0xFFF9,0,997,963,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr16= RTLNRF(typres0.id, (EIF_POINTER) __A334_510, (EIF_POINTER) _A334_510, (EIF_POINTER)(F847_6413),tr15, 1, 0);
		}
		tr17 = *(EIF_REFERENCE *)(Current);
		F1206_11126(RTCW(tr1), Current, Result, tr2, tr3, tr4, tr8, tr12, tr14, tr16, tr17);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4436[Dtype(RTCW(tr1))-534])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_12_));
		F1120_10300(RTCV(F1563_17188(Current)));
	}
	F847_6409(Current);
	F1563_17197(Current, Result);
	F1563_17196(Current, Result);
	RTLE;
	return Result;
}

/* {GB_EV_NOTEBOOK_EDITOR_CONSTRUCTOR}.update_attribute_editor */
void F847_6409 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,loc1);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	tr1 = F1152_10678(RTCW(tr1));
	F688_5577(RTCW(tr1));
	ti4_1 = F1202_11091(RTCV(F1563_17188(Current)));
	ti4_2 = ((EIF_INTEGER_32) 3L);
	if ((EIF_BOOLEAN)(ti4_1 == ti4_2)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		F1109_10165(RTCW(tr1));
	} else {
		ti4_1 = F1202_11091(RTCV(F1563_17188(Current)));
		ti4_2 = ((EIF_INTEGER_32) 4L);
		if ((EIF_BOOLEAN)(ti4_1 == ti4_2)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			F1109_10165(RTCW(tr1));
		} else {
			ti4_1 = F1202_11091(RTCV(F1563_17188(Current)));
			ti4_2 = ((EIF_INTEGER_32) 2L);
			if ((EIF_BOOLEAN)(ti4_1 == ti4_2)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
				F1109_10165(RTCW(tr1));
			} else {
				ti4_1 = F1202_11091(RTCV(F1563_17188(Current)));
				ti4_2 = ((EIF_INTEGER_32) 1L);
				if ((EIF_BOOLEAN)(ti4_1 == ti4_2)) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
					F1109_10165(RTCW(tr1));
				}
			}
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	tr1 = F1152_10678(RTCW(tr1));
	F688_5579(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F664_5478(RTCW(tr1));
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tb1 = F591_5028(RTCW(tr1));
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tr1 = F664_5452(RTCW(tr1));
		tr2 = F1563_17188(Current);
		tr3 = F1563_17188(Current);
		tr4 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr4) + O4870[Dtype(tr4)-663]);
		tr3 = F1120_10291(RTCW(tr3), ti4_1);
		tr2 = F1202_11086(RTCW(tr2), tr3);
		tr2 = F1078_9449(RTCW(tr2));
		F1207_11160(RTCW(tr1), tr2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F664_5480(RTCW(tr1));
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F664_5478(RTCW(tr1));
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		tb2 = F591_5028(RTCW(tr1));
		if (tb2) break;
		tr1 = F1563_17188(Current);
		tr2 = F1563_17188(Current);
		tr3 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr3) + O4870[Dtype(tr3)-663]);
		tr2 = F1120_10291(RTCW(tr2), ti4_1);
		loc1 = F1202_11087(RTCW(tr1), tr2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		tr1 = F664_5452(RTCW(tr1));
		tr2 = F1108_10155(RTCW(loc1));
		F1206_11127(RTCW(tr1), tr2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		F664_5480(RTCW(tr1));
	}
	RTLE;
}

/* {GB_EV_NOTEBOOK_EDITOR_CONSTRUCTOR}.validate */
EIF_BOOLEAN F847_6411 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {GB_EV_NOTEBOOK_EDITOR_CONSTRUCTOR}.return_pixmap */
EIF_REFERENCE F847_6412 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O13222[dtype-1562]);
	tr1 = F664_5455(RTCW(tr1));
	tr2 = *(EIF_REFERENCE *)(Current + O13222[dtype-1562]);
	tr2 = F664_5455(RTCW(tr2));
	tr2 = F1120_10291(RTCW(tr2), arg1);
	loc1 = F1202_11087(RTCW(tr1), tr2);
	tr1 = F1108_10155(RTCW(loc1));
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {GB_EV_NOTEBOOK_EDITOR_CONSTRUCTOR}.return_pixmap_path */
EIF_REFERENCE F847_6413 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O13222[Dtype(Current)-1562]);
	tr1 = F664_5455(RTCW(tr1));
	tr1 = RTOSCF(11088,F1202_11088, (RTCW(tr1)));
	Result = F656_5322(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {GB_EV_NOTEBOOK_EDITOR_CONSTRUCTOR}.selection_changed */
void F847_6414 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 2, 1);
	}
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	tr2 = F1253_12120(RTCW(tr2));
	tr2 = F1113_10183(RTCW(tr2));
	tr2 = F1078_9449(RTCW(tr2));
	ti4_1 = F847_6420(Current, tr2);
	((EIF_TYPED_VALUE *)tr1+1)->it_i4 = ti4_1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1201,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A560_317_1, (EIF_POINTER) _A560_317_1, 0, tr1, 0, 1);
	}
	F1563_17199(Current, tr4);
	RTLE;
}

/* {GB_EV_NOTEBOOK_EDITOR_CONSTRUCTOR}.set_text */
void F847_6415 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLIU(7);
	
	RTGC;
	F847_6416(Current, *(EIF_REFERENCE *)(Current + _REFACS_3_), arg1, arg2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,997,0,1085,1033,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 4, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	((EIF_TYPED_VALUE *)tr2+2)->it_r = arg1;
	RTAR(tr2,arg1);
	((EIF_TYPED_VALUE *)tr2+3)->it_i4 = arg2;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,33,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A334_513_2, (EIF_POINTER) _A334_513_2, (EIF_POINTER)(F847_6416),tr2, 1, 1);
	}
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.for_all_instance_referers) */
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.enable_project_modified) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {GB_EV_NOTEBOOK_EDITOR_CONSTRUCTOR}.actual_set_text */
void F847_6416 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
	loc1 = RTRV(eif_new_type(1201, 0x00), loc1);
	tr1 = F1120_10291(RTCW(loc1), arg3);
	F1202_11104(RTCW(loc1), tr1, arg2);
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
	loc1 = RTRV(eif_new_type(1201, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = F1120_10291(RTCW(loc1), arg3);
		F1202_11104(RTCW(loc1), tr1, arg2);
	}
	RTLE;
}

/* {GB_EV_NOTEBOOK_EDITOR_CONSTRUCTOR}.set_pixmap */
void F847_6417 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,tr5);
	RTLIU(8);
	
	RTGC;
	F847_6418(Current, *(EIF_REFERENCE *)(Current + _REFACS_3_), arg1, arg2, arg3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,4,997,0,1278,963,1033,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 5, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	((EIF_TYPED_VALUE *)tr2+2)->it_r = arg1;
	RTAR(tr2,arg1);
	((EIF_TYPED_VALUE *)tr2+3)->it_r = arg2;
	RTAR(tr2,arg2);
	((EIF_TYPED_VALUE *)tr2+4)->it_i4 = arg3;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,33,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A334_515_2, (EIF_POINTER) _A334_515_2, (EIF_POINTER)(F847_6418),tr2, 1, 1);
	}
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.for_all_instance_referers) */
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.enable_project_modified) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {GB_EV_NOTEBOOK_EDITOR_CONSTRUCTOR}.actual_set_pixmap */
void F847_6418 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,arg3);
	RTLR(5,arg2);
	RTLR(6,Current);
	RTLIU(7);
	
	RTGC;
	loc2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
	loc2 = RTRV(eif_new_type(1201, 0x00), loc2);
	tr1 = F1120_10291(RTCW(loc2), arg4);
	loc1 = F1202_11087(RTCW(loc2), tr1);
	if ((EIF_BOOLEAN)(arg3 != NULL)) {
		tr1 = RTOSCF(11088,F1202_11088, (RTCW(loc2)));
		F656_5362(RTCW(tr1), arg3, arg4);
	} else {
		tr1 = RTOSCF(11088,F1202_11088, (RTCW(loc2)));
		F656_5368(RTCW(tr1), arg4);
	}
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		F1108_10157(RTCW(loc1), arg2);
	} else {
		F1108_10158(RTCW(loc1));
	}
	loc2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
	loc2 = RTRV(eif_new_type(1201, 0x00), loc2);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		tr1 = F1120_10291(RTCW(loc2), arg4);
		loc1 = F1202_11087(RTCW(loc2), tr1);
		if ((EIF_BOOLEAN)(arg3 != NULL)) {
			tr1 = RTOSCF(11088,F1202_11088, (RTCW(loc2)));
			F656_5362(RTCW(tr1), arg3, arg4);
		} else {
			tr1 = RTOSCF(11088,F1202_11088, (RTCW(loc2)));
			F656_5368(RTCW(tr1), arg4);
		}
		if ((EIF_BOOLEAN)(arg2 != NULL)) {
			F1108_10157(RTCW(loc1), arg2);
		} else {
			F1108_10158(RTCW(loc1));
		}
	}
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.enable_project_modified) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {GB_EV_NOTEBOOK_EDITOR_CONSTRUCTOR}.position_from_text */
EIF_INTEGER_32 F847_6420 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(6426,F847_6426, (Current));
	tb1 = F1084_9718(RTCW(arg1), tr1);
	if (tb1) {
		Result = ((EIF_INTEGER_32) 3L);
	} else {
		tr1 = RTOSCF(6427,F847_6427, (Current));
		tb1 = F1084_9718(RTCW(arg1), tr1);
		if (tb1) {
			Result = ((EIF_INTEGER_32) 4L);
		} else {
			tr1 = RTOSCF(6425,F847_6425, (Current));
			tb1 = F1084_9718(RTCW(arg1), tr1);
			if (tb1) {
				Result = ((EIF_INTEGER_32) 2L);
			} else {
				tr1 = RTOSCF(6424,F847_6424, (Current));
				tb1 = F1084_9718(RTCW(arg1), tr1);
				if (tb1) {
					Result = ((EIF_INTEGER_32) 1L);
				} else {
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {GB_EV_NOTEBOOK_EDITOR_CONSTRUCTOR}.ev_tab_left_string */

EIF_REFERENCE F847_6424 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6424,RTMS_EX_H("Left",4,1281713780));
}

/* {GB_EV_NOTEBOOK_EDITOR_CONSTRUCTOR}.ev_tab_right_string */

EIF_REFERENCE F847_6425 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6425,RTMS_EX_H("Right",5,1769014388));
}

/* {GB_EV_NOTEBOOK_EDITOR_CONSTRUCTOR}.ev_tab_top_string */

EIF_REFERENCE F847_6426 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6426,RTMS_EX_H("Top",3,5533552));
}

/* {GB_EV_NOTEBOOK_EDITOR_CONSTRUCTOR}.ev_tab_bottom_string */

EIF_REFERENCE F847_6427 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6427,RTMS_EX_H("Bottom",6,2084401517));
}

void EIF_Minit334 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
