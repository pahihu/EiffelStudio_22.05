/*
 * Code for class EV_PND_ACTION_SEQUENCE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev302.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PND_ACTION_SEQUENCE}.call */
void F814_6166 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		switch (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_2_0_1_)) {
			case 1L:
				tr1 = eif_boxed_item(arg1,1);
				tr2 = RTCCL(tr1);
				if (F814_6171(Current, tr2)) {
					{
						static EIF_TYPE_INDEX typarr0[] = {663,1071,0xFFF9,1,997,0,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
						loc1 = RTLNS(typres0.id, 663, _OBJSIZ_1_1_0_1_0_0_0_0_);
					}
					ti4_1 = F664_5468(Current);
					F664_5447(RTCW(loc1), ti4_1);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4437[Dtype(RTCW(loc1))-534])(loc1, Current);
					tr1 = F688_5594(Current);
					F644_5112(RTCW(tr1), (EIF_BOOLEAN) 0);
					F664_5478(RTCW(loc1));
					for (;;) {
						tb1 = '\01';
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O4870[Dtype(loc1)-663]);
						ti4_2 = F664_5468(RTCW(loc1));
						if (!(EIF_BOOLEAN) (ti4_1 > ti4_2)) {
							tb2 = F644_5110(RTCV(F688_5594(Current)));
							tb1 = tb2;
						}
						if (tb1) break;
						tr1 = F664_5452(RTCW(loc1));
						tb2 = F1071_9349(RTCW(tr1), arg1);
						if (tb2) {
							tr1 = F664_5452(RTCW(loc1));
							F1071_9358(RTCW(tr1), arg1);
						}
						F664_5480(RTCW(loc1));
					}
					F644_5114(RTCV(F688_5594(Current)));
				}
				break;
			case 2L:
				tr1 = F688_5596(Current);
				F645_5127(RTCW(tr1), arg1);
				break;
			case 3L:
				break;
			default:
				RTEC(EN_WHEN);
		}
	}
	RTLE;
}

/* {EV_PND_ACTION_SEQUENCE}.set_veto_pebble_function */
void F814_6167 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) arg1;
}

/* {EV_PND_ACTION_SEQUENCE}.accepts_pebble */
EIF_BOOLEAN F814_6168 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	tr1 = RTCCL(arg1);
	if (F814_6171(Current, tr1)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr1 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr1+1)->it_r = arg1;
		RTAR(tr1,arg1);
		loc2 = (EIF_REFERENCE) tr1;
		loc1 = F664_5458(Current);
		F664_5478(Current);
		for (;;) {
			tb1 = '\01';
			if (!Result) {
				tb1 = F615_5052(Current);
			}
			if (tb1) break;
			tr1 = F664_5452(Current);
			Result = F1071_9349(RTCW(tr1), loc2);
			F664_5480(Current);
		}
		F664_5483(Current, loc1);
	}
	RTLE;
	return Result;
}

/* {EV_PND_ACTION_SEQUENCE}.veto_pebble_function_result */
EIF_BOOLEAN F814_6171 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr1+1)->it_r = arg1;
		RTAR(tr1,arg1);
		loc1 = (EIF_REFERENCE) tr1;
		Result = '\0';
		tb1 = F1071_9349(loc2, loc1);
		if (tb1) {
			tb1 = F1074_9390(loc2, loc1);
			Result = tb1;
		}
	} else {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTLE;
	return Result;
}

void EIF_Minit302 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
