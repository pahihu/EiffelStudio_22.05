/*
 * Code for class EV_RECTANGLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev348.h"
#include "eif_helpers.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_RECTANGLE}.make */
void F861_6692 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_1_) = (EIF_INTEGER_32) arg2;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_2_) = (EIF_INTEGER_32) arg3;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_3_) = (EIF_INTEGER_32) arg4;
	RTLE;
}

/* {EV_RECTANGLE}.set */
void F861_6693 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_1_) = (EIF_INTEGER_32) arg2;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_2_) = (EIF_INTEGER_32) arg3;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_3_) = (EIF_INTEGER_32) arg4;
	RTLE;
}

/* {EV_RECTANGLE}.left */
EIF_INTEGER_32 F861_6698 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_);
}

/* {EV_RECTANGLE}.top */
EIF_INTEGER_32 F861_6699 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_1_);
}

/* {EV_RECTANGLE}.right */
EIF_INTEGER_32 F861_6700 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) + *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_2_));
}

/* {EV_RECTANGLE}.bottom */
EIF_INTEGER_32 F861_6701 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_1_) + *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_3_));
}

/* {EV_RECTANGLE}.has_area */
EIF_BOOLEAN F861_6702 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_2_) > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_3_) > ((EIF_INTEGER_32) 0L)));
}

/* {EV_RECTANGLE}.contains */
EIF_BOOLEAN F861_6709 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	tb2 = '\0';
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) <= ti4_1)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_1_);
		tb2 = (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_1_) <= ti4_1);
	}
	if (tb2) {
		ti4_1 = F861_6701(RTCW(arg1));
		tb1 = (EIF_BOOLEAN) (ti4_1 <= F861_6701(Current));
	}
	if (tb1) {
		ti4_1 = F861_6700(RTCW(arg1));
		Result = (EIF_BOOLEAN) (ti4_1 <= F861_6700(Current));
	}
	RTLE;
	return Result;
}

/* {EV_RECTANGLE}.intersects */
EIF_BOOLEAN F861_6710 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	if (F861_6702(Current)) {
		tb2 = F861_6702(RTCW(arg1));
		tb1 = tb2;
	}
	if (tb1) {
		tb1 = '\01';
		tb2 = '\01';
		tb3 = '\01';
		ti4_1 = F861_6700(RTCW(arg1));
		if (!(EIF_BOOLEAN) (F861_6698(Current) >= ti4_1)) {
			ti4_1 = F861_6698(RTCW(arg1));
			tb3 = (EIF_BOOLEAN) (F861_6700(Current) <= ti4_1);
		}
		if (!tb3) {
			ti4_1 = F861_6701(RTCW(arg1));
			tb2 = (EIF_BOOLEAN) (F861_6699(Current) >= ti4_1);
		}
		if (!tb2) {
			ti4_1 = F861_6699(RTCW(arg1));
			tb1 = (EIF_BOOLEAN) (F861_6701(Current) <= ti4_1);
		}
		Result = (EIF_BOOLEAN) !tb1;
	}
	RTLE;
	return Result;
}

/* {EV_RECTANGLE}.include */
void F861_6713 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = F861_6698(Current);
	ti4_1 = eif_min_int32 (ti4_1,arg1);
	F861_6719(Current, ti4_1);
	ti4_1 = F861_6699(Current);
	ti4_1 = eif_min_int32 (ti4_1,arg2);
	F861_6721(Current, ti4_1);
	ti4_1 = F861_6700(Current);
	ti4_1 = eif_max_int32 (ti4_1,arg1);
	F861_6720(Current, ti4_1);
	ti4_1 = F861_6701(Current);
	ti4_1 = eif_max_int32 (ti4_1,arg2);
	F861_6722(Current, ti4_1);
	RTLE;
}

/* {EV_RECTANGLE}.merge */
void F861_6714 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	ti4_1 = F861_6698(Current);
	ti4_2 = F861_6698(RTCW(arg1));
	ti4_1 = eif_min_int32 (ti4_1,ti4_2);
	F861_6719(Current, ti4_1);
	ti4_1 = F861_6699(Current);
	ti4_2 = F861_6699(RTCW(arg1));
	ti4_1 = eif_min_int32 (ti4_1,ti4_2);
	F861_6721(Current, ti4_1);
	ti4_1 = F861_6700(Current);
	ti4_2 = F861_6700(RTCW(arg1));
	ti4_1 = eif_max_int32 (ti4_1,ti4_2);
	F861_6720(Current, ti4_1);
	ti4_1 = F861_6701(Current);
	ti4_2 = F861_6701(RTCW(arg1));
	ti4_1 = eif_max_int32 (ti4_1,ti4_2);
	F861_6722(Current, ti4_1);
	RTLE;
}

/* {EV_RECTANGLE}.set_left */
void F861_6719 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_2_) = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_2_) - arg1) + *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_INTEGER_32) arg1;
	RTLE;
}

/* {EV_RECTANGLE}.set_right */
void F861_6720 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_2_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_));
}

/* {EV_RECTANGLE}.set_top */
void F861_6721 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_3_) = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_3_) - arg1) + *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_1_));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_1_) = (EIF_INTEGER_32) arg1;
	RTLE;
}

/* {EV_RECTANGLE}.set_bottom */
void F861_6722 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_3_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_1_));
}

/* {EV_RECTANGLE}.set_x */
void F861_6723 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_INTEGER_32) arg1;
}

/* {EV_RECTANGLE}.set_y */
void F861_6724 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_1_) = (EIF_INTEGER_32) arg1;
}

/* {EV_RECTANGLE}.set_width */
void F861_6725 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_2_) = (EIF_INTEGER_32) arg1;
}

/* {EV_RECTANGLE}.set_height */
void F861_6726 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_3_) = (EIF_INTEGER_32) arg1;
}

/* {EV_RECTANGLE}.move_and_resize */
void F861_6729 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_1_) = (EIF_INTEGER_32) arg2;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_2_) = (EIF_INTEGER_32) arg3;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_3_) = (EIF_INTEGER_32) arg4;
	RTLE;
}

/* {EV_RECTANGLE}.out */
EIF_REFERENCE F861_6731 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = RTMS_EX_H("(X: ",4,676870688);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_);
	tr2 = eif_out__i4_s1(ti4_1);
	tr1 = F1086_9822(tr1, tr2);
	tr2 = RTMS_EX_H(", Y: ",5,543056416);
	tr1 = F1086_9822(RTCW(tr1), tr2);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_1_);
	tr2 = eif_out__i4_s1(ti4_1);
	tr1 = F1086_9822(RTCW(tr1), tr2);
	tr2 = RTMS_EX_H(", Width: ",9,1306770464);
	tr1 = F1086_9822(RTCW(tr1), tr2);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_2_);
	tr2 = eif_out__i4_s1(ti4_1);
	tr1 = F1086_9822(RTCW(tr1), tr2);
	tr2 = RTMS_EX_H(", Height: ",10,1818164768);
	tr1 = F1086_9822(RTCW(tr1), tr2);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_3_);
	tr2 = eif_out__i4_s1(ti4_1);
	tr1 = F1086_9822(RTCW(tr1), tr2);
	tr2 = RTMS_EX_H(")",1,41);
	Result = F1086_9822(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

void EIF_Minit348 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
