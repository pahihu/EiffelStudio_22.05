/*
 * Code for class GB_EV_VIEWPORT_EDITOR_CONSTRUCTOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gb342.h"
#include "eif_helpers.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GB_EV_VIEWPORT_EDITOR_CONSTRUCTOR}.ev_type */
EIF_REFERENCE F855_6554 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_8_);
}


/* {GB_EV_VIEWPORT_EDITOR_CONSTRUCTOR}.attribute_editor */
EIF_REFERENCE F855_6556 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_REFERENCE tr6 = NULL;
	EIF_REFERENCE tr7 = NULL;
	EIF_REFERENCE tr8 = NULL;
	EIF_REFERENCE tr9 = NULL;
	EIF_REFERENCE tr10 = NULL;
	EIF_REFERENCE tr11 = NULL;
	EIF_REFERENCE tr12 = NULL;
	EIF_REFERENCE tr13 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(15);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLR(7,tr6);
	RTLR(8,tr7);
	RTLR(9,tr8);
	RTLR(10,tr9);
	RTLR(11,tr10);
	RTLR(12,tr11);
	RTLR(13,tr12);
	RTLR(14,tr13);
	RTLIU(15);
	
	RTGC;
	Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_7_3_0_1_0_0_0_0_);
	F1209_11188(RTCW(Result), *(EIF_REFERENCE *)(Current));
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.initialize_attribute_editor) */
		/* END INLINED CODE */
	}
	;
	tr1 = RTLNSMART(eif_new_type(1207, 0).id);
	tr2 = RTOSCF(6568,F855_6568, (Current));
	tr3 = RTOSCF(5804,F689_5804, (Current));
	tr4 = RTOSCF(5805,F689_5805, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr5 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr5+1)->it_r = Current;
	RTAR(tr5,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr8= RTLNRF(typres0.id, (EIF_POINTER) __A342_508_2, (EIF_POINTER) _A342_508_2, (EIF_POINTER)(F855_6559),tr5, 1, 1);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr9 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr9+1)->it_r = Current;
	RTAR(tr9,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1076,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr12= RTLNRF(typres0.id, (EIF_POINTER) __A342_510_2, (EIF_POINTER) _A342_510_2, (EIF_POINTER)(F855_6561),tr9, 1, 1);
	}
	tr13 = *(EIF_REFERENCE *)(Current);
	F1208_11174(RTCW(tr1), Current, Result, tr2, tr3, tr4, tr8, tr12, tr13);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1207, 0).id);
	tr2 = RTOSCF(6569,F855_6569, (Current));
	tr3 = RTOSCF(5806,F689_5806, (Current));
	tr4 = RTOSCF(5807,F689_5807, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr5 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr5+1)->it_r = Current;
	RTAR(tr5,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr8= RTLNRF(typres0.id, (EIF_POINTER) __A342_509_2, (EIF_POINTER) _A342_509_2, (EIF_POINTER)(F855_6560),tr5, 1, 1);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr9 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr9+1)->it_r = Current;
	RTAR(tr9,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1076,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr12= RTLNRF(typres0.id, (EIF_POINTER) __A342_510_2, (EIF_POINTER) _A342_510_2, (EIF_POINTER)(F855_6561),tr9, 1, 1);
	}
	tr13 = *(EIF_REFERENCE *)(Current);
	F1208_11174(RTCW(tr1), Current, Result, tr2, tr3, tr4, tr8, tr12, tr13);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1207, 0).id);
	tr2 = RTOSCF(6570,F855_6570, (Current));
	tr3 = RTOSCF(5810,F689_5810, (Current));
	tr4 = RTOSCF(5811,F689_5811, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr5 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr5+1)->it_r = Current;
	RTAR(tr5,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr8= RTLNRF(typres0.id, (EIF_POINTER) __A342_511_2, (EIF_POINTER) _A342_511_2, (EIF_POINTER)(F855_6562),tr5, 1, 1);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr9 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr9+1)->it_r = Current;
	RTAR(tr9,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1076,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr12= RTLNRF(typres0.id, (EIF_POINTER) __A342_515_2, (EIF_POINTER) _A342_515_2, (EIF_POINTER)(F855_6566),tr9, 1, 1);
	}
	tr13 = *(EIF_REFERENCE *)(Current);
	F1208_11174(RTCW(tr1), Current, Result, tr2, tr3, tr4, tr8, tr12, tr13);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1207, 0).id);
	tr2 = RTOSCF(6571,F855_6571, (Current));
	tr3 = RTOSCF(5808,F689_5808, (Current));
	tr4 = RTOSCF(5809,F689_5809, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr5 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr5+1)->it_r = Current;
	RTAR(tr5,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr8= RTLNRF(typres0.id, (EIF_POINTER) __A342_513_2, (EIF_POINTER) _A342_513_2, (EIF_POINTER)(F855_6564),tr5, 1, 1);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr9 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr9+1)->it_r = Current;
	RTAR(tr9,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1076,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr12= RTLNRF(typres0.id, (EIF_POINTER) __A342_516_2, (EIF_POINTER) _A342_516_2, (EIF_POINTER)(F855_6567),tr9, 1, 1);
	}
	tr13 = *(EIF_REFERENCE *)(Current);
	F1208_11174(RTCW(tr1), Current, Result, tr2, tr3, tr4, tr8, tr12, tr13);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	F855_6558(Current);
	F1563_17197(Current, Result);
	F1563_17196(Current, Result);
	RTLE;
	return Result;
}

/* {GB_EV_VIEWPORT_EDITOR_CONSTRUCTOR}.update_attribute_editor */
void F855_6558 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	ti4_1 = F1212_11396(RTCV(F1563_17188(Current)));
	tr2 = eif_out__i4_s1(ti4_1);
	{
		/* INLINED CODE (GB_INTEGER_INPUT_FIELD.update_constant_display) */
		(void) RTCW(tr1);
		/* END INLINED CODE */
	}
	;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	ti4_1 = F1212_11397(RTCV(F1563_17188(Current)));
	tr2 = eif_out__i4_s1(ti4_1);
	{
		/* INLINED CODE (GB_INTEGER_INPUT_FIELD.update_constant_display) */
		(void) RTCW(tr1);
		/* END INLINED CODE */
	}
	;
	tb1 = F1210_11192(RTCV(F1563_17188(Current)));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tr2 = F1195_10952(RTCV(F1563_17188(Current)));
		ti4_1 = F1106_10142(RTCW(tr2));
		tr2 = eif_out__i4_s1(ti4_1);
		{
			/* INLINED CODE (GB_INTEGER_INPUT_FIELD.update_constant_display) */
			(void) RTCW(tr1);
			/* END INLINED CODE */
		}
		;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr2 = F1195_10952(RTCV(F1563_17188(Current)));
		ti4_1 = F1106_10143(RTCW(tr2));
		tr2 = eif_out__i4_s1(ti4_1);
		{
			/* INLINED CODE (GB_INTEGER_INPUT_FIELD.update_constant_display) */
			(void) RTCW(tr1);
			/* END INLINED CODE */
		}
		;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tr2 = RTMS_EX_H("0",1,48);
		F1208_11176(RTCW(tr1), tr2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr2 = RTMS_EX_H("0",1,48);
		F1208_11176(RTCW(tr1), tr2);
	}
	tb1 = F1210_11190(RTCV(F1563_17188(Current)));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F1121_10336(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		F1121_10336(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		F1121_10336(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		F1121_10336(RTCW(tr1));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F1121_10335(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		F1121_10335(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		F1121_10335(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		F1121_10335(RTCW(tr1));
	}
	RTLE;
}

/* {GB_EV_VIEWPORT_EDITOR_CONSTRUCTOR}.set_x_offset */
void F855_6559 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 2, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_i4 = arg1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1211,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A570_248_1, (EIF_POINTER) _A570_248_1, 0, tr1, 0, 1);
	}
	F1563_17199(Current, tr4);
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.update_editors) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {GB_EV_VIEWPORT_EDITOR_CONSTRUCTOR}.set_y_offset */
void F855_6560 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 2, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_i4 = arg1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1211,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A570_249_1, (EIF_POINTER) _A570_249_1, 0, tr1, 0, 1);
	}
	F1563_17199(Current, tr4);
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.update_editors) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {GB_EV_VIEWPORT_EDITOR_CONSTRUCTOR}.valid_position */
EIF_BOOLEAN F855_6561 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {GB_EV_VIEWPORT_EDITOR_CONSTRUCTOR}.set_item_width */
void F855_6562 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,tr5);
	RTLIU(6);
	
	RTGC;
	F855_6563(Current, *(EIF_REFERENCE *)(Current + _REFACS_3_), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,0,1033,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	((EIF_TYPED_VALUE *)tr2+2)->it_i4 = arg1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,33,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A342_512_2, (EIF_POINTER) _A342_512_2, (EIF_POINTER)(F855_6563),tr2, 1, 1);
	}
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.for_all_instance_referers) */
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.enable_project_modified) */
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.update_editors) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {GB_EV_VIEWPORT_EDITOR_CONSTRUCTOR}.actual_set_item_width */
void F855_6563 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
	loc1 = RTRV(eif_new_type(1211, 0x00), loc1);
	tb1 = F1210_11195(RTCW(loc1));
	if (tb1) {
		F1212_11401(RTCW(loc1), arg2);
	}
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
	loc1 = RTRV(eif_new_type(1211, 0x00), loc1);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tb2 = F1210_11195(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = F1195_10952(RTCW(loc1));
		ti4_1 = F1106_10142(RTCW(tr1));
		ti4_1 = eif_max_int32 (arg2,ti4_1);
		F1212_11401(RTCW(loc1), ti4_1);
	}
	RTLE;
}

/* {GB_EV_VIEWPORT_EDITOR_CONSTRUCTOR}.set_item_height */
void F855_6564 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,tr5);
	RTLIU(6);
	
	RTGC;
	F855_6565(Current, *(EIF_REFERENCE *)(Current + _REFACS_3_), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,0,1033,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	((EIF_TYPED_VALUE *)tr2+2)->it_i4 = arg1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,33,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A342_514_2, (EIF_POINTER) _A342_514_2, (EIF_POINTER)(F855_6565),tr2, 1, 1);
	}
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.for_all_instance_referers) */
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.enable_project_modified) */
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.update_editors) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {GB_EV_VIEWPORT_EDITOR_CONSTRUCTOR}.actual_set_item_height */
void F855_6565 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
	loc1 = RTRV(eif_new_type(1211, 0x00), loc1);
	tb1 = F1210_11195(RTCW(loc1));
	if (tb1) {
		F1212_11402(RTCW(loc1), arg2);
	}
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
	loc1 = RTRV(eif_new_type(1211, 0x00), loc1);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tb2 = F1210_11195(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = F1195_10952(RTCW(loc1));
		ti4_1 = F1106_10143(RTCW(tr1));
		ti4_1 = eif_max_int32 (arg2,ti4_1);
		F1212_11402(RTCW(loc1), ti4_1);
	}
	RTLE;
}

/* {GB_EV_VIEWPORT_EDITOR_CONSTRUCTOR}.valid_item_width */
EIF_BOOLEAN F855_6566 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = F1195_10952(RTCV(F1563_17188(Current)));
	ti4_1 = F1106_10144(RTCW(tr1));
	if ((EIF_BOOLEAN) (arg1 >= ti4_1)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

/* {GB_EV_VIEWPORT_EDITOR_CONSTRUCTOR}.valid_item_height */
EIF_BOOLEAN F855_6567 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = F1195_10952(RTCV(F1563_17188(Current)));
	ti4_1 = F1106_10145(RTCW(tr1));
	if ((EIF_BOOLEAN) (arg1 >= ti4_1)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

/* {GB_EV_VIEWPORT_EDITOR_CONSTRUCTOR}.x_offset_string */

EIF_REFERENCE F855_6568 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6568,RTMS_EX_H("X_offset",8,381162100));
}

/* {GB_EV_VIEWPORT_EDITOR_CONSTRUCTOR}.y_offset_string */

EIF_REFERENCE F855_6569 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6569,RTMS_EX_H("Y_offset",8,381392500));
}

/* {GB_EV_VIEWPORT_EDITOR_CONSTRUCTOR}.item_width_string */

EIF_REFERENCE F855_6570 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6570,RTMS_EX_H("Item_width",10,2011642984));
}

/* {GB_EV_VIEWPORT_EDITOR_CONSTRUCTOR}.item_height_string */

EIF_REFERENCE F855_6571 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6571,RTMS_EX_H("Item_height",11,1786442100));
}

void EIF_Minit342 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
