/*
 * Code for class GB_EV_GAUGE_EDITOR_CONSTRUCTOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gb328.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GB_EV_GAUGE_EDITOR_CONSTRUCTOR}.ev_type */
EIF_REFERENCE F841_6300 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_10_);
}


/* {GB_EV_GAUGE_EDITOR_CONSTRUCTOR}.attribute_editor */
EIF_REFERENCE F841_6302 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_REFERENCE tr6 = NULL;
	EIF_REFERENCE tr7 = NULL;
	EIF_REFERENCE tr8 = NULL;
	EIF_REFERENCE tr9 = NULL;
	EIF_REFERENCE tr10 = NULL;
	EIF_REFERENCE tr11 = NULL;
	EIF_REFERENCE tr12 = NULL;
	EIF_REFERENCE tr13 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(15);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLR(7,tr6);
	RTLR(8,tr7);
	RTLR(9,tr8);
	RTLR(10,tr9);
	RTLR(11,tr10);
	RTLR(12,tr11);
	RTLR(13,tr12);
	RTLR(14,tr13);
	RTLIU(15);
	
	RTGC;
	Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_7_3_0_1_0_0_0_0_);
	F1209_11188(RTCW(Result), *(EIF_REFERENCE *)(Current));
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.initialize_attribute_editor) */
		/* END INLINED CODE */
	}
	;
	tr1 = RTLNSMART(eif_new_type(1207, 0).id);
	tr2 = RTOSCF(6320,F841_6320, (Current));
	tr3 = RTOSCF(5794,F689_5794, (Current));
	tr4 = RTOSCF(5795,F689_5795, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr5 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr5+1)->it_r = Current;
	RTAR(tr5,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr8= RTLNRF(typres0.id, (EIF_POINTER) __A328_513_2, (EIF_POINTER) _A328_513_2, (EIF_POINTER)(F841_6310),tr5, 1, 1);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr9 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr9+1)->it_r = Current;
	RTAR(tr9,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1076,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr12= RTLNRF(typres0.id, (EIF_POINTER) __A328_514_2, (EIF_POINTER) _A328_514_2, (EIF_POINTER)(F841_6311),tr9, 1, 1);
	}
	tr13 = *(EIF_REFERENCE *)(Current);
	F1208_11174(RTCW(tr1), Current, Result, tr2, tr3, tr4, tr8, tr12, tr13);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1207, 0).id);
	tr2 = RTOSCF(6321,F841_6321, (Current));
	tr3 = RTOSCF(5796,F689_5796, (Current));
	tr4 = RTOSCF(5797,F689_5797, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr5 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr5+1)->it_r = Current;
	RTAR(tr5,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr8= RTLNRF(typres0.id, (EIF_POINTER) __A328_515_2, (EIF_POINTER) _A328_515_2, (EIF_POINTER)(F841_6312),tr5, 1, 1);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr9 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr9+1)->it_r = Current;
	RTAR(tr9,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1076,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr12= RTLNRF(typres0.id, (EIF_POINTER) __A328_516_2, (EIF_POINTER) _A328_516_2, (EIF_POINTER)(F841_6313),tr9, 1, 1);
	}
	tr13 = *(EIF_REFERENCE *)(Current);
	F1208_11174(RTCW(tr1), Current, Result, tr2, tr3, tr4, tr8, tr12, tr13);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1207, 0).id);
	tr2 = RTOSCF(6322,F841_6322, (Current));
	tr3 = RTOSCF(5798,F689_5798, (Current));
	tr4 = RTOSCF(5799,F689_5799, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr5 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr5+1)->it_r = Current;
	RTAR(tr5,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr8= RTLNRF(typres0.id, (EIF_POINTER) __A328_517_2, (EIF_POINTER) _A328_517_2, (EIF_POINTER)(F841_6314),tr5, 1, 1);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr9 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr9+1)->it_r = Current;
	RTAR(tr9,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1076,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr12= RTLNRF(typres0.id, (EIF_POINTER) __A328_516_2, (EIF_POINTER) _A328_516_2, (EIF_POINTER)(F841_6313),tr9, 1, 1);
	}
	tr13 = *(EIF_REFERENCE *)(Current);
	F1208_11174(RTCW(tr1), Current, Result, tr2, tr3, tr4, tr8, tr12, tr13);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1207, 0).id);
	tr2 = RTOSCF(6323,F841_6323, (Current));
	tr3 = RTOSCF(5800,F689_5800, (Current));
	tr4 = RTOSCF(5801,F689_5801, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr5 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr5+1)->it_r = Current;
	RTAR(tr5,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr8= RTLNRF(typres0.id, (EIF_POINTER) __A328_518_2, (EIF_POINTER) _A328_518_2, (EIF_POINTER)(F841_6315),tr5, 1, 1);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr9 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr9+1)->it_r = Current;
	RTAR(tr9,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1076,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr12= RTLNRF(typres0.id, (EIF_POINTER) __A328_520_2, (EIF_POINTER) _A328_520_2, (EIF_POINTER)(F841_6317),tr9, 1, 1);
	}
	tr13 = *(EIF_REFERENCE *)(Current);
	F1208_11174(RTCW(tr1), Current, Result, tr2, tr3, tr4, tr8, tr12, tr13);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1207, 0).id);
	tr2 = RTOSCF(6324,F841_6324, (Current));
	tr3 = RTOSCF(5802,F689_5802, (Current));
	tr4 = RTOSCF(5803,F689_5803, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr5 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr5+1)->it_r = Current;
	RTAR(tr5,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr8= RTLNRF(typres0.id, (EIF_POINTER) __A328_521_2, (EIF_POINTER) _A328_521_2, (EIF_POINTER)(F841_6318),tr5, 1, 1);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr9 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr9+1)->it_r = Current;
	RTAR(tr9,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1076,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr12= RTLNRF(typres0.id, (EIF_POINTER) __A328_522_2, (EIF_POINTER) _A328_522_2, (EIF_POINTER)(F841_6319),tr9, 1, 1);
	}
	tr13 = *(EIF_REFERENCE *)(Current);
	F1208_11174(RTCW(tr1), Current, Result, tr2, tr3, tr4, tr8, tr12, tr13);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	F841_6304(Current);
	F1563_17197(Current, Result);
	F1563_17196(Current, Result);
	RTLE;
	return Result;
}

/* {GB_EV_GAUGE_EDITOR_CONSTRUCTOR}.update_attribute_editor */
void F841_6304 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	ti4_1 = F1263_12180(RTCV(F1563_17188(Current)));
	tr2 = eif_out__i4_s1(ti4_1);
	{
		/* INLINED CODE (GB_INTEGER_INPUT_FIELD.update_constant_display) */
		(void) RTCW(tr1);
		/* END INLINED CODE */
	}
	;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	ti4_1 = F1263_12181(RTCV(F1563_17188(Current)));
	tr2 = eif_out__i4_s1(ti4_1);
	{
		/* INLINED CODE (GB_INTEGER_INPUT_FIELD.update_constant_display) */
		(void) RTCW(tr1);
		/* END INLINED CODE */
	}
	;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	ti4_1 = F1263_12182(RTCV(F1563_17188(Current)));
	tr2 = eif_out__i4_s1(ti4_1);
	{
		/* INLINED CODE (GB_INTEGER_INPUT_FIELD.update_constant_display) */
		(void) RTCW(tr1);
		/* END INLINED CODE */
	}
	;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr2 = F1263_12183(RTCV(F1563_17188(Current)));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2) + O4506[Dtype(tr2)-575]);
	tr2 = eif_out__i4_s1(ti4_1);
	{
		/* INLINED CODE (GB_INTEGER_INPUT_FIELD.update_constant_display) */
		(void) RTCW(tr1);
		/* END INLINED CODE */
	}
	;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	tr2 = F1263_12183(RTCV(F1563_17188(Current)));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2) + O4507[Dtype(tr2)-575]);
	tr2 = eif_out__i4_s1(ti4_1);
	{
		/* INLINED CODE (GB_INTEGER_INPUT_FIELD.update_constant_display) */
		(void) RTCW(tr1);
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {GB_EV_GAUGE_EDITOR_CONSTRUCTOR}.set_value */
void F841_6310 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 2, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_i4 = arg1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1262,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A621_212_1, (EIF_POINTER) _A621_212_1, 0, tr1, 0, 1);
	}
	F1563_17199(Current, tr4);
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.update_editors) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {GB_EV_GAUGE_EDITOR_CONSTRUCTOR}.valid_value */
EIF_BOOLEAN F841_6311 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = '\0';
	if ((EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 0L))) {
		tr1 = F1263_12183(RTCV(F1563_17188(Current)));
		tb1 = F576_4892(RTCW(tr1), arg1);
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {GB_EV_GAUGE_EDITOR_CONSTRUCTOR}.set_step */
void F841_6312 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 2, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_i4 = arg1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1262,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A621_213_1, (EIF_POINTER) _A621_213_1, 0, tr1, 0, 1);
	}
	F1563_17199(Current, tr4);
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.update_editors) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {GB_EV_GAUGE_EDITOR_CONSTRUCTOR}.positive_value */
EIF_BOOLEAN F841_6313 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (arg1 > ((EIF_INTEGER_32) 0L));
}

/* {GB_EV_GAUGE_EDITOR_CONSTRUCTOR}.set_leap */
void F841_6314 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 2, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_i4 = arg1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1262,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A621_214_1, (EIF_POINTER) _A621_214_1, 0, tr1, 0, 1);
	}
	F1563_17199(Current, tr4);
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.update_editors) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {GB_EV_GAUGE_EDITOR_CONSTRUCTOR}.set_upper */
void F841_6315 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	tr1 = F1208_11177(RTCW(tr1));
	loc1 = F1078_9458(RTCW(tr1));
	loc2 = RTLNS(eif_new_type(575, 0x00).id, 575, _OBJSIZ_0_1_0_2_0_0_0_0_);
	F576_4884(RTCW(loc2), loc1, arg1);
	F841_6316(Current, *(EIF_REFERENCE *)(Current + _REFACS_3_), loc2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,0,575,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	((EIF_TYPED_VALUE *)tr2+2)->it_r = loc2;
	RTAR(tr2,loc2);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,33,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A328_519_2, (EIF_POINTER) _A328_519_2, (EIF_POINTER)(F841_6316),tr2, 1, 1);
	}
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.for_all_instance_referers) */
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.enable_project_modified) */
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.update_editors) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {GB_EV_GAUGE_EDITOR_CONSTRUCTOR}.adapt_value_range */
void F841_6316 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1262, 0x00),loc1);
	if (EIF_TEST(loc1)) {
		tr1 = F1263_12183(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4492[Dtype(RTCW(tr1))-575])(tr1, arg2);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
	loc2 = tr1;
	loc2 = RTRV(eif_new_type(1262, 0x00),loc2);
	if (EIF_TEST(loc2)) {
		tr1 = F1263_12183(loc2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4492[Dtype(RTCW(tr1))-575])(tr1, arg2);
	}
	RTLE;
}

/* {GB_EV_GAUGE_EDITOR_CONSTRUCTOR}.valid_upper */
EIF_BOOLEAN F841_6317 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	tr1 = F1208_11177(RTCW(tr1));
	ti4_1 = F1078_9458(RTCW(tr1));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (arg1 >= ti4_1);
	RTLE;
	return Result;
}

/* {GB_EV_GAUGE_EDITOR_CONSTRUCTOR}.set_lower */
void F841_6318 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr1 = F1208_11177(RTCW(tr1));
	loc1 = F1078_9458(RTCW(tr1));
	loc2 = RTLNS(eif_new_type(575, 0x00).id, 575, _OBJSIZ_0_1_0_2_0_0_0_0_);
	F576_4884(RTCW(loc2), arg1, loc1);
	F841_6316(Current, *(EIF_REFERENCE *)(Current + _REFACS_3_), loc2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,997,0,575,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	((EIF_TYPED_VALUE *)tr2+2)->it_r = loc2;
	RTAR(tr2,loc2);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,33,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A328_519_2, (EIF_POINTER) _A328_519_2, (EIF_POINTER)(F841_6316),tr2, 1, 1);
	}
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.for_all_instance_referers) */
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.enable_project_modified) */
		/* END INLINED CODE */
	}
	;
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.update_editors) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {GB_EV_GAUGE_EDITOR_CONSTRUCTOR}.valid_lower */
EIF_BOOLEAN F841_6319 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr1 = F1208_11177(RTCW(tr1));
	ti4_1 = F1078_9458(RTCW(tr1));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (arg1 <= ti4_1);
	RTLE;
	return Result;
}

/* {GB_EV_GAUGE_EDITOR_CONSTRUCTOR}.value_string */

EIF_REFERENCE F841_6320 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6320,RTMS_EX_H("Value",5,1635158373));
}

/* {GB_EV_GAUGE_EDITOR_CONSTRUCTOR}.step_string */

EIF_REFERENCE F841_6321 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6321,RTMS_EX_H("Step",4,1400137072));
}

/* {GB_EV_GAUGE_EDITOR_CONSTRUCTOR}.leap_string */

EIF_REFERENCE F841_6322 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6322,RTMS_EX_H("Leap",4,1281712496));
}

/* {GB_EV_GAUGE_EDITOR_CONSTRUCTOR}.upper_string */

EIF_REFERENCE F841_6323 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6323,RTMS_EX_H("Upper",5,1887066994));
}

/* {GB_EV_GAUGE_EDITOR_CONSTRUCTOR}.lower_string */

EIF_REFERENCE F841_6324 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6324,RTMS_EX_H("Lower",5,1870679410));
}

void EIF_Minit328 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
