/*
 * Code for class GB_EV_WIDGET_EDITOR_CONSTRUCTOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gb336.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GB_EV_WIDGET_EDITOR_CONSTRUCTOR}.ev_type */
EIF_REFERENCE F849_6463 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_6_);
}


/* {GB_EV_WIDGET_EDITOR_CONSTRUCTOR}.update_attribute_editor */
void F849_6465 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	ti4_1 = F1106_10145(RTCV(F1563_17188(Current)));
	tr2 = eif_out__i4_s1(ti4_1);
	F1208_11176(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	ti4_1 = F1106_10144(RTCV(F1563_17188(Current)));
	tr2 = eif_out__i4_s1(ti4_1);
	F1208_11176(RTCW(tr1), tr2);
	RTLE;
}

/* {GB_EV_WIDGET_EDITOR_CONSTRUCTOR}.attribute_editor */
EIF_REFERENCE F849_6466 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_REFERENCE tr6 = NULL;
	EIF_REFERENCE tr7 = NULL;
	EIF_REFERENCE tr8 = NULL;
	EIF_REFERENCE tr9 = NULL;
	EIF_REFERENCE tr10 = NULL;
	EIF_REFERENCE tr11 = NULL;
	EIF_REFERENCE tr12 = NULL;
	EIF_REFERENCE tr13 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(15);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLR(7,tr6);
	RTLR(8,tr7);
	RTLR(9,tr8);
	RTLR(10,tr9);
	RTLR(11,tr10);
	RTLR(12,tr11);
	RTLR(13,tr12);
	RTLR(14,tr13);
	RTLIU(15);
	
	RTGC;
	Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_7_3_0_1_0_0_0_0_);
	F1209_11188(RTCW(Result), *(EIF_REFERENCE *)(Current));
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.initialize_attribute_editor) */
		/* END INLINED CODE */
	}
	;
	tr1 = RTLNSMART(eif_new_type(1207, 0).id);
	tr2 = RTOSCF(6473,F849_6473, (Current));
	tr3 = RTOSCF(5788,F689_5788, (Current));
	tr4 = RTOSCF(5789,F689_5789, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr5 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr5+1)->it_r = Current;
	RTAR(tr5,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr8= RTLNRF(typres0.id, (EIF_POINTER) __A336_511_2, (EIF_POINTER) _A336_511_2, (EIF_POINTER)(F849_6470),tr5, 1, 1);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr9 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr9+1)->it_r = Current;
	RTAR(tr9,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1076,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr12= RTLNRF(typres0.id, (EIF_POINTER) __A336_512_2, (EIF_POINTER) _A336_512_2, (EIF_POINTER)(F849_6471),tr9, 1, 1);
	}
	tr13 = *(EIF_REFERENCE *)(Current);
	F1208_11174(RTCW(tr1), Current, Result, tr2, tr3, tr4, tr8, tr12, tr13);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1207, 0).id);
	tr2 = RTOSCF(6474,F849_6474, (Current));
	tr3 = RTOSCF(5790,F689_5790, (Current));
	tr4 = RTOSCF(5791,F689_5791, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr5 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr5+1)->it_r = Current;
	RTAR(tr5,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr8= RTLNRF(typres0.id, (EIF_POINTER) __A336_513_2, (EIF_POINTER) _A336_513_2, (EIF_POINTER)(F849_6472),tr5, 1, 1);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr9 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr9+1)->it_r = Current;
	RTAR(tr9,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1076,0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr12= RTLNRF(typres0.id, (EIF_POINTER) __A336_512_2, (EIF_POINTER) _A336_512_2, (EIF_POINTER)(F849_6471),tr9, 1, 1);
	}
	tr13 = *(EIF_REFERENCE *)(Current);
	F1208_11174(RTCW(tr1), Current, Result, tr2, tr3, tr4, tr8, tr12, tr13);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	F849_6465(Current);
	F1563_17197(Current, Result);
	F1563_17196(Current, Result);
	RTLE;
	return Result;
}

/* {GB_EV_WIDGET_EDITOR_CONSTRUCTOR}.set_minimum_width */
void F849_6470 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 2, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_i4 = arg1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1193,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A552_182_1, (EIF_POINTER) _A552_182_1, 0, tr1, 0, 1);
	}
	F1563_17200(Current, tr4);
	RTLE;
}

/* {GB_EV_WIDGET_EDITOR_CONSTRUCTOR}.valid_minimum_dimension */
EIF_BOOLEAN F849_6471 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 0L));
}

/* {GB_EV_WIDGET_EDITOR_CONSTRUCTOR}.set_minimum_height */
void F849_6472 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,1033,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 2, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_i4 = arg1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1193,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A552_183_1, (EIF_POINTER) _A552_183_1, 0, tr1, 0, 1);
	}
	F1563_17200(Current, tr4);
	RTLE;
}

/* {GB_EV_WIDGET_EDITOR_CONSTRUCTOR}.minimum_width_string */

EIF_REFERENCE F849_6473 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6473,RTMS_EX_H("Minimum_width",13,1792475752));
}

/* {GB_EV_WIDGET_EDITOR_CONSTRUCTOR}.minimum_height_string */

EIF_REFERENCE F849_6474 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6474,RTMS_EX_H("Minimum_height",14,1514105716));
}

void EIF_Minit336 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
