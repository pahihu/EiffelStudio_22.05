/*
 * Code for class GB_EV_TEXT_ALIGNABLE_EDITOR_CONSTRUCTOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gb331.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GB_EV_TEXT_ALIGNABLE_EDITOR_CONSTRUCTOR}.ev_type */
EIF_REFERENCE F844_6358 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_10_);
}


/* {GB_EV_TEXT_ALIGNABLE_EDITOR_CONSTRUCTOR}.attribute_editor */
EIF_REFERENCE F844_6360 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	Result = RTLNS(eif_new_type(1208, 0x00).id, 1208, _OBJSIZ_7_3_0_1_0_0_0_0_);
	F1209_11188(RTCW(Result), *(EIF_REFERENCE *)(Current));
	F1203_11116(RTCW(Result), ((EIF_INTEGER_32) 2L));
	{
		/* INLINED CODE (GB_EV_EDITOR_CONSTRUCTOR.initialize_attribute_editor) */
		/* END INLINED CODE */
	}
	;
	tr1 = RTLNSMART(eif_new_type(1241, 0).id);
	tr2 = RTOSCF(5849,F689_5849, (Current));
	F1113_10182(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr2 = RTOSCF(5850,F689_5850, (Current));
	F1112_10176(RTCW(tr1), tr2);
	F1120_10306(RTCW(Result), *(EIF_REFERENCE *)(Current + _REFACS_8_));
	tr1 = RTLNSMART(eif_new_type(1253, 0).id);
	F1088_9856(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = RTOSCF(5850,F689_5850, (Current));
	F1112_10176(RTCW(tr1), tr2);
	F1120_10306(RTCW(Result), *(EIF_REFERENCE *)(Current + _REFACS_7_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F1248_12039(RTCW(tr1));
	tr1 = RTLNSMART(eif_new_type(1189, 0).id);
	tr2 = RTOSCF(6372,F844_6372, (Current));
	F1113_10182(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F1120_10306(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_4_));
	tr1 = RTLNSMART(eif_new_type(1189, 0).id);
	tr2 = RTOSCF(6373,F844_6373, (Current));
	F1113_10182(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F1120_10306(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_5_));
	tr1 = RTLNSMART(eif_new_type(1189, 0).id);
	tr2 = RTOSCF(6374,F844_6374, (Current));
	F1113_10182(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F1120_10306(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_6_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1152_10678(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A331_508, (EIF_POINTER) _A331_508, (EIF_POINTER)(F844_6363),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1152_10678(RTCW(tr1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,997,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,0,997,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A331_528, (EIF_POINTER) _A331_528, (EIF_POINTER)(F1563_17201),tr2, 1, 0);
	}
	F681_5535(RTCW(tr1), tr3);
	F844_6361(Current);
	F1563_17197(Current, Result);
	F1563_17196(Current, Result);
	RTLE;
	return Result;
}

/* {GB_EV_TEXT_ALIGNABLE_EDITOR_CONSTRUCTOR}.update_attribute_editor */
void F844_6361 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1152_10678(RTCW(tr1));
	F688_5577(RTCW(tr1));
	loc1 = F1114_10188(RTCV(F1563_17188(Current)));
	switch (loc1) {
		case 1L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			F1109_10165(RTCW(tr1));
			break;
		case 2L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			F1109_10165(RTCW(tr1));
			break;
		case 3L:
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			F1109_10165(RTCW(tr1));
			break;
		default:
			break;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1152_10678(RTCW(tr1));
	F688_5579(RTCW(tr1));
	RTLE;
}

/* {GB_EV_TEXT_ALIGNABLE_EDITOR_CONSTRUCTOR}.selection_changed */
void F844_6363 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1253_12120(RTCW(tr1));
	tr1 = F1113_10183(RTCW(tr1));
	tr2 = RTOSCF(6372,F844_6372, (Current));
	tb1 = F1078_9438(RTCW(tr1), tr2);
	if (tb1) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,0,997,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 1, 1);
		}
		
		{
			static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1113,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr4= RTLNRF(typres0.id, (EIF_POINTER) __A474_54_1, (EIF_POINTER) _A474_54_1, 0, tr1, 0, 1);
		}
		F1563_17199(Current, tr4);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr1 = F1253_12120(RTCW(tr1));
		tr1 = F1113_10183(RTCW(tr1));
		tr2 = RTOSCF(6373,F844_6373, (Current));
		tb1 = F1078_9438(RTCW(tr1), tr2);
		if (tb1) {
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,0,997,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr1 = RTLNTS(typres0.id, 1, 1);
			}
			
			{
				static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1113,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A474_52_1, (EIF_POINTER) _A474_52_1, 0, tr1, 0, 1);
			}
			F1563_17199(Current, tr4);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			tr1 = F1253_12120(RTCW(tr1));
			tr1 = F1113_10183(RTCW(tr1));
			tr2 = RTOSCF(6374,F844_6374, (Current));
			tb1 = F1078_9438(RTCW(tr1), tr2);
			if (tb1) {
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFFF9,0,997,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr1 = RTLNTS(typres0.id, 1, 1);
				}
				
				{
					static EIF_TYPE_INDEX typarr0[] = {1071,0xFFF9,1,997,1113,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr4= RTLNRF(typres0.id, (EIF_POINTER) __A474_53_1, (EIF_POINTER) _A474_53_1, 0, tr1, 0, 1);
				}
				F1563_17199(Current, tr4);
			} else {
			}
		}
	}
	RTLE;
}

/* {GB_EV_TEXT_ALIGNABLE_EDITOR_CONSTRUCTOR}.ev_textable_left_string */

EIF_REFERENCE F844_6372 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6372,RTMS_EX_H("Left",4,1281713780));
}

/* {GB_EV_TEXT_ALIGNABLE_EDITOR_CONSTRUCTOR}.ev_textable_center_string */

EIF_REFERENCE F844_6373 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6373,RTMS_EX_H("Center",6,1985624946));
}

/* {GB_EV_TEXT_ALIGNABLE_EDITOR_CONSTRUCTOR}.ev_textable_right_string */

EIF_REFERENCE F844_6374 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6374,RTMS_EX_H("Right",5,1769014388));
}

void EIF_Minit331 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
